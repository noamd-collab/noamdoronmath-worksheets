# -*- coding: utf-8 -*-
u"""deliver.py — v6.5: a level's DELIVERABLE, written by the build that made it.

THE AUTHOR'S DECISION (DELIVERABLE_SPEC.md, 21.9.2026). Every sheet ships as

    <out>/<level>/
      sheet.pdf              the printable page
      source/                the editable source, as it was built
      sheet.json             the questions, the data and the figures
      figures/<fig_id>.svg   every figure as its own file, with stable ids
      figures/<fig_id>.py    the code that made that figure
      build.json             skill version, source hash, per-file hashes

so the author's AI can highlight a point, a segment or an angle on a figure
WITHOUT re-reading an image, and so a sheet that was sold can be rebuilt
exactly. Rule 1 of the spec is the whole design: the PDF, the SVG and the
JSON come from ONE build. Nothing here draws anything and nothing here
re-runs a builder: every figure was recorded by the render that produced it
(`export.stamp`), and this module looks it up by the key written into the
file.

USE (one call; `build.py` makes it part of every build)

    import deliver
    deliver.deliver(L, out_dir="out/deliver", pdf="out/a.pdf",
                    source=["content.py", "level.py"], package="z08")

THE CONTENT SCHEMA (spec item 3; backward compatible)
-----------------------------------------------------
A question, and a sub-item, may declare what is GIVEN and what is TO PROVE:

    dict(n=7, text=..., fig=svg,
         given=["AB = 12", {"type": "midpoint", "point": "M", "of": "AB",
                            "text": "M אמצע AB"}],
         items=[dict(label="ב", text="...", space=30, fig=svg2,
                     to_prove=[{"type": "equal_length", "of": ["MD", "MC"]}],
                     answer="...")])

A plain string is the wording as the sheet states it. A dict is a CONSTRAINT
— and it is not a second source of truth: it must MATCH a constraint the
figure already exported from its own build, and all it does is label that
constraint `given` or `to_prove` and tie it to its item (spec rules 1-3). A
declaration that matches nothing is refused, because the drawing and the
question would then be saying different things.

A level that declares nothing still builds, and its constraints export as
`derived` — which is what every sheet in the corpus does today.

WHAT IS CHECKED BEFORE ANYTHING IS WRITTEN (spec section 8)
-----------------------------------------------------------
1. every exported constraint re-measured on the finished SVG;
2. a `to_prove` constraint MARKED in the drawing — refused (the sheet would
   be giving away the proof);
3. an object whose `svg_id` is not in the SVG — refused;
4. a number printed in the PDF that comes from no data of this level —
   reported (and refused with `strict_numbers=True`).
Two builds of the same source write the same ids and the same sheet.json
apart from its timestamp.
"""
import datetime
import hashlib
import unicodedata
import json
import math                 # v6.10: C3 statements read the figure
import os
import re
import shutil
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import export                                     # noqa: E402
import didactic as DD                             # noqa: E402
import visual_model as VM                         # noqa: E402
import wspec_build as WB                          # noqa: E402  (v6.9)

SKILL_VERSION = "6.18-noam"   # v6.17 integrate (BRIEF_V617: vocabulary V1-V5 of the 18 packages); was 6.16.2-noam (v6.16.2 apply; 6.16.1-noam v6.16.1 integrate; 6.16-noam v6.16 deliver; 6.15-noam v6.15 wrap-up; v6.14 kept 6.13-noam, no package)

# the sheet's own item letters, in the order Hebrew counts them
_HEB = u"אבגדהוזחטיכלמנסעפצקרשת"
_LAT = "abcdefghijklmnopqrstuvwx"

_SVG_RE = re.compile(r"<svg\b.*?</svg>", re.S)
_TEXT_RE = re.compile(r"<text\b[^>]*>(.*?)</text>", re.S)
_TAG_RE = re.compile(r"<[^>]*>")
_NUM_RE = re.compile(u"−?-?\\d+(?:[.,]\\d+)?")


class DeliverError(AssertionError):
    """A deliverable that would not be true to its own build."""



# (v6.10 fix r1, s2) a NUMBER printed in a figure: digits (a sign, a
# fraction, a decimal, a root) with or without its unit -- '48°', '6 ס״מ',
# '6√2' are numbers too (N3 matched digits alone, so a degree value never
# had to name its object)
_NUM_LABEL = re.compile(u"^[\u2212\\-]?[\\d.,/\u2212\\-]*\\d[\\d.,/]*$")
_UNIT_TAIL = re.compile(u"\\s*(?:\u00b0|\u2032|ס\"מ|ס\u05f4מ|סמ\"ר|"
                        u"סמ\u05f4ר|cm|%)$")


def numeric_label(t):
    t = _UNIT_TAIL.sub(u"", str(t or u"").strip())
    t = t.replace(u"\u221a", u"")
    return bool(_NUM_LABEL.match(t))

def _bad(said, fix):
    raise DeliverError("deliver: %s -- %s" % (said, fix))


# --------------------------------------------------------------- level ----
def item_id(n, label):
    """`q7b` — the id of one sub-item, from its Hebrew letter."""
    i = _HEB.find(label.strip()[0]) if label else -1
    return "q%s%s" % (n, _LAT[i] if 0 <= i < len(_LAT) else
                      re.sub(r"\W", "", label or "x"))


def _as_item(it):
    """One sub-item as a dict, whether the author wrote a tuple or a dict.

    The emitter takes 3-tuples (and emit_plus a 4-tuple with a figure); the
    deliverable needs a name for every part, and the author needs somewhere
    to declare `given` / `to_prove` / `answer`. Both spellings live side by
    side, and `normalize()` hands the emitter the tuple it has always had."""
    if isinstance(it, dict):
        d = dict(it)
        d.setdefault("label", "")
        d.setdefault("text", "")
        d.setdefault("space", 0)
        return d
    it = tuple(it)
    d = {"label": it[0] if len(it) > 0 else "",
         "text": it[1] if len(it) > 1 else "",
         "space": it[2] if len(it) > 2 else 0}
    if len(it) > 3 and it[3]:
        d["fig"] = it[3]
    return d


def normalize(L):
    """The level the EMITTER takes: every sub-item back to its tuple.

    A dict item is the deliverable's spelling; the emitter never learns about
    it, so no gate, no fixture and no shipped level changes behaviour.

    v6.9: a question that carries a wspec `spec=` is expanded first
    (wspec_build.expand_level -- the same object back when none does)."""
    L = WB.expand_level(L)
    out = dict(L)
    qs = []
    for q in L.get("questions", []):
        q2 = dict(q)
        items = []
        for it in q.get("items", []):
            if isinstance(it, dict):
                d = _as_item(it)
                items.append((d["label"], d["text"], d["space"], d["fig"])
                             if d.get("fig") else
                             (d["label"], d["text"], d["space"]))
            else:
                items.append(tuple(it))
        if items:
            q2["items"] = items
        # v6.7.1-noam: the didactic schema never reaches the emitter
        for k in ("given", "to_prove", "to_construct", "aux", "dashed",
                  "didactic", "visual", "no_target_reason", "variables",
                  "_wspec", "spec_unsupported"):
            q2.pop(k, None)
        qs.append(q2)
    out["questions"] = qs
    return out


def declares(L):
    """True when this level uses any of the v6.5 content schema."""
    for q in L.get("questions", []):
        if q.get("given") or q.get("to_prove"):
            return True
        for it in q.get("items", []):
            if isinstance(it, dict) and (it.get("given") or it.get("to_prove")
                                         or it.get("answer")):
                return True
    return False


# -------------------------------------------------------------- figures ---
def svgs_in(blob):
    """Every <svg> inside a figure slot. `figkit_plus.row()` puts three of
    them in one HTML table, and each one is a figure of its own."""
    return _SVG_RE.findall(str(blob or ""))


def _fig_entries(L):
    """[(fig_id, svg, owner_question, owner_item)] in reading order."""
    out = []
    for q in L.get("questions", []):
        n = q.get("n")
        got = svgs_in(q.get("fig"))
        for k, svg in enumerate(got):
            out.append(("q%s_head%s" % (n, "" if k == 0 else "_%d" % (k + 1)),
                        svg, "q%s" % n, None))
        for it in q.get("items", []):
            d = _as_item(it)
            if not d.get("fig"):
                continue
            iid = item_id(n, d["label"])
            for k, svg in enumerate(svgs_in(d["fig"])):
                out.append(("%s%s" % (iid, "" if k == 0 else "_%d" % (k + 1)),
                            svg, "q%s" % n, iid))
    return out


# v6.6 E (X1R2-02): ids unique per SHEET. A figure file keeps its short ids
# (seg-AB); the sheet's HTML -- which inlines every figure, and is what the
# PDF is made from -- carries each one as <fig_id>__<id>, so the document's
# getElementById('q7_head__seg-AB') names ONE stroke. sheet.json records both
# (`svg_id` and `sheet_svg_id`).
SHEET_SEP = "__"
_FIG_KEY = re.compile(r'<svg[^>]*\bdata-fig="([0-9a-f]+)"')
_ID_ATTR = re.compile(r'(\sid=")([^"]+)(")')
_ID_REF = re.compile(r'(url\(#|href="#)([^)"]+)')


_FAM_TAG = re.compile(r"<!--\s*fam:\s*(.*?)\s*-->")


def svg_fam(svg):
    """The fam the figure's SVG declares (`<!--fam:NAME-->`, v6 C3), or None.
    v6.6 E r1 (E-X1R2-06-fam-null): sheet.json's fam is never null for a
    figure whose file names its fam."""
    m = _FAM_TAG.search(str(svg or ""))
    return m.group(1) if m else None


def _fig_key(svg):
    """The key that names one inlined figure: its data-fig, or (v6.9) the
    content key of an engine (wspec) figure, which carries no data-fig."""
    m = _FIG_KEY.search(svg)
    if m:
        return m.group(1)
    if WB.is_spec_svg(svg):
        return WB.fig_key(svg)
    return None


def sheet_fig_ids(L):
    """{data-fig key: [fig_id, ...]} in reading order, from the same walk
    that names the figures in sheet.json."""
    out = {}
    for fid, svg, _q, _i in _fig_entries(WB.expand_level(L)):
        k = _fig_key(svg)
        if k:
            out.setdefault(k, []).append(fid)
    return out


def prefix_ids(svg, prefix):
    """Every id of one inlined figure, and every #reference to it, with the
    figure's prefix."""
    if not prefix:
        return svg
    svg = _ID_ATTR.sub(lambda m: m.group(1) + prefix + m.group(2) +
                       m.group(3), svg)
    return _ID_REF.sub(lambda m: m.group(1) + prefix + m.group(2), svg)


def sheet_unique_ids(doc, L):
    """The sheet document with every inlined figure's ids prefixed by its
    figure id (an SVG no figure owns -- an icon -- by its position)."""
    by_key = sheet_fig_ids(L)
    used = {}
    k = [0]

    def one(m):
        svg = m.group(0)
        k[0] += 1
        km = _fig_key(svg)
        fid = None
        if km and by_key.get(km):
            lst = by_key[km]
            n = used.get(km, 0)
            used[km] = n + 1
            fid = lst[n] if n < len(lst) else "%s-%d" % (lst[-1], n + 1)
        if fid is None:
            fid = "svg%d" % k[0]
        return prefix_ids(svg, fid + SHEET_SEP)
    return _SVG_RE.sub(one, doc)


def _numbers(text):
    return set(_NUM_RE.findall(str(text).replace(u"−", "-")))


def _norm_num(s):
    s = str(s).replace(u"−", "-").replace(",", ".")
    try:
        v = float(s)
    except ValueError:
        return None
    return ("%g" % v)


# keys of a level that carry LAYOUT, never printed data: a `space` of 20
# lines, a figure slot's raw SVG, a CSS class, the level's key
_LAYOUT_KEYS = frozenset(("fig", "space", "cls", "key", "style", "width",
                          "height", "size", "lines", "cols", "layout", "css",
                          "package", "grade_key", "fam"))
_SVG_BLOCK = re.compile(r"<svg\b.*?</svg>", re.S)
_ENT = re.compile(r"&#?\w+;")


def _printed_text(s):
    """What a string of the level PRINTS: its SVGs (read separately, from
    their <text> only) and its HTML tags (whose attributes are numbers of
    layout -- a width, a margin) removed."""
    s = _SVG_BLOCK.sub(" ", str(s))
    s = _TAG_RE.sub(" ", s)
    return _ENT.sub(" ", s)


_MAQAF_HYPHEN = re.compile(u"(?<=[\u05d0-\u05ea])-")


def _level_numbers(L, figs):
    """Every number this level's DATA states: its own printed text, and the
    text its figures print. A number in the PDF that is in neither came from
    somewhere else, and the spec wants to hear about it.

    v6.5 X2 r1 (MUST-6): only what is PRINTED counts as data. The walk used
    to read every string of the level, the raw SVG of every figure slot
    included, so each coordinate, stroke width and viewBox number was
    'data': on z08_a every integer 1-12 was accepted whatever the page
    printed. Layout keys (`space`, `fig`, ...) and a tuple item's space are
    skipped, SVG and HTML markup is stripped, and a figure contributes only
    its <text>."""
    seen = set()

    def take(text):
        # (v6.16 integrate) a hyphen right after a Hebrew letter is a maqaf
        # ("40 ו-30", "ב-C"), never a minus sign (the bound-prose atom rule,
        # wspec/schema_bound.py): "ו-30" states 30
        text = _MAQAF_HYPHEN.sub(u"\u05be", _printed_text(text))
        for t in _NUM_RE.findall(text.replace(u"−", "-")):
            x = _norm_num(t)
            if x is not None:
                seen.add(x)

    def walk(v, key=None):
        if key in _LAYOUT_KEYS:
            return
        if isinstance(v, str):
            take(v)
        elif isinstance(v, bool) or v is None:
            return
        elif isinstance(v, (int, float)):
            if key in ("n", "value", "answer", "answers"):
                seen.add("%g" % float(v))
        elif isinstance(v, dict):
            for k in v:
                walk(v[k], k)
        elif isinstance(v, (list, tuple)):
            for x in v:
                walk(x, key)

    for k, v in L.items():
        if k == "questions":
            continue
        walk(v, k)
    for q in L.get("questions", []):
        for k, v in q.items():
            if k == "items":
                continue
            walk(v, k)
        for it in q.get("items", []):
            d = _as_item(it)
            for k, v in d.items():
                walk(v, k)
    for _fid, svg, _q, _i in figs:
        for raw in _TEXT_RE.findall(svg):
            for t in _NUM_RE.findall(_TAG_RE.sub("", raw)
                                     .replace(u"−", "-")):
                x = _norm_num(t)
                if x is not None:
                    seen.add(x)
    return seen


def stray_numbers(L, entries, printed, pages=0):
    """The numbers on the page that no datum of this level states.

    The level's own text, its figures' printed text and the page numbers are
    the data; anything else on the paper came from somewhere that cannot be
    rebuilt from the source, which is what spec rule 1 is about."""
    known = _level_numbers(L, entries)
    known |= set("%g" % i for i in range(1, int(pages) + 1))
    return sorted(set(g for g in printed if g not in known),
                  key=lambda v: (len(v), v))


def pdf_numbers(path):
    """The numbers PRINTED on the page, read from the finished PDF."""
    try:
        import pymupdf
    except ImportError:                       # no PDF, no check
        return None, 0
    doc = pymupdf.open(str(path))
    out = []
    for pg in doc:
        for t in _NUM_RE.findall(pg.get_text("text").replace(u"−", "-")):
            x = _norm_num(t)
            if x is not None:
                out.append(x)
    return out, len(doc)


# --------------------------------------------------- the code of a figure --
_TMP_DIR = re.compile(u"^(?:/private)?/(?:tmp|var/folders)/")


def _skill_lines():
    """How a figure script finds the skill (v6.6 E r1, E-figs-tmp-path):
    WORKSHEET_SKILL_DIR, else a `skill` folder beside the package, else the
    installed skill; the build's own skill folder is named only when it is
    not a temporary folder (a /tmp path exists on no other machine and is
    gone after a reboot)."""
    cands = []
    if not _TMP_DIR.match(os.path.realpath(export.SKILL_HOME)) and \
            not _TMP_DIR.match(export.SKILL_HOME):
        cands.append(repr(export.SKILL_HOME))
    cands += [u"os.path.join(_HERE, \"..\", \"skill\")",
              u"os.path.join(_HERE, \"..\", \"..\", \"skill\")",
              u"os.path.expanduser(\"~/.claude/skills/"
              u"hebrew-math-worksheet-v5\")"]
    return [u"_HERE = os.path.dirname(os.path.abspath("
            u"globals().get(\"__file__\", \".\")))",
            # v6.8 r1: a skill already importable (PYTHONPATH, or loaded
            # by the caller) is used before any guessed folder
            u"_FOUND = __import__(\"importlib.util\").util.find_spec("
            u"\"figkit\") is not None",
            u"SKILL = os.environ.get(\"WORKSHEET_SKILL_DIR\") or (None if "
            u"_FOUND else next(("
            u"p for p in (%s) if os.path.isfile(os.path.join(p, "
            u"\"figkit.py\"))), None))" % u", ".join(cands),
            u"if SKILL:",
            u"    sys.path.insert(0, SKILL)",
            # v6.8 r1 (audit-rerun-needs-env): the skill on PYTHONPATH is
            # found too -- only a skill nowhere at all stops the script
            u"elif not _FOUND:",
            u"    raise SystemExit(\"set WORKSHEET_SKILL_DIR to the folder of "
            u"the hebrew-math-worksheet skill\")"]


def _own_modules(src):
    """The modules a recorded call imports that are NOT the skill's (the
    level's own helpers)."""
    out = []
    for m in re.findall(r"^import ([A-Za-z_][A-Za-z0-9_]*)\s*$", src, re.M):
        if not os.path.isfile(os.path.join(export.SKILL_HOME, m + ".py")):
            out.append(m)
    return out


def _script(rec, light=False):
    """The runnable part of figures/<id>.py, or None. `light=True`: the
    level's own module is loaded with export.light_import (its defs, not its
    figures) -- the variant is shipped only when it re-draws the figure."""
    rp = (rec.code or {}).get("replay") or {}
    src = rp.get("src")
    if not src:
        return None
    lines = [u"import os", u"import sys",
             u"from fractions import Fraction  # noqa: F401"]
    lines += _skill_lines()
    # v6.6 E: a figure drawn by the level's own helper imports it from the
    # package's source/ folder
    lines.append(u"sys.path.insert(0, os.path.join(_HERE, \"..\", "
                 u"\"source\"))")
    lines += list(rp.get("sheet") or [])
    if light:
        own = _own_modules(src)
        if not own:
            return None
        lines.append(u"import export  # the skill's; light_import below")
        for m in own:
            src = re.sub(r"^import %s\s*$" % re.escape(m),
                         u"%s = export.light_import(%r)  # its defs only: "
                         u"the call below runs in well under a second"
                         % (m, m), src, flags=re.M)
    lines.append(src)
    return u"\n".join(lines) + u"\n"


def run_script(code):
    """Run a figure's script in THIS process and return its `svg`, leaving
    no trace: the figure registry and the sheet-wide settings are restored,
    because a packaging run must not change the build it describes."""
    import sys as _sys
    saved_figs = (dict(export._FIGS), list(export._ORDER))
    fp = _sys.modules.get("figkit_plus")
    nl = _sys.modules.get("numberline")
    saved = [(fp, "SHEET", dict(getattr(fp, "SHEET", {}) or {})),
             (fp, "HOUSE_FALLBACKS", list(getattr(fp, "HOUSE_FALLBACKS", [])
                                          or [])),
             (nl, "_SHEET", dict(getattr(nl, "_SHEET", {}) or {}))]
    ns = {"__name__": "figure_code"}
    try:
        exec(compile(code, "<figure code>", "exec"), ns)
        return ns.get("svg")
    finally:
        export._FIGS.clear()
        export._FIGS.update(saved_figs[0])
        export._ORDER[:] = saved_figs[1]
        for mod, name, val in saved:
            if mod is None or not hasattr(mod, name):
                continue
            cur = getattr(mod, name)
            if isinstance(cur, dict):
                cur.clear()
                cur.update(val)
            elif isinstance(cur, list):
                cur[:] = val


def _light_effects(rec):
    """True when the level's own module has a top-level statement that
    export.light_import skips and that could change another module's state
    (a bare call, a subscript store, a statement that failed)."""
    rp = (rec.code or {}).get("replay") or {}
    for m in _own_modules(rp.get("src") or ""):
        try:
            mod = export.light_import(m)
        except Exception:                        # noqa: BLE001
            return True
        if getattr(mod, "_light_skipped", None):
            return True
    return False


def run_script_fresh(code, rec=None):
    """Run a figure's script in a NEW python process -- no module the build
    imported or changed is shared -- and return the SVG it draws."""
    import subprocess
    import sys as _sys
    import tempfile
    rp = ((rec.code or {}).get("replay") or {}) if rec is not None else {}
    paths = [export.SKILL_HOME]
    for m in _own_modules(rp.get("src") or ""):
        try:
            import importlib.util
            sp = importlib.util.find_spec(m)
            if sp is not None and sp.origin:
                paths.append(os.path.dirname(sp.origin))
        except Exception:                        # noqa: BLE001
            continue
    d = tempfile.mkdtemp(prefix="figfresh")
    f = os.path.join(d, "fig.py")
    with open(f, "w", encoding="utf-8") as fh:
        fh.write(code + u"\nimport sys as _s\n_s.stdout.write(svg)\n")
    env = dict(os.environ, WORKSHEET_SKILL_DIR=export.SKILL_HOME,
               PYTHONPATH=os.pathsep.join(paths))
    try:
        r = subprocess.run([_sys.executable, f], cwd=d, env=env,
                           capture_output=True, text=True)
    finally:
        try:
            os.remove(f)
            os.rmdir(d)
        except OSError:
            pass
    if r.returncode != 0:
        raise RuntimeError(r.stderr[-300:])
    return r.stdout


def verify_code(rec, svg):
    """(runnable script or None, why). The script ships as RUNNABLE only when
    running it re-draws `svg` byte for byte (spec rule 6)."""
    light = _script(rec, light=True) if rec is not None else None
    if light is not None:
        try:
            # v6.7 (E-r2-light-import-state): in THIS process the modules the
            # build touched keep its state, so a light script that skips a
            # statement with an effect could still come out "identical". It
            # is checked in a fresh process whenever light_import skipped
            # such a statement.
            got = (run_script_fresh(light, rec) if _light_effects(rec)
                   else run_script(light))
        except Exception:                        # noqa: BLE001
            got = None
        if isinstance(got, str) and got == svg:
            return light, "verified"
        if isinstance(got, str) and len(svgs_in(got)) == 1 and \
                svgs_in(got)[0] == svg:
            return light, "verified:element"
    code = _script(rec) if rec is not None else None
    if code is None:
        rp = (rec.code or {}).get("replay") if rec is not None else None
        return None, ("the figure was built by calls this module cannot "
                      "write as source (a value with no literal form, or a "
                      "builder that records no call)" if rp is not None else
                      "the builder that drew it records no call")
    try:
        got = run_script(code)
    except Exception as e:                       # noqa: BLE001
        return None, "running the recorded call failed: %s" % (
            str(e).splitlines()[0][:160] if str(e) else type(e).__name__)
    if not isinstance(got, str):
        return None, "the recorded call does not return an SVG string"
    if got != svg:
        # v6.6 E: the sheet carries the <svg> element alone (svgs_in), and a
        # builder may append its claims as a comment after </svg> (solidkit's
        # v3d tag) -- the same drawing, compared the way the sheet holds it
        one = svgs_in(got)
        if len(one) != 1 or one[0] != svg:
            return None, "the recorded call draws a different SVG"
        return code, "verified:element"
    return code, "verified"


def figure_code(rec, fig_id, svg=None, verify=True):
    """`figures/<fig_id>.py` — the code that made this figure.

    Spec rule 6: the drawing's code travels beside it, so a number can be
    changed without guessing what was there. v6.5 X2 r1 (MUST-3): it is the
    author's CALL INTO THE SKILL with the values it was given (recorded by
    export.entry / export.seq / export.replay at the moment of the call),
    written as a script that re-draws the figure -- and it is marked
    runnable only after packaging has run it and got the same file back.
    Below it, for reading, the author's own code around the call: each
    frame's source and the literal values it held."""
    head = [u"# -*- coding: utf-8 -*-",
            u"# %s — the code that drew this figure." % fig_id,
            u"# Written by deliver.py from the build itself (skill %s)."
            % SKILL_VERSION]
    if rec is None:
        head.append(u"# This figure was not built by a recorded builder: it "
                    u"reached the sheet as an SVG string.")
        return u"\n".join(head) + u"\n", False
    code = rec.code or {}
    if rec.kind:
        head.append(u"# kind: %s" % rec.kind)
    if rec.fam:
        head.append(u"# fam:  %s" % rec.fam)
    view = dict((rec.objects.view or {}))
    view.pop("data_to_svg", None)
    view.pop("rows", None)
    head.append(u"# view: %s" % json.dumps(view, sort_keys=True))
    script, why = (verify_code(rec, svg) if (verify and svg is not None)
                   else (None, "not verified"))
    body = []
    if script:
        head.append(u"# RUNNABLE: running this file re-draws figures/%s.svg "
                    u"byte for byte (checked when the package was written)."
                    % fig_id)
        head.append(u"# Change a number in the call below and run it again; "
                    u"`python3 %s.py > %s.svg`." % (fig_id, fig_id))
        body.append(script.rstrip("\n"))
        body.append(u"")
        body.append(u"if __name__ == \"__main__\":")
        if why == "verified:element":
            # v6.8 G2: the builder appends its claims as a comment after
            # </svg> (solidkit's <!--v3d:...-->); the file holds the drawing
            # as the sheet printed it, the <svg> element alone, and "byte for
            # byte" must be true of what this script writes
            body.append(u"    # the <svg> element alone, as figures/%s.svg "
                        u"holds it (the builder's trailing <!--v3d--> claim "
                        u"is in sheet.json as xyz)" % fig_id)
            body.append(u"    sys.stdout.write(svg[svg.index(\"<svg\"):"
                        u"svg.index(\"</svg>\") + len(\"</svg>\")])")
        else:
            body.append(u"    sys.stdout.write(svg)")
    else:
        head.append(u"# NOT RUNNABLE ON ITS OWN: %s. The author's code that "
                    u"asked for it follows." % why)
        rp = code.get("replay") or {}
        if rp.get("src"):
            body.append(u"# the recorded call (it did not re-draw the file "
                        u"byte for byte):")
            body += [u"#   " + x for x in rp["src"].splitlines()]
    chain = code.get("chain") or []
    if not chain and code.get("file"):
        chain = [code]
    if chain:
        body.append(u"")
        body.append(u"# ---- where the level asked for it, innermost first "
                    u"(for reading; not executed) ----")
    for fr in chain:
        path, line = fr.get("file"), fr.get("line")
        body.append(u"# %s:%s in %s()" % (os.path.basename(path or "?"), line,
                                          fr.get("func")))
        for k, v in sorted((fr.get("locals") or {}).items()):
            body.append(u"#   %s = %s" % (k, v))
        if path and os.path.isfile(path):
            src = _source_at(path, line, fr.get("func"))
            body += [u"#   | " + x for x in src.rstrip("\n").splitlines()]
    return u"\n".join(head) + u"\n\n" + u"\n".join(body) + u"\n", bool(script)


def _source_at(path, line, func):
    """The enclosing function's source (or the statement, at module level)."""
    with open(path, encoding="utf-8") as fh:
        lines = fh.readlines()
    i = max(0, int(line or 1) - 1)
    if func and func != "<module>":
        j = i
        while j >= 0:
            s = lines[j]
            if re.match(r"\s*def\s+%s\b" % re.escape(func), s):
                break
            j -= 1
        if j >= 0:
            indent = len(lines[j]) - len(lines[j].lstrip())
            k = j + 1
            while k < len(lines):
                s = lines[k]
                if s.strip() and (len(s) - len(s.lstrip())) <= indent:
                    break
                k += 1
            return "".join(lines[j:k])
    j = i
    while j > 0 and lines[j].strip().startswith(("#", ")")):
        j -= 1
    k = i
    depth = 0
    while k < len(lines):
        depth += lines[k].count("(") - lines[k].count(")")
        k += 1
        if depth <= 0:
            break
    return "".join(lines[j:k])


# ------------------------------------------------------------ the writing --
def _sha(data):
    if isinstance(data, str):
        data = data.encode("utf-8")
    return hashlib.sha256(data).hexdigest()


# ------------------------------------------------ portable source ---------
# v6.6 E: the delivered source/ names no build folder. A level's content.py
# puts its own folder and the skill's on sys.path with absolute paths; copied
# as they were, every rebuild in another folder changed `source_hash` (the
# same sheet hashed differently) and the package carried /private/tmp paths
# that exist on no other machine. The copy rewrites every string literal
# under the build folder or the skill folder into a path computed at run
# time, and `source_hash` is taken over the rewritten files.
_SRC_HEAD = (u"import os as _os_src  # deliver.py v6.6: portable paths\n"
             u"_SRC_HERE = _os_src.path.dirname(_os_src.path.abspath("
             u"__file__))\n"
             u"_SRC_SKILL = _os_src.environ.get(\"WORKSHEET_SKILL_DIR\", "
             u"_os_src.path.join(_SRC_HERE, \"skill\"))\n")
_ABS_TMP = re.compile(u"(?:/private)?/tmp/[^\"'\\s)]*")


_FONT_URL = re.compile(r'url\("file://([^"]+?\.(ttf|otf|woff2?))"\)')
_FONT_MIME = {"ttf": "font/ttf", "otf": "font/otf", "woff": "font/woff",
              "woff2": "font/woff2"}


def portable_html(html):
    """v6.11 fix r1 (HTML-FONT): every @font-face url("file:///<build
    machine>/assets/X.ttf") of the HTML the PDF was printed from becomes a
    data: URI of the same file's bytes, so the delivered sheet.html shows
    the same fonts anywhere and names no path of the build machine. A URL
    whose file is not there is left as it is (never guessed)."""
    import base64

    def emb(m):
        path = m.group(1)
        if not os.path.isfile(path):
            return m.group(0)
        with open(path, "rb") as fh:
            b = base64.b64encode(fh.read()).decode("ascii")
        return 'url("data:%s;base64,%s")' % (_FONT_MIME[m.group(2)], b)
    return _FONT_URL.sub(emb, html)


def portable_source(text, build_dir, skill_dir=None):
    """(rewritten text, absolute tmp paths left). Idempotent."""
    skill_dir = skill_dir or export.SKILL_HOME
    roots = []
    for root, var in ((os.path.realpath(str(build_dir)), "_SRC_HERE"),
                      (os.path.abspath(str(build_dir)), "_SRC_HERE"),
                      (os.path.realpath(str(skill_dir)), "_SRC_SKILL"),
                      (os.path.abspath(str(skill_dir)), "_SRC_SKILL")):
        root = root.rstrip("/")
        for r in {root, root.replace("/private/tmp/", "/tmp/", 1),
                  root.replace("/tmp/", "/private/tmp/", 1)
                  if root.startswith("/tmp/") else root}:
            if (r, var) not in roots:
                roots.append((r, var))
    roots.sort(key=lambda t: -len(t[0]))       # the longest root first
    changed = [False]

    def lit(m):
        q, body = m.group(1), m.group(2)
        for r, var in roots:
            if body == r or body.startswith(r + "/"):
                rest = body[len(r):].lstrip("/")
                changed[0] = True
                if not rest:
                    return var
                return u"_os_src.path.join(%s, %s%s%s)" % (var, q, rest, q)
        return m.group(0)
    out = re.sub(u"(\"|')(/[^\"'\n]*)\\1", lit, text)
    if changed[0] and _SRC_HEAD not in out:
        lines = out.split(u"\n")
        k = 0
        while k < len(lines) and k < 2 and (lines[k].startswith(u"#!") or
                                            u"coding" in lines[k][:40]):
            k += 1
        lines.insert(k, _SRC_HEAD.rstrip(u"\n"))
        out = u"\n".join(lines)
    left = sorted(set(_ABS_TMP.findall(out)))
    return out, left


# ------------------------------------------------ the content schema -------
# v6.5 X2 r1. A declaration is a SELECTOR over what the figure exports, and a
# selector that names nothing selects everything: `{"text": ...}` alone, or a
# bare `{"type": "length"}`, used to relabel every constraint of every figure
# of the question (MUST-5). A dict is now a whole constraint -- its type and
# every field that type requires -- or a `text` this module can read; and a
# plain STRING is read too, because a claim written as a string used to be
# the one way past the to_prove check (MUST-2).
_PT = u"[A-Z][′″']?[0-9]?"
_SEG = u"(%s)(%s)" % (_PT, _PT)
_NUMX = u"(-?\\d+(?:[.,]\\d+)?)"
_UNIT = u"(?:\\s*(?:ס\"מ|ס״מ|מ\"מ|מ״מ|מ'|מטר|cm|mm|m))?"
# v6.7 r2 (V67F2-proof-verbs-silent): every verb a sheet uses to ask for an
# argument, in the plural, masculine and feminine singular -- one list, read
# by _LEAD (a declared claim), _PROOF and _claims_in (an item's own text)
# v6.8 §3: the infinitive too (יש להוכיח / צריך להראות / עליכם לנמק)
_VERBS = (u"הוכיחו|הוכיחי|הוכח|הראו|הראי|הראה|נמקו|נמקי|נמק|הסבירו|הסבירי|"
          u"הסבר|הצדיקו|הצדיקי|הצדק|בססו|בססי|בסס|"
          u"להוכיח|להראות|לנמק|להסביר|להצדיק|לבסס")
# the auxiliary before an infinitive request
_AUX = u"(?:(?:יש|צריך|צריכים|עליכם|עלייך|עליך|נדרש)\\s+)?"
# v6.8 §3: what may stand between the verb and its claim
_BETWEEN = (u"(?:את\\s+הטענה(?:\\s+הבאה)?\\s*(?:ש-?|:)?|את\\s+השוויון\\s*:?|"
            u"(?:ש-?|כי\\s+)?מתקיי(?:ם|מת|מים|מות)\\s*:?|ש-?|כי|:)?")
_WHY = u"(?:מדוע\\s+זה\\s+נכון\\s+ש-?|מדוע|למה)"
_LEAD = re.compile(u"^(?:%s(?:%s|נתון|ידוע)\\s*,?\\s*(?:%s\\s*)?|%s\\s+)"
                   u"%s\\s*(?:%s\\s*)?"
                   % (_AUX, _VERBS, _WHY, _WHY, _BETWEEN, _BETWEEN))
# v6.7 (E-r2-d4-phrasing): a maqaf (ש־, the usual spelling), an en dash or
# an em dash after the particle is the same hyphen
_MAQAF = re.compile(u"(?<![א-ת])ש\\s*[־–—]")


def _dehyphen(t):
    return _MAQAF.sub(u"ש-", t)
_NAME_TOK = re.compile(u"[A-Za-z][′″']*[0-9]?")


# v6.6 E (V2-M2): the sheet's own $...$ notation. A level writes its math
# the way the emitter typesets it ('$AM = MB$', '$AB \\perp AC$',
# '$\\angle BAC = 90^\\circ$'), so the declaration is read in that notation
# too -- otherwise the natural spelling of a claim was the one that slipped
# past the to_prove check and the false-given check.
_TEX = ((u"\\perp", u"⊥"), (u"\\parallel", u"∥"), (u"\\|", u"∥"),
        (u"\\measuredangle", u"∠"), (u"\\sphericalangle", u"∠"),
        (u"\\angle", u"∠"), (u"^{\\circ}", u"°"), (u"^\\circ", u"°"),
        (u"\\circ", u"°"), (u"\\degree", u"°"), (u"\\cdot", u"·"),
        (u"\\times", u"·"), (u"\\,", u" "), (u"\\;", u" "),
        (u"\\!", u""), (u"\\ ", u" "), (u"\\text", u""),
        (u"\\mathrm", u""), (u"\\overline", u""),
        # v6.8 §3: congruence of two angles or segments is their equality
        (u"\\cong", u"="), (u"\\equiv", u"="))


def _untex(t):
    if u"$" not in t and u"\\" not in t:
        return t
    t = t.replace(u"$", u"")
    # v6.7 r1 (V67F-marked-proof-notation-escapes): the hat notation for an
    # angle -- $\\hat{A}$ is the angle at A, $B\\hat{A}C$ and
    # $\\widehat{BAC}$ the angle BAC
    t = re.sub(u"([A-Z])\\s*\\\\(?:wide)?hat\\s*\\{?\\s*([A-Z])\\s*\\}?\\s*([A-Z])",
               u"∠\\1\\2\\3", t)
    t = re.sub(u"\\\\(?:wide)?hat\\s*", u"∠", t)
    # v6.7 r2: 90^o / 90^{o} -- the letter o written as the degree sign
    t = re.sub(u"\\^\\s*\\{?\\s*o\\s*\\}?(?![A-Za-z])", u"°", t)
    for a, b in _TEX:
        t = t.replace(a, b)
    t = re.sub(u"[{}]", u"", t)
    return re.sub(u"\\s+", u" ", t).strip()


def _clean_statement(text):
    t = _untex(str(text or ""))
    for ch in (u"‏", u"‎", u"‪", u"‫", u"‬"):
        t = t.replace(ch, "")
    t = t.replace(u"−", "-").replace(u"∢", u"∠").replace(u"≮", u"∠")
    t = t.replace(u"≅", u"=").replace(u"≡", u"=")
    # v6.7 r1: ∡ (U+2221, what \\measuredangle prints) and ⦣ are the angle
    # sign too, and Â / BÂC (a circumflex over the vertex) the hat notation
    for ch in (u"∡", u"⦣", u"⦛"):
        t = t.replace(ch, u"∠")
    d = unicodedata.normalize("NFD", t)
    if u"\u0302" in d:
        d = re.sub(u"([A-Z])([A-Z])\u0302([A-Z])", u"∠\\1\\2\\3", d)
        d = re.sub(u"([A-Z])\u0302", u"∠\\1", d)
        t = unicodedata.normalize("NFC", d)
    # "90 מעלות" is 90°
    t = re.sub(u"(\\d)\\s*מעלות", u"\\1°", t)
    # v6.6 E r1: the measure-of-angle form, m∠BAC / $m\angle BAC$
    t = re.sub(u"(?<![A-Za-z])m\\s*∠", u"∠", t)
    # v6.8 r2: the sign typed AFTER the letters, as RTL typing leaves it
    # ('BAC∠ = EDF∠') is the same angle
    t = re.sub(u"(?<![A-Za-z'′∠])((?:[A-Z]['′]*){1,3})\\s*∠"
               u"(?=\\s*(?:=|$|[,.;:]|[א-ת]))", u"∠\\1", t)
    t = _dehyphen(t).strip().rstrip(u".:;")
    t = _LEAD.sub("", t).strip()
    t = re.sub(u"^ש-?", "", t).strip()
    t = _worded(t)
    return t


# v6.7 (E-r2-d4-phrasing): the WORDED forms of the same claims -- "הזווית
# BAC שווה לזווית EDF", "הקטע AB שווה לקטע CD", "AB מקביל ל-CD" -- read as
# the symbolic ones, so a worded proof item is checked like any other.
_W_ANG = u"(?:ה)?זווית\\s+"
_W_SEG = u"(?:ה)?(?:קטע|צלע)\\s+"
_W_EQ = u"\\s+(?:שווה|שווים|שוות)\\s+ל-?\\s*"


def _worded(t):
    pt = u"[A-Z][′″']?[0-9]?"
    a3 = u"((?:%s){1,3})" % pt
    # v6.8 §3: "גודל הזווית BAC שווה לגודל הזווית EDF" -- the size of an
    # angle is the angle
    t = re.sub(u"(?<![א-ת])(ל-?)?(?:ה)?גודל\\s+(?=(?:ה)?זווית)", u"\\1", t)
    # "∠BAC ו-∠EDF שוות", "הזווית BAC והזווית EDF שוות"
    m = re.match(u"^(?:∠\\s*|(?:ה)?זווית\\s+)%s\\s+ו-?\\s*(?:∠\\s*|(?:ה)?זווית\\s+)"
                 u"%s\\s+(?:שוות|שוות\\s+זו\\s+לזו|שוות\\s+בגודלן)$" % (a3, a3), t)
    if m:
        return u"∠%s = ∠%s" % (m.group(1), m.group(2))
    # v6.7 r2: a maqaf after ל / ו is the hyphen ("שווה ל־∠EDF")
    t = re.sub(u"(?<![א-ת])([לו])\\s*[־–—]", u"\\1-", t)
    # the plural: "הזוויות BAC ו-EDF שוות", "הקטעים AB ו-CD שווים"
    m = re.match(u"^(?:ה)?זוויות\\s+%s\\s+ו-?\\s*%s\\s+(?:שוות|שוות\\s+זו\\s+לזו)$"
                 % (a3, a3), t)
    if m:
        return u"∠%s = ∠%s" % (m.group(1), m.group(2))
    m = re.match(u"^(?:ה)?(?:קטעים|צלעות)\\s+((?:%s){2})\\s+ו-?\\s*((?:%s){2})"
                 u"\\s+(?:שווים|שוות)(?:\\s+זה\\s+לזה|\\s+זו\\s+לזו)?$"
                 % (pt, pt), t)
    if m:
        return u"%s = %s" % (m.group(1), m.group(2))
    m = re.match(u"^%s%s%s%s%s$" % (_W_ANG, a3, _W_EQ, _W_ANG, a3), t)
    if m:
        return u"∠%s = ∠%s" % (m.group(1), m.group(2))
    m = re.match(u"^%s%s\\s+(?:שווה|היא|הוא|הינה)\\s+(?:ל-?\\s*)?(-?\\d+(?:[.,]\\d+)?)"
                 u"\\s*(?:°|מעלות)?$" % (_W_ANG, a3), t)
    if m:
        return u"∠%s = %s°" % (m.group(1), m.group(2))
    s2 = u"((?:%s){2})" % pt
    m = re.match(u"^(?:%s)?%s%s(?:%s)?%s$" % (_W_SEG, s2, _W_EQ, _W_SEG, s2),
                 t)
    if m:
        return u"%s = %s" % (m.group(1), m.group(2))
    m = re.match(u"^(?:%s)?%s\\s+(?:מקביל|מקבילה|מקבילים)\\s+ל-?\\s*(?:%s)?%s$"
                 % (_W_SEG, s2, _W_SEG, s2), t)
    if m:
        return u"%s ∥ %s" % (m.group(1), m.group(2))
    m = re.match(u"^(?:%s)?%s\\s+(?:מאונך|מאונכת|ניצב|ניצבת)\\s+ל-?\\s*(?:%s)?%s$"
                 % (_W_SEG, s2, _W_SEG, s2), t)
    if m:
        return u"%s ⊥ %s" % (m.group(1), m.group(2))
    # v6.8 r1 (D4-tp-empty-silences-marked-claim): the plural forms --
    # "הישרים AB ו-AC מאונכים", "הקטעים AB ו-CD מקבילים (זה לזה)"
    m = re.match(u"^(?:ה)?(?:ישרים|ישרות|קטעים|צלעות)\\s+%s\\s+ו-?\\s*%s\\s+"
                 u"(מאונכים|מאונכות|ניצבים|ניצבות|מקבילים|מקבילות)"
                 u"(?:\\s+זה\\s+לזה|\\s+זו\\s+לזו)?$" % (s2, s2), t)
    if m:
        op = u" ∥ " if m.group(3).startswith(u"מקביל") else u" ⊥ "
        return m.group(1) + op + m.group(2)
    # "ABC משולש ישר זווית", "ABC הוא משולש ישר זווית (ב-A)"
    m = re.match(u"^((?:%s){3})\\s+(?:הוא\\s+|הינו\\s+)?משולש\\s+ישר[-־\\s]?(?:ה)?זווית"
                 u"(?:\\s+(?:ב-?|בקדקוד\\s+|בזווית\\s+)\\s*(%s))?$" % (pt, pt), t)
    if m:
        return u"⊿%s%s" % (m.group(1), (u"@" + m.group(2)) if m.group(2)
                           else u"")
    # "BAC = 90°" -- three vertex letters and a degree sign are an angle
    m = re.match(u"^((?:%s){3})\\s*=\\s*(-?\\d+(?:[.,]\\d+)?)\\s*°$" % pt, t)
    if m:
        return u"∠%s = %s°" % (m.group(1), m.group(2))
    # v6.7 r1 (V67F-marked-proof-notation-escapes): "זווית A = 90°" (no ה),
    # "הזווית BAC ישרה", "המשולש ABC ישר זווית (ב-A)"
    t = re.sub(u"^[∆△Δ]\\s*(?=[A-Z])", u"המשולש ", t)
    m = re.match(u"^(?:ה)?משולש\\s+(?:הוא\\s+)?ישר[-־\\s]?(?:ה)?זווית$", t)
    if m:
        return u"⊿***"
    m = re.match(u"^(?:ה)?משולש\\s+([A-Z][′″']?[0-9]?[A-Z][′″']?[0-9]?"
                 u"[A-Z][′″']?[0-9]?)\\s+(?:הוא\\s+)?ישר[-־\\s]?(?:ה)?זווית"
                 u"(?:\\s+(?:ב-?|בקדקוד\\s+|בזווית\\s+)\\s*(%s))?$" % pt, t)
    if m:
        return u"⊿%s%s" % (m.group(1), (u"@" + m.group(2)) if m.group(2)
                           else u"")
    t = re.sub(u"(?<![א-ת])(?:ה)?זווית\\s+(%s)(?![A-Za-z])" % a3,
               u"∠\\1", t)
    m = re.match(u"^∠\\s*%s\\s+(?:(?:היא|הינה|הוא|הינו)\\s+)?(?:(?:ה)?זווית\\s+)?"
                 u"ישרה$" % a3, t)
    if m:
        return u"∠%s = 90°" % m.group(1)
    m = re.match(u"^∠\\s*%s%s∠\\s*%s$" % (a3, _W_EQ, a3), t)
    if m:
        return u"∠%s = ∠%s" % (m.group(1), m.group(2))
    m = re.match(u"^∠\\s*%s\\s+(?:שווה|היא|הוא|הינה|הינו)\\s+(?:ל-?\\s*)?"
                 u"(-?\\d+(?:[.,]\\d+)?)\\s*°?$" % a3, t)
    if m:
        return u"∠%s = %s°" % (m.group(1), m.group(2))
    return t


def parse_statement(text):
    """A datum as the sheet words it -> the constraint it states, or None.

    Only the plain forms a middle-school sheet writes: AM = BM (and chains),
    AB = 12 (a unit may follow), AB ∥ CD, AB ⊥ CD, "M אמצע AB",
    ∠ABC = ∠DEF, ∠ABC = 37°. Anything else stays wording and is reported as
    a statement no figure was checked against."""
    t = _clean_statement(text)
    if not t:
        return None
    seg_chain = re.match(u"^%s(?:\\s*=\\s*%s)+$" % (_SEG, _SEG), t)
    if seg_chain:
        segs = re.findall(_SEG, t)
        return {"type": "equal_length", "of": ["".join(x) for x in segs]}
    m = re.match(u"^%s\\s*=\\s*%s%s$" % (_SEG, _NUMX, _UNIT), t)
    if m:
        return {"type": "length", "of": m.group(1) + m.group(2),
                "value": float(m.group(3).replace(",", "."))}
    # V2-N1: the number first ('7 = BC') is the same datum
    m = re.match(u"^%s%s\\s*=\\s*%s$" % (_NUMX, _UNIT, _SEG), t)
    if m:
        return {"type": "length", "of": m.group(2) + m.group(3),
                "value": float(m.group(1).replace(",", "."))}
    m = re.match(u"^%s\\s*(?:∥|\\|\\||//)\\s*%s$" % (_SEG, _SEG), t)
    if m:
        return {"type": "parallel", "of": [m.group(1) + m.group(2),
                                           m.group(3) + m.group(4)]}
    m = re.match(u"^%s\\s*(?:⊥|⟂)\\s*%s$" % (_SEG, _SEG), t)
    if m:
        return {"type": "perpendicular", "of": [m.group(1) + m.group(2),
                                                m.group(3) + m.group(4)]}
    m = re.match(u"^(%s)\\s+(?:היא\\s+|הוא\\s+)?(?:נקודת\\s+)?(?:ה)?אמצע\\s+"
                 u"(?:של\\s+)?(?:ה?קטע\\s+|ה?צלע\\s+)?%s$" % (_PT, _SEG), t)
    if m:
        return {"type": "midpoint", "point": m.group(1),
                "of": [m.group(2), m.group(3)]}
    # v6.7 r1: "המשולש ABC ישר זווית" -- a right angle at the vertex it
    # names (ב-A), or at the one vertex the figure resolves (resolve_short)
    if t == u"⊿***":
        # an unnamed right triangle: the one triangle the figure draws
        return {"type": "angle", "at": "?", "rays": [], "value": 90.0,
                "unit": "deg", "right_of": ["*"]}
    m = re.match(u"^⊿(%s)(%s)(%s)(?:@(%s))?$" % (_PT, _PT, _PT, _PT), t)
    if m:
        tri = list(m.group(1, 2, 3))
        if m.group(4) and m.group(4) in tri:
            v = m.group(4)
            r = [x for x in tri if x != v]
            return {"type": "angle", "at": v, "rays": r, "value": 90.0,
                    "unit": "deg"}
        return {"type": "angle", "at": "?", "rays": [], "value": 90.0,
                "unit": "deg", "right_of": tri}
    ang = u"∠\\s*(%s)(%s)(%s)" % (_PT, _PT, _PT)
    # v6.7 (E-r2-single-letter-angle): ∠A -- the sheet's usual notation --
    # parses as the angle AT A, flagged `short`; the caller resolves it on
    # the figure (the one angle at that vertex) or reports it ambiguous
    one = u"∠\\s*(%s)(?![A-Z′″'0-9])" % _PT
    one_nc = u"∠\\s*%s(?![A-Z′″'0-9])" % _PT
    anyang = u"(∠\\s*(?:%s){3}|%s)" % (_PT, one_nc)
    m = re.match(u"^%s\\s*=\\s*%s$" % (anyang, anyang), t)
    if m and (re.match(u"^%s$" % one_nc, m.group(1).strip()) or
              re.match(u"^%s$" % one_nc, m.group(2).strip())):
        ops = [_NAME_TOK.findall(g.replace(u"∠", u"")) for g in m.group(1, 2)]
        return {"type": "equal_angle",
                "of": ["".join(o) for o in ops],
                "short": [o[0] for o in ops if len(o) == 1]}
    m = re.match(u"^%s\\s*=\\s*%s\\s*°?$" % (one, _NUMX), t) or \
        re.match(u"^%s\\s*°?\\s*=\\s*%s$" % (_NUMX, one), t)
    if m:
        g = m.groups()
        at, val = (g[0], g[1]) if not re.match(u"^-?\\d", g[0]) else (g[1],
                                                                     g[0])
        return {"type": "angle", "at": at, "rays": [],
                "value": float(val.replace(",", ".")), "unit": "deg",
                "short": [at]}
    m = re.match(u"^%s\\s*=\\s*%s$" % (ang, ang), t)
    if m:
        return {"type": "equal_angle",
                "of": ["".join(m.group(1, 2, 3)), "".join(m.group(4, 5, 6))]}
    m = re.match(u"^%s\\s*=\\s*%s\\s*°?$" % (ang, _NUMX), t)
    if m:
        return {"type": "angle", "at": m.group(2),
                "rays": [m.group(1), m.group(3)],
                "value": float(m.group(4).replace(",", ".")), "unit": "deg"}
    m = re.match(u"^%s\\s*°?\\s*=\\s*%s$" % (_NUMX, ang), t)
    if m:
        return {"type": "angle", "at": m.group(3),
                "rays": [m.group(2), m.group(4)],
                "value": float(m.group(1).replace(",", ".")), "unit": "deg"}
    return None


def _toks(name):
    return _NAME_TOK.findall(str(name))


def _canon_seg(v):
    if isinstance(v, (list, tuple)) and len(v) == 2:
        a, b = str(v[0]), str(v[1])
    else:
        t = _toks(v)
        if len(t) != 2 or "".join(t) != str(v):
            return str(v)                      # an id: compared as it is
        a, b = t
    return export.pair_name(a, b)


def _canon_angle(v):
    if isinstance(v, dict):
        at, rays = v.get("at"), list(v.get("rays") or [])
    else:
        t = _toks(v)
        if len(t) != 3:
            return str(v)
        at, rays = t[1], [t[0], t[2]]
    return "%s<%s>" % (at, ",".join(sorted(map(str, rays))))


def _canon(ctype, key, v):
    kind = export.FIELD_KIND.get((ctype, key))
    if kind == "segment":
        return _canon_seg(v)
    if kind == "segments":
        return tuple(sorted(_canon_seg(x) for x in v))
    if kind == "points":
        if ctype == "angle":                   # rays: unordered
            return tuple(sorted(map(str, v)))
        return tuple(sorted(map(str, v)))
    if kind == "angles":
        return tuple(sorted(_canon_angle(x) for x in v))
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)):
        return round(float(v), 9)
    return str(v)


def _decl(dec, where):
    """A declaration as (constraint fields, wording), or (None, wording)
    for wording this module cannot read. Refuses a dict that names no
    operand (MUST-5)."""
    if isinstance(dec, str):
        c = parse_statement(dec)
        return c, dec
    if not isinstance(dec, dict):
        _bad("%s declares %r" % (where, dec),
             "a datum is the wording as a string, or a dict naming a "
             "constraint the figure already exports")
    text = dec.get("text")
    fields = dict((k, v) for k, v in dec.items()
                  if k not in ("text", "item", "source", "from_item"))
    if "type" not in fields:
        c = parse_statement(text) if text else None
        if c is None or len(fields):
            _bad("%s declares %r, which names no constraint" % (where, dec),
                 "a declaration is a WHOLE constraint -- its type and every "
                 "field that type needs, e.g. {'type': 'midpoint', 'point': "
                 "'M', 'of': ['A', 'B'], 'text': 'M אמצע AB'} -- or wording "
                 "this module reads (AM = BM, AB = 12, AB ∥ CD, AB ⊥ CD, "
                 "'M אמצע AB', ∠ABC = ∠DEF, ∠ABC = 37°). A text alone that "
                 "it cannot read would otherwise select every constraint of "
                 "the question")
        return c, text
    ctype = fields.pop("type")
    try:
        export.check_fields(ctype, fields)
    except export.ConstraintError as e:
        _bad("%s declares %s: %s" % (where, _phrase(dec), str(e)),
             "a declaration names ONE constraint completely, so it can "
             "select nothing but that constraint")
    out = dict(fields)
    out["type"] = ctype
    return out, text or _phrase(dec)


def _match(dec, cons):
    """The exported constraints a WHOLE declaration names (operands compared
    in canonical form: MB is BM, the rays of an angle are unordered)."""
    ctype = dec["type"]
    want = dict((k, _canon(ctype, k, v)) for k, v in dec.items()
                if k != "type")
    hit = []
    for c in cons:
        if c.type != ctype:
            continue
        ok = True
        for k, v in want.items():
            if k not in c.f:
                # an optional field the figure did not state (a `t` along a
                # segment, a unit) cannot match a declared one
                ok = False
                break
            if _canon(ctype, k, c.f[k]) != v:
                ok = False
                break
        if ok:
            hit.append(c)
    return hit


def _pair(seg):
    t = _toks(seg) if isinstance(seg, str) else [str(x) for x in seg]
    return tuple(t) if len(t) == 2 else None


def _equiv(dec, cons):
    """v6.6 E (V2-N3): the exported constraints that state the SAME fact as
    `dec` in another form -- 'AM = MB' is the midpoint M of AB, 'AB ⊥ AC'
    is the 90-degree angle at A. A declaration that finds one labels it
    (one entry, the declared source) instead of adding a second entry
    beside it, so the JSON never says 'derived' and 'to_prove' of one
    fact."""
    t = dec["type"]
    hit = []
    for c in cons:
        f = c.f
        try:
            if t == "equal_length" and c.type == "midpoint" and \
                    len(dec["of"]) == 2:
                P, (X, Y) = str(f["point"]), [str(v) for v in f["of"]]
                want = sorted([_canon_seg((P, X)), _canon_seg((P, Y))])
                if sorted(_canon_seg(v) for v in dec["of"]) == want:
                    hit.append(c)
            elif t == "midpoint" and c.type == "equal_length" and \
                    len(f["of"]) == 2:
                P = str(dec["point"])
                X, Y = [str(v) for v in (dec["of"] if not isinstance(
                    dec["of"], str) else _toks(dec["of"]))]
                want = sorted([_canon_seg((P, X)), _canon_seg((P, Y))])
                if sorted(_canon_seg(v) for v in f["of"]) == want:
                    hit.append(c)
            elif t == "perpendicular" and c.type == "angle" and \
                    abs(float(f["value"]) - 90.0) < 1e-9:
                V, (A, B) = str(f["at"]), [str(v) for v in f["rays"]]
                want = sorted([_canon_seg((V, A)), _canon_seg((V, B))])
                if sorted(_canon_seg(v) for v in dec["of"]) == want:
                    hit.append(c)
            elif t == "angle" and c.type == "perpendicular" and \
                    abs(float(dec["value"]) - 90.0) < 1e-9:
                V, (A, B) = str(dec["at"]), [str(v) for v in dec["rays"]]
                want = sorted([_canon_seg((V, A)), _canon_seg((V, B))])
                if sorted(_canon_seg(v) for v in f["of"]) == want:
                    hit.append(c)
        except (KeyError, TypeError, ValueError):
            continue
    return hit


def _measure_new(dec, source, item, figs):
    """A declared fact the figure did not export by itself (MUST-2): an
    unmarked `CM ⊥ AB` in an isosceles triangle with a median. It is
    MEASURED on the finished SVG of each figure of the question that draws
    its operands, and added -- flagged `declared` -- where it holds.
    Returns (added, drawn_but_false, why)."""
    added, false, why = [], [], []
    fields = dict((k, v) for k, v in dec.items() if k != "type")
    for fid, rec, svg in figs:
        if rec is None:
            continue
        ob = rec.objects
        if ob.projection and dec["type"] in export.PROJECTION_UNSAFE:
            why.append("%s is drawn in the %s projection, which does not "
                       "preserve a %s" % (fid, ob.projection, dec["type"]))
            continue
        con = export.Con(dec["type"], dict(fields), source, item, False, None)
        con._pending = False
        fr = export.Frame(svg, ob.view)
        scale = export.length_scale(list(ob.cons) + [con], fr)
        ok, said = export.measure(con, fr, scale)
        if ok:
            con.declared = True
            ob.cons.append(con)
            added.append(con)
        elif export._missing_operand(said):
            why.append("%s: %s" % (fid, said))
        else:
            false.append("%s: %s" % (fid, said))
    return added, false, why


def _apply(dec_list, source, item, figs, where, taken, unchecked,
           strict=False, claims=None):
    """Label the figures' constraints `given` / `to_prove`, and return the
    wording the sheet states. `taken` remembers who declared what, so the
    same fact cannot be `given` in one item and `to_prove` in another
    (SHOULD-8)."""
    words = []
    recorded = any(rec is not None for _f, rec, _s in figs)

    def refuse(said):
        # v6.8 §3: the author's declaration is the source of truth, so a
        # to_prove this module cannot check against the drawing is refused
        # under STRICT_FIGURES, never shipped as "unchecked"
        _bad("%s declares to_prove %r, which %s" % (where, text, said),
             "write the claim in the structured form of references/"
             "noam-ai-deliverable-he.md -- {'type': 'equal_length', 'of': "
             "['AM', 'MQ']}, {'type': 'angle', 'at': 'A', 'rays': ['B', "
             "'C'], 'value': 90}, {'type': 'parallel', 'of': ['AB', 'CD']} "
             "-- or as $AM = MQ$ / $\\angle BAC = 90^\\circ$ that parses; "
             "to_prove=[] declares an item that explains without a "
             "geometric claim")
    for dec in dec_list or []:
        if DD.is_find(dec):
            # v6.7.2-noam: a COMPUTE / FIND target ('חשבו את ∠ACB'): the
            # quantity and the object it names; its value is private
            # (sheet.json, with the answer), never in noam-ai.json
            fb = DD.find_schema_faults(dec)
            if fb:
                _bad("%s declares the find target %r: %s"
                     % (where, dec, "; ".join(fb)),
                     "{'type': 'find', 'quantity': '<%s>', 'of': ...} -- "
                     "e.g. {'type': 'find', 'quantity': 'angle', 'of': "
                     "'ACB'}, {'type': 'find', 'quantity': 'length', 'of': "
                     "'AB', 'value': 10} (value required and private)"
                     % " | ".join(sorted(DD.FIND_QUANTITIES)))
            if source != "to_prove":
                _bad("%s declares the find target %s as %s"
                     % (where, DD.find_text(dec), source),
                     "a find target is what the student computes: it "
                     "belongs in to_prove (a known value is a given, e.g. "
                     "{'type': 'length', 'of': 'AB', 'value': 10})")
            if claims is not None:
                claims.append(DD.find_public(dec))
            words.append(DD.find_text(dec))
            continue
        if isinstance(dec, dict) and dec.get("type") in DD.DIDACTIC_TYPES:
            # v6.7.1-noam: a shape the question names ('ABCD is a
            # rectangle') or an object to construct is not a figure
            # constraint: recorded as a claim, never matched to a mark
            _cl = dict((k, v) for k, v in dec.items()
                       if k in _NOAM_CLAIM_KEYS or k == "from_item")
            if claims is not None:
                claims.append(_cl)
            words.append(dec.get("text") or DD._say(dec))
            continue
        c, text = _decl(dec, where)
        if text is None and c is not None:
            text = _say(c)
        words.append(text)
        # v6.7-noam: the structured claim beside its wording, for the
        # public noam-ai.json (sheet.json keeps the wording alone)
        _cl = {"text": text}
        if isinstance(dec, dict) and dec.get("from_item"):
            _cl["from_item"] = str(dec["from_item"])
        if claims is not None:
            claims.append(_cl)
        if c is not None and _short_names(c):
            c, why_short = resolve_short(c, figs)
            if c is None:
                if strict and source == "to_prove" and recorded:
                    refuse("names an angle the figure cannot resolve (%s)"
                           % why_short)
                unchecked.append({"where": where, "source": source,
                                  "item": item, "text": text,
                                  "why": why_short})
                continue
        if c is None:
            if strict and source == "to_prove":
                refuse("does not parse as a claim")
            unchecked.append({"where": where, "source": source,
                              "item": item, "text": text})
            continue
        hit = []
        for _fid, rec, _svg in figs:
            if rec is None:
                continue
            hit += _match(c, rec.objects.cons)
        if not hit:
            for _fid, rec, _svg in figs:
                if rec is not None:
                    hit += _equiv(c, rec.objects.cons)
        if not hit:
            hit, false, why = _measure_new(c, source, item, figs)
            if false and not hit:
                _bad("%s declares %s, and the finished figure says otherwise "
                     "(%s)" % (where, _phrase(c), "; ".join(false[:2])),
                     "the question and the drawing must state the same "
                     "facts. Draw the figure from this datum (the builders "
                     "take the numbers the question states), or correct the "
                     "wording")
            if not hit and isinstance(dec, dict):
                known = sorted(set("%s%s" % (k.type, _ops(k))
                                   for _f, r, _s in figs if r
                                   for k in r.objects.cons))[:8]
                _bad("%s declares %s, and no figure of this question draws "
                     "its operands (%s)"
                     % (where, _phrase(c), "; ".join(why[:2]) or
                        "the question has no recorded figure"),
                     "a declaration is measured on the finished SVG, so its "
                     "points and segments must be drawn: draw the segment "
                     "(plane(solid=[...]), a shapekit add-on such as "
                     "median()/altitude(), g.segment), or state the fact in "
                     "the figure's own code with g.constrain(...). This "
                     "question's figures export %s"
                     % (", ".join(known) or "no constraints at all"))
            if not hit:
                if strict and source == "to_prove" and recorded:
                    refuse("no figure of this question draws (%s)"
                           % ("; ".join(why[:2]) or "no operand found"))
                unchecked.append({"where": where, "source": source,
                                  "item": item, "text": text,
                                  "why": "; ".join(why[:2]) or
                                  "no recorded figure"})
                continue
        _cl.update((k, v) for k, v in c.items()
                   if k not in ("text", "item", "source"))
        for k in hit:
            prev = taken.get(id(k))
            # v6.7.1-noam §2: a later item may take what an EARLIER item
            # proved as its given -- declared, never silent
            if prev is not None and prev[0] == "to_prove" and \
                    source == "given" and isinstance(dec, dict) and \
                    dec.get("from_item") and \
                    str(dec.get("from_item")) == str(prev[1]):
                continue
            if prev is not None and prev[0] != source:
                _bad("%s declares %s as %s, and %s already declared it %s"
                     % (where, _phrase(c), source, prev[2], prev[0]),
                     "one fact is either stated by the question (given) or "
                     "proved by the student (to_prove), never both. If a "
                     "later item uses what an earlier one proved, declare it "
                     "to_prove where it is proved and, on the later item's "
                     "given, from_item='<that item id>' (v6.7.1-noam)")
            if prev is not None:
                continue                  # same source: the first item keeps it
            taken[id(k)] = (source, item, where)
            k.source = source
            k.item = item
            # v6.7-noam final (VC2-Q4C-GIVEN-IS-CONCLUSION): a GIVEN states
            # what the question states and no more. A measured on_segment
            # carries t (0.5 = the midpoint); when the declaration names no
            # t, the premise is "on the segment" only -- the exported given
            # must not hand over a position the item may ask to prove
            if source == "given" and isinstance(k.f, dict) and \
                    k.f.get("t") is not None and c.get("t") is None:
                k.f = dict((a, b) for a, b in k.f.items() if a != "t")
    return words


def _op1(x):
    """One operand as the sheet writes it: an angle dict is ∠BAC."""
    if isinstance(x, dict) and "at" in x:
        r = list(x.get("rays") or [])
        return u"∠%s%s%s" % (r[0] if r else "?", x["at"],
                             r[1] if len(r) > 1 else "?")
    return str(x)


def _ops(c):
    v = []
    for k in sorted(c.f):
        x = c.f[k]
        v.append((",".join if any(isinstance(y, dict) for y in x) else
                  "".join)(map(_op1, x))
                 if isinstance(x, (list, tuple)) else _op1(x))
    return "(%s)" % ",".join(v)


def _phrase(dec):
    """A declared claim the way a sheet writes it (v6.8 r1: refusals read
    'declares AB = AC', never 'equal_length(ABAC)'); the raw form only for
    a type the sheet has no notation for."""
    if isinstance(dec, dict) and dec.get("type") in (
            "equal_angle", "equal_length", "perpendicular", "parallel",
            "angle", "length", "midpoint"):
        try:
            got = _say(dec)
            if got and "(" not in got:
                return got
        except Exception:                            # noqa: BLE001
            pass
    return _phrase_raw(dec)


def _typed_phrase(c):
    """'equal_angle ∠BAC = ∠EDF': the constraint's type (what a reader
    greps for) and the claim the way the sheet writes it."""
    raw = "%s%s" % (c.type, _ops(c))
    try:
        said = _phrase(dict(getattr(c, "f", {}) or {}, type=c.type))
    except Exception:                                # noqa: BLE001
        return raw
    return raw if said.startswith(c.type) else "%s %s" % (c.type, said)


def _phrase_raw(dec):
    return "%s%s" % (dec.get("type", "?"),
                     _ops(type("C", (), {"f": dict(
                         (k, v) for k, v in dec.items()
                         if k not in ("text", "type"))})))


# v6.6 E (V2-S3): an item that ASKS for a proof. A `given` declared there
# is the cheapest way past the to_prove check (relabel the claim), and it
# leaves sheet.json telling the author's AI that the student is handed what
# the student is asked to prove -- so it is reported, never silent.
# v6.7 r2 (V67F2-proof-verbs-silent): the request for an argument is any
# verb of _VERBS (a whole word, ו- allowed: "ונמקו"), a sentence that opens
# with מדוע / למה ("מדוע ∠A = ∠D?"), or a yes/no question (האם, בדקו האם)
# on a sheet that asks to argue the answer anywhere in the item.
_VERB_RE = re.compile(u"(?<![א-ת])ו?(?:%s)(?![א-ת])" % _VERBS)
_PROOF = re.compile(u"(?:(?<![א-ת])ו?(?:%s)(?![א-ת])|"
                    u"(?:^|(?<=[.;?!:\\n]))\\s*(?:מדוע|למה)(?![א-ת])|"
                    u"(?<![א-ת])(?:בדקו\\s+)?(?:ה)?אם(?![א-ת])"
                    u"(?=[\\s\\S]*(?<![א-ת])ו?(?:%s)(?![א-ת])))"
                    % (_VERBS, _VERBS))
# a request that STATES a claim (not "... נמקו את תשובתכם" after a sum):
# only these make an unreadable item a report row
_STRONG = re.compile(u"(?:(?<![א-ת])ו?(?:הוכיחו|הוכיחי|הוכח|הראו|הראי|הראה)"
                     u"(?![א-ת])|(?<![א-ת])ו?(?:%s)\\s*(?:(?:כי|מדוע|למה)(?![א-ת])|ש-|:|"
                     u"את\\s+הטענה)|(?:^|(?<=[.;?!:\\n]))\\s*(?:מדוע|למה)"
                     u"(?![א-ת]))" % _VERBS)
# v6.8 r1: under to_prove=[] ("explain, no geometric claim") only a request
# to PROVE / SHOW over a figure is still a claim to report -- "הסבירו מדוע"
# is the explaining the declaration names
_PROVE = re.compile(u"(?<![א-ת])ו?(?:הוכיחו|הוכיחי|הוכח|הראו|הראי|הראה|"
                    u"להוכיח|להראות)(?![א-ת])")
_DOLLAR = re.compile(u"\\$[^$]+\\$")


def _claims_in(text):
    """The statements a proof item's own text asks to prove, parsed.

    v6.7 r2: every sentence of the item is read. A sentence holding a
    request (a verb of _VERBS, מדוע / למה, האם) gives the claim that
    follows the request; a request with nothing after it ("... ? נמקו",
    "נמקו את תשובתכם") argues the question just before it, when that one
    is a question (האם / מדוע / למה). A sentence opening with נתון / ידוע
    is a given, never a claim."""
    t = _dehyphen(_untex_keep(str(text or "")))
    sents = [x for x in re.split(u"(?<=[;?!\\n])|(?<=\\.)(?!\\d)", t)]
    out = []
    lead = re.compile(u"^\\s*(?:(?:בדקו\\s+)?(?:ה)?אם|מדוע\\s+זה\\s+נכון|"
                      u"מדוע|למה|את\\s+הטענה(?:\\s+הבאה)?|את\\s+השוויון|"
                      u"(?:ש-?)?מתקיי(?:ם|מת|מים|מות)|כי|ש-?|:|,)"
                      u"(?![א-ת])\\s*")

    def _strip(rest):
        prev = None
        while prev != rest:
            prev = rest
            rest = lead.sub(u"", rest)
            rest = re.sub(u"^\\s*(?:%s)(?![א-ת])\\s*" % _VERBS, u"", rest)
        return rest

    def _parse(rest):
        got = []
        rest = re.split(u"[;\\n?!]|\\.(?!\\d)", rest)[0]
        rest = _strip(rest)
        # "בדקו האם X ונמקו": the claim ends where the request to argue it
        # begins
        rest = re.split(u"\\s+ו?(?:%s)(?![א-ת])" % _VERBS, rest)[0]
        whole = parse_statement(rest)
        # the whole claim first: "הזוויות BAC ו-EDF שוות" holds a ו-
        for part in ([rest] if whole else
                     re.split(u"\\s+(?:וגם|ו-|וכי|ושה|ש-)\\s*|,", rest)):
            c = parse_statement(part)
            if c:
                got.append(c)
        for chunk in _DOLLAR.findall(rest):
            c = parse_statement(chunk)
            if c:
                got.append(c)
        return got

    for i, sent in enumerate(sents):
        # v6.8 §3: a sentence opening with נתון / ידוע states a given; a
        # request later in it ("נתון AB = DE, הוכיחו כי X") still asks X --
        # only the claim AFTER the request is read (below), never the given
        ms = list(_PROOF.finditer(sent))
        if not ms:
            continue
        got = []
        for m in ms:
            got = _parse(sent[m.start():] if not _VERB_RE.match(
                sent[m.start():].lstrip()) else sent[m.end():])
            if got:
                break
        if not got and i > 0 and re.match(
                u"^\\s*(?:(?:בדקו\\s+)?(?:ה)?אם|מדוע|למה)(?![א-ת])",
                sents[i - 1]):
            got = _parse(sents[i - 1])
        # v6.8 §3: a bare request -- "הוכיחו:" with the claim on the next
        # line, or "X. הוכיחו." with the claim before it
        bare = re.match(u"^\\s*%s\\s*ו?(?:%s)\\s*[:.;!]?\\s*$"
                        % (_AUX, _VERBS), sent)
        if not got and bare:
            if sent.rstrip().endswith(u":") and i + 1 < len(sents):
                got = _parse(u"כי " + sents[i + 1])
            elif i > 0 and not re.match(u"^\\s*(?:נתון|ידוע)(?![א-ת])",
                                        sents[i - 1]):
                got = _parse(u"כי " + sents[i - 1])
        # v6.8 r1: the claim BEFORE the request, in the same sentence --
        # "∠BAC = ∠EDF, הוכיחו זאת", "AB ⊥ AC -- הוכיחו"
        if not got:
            m0 = ms[0]
            pre = sent[:m0.start()]
            post = sent[m0.end():]
            if (pre.strip() and re.match(
                    u"^\\s*(?:זאת|את\\s+זה|זו|את\\s+הטענה)?\\s*[.:;!]?\\s*$", post)
                    and not re.match(u"^\\s*(?:נתון|ידוע)(?![א-ת])", pre)):
                got = _parse(u"כי " + pre.rstrip(u" ,:;–—-"))
        out.extend(got)
    return out


def _untex_keep(t):
    """The text with each $...$ chunk kept in place but de-TeXed, so the
    phrase scanner sees '∠A' where the sheet wrote '$\\angle A$'."""
    return _DOLLAR.sub(lambda m: _untex(m.group(0)), t)


def _short_names(c):
    if isinstance(c, dict) and c.get("right_of"):
        return ["?"]
    return list(c.get("short") or []) if isinstance(c, dict) else []


def _right_of(c, figs):
    """v6.7 r1: "המשולש ABC ישר זווית" -> the angle claim at the ONE vertex
    of ABC where the figures state a right angle, or (None, why)."""
    tri = list(c["right_of"])
    if tri == ["*"]:
        tris = set()
        for _fid, rec, _svg in figs:
            if rec is None:
                continue
            ob = rec.objects
            for it in ob.items:
                if it.kind == "polygon" and len(it.pts) == 3:
                    ns = [ob.name_of(q) for q in it.pts]
                    if all(ns):
                        tris.add(tuple(ns))
        if len(tris) != 1:
            return None, ("'the triangle is a right triangle' names no "
                          "triangle, and the figure draws %s -- name it "
                          "(המשולש ABC ישר זווית ב-A)"
                          % ("no named triangle" if not tris else
                             "%d triangles" % len(tris)))
        tri = list(next(iter(tris)))
    found = []
    for v in tri:
        r = [x for x in tri if x != v]
        cand = {"type": "angle", "at": v, "rays": r, "value": 90.0,
                "unit": "deg"}
        for _fid, rec, _svg in figs:
            if rec is None:
                continue
            cons = rec.objects.cons
            if _match(cand, cons) or _equiv(cand, cons):
                found.append(cand)
                break
    if not found:
        # nothing exported states a right angle there: MEASURE each vertex
        # on the finished drawing (read only -- nothing is added)
        for v in tri:
            r = [x for x in tri if x != v]
            cand = {"type": "angle", "at": v, "rays": r, "value": 90.0,
                    "unit": "deg"}
            if any(_measures(cand, rec, svg) for _f, rec, svg in figs
                   if rec is not None):
                found.append(cand)
    if len(found) == 1:
        return found[0], None
    return None, ("'%s is a right triangle' does not say at which vertex, "
                  "and the figure states a right angle at %s -- write "
                  "∠%s%s%s = 90° (or 'ישר זווית ב-%s')"
                  % ("".join(tri), "none of its vertices" if not found else
                     "more than one", tri[1], tri[0], tri[2], tri[0]))


def _vertex_angles(figs):
    """{vertex name: set of (ray, ray)} over the question's figures: the
    named points joined to each named point by a drawn segment or polygon
    edge. A vertex with exactly two neighbours has ONE angle (∠A is it)."""
    nb = {}
    for _fid, rec, _svg in figs:
        if rec is None:
            continue
        ob = rec.objects
        for it in ob.items:
            if it.kind == "polygon" and len(it.pts) >= 3:
                ns = [ob.name_of(q) for q in it.pts]
                for i in range(len(ns)):
                    a, b = ns[i], ns[(i + 1) % len(ns)]
                    if a and b and a != b:
                        nb.setdefault(a, set()).add(b)
                        nb.setdefault(b, set()).add(a)
            elif it.kind == "segment" and len(it.pts) >= 2:
                a, b = ob.name_of(it.pts[0]), ob.name_of(it.pts[-1])
                if a and b and a != b:
                    nb.setdefault(a, set()).add(b)
                    nb.setdefault(b, set()).add(a)
    return nb


def _measures(dec, rec, svg):
    """True when `dec` holds on the finished figure (measured, not added)."""
    ob = rec.objects
    if ob.projection and dec["type"] in export.PROJECTION_UNSAFE:
        return False
    try:
        con = export.Con(dec["type"], dict((k, v) for k, v in dec.items()
                                           if k != "type"),
                         "to_prove", None, False, None)
        con._pending = False
        fr = export.Frame(svg, ob.view)
        scale = export.length_scale(list(ob.cons) + [con], fr)
        return bool(export.measure(con, fr, scale)[0])
    except Exception:                            # noqa: BLE001
        return False


def resolve_short(c, figs):
    """v6.7 (E-r2-single-letter-angle): a claim naming an angle by its
    vertex alone (∠A) -> the same claim with the full angle (∠BAC), when
    the figures draw exactly one angle at that vertex (two neighbours: a
    polygon's corner). Returns (claim, None), or (None, why) when the
    vertex has no drawn angle or more than one -- such a claim is REPORTED,
    never shipped as if it had been checked."""
    short = _short_names(c)
    if not short:
        return c, None
    if c.get("right_of"):
        return _right_of(c, figs)
    nb = _vertex_angles(figs)
    full = {}
    for v in short:
        n = sorted(nb.get(v, ()))
        if len(n) != 2:
            return None, ("∠%s names the angle by its vertex alone, and the "
                          "figure draws %s at %s -- write the three letters "
                          "(∠%s)" % (v, "no angle" if len(n) < 2 else
                                     "%d segments meeting" % len(n), v,
                                     (n[0] + v + n[1]) if len(n) >= 2 else
                                     "X%sY" % v))
        full[v] = n[0] + v + n[1]
    out = dict((k, x) for k, x in c.items() if k != "short")
    if out["type"] == "equal_angle":
        out["of"] = [full.get(x, x) for x in out["of"]]
    elif out["type"] == "angle":
        n = full[out["at"]]
        out["rays"] = [n[0], n[-1]]
    return out, None


def _same(a, b):
    if a.get("type") != b.get("type"):
        return False
    t = a["type"]
    ka = dict((k, _canon(t, k, v)) for k, v in a.items() if k != "type")
    kb = dict((k, _canon(t, k, v)) for k, v in b.items() if k != "type")
    return ka == kb


def given_on_proof(text, given, to_prove, where, item, figs=()):
    """Report rows for `given` declared on an item whose text asks for a
    proof: the given IS a claim the text asks to prove (relabelled), or the
    item declares givens and no to_prove at all."""
    if not given or not _PROOF.search(_dehyphen(str(text or ""))):
        return []
    rows = []
    asked = [x for x in (resolve_short(a, figs)[0] for a in _claims_in(text))
             if x is not None]
    for g in given:
        gt = g if isinstance(g, str) else (g.get("text") or _phrase(g))
        gc = parse_statement(g) if isinstance(g, str) else (
            dict(g) if isinstance(g, dict) and "type" in g
            else parse_statement(g.get("text")))
        if gc is not None:
            gc = dict((k, v) for k, v in gc.items()
                      if k not in ("text", "item", "source"))
            gc = resolve_short(gc, figs)[0]
        if gc is not None and any(_same(gc, a) for a in asked):
            rows.append({"where": where, "item": item, "given": gt,
                         "why": "the item's text asks the student to "
                                "prove this -- declare it to_prove, not "
                                "given"})
    if not rows and to_prove is None:
        rows.append({"where": where, "item": item,
                     "given": u"; ".join(g if isinstance(g, str) else
                                         (g.get("text") or _phrase(g))
                                         for g in given),
                     "why": "the item asks for a proof and declares givens "
                            "but no to_prove -- if a claim was relabelled "
                            "given to pass the to_prove check, the JSON now "
                            "hands the student the proof"})
    return rows


def _say(c):
    """A parsed claim written back the way a sheet writes it."""
    t, of = c.get("type"), c.get("of") or []
    if t == "equal_angle":
        return u" = ".join(u"∠" + (x if isinstance(x, str) else
                                   u"%s%s%s" % ((x.get("rays") or ["", ""])[0],
                                               x.get("at", ""),
                                               (x.get("rays") or ["", ""])[-1]))
                           for x in of)
    if t == "equal_length":
        return u" = ".join(of)
    if t in ("perpendicular", "parallel") and len(of) == 2:
        return (u" ⊥ " if t == "perpendicular" else u" ∥ ").join(of)
    # v6.8 §3 (V67F3-garbled-claim-in-report): an angle reads as the sheet
    # writes it -- ∠A = 90°, never angle(A,,A,deg,90.0)
    if t == "angle":
        r = [str(x) for x in (c.get("rays") or [])]
        at = str(c.get("at") or "?")
        name = (u"%s%s%s" % (r[0], at, r[1])) if len(r) == 2 else at
        v = c.get("value")
        try:
            v = u"%g" % float(v)
        except (TypeError, ValueError):
            v = str(v)
        return u"∠%s = %s°" % (name, v)
    if t == "length":
        return u"%s = %s" % (c.get("of"), c.get("value"))
    if t == "midpoint":
        return u"%s אמצע %s" % (c.get("point"), "".join(map(str, of)))
    return _phrase_raw(c)


def _declared_same(c, decls, figs=()):
    for dec in decls or []:
        try:
            dc = parse_statement(dec) if isinstance(dec, str) else (
                dict(dec) if isinstance(dec, dict) and "type" in dec
                else parse_statement(dec.get("text")))
        except Exception:
            dc = None
        if dc is not None:
            dc = dict((k, v) for k, v in dc.items()
                      if k not in ("text", "item", "source"))
            dc = resolve_short(dc, figs)[0]
            if dc is not None and _same(dc, c):
                return True
    return False



# v6.7 r1 (V67F-congruent-pair-route): a refusal for a MARKED claim names
# calls that render THIS figure without that mark -- each one drawn (as a
# probe the export forgets) and read before it is named. The knobs are the
# ones the builder has: congruent_pair has no arcs=/ticks=, but another
# kind= marks other parts (kind='sss' leaves the angles to be proved).
_UNMARK_KNOBS = {"congruent_pair": ("kind", ("sss", "sas", "asa")),
                 "shape": ("marks", (False,)),
                 "bisector": ("arcs", (False,)),
                 "midpoint": ("ticks", (False,)),
                 "median": ("ticks", (False,))}
_UNMARK_MAX = 4


def _claim_dict(c):
    if isinstance(c, dict):
        return dict((k, v) for k, v in c.items()
                    if k not in ("text", "item", "source", "short"))
    d = {"type": c.type}
    d.update(c.f)
    return d


def _still_marked(claim, rec, svg):
    cons = rec.objects.cons
    for h in (_match(claim, cons) or _equiv(claim, cons)):
        if h.marked or export.implied_by_marks(h, cons, svg):
            return True
    return False


def _marked_says(rec, claim=None):
    out = set()
    for c in rec.objects.cons:
        if not c.marked or c.type == "hidden_edge":
            continue
        if claim is not None and (_match(claim, [c]) or _equiv(claim, [c])):
            continue
        try:
            out.add(_say(_claim_dict(c)))
        except Exception:                        # noqa: BLE001
            out.add(c.type)
    return out


def _givens_change(rec, r2, claim):
    """v6.7 r2 (V67F2-unmark-route-changes-givens): what a route changes
    besides the mark on the claim, said out loud (doctrine 4: nothing is
    dropped silently). '' when the other marks are the same."""
    a, b = _marked_says(rec, claim), _marked_says(r2, claim)
    lost, new = sorted(a - b), sorted(b - a)
    if not lost and not new:
        return ""
    bits = []
    if lost:
        bits.append("drops the given%s %s" % ("s" if len(lost) > 1 else "",
                                              ", ".join(lost)))
    if new:
        bits.append("adds the given%s %s" % ("s" if len(new) > 1 else "",
                                             ", ".join(new)))
    return (" [this CHANGES the question's givens: %s -- rewrite the "
            "question's data to match, or keep the figure and drop the "
            "claim]" % "; ".join(bits))


def unmark_routes(rec, claim):
    """Calls, as source text, that draw the recorded figure without the
    mark on `claim` -- each drawn and checked. [] when none is found."""
    import ast
    rp = ((getattr(rec, "code", None) or {}).get("replay") or {})
    src = rp.get("src") or ""
    try:
        tree = ast.parse(src)
    except SyntaxError:
        return []
    claim = _claim_dict(claim)
    cands = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        fn = node.func.attr if isinstance(node.func, ast.Attribute) else (
            node.func.id if isinstance(node.func, ast.Name) else None)
        if fn not in _UNMARK_KNOBS:
            continue
        kw, vals = _UNMARK_KNOBS[fn]
        cur = [k for k in node.keywords if k.arg == kw]
        now = None
        if cur:
            try:
                now = ast.literal_eval(cur[0].value)
            except ValueError:
                now = None
        for v in vals:
            if v == now or (now is None and fn == "congruent_pair" and
                            v == "sas"):
                continue
            cands.append((node, kw, v))
    out = []
    saved = (dict(export._FIGS), list(export._ORDER), list(export._ENTRY),
             list(export._REPLAY), list(export._SEQ))
    try:
        for node, kw, v in cands[:_UNMARK_MAX]:
            old = list(node.keywords)
            node.keywords = [k for k in old if k.arg != kw] + [
                ast.keyword(arg=kw, value=ast.Constant(v))]
            new_src = ast.unparse(tree)
            call = ast.unparse(node)
            node.keywords = old
            n0 = len(export._ORDER)
            ns = {"__name__": "_unmark_probe"}
            try:
                exec(compile(new_src, "<unmark-probe>", "exec"), ns)
            except Exception:                    # noqa: BLE001
                continue
            svg2 = ns.get("svg") or next(
                (x for x in ns.values() if isinstance(x, str) and
                 x.lstrip().startswith("<svg")), None)
            # the record by the drawn file (a figure drawn before with the
            # same data is registered once, so _ORDER need not grow)
            r2 = export.lookup(svg2) if svg2 else None
            if r2 is None and export._ORDER[n0:]:
                r2 = export._FIGS.get(export._ORDER[-1])
            if r2 is None or svg2 is None:
                continue
            if not _still_marked(claim, r2, svg2):
                out.append(call + _givens_change(rec, r2, claim))
    finally:
        export._FIGS.clear()
        export._FIGS.update(saved[0])
        export._ORDER[:] = saved[1]
        export._ENTRY[:] = saved[2]
        export._REPLAY[:] = saved[3]
        export._SEQ[:] = saved[4]
    return out


def _route_text(rec, claim):
    try:
        got = unmark_routes(rec, claim)
    except Exception:                            # noqa: BLE001
        got = []
    if not got:
        return ""
    return ("For THIS figure, drawn and checked without that mark: %s. "
            % "; ".join(got))

_BARE = re.compile(u"^\\s*ו?(?:הוכיחו|הוכיחי|הוכח|הראו|הראי|הראה|נמקו|"
                   u"הסבירו|הצדיקו|בססו|יש\\s+להוכיח|יש\\s+להראות)"
                   u"(?:\\s+(?:זאת|זו|זה|את\\s+זה|את\\s+הטענה(?:\\s+הזו|"
                   u"\\s+הזאת)?|את\\s+השוויון))?\\s*[.!:]?\\s*$")


def _claims_before(context):
    """v6.8 r2 (D4): a bare 'הוכיחו זאת.' proves what the question said just
    before it ('בציור ∠BAC = ∠EDF.'). The last sentence of the question's
    text that states a claim, read as one; a sentence opening with נתון /
    ידוע states a given and is skipped."""
    t = _dehyphen(_untex_keep(str(context or "")))
    for sent in reversed(re.split(u"(?<=[;?!\\n])|(?<=\\.)(?!\\d)", t)):
        sent = sent.strip()
        if not sent or re.match(u"^(?:נתון|נתונה|נתונים|נתונות|ידוע)"
                                u"(?![א-ת])", sent):
            continue
        rest = re.sub(u"^(?:[א-ת]+[\\s,:]+)+", u"", sent)
        got = []
        for chunk in [rest] + _DOLLAR.findall(sent):
            c = parse_statement(chunk)
            if c:
                got.append(c)
        if got:
            return got
    return []


_REL = re.compile(u"[=∥⊥≅∠]|\\\\(?:cong|parallel|perp|angle)")
# v6.8 final: a proof request with to_prove=[] is still reported when its
# text names a geometric relation in words ('שהמשולשים חופפים', 'מקבילים')
_GEO_WORDS = re.compile(u"חופפ|שוו(?:ה|ים|ות)|מקביל|מאונכ|מאונך|ניצב|"
                        u"ישר[\\s-]+זווית|אמצע|חוצ|משיק|זווי|משולש|צלע|"
                        u"אלכסון|מרובע|מקבילית|מעוין|טרפז|מעגל|רדיוס|קוטר")


def _formulas_in(text):
    """v6.8 final (R3-D4-claim-with-leading-word): when the request reading
    finds no claim, every formula of the item's text is read -- a claim
    sentence may open with any word ('בציור ∠BAC = ∠EDF. הוכיחו.', 'גם …
    נמקו.'). Sentences opening with נתון / ידוע state givens and are
    skipped."""
    t = _dehyphen(_untex_keep(str(text or "")))
    out = []
    for sent in re.split(u"(?<=[;?!\\n])|(?<=\\.)(?!\\d)", t):
        if re.match(u"^\\s*(?:נתון|נתונה|נתונים|נתונות|ידוע)(?![א-ת])", sent):
            continue
        for span in re.findall(u"[^א-ת]+", sent):
            span = span.strip(u" ,:;.?!\u200f\u200e")
            if span and _REL.search(span):
                c = parse_statement(span)
                if c:
                    out.append(c)
    return out


def proof_undeclared(text, to_prove, figs, where, item, context=None):
    """v6.6 E r1 (E-d4-drop-toprove): an item whose text asks for a proof
    and declares NO to_prove is read as declaring the claims its own text
    states. A claim the figure MARKS (an arc pair, ticks, a right-angle
    mark -- or marks that imply it) is refused exactly as a declared
    to_prove would be: deleting the to_prove is not a way past doctrine 4.
    A claim the figure does not mark is reported (the JSON has nothing that
    checks it). Returns the report rows."""
    if not _PROOF.search(_dehyphen(str(text or ""))):
        return []
    rows = []
    claims = _claims_in(text)
    if not claims and context and _BARE.match(
            _dehyphen(_untex_keep(str(text or "")))):
        claims = _claims_before(context)
    if not claims:
        claims = _formulas_in(text)
    # v6.8 r1 (D4-tp-empty-silences-marked-claim): to_prove=[] does not
    # silence it -- [] says "no geometric claim", and a strong proof verb
    # over a figure says there is one this module could not read
    # v6.8 final: to_prove=[] is the author's declaration "explain, no
    # geometric claim" (§3); it is reported only when the text still holds
    # a relation (=, ∥, ⊥, ≅, ∠) this module could not read
    if not claims and not to_prove and (
            _STRONG if to_prove is None else _PROVE).search(
            _dehyphen(str(text or ""))) and (
            to_prove is None or _REL.search(
                _dehyphen(_untex_keep(str(text or "")))) or
            _GEO_WORDS.search(str(text or ""))) and any(
            rec is not None for _f, rec, _s in figs):
        # v6.7 r1: a proof item whose claim this module cannot read at all
        # is REPORTED -- silence would read as "checked against the figure"
        rows.append({"where": where, "item": item, "claim": str(text),
                     "why": "the item asks for a proof, and its claim is "
                            "worded in a form deliver cannot read, so the "
                            "figure was not checked against it (a mark on "
                            "the claim would give the proof away unseen) -- "
                            "write it as ∠BAC = 90°, AB = CD, AB ⊥ CD, or "
                            "declare it to_prove" + (
                                "" if to_prove is None else
                                " (the item declares to_prove=[], and its "
                                "text still asks for a proof over a "
                                "figure)")})
    for c0 in claims:
        c = dict((k, v) for k, v in c0.items()
                 if k not in ("text", "item", "source"))
        said = c0.get("text") or _say(c)
        if _short_names(c):
            c, why_short = resolve_short(c, figs)
            if c is None:
                # v6.7: ∠A with no single angle at A -- reported, not
                # silently shipped (the figure could not be checked)
                rows.append({"where": where, "item": item, "claim": said,
                             "why": why_short})
                continue
            said = _say(c)
        if _declared_same(c, to_prove, figs):
            continue          # the declared to_prove gets its own check
        for fid, rec, svg in figs:
            if rec is None:
                continue
            cons = rec.objects.cons
            hit = _match(c, cons) or _equiv(c, cons)
            for h in hit:
                by = [] if h.marked else export.implied_by_marks(h, cons, svg)
                if h.marked or by:
                    marks = [m.mark_id or m.type for m in
                             ([h] if h.marked else by)]
                    _bad("%s asks the student to prove %s, and figure %s "
                         "MARKS it (%s) -- whatever the item declares (no "
                         "to_prove, a given, another to_prove), the drawing "
                         "gives the proof away"
                         % (where, said, fid,
                            ", ".join(sorted(set(map(str, marks))))),
                         _route_text(rec, c) +
                         "otherwise take the mark off the figure with "
                         "the builder's own knob, where it has one "
                         "(arcs=False, no "
                         "ticks, no right-angle mark on what is to be "
                         "proved) and declare the claim to_prove")
        if to_prove:
            continue
        rows.append({"where": where, "item": item, "claim": said,
                     "why": ("the item's text asks for a proof of this and "
                             "declares no to_prove -- declare it, so the "
                             "figure is checked against it")
                     if to_prove is None else
                            ("the item declares to_prove=[] (no geometric "
                             "claim), and its text reads as the claim %s -- "
                             "declare it, or reword the item" % said)})
    return rows


def _answers(L):
    """{question number: {item label: answer text}} from `answers`."""
    out = {}
    for row in L.get("answers", []) or []:
        if not isinstance(row, (list, tuple)) or len(row) < 2:
            continue
        n, items = row[0], row[1]
        d = out.setdefault(str(n), {})
        if isinstance(items, (list, tuple)):
            for pair in items:
                if isinstance(pair, (list, tuple)) and len(pair) >= 2:
                    d[str(pair[0])] = pair[1]
        else:
            d["*"] = items
    return out


PACKAGE_RE = re.compile(r"^G(?:[7-9]|1[0-2])-T[0-9]{2}$")
LEVEL_KEYS = ("a", "b", "c")


def asks_proof(text):
    """v6.8 §3: does this text ask for a proof / an argument, in any form
    (imperative, past, infinitive after יש / צריך / עליכם, after a comma,
    colon or newline, or a bare 'X. הוכיחו.' at the end)?"""
    return bool(_PROOF.search(_dehyphen(_untex_keep(str(text or "")))))


# r2 M2: an item may ask for an argument without a proof verb -- 'בדקו ש',
# 'שכנעו ש', a yes/no question 'האם המשולש MDC שווה שוקיים?' -- when it
# names points (a geometric claim). Used by the didactic checks only (the
# older undeclared_proofs contract keeps asks_proof).
_ASK_MORE = re.compile(u"(?<![א-ת])ו?(?:בדקו|בדקי|בדוק|שכנעו|שכנעי|שכנע|"
                       u"ודאו|וודאו|אמתו)(?![א-ת])|"
                       u"(?<![א-ת])האם(?![א-ת])[^?.!\n]*\\?")
_ASK_END = re.compile(u"[.?!;\n]")


def asks_argument(text):
    """asks_proof, or a check / convince verb or a yes/no question over a
    text that names two or more points (r2 M2)"""
    if asks_proof(text):
        return True
    t = _dehyphen(_untex_keep(str(text or "")))
    return bool(_ASK_MORE.search(t)) and any(
        len(DD.toks(r)) >= 2 for r in DD._RUN.findall(t))


def asked_clauses(text):
    """the parts of a text that state what the student is asked to argue:
    from each request word to the end of its sentence, and each yes/no
    question (r2 M2)"""
    t = _dehyphen(_untex_keep(str(text or "")))
    out = []
    for rx in (_PROOF, _ASK_MORE):
        for m in rx.finditer(t):
            if m.group(0).lstrip().startswith(u"האם"):
                out.append(m.group(0))
                continue
            e = _ASK_END.search(t, m.end())
            out.append(t[m.end():e.start() if e else len(t)])
    return [c for c in out if c.strip()]


def undeclared_proofs(L):
    """[(where, text)] for every question / item whose text asks for a proof
    and carries no explicit `to_prove` key (v6.8 §3; [] is a declaration)."""
    out = []
    for q in L.get("questions", []):
        n = q.get("n")
        qt = u" ".join(str(q.get(k) or "") for k in ("text", "intro"))
        if asks_proof(qt) and "to_prove" not in q:
            out.append(("question %s" % n, qt.strip()))
        for it in q.get("items", []) or []:
            d = _as_item(it)
            if asks_proof(d["text"]) and "to_prove" not in d:
                out.append(("item %s of question %s" % (d["label"], n),
                            str(d["text"]).strip()))
    return out


# ------------------------------------------- v6.7.1-noam: didactic layer --
_CONSTRUCT_KEYS = ("text", "type", "points", "point", "of", "t", "at",
                   "rays", "value", "unit", "circle", "to")


def to_construct_claims(lst, where):
    """`to_construct` as claim dicts: an object the student adds
    ({'type': 'segment', 'of': 'BD'}, {'type': 'point', 'point': 'E'},
    {'type': 'polygon', 'points': [...]}) or a relation the construction
    makes ({'type': 'parallel', 'of': ['EF', 'AB']}); wording alone is kept
    as {'text': ...} (and parsed when it reads as a relation)."""
    out = []
    for c in lst or []:
        if isinstance(c, str):
            p = parse_statement(c)
            d = dict(p) if p else {}
            d["text"] = c
            out.append(d)
            continue
        if not isinstance(c, dict):
            _bad("%s declares to_construct %r" % (where, c),
                 "an object to construct is a dict, e.g. {'type': "
                 "'segment', 'of': 'BD', 'text': 'האלכסון BD'}")
        t = c.get("type")
        if t not in DD.OBJECT_TYPES and t not in export.CONSTRAINT_TYPES:
            _bad("%s declares to_construct of type %r" % (where, t),
                 "to_construct names an object (%s) or a relation the "
                 "construction makes (%s)" % (
                     ", ".join(DD.OBJECT_TYPES),
                     ", ".join(sorted(export.CONSTRAINT_TYPES))))
        out.append(dict((k, v) for k, v in c.items()
                        if k in _CONSTRUCT_KEYS))
    return out


def _aux_entries(L):
    """[(fig_id, svg, question, item, spec)] of the aux figures (שרטוט עזר):
    never printed, public on request."""
    out = []
    for q in L.get("questions", []):
        n = q.get("n")
        rows = [("q%s" % n, None, q)]
        for it in q.get("items", []) or []:
            d = _as_item(it)
            rows.append((item_id(n, d["label"]), item_id(n, d["label"]), d))
        for rid, iid, d in rows:
            for k, a in enumerate(d.get("aux") or []):
                spec = dict(a) if isinstance(a, dict) else {"fig": a}
                svgs = svgs_in(spec.get("fig"))
                for j, svg in enumerate(svgs):
                    out.append(("%s_aux%d%s" % (rid, k + 1,
                                                "" if j == 0 else "_%d" % j),
                                svg, "q%s" % n, iid, spec))
    return out


def _ans_of(ans, n, label):
    a = ans.get(str(n), {})
    return a.get(label) if label is not None else a.get("*")


_DIDACTIC_KEYS = ("hint_type", "exposure", "requires_human_review",
                  "allowed_tools", "aux_allowed", "forbidden_to_show",
                  "hint", "approved", "approved_by", "note")


def didactic_row(spec, rid, where, to_prove, to_construct, answer, qtext,
                 has_aux, allowed_ids, reg):
    """One item's private didactic record (didactic.json) and its public
    face (hint_mode, approved hint text). Refuses what can be decided."""
    spec = dict(spec or {})
    bad = [k for k in spec if k not in _DIDACTIC_KEYS]
    if bad:
        _bad("%s: didactic names unknown key(s) %s" % (where, bad),
             "didactic = dict(%s)" % ", ".join(_DIDACTIC_KEYS))
    ht = spec.get("hint_type", "guiding_question")
    if ht not in DD.HINT_TYPES:
        _bad("%s: hint_type %r" % (where, ht),
             "one of %s" % ", ".join(DD.HINT_TYPES))
    ex = spec.get("exposure", 0)
    if not isinstance(ex, int) or not 0 <= ex <= 3:
        _bad("%s: exposure %r" % (where, ex),
             "0 (none) .. 3 (strong), an integer")
    tools = list(spec.get("allowed_tools") or [])
    known = set(t["id"] for t in reg["tools"]) if reg else set()
    unk = [t for t in tools if reg and t not in known]
    if unk:
        _bad("%s: allowed_tools names unknown id(s) %s" % (where, unk[:4]),
             "ids come from curriculum_tools.json (build_curriculum_tools."
             "py)")
    if allowed_ids is not None:
        late = [t for t in tools if t not in allowed_ids]
        if late:
            names = dict((t["id"], t["name_he"]) for t in reg["tools"])
            _bad("%s: allowed_tools %s are not yet taught at this point of "
                 "the sequence (%s)" % (where, late[:4], "; ".join(
                     names.get(t, t) for t in late[:4])),
                 "a hint may use only tools of the package's curriculum "
                 "block (allowed_tools); choose an earlier theorem or "
                 "narrow the item")
    row = {"hint_type": ht, "exposure": ex,
           "requires_human_review": bool(spec.get("requires_human_review")),
           "allowed_tools": tools,
           "aux_allowed": bool(spec.get("aux_allowed", has_aux)),
           "forbidden_to_show": list(spec.get("forbidden_to_show") or []) +
           [c.get("text") or DD._say(c) for c in (to_prove or []) +
            (to_construct or []) if isinstance(c, dict)],
           "review_reasons": []}
    if str(spec.get("note") or "").strip():
        # v6.7.2-noam item 5: the author's note travels with the record
        row["note"] = str(spec["note"])
    if has_aux and not row["aux_allowed"]:
        _bad("%s carries an aux figure and its didactic says aux_allowed="
             "False" % where, "drop the aux figure or allow it")
    hint = spec.get("hint")
    public = {"hint_mode": "concept" if ht in ("theorem", "formula")
              else "guiding_question"}
    if hint:
        verdict, why = DD.hint_verdict(hint, to_prove, to_construct, answer,
                                       qtext, ex, ht)
        if verdict == "decisive":
            _bad("%s: the hint %r gives the decisive step away -- %s"
                 % (where, hint[:60], why),
                 "a hint points to a way in and leaves the inference to the "
                 "student: ask a guiding question, name the tool (from "
                 "allowed_tools) without applying it, or leave hint out "
                 "(Noam AI then asks guiding questions)")
        if allowed_ids is not None and reg:
            late = DD.tools_named_in(hint, reg, None)
            late = [t for t in late if t not in allowed_ids]
            if late:
                names = dict((t["id"], t["name_he"]) for t in reg["tools"])
                _bad("%s: the hint uses %s, not yet taught at this point"
                     % (where, "; ".join(names.get(t, t) for t in late[:3])),
                     "use only tools of the package's allowed_tools")
        row["hint"] = hint
        if verdict == "review":
            row["requires_human_review"] = True
            row["review_reasons"].append(why)
        approved = bool(spec.get("approved"))
        if approved and not str(spec.get("approved_by") or "").strip():
            _bad("%s: hint approved without approved_by" % where,
                 "`approved` is set only by a human: approved=True, "
                 "approved_by='<who reviewed it>'")
        row["approved"] = approved
        if approved:
            row["approved_by"] = str(spec["approved_by"])
            public = {"hint_mode": "approved_hint", "approved_hint": hint}
    elif spec.get("approved"):
        _bad("%s: approved=True with no hint text" % where,
             "approve a hint text, or leave approved out")
    return row, public


# ---- C3 (v6.10): what a typed-shape given states ---------------------------
# The same block is in deliver.py, check_didactic.py and
# selfcheck_noam_package.py (each file stays independent; the v6.10 suite
# proves the three copies are identical). The statements are the
# definitions the school course uses (PENDING the author's approval):
#   parallelogram  both pairs of opposite sides parallel
#   rectangle      four right angles (as AB ⊥ BC ..., no number)
#                                           square  + four equal sides
#   rhombus        four equal sides         kite    two pairs of adjacent
#                                                   equal sides (read off the
#                                                   figure; ambiguous: refused)
#   trapezoid      the one pair of parallel sides (read off the figure;
#                  "שווה־שוקיים" in its text adds the equal legs)
#   equilateral    three equal sides        isosceles  the two equal sides
#   right_triangle the right angle          (read off the figure)
# A statement that IS a goal of the figure's question (a find / to_prove:
# 'what is the angle ABC?' of a given rectangle) is never offered --
# highlighting it would answer the question.
C3_SHAPES = ("parallelogram", "rectangle", "square", "rhombus", "kite",
             "trapezoid", "equilateral", "isosceles", "right_triangle")
_C3_TOK = re.compile(r"[A-Z][0-9]*'*")


class ShapeStateError(ValueError):
    pass


def _c3_len(P, a, b):
    return math.hypot(P[b][0] - P[a][0], P[b][1] - P[a][1])


def _c3_par(P, a, b, c, d):
    u = (P[b][0] - P[a][0], P[b][1] - P[a][1])
    v = (P[d][0] - P[c][0], P[d][1] - P[c][1])
    nu, nv = math.hypot(*u), math.hypot(*v)
    return nu > 0 and nv > 0 and \
        abs(u[0] * v[1] - u[1] * v[0]) / (nu * nv) < math.sin(
            math.radians(0.5))


def _c3_eq(P, s, t):
    a, b = _c3_len(P, *s), _c3_len(P, *t)
    return abs(a - b) <= 0.01 * max(a, b, 1e-9)


def _c3_right(P, v, a, b):
    u = (P[a][0] - P[v][0], P[a][1] - P[v][1])
    w = (P[b][0] - P[v][0], P[b][1] - P[v][1])
    nu, nw = math.hypot(*u), math.hypot(*w)
    return nu > 0 and nw > 0 and \
        abs(u[0] * w[0] + u[1] * w[1]) / (nu * nw) < math.sin(
            math.radians(0.5))


def shape_states(value, points, P=None, text=""):
    """The claims a GIVEN 'points are a <value>' states, as claim dicts
    ({type: parallel / equal_length / perpendicular, of: [..], at} --
    no number, so the overlay prints no value). P {name: (x, y)} reads the figure where the definition
    leaves a choice (which pair of a trapezoid, which vertex of an
    isosceles / right triangle, which pairs of a kite); a choice the
    figure does not settle raises ShapeStateError (refuse, never guess)."""
    pts = [str(p) for p in points or []]
    n = len(pts)
    side = [(pts[i], pts[(i + 1) % n]) for i in range(n)]

    def seg(s):
        return s[0] + s[1]

    def par(s, t):
        return {"type": "parallel", "of": [seg(s), seg(t)],
                "text": u"%s ∥ %s" % (seg(s), seg(t))}

    def eq(*ss):
        return {"type": "equal_length", "of": [seg(s) for s in ss],
                "text": " = ".join(seg(s) for s in ss)}

    def right(i):
        a, v, b = pts[i - 1], pts[i], pts[(i + 1) % n]
        return {"type": "perpendicular", "of": [a + v, v + b], "at": v,
                "text": u"%s%s ⊥ %s%s" % (a, v, v, b)}

    def need(k):
        if n != k or len(set(pts)) != k:
            raise ShapeStateError("a %s names %d distinct points, not %d"
                                  % (value, len(set(pts)), k))

    def figure():
        if not P or any(p not in P for p in pts):
            raise ShapeStateError("which sides a %s's given states is read "
                                  "off the figure, and its points are not "
                                  "all drawn" % value)
    if value == "parallelogram":
        need(4)
        return [par(side[0], side[2]), par(side[1], side[3])]
    if value == "rectangle":
        need(4)
        return [right(i) for i in range(4)]
    if value == "square":
        need(4)
        return [right(i) for i in range(4)] + [eq(*side)]
    if value == "rhombus":
        need(4)
        return [eq(*side)]
    if value == "trapezoid":
        need(4)
        figure()
        pairs = [(side[0], side[2]), (side[1], side[3])]
        hit = [pq for pq in pairs if _c3_par(P, *(pq[0] + pq[1]))]
        if len(hit) != 1:
            raise ShapeStateError("the figure shows %d parallel pair(s) of "
                                  "the trapezoid %s: its bases are not "
                                  "settled" % (len(hit), "".join(pts)))
        out = [par(*hit[0])]
        if re.search(u"שווה[־\\s-]?שוק"
                     u"יים", str(text or "")):
            legs = [s for s in side if s not in hit[0]]
            out.append(eq(*legs))
        return out
    if value == "kite":
        need(4)
        figure()
        cfg = [((side[0], side[1]), (side[2], side[3])),
               ((side[1], side[2]), (side[3], side[0]))]
        ok = [c for c in cfg if _c3_eq(P, *c[0]) and _c3_eq(P, *c[1])]
        if len(ok) != 1:
            raise ShapeStateError("the figure does not settle the equal "
                                  "pairs of the kite %s" % "".join(pts))
        return [eq(*ok[0][0]), eq(*ok[0][1])]
    if value == "equilateral":
        need(3)
        return [eq(*side)]
    if value == "isosceles":
        need(3)
        figure()
        at = [i for i in range(3) if _c3_eq(P, side[i - 1], side[i])]
        if len(at) != 1:
            raise ShapeStateError("the figure does not settle the apex of "
                                  "the isosceles %s (%d candidates)"
                                  % ("".join(pts), len(at)))
        i = at[0]
        return [eq(side[i - 1], side[i])]
    if value == "right_triangle":
        need(3)
        figure()
        at = [i for i in range(3) if _c3_right(P, pts[i], pts[i - 1],
                                                pts[(i + 1) % 3])]
        if len(at) != 1:
            raise ShapeStateError("the figure does not settle the right "
                                  "angle of %s" % "".join(pts))
        return [right(at[0])]
    raise ShapeStateError("no statement is known for the shape %r" % value)


def c3_key(c):
    """A canonical key of a stated claim (order of names ignored)."""
    t = (c or {}).get("type")
    if t in ("parallel", "equal_length", "perpendicular"):
        segs = sorted("".join(sorted(_C3_TOK.findall(str(s))))
                      for s in c.get("of") or [])
        if t != "perpendicular":
            return (t, tuple(segs))
        at = c.get("at")
        if not at and len(segs) == 2:
            common = set(_C3_TOK.findall(segs[0])) & set(
                _C3_TOK.findall(segs[1]))
            at = list(common)[0] if len(common) == 1 else None
        return (t, tuple(segs), str(at))
    if t == "angle" and str(c.get("value")) in ("90", "90.0") and \
            c.get("at") and len(c.get("rays") or []) == 2:
        v = str(c["at"])
        return c3_key({"type": "perpendicular", "at": v, "of": [
            str(c["rays"][0]) + v, v + str(c["rays"][1])]})
    if t == "angle":
        return (t, str(c.get("at")), tuple(sorted(
            str(x) for x in c.get("rays") or [])), str(c.get("value")))
    return (t, repr(sorted((k, str(v)) for k, v in (c or {}).items()
                           if k not in ("text", "id", "objects"))))


def c3_goal_keys(vm):
    """keys of what the figure's question asks (to_prove / to_construct /
    find): a statement with one of them is not offered (it answers)."""
    out = set()
    for r in vm.get("relations") or []:
        if not isinstance(r, dict) or r.get("role") not in (
                "to_prove", "to_construct"):
            continue
        out.add(c3_key(r))
        at, rays = r.get("at"), r.get("rays") or []
        if at and len(rays) == 2 and (r.get("type") == "angle" or (
                r.get("type") == "find" and r.get("quantity") == "angle")):
            v = str(at)
            out.add(c3_key({"type": "perpendicular", "at": v,
                            "of": [str(rays[0]) + v, v + str(rays[1])]}))
    return out


def c3_faults(vm):
    """[reason] -- highlight_given of one visual_model holds EXACTLY what
    each typed-shape given states: every statement of every given shape
    (role given, not carried with from_item) that is not the question's
    own goal is offered -- by a relation
    derived from it (from_given = the shape's id) or by an explicit given
    relation saying the same -- and every derived relation is a statement
    of a given shape, nothing else."""
    out = []
    rels = [r for r in vm.get("relations") or [] if isinstance(r, dict)]
    rid = dict((r.get("id"), r) for r in rels)
    hg = [x for x in vm.get("highlight_given") or [] if isinstance(x, str)]
    P = dict((str(o.get("name")), tuple(o["svg_xy"]))
             for o in vm.get("objects") or []
             if isinstance(o, dict) and o.get("type") == "point" and
             o.get("name") and isinstance(o.get("svg_xy"), list) and
             len(o["svg_xy"]) == 2 and not isinstance(o["svg_xy"][0], list))
    offered = {}
    for x in hg:
        r = rid.get(x) or {}
        if r.get("role") == "given":
            offered.setdefault(c3_key(r), []).append(r)
    want = {}
    goals = c3_goal_keys(vm)
    for r in rels:
        if r.get("type") != "shape" or r.get("role") != "given" or \
                r.get("from_item") or r.get("no_overlay"):
            continue
        try:
            st = shape_states(r.get("value"), r.get("points"), P,
                              r.get("text"))
        except ShapeStateError as e:
            out.append("given %s (%s): %s" % (r.get("id"), r.get("text"), e))
            continue
        st = [c for c in st if c3_key(c) not in goals]
        want[r.get("id")] = set(c3_key(c) for c in st)
        for c in st:
            if c3_key(c) not in offered:
                out.append("given %s (%s) states %s, which highlight_given "
                           "does not offer" % (r.get("id"), r.get("text"),
                                               c.get("text")))
    for x in hg:
        r = rid.get(x) or {}
        src = r.get("from_given")
        if src is None:
            continue
        if src not in want:
            s = rid.get(src) or {}
            out.append("%s is derived from %s, which is no given shape "
                       "(%s %s%s)" % (x, src, s.get("role"), s.get("value"),
                                      ", carried from_item"
                                      if s.get("from_item") else ""))
        elif c3_key(r) not in want[src]:
            out.append("%s (%s) is not what the given %s states"
                       % (x, r.get("text"), src))
    for r in rels:
        if r.get("from_given") and r.get("id") not in hg:
            out.append("%s is derived from %s but not offered in "
                       "highlight_given" % (r.get("id"), r.get("from_given")))
    return out
# ---- end of the C3 block ---------------------------------------------------


def add_shape_states(vm):
    """(v6.10, Codex C3) a typed-shape GIVEN ('ABCD מקבילית') states
    relations (both pairs of parallel sides ...): each one joins the
    model as a given relation derived from it (from_given = the shape's
    relation id) with its overlay mark, and highlight_given offers it --
    unless an explicit given relation already says the same. Nothing is
    added for a shape that is to be proved or carried with from_item.
    A statement the figure does not settle is refused (ShapeStateError).
    Returns the ids added."""
    objs = vm.get("objects") or []
    rels = vm.get("relations") or []
    P, pid = {}, {}
    for o in objs:
        if o.get("type") == "point" and o.get("name") and \
                isinstance(o.get("svg_xy"), list) and \
                len(o["svg_xy"]) == 2 and not isinstance(o["svg_xy"][0],
                                                         list):
            P[str(o["name"])] = tuple(o["svg_xy"])
            pid[str(o["name"])] = o
    segs, angs = {}, {}
    for o in objs:
        nm = _C3_TOK.findall(str(o.get("name") or ""))
        if o.get("type") == "segment" and len(nm) == 2:
            segs.setdefault(frozenset(nm), o)
        elif o.get("type") == "angle" and len(nm) == 3:
            angs.setdefault((nm[1], frozenset((nm[0], nm[2]))), o)
    hg = vm.setdefault("highlight_given", [])
    have = set(c3_key(r) for r in rels if r.get("id") in hg and
               r.get("role") == "given")
    count = {}
    for o in objs:
        if o.get("display") == "given_highlight" and o.get("n"):
            count[o.get("mark")] = max(count.get(o.get("mark"), 0),
                                       int(o["n"]))
    added = []
    goals = c3_goal_keys(vm)
    for r in list(rels):
        if r.get("type") != "shape" or r.get("role") != "given" or \
                r.get("from_item") or r.get("no_overlay"):
            continue
        st = shape_states(r.get("value"), r.get("points"), P, r.get("text"))
        for k, c in enumerate(st, 1):
            if c3_key(c) in have or c3_key(c) in goals:
                continue
            rid = "%s-s%d" % (r["id"], k)
            d = dict(c, id=rid, role="given", from_given=r["id"])
            if r.get("item"):
                d["item"] = r["item"]
            ob, on = [], []
            if c["type"] in ("parallel", "equal_length", "perpendicular"):
                mark = {"parallel": "parallel", "equal_length": "ticks",
                        "perpendicular": "right_angle"}[c["type"]]
                for s in c["of"]:
                    so = segs.get(frozenset(_C3_TOK.findall(s)))
                    if so is None:
                        continue
                    ob.append(so["id"])
                    on += [so["svg_id"]] if so.get("svg_id") else [
                        p.get("svg_id") for p in so.get("parts") or []
                        if p.get("svg_id")]
                names = [x for s in c["of"] for x in _C3_TOK.findall(s)]
                if c["type"] == "perpendicular":
                    ends = [x for x in names if x != c["at"]]
                    ao = angs.get((c["at"], frozenset(ends)))
                    if ao is not None:
                        ob.insert(0, ao["id"])
                    if c["at"] in pid and pid[c["at"]].get("svg_id"):
                        on.append(pid[c["at"]]["svg_id"])
            else:
                raise ShapeStateError("a %s statement has no overlay mark"
                                      % c["type"])
            for x in names:
                if x in pid and pid[x]["id"] not in ob:
                    ob.append(pid[x]["id"])
            d["objects"] = ob
            ov = {"id": "hl-" + rid[2:], "svg_id": None,
                  "type": "overlay_mark", "mark": mark,
                  "on": list(dict.fromkeys(on)), "for": rid,
                  "role": "given", "display": "given_highlight"}
            if mark in ("parallel", "ticks"):
                count[mark] = count.get(mark, 0) + 1
                ov["n"] = count[mark]
            d["highlight"] = ov["id"]
            rels.append(d)
            objs.append(ov)
            hg.append(rid)
            have.add(c3_key(c))
            added.append(rid)
    act = vm.get("actions")
    if added and isinstance(act, dict) and "highlight" in act:
        act["highlight"] = list(hg)
    return added


def build_visuals(L, figures, svg_of, claims, _meta, q_items, aux_spec,
                  rows_of, neutral, report):
    """§9: attach `visual_model` to every starting figure entry and return
    the component list of visuals with no SVG figure (question tables,
    declared visuals). Refuses, under the didactic policy, a model the
    independent validator fails; a declared visual is always checked."""
    import check_didactic as CD
    start = [e for e in figures if not e.get("aux")]
    auxs = [e for e in figures if e.get("aux")]

    def base_of(a):
        for want in (a.get("item"), None):
            for e in start:
                if e["question"] == a["question"] and \
                        e.get("item") == want:
                    return e
        for e in start:
            if e["question"] == a["question"]:
                return e
        return None
    aux_of = {}
    for a in auxs:
        b = base_of(a)
        if b is None:
            if neutral:
                _bad("aux figure %s has no starting figure to patch"
                     % a["id"],
                     "an aux figure (שרטוט עזר) is a patch on its "
                     "question's figure: give the question a figure, or "
                     "drop the aux")
            continue
        aux_of.setdefault(b["id"], []).append(a)
    faults = []
    for e in start:
        rids = rows_of(e)
        from wspec import figure_scopes618 as FS618
        rec = WB.spec_figs(L).get(e["id"]) or {}
        rows = [(r, _meta[r]["label"] is not None,
                 FS618.visual_claims(rec.get("level"), e, r, claims[r],
                                     WB.claim_of, DD.canon))
                for r in rids if r in claims]
        has_tc = any(cl.get("to_construct") for _r, _i, cl in rows)
        try:
            vm = VM.from_figure(e, svg_of.get(e["id"], ""), rows,
                                [(a, aux_spec.get(a["id"]) or {})
                                 for a in aux_of.get(e["id"], [])],
                                has_construct=has_tc,
                                family=WB.family_of_rec(
                                    WB.spec_figs(L).get(e["id"])))
        except VM.VMError as ex:
            _bad("figure %s: %s" % (e["id"], ex),
                 "an aux figure is a patch on the starting figure: the same "
                 "points in the same places, only its step added; it never "
                 "marks what is to be proved")
        if e["id"] in WB.spec_figs(L):
            # v6.9: the engine's objects (id -> parts) join the model
            vm = WB.vm_engine_layer(vm, WB.spec_figs(L)[e["id"]], e)
        try:
            # (v6.14 F2 / F3) a given parallel to an axis names its objects
            # (end points, segment, axis) and has its ∥ overlay (an engine
            # figure gets it here); a scale given names its axes
            WB.G614.given_marks(vm, WB.spec_figs(L).get(e["id"]), WB._split)
        except WB.G614.GivenError as ex:
            _bad(str(ex), "an axis_parallel given is marked on the segment "
                 "(or its end points) and the axis the figure draws")
        try:
            # (v6.10, C3) what a typed-shape given states, offered whole
            add_shape_states(vm)
        except ShapeStateError as ex:
            _bad("figure %s: %s" % (e["id"], ex),
                 "a typed-shape given is highlighted by what it states; "
                 "draw the figure so the statement is settled (one "
                 "parallel pair of a trapezoid, one apex ...) or report it")
        e["visual_model"] = vm
        aux_svgs = dict((a["id"], svg_of.get(a["id"], ""))
                        for a in aux_of.get(e["id"], []))
        for st, rule, txt in CD.vm_faults(vm, svg_of.get(e["id"], ""),
                                          aux_svgs):
            if st == "FAIL":
                faults.append("%s [%s] %s" % (e["id"], rule, txt))
    visuals = []
    for q in L.get("questions", []):
        n = q.get("n")
        rows = [("q%s" % n, None, q)]
        for it in q.get("items", []) or []:
            d = _as_item(it)
            rows.append((item_id(n, d["label"]), item_id(n, d["label"]), d))
        if isinstance(q.get("table"), dict):
            visuals.append(VM.from_table("q%s_table" % n, "q%s" % n,
                                         question_table(q["table"])))
        for rid, iid, d in rows:
            spec = d.get("visual")
            if spec is None:
                continue
            where = "item %s" % iid if iid else "question %s" % n
            try:
                vm = VM.declared("%s_visual" % rid, "q%s" % n, iid, spec)
            except VM.VMError as ex:
                _bad("%s: %s" % (where, ex),
                     "visual=dict(kind='<a registry kind>', objects=[...], "
                     "relations=[...], data={...}) -- see visual_model."
                     "KIND_FIELDS")
            if vm["visual_support"] == "unsupported" and d.get("fig"):
                _bad("%s declares a %s visual, which the skill cannot draw "
                     "exactly yet, AND carries a drawn figure"
                     % (where, vm["kind"]),
                     "no approximate or hand-drawn SVG for an unsupported "
                     "kind: drop fig=; the package ships the exact model "
                     "with visual_support 'unsupported' and Noam AI "
                     "explains in words")
            bad = [t for st, r, t in CD.vm_faults(vm, None, {})
                   if st == "FAIL"]
            if bad:
                _bad("%s: the %s model fails its checks: %s"
                     % (where, vm["kind"], "; ".join(bad[:4])),
                     "the model is exact data -- fix the numbers (branch "
                     "sums, totals, region counts ...) so they agree")
            visuals.append(vm)
    report["visual_faults"] = faults
    report["unsupported_visuals"] = [v["id"] for v in visuals
                                     if v["visual_support"] ==
                                     "unsupported"]
    if faults and neutral:
        _bad("%d visual_model fault(s): %s" % (len(faults),
                                               "; ".join(faults[:6])),
             "the visual model is built from the engine's own record; a "
             "fault means the figure, its SVG and its model disagree -- "
             "rebuild the figure with the engine (never hand-edit the SVG)")
    return visuals


def _faults_text(faults, n=12):
    return "; ".join("[%s] %s -> FIX: %s" % (f["rule"], f["said"], f["fix"])
                     for f in faults[:n]) + (
        " (+%d more)" % (len(faults) - n) if len(faults) > n else "")


def _row_find(row, src):
    """v6.7.2-noam: the private side of a row's find targets (sheet.json
    keeps each with its value, beside the answer), and the row's declared
    no_target_reason / variables."""
    fs = [dict((k, c[k]) for k in DD.FIND_KEYS if c.get(k) is not None)
          for c in src.get("to_prove") or [] if DD.is_find(c)]
    if fs:
        row["find"] = fs
    ntr = src.get("no_target_reason")
    if ntr is not None:
        if not str(ntr).strip():
            _bad("%s: no_target_reason is empty" % row.get("id"),
                 "say in words why this compute item has no find target, "
                 "or declare the target")
        row["no_target_reason"] = str(ntr)
    if src.get("variables"):
        v = src["variables"]
        row["variables"] = [str(x) for x in (v if isinstance(v, (list, tuple))
                                             else [v])]


_SYM = re.compile(u"(?<![A-Za-z\\\\])([a-z])(?![A-Za-z])")


def _source_state_find_givens(L, figures, m, rid, c, scoped):
    """Only an independently proved previous-state head height is separate.

    Select inputs to the same-quantity overlap check, without changing any
    source/export claim or the separate checks for printed answer values.
    Local/later givens, legacy builders and unproved state claims stay intact.
    """
    original = [g for _scope, g in scoped]
    qid = "q%s" % m["n"]
    marker = (m.get("q") or {}).get("_wspec")
    if not isinstance(marker, dict) or marker.get("qid") != qid:
        return original
    try:
        import check_didactic as CD
        from wspec import canon as WC
        from wspec.check.figure_state import obsolete_height
        level = marker["level"]
        public = level.pub
        own = [q for q in public.get("questions", []) if q.get("id") == qid]
        if len(own) != 1:
            return original
        own = own[0]
        items = [i for i in own.get("items", []) if i.get("id") == rid]
        if len(items) != 1 or c.get("type") != "find" or c.get("quantity") != "length":
            return original
        item = items[0]
        if (m["q"].get("intro", m["q"].get("text")) != own.get("text")
                or m["src"].get("text") != item.get("text") or WC.canon_unit(c.get("unit")) != "m"):
            return original
        entries = [e for e in figures if not e.get("aux") and e.get("question") == qid
                   and e.get("item") == rid and e.get("id") == item.get("figure")]
        if len(entries) != 1:
            return original
        fid = entries[0]["id"]
        rec = WB.spec_figs(L).get(fid) or {}
        if rec.get("level") is not level or rec.get("fid") != fid:
            return original
        figs = [g for g in public.get("figures", []) if g.get("id") == fid and g.get("scope") == rid]
        if len(figs) != 1 or not obsolete_height(public, figs[0]):
            return original
        target = level.ix.facts[figs[0]["state_change"]["height_target"]]
        expected = WB.claim_of(level, target)
        if (DD.find_key(c) != DD.find_key(expected) or not WC.same_quantity(
                c.get("value"), c.get("unit"), expected.get("value"), expected.get("unit"))):
            return original
        old = level.ix.facts[figs[0]["state_change"]["old_height"]]
        declared = _spec_claim(WB.claim_of(level, old))
        return [g for scope, g in scoped
                if g != declared or not CD._source_old_height_given(public, qid, rid, scope, c, g)]
    except Exception:
        return original  # malformed/unavailable proof never suppresses a finding


def find_checks(L, figures, visuals, claims, _meta, rows_of, neutral,
                report):
    """v6.7.2-noam (BRIEF_V672 items 2-3): every object a find target names
    exists in the question's model (a point of its figures, a point a given
    or a to_construct names, a model object id / table cell, or a declared
    variable) -- else refused; and no starting figure prints or marks the
    value it asks for (refused under the neutral policy)."""
    start = [e for e in figures if not e.get("aux")]
    faults = []
    for rid, m in _meta.items():
        src = m["src"]
        finds = [c for c in src.get("to_prove") or [] if DD.is_find(c)]
        if not finds:
            continue
        qid = "q%s" % m["n"]
        rows = [r for r, mm in _meta.items() if "q%s" % mm["n"] == qid]
        pts, ids, var = set(), set(), set()
        for e in start:
            if e["question"] != qid:
                continue
            for o in (e.get("objects") or {}).get("points") or []:
                if o.get("name"):
                    pts.add(str(o["name"]))
            for o in (e.get("visual_model") or {}).get("objects") or []:
                ids.add(str(o.get("id")))
        for v in visuals or []:
            if v.get("question") == qid:
                ids.add(str(v.get("id")))
                for o in v.get("objects") or []:
                    ids.add(str(o.get("id")))
        for r in rows:
            for kk in ("given", "to_construct"):
                for c in (claims.get(r) or {}).get(kk) or []:
                    if isinstance(c, dict):
                        pts.update(DD.names_in(c))
            rs = _meta[r]["src"]
            vv = rs.get("variables") or []
            var.update(str(x) for x in (vv if isinstance(vv, (list, tuple))
                                        else [vv]))
            for k in ("text", "intro"):
                var.update(_SYM.findall(str(rs.get(k) or "")))
        scoped_given = [(r, c) for r in (qid, rid) for c in
                 (claims.get(r) or {}).get("given") or []
                 if isinstance(c, dict) and not c.get("from_item")]
        given = [c for _r, c in scoped_given]
        ctx = u" ".join(str(x) for x in (m["q"].get("text"),
                                         m["q"].get("intro"),
                                         src.get("text")) if x)
        for c in finds:
            # r2 M2: the private value is required -- every value check
            # (free labels, the SVG, noam-ai.json) reads it; a target
            # without one could print its answer unseen
            if c.get("value") is None or not str(c.get("value")).strip():
                _bad("%s: the find target %s has no value"
                     % (m["where"], DD.find_text(c)),
                     "give the find target its value -- the answer, e.g. "
                     "{'type': 'find', 'quantity': 'length', 'of': 'AB', "
                     "'value': 10}; it stays private (sheet.json only)")
            # r1 T4: text / what / unit never state the value
            lk = DD.find_leaks(c, c.get("value"), ctx)
            if lk:
                _bad("%s: the find target %s leaks its value into "
                     "noam-ai.json: %s" % (m["where"], DD.find_text(c),
                                            "; ".join(lk)),
                     "unit is a word ('ס\"מ', 'מעלות'); the value goes in "
                     "'value' (private, sheet.json) only")
            # v6.7.3 (M1): the answer never rides on a given -- a given of
            # the same quantity (section 2 overlap), or a JSON-only given
            # carrying its value
            overlap_given = _source_state_find_givens(L, start, m, rid, c, scoped_given)
            gf = DD.find_given_faults(c, overlap_given, c.get("value"),
                                      ctx + u" " + DD.stated_text(m["q"]))
            if gf:
                _bad("%s: the find target %s leaks through a given: %s"
                     % (m["where"], DD.find_text(c), "; ".join(gf)),
                     "a quantity the item asks to find is never a given of "
                     "its question; a given's number is one the question's "
                     "text states (then the model may carry it on that "
                     "given's own object)")
            # r1 T2: a table-cell target is blank in the table, and its
            # cell is no given: the blank frame the student fills
            # (role context -- V3 keeps to_prove objects out of the
            # starting figure, and the empty cell IS in it)
            qv = [v for v in visuals or [] if v.get("question") == qid]
            cf = DD.find_cell_faults(qv, c, c.get("value"))
            if cf:
                _bad("%s: the find target %s is printed in the table: %s"
                     % (m["where"], DD.find_text(c), "; ".join(cf)),
                     "leave the target cell empty or '?' in the table -- "
                     "the answer is never in the starting table")
            if DD.FIND_QUANTITIES.get(str(c.get("quantity")),
                                      ("any",))[0] == "cell":
                want = [str(x) for x in (c["of"] if isinstance(
                    c.get("of"), list) else [c.get("of")])]
                for v in qv:
                    for o in v.get("objects") or []:
                        if o.get("type") == "cell" and any(
                                str(o.get("id")) == w or
                                str(o.get("id")).endswith("-" + w)
                                for w in want):
                            o["role"] = "context"
            miss = DD.find_unknown(c, pts, var, ids)
            if miss:
                _bad("%s: the find target %s names %s, which the question's "
                     "model does not hold" % (m["where"], DD.find_text(c),
                                              ", ".join(miss)),
                     "a find target names objects of the figure (points "
                     "drawn, or named by a given / to_construct), a cell "
                     "of a declared table model, or a variable the "
                     "question declares (variables=['x'] or $x$ in its "
                     "text)")
            for e in start:
                if e["question"] != qid or rid not in rows_of(e):
                    continue
                for t in DD.find_value_faults(e, c, given, c.get("value")):
                    faults.append({"rule": "F3", "said": "%s: %s"
                                   % (m["where"], t),
                                   "fix": "drop the value label / mark of "
                                   "the object the item asks to find -- "
                                   "the answer is never in the starting "
                                   "figure"})
    report["find_value_faults"] = faults
    if faults and neutral:
        _bad("%d starting figure(s) print or mark the value a find target "
             "asks for: %s" % (len(faults), _faults_text(faults)),
             "the starting figure is neutral (BRIEF_V672 item 3)")


def _spec_claim(c):
    """v6.9: one spec claim as the public claims list holds it (the value of
    a find target never: find_public)."""
    if DD.is_find(c):
        return DD.find_public(c)
    # v6.13 fix_r1 (C1): 'readoff' (a spec family target) rides along for
    # readoff_questions; _noam_claims never exports it
    return dict((k, v) for k, v in c.items()
                if k in _NOAM_CLAIM_KEYS or k in ("from_item", "readoff"))


def _spec_word(c):
    return DD.find_text(c) if DD.is_find(c) else (c.get("text") or
                                                  DD._say(c))


def _spec_rows(q, qd, n, qid, mine, aux_spec, claims, _meta, ans,
               questions):
    """v6.9: the sheet.json rows of a spec question (expanded by
    wspec_build): given / to_prove / to_construct are the spec's facts as
    claim dicts; the answer is the key the private part wrote."""
    # (v6.13 fix_r2, NOITEM) a question whose one item is a STEM ITEM
    # carries that item's to_prove / to_construct itself (it has no item
    # row); any other spec question has none of its own
    claims[qid] = dict((k, [_spec_claim(c) for c in q.get(k) or []])
                       for k in ("given", "to_prove", "to_construct"))
    for k in ("given", "to_prove", "to_construct"):
        qd[k] = [_spec_word(c) for c in q.get(k) or []]
    _row_find(qd, q)
    if q.get("spec_unsupported"):
        # v6.9 (Codex F4): the author marked the WHOLE question: the public
        # spec lacks an essential datum / target (listed); Noam AI is told
        su = q["spec_unsupported"]
        qd["spec_unsupported"] = {"reason": str(su["reason"]),
                                  "missing": [str(x) for x in
                                              su.get("missing") or []]}
    _meta[qid] = {"src": q, "n": n, "label": None, "q": q,
                  "where": "question %s" % n}
    if q.get("dashed"):
        qd["dashed"] = [str(x) for x in q["dashed"]]
    items = []
    for it in q.get("items", []):
        d = _as_item(it)
        iid = item_id(n, d["label"])
        row = {"id": iid, "label": d["label"], "text": d["text"]}
        fids = [fid for fid, _r, _s in mine if (
            fid == iid or fid.startswith(iid + "_")) and
            fid not in aux_spec]
        row["figure"] = fids[0] if fids else qd.get("figure")
        claims[iid] = dict((k, [_spec_claim(c) for c in d.get(k) or []])
                           for k in ("given", "to_prove", "to_construct"))
        for k in ("given", "to_prove", "to_construct"):
            row[k] = [_spec_word(c) for c in d.get(k) or []]
        _row_find(row, d)
        _meta[iid] = {"src": d, "n": n, "label": d["label"], "q": q,
                      "where": "item %s of question %s" % (d["label"], n)}
        a = ans.get(str(n), {}).get(d["label"])
        if a is not None:
            row["answer"] = a
        items.append(row)
    if items:
        qd["items"] = items
    questions.append(qd)



# (v6.16 fix r1, verify P2-S2) THE AXIS OF SYMMETRY IS DASHED. BRIEF_V616 G2
# lists "a dashed axis of symmetry" among the parabola marks, and the frozen
# graph corpus calls dashed "the house style" of a given axis (G9-T06 q12,
# GP368). The neutral-figure rule N3 (BRIEF_V671 s3) refuses a dashed stroke
# the text does not call dashed ("a line that is DATA is drawn solid"), so a
# given axis x = 1 printed SOLID at axis weight, and read as a second y axis.
# A dashed stroke is accepted for exactly this: a VERTICAL line (fn vline) of
# a spec graph figure, declared "style": "dashed", when the question's own
# text names an axis of symmetry ('ציר הסימטריה' / 'ציר סימטריה'). Any other
# dashed data line is still refused (N3), e.g. y = 16 of G9-T06 q21.
_SYM_AXIS_WORDS = re.compile(u"ציר\\s+(?:ה)?סימטריה")


# (v6.16 fix r1 continuation, the frozen graph corpus GP185-190 / GP251-257 /
# GP317-320 + CONVENTIONS_v616 L15: G9-T06 q21's line y = 16 / 9 / 25 is drawn
# DASHED in the source, and the corpus scores CURVE_STYLE_AS_DECLARED dashed;
# the author's W-MATCH-ORIGINAL-MARKS: a correct mark of the original that
# reveals no answer may be drawn.) A second, equally narrow acceptance: a
# dashed LEVEL line -- a horizontal line (fn line, m = 0) or a vertical one
# (vline) -- whose printed label equation ('y = 16', 'x = 1') the question's
# own text prints: a GIVEN auxiliary line the text states, never data the
# student reads off and never a find (an asked line is undrawn). Any other
# dashed line is still refused (N3).
_EQ_SPACE = re.compile(u"\\s+")


def _eq_norm(t):
    """'y = −16' / '$y=-16$' -> 'y=-16' (spaces, math dollars, the minus)"""
    t = str(t or u"").replace(u"\u2212", u"-").replace(u"$", u"")
    return _EQ_SPACE.sub(u"", t)


def _symmetry_axis_dashes(e, rec, text):
    """svg ids of the dashed strokes N3 accepts (above): the figure's PUBLIC
    graph model says which curve is a dashed vline (the axis of symmetry the
    text names), or a dashed level line whose label equation the text
    prints"""
    if not rec:
        return []
    pub = getattr(rec.get("level"), "pub", None) or {}
    sym = bool(_SYM_AXIS_WORDS.search(text or u""))
    body = _eq_norm(text)
    want = set()
    for f in pub.get("figures") or []:
        if f.get("id") == e.get("id"):
            for c in (f.get("graph") or {}).get("curves") or []:
                if c.get("style") != "dashed":
                    continue
                if c.get("fn") == "vline" and sym:
                    want.add(c.get("id"))
                    continue
                d = c.get("def") or {}
                level = c.get("fn") == "vline" or (
                    c.get("fn") == "line" and str(d.get("m")) in ("0",
                                                                  "0.0"))
                lab = _eq_norm((c.get("label") or {}).get("text"))
                if level and lab and re.search(
                        re.escape(lab) + u"(?![0-9.,/])", body):
                    want.add(c.get("id"))
    out = []
    for o in ((e.get("objects") or {}).get("paths") or []):
        if o.get("kind") == "curve" and o.get("name") in want:
            out.append(o.get("svg_id"))
    return out


def _parameter_locus_dashes(entry, rec, svg, text):
    if not rec:
        return []
    from wspec.check.base_height import native_extension_dashes
    public = getattr(rec.get("level"), "pub", None) or {}
    return list(DD.native_locus_dashes(svg, public, entry.get("id"),
        rec.get("object_map") or {}, text) | native_extension_dashes(
        svg, public, entry.get("id"), rec.get("object_map") or {}, text))


def deliver(L, out_dir, pdf=None, source=(), package=None, grade=None,
            built_at=None, strict_numbers=False, strict_figures=False,
            skill_version=SKILL_VERSION, verify_code_=True,
            strict_declared=None, html=None, neutral=None,
            curriculum=None, g79=None, text_binding=None):
    """Write one level's deliverable package. Returns the report dict.

    v6.11 (G80-text, Codex NEW-1): `text_binding` is the build's record of
    where each bound block (data-bind) of sheet.html printed in the PDF and
    under which renderer / fonts (textbind.record); it is written to
    build.json so the verifier can cross-check its own layout.

    v6.8: under `strict_figures` (build.py's default, STRICT_FIGURES in
    content.py) the package is a Noam AI package: PACKAGE is the site topic
    id G<grade>-T<nn>, the level key is a/b/c, every proof request declares
    `to_prove`, and noam-ai.json is written beside sheet.json."""
    # v6.9: spec questions are expanded (the same object when none is)
    L = WB.expand_level(L)
    wfigs = WB.spec_figs(L)
    key = L.get("key", "x")
    root = os.path.join(str(out_dir), str(key))
    figs_dir = os.path.join(root, "figures")
    src_dir = os.path.join(root, "source")
    for d in (root, figs_dir, src_dir):
        if not os.path.isdir(d):
            os.makedirs(d)

    # v6.7.1-noam §3: the starting figure is neutral under STRICT
    neutral = bool(strict_figures) if neutral is None else bool(neutral)
    aux = _aux_entries(L)
    aux_spec = dict((fid, spec) for fid, _s, _q, _i, spec in aux)
    entries = _fig_entries(L) + [(fid, svg, q, i)
                                 for fid, svg, q, i, _sp in aux]
    recs = [(fid, export.lookup(svg) if fid not in wfigs else None)
            for fid, svg, _q, _i in entries]
    # a figure outlives one packaging run; start from what the build said
    for _fid, _rec in recs:
        if _rec is not None:
            export.reset_declarations(_rec.objects)
    # v6.9: an engine (wspec) figure is recorded by the engine itself -- its
    # object map; the walk that names figures must meet the spec's names
    _wseen = [fid for fid, _s, _q, _i in entries if fid in wfigs]
    for fid, svg, _q, _i in entries:
        if WB.is_spec_svg(svg) and (fid not in wfigs or
                                    wfigs[fid]["svg"] != svg):
            _bad("engine figure at %s is not the spec's figure %s"
                 % (fid, fid),
                 "a spec question names its figures q<n>_head and the item "
                 "id; an engine SVG is never pasted into a builder question")
    if sorted(_wseen) != sorted(wfigs):
        _bad("the sheet shows engine figures %s, the spec built %s"
             % (sorted(_wseen), sorted(wfigs)),
             "every figure a spec question renders is printed once")
    unrecorded = [fid for fid, r in recs if r is None and fid not in wfigs]
    _aux_bare = [fid for fid in unrecorded if fid in aux_spec]
    if _aux_bare:
        _bad("aux figure(s) %s were not built by a recorded builder"
             % ", ".join(_aux_bare[:4]),
             "an aux figure (שרטוט עזר) comes from the same engine as the "
             "sheet's figures, with objects and ids -- build it with "
             "figkit / shapekit / euclid like the starting figure")
    if unrecorded and strict_figures:
        _bad("%d figure(s) of level %s were not built by a recorded builder "
             "(%s)" % (len(unrecorded), key, ", ".join(unrecorded[:4])),
             "every figure must come from a builder that records its own "
             "build (figkit.Figure.render, numberline.NL.render and "
             "everything on top of them). A hand-written SVG string has no "
             "objects and no constraints to export")
    package = package or L.get("package")
    if strict_figures:
        if strict_declared is False:
            _bad("content.py does not write STRICT_FIGURES",
                 "a Noam AI package states it explicitly: STRICT_FIGURES = "
                 "True in content.py (False only for maintenance of an old "
                 "sheet, which is then not a Noam AI package)")
        if not (isinstance(package, str) and PACKAGE_RE.match(package)):
            _bad("PACKAGE is %r, not a site topic id" % (package,),
                 "write PACKAGE = \"G<grade>-T<nn>\" in content.py, the "
                 "topic id of the site (regen/topic_ids.json: z08 -> G7-T08, "
                 "ט׳/18 -> G9-T18)")
        if str(key) not in LEVEL_KEYS:
            _bad("level key %r is not one of a, b, c" % (key,),
                 "a Noam AI package names its levels a, b, c "
                 "(L['key'] = 'a')")
        missing = undeclared_proofs(L)
        if missing:
            _bad("%d question(s)/item(s) ask for a proof and declare no "
                 "to_prove: %s" % (len(missing), "; ".join(
                     "%s (%s)" % (w, t[:60]) for w, t in missing[:6])),
                 "the author's declaration is the source of truth: give "
                 "each one an explicit to_prove -- the claim, e.g. "
                 "to_prove=[{'type': 'equal_length', 'of': ['AM', 'MQ']}], "
                 "or to_prove=[] when the item explains without a "
                 "geometric claim ('הסבירו כיצד פתרתם')")

    # ---- the content schema: label what the author declared ---------------
    by_q = {}
    for (fid, svg, qid, iid), (_f, rec) in zip(entries, recs):
        by_q.setdefault(qid, []).append((fid, rec, svg))
    taken, unchecked = {}, []
    _meta = {}              # row id -> the content row (v6.7.1-noam)
    proof_given = []
    claims = {}             # row id -> structured given / to_prove (noam)

    questions = []
    ans = _answers(L)
    for q in L.get("questions", []):
        n = q.get("n")
        qid = "q%s" % n
        mine = by_q.get(qid, [])
        qd = {"id": qid, "n": n}
        for k in ("text", "intro", "star"):
            if q.get(k) is not None:
                qd[k if k != "intro" else "text"] = q.get(k)
        # v6.7-noam (BC2-TABLE): a table or a worked example the student
        # reads is QUESTION DATA -- written to sheet.json and noam-ai.json
        _tb = question_table(q.get("table"))
        if _tb is not None:
            qd["table"] = _tb
        _ex = question_example(q.get("example"))
        if _ex is not None:
            qd["example"] = _ex
        head = [fid for fid, _r, _s in mine
                if fid.startswith("%s_head" % qid)]
        # v6.8 G4: every question and item names its figure (null: none)
        qd["figure"] = head[0] if head else None
        if q.get("_wspec") is not None:
            # v6.9: a spec question -- its given / to_prove / to_construct
            # are the spec's facts (validated, public / private split by the
            # engine's projection); nothing is parsed from wording
            _spec_rows(q, qd, n, qid, mine, aux_spec, claims, _meta, ans,
                       questions)
            continue
        _cg, _ct = [], []
        g = _apply(q.get("given"), "given", None, mine, "question %s" % n,
                   taken, unchecked, strict=strict_figures, claims=_cg)
        t = _apply(q.get("to_prove"), "to_prove", None, mine,
                   "question %s" % n, taken, unchecked,
                   strict=strict_figures, claims=_ct)
        claims[qid] = {"given": _cg, "to_prove": _ct,
                       "to_construct": to_construct_claims(
                           q.get("to_construct"), "question %s" % n)}
        # v6.8 G5: both keys, always
        qd["given"] = g or []
        qd["to_prove"] = t or []
        qd["to_construct"] = [c.get("text") or DD._say(c)
                              for c in claims[qid]["to_construct"]]
        _row_find(qd, q)
        _meta[qid] = {"src": q, "n": n, "label": None, "q": q,
                      "where": "question %s" % n}
        if q.get("dashed"):
            qd["dashed"] = [str(x) for x in q["dashed"]]
        proof_given.extend(given_on_proof(
            u" ".join(str(q.get(k) or "") for k in ("text", "intro")),
            q.get("given"), q.get("to_prove"), "question %s" % n, None,
            mine))
        # v6.8 final (R3-D4-question-level-silence): the question's own
        # text is read too when it has items -- a marked claim stated in the
        # intro is refused whatever the question declares
        if True:
            proof_given.extend(proof_undeclared(
                u" ".join(str(q.get(k) or "") for k in ("text", "intro")),
                q.get("to_prove"), mine, "question %s" % n, None))
        items = []
        for it in q.get("items", []):
            d = _as_item(it)
            iid = item_id(n, d["label"])
            row = {"id": iid, "label": d["label"], "text": d["text"]}
            # v6.7.1-noam: an aux figure (q1b_aux1) is never the item's
            # figure -- it is a patch shown on request
            fids = [fid for fid, _r, _s in mine if (
                fid == iid or fid.startswith(iid + "_")) and
                fid not in aux_spec]
            # v6.8 G4: the item's own figure, else the question's
            row["figure"] = fids[0] if fids else qd.get("figure")
            _cg, _ct = [], []
            gg = _apply(d.get("given"), "given", iid, mine,
                        "item %s of question %s" % (d["label"], n),
                        taken, unchecked, strict=strict_figures, claims=_cg)
            tt = _apply(d.get("to_prove"), "to_prove", iid, mine,
                        "item %s of question %s" % (d["label"], n),
                        taken, unchecked, strict=strict_figures, claims=_ct)
            claims[iid] = {"given": _cg, "to_prove": _ct,
                           "to_construct": to_construct_claims(
                               d.get("to_construct"),
                               "item %s of question %s" % (d["label"], n))}
            row["given"] = gg or []
            row["to_prove"] = tt or []
            row["to_construct"] = [c.get("text") or DD._say(c)
                                   for c in claims[iid]["to_construct"]]
            _row_find(row, d)
            _meta[iid] = {"src": d, "n": n, "label": d["label"], "q": q,
                          "where": "item %s of question %s"
                          % (d["label"], n)}
            if d.get("dashed"):
                row["dashed"] = [str(x) for x in d["dashed"]]
            proof_given.extend(given_on_proof(
                d["text"], d.get("given"), d.get("to_prove"),
                "item %s of question %s" % (d["label"], n), iid, mine))
            proof_given.extend(proof_undeclared(
                d["text"], d["to_prove"] if "to_prove" in d
                else q.get("to_prove"), mine,
                "item %s of question %s" % (d["label"], n), iid,
                context=u" ".join(str(q.get(k) or "")
                                  for k in ("text", "intro"))))
            a = d.get("answer") or ans.get(str(n), {}).get(d["label"])
            if a is not None:
                row["answer"] = a
            items.append(row)
        if items:
            qd["items"] = items
        elif ans.get(str(n), {}).get("*") is not None:
            qd["answer"] = ans[str(n)]["*"]
        questions.append(qd)

    # ---- the checks, before a single file is written ----------------------
    report = {"figures": len(entries), "unrecorded": unrecorded,
              "constraints": 0, "remeasured": 0, "unchecked": unchecked,
              "given_on_proof_item": proof_given}
    figures = []
    for (fid, svg, qid, iid), (_f, rec) in zip(entries, recs):
        entry = {"id": fid, "svg": "figures/%s.svg" % fid,
                 "code": "figures/%s.py" % fid, "question": qid}
        if iid:
            entry["item"] = iid
        if fid in wfigs:
            # v6.9: the engine's figure -- objects on the engine's element
            # ids, constraints from the spec's facts, the map beside it
            _rid = [qid] + ([iid] if iid else [])
            entry.update(WB.figure_entry(wfigs[fid]))
            entry["map"] = "figures/%s.map.json" % fid
            entry["engine"] = WB.WR.ENGINE_VERSION
            for _c in entry["constraints"]:
                if _c.get("source") == "to_prove" and _c.get("marked"):
                    _bad("figure %s marks %s, which is to be proved"
                         % (fid, _typed_phrase(_c)),
                         "the engine draws only given facts; report this "
                         "spec")
            for _b in (entry.get("objects") or {}).values():
                for _o in _b:
                    if _o.get("svg_id"):
                        _o["sheet_svg_id"] = fid + SHEET_SEP + _o["svg_id"]
            entry["sheet_id_prefix"] = fid + SHEET_SEP
            report["constraints"] += len(entry["constraints"])
            report["remeasured"] += len(entry["constraints"])
            figures.append(entry)
            del _rid
            continue
        if rec is None:
            entry["kind"] = "unrecorded"
            entry["fam"] = svg_fam(svg)
            entry["objects"] = {}
            entry["constraints"] = []
            figures.append(entry)
            continue
        ob = rec.objects
        # (2) the drawing never marks what is to be proved
        told = export.marked_to_prove(ob, svg)
        if told:
            c = told[0]
            by = [m.mark_id or "%s%s" % (m.type, _ops(m))
                  for m in (c.implied_by or [])]
            _bad("figure %s MARKS %s%s, which %s declares as to_prove"
                 % (fid, _typed_phrase(c),
                    (" (the marks %s state it)" % ", ".join(
                        sorted(set(map(str, by))))) if by else
                    (" (mark %s)" % c.mark_id if c.mark_id else ""),
                    c.item or qid),
                 "the sheet would be giving the proof away in the drawing "
                 "(DELIVERABLE_SPEC rule 2). " + _route_text(rec, c) +
                 "Otherwise draw the figure WITHOUT the "
                 "mark and keep the claim: shapekit.midpoint(..., "
                 "ticks=False) / median(..., ticks=False), no right_angle() "
                 "or side_label() on what is to be proved, bisector(..., "
                 "arcs=False) instead of equal arcs, plane() without "
                 "that tickmarks=/right= entry. Writing the claim as a plain "
                 "string does not hide it -- strings are read too. Only if "
                 "the question itself STATES the fact is it `given`")
        # (3) first, because it is the plainer fault: an id in the JSON that
        # the file does not carry points the author's AI at nothing, and it
        # would otherwise be reported as a constraint that cannot be measured
        missing = [it.id for it in ob.items if it.id not in export.read_ids(svg)]
        # spec rule 4: an id names ONE element. Two elements with one id
        # (a composed figure that did not prefix its parts) make every
        # highlight of it ambiguous
        _all = re.findall(r'\sid="([^"]+)"', svg)
        dup = sorted(set(x for x in _all if _all.count(x) > 1))
        if dup:
            _bad("figure %s carries %d id(s) on more than one element (%s)"
                 % (fid, len(dup), ", ".join(dup[:4])),
                 "an id in sheet.json must name one element of the SVG. A "
                 "figure composed of parts gives each part its own prefix "
                 "(numberline.stack writes r1-, r2-) -- never drop the ids")
        if missing:
            _bad("figure %s exports %d object(s) the SVG does not carry (%s)"
                 % (fid, len(missing), ", ".join(missing[:4])),
                 "every object in sheet.json is highlighted BY ITS ID in the "
                 "SVG the sheet ships; an id in the JSON and not in the file "
                 "points the author's AI at nothing")
        # (1) every constraint re-measured on the finished file. A
        # find-the-error figure declares itself in the SVG and keeps its
        # deliberate lie, flagged `violated`.
        export.recheck(svg, ob, "deliver(%s)" % fid,
                       lenient=bool(getattr(ob, "critique", None)))
        d = ob.as_dict()
        for _b in (d.get("objects") or {}).values():
            for _o in _b:
                if _o.get("svg_id"):
                    _o["sheet_svg_id"] = fid + SHEET_SEP + _o["svg_id"]
        entry["sheet_id_prefix"] = fid + SHEET_SEP
        _kind = rec.kind or d.get("kind") or "figure"
        # fam: what the builder or the SVG declares; failing both, a family
        # builder's own kind (plane, numberline, ...) -- only a raw figure,
        # which belongs to no family, keeps null
        _fam = d.get("fam") or svg_fam(svg)
        if not _fam and _kind not in ("figure", "figkit.figure"):
            _fam = _kind
        entry.update(kind=_kind,
                     fam=_fam, view=d.get("view"),
                     objects=d.get("objects", {}),
                     constraints=d.get("constraints", []))
        report["constraints"] += len(entry["constraints"])
        report["remeasured"] += len(entry["constraints"])
        figures.append(entry)

    # ---- v6.7.1-noam: the didactic policy (BRIEF_V671 §1-§8) -------------
    svg_of = dict((fid, svg) for fid, svg, _q, _i in entries)
    q_items = {}
    for rid, m in _meta.items():
        if m["label"] is not None:
            q_items.setdefault("q%s" % m["n"], []).append(rid)

    def rows_of(F):
        """the question row and the item rows a figure serves"""
        from wspec import figure_scopes618 as FS618
        return FS618.served_rows(F, figures, q_items)

    # §2 one relation in two of given / to_prove / to_construct is refused,
    # unless the later given says it comes from an earlier item
    overlap = []
    for qid in [k for k in _meta if _meta[k]["label"] is None]:
        rids = [qid] + q_items.get(qid, [])
        gk = {}
        for r in rids:
            for c in claims[r]["given"]:
                if isinstance(c, dict) and not c.get("from_item"):
                    k = DD.canon(c)
                    if k is not None:
                        gk.setdefault(k, (r, c))
        for r in rids:
            for kk in ("to_prove", "to_construct"):
                for c in claims[r][kk]:
                    k = DD.canon(c) if isinstance(c, dict) else None
                    if k is not None and k in gk:
                        overlap.append(
                            "%s is given in %s and %s in %s"
                            % (c.get("text") or DD._say(c), gk[k][0], kk, r))
        # a given that restates the item's own claim ("הוכיחו כי AM = MB"
        # with AM = MB among its givens; r2 M2: "בדקו שהמשולש MDC שווה
        # שוקיים" / "האם MD = MC?" with MD = MC among them)
        for r in rids:
            m = _meta[r]
            if m["label"] is None or not asks_argument(m["src"].get("text")):
                continue
            if m["q"].get("_wspec") is not None:
                # v6.9: a spec item's claim and givens are FACTS, compared
                # exactly above (canon, the shape's value included) and by
                # the spec's own validation (a fact is never given and
                # target); the word reading below ignores a shape's value
                # ('ABCD מקבילית' read as the claim 'ABCD מלבן')
                continue
            said = set(DD.canon(c) for c in _claims_in(m["src"]["text"])) \
                if asks_proof(m["src"].get("text")) else set()
            asked = asked_clauses(m["src"].get("text"))
            for c in claims[r]["given"] + claims[qid]["given"]:
                if isinstance(c, dict) and not c.get("from_item") and (
                        DD.canon(c) in said or
                        any(DD.restates(a, c) for a in asked)):
                    overlap.append("%s is the claim %s asks to prove, and "
                                   "a given" % (c.get("text") or
                                                DD._say(c), r))
            # r2 M2: with to_prove=[] the item's own givens may BE its claim
            # in words no reader parses -- never offered as givens to mark
            if not claims[r]["to_prove"]:
                for c in claims[r]["given"]:
                    if isinstance(c, dict):
                        c["no_overlay"] = True
    # r2 S4: from_item names an EARLIER item that declares this claim in its
    # to_prove / to_construct -- anything else is a certain error
    fi_faults = []
    order = list(_meta)
    for r in order:
        for c in claims[r]["given"]:
            fi = c.get("from_item") if isinstance(c, dict) else None
            if not fi:
                continue
            fi = str(fi)
            if fi not in _meta:
                fi_faults.append("%s takes %s from_item=%r, and the sheet has "
                               "no item %r" % (r, c.get("text") or
                                               DD._say(c), fi, fi))
            elif order.index(fi) >= order.index(r):
                fi_faults.append("%s takes %s from_item=%r, which is not an "
                               "earlier item" % (r, c.get("text") or
                                                 DD._say(c), fi))
            elif DD.canon(c) not in set(
                    DD.canon(x) for kk in ("to_prove", "to_construct")
                    for x in claims[fi][kk] if isinstance(x, dict)):
                fi_faults.append("%s takes %s from_item=%r, and %s does not "
                               "prove it (no such to_prove)"
                               % (r, c.get("text") or DD._say(c), fi, fi))
    report["from_item"] = fi_faults
    if fi_faults and neutral:
        _bad("%d given(s) carried with a from_item that does not hold: %s"
             % (len(fi_faults), "; ".join(fi_faults[:6])),
             "from_item='<id>' names an EARLIER item of the sheet whose "
             "to_prove (or to_construct) declares this same relation")
    report["overlap"] = overlap
    if overlap and neutral:
        _bad("%d relation(s) are both a given and a conclusion: %s"
             % (len(overlap), "; ".join(overlap[:6])),
             "a conclusion never appears as a given. Keep it in to_prove / "
             "to_construct where the student reaches it; a LATER item that "
             "uses it declares it on its given with from_item='<item id>'")

    # §8 / §9 the text and the model agree (r1 S2 S3): a name of two or more
    # points in the text that no starting figure of the question defines,
    # and a length / angle the text states with another value than the
    # model's, are certain mismatches -- refused, not left to the checker
    text_faults = []
    for qid in [k for k in _meta if _meta[k]["label"] is None]:
        rids = [qid] + q_items.get(qid, [])
        P = set()
        for e in figures:
            if e.get("question") == qid and aux_spec.get(e["id"]) is None:
                for o in (e.get("objects") or {}).get("points") or []:
                    if o.get("name"):
                        P.add(str(o["name"]))
                    # (v6.16 fix r1) a graph mark's printed letter
                    if o.get("letter"):
                        P.add(str(o["letter"]))
        full = u" ".join(str(x) for r in rids for x in (
            _meta[r]["src"].get("text"), _meta[r]["src"].get("intro")) if x)
        # (v6.16 fix r1, G9-T06 F3) a point the question's TEXT itself names
        # ("נסמן ב-Q את הנקודה מסעיף ב, וב-V את קדקוד הפרבולה") is defined
        # by that text: a denotation, not a mismatch with the model
        P |= text_named_points(full)
        for r in rids:
            for x in _meta[r]["src"].get("dashed") or []:
                if not DD.says_dashed(full, x):
                    text_faults.append(
                        "%s declares dashed=[%r], and the text never calls "
                        "%s dashed" % (_meta[r]["where"], x, x))
        if not P:
            continue
        new = set()
        vals = {}
        for r in rids:
            for kk in ("given", "to_prove", "to_construct"):
                for c in claims[r][kk]:
                    if not isinstance(c, dict):
                        continue
                    if kk == "to_construct":
                        new |= set(DD.names_in(c))
                    k = DD.canon(c)
                    if c.get("type") in ("length", "angle") and k:
                        vals.setdefault(k[:-1], set()).add(k[-1])
        for r in rids:
            m = _meta[r]
            txt = u" ".join(str(x) for x in (
                [m["src"].get("text"), m["src"].get("intro")]
                if m["label"] is None else [m["src"].get("text")]) if x)
            txt = re.sub(r"\\[A-Za-z]+", " ", txt)
            for run in DD._RUN.findall(txt):
                t = DD.toks(run)
                miss = [p for p in t if p not in P and p not in new]
                if miss and len(t) >= 2:
                    text_faults.append(
                        "%s names %s; no figure of question %s defines %s"
                        % (m["where"], run, m["n"], ", ".join(miss)))
            for rel in DD.relations_in(txt):
                k = DD.canon(rel)
                if rel.get("type") in ("length", "angle") and k and \
                        k[:-1] in vals and k[-1] not in vals[k[:-1]]:
                    text_faults.append(
                        "%s states %s; the model says %s"
                        % (m["where"], DD._say(rel),
                           " / ".join(sorted(str(v) for v in
                                             vals[k[:-1]]))))
    report["text_faults"] = text_faults
    if text_faults and neutral:
        _bad("%d mismatch(es) between the text and the model: %s"
             % (len(text_faults), "; ".join(text_faults[:6])),
             "the text, noam-ai.json and the SVG say one thing: name only "
             "points the figure draws (or that a to_construct adds), and "
             "state each length / angle with the value the given and the "
             "figure carry")

    neutral_rows = []
    for e in figures:
        if e.get("kind") == "unrecorded":
            continue
        rids = rows_of(e)
        given = [c for r in rids for c in claims[r]["given"]]
        tprove = [c for r in rids for c in claims[r]["to_prove"]]
        tcons = [c for r in rids for c in claims[r]["to_construct"]]
        spec = aux_spec.get(e["id"])
        if spec is not None:
            # §5 an aux figure: shown on request, one step, never the end
            e.update(aux=True, reveal="on_request",
                     label=spec.get("label") or DD.AUX_LABEL,
                     step=spec.get("step"),
                     completes=bool(spec.get("completes")))
            where = "aux figure %s" % e["id"]
            if not str(spec.get("step") or "").strip():
                _bad("%s names no step" % where,
                     "aux=[dict(fig=..., step='<the one step it explains>')]"
                     " -- an aux figure explains exactly one step")
            it_tc = claims.get(e.get("item") or e["question"],
                               {}).get("to_construct") or []
            for c in it_tc:
                drawn = DD._drawn(e, c)
                if drawn and not spec.get("completes"):
                    _bad("%s draws the complete construction %s (%s)"
                         % (where, DD._say(DD._claim_of(c)),
                            ", ".join(drawn)),
                         "an aux figure shows one step, not the result the "
                         "student builds; draw the step only, or declare "
                         "completes=True when the step IS exactly this one "
                         "construction")
            if spec.get("completes") and len(it_tc) == 1 and \
                    isinstance(it_tc[0], dict) and \
                    not DD.step_names(spec.get("step"), it_tc[0]):
                _bad("%s declares completes=True, and its step %r does not "
                     "name the construction %s"
                     % (where, spec.get("step"),
                        DD._say(DD._claim_of(it_tc[0]))),
                     "completes=True is for a step that IS the one "
                     "construction -- name it in the step ('העבירו את "
                     "האלכסון AC'); otherwise draw only the step")
            if spec.get("completes") and len(it_tc) != 1:
                _bad("%s declares completes=True, and its item has %d "
                     "to_construct" % (where, len(it_tc)),
                     "completes=True names the one construction the step "
                     "is; the item must declare exactly one to_construct")
            tk = set(DD.canon(c) for c in tprove if isinstance(c, dict))
            for c in e.get("constraints") or []:
                if c.get("marked") and DD.canon(c) in tk:
                    _bad("%s marks %s, which is to be proved"
                         % (where, DD._say(DD._claim_of(c))),
                         "an aux figure never marks a to_prove relation")
            m = _meta.get(e.get("item") or e["question"]) or {}
            a = _ans_of(ans, m.get("n"), m.get("label"))
            if a is None and m.get("src") is not None:
                a = m["src"].get("answer")
            if a is not None:
                qtext = u" ".join(str(x) for x in (
                    (m.get("q") or {}).get("text"),
                    (m.get("q") or {}).get("intro"),
                    (m.get("src") or {}).get("text")) if x)
                new = DD._numbers(a) - DD._numbers(qtext)
                shown = set()
                for t in _TEXT_RE.findall(svg_of.get(e["id"], "")):
                    shown |= DD._numbers(_TAG_RE.sub("", t))
                hit = sorted(new & shown)
                if hit:
                    _bad("%s prints %s, the answer of %s"
                         % (where, hit, e.get("item") or e["question"]),
                         "an aux figure never prints the final answer")
            continue
        faults = DD.neutral_faults(
            e, svg_of.get(e["id"], ""), given, tprove, tcons,
            dashed=[x for r in rids
                    for x in (_meta[r]["src"].get("dashed") or [])]
            + _parameter_locus_dashes(
                e, WB.spec_figs(L).get(e["id"]), svg_of.get(e["id"], ""),
                u" ".join(str(x) for r in rids for x in (
                    _meta[r]["src"].get("text"),
                    _meta[r]["src"].get("intro")) if x))
            + _symmetry_axis_dashes(
                e, WB.spec_figs(L).get(e["id"]),
                u" ".join(str(x) for r in rids for x in (
                    _meta[r]["src"].get("text"),
                    _meta[r]["src"].get("intro")) if x)),
            where=_meta[rids[0]]["where"])
        neutral_rows += faults
        # §4 how the givens are marked -- data for Noam AI, never drawn
        # (a result carried from an earlier item with from_item is NOT
        # marked: the overlay is per figure, and the earlier item that must
        # prove it shares this figure)
        rows = []
        for r in rids:
            for c in claims[r]["given"]:
                if isinstance(c, dict) and (c.get("from_item") or
                                            c.get("no_overlay")):
                    continue
                rows.append((c, r if r != rids[0] else None))
        e["given_marks"] = DD.given_marks(e, rows)
        tk = set(DD.canon(c) for c in tprove + tcons
                 if isinstance(c, dict))
        for gm in e["given_marks"]:
            if DD.canon(gm["claim"]) in tk:
                _bad("figure %s: a given_mark (%s) marks a to_prove / "
                     "to_construct relation" % (e["id"],
                                                DD._say(gm["claim"])),
                     "given_marks are built only from `given`; a "
                     "conclusion is never marked")
    report["neutral"] = neutral_rows
    if neutral_rows and os.environ.get("DIDACTIC_FAULTS_TO"):
        # maintenance: the WHOLE list of starting-figure faults (the refusal
        # below names the first 12), for porting an old sheet
        with open(os.environ["DIDACTIC_FAULTS_TO"], "w",
                  encoding="utf-8") as fh:
            json.dump(neutral_rows, fh, ensure_ascii=False, indent=1)
    if neutral_rows and neutral:
        _bad("%d starting-figure fault(s) of level %s (the starting figure "
             "is clean and neutral, BRIEF_V671 §3): %s"
             % (len(neutral_rows), key, _faults_text(neutral_rows)),
             "each fault names its fix; none of them drops the question's "
             "data (points, coordinates, numbers stay in the figure and in "
             "noam-ai.json)")
    aux_q = sorted(set(e["question"] for e in figures if e.get("aux")))
    nq = len(L.get("questions", []))
    if aux_q and len(aux_q) > DD.aux_limit(nq):
        _bad("%d of %d questions carry an aux figure (%s)"
             % (len(aux_q), nq, ", ".join(aux_q)),
             "aux figures are rare: at most %d on a sheet of %d questions "
             "(~10%%) -- keep them for the step that needs a picture"
             % (DD.aux_limit(nq), nq))

    # §9 the general visual layer: one visual_model per starting figure
    # (given_marks -> highlight_given, aux figures -> patches on it), one
    # per question table and per declared visual (`visual=`); validated by
    # the independent check_didactic.vm_faults
    visuals = build_visuals(L, figures, svg_of, claims, _meta, q_items,
                            aux_spec, rows_of, neutral, report)
    find_checks(L, figures, visuals, claims, _meta, rows_of, neutral, report)

    # §7 the package's place in the official teaching order
    reg = None
    cur_spec = curriculum if curriculum is not None else L.get("curriculum")
    cur = None
    if cur_spec is not None:
        reg = DD.load_tools()
        try:
            cur = DD.curriculum_block(cur_spec, grade or L.get("grade") or (
                str(package)[1] if isinstance(package, str) and
                PACKAGE_RE.match(package) else None), reg)
        except DD.CurriculumError as ex:
            _bad("curriculum: %s" % ex,
                 "L['curriculum'] = dict(topic='<topic id of "
                 "curriculum_tools.json>', track='ט_רגילה') -- the topic "
                 "id of the official sequence, not the site id")
    elif neutral:
        _bad("level %s declares no curriculum block" % key,
             "a Noam AI package states its place in the official order: "
             "L['curriculum'] = dict(topic='rectangle') (track by grade; "
             "narrow=[tool ids] to allow fewer) -- Noam AI must not suggest "
             "a tool not yet taught")
    allowed_ids = None if cur is None else set(
        t["id"] for t in cur["allowed_tools"])

    # §6 hints: private didactic.json, public hint_mode only
    didactic = {}
    public = {}
    for rid, m in _meta.items():
        if m["label"] is None and q_items.get(rid):
            continue                         # rows are the items
        has_aux = any(e.get("aux") and (e.get("item") or e["question"])
                      == rid for e in figures)
        a = _ans_of(ans, m["n"], m["label"])
        if a is None:
            a = m["src"].get("answer")
        qtext = u" ".join(str(x) for x in (m["q"].get("text"),
                                           m["q"].get("intro"),
                                           m["src"].get("text")) if x)
        row, pub = didactic_row(m["src"].get("didactic"), rid, m["where"],
                                claims[rid]["to_prove"],
                                claims[rid]["to_construct"], a, qtext,
                                has_aux, allowed_ids, reg or (
                                    DD.load_tools() if allowed_ids is None
                                    and (m["src"].get("didactic") or {})
                                    .get("allowed_tools") else None))
        if asks_argument(m["src"].get("text")) and \
                not claims[rid]["to_prove"]:
            # r1 M3: a proof request with nothing to prove -- the claim may
            # sit in `given` in words no reader parses; a human decides
            row["requires_human_review"] = True
            row["review_reasons"].append(
                "the text asks for a proof and declares to_prove=[]")
        if str(m["src"].get("no_target_reason") or "").strip():
            # r1 T1: an item that opts out of a find target is never
            # auto-passed -- a human reads its reason
            row["requires_human_review"] = True
            row["review_reasons"].append(
                "no find target: %s" % m["src"]["no_target_reason"])
        if m["src"].get("didactic") and \
                (m["src"].get("didactic") or {}).get("note") and \
                row["requires_human_review"]:
            # v6.7.2-noam item 5: the author's note says WHY a human decides
            row["review_reasons"].append(
                str(m["src"]["didactic"]["note"]))
        didactic[rid] = row
        public[rid] = pub
    report["review"] = sorted(r for r, d in didactic.items()
                              if d["requires_human_review"])

    # v6.7-noam r1 (R3-G6-DELIVER-SHIPS): under STRICT_FIGURES a printed
    # number that names nothing is not delivered -- the same rule as
    # verify_export N3, enforced where the package is written
    if strict_figures:
        _nofor = []
        for _e in figures:
            for _o in (_e.get("objects") or {}).get("labels", []) or []:
                _t = str(_o.get("text", _o.get("name", "")) or "")
                if numeric_label(_t) and not _o.get("for"):
                    _nofor.append("%s %s (%r)" % (_e["id"], _o.get("svg_id"),
                                                  _t))
        if _nofor:
            _bad("%d numeric label(s) of level %s name no object (%s)"
                 % (len(_nofor), key, ", ".join(_nofor[:4])),
                 "every number printed in a figure says what it stands for "
                 "(`for`): put it on a point, a tick, a segment or a face "
                 "(values=[(xy, text, side)] at a plotted point, a length "
                 "on its segment), or draw it as a tick's number")

    # (4) a number printed in the PDF that no datum of this level states
    strays = []
    pages = 0
    if pdf and os.path.isfile(str(pdf)):
        got, pages = pdf_numbers(pdf)
        if got is not None:
            strays = stray_numbers(L, entries, got, pages)
    report["strays"] = strays
    if strays and strict_numbers:
        _bad("the PDF prints %d number(s) no datum of this level states (%s)"
             % (len(strays), ", ".join(strays[:8])),
             "every number on the page comes from the level's own data "
             "(spec rule 1). Put the number in the level and let the text "
             "and the figure read it, rather than typing it into the page")

    # ---- write ------------------------------------------------------------
    stamp = built_at or datetime.datetime.now().replace(
        microsecond=0).isoformat()
    files = {}
    if wfigs:
        # v6.9: the PUBLIC spec every engine figure re-renders from
        _pubs = set(id(r["level"]) for r in wfigs.values())
        if len(_pubs) != 1:
            _bad("level %s draws from %d spec files" % (key, len(_pubs)),
                 "one LevelSpec per level (its figures re-render from one "
                 "public spec)")
        _lv = list(wfigs.values())[0]["level"]
        _pb = WB.public_spec_bytes(_lv)
        os.makedirs(os.path.join(root, os.path.dirname(WB.PUBLIC_SPEC_REL)),
                    exist_ok=True)
        with open(os.path.join(root, WB.PUBLIC_SPEC_REL), "w",
                  encoding="utf-8") as fh:
            fh.write(_pb)
        files[WB.PUBLIC_SPEC_REL] = _sha(_pb)
        # (v6.10 fix r1) the spec the build used, beside the level's source
        _lb = WB.level_spec_bytes(_lv)
        os.makedirs(os.path.join(root, os.path.dirname(WB.LEVEL_SPEC_REL)),
                    exist_ok=True)
        with open(os.path.join(root, WB.LEVEL_SPEC_REL), "w",
                  encoding="utf-8") as fh:
            fh.write(_lb)
        files[WB.LEVEL_SPEC_REL] = _sha(_lb)
    for (fid, svg, _q, _i), (_f, rec) in zip(entries, recs):
        if fid in wfigs:
            _wr = wfigs[fid]
            with open(os.path.join(figs_dir, "%s.svg" % fid), "w",
                      encoding="utf-8") as fh:
                fh.write(_wr["svg_file"])
            files["figures/%s.svg" % fid] = _sha(_wr["svg_file"])
            _mb = WB.map_bytes(_wr)
            with open(os.path.join(figs_dir, "%s.map.json" % fid), "w",
                      encoding="utf-8") as fh:
                fh.write(_mb)
            files["figures/%s.map.json" % fid] = _sha(_mb)
            if WB.F616.family_of_rec(_wr):
                # (v6.16 integrate) a graph / pie figure: its renderer
                # settings beside it (the acceptance runner re-renders the
                # delivered figure from wspec/public_spec.json + these;
                # the same settings figures/<fid>.py carries)
                _sb = json.dumps(_wr["settings"], ensure_ascii=False,
                                 indent=1, sort_keys=True) + "\n"
                with open(os.path.join(figs_dir, "%s.settings.json" % fid),
                          "w", encoding="utf-8") as fh:
                    fh.write(_sb)
                files["figures/%s.settings.json" % fid] = _sha(_sb)
            code = WB.figure_script(_wr, skill_version)
            f_py = os.path.join(figs_dir, "%s.py" % fid)
            with open(f_py, "w", encoding="utf-8") as fh:
                fh.write(code)
            files["figures/%s.py" % fid] = _sha(code)
            runnable = (not verify_code_) or \
                WB.script_redraws(f_py, _wr["svg_file"])
            report.setdefault("runnable", 0)
            report["runnable"] += 1 if runnable else 0
            if verify_code_ and not runnable:
                _bad("figures/%s.py does not re-draw figures/%s.svg byte "
                     "for byte" % (fid, fid),
                     "the engine is deterministic; report this figure")
            for e in figures:
                if e["id"] == fid:
                    e["code_runnable"] = runnable
            continue
        f_svg = os.path.join(figs_dir, "%s.svg" % fid)
        with open(f_svg, "w", encoding="utf-8") as fh:
            fh.write(svg)
        files["figures/%s.svg" % fid] = _sha(svg)
        code, runnable = figure_code(rec, fid, svg, verify=verify_code_)
        report.setdefault("runnable", 0)
        report["runnable"] += 1 if runnable else 0
        for e in figures:
            if e["id"] == fid:
                e["code_runnable"] = runnable
        f_py = os.path.join(figs_dir, "%s.py" % fid)
        with open(f_py, "w", encoding="utf-8") as fh:
            fh.write(code)
        files["figures/%s.py" % fid] = _sha(code)

    src_hashes = {}
    for s in source or ():
        if not os.path.isfile(str(s)):
            continue
        base = os.path.basename(str(s))
        with open(str(s), "rb") as fh:
            raw = fh.read()
        try:
            txt = raw.decode("utf-8")
        except UnicodeDecodeError:
            txt = None
        if txt is None:
            with open(os.path.join(src_dir, base), "wb") as fh:
                fh.write(raw)
            src_hashes["source/%s" % base] = _sha(raw)
            continue
        txt, left = portable_source(txt, os.path.dirname(os.path.abspath(
            str(s))))
        if left:
            _bad("source/%s names %d absolute temporary path(s) (%s)"
                 % (base, len(left), ", ".join(left[:3])),
                 "the delivered source must rebuild on any machine: keep "
                 "the files a level reads inside its own folder (or the "
                 "skill's), where the copy rewrites the path relative, or "
                 "pass the path in from the environment")
        with open(os.path.join(src_dir, base), "w", encoding="utf-8") as fh:
            fh.write(txt)
        src_hashes["source/%s" % base] = _sha(txt)
    files.update(src_hashes)

    if html:
        # v6.8 G9: the HTML the PDF was printed from (ids prefixed per
        # figure): verify_export compares each inlined figure with its file
        # v6.11 fix r1 (HTML-FONT): the fonts the PDF was printed with are
        # embedded (data: URIs, the same bytes), so the delivered HTML names
        # no path of the build machine
        html = portable_html(html)
        with open(os.path.join(root, "sheet.html"), "w",
                  encoding="utf-8") as fh:
            fh.write(html)
        files["sheet.html"] = _sha(html)
    if pdf and os.path.isfile(str(pdf)):
        shutil.copyfile(str(pdf), os.path.join(root, "sheet.pdf"))
        with open(str(pdf), "rb") as fh:
            files["sheet.pdf"] = _sha(fh.read())

    sheet = {"package": package, "level": key,
             "grade": grade or L.get("grade"), "title": L.get("title"),
             "subtitle": L.get("subtitle"),
             "skill_version": skill_version, "built_at": stamp,
             "source_hash": _sha("".join(sorted(src_hashes.values()))),
             "questions": questions, "figures": figures}
    if cur is not None:
        sheet["curriculum"] = cur
    if visuals:
        sheet["visuals"] = visuals
    body = json.dumps(sheet, ensure_ascii=False, indent=1, sort_keys=False)
    with open(os.path.join(root, "sheet.json"), "w", encoding="utf-8") as fh:
        fh.write(body)
    files["sheet.json"] = _sha(body)

    # Public, answer-free view for Noam AI (the author's v6.6-noam, merged in
    # v6.8). The private sheet.json stays the rebuild/audit record; this file
    # is safe to serve with figures/*.svg: no answers at any depth and no
    # code paths, so the browser receives only the exact drawing, its stable
    # ids and its verified mathematical meaning.
    # v6.7.1-noam §6: the didactic record is PRIVATE (never in noam-ai.json,
    # never published): hint types, exposure, review flags, hint texts
    dbody = json.dumps({"schema": "didactic/v1", "package": package,
                        "level": key, "items": didactic},
                       ensure_ascii=False, indent=1, sort_keys=False)
    with open(os.path.join(root, "didactic.json"), "w",
              encoding="utf-8") as fh:
        fh.write(dbody)
    files["didactic.json"] = _sha(dbody)
    noam = noam_view(sheet, claims, public)
    # (v6.14 F2 / F3) the focused checks on the file Noam AI reads: every
    # given stating a segment ∥ an axis is a typed relation with its
    # objects, highlight and ∥ overlay; every scale a bound stem prints is
    # a structured given with its unit
    _gf = [t for f in noam.get("figures") or []
           for t in WB.G614.axis_parallel_faults(f.get("visual_model")
                                                 or {})]
    if wfigs:
        _gf += WB.G614.scale_unit_faults(noam, json.loads(_pb))
    # (v6.14 fix_r1, W-META-LINES-3) every line in an approved unprinted
    # wording restates one printed given / target of its row, linked to
    # its public spec fact (a builder level: only the ∥ given its
    # question prints)
    _gf += WB.G614.meta_line_faults(noam, json.loads(_pb) if wfigs
                                    else None)
    if _gf:
        _bad("noam-ai.json: %s" % "; ".join(_gf[:4]),
             "a printed axis-parallel / scale given is structured, and a "
             "W-META-LINES-3 line restates its printed source fact "
             "(givens614) -- rebuild with the skill's wspec_build / deliver")
    noam_body = json.dumps(noam, ensure_ascii=False, indent=1,
                           sort_keys=False)
    with open(os.path.join(root, "noam-ai.json"), "w", encoding="utf-8") as fh:
        fh.write(noam_body)
    files["noam-ai.json"] = _sha(noam_body)
    if neutral:
        # v6.7.1-noam r3 M1: a claim an item proves, written in the text as a
        # FACT (the intro, an earlier item, or its own text outside the asked
        # clause) is a conclusion shown as a given -- certain, so refused
        import check_didactic as _CD
        _f11 = [x for x in _CD.check_level(root)[0]
                if x[0] == "FAIL" and x[1] == "D11"]
        if _f11:
            _bad("level %s: %s %s" % (key, _f11[0][2], _f11[0][3]),
                 "a claim the student proves is not written as a fact: say "
                 "it only in the asked clause ('הוכיחו כי ...'), and let a "
                 "later item that uses it declare it as a given with "
                 "from_item='<the proving item>'")

    build = {"skill_version": skill_version, "built_at": stamp,
             "package": package, "level": key,
             # v6.8 G3: what this package was built under
             "strict_figures": bool(strict_figures),
             "strict_figures_declared": strict_declared,
             # v6.7.1-noam: built under the didactic policy (§3-§7)?
             "neutral": neutral,
             "source_hash": sheet["source_hash"],
             "pages": pages, "figures": len(entries),
             "constraints": report["constraints"],
             "checks": {"constraints_remeasured": report["remeasured"],
                        "to_prove_marked": 0,
                        "objects_missing_in_svg": 0,
                        "numbers_not_in_data": strays,
                        "figures_unrecorded": unrecorded,
                        "statements_not_checked": unchecked,
                        "given_on_proof_item": proof_given},
             "files": dict(sorted(files.items()))}
    if wfigs:
        # (v6.10, Codex E2) the object maps the package needs come from the
        # engine's figure list, not from what happened to be written: every
        # engine figure has its sheet entry, its hashed map, and the map is
        # ITS map (figure id, the SVG's element ids)
        for _fid in sorted(wfigs):
            _rel = "figures/%s.map.json" % _fid
            _ent_ = [e for e in figures if e["id"] == _fid]
            if not _ent_ or _ent_[0].get("map") != _rel or                     _rel not in files:
                _bad("engine figure %s ships no object map %s" % (_fid, _rel),
                     "every figure the engine draws is written with its "
                     "map; report this figure")
            _mj = json.loads(WB.map_bytes(wfigs[_fid]))
            _ids = set(re.findall(r'\sid="(e\d{4})"',
                                  wfigs[_fid]["svg_file"]))
            if _mj.get("figure") != _fid or set(_mj.get("elements") or {})                     != _ids:
                _bad("the map written for %s is not its map (figure %r, "
                     "%d element ids for %d in the SVG)"
                     % (_fid, _mj.get("figure"),
                        len(_mj.get("elements") or {}), len(_ids)),
                     "report this figure")
        # v6.9: the engine that drew the spec figures, and the PDF gate
        build["wspec"] = {"engine": WB.WR.ENGINE_VERSION,
                          "figures": sorted(wfigs),
                          "public_spec": WB.PUBLIC_SPEC_REL,
                          "level_spec": WB.LEVEL_SPEC_REL}
        if g79 is not None:
            build["checks"]["g79_spec"] = g79
    if text_binding is not None:
        build["text_binding"] = text_binding
    with open(os.path.join(root, "build.json"), "w", encoding="utf-8") as fh:
        json.dump(build, fh, ensure_ascii=False, indent=1, sort_keys=False)
    report.update(dir=root, sheet=sheet, build=build)
    return report


def _drop_answers(o):
    if isinstance(o, dict):
        for k in list(o):
            if k == "answer":
                del o[k]
            else:
                _drop_answers(o[k])
    elif isinstance(o, list):
        for v in o:
            _drop_answers(v)


def _cell(v):
    return u"" if v is None else (v if isinstance(v, str) else str(v))


def question_table(t):
    """A question's table as data: {"head": [...], "rows": [[...], ...]}
    (the emitter's cls / hcol are print layout, not data). None when the
    question has no table."""
    if not isinstance(t, dict):
        return None
    out = {}
    if t.get("head") is not None:
        out["head"] = [_cell(x) for x in t["head"]]
    out["rows"] = [[_cell(x) for x in (r or [])] for r in t.get("rows") or []]
    return out


def question_example(e):
    """A worked example printed with the question: {"title", "lines"}."""
    if not e:
        return None
    if isinstance(e, dict):
        title, lines = e.get("title"), e.get("lines")
    else:
        e = list(e)
        title = e[0] if e else None
        lines = e[1] if len(e) > 1 else []
    if isinstance(lines, str):
        lines = [lines]
    return {"title": _cell(title), "lines": [_cell(x) for x in lines or []]}


# ---------------------------------------------------- noam-ai.json --------
# v6.7-noam (BRIEF_V68 §5.2/§5.3): the public view is a WHITELIST, built
# field by field. A key that is not named below never reaches the browser,
# whatever a builder or a later version adds to sheet.json.
NOAM_SCHEMA = "noam-ai/v1"


_DENOTE = re.compile(u"(?:נסמן|נסמנה|יסומן|סמנו)[^.?!:]*")
_DENOTE_NAME = re.compile(u"ב[-־]?\\s*([A-Z](?:′|')?)\\s+את\\s")


def text_named_points(text):
    """(v6.16 fix r1) the point names a text DEFINES by denotation: inside a
    sentence of "נסמן ..." every "ב-X את ..." ("let X be ...")."""
    t = (text or u"").replace("$", "")
    out = set()
    for m in _DENOTE.finditer(t):
        out |= set(n.replace(u"′", "'") for n in
                   _DENOTE_NAME.findall(m.group(0) + " "))
    return out
_NOAM_BUCKETS = ("points", "segments", "lines", "rays", "angles", "polygons",
                 "circles", "arcs", "marks", "labels", "dimensions", "paths")
_NOAM_OBJ_KEYS = ("svg_id", "kind", "role", "name", "text", "for",
                  "for_part", "xy", "xyz", "svg_xy", "ink_xy", "ink_box",
                  "ink_svg_id", "measures_xy", "measures_svg_xy", "n", "r",
                  "space", "letter_printed", "series", "legend", "marker",
                  "row", "letter")
_NOAM_VIEW_KEYS = ("width_px", "height_px", "unit_px", "viewbox", "rotate",
                   "data_to_svg", "data_unit_px", "frame", "sketch")
_NOAM_CON_KEYS = ("type", "points", "point", "of", "t", "at", "rays",
                  "value", "unit", "circle", "to", "space", "item",
                  "marked", "mark_id", "mark_ids", "violated")
_NOAM_CLAIM_KEYS = ("text", "type", "points", "point", "of", "t", "at",
                    "rays", "value", "unit", "circle", "to", "space",
                    "quantity", "what", "curve", "x",
                    # (v6.14 F2 / F3) the public spec fact ids a printed
                    # given restates (givens614; wspec/public_spec.json)
                    "facts")
# a constraint's `source` is renamed: `source` is a key the public file never
# carries (it reads as a code/source reference)
_NOAM_STATUS = ("given", "to_prove", "derived", "decorative")


def _pick(d, keys):
    return dict((k, d[k]) for k in keys if k in d and d[k] is not None)


def _noam_claims(rows):
    out = []
    for r in rows or []:
        if DD.is_find(r):
            c = DD.find_public(r)           # v6.7.2: never the value
        elif isinstance(r, dict):
            c = _pick(r, _NOAM_CLAIM_KEYS)
        else:
            c = {"text": _cell(r)}
        out.append(c)
    return out


def _noam_row(src, claims, keys, public=None, aux=None):
    row = {}
    for k in keys:
        if src.get(k) is not None:
            row[k] = src[k]
    row["figure_id"] = src.get("figure")
    cl = claims.get(src.get("id")) or {}
    for k in ("given", "to_prove", "to_construct"):
        row[k] = _noam_claims(cl.get(k) if cl.get(k) is not None
                              else src.get(k))
    # v6.7.2-noam: why a compute item carries no find target; the symbols
    # the question declares
    for k in ("no_target_reason", "variables"):
        if src.get(k):
            row[k] = src[k]
    # v6.9 (Codex F4): a spec question the public spec cannot carry whole
    if isinstance(src.get("spec_unsupported"), dict):
        row["spec_unsupported"] = _pick(src["spec_unsupported"],
                                        ("reason", "missing"))
    # v6.7.1-noam: a given that an earlier item proved says so
    for c, raw in zip(row["given"], cl.get("given") or []):
        if isinstance(raw, dict) and raw.get("from_item"):
            c["from_item"] = raw["from_item"]
    pub = (public or {}).get(src.get("id"))
    if pub:
        row["hint_mode"] = pub["hint_mode"]
        if pub.get("hint_mode") == "approved_hint":
            row["approved_hint"] = pub["approved_hint"]
    if aux and aux.get(src.get("id")):
        row["aux"] = list(aux[src.get("id")])
    return row


def noam_view(sheet, claims=None, public=None):
    """noam-ai.json, built FIELD BY FIELD from sheet.json (v6.7-noam).

    Carried: the package and level ids; each question's id, number, text,
    figure_id, given, to_prove, table and worked example, and its items
    (id, label, text, figure_id, given, to_prove); each figure's id, SVG
    file, question/item link, view, objects (whitelisted fields, svg_id)
    and constraints. Never: answers, solutions, hints, code or code
    references, paths, hashes, built_at, skill_version, fam, kind,
    sheet_id_prefix / sheet_svg_id, strict flags, report rows."""
    claims = claims or {}
    noam = {"schema_version": NOAM_SCHEMA, "package": sheet.get("package"),
            "level": sheet.get("level")}
    if isinstance(sheet.get("curriculum"), dict):
        cu = sheet["curriculum"]
        noam["curriculum"] = dict(
            (k, cu[k]) for k in ("grade", "track", "topic", "unit")
            if cu.get(k) is not None)
        for k in ("allowed_tools", "not_yet_allowed"):
            noam["curriculum"][k] = [_pick(t, ("id", "name"))
                                     for t in cu.get(k) or []]
    aux = {}
    for F in sheet.get("figures") or []:
        if F.get("aux"):
            aux.setdefault(F.get("item") or F.get("question"),
                           []).append(F.get("id"))
    qs = []
    for q in sheet.get("questions") or []:
        qd = {"id": q.get("id"), "label": q.get("n")}
        if q.get("text") is not None:
            qd["text"] = q["text"]
        r = _noam_row(q, claims, (), public, aux)
        qd.update(r)
        if isinstance(q.get("table"), dict):
            qd["table"] = question_table(q["table"])
        if isinstance(q.get("example"), dict):
            qd["example"] = question_example(q["example"])
        items = []
        for it in q.get("items") or []:
            items.append(_noam_row(it, claims, ("id", "label", "text"),
                                   public, aux))
        qd["items"] = items
        qs.append(qd)
    noam["questions"] = qs
    ro_q = readoff_questions(sheet, claims)
    figs = []
    for F in sheet.get("figures") or []:
        if F.get("aux"):
            # v6.7.1-noam §9: an aux figure (שרטוט עזר) is a PATCH in its
            # starting figure's visual_model (reveal on_request), not a
            # figure of its own
            continue
        fd = {"id": F.get("id"), "svg": F.get("svg"),
              "question": F.get("question")}
        if F.get("item"):
            fd["item"] = F["item"]
        fd["view"] = _pick(F.get("view") or {}, _NOAM_VIEW_KEYS)
        if isinstance((F.get("view") or {}).get("rows"), list):
            # a stack of number lines: each row's prefix, offset and map
            fd["view"]["rows"] = [_pick(r, ("row", "id_prefix", "offset",
                                            "data_to_svg"))
                                  for r in F["view"]["rows"]
                                  if isinstance(r, dict)]
        objs = {}
        for b in _NOAM_BUCKETS:
            lst = (F.get("objects") or {}).get(b)
            if lst:
                objs[b] = [_pick(o, _NOAM_OBJ_KEYS) for o in lst]
        fd["objects"] = objs
        cons = []
        for c in F.get("constraints") or []:
            cd = _pick(c, _NOAM_CON_KEYS)
            if c.get("source") in _NOAM_STATUS:
                cd["status"] = c["source"]
            cons.append(cd)
        fd["constraints"] = cons
        if isinstance(F.get("visual_model"), dict):
            # §4 + §9: the givens overlay is the model's highlight_given
            fd["visual_model"] = noam_vm(F["visual_model"])
            # A native base/height foot has a technical ID, not a printed
            # name. Keep the private figure's typed, remeasurable geometry;
            # its public claims use the source's base/height descriptions.
            anchors = {o.get("id") for o in fd["visual_model"].get("objects") or [] if o.get("type") == "point" and o.get("part") == "anchor" and not o.get("name")}
            if anchors:
                lines = {r.get("text") for r in fd["visual_model"].get("relations") or [] if r.get("type") == "statement" and r.get("role") == "given"}
                native_names = {o.get("name"): o.get("svg_id") for bucket in (F.get("objects") or {}).values() for o in bucket if o.get("name") and o.get("svg_id") and o.get("kind") in ("point", "segment", "line", "ray")}
                for obj in (objs.get("labels") or []) + [o for o in fd["visual_model"].get("objects") or [] if o.get("type") == "label"]:
                    if anchors.intersection(DD.toks(obj.get("for", ""))):
                        obj["for"] = native_names.get(obj["for"], obj["for"])
                for bucket in objs.values():
                    for obj in bucket:
                        if anchors.intersection(DD.toks(obj.get("name", ""))):
                            obj.pop("name", None)
                            if obj.get("kind") == "point":
                                obj["role"] = "anchor"
                for constraint in cons:
                    if constraint.get("text") in lines:
                        for key in ("of", "point", "points", "at", "rays", "value", "unit"):
                            constraint.pop(key, None)
                        constraint["type"] = "statement"
        if F.get("question") in ro_q and is_family_figure(F):
            withhold_data(fd)
        figs.append(fd)
    noam["figures"] = figs
    vis = [noam_vm(v) for v in sheet.get("visuals") or []
           if isinstance(v, dict)]
    if vis:
        noam["visuals"] = vis
    return noam


# v6.12 fix_r1 (M1-readoff): on a coordinate plane or a number line the
# DATA coordinate of a drawn point is what a read-off item asks for ("כתבו את
# שיעורי הנקודה A", "איזה מספר מייצגת הנקודה P", "מהו ערך כל מרווח"). The
# public file gave it away as the object's xy / the VM object's value, and
# data_to_svg + any svg_xy gave the scale. For every family figure of a
# question that asks the student to find something, noam-ai.json carries
# the drawing only in SVG pixels (svg_id, svg_xy, names, printed texts):
# no data_to_svg / data_unit_px / step / scale, no xy / xyz / measures_xy,
# no VM value. Highlighting works from svg ids and svg_xy alone. A figure of
# a question with no find target keeps its data frame.
FAMILY_KINDS = ("coordinate_plane", "number_line",
                # (v6.16 integrate) a graph figure: the SVG coordinates of an
                # asked curve / mark would give its numbers; a pie chart
                "function_graph", "pie_chart")
WITHHELD_VIEW = ("data_to_svg", "data_unit_px", "step")
WITHHELD_OBJ = ("xy", "xyz", "measures_xy", "value")


def is_family_figure(F):
    vm = F.get("visual_model") if isinstance(F.get("visual_model"),
                                             dict) else {}
    return vm.get("kind") in FAMILY_KINDS or str(F.get("kind") or "") in (
        "plane", "numberline", "numberline.stack", "number_line")


def readoff_questions(sheet, claims=None):
    """ids of the questions that ask the student to find something: a find
    target (item `find` / `to_prove`, the question's own) or an item that
    states why it carries none (no_target_reason)."""
    claims = claims or {}
    out = set()
    for q in (sheet or {}).get("questions") or []:
        rows = [q] + list(q.get("items") or [])
        for r in rows:
            cl = claims.get(r.get("id")) or {}
            got = list(r.get("find") or []) + list(r.get("to_prove") or []) \
                + list(cl.get("to_prove") or [])
            # v6.13 fix_r1 (C1): a spec family target (a text row marked
            # 'readoff' by wspec_build.claim_of) is a find as well
            if any(DD.is_find(c) or (isinstance(c, dict) and
                                     c.get("readoff")) for c in got) or \
                    r.get("no_target_reason"):
                out.add(q.get("id"))
    return out


def withhold_data(fd):
    """strip the data frame from one public figure (in place)."""
    v = fd.get("view") or {}
    for k in WITHHELD_VIEW:
        v.pop(k, None)
    for r in v.get("rows") or []:
        if isinstance(r, dict):
            r.pop("data_to_svg", None)
    for lst in (fd.get("objects") or {}).values():
        for o in lst or []:
            for k in WITHHELD_OBJ:
                o.pop(k, None)
    vm = fd.get("visual_model")
    if isinstance(vm, dict):
        for k in WITHHELD_VIEW:
            (vm.get("view") or {}).pop(k, None)
        if isinstance(vm.get("data"), dict):
            vm["data"].pop("scale", None)
        for o in vm.get("objects") or []:
            for k in WITHHELD_OBJ:
                o.pop(k, None)
    return fd


# v6.7.1-noam §9: the visual_model is whitelisted field by field too
NOAM_VM_KEYS = ("schema_version", "id", "kind", "visual_support", "reason",
                "question", "item", "svg", "view", "data", "objects",
                "relations", "highlight_given", "aux", "actions")
NOAM_VM_OBJ = ("id", "svg_id", "type", "part", "name", "letter", "text",
               "xy", "xyz", "svg_xy", "bbox", "r", "n", "for", "series",
               "legend", "marker", "row", "col", "value", "label", "parent",
               "p", "leaf_p", "frequency", "relative", "in", "count",
               "total", "height_px", "angle", "expr", "category", "mark",
               "on", "role", "display",
               # v6.9: an engine figure's object -> its svg ids (+ span)
               "parts",
               # v6.16 gaps (corpus-v2 G1): a partial polygon's shown
               # vertices (its highlight paints exactly that part)
               "shown")
NOAM_VM_PART = ("svg_id", "span")
NOAM_VM_REL = ("id", "type", "role", "item", "points", "point", "of", "t",
               # v6.10 (C3): a relation a typed-shape given states
               "from_given",
               "at", "rays", "value", "unit", "circle", "to", "space",
               "quantity", "what", "x",
               "text", "from_item", "objects", "measured", "marked",
               "mark_id", "mark_ids", "violated", "highlight", "row", "col",
               "curve", "node", "set", "sets", "bar", "sector")
NOAM_VM_VIEW = ("viewbox", "data_to_svg", "data_unit_px", "frame", "sketch",
                "rotate", "step")
NOAM_VM_DATA = ("size", "stages", "rows", "cols", "total", "universe",
                "scale")
NOAM_VM_AUX = ("id", "svg", "label", "reveal", "step", "item", "completes",
               "ops")


def _vm_obj(o):
    d = _pick(o, NOAM_VM_OBJ)
    d["svg_id"] = o.get("svg_id")       # null for an overlay / a cell
    if isinstance(o.get("parts"), list):
        # v6.9: highlight from noam-ai.json alone -- object id -> svg ids
        d["parts"] = [_pick(p, NOAM_VM_PART) for p in o["parts"]
                      if isinstance(p, dict)]
    return d


# v6.13 fix_r2 (R2-nl-axis-object-named-n): the axis of a NUMBER LINE has
# an internal letter ('n') that the sheet never prints. Unless the figure
# prints the axis's name (a label object 'for' the axis), noam-ai.json names
# the object "ישר המספרים", so Noam AI never calls the line 'n'.
NL_AXIS_NAME = u"\u05d9\u05e9\u05e8 \u05d4\u05de\u05e1\u05e4\u05e8\u05d9\u05dd"


def _nl_axis_names(out):
    if out.get("kind") != "number_line":
        return
    objs = out.get("objects") or []
    printed = set(o.get("for") for o in objs if o.get("type") == "label")
    for o in objs:
        if o.get("type") == "axis" and o.get("id") not in printed and \
                o.get("name") and o.get("name") != NL_AXIS_NAME:
            o["name"] = NL_AXIS_NAME


def noam_vm(vm):
    out = _pick(vm, NOAM_VM_KEYS)
    if isinstance(vm.get("view"), dict):
        out["view"] = _pick(vm["view"], NOAM_VM_VIEW)
    if isinstance(vm.get("data"), dict):
        out["data"] = _pick(vm["data"], NOAM_VM_DATA)
    out["svg"] = vm.get("svg")          # null: no drawing (unsupported)
    out["objects"] = [_vm_obj(o) for o in vm.get("objects") or []]
    _nl_axis_names(out)
    out["relations"] = [_pick(r, NOAM_VM_REL)
                        for r in vm.get("relations") or []]
    aux = []
    for a in vm.get("aux") or []:
        ad = _pick(a, NOAM_VM_AUX)
        ops = []
        for op in a.get("ops") or []:
            od = _pick(op, ("op", "ids"))
            if op.get("objects"):
                od["objects"] = [_vm_obj(o) for o in op["objects"]]
            if op.get("relations"):
                od["relations"] = [_pick(r, NOAM_VM_REL)
                                   for r in op["relations"]]
            ops.append(od)
        ad["ops"] = ops
        aux.append(ad)
    out["aux"] = aux
    if isinstance(vm.get("actions"), dict):
        out["actions"] = _pick(vm["actions"], ("allowed", "show",
                                               "highlight", "show_aux"))
    return out


def line(report):
    """The one line a build prints about the package it just wrote."""
    r = report
    return ("deliverable %-28s %2d figures · %3d constraints re-measured · "
            "%s%s" % (r["dir"].split(os.sep)[-1] + "/", r["figures"],
                      r["constraints"],
                      "%d unrecorded figure(s) · " % len(r["unrecorded"])
                      if r["unrecorded"] else "",
                      "%d number(s) not in the level's data"
                      % len(r.get("strays") or [])
                      if r.get("strays") else "every printed number is data")
            + ("" if not r.get("given_on_proof_item") else
               " · %d given(s) on an item that asks for a proof (%s)"
               % (len(r["given_on_proof_item"]),
                  r["given_on_proof_item"][0]["where"])))
