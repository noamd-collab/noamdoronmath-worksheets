# -*- coding: utf-8 -*-
u"""subtopics — v7.2.0. One API over the subtopic registry and the glossary.

WHY ONE MODULE
--------------
Three consumers read the same two data files: gate_sections (G85-G92), the
catalog/landing builders and the Word checker. If each compiled the glossary
patterns or computed a "position" its own way, a term could pass one gate and
fail another for the same text. So the normalisation, the regex wrapper, the
(grade, topic, subtopic) ordering and the volume ranges live here once, and
every consumer imports them.

DATA (read-only; this module never writes a file)
-------------------------------------------------
    curriculum_tashpaz.json  ["subtopics"]                 the registry
                             ["coverage_policy"]["volume_policy"|"volume_rule"]
                             ["tracks"][track]["excluded"]  not-in-track keywords
    curriculum_tools.json    ["sequences"][track]           teaching order of topics
    glossary_he.json         terms / forbidden / house_spelling / matching

STDLIB ONLY: the module must import under ``python3 -I`` (check_docx_rtl and
the catalog checker run isolated), so no third-party import, no import of the
engine.

Matching contract (glossary_he.json["matching"]):
    normalize  NFC; drop niqqud/cantillation U+0591-U+05C7 except U+05BE
               (maqaf, a word separator in the patterns), U+05C0, U+05C3,
               U+05C6; ASCII ' -> geresh U+05F3, ASCII " -> gershayim U+05F4;
               and drop the invisible U+200D / U+200E / U+200F / U+2060 that
               emit_docx puts before formulas and between math zones (a Word
               run would otherwise hide a term from a gate).
    compile    "(?<![א-ת])(?:<prefixes>)(?:<pattern>)(?![א-ת])", the template
               string read from the glossary itself.
Spans returned by find_terms / forbidden_hits / house_spelling_hits index the
NORMALISED text (normalize() output), never the raw input.

    python3 -I subtopics.py --selftest
"""
import json
import os
import re
import sys
import unicodedata

HERE = os.path.dirname(os.path.abspath(__file__))
CURRICULUM_PATH = os.path.join(HERE, "curriculum_tashpaz.json")
TOOLS_PATH = os.path.join(HERE, "curriculum_tools.json")
GLOSSARY_PATH = os.path.join(HERE, "glossary_he.json")

GRADE9_REGULAR = u"ט_רגילה"
GRADE9_REDUCED = u"ט_מצומצמת"

# Characters stripped by normalize(). The niqqud range is U+0591-U+05C7 minus
# the four punctuation marks the glossary keeps (maqaf above all).
_KEEP_IN_NIQQUD_RANGE = {0x05BE, 0x05C0, 0x05C3, 0x05C6}
_INVISIBLE = {0x200D, 0x200E, 0x200F, 0x2060}
_STRIP = dict((cp, None) for cp in range(0x0591, 0x05C8)
              if cp not in _KEEP_IN_NIQQUD_RANGE)
_STRIP.update((cp, None) for cp in _INVISIBLE)
_STRIP[ord("'")] = u"׳"
_STRIP[ord('"')] = u"״"

_cache = {}


def _load_json(path):
    if path not in _cache:
        with open(path, encoding="utf-8") as f:
            _cache[path] = json.load(f)
    return _cache[path]


def reset_cache():
    """Drop every cached file and compiled pattern (tests patch the files)."""
    _cache.clear()


# ----------------------------------------------------------------- files ---
def load_curriculum():
    return _load_json(CURRICULUM_PATH)


def load_tools():
    return _load_json(TOOLS_PATH)


def load_registry():
    """curriculum_tashpaz.json["subtopics"] ({"meta", "by_track"}), cached."""
    reg = load_curriculum().get("subtopics")
    if not isinstance(reg, dict) or "by_track" not in reg:
        raise KeyError("curriculum_tashpaz.json has no 'subtopics' registry")
    return reg


def load_glossary():
    return _load_json(GLOSSARY_PATH)


# -------------------------------------------------------------- registry ---
def _index():
    """{subtopic_id: (track, topic_id, entry)} -- built once per cache."""
    key = ("__index__",)
    if key not in _cache:
        idx = {}
        for track, topics in load_registry()["by_track"].items():
            for topic_id, lst in topics.items():
                for e in lst:
                    idx[e["id"]] = (track, topic_id, e)
        _cache[key] = idx
    return _cache[key]


def get(subtopic_id):
    """The registry entry of a subtopic id, or None."""
    hit = _index().get(subtopic_id)
    return hit[2] if hit else None


def locate(subtopic_id):
    """(track, topic_id, entry) of a subtopic id, or None -- the entry itself
    does not carry its track/topic, the registry nesting does."""
    return _index().get(subtopic_id)


def entries(track, topic_id):
    """The subtopics of one topic in one track, in teaching order."""
    lst = load_registry()["by_track"].get(track, {}).get(topic_id, [])
    return sorted(lst, key=lambda e: e.get("order", 0))


def sequence(track):
    """curriculum_tools.json sequences[track]: the cumulative teaching order
    (a track's sequence starts with the earlier grades' topics)."""
    return load_tools().get("sequences", {}).get(track, [])


def topic_index(track, topic_id, grade=None, topic_track=None):
    """Index of a topic in sequences[track], or None.

    topic_track/grade narrow the match: sequences["ח"] lists both
    (ז, transformations) and (ח, transformations)."""
    for i, e in enumerate(sequence(track)):
        if e.get("topic") != topic_id:
            continue
        if topic_track is not None and e.get("track") != topic_track:
            continue
        if grade is not None and str(e.get("grade")) != str(grade):
            continue
        return i
    return None


def position(grade, track, topic_id, subtopic_id):
    """(grade, topic index in sequences[track], subtopic order) -- comparable.

    subtopic_id None means "from the start of the topic" (order 0); a topic
    that is not in the track's sequence gives None (the caller decides: for
    grade 9 that is the not-in-track case)."""
    g = int(str(grade))
    ti = topic_index(track, topic_id, grade=g)
    if ti is None:
        ti = topic_index(track, topic_id)
    if ti is None:
        return None
    order = 0
    if subtopic_id:
        e = get(subtopic_id)
        if e is None:
            return None
        order = e.get("order", 0)
    return (g, ti, order)


def track_for(grade, level_key, sheet=None):
    """The curriculum track a level is checked against.

    Grades 7 and 8 have one track each (ז, ח). In grade 9 the house maps
    levels to tracks (curriculum_tashpaz tracks.*.house_level_mapping:
    ט_רגילה = רמה א׳ + מצוינות, ט_מצומצמת = רמה ב׳), so by default level b
    is ט_מצומצמת and a/c are ט_רגילה. SHEET may override:
      * SHEET["track_by_level"] = {"a": .., "b": .., "c": ..}  explicit;
      * SHEET["track"] = {"a": .., ...}                         same, inline;
      * SHEET["track"] = "ט_מצומצמת"   a sheet written for the reduced track:
                                       every level is ט_מצומצמת.
    Any other SHEET["track"] string keeps the default mapping. (Decision
    recorded for Noam: the default is a house rule, not an MoE rule.)"""
    g = str(grade)
    sheet = sheet or {}
    by_level = sheet.get("track_by_level")
    tr = sheet.get("track")
    if isinstance(tr, dict):
        by_level = tr
    if isinstance(by_level, dict) and by_level.get(level_key):
        return by_level[level_key]
    if g == "9":
        if tr == GRADE9_REDUCED:
            return GRADE9_REDUCED
        return GRADE9_REDUCED if level_key == "b" else GRADE9_REGULAR
    if isinstance(tr, str) and tr:
        return tr
    return {"7": u"ז", "8": u"ח"}.get(g, tr)


def not_in_track(track):
    """Everything the curriculum says a track does not teach:
    [{"topic", "keywords", "basis"}] from tracks[track].excluded and from the
    registry meta.not_in_track (whose topics are named, without keywords: the
    topic name itself is then the keyword)."""
    out = []
    cur = load_curriculum()
    for x in (cur.get("tracks", {}).get(track, {}) or {}).get("excluded", []) or []:
        out.append({"topic": x.get("topic"), "keywords": list(x.get("keywords") or []),
                    "basis": x.get("basis")})
    meta = load_registry().get("meta", {})
    for x in (meta.get("not_in_track") or {}).get(track, []) or []:
        t = x.get("topic")
        if not any(o["topic"] == t for o in out):
            out.append({"topic": t, "keywords": [t] if t else [], "basis": x.get("basis")})
    return out


def track_topics(track):
    """The topic ids taught in a track (curriculum_tashpaz tracks[track].topics)."""
    return [t.get("id") for t in
            (load_curriculum().get("tracks", {}).get(track, {}) or {}).get("topics", [])]


_TRACK_GRADE = {u"ז": "7", u"ח": "8", GRADE9_REGULAR: "9", GRADE9_REDUCED: "9"}


def grade_of_track(track):
    """"7" | "8" | "9" for a curriculum track name, or None (unknown track)."""
    return _TRACK_GRADE.get(track)


def tracks_for_grade(grade):
    """The track names a sheet of `grade` may declare (grade 9 has two)."""
    g = str(grade)
    return [t for t, tg in sorted(_TRACK_GRADE.items(), key=lambda x: x[1]) if tg == g]


# a tool id quoted inside a not_in_track "basis" text, e.g. "thm.parallel_converse"
_TOOL_ID = re.compile(r"(?<![A-Za-z0-9_.])[a-z][a-z0-9_]*\.[a-z0-9_.]*[a-z0-9_]")


def not_in_track_reasons(track, subtopic_id, _seen=None):
    """Why `track` does not teach a subtopic registered under another track:
    a list of reasons, empty when the not-in-track lists do not cover it.

    WHY THIS EXISTS: a grade-9 ט_רגילה sheet is checked in level b against
    ט_מצומצמת (house mapping). Most ט_רגילה topic ids simply do not exist in
    ט_מצומצמת (parallels_trapezoid there is parallels_and_parallelogram), so
    "topic not in sequences[track]" says nothing about whether the track
    teaches the content. Only the curriculum's own not-in-track lists may turn
    that into a FAIL, so a subtopic is covered when
      * a keyword of tracks[track].excluded / registry meta.not_in_track[track]
        occurs in its title, its aliases or the preferred form of a term it
        introduces (e.g. alias 'חוקי חזקות'), or
      * the entry's basis quotes a tool id the subtopic introduces
        (basis 'thm.parallel_converse רק ב־ט_רגילה'), or
      * it requires (registry "requires", transitively) a subtopic that is
        covered: what builds on an untaught subtopic is not taught either
        (quotient_same_base requires product_same_base = 'חוקי חזקות').
    The caller treats an uncovered subtopic without a declared equivalent as
    REVIEW, never as FAIL."""
    seen = set() if _seen is None else _seen
    if subtopic_id in seen:
        return []
    seen.add(subtopic_id)
    e = get(subtopic_id)
    if e is None:
        return []
    texts = [(u"title", e.get("title"))] + [(u"alias", a) for a in e.get("aliases") or []]
    intro = e.get("introduces") or {}
    for tk in intro.get("terms") or []:
        t = term(tk) or {}
        if t.get("preferred"):
            texts.append((u"term %s" % tk, t["preferred"]))
    tools = set(intro.get("tools") or [])
    out = []
    for x in not_in_track(track):
        hit = None
        for kw in x["keywords"]:
            if not kw:
                continue
            rx = compile_term(literal_pattern(kw))
            for where, txt in texts:
                if txt and rx.search(normalize(txt)):
                    hit = u"its %s '%s' names '%s'" % (where, txt, kw)
                    break
            if hit:
                break
        if not hit:
            quoted = set(_TOOL_ID.findall(u"%s" % (x.get("basis") or u""))) & tools
            if quoted:
                hit = u"the entry's basis quotes tool %s, which it introduces" % sorted(quoted)[0]
        if hit:
            out.append(u"%s does not teach '%s' (%s)" % (track, x["topic"], hit))
    if not out:
        for req in e.get("requires") or []:
            sub = not_in_track_reasons(track, req, seen)
            if sub:
                out.append(u"it requires %s, and %s" % (req, sub[0]))
                break
    return out


def equivalent_position(grade, track, subtopic_id):
    """(position, why) of a subtopic in a track that does not list its topic,
    from an EXPLICIT equivalence only, or (None, None):
      * registry entry "equivalent_by_track": {track: subtopic id of that track}
        (optional field, absent from the registry today);
      * allowed_from_by_track[track] of the glossary terms the subtopic
        introduces: the curriculum places those terms in that track, so the
        section sits at least there (the latest such place wins).
    No guessing from titles or aliases: a wrong place would silently pass or
    fail every term of the section."""
    e = get(subtopic_id)
    if e is None:
        return None, None
    g = int(str(grade))
    eq = (e.get("equivalent_by_track") or {}).get(track)
    if eq:
        loc = locate(eq)
        if loc is not None:
            p = position(grade, track, loc[1], eq)
            if p is not None:
                return p, u"registry equivalent_by_track[%s] = %s" % (track, eq)
    best, why = None, None
    for tk in (e.get("introduces") or {}).get("terms") or []:
        af = ((term(tk) or {}).get("allowed_from_by_track") or {}).get(track)
        if not af or str(af.get("grade")) != str(g) or not af.get("topic"):
            continue
        ti = topic_index(track, af["topic"], grade=g)
        if ti is None:
            continue
        order = 0
        if af.get("subtopic"):
            se = get(af["subtopic"])
            order = se.get("order", 0) if se else 0
        p = (g, ti, order)
        if best is None or p > best:
            best, why = p, u"allowed_from_by_track[%s] of term %s (%s)" % (track, tk, _af_desc(af))
    return best, why


# ---------------------------------------------------------------- volume ---
def volume_policy():
    return load_curriculum()["coverage_policy"]["volume_policy"]


def volume_rule():
    """The unchanged v7 volume_rule (2-6 sub-items, mean 3, broad floors)."""
    return load_curriculum()["coverage_policy"]["volume_rule"]


def volume_range(kind_or_size):
    """(lo, hi) main questions per level for "S" | "M" | "L" | "combo" |
    "single_S_sheet", read from coverage_policy.volume_policy."""
    rng = volume_policy()["main_questions_per_level"][kind_or_size]
    return (int(rng[0]), int(rng[1]))


# -------------------------------------------------------------- matching ---
def normalize(text):
    """The glossary's matching normalisation (see the module docstring)."""
    if text is None:
        return u""
    return unicodedata.normalize("NFC", u"%s" % text).translate(_STRIP)


def compile_term(pattern):
    """A glossary pattern inside the contract's Hebrew word-boundary wrapper."""
    key = ("__re__", pattern)
    if key not in _cache:
        g = load_glossary()
        tpl = g.get("matching", {}).get("compile") or \
            u"(?<![א-ת])(?:[ובכלמשה]{0,3})(?:<pattern>)(?![א-ת])"
        pre = g.get("hebrew_prefixes")
        if pre:
            tpl = tpl.replace(u"[ובכלמשה]{0,3}", pre, 1)
        _cache[key] = re.compile(tpl.replace(u"<pattern>", pattern))
    return _cache[key]


def literal_pattern(phrase):
    """A plain phrase (a not-in-track keyword) as a glossary-style pattern:
    escaped, with the glossary word separator between words."""
    sep = load_glossary().get("matching", {}).get("word_separator", u"[\\s־-]+ between")
    sep = sep.split(u" ")[0] or u"[\\s־-]+"
    words = [re.escape(w) for w in re.split(u"[\\s־-]+", normalize(phrase).strip()) if w]
    return sep.join(words)


def _term_patterns():
    key = ("__terms__",)
    if key not in _cache:
        out = []
        for tk, t in load_glossary().get("terms", {}).items():
            for p in t.get("patterns") or []:
                out.append((tk, compile_term(p)))
        _cache[key] = out
    return _cache[key]


def find_terms(text):
    """[(term_key, match_text, (start, end))] for every glossary term match.

    Each term is matched on its own: when two terms match the same words both
    are returned (the glossary rule: each must be allowed). Duplicate spans of
    one term (two patterns hitting the same words) are reported once. Spans
    index normalize(text)."""
    s = normalize(text)
    seen = set()
    out = []
    for tk, rx in _term_patterns():
        for m in rx.finditer(s):
            if m.end() == m.start():
                continue
            k = (tk, m.start(), m.end())
            if k in seen:
                continue
            seen.add(k)
            out.append((tk, m.group(0), (m.start(), m.end())))
    out.sort(key=lambda x: (x[2][0], x[0]))
    return out


def forbidden_hits(text, grade):
    """glossary.forbidden matches for a sheet of `grade`:
    [{"id", "match", "span", "use_instead", "reason"}] (spans on normalize(text))."""
    s = normalize(text)
    g = str(grade)
    out = []
    for f in load_glossary().get("forbidden", []):
        grades = [str(x) for x in ((f.get("scope") or {}).get("grades") or [])]
        if grades and g not in grades:
            continue
        for m in compile_term(f["pattern"]).finditer(s):
            if m.end() == m.start():
                continue
            out.append({"id": f.get("id"), "match": m.group(0), "span": (m.start(), m.end()),
                        "use_instead": f.get("use_instead"), "reason": f.get("reason")})
    return out


def house_spelling_patterns():
    hs = load_glossary().get("house_spelling") or {}
    pats = list(hs.get("forbidden_patterns") or [])
    # forbidden_forms is documented as a subset of forbidden_patterns; the
    # union costs nothing and survives a later edit that forgets one side.
    pats += [literal_pattern(w) for w in hs.get("forbidden_forms") or []]
    return pats


def house_spelling_applies(scope):
    hs = load_glossary().get("house_spelling") or {}
    return scope in (hs.get("applies_to_scope") or [])


def house_spelling_hits(text):
    """house_spelling forbidden forms: [{"match", "span", "preferred"}].
    The caller decides whether the rule applies (SHEET.scope)."""
    s = normalize(text)
    hs = load_glossary().get("house_spelling") or {}
    spans = {}
    for p in house_spelling_patterns():
        for m in compile_term(p).finditer(s):
            if m.end() == m.start():
                continue
            spans.setdefault((m.start(), m.end()), m.group(0))
    # keep only maximal spans (a literal form inside a longer pattern match)
    keys = sorted(spans)
    out = []
    for a, b in keys:
        if any(x <= a and b <= y and (x, y) != (a, b) for x, y in keys):
            continue
        out.append({"match": spans[(a, b)], "span": (a, b), "preferred": hs.get("preferred")})
    return out


def not_in_track_hits(text, track):
    """Keyword hits of everything `track` does not teach:
    [{"topic", "match", "span", "basis"}]."""
    s = normalize(text)
    out = []
    for x in not_in_track(track):
        for kw in x["keywords"]:
            if not kw:
                continue
            for m in compile_term(literal_pattern(kw)).finditer(s):
                out.append({"topic": x["topic"], "match": m.group(0),
                            "span": (m.start(), m.end()), "basis": x["basis"]})
    return out


# ------------------------------------------------------------ chronology ---
def term(term_key):
    return load_glossary().get("terms", {}).get(term_key)


def allowed_from_for(term_key, track):
    """The allowed_from that governs a term in `track`
    (allowed_from_by_track[track] when present)."""
    t = term(term_key) or {}
    bt = t.get("allowed_from_by_track") or {}
    return bt.get(track) or t.get("allowed_from")


def term_allowed(term_key, grade, track, pos):
    """(allowed: bool, why: str) -- may `term_key` be printed at `pos`?

    pos is position(grade, track, topic, subtopic) of the section, or None for
    "the end of the grade" (unknown topic). Rules (glossary terms_rule):
      * allowed_from.grade <= 8 (elementary included) holds for every later
        grade and every track;
      * a grade-9 allowed_from holds only in its own track unless
        allowed_from_by_track names the other track;
      * same grade: compare (topic index in sequences[track], subtopic order);
        topic null = from the start of that grade, subtopic null = from the
        start of the topic;
      * a higher grade (10 = high school) is never allowed."""
    af = allowed_from_for(term_key, track)
    if not af:
        return True, "no allowed_from"
    try:
        ga = int(str(af.get("grade")))
    except (TypeError, ValueError):
        return False, "allowed_from.grade %r is not a number" % (af.get("grade"),)
    gs = int(str(grade))
    desc = _af_desc(af)
    if ga < gs:
        if ga <= 8:
            return True, desc
        return True, desc
    if ga > gs:
        return False, "allowed from %s, the section is grade %d" % (desc, gs)
    if ga == 9 and af.get("track") != track:
        return False, "allowed from %s only (track %s), the level is %s" % (
            desc, af.get("track"), track)
    if af.get("topic") is None:
        return True, desc
    if pos is None:
        return False, "allowed from %s; the section's topic is not in %s" % (desc, track)
    ti = topic_index(track, af["topic"], grade=ga, topic_track=af.get("track"))
    if ti is None:
        ti = topic_index(track, af["topic"], grade=ga)
    if ti is None:
        return False, "allowed from %s, a topic that is not in sequences[%s]" % (desc, track)
    if ti < pos[1]:
        return True, desc
    if ti > pos[1]:
        return False, "allowed from %s (topic #%d), the section is topic #%d" % (desc, ti, pos[1])
    sub = af.get("subtopic")
    if not sub:
        return True, desc
    e = get(sub)
    if e is None:
        return False, "allowed from subtopic %s, which the registry lacks" % sub
    if e.get("order", 0) <= pos[2]:
        return True, desc
    return False, "allowed from %s (order %s), the section is order %s" % (
        desc, e.get("order"), pos[2])


def _af_desc(af):
    parts = [u"grade %s" % af.get("grade")]
    if af.get("track"):
        parts.append(u"%s" % af.get("track"))
    if af.get("topic"):
        parts.append(u"%s" % af.get("topic"))
    if af.get("subtopic"):
        parts.append(u"%s" % af.get("subtopic"))
    return u"/".join(parts)


def terms_introduced_by(subtopic_id):
    """Glossary keys a subtopic introduces: registry introduces.terms plus
    every term whose allowed_from names this subtopic."""
    keys = set()
    e = get(subtopic_id)
    if e:
        keys.update((e.get("introduces") or {}).get("terms") or [])
    for tk, t in load_glossary().get("terms", {}).items():
        afs = [t.get("allowed_from") or {}] + list((t.get("allowed_from_by_track") or {}).values())
        if any((a or {}).get("subtopic") == subtopic_id for a in afs):
            keys.add(tk)
    return keys


# -------------------------------------------------------------- selftest ---
def selftest():
    """Offline checks against the real data files (no build, < 1 s)."""
    fails = []

    def ok(cond, msg):
        if not cond:
            fails.append(msg)

    reset_cache()
    # normalisation
    ok(normalize(u"שִׁתֵּי זָוִיּוֹת") == u"שתי זויות", "niqqud not stripped")
    ok(normalize(u"חד־צדדיות") == u"חד־צדדיות", "maqaf must stay")
    ok(normalize(u"זוויות‍ צמודות‏") == u"זוויות צמודות", "invisible marks stay")
    ok(normalize(u"ז'") == u"ז׳" and normalize(u'תשפ"ז') == u"תשפ״ז", "geresh")
    ok(normalize(u"a⁠b‎с") == u"abс", "U+2060/U+200E")
    # registry
    reg = load_registry()
    ok(reg["meta"]["schema"] == "noam-subtopics/v1", "registry schema")
    e = get("st.g7.angles.vertical")
    ok(e is not None and e["size_class"] == "S" and e["order"] == 8, "get(vertical)")
    ok(get("st.nope") is None, "get(unknown) must be None")
    ok(locate("st.g7.angles.adjacent")[:2] == (u"ז", "angles"), "locate")
    ords = [x["order"] for x in entries(u"ז", "angles")]
    ok(ords == sorted(ords) and len(ords) >= 12, "entries order")
    p_adj = position("7", u"ז", "angles", "st.g7.angles.adjacent")
    p_ver = position("7", u"ז", "angles", "st.g7.angles.vertical")
    ok(p_adj is not None and p_adj < p_ver, "position order adj < vert")
    ok(position("7", u"ז", "angles", None)[2] == 0, "subtopic None -> order 0")
    ok(position("9", GRADE9_REDUCED, "powers", "st.g9r.powers.product_same_base") is None,
       "powers is not in ט_מצומצמת")
    ok(position("9", GRADE9_REGULAR, "powers", "st.g9r.powers.product_same_base") is not None,
       "powers is in ט_רגילה")
    # volume
    ok(volume_range("S") == (3, 5) and volume_range("combo") == (2, 4) and
       volume_range("single_S_sheet") == (4, 8) and volume_range("M") == (5, 8) and
       volume_range("L") == (8, 12), "volume ranges")
    vr = volume_rule()
    ok(vr["min_main_questions_general"] == 20 and vr["min_total_subitems_geometry"] == 42,
       "volume_rule floors")
    # tracks
    ok(track_for("9", "b", {"track": GRADE9_REGULAR}) == GRADE9_REDUCED, "9b default")
    ok(track_for("9", "a", {"track": GRADE9_REGULAR}) == GRADE9_REGULAR, "9a default")
    ok(track_for("9", "a", {"track": GRADE9_REDUCED}) == GRADE9_REDUCED, "reduced sheet")
    ok(track_for("9", "b", {"track_by_level": {"b": GRADE9_REGULAR}}) == GRADE9_REGULAR,
       "explicit override")
    ok(track_for("7", "b", {"track": u"ז"}) == u"ז", "grade 7")
    ok(any(h["topic"] == u"חוקי חזקות" for h in not_in_track_hits(u"נשתמש בחוקי החזקות", GRADE9_REDUCED)),
       "not-in-track keyword")
    # glossary vectors: every forbidden/house/term test in the glossary itself
    g = load_glossary()
    for f in g["forbidden"]:
        rx = compile_term(f["pattern"])
        for s in f.get("tests", {}).get("match", []):
            ok(rx.search(normalize(s)), "forbidden %s should match %r" % (f["id"], s))
        for s in f.get("tests", {}).get("no_match", []):
            ok(not rx.search(normalize(s)), "forbidden %s should not match %r" % (f["id"], s))
    hs = g["house_spelling"]
    for s in hs["tests"]["match"]:
        ok(house_spelling_hits(s), "house spelling should match %r" % s)
    for s in hs["tests"]["no_match"]:
        ok(not house_spelling_hits(s), "house spelling should not match %r" % s)
    for s in g["tests"]["must_not_match_any_forbidden"]:
        ok(not forbidden_hits(s, "7") and not house_spelling_hits(s),
           "must_not_match_any_forbidden: %r" % s)
    for tk, t in g["terms"].items():
        for s in (t.get("tests") or {}).get("match", []):
            ok(any(x[0] == tk for x in find_terms(s)), "term %s should match %r" % (tk, s))
        for s in (t.get("tests") or {}).get("no_match", []):
            ok(not any(x[0] == tk for x in find_terms(s)), "term %s should not match %r" % (tk, s))
    ok(forbidden_hits(u"זוויות נשלמות", "7")[0]["id"] == "nishlamot", "nishlamot hit")
    ok(not forbidden_hits(u"הזוויות משלימות.", "8"), "mashlimot is grade 7 only")
    ok(forbidden_hits(u"הזוויות משלימות.", "7"), "mashlimot in grade 7")
    ok(forbidden_hits(u"זוויות‍ נשלמות", "9"), "invisible mark must not hide a term")
    # chronology
    pv = position("7", u"ז", "angles", "st.g7.angles.vertical")
    pa = position("7", u"ז", "angles", "st.g7.angles.adjacent")
    ok(term_allowed("adjacent_angles", "7", u"ז", pv)[0], "adjacent ok in vertical")
    ok(not term_allowed("vertical_angles", "7", u"ז", pa)[0], "vertical not ok in adjacent")
    ok(term_allowed("angle", "7", u"ז", pa)[0], "elementary term")
    ok(not term_allowed("exterior_angle", "7", u"ז", pv)[0], "grade-8 term in grade 7")
    ok(term_allowed("exterior_angle", "9", GRADE9_REDUCED, None)[0], "grade-8 term in grade 9")
    ok(not term_allowed("high_school_only", "9", GRADE9_REGULAR,
                        position("9", GRADE9_REGULAR, "powers", None))[0], "grade 10")
    pp = position("9", GRADE9_REGULAR, "powers", "st.g9r.powers.product_same_base")
    ok(term_allowed("power_laws", "9", GRADE9_REGULAR, pp)[0], "power_laws in 9r")
    ok(not term_allowed("power_laws", "9", GRADE9_REDUCED, None)[0], "power_laws not in 9m")
    pn = position("9", GRADE9_REGULAR, "powers", "st.g9r.powers.natural_review")
    ok(not term_allowed("power_laws", "9", GRADE9_REGULAR, pn)[0], "power_laws before order 3")
    ok(term_allowed("parabola", "9", GRADE9_REDUCED,
                    position("9", GRADE9_REDUCED, "quad_partial", None))[0], "by_track")
    ok(not term_allowed("congruent_shapes", "7", u"ז", pa)[0],
       "transformations come after angles in sequences[ז]")
    ok("vertical_angles" in terms_introduced_by("st.g7.angles.vertical"), "introduced terms")
    # tracks of a grade, grade of a track
    ok(grade_of_track(u"ז") == "7" and grade_of_track(GRADE9_REDUCED) == "9" and
       grade_of_track(u"x") is None, "grade_of_track")
    ok(tracks_for_grade("7") == [u"ז"] and set(tracks_for_grade(9)) == {GRADE9_REGULAR, GRADE9_REDUCED},
       "tracks_for_grade")
    # which ט_רגילה subtopics ט_מצומצמת does not teach (review 2026-11-09: only the
    # not-in-track lists may say so; a missing topic id alone must not)
    R = GRADE9_REDUCED
    ok(not_in_track_reasons(R, "st.g9r.parallels_trapezoid.converse"), "converse not in 9m")
    ok(not_in_track_reasons(R, "st.g9r.parallels_trapezoid.co_interior"), "co-interior not in 9m")
    ok(not_in_track_reasons(R, "st.g9r.powers.product_same_base"), "power laws not in 9m")
    ok(any("requires" in x for x in not_in_track_reasons(R, "st.g9r.powers.quotient_same_base")),
       "quotient law: via requires")
    ok(any("thm.parallel_converse" in x or u"משפט הפוך" in x
           for x in not_in_track_reasons(R, "st.g9r.parallels_trapezoid.converse")), "converse reason")
    for sid in ("st.g9r.parallels_trapezoid.properties", "st.g9r.parallels_trapezoid.alternate_corresponding",
                "st.g9r.powers.natural_review"):
        ok(not not_in_track_reasons(R, sid), "%s must not be 'not in track' for 9m" % sid)
    ok(equivalent_position("9", R, "st.g9r.parallels_trapezoid.properties") == (None, None),
       "no invented equivalence")
    for f in fails:
        print("FAIL", f)
    print("subtopics selftest: %s (%d failure(s))" % ("PASS" if not fails else "FAIL", len(fails)))
    return not fails


if __name__ == "__main__":
    if "--selftest" in sys.argv[1:]:
        sys.exit(0 if selftest() else 1)
    print(__doc__)
