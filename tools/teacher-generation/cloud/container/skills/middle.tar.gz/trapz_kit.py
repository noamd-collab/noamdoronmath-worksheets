# -*- coding: utf-8 -*-
r"""trapz_kit — parametric trapezoid figures drawn FROM THE NUMBERS.

WHY THIS FILE EXISTS (Noam, Sep 2026, טרפז review).
The shipped טרפז package reused ONE fixed SVG template for every question at
every level and only swapped the labels.  Two consequences, both visible to a
customer at a glance:

  * every figure on every page looked identical — three levels, eight
    questions each, one shape;
  * the shape did not match its own givens.  רמה א׳ Q1 declares bases 9 and
    12 (ratio 0.75) and draws 88px over 178px — **ratio 0.49, off by 34%**.
    A student who measures the drawing gets a different sheet from the one
    they read, which is exactly the failure §3e (LAW OF THE MEASURED FIGURE)
    was written to stop.

So geometry here is COMPUTED, never posed: give `trapezoid()` the real a, b, h
and it lays out the polygon to scale, then ASSERTS the drawn proportions
against the givens before it will emit a single byte.  Variety is a parameter
(`kind`, `rotate`, `flip`), not a second template — a template you copy is a
template you will forget to re-measure.

SVG carries GEOMETRY ONLY (G49): WeasyPrint does not run the bidi algorithm
inside <svg><text>, so a Hebrew label prints reversed.  Vertex letters, Latin
variables and numerals only; Hebrew captions go in HTML beneath the figure.

    from trapz_kit import trapezoid, quad_from_angles, grid_quad

    trapezoid(12, 9, 8, kind="scalene", lab=dict(a="12", b="9", h="h"))
    trapezoid(14, 8, 5, kind="iso", rotate=180, angles={"A": "59°"})
    trapezoid(10, 6, 4, kind="right-l", diagonals=True)
"""
import math
import re

INK = "#111"
HEB = range(0x0590, 0x0600)
_TOL = 0.02          # drawn-vs-given proportion tolerance (§3e)
_SCALENE_MIN = 0.12  # 3b-iso: |AD-BC| / max, for a NON-isosceles trapezoid


# --------------------------------------------------------------- helpers ---
def _rot(p, deg, c):
    t = math.radians(deg)
    x, y = p[0] - c[0], p[1] - c[1]
    return (c[0] + x * math.cos(t) - y * math.sin(t),
            c[1] + x * math.sin(t) + y * math.cos(t))


def _mid(p, q):
    return ((p[0] + q[0]) / 2, (p[1] + q[1]) / 2)


def _dist(p, q):
    return math.hypot(p[0] - q[0], p[1] - q[1])


def _seg_dist(p, a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    L2 = dx * dx + dy * dy
    if L2 == 0:
        return _dist(p, a)
    t = max(0.0, min(1.0, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / L2))
    return math.hypot(p[0] - (a[0] + t * dx), p[1] - (a[1] + t * dy))


def _line_dist(p, a, b):
    """Distance to the INFINITE line ab. _seg_dist clamps to the segment, so
    it silently returns the wrong number for a flipped trapezoid whose apex
    projects past the end of the short base — which is how the height gate
    failed on a figure that was actually correct."""
    dx, dy = b[0] - a[0], b[1] - a[1]
    L = math.hypot(dx, dy) or 1.0
    return abs(dx * (a[1] - p[1]) - dy * (a[0] - p[0])) / L


def _seg_box_hit(p, q, box, pad):
    """Segment p-q within `pad` of the axis-aligned box (x0, y0, x1, y1)."""
    x0, y0, x1, y1 = box[0] - pad, box[1] - pad, box[2] + pad, box[3] + pad
    if max(p[0], q[0]) < x0 or min(p[0], q[0]) > x1 or \
            max(p[1], q[1]) < y0 or min(p[1], q[1]) > y1:
        return False
    dx, dy = q[0] - p[0], q[1] - p[1]
    t0, t1 = 0.0, 1.0
    for pk, qk in ((-dx, p[0] - x0), (dx, x1 - p[0]),
                   (-dy, p[1] - y0), (dy, y1 - p[1])):
        if abs(pk) < 1e-12:
            if qk < 0:
                return False
        else:
            t = qk / pk
            if pk < 0:
                t0 = max(t0, t)
            else:
                t1 = min(t1, t)
            if t0 > t1:
                return False
    return True


def _outward(pts, i, j):
    """Unit normal of edge i→j pointing AWAY from the polygon centroid."""
    p, q = pts[i], pts[j]
    cx = sum(a[0] for a in pts) / len(pts)
    cy = sum(a[1] for a in pts) / len(pts)
    m = _mid(p, q)
    nx, ny = -(q[1] - p[1]), (q[0] - p[0])
    L = math.hypot(nx, ny) or 1.0
    nx, ny = nx / L, ny / L
    if (m[0] - cx) * nx + (m[1] - cy) * ny < 0:
        nx, ny = -nx, -ny
    return nx, ny


def assert_no_hebrew(svg):
    bad = sorted({c for c in svg if ord(c) in HEB})
    if bad:
        raise AssertionError("Hebrew inside SVG (G49): %r" % "".join(bad))
    return svg


# ------------------------------------------------------------- the canvas --
class _Canvas:
    """Collects primitives in FINAL pixel space, then self-checks label
    clearance (§3b-QA) before rendering."""

    def __init__(self, w, h):
        self.w, self.h, self.parts = w, h, []
        self.segs, self.labs = [], []
        self.owners = []
        # Running ink bbox. G63 caught a vertex letter pushed 24px out by an
        # angle mark and straight off the canvas: the polygon fitted the
        # padding, the LABEL did not. Sizing from the polygon alone cannot
        # see that, so every primitive reports its extent and render() fits
        # the canvas to the ink — never the other way round.
        self.bb = [1e9, 1e9, -1e9, -1e9]

    def _grow(self, x0, y0, x1=None, y1=None):
        x1 = x0 if x1 is None else x1
        y1 = y0 if y1 is None else y1
        self.bb[0] = min(self.bb[0], x0, x1)
        self.bb[1] = min(self.bb[1], y0, y1)
        self.bb[2] = max(self.bb[2], x0, x1)
        self.bb[3] = max(self.bb[3], y0, y1)

    def poly(self, pts, width=1.5, dash=None, fill="none"):
        self.parts.append(("poly", list(pts), width, dash, fill))
        for k in range(len(pts)):
            self.segs.append((pts[k], pts[(k + 1) % len(pts)]))
        for p in pts:
            self._grow(p[0], p[1])

    def line(self, p, q, width=1.2, dash=None, record=True):
        self.parts.append(("line", [p, q], width, dash, None))
        if record:
            self.segs.append((p, q))
        self._grow(p[0], p[1], q[0], q[1])

    def text(self, p, s, size=13, italic=False, value=False, owner=None,
             alts=None):
        self.parts.append(("text", [p], size, italic, s))
        self.labs.append((p, s, value))
        # C3 r2 (E24): a length written beside its side is judged at render by
        # svgcheck.label_ownership, like every figkit value label.
        # C3 r3: `alts` -- other baseline positions, in order of preference,
        # the label may move to when the finished drawing reads it as another
        # stroke's (render() tries them; the label is never dropped)
        if owner is not None:
            self.owners.append([s, owner, p, size, list(alts or ())])
        w = 0.62 * size * max(1, len(s))
        self._grow(p[0] - w / 2, p[1] - size, p[0] + w / 2, p[1] + 0.30 * size)

    def _svg_owners(self, svg_T):
        return [(t.replace("-", "\u2212"), (svg_T(a), svg_T(b)),
                 (svg_T(p)[0], svg_T(p)[1] - 0.35 * size))
                for t, (a, b), p, size, _ in self.owners]

    def _move_label(self, k, q):
        """Move owned label k to baseline q, in parts, labs and owners."""
        t, own, p, size, alts = self.owners[k]
        for n, part in enumerate(self.parts):
            if part[0] == "text" and part[4] == t and part[1][0] == p:
                self.parts[n] = ("text", [q], part[2], part[3], part[4])
                break
        for n, lab in enumerate(self.labs):
            if lab[1] == t and lab[0] == p:
                self.labs[n] = (q, lab[1], lab[2])
                break
        self.owners[k][2] = q

    def _fits(self, k, q):
        """check()'s own rules for a moved label: 17px from every other
        label, its anchor 8px off every recorded stroke."""
        t, _, p, _, _ = self.owners[k]
        if any(_dist(q, lp) < 17 for lp, s_, _ in self.labs
               if not (s_ == t and lp == p)):
            return False
        return all(_seg_dist((q[0], q[1] - 4), a, b) >= 8 for a, b in self.segs)

    def _own_labels(self):
        """C3 r3: every owned label the finished drawing reads as another
        stroke's moves to the first of its alternatives that it owns. A
        trapezoid's labels were written at fixed offsets, so '2' beside a
        short height, next to the right-angle mark and the base, had nowhere
        to go and the only escape left to an author was dropping it."""
        import svgcheck
        for k in range(len(self.owners)):
            def bad():
                svg, T = self._assemble()
                return svgcheck.label_ownership(svg, [self._svg_owners(T)[k]])
            if not bad():
                continue
            home = self.owners[k][2]
            for q in self.owners[k][4]:
                if not self._fits(k, q):
                    continue
                self._move_label(k, q)
                if not bad():
                    break
                self._move_label(k, home)
                home = self.owners[k][2]

    def unowned(self):
        """C3 r3: the owned labels still read as another stroke's after
        _own_labels() moved what it could: [(text, message)]."""
        import svgcheck
        self._own_labels()
        svg, T = self._assemble()
        own = self._svg_owners(T)
        return [(o[0], m) for o in own for m in svgcheck.label_ownership(svg, [o])]

    def right_angle(self, vertex, to1, to2, size=9):
        # v6 C3 (E5): a right-angle mark is measured before it is drawn
        v1 = (to1[0] - vertex[0], to1[1] - vertex[1])
        v2 = (to2[0] - vertex[0], to2[1] - vertex[1])
        n = (math.hypot(*v1) * math.hypot(*v2)) or 1.0
        ang = math.degrees(math.acos(max(-1.0, min(1.0, (v1[0] * v2[0] +
                                                         v1[1] * v2[1]) / n))))
        if abs(ang - 90.0) > 0.5:
            raise AssertionError(
                "trapz_kit: a right-angle mark on an angle of %.1f° -- the mark "
                "says 90°; put it where the angle is right" % ang)

        def u(a, b):
            L = _dist(a, b) or 1.0
            return ((b[0] - a[0]) / L, (b[1] - a[1]) / L)
        u1, u2 = u(vertex, to1), u(vertex, to2)
        p1 = (vertex[0] + u1[0] * size, vertex[1] + u1[1] * size)
        p3 = (vertex[0] + u2[0] * size, vertex[1] + u2[1] * size)
        p2 = (p1[0] + u2[0] * size, p1[1] + u2[1] * size)
        self.line(p1, p2, 1.1, record=False)
        self.line(p2, p3, 1.1, record=False)

    def arc(self, vertex, to1, to2, r=20, n=1):
        """Minor arc at `vertex`, bulging outward (§3b-arc)."""
        a1 = math.atan2(to1[1] - vertex[1], to1[0] - vertex[0])
        a2 = math.atan2(to2[1] - vertex[1], to2[0] - vertex[0])
        while a2 - a1 > math.pi:
            a1 += 2 * math.pi
        while a1 - a2 > math.pi:
            a2 += 2 * math.pi
        for i in range(n):
            rr = r + i * 4.5
            pts = [(vertex[0] + rr * math.cos(a1 + (a2 - a1) * k / 18),
                    vertex[1] + rr * math.sin(a1 + (a2 - a1) * k / 18))
                   for k in range(19)]
            self.parts.append(("path", pts, 1.2, None, None))
            for p in pts:
                self._grow(p[0], p[1])
        return (vertex[0] + (r + 13) * math.cos((a1 + a2) / 2),
                vertex[1] + (r + 13) * math.sin((a1 + a2) / 2))

    def clear_spot(self, vertex, anchor, txt, size, tries=12, step=3.0,
                   sides=None, poly=None):
        """v6: where an angle value can sit clear of the ink, as the finished
        SVG is read (svgcheck's box: 0.58 em per character, 0.78 ascent,
        0.24 descent, plus the stroke's half width). Walks outward along the
        bisector from the arc's own anchor and swings inside the angle; the
        value only moves off the edge, diagonal or arc that would cross it.
        Returns the baseline position for text().

        `sides=(to1, to2)`: the points the angle's two edges run to. The
        whole value box must then stay INSIDE that angle (between both edge
        lines) — a value swung past an edge prints outside the polygon and
        reads as the exterior angle. `poly`: the value's centre must also lie
        inside this polygon. A candidate closer than check()'s 17px to a
        label already placed is skipped. No spot → the arc's own anchor,
        which the render-time sweep then judges (loudly, never silently);
        with `sides` given, None, so the caller can draw the figure larger."""
        ink = []
        for kind, pts, a, b, c in self.parts:
            if kind == "poly":
                ink += [(pts[k], pts[(k + 1) % len(pts)], a)
                        for k in range(len(pts))]
            elif kind == "line":
                ink.append((pts[0], pts[1], a))
            elif kind == "path":
                ink += [(p, q, a) for p, q in zip(pts, pts[1:])]
        d = _dist(vertex, anchor) or 1.0
        a0 = math.atan2(anchor[1] - vertex[1], anchor[0] - vertex[0])
        w = max(len(txt), 1) * 0.58 * size

        def cross(u, v):
            return u[0] * v[1] - u[1] * v[0]

        def in_angle(pt):
            if not sides:
                return True
            u1 = (sides[0][0] - vertex[0], sides[0][1] - vertex[1])
            u2 = (sides[1][0] - vertex[0], sides[1][1] - vertex[1])
            p = (pt[0] - vertex[0], pt[1] - vertex[1])
            sg = cross(u1, u2)
            return cross(u1, p) * sg > 0 and cross(p, u2) * sg > 0

        def in_poly(pt):
            if not poly:
                return True
            n, inside = len(poly), False
            for k in range(n):
                (x1, y1), (x2, y2) = poly[k], poly[(k + 1) % n]
                if (y1 > pt[1]) != (y2 > pt[1]) and \
                        pt[0] < x1 + (pt[1] - y1) * (x2 - x1) / (y2 - y1):
                    inside = not inside
            return inside
        # swing inside the angle too: a diagonal from the vertex runs along
        # the bisector, and no distance out along it is ever clear
        swing = [0]
        for k in range(1, 8):
            swing += [6 * k, -6 * k]
        # no farther out than 45% of the shorter edge: beyond that a value
        # stops reading as this vertex's angle
        reach = 0.45 * min(_dist(vertex, q) for q in sides) if sides else 1e9
        for k in range(tries + 1):
            if k and d + step * k > reach:
                break
            for da in swing:
                th = a0 + math.radians(da)
                c = (vertex[0] + math.cos(th) * (d + step * k),
                     vertex[1] + math.sin(th) * (d + step * k))
                pos = (c[0], c[1] + 4)
                box = (pos[0] - w / 2, pos[1] - 0.78 * size,
                       pos[0] + w / 2, pos[1] + 0.24 * size)
                corners = [(box[0], box[1]), (box[2], box[1]),
                           (box[0], box[3]), (box[2], box[3])]
                if not all(in_angle(q) for q in corners) or \
                        not in_poly(((box[0] + box[2]) / 2,
                                     (box[1] + box[3]) / 2)):
                    continue
                if any(_dist(pos, lp) < 17 for lp, _, _ in self.labs):
                    continue
                # and check()'s own rule: the value's anchor 8px off a
                # recorded stroke
                if not any(_seg_box_hit(p, q, box, float(wd) / 2 + 0.6)
                           for p, q, wd in ink) and \
                        all(_seg_dist((pos[0], pos[1] - 4), p, q) >= 8
                            for p, q in self.segs):
                    return pos
        if sides:
            return None             # the caller enlarges the figure
        return (anchor[0], anchor[1] + 4)

    def check(self):
        """§3b-QA, enforced instead of documented. A value label touching a
        stroke misreads (`60°` on a diagonal renders as `-60°`); two labels
        on top of each other are unreadable. Vertex letters legitimately hug
        their edges, so only VALUE labels are swept against strokes."""
        for i in range(len(self.labs)):
            for j in range(i + 1, len(self.labs)):
                d = _dist(self.labs[i][0], self.labs[j][0])
                if d < 17:
                    raise AssertionError("labels %r/%r only %.1fpx apart"
                                         % (self.labs[i][1], self.labs[j][1], d))
        for p, s, val in self.labs:
            if not (val or re.search(r"[0-9°]", s)):
                continue
            anchor = (p[0], p[1] - 4)
            for a, b in self.segs:
                if _seg_dist(anchor, a, b) < 8:
                    raise AssertionError("value label %r sits on a stroke" % s)
        return self

    G63_CHAR_W = 0.56      # must match content_quality.CHAR_W
    G63_PAD = 2.0          # must match content_quality.PAD

    def _label_box(self, p, size, txt):
        w = max(len(txt), 1) * self.G63_CHAR_W * size
        return (p[0] - w / 2, p[1] - size, p[0] + w / 2, p[1] + 0.30 * size)

    def render(self, margin=8):
        self._own_labels()
        svg, T = self._assemble(margin)
        # v6 (E3/E29): the canvas's own check() measures label ANCHORS against
        # its records; the finished SVG is read back by the independent sweep
        # (struck runs, ASCII minus, printed floor, arrows, dots) like every
        # figkit figure. Imported here so svgcheck stays optional to import.
        import svgcheck
        owners = self._svg_owners(T)
        return svgcheck.assert_clean(svg, "trapz_kit._Canvas.render",
                                     owners=owners or None)

    def _assemble(self, margin=8):
        # G63 reads the RAW x/y of every <text> against the viewBox and knows
        # nothing about a <g transform>: wrapping the drawing in a translate
        # leaves the gate reading pre-shift coordinates and failing a figure
        # that is actually fine. So bake the offset into the numbers.
        bb = [1e9, 1e9, -1e9, -1e9]

        def grow(x0, y0, x1=None, y1=None):
            bb[0] = min(bb[0], x0, x1 if x1 is not None else x0)
            bb[1] = min(bb[1], y0, y1 if y1 is not None else y0)
            bb[2] = max(bb[2], x0, x1 if x1 is not None else x0)
            bb[3] = max(bb[3], y0, y1 if y1 is not None else y0)
        for kind, pts, a, b, c in self.parts:
            if kind == "text":
                grow(*self._label_box(pts[0], a, c))
            else:
                for p in pts:
                    grow(p[0], p[1])
        if bb[0] > bb[2]:
            bb = [0.0, 0.0, float(self.w), float(self.h)]
        margin = max(margin, self.G63_PAD + 3)
        dx, dy = margin - bb[0], margin - bb[1]
        W = math.ceil(bb[2] - bb[0] + 2 * margin)
        H = math.ceil(bb[3] - bb[1] + 2 * margin)

        def T(p):
            return (p[0] + dx, p[1] + dy)
        out = []
        for kind, pts, a, b, c in self.parts:
            d = ' stroke-dasharray="%s"' % b if b else ""
            if kind == "poly":
                out.append('<polygon points="%s" fill="%s" stroke="%s" '
                           'stroke-width="%s" stroke-linejoin="round"%s/>'
                           % (" ".join("%.1f,%.1f" % T(p) for p in pts),
                              c, INK, a, d))
            elif kind == "line":
                (x1_, y1_), (x2_, y2_) = T(pts[0]), T(pts[1])
                out.append('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" '
                           'stroke="%s" stroke-width="%s"%s/>'
                           % (x1_, y1_, x2_, y2_, INK, a, d))
            elif kind == "path":
                out.append('<path d="M %s" fill="none" stroke="%s" '
                           'stroke-width="%s"/>'
                           % (" L ".join("%.1f %.1f" % T(p) for p in pts),
                              INK, a))
            elif kind == "circle":
                x_, y_ = T(pts[0])
                out.append('<circle cx="%.1f" cy="%.1f" r="%s" fill="%s"/>'
                           % (x_, y_, a, INK))
            else:
                x_, y_ = T(pts[0])
                st = ' font-style="italic"' if b else ""
                out.append('<text x="%.1f" y="%.1f" font-size="%s" '
                           'text-anchor="middle" '
                           'font-family="David Libre, serif" fill="%s"%s>%s'
                           '</text>'
                           % (x_, y_, a, INK, st,
                              # v6 (E7): a figure prints U+2212, not '-'
                              c.replace("&", "&amp;").replace("<", "&lt;")
                              .replace("-", "\u2212")))
        svg = assert_no_hebrew(
            '<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" '
            'viewBox="0 0 %d %d" dir="ltr">%s</svg>'
            % (W, H, W, H, "".join(out)))
        return svg, T


# --------------------------------------------------------- the trapezoid ---
def _offsets(a, b, h, kind, base_angle=None):
    """Horizontal offset of the top-left vertex from the bottom-left one."""
    if kind == "angle":
        if base_angle is None:
            raise ValueError("kind='angle' needs base_angle=∡A in degrees")
        return h / math.tan(math.radians(base_angle))
    if kind == "iso":
        return (a - b) / 2.0
    if kind == "right-l":
        return 0.0
    if kind == "right-r":
        return a - b
    if kind == "scalene":
        return _solve_scalene(a, b, h)
    raise ValueError("unknown kind %r" % kind)


def _solve_scalene(a, b, h, want=0.16):
    """3b-iso, SOLVED rather than guessed.

    The obvious implementation — `ax = (a-b) * 0.16`, some fraction of the
    overhang — silently fails whenever the trapezoid is tall relative to the
    base difference: at a=12, b=9, h=8 both legs are ~8 wherever the top base
    sits, and they come out 4.4% apart. A reader sees an isosceles trapezoid;
    the answer key says it is not one.

    Solve for the offset instead, and keep the top base NESTED inside the
    bottom one (0 < ax < a-b) so the legs lean in opposite directions. The
    tempting fallback — let the top base overhang — was tried and rejected:
    it draws a shape that reads as a parallelogram, trading one wrong
    impression for another.

    Choose the LEAST extreme offset that still clears the threshold, and when
    no offset clears it, RAISE. Geometry is telling you the truth here: at
    these numbers no honest drawing is visibly scalene, so per the house
    doctrine you change the GIVENS (roughly, the base difference wants to be
    at least ~0.75h), not the picture."""
    d = a - b
    lo, hi = 0.05 * d, 0.95 * d
    best = None
    for i in range(401):
        ax = lo + (hi - lo) * i / 400
        ad, bc = math.hypot(ax, h), math.hypot(d - ax, h)
        con = abs(ad - bc) / max(ad, bc)
        if con < want:
            continue
        if best is None or con < best[0]:
            best = (con, ax)
    if best is None:
        need = 0.75 * h
        raise ValueError(
            "no visibly-scalene layout for a=%s b=%s h=%s: the base "
            "difference (%.3g) is too small next to the height. Widen it to "
            "about %.3g, or declare the shape honestly with "
            "kind='iso'/'right-l'/'right-r'." % (a, b, h, d, need))
    return best[1]


_GROW_MAX = 1.75     # v6: how far trapezoid() may enlarge itself (x its target)
_PROBE = []


def _tried_fix(kw, target):
    """v6 open issues (C3 trapz-named-target-untried, C1 r3): the fix a
    refusal names is TRIED first. 'pass target=460 or larger, or rotate the
    figure' was computed, never drawn, and 5 of 15 such refusals named a
    target that was itself refused. Returns the phrase for the message: the
    first larger target, rotation or flip that renders, or what was tried."""
    if _PROBE:
        return "a larger target= or a rotation"
    tries = [dict(kw, target=int(math.ceil(target * k / 10.0)) * 10)
             for k in (1.5, 2.0, 2.6)]
    tries += [dict(kw, rotate=(float(kw["rotate"]) + r) % 360, target=target)
              for r in (90, 270, 180)]
    tries += [dict(kw, flip=not kw["flip"], target=target)]
    _PROBE.append(1)
    try:
        for t in tries:
            k = dict(t)
            a, b, h = k.pop("a"), k.pop("b"), k.pop("h")
            try:
                trapezoid(a, b, h, **k)
            except AssertionError:
                continue
            if t["target"] != target:
                return "pass target=%d (tried: it renders)" % t["target"]
            if t["flip"] != kw["flip"]:
                return "pass flip=%r (tried: it renders)" % t["flip"]
            return "pass rotate=%g (tried: it renders)" % t["rotate"]
    finally:
        _PROBE.pop()
    return ("tried target=%d/%d/%d, rotate=+90/+180/+270 and flip=%r -- none "
            "renders it, so this shape at these proportions needs another "
            "layout: other label texts (lab=), or its crowded part drawn again "
            "in a second, magnified figure beside it"
            % (tries[0]["target"], tries[1]["target"], tries[2]["target"],
               not kw["flip"]))
                     # for an angle value: three steps of 1.2


def trapezoid(a, b, h, kind="scalene", rotate=0.0, flip=False, lab=None,
              names="ABCD", height_from=None, diagonals=False, midseg=None,
              angles=None, ticks=False, base_angle=None, diag=None,
              target=210, pad=30, _grown=0, fam=None):
    """A trapezoid drawn to scale from its real measurements.

    a  bottom base (AB)   b  top base (DC)   h  height
    kind      "scalene" | "iso" | "right-l" | "right-r" | "angle"
              "angle" lays the figure out from a GIVEN base angle ∡A
              (`base_angle=`) — for §3b-prove questions, where the drawn
              angles must be the given ones and the pair the student proves
              parallel must be the pair that is drawn parallel.
    rotate    degrees, counter-clockwise, about the centroid — the cheapest
              honest variety there is: same mathematics, different picture.
    flip      draw the SHORT base at the bottom (a genuinely different read;
              students who only ever meet "long base down" fail on it)
    lab       {"a": "12", "b": "9", "h": "h", "AD": "10", "BC": "…"}
    height_from  vertex letter ("D"/"C") — dashed height + ⊾ at the foot
    angles    {"A": "59°"} — arc at that vertex, value inside its angle.
              v6 C3 (E5): a numeric value ('59°', '112.5°') is checked against
              the DRAWN angle (to the precision it is written, +0.1): the
              selftest printed '72°' on a 59.04° angle and passed
    ticks     equality ticks on the legs AD and BC -- refused unless the legs
              are drawn equal (1.5%); a scalene kind's legs differ by 12%
    fam       v6 C3 (E10): tag the figure (figkit.tag)
    """
    lab, angles = lab or {}, angles or {}
    if b >= a:
        raise ValueError("b must be the SHORT base; got a=%s b=%s" % (a, b))
    if h <= 0:
        raise ValueError("height must be positive")
    ax = _offsets(a, b, h, kind, base_angle)

    # maths frame, y up
    A, B = (0.0, 0.0), (float(a), 0.0)
    D, C = (ax, float(h)), (ax + b, float(h))
    if flip:                       # short base down: reflect through mid-height
        A, B, D, C = (D[0], 0.0), (C[0], 0.0), (0.0, float(h)), (float(a), float(h))
    P = [A, B, C, D]

    if kind in ("scalene", "angle"):
        ad, bc = _dist(P[3], P[0]), _dist(P[1], P[2])
        if abs(ad - bc) / max(ad, bc) < _SCALENE_MIN:
            raise AssertionError("3b-iso: a non-isosceles trapezoid drawn "
                                 "near-symmetric (legs differ by %.1f%%)"
                                 % (100 * abs(ad - bc) / max(ad, bc)))

    c = (sum(p[0] for p in P) / 4, sum(p[1] for p in P) / 4)
    P = [_rot(p, rotate, c) for p in P]

    # -> pixel space (y down), scaled so the widest span hits `target`
    xs, ys = [p[0] for p in P], [p[1] for p in P]
    span = max(max(xs) - min(xs), max(ys) - min(ys)) or 1.0
    k = target / span
    W = (max(xs) - min(xs)) * k + 2 * pad
    H = (max(ys) - min(ys)) * k + 2 * pad
    P = [(pad + (p[0] - min(xs)) * k, H - pad - (p[1] - min(ys)) * k) for p in P]
    A, B, C, D = P
    cv = _Canvas(round(W), round(H))

    # §3e LAW OF THE MEASURED FIGURE — assert the DRAWING, not the intent.
    exp_bot, exp_top = (b, a) if flip else (a, b)
    dr_bot, dr_top = _dist(A, B), _dist(D, C)
    if abs(dr_top / dr_bot - exp_top / exp_bot) > _TOL:
        raise AssertionError("drawn base ratio %.3f != given %.3f"
                             % (dr_top / dr_bot, exp_top / exp_bot))
    if abs(_line_dist(D, A, B) / dr_bot - h / exp_bot) > _TOL:
        raise AssertionError("drawn height ratio off the given h")

    if base_angle is not None:
        v1 = (B[0] - A[0], B[1] - A[1])
        v2 = (D[0] - A[0], D[1] - A[1])
        dr = math.degrees(math.acos(
            max(-1.0, min(1.0, (v1[0] * v2[0] + v1[1] * v2[1])
                          / ((math.hypot(*v1) * math.hypot(*v2)) or 1.0)))))
        if abs(dr - base_angle) > 1.0:
            raise AssertionError("drawn ∡A = %.1f°, given %s°" % (dr, base_angle))

    cv.poly(P, 1.6)

    if diagonals:
        # solid and thin: dashes mean "height" or "hidden edge" in this house,
        # and a dashed diagonal reads as a construction line the student may skip
        cv.line(A, C, 1.0, record=False)
        cv.line(B, D, 1.0, record=False)
    if diag:                       # a SINGLE named diagonal, e.g. diag="AC"
        cv.line(P["ABCD".index(diag[0])], P["ABCD".index(diag[1])],
                1.0, record=False)
    if midseg:
        cv.line(_mid(A, D), _mid(B, C), 1.3, record=False)
    if ticks:
        la, lb = _dist(A, D), _dist(B, C)
        if abs(la - lb) / max(la, lb) > 0.015:
            raise AssertionError(
                "trapz_kit.trapezoid: ticks=True marks the legs AD and BC equal, "
                "but they are drawn %.1f and %.1f (%.0f%% apart, kind=%r). An "
                "equality mark on unequal legs tells the student a falsehood: "
                "use kind='iso' for equal legs, or leave ticks off."
                % (la, lb, 100 * abs(la - lb) / max(la, lb), kind))
        for p, q in ((A, D), (B, C)):
            m, L = _mid(p, q), _dist(p, q) or 1.0
            ux, uy = (q[0] - p[0]) / L, (q[1] - p[1]) / L
            cv.line((m[0] - uy * 5, m[1] + ux * 5),
                    (m[0] + uy * 5, m[1] - ux * 5), 1.5, record=False)

    if height_from:
        i = names.index(height_from)
        apex = P[i]
        # project onto the OPPOSITE base, whichever that is — so a flipped or
        # rotated figure still gets a height that lands where it should.
        base_a, base_b = (P[0], P[1]) if i in (2, 3) else (P[3], P[2])
        dx, dy = base_b[0] - base_a[0], base_b[1] - base_a[1]
        L2 = dx * dx + dy * dy
        t = ((apex[0] - base_a[0]) * dx + (apex[1] - base_a[1]) * dy) / L2
        if not -0.02 <= t <= 1.02:
            raise AssertionError(
                "height from %s lands outside the opposite base (t=%.2f) — "
                "drop it from the other vertex, or extend the base with a "
                "dashed segment" % (height_from, t))
        top = apex
        foot = (base_a[0] + t * dx, base_a[1] + t * dy)
        cv.line(top, foot, 1.2, dash="4 3", record=False)
        cv.right_angle(foot, base_b, top)
        if lab.get("h"):
            nx, ny = -(top[1] - foot[1]), (top[0] - foot[0])
            L = math.hypot(nx, ny) or 1.0

            def at_h(t, d, sd=1):
                c = (foot[0] + (top[0] - foot[0]) * t,
                     foot[1] + (top[1] - foot[1]) * t)
                return (c[0] + sd * nx / L * d, c[1] + sd * ny / L * d + 4)
            # C3 r3: farther from the foot (its right-angle mark and the
            # base) first, then the other side of the height
            alts = [at_h(t, d, sd) for sd in (1, -1)
                    for t in (0.6, 0.7, 0.5, 0.8, 0.4)
                    for d in (12, 15, 18)]
            cv.text(at_h(0.5, 12), lab["h"], italic=not lab["h"].isdigit(),
                    owner=(top, foot), alts=alts)

    edges = ({"b": (0, 1), "BC": (1, 2), "a": (2, 3), "AD": (3, 0)} if flip
             else {"a": (0, 1), "BC": (1, 2), "b": (2, 3), "AD": (3, 0)})
    for key, (i, j) in edges.items():
        if not lab.get(key):
            continue
        nx, ny = _outward(P, i, j)
        m = _mid(P[i], P[j])
        alts = [(P[i][0] + (P[j][0] - P[i][0]) * t + nx * d,
                 P[i][1] + (P[j][1] - P[i][1]) * t + ny * d + 4)
                for d in (15, 19, 23, 12) for t in (0.5, 0.42, 0.58, 0.34, 0.66)]
        cv.text((m[0] + nx * 15, m[1] + ny * 15 + 4), lab[key],
                italic=not re.match(r"^[\d.]+$", lab[key]), value=True,
                owner=(P[i], P[j]), alts=alts)

    for v, txt in angles.items():
        i = "ABCD".index(v)
        mv = re.match(u"^\\s*(\\d+(?:\\.(\\d+))?)\\s*\u00b0\\s*$", txt)
        if mv:
            nb0, nb1 = P[(i + 1) % 4], P[(i - 1) % 4]
            u1 = (nb0[0] - P[i][0], nb0[1] - P[i][1])
            u2 = (nb1[0] - P[i][0], nb1[1] - P[i][1])
            n = (math.hypot(*u1) * math.hypot(*u2)) or 1.0
            drawn = math.degrees(math.acos(max(-1.0, min(1.0, (
                u1[0] * u2[0] + u1[1] * u2[1]) / n))))
            tol = 0.5 * 10 ** -len(mv.group(2) or "") + 0.1
            if abs(float(mv.group(1)) - drawn) > tol:
                raise AssertionError(
                    "trapz_kit.trapezoid: angles={%r: %r}, but the angle at %s "
                    "is drawn %.2f° -- the figure is laid out from a, b, h and "
                    "kind, so the printed value contradicts it. Print %.0f°, or "
                    "lay the figure out from the angle (kind='angle', "
                    "base_angle=)." % (v, txt, v, drawn, drawn))
        nb = [P[(i + 1) % 4], P[(i - 1) % 4]]
        anchor = cv.arc(P[i], nb[0], nb[1], r=20)
        spot = cv.clear_spot(P[i], anchor, txt, 11.5, tries=30, sides=nb,
                             poly=P)
        if spot is None:
            # A narrow angle split by a diagonal has no clear room near its
            # vertex at this size. The value may not leave its angle (outside
            # the polygon it reads as the exterior angle) and may not be
            # dropped, so the figure grows: the text stays 11.5px while the
            # wedges widen under it.
            if 1.2 ** (_grown + 1) <= _GROW_MAX + 1e-6:
                return trapezoid(a, b, h, kind=kind, rotate=rotate, flip=flip,
                                 lab=lab, names=names,
                                 height_from=height_from,
                                 diagonals=diagonals, midseg=midseg,
                                 angles=angles, ticks=ticks,
                                 base_angle=base_angle, diag=diag,
                                 target=target * 1.2, pad=pad,
                                 _grown=_grown + 1, fam=fam)
            raise AssertionError(
                "angle value %r at %s has no clear spot inside its angle at "
                "target=%d (a diagonal or edge crowds the vertex) — %s; never "
                "print the value outside the angle, and never drop the value "
                "or a diagonal the item asks about" % (txt, v, target, _tried_fix(
                    dict(a=a, b=b, h=h, kind=kind, rotate=rotate, flip=flip,
                         lab=lab, names=names, height_from=height_from,
                         diagonals=diagonals, midseg=midseg, angles=angles,
                         ticks=ticks, base_angle=base_angle, diag=diag, pad=pad,
                         fam=fam), target / 1.2 ** _grown)))
        cv.text(spot, txt, size=11.5,
                value=True)

    # names="" omits the vertex letters. Needed for a genuinely extreme
    # section — a dam at 14 m over 200 m draws a top edge ~15px wide, and
    # C and D cannot both sit on it. Dropping the letters is honest; drawing
    # the section out of scale to make room is not.
    cx = sum(p[0] for p in P) / 4
    cy = sum(p[1] for p in P) / 4
    for i, n in enumerate(names or ""):
        p = P[i]
        vx, vy = p[0] - cx, p[1] - cy
        L = math.hypot(vx, vy) or 1.0
        # a vertex that carries an angle value needs its letter out of the way
        off = 24 if n in angles else 13
        cv.text((p[0] + vx / L * off, p[1] + vy / L * off + 4), n, size=12.5)

    cv.check()
    # C3 r3: a length or height the drawing reads as another stroke's, at
    # every position its canvas may move it to, needs more room: the figure
    # grows (the text stays its size) as it does for a crowded angle value
    lost = cv.unowned()
    if lost:
        if 1.2 ** (_grown + 1) <= _GROW_MAX + 1e-6:
            return trapezoid(a, b, h, kind=kind, rotate=rotate, flip=flip,
                             lab=lab, names=names, height_from=height_from,
                             diagonals=diagonals, midseg=midseg, angles=angles,
                             ticks=ticks, base_angle=base_angle, diag=diag,
                             target=target * 1.2, pad=pad, _grown=_grown + 1,
                             fam=fam)
        raise AssertionError(
            "trapz_kit.trapezoid: the label %r stays nearer another stroke than "
            "its own side at every place beside that side, even grown to "
            "target=%d (%s) -- %s; never drop the label, the height or a "
            "diagonal the item asks about"
            % (lost[0][0], target, lost[0][1], _tried_fix(
                dict(a=a, b=b, h=h, kind=kind, rotate=rotate, flip=flip,
                     lab=lab, names=names, height_from=height_from,
                     diagonals=diagonals, midseg=midseg, angles=angles,
                     ticks=ticks, base_angle=base_angle, diag=diag, pad=pad,
                     fam=fam), target / 1.2 ** _grown)))
    svg = cv.render()
    if fam:
        import figkit
        svg = figkit.tag(svg, fam)
    return svg


# ---------------------------------------------- quadrilateral from angles --
def quad_from_angles(*a, **k):
    """RETIRED — it built a PARALLELOGRAM and called it a trapezoid.

    Given ∡A and ∡D with ∡A + ∡D = 180°, the shape is NOT determined: those
    two angles are co-interior across the leg AD, so they are supplementary
    in *every* trapezoid with AB ∥ DC, and they say nothing about the second
    pair. The old construction resolved the freedom by placing C symmetrically
    to D, which makes AD ∥ BC — a parallelogram. On a sheet whose question is
    "prove AB ∥ DC" and whose next part asks "does it follow that it is a
    trapezoid?", shipping a parallelogram gives the second part away and
    contradicts the key.

    Use `trapezoid(a, b, h, kind="angle", base_angle=∡A)`: it fixes the leg
    from the given angle, takes the top base as the remaining free parameter,
    asserts the DRAWN ∡A against the given one, and enforces 3b-iso so the
    legs cannot come out parallel."""
    raise NotImplementedError(quad_from_angles.__doc__)


# ------------------------------------------------------- coordinate plane --
def grid_quad(pts, names="ABCD", xmax=9, ymax=8, step=34, pad=26,
              show=(2, 2), fam=None):
    """A quadrilateral on a labelled grid. `pts` are integer lattice points in
    the order A, B, C, D."""
    W, H = xmax * step + 2 * pad, ymax * step + 2 * pad

    def px(p):
        return (pad + p[0] * step, H - pad - p[1] * step)
    cv = _Canvas(W, H)
    for i in range(xmax + 1):
        x = pad + i * step
        cv.line((x, pad), (x, H - pad), 0.7, record=False)
    for j in range(ymax + 1):
        y = H - pad - j * step
        cv.line((pad, y), (W - pad, y), 0.7, record=False)
    cv.line((pad, H - pad), (W - 6, H - pad), 1.3, record=False)
    cv.line((pad, H - pad), (pad, 6), 1.3, record=False)
    cv.text((W - 10, H - pad + 15), "x", size=11.5, italic=True)
    cv.text((pad - 12, 14), "y", size=11.5, italic=True)
    for i in range(show[0], xmax + 1, show[0]):
        cv.text((pad + i * step, H - pad + 15), str(i), size=10.5)
    for j in range(show[1], ymax + 1, show[1]):
        cv.text((pad - 12, H - pad - j * step + 4), str(j), size=10.5)
    Q = [px(p) for p in pts]
    cv.poly(Q, 1.7)
    for q in Q:
        cv.parts.append(("circle", [q], 3, None, None))
    cx = sum(q[0] for q in Q) / 4
    cy = sum(q[1] for q in Q) / 4
    for i, n in enumerate(names):
        vx, vy = Q[i][0] - cx, Q[i][1] - cy
        L = math.hypot(vx, vy) or 1.0
        cv.text((Q[i][0] + vx / L * 15, Q[i][1] + vy / L * 15 + 4), n, size=12.5)
    svg = cv.render()
    if fam:                                    # v6 C3 (E10)
        import figkit
        svg = figkit.tag(svg, fam)
    return svg


def selftest():
    """Both directions: a correct figure builds, a lying one raises."""
    ok = True
    trapezoid(12, 6, 7, kind="scalene", lab=dict(a="12", b="6", h="h"),
              height_from="D")
    trapezoid(14, 8, 5, kind="iso", rotate=180, angles={"A": "59°"})
    trapezoid(10, 6, 4, kind="right-l", diagonals=True, rotate=90)
    trapezoid(22, 10, 8, kind="iso", flip=True, ticks=True)
    trapezoid(11, 5, 6, kind="angle", base_angle=112, lab=dict(a="11", b="5"))
    grid_quad([(2, 1), (8, 1), (6, 6), (4, 6)])
    try:                                   # a near-symmetric "scalene" must die
        trapezoid(12, 9, 8, kind="scalene")
        print("SELFTEST FAIL: 3b-iso not enforced"); ok = False
    except (AssertionError, ValueError):
        pass
    try:                                   # an angle build that would be a ∥gram
        trapezoid(12, 12 - 2 * 6 / math.tan(math.radians(65)), 6,
                  kind="angle", base_angle=65)
        print("SELFTEST FAIL: parallelogram not rejected"); ok = False
    except (AssertionError, ValueError):
        pass
    print("SELFTEST PASS" if ok else "SELFTEST FAILED")
    return 0 if ok else 1



# v6.5 X2 r1 (MUST-3, spec rule 6): the author's call into this module
# is recorded as source, so figures/<id>.py can re-draw the figure.
import export as _export_rec  # noqa: E402
trapezoid = _export_rec.entry(trapezoid)
quad_from_angles = _export_rec.entry(quad_from_angles)
grid_quad = _export_rec.entry(grid_quad)

if __name__ == "__main__":
    import sys
    sys.exit(selftest())
