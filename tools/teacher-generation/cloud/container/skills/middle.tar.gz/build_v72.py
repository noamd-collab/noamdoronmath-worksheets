# -*- coding: utf-8 -*-
u"""build_v72 — v7.2.0. One command for a sheet: PDF + Word + gates + catalog + landing.

    cd <package folder>
    DYLD_FALLBACK_LIBRARY_PATH=/opt/homebrew/lib python3 /abs/skill/build_v72.py [--render] [--no-docx]

WHY A NEW DRIVER, AND WHY IT DOES NOT TOUCH build.py
----------------------------------------------------
build.py ends in sys.exit and stops at the first failing level (build.py:397),
so cross-level gates (the same sections in a, b and c), the catalog and the Word
file cannot run inside it. build_plus.py stays the PDF build, unchanged in
behaviour; this driver runs it as a subprocess and then runs, in order:

  1. the four existing checkers on out/deliver/a|b|c (v7-production-he.md)
  2. emit_docx      out/docx/<k>/sheet.docx from the same IR as sheet.pdf
  3. catalog_build  out/catalog/<sheet_id>/catalog-entry.json
     landing_build  out/catalog/<sheet_id>/landing.json
  4. gate_sections  G85 volume · G86 terms · G87 chronology · G88 level parity ·
                    G89 catalog · G92 structure
  5. check_docx_rtl G90 RTL · G91 parity, per level
  6. --render       PNG of every sheet.pdf page and of every Word page
                    (Word.app; a local check only) into out/review/<k>/

New outputs live OUTSIDE out/deliver: deliver never cleans its folders and
nothing hashes extra files there (understand/package.md), so a stale DOCX
next to sheet.pdf would go unnoticed.

SPACE IN THE SKILL PATH. The locked emit_html._body_cmap opens the font through
a file:// URI without decoding it, so a skill folder under ".../Application
Support/..." fails with FileNotFoundError (DavidLibre-Regular.ttf, %20 left in
the path). That is a bug in a locked file, so it is not patched here. Instead,
when this file's folder contains a space, the driver copies the skill byte for
byte into a temporary folder without spaces, re-runs itself from there, and
deletes the copy afterwards. v72-report.json records both folders.

A legacy package (no sheet_meta.py and no SHEET) still builds: its PDF and
deliver files are the 7.1.1 ones, G85–G89 and G92 report SKIP (never PASS),
and it also gets a Word file, checked by G90 (RTL) and G91 (parity) without
the glossary term rules, because term rules are part of the sectioned-sheet
contract. A package that ships sheet_meta.py but whose content.py exposes no
SHEET is NOT legacy: every section gate and the catalog step FAIL.

Each run first removes the outputs this driver owns (out/docx, out/catalog,
out/review, out/logs, out/v72-report.json), so nothing from an earlier run is
gated, hashed or shipped as if this run made it. out/deliver belongs to
build_plus/deliver and is rebuilt by it.

Exit 1 when any blocking step fails. REVIEW items do not fail the run; they
are listed on the RESULT line. out/v72-report.json lists every step, every
gate result and the sha256 of every file under out/ except out/logs.
"""
import sys

# The skill folder must stay free of __pycache__ (it is copied and hashed as a
# unit), so no bytecode is written by this process either; child processes get
# PYTHONDONTWRITEBYTECODE from _env (final review, 2026-11-09).
sys.dont_write_bytecode = True

import argparse  # noqa: E402
import hashlib  # noqa: E402
import json  # noqa: E402
import os  # noqa: E402
import shutil  # noqa: E402
import signal  # noqa: E402
import subprocess  # noqa: E402
import tempfile  # noqa: E402
import time  # noqa: E402
from pathlib import Path  # noqa: E402

SK = Path(__file__).resolve().parent
sys.path.insert(0, str(SK))

import pkgload  # noqa: E402

SKILL_VERSION = "7.2.0-noam"
ENGINE_VERSION = "6.18-noam"
CHECKERS = ("check_plain_math.py", "verify_export.py",
            "selfcheck_noam_package.py", "check_didactic.py")


def _env():
    env = dict(os.environ)
    env.setdefault("DYLD_FALLBACK_LIBRARY_PATH", "/opt/homebrew/lib")
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    return env


def _run(cmd, cwd, log):
    t0 = time.time()
    r = subprocess.run(cmd, cwd=str(cwd), env=_env(), capture_output=True, text=True)
    log.parent.mkdir(parents=True, exist_ok=True)
    log.write_text((r.stdout or "") + "\n--- stderr ---\n" + (r.stderr or ""), encoding="utf-8")
    return r.returncode, round(time.time() - t0, 2), r


def _sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def _step(report, name, status, **kw):
    rec = {"step": name, "status": status}
    rec.update(kw)
    report["steps"].append(rec)
    mark = {"PASS": "✓", "FAIL": "✗", "SKIP": "·", "REVIEW": "?"}.get(status, " ")
    print("%s %-28s %s %s" % (mark, name, status, kw.get("note", "")))
    return rec


OWNED_OUTPUTS = ("docx", "catalog", "review", "logs", "v72-report.json")


def _space_free_mirror():
    """A byte-identical copy of the skill in a folder without spaces, or None.
    The temporary folder is removed here if the copy cannot be completed."""
    if " " not in str(SK) or os.environ.get("HMW_V72_ORIGIN"):
        return None
    base = tempfile.gettempdir()
    if " " in base:
        base = "/tmp" if os.path.isdir("/tmp") and " " not in os.path.realpath("/tmp") else None
        if base is None:
            raise RuntimeError("no temporary folder without a space (TMPDIR=%s)"
                               % tempfile.gettempdir())
    root = Path(tempfile.mkdtemp(prefix="hmw-skill-v72-", dir=base))
    dst = root / SK.name
    try:
        shutil.copytree(str(SK), str(dst), ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    except BaseException:
        shutil.rmtree(str(root), ignore_errors=True)
        raise
    return dst


def _clean_owned(out):
    """Remove the outputs this driver writes, so an earlier run's Word file,
    catalog, review pages or report can never pass for this run's."""
    for name in OWNED_OUTPUTS:
        p = out / name
        if p.is_dir():
            shutil.rmtree(str(p))
        elif p.exists():
            p.unlink()


def main(argv=None):
    # SIGTERM (a harness timeout, for example) becomes SystemExit, so the
    # finally blocks below still remove the temporary skill copy and
    # subprocess.run kills the child build.
    if hasattr(signal, "SIGTERM"):
        signal.signal(signal.SIGTERM, lambda signum, frame: sys.exit(128 + signum))
    try:
        mirror = _space_free_mirror()
    except Exception as e:
        print("build_v72: cannot prepare a copy of the skill without a space in its path: %r" % e,
              file=sys.stderr)
        return 1
    if mirror is not None:
        env = _env()
        env["HMW_V72_ORIGIN"] = str(SK)
        print("build_v72: the skill path has a space; running from a copy at %s" % mirror, flush=True)
        try:
            r = subprocess.run([sys.executable, "-B", str(mirror / "build_v72.py")] +
                               list(sys.argv[1:] if argv is None else argv), env=env)
        finally:
            shutil.rmtree(str(mirror.parent), ignore_errors=True)
        return r.returncode
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--pkg", default=".", help="package folder (default: cwd)")
    ap.add_argument("--render", action="store_true", help="PNG review pages (Word for the DOCX)")
    ap.add_argument("--no-docx", action="store_true")
    ap.add_argument("--skip-build", action="store_true", help="reuse an existing out/deliver")
    a = ap.parse_args(argv)

    pkg = Path(a.pkg).resolve()
    out = pkg / "out"
    logs = out / "logs"
    report = {"skill_version": SKILL_VERSION, "engine_version": ENGINE_VERSION,
              "package_dir": str(pkg), "steps": [], "gates": [], "files": {},
              "skill_dir": os.environ.get("HMW_V72_ORIGIN") or str(SK),
              "ran_from_copy": str(SK) if os.environ.get("HMW_V72_ORIGIN") else None}
    _clean_owned(out)
    try:
        P = pkgload.load(pkg, with_ir=False)
    except Exception as e:
        # A package that cannot even be loaded is a failed run with a report,
        # never a bare traceback next to an earlier run's outputs.
        print("build_v72 %s · package folder %s" % (SKILL_VERSION, pkg))
        _step(report, "load package (content.py)", "FAIL", note=repr(e)[:400])
        return _finish(report, out, 1)
    sheet = P.sheet or None
    keys = P.keys
    has_meta = (pkg / "sheet_meta.py").is_file()
    legacy = sheet is None and not has_meta
    report["package"] = P.package
    report["sheet_id"] = (sheet or {}).get("sheet_id")
    report["legacy"] = legacy
    label = report["sheet_id"] or ("(legacy, no SHEET)" if legacy else
                                   "(sheet_meta.py present, but content.py exposes no SHEET)")
    print("build_v72 %s · package %s · sheet %s · levels %s"
          % (SKILL_VERSION, P.package, label, ",".join(keys)))

    # 1. PDF build (unchanged build_plus.py)
    if not a.skip_build:
        rc, dt, _ = _run([sys.executable, str(SK / "build_plus.py")], pkg, logs / "build_plus.log")
        _step(report, "build_plus (PDF + gates)", "PASS" if rc == 0 else "FAIL",
              seconds=dt, log=str(logs / "build_plus.log"))
        if rc != 0:
            return _finish(report, out, 1)
    deliver = pkgload.deliver_dir(pkg)
    dirs = [str(deliver / k) for k in keys]

    # 2. existing checkers
    for c in CHECKERS:
        rc, dt, r = _run([sys.executable, str(SK / c)] + dirs, pkg, logs / (c + ".log"))
        _step(report, c, "PASS" if rc == 0 else "FAIL", seconds=dt, log=str(logs / (c + ".log")))

    # 3. Word
    docx_paths = {}
    if a.no_docx:
        # A sectioned sheet is not deliverable without its Word file (SKILL.md
        # rule 14), so skipping it is something a person must see.
        _step(report, "emit_docx", "SKIP" if legacy else "REVIEW",
              note="--no-docx: no Word file, so G90/G91 did not run")
    else:
        try:
            import emit_docx
            Pir = pkgload.load(pkg)
            for k in keys:
                dp = out / "docx" / k / "sheet.docx"
                dp.parent.mkdir(parents=True, exist_ok=True)
                stats = emit_docx.build_docx(Pir.ir[k], dp, meta={"level": k, "package": P.package,
                                                                    "sheet": sheet})
                docx_paths[k] = dp
                _step(report, "emit_docx %s" % k, "PASS", stats=stats)
        except Exception as e:  # a missing or failing writer is a failed step, never a skip
            _step(report, "emit_docx", "FAIL", note=repr(e)[:400])

    # 4. catalog + landing (sectioned sheets)
    if sheet:
        for modname in ("catalog_build", "landing_build"):
            try:
                mod = __import__(modname)
                path = mod.build(pkg, out)
                _step(report, modname, "PASS", path=str(path))
            except Exception as e:
                _step(report, modname, "FAIL", note=repr(e)[:400])
    elif not legacy:
        _step(report, "catalog/landing", "FAIL",
              note="sheet_meta.py is present but content.py exposes no SHEET "
                   "(add: from sheet_meta import SHEET)")
    else:
        _step(report, "catalog/landing", "SKIP", note="legacy package (no SHEET)")

    # 5. section gates
    try:
        import gate_sections
        res = gate_sections.run(pkg, out)
        report["gates"].extend(res)
        bad = [r for r in res if r["status"] == "FAIL"]
        rev = [r for r in res if r["status"] == "REVIEW"]
        # REVIEW does not fail the build, but it must be visible on the
        # console, not only in out/v72-report.json (gates fix, 2026-11-09).
        _step(report, "gate_sections G85–G92", "FAIL" if bad else
              ("SKIP" if all(r["status"] == "SKIP" for r in res) else
               ("REVIEW" if rev else "PASS")),
              note="%d results, %d FAIL, %d REVIEW%s" % (
                  len(res), len(bad), len(rev),
                  "".join("\n    ? %s %s: %s" % (r["gate"], r.get("level") or "sheet",
                                                 "; ".join(r.get("messages") or [])[:300])
                          for r in rev)))
    except Exception as e:
        _step(report, "gate_sections", "FAIL", note=repr(e)[:400])

    # 6. Word RTL + parity
    gloss = SK / "glossary_he.json"
    for k, dp in docx_paths.items():
        j = logs / ("check_docx_rtl_%s.json" % k)
        cmd = [sys.executable, "-I", str(SK / "check_docx_rtl.py"), str(dp),
               "--source", str(deliver / k / "sheet.json"), "--json", str(j)]
        # Term rules (forbidden terms, house spelling) belong to the sectioned
        # contract; a legacy sheet gets the RTL and parity rules only, so a
        # sheet that 7.1.1 accepted is not failed on wording (final review).
        if legacy:
            cmd += ["--no-terms"]
        elif gloss.is_file():
            cmd += ["--glossary", str(gloss)]
        if sheet and sheet.get("scope") in ("sectioned", "broad"):
            cmd += ["--scope", sheet["scope"], "--pkg", str(pkg)]
        rc, dt, r = _run(cmd, pkg, logs / ("check_docx_rtl_%s.log" % k))
        st = "PASS" if rc == 0 else "FAIL"
        report["gates"].append({"gate": "G90/G91-docx", "level": k, "status": st,
                                "messages": [str(j)]})
        _step(report, "check_docx_rtl %s" % k, st, seconds=dt)

    # 7. review renders
    if a.render:
        try:
            import pymupdf
            for k in keys:
                rv = out / "review" / k
                rv.mkdir(parents=True, exist_ok=True)
                doc = pymupdf.open(str(deliver / k / "sheet.pdf"))
                for i, pg in enumerate(doc):
                    pg.get_pixmap(dpi=110).save(str(rv / ("pdf_p%02d.png" % (i + 1))))
            _step(report, "render PDF pages", "PASS")
        except Exception as e:
            _step(report, "render PDF pages", "FAIL", note=repr(e)[:300])
        for k, dp in docx_paths.items():
            rv = out / "review" / k
            rc, dt, r = _run([sys.executable, "-B", str(SK / "docx_render.py"), str(dp),
                              "--dpi", "110", "--out", str(rv), "--assert",
                              "--json", str(logs / ("docx_render_%s.json" % k))],
                             pkg, logs / ("docx_render_%s.log" % k))
            _step(report, "render Word pages %s" % k, "PASS" if rc == 0 else "FAIL", seconds=dt,
                  note="local check, needs Word.app")

    status = 1 if any(s["status"] == "FAIL" for s in report["steps"]) else 0
    return _finish(report, out, status)


def _finish(report, out, status):
    # Every file under out/ except the logs and this report: owned outputs were
    # removed at the start of the run, so everything listed is this run's or
    # build_plus's (out/deliver, rebuilt by it).
    if out.is_dir():
        for p in sorted(out.rglob("*")):
            if not p.is_file():
                continue
            rel = p.relative_to(out)
            if rel.parts[0] == "logs" or rel.as_posix() == "v72-report.json":
                continue
            report["files"][rel.as_posix()] = _sha(p)
    report["result"] = "PASS" if status == 0 else "FAIL"
    review = [s["step"] for s in report["steps"] if s["status"] == "REVIEW"] + \
        ["%s %s" % (g["gate"], g.get("level") or "sheet") for g in report.get("gates", [])
         if g.get("status") == "REVIEW"]
    report["review"] = review
    out.mkdir(exist_ok=True)
    (out / "v72-report.json").write_text(json.dumps(report, ensure_ascii=False, indent=1),
                                         encoding="utf-8")
    print("RESULT: %s%s  (out/v72-report.json)" % (
        report["result"], "  -- %d item(s) need a human look: %s" % (len(review), ", ".join(review))
        if review else ""))
    return status


if __name__ == "__main__":
    sys.exit(main())
