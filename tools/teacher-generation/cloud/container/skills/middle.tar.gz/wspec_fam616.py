# -*- coding: utf-8 -*-
u"""wspec_fam616 -- (v6.16 integrate) the GRAPH and PIE families on the
worksheet's spec path (wspec_build / deliver / G79). Owner: the integrator.

The engine side is merged in wspec/ (sheet_graph.py, sheet_pie.py); this
module is what the SHEET needs of a graph / pie figure, called from
wspec_build at the few places where a family engine differs from the
geometry engine (the coordinate-plane / number-line precedent of v6.12):

  family_of_engine(eng)   'function_graph' / 'pie_chart' / None
  settings(LS, fid, st)   a graph figure's renderer settings: the author's
                          display settings (square, fonts) + the display
                          layout of what the public model hides (an asked
                          curve's numbers, an asked mark's place) --
                          computed from the spec, never written by hand
  graph_finds(LS, iid)    the graph finds an ITEM asks [(fig, rec, truth)]
  find_claims(LS, iid)    their to_prove claims (metadata lines from
                          templates_he.json graph_target_lines, PENDING the
                          author: wspec/PENDING_V616.txt), marked readoff
  key_problems(LS, it, txt)  the original key line must restate every graph
                          find's exact answer (sheet_graph.key_restates)
  answer_values(LS)       every graph find's answer numbers (G79's guard)
  figure_entry(rec)       the sheet.json entry of a graph / pie figure
  vm_layer(vm, rec, entry)   its visual_model objects, by the engine's ids
  figure_guard(rec)       the graph checker's own answer guard of a figure
                          (kinds.answer_guard: points / curves / texts /
                          equations a find forbids) for G79's checker

Nothing here prints a word on the sheet: the question is its source words
(bound prose), the key is the source's key line (keys=)."""
import math
import re

from wspec import sheet_graph as SGR
from wspec import pie as PIE
from wspec.graph import kinds as GK

GRAPH_ENGINE = "wspec-graph-render/1.0.0"
PIE_ENGINE = "wspec-render-pie/1.0.0"
ENGINES = {GRAPH_ENGINE: "function_graph", PIE_ENGINE: "pie_chart"}


def family_of_engine(eng):
    return ENGINES.get(eng)


def family_of_rec(rec):
    return family_of_engine(((rec or {}).get("object_map") or {}).get(
        "engine"))


def spec_figure(LS, fid):
    for g in (getattr(LS, "spec", None) or {}).get("figures") or []:
        if isinstance(g, dict) and g.get("id") == fid:
            return g
    return None


def is_graph_fid(LS, fid):
    return SGR.is_graph(spec_figure(LS, fid))


def is_pie_fid(LS, fid):
    return PIE.is_pie_figure(spec_figure(LS, fid))


def settings(LS, fid, st):
    """st: the author's display settings of the figure (None allowed for a
    graph / pie figure: the engine's defaults). A graph figure gets its
    display layout added (never an author's hand-written number)."""
    g = spec_figure(LS, fid)
    st = dict(st or {})
    if PIE.is_pie_figure(g):
        # the worksheet's neutral figure (BRIEF_V671 s3: ink and greys
        # only): the pie's print palette unless the author says otherwise
        st.setdefault("palette", "print")
    if SGR.is_graph(g):
        lay = SGR.display_layout(g)
        for k in ("curves", "marks"):
            if k in st:
                raise ValueError("figure %s: the display settings write %r; "
                                 "a graph figure's hidden numbers come from "
                                 "its spec (sheet_graph.display_layout)"
                                 % (fid, k))
            if lay.get(k):
                st[k] = lay[k]
    return st


# ------------------------------------------------------------- finds ----
def graph_finds(LS, iid):
    return SGR.finds_of_item(LS.ix, iid)


def _tset():
    from wspec import templates as WT
    return WT.load_templates()


def curve_ref(LS, fid, cid):
    """'הישר f' / 'הפרבולה y = (x − 2)² − 9' / 'הפרבולה' -- a curve as the
    metadata line names it: its kind word + its PRINTED name or equation
    (never a hidden number)"""
    data = _tset().data
    g = spec_figure(LS, fid)
    pub = SGR.public_graph(g)
    c = [x for x in pub["curves"] if x["id"] == cid]
    words = data.get("graph_curve_words") or {}
    if not c:
        # (v6.16 integrate r2, graph I1) an UNDRAWN curve ("drawn": false,
        # the curve a givens-only figure asks about) is not in the public
        # model: its kind word only ('הישר' / 'הפרבולה') -- never its id
        # ('curve:l') and never a number of it (they are the answers)
        a = [x for x in (SGR.author_of(g).get("curves") or [])
             if isinstance(x, dict) and x.get("id") == cid]
        if a and a[0].get("fn") in words:
            return words[a[0]["fn"]]
        raise ValueError("figure %s: no curve %s to name in a metadata "
                         "line" % (fid, cid))
    c = c[0]
    word = words.get(c["fn"], c["fn"])
    lab = c.get("label") or {}
    if lab.get("name"):
        return u"%s %s" % (word, lab["name"])
    if lab.get("text"):
        return u"%s %s" % (word, lab["text"])
    return word


def find_line(LS, fid, rec):
    lines = _tset().data.get("graph_target_lines") or {}
    tl = lines.get(rec.get("rel"))
    if tl is None:
        raise ValueError("no graph target line for %s" % rec.get("rel"))
    args = rec.get("args") or []
    at = rec.get("at")
    subs = {"c0": curve_ref(LS, fid, args[0]) if len(args) > 0 else "",
            "c1": curve_ref(LS, fid, args[1]) if len(args) > 1 else "",
            "at": GK.disp(GK.Q(at)) if at is not None else ""}
    return re.sub(r"\{(c0|c1|at)\}", lambda m: subs[m.group(1)], tl)


def find_claims(LS, iid):
    """the item's graph finds as to_prove claims: a text row (metadata),
    marked readoff (its figure's data frame is withheld in noam-ai.json:
    the SVG coordinates of an asked curve would give the answer)"""
    out = []
    for fid, rec, _truth in graph_finds(LS, iid):
        out.append({"text": find_line(LS, fid, rec), "readoff": True})
    return out


def key_problems(LS, it, txt):
    """[why] -- the original key line of item `it` must restate every graph
    find's exact answer (an equation as an equation)"""
    out = []
    for fid, rec, truth in graph_finds(LS, it.get("id")):
        # (v6.16 integrate r2, graph I2) the curve the find asks about (its
        # author def, drawn or not): a key line that prints the curve's
        # equation in the form the answer is read from restates it
        args = rec.get("args") or []
        cur = None
        if len(args) == 1:
            g = spec_figure(LS, fid)
            cur = [x for x in (SGR.author_of(g).get("curves") or [])
                   if isinstance(x, dict) and x.get("id") == args[0]]
            cur = cur[0] if cur else None
        why = SGR.key_restates(txt, fid, rec, truth, curve=cur,
                               axes=SGR.author_of(spec_figure(LS, fid)).get("axes"))
        if why:
            out.append(why)
    return out


def answer_values(LS):
    """the numbers every graph find of the level answers (G79 answer
    guard): printed as the page prints numbers"""
    from fractions import Fraction
    vals = set()
    for g in (getattr(LS, "spec", None) or {}).get("figures") or []:
        if not SGR.is_graph(g):
            continue
        M = GK.checked(SGR.author_of(g))
        for f in M.finds:
            nums = SGR.answer_numbers(f.truth, f.rel)
            for v in nums or []:
                v = Fraction(v)
                if v.denominator == 1 and v != 0:
                    vals.add(str(v.numerator).replace("-", u"−"))
    return sorted(vals)


def figure_guard(rec):
    """the graph checker's own answer guard of one graph figure"""
    if family_of_rec(rec) != "function_graph":
        return None
    g = spec_figure(rec.get("level"), rec["fid"])
    if not SGR.is_graph(g):
        return None
    return GK.answer_guard(SGR.author_of(g))


# ------------------------------------------------------ sheet entries ----
def _r2(p):
    return [round(float(p[0]), 2), round(float(p[1]), 2)]


_NUM = re.compile(r"-?\d*\.?\d+(?:[eE][-+]?\d+)?")


def _anchor(tag, attrs):
    """a point ON the element (the start of a line / path, a circle's
    centre): the svg_xy every package checker verifies against the ink"""
    if tag == "line":
        return (float(attrs.get("x1", 0)), float(attrs.get("y1", 0)))
    if tag == "circle":
        return (float(attrs.get("cx", 0)), float(attrs.get("cy", 0)))
    v = [float(x) for x in _NUM.findall(attrs.get("d") or
                                        attrs.get("points") or "")]
    return (v[0], v[1]) if len(v) >= 2 else (0.0, 0.0)


def _elements(svg):
    from wspec_build import svg_elements
    return svg_elements(svg)


def figure_entry(rec):
    """the sheet.json entry of a graph / pie figure (the schema every
    checker of the skill reads): objects by bucket on the engine's element
    ids, the view, no constraint (a graph / pie figure states no geometric
    relation of points; its data are checked by the family checkers)"""
    fam = family_of_rec(rec)
    if fam == "function_graph":
        return _graph_entry(rec)
    return _pie_entry(rec)


def _graph_entry(rec):
    LS = rec["level"]
    om = rec["object_map"]
    pl = rec["placements"]
    m = pl["model_to_svg"]["matrix"]
    a, d, e, f = float(m[0]), float(m[3]), float(m[4]), float(m[5])
    W, H = pl["canvas_px"]
    pub = SGR.public_graph(spec_figure(LS, rec["fid"]))
    pubm = dict((x["id"], x) for x in pub["marks"])
    els = _elements(rec["svg"])
    out = {"points": [], "labels": [], "paths": []}
    by_item = {}
    for it in om.get("display_items") or []:
        for el in it.get("elements") or []:
            by_item[el] = it
    for oid, o in sorted((om.get("objects") or {}).items()):
        if o["kind"] == "mark":
            dot = [p["element"] for p in o["parts"]
                   if els.get(p["element"], ("",))[0] == "circle"]
            if not dot:
                continue
            ta = els[dot[0]][1]
            sxy = (float(ta.get("cx", 0)), float(ta.get("cy", 0)))
            ob = {"svg_id": dot[0], "kind": "point", "role": "point",
                  "name": oid, "svg_xy": _r2(sxy)}
            # (v6.16 fix r1, G9-T06 F2) a mark whose label prints a NAME
            # ('P' of 'P(3, 6)') is that named point for the text / model
            # checks (deliver s8, check_didactic D8, K6): its letter
            lab = (pubm.get(oid) or {}).get("label") or {}
            if isinstance(lab, dict) and lab.get("name"):
                ob["letter"] = lab["name"]
            xy = (pubm.get(oid) or {}).get("xy")
            if xy is not None:
                # a PUBLIC place only (a mark whose place is asked keeps its
                # svg_xy; noam-ai withholds the data frame of a find figure)
                ob["xy"] = [float(GK.Q(xy[0])), float(GK.Q(xy[1]))]
            out["points"].append(ob)
        elif o["kind"] in ("line", "vline", "parabola"):
            for p in o["parts"]:
                it = by_item.get(p["element"]) or {}
                if it.get("role") == "curve":
                    tg, at, _t = els.get(p["element"], ("", {}, ""))
                    out["paths"].append({"svg_id": p["element"],
                                         "kind": "curve", "role": "data",
                                         "name": oid, "svg_xy": _r2(
                                             _anchor(tg, at))})
    for el, (tag, attrs, text) in sorted(els.items()):
        it = by_item.get(el) or {}
        if tag != "text" or it.get("role") not in (
                "curve_label", "mark_label", "axis_name", "axis_unit"):
            continue
        x, y = float(attrs.get("x", 0)), float(attrs.get("y", 0))
        out["labels"].append({"svg_id": el, "kind": "label", "text": text,
                              "role": it["role"],
                              "for": (it.get("source") or {}).get("entity"),
                              "svg_xy": _r2((x, y))})
    out = dict((k, v) for k, v in out.items() if v)
    view = {"width_px": float(W), "height_px": float(H), "unit_px": 1.0,
            "viewbox": [float(W), float(H)], "rotate": 0.0,
            "data_to_svg": [a, 0.0, 0.0, d, e, f],
            "data_unit_px": [abs(a), abs(d)]}
    return {"kind": "wspec", "fam": "wspec", "view": view,
            "objects": out, "constraints": []}


def _pie_entry(rec):
    om = rec["object_map"]
    pl = rec["placements"]
    W, H = pl["canvas_px"]
    els = _elements(rec["svg"])
    out = {"paths": [], "labels": []}
    for it in om.get("display_items") or []:
        role = it.get("role")
        ent = (it.get("source") or {}).get("entity")
        for el in it.get("elements") or []:
            tag, attrs, text = els.get(el, (None, {}, ""))
            if tag is None:
                continue
            if tag == "text":
                out["labels"].append({"svg_id": el, "kind": "label",
                                      "text": text, "role": role,
                                      "for": ent, "svg_xy": _r2((
                                          float(attrs.get("x", 0)),
                                          float(attrs.get("y", 0))))})
            elif role in ("sector_wedge", "pie_outline", "build_circle"):
                out["paths"].append({"svg_id": el, "kind": role,
                                     "role": "data", "name": ent,
                                     "svg_xy": _r2(_anchor(tag, attrs))})
    out = dict((k, v) for k, v in out.items() if v)
    view = {"width_px": float(W), "height_px": float(H), "unit_px": 1.0,
            "viewbox": [float(W), float(H)], "rotate": 0.0}
    return {"kind": "wspec", "fam": "wspec", "view": view,
            "objects": out, "constraints": []}


# ------------------------------------------------------ visual model ----
def entity_parts(rec):
    out = {}
    for eid, o in (rec["object_map"].get("objects") or {}).items():
        out[eid] = [dict({"svg_id": p["element"]},
                         **({"span": list(p["span"])}
                            if p.get("span") not in (None, "whole") else {}))
                    for p in o["parts"]]
    return out


# a graph mark is a "mark" (not a house "point": its name is its printed
# label '(2, −9)' or none, and its highlight is checked by the graph family's
# own check_highlight, not by the letter / data-pt union rule of points)
VM_TYPE = {"line": "curve", "vline": "curve", "parabola": "curve",
           "mark": "mark", "axis": "axis", "plane": "plane",
           "guide": "guide", "pie": "pie", "sector": "sector",
           "legend": "legend", "build_circle": "build_circle"}


def vm_layer(vm, rec, entry):
    """the visual_model objects of a graph / pie figure speak the engine's
    ids (curve:w, mark:V, axis:x, sector:qb:a, pie:qb ...) with their parts
    (svg ids): Noam AI highlights by them (render.highlight dispatches the
    family's overlay). A graph curve carries NO equation / expr (an asked
    curve's numbers are the answer); a sector carries its printed label,
    never an angle or a value (an angle / a missing value may be asked)."""
    LS = rec["level"]
    fam = family_of_rec(rec)
    parts = entity_parts(rec)
    names = {}
    if fam == "function_graph":
        pub = SGR.public_graph(spec_figure(LS, rec["fid"]))
        for c in pub["curves"]:
            lab = c.get("label") or {}
            names[c["id"]] = lab.get("name") or lab.get("text") or ""
        for mk in pub["marks"]:
            lab = mk.get("label") or {}
            names[mk["id"]] = lab.get("name") or lab.get("text") or ""
    else:
        # (v6.16 integrate r2, pie IR4) a sector of a names-"none" disc and
        # a REGION print no name: their entity name is a never-printed
        # handle, never presented as a printed label
        unnamed = set()
        fr = (spec_figure(LS, rec["fid"]) or {}).get("frame") or {}
        for p in fr.get("parts") or []:
            if not isinstance(p, dict) or p.get("part") != "pie":
                continue
            if p.get("names") == "none":
                unnamed.update(p.get("order") or [])
            unnamed.update(p.get("regions") or [])
        for eid, e in LS.ix.entities.items():
            if e.get("kind") == "sector" and eid not in unnamed:
                names[eid] = e.get("name")
    keep = []
    for o in vm.get("objects") or []:
        # the bucket objects of the sheet entry are replaced by the
        # engine's objects (one per engine object, never an svg-level copy)
        if o.get("display") == "initial" and o.get("type") not in (
                "overlay_mark",):
            continue
        keep.append(o)
    gids = set(x for r in vm.get("relations") or []
               if r.get("role") == "given" for x in r.get("objects") or [])
    els = _elements(rec["svg"])
    for eid in sorted(parts):
        kind = (rec["object_map"]["objects"][eid] or {}).get("kind")
        d = {"id": eid, "svg_id": None, "type": VM_TYPE.get(kind, kind),
             "parts": parts[eid],
             "role": "given" if eid in gids else "context",
             "display": "initial"}
        if names.get(eid):
            d["name"] = names[eid]
        if kind == "mark":
            # a mark is a drawn point: its dot's centre (the union rule of
            # the package checkers paints a point at its svg_xy)
            dot = [p["svg_id"] for p in parts[eid]
                   if els.get(p["svg_id"], ("",))[0] == "circle"]
            if dot:
                # its principal element is its dot (a drawn element: the
                # acceptance runner refuses a drawing object of noam-ai.json
                # that is no element of the SVG)
                d["svg_id"] = dot[0]
                d["svg_xy"] = _r2(_anchor("circle", els[dot[0]][1]))
        keep.append(d)
    vm["objects"] = keep
    # the engine renders every object with ids: the model is FULL
    vm["visual_support"] = "full"
    return vm
