#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
coverage_gate.py — the gate the skill never had.

The skill carries 53 render gates. All 53 measure how a sheet LOOKS.
None measures WHAT IS IN IT. That is how three "מעבר לחטיבה העליונה"
sheets shipped with 0 geometry questions on a track where geometry is
40% of the teaching year, and how a רמה ב׳ sheet shipped two topics the
official פריסה says are not taught on that track.

Five blocking gates, all content:

  G70  domain coverage       — every domain ≥10% of the track's hours is represented
  G71  track legality        — no topic outside the track; no excluded topic
  G72  practice volume       — main questions, sub-items per question, total sub-items
  G73  marker format         — (1) not 1. / .1
  G74  geometry has figures  — geometry questions carry drawings

Two modes:

  spec mode  (authoring)   full check against a sheet_spec.json the author writes
  audit mode (forensic)    keyword sweep of a built PDF, no spec needed

Usage
-----
  python3 coverage_gate.py --spec sheet_spec.json [--pdf built.pdf]
  python3 coverage_gate.py --pdf existing.pdf --track ט_מצומצמת
  python3 coverage_gate.py --selftest

  --curriculum PATH     default: curriculum_tashpaz.json next to this file
  --allow TOPIC         override one not_in_track exclusion (never an explicit one)
  --report PATH         write the machine-readable report
  --non-strict          SKIPPED no longer fails the run

Exit codes: 0 pass · 1 gate failure · 2 usage/IO error

sheet_spec.json
---------------
{
  "title": "מיומנויות מעבר לחטיבה העליונה",
  "track": "ט_מצומצמת",
  "level": "רמה ב׳",
  "scope_mode": "broad",            # broad | focused
  "questions": [
    {"n": 1, "topics": ["pythagoras"], "subitems": 3, "figure": true,
     "text": "במשולש ישר זווית ..."}
  ]
}

Counting rule (deliberate, do not relax): a question counts toward the
domain of its FIRST listed topic only. Extra topics are logged as
secondary and earn no coverage credit. Otherwise coverage is padded by
tacking a geometry keyword onto an algebra question.
"""

import argparse
import json
import math
import os
import re
import subprocess
import sys
import unicodedata

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_CURRICULUM = os.path.join(HERE, "curriculum_tashpaz.json")

PASS, FAIL, WARN, SKIP = "PASS", "FAIL", "WARN", "SKIPPED"


# --------------------------------------------------------------------------
# result plumbing
# --------------------------------------------------------------------------

class Report:
    def __init__(self):
        self.rows = []

    def add(self, gate, status, message, detail=None):
        self.rows.append({"gate": gate, "status": status,
                          "message": message, "detail": detail or {}})

    def status_of(self, gate):
        for r in self.rows:
            if r["gate"] == gate:
                return r["status"]
        return None

    def failed(self, strict=True):
        bad = {FAIL, SKIP} if strict else {FAIL}
        return any(r["status"] in bad for r in self.rows)

    def render(self):
        width = max((len(r["gate"]) for r in self.rows), default=4)
        out = []
        for r in self.rows:
            out.append("  {:<6} {:<{w}}  {}".format(r["status"], r["gate"],
                                                    r["message"], w=width))
            for k, v in (r["detail"] or {}).items():
                out.append("           · {}: {}".format(k, v))
        return "\n".join(out)


# --------------------------------------------------------------------------
# text helpers  (RTL PDF extraction mangles parentheses and periods)
# --------------------------------------------------------------------------

def strip_bidi(s):
    """Drop bidi control codepoints so regexes see the raw characters."""
    return "".join(c for c in s if unicodedata.category(c) != "Cf")


def normalise(s):
    s = strip_bidi(s)
    s = s.replace("\u2212", "-").replace("\u05F4", '"').replace("\u05F3", "'")
    s = re.sub(r"[ \t\u00a0]+", " ", s)
    return s


def pdf_text(path):
    """Extract text from every page. Returns None if no extractor is present."""
    for cmd in (["pdftotext", "-enc", "UTF-8", path, "-"],
                ["pdftotext", path, "-"]):
        try:
            out = subprocess.run(cmd, capture_output=True, timeout=120)
            if out.returncode == 0:
                return normalise(out.stdout.decode("utf-8", "replace"))
        except (FileNotFoundError, subprocess.TimeoutExpired):
            continue
    return None


HEB = "\u05d0-\u05ea"

# Generic measurement words. They appear in algebra word problems ("למלבן
# היקף 40") just as often as in geometry, so on their own they must never
# establish that a geometry topic is present.
WEAK_KEYWORDS = {"היקף", "שטח", "גובה", "זווית", "נקודה", "ישר", "צלע"}


def has_keyword(text, keywords, allow_weak=False):
    """Return the matched keyword, or None.

    Hebrew prefixes (ב/ל/ה/ו/מ/ש/כ) attach to the FRONT of a word, so a match
    may legitimately start mid-token — but it must END on a word boundary.
    Without that, "ריבוע" matches inside "ריבועית" and a quadratic-function
    sheet reports that it covers squares."""
    for k in keywords:
        k = normalise(k).strip()
        if not k:
            continue
        if not allow_weak and k in WEAK_KEYWORDS:
            continue
        for m in re.finditer(re.escape(k), text):
            tail = text[m.end():m.end() + 1]
            if not re.match("[" + HEB + "]", tail):
                return k
    return None


# --------------------------------------------------------------------------
# curriculum access
# --------------------------------------------------------------------------

class Curriculum:
    def __init__(self, path):
        with open(path, encoding="utf-8") as fh:
            self.data = json.load(fh)
        self.policy = self.data["coverage_policy"]

    def track(self, name):
        if name not in self.data["tracks"]:
            raise KeyError("מסלול לא מוכר: {} · קיימים: {}".format(
                name, ", ".join(self.data["tracks"])))
        return self.data["tracks"][name]

    def topic(self, track_name, topic_id):
        for t in self.track(track_name)["topics"]:
            if t["id"] == topic_id:
                return t
        return None

    def excluded_keywords(self, track_name):
        """Resolve keywords for every excluded entry: use its own list if the
        curriculum supplies one, else borrow them from the track named in
        seen_in, where the topic IS taught."""
        out = []
        for ex in self.track(track_name).get("excluded", []):
            kws = list(ex.get("keywords", []))
            src = ex.get("seen_in")
            if not kws and src and src in self.data["tracks"]:
                for t in self.data["tracks"][src]["topics"]:
                    if t["name"].startswith(ex["topic"][:12]) or \
                       ex["topic"].startswith(t["name"][:12]):
                        kws = list(t.get("keywords", []))
                        break
            if kws:
                out.append({"topic": ex["topic"], "basis": ex["basis"],
                            "keywords": kws})
        return out


# --------------------------------------------------------------------------
# G70 — domain coverage
# --------------------------------------------------------------------------

def gate_G70(rep, cur, spec):
    track = cur.track(spec["track"])
    mode = spec.get("scope_mode", "broad")
    if mode == "focused":
        rep.add("G70", PASS, "דף ממוקד — אין דרישת כיסוי תחומים", {"scope_mode": mode})
        return

    qs = spec["questions"]
    n = len(qs)
    shares = track["domain_share"]
    threshold = 0.10

    primary = {}
    secondary = {}
    unmapped = []
    for q in qs:
        topics = q.get("topics") or []
        if not topics:
            unmapped.append(q["n"])
            continue
        t0 = cur.topic(spec["track"], topics[0])
        if t0 is None:
            unmapped.append(q["n"])
            continue
        primary[t0["domain"]] = primary.get(t0["domain"], 0) + 1
        for tid in topics[1:]:
            t = cur.topic(spec["track"], tid)
            if t:
                secondary[t["domain"]] = secondary.get(t["domain"], 0) + 1

    required = {}
    for dom, share in shares.items():
        if share >= threshold:
            required[dom] = max(1, math.ceil(share * n))

    missing = {}
    for dom, need in required.items():
        got = primary.get(dom, 0)
        if got < need:
            missing[dom] = "יש {} · דרוש {}".format(got, need)

    detail = {
        "שאלות ראשיות": n,
        "נדרש לפי שעות": required,
        "בפועל (ראשי)": primary or "—",
    }
    if secondary:
        detail["משני (ללא זיכוי)"] = secondary
    if unmapped:
        detail["שאלות ללא נושא מזוהה"] = unmapped

    if unmapped:
        rep.add("G70", FAIL, "שאלות בלי נושא שניתן למפות למסלול", detail)
    elif missing:
        detail["חסר"] = missing
        rep.add("G70", FAIL, "כיסוי תחומים מתחת לרצפה של הפריסה", detail)
    else:
        rep.add("G70", PASS, "כל תחום ≥10% משעות המסלול מיוצג", detail)


# --------------------------------------------------------------------------
# G71 — track legality
# --------------------------------------------------------------------------

def gate_G71(rep, cur, spec, allow=(), text=None):
    track_name = spec["track"]
    track = cur.track(track_name)
    valid = {t["id"] for t in track["topics"]}

    unknown = []
    for q in spec["questions"]:
        for tid in (q.get("topics") or []):
            if tid not in valid:
                unknown.append((q["n"], tid))

    hits_explicit, hits_soft, overridden = [], [], []
    if text:
        for ex in cur.excluded_keywords(track_name):
            hit = has_keyword(text, ex["keywords"])
            if not hit:
                continue
            entry = {"נושא": ex["topic"], "מילה שנמצאה": hit}
            if ex["topic"] in allow and ex["basis"] == "not_in_track":
                overridden.append(entry)
            elif ex["basis"] == "explicit":
                hits_explicit.append(entry)
            else:
                hits_soft.append(entry)

    detail = {}
    if unknown:
        detail["נושאים שאינם במסלול"] = ["שאלה {}: {}".format(n, t) for n, t in unknown]
    if hits_explicit:
        detail["אסור מפורשות (לא ניתן לעקיפה)"] = hits_explicit
    if hits_soft:
        detail["לא קיים במסלול (ניתן לעקיפה ב---allow)"] = hits_soft
    if overridden:
        detail["נעקף באישור מפורש"] = overridden
    if text is None:
        detail["סריקת טקסט"] = "לא בוצעה — לא נמסר PDF"

    if unknown or hits_explicit or hits_soft:
        rep.add("G71", FAIL, "חריגה מהפריסה של {}".format(track_name), detail)
    else:
        rep.add("G71", PASS, "כל התוכן בתוך הפריסה של {}".format(track_name), detail)


# --------------------------------------------------------------------------
# G72 — practice volume
# --------------------------------------------------------------------------

def gate_G72(rep, cur, spec):
    vol = cur.policy["volume_rule"]
    qs = spec["questions"]
    n = len(qs)
    if n == 0:
        rep.add("G72", FAIL, "אין שאלות בכלל", {})
        return

    fig_ratio = sum(1 for q in qs if q.get("figure")) / n
    is_geo_sheet = fig_ratio >= 0.60
    min_q = (vol["min_main_questions_geometry_sheet"] if is_geo_sheet
             else vol["min_main_questions_general"])
    min_total = (vol["min_total_subitems_geometry"] if is_geo_sheet
                 else vol["min_total_subitems_general"])

    subs = [int(q.get("subitems", 0)) for q in qs]
    total = sum(subs)
    mean = total / n
    too_few = [q["n"] for q, s in zip(qs, subs) if s < vol["min_subitems_per_question"]]
    too_many = [q["n"] for q, s in zip(qs, subs) if s > vol["max_subitems_per_question"]]

    problems = []
    if n < min_q:
        problems.append("שאלות ראשיות {} < {}".format(n, min_q))
    if total < min_total:
        problems.append("סעיפי תרגול {} < {}".format(total, min_total))
    if mean < vol["mean_subitems_per_question"]:
        problems.append("ממוצע סעיפים {:.2f} < {}".format(
            mean, vol["mean_subitems_per_question"]))
    if too_few:
        problems.append("מתחת ל-{} סעיפים: שאלות {}".format(
            vol["min_subitems_per_question"], too_few))
    if too_many:
        problems.append("מעל {} סעיפים: שאלות {}".format(
            vol["max_subitems_per_question"], too_many))

    detail = {
        "סוג דף": "גאומטרי ({:.0%} עם שרטוט)".format(fig_ratio) if is_geo_sheet
                  else "רגיל ({:.0%} עם שרטוט)".format(fig_ratio),
        "שאלות": "{} (רצפה {})".format(n, min_q),
        "סעיפים": "{} (רצפה {})".format(total, min_total),
        "ממוצע": "{:.2f}".format(mean),
    }
    if problems:
        detail["כשלים"] = problems
        rep.add("G72", FAIL, "נפח תרגול מתחת לרצפת הבית", detail)
    else:
        rep.add("G72", PASS, "נפח תרגול תקין", detail)


# --------------------------------------------------------------------------
# G73 — marker format
# --------------------------------------------------------------------------

# RTL extraction flips both the parentheses pair and the trailing period,
# so every pattern is matched in both directions.
# A marker sits at the START of a line (LTR extraction) or at its END
# (RTL extraction flips the run). Anchoring is the whole point: an
# unanchored r"\(\d{1,2}\)" matches f(4) in a table of function values,
# which is how a sheet numbered "1." was reported as correctly numbered.
RE_GOOD_START = re.compile(r"^\s*(?:\(\d{1,2}\)|\)\d{1,2}\()")
RE_GOOD_END = re.compile(r"(?:\(\d{1,2}\)|\)\d{1,2}\()\s*$")
# THIRD form, and the one a real build actually produces. pdftotext emits a
# correct `(N)` marker inside an RTL paragraph as: RLE `)` LRE `(N` PDF PDF.
# Once the bidi controls are stripped that reads `)(N` — the closing paren
# has migrated to the front. Verified against a rasterised page: the sheet
# prints `(1)`, and only the extraction is rearranged. It must be the WHOLE
# line (a marker sits in its own box), otherwise a math line beginning
# `(2x+1)(x+3)` would be counted as marker number 2.
RE_GOOD_SPLIT = re.compile(r"^\)\(\d{1,2}\s*\u2605?\s*$")
# "1." / ".1" — with or without a following space, digits excluded so that
# decimals (3.5) and the answers page (.15) are not mistaken for markers.
RE_BAD_START = re.compile(r"^\s*(?:\d{1,2}\.(?!\d)|(?<!\d)\.\d{1,2}(?!\d))")
RE_BAD_END = re.compile(r"(?:(?<!\.)\d{1,2}\.(?!\d)|(?<!\d)\.\d{1,2}(?!\d))\s*$")


def count_markers(text):
    """(good, [blocking bad lines], [suspect lines]).

    A line-START `1.` / `.1` is unambiguously a question marker and blocks.
    A line-END digit+period is usually an ordinary Hebrew sentence that
    happens to finish on a number ("...מכפלת הניצבים חלקי 2.") — flagging
    those as markers made the gate cry wolf on correct sheets, so they are
    reported as suspects for the eye, not as failures."""
    good, bad, suspect = 0, [], []
    for ln in text.splitlines():
        s = ln.strip()
        if not s:
            continue
        if (RE_GOOD_START.match(s) or RE_GOOD_END.search(s)
                or RE_GOOD_SPLIT.match(s)):
            good += 1
        elif RE_BAD_START.match(s):
            bad.append(s[:60])
        elif RE_BAD_END.search(s):
            suspect.append(s[:60])
    return good, bad, suspect


def gate_G73(rep, cur, text):
    if text is None:
        rep.add("G73", SKIP, "לא נמסר PDF — לא ניתן לבדוק מרקרים", {})
        return
    rule = cur.policy["marker_rule"]
    good, bad, suspect = count_markers(text)
    detail = {"נדרש": rule["required"],
              "מרקרים תקינים": good,
              "שורות עם מרקר אסור": len(bad)}
    if suspect:
        detail["חשוד (שורה המסתיימת בספרה ונקודה)"] = suspect[:4]
    if bad:
        detail["דוגמאות"] = bad[:6]
        rep.add("G73", FAIL, "מרקרים בפורמט אסור", detail)
    elif good == 0:
        rep.add("G73", FAIL, "לא נמצא ולו מרקר אחד בפורמט (N)", detail)
    elif suspect:
        rep.add("G73", WARN, "מרקרים תקינים; שורות חשודות לבדיקה בעין", detail)
    else:
        rep.add("G73", PASS, "מרקרים בפורמט (N)", detail)


# --------------------------------------------------------------------------
# G74 — geometry questions carry figures
# --------------------------------------------------------------------------

def gate_G74(rep, cur, spec):
    geo = []
    for q in spec["questions"]:
        topics = q.get("topics") or []
        if not topics:
            continue
        t0 = cur.topic(spec["track"], topics[0])
        if t0 and t0["domain"] == "גיאומטרי":
            geo.append(q)
    if not geo:
        rep.add("G74", SKIP, "אין שאלות גיאומטריה בדף — G70 מטפל בזה", {})
        return
    with_fig = sum(1 for q in geo if q.get("figure"))
    ratio = with_fig / len(geo)
    detail = {"שאלות גיאומטריה": len(geo),
              "עם שרטוט": with_fig,
              "שיעור": "{:.0%}".format(ratio)}
    if with_fig == 0:
        rep.add("G74", FAIL, "אף שאלת גיאומטריה בלי שרטוט", detail)
    elif ratio < 0.70:
        rep.add("G74", WARN, "פחות מ-70% משאלות הגיאומטריה נושאות שרטוט", detail)
    else:
        rep.add("G74", PASS, "שאלות הגיאומטריה נושאות שרטוטים", detail)


# --------------------------------------------------------------------------
# audit mode — no spec, keyword sweep of a built PDF
# --------------------------------------------------------------------------

def audit(rep, cur, track_name, text):
    """Forensic pass on a finished PDF. Coverage is keyword-inferred and
    therefore WARN-level — except a domain with zero hits, which is decisive."""
    track = cur.track(track_name)
    shares = track["domain_share"]

    good_m, bad_m, _sus = count_markers(text)
    n_markers = good_m + len(bad_m)

    hits = {}
    for t in track["topics"]:
        hit = has_keyword(text, t.get("keywords", []))   # strong only
        if hit:
            hits.setdefault(t["domain"], []).append(
                "{} ({})".format(t["name"], hit))

    # A domain worth a third of the year cannot be represented by ONE topic.
    # Without this, a single "למלבן היקף 40" inside an algebra optimisation
    # question reports that geometry is covered.
    thin = {}
    for d, sh in shares.items():
        if sh < 0.10:
            continue
        need = 2 if sh >= 0.25 else 1
        got = len(hits.get(d, []))
        if got < need:
            thin[d] = "{} נושאים · דרוש ≥{} ({:.0%} מהשעות)".format(got, need, sh)

    detail = {"מרקרים שזוהו": n_markers,
              "שעות לפי תחום": track["domain_hours"]}
    for d in shares:
        detail["נמצא · " + d] = hits.get(d, "—")
    if thin:
        detail["ייצוג דל מדי"] = thin
        rep.add("G70", FAIL,
                "תחומים מרכזיים במסלול כמעט אינם מופיעים בדף", detail)
    else:
        rep.add("G70", WARN,
                "כל התחומים מיוצגים לפי מילות מפתח — ספירה מדויקת דורשת spec",
                detail)

    gate_G71(rep, cur, {"track": track_name, "questions": []}, text=text)
    gate_G73(rep, cur, text)
    rep.add("G72", SKIP, "נפח סעיפים לא ניתן לספירה מטקסט — נדרש spec", {})
    rep.add("G74", SKIP, "נוכחות שרטוטים לא ניתנת לספירה מטקסט — נדרש spec", {})


# --------------------------------------------------------------------------
# selftest — both directions, like every other tool in this skill
# --------------------------------------------------------------------------

def selftest(curriculum_path):
    cur = Curriculum(curriculum_path)
    ok = True

    def q(n, topics, subs, fig=False):
        return {"n": n, "topics": topics, "subitems": subs, "figure": fig}

    # -- direction 1: the sheet that actually shipped. must FAIL.
    bad = {"track": "ט_מצומצמת", "scope_mode": "broad",
           "questions": [q(i, ["equations"], 1) for i in range(1, 21)]}
    rep = Report()
    gate_G70(rep, cur, bad)
    gate_G71(rep, cur, bad, text="מצאו את הקודקוד ואת ציר הסימטריה")
    gate_G72(rep, cur, bad)
    gate_G74(rep, cur, bad)
    for g in ("G70", "G71", "G72"):
        if rep.status_of(g) != FAIL:
            print("SELFTEST FAIL: {} should have failed the shipped sheet".format(g))
            ok = False

    # -- direction 2: a compliant sheet. must PASS.
    good = {"track": "ט_מצומצמת", "scope_mode": "broad", "questions": []}
    plan = ([("pythagoras", True)] * 3 + [("similarity", True)] * 2 +
            [("rectangle", True)] * 2 + [("kite_and_isosceles", True)] * 2 +
            [("linear_function", False)] * 3 + [("equations", False)] * 3 +
            [("quad_partial", False)] * 3 + [("statistics", False)] * 2 +
            [("probability", False)] * 2)
    for i, (tid, fig) in enumerate(plan, 1):
        good["questions"].append(q(i, [tid], 3, fig))
    rep2 = Report()
    gate_G70(rep2, cur, good)
    gate_G71(rep2, cur, good, text="מצאו את שטח המלבן והיקפו")
    gate_G72(rep2, cur, good)
    gate_G74(rep2, cur, good)
    for g in ("G70", "G71", "G72", "G74"):
        if rep2.status_of(g) != PASS:
            print("SELFTEST FAIL: {} should have passed the compliant sheet"
                  .format(g))
            print(rep2.render())
            ok = False

    # -- direction 3: marker gate, both ways.
    r3 = Report()
    gate_G73(r3, cur, "(1) פתרו\n(2) חשבו")
    if r3.status_of("G73") != PASS:
        print("SELFTEST FAIL: G73 rejected valid (N) markers"); ok = False
    r4 = Report()
    gate_G73(r4, cur, "1. פתרו\n.2 חשבו")
    if r4.status_of("G73") != FAIL:
        print("SELFTEST FAIL: G73 accepted 1. / .2 markers"); ok = False

    # -- direction 4: the two bugs found on the shipped sheets, Sep 2026.
    #    Both were VACUOUS PASSES — the worst kind. They stay pinned here.
    if has_keyword("נתונה הפונקציה הריבועית", ["ריבוע"]) is not None:
        print("SELFTEST FAIL: 'ריבוע' matched inside 'ריבועית'"); ok = False
    if has_keyword("שטח המלבן", ["שטח"]) is not None:
        print("SELFTEST FAIL: weak keyword 'שטח' established a topic"); ok = False
    if has_keyword("שטח המלבן", ["שטח"], allow_weak=True) is None:
        print("SELFTEST FAIL: allow_weak did not re-enable weak keywords"); ok = False
    g, b, _ = count_markers("f(0)=5, f(1)=2, f(2)=1")
    if g:
        print("SELFTEST FAIL: f(N) counted as a question marker"); ok = False
    g, b, _ = count_markers("1.פתרו: 3x+7=25")
    if not b:
        print("SELFTEST FAIL: '1.' with no following space went undetected")
        ok = False
    g, b, _ = count_markers("(1) פתרו: 3x+7=25")
    if g != 1 or b:
        print("SELFTEST FAIL: valid '(1)' marker rejected"); ok = False
    # the RTL-extraction form of a correct (N), and the math line it must
    # NOT be confused with
    g, b, _ = count_markers(")(1\n)(18 \u2605")
    if g != 2:
        print("SELFTEST FAIL: RTL-split ')(N' marker not recognised"); ok = False
    g, b, _ = count_markers(")(2x + 1)(x + 3")
    if g:
        print("SELFTEST FAIL: a math line was counted as a marker"); ok = False
    g, b, s3 = count_markers("7.5")
    if b or s3:
        print("SELFTEST FAIL: the decimal 7.5 alone on a line was read as a "
              "marker"); ok = False
    g, b, _ = count_markers("התשובה היא 3.5 מטרים")
    g2, b2, s2 = count_markers("מכפלת הניצבים חלקי 2.")
    if b2:
        print("SELFTEST FAIL: a Hebrew sentence ending on a number was "
              "reported as a forbidden marker"); ok = False
    if not s2:
        print("SELFTEST FAIL: line-end digit+period not reported as suspect")
        ok = False
    if b:
        print("SELFTEST FAIL: decimal 3.5 read as a marker"); ok = False

    print("SELFTEST {}".format("PASS" if ok else "FAIL"))
    return 0 if ok else 1


# --------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(add_help=True)
    ap.add_argument("--spec")
    ap.add_argument("--pdf")
    ap.add_argument("--track")
    ap.add_argument("--curriculum", default=DEFAULT_CURRICULUM)
    ap.add_argument("--allow", action="append", default=[])
    ap.add_argument("--report")
    ap.add_argument("--non-strict", action="store_true")
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()

    if a.selftest:
        return selftest(a.curriculum)

    if not os.path.exists(a.curriculum):
        print("שגיאה: לא נמצא {}".format(a.curriculum), file=sys.stderr)
        return 2
    cur = Curriculum(a.curriculum)

    text = None
    if a.pdf:
        if not os.path.exists(a.pdf):
            print("שגיאה: לא נמצא {}".format(a.pdf), file=sys.stderr)
            return 2
        text = pdf_text(a.pdf)
        if text is None:
            print("אזהרה: pdftotext לא זמין — שערי הטקסט ידווחו SKIPPED",
                  file=sys.stderr)

    rep = Report()
    strict = not a.non_strict

    if a.spec:
        with open(a.spec, encoding="utf-8") as fh:
            spec = json.load(fh)
        header = "{} · {} · {}".format(spec.get("title", "—"),
                                       spec.get("level", "—"), spec["track"])
        gate_G70(rep, cur, spec)
        gate_G71(rep, cur, spec, allow=a.allow, text=text)
        gate_G72(rep, cur, spec)
        gate_G73(rep, cur, text)
        gate_G74(rep, cur, spec)
    elif a.pdf and a.track:
        header = "ביקורת טקסט · {} · {}".format(os.path.basename(a.pdf), a.track)
        if text is None:
            print("שגיאה: אין טקסט לביקורת", file=sys.stderr)
            return 2
        audit(rep, cur, a.track, text)
    else:
        ap.print_help()
        return 2

    print("\n" + header)
    print("-" * max(40, len(header)))
    print(rep.render())

    if a.report:
        with open(a.report, "w", encoding="utf-8") as fh:
            json.dump({"header": header, "strict": strict, "rows": rep.rows},
                      fh, ensure_ascii=False, indent=2)

    failed = rep.failed(strict=strict)
    print("-" * max(40, len(header)))
    print("תוצאה: {}".format("נפילה" if failed else "עבר"))
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
