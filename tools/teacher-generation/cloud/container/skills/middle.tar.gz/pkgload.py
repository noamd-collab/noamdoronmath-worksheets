# -*- coding: utf-8 -*-
u"""pkgload — v7.2.0. Load a worksheet package the way build.py does, without building it.

The v7.2 post-build tools (gate_sections, emit_docx, catalog_build, landing_build)
all need the same three things from a package folder:

    LEVELS   the level dicts content.py defines (after final_answers_hook.apply)
    IR       per level, D.normalize(WB.expand_level(L)) -- the very object
             build.py hands to emit_html.build_html (build.py:66-70), so the
             DOCX and the gates read exactly what the PDF printed
    SHEET    the module-level sections manifest (sheet_meta.SHEET), or None for
             a legacy package

SHEET stays OUT of the level dicts on purpose: deliver._level_numbers walks every
string inside L, so ids or ranges stored there would whitelist their digits for
STRICT_NUMBERS (critic probe, deliver.py:305-309, 326-381).

    import pkgload
    P = pkgload.load("/abs/package")       # P.levels, P.ir, P.sheet, P.module

Nothing here writes a file.
"""
import importlib.util
import os
import sys
from pathlib import Path

# Loading a package imports its modules and skill modules; none of that may
# leave __pycache__ in the skill or package folders (final review, 2026-11-09).
sys.dont_write_bytecode = True

SKILL = Path(__file__).resolve().parent
if str(SKILL) not in sys.path:
    sys.path.insert(0, str(SKILL))

LEVEL_KEYS = ("a", "b", "c")
LEVEL_NAMES = {"a": u"רמה א׳", "b": u"רמה ב׳", "c": u"מצוינות"}


class Package(object):
    def __init__(self, path, module, levels, ir, sheet):
        self.path = path
        self.module = module
        self.levels = levels          # {key: L}
        self.ir = ir                  # {key: normalized L}
        self.sheet = sheet            # dict or None
        self.package = getattr(module, "PACKAGE", None)

    @property
    def keys(self):
        return [k for k in LEVEL_KEYS if k in self.levels]


def _inside(mod, root):
    f = getattr(mod, "__file__", None)
    if not f:
        return False
    try:
        Path(f).resolve().relative_to(root)
        return True
    except (ValueError, OSError):
        return False


def _purge_package_modules(pkg):
    """Drop cached modules that belong to a package folder, or that shadow one.

    content.py imports its siblings by bare name (kit, sheet_meta, level_a,
    final_answers, final_answers_hook ...). Python caches them in sys.modules
    by that bare name, so loading a second package in the same process would
    silently hand it the FIRST package's kit/levels (fixtures review, 2026-11-09).
    Before a load we drop any cached module whose name matches a .py file in the
    package but lives elsewhere -- the skill folder included: a package that
    imported final_answers_hook from the skill must not hand the skill's copy to
    a later package that ships its own (final review, 2026-11-09). After the
    load we drop the package's own modules. A dropped skill module is simply
    imported again on its next use.
    """
    local = {p.stem for p in pkg.glob("*.py")}
    for name, mod in list(sys.modules.items()):
        if mod is None:
            continue
        if _inside(mod, pkg) or name in local:
            sys.modules.pop(name, None)


def load(pkg_dir, with_ir=True):
    pkg = Path(pkg_dir).resolve()
    content = pkg / "content.py"
    if not content.is_file():
        raise FileNotFoundError("no content.py in %s" % pkg)
    old_cwd = os.getcwd()
    old_path = list(sys.path)
    _purge_package_modules(pkg)
    os.chdir(str(pkg))
    sys.path.insert(0, str(pkg))
    try:
        name = "content_%x" % (abs(hash(str(pkg))) & 0xFFFFFFFF)
        spec = importlib.util.spec_from_file_location(name, str(content))
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        levels = {}
        for L in m.LEVELS:
            L.setdefault("title", getattr(m, "TITLE", u"דף עבודה"))
            levels[L.get("key", "x")] = L
        ir = {}
        if with_ir:
            import deliver as D
            import wspec_build as WB
            for k, L in levels.items():
                ir[k] = D.normalize(WB.expand_level(L))
        sheet = getattr(m, "SHEET", None)
        return Package(pkg, m, levels, ir, sheet)
    finally:
        _purge_package_modules(pkg)
        os.chdir(old_cwd)
        sys.path[:] = old_path


def deliver_dir(pkg_dir):
    """The deliver root a build of this package writes (build.py:50)."""
    P = load(pkg_dir, with_ir=False)
    d = getattr(P.module, "DELIVER_DIR", "") or (Path(pkg_dir) / "out" / "deliver")
    return Path(d)
