# -*- coding: utf-8 -*-
"""G81 -- an angle is ALWAYS named with three letters (v6.11 fix r1).

The author's decision W-ANGLE-3-LETTERS (wspec/approvals/APPROVALS_NOAM.json,
24.9.2026: "תמיד זווית עם 3 אותיות"): generated text, keys, figure labels,
prose and question wording carried over from the original sheets name an
angle by three letters (∠BAC), never by its vertex alone (∠A, "זווית A").

This gate reads a DELIVERED level folder and FAILS on any one-letter angle
name in what the package prints or tells Noam AI:
  sheet.json     every string (texts, givens, to_prove, find texts, answers,
                 key rows, figure relations) -- the texts the page prints:
                 G80-text binds every printed block of sheet.pdf to them
  noam-ai.json   every string
  sheet.html     its visible TEXT (a backstop: the emitter draws some maths,
                 "∠B" among it, as inline SVG paths with no text; those are
                 read through sheet.json above, which G80 binds to the page)
Each finding names where it is and the three-letter form to print instead
(the angle entities of the level's spec with that vertex, those of the same
question first).

    python3 anglenames.py <deliver>/<k> [--json]      exit 0 PASS, 1 FAIL

On the spec side wspec_build.three_letter_angles drops a one-letter angle
display, so the engine prints the angle entity's own three letters. The
schema itself still ACCEPTS such a display (frozen v6.9 specs and the
engine's tests carry them); the refusal is this gate, on what a package
actually prints. Stdlib only."""
import html as _html
import json
import os
import re
import sys

PASS, FAIL = "PASS", "FAIL"
NAME = r"[A-Z](?:_?\d+)?['\u2032\u2019]*"
_END = r"(?![A-Za-z0-9'\u2032\u2019_])"
PATTERNS = (
    # ∠A, ∡A (a sign before ONE point name)
    re.compile(r"[\u2220\u2221]\s*(" + NAME + r")" + _END),
    # \angle{A}, \angle A (tex source in the JSON texts)
    re.compile(r"\\angle\s*\{\s*(" + NAME + r")\s*\}"),
    re.compile(r"\\angle\s+(" + NAME + r")" + _END),
    # זווית A, הזווית B, בזווית C ... (the word, then ONE point name)
    re.compile(u"\u05d6\u05d5\u05d5\u05d9\u05ea\\s+(" + NAME + r")" + _END),
)
# bidi controls and marks the emitter may put between a sign and a name
_BIDI = re.compile(u"[\u200e\u200f\u202a-\u202e\u2066-\u2069\u061c]")
_Q = re.compile(r"^(q\d+)")


def find(text):
    """[(matched text, point name)] of every one-letter angle in `text`."""
    t = _BIDI.sub("", text or "")
    out = []
    for p in PATTERNS:
        for m in p.finditer(t):
            out.append((m.group(0), m.group(1)))
    return out


def html_text(h):
    """The visible text of an HTML document (style / script / svg <title>
    dropped, tags removed, entities decoded)."""
    h = re.sub(r"(?is)<(style|script|title)\b.*?</\1>", " ", h)
    h = re.sub(r"(?s)<[^>]+>", "", h)
    return _html.unescape(h)


def _walk(o, path, out):
    if isinstance(o, dict):
        for k, v in o.items():
            _walk(v, "%s.%s" % (path, k), out)
    elif isinstance(o, list):
        for i, v in enumerate(o):
            _walk(v, "%s[%d]" % (path, i), out)
    elif isinstance(o, str):
        out.append((path, o))


def _qid_of(doc, path):
    m = re.match(r"^\.questions\[(\d+)\]", path)
    if m:
        try:
            return doc["questions"][int(m.group(1))].get("id")
        except (KeyError, IndexError, TypeError, AttributeError):
            return None
    m = re.match(r"^\.figures\[(\d+)\]", path)
    if m:
        try:
            fid = doc["figures"][int(m.group(1))].get("id") or ""
        except (KeyError, IndexError, TypeError, AttributeError):
            return None
        mm = _Q.match(str(fid))
        return mm.group(1) if mm else None
    return None


def _angles(level_dir):
    """[(vertex, three-letter name, question ids)] of the level spec."""
    p = os.path.join(level_dir, "source", "level_spec.json")
    if not os.path.isfile(p):
        return []
    try:
        with open(p, encoding="utf-8") as fh:
            sp = json.load(fh)
        sp = sp.get("spec", sp)
    except (OSError, ValueError):
        return []
    used = {}
    for f in sp.get("facts") or []:
        q = _Q.match(str(f.get("item") or f.get("id") or ""))
        for a in f.get("args") or []:
            if isinstance(a, str) and q:
                used.setdefault(a, set()).add(q.group(1))
    # an entity a question's TEXT names (in_triangle's △ABC is a text
    # entity, not a fact argument)
    for q in sp.get("questions") or []:
        qid = q.get("id")
        stack = [q]
        while stack:
            o = stack.pop()
            if isinstance(o, dict):
                for k, v in o.items():
                    if k == "entities" and isinstance(v, list):
                        for x in v:
                            if isinstance(x, str):
                                used.setdefault(x, set()).add(qid)
                    else:
                        stack.append(v)
            elif isinstance(o, list):
                stack.extend(o)
    out = []
    polys = [(set(e.get("vertices") or []), used.get(e.get("id"), set()))
             for e in sp.get("entities") or [] if e.get("kind") == "polygon"]
    for e in sp.get("entities") or []:
        if e.get("kind") != "angle":
            continue
        a = sorted(e.get("arms") or [])
        if len(a) != 2:
            continue
        qs = used.get(e.get("id"), set())
        # an angle OF a polygon the same question names (∠ABC of △ABC)
        of_poly = set(q for vs, pq in polys if set(a + [e["vertex"]]) <= vs
                      for q in pq)
        out.append((e.get("vertex"), a[0] + e["vertex"] + a[1], qs, of_poly))
    return out


def suggest(angles, point, qid):
    """The three-letter name(s) for a one-letter angle at `point`."""
    cand = []
    for pick in (lambda qs, op: qid in qs and qid in op,
                 lambda qs, op: qid in qs,
                 lambda qs, op: bool(op),
                 lambda qs, op: True):
        cand = sorted(set(n for v, n, qs, op in angles
                          if v == point and pick(qs, op)))
        if cand:
            break
    if len(cand) == 1:
        return u"\u2220" + cand[0]
    if cand:
        return u"one of " + ", ".join(u"\u2220" + c for c in cand[:4])
    return u"\u2220X%sY (the arms' points around the vertex %s)" % (point,
                                                                     point)


def check_level(level_dir):
    """{"status", "findings": [{"file", "where", "question", "found",
    "three_letters"}], "scanned": [...]}"""
    angles = _angles(level_dir)
    findings, scanned = [], []
    for base in ("sheet.json", "noam-ai.json"):
        p = os.path.join(level_dir, base)
        if not os.path.isfile(p):
            continue
        scanned.append(base)
        with open(p, encoding="utf-8") as fh:
            doc = json.load(fh)
        strs = []
        _walk(doc, "", strs)
        for path, s in strs:
            for found, pt in find(s):
                qid = _qid_of(doc, path)
                findings.append({"file": base, "where": path,
                                 "question": qid, "found": found,
                                 "three_letters": suggest(angles, pt, qid)})
    p = os.path.join(level_dir, "sheet.html")
    if os.path.isfile(p):
        scanned.append("sheet.html")
        with open(p, encoding="utf-8") as fh:
            t = html_text(fh.read())
        for found, pt in find(t):
            i = t.find(found)
            ctx = re.sub(r"\s+", " ", t[max(0, i - 40):i + 30]).strip()
            findings.append({"file": "sheet.html", "where": ctx,
                             "question": None, "found": found,
                             "three_letters": suggest(angles, pt, None)})
    status = FAIL if findings else PASS
    if not scanned:
        status = FAIL
        findings.append({"file": None, "where": level_dir, "question": None,
                         "found": None, "three_letters": None,
                         "detail": "nothing to read (no sheet.html, "
                                   "sheet.json or noam-ai.json)"})
    return {"gate": "G81-angle-names", "status": status,
            "findings": findings, "scanned": scanned}


def line(key, r):
    if r["status"] == PASS:
        return "G81-angles %-3s PASS: no one-letter angle name (%s)" % (
            key, ", ".join(r["scanned"]))
    f = r["findings"][0]
    return ("G81-angles %-3s FAIL: %d one-letter angle name(s); first: %r "
            "in %s %s -> print %s (author rule W-ANGLE-3-LETTERS)" % (
                key, len(r["findings"]), f.get("found"), f.get("file"),
                f.get("question") or f.get("where"), f.get("three_letters")))


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    js = "--json" in argv
    dirs = [a for a in argv if a != "--json"]
    if len(dirs) != 1:
        print(__doc__)
        return 2
    r = check_level(dirs[0])
    if js:
        print(json.dumps(r, ensure_ascii=False, indent=1))
    else:
        print(line(os.path.basename(os.path.normpath(dirs[0])), r))
        for f in r["findings"][:40]:
            print("  %s %s: %r -> %s" % (f.get("file"), f.get("question") or
                                         f.get("where"), f.get("found"),
                                         f.get("three_letters")))
    return 0 if r["status"] == PASS else 1


if __name__ == "__main__":
    sys.exit(main())
