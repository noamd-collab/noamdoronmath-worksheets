# -*- coding: utf-8 -*-
r"""check_didactic.py -- v6.7.1-noam: an INDEPENDENT check of the author's
didactic policy (BRIEF_V671 §8) on finished level folders. Standard library
only; it imports nothing from the skill. It reads what a level folder holds:
noam-ai.json (public), figures/*.svg, and the PRIVATE sheet.json (answers,
declared dashed lines, aux `completes`) and didactic.json (hints). It reads
curriculum_tools.json beside itself, when present, for tool keywords (when
it is missing the tool check is reported off as REVIEW D6, never silent).

    python3 check_didactic.py out/deliver/a out/deliver/b out/deliver/c
    python3 check_didactic.py            # its own pass + fail fixtures

Per level it prints PASS / FAIL / REVIEW counts and the items: an item is
FAIL when any rule fails on it, REVIEW when a rule cannot decide (it is
never auto-passed), PASS otherwise. Exit 0 = all PASS, 1 = a FAIL, 2 = no
FAIL but something to REVIEW.

  D1 a conclusion that appears as a given: one relation in given and in
     to_prove / to_construct of a question (a given carried over from an
     earlier item with from_item is allowed); a given that is the claim the
     item's own text asks to prove; r2: a from_item that names no item, a
     later item, or one whose to_prove / to_construct lacks the relation
  D2 a helper line or a construction result in the starting figure: a
     dashed stroke that is not a hidden edge of a solid (hidden_edge) and
     not declared dashed by the question (a declared dashed name counts
     only when the text itself calls it dashed -- r1); a to_construct
     object drawn; REVIEW: a solid segment that is no side of a drawn
     polygon, lies on no side, and the text / claims never name (plane
     figures only -- r2: a solid's edges are all segments)
  D3 a colour or a mark that reveals a goal: fill / stroke off the ink-and-
     grey palette; a marked constraint that is a to_prove / to_construct
  D4 a mark in the figure that is not in `given`: a marked constraint that
     is not a given (a given shape covers the marks of its definition); a
     mark element (tick, arc, right angle, chevron) no constraint accounts
     for and no given names; a given_mark that is no given; REVIEW: a mark
     covered only by a given the text does not state (r1)
  D5 a hint containing the decisive step: an approved hint, or a hint in
     didactic.json, that states the to_prove (also in words: both objects
     of the claim with a word of its relation -- "באותו אורך", "כמו",
     "מקביל"), the answer or the complete construction -- r2: also its
     points named apart with a construction verb, "חברו את A עם C" (FAIL);
     one that names two or more of the claim's or the construction's
     points, or says the claim's relation about unnamed objects ("שני
     הקטעים ... שווים"), one this reading cannot settle, and every item
     didactic.json flags requires_human_review (REVIEW)
  D6 a theorem / formula outside the package's allowed tools: an item's
     allowed_tools not in the curriculum block's allowed_tools; a hint
     naming a tool that is not yet allowed; no curriculum block at all;
     REVIEW (r2): curriculum_tools.json missing beside this file
  D7 an aux figure showing more than its step: no step / label / reveal
     on_request; it marks a to_prove; it draws a to_construct result
     (unless sheet.json says the step completes exactly that one AND the
     step names it); it
     prints the answer; more aux questions than ~10% of the sheet
  D8 a mismatch between the question text, noam-ai.json and the SVG: a
     name in the text (AB, ∠ABC, triangle MDC) with a point that no figure
     of the question defines (FAIL; a lone capital, which may be a
     variable, is REVIEW); a relation stated in the text that is in none
     of given / to_prove / to_construct (REVIEW), or with another value
     than a declared length / angle (FAIL) -- r2: also a value written in
     words, "אורך AB הוא 10"; a point of a given that the
     SVG does not carry (FAIL)
  D9 an item whose text asks to construct (העבירו / סרטטו / בנו ...) with
     no to_construct (REVIEW)
  D10 an item whose text asks for a proof (הוכיחו / הראו / נמקו; r2: also
     בדקו / שכנעו / בססו / הסבירו and a yes/no question "האם ...?" over
     named points) and declares to_prove=[] (REVIEW: the claim may sit in
     given, worded so no relation reader parses it); FAIL (r2): the asked
     clause restates one of its givens (also as the isosceles triangle
     whose legs the given equates), or the givens overlay offers an own
     given of such an item
     v6.7.2 (BRIEF_V672 item 5): FAIL when the asked claim is typable by
     the relation vocabulary (declare it); REVIEW only for a claim in
     words or a yes/no question, with the reason and didactic.json's note
  D12 (v6.7.2, BRIEF_V672) compute / find targets: an item whose text asks
     to compute / find (חשבו, מצאו, קבעו את, כמה, מהו/מהי, רשמו/כתבו את
     שיעורי, קראו, השלימו, אילו ...?) with to_prove=[] and no
     no_target_reason (FAIL under STRICT -- build.json strict_figures,
     default on -- else REVIEW); an empty no_target_reason; a find target
     outside the vocabulary; a find target whose value is in noam-ai.json
     (the claim, its text, the model's relation) or on highlight_given; a
     find target naming a point / variable / cell / id the question's model
     does not hold; a starting figure (or another item's aux) that prints a
     value label on its object or marks / equates its value
  D13 (v6.9, Codex F4) a question marked spec_unsupported (its public spec
     lacks an essential datum / target): REVIEW with its reason; an empty
     reason FAILS
  V1-V7 the general visual model (§9, visual-model/v1 on every figure and in
     `visuals`): see vm_faults -- schema, model vs SVG, the neutral start,
     aux patches, the closed action list, per-kind constraints (ticks,
     function points, table sums, tree branches, sample space, Venn, bars,
     pie, geometry re-measured from xy); V7 REVIEW: a text that asks for a
     tree / Venn / pie / sample space with no model of that kind
  V6 (v6.10, Codex C3) a typed-shape given (parallelogram, rectangle, ...)
     is offered in highlight_given by EXACTLY what it states (both pairs of
     parallel sides; four right angles as perpendiculars), less a
     statement that is the question's own goal; a statement missing, one
     the shape does not state, one derived from a shape that is no given,
     or one the figure cannot settle FAILS (c3_faults; the same block as
     deliver.py and selfcheck_noam_package.py)
"""
import json
import math
import os
import re
import shutil
import sys
import tempfile
import unicodedata

HERE = os.path.dirname(os.path.abspath(__file__))
TOOLS = os.path.join(HERE, "curriculum_tools.json")
HINT_MODES = ("guiding_question", "concept", "approved_hint")
OBJ_TYPES = ("segment", "line", "ray", "point", "polygon", "circle")
MARK_KINDS = ("ticks", "arc", "parallel", "right_angle")
_P = re.compile(u"[A-Z][0-9]*[\u2032\u2033']*")
_RUN = re.compile(u"(?<![A-Za-z])((?:[A-Z][0-9]*[\u2032\u2033']*)+)"
                  u"(?![A-Za-z])")
_CONSTRUCT = re.compile(u"(?<![א-ת])ו?(?:העבירו|העבר|סרטטו|שרטטו|בנו|"
                        u"הורידו|חברו|הוסיפו|השלימו את השרטוט)(?![א-ת])")
_DASHW = re.compile(u"מקו+קו|קו+קו|מרוסק")
# (v6.16 fix r1) the words that name an axis of symmetry
_SYM_AXIS = re.compile(u"ציר\\s+(?:ה)?סימטריה")


def _vertical_line(svg, sid):
    """(v6.16 fix r1) is the SVG element `sid` a vertical straight stroke
    (a <line> with x1 == x2, or a path 'M x y L x y2')?"""
    if not sid:
        return False
    m = re.search(r'<(line|path)\b[^>]*\bid="%s"[^>]*>' % re.escape(sid),
                  svg or "")
    if not m:
        return False
    el = m.group(0)
    if m.group(1) == "line":
        a = dict(re.findall(r'(x1|x2)="([-\d.]+)"', el))
        return "x1" in a and "x2" in a and \
            abs(float(a["x1"]) - float(a["x2"])) < 0.01
    d = re.search(r'\bd="([^"]+)"', el)
    nums = re.findall(r"[-\d.]+", d.group(1)) if d else []
    if len(nums) != 4 or not re.fullmatch(r"\s*M[^A-Za-z]+L[^A-Za-z]+",
                                          d.group(1)):
        return False
    return abs(float(nums[0]) - float(nums[2])) < 0.01
def _horizontal_line(svg, sid):
    """(v6.16 fix r1 cont.) is the SVG element `sid` a horizontal straight
    stroke (a <line> with y1 == y2, or a path 'M x y L x2 y')?"""
    if not sid:
        return False
    m = re.search(r'<(line|path)\b[^>]*\bid="%s"[^>]*>' % re.escape(sid),
                  svg or "")
    if not m:
        return False
    el = m.group(0)
    if m.group(1) == "line":
        a = dict(re.findall(r'(y1|y2)="([-\d.]+)"', el))
        return "y1" in a and "y2" in a and \
            abs(float(a["y1"]) - float(a["y2"])) < 0.01
    d = re.search(r'\bd="([^"]+)"', el)
    nums = re.findall(r"[-\d.]+", d.group(1)) if d else []
    if len(nums) != 4 or not re.fullmatch(r"\s*M[^A-Za-z]+L[^A-Za-z]+",
                                          d.group(1)):
        return False
    return abs(float(nums[1]) - float(nums[3])) < 0.01


def _eq_norm(t):
    """'y = −16' / '$y=-16$' -> 'y=-16' (spaces, math dollars, the minus)"""
    t = str(t or u"").replace(u"\u2212", u"-").replace(u"$", u"")
    return re.sub(r"\s+", u"", t)


# v6.12 fix_r2: one unnamed dashed line the text names "הקו המקווקו"
_THE_DASHED_LINE = re.compile(u"ה(?:קו|ישר) ה(?:מקו+קו|מרוסק)(?![א-ת])")
_UNNAMED_SEG = re.compile(r"^seg-(?![A-Z])[0-9a-z]+$")
_PROOF = re.compile(u"(?<![א-ת])ו?(?:הוכיחו|הוכיחי|הוכח|הראו|הראי|הראה|"
                    u"נמקו)(?![א-ת])")
# r2 M2: the other ways a sheet asks the student to argue a claim
_ARGUE = re.compile(u"(?<![א-ת])ו?(?:הוכיחו|הוכיחי|הוכח|הראו|הראי|הראה|"
                    u"נמקו|נמקי|נמק|הסבירו|הסבירי|הסבר|הצדיקו|הצדיקי|בססו|"
                    u"בססי|בדקו|בדקי|בדוק|שכנעו|שכנעי|שכנע|ודאו|וודאו|"
                    u"אמתו|הפריכו|הפריכי|הסיקו|הסיקי|הסק)(?![א-ת])|"
                    # r3 M2: a decision asked of a claim is an argument too
                    u"(?<![א-ת])ו?(?:קבעו|קבעי|קבע|בררו|בררי|ברר|הכריעו|"
                    u"הכריעי|הכרע)\\s*(?:אם|האם|:)|"
                    u"(?<![א-ת])נכון\\s+או\\s+לא(?:\\s+נכון)?(?![א-ת])|"
                    u"(?:^|(?<=[.;?!:\n]))\\s*(?:מדוע|למה)"
                    u"(?![א-ת])|(?<![א-ת])האם(?![א-ת])[^?.!\n]*\\?")


def argues(text):
    """does the text ask the student to argue a geometric claim (a request
    word or a yes/no question, over a text naming two or more points)?"""
    t = str(text or "")
    return bool(_ARGUE.search(t)) and any(
        len(tk(u)) >= 2 for u in _RUN.findall(t))


def argued(text):
    """the clauses that say what is to be argued: request word to the end
    of its sentence; a yes/no question whole"""
    t = str(text or "")
    out = []
    for m in _ARGUE.finditer(t):
        if m.group(0).lstrip().startswith(u"האם"):
            out.append(m.group(0))
            continue
        e = re.compile(u"[.?!;\n]").search(t, m.end())
        out.append(t[m.end():e.start() if e else len(t)])
    return [c for c in out if c.strip()]


def restated(text, c):
    """the clause states the given c: stated(), or the isosceles triangle
    whose legs c equates ('המשולש MDC שווה שוקיים')"""
    if stated(c, text):
        return True
    if c.get("type") == "equal_length" and re.search(
            u"שוו(?:ה|ת).?שוקיים", str(text)):
        sg = [tk(x) for x in c.get("of") or []]
        if len(sg) == 2 and all(len(x) == 2 for x in sg):
            P = set(sg[0]) | set(sg[1])
            if len(set(sg[0]) & set(sg[1])) == 1 and len(P) == 3:
                return any(set(tk(u)) == P and len(tk(u)) == 3
                           for u in _RUN.findall(str(text)))
    return False


_THEOREM = re.compile(u"משפט|חוק|טריגונומטר|סינוס|קוסינוס|טנגנס|"
                      u"דמיון|דומים|חפיפ|פיתגור|נוסח")


def unasked(text):
    """r3 M1: the text with every asked clause cut out -- what is left is
    what the text STATES (a claim written there is written as a fact)"""
    t = str(text or "")
    spans = []
    for m in _ARGUE.finditer(t):
        if m.group(0).lstrip().startswith(u"האם"):
            spans.append((m.start(), m.end()))
            continue
        e = re.compile(u"[.?!;\n]").search(t, m.end())
        spans.append((m.start(), e.start() if e else len(t)))
    out, last = [], 0
    for a, b in sorted(spans):
        if a > last:
            out.append(t[last:a])
        last = max(last, b)
    out.append(t[last:])
    return " ".join(out)


_SHAPE_WORD = {"rectangle": u"מלבן", "square": u"ריבוע",
               "parallelogram": u"מקבילית", "rhombus": u"מעוין",
               "trapezoid": u"טרפז", "kite": u"דלתון",
               "isosceles": u"שוו(?:ה|ת).?שוקיים",
               "equilateral": u"שוו(?:ה|ת).?צלעות",
               "right_triangle": u"ישר.?זווית"}


def _source_read_off_claim(c, iid, public_spec):
    """A source-linked native read-off is a request, never a proposition.
    This only classifies D11; no find/answer-leak check is waived.
    """
    if set(c) != {"text", "facts"} or len(c.get("facts") or []) != 1:
        return False
    try:
        q = next(q for q in public_spec.get("questions", []) if any(i.get("id") == iid for i in q.get("items", [])))
        it = next(i for i in q["items"] if i["id"] == iid)
        target = next(t for t in it["targets"] if t["id"] == c["facts"][0])
        g = next(g for g in public_spec.get("figures", []) if g.get("scope") == q["id"] and g.get("base_height"))
        fs = {f["id"]: f for f in public_spec["facts"]}
        return bool(it["task_type"] == "read_off" and it["measurement_allowed"] is True and target["role"] == "target" and target["rel"] == "length" and c["text"] == it["text"] == target["description"] and any(target["args"] == fs[g["base_height"][k]]["args"] for k in ("base", "height")))
    except (KeyError, TypeError, StopIteration):
        return False


def asserts(text, c):
    """r3 M1: does `text` state the claim c as a fact? A shape only with
    its own word ('ABCD מקבילית' does not state 'ABCD מלבן'); a length or
    an angle only with its value."""
    t = c.get("type")
    if t in ("length", "angle") and c.get("value") is None:
        return False
    if t == "find":
        return False        # v6.7.2: a find target asks; it states nothing
    if t == "shape":
        w = _SHAPE_WORD.get(str(c.get("value")))
        if c.get("text") and len(norm(c["text"])) >= 3 and \
                norm(c["text"]) in norm(text):
            return True
        want = "".join(sorted(tk(c.get("points"))))
        return bool(w) and bool(re.search(w, str(text))) and any(
            "".join(sorted(tk(u))) == want for u in _RUN.findall(str(text)))
    return restated(text, c)


# ------------------------------------------------------------- claims ------
def tk(v):
    if isinstance(v, (list, tuple)):
        return [x for y in v for x in tk(y)]
    return _P.findall(str(v or ""))


def seg(v):
    t = tk(v)
    return "".join(sorted(t)) if len(t) == 2 else "|".join(t)


def ang(v):
    if isinstance(v, dict):
        return (str(v.get("at")), tuple(sorted(map(str, v.get("rays") or []))))
    t = tk(v)
    return (t[1], tuple(sorted((t[0], t[2])))) if len(t) == 3 else (str(v),)


def num(v):
    try:
        return round(float(str(v).replace(u"\u2212", "-")), 6)
    except (TypeError, ValueError):
        return str(v)


def key(c):
    if not isinstance(c, dict):
        return ("text", re.sub(r"[\s$]+", "", str(c)))
    t, of = c.get("type"), c.get("of")
    if t in ("equal_length", "parallel", "perpendicular", "concentric"):
        return (t, tuple(sorted(seg(x) for x in of or [])))
    if t == "equal_angle":
        return (t, tuple(sorted(ang(x) for x in of or [])))
    if t == "length":
        return (t, seg(of), num(c.get("value")))
    if t == "angle":
        return (t, ang({"at": c.get("at"), "rays": c.get("rays")}),
                num(c.get("value")))
    if t in ("midpoint", "on_segment"):
        return (t, str(c.get("point")), seg(of))
    if t == "collinear":
        return (t, tuple(sorted(map(str, c.get("points") or []))))
    if t in ("segment", "line", "ray"):
        return ("segment", seg(of))
    if t == "point":
        return (t, str(c.get("point") or of))
    if t in ("polygon", "shape"):
        return (t, tuple(sorted(tk(c.get("points") or of))),
                str(c.get("value") or ""))
    if t == "find":
        return f_key(c)
    if t:
        return (t, json.dumps(dict((k, v) for k, v in sorted(c.items())
                                   if k not in ("text", "from_item", "facts",
                                                "status", "item", "marked",
                                                "mark_id", "mark_ids",
                                                "violated")),
                              sort_keys=True, ensure_ascii=False))
    return ("text", re.sub(r"[\s$]+", "", str(c.get("text") or "")))


def c_txt(c):
    return c.get("text") or str(key(c))


def names(c):
    out = []
    for k in ("of", "points", "point", "at", "rays", "to", "circle"):
        if isinstance(c, dict) and k in c:
            out += tk(c[k])
    return set(out)


def norm(s):
    s = str(s or "")
    for a, b in ((u"\\angle", u"\u2220"), (u"\\parallel", u"\u2225"),
                 (u"\\perp", u"\u22a5"), (u"\\|", u"\u2225"),
                 (u"\\cong", u"\u2245")):
        s = s.replace(a, b)
    s = re.sub(r"\\text\{([^}]*)\}", r"\1", s)
    return re.sub(u"[\\s${}]+", "", s).replace("||", u"\u2225")


_REL = re.compile(u"((?:\u2220)?[A-Z][A-Z0-9\u2032']{1,3})(=|\u2225|\u22a5)"
                  u"((?:\u2220)?[A-Z][A-Z0-9\u2032']{1,3}|\\d+(?:[.,]\\d+)?"
                  # r3 (D8-FALSE-REVIEW): 'AC = 3x + 4' is no length 3
                  u"(?![0-9A-Za-z\u00bd\u2153\u00bc/]))")


def relations(text):
    out = []
    for a, op, b in _REL.findall(norm(text)):
        if op == "=" and re.match(r"^\d", b):
            if a.startswith(u"\u2220") and len(tk(a)) == 3:
                t = tk(a)
                out.append({"type": "angle", "at": t[1],
                            "rays": [t[0], t[2]], "value": b})
            elif len(tk(a)) == 2:
                out.append({"type": "length", "of": a, "value": b})
            continue
        if a.startswith(u"\u2220") or b.startswith(u"\u2220"):
            if op == "=":
                out.append({"type": "equal_angle",
                            "of": [a.lstrip(u"\u2220"), b.lstrip(u"\u2220")]})
            continue
        if len(tk(a)) == 2 and len(tk(b)) == 2:
            out.append({"type": {"=": "equal_length", u"\u2225": "parallel",
                                 u"\u22a5": "perpendicular"}[op],
                        "of": [a, b]})
    have = set(key(r) for r in out)
    for r in worded(text):
        if key(r) not in have:
            have.add(key(r))
            out.append(r)
    return out


# r2 S3: a length / angle written in words ('אורך AB הוא 10 ס"מ')
_NW = u"(\\d+(?:[.,]\\d+)?)"
_SG = u"(?<![A-Za-z])([A-Z][0-9]*'?[A-Z][0-9]*'?)(?![A-Za-z0-9])"
_AN = u"(?<![A-Za-z])\u2220?\\s*([A-Z][0-9]*'?[A-Z][0-9]*'?[A-Z][0-9]*'?)" \
      u"(?![A-Za-z0-9])"
_BE = u"\\s*(?:הוא|היא|שווה\\s*ל\\s*[-\u05be]?|שווים\\s*ל\\s*[-\u05be]?|=)\\s*"
_WORDED = [("length", re.compile(u"אורך\\s+(?:ה?קטע\\s+|ה?צלע\\s+)?" +
                                 _SG + _BE + _NW)),
           ("length", re.compile(_SG + u"\\s+(?:אורכו|אורכה|באורך)\\s*"
                                 u"(?:של\\s*|הוא\\s*|היא\\s*)?" + _NW)),
           ("length", re.compile(u"(?:ה?קטע|ה?צלע)\\s+" + _SG + _BE + _NW)),
           # r3 S1: 'אורכו של AB הוא 10', 'הקטע AB ארוך 10 ס"מ', 'AB הוא 10'
           ("length", re.compile(u"(?:אורכו|אורכה)\\s+של\\s+"
                                 u"(?:ה?קטע\\s+|ה?צלע\\s+)?" + _SG + _BE + _NW)),
           ("length", re.compile(_SG + u"\\s+(?:ארוך|ארוכה)\\s*(?:ב\\s*[-\u05be]?)?"
                                 u"\\s*" + _NW)),
           ("length", re.compile(_SG + u"\\s+(?:הוא|היא)\\s+" + _NW +
                                 u"(?![0-9A-Za-z])")),
           ("angle", re.compile(u"(?:גודל\\s+)?ה?זווית\\s+" + _AN + _BE +
                                _NW)),
           ("angle", re.compile(_AN + u"\\s+(?:גודלה|שווה\\s*ל\\s*[-\u05be]?)"
                                u"\\s*" + _NW))]


def worded(text):
    t = unicodedata.normalize("NFKC", str(text or "")).replace("$", " ")
    t = t.replace(u"\u2032", "'")
    out = []
    for kind, rx in _WORDED:
        for a, v in rx.findall(t):
            p = tk(a)
            if kind == "length" and len(p) == 2:
                out.append({"type": "length", "of": a,
                            "value": v.replace(",", ".")})
            elif kind == "angle" and len(p) == 3:
                out.append({"type": "angle", "at": p[1],
                            "rays": [p[0], p[2]],
                            "value": v.replace(",", ".")})
    return out


# v6.7.2: an asked claim that is an EXPRESSION (a sum, a difference, a
# multiple, a fraction of angles / segments) is no typed relation
_EXPR = re.compile(u"[+−*/·⋅]|\\\\frac|\\\\cdot|"
                   u"(?<![A-Za-z0-9])\\d+(?:[.,]\\d+)?(?:∠|[A-Z])|"
                   u"[A-Z0-9]-[A-Z0-9∠]")


def after_proof_verb(text):
    m = _PROOF.search(str(text or ""))
    return str(text)[m.end():] if m else ""


def numbers(s):
    return set(x.replace(",", ".") for x in re.findall(
        u"(?<![\\w.])-?\\d+(?:[.,]\\d+)?(?![\\w.])",
        str(s or "").replace(u"\u2212", "-")))


# ---------------------------------------------------------------- SVG -----
# Independent stdlib reconstruction of source/figure/axis/map binding.
def native_locus_dashes(svg, public, fid, object_map, visible_text):
    """License only the measured stroke of a source-stated parameter locus.

    Pure public data + XML; no renderer, private layout, answer or engine
    checker is consulted. This does not grant arbitrary native element ids
    permission to be dashed. Each accepted id must bind its own printed
    clause, fixed coordinate, whole mapped locus and measured axis geometry.
    """
    import xml.etree.ElementTree as ET
    from fractions import Fraction
    def normal(s):return ' '.join(s.replace('$', '').split()) if isinstance(s, str) else ''
    def number(s):return Fraction(str(s))
    try:
        fig = next(f for f in public.get('figures', []) if f.get('id') == fid)
        loci = fig.get('loci')
        if not isinstance(loci, list) or not loci:return set()
        frame = fig.get('frame') or {}
        if frame.get('family') != 'coordinate_plane' or frame.get('sketch') or fig.get('data') or fig.get('graph'):return set()
        tree = ET.fromstring(svg)
        if tree.get('data-dialect') != 'wspec-coord-svg/1':return set()
        elements = list(tree.iter())
        if any(any(k in e.attrib for k in ('transform', 'style')) for e in elements):return set()
        ids = [e.get('id') for e in elements if e.get('id')]
        if len(ids) != len(set(ids)):return set()
        byid = {e.get('id'): e for e in elements if e.get('id')}
        texts, owners, printed = {}, {}, set()
        for q in public.get('questions', []):
            for row in [q] + q.get('items', []):
                texts[row['id']] = normal(row.get('text')); owners[row['id']] = q['id']
                for block in row.get('bound', []):
                    printed.update(block.get('prints', []))
                    for bind in block.get('bind', []):
                        fact = bind.get('fact'); printed.update(fact if isinstance(fact, list) else [fact] if fact else [])
        question = owners[fig['scope']]
        facts = {f['id']: f for f in public.get('facts', [])}
        entities = {e['id']: e for e in public.get('entities', [])}
        def axis_map(axis):
            letter = axis['axis'].split(':')[1]; n = axis['intervals']
            if not isinstance(n, int) or n < 1 or axis.get('break_before'):raise ValueError('invalid locus axis')
            pix = []
            for i in range(n + 1):
                hits = [e for e in elements if e.get('data-grid') == '%s %d' % (letter, i)]
                # Native grids omit the stroke already drawn by the crossing
                # axis. Only an explicitly printed zero licenses that axis
                # as this grid position; no assumed origin or scale.
                if not hits and any(j == i and number(v) == 0 for j,v in axis['labels']):
                    other = 'y' if letter == 'x' else 'x'
                    hits = [e for e in elements if e.get('data-axis') == other]
                if not hits:raise ValueError('unmeasured grid')
                # A grid stroke may have real gaps for label/dot clearance.
                # Every surviving piece must lie on the same measured line.
                at = []
                for el in hits:
                    if el.tag.split('}')[-1] != 'line':raise ValueError('not a grid stroke')
                    k = 'x' if letter == 'x' else 'y'
                    a, b = float(el.get(k+'1')), float(el.get(k+'2'))
                    if abs(a-b) > .05:raise ValueError('grid not axis aligned')
                    at.append(a)
                if max(at)-min(at) > .05:raise ValueError('split grid pieces disagree')
                pix.append(at[0])
            scale = (pix[-1]-pix[0])/n
            if not scale or (letter == 'x') != (scale > 0) or any(abs(p-(pix[0]+i*scale)) > .05 for i,p in enumerate(pix)):raise ValueError('inconsistent grid scale')
            labels = axis['labels']
            if len(labels) < 2:raise ValueError('no printed scale')
            i0,v0 = labels[0]; i1,v1 = labels[-1]; v0,v1 = number(v0),number(v1)
            step = (v1-v0)/(i1-i0)
            if step <= 0 or any(number(v) != v0+(i-i0)*step for i,v in labels):raise ValueError('inconsistent public scale')
            for i,v in labels:
                hits = [e for e in elements if e.get('data-num') == '%s %d' % (letter,i) or number(v) == 0 and e.get('data-num') == 'origin']
                if len(hits) != 1 or hits[0].tag.split('}')[-1] != 'text' or number((hits[0].text or '').replace('−','-')) != number(v):raise ValueError('scale number not printed')
            return n, lambda v: float(i0+(number(v)-v0)/step), lambda i: pix[0]+float(i)*scale
        axes = {a['axis']:axis_map(a) for a in frame['axes']}
        accepted = set()
        for row in loci:
            if not isinstance(row,dict) or set(row) != {'id','point','variable','coordinate_fact','domain','source','example'}:continue
            if not all(isinstance(row.get(k),str) for k in ('id','point','variable','coordinate_fact')) or not isinstance(row['example'],bool):continue
            fact=facts.get(row['coordinate_fact'],{});args=fact.get('args') or []
            point=entities.get(row['point'],{});variable=entities.get(row['variable'],{})
            if fact.get('id') not in printed or fact.get('role') != 'given' or fact.get('rel') != 'coordinate' or len(args)!=2 or args[0]!=row['point'] or args[1] not in axes or owners.get(fact.get('item'))!=question or point.get('kind')!='point' or variable.get('kind')!='variable':continue
            fixed=args[1]; free='axis:y' if fixed=='axis:x' else 'axis:x'
            source=row['source'];dom=row['domain']
            if not isinstance(source,dict) or set(source)!={'scope','text'} or not isinstance(source.get('scope'),str) or owners.get(source['scope'])!=question:continue
            clause=normal(source.get('text'))
            if not clause or clause not in texts.get(source['scope'],'') or clause not in normal(visible_text) or 'מקווקו' not in clause:continue
            pair=[variable['name'],str(fact['value'])] if fixed=='axis:y' else [str(fact['value']),variable['name']]
            if not re.search(re.escape(point['name'])+r'\s*\(\s*'+re.escape(pair[0])+r'\s*,\s*'+re.escape(pair[1])+r'\s*\)',clause):continue
            if not isinstance(dom,dict) or set(dom)!={'lo','lo_in'} or number(dom['lo'])!=0 or dom['lo_in'] is not True or not re.search(r'\b'+re.escape(variable['name'])+r'\b.*אינו שלילי',clause):continue
            oid='line:'+fixed.split(':')[1]+'='+str(fact['value'])
            obj=(object_map.get('objects') or {}).get(oid,{})
            parts=obj.get('parts') or []
            if object_map.get('figure')!=fid or obj.get('kind')!='line' or len(parts)!=1 or parts[0].get('span')!='whole':continue
            sid=parts[0].get('element');el=byid.get(sid)
            if el is None or el.tag.split('}')[-1]!='line' or el.get('data-locus')!=row['id'] or el.get('stroke-dasharray')!='3 3':continue
            items=[i for i in object_map.get('display_items',[]) if sid in i.get('elements',[])]
            if len(items)!=1 or items[0].get('role')!='parameter_locus' or items[0].get('source')!={'entity':oid} or (object_map.get('elements',{}).get(sid) or {}).get('item')!=items[0].get('id'):continue
            n,idx,px=axes[fixed]; fn,fidx,fpx=axes[free]
            at=idx(fact['value']);lo=max(0,fidx(dom['lo']))
            if not 0<=at<=n or not lo<fn:continue
            fixedpx=px(at);aa=fpx(lo);bb=fpx(fn)
            want=[(aa,fixedpx),(bb,fixedpx)] if fixed=='axis:y' else [(fixedpx,aa),(fixedpx,bb)]
            actual=[(float(el.get('x1')),float(el.get('y1'))),(float(el.get('x2')),float(el.get('y2')))]
            if not any(all(abs(x-y)<=.3 for p,q in zip(actual,ordered) for x,y in zip(p,q)) for ordered in (want,want[::-1])):continue
            accepted.add(sid)
        return accepted
    except (KeyError,ValueError,TypeError,ZeroDivisionError,StopIteration,ET.ParseError,IndexError):
        return set()


def dashed(svg):
    out, stack = [], []
    for m in re.finditer(r"<(/?)([a-zA-Z]+)([^>]*?)(/?)>", svg or ""):
        close, tag, attrs, selfc = m.groups()
        if tag == "g":
            if close:
                if stack:
                    stack.pop()
            elif not selfc:
                gid = re.search(r'\sid="([^"]+)"', attrs)
                stack.append(("stroke-dasharray" in attrs,
                              gid.group(1) if gid else None))
            continue
        if close or tag in ("svg", "text", "tspan", "defs", "style"):
            continue
        own = re.search(r'stroke-dasharray\s*[=:]\s*"?([^";]+)', attrs)
        d = own is not None and own.group(1).strip() not in ("none", "0")
        inh = [g for g in stack if g[0]]
        if not (d or inh) or 'class="ink-copy"' in attrs:
            continue
        i = re.search(r'\sid="([^"]+)"', attrs)
        out.append(i.group(1) if i else (inh[-1][1] if inh else None))
    return out


def colours(svg):
    out = []
    for el in re.findall(r"<[a-zA-Z][^>]*>", svg or ""):
        vals = re.findall(r'\b(?:fill|stroke|stop-color|color)="([^"]*)"', el)
        for st in re.findall(r'\bstyle="([^"]*)"', el):
            vals += re.findall(r"(?:fill|stroke|color)\s*:\s*([^;]+)", st)
        for v in vals:
            v = v.strip().lower()
            if v in ("none", "", "transparent", "currentcolor", "black",
                     "white", "inherit", "gray", "grey", "silver") or \
                    v.startswith("url("):
                continue
            m = re.match(r"^#([0-9a-f]{3}|[0-9a-f]{6})$", v)
            if m:
                h = m.group(1)
                h = "".join(c * 2 for c in h) if len(h) == 3 else h
                r, g, b = [int(h[i:i + 2], 16) for i in (0, 2, 4)]
                if max(r, g, b) - min(r, g, b) <= 8:
                    continue
            out.append(v)
    return out


def ids_in(svg):
    return set(re.findall(r'\sid="([^"]+)"', svg or ""))


def svg_numbers(svg):
    out = set()
    for t in re.findall(r"<text\b[^>]*>(.*?)</text>", svg or "", re.S):
        out |= numbers(re.sub(r"<[^>]*>", "", t))
    return out


# ------------------------------------------------ §9 the visual model -----
# An independent reading of visual-model/v1 (the builder is the skill's
# visual_model.py; nothing is imported from it). Rules:
#   V1 schema: kind in the registry, support no better than the kind's
#      ceiling, unique ids / svg_ids, roles and displays from the closed
#      lists, every relation's objects exist, every point a relation names
#      exists exactly once; unsupported = no SVG, no ids, nothing to show
#   V2 model vs SVG: each initial svg_id exactly once in the SVG, no
#      overlay / aux-only object in it, a label's numbers = its SVG text,
#      every xy maps to its svg_xy by view.data_to_svg, xyz -> xy one
#      parallel projection
#   V3 the neutral start: no to_prove / to_construct object shown at
#      first, no goal relation marked, highlight_given only givens
#   V4 aux patches: on request, labelled, one step, an SVG; ops add / show
#      / highlight only; every id shown or highlighted is in the model or in
#      the patch's own additions; a patch never re-adds a model id, never
#      highlights a goal, never adds a given or a goal
#   V5 actions: the closed list show / highlight / show_aux, highlight ⊆
#      highlight_given, show_aux = the aux ids
#   V6 per kind: number-line ticks at their values; plane tick labels on
#      their axis values (and at view.step); function points on the curve
#      (on_graph); table row / column sums; tree branch sums = 1 and leaf =
#      product; sample-space size; outcome-table cells; frequency totals;
#      Venn set totals and universe; bar heights = value x scale; pie
#      angles = 360 x share; geometry relations re-measured from xy
from fractions import Fraction as _Fr

VM_SCHEMA = "visual-model/v1"
VM_KINDS = {"plane_geometry": "full", "construction": "full",
            # (v6.16 integrate) the graph and pie ENGINES draw every object
            # with ids: a function graph / pie chart may be "full" (a
            # builder-path curve without ids stays "partial"; a declared
            # pie visual without an engine figure stays "unsupported")
            "coordinate_plane": "full", "function_graph": "full",
            "number_line": "full", "table": "partial", "solid_3d": "full",
            "projection_2d": "unsupported", "net_2d": "full",
            "probability_tree": "unsupported", "sample_space": "unsupported",
            "outcome_table": "unsupported",
            "frequency_table": "unsupported", "venn": "unsupported",
            "bar_chart": "unsupported", "pie_chart": "full",
            "line_chart": "unsupported"}
VM_SUPPORT = ("unsupported", "partial", "full")
VM_ROLES = ("given", "to_prove", "to_construct", "context", "aux_step")
VM_DISPLAY = ("initial", "given_highlight", "aux_only")
VM_OPS = ("add", "show", "highlight")
VM_ACTIONS = ("show", "highlight", "show_aux")
_GEOM = ("plane_geometry", "construction", "coordinate_plane",
         "function_graph", "number_line", "solid_3d", "projection_2d",
         "net_2d", "line_chart")


def _fr(v):
    try:
        if isinstance(v, str):
            return _Fr(v.replace(u"−", "-").strip())
        return _Fr(v).limit_denominator(10 ** 6)
    except (TypeError, ValueError, ZeroDivisionError):
        return None


def _map(M, p):
    a, b, c, d, e, f = M
    return (a * p[0] + c * p[1] + e, b * p[0] + d * p[1] + f)


def _solve(A, y):
    """least squares A x = y by the normal equations (small, stdlib)."""
    n = len(A[0])
    N = [[sum(r[i] * r[j] for r in A) for j in range(n)] for i in range(n)]
    v = [sum(r[i] * t for r, t in zip(A, y)) for i in range(n)]
    for i in range(n):
        p = max(range(i, n), key=lambda k: abs(N[k][i]))
        if abs(N[p][i]) < 1e-12:
            return None
        N[i], N[p], v[i], v[p] = N[p], N[i], v[p], v[i]
        for k in range(n):
            if k != i:
                t = N[k][i] / N[i][i]
                N[k] = [x - t * z for x, z in zip(N[k], N[i])]
                v[k] -= t * v[i]
    return [v[i] / N[i][i] for i in range(n)]


_EXPR_OK = re.compile(r"^[0-9x+\-*/(). ]+$")


def _f_of(expr):
    e = str(expr or "").replace(u"−", "-").replace("^", "**")
    if not _EXPR_OK.match(e):
        return None
    try:
        code = compile(e, "<expr>", "eval")
    except SyntaxError:
        return None
    if any(n != "x" for n in code.co_names):
        return None
    return lambda x: eval(code, {"__builtins__": {}}, {"x": x})


def _pts_by_name(vm):
    out = {}
    for o in vm.get("objects") or []:
        if o.get("type") == "point":
            # v6.12 fix_r1: a number-line point named by its letter (pt-A,
            # name "A", letter "A") is ONE object, not two
            for nm in sorted({str(x) for x in (o.get("name"), o.get("letter"))
                              if x}):
                if _P.fullmatch(nm):
                    out.setdefault(nm, []).append(o)
    return out


def _elem_text(svg, sid):
    m = re.search(r'<(text)\b[^>]*\sid="%s"[^>]*>(.*?)</text>'
                  % re.escape(sid), svg or "", re.S)
    if not m:
        m = re.search(r'<g\b[^>]*\sid="%s"[^>]*>(.*?)</g>' % re.escape(sid),
                      svg or "", re.S)
        if not m:
            return None
        return re.sub(r"<[^>]*>", "", m.group(1))
    return re.sub(r"<[^>]*>", "", m.group(2))


# ---- C3 (v6.10): what a typed-shape given states ---------------------------
# The same block is in deliver.py, check_didactic.py and
# selfcheck_noam_package.py (each file stays independent; the v6.10 suite
# proves the three copies are identical). The statements are the
# definitions the school course uses (PENDING the author's approval):
#   parallelogram  both pairs of opposite sides parallel
#   rectangle      four right angles (as AB ⊥ BC ..., no number)
#                                           square  + four equal sides
#   rhombus        four equal sides         kite    two pairs of adjacent
#                                                   equal sides (read off the
#                                                   figure; ambiguous: refused)
#   trapezoid      the one pair of parallel sides (read off the figure;
#                  "שווה־שוקיים" in its text adds the equal legs)
#   equilateral    three equal sides        isosceles  the two equal sides
#   right_triangle the right angle          (read off the figure)
# A statement that IS a goal of the figure's question (a find / to_prove:
# 'what is the angle ABC?' of a given rectangle) is never offered --
# highlighting it would answer the question.
C3_SHAPES = ("parallelogram", "rectangle", "square", "rhombus", "kite",
             "trapezoid", "equilateral", "isosceles", "right_triangle")
_C3_TOK = re.compile(r"[A-Z][0-9]*'*")


class ShapeStateError(ValueError):
    pass


def _c3_len(P, a, b):
    return math.hypot(P[b][0] - P[a][0], P[b][1] - P[a][1])


def _c3_par(P, a, b, c, d):
    u = (P[b][0] - P[a][0], P[b][1] - P[a][1])
    v = (P[d][0] - P[c][0], P[d][1] - P[c][1])
    nu, nv = math.hypot(*u), math.hypot(*v)
    return nu > 0 and nv > 0 and \
        abs(u[0] * v[1] - u[1] * v[0]) / (nu * nv) < math.sin(
            math.radians(0.5))


def _c3_eq(P, s, t):
    a, b = _c3_len(P, *s), _c3_len(P, *t)
    return abs(a - b) <= 0.01 * max(a, b, 1e-9)


def _c3_right(P, v, a, b):
    u = (P[a][0] - P[v][0], P[a][1] - P[v][1])
    w = (P[b][0] - P[v][0], P[b][1] - P[v][1])
    nu, nw = math.hypot(*u), math.hypot(*w)
    return nu > 0 and nw > 0 and \
        abs(u[0] * w[0] + u[1] * w[1]) / (nu * nw) < math.sin(
            math.radians(0.5))


def shape_states(value, points, P=None, text=""):
    """The claims a GIVEN 'points are a <value>' states, as claim dicts
    ({type: parallel / equal_length / perpendicular, of: [..], at} --
    no number, so the overlay prints no value). P {name: (x, y)} reads the figure where the definition
    leaves a choice (which pair of a trapezoid, which vertex of an
    isosceles / right triangle, which pairs of a kite); a choice the
    figure does not settle raises ShapeStateError (refuse, never guess)."""
    pts = [str(p) for p in points or []]
    n = len(pts)
    side = [(pts[i], pts[(i + 1) % n]) for i in range(n)]

    def seg(s):
        return s[0] + s[1]

    def par(s, t):
        return {"type": "parallel", "of": [seg(s), seg(t)],
                "text": u"%s ∥ %s" % (seg(s), seg(t))}

    def eq(*ss):
        return {"type": "equal_length", "of": [seg(s) for s in ss],
                "text": " = ".join(seg(s) for s in ss)}

    def right(i):
        a, v, b = pts[i - 1], pts[i], pts[(i + 1) % n]
        return {"type": "perpendicular", "of": [a + v, v + b], "at": v,
                "text": u"%s%s ⊥ %s%s" % (a, v, v, b)}

    def need(k):
        if n != k or len(set(pts)) != k:
            raise ShapeStateError("a %s names %d distinct points, not %d"
                                  % (value, len(set(pts)), k))

    def figure():
        if not P or any(p not in P for p in pts):
            raise ShapeStateError("which sides a %s's given states is read "
                                  "off the figure, and its points are not "
                                  "all drawn" % value)
    if value == "parallelogram":
        need(4)
        return [par(side[0], side[2]), par(side[1], side[3])]
    if value == "rectangle":
        need(4)
        return [right(i) for i in range(4)]
    if value == "square":
        need(4)
        return [right(i) for i in range(4)] + [eq(*side)]
    if value == "rhombus":
        need(4)
        return [eq(*side)]
    if value == "trapezoid":
        need(4)
        figure()
        pairs = [(side[0], side[2]), (side[1], side[3])]
        hit = [pq for pq in pairs if _c3_par(P, *(pq[0] + pq[1]))]
        if len(hit) != 1:
            raise ShapeStateError("the figure shows %d parallel pair(s) of "
                                  "the trapezoid %s: its bases are not "
                                  "settled" % (len(hit), "".join(pts)))
        out = [par(*hit[0])]
        if re.search(u"שווה[־\\s-]?שוק"
                     u"יים", str(text or "")):
            legs = [s for s in side if s not in hit[0]]
            out.append(eq(*legs))
        return out
    if value == "kite":
        need(4)
        figure()
        cfg = [((side[0], side[1]), (side[2], side[3])),
               ((side[1], side[2]), (side[3], side[0]))]
        ok = [c for c in cfg if _c3_eq(P, *c[0]) and _c3_eq(P, *c[1])]
        if len(ok) != 1:
            raise ShapeStateError("the figure does not settle the equal "
                                  "pairs of the kite %s" % "".join(pts))
        return [eq(*ok[0][0]), eq(*ok[0][1])]
    if value == "equilateral":
        need(3)
        return [eq(*side)]
    if value == "isosceles":
        need(3)
        figure()
        at = [i for i in range(3) if _c3_eq(P, side[i - 1], side[i])]
        if len(at) != 1:
            raise ShapeStateError("the figure does not settle the apex of "
                                  "the isosceles %s (%d candidates)"
                                  % ("".join(pts), len(at)))
        i = at[0]
        return [eq(side[i - 1], side[i])]
    if value == "right_triangle":
        need(3)
        figure()
        at = [i for i in range(3) if _c3_right(P, pts[i], pts[i - 1],
                                                pts[(i + 1) % 3])]
        if len(at) != 1:
            raise ShapeStateError("the figure does not settle the right "
                                  "angle of %s" % "".join(pts))
        return [right(at[0])]
    raise ShapeStateError("no statement is known for the shape %r" % value)


def c3_key(c):
    """A canonical key of a stated claim (order of names ignored)."""
    t = (c or {}).get("type")
    if t in ("parallel", "equal_length", "perpendicular"):
        segs = sorted("".join(sorted(_C3_TOK.findall(str(s))))
                      for s in c.get("of") or [])
        if t != "perpendicular":
            return (t, tuple(segs))
        at = c.get("at")
        if not at and len(segs) == 2:
            common = set(_C3_TOK.findall(segs[0])) & set(
                _C3_TOK.findall(segs[1]))
            at = list(common)[0] if len(common) == 1 else None
        return (t, tuple(segs), str(at))
    if t == "angle" and str(c.get("value")) in ("90", "90.0") and \
            c.get("at") and len(c.get("rays") or []) == 2:
        v = str(c["at"])
        return c3_key({"type": "perpendicular", "at": v, "of": [
            str(c["rays"][0]) + v, v + str(c["rays"][1])]})
    if t == "angle":
        return (t, str(c.get("at")), tuple(sorted(
            str(x) for x in c.get("rays") or [])), str(c.get("value")))
    return (t, repr(sorted((k, str(v)) for k, v in (c or {}).items()
                           if k not in ("text", "id", "objects"))))


def c3_goal_keys(vm):
    """keys of what the figure's question asks (to_prove / to_construct /
    find): a statement with one of them is not offered (it answers)."""
    out = set()
    for r in vm.get("relations") or []:
        if not isinstance(r, dict) or r.get("role") not in (
                "to_prove", "to_construct"):
            continue
        out.add(c3_key(r))
        at, rays = r.get("at"), r.get("rays") or []
        if at and len(rays) == 2 and (r.get("type") == "angle" or (
                r.get("type") == "find" and r.get("quantity") == "angle")):
            v = str(at)
            out.add(c3_key({"type": "perpendicular", "at": v,
                            "of": [str(rays[0]) + v, v + str(rays[1])]}))
    return out


def c3_faults(vm):
    """[reason] -- highlight_given of one visual_model holds EXACTLY what
    each typed-shape given states: every statement of every given shape
    (role given, not carried with from_item) that is not the question's
    own goal is offered -- by a relation
    derived from it (from_given = the shape's id) or by an explicit given
    relation saying the same -- and every derived relation is a statement
    of a given shape, nothing else."""
    out = []
    rels = [r for r in vm.get("relations") or [] if isinstance(r, dict)]
    rid = dict((r.get("id"), r) for r in rels)
    hg = [x for x in vm.get("highlight_given") or [] if isinstance(x, str)]
    P = dict((str(o.get("name")), tuple(o["svg_xy"]))
             for o in vm.get("objects") or []
             if isinstance(o, dict) and o.get("type") == "point" and
             o.get("name") and isinstance(o.get("svg_xy"), list) and
             len(o["svg_xy"]) == 2 and not isinstance(o["svg_xy"][0], list))
    offered = {}
    for x in hg:
        r = rid.get(x) or {}
        if r.get("role") == "given":
            offered.setdefault(c3_key(r), []).append(r)
    want = {}
    goals = c3_goal_keys(vm)
    for r in rels:
        if r.get("type") != "shape" or r.get("role") != "given" or \
                r.get("from_item") or r.get("no_overlay"):
            continue
        try:
            st = shape_states(r.get("value"), r.get("points"), P,
                              r.get("text"))
        except ShapeStateError as e:
            out.append("given %s (%s): %s" % (r.get("id"), r.get("text"), e))
            continue
        st = [c for c in st if c3_key(c) not in goals]
        want[r.get("id")] = set(c3_key(c) for c in st)
        for c in st:
            if c3_key(c) not in offered:
                out.append("given %s (%s) states %s, which highlight_given "
                           "does not offer" % (r.get("id"), r.get("text"),
                                               c.get("text")))
    for x in hg:
        r = rid.get(x) or {}
        src = r.get("from_given")
        if src is None:
            continue
        if src not in want:
            s = rid.get(src) or {}
            out.append("%s is derived from %s, which is no given shape "
                       "(%s %s%s)" % (x, src, s.get("role"), s.get("value"),
                                      ", carried from_item"
                                      if s.get("from_item") else ""))
        elif c3_key(r) not in want[src]:
            out.append("%s (%s) is not what the given %s states"
                       % (x, r.get("text"), src))
    for r in rels:
        if r.get("from_given") and r.get("id") not in hg:
            out.append("%s is derived from %s but not offered in "
                       "highlight_given" % (r.get("id"), r.get("from_given")))
    return out
# ---- end of the C3 block ---------------------------------------------------


def vm_faults(vm, svg=None, aux_svgs=None):
    """[(status, rule, text)] for one visual_model (FAIL / REVIEW)."""
    out = []

    def bad(rule, t, st="FAIL"):
        out.append((st, rule, "%s: %s" % (vm.get("id"), t)))
    if not isinstance(vm, dict):
        return [("FAIL", "V1", "visual_model is not an object")]
    kind = vm.get("kind")
    sup = vm.get("visual_support")
    if vm.get("schema_version") != VM_SCHEMA:
        bad("V1", "schema_version %r" % vm.get("schema_version"))
    if kind not in VM_KINDS:
        bad("V1", "kind %r is not registered" % kind)
        return out
    if sup not in VM_SUPPORT:
        bad("V1", "visual_support %r" % sup)
        return out
    if VM_SUPPORT.index(sup) > VM_SUPPORT.index(VM_KINDS[kind]):
        bad("V1", "%s claims support %r; the skill renders it at most %r"
            % (kind, sup, VM_KINDS[kind]))
    objs = vm.get("objects") or []
    rels = vm.get("relations") or []
    ids, sids = {}, {}
    for o in objs:
        i = o.get("id")
        if not i:
            bad("V1", "an object with no id")
            continue
        ids[i] = ids.get(i, 0) + 1
        if o.get("svg_id"):
            sids[o["svg_id"]] = sids.get(o["svg_id"], 0) + 1
        if o.get("role") not in VM_ROLES:
            bad("V1", "object %s role %r" % (i, o.get("role")))
        if o.get("display") not in VM_DISPLAY:
            bad("V1", "object %s display %r" % (i, o.get("display")))
    for x, n in list(ids.items()) + list(sids.items()):
        if n > 1:
            bad("V1", "id %s names %d objects" % (x, n))
    rid = {}
    for r in rels:
        if not r.get("id") or r["id"] in ids or r["id"] in rid:
            bad("V1", "relation id %r missing or not unique" % r.get("id"))
        rid[r.get("id")] = r
        if r.get("role") not in VM_ROLES:
            bad("V1", "relation %s role %r" % (r.get("id"), r.get("role")))
        for x in r.get("objects") or []:
            if x not in ids:
                bad("V1", "relation %s names object %s, not in the model"
                    % (r.get("id"), x))
    if kind in _GEOM:
        P = _pts_by_name(vm)
        for nm, lst in P.items():
            if len(lst) > 1:
                bad("V1", "point %s is %d objects" % (nm, len(lst)))
        for r in rels:
            if r.get("role") in ("to_construct", "aux_step") or \
                    r.get("type") == "find":
                # v6.7.2: a find target's objects are checked by D12,
                # which also knows the points a given / to_construct names
                continue
            for k in ("of", "points", "point", "at", "rays"):
                for nm in tk(r.get(k)):
                    if P and nm not in P and kind != "number_line":
                        bad("V1", "relation %s names %s, no point of the "
                            "model" % (r.get("id"), nm))
    if sup == "unsupported":
        if vm.get("svg") or any(o.get("svg_id") for o in objs) or \
                vm.get("aux"):
            bad("V1", "unsupported, yet it ships an SVG / svg ids / aux -- "
                "an approximate drawing")
        a = vm.get("actions") or {}
        if a.get("show") or a.get("highlight") or a.get("show_aux"):
            bad("V5", "unsupported, yet actions offer something to show")
    # V3 --------------------------------------------------------------------
    for o in objs:
        if o.get("role") in ("to_prove", "to_construct") and \
                o.get("display") == "initial":
            bad("V3", "%s (%s) is in the starting figure" % (o.get("id"),
                                                            o.get("role")))
    for r in rels:
        if r.get("role") in ("to_prove", "to_construct") and \
                r.get("marked"):
            bad("V3", "the goal %s is marked in the starting figure"
                % r.get("id"))
    hg = vm.get("highlight_given") or []
    for i, x in enumerate(hg):
        if not isinstance(x, str):
            # r1 m1: an id list holds ids -- a dict here crashed the check
            bad("V3", "highlight_given[%d] is a %s (%s), not a relation id"
                % (i, type(x).__name__, str(x)[:40]))
            continue
        if (rid.get(x) or {}).get("role") != "given":
            bad("V3", "highlight_given names %s, which is no given relation"
                % x)
    # V6 (v6.10, Codex C3): a typed-shape given is offered by EXACTLY what
    # it states (both pairs of parallel sides of a parallelogram ...)
    for t in c3_faults(vm):
        bad("V6", t)
    # (v6.14 F2) an engine figure addresses an element through an object's
    # parts (an axis line is a part of axis:x): an overlay may sit on it
    psids = set(p.get("svg_id") for o in objs for p in o.get("parts") or []
                if isinstance(p, dict) and p.get("svg_id"))
    for o in objs:
        if o.get("display") == "given_highlight":
            if o.get("role") != "given" or \
                    (rid.get(o.get("for")) or {}).get("role") != "given":
                bad("V3", "overlay %s marks %s, which is no given"
                    % (o.get("id"), o.get("for")))
            for x in o.get("on") or []:
                if x not in sids and x not in psids:
                    bad("V1", "overlay %s sits on %s, no svg_id of the "
                        "model" % (o.get("id"), x))
    # V2 --------------------------------------------------------------------
    if svg:
        found = re.findall(r'\sid="([^"]+)"', svg)
        for o in objs:
            s = o.get("svg_id")
            if not s:
                continue
            c = found.count(s)
            if o.get("display") == "initial" and c != 1:
                bad("V2", "%s is %d times in the SVG" % (s, c))
            if o.get("display") != "initial" and c:
                bad("V2", "%s (%s) is drawn in the starting SVG"
                    % (s, o.get("display")))
            if o.get("type") == "label" and o.get("text") is not None and \
                    c == 1:
                t = _elem_text(svg, s)
                if t is not None and numbers(o["text"]) != numbers(t):
                    bad("V2", "label %s says %r in the model and %r in the "
                        "SVG" % (s, o["text"], t.strip()))
        # v6.9: an engine figure's object -> parts (its svg ids): each part
        # is ONE element of the starting SVG
        for o in objs:
            for p in o.get("parts") or []:
                ps = p.get("svg_id") if isinstance(p, dict) else None
                c = found.count(ps) if ps else 0
                if c != 1:
                    bad("V2", "object %s: part %s is %d times in the SVG"
                        % (o.get("id"), ps, c))
    M = (vm.get("view") or {}).get("data_to_svg")
    if isinstance(M, list) and len(M) == 6 and sup != "unsupported":
        sc = max(abs(M[0]), abs(M[3]), 1e-9)
        for o in objs:
            xy, sv = o.get("xy"), o.get("svg_xy")
            if not isinstance(xy, list) or not isinstance(sv, list) or \
                    o.get("type") not in ("point", "segment", "ticks",
                                          "marker"):
                continue
            prs = list(zip(xy, sv)) if xy and isinstance(xy[0], list) \
                else [(xy, sv)]
            for p, q in prs:
                try:
                    X = _map(M, p)
                except (TypeError, IndexError):
                    continue
                if abs(X[0] - q[0]) > 0.75 or abs(X[1] - q[1]) > 0.75:
                    bad("V2", "%s: xy %s maps to %s, the SVG has %s"
                        % (o.get("id"), p, [round(v, 2) for v in X], q))
                    break
        _ = sc
    xyz = [o for o in objs if isinstance(o.get("xyz"), list) and
           isinstance(o.get("xy"), list) and len(o["xyz"]) == 3]
    if len(xyz) >= 4:
        A = [list(o["xyz"]) + [1.0] for o in xyz]
        for k in (0, 1):
            y = [o["xy"][k] for o in xyz]
            sol = _solve(A, y)
            if sol is None:
                continue
            res = max(abs(sum(a * s for a, s in zip(r, sol)) - t)
                      for r, t in zip(A, y))
            span = max(1.0, max(y) - min(y))
            if res > 1e-3 * span:
                bad("V2", "the 2D drawing is no parallel projection of the "
                    "solid's xyz (residual %.3g)" % res)
                break
    # V4 --------------------------------------------------------------------
    aid = []
    for a in vm.get("aux") or []:
        ai = a.get("id")
        aid.append(ai)
        if a.get("reveal") != "on_request" or not a.get("label") or \
                not str(a.get("step") or "").strip() or not a.get("svg"):
            bad("V4", "aux %s: reveal on_request, a label, one step and a "
                "pre-rendered SVG" % ai)
        added, arel = set(), {}
        for op in a.get("ops") or []:
            if op.get("op") not in VM_OPS:
                bad("V4", "aux %s: op %r is not add / show / highlight"
                    % (ai, op.get("op")))
                continue
            if op["op"] == "add":
                for o in op.get("objects") or []:
                    if o.get("id") in ids:
                        bad("V4", "aux %s re-adds %s, an object of the "
                            "model" % (ai, o.get("id")))
                    if o.get("display") != "aux_only":
                        bad("V4", "aux %s adds %s with display %r"
                            % (ai, o.get("id"), o.get("display")))
                    added.add(o.get("id"))
                for r in op.get("relations") or []:
                    if r.get("role") not in ("aux_step", "context"):
                        bad("V4", "aux %s adds the relation %s as %r -- a "
                            "patch never invents a given or a goal"
                            % (ai, r.get("id"), r.get("role")))
                    arel[r.get("id")] = r
        asvg = (aux_svgs or {}).get(ai)
        for op in a.get("ops") or []:
            if op.get("op") == "show":
                for x in op.get("ids") or []:
                    if x not in ids:
                        bad("V4", "aux %s shows %s, not in the model"
                            % (ai, x))
            if op.get("op") == "highlight":
                for x in op.get("ids") or []:
                    r = rid.get(x) or arel.get(x)
                    if r is None:
                        bad("V4", "aux %s highlights %s, neither in the "
                            "model nor added by the patch" % (ai, x))
                    elif r.get("role") in ("to_prove", "to_construct"):
                        bad("V4", "aux %s highlights the goal %s" % (ai, x))
        if asvg:
            have = set(re.findall(r'\sid="([^"]+)"', asvg))
            for x in added:
                if x not in have:
                    bad("V4", "aux %s adds %s, which its SVG does not "
                        "carry" % (ai, x))
    # V5 --------------------------------------------------------------------
    act = vm.get("actions")
    if not isinstance(act, dict):
        bad("V5", "no actions")
    else:
        extra = [k for k in act if k not in ("allowed",) + VM_ACTIONS]
        if extra or any(x not in VM_ACTIONS for x in act.get("allowed")
                        or []):
            bad("V5", "actions beyond show / highlight / show_aux (%s)"
                % (extra or act.get("allowed")))
        if any(x not in hg for x in act.get("highlight") or []):
            bad("V5", "highlight offers ids outside highlight_given")
        if sorted(act.get("show_aux") or []) != sorted(aid):
            bad("V5", "show_aux %s is not the aux list %s"
                % (act.get("show_aux"), aid))
        if any(x != vm.get("id") for x in act.get("show") or []):
            bad("V5", "show names another component")
    out += [(s, r, t) for s, r, t in _kind_faults(vm, kind, objs, rels)]
    return out


def _kind_faults(vm, kind, objs, rels):
    out = []

    def bad(t):
        out.append(("FAIL", "V6", "%s: %s" % (vm.get("id"), t)))
    data = vm.get("data") or {}
    view = vm.get("view") or {}
    byid = dict((o.get("id"), o) for o in objs)
    if kind == "number_line":
        vals = []
        for o in objs:
            if o.get("type") == "ticks" and isinstance(o.get("xy"), list):
                v = _fr(o.get("name"))
                x = o["xy"][0][0] if isinstance(o["xy"][0], list) \
                    else o["xy"][0]
                if v is not None and abs(float(v) - x) > 1e-6:
                    bad("tick %s is named %s and sits at %s"
                        % (o.get("id"), o.get("name"), x))
                if v is not None:
                    vals.append(float(v))
            if o.get("type") == "point" and o.get("value") is not None and \
                    _fr(o.get("name")) is not None and \
                    abs(float(_fr(o.get("name"))) - o["value"]) > 1e-6:
                bad("point %s is named %s and sits at %s"
                    % (o.get("id"), o.get("name"), o["value"]))
        st = _fr(view.get("step"))
        if st and vals:
            for v in vals:
                q = (v - vals[0]) / float(st)
                if abs(q - round(q)) > 1e-6:
                    bad("tick %s is off the step %s" % (v, view.get("step")))
                    break
    if kind in ("coordinate_plane", "function_graph"):
        vx, vy, lab = [], [], []
        for o in objs:
            m = re.match(r"^(?:.*-)?lbl-([xy])(m?)(\d+(?:d\d+)?)$",
                         str(o.get("id") or ""))
            if not m or not isinstance(o.get("xy"), list):
                continue
            v = _fr(str(o.get("text") or "").replace(u"−", "-"))
            if v is None:
                continue
            ax = 0 if m.group(1) == "x" else 1
            want = float(m.group(3).replace("d", ".")) * (
                -1 if m.group(2) else 1)
            if abs(float(v) - want) > 1e-6:
                bad("tick label %s prints %s" % (o["id"], o.get("text")))
            (vx if ax == 0 else vy).append(float(v))
            lab.append((ax, float(v), o["xy"][ax], o["id"]))
        # a tick label sits nearer its own value than any other tick's (a
        # label may step aside or sit on its baseline, never on the wrong
        # tick)
        for ax, vals in ((0, sorted(set(vx))), (1, sorted(set(vy)))):
            gap = min([b - a for a, b in zip(vals, vals[1:])] or [1.0])
            for a2, v, pos, i in lab:
                if a2 == ax and abs(pos - v) >= 0.5 * gap:
                    bad("tick label %s (%s) sits at %s on its axis, nearer "
                        "another tick" % (i, v, round(pos, 3)))
        st = _fr(view.get("step"))
        if st:
            for v in vx + vy:
                q = v / float(st)
                if abs(q - round(q)) > 1e-6:
                    bad("tick %s is off the declared step %s"
                        % (v, view.get("step")))
                    break
    if kind in ("function_graph", "coordinate_plane", "line_chart"):
        for r in rels:
            if r.get("type") != "on_graph":
                continue
            p, c = byid.get(r.get("point")), byid.get(r.get("curve"))
            f = _f_of((c or {}).get("expr"))
            if p is None or f is None or not isinstance(p.get("xy"), list):
                bad("on_graph %s: point or curve (expr) missing"
                    % r.get("id"))
                continue
            try:
                y = f(p["xy"][0])
            except (ArithmeticError, TypeError, ValueError):
                y = None
            if y is None or abs(y - p["xy"][1]) > 1e-6 * max(1, abs(y)):
                bad("%s = %s is not on %s (f(x) = %s)" % (
                    p.get("id"), p["xy"], c.get("expr"), y))
    if kind in ("table", "outcome_table", "frequency_table"):
        cells = [o for o in objs if o.get("type") == "cell"]
        grid = dict(((o.get("row"), o.get("col")), o) for o in cells)
        if len(grid) != len(cells):
            bad("two cells share a row and column")
        for r in rels:
            if r.get("type") not in ("row_sum", "col_sum"):
                continue
            k = "row" if r["type"] == "row_sum" else "col"
            vals = [_fr(o.get("value")) for o in cells
                    if o.get(k) == r.get(k) and o.get("id") not in
                    (r.get("objects") or [])[-1:]]
            tot = _fr(r.get("value"))
            vals = [v for v in vals if v is not None]
            if tot is None or sum(vals) != tot:
                bad("%s %s: the cells add up to %s, the model says %s"
                    % (r["type"], r.get(k), sum(vals), r.get("value")))
    if kind == "outcome_table":
        R, C = data.get("rows") or [], data.get("cols") or []
        cells = [o for o in objs if o.get("type") == "cell"]
        if len(cells) != len(R) * len(C):
            bad("%d cells for %d x %d outcomes" % (len(cells), len(R),
                                                   len(C)))
        for o in cells:
            if o.get("row") not in R or o.get("col") not in C:
                bad("cell %s is outside the table's rows / cols"
                    % o.get("id"))
    if kind == "frequency_table":
        cats = [o for o in objs if o.get("type") == "category"]
        tot = _fr(data.get("total"))
        s = sum(_fr(o.get("frequency")) or 0 for o in cats)
        if tot is None or s != tot:
            bad("frequencies add up to %s, the total is %s"
                % (s, data.get("total")))
        for o in cats:
            rl = _fr(o.get("relative"))
            if rl is not None and tot and \
                    rl != (_fr(o.get("frequency")) or 0) / tot:
                bad("relative frequency of %s is %s, not f / total"
                    % (o.get("id"), o.get("relative")))
    if kind == "probability_tree":
        nodes = dict((o.get("id"), o) for o in objs
                     if o.get("type") == "node")
        kids = {}
        for o in nodes.values():
            if o.get("parent") is not None:
                if o["parent"] not in nodes:
                    bad("node %s hangs on %s, no node" % (o.get("id"),
                                                          o["parent"]))
                kids.setdefault(o["parent"], []).append(o)
        for par, ks in kids.items():
            ps = [_fr(k.get("p")) for k in ks]
            if None in ps or sum(ps) != 1:
                bad("the branches from %s add up to %s, not 1"
                    % (par, sum(p for p in ps if p is not None)))
        for o in nodes.values():
            if o.get("id") in kids or o.get("leaf_p") is None:
                continue
            prod, cur, seen = _Fr(1), o, set()
            while cur is not None and cur.get("parent") is not None and \
                    cur.get("id") not in seen:
                seen.add(cur.get("id"))
                prod *= _fr(cur.get("p")) or 0
                cur = nodes.get(cur.get("parent"))
            if _fr(o.get("leaf_p")) != prod:
                bad("leaf %s says %s; the product of its branches is %s"
                    % (o.get("id"), o.get("leaf_p"), prod))
    if kind == "sample_space":
        outs = [o for o in objs if o.get("type") == "outcome"]
        vals = [json.dumps(o.get("value"), sort_keys=True) for o in outs]
        if len(set(vals)) != len(vals):
            bad("an outcome is listed twice")
        if data.get("size") is not None and data["size"] != len(outs):
            bad("size %s, %d outcomes listed" % (data["size"], len(outs)))
        st = data.get("stages")
        if st:
            p = 1
            for n in st:
                p *= n
            if p != len(outs):
                bad("stages %s give %d outcomes, %d listed"
                    % (st, p, len(outs)))
    if kind == "venn":
        sets = [o for o in objs if o.get("type") == "set"]
        regs = [o for o in objs if o.get("type") == "region"]
        for s in sets:
            t = sum(_fr(r.get("count")) or 0 for r in regs
                    if s.get("id") in (r.get("in") or []))
            if s.get("total") is not None and _fr(s["total"]) != t:
                bad("set %s totals %s; its regions add up to %s"
                    % (s.get("id"), s["total"], t))
        for r in regs:
            if any(x not in [s.get("id") for s in sets]
                   for x in r.get("in") or []):
                bad("region %s names a set the model lacks" % r.get("id"))
        if data.get("universe") is not None:
            t = sum(_fr(r.get("count")) or 0 for r in regs)
            if _fr(data["universe"]) != t:
                bad("the universe is %s; the regions add up to %s"
                    % (data["universe"], t))
    if kind == "projection_2d":
        axes = {"front": (0, 2), "top": (0, 1), "side": (1, 2)}
        cubes = data.get("cubes")
        verts = data.get("vertices")
        for o in objs:
            if o.get("type") != "view":
                continue
            ax = axes.get(o.get("name"))
            if ax is None:
                bad("view %s is not front / top / side" % o.get("id"))
                continue
            if cubes is not None and o.get("cells") is not None:
                want = set((c[ax[0]], c[ax[1]]) for c in cubes)
                got = set(tuple(c) for c in o["cells"])
                if want != got:
                    bad("view %s shows %d cells; the cubes project to %d "
                        "(%s)" % (o.get("id"), len(got), len(want),
                                  sorted(want ^ got)[:3]))
            if isinstance(verts, dict) and isinstance(o.get("points"),
                                                      dict):
                for nm, p in o["points"].items():
                    v = verts.get(nm)
                    if v is None or [v[ax[0]], v[ax[1]]] != list(p):
                        bad("view %s puts %s at %s; the solid's xyz says %s"
                            % (o.get("id"), nm, p, v and [v[ax[0]],
                                                          v[ax[1]]]))
    if kind == "bar_chart":
        sc = _fr(data.get("scale"))
        for o in objs:
            if o.get("type") != "bar":
                continue
            if sc is None or o.get("height_px") is None:
                bad("bar %s: no scale / height_px to check" % o.get("id"))
                continue
            if abs(float(_fr(o.get("value")) or 0) * float(sc) -
                   float(o["height_px"])) > 0.75:
                bad("bar %s: value %s x scale %s != height %s"
                    % (o.get("id"), o.get("value"), data.get("scale"),
                       o["height_px"]))
    if kind == "pie_chart":
        sec = [o for o in objs if o.get("type") == "sector"]
        tot = sum(_fr(o.get("value")) or 0 for o in sec)
        for o in sec:
            if not tot:
                break
            want = 360 * (_fr(o.get("value")) or 0) / tot
            if o.get("angle") is None or \
                    abs(float(want) - float(o["angle"])) > 0.5:
                bad("sector %s: %s degrees, its share is %.1f"
                    % (o.get("id"), o.get("angle"), float(want)))
    if kind in ("plane_geometry", "construction") and \
            not view.get("sketch"):
        P = dict((n, l[0].get("xy")) for n, l in _pts_by_name(vm).items()
                 if isinstance(l[0].get("xy"), list))
        span = 1.0
        if P:
            xs = [p[0] for p in P.values()] + [p[1] for p in P.values()]
            span = max(1.0, max(xs) - min(xs))
        tol = 2e-3 * span

        def L(s):
            t = tk(s)
            if len(t) != 2 or t[0] not in P or t[1] not in P:
                return None
            a, b = P[t[0]], P[t[1]]
            return (b[0] - a[0], b[1] - a[1])
        for r in rels:
            if r.get("role") in ("to_construct", "aux_step") or \
                    r.get("violated"):
                continue
            t, of = r.get("type"), r.get("of")
            segs = [L(x) for x in of] if isinstance(of, list) else []
            if t in ("equal_length", "parallel", "perpendicular") and \
                    len(segs) == 2 and all(segs):
                u, v = segs
                lu, lv = (u[0] ** 2 + u[1] ** 2) ** .5, \
                    (v[0] ** 2 + v[1] ** 2) ** .5
                cr = u[0] * v[1] - u[1] * v[0]
                dt = u[0] * v[0] + u[1] * v[1]
                ok = {"equal_length": abs(lu - lv) <= tol,
                      "parallel": abs(cr) <= tol * max(lu, lv),
                      "perpendicular": abs(dt) <= tol * max(lu, lv)}[t]
                if not ok:
                    bad("%s %s does not hold on the model's xy"
                        % (t, r.get("id")))
            if t == "midpoint" and str(r.get("point")) in P:
                ab = tk(of)
                if len(ab) == 2 and all(x in P for x in ab):
                    m = P[str(r["point"])]
                    c = ((P[ab[0]][0] + P[ab[1]][0]) / 2,
                         (P[ab[0]][1] + P[ab[1]][1]) / 2)
                    if abs(m[0] - c[0]) > tol or abs(m[1] - c[1]) > tol:
                        bad("midpoint %s does not hold on the model's xy"
                            % r.get("id"))
    return out


def vm_of_level(nj):
    """[(vm, fig or None)] of a level's noam-ai.json."""
    out = []
    for f in nj.get("figures") or []:
        if isinstance(f.get("visual_model"), dict):
            out.append((f["visual_model"], f))
    for v in nj.get("visuals") or []:
        out.append((v, None))
    return out


def legacy_view(nj):
    """The figure list the D rules read: a visual_model's highlight_given
    as given_marks, each aux patch as an aux figure (reveal, label, step,
    the objects it adds / shows and the relations it highlights)."""
    figs = []
    for f in nj.get("figures") or []:
        vm = f.get("visual_model")
        if not isinstance(vm, dict):
            figs.append(f)
            continue
        f = dict(f)
        rid = dict((r.get("id"), r) for r in vm.get("relations") or [])
        oid = dict((o.get("id"), o) for o in vm.get("objects") or [])
        gm = []
        for x in vm.get("highlight_given") or []:
            if not isinstance(x, str):
                continue                 # vm_faults V3 names it (r1 m1)
            r = rid.get(x) or {}
            if r.get("from_given"):
                # (v6.10, C3) a statement of a typed-shape given: D4 reads
                # the given it comes from (V6 checks the statement itself)
                r = rid.get(r["from_given"]) or {"type": "shape",
                                                 "from_given": x}
            gm.append({"claim": dict((k, v) for k, v in r.items()
                                     if k not in ("id", "role", "objects",
                                                  "highlight", "measured",
                                                  "marked", "mark_id",
                                                  "mark_ids"))})
        f["given_marks"] = gm
        figs.append(f)
        for a in vm.get("aux") or []:
            ob, cons = {}, []
            for op in a.get("ops") or []:
                if op.get("op") == "add":
                    for o in op.get("objects") or []:
                        ob.setdefault(_BUCKET.get(o.get("type"), "marks"),
                                      []).append(o)
                if op.get("op") == "show":
                    for x in op.get("ids") or []:
                        o = oid.get(x)
                        if o:
                            ob.setdefault(_BUCKET.get(o.get("type"),
                                                      "marks"), []).append(o)
            arel = dict((r.get("id"), r) for op in a.get("ops") or []
                        for r in op.get("relations") or [])
            for op in a.get("ops") or []:
                if op.get("op") == "highlight":
                    for x in op.get("ids") or []:
                        r = rid.get(x) or arel.get(x)
                        if r:
                            c = dict(r)
                            c["marked"] = True
                            c["status"] = {"to_prove": "to_prove"}.get(
                                r.get("role"), "derived")
                            cons.append(c)
            figs.append({"id": a.get("id"), "svg": a.get("svg"),
                         "question": f.get("question"),
                         "item": a.get("item"), "reveal": a.get("reveal"),
                         "label": a.get("label"), "step": a.get("step"),
                         "objects": ob, "constraints": cons})
    return figs


_NEEDS = (("probability_tree", u"(?<![א-ת])(?:ב|ה|ו)?עץ(?![א-ת])|דיאגרמת עץ"),
          ("venn", u"(?:דיאגרמת|דיאגרמה של) ון"),
          ("pie_chart", u"(?:דיאגרמת|דיאגרמה) עוגה"),
          ("bar_chart", u"(?:דיאגרמת|דיאגרמה) עמודות"),
          ("sample_space", u"מרחב (?:ה)?מדגם"),
          ("frequency_table", u"טבלת שכיחויות"))
_BUCKET = {"point": "points", "segment": "segments", "line": "lines",
           "ray": "rays", "polygon": "polygons", "circle": "circles",
           "arc": "arcs", "label": "labels", "dimension": "dimensions",
           "path": "paths"}


# ------------------------------------------------ find targets (v6.7.2) --
# BRIEF_V672: an item that asks to COMPUTE / FIND declares a find target in
# to_prove: {"type": "find", "quantity": "angle", "of": "ACB"}. This is the
# checker's own copy of the vocabulary (quantity -> what `of` names); a new
# quantity is one row here and one in didactic.FIND_QUANTITIES.
FIND_QUANTITIES = {
    "angle": "angle", "length": "segment", "distance": "segment",
    "area": "polygon", "perimeter": "polygon", "coordinates": "point",
    "variable": "variable", "ratio": "segments", "count": "any",
    "probability": "any", "cell": "cell", "graph_value": "any",
    "value": "any"}
_F_VAR = re.compile(u"^[a-zα-ω][0-9]*$")
_F_CELL = re.compile(u"^(?:.*-)?r([0-9]+)c([0-9]+)$")
# the words a sheet uses to ask for a number, an object or a value
_COMPUTE = re.compile(
    u"(?<![א-ת])ו?(?:חשבו|חשבי|חשב|מצאו|מצאי|מצא|קראו|קראי|קרא)(?![א-ת])|"
    u"(?<![א-ת])ו?(?:קבעו|קבעי|קבע)\\s+את(?![א-ת])|"
    u"(?<![א-ת])ו?ב?כמה(?![א-ת])|"
    u"(?<![א-ת])ו?(?:מהו|מהי|מהם|מהן|מה\\s+(?:ה|גודל|אורך|שטח|היקף|ערך|"
    u"שיעור|מספר|היחס|ההסתברות))(?![א-ת])|"
    # r1 T5: 'מה אורכו של', 'מה גודלה של', 'מה השטח של', 'מה שווה',
    # 'מה יהיה' -- not 'מה המשמעות / הקשר / ההבדל' (an explanation)
    u"(?<![א-ת])ו?מה\\s+(?:ה(?!(?:משמעות|קשר|הבדל|מסקנה|טעות|סיבה|"
    u"דמיון|שונה|יה|ייתה|יתה|יו)(?![א-ת]))[א-ת]+|(?:גודל|אורכ|שטח|היקפ|ערכ|שיעור|מספר)"
    u"[א-ת]*|שווה|שווים|יהיה|תהיה|יהיו|יצא|יוצא|יוצאת)(?![א-ת])|"
    u"(?<![א-ת])ו?(?:פתרו|פתרי|פתור|הביעו|הביעי|הבע|הציבו|הציבי|הצב|"
    u"העריכו|העריכי|פשטו|פשטי|עגלו|עגלי)(?![א-ת])|"
    u"=\\s*\\?|_{3,}|"
    u"(?<![א-ת])ו?(?:רשמו|רשמי|כתבו|כתבי)\\s+(?:את\\s+)?(?:ה?שיעור|"
    u"ה?ערך|ה?ערכי|ה?אורך|ה?גודל|ה?מספר|ה?יחס|"
    # r2 S1: 'רשמו את התוצאה / התשובה / הביטוי'
    u"ה?תוצאה|ה?תוצאות|ה?תשובה|ה?תשובות|ה?ביטוי|ה?סכום|ה?הפרש|ה?מכפלה|"
    u"ה?מנה|ה?שטח|ה?היקף|ה?פתרון|ה?פתרונות)|"
    # r2 S1: 'מי מהמספרים גדול יותר?' -- a comparison asks for a value
    u"(?<![א-ת])ו?מי\\s+מ[א-ת]+[^?!\n]*?(?:גדול|קטנ|קטן|ארוכ|ארוך|קצר|"
    u"רחוק|קרוב|כבד|קל|יקר|זול|גבוה|נמוכ|נמוך)[א-ת]*\\s+(?:יותר|ביותר)|"
    u"(?<![א-ת])ו?(?:השלימו|השלימי|השלם)(?![א-ת])(?!\\s+את\\s+ה?שרטוט)|"
    # r2 S1: a decimal point inside the question ('0.5 או 0.45?')
    u"(?<![א-ת])ו?[בלמש]?(?:אילו|איזה|איזו)(?![א-ת])"
    u"(?:[^?.!\n]|(?<=\\d)[.](?=\\d))*\\?|"
    u"(?<![א-ת])ו?[בלמש](?:אילו|איזה|איזו)(?![א-ת])")


# not a request for a value: an explanation ('הסבירו כיצד ידעתם מהו ...'),
# a hypothetical 'אילו' (= 'if': 'אילו ציר y היה מתחיל ב-0 ...'), an error
# to name ('איזו טעות עשתה דנה?')
_NOT_ASK = re.compile(
    u"(?<![א-ת])ו?(?:הסבירו|הסבירי|הסבר|תארו|תארי)\\s+(?:כיצד|איך|מדוע|"
    u"למה|במה)[^.?!\n]*|"
    u"(?<![א-ת])אילו(?=(?:\\s+\\S+){0,3}?\\s+(?:היה|הייתה|היתה|היו|הותר|"
    u"הותרו)(?![א-ת]))[^,–—.?!\n]*|"
    u"(?<![א-ת])(?:איזו|איזה|אילו)\\s+(?:טעות|טעויות|שגיאה)[^.?!\n]*[.?!]?")


def computes(text):
    """does the text ask the student to compute / find / read a value?"""
    t = re.sub(u"\\$[^$]*\\$", " x ", str(text or ""))
    t = _NOT_ASK.sub(" ", t)
    return bool(_COMPUTE.search(t))


def f_key(c):
    q = str(c.get("quantity") or "")
    k = FIND_QUANTITIES.get(q, "any")
    of = c.get("of")
    if k == "angle":
        return ("find", q, ang({"at": c.get("at"), "rays": c.get("rays")})
                if c.get("at") else ang(of))
    if k == "segment":
        return ("find", q, seg(of))
    if k == "segments":
        return ("find", q, tuple(seg(x) for x in of or []))
    if k == "polygon":
        return ("find", q, tuple(sorted(tk(of))))
    if isinstance(of, list):
        return ("find", q, tuple(map(str, of)))
    return ("find", q, str(of if of is not None else c.get("what") or ""))


def f_schema(c):
    q = c.get("quantity")
    if q not in FIND_QUANTITIES:
        return "quantity %r is not in the vocabulary (%s)" % (
            q, ", ".join(sorted(FIND_QUANTITIES)))
    k = FIND_QUANTITIES[q]
    of = c.get("of")
    n = len(tk(of)) if not isinstance(of, list) else None
    vals = of if isinstance(of, list) else ([] if of is None else [of])
    if k == "angle" and not c.get("at") and n != 3:
        return "an angle target names 3 points"
    if k == "segment" and n != 2:
        return "a %s target names one segment (2 points)" % q
    if k == "segments" and len(vals) < 2:
        return "a ratio target names 2+ quantities"
    if k == "polygon" and (n or 0) < 3:
        return "an %s target names a polygon (3+ points)" % q
    if k == "point" and n != 1:
        return "a coordinates target names one point"
    if k == "variable" and not (vals and all(_F_VAR.match(str(v))
                                             for v in vals)):
        return "a variable target names a symbol"
    if k == "cell" and not (vals and all(_F_CELL.match(str(v))
                                         for v in vals)):
        return "a cell target names r<row>c<col>"
    if k == "any" and not vals and not str(c.get("what") or "").strip() \
            and not c.get("curve"):
        return "the target names no object and says nothing (what=)"
    return None


def f_refs(c):
    """(points, variables, ids) one find target names."""
    k = FIND_QUANTITIES.get(str(c.get("quantity") or ""), "any")
    of = c.get("of")
    vals = of if isinstance(of, list) else ([] if of is None else [of])
    P, V, I = [], [], []
    if k == "angle" and c.get("at"):
        P = tk([c.get("at")] + list(c.get("rays") or []))
    elif k == "variable":
        V = list(map(str, vals))
    elif k == "cell":
        I = list(map(str, vals))
    else:
        for v in vals:
            if tk(v) and not re.sub(u"[A-Z0-9′″'\\s,]", "",
                                    str(v)):
                P += tk(v)
            elif k == "any":
                I.append(str(v))
            else:
                P += tk(v)
    if c.get("curve"):
        I.append(str(c["curve"]))
    return set(P), set(V), set(I)


def _wedge(V, A, B, L):
    d = lambda p: math.atan2(p[1] - V[1], p[0] - V[0])
    a, b, x = d(A), d(B), d(L)
    w = (b - a) % (2 * math.pi)
    if w > math.pi:
        a, w = b, 2 * math.pi - w
    return 0 < (x - a) % (2 * math.pi) < w, w


def _names_tg(txt, k, tg):
    m = re.match(u"^\\s*([^=(:]*?)\\s*[=(:]", txt)
    if not m or not re.search(r"\d", txt[m.end():]):
        return False
    t = tk(m.group(1))
    if k == "segment":
        return len(t) == 2 and seg("".join(t)) == tg
    if k == "angle":
        return (len(t) == 3 and ang("".join(t)) == tg) or \
            (len(t) == 1 and t[0] == tg[0])
    if k == "point":
        return t == [tg]
    if k == "polygon":
        return len(t) >= 3 and tuple(sorted(t)) == tg
    return False


def _f_given_owner(xy, txt, given, pts, tgt=None):
    """v6.7.2 r3 (G9T18-held-targets): the GIVEN angle a free degree label
    prints. shapekit.angle_arc writes a given's number with no `for`, on
    its own bisector (or as a callout beside its arc). A label whose number
    is a given angle's value, inside that given's wedge, and nearer (in
    angle, relative to the half-width) to the given's bisector than to the
    target's, is the given's own: the '35\u00b0' of a given \u2220BAC in a long
    rectangle is not printed on the wider target \u2220ACB or \u2220AOB whose
    wedge happens to hold it. `tgt` = (V, (R1, R2)) point names."""
    if not isinstance(xy, list) or len(xy) < 2:
        return None
    tn = fnums(txt)

    def ratio(Vn, rays):
        V = pts.get(str(Vn))
        R = [pts.get(str(r)) for r in rays or []]
        if not V or len(R) != 2 or not all(R):
            return None
        a1 = math.atan2(R[0][1] - V[1], R[0][0] - V[0])
        a2 = math.atan2(R[1][1] - V[1], R[1][0] - V[0])
        d = math.atan2(math.sin(a2 - a1), math.cos(a2 - a1))
        bis = a1 + d / 2.0
        x = math.atan2(xy[1] - V[1], xy[0] - V[0])
        off = abs(math.atan2(math.sin(x - bis), math.cos(x - bis)))
        return off / max(abs(d) / 2.0, 1e-6)
    tr = ratio(tgt[0], tgt[1]) if tgt else None
    Vt = pts.get(str(tgt[0])) if tgt else None

    def half_of(Vn, rays):
        V = pts.get(str(Vn))
        R = [pts.get(str(r)) for r in rays or []]
        if not V or len(R) != 2 or not all(R):
            return None
        a1 = math.atan2(R[0][1] - V[1], R[0][0] - V[0])
        a2 = math.atan2(R[1][1] - V[1], R[1][0] - V[0])
        return abs(math.atan2(math.sin(a2 - a1), math.cos(a2 - a1))) / 2.0
    best = None
    for g in given or []:
        if not isinstance(g, dict) or g.get("type") != "angle" or \
                g.get("value") is None:
            continue
        gn = fnums(str(g.get("value")))
        if not gn or not gn <= tn:
            continue
        r = ratio(g.get("at"), g.get("rays"))
        if r is None:
            continue
        if r >= 1.0 or (tr is not None and r >= tr):
            # not on the given's bisector: still its CALLOUT when it stands
            # just outside its wedge (angle_arc: 20deg past the arm) and
            # nearer its vertex than the target's
            Vg = pts.get(str(g.get("at")))
            half = half_of(g.get("at"), g.get("rays"))
            if Vt is None or half is None or \
                    (r - 1.0) * half > math.radians(60) or \
                    math.hypot(xy[0] - Vg[0], xy[1] - Vg[1]) >= \
                    math.hypot(xy[0] - Vt[0], xy[1] - Vt[1]):
                continue
        if best is None or r < best[0]:
            best = (r, ang({"at": g.get("at"), "rays": g.get("rays")}))
    return best[1] if best else None


def f_labels(F, c, given, val=None):
    """labels of figure F that print a value ON the object c asks for."""
    ob = F.get("objects") or {}
    k = FIND_QUANTITIES.get(str(c.get("quantity") or ""), "any")
    tg = f_key(c)[2]
    pts = {}
    for o in ob.get("points") or []:
        xy = o.get("xy")
        if o.get("name") and isinstance(xy, list) and len(xy) >= 2 and \
                not isinstance(xy[0], list):
            pts[str(o["name"])] = xy[:2]
    out = []
    gnums = set()
    for g in given or []:
        if isinstance(g, dict) and g.get("value") is not None:
            gnums |= fnums(str(g.get("value")))
    for lb in ob.get("labels") or []:
        txt = str(lb.get("text") or "")
        if not re.search(r"\d", txt):
            continue
        fo = str(lb.get("for") or "")
        hit = False
        if k == "segment" and fo and len(tk(fo)) == 2:
            hit = seg(fo) == tg
        elif k == "point" and fo:
            hit = fo == tg
        elif k == "polygon" and fo:
            hit = tuple(sorted(tk(fo))) == tg
        elif k == "angle" and not fo and u"°" in txt and \
                isinstance(lb.get("xy"), list) and len(tg) == 2 and \
                _f_given_owner(lb.get("xy"), txt, given, pts,
                               tg) not in \
                (None, tg):
            continue     # v6.7.2 r3: a given angle's own number
        elif k == "angle" and not fo and u"°" in txt and \
                isinstance(lb.get("xy"), list) and len(tg) == 2:
            V = pts.get(tg[0])
            R = [pts.get(r) for r in tg[1]]
            if V and len(R) == 2 and all(R):
                inside, w = _wedge(V, R[0], R[1], lb["xy"])
                hit = inside
                for g in given:
                    if g.get("type") == "angle" and \
                            str(g.get("at")) == tg[0] and hit:
                        gr = [pts.get(r) for r in g.get("rays") or []]
                        if len(gr) == 2 and all(gr):
                            gi, gw = _wedge(V, gr[0], gr[1], lb["xy"])
                            if gi and gw < w - 1e-6:
                                hit = False
        elif k == "angle" and fo and len(tk(fo)) == 3:
            hit = ang(fo) == tg          # r1 T7
        elif k == "any" and fo:
            hit = fo in set(map(str, c.get("of") if isinstance(
                c.get("of"), list) else [c.get("of")]))
        if not hit and k == "variable":
            # r1: 'x = 5' prints the variable's value, whatever it labels
            mv = re.match(u"^\\s*\\$?\\s*([a-zα-ω][0-9]*)\\s*\\$?\\s*=\\s*"
                          u"\\$?\\s*-?\\d", txt)
            hit = bool(mv and mv.group(1) in set(map(str, c.get("of") if
                       isinstance(c.get("of"), list) else [c.get("of")])))
        if not hit and k == "segments" and val is not None and \
                re.search(u"[:/]", txt) and f_hit(f_atoms(val), txt):
            hit = True                   # a ratio '1:2' printed anywhere
        if not hit and not fo:
            # r1 T3: a free label naming the target, or printing its value
            hit = _names_tg(txt, k, tg) or bool(
                k in ("angle", "segment", "polygon") and
                val is not None and f_hit(f_atoms(val), txt) and
                not f_hit(f_atoms(val), " ".join(sorted(
                    fvals(" ".join(sorted(gnums)))))))  # r3: a given's
        if hit:
            out.append((lb.get("svg_id"), txt))
    return out


def fnums(s):
    """numbers a text prints, a sentence's full stop not glued on."""
    out = set()
    # v6.13 fix_r1 (T08B-D9, from work_t08_b/skillfix): '(2,5)' is two
    # numbers, never 2.5 (the sheets write decimals with '.')
    for x in re.findall(u"(?<![\\w.])-?\\d+(?:[.]\\d+)?(?!\\w|[.]\\d)",
                        str(s or "").replace(u"\u2212", "-")):
        try:
            out.add("%g" % float(x.replace(",", ".")))
        except ValueError:
            out.add(x)
    return out


def f_leaks(c, val, ctx):
    """r1 T4: a public find target / relation states no number its item's
    text does not print; its unit is a word."""
    out = []
    u = c.get("unit")
    if u is not None and re.search(r"\d", str(u)):
        out.append("carries a unit with a number (%r)" % (u,))
    cn = fnums(ctx)
    vn = fnums(str(val)) if val is not None else set()
    for k in ("text", "what"):
        v = c.get(k)
        if v is None:
            continue
        ex = fnums(v) - cn
        if ex:
            out.append("%s %r prints %s, a number the item's text does not"
                       % (k, v, ", ".join(sorted(ex))))
        elif vn and vn <= fnums(v) and not vn <= cn:
            out.append("%s %r states its value" % (k, v))
    return out


# r2 (M1 / m2): where a find target's value can hide in noam-ai.json.
# Exact geometry (coordinates, view transforms, table row / col) is the
# model, not a printed value; everything else is read.
_F_GEOM = frozenset(("xy", "xyz", "svg_xy", "ink_box", "bbox", "view",
                     "viewbox", "data_to_svg", "data_unit_px", "rotate",
                     "row", "col", "r", "n", "width_px", "height_px",
                     "unit_px", "frame", "id", "svg_id", "svg"))
_F_TGT_KEYS = frozenset(("type", "text", "quantity", "of", "at", "rays",
                         "what", "curve", "x", "unit", "points", "point",
                         "t", "circle", "to", "space", "from_item"))
_F_REL_KEYS = _F_TGT_KEYS | frozenset(("id", "role", "item", "objects",
                                       "mark_id", "mark_ids", "marked"))
_F_SECRET = frozenset(("value", "answer", "answers", "solution",
                       "solutions", "result", "results"))
_F_DATA_KINDS = ("bar_chart", "pie_chart", "line_chart", "table",
                 "function_graph", "number_line")


def _leaves(o, path=""):
    """(path, key, leaf) of every scalar under o, geometry keys skipped."""
    if isinstance(o, dict):
        for k, v in o.items():
            if k in _F_GEOM:
                continue
            if isinstance(v, (dict, list)):
                for x in _leaves(v, "%s.%s" % (path, k)):
                    yield x
            elif v is not None and not isinstance(v, bool):
                yield "%s.%s" % (path, k), k, v
    elif isinstance(o, list):
        for i, v in enumerate(o):
            if isinstance(v, (dict, list)):
                for x in _leaves(v, "%s[%d]" % (path, i)):
                    yield x
            elif v is not None and not isinstance(v, bool):
                yield "%s[%d]" % (path, i), "", v


def _secret_paths(o, path=""):
    """paths of an answer-like key at any depth under o."""
    out = []
    if isinstance(o, dict):
        for k, v in o.items():
            p = "%s.%s" % (path, k)
            if k in _F_SECRET:
                out.append(p)
            out += _secret_paths(v, p)
    elif isinstance(o, list):
        for i, v in enumerate(o):
            out += _secret_paths(v, "%s[%d]" % (path, i))
    return out


def f_shape(c, rel=False):
    """r2 m2: a public find target / find relation carries only its own
    fields, and no answer-like key at any depth below them."""
    out = []
    keys = _F_REL_KEYS if rel else _F_TGT_KEYS
    for k in sorted(c):
        if k not in keys and k not in ("value", "answer"):
            out.append("carries the field %r, which a find %s does not "
                       "have" % (k, "relation" if rel else "target"))
    for k, v in c.items():
        if isinstance(v, (dict, list)):
            for p in _secret_paths(v, k):
                out.append("carries %r nested at %s" % (
                    p.rsplit(".", 1)[-1], p))
    return out


def f_target_objs(nj, qid, rid, c):
    """[(vm, obj)] the visual model says the find target c names: the
    objects of its find relation, or the objects named like it."""
    k = FIND_QUANTITIES.get(str(c.get("quantity") or ""), "any")
    tg = f_key(c)
    want = set()
    for vm, _f in vm_of_level(nj):
        if vm.get("question") != qid:
            continue
        for r in vm.get("relations") or []:
            if r.get("type") == "find" and r.get("item", rid) == rid and \
                    f_key(r) == tg:
                want.update(str(x) for x in r.get("objects") or [])
    P, _V, I = f_refs(c)
    if k == "segment":
        want.update("seg-" + "".join(s) for s in
                    [tk(c.get("of")), tk(c.get("of"))[::-1]])
    elif k == "point":
        want.update("pt-" + p for p in P)
    elif k in ("any", "cell"):
        want.update(I)
    out = []
    for vm, _f in vm_of_level(nj):
        if vm.get("question") != qid:
            continue
        for o in vm.get("objects") or []:
            oid = str(o.get("id"))
            if oid in want or (k == "cell" and any(
                    oid.endswith("-" + w) for w in I)):
                out.append((vm, o))
    return out


def f_objs(nj, qid, rid, c, ctx):
    """r2 M1: the model object a find target names prints no number its
    item's text does not print (value / label / text / frequency ...) --
    whatever sheet.json keeps."""
    cn = fnums(ctx)
    out = []
    for vm, o in f_target_objs(nj, qid, rid, c):
        data = vm.get("kind") in _F_DATA_KINDS
        for p, k, v in _leaves(o):
            if o.get("type") == "cell" and k == "value":
                continue                         # f_cells reads the cell
            if data and k in ("value", "angle") and \
                    isinstance(v, (int, float)):
                continue                         # chart data is the model
            ex = fnums(v) - cn
            if ex:
                out.append("%s: the model object %s carries %s = %r on the "
                           "object the item asks to find" % (
                               vm.get("id"), o.get("id"), p.lstrip("."), v))
    return out


def f_json(nj, qid, val, public, tobj):
    """r2 m2: the private value printed in noam-ai.json outside the
    author's words: a stray root field, a nested note, a free field of its
    own question's rows. v6.7.3: `public` is what the question's WORDS
    print (never a JSON given); figures / visuals / givens of the whole
    file are f_file's."""
    atoms = f_atoms(val)
    if not atoms or f_hit(atoms, " ".join(sorted(public))):
        return []
    out = []

    def hit(p, v):
        if f_hit(atoms, v):
            out.append("noam-ai.json prints the find target's value at "
                       "%s (%r)" % (p.lstrip("."), str(v)[:40]))
    for k, v in nj.items():
        if k in ("questions", "figures", "visuals", "curriculum",
                 "schema_version", "package", "level"):
            continue
        for p, _k, x in _leaves({k: v}):
            hit(p, x)
    for q in nj.get("questions") or []:
        if q.get("id") != qid:
            continue
        for r in [q] + list(q.get("items") or []):
            for k, v in r.items():
                if k in ("text", "intro", "label", "given", "items",
                         "figure_id", "id", "to_construct", "table"):
                    continue
                for p, _k, x in _leaves({k: v}, "." + str(r.get("id"))):
                    hit(p, x)
    return out


def f_cells(nj, qid, c):
    """r1 T2: a cell target's own cell is blank in the starting table, and
    the model does not call it a given."""
    if FIND_QUANTITIES.get(str(c.get("quantity") or "")) != "cell":
        return []
    of = c.get("of")
    want = [str(x) for x in (of if isinstance(of, list) else [of])]
    out = []
    vms = [v for v in nj.get("visuals") or [] if v.get("question") == qid]
    for f in nj.get("figures") or []:
        if f.get("question") == qid and f.get("visual_model"):
            vms.append(f["visual_model"])
    for vm in vms:
        for o in vm.get("objects") or []:
            oid = str(o.get("id"))
            if o.get("type") != "cell" or not any(
                    oid == w or oid.endswith("-" + w) for w in want):
                continue
            if re.search(r"\d", str(o.get("value") if o.get("value")
                                     is not None else "")):
                out.append("%s shows %r in the cell the item asks to find"
                           % (oid, o.get("value")))
            if o.get("role") == "given":
                out.append("%s is the find target and the model calls it "
                           "a given" % oid)
    return out


_SVGTXT = re.compile(r"<text\b[^>]*>(.*?)</text>", re.S)
_SVGTXT_ID = re.compile(r"<text\b([^>]*)>(.*?)</text>", re.S)
_F_AXIS_KINDS = ("coordinate_plane", "number_line", "function_graph")
_F_TICK_ID = re.compile(r"^(?:.*-)?lbl-(?:[xy]|o)?m?\d+(?:d\d+)?$")


# ------------------------------------------ v6.7.3 whole-file leak scan --
# BRIEF v673 (M1 M2 S1 m1): a find target's value may appear in
# noam-ai.json ONLY where a STATED given of a question carries the same
# number -- and then only on that given's own object / relation. Anywhere
# else in the whole file (relations, constraints, JSON-only givens, table
# cells, label / dimension / tick objects, any question's figure) it FAILs.
# Numbers compare by VALUE: 3/5 = 0.6 = 60%.
# (v6.16 fix r1, S1 / D-D12FRAC) the HOUSE fraction macros \\f{p}{q}
# (inline) and \\d{p}{q} (display) of emit_html are fractions too: "(1,
# \\f{5}{2})" states 2.5 (G8-T15 c q2's printed point read as unstated)
_FV_FRAC = re.compile(u"\\\\(?:[dt]?frac|f|d)\\s*\\{\\s*(-?\\d+(?:[.,]\\d+)?)\\s*\\}"
                      u"\\s*\\{\\s*(-?\\d+(?:[.,]\\d+)?)\\s*\\}")
# a/b, a:b, a : b -- not a heading colon ('days 1-5: 9, 7')
_FV_DIV = re.compile(u"(?<![\\w.])(-?\\d+(?:[.,]\\d+)?)(?:\\s*[/⁄]\\s*|[:∶]|"
                     u"\\s[:∶]\\s)(\\d+(?:[.,]\\d+)?)(?![\\w]|[.,]\\d)")
_FV_PCT = re.compile(u"(?<![\\w.])(-?\\d+(?:[.,]\\d+)?)\\s*(?:%|אחוז)")
_FV_WHOLE_DIV = re.compile(u"^\\s*\\$?\\s*(-?\\d+(?:[.,]\\d+)?)\\s*"
                           u"[/:⁄∶]\\s*(\\d+(?:[.,]\\d+)?)\\s*\\$?\\s*$")
_FV_WHOLE_PCT = re.compile(u"^\\s*(-?\\d+(?:[.,]\\d+)?)\\s*%\\s*$")
# keys that hold references to other objects (ids), never a printed number
_F_REFKEYS = frozenset(("name", "objects", "ids", "mark_id", "mark_ids", "highlight", "on",
                        "for", "item", "question", "status", "role",
                        "display", "part", "type", "kind", "schema_version",
                        "visual_support", "measured", "marked", "violated",
                        "ink_svg_id"))


def _fk(x):
    x = float(x)
    return "%.9g" % (0.0 if abs(x) < 1e-12 else x)


def _ff(s):
    return float(str(s).replace(",", "."))


def fvals(s):
    """every number a text prints, BY VALUE: 12, 0.6, a/b and a:b as their
    quotient (and their parts), p% as p and p/100, \\frac{a}{b}."""
    s = str(s if s is not None else "").replace(u"−", "-")
    out = set()
    for x in fnums(s):
        try:
            out.add(_fk(x))
        except ValueError:
            pass
    for a, b in _FV_FRAC.findall(s) + _FV_DIV.findall(s):
        try:
            if _ff(b) != 0:
                out.add(_fk(_ff(a) / _ff(b)))
            out.add(_fk(_ff(a)))
            out.add(_fk(_ff(b)))
        except ValueError:
            pass
    for p in _FV_PCT.findall(s):
        try:
            out.add(_fk(_ff(p) / 100.0))
        except ValueError:
            pass
    return out | _fv_wide(s)


def f_atoms(val):
    """the target's value as atoms, each a set of equal spellings BY VALUE:
    12 -> [{12}]; '3/5' -> [{0.6}]; '60%' -> [{60, 0.6}]; '(4, 0)' ->
    [{4}, {0}] (every coordinate must be there)."""
    if val is None or isinstance(val, bool):
        return []
    if isinstance(val, (int, float)):
        return [set([_fk(val)])]
    s = str(val).replace(u"−", "-").strip()
    m = _FV_WHOLE_DIV.match(s)
    if not m and re.match(u"^\\s*\\$?\\s*\\\\[dt]?frac", s):
        m = _FV_FRAC.search(s)
    if m:
        try:
            if _ff(m.group(2)) != 0:
                return [set([_fk(_ff(m.group(1)) / _ff(m.group(2)))])]
        except ValueError:
            pass
    m = _FV_WHOLE_PCT.match(s)
    if m:
        return [set([_fk(_ff(m.group(1))), _fk(_ff(m.group(1)) / 100.0)])]
    out = []
    for x in fnums(s):
        try:
            out.append(set([_fk(x)]))
        except ValueError:
            pass
    return out


def f_hit(atoms, s, conv=False, unit=None):
    """does the text print the value (every atom, in any spelling)? conv:
    a length target -- a length in another unit counts too (r1 M4)."""
    if not atoms:
        return False
    fv = fvals(s)
    if conv:
        fv = fv | _fv_conv(s, unit)
    return all(a & fv for a in atoms)


# ------------------------------------------------ v6.7.3 r1 wide reading --
# BRIEF v673 r1 (M3 M4 M5 S1): a value hides in more spellings than digits
# with a clean boundary. Hebrew letters glued to a number ('ב60%',
# '6.4ס"מ'), a Latin unit ('6.4cm'), a unit other than the answer's
# ('64 מ"מ'), an exact root ('√41' = 6.4 rounded), a mixed or vulgar
# fraction ('6⅖'), '%60', '600‰', 'a מתוך b' and Hebrew number words
# ('שש נקודה ארבע', 'שלוש חמישיות', 'שישים אחוז', 'תריסר') all print it.
_FV_LAT_UNITS = frozenset(("mm", "cm", "dm", "m", "km", "g", "kg", "l",
                           "ml", "s", "sec", "min", "h", "cm2", "m2", "mm2",
                           "cm3", "m3"))
_FV_NUM_G = re.compile(u"(?<![A-Za-z0-9_.])(-?\\d+(?:[.,]\\d+)?)"
                       u"(?![.,]?\\d)(?=([A-Za-z]*))")
_FV_PERMIL = re.compile(u"(?<![A-Za-z0-9_.])(\\d+(?:[.,]\\d+)?)\\s*‰")
_FV_PCT_FIRST = re.compile(u"%\\s*(\\d+(?:[.,]\\d+)?)(?![.,]?\\d)")
_FV_PCT_G = re.compile(u"(?<![A-Za-z0-9_.])(-?\\d+(?:[.,]\\d+)?)\\s*"
                       u"(?:%|אחוז)")
_FV_DIV_G = re.compile(u"(?<![A-Za-z0-9_.])(-?\\d+(?:[.,]\\d+)?)(?:\\s*[/⁄]"
                       u"\\s*|[:∶]|\\s[:∶]\\s|\\s*מתוך\\s*)(\\d+(?:[.,]\\d+)?)"
                       u"(?![A-Za-z0-9_]|[.,]\\d)")
_FV_VULGAR = {u"½": (1, 2), u"⅓": (1, 3), u"⅔": (2, 3), u"¼": (1, 4),
              u"¾": (3, 4), u"⅕": (1, 5), u"⅖": (2, 5), u"⅗": (3, 5),
              u"⅘": (4, 5), u"⅙": (1, 6), u"⅚": (5, 6), u"⅛": (1, 8),
              u"⅜": (3, 8), u"⅝": (5, 8), u"⅞": (7, 8), u"⅐": (1, 7),
              u"⅑": (1, 9), u"⅒": (1, 10)}
_FV_VULG_RX = re.compile(u"(?<![A-Za-z0-9_.])(\\d+)?\\s*([%s])" %
                         u"".join(_FV_VULGAR))
_FV_MIXED = re.compile(u"(?<![A-Za-z0-9_./])(\\d+)\\s+(\\d+)\\s*/\\s*(\\d+)"
                       u"(?![A-Za-z0-9_./])")
_FV_ROOT = re.compile(u"(?<![A-Za-z0-9_.])(\\d+(?:[.,]\\d+)?)?\\s*\\*?\\s*"
                      u"(?:√|\\\\sqrt)\\s*\\{?\\s*(\\d+(?:[.,]\\d+)?)\\s*\\}?")
# length units -> millimetres (a length target's value in another unit)
_FV_LEN_MM = [(u"ק\"מ", 1e6), (u"ק״מ", 1e6), (u"דצ\"מ", 100.0),
              (u"דצ״מ", 100.0), (u"ס\"מ", 10.0), (u"ס״מ", 10.0),
              (u"מ\"מ", 1.0), (u"מ״מ", 1.0), (u"מטרים", 1000.0),
              (u"מטר", 1000.0), (u"מ'", 1000.0), (u"מ׳", 1000.0),
              (u"km", 1e6), (u"dm", 100.0), (u"cm", 10.0), (u"mm", 1.0),
              (u"m", 1000.0)]
_FV_LEN_RX = re.compile(u"(?<![A-Za-z0-9_.])(\\d+(?:[.,]\\d+)?)\\s*(%s)"
                        u"(?![A-Za-z])" % u"|".join(
                            re.escape(u) for u, _f in _FV_LEN_MM))

_HW_UNIT = {u"אפס": 0, u"אחת": 1, u"אחד": 1, u"שתיים": 2, u"שתים": 2,
            u"שתי": 2, u"שניים": 2, u"שני": 2, u"שלוש": 3, u"שלושה": 3,
            u"שלושת": 3, u"ארבע": 4, u"ארבעה": 4, u"ארבעת": 4, u"חמש": 5,
            u"חמישה": 5, u"חמשת": 5, u"שש": 6, u"שישה": 6, u"ששת": 6,
            u"שבע": 7, u"שבעה": 7, u"שבעת": 7, u"שמונה": 8, u"שמונת": 8,
            u"תשע": 9, u"תשעה": 9, u"תשעת": 9}
_HW_TEN = {u"עשר": 10, u"עשרה": 10, u"עשרת": 10}
_HW_TENS = {u"עשרים": 20, u"שלושים": 30, u"ארבעים": 40, u"חמישים": 50,
            u"שישים": 60, u"שבעים": 70, u"שמונים": 80, u"תשעים": 90}
_HW_HUND = {u"מאה": 100, u"מאתיים": 200}
_HW_THOU = {u"אלף": 1000, u"אלפיים": 2000}
_HW_FIX = {u"תריסר": 12, u"תריסרים": 24}
_HW_DEN1 = {u"חצי": 2, u"שליש": 3, u"רבע": 4, u"חמישית": 5, u"שישית": 6,
            u"שביעית": 7, u"שמינית": 8, u"תשיעית": 9, u"עשירית": 10,
            u"מאית": 100, u"אלפית": 1000}
_HW_DENS = {u"חצאים": 2, u"שלישים": 3, u"שלישי": 3, u"רבעים": 4,
            u"רבעי": 4, u"חמישיות": 5, u"חמישיים": 5, u"שישיות": 6,
            u"שביעיות": 7, u"שמיניות": 8, u"תשיעיות": 9, u"עשיריות": 10,
            u"מאיות": 100, u"אלפיות": 1000}
_HW_PCT = (u"אחוז", u"אחוזים", u"אחוזי")
_HW_ALL = set(_HW_UNIT) | set(_HW_TEN) | set(_HW_TENS) | set(_HW_HUND) | \
    set(_HW_THOU) | set(_HW_FIX) | set(_HW_DEN1) | set(_HW_DENS) | \
    set(_HW_PCT) | set((u"מאות", u"אלפים", u"נקודה", u"מתוך"))
_HW_TOK = re.compile(u"\\d+(?:[.,]\\d+)?|[א-ת]+")
# a lone one-word 0 / 1 / 2 is mostly not a number ('כל אחד', 'שני
# הצדדים'): it may whitelist, it never makes a leak
_HW_WEAK = frozenset((u"אפס", u"אחת", u"אחד", u"שתיים", u"שתים", u"שתי",
                      u"שניים", u"שני"))


def _hw_lk(t, first):
    """the number word a token is, its prefix letters stripped."""
    if t in _HW_ALL:
        return t
    pre = u"ובלמשהכ" if first else u"ו"
    if len(t) > 2 and t[0] in pre:
        if t[1:] in _HW_ALL:
            return t[1:]
        if first and len(t) > 3 and t[1] in u"בלמשהכ" and t[2:] in _HW_ALL:
            return t[2:]
    return None


def _hw_int(toks, i):
    """(value, next index, words) of the Hebrew whole number at toks[i]."""
    total, j, lvl, words = 0, i, 9, []
    while j < len(toks):
        w = _hw_lk(toks[j], j == i)
        if w is None:
            break
        nx = _hw_lk(toks[j + 1], False) if j + 1 < len(toks) else None
        if w in _HW_UNIT and nx in _HW_TEN and lvl > 1:
            v, L, step = _HW_UNIT[w] + 10, 1, 2
        elif w in _HW_UNIT and nx == u"מאות" and lvl > 2:
            v, L, step = _HW_UNIT[w] * 100, 2, 2
        elif w in _HW_UNIT and nx == u"אלפים" and lvl > 3:
            v, L, step = _HW_UNIT[w] * 1000, 3, 2
        elif w in _HW_UNIT and lvl > 0:
            v, L, step = _HW_UNIT[w], 0, 1
        elif w in _HW_TEN and lvl > 1:
            v, L, step = 10, 1, 1
        elif w in _HW_TENS and lvl > 1:
            v, L, step = _HW_TENS[w], 1, 1
        elif w in _HW_HUND and lvl > 2:
            v, L, step = _HW_HUND[w], 2, 1
        elif w in _HW_THOU and lvl > 3:
            v, L, step = _HW_THOU[w], 3, 1
        elif w in _HW_FIX and lvl == 9:
            v, L, step = _HW_FIX[w], 0, 1
        else:
            break
        total += v
        lvl = L
        words += [w] + ([nx] if step == 2 else [])
        j += step
    if j == i:
        return None
    return total, j, words


def _hw_vals(s):
    """(strong, weak): the values Hebrew number words (mixed with digits:
    '3 מתוך 5') print -- whole numbers, 'נקודה' decimals, fractions
    ('שלוש חמישיות', 'חצי', 'שש וחצי'), 'אחוז', 'a מתוך b'."""
    toks = _HW_TOK.findall(str(s if s is not None else ""))
    strong, weak = set(), set()

    def num_at(i):
        if i >= len(toks):
            return None
        if re.match(u"^\\d", toks[i]):
            try:
                return _ff(toks[i]), i + 1, [toks[i]], True
            except ValueError:
                return None
        r = _hw_int(toks, i)
        return (float(r[0]), r[1], r[2], False) if r else None
    i = 0
    while i < len(toks):
        w = _hw_lk(toks[i], True)
        if w in _HW_DEN1 and not re.match(u"^\\d", toks[i]):
            strong.add(1.0 / _HW_DEN1[w])
            i += 1
            continue
        r = num_at(i)
        if r is None:
            i += 1
            continue
        n, j, words, digits = r
        out = set()
        nx = _hw_lk(toks[j], False) if j < len(toks) else None
        if nx == u"נקודה" and j + 1 < len(toks):
            ds, k = u"", j + 1
            while k < len(toks):
                d = _hw_lk(toks[k], False)
                if d in _HW_UNIT and _HW_UNIT[d] <= 9:
                    ds += str(_HW_UNIT[d])
                    k += 1
                else:
                    break
            if len(ds) < 2:
                if re.match(u"^\\d+$", toks[j + 1]):
                    ds, k = toks[j + 1], j + 2
                else:
                    m = _hw_int(toks, j + 1)
                    if m:
                        ds, k = str(m[0]), m[1]
            if ds:
                out.add(n + int(ds) / 10.0 ** len(ds))
                j = k
        elif nx in _HW_DENS or nx in _HW_DEN1:
            d = _HW_DENS.get(nx) or _HW_DEN1.get(nx)
            out |= set((n / d, n, float(d)))
            j += 1
        elif nx in _HW_PCT:
            out |= set((n / 100.0, n))
            j += 1
        elif nx == u"מתוך":
            m = num_at(j + 1)
            if m and m[0]:
                out |= set((n / m[0], n, m[0]))
                j = m[1]
        elif j < len(toks) and toks[j][:1] == u"ו" and \
                toks[j][1:] in _HW_DEN1:
            out.add(n + 1.0 / _HW_DEN1[toks[j][1:]])
            j += 1
        if not out:
            if digits:
                i = j
                continue
            if len(words) == 1 and words[0] in _HW_WEAK:
                weak.add(n)
            else:
                strong.add(n)
        else:
            strong |= out
        i = max(j, i + 1)
    return strong, weak


def _fnums_g(s):
    """the numbers a text prints, a Hebrew letter or a Latin unit glued on
    ('ב60%', '6.4ס\"מ', '6.4cm') -- not a Latin name ('A1', 'x2', '2x')."""
    out = set()
    for m in _FV_NUM_G.finditer(str(s if s is not None else "").replace(
            u"−", "-")):
        if m.group(2) and m.group(2).lower() not in _FV_LAT_UNITS:
            continue
        try:
            out.add("%g" % _ff(m.group(1)))
        except ValueError:
            pass
    return out


def _fv_rounded(v):
    """an exact root prints the answer rounded to 1-3 decimals."""
    out = set([_fk(v)])
    for n in (1, 2, 3):
        if abs(round(v, n) - round(v)) > 1e-12:
            out.add(_fk(round(v, n)))
    return out


def _fv_wide(s):
    """fvals' extra spellings (see the block comment)."""
    s = str(s if s is not None else "").replace(u"−", "-")
    out = set()
    for x in _fnums_g(s):
        out.add(_fk(x))
    for a, b in _FV_DIV_G.findall(s):
        try:
            if _ff(b) != 0:
                out.add(_fk(_ff(a) / _ff(b)))
        except ValueError:
            pass
    for p in _FV_PCT_G.findall(s) + _FV_PCT_FIRST.findall(s):
        try:
            out |= set((_fk(_ff(p)), _fk(_ff(p) / 100.0)))
        except ValueError:
            pass
    for p in _FV_PERMIL.findall(s):
        out.add(_fk(_ff(p) / 1000.0))
    for w, ch in _FV_VULG_RX.findall(s):
        a, b = _FV_VULGAR[ch]
        out.add(_fk((int(w) if w else 0) + float(a) / b))
    for w, a, b in _FV_MIXED.findall(s):
        if int(b):
            out.add(_fk(int(w) + float(a) / int(b)))
    for k, r in _FV_ROOT.findall(s):
        try:
            out |= _fv_rounded((_ff(k) if k else 1.0) * math.sqrt(_ff(r)))
        except ValueError:
            pass
    st, _wk = _hw_vals(s)
    for v in st:
        out |= _fv_rounded(v) if abs(v - round(v, 6)) > 1e-9 else \
            set([_fk(v)])
    return out


def _fv_conv(s, unit=None):
    """a length printed in another unit, as the answer's unit (the target's
    'unit', else centimetres): '64 מ\"מ' -> 6.4."""
    to = 10.0
    if unit:
        for u, f in _FV_LEN_MM:
            if str(unit).strip() == u:
                to = f
                break
    out = set()
    for x, u in _FV_LEN_RX.findall(str(s if s is not None else "")):
        f = dict(_FV_LEN_MM).get(u)
        if f and f != to:
            try:
                out.add(_fk(_ff(x) * f / to))
            except ValueError:
                pass
    return out


# number words the author's text may use for a number the JSON writes
_F_HEB_NUM = [(u"אפס", 0), (u"אחת", 1), (u"אחד", 1), (u"שתיים", 2),
              (u"שתים", 2), (u"שתי", 2), (u"שניים", 2), (u"שני", 2),
              (u"שלוש", 3), (u"שלושה", 3), (u"ארבע", 4), (u"ארבעה", 4),
              (u"חמש", 5), (u"חמישה", 5), (u"שש", 6), (u"שישה", 6),
              (u"שבע", 7), (u"שבעה", 7), (u"שמונה", 8), (u"תשע", 9),
              (u"תשעה", 9), (u"עשר", 10), (u"עשרה", 10)]
_F_HEB_RX = re.compile(u"(?<![א-ת])[ובלמשה]?(%s)(?![א-ת])" % "|".join(
    sorted(set(w for w, _n in _F_HEB_NUM), key=len, reverse=True)))


def _f_qtext(q):
    """the author's words of one question: text, intro, its items' texts
    and its printed table."""
    parts = [q.get("text"), q.get("intro")]
    for it in q.get("items") or []:
        parts += [it.get("text"), it.get("intro")]
    # v6.12 fix_r1 (t01_a D3): a worked example is PRINTED above the stem
    # (G80 binds it), so its numbers are the question's own words -- not a
    # JSON-only field of the file
    ex = q.get("example")
    if isinstance(ex, dict):
        parts += [ex.get("title")] + list(ex.get("lines") or [])
    tb = q.get("table")
    if isinstance(tb, dict):
        parts += list(tb.get("head") or [])
        for row in tb.get("rows") or []:
            parts += list(row or [])
    t = u" ".join(str(x) for x in parts if x is not None)
    hn = dict(_F_HEB_NUM)
    words = [str(hn[m]) for m in _F_HEB_RX.findall(t)]
    st, wk = _hw_vals(t)
    words += ["%g" % v for v in sorted(st | wk)]
    return t + (u" " + u" ".join(words) if words else u"")


# (v6.16 fix r1, D-D12) {question id: numbers} the question's PIE CHART
# prints in its SVG text (value labels "40%", a total label): check_level
# fills it from figures/*.svg before the rules run. A pie's visual_model
# sector objects carry their names only (never a value: a missing value may
# be asked), so without this a printed given "הגזרה A: 40%" read as a
# JSON-only given and every find of the sheet equal to 40 FAILed D12.
_SVG_SHOWN = {}
# PROPOSAL ONLY: per-figure evidence, never a global numeric allow-list.
# A label must agree in the legacy export, visual model, and actual SVG,
# and its non-text owner must also exist in all three representations.
_NATIVE_PRINTED_LABELS = {}
_NATIVE_PRINTED_LENGTH_LABELS = {}


def native_printed_labels(figure, svg, strict_length_ink=False):
    import xml.etree.ElementTree as ET
    vm = figure.get("visual_model") or {}
    if not isinstance(vm, dict):
        return {}
    try:
        root = ET.fromstring(svg or "")
    except ET.ParseError:
        return {}
    ids = [e.get("id") for e in root.iter() if e.get("id")]
    if strict_length_ink and (len(ids) != len(set(ids)) or any(
            e.tag.split("}")[-1] in ("style", "script", "use", "foreignObject",
                                     "animate", "set") for e in root.iter())):
        return {}  # complex/dynamic paint is outside this bounded proof
    els = {e.get("id"): e for e in root.iter() if e.get("id")}
    parents = {child: parent for parent in root.iter() for child in parent}
    def visible(element, paint_kind=None):
        paint = {}
        while element is not None:
            style = str(element.get("style") or "").replace(" ", "").lower()
            if (element.get("display") == "none" or element.get("visibility") == "hidden"
                    or element.get("opacity") == "0" or any(x in style for x in
                        ("display:none", "visibility:hidden", "opacity:0"))):
                return False
            if strict_length_ink:
                # Fixed native profile only: do not interpret CSS shorthands,
                # priorities, alternate fonts or inherited text rendering.
                if element.get("style") is not None:
                    return False
                attrs = dict(element.attrib)
                attrs.update(x.split(":", 1) for x in style.split(";")
                             if ":" in x)
                if any(attrs.get(x) not in (None, "", "none") for x in
                       ("clip-path", "mask", "filter", "transform")):
                    return False
                try:
                    opacity = float(attrs.get("opacity", 1))
                    if not math.isfinite(opacity) or opacity != 1:
                        return False
                except (ValueError, TypeError):
                    return False
                # Walk from child to ancestors: the closest explicit paint
                # wins; ancestor display/opacity restrictions still apply.
                for name in ("fill", "stroke", "fill-opacity", "stroke-opacity",
                             "stroke-width", "font-size", "visibility"):
                    if name in attrs and name not in paint:
                        paint[name] = str(attrs[name]).strip().lower()
            element = parents.get(element)
        if strict_length_ink:
            def native_number(value, expected):
                try:
                    value = float(str(value).removesuffix("px"))
                    return math.isfinite(value) and value == expected
                except (ValueError, TypeError):
                    return False
            def positive(value):
                try:
                    value = float(str(value).removesuffix("px"))
                    return math.isfinite(value) and value > 0
                except (ValueError, TypeError):
                    return False
            def opaque_fixed(value):
                # Only demonstrated dark native ink establishes the new fact.
                # White/light ink on the native white canvas, alpha colors,
                # functions and paint servers fail closed; no contrast renderer.
                value = str(value).strip().lower()
                return value in {"black", "#000", "#000000", "#111", "#111111",
                                 "#333", "#333333"}
            if paint.get("visibility") in ("hidden", "collapse"):
                return False
            if paint_kind == "text":
                return (opaque_fixed(paint.get("fill", "black"))
                        and native_number(paint.get("fill-opacity", 1), 1)
                        and native_number(paint.get("font-size", 14), 14))
            return (opaque_fixed(paint.get("stroke", "none"))
                    and native_number(paint.get("stroke-opacity", 1), 1)
                    and native_number(paint.get("stroke-width", 1), 1.5))
        return True
    def simple_coordinates(label, owner, text_element, owner_element):
        """Actual simple native ink and VM coordinates agree inside viewBox.

        No transformed text, relative offsets, path renderer or inferred
        clipping proof. The existing fallback polygon must contain this
        exact consecutive native segment. Unsupported forms fail closed.
        """
        try:
            box = [float(v) for v in re.split(r"[ ,]+", root.get("viewBox", "").strip())]
            if (len(box) != 4 or not all(math.isfinite(v) for v in box)
                    or box[2] <= 0 or box[3] <= 0):
                return False
            # The supported export renders one SVG pixel per viewBox unit.
            # A microscopic outer viewport is not proof of readable native ink.
            if (root.tag.split("}")[-1] != "svg" or root.get("x") is not None
                    or root.get("y") is not None
                    or float(root.get("width")) != box[2]
                    or float(root.get("height")) != box[3]):
                return False
            allowed_root = {"data-fig", "width", "height", "viewBox",
                            "opacity", "display", "visibility"}
            owner_tag = owner_element.tag.split("}")[-1]
            allowed_owner = {"id", "class", "fill", "stroke", "stroke-width",
                             "opacity", "stroke-opacity", "display", "visibility"}
            allowed_owner |= ({"x1", "y1", "x2", "y2"} if owner_tag == "line"
                              else {"points"} if owner_tag == "polygon" else set())
            if (set(root.attrib) - allowed_root
                    or set(owner_element.attrib) - allowed_owner
                    or len(owner_element)):
                return False  # no alternate inherited/dashed/marker rendering
            if (len(text_element) or parents.get(text_element) is not root
                    or parents.get(owner_element) is not root
                    or text_element.get("font-family") != "David Libre,serif"):
                return False
            allowed_text = {"id", "x", "y", "font-family", "font-size",
                            "text-anchor", "fill", "opacity", "fill-opacity",
                            "visibility", "display"}
            if set(text_element.attrib) - allowed_text:
                return False  # no tspan/relative-font/CSS renderer fallback
            def pair(values):
                return (isinstance(values, (list, tuple)) and len(values) == 2
                        and all(isinstance(v, (int, float)) and math.isfinite(v)
                                for v in values))
            def close(a, b):
                return pair(a) and pair(b) and all(abs(a[i]-b[i]) <= 0.02 for i in (0, 1))
            def inside(a):
                return pair(a) and (box[0] <= a[0] <= box[0]+box[2]
                                    and box[1] <= a[1] <= box[1]+box[3])
            if (owner.get("type") != "segment" or text_element.get("text-anchor") != "middle"
                    or any(text_element.get(k) is not None for k in
                           ("dx", "dy", "rotate", "textLength", "lengthAdjust"))):
                return False
            anchor = [float(text_element.get(k)) for k in ("x", "y")]
            if not inside(anchor) or not close(anchor, label.get("svg_xy")):
                return False
            bbox = label.get("bbox") or []
            if (len(bbox) != 4 or not inside(bbox[:2]) or not inside(bbox[2:])
                    or not bbox[0] <= anchor[0] <= bbox[2]
                    or not bbox[1] <= anchor[1] <= bbox[3]):
                return False
            # Separation/clipping cannot rely only on a JSON bbox that could
            # be jointly shrunk. The fixed14px native ASCII font has this
            # conservative per-character ink reserve around its actual anchor.
            actual_words = (text_element.text or "").strip()
            if not re.fullmatch(r"[A-Za-z0-9.+-]{1,16}", actual_words):
                return False
            glyph_reserve = [anchor[0]-7*len(actual_words), anchor[1]-16,
                             anchor[0]+7*len(actual_words), anchor[1]+4]
            if not inside(glyph_reserve[:2]) or not inside(glyph_reserve[2:]):
                return False
            # A label is not public ink if later/unsupported paint can cover
            # it. This deliberately recognizes only the simple native canvas:
            # empty point hooks, unfilled dark geometry, then separate fixed
            # dark labels. It is not a general SVG compositing proof.
            namespace = "{http://www.w3.org/2000/svg}"
            if root.tag != namespace + "svg":
                return False
            canvas = []
            for child in root:
                if child.tag == namespace + "g":
                    if (set(child.attrib) - {"id", "class", "data-kind", "data-role", "data-xy"}
                            or child.get("class") != "ink-copy"
                            or child.get("data-kind") != "point"
                            or child.get("data-role") != "vertex"
                            or len(child) != 1 or child[0].tag != namespace + "line"):
                        return False
                    canvas.append(child[0])  # one short native vertex ink hook
                else:
                    canvas.append(child)
            seen_text = False
            def overlaps(a, b):
                return (a[0] <= b[2] and b[0] <= a[2]
                        and a[1] <= b[3] and b[1] <= a[3])
            for ink in canvas:
                tag = ink.tag.removeprefix(namespace)
                if ink.tag != namespace + tag or tag not in {"g", "line", "polygon", "text"}:
                    return False
                if tag == "text":
                    seen_text = True
                    if (len(ink) or set(ink.attrib) - allowed_text
                            or ink.get("font-family") != "David Libre,serif"
                            or ink.get("text-anchor") != "middle"
                            or not visible(ink, "text")):
                        return False
                    sid = ink.get("id")
                    sibling = objects.get(sid) or {}
                    sibling_old = legacy.get(sid) or {}
                    words = (ink.text or "").strip()
                    position = [float(ink.get(k)) for k in ("x", "y")]
                    if (not words or not re.fullmatch(r"[A-Za-z0-9.+-]{1,16}", words)
                            or words != sibling.get("text") or words != sibling_old.get("text")
                            or not close(position, sibling.get("svg_xy"))):
                        return False
                    # A conservative fixed-font rectangle around every other
                    # label must be separate from the fact's declared bbox.
                    if ink is not text_element:
                        reserve = [position[0]-7*len(words), position[1]-16,
                                   position[0]+7*len(words), position[1]+4]
                        if overlaps(glyph_reserve, reserve):
                            return False
                    continue
                if seen_text or len(ink):
                    return False  # all geometry precedes all labels, no children
                if tag == "g":
                    if set(ink.attrib) - {"id", "class", "data-kind", "data-role", "data-xy"}:
                        return False
                    continue
                allowed = {"id", "class", "fill", "stroke", "stroke-width",
                           "opacity", "stroke-opacity", "display", "visibility"}
                allowed |= {"points"} if tag == "polygon" else {"x1", "y1", "x2", "y2"}
                if (set(ink.attrib) - allowed or ink.get("fill", "none") != "none"
                        or ink.get("stroke") not in {"black", "#000", "#000000", "#111", "#111111", "#333", "#333333"}
                        or float(ink.get("stroke-width", 0)) not in (1.2, 1.5)
                        or float(ink.get("opacity", 1)) != 1
                        or float(ink.get("stroke-opacity", 1)) != 1):
                    return False
                if tag == "line":
                    points = [[float(ink.get(x)), float(ink.get(y))]
                              for x, y in (("x1", "y1"), ("x2", "y2"))]
                else:
                    vals = [float(v) for v in re.split(r"[ ,]+", ink.get("points", "").strip())]
                    if len(vals) < 6 or len(vals) % 2:
                        return False
                    points = list(zip(vals[::2], vals[1::2]))
                if not all(inside(p) for p in points):
                    return False
                reserve = [min(p[0] for p in points)-2, min(p[1] for p in points)-2,
                           max(p[0] for p in points)+2, max(p[1] for p in points)+2]
                if overlaps(glyph_reserve, reserve):
                    return False
            ends = owner.get("svg_xy") or []
            if len(ends) != 2 or not all(inside(e) for e in ends):
                return False
            tag = owner_element.tag.split("}")[-1]
            if tag == "line":
                actual = [[float(owner_element.get(x)), float(owner_element.get(y))]
                          for x, y in (("x1", "y1"), ("x2", "y2"))]
                if not ((close(actual[0], ends[0]) and close(actual[1], ends[1]))
                        or (close(actual[0], ends[1]) and close(actual[1], ends[0]))):
                    return False
            elif tag == "polygon":
                nums = [float(v) for v in re.split(r"[ ,]+", owner_element.get("points", "").strip())]
                if len(nums) < 6 or len(nums) % 2:
                    return False
                actual = list(zip(nums[::2], nums[1::2]))
                if not all(inside(a) for a in actual) or not any(
                        (close(a, ends[0]) and close(b, ends[1]))
                        or (close(a, ends[1]) and close(b, ends[0]))
                        for a, b in zip(actual, actual[1:]+actual[:1])):
                    return False
            else:
                return False
            matrix = (figure.get("view") or {}).get("data_to_svg")
            vm_matrix = (vm.get("view") or {}).get("data_to_svg")
            if (not isinstance(matrix, list) or len(matrix) != 6
                    or matrix != vm_matrix or not all(math.isfinite(v) for v in matrix)):
                return False
            def mapped(a):
                return [matrix[0]*a[0]+matrix[2]*a[1]+matrix[4],
                        matrix[1]*a[0]+matrix[3]*a[1]+matrix[5]]
            data_ends = owner.get("xy") or []
            return (len(data_ends) == 2 and all(pair(a) for a in data_ends)
                    and all(close(mapped(a), b) for a, b in zip(data_ends, ends))
                    and pair(label.get("xy")) and close(mapped(label["xy"]), anchor))
        except (TypeError, ValueError, KeyError, IndexError, OverflowError):
            return False

    legacy = {o.get("svg_id"): o for rows in (figure.get("objects") or {}).values()
              if isinstance(rows, list) for o in rows if isinstance(o, dict)}
    objects = {o.get("id"): o for o in vm.get("objects") or [] if isinstance(o, dict)}
    out = {}
    for oid, o in objects.items():
        if o.get("type") not in ("label", "dimension") or o.get("display") != "initial":
            continue
        sid, owner = o.get("svg_id"), objects.get(o.get("for"))
        if owner is None:
            matches = [v for v in objects.values() if v.get("name") == o.get("for")
                       and v.get("type") not in ("label", "dimension", "text", "note")]
            owner = matches[0] if len(matches) == 1 else None
        old, el = legacy.get(sid), els.get(sid)
        if not old or el is None or el.tag.split("}")[-1] != "text":
            continue
        if not owner or owner.get("type") in ("label", "dimension", "text", "note"):
            continue
        osid = owner.get("svg_id")
        if osid not in legacy or owner.get("display") != "initial":
            continue
        owner_el = els.get(osid)
        # Native shared polygon ink can render an edge without a separate
        # line element. Accept only the actual consecutive endpoint pair.
        if owner_el is None and owner.get("type") == "segment":
            ends = owner.get("svg_xy") or []
            for ink in legacy[osid].get("ink_svg_id") or []:
                candidate = els.get(ink)
                if candidate is None or candidate.tag.split("}")[-1] != "polygon":
                    continue
                try:
                    coords = [float(x) for x in re.split(r"[ ,]+", candidate.get("points", "").strip())]
                    pairs = list(zip(coords[::2], coords[1::2]))
                    close = lambda a, b: len(a) == 2 and all(abs(float(a[i])-b[i]) <= 0.02 for i in (0, 1))
                    if len(ends) == 2 and any((close(ends[0], a) and close(ends[1], b))
                            or (close(ends[1], a) and close(ends[0], b))
                            for a, b in zip(pairs, pairs[1:] + pairs[:1])):
                        owner_el = candidate
                        break
                except (ValueError, TypeError):
                    pass
        if owner_el is None:
            continue
        tags = {"point": {"circle", "ellipse"}, "segment": {"line", "path", "polygon"},
                "polygon": {"polygon", "path"}, "circle": {"circle"},
                "arc": {"path"}, "line": {"line", "path"}, "ray": {"line", "path"}}
        if owner_el.tag.split("}")[-1] not in tags.get(owner.get("type"), set()):
            continue
        # The strict new length path also proves actual simple ink placement;
        # the legacy default keeps its previously reviewed behavior.
        if strict_length_ink and not simple_coordinates(o, owner, el, owner_el):
            continue
        # An absent/hidden/mismatched label never establishes public data.
        if not visible(el, "text") or not visible(owner_el, "geometry"):
            continue
        raw = "".join(el.itertext()).strip()
        if (raw and raw == o.get("text") == old.get("text")
                and old.get("for") == o.get("for")):
            out[oid] = raw
    return out
_SVG_TEXT = re.compile(r"<text\b[^>]*>([^<]*)</text>")


def svg_shown(svg):
    """the numbers the <text> elements of an SVG print"""
    out = set()
    for t in _SVG_TEXT.findall(str(svg or "")):
        out |= fvals(t)
    return out


def native_axis_shown(svg, figure, object_map):
    """Only actual native tick labels backed by this figure's public frame.

    A day/month number may equal a requested graph value.  Like legacy
    ticks it is a scale label, not an answer.  Free captions and marker
    coordinates never enter this set.
    """
    import xml.etree.ElementTree as ET
    frame = figure.get("frame") or {}
    if frame.get("family") not in ("coordinate_plane", "number_line"):
        return set()
    labels = {}
    for axis in frame.get("axes") or []:
        name = str(axis.get("axis", "")).split(":")[-1]
        for index, value in axis.get("labels") or []:
            labels[(name, str(index))] = str(value)
    try:
        root = ET.fromstring(svg or "")
    except ET.ParseError:
        return set()
    els = {e.get("id"): e for e in root.iter() if e.get("id")}
    out = set()
    for row in object_map.get("display_items") or []:
        if row.get("role") not in ("axis_number", "origin_number"):
            continue
        for sid in row.get("elements") or []:
            e = els.get(sid)
            if e is None or e.tag.split("}")[-1] != "text":
                continue
            hook = e.get("data-num", "").split()
            raw = "".join(e.itertext()).strip()
            if len(hook) == 2:
                expected = labels.get(tuple(hook))
                own_axis = (row.get("source") or {}).get("entity") == "axis:" + hook[0]
            elif hook == ["origin"]:
                expected = "0" if any(k[1] == "0" and v == "0" for k, v in labels.items()) else None
                own_axis = (row.get("source") or {}).get("entity") == frame.get("plane")
            else:
                continue
            if own_axis and expected is not None and raw == expected == row.get("text"):
                out |= fvals(raw)
    return out


_DEN = re.compile(u"(?:נסמן|נסמנה|יסומן|סמנו)[^.?!:]*")
_DEN_NAME = re.compile(u"ב[-\u05be]?\\s*([A-Z](?:\u2032|')?)\\s+את\\s")


def _denoted(text):
    """(v6.16 fix r1) the point names a text defines by denotation: in a
    sentence of "נסמן ..." every "ב-X את ..." ("let X be ...")."""
    t = str(text or "").replace("$", "")
    out = set()
    for m in _DEN.finditer(t):
        out |= set(x.replace(u"\u2032", "'") for x in
                   _DEN_NAME.findall(m.group(0) + " "))
    return out


def _f_shown(nj, qid):
    """the numbers a question's data visuals print (chart values and their
    category / tick labels): stated content, like its words."""
    out = set(_SVG_SHOWN.get(qid) or ())
    for f in list(nj.get("figures") or []) + list(nj.get("visuals") or []):
        vm = f.get("visual_model") if "visual_model" in f else f
        if not isinstance(vm, dict) or (f.get("question") or
                                        vm.get("question")) != qid:
            continue
        if vm.get("kind") not in _F_DATA_KINDS or vm.get("kind") == "table":
            continue
        for o in vm.get("objects") or []:
            if o.get("type") in ("cell",):
                continue
            for k in ("value", "text", "label", "category", "frequency"):
                if o.get(k) is not None:
                    out |= fvals(o.get(k))
    return out


def _f_table(q):
    """{(row, col): printed text} of the question's table: head = row 1."""
    tb = q.get("table")
    out = {}
    if not isinstance(tb, dict):
        return out
    for j, x in enumerate(tb.get("head") or []):
        out[(1, j + 1)] = x
    for i, row in enumerate(tb.get("rows") or []):
        for j, x in enumerate(row or []):
            out[(i + (2 if tb.get("head") else 1), j + 1)] = x
    return out


def _f_abs(v):
    """a set of value keys, sign dropped: '1-5' is a range, '5x - 8' prints
    8 -- whether the author's words state a given compares magnitudes."""
    return set(x.lstrip("-") for x in v)


def _f_gvals(g):
    return fvals(g.get("value") if g.get("value") is not None else "") | \
        fvals(g.get("text"))


def _f_plain(s):
    """the plain numbers a text prints, sign dropped (the stated check).
    (v6.16 fix r1, S1 / D-D12FRAC) a printed FRACTION macro (\\f{5}{2},
    \\d{p}{q}, \\frac) prints its value too: "(1, \\f{5}{2})" states 2.5"""
    out = set()
    for x in fnums(s) | _fnums_g(s):
        try:
            out.add(_fk(x).lstrip("-"))
        except ValueError:
            pass
    for a, b in _FV_FRAC.findall(str(s if s is not None else "")):
        try:
            if _ff(b) != 0:
                out.add(_fk(_ff(a) / _ff(b)).lstrip("-"))
        except ValueError:
            pass
    return out


def _f_gplain(g):
    return _f_plain(g.get("value") if g.get("value") is not None else "") \
        | _f_plain(g.get("text"))


def _f_stated(q, shown=frozenset()):
    """[(given, its numbers)] of the question whose every number the
    author's words (or its printed chart data) print: a STATED given (not
    a JSON-only one)."""
    tv = _f_plain(_f_qtext(q)) | _f_abs(shown)
    out = []
    for r in [q] + list(q.get("items") or []):
        for g in r.get("given") or []:
            if isinstance(g, dict) and not g.get("from_item"):
                gv = _f_gvals(g)
                if gv and _f_gplain(g) <= tv:
                    out.append((g, gv))
    return out


def _f_same_obj(g, c):
    """does the given g state the very quantity the find target c asks?"""
    q = str(c.get("quantity") or "")
    k = FIND_QUANTITIES.get(q, "any")
    tg = f_key(c)[2]
    t = g.get("type")
    if k == "segment":
        return t in ("length", "distance") and seg(g.get("of")) == tg
    if k == "angle":
        return t == "angle" and (
            ang({"at": g.get("at"), "rays": g.get("rays")}) == tg
            if g.get("at") else ang(g.get("of")) == tg)
    if k == "polygon":
        return t == q and tuple(sorted(tk(g.get("of") or
                                          g.get("points")))) == tg
    if k == "point":
        return t in ("coordinates", "point") and \
            g.get("value") is not None and \
            str(g.get("point") or g.get("of")) == str(tg)
    if k == "variable":
        return t in ("variable", "value") and g.get("value") is not None \
            and str(g.get("of")) == str(tg)
    return False


_F_REL_META = ("id", "role", "objects", "measured", "highlight", "marked",
               "mark_id", "mark_ids", "item", "from_item", "status",
               "violated", "note", "svg_id", "display")


def _f_is(r, g):
    """is the model relation / constraint r the claim g (a given, a
    to_prove, a to_construct) -- its own relation?"""
    if not isinstance(g, dict):
        return False
    if not g.get("type") or r.get("type") == "statement":
        return bool(g.get("text")) and norm(r.get("text")) == \
            norm(g.get("text")) and (not g.get("type") or
                                    r.get("type") == g.get("type"))
    rr = dict((k, v) for k, v in r.items() if k not in _F_REL_META)
    gg = dict((k, v) for k, v in g.items() if k not in _F_REL_META)
    return key(rr) == key(gg)


def _f_owns(o, g, pts):
    """is the model object o the stated given g's own object?"""
    t = g.get("type")
    fo = o.get("for")
    nm = o.get("name")
    if o.get("type") in ("label", "dimension"):
        if fo:
            if t in ("length", "distance"):
                return len(tk(fo)) == 2 and seg(fo) == seg(g.get("of"))
            if t == "angle":
                ga = ang({"at": g.get("at"), "rays": g.get("rays")}) \
                    if g.get("at") else ang(g.get("of"))
                # (v6.10 fix r1, s2) a degree value names the ARC it sits
                # in ('arc-A', 'arc-A-2'): the angle at that vertex
                ma = re.match(r"^arc-([A-Z][0-9]*'*)(?:-\d+)?$", str(fo))
                return (len(tk(fo)) == 3 and ang(fo) == ga) or \
                    str(fo) == str(g.get("at")) or \
                    bool(ma and ma.group(1) == str(g.get("at")))
            gn = names(g)
            return bool(gn) and set(tk(fo)) <= gn
        if t == "angle":
            if _f_given_owner(o.get("xy"), o.get("text"), [g], pts) \
                    is not None:
                return True
            # shapekit's callout of a given angle: 20deg past its arm, and
            # nearer its vertex than any other point of the figure
            xy = o.get("xy")
            if not (isinstance(xy, list) and len(xy) >= 2 and pts):
                return False
            near = min(pts, key=lambda n: math.hypot(
                xy[0] - pts[n][0], xy[1] - pts[n][1]))
            return near == str(g.get("at") or (tk(g.get("of")) or
                                               [None, None])[1])
        return False
    gn = names(g)
    return bool(nm) and bool(gn) and set(tk(nm)) <= gn


def _f_leaves(o, path=""):
    """_leaves without the keys that only reference other objects."""
    for p, k, v in _leaves(o, path):
        segs = set(re.sub(r"\[\d+\]", "", x) for x in p.split("."))
        if segs & _F_REFKEYS:
            continue
        yield p, k, v


def _source_old_height_given(public_spec, qid, rid, given_scope, c, g):
    """An exact head-height claim of a verified, genuinely moved ladder.

    Local/later givens and every other same-object overlap remain errors.
    This reads only independently validated public source data, never the
    author's unsupported flag, private answer, or display placement.
    """
    if given_scope != qid or c.get("type") != "find" or c.get("quantity") != "length":
        return False
    if not isinstance(public_spec, dict):
        return False
    try:
        from wspec.check.figure_state import obsolete_height
        from wspec import canon as WC
        facts = {f["id"]: f for f in public_spec.get("facts") or []}
        ents = {e["id"]: e for e in public_spec.get("entities") or []}
        for fig in public_spec.get("figures") or []:
            if fig.get("scope") != rid or "state_change" not in fig:
                continue
            excluded = obsolete_height(public_spec, fig)
            declaration = fig["state_change"]
            target = facts[declaration["height_target"]]
            old = facts[declaration["old_height"]]
            if (old["id"] not in excluded or old.get("item") != qid
                    or target.get("item") != rid or g.get("type") != "length"):
                continue
            ends = ents[old["args"][0]]["ends"]
            if (seg(c.get("of")) == seg(ends) == seg(g.get("of"))
                    and WC.same_quantity(g.get("value"), g.get("unit"), old["value"], old.get("unit"))):
                return True
    except Exception:
        return False  # a malformed/unavailable contract cannot suppress a finding
    return False


def _native_initial_length_given(figure, given):
    """One exact visible initial native length, never a scalar allow-list.

    This deliberately supports only the native segment-length path. Existing
    SVG/legacy/VM ownership checks must establish the actual printed label;
    a marked given relation and constraint must bind that same label/value.
    No free caption, aux object, absent ink or merely equal number qualifies.
    """
    try:
        vm = figure.get("visual_model") or {}
        qid = figure.get("question")
        if (not qid or vm.get("question") != qid
                or figure.get("item") not in (None, qid)
                or vm.get("item") not in (None, qid)
                or vm.get("kind") not in ("plane_geometry", "construction")
                or given.get("type") != "length" or given.get("from_item")):
            return False
        if set(given) - {"type", "of", "value", "unit", "text"}:
            return False  # an arbitrary extra payload is not the printed fact
        value = float(given.get("value"))
        if not math.isfinite(value) or value <= 0 or isinstance(given.get("value"), bool):
            return False
        if given.get("text") and norm(given["text"]) != norm(
                "%s=%g" % (given.get("of"), value)):
            return False
        side = seg(given.get("of"))
        objects = {o.get("id"): o for o in vm.get("objects") or []
                   if isinstance(o, dict)}
        printed = _NATIVE_PRINTED_LENGTH_LABELS.get(figure.get("id"), {})
        for oid, text in printed.items():
            label = objects.get(oid) or {}
            if (label.get("role") != "given" or label.get("display") != "initial"
                    or label.get("type") != "label" or float(text) != value):
                continue
            owner = [o for o in objects.values() if o.get("type") == "segment"
                     and (o.get("id") == label.get("for")
                          or o.get("name") == label.get("for"))]
            if len(owner) != 1:
                continue
            owner = owner[0]
            if (owner.get("display") != "initial" or owner.get("role") != "given"
                    or seg(owner.get("name")) != side):
                continue
            ends = owner.get("xy") or []
            if (len(ends) != 2 or len(ends[0]) != 2 or len(ends[1]) != 2
                    or not math.isclose(math.dist(ends[0], ends[1]), value,
                                        rel_tol=1e-8, abs_tol=1e-8)):
                continue
            # A relabelled equal-length edge must not inherit somebody else's
            # printed dimension: the owning edge must be nearest to its ink.
            anchor = label.get("svg_xy")
            def distance(edge):
                a, b = edge.get("svg_xy") or ((), ())
                if not anchor or len(a) != 2 or len(b) != 2:
                    return float("inf")
                dx, dy = b[0]-a[0], b[1]-a[1]
                den = dx*dx+dy*dy
                t = max(0., min(1., ((anchor[0]-a[0])*dx+
                                     (anchor[1]-a[1])*dy)/den)) if den else 0.
                return math.dist(anchor, (a[0]+t*dx, a[1]+t*dy))
            own_distance = distance(owner)
            if not math.isfinite(own_distance) or any(
                    distance(o)+0.5 < own_distance for o in objects.values()
                    if o.get("type") == "segment" and o.get("display") == "initial"):
                continue
            sid = label.get("svg_id")
            constraints = [c for c in figure.get("constraints") or []
                           if c.get("status") == "given" and c.get("marked")
                           and c.get("mark_id") == sid and _f_is(c, given)]
            relations = [r for r in vm.get("relations") or []
                         if r.get("role") == "given" and r.get("marked")
                         and r.get("mark_id") == sid and _f_is(r, given)
                         and owner.get("id") in (r.get("objects") or [])
                         and r.get("unit") == given.get("unit")]
            # The new printed-fact exemption may skip only proved native
            # references, not arbitrary strings in a reference-shaped list.
            # Fail closed for unsupported/extra/mismatched mark or owner IDs.
            # No legacy generic metadata parser or global leaf scan changes.
            if not constraints or not relations:
                continue
            points = [o for o in objects.values()
                      if o.get("type") == "point"
                      and o.get("name") in side]
            if (len(points) != 2 or {o.get("name") for o in points} != set(side)
                    or any(o.get("display") != "initial"
                           or o.get("role") != "given" for o in points)):
                continue
            expected_objects = {owner.get("id")} | {o.get("id") for o in points}
            def exact_mark_refs(row):
                return (row.get("mark_id") == sid
                        and row.get("mark_ids") == [sid])
            def exact_relation_refs(row):
                refs = row.get("objects")
                highlight = objects.get(row.get("highlight")) or {}
                return (exact_mark_refs(row) and isinstance(refs, list)
                        and len(refs) == 3 and all(isinstance(x, str) for x in refs)
                        and set(refs) == expected_objects
                        and isinstance(row.get("id"), str)
                        and highlight.get("type") == "overlay_mark"
                        and highlight.get("for") == row["id"]
                        and highlight.get("role") == "given"
                        and highlight.get("display") == "given_highlight"
                        and highlight.get("mark") == "length"
                        and highlight.get("on") == [owner.get("id")]
                        and highlight.get("value") == given.get("value"))
            # Validate every representation of this fact, including an
            # unmarked typed constraint. Its reference-free declaration may
            # not acquire a hidden mark_ids/objects/highlight payload.
            fact_constraints = [c for c in figure.get("constraints") or []
                                if _f_is(c, given)]
            fact_relations = [r for r in vm.get("relations") or []
                              if _f_is(r, given)]
            def exact_constraint_refs(row):
                if any(k in row for k in ("objects", "highlight", "on", "for")):
                    return False
                if row.get("marked"):
                    return exact_mark_refs(row)
                return not any(k in row for k in ("mark_id", "mark_ids"))
            if (all(exact_constraint_refs(c) for c in fact_constraints)
                    and all(exact_relation_refs(r) for r in fact_relations)):
                return True
    except (TypeError, ValueError, KeyError, IndexError, OverflowError):
        return False
    return False


def _native_linked_scope(own, figure_id, source_qid):
    """Conservative existing cross-question dependency policy, kept intact."""
    return (any(row.get("figure_id") == figure_id for row in
                [own] + list(own.get("items") or []))
            or any(str(g.get("from_item") or "").startswith(str(source_qid))
                   for row in [own] + list(own.get("items") or [])
                   for g in row.get("given") or [] if isinstance(g, dict))
            or bool(re.search(r"שאלה|שאלות|question", _f_qtext(own), re.I)))


def f_file(nj, qid, rid, c, val, tobj, public_spec=None):
    """v6.7.3: the find target's value anywhere in the whole noam-ai.json
    that no stated given of its question carries on its own object."""
    atoms = f_atoms(val)
    if not atoms:
        return []
    out = []
    qs = dict((q.get("id"), q) for q in nj.get("questions") or [])
    own = qs.get(qid) or {}
    SH = dict((x, _f_shown(nj, x)) for x in qs)
    def native_given(q, given, figure_id=None):
        # Scope and exact quantity remain attached. Same-object targets and
        # cross-question dependencies retain all existing leak findings.
        if q.get("id") == qid and _f_same_obj(given, c):
            return False
        return any(f.get("question") == q.get("id")
                   and (figure_id is None or f.get("id") == figure_id)
                   and (q.get("id") == qid or not _native_linked_scope(
                       own, f.get("id"), q.get("id")))
                   and _native_initial_length_given(f, given)
                   for f in nj.get("figures") or [])
    # r1 M4: a length target's value printed in another unit
    cq = str(c.get("quantity") or "")
    cv = cq in ("length", "distance", "perimeter") or \
        FIND_QUANTITIES.get(cq) == "segment"

    def hit(x):
        return f_hit(atoms, x, cv, c.get("unit"))

    def say(where, what):
        out.append("noam-ai.json prints the find target's value at %s (%r)"
                   " -- %s" % (where.lstrip("."), str(what)[:40],
                               "no stated given of the question carries it "
                               "there" if where else ""))
    # givens: a JSON-only given carrying the value; a given of the item /
    # question that states the very quantity asked (the section 2 overlap)
    for q in nj.get("questions") or []:
        tv = fvals(_f_qtext(q)) | SH.get(q.get("id"), set())
        for r in [q] + list(q.get("items") or []):
            for i, g in enumerate(r.get("given") or []):
                if not isinstance(g, dict) or g.get("from_item"):
                    continue
                gv = _f_gvals(g)
                where = "%s.given[%d]" % (r.get("id"), i)
                if q is own and r.get("id") in (qid, rid) and \
                        _f_same_obj(g, c) and not _source_old_height_given(
                            public_spec, qid, rid, r.get("id"), c, g):
                    out.append("%s %r states the quantity the item asks to "
                               "find -- a given and a find target at once "
                               "(section 2 overlap)" % (where, c_txt(g)))
                elif f_hit(atoms, " ".join(sorted(gv))) and \
                        not native_given(q, g) and \
                        not _f_gplain(g) <= _f_abs(tv) | _f_plain(
                            _f_qtext(q)):
                    out.append("%s %r is a JSON-only given (the text does "
                               "not state it) carrying the find target's "
                               "value -- also a section 2 given / to_find "
                               "overlap" % (where, c_txt(g)))
    # r1 M1 M2 S2: the find target's OWN question's words -- its text,
    # intro, every item's text / intro, its printed table (head, rows,
    # caption, title, ...) -- print the value only where a stated given of
    # the question carries that number (the rule the figure objects obey)
    ostated = _f_stated(own, SH.get(qid, set())) if own else []

    # numbers the question's own figures print as its scale (axis ticks)
    # or its chart data: 'ביום 4' names a tick, it states no answer
    oscale = set(SH.get(qid, set()))
    for f in list(nj.get("figures") or []) + list(nj.get("visuals") or []):
        vm = f.get("visual_model") if "visual_model" in f else f
        if isinstance(vm, dict) and vm.get("kind") in _F_AXIS_KINDS and (
                f.get("question") or vm.get("question")) == qid:
            for o in vm.get("objects") or []:
                if isinstance(o, dict) and o.get("type") in (
                        "label", "tick") and \
                        _F_TICK_ID.match(str(o.get("id"))):
                    oscale |= fvals(o.get("text"))

    def words_backed(x):
        hv = fvals(x)
        if f_hit(atoms, " ".join(sorted(hv & oscale))):
            return True
        return any(f_hit(atoms, " ".join(sorted(gv & hv))) and
                   not _f_same_obj(g, c) for g, gv in ostated)
    # a LATER item may build on this item's result ('גדול מ-2000 מטר'):
    # the author confirms it (REVIEW); the question's words, the table and
    # every earlier item FAIL
    oits = [str(it.get("id")) for it in own.get("items") or []]
    later = set(oits[oits.index(rid) + 1:]) if rid in oits else set()
    ocell = {}
    for f in list(nj.get("figures") or []) + list(nj.get("visuals") or []):
        vm = f.get("visual_model") if "visual_model" in f else f
        if isinstance(vm, dict) and vm.get("kind") == "table" and (
                f.get("question") or vm.get("question")) == qid:
            for o in vm.get("objects") or []:
                if isinstance(o, dict) and o.get("type") == "cell":
                    ocell[(o.get("row"), o.get("col"))] = o
    wl = []
    for r in [own] + list(own.get("items") or []):
        for k in ("text", "intro", "caption", "title", "note"):
            if isinstance(r.get(k), str):
                wl.append((".%s.%s" % (r.get("id"), k), r.get(k)))
    for p, x in wl:
        if hit(x) and not words_backed(x):
            if p.split(".")[1] in later:
                out.append("REVIEW:the later item %s prints the find "
                           "target's value (%r) -- it builds on this "
                           "item's result; confirm it gives no answer "
                           "away" % (p.lstrip(".").split(".")[0],
                                     str(x)[:40]))
            else:
                say(p, x)
    otb = own.get("table")
    if isinstance(otb, dict):
        for k, v in otb.items():
            if k in ("head", "rows"):
                continue
            for p, _k, x in _leaves({k: v}, ".%s.table" % qid):
                if hit(x) and not words_backed(x):
                    say(p, x)
        for (ri, ci), x in sorted(_f_table(own).items()):
            if not hit(x):
                continue
            o = ocell.get((ri, ci))
            if o is not None and o.get("role") == "given" and \
                    hit(o.get("value")) and \
                    fvals(x) <= fvals(o.get("value")):
                continue                 # a given cell of the table
            if words_backed(x):
                continue
            say(".%s.table[r%dc%d]" % (qid, ri, ci), x)
    # other questions' rows: a free field printing the value its own
    # question's words do not
    for q in nj.get("questions") or []:
        if q is own:
            continue
        tv = fvals(_f_qtext(q)) | SH.get(q.get("id"), set())
        for r in [q] + list(q.get("items") or []):
            for k, v in r.items():
                if k in ("text", "intro", "label", "given", "items",
                         "figure_id", "id", "to_construct", "to_prove",
                         "table", "n", "example"):
                    # v6.12 fix_r1: "example" is printed (in _f_qtext)
                    continue
                for p, _k, x in _leaves({k: v}, "." + str(r.get("id"))):
                    if hit(x) and not f_hit(
                            atoms, " ".join(sorted(fvals(x) & tv))):
                        say(p, x)
    # every figure / visual of every question
    for f in list(nj.get("figures") or []) + list(nj.get("visuals") or []):
        vm = f.get("visual_model") if "visual_model" in f else f
        fq = f.get("question") or (vm or {}).get("question")
        q = qs.get(fq) or {}
        stated = _f_stated(q, SH.get(fq, set())) if q else []
        tv = (fvals(_f_qtext(q)) | SH.get(fq, set())) if q else set()
        fid = str(f.get("id"))
        native_stated = [(g, _f_gvals(g)) for row in
                         [q] + list(q.get("items") or [])
                         for g in row.get("given") or [] if isinstance(g, dict)
                         and native_given(q, g, fid)]
        for k, v in f.items():
            if k in ("objects", "constraints", "given_marks", "visual_model",
                     "relations", "aux", "actions", "highlight_given",
                     "view", "svg", "id", "question", "item", "kind",
                     "schema_version", "visual_support", "reveal", "step"):
                continue
            for p, _k, x in _leaves({k: v}, "." + fid):
                if hit(x):
                    say(p, x)
        if not isinstance(vm, dict):
            continue

        def sbacked(x):
            hv = fvals(x)
            return any(f_hit(atoms, " ".join(sorted(gv & hv))) and
                       not _f_same_obj(g, c) for g, gv in stated)
        # r1 S2: the model's own free fields (caption, title, ...)
        if vm is not f:
            for k, v in vm.items():
                if k in _F_VM_SKIP:
                    continue
                for p, _k, x in _leaves({k: v}, ".%s" % vm.get("id")):
                    if hit(x) and not sbacked(x):
                        say(p, x)
        act = vm.get("actions")
        if isinstance(act, dict):
            for k, v in act.items():
                if k in ("allowed", "show", "highlight", "show_aux"):
                    continue             # id lists
                for p, _k, x in _leaves({k: v}, ".%s.actions" %
                                        vm.get("id")):
                    if hit(x) and not sbacked(x):
                        say(p, x)
        def native_payload_leaves(obj, prefix, enabled, category, strict_native):
            """Local structural ancestry for the new native exemption only.

            Direct native geometry/reference fields retain their ordinary
            skips. Unknown nested payloads are scanned at every depth, even
            if their keys imitate value/text/on/for/id. No serialized object
            ID or scalar identity can establish that a leaf is direct.
            The legacy global _f_leaves behavior is not changed.
            """
            if not enabled:
                for path, key, value in _f_leaves(obj, prefix):
                    yield path, key, value, False
                return
            if not strict_native:
                # Generic native dimension/label support predates this change.
                # Preserve its legacy raw metadata filters; add only actual
                # structural directness, never schema-gate unrelated models.
                def legacy_walk(node, path, root=False):
                    if isinstance(node, dict):
                        for key, value in node.items():
                            if key in _F_GEOM:
                                continue
                            child_path = "%s.%s" % (path, key)
                            if isinstance(value, (dict, list)):
                                yield from legacy_walk(value, child_path)
                            elif value is not None and not isinstance(value, bool):
                                segs = set(re.sub(r"\[\d+\]", "", x) for x in child_path.split("."))
                                if not segs & _F_REFKEYS:
                                    yield child_path, key, value, root
                    elif isinstance(node, list):
                        for index, value in enumerate(node):
                            child_path = "%s[%d]" % (path, index)
                            if isinstance(value, (dict, list)):
                                yield from legacy_walk(value, child_path)
                            elif value is not None and not isinstance(value, bool):
                                segs = set(re.sub(r"\[\d+\]", "", x) for x in child_path.split("."))
                                if not segs & _F_REFKEYS:
                                    yield child_path, "", value, False
                yield from legacy_walk(obj, prefix, True)
                return
            # The exemption recognizes only this native schema, not any
            # arbitrary container whose spelling resembles a metadata key.
            if category == "relation":
                known = {"id", "type", "role", "of", "value", "unit", "text",
                         "objects", "measured", "marked", "mark_id", "mark_ids", "highlight"}
            elif category == "constraint":
                known = {"id", "type", "of", "value", "unit", "marked",
                         "mark_id", "mark_ids", "status"}
            else:
                known = {"id", "svg_id", "type", "part", "name", "role", "display"}
                if obj.get("type") in ("point", "segment", "polygon", "label"):
                    known |= {"xy", "svg_xy"}
                if obj.get("type") == "label":
                    known |= {"text", "bbox", "for"}
                if obj.get("type") == "overlay_mark":
                    known |= {"for", "value", "mark", "on"}
            def number(v):
                return (isinstance(v, (int, float)) and not isinstance(v, bool)
                        and math.isfinite(v))
            def coordinate(key, value):
                if not isinstance(value, list):
                    return False
                if key == "bbox":
                    return len(value) == 4 and all(number(v) for v in value)
                if obj.get("type") in ("label", "point"):
                    return len(value) == 2 and all(number(v) for v in value)
                if obj.get("type") == "segment" and len(value) != 2:
                    return False
                if obj.get("type") == "polygon" and len(value) < 3:
                    return False
                return all(isinstance(p, list) and len(p) == 2
                           and all(number(v) for v in p) for p in value)
            def supported_field(key, value):
                if key not in known:
                    return False
                if key in {"xy", "svg_xy", "bbox"}:
                    return coordinate(key, value)
                if key in {"objects", "mark_ids", "on"}:
                    return isinstance(value, list) and all(isinstance(v, str) for v in value)
                if key == "of" and isinstance(value, list):
                    return all(isinstance(v, str) for v in value)
                return not isinstance(value, (dict, list))
            def supported_reference(key, value):
                # Only this new strict-native context requires actual local
                # reference resolution. Never change the legacy generic path.
                if key not in {"objects", "mark_id", "mark_ids", "highlight", "on", "for"}:
                    return True
                obs = [o for o in vm.get("objects") or [] if isinstance(o, dict)]
                byid = {o.get("id"): o for o in obs}
                if len(byid) != len(obs):
                    return False
                def segment(name):
                    found = [o for o in obs if o.get("type") == "segment"
                             and (o.get("id") == name or seg(o.get("name")) == seg(name))
                             and o.get("role") == "given" and o.get("display") == "initial"]
                    return found[0] if len(found) == 1 else None
                def length_label(ref):
                    if obj.get("type") != "length" or not obj.get("marked"):
                        return False
                    edge = segment(obj.get("of"))
                    lbs = [o for o in obs if o.get("type") == "label"
                           and o.get("svg_id") == ref
                           and o.get("role") == "given" and o.get("display") == "initial"
                           and _NATIVE_PRINTED_LENGTH_LABELS.get(fid, {}).get(o.get("id")) == o.get("text")]
                    if edge is None or len(lbs) != 1:
                        return False
                    lb = lbs[0]
                    try:
                        return (lb.get("for") in (edge.get("id"), edge.get("name"))
                                and float(lb.get("text")) == float(obj.get("value")))
                    except (TypeError, ValueError, OverflowError):
                        return False
                if key in {"mark_id", "mark_ids"}:
                    refs = [value] if key == "mark_id" else value
                    return (isinstance(refs, list) and len(refs) == 1
                            and isinstance(refs[0], str) and length_label(refs[0]))
                if key == "objects":
                    if category != "relation" or obj.get("type") not in ("length", "parallel", "perpendicular"):
                        return False
                    names = [obj.get("of")] if obj.get("type") == "length" else obj.get("of")
                    if not isinstance(names, list) or not names or not all(isinstance(v, str) for v in names):
                        return False
                    edges = [segment(name) for name in names]
                    if any(e is None for e in edges):
                        return False
                    expected = {e.get("id") for e in edges}
                    for point in set(tk(names)):
                        found = [o for o in obs if o.get("type") == "point" and o.get("name") == point
                                 and o.get("role") == "given" and o.get("display") == "initial"]
                        if len(found) != 1:
                            return False
                        expected.add(found[0].get("id"))
                    return (isinstance(value, list) and len(value) == len(expected)
                            and all(isinstance(v, str) for v in value) and set(value) == expected)
                if key == "highlight":
                    edge = segment(obj.get("of"))
                    mark = byid.get(value) if isinstance(value, str) else None
                    return (category == "relation" and obj.get("type") == "length"
                            and edge is not None and isinstance(mark, dict)
                            and mark.get("type") == "overlay_mark" and mark.get("mark") == "length"
                            and mark.get("for") == obj.get("id") and mark.get("on") == [edge.get("id")]
                            and mark.get("value") == obj.get("value")
                            and mark.get("role") == "given" and mark.get("display") == "given_highlight")
                if obj.get("type") == "label" and key == "for":
                    return isinstance(value, str) and segment(value) is not None
                if obj.get("type") == "overlay_mark":
                    matches = [r for r in vm.get("relations") or []
                               if r.get("id") == obj.get("for") and r.get("type") == "length"]
                    if len(matches) != 1:
                        return False
                    relation = matches[0]; edge = segment(relation.get("of"))
                    if (edge is None or relation.get("highlight") != obj.get("id")
                            or obj.get("mark") != "length" or obj.get("value") != relation.get("value")):
                        return False
                    return ((key == "for" and value == relation.get("id"))
                            or (key == "on" and value == [edge.get("id")]))
                return False
            supported = all(supported_field(k, v) and supported_reference(k, v)
                            for k, v in obj.items())
            def walk(node, path, root=False):
                if isinstance(node, dict):
                    for key, value in node.items():
                        # Only an actual direct reference/geometry payload
                        # shape inherits its legacy skip. A mapping/list of
                        # mappings cannot hide arbitrary leaves by naming its
                        # container id/on/for/xy/view instead.
                        if (root and key in known and supported_field(key, value)
                                and supported_reference(key, value) and key in _F_REFKEYS):
                            if (value is None or isinstance(value, (str, bool))
                                    or (isinstance(value, list)
                                        and all(isinstance(v, str) for v in value))):
                                continue
                        if (root and key in known and key in _F_GEOM
                                and supported_field(key, value)):
                            continue
                        child_path = "%s.%s" % (path, key)
                        if isinstance(value, (dict, list)):
                            yield from walk(value, child_path)
                        elif value is not None and not isinstance(value, bool):
                            yield child_path, key, value, root and supported
                elif isinstance(node, list):
                    for index, value in enumerate(node):
                        child_path = "%s[%d]" % (path, index)
                        if isinstance(value, (dict, list)):
                            yield from walk(value, child_path)
                        elif value is not None and not isinstance(value, bool):
                            yield child_path, "", value, False
            yield from walk(obj, prefix, True)

        def native_value(x, g):
            try:
                return (not isinstance(x, bool) and math.isfinite(float(x))
                        and float(x) == float(g.get("value")))
            except (TypeError, ValueError, OverflowError):
                return False

        def native_fact_payload(obj, field, x, g, direct):
            # Only the canonical fact payload is public. A note/answer/extra
            # field on the same relation must retain the ordinary leak scan.
            return (direct and _f_is(obj, g) and (
                (field == "value" and native_value(x, g))
                or (field == "text" and norm(x) == norm(
                    "%s=%g" % (g.get("of"), float(g.get("value")))))))

        def backed(obj, x, field, direct):
            hv = fvals(x)
            return any(_f_is(obj, g) and
                       f_hit(atoms, " ".join(sorted(gv & hv)))
                       for g, gv in stated) or any(
                           native_fact_payload(obj, field, x, g, direct)
                           for g, _gv in native_stated)

        def native_object_payload(obj, field, x, direct):
            if not direct:
                return False
            for g, _gv in native_stated:
                if (obj.get("type") == "label" and field == "text"
                        and obj.get("role") == "given"
                        and obj.get("display") == "initial"
                        and _NATIVE_PRINTED_LENGTH_LABELS.get(fid, {}).get(
                            obj.get("id")) == x and native_value(x, g)
                        and _f_owns(obj, g, pts)):
                    return True
                relation = rels.get(str(obj.get("for"))) or {}
                if (obj.get("type") == "overlay_mark" and field == "value"
                        and obj.get("role") == "given"
                        and obj.get("display") == "given_highlight"
                        and obj.get("mark") == "length"
                        and relation.get("highlight") == obj.get("id")
                        and obj.get("on") == [o.get("id") for o in vm.get("objects") or []
                            if o.get("type") == "segment"
                            and seg(o.get("name")) == seg(g.get("of"))]
                        and _f_is(relation, g) and native_value(x, g)):
                    return True
            return False

        def claimed(obj, x):
            # a to_prove / to_construct claim of the question whose number
            # the author's words print
            if not f_hit(atoms, " ".join(sorted(fvals(x) & tv))):
                return False
            for r in [q] + list(q.get("items") or []):
                # a given carried from_item is an earlier item's claim
                for t in list(r.get("to_prove") or []) + list(
                        r.get("to_construct") or []) + [
                        g for g in r.get("given") or []
                        if isinstance(g, dict) and g.get("from_item")]:
                    if isinstance(t, dict) and t.get("type") != "find" and \
                            _f_is(obj, t):
                        return True
            return False
        def geom_t(obj, k, x):
            # an on_segment's parameter t in [0, 1] is exact geometry
            # (like xy), never a printed number
            return k == "t" and obj.get("type") == "on_segment" and \
                isinstance(x, (int, float)) and 0 <= x <= 1
        for i, r in enumerate(vm.get("relations") or []):
            if r.get("type") == "find":
                continue                 # f_shape / f_leaks read it
            for p, _k, x, direct in native_payload_leaves(
                    r, ".%s.relations[%d]" % (vm.get("id"), i), bool(native_stated), "relation", bool(native_stated)):
                if hit(x) and not geom_t(r, _k, x) and not (
                        backed(r, x, _k, direct) or
                        ((r.get("role") in ("to_prove", "to_construct") or
                          r.get("from_item")) and claimed(r, x))):
                    say(p, x)
        for i, fc in enumerate(f.get("constraints") or []):
            for p, _k, x, direct in native_payload_leaves(
                    fc, ".%s.constraints[%d]" % (fid, i), bool(native_stated), "constraint", bool(native_stated)):
                if hit(x) and not geom_t(fc, _k, x) and not (
                        backed(fc, x, _k, direct) or
                        (fc.get("status") in ("to_prove", "to_construct")
                         and claimed(fc, x))):
                    say(p, x)
        rels = dict((str(r.get("id")), r) for r in vm.get("relations") or [])
        kind = vm.get("kind")
        data = kind in _F_DATA_KINDS and kind != "table"
        axes = kind in _F_AXIS_KINDS
        cells = _f_table(q) if q else {}
        pts = {}
        for o in vm.get("objects") or []:
            xy = o.get("xy")
            if o.get("type") == "point" and o.get("name") and \
                    isinstance(xy, list) and len(xy) >= 2 and \
                    not isinstance(xy[0], list):
                pts[str(o["name"])] = xy[:2]
        # r1 S2 m1: aux patches (the model's and the figure's) and a
        # malformed highlight_given entry are read like objects
        objs = [o for o in vm.get("objects") or [] if isinstance(o, dict)]
        objs += [o for o in vm.get("aux") or [] if isinstance(o, dict)]
        if vm is not f:
            objs += [o for o in f.get("aux") or [] if isinstance(o, dict)]
        objs += [o for o in vm.get("highlight_given") or []
                 if isinstance(o, dict)]
        for o in objs:
            if id(o) in tobj:
                continue                     # f_objs reads the target
            oid = str(o.get("id"))
            if axes and o.get("type") in ("label", "tick") and \
                    _F_TICK_ID.match(oid):
                continue                     # the axis's own scale
            for p, k, x, direct in native_payload_leaves(
                    o, ".%s.%s" % (vm.get("id"), oid),
                    bool(native_stated) or oid in _NATIVE_PRINTED_LABELS.get(fid, {}), "object",
                    bool(native_stated)):
                if not hit(x):
                    continue
                # Distinct questions are distinct semantic scopes. An exact
                # native-owned label already printed in another question is
                # not this target's answer merely because a scalar agrees.
                # Keep all same-question checks and every unprinted/JSON-only
                # field; this does not add the label's numbers to SH/stated.
                linked_scope = (any(row.get("figure_id") == fid for row in
                                    [own] + list(own.get("items") or []))
                    or any(str(g.get("from_item") or "").startswith(str(fq))
                           for row in [own] + list(own.get("items") or [])
                           for g in row.get("given") or [] if isinstance(g, dict))
                    or bool(re.search(r"שאלה|שאלות|question", _f_qtext(own), re.I)))
                if (direct and fq != qid and not linked_scope and k == "text"
                        and _NATIVE_PRINTED_LABELS.get(fid, {}).get(oid) == x):
                    continue
                if o.get("type") == "cell":
                    rc = (o.get("row"), o.get("col"))
                    st = cells.get(rc)
                    if st is not None and f_hit(atoms, st) and \
                            fvals(x) <= fvals(st):
                        continue             # the printed table's own cell
                    say(p, x)
                    continue
                if data and k in ("value", "angle", "frequency", "y", "x") \
                        and isinstance(x, (int, float)):
                    continue                 # chart data is the model
                if data and k in ("text", "label") and fvals(x) <= fvals(
                        o.get("value")):
                    continue                 # a data point's printed value
                if any(f_hit(atoms, " ".join(sorted(gv & fvals(x)))) and
                       (_f_owns(o, g, pts) or (
                           str(o.get("for")) in rels and
                           _f_is(rels[str(o.get("for"))], g)))
                       for g, gv in stated):
                    continue                 # a stated given on its object
                if native_object_payload(o, k, x, direct):
                    continue                 # exact native fact payload only
                say(p, x)
        # r1 M5: the value split over two number labels -- side by side
        # ('6' '.4') or stacked as a fraction ('3' over '5')
        for p, x in _f_split(f, vm, objs, axes, tobj):
            if hit(x) and not sbacked(x):
                say(p, x)
    return out


_F_VM_SKIP = frozenset(("objects", "constraints", "given_marks", "relations",
                        "aux", "actions", "highlight_given", "view", "svg",
                        "id", "question", "item", "kind", "schema_version",
                        "visual_support", "reveal", "step", "data",
                        "axes", "grid", "items"))
_F_NUMTXT = re.compile(u"^\\s*-?(?:\\d+(?:[.,]\\d*)?|[.,]\\d+)\\s*$")


def _f_split(f, vm, objs, axes, tobj):
    """[(where, joined text)]: two number labels printed as one number --
    side by side on one baseline, or one above the other (a fraction)."""
    t = ((f.get("view") or {}).get("data_to_svg") or
         (vm.get("view") or {}).get("data_to_svg"))
    nl = []
    for o in objs:
        if id(o) in tobj or o.get("type") not in ("label", "dimension",
                                                  "text", "note"):
            continue
        if axes and _F_TICK_ID.match(str(o.get("id"))):
            continue
        s = str(o.get("text") if o.get("text") is not None else "")
        if not _F_NUMTXT.match(s):
            continue
        xy = o.get("svg_xy")
        if not (isinstance(xy, list) and len(xy) >= 2):
            d = o.get("xy")
            if not (t and isinstance(d, list) and len(d) >= 2 and
                    not isinstance(d[0], list)):
                continue
            xy = [t[0] * d[0] + t[2] * d[1] + t[4],
                  t[1] * d[0] + t[3] * d[1] + t[5]]
        nl.append((o, s.strip(), float(xy[0]), float(xy[1])))
    out = []
    for a in nl:
        for b in nl:
            if a is b:
                continue
            dx, dy = b[2] - a[2], b[3] - a[3]
            if abs(dy) <= 4 and 0 < dx <= 24:
                j = a[1] + b[1]
            elif abs(dx) <= 6 and 0 < dy <= 28:
                j = a[1] + "/" + b[1]
            else:
                continue
            out.append((".%s.%s+%s" % (vm.get("id"), a[0].get("id"),
                                       b[0].get("id")), j))
    return out



def f_svg(svg, F, c, val, given, ctx=""):
    """r1 T7: the starting figure's SVG itself prints the value of a
    geometric find target (a <text> the JSON does not list)."""
    k = FIND_QUANTITIES.get(str(c.get("quantity") or ""), "any")
    if val is None or not svg:
        return []
    geo = k in ("angle", "segment", "polygon") or (
        (F.get("visual_model") or {}).get("kind") in (
            "plane_geometry", "construction", "solid_3d", "projection_2d"))
    atoms = f_atoms(val)
    if not atoms:
        return []
    gv = set()
    for g in given:
        gv |= fvals(g.get("value") if g.get("value") is not None
                    else "") | fvals(g.get("text"))
    gv |= fvals(ctx)
    if f_hit(atoms, " ".join(sorted(gv))):
        return []          # a given / the text prints the same number
    axes = (F.get("visual_model") or {}).get("kind") in _F_AXIS_KINDS
    out = []
    for attrs, raw in _SVGTXT_ID.findall(svg):
        t = re.sub(r"<[^>]+>", "", raw).strip()
        # an axis / number-line tick is a bare number: it counts only in a
        # figure with no axes
        bare = not re.sub(u"[-\u2212\\d.,\\s]", "", t)
        # v6.7.2 final: a bare tick number on an axis (lbl-x8, lbl-ym3,
        # lbl-4 on a number line) is the axis's own scale, never the answer
        # printed on the target's object, even for a geometric target.
        mi = re.search(r'\bid="([^"]*)"', attrs)
        # v6.13 fix_r2: an ENGINE plane / number line marks its axis numbers
        # with the hook data-num="x 3" / "origin" (wspec-coord-svg/1), not
        # with an lbl- id -- the same bare tick number
        tick = bool(bare and axes and (
            (mi and _F_TICK_ID.match(mi.group(1))) or
            re.search(r'\bdata-num="(?:[xy] \d+|origin)"', attrs)))
        if f_hit(atoms, t) and (geo or not bare) and not tick:
            out.append(t)
    return out


def f_marks(F, c, gkeys):
    """marked constraints of F that state or equate the target's value."""
    k = FIND_QUANTITIES.get(str(c.get("quantity") or ""), "any")
    tg = f_key(c)[2]
    out = []
    for fc in F.get("constraints") or []:
        if not fc.get("marked") or fc.get("violated"):
            continue
        t = fc.get("type")
        if k == "angle" and t == "angle" and ang(
                {"at": fc.get("at"), "rays": fc.get("rays")}) == tg:
            out.append("marks its value %s" % fc.get("value"))
        elif k == "segment" and t == "length" and seg(fc.get("of")) == tg:
            out.append("marks its value %s" % fc.get("value"))
        elif k == "angle" and t == "equal_angle" and tg in [
                ang(x) for x in fc.get("of") or []] and key(fc) not in gkeys:
            out.append("equates it by arcs, no given says so")
        elif k == "segment" and t == "equal_length" and tg in [
                seg(x) for x in fc.get("of") or []] and key(fc) not in gkeys:
            out.append("equates it by ticks, no given says so")
    return out


def _source_state_figure_observation(F, svg, c, val, question, item, public_spec):
    """Remove only the proved old-height observation from two overlap checks.

    All answer-value scans still read the complete original JSON and SVG.
    This never exempts a head figure, another object, or a changed-state mark.
    """
    try:
        import xml.etree.ElementTree as ET
        from wspec import canon as WC
        from wspec.check.figure_state import obsolete_height
        qid, rid = question["id"], item["id"]
        if (F.get("question") != qid or F.get("item") or F.get("aux")
                or c.get("type") != "find" or c.get("quantity") != "length"
                or WC.canon_unit(c.get("unit")) != "m"):
            return F
        pq = [q for q in public_spec.get("questions", []) if q.get("id") == qid]
        if len(pq) != 1:
            return F
        pq = pq[0]
        pi = [i for i in pq.get("items", []) if i.get("id") == rid]
        if (len(pi) != 1 or question.get("text") != pq.get("text") or item.get("text") != pi[0].get("text")
                or question.get("figure_id") != pq.get("figure") or item.get("figure_id") != pi[0].get("figure")):
            return F
        changed = [g for g in public_spec.get("figures", []) if g.get("id") == pi[0].get("figure") and g.get("scope") == rid]
        if len(changed) != 1:
            return F
        changed = changed[0]
        old_ids = obsolete_height(public_spec, changed)
        state = changed.get("state_change") or {}
        if not old_ids or F.get("id") != state.get("from_figure") or F.get("id") != pq.get("figure"):
            return F
        facts = {f["id"]: f for f in public_spec.get("facts", [])}
        old = facts[state["old_height"]]
        if WC.same_quantity(val, c.get("unit"), old["value"], old["unit"]):
            return F  # a substituted private answer equal to the old datum remains a leak
        givens = [g for g in question.get("given", []) if isinstance(g, dict) and not g.get("from_item")
                  and g.get("text") in pq.get("given_lines", [])
                  and _source_old_height_given(public_spec, qid, rid, qid, c, g)]
        if len(givens) != 1:
            return F
        target = f_key(c)[2]
        constraints = [fc for fc in F.get("constraints", []) if fc.get("type") == "length"
                       and seg(fc.get("of")) == target and fc.get("status") == "given"
                       and fc.get("marked") is True and not fc.get("violated")
                       and WC.same_quantity(fc.get("value"), fc.get("unit"), old["value"], old["unit"])]
        if len(constraints) != 1:
            return F
        constraint = constraints[0]
        sid = constraint.get("mark_id")
        if not isinstance(sid, str) or constraint.get("mark_ids") != [sid]:
            return F
        labels = [lb for lb in (F.get("objects") or {}).get("labels", []) if lb.get("svg_id") == sid]
        if len(labels) != 1:
            return F
        label = labels[0]
        text = label.get("text")
        if (label.get("kind") != "label" or label.get("role") != "value" or seg(label.get("for")) != target
                or not isinstance(text, str) or not re.fullmatch(r"[0-9]+(?:\.[0-9]+)?", text)
                or not WC.same_quantity(text, old["unit"], old["value"], old["unit"])):
            return F
        nodes = [n for n in ET.fromstring(svg).iter() if n.get("id") == sid]
        if (len(nodes) != 1 or nodes[0].tag.rsplit("}", 1)[-1] != "text" or list(nodes[0])
                or (nodes[0].text or "").strip() != text):
            return F
        hook = (nodes[0].get("data-for") or "").split()
        xy = label.get("svg_xy")
        if (len(hook) != 2 or hook[0] != "seg" or seg(hook[1]) != target
                or not isinstance(xy, list) or len(xy) != 2
                or any(abs(float(nodes[0].get(k)) - float(v)) > .02 for k, v in zip(("x", "y"), xy))):
            return F
        # A new view for f_labels/f_marks only; no source/public object is mutated.
        objects = dict(F.get("objects") or {})
        objects["labels"] = [lb for lb in objects.get("labels", []) if lb is not label]
        view = dict(F, objects=objects)
        view["constraints"] = [fc for fc in F.get("constraints", []) if fc is not constraint]
        return view
    except Exception:
        return F  # missing or malformed independent evidence grants no exception


# ------------------------------------------------------------- the level --
def _load(p):
    try:
        with open(p, encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return None


def _tools():
    reg = _load(TOOLS)
    return dict((t["id"], t) for t in (reg or {}).get("tools") or [])


def _shape_covers(c, shapes):
    t = c.get("type")
    segs = [seg(x) for x in c.get("of") or []] \
        if isinstance(c.get("of"), list) else []
    for sh in shapes:
        P = tk(sh.get("points") or sh.get("of"))
        v = str(sh.get("value") or "")
        n = len(P)
        if n < 3:
            continue
        sides = set(seg([P[i], P[(i + 1) % n]]) for i in range(n))
        if t == "perpendicular" and v in ("rectangle", "square") and \
                len(segs) == 2 and all(s in sides for s in segs):
            return True
        if t == "equal_length" and v in ("square", "rhombus",
                                         "equilateral") and segs and \
                all(s in sides for s in segs):
            return True
        if t == "parallel" and n == 4 and len(segs) == 2 and v in (
                "parallelogram", "rectangle", "square", "rhombus",
                "trapezoid"):
            opp = {tuple(sorted((seg(P[0:2]), seg(P[2:4])))),
                   tuple(sorted((seg(P[1:3]), seg([P[3], P[0]]))))}
            if tuple(sorted(segs)) in opp:
                return True
    return False


def _mid_covers(c, given):
    """a given midpoint states the ticks AM = MB"""
    if c.get("type") != "equal_length" or not isinstance(c.get("of"), list):
        return False
    segs = sorted(seg(x) for x in c["of"])
    for g in given or []:
        if g.get("type") == "midpoint":
            P = str(g.get("point"))
            ab = (tk(g.get("of")) + ["", ""])[:2]
            if segs == sorted([seg([ab[0], P]), seg([P, ab[1]])]):
                return True
    return False


def stated(c, text):
    """is the given c said by the text (its own words, a relation the text
    writes, or its objects with a word of its relation)?"""
    if c.get("text") and len(norm(c["text"])) >= 3 and \
            norm(c["text"]) in norm(text):
        return True
    if key(c) in set(key(r) for r in relations(text)):
        return True
    return states_in_words(text, c)


def _covering(c, given, shapes):
    """the given(s) that make the mark of constraint c a given"""
    out = [g for g in given if key(g) == key(c)]
    out += [s for s in shapes if _shape_covers(c, [s])]
    out += [g for g in given if _mid_covers(c, [g])]
    return out


def _drawn(F, c):
    ob = F.get("objects") or {}
    byname = {}
    for b, lst in ob.items():
        for o in lst or []:
            if o.get("name"):
                byname[(b, str(o["name"]))] = o
    t = c.get("type")
    if t in ("segment", "line", "ray"):
        nm = "".join(tk(c.get("of")))
        for b in ("segments", "lines", "rays"):
            for k in (nm, nm[::-1]):
                if (b, k) in byname:
                    return True
        return False
    if t == "point":
        return ("points", str(c.get("point") or c.get("of"))) in byname
    if t == "polygon":
        P = sorted(tk(c.get("points") or c.get("of")))
        return any(b == "polygons" and sorted(tk(n)) == P
                   for (b, n) in byname)
    if t == "circle":
        return ("circles", str(c.get("circle") or c.get("of"))) in byname
    segs = c.get("of") if isinstance(c.get("of"), list) else []
    return bool(segs) and all(
        any((b, k) in byname for k in ("".join(tk(s)),
                                       "".join(tk(s))[::-1]))
        for s in segs for b in ("segments",))


_WORDS = {"same": u"שוו|שווה|זהים|זהות|זהה|אותו אורך|אותו גודל|באותו|כמו|"
                  u"חופפ|אורכם|=|\u2245",
          "parallel": u"מקביל|\u2225|\\|\\|",
          "perpendicular": u"מאונך|מאונכ|ניצב|אנך|\u22a5|90|ישר",
          "midpoint": u"אמצע|חוצה|מחלק|שוו",
          "shape": u"מלבן|ריבוע|מקבילית|מעוין|טרפז|דלתון|משולש|שוקיים"}


def said_objects(text):
    """what a text names: ('s', P, Q) segments, ('a', V, P, Q) angles,
    ('p', P) points, ('r', sorted letters) runs"""
    out = set()
    for run in _RUN.findall(str(text or "")):
        t = tk(run)
        out.add(("r", "".join(sorted(t))))
        if len(t) == 1:
            out.add(("p", t[0]))
        elif len(t) == 2:
            out.add(("s",) + tuple(sorted(t)))
        elif len(t) == 3:
            out.add(("a", t[1]) + tuple(sorted((t[0], t[2]))))
    return out


def states_in_words(text, c):
    """does `text` name every object of claim c with a word stating c's
    relation (no '=' needed: 'MD ארוך בדיוק כמו MC')?"""
    t = c.get("type")
    if t in ("equal_length", "parallel", "perpendicular"):
        of = [tk(x) for x in c.get("of") or []]
        if len(of) != 2 or any(len(x) != 2 for x in of):
            return False
        need = set(("s",) + tuple(sorted(x)) for x in of)
        w = _WORDS["same" if t == "equal_length" else t]
    elif t == "equal_angle":
        need = set()
        for a in c.get("of") or []:
            g = ang(a)
            if len(g) != 2 or len(g[1]) != 2:
                return False
            need.add(("a", g[0]) + tuple(g[1]))
        w = _WORDS["same"]
    elif t == "midpoint" and c.get("point"):
        need = set([("p", str(c["point"])),
                    ("s",) + tuple(sorted(tk(c.get("of"))))])
        w = _WORDS["midpoint"]
    elif t == "shape" and c.get("points"):
        need = set([("r", "".join(sorted(tk(c["points"]))))])
        # v6.9: a TYPED shape is stated by its own word only -- 'ABCD
        # מלבן' does not state the given 'ABCD מקבילית' (the claim of an
        # item that proves a parallelogram is a rectangle); an untyped one
        # by any shape word, as before
        w = _SHAPE_WORD.get(str(c.get("value") or ""), _WORDS["shape"])
    else:
        return False
    return bool(need) and need <= said_objects(text) and \
        bool(re.search(w, str(text)))


_INVIS = re.compile(u"[\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]")


def seen(s):
    """the text as a reader sees it: NFKC ('ＭＤ' is MD), no bidi marks"""
    return _INVIS.sub("", unicodedata.normalize("NFKC", str(s or "")))


# the claim's relation said of objects the text does not name (r2 S1)
_UNNAMED = {"equal_length": (u"קטע|צלע|אורך|אורכ",
                             u"שוו|זהים|זהות|זהה|אותו אורך|אותו גודל|חופפ"),
            "equal_angle": (u"זווית|זוויות",
                            u"שוו|זהות|זהים|זהה|אותו גודל|חופפ"),
            "parallel": (u"קטע|צלע|ישר|קו", u"מקביל"),
            "perpendicular": (u"קטע|צלע|ישר|קו",
                              u"מאונך|מאונכ|ניצב|ישרה|90"),
            "midpoint": (u"נקוד|קטע|צלע", u"אמצע|חוצה|מחלק"),
            "shape": (u"משולש|מרובע|צור",
                      u"מלבן|ריבוע|מקבילית|מעוין|טרפז|דלתון|שווה.?שוקיים|"
                      u"שווה.?צלעות|ישר.?זווית")}


def verdict(text, to_prove, to_construct, answer, qtext):
    """('FAIL' | 'REVIEW' | None, why) for one hint text."""
    if not text:
        return None, ""
    text = seen(text)
    n = norm(text)
    goals = set(key(c) for c in to_prove if isinstance(c, dict))
    for c in to_prove:
        if isinstance(c, dict) and c.get("text") and \
                len(norm(seen(c["text"]))) >= 3 and norm(seen(c["text"])) in n:
            return "FAIL", "states the claim to be proved (%s)" % c["text"]
    for r in relations(text):
        if key(r) in goals:
            return "FAIL", "states the claim to be proved"
    for c in to_prove:
        if isinstance(c, dict) and states_in_words(text, c):
            return "FAIL", "states the claim to be proved in words"
    if answer not in (None, ""):
        if len(norm(answer)) >= 2 and norm(answer) in n:
            return "FAIL", "contains the answer"
        hit = (numbers(answer) - numbers(qtext)) & numbers(text)
        if hit:
            return "FAIL", "contains the answer's number %s" % sorted(hit)
    for c in to_construct:
        nm = "".join(tk(c.get("of") or c.get("point") or c.get("points")))
        if nm and _CONSTRUCT.search(str(text)) and (nm in n or nm[::-1] in n):
            return "FAIL", "names the whole construction %s" % nm
        # r2 M1: 'חברו את A עם C' names the construction's points apart
        pts = set(tk(c.get("of") or c.get("point") or c.get("points") or
                     c.get("circle")))
        if len(pts) >= 2 and _CONSTRUCT.search(str(text)) and \
                pts <= set(tk(text)):
            return "FAIL", "names every point of the construction %s " \
                "with a construction verb" % "".join(sorted(pts))
    # r3 M3: a construction verb on an item that asks for a construction
    # may give the whole construction away without naming its points
    # ('העבירו אלכסון מ-A', 'חברו את הקודקוד השמאלי ... עם הימני ...') --
    # undecidable, so never auto-passed
    if to_construct and _CONSTRUCT.search(str(text)):
        return "REVIEW", "a construction hint on an item whose answer is " \
            "a construction: may give the construction away"
    ns = set()
    for c in to_prove:
        ns |= names(c)
    if len(ns & set(tk(text))) >= 2:
        return "REVIEW", "names %d of the claim's points" % len(
            ns & set(tk(text)))
    cs = set()
    for c in to_construct:
        cs |= names(c)
    if len(cs & set(tk(text))) >= 2:
        return "REVIEW", "names %d of the construction's points" % len(
            cs & set(tk(text)))
    for c in to_prove:
        u = _UNNAMED.get(c.get("type")) if isinstance(c, dict) else None
        if u and re.search(u[0], text) and re.search(u[1], text):
            return "REVIEW", "may state the claim in words without naming " \
                "its points"
    if len(str(text).split()) > 25:
        return "REVIEW", "longer than 25 words"
    return None, ""


def check_level(d, tools=None):
    """(findings, rows): findings [(status, rule, row id, text)]."""
    tools = tools if tools is not None else _tools()
    F = []
    nj = _load(os.path.join(d, "noam-ai.json"))
    if nj is None:
        return [("FAIL", "D0", "-", "noam-ai.json missing or not JSON")], []
    sj = _load(os.path.join(d, "sheet.json")) or {}
    dj = (_load(os.path.join(d, "didactic.json")) or {}).get("items") or {}
    # v6.7.2: a Noam AI package is STRICT unless its build.json says not
    strict = (_load(os.path.join(d, "build.json")) or {}).get(
        "strict_figures", True) is not False
    figs = dict((f.get("id"), f) for f in legacy_view(nj))
    svgs = {}
    for fid, f in figs.items():
        try:
            with open(os.path.join(d, f.get("svg") or ""),
                      encoding="utf-8") as fh:
                svgs[fid] = fh.read()
        except OSError:
            svgs[fid] = ""
            F.append(("FAIL", "D8", fid, "SVG %s missing" % f.get("svg")))
    # (v6.16 fix r1, D-D12) what each question's pie charts print
    _SVG_SHOWN.clear()
    _NATIVE_PRINTED_LABELS.clear()
    for nf in nj.get("figures") or []:
        _NATIVE_PRINTED_LABELS[nf.get("id")] = native_printed_labels(nf, svgs.get(nf.get("id")))
    _NATIVE_PRINTED_LENGTH_LABELS.clear()
    for nf in nj.get("figures") or []:
        _NATIVE_PRINTED_LENGTH_LABELS[nf.get("id")] = native_printed_labels(
            nf, svgs.get(nf.get("id")), strict_length_ink=True)
    public_spec = _load(os.path.join(d, "wspec/public_spec.json")) or {}
    public_figures = {f.get("id"): f for f in public_spec.get("figures", [])}
    public_owners = {row.get("id"): q.get("id") for q in public_spec.get("questions", [])
                     for row in [q] + list(q.get("items") or [])}
    for f in nj.get("figures") or []:
        vm = f.get("visual_model")
        if isinstance(vm, dict) and vm.get("kind") == "pie_chart":
            q_ = f.get("question") or vm.get("question")
            _SVG_SHOWN.setdefault(q_, set()).update(
                svg_shown(svgs.get(f.get("id"))))
        elif isinstance(vm, dict) and vm.get("kind") in _F_AXIS_KINDS:
            fid = f.get("id")
            q_ = f.get("question") or vm.get("question")
            pf = public_figures.get(fid) or {}
            if public_owners.get(pf.get("scope")) == q_:
                mp = _load(os.path.join(d, "figures", str(fid) + ".map.json")) or {}
                _SVG_SHOWN.setdefault(q_, set()).update(native_axis_shown(svgs.get(fid), pf, mp))
    sfig = dict((f.get("id"), f) for f in sj.get("figures") or [])
    sq = dict((q.get("id"), q) for q in sj.get("questions") or [])
    srow = {}
    for q in sj.get("questions") or []:
        srow[q.get("id")] = q
        for it in q.get("items") or []:
            srow[it.get("id")] = it
    rows = []
    # r2 S4: every row id in sheet order, for from_item
    order = {}
    for q in nj.get("questions") or []:
        for r in [q] + list(q.get("items") or []):
            order[r.get("id")] = (len(order), r)
    if not tools:
        # r2 m1: without the registry the not-yet-taught check is off --
        # said, never silent
        F.append(("REVIEW", "D6", "-", "curriculum_tools.json not found (or "
                  "empty) beside check_didactic.py -- the check for a hint "
                  "tool not yet taught did not run"))
    cu = nj.get("curriculum")
    allowed = None
    later = set()
    if not isinstance(cu, dict):
        F.append(("FAIL", "D6", "-", "no curriculum block: Noam AI cannot "
                  "know which tools are taught"))
    else:
        allowed = set(t.get("id") for t in cu.get("allowed_tools") or [])
        later = set(t.get("id") for t in cu.get("not_yet_allowed") or [])
    for q in nj.get("questions") or []:
        qid = q.get("id")
        its = list(q.get("items") or [])
        rows.append(qid)
        rows += [it.get("id") for it in its]
        allr = [q] + its
        qfigs = [f for f in figs.values() if f.get("question") == qid]
        start = [f for f in qfigs if f.get("reveal") != "on_request"]
        auxf = [f for f in qfigs if f.get("reveal") == "on_request" or
                f.get("step") is not None or
                (sfig.get(f.get("id")) or {}).get("aux")]
        # D13 (v6.9, Codex F4): a spec question marked spec_unsupported --
        # the public spec lacks an essential datum / target. Never
        # auto-passed: a human reads the reason (REVIEW); an empty reason
        # or an empty missing list FAILS
        su = q.get("spec_unsupported")
        if su is not None:
            if not isinstance(su, dict) or not str(
                    su.get("reason") or "").strip():
                F.append(("FAIL", "D13", qid, "spec_unsupported without a "
                          "reason"))
            else:
                F.append(("REVIEW", "D13", qid, "marked spec-unsupported "
                          "(the public spec lacks: %s); a human reads its "
                          "reason %r" % ("; ".join(
                              su.get("missing") or [])[:120] or "-",
                              str(su["reason"]).strip()[:60])))
        # D1 ---------------------------------------------------------------
        gk = {}
        for r in allr:
            for c in r.get("given") or []:
                if isinstance(c, dict) and not c.get("from_item"):
                    gk.setdefault(key(c), r.get("id"))
        for r in allr:
            for kk in ("to_prove", "to_construct"):
                for c in r.get(kk) or []:
                    if key(c) in gk:
                        F.append(("FAIL", "D1", r.get("id"),
                                  "%r is given in %s and %s here"
                                  % (c.get("text") or key(c), gk[key(c)],
                                     kk)))
            said = set(key(c) for c in relations(
                after_proof_verb(r.get("text"))))
            for c in (r.get("given") or []) + (q.get("given") or []
                                               if r is not q else []):
                if isinstance(c, dict) and not c.get("from_item") and \
                        key(c) in said:
                    F.append(("FAIL", "D1", r.get("id"),
                              "the given %r is the claim the text asks to "
                              "prove" % (c.get("text") or key(c),)))
        goals = set()
        for r in allr:
            for kk in ("to_prove", "to_construct"):
                for c in r.get(kk) or []:
                    goals.add(key(c))
        # r2 S4: from_item names an EARLIER row that proves this relation
        for r in allr:
            for c in r.get("given") or []:
                fi = c.get("from_item") if isinstance(c, dict) else None
                if not fi:
                    continue
                src = order.get(str(fi))
                if src is None:
                    F.append(("FAIL", "D1", r.get("id"), "from_item=%r: no "
                              "such item" % fi))
                elif src[0] >= order[r.get("id")][0]:
                    F.append(("FAIL", "D1", r.get("id"), "from_item=%r is "
                              "not an earlier item" % fi))
                elif key(c) not in set(key(x) for kk in (
                        "to_prove", "to_construct") for x in
                        src[1].get(kk) or [] if isinstance(x, dict)):
                    F.append(("FAIL", "D1", r.get("id"), "from_item=%r: "
                              "that item does not prove %r"
                              % (fi, c.get("text") or key(c))))
        # D2 D3 D4 on each starting figure ----------------------------------
        for f in start:
            fid = f.get("id")
            owner = f.get("item") or qid
            rr = [q] + ([it for it in its if it.get("id") == f.get("item")]
                        if f.get("item") else its)
            given = [c for r in rr for c in r.get("given") or []
                     if isinstance(c, dict)]
            gkeys = set(key(c) for c in given)
            shapes = [c for c in given if c.get("type") == "shape"]
            svg = svgs.get(fid, "")
            cons = f.get("constraints") or []
            hidden = set()
            for c in cons:
                if c.get("type") == "hidden_edge":
                    for o in (f.get("objects") or {}).get("segments") or []:
                        if seg(o.get("name") or "") == seg(c.get("of")):
                            hidden.add(o.get("svg_id"))
                            hidden.update(o.get("ink_svg_id") or [])
            decl = set()
            full = " ".join(str(x) for r2 in allr for x in (
                r2.get("text"), (srow.get(r2.get("id")) or {}).get("intro"))
                if x)
            for r in rr:
                for x in (srow.get(r.get("id")) or {}).get("dashed") or []:
                    lt = sorted(tk(re.sub(r"^[a-z]+-", "", str(x))))
                    # v6.12 fix_r2 (mD): an unnamed line, declared by its svg
                    # id, that the text calls "הקו המקווקו"
                    if _UNNAMED_SEG.match(str(x)):
                        said = bool(_DASHW.search(full)
                                    and _THE_DASHED_LINE.search(full))
                    else:
                        said = bool(_DASHW.search(full) and any(
                            sorted(tk(u)) == lt for u in _RUN.findall(full)))
                    if not said:
                        F.append(("FAIL", "D2", owner, "%s: dashed=[%r] is "
                                  "declared and the text never calls it "
                                  "dashed" % (fid, x)))
                        continue
                    decl.add(str(x))
                    for o in (f.get("objects") or {}).get("segments") or []:
                        if seg(o.get("name") or "") == seg(x):
                            decl.add(o.get("svg_id"))
            # (v6.16 fix r1, verify P2-S2) a GRAPH figure's dashed VERTICAL
            # curve stroke is the axis of symmetry when the text names one
            # ('ציר הסימטריה'): BRIEF_V616 G2's dashed axis (deliver
            # _symmetry_axis_dashes); measured here on the SVG element
            if (f.get("visual_model") or {}).get("kind") == \
                    "function_graph" and _SYM_AXIS.search(full):
                for o in (f.get("objects") or {}).get("paths") or []:
                    if o.get("kind") == "curve" and \
                            _vertical_line(svg, o.get("svg_id")):
                        decl.add(o.get("svg_id"))
            # (v6.16 fix r1 cont., frozen graph corpus GP185-190 / CONVENTIONS
            # L15; W-MATCH-ORIGINAL-MARKS) a GRAPH figure's dashed LEVEL line
            # -- a horizontal or vertical straight stroke -- whose curve label
            # prints an equation ('y = 16') that the question's own text
            # prints: a stated given line drawn dashed as the source draws it
            if (f.get("visual_model") or {}).get("kind") == "function_graph":
                labs = {}
                for o in (f.get("objects") or {}).get("labels") or []:
                    if o.get("role") == "curve_label" and o.get("for"):
                        labs[o["for"]] = _eq_norm(o.get("text"))
                body = _eq_norm(full)
                for o in (f.get("objects") or {}).get("paths") or []:
                    lab = labs.get(o.get("name"))
                    if o.get("kind") == "curve" and lab and re.search(
                            re.escape(lab) + u"(?![0-9.,/])", body) and (
                            _vertical_line(svg, o.get("svg_id")) or
                            _horizontal_line(svg, o.get("svg_id"))):
                        decl.add(o.get("svg_id"))
            decl.update(native_locus_dashes(svg, public_spec, fid,
                        _load(os.path.join(d, "figures", str(fid) + ".map.json")) or {}, full))
            from wspec.check.base_height import native_extension_dashes
            decl.update(native_extension_dashes(svg, public_spec, fid,
                        _load(os.path.join(d, "figures", str(fid) + ".map.json")) or {}, full))
            bad = [i for i in dashed(svg) if i not in hidden and
                   i not in decl]
            if bad:
                F.append(("FAIL", "D2", owner, "%s: helper / guide line(s) "
                          "in the starting figure (%s)"
                          % (fid, ", ".join(sorted(set(
                              str(b) for b in bad)))[:120])))
            ob = f.get("objects") or {}
            sides, onl = set(), []
            for o in ob.get("polygons") or []:
                P = tk(o.get("name") or "")
                if len(P) >= 3:
                    sides |= set(seg([P[i], P[(i + 1) % len(P)]])
                                 for i in range(len(P)))
                    onl += [(P[i], P[(i + 1) % len(P)])
                            for i in range(len(P))]
            for c in given:
                if c.get("type") in ("midpoint", "on_segment"):
                    ab = tk(c.get("of"))
                    if len(ab) == 2:
                        onl.append((ab[0], ab[1], str(c.get("point"))))
            said_segs = set()
            for u in _RUN.findall(full):
                t = tk(u)
                said_segs |= set(seg([t[i], t[(i + 1) % len(t)]])
                                 for i in range(len(t))) if len(t) >= 2 \
                    else set()
            for r2 in allr:
                for kk in ("given", "to_prove", "to_construct"):
                    for c in r2.get(kk) or []:
                        if isinstance(c, dict):
                            for x in (c.get("of") if isinstance(
                                    c.get("of"), list) else [c.get("of")]):
                                if len(tk(x)) == 2:
                                    said_segs.add(seg(x))
            # r2 S2: a solid's edges are its segments -- the helper-line
            # reading is for plane figures only
            vk = (f.get("visual_model") or {}).get("kind")
            plane = vk in (None, "plane_geometry", "construction")
            for o in (ob.get("segments") or []) if plane else []:
                s = seg(o.get("name") or "")
                pq = set(tk(o.get("name") or ""))
                if len(pq) != 2 or s in sides or s in said_segs or \
                        o.get("svg_id") in hidden or any(
                            pq <= set(L) for L in onl):
                    continue
                F.append(("REVIEW", "D2", owner, "%s draws the segment %s, "
                          "which is no side and which the text never "
                          "mentions (a helper line?)" % (fid, o.get("name"))))
            for r in rr:
                for c in r.get("to_construct") or []:
                    if isinstance(c, dict) and _drawn(f, c):
                        F.append(("FAIL", "D2", owner, "%s already draws "
                                  "%s, which the student constructs"
                                  % (fid, c.get("text") or key(c))))
            col = colours(svg)
            if col:
                F.append(("FAIL", "D3", owner, "%s: colour(s) %s off the "
                          "ink / grey palette" % (fid, sorted(set(col))[:4])))
            covered = set()
            for c in cons:
                if not c.get("marked") or c.get("violated") or \
                        c.get("type") == "hidden_edge":
                    continue
                mids = [m for m in [c.get("mark_id")] +
                        list(c.get("mark_ids") or []) if m]
                covered.update(mids)
                if c.get("status") == "to_prove" or key(c) in goals:
                    F.append(("FAIL", "D3", owner, "%s marks %s, a goal of "
                              "the question" % (fid, key(c))))
                elif c.get("status") != "given" and key(c) not in gkeys \
                        and not _shape_covers(c, shapes) and \
                        not _mid_covers(c, given):
                    F.append(("FAIL", "D4", owner, "%s marks %s, which is "
                              "not a given" % (fid, key(c))))
                else:
                    cov = _covering(c, given, shapes)
                    if cov and not any(stated(g, full) for g in cov):
                        F.append(("REVIEW", "D4", owner, "%s marks %s, "
                                  "covered only by the given %s, which the "
                                  "text does not state" % (
                                      fid, key(c), c_txt(cov[0]))))
            gnames = set()
            for c in given:
                gnames |= names(c)
            for o in (f.get("objects") or {}).get("marks") or []:
                if o.get("role", "mark") != "mark" or \
                        o.get("kind") not in MARK_KINDS or \
                        o.get("svg_id") in covered:
                    continue
                if o.get("kind") in ("arc", "right_angle") and \
                        str(o.get("name") or "") in gnames:
                    continue
                F.append(("FAIL", "D4", owner, "%s: mark %s (%s) states no "
                          "given" % (fid, o.get("svg_id"), o.get("kind"))))
            for gm in f.get("given_marks") or []:
                k = key(gm.get("claim"))
                if k in goals:
                    F.append(("FAIL", "D4", owner, "%s: given_mark on the "
                              "goal %s" % (fid, k)))
                elif k not in gkeys:
                    F.append(("FAIL", "D4", owner, "%s: given_mark %s is no "
                              "given" % (fid, k)))
            # D8 objects of a given exist in the SVG
            ids = ids_in(svg)
            pts = set(str(o.get("name")) for o in
                      (f.get("objects") or {}).get("points") or [])
            for c in given:
                if c.get("type") in OBJ_TYPES:
                    continue
                for p in names(c):
                    if p not in pts or ("pt-%s" % p) not in ids and not any(
                            o.get("name") == p and o.get("svg_id") in ids
                            for o in (f.get("objects") or {}).get("points")
                            or []):
                        F.append(("FAIL", "D8", owner, "%s: the given %s "
                                  "names %s, which the SVG does not carry"
                                  % (fid, c.get("text") or key(c), p)))
                        break
        # D7 aux figures ---------------------------------------------------
        for f in auxf:
            fid = f.get("id")
            owner = f.get("item") or qid
            if f.get("reveal") != "on_request" or not f.get("label") or \
                    not str(f.get("step") or "").strip():
                F.append(("FAIL", "D7", owner, "%s: an aux figure is shown "
                          "on request, labelled, with its one step" % fid))
            for c in f.get("constraints") or []:
                if c.get("marked") and key(c) in set(
                        key(x) for r in allr for x in r.get("to_prove") or []):
                    F.append(("FAIL", "D7", owner, "%s marks the to_prove %s"
                              % (fid, key(c))))
            mine = [r for r in allr if r.get("id") == owner] or [q]
            done = (sfig.get(fid) or {}).get("completes")
            tcs = [c for r in mine for c in r.get("to_construct") or []
                   if isinstance(c, dict)]
            if done and len(tcs) == 1:
                lt = sorted(names(tcs[0]))
                if not any(sorted(tk(u)) == lt for u in _RUN.findall(
                        str(f.get("step") or ""))):
                    F.append(("FAIL", "D7", owner, "%s: completes=True, and "
                              "its step does not name the construction %s"
                              % (fid, c_txt(tcs[0]))))
                    done = False
            for c in tcs:
                if _drawn(f, c) and not (done and len(tcs) == 1):
                    F.append(("FAIL", "D7", owner, "%s draws the whole "
                              "construction %s" % (fid, c.get("text") or
                                                   key(c))))
            srcrow = srow.get(owner) or {}
            ans = srcrow.get("answer")
            if ans is not None:
                qtext = " ".join(str(x) for x in (q.get("text"),
                                                  srcrow.get("text")) if x)
                hit = (numbers(ans) - numbers(qtext)) & svg_numbers(
                    svgs.get(fid, ""))
                if hit:
                    F.append(("FAIL", "D7", owner, "%s prints the answer %s"
                              % (fid, sorted(hit))))
        # D8 names and relations of the text --------------------------------
        if start:
            P = set()
            for f in start:
                for o in (f.get("objects") or {}).get("points") or []:
                    if o.get("name"):
                        P.add(str(o["name"]))
                # (v6.16 integrate) a pie chart's sectors are named by their
                # printed labels (visual_model objects of type sector)
                for o in (f.get("visual_model") or {}).get("objects") or []:
                    if isinstance(o, dict) and o.get("type") == "sector" and \
                            o.get("name") and o.get("parts"):
                        P.add(str(o["name"]))
                    # (v6.16 fix r1) a graph mark / curve named by its
                    # printed label ('P' of 'P(3, 6)', the line 'A')
                    if isinstance(o, dict) and o.get("type") in (
                            "mark", "curve") and o.get("name") and \
                            o.get("parts") and re.fullmatch(
                                r"[A-Z](?:'|\u2032)?", str(o["name"])):
                        P.add(str(o["name"]))
                for o in (f.get("objects") or {}).get("points") or []:
                    if o.get("letter"):
                        P.add(str(o["letter"]))
            # (v6.16 fix r1) a point the question's text itself DEFINES by
            # denotation ("נסמן ב-Q את הנקודה ..., וב-V את ...")
            P |= _denoted(" ".join(str(r.get("text") or "") for r in allr))
            for r in allr:
                txt = str(r.get("text") or "")
                txt = re.sub(r"\\[A-Za-z]+", " ", txt)
                new = set()
                for kk in ("to_construct",):
                    for rr2 in allr:
                        for c in rr2.get(kk) or []:
                            new |= names(c) if isinstance(c, dict) else set()
                for run in _RUN.findall(txt):
                    t = tk(run)
                    miss = [p for p in t if p not in P and p not in new]
                    if miss and len(t) >= 2:
                        F.append(("FAIL", "D8", r.get("id"), "the text names "
                                  "%s; no figure of %s defines %s"
                                  % (run, qid, ", ".join(miss))))
                    elif miss:
                        F.append(("REVIEW", "D8", r.get("id"), "the text "
                                  "uses %s, not a point of the figure (a "
                                  "variable?)" % run))
                declared = set()
                for rr2 in allr:
                    for kk in ("given", "to_prove", "to_construct"):
                        for c in rr2.get(kk) or []:
                            declared.add(key(c))
                vals = {}
                for k in declared:
                    if k and k[0] in ("length", "angle"):
                        vals.setdefault(k[:2], set()).add(k[2])
                for rel in relations(txt):
                    k = key(rel)
                    if k not in declared and k[:2] in vals:
                        F.append(("FAIL", "D8", r.get("id"), "the text "
                                  "states %s = %s; the model says %s"
                                  % (k[1], rel.get("value"),
                                     sorted(vals[k[:2]]))))
                    elif k not in declared:
                        F.append(("REVIEW", "D8", r.get("id"), "the text "
                                  "states %s, which is in none of given / "
                                  "to_prove / to_construct" % (key(rel),)))
        # D9 ---------------------------------------------------------------
        for r in its:
            if _CONSTRUCT.search(str(r.get("text") or "")) and \
                    not r.get("to_construct"):
                F.append(("REVIEW", "D9", r.get("id"), "the text asks to "
                          "construct and declares no to_construct"))
        # D10 a proof request with nothing to prove: the claim may have been
        # moved into `given` in words no relation reader parses (r1 M3)
        # r2 M2: the item asks to argue what one of its givens states
        for r in its:
            for a in argued(r.get("text")) if argues(r.get("text")) else []:
                for c in (r.get("given") or []) + (q.get("given") or []):
                    if isinstance(c, dict) and not c.get("from_item") and \
                            c.get("type") not in OBJ_TYPES and \
                            restated(a, c):
                        F.append(("FAIL", "D10", r.get("id"), "the text "
                                  "asks to argue %r, and it is a given"
                                  % (c.get("text") or key(c),)))
        # D11 (r3 M1): the claim an item proves is written as a FACT --
        # in the intro, in an earlier item, or in its own text outside the
        # asked clause. A later item may use it only as a from_item given.
        qtx = seen(q.get("text"))
        for ri, r in enumerate(its):
            for c in r.get("to_prove") or []:
                if not isinstance(c, dict):
                    continue
                ct = c.get("text") or key(c)
                if _source_read_off_claim(c, r.get("id"), public_spec):
                    continue
                if qtx and asserts(unasked(qtx), c):
                    F.append(("FAIL", "D11", r.get("id"), "the question's "
                              "text states %r as a fact; the item proves it"
                              % (ct,)))
                if asserts(unasked(seen(r.get("text"))), c):
                    F.append(("FAIL", "D11", r.get("id"), "the item's text "
                              "states %r as a fact and asks to prove it"
                              % (ct,)))
                for e in its[:ri]:
                    if asserts(unasked(seen(e.get("text"))), c):
                        F.append(("FAIL", "D11", e.get("id"), "the text "
                                  "states %r, which the later item %s "
                                  "proves" % (ct, r.get("id"))))
                for e in its[ri + 1:]:
                    if asserts(unasked(seen(e.get("text"))), c) and \
                            not any(isinstance(g, dict) and
                                    g.get("from_item") and key(g) == key(c)
                                    for g in e.get("given") or []):
                        F.append(("REVIEW", "D11", e.get("id"), "the text "
                                  "states %r, the claim of %s, with no "
                                  "from_item given" % (ct, r.get("id"))))
        # r3 S3: a to_prove the item's text never asks (a claim moved
        # onto an item only so a later from_item given is legal)
        for r in its:
            words = set(tk(seen(r.get("text"))))
            for c in r.get("to_prove") or []:
                if not isinstance(c, dict) or c.get("type") in OBJ_TYPES \
                        or c.get("type") == "find":
                    continue
                nm = names(c)
                if c.get("type") == "angle":
                    nm = set([str(c.get("at"))])
                elif c.get("type") == "equal_angle":
                    # '∠B' names the angle ABC by its vertex alone
                    nm = set(ang(a)[0] for a in c.get("of") or []
                             if ang(a))
                if nm and not nm <= words and \
                        not stated(c, seen(r.get("text"))):
                    F.append(("REVIEW", "D11", r.get("id"), "to_prove %r "
                              "is not asked by the item's text"
                              % (c.get("text") or key(c),)))
        # r3 m1: an approved_hint Noam AI would say that no human approved
        for r in its:
            ah = r.get("approved_hint")
            dr = dj.get(r.get("id")) or {}
            if ah and not (dr.get("approved") is True and
                           seen(dr.get("hint")).strip() ==
                           seen(ah).strip()):
                F.append(("FAIL", "D5", r.get("id"), "noam-ai.json carries "
                          "an approved_hint that didactic.json does not "
                          "approve"))
        # r2 M2: with to_prove=[] an item's own givens may BE its claim --
        # the givens overlay must not offer them
        sus = {}
        for r in its:
            if argues(r.get("text")) and not r.get("to_prove"):
                for c in r.get("given") or []:
                    if isinstance(c, dict) and not c.get("from_item"):
                        sus[key(c)] = r.get("id")
        qk = set(key(c) for c in q.get("given") or [] if isinstance(c, dict))
        for f in start:
            for gm in f.get("given_marks") or []:
                k = key(gm.get("claim"))
                if k in sus and k not in qk:
                    F.append(("FAIL", "D10", sus[k], "%s offers %s in the "
                              "givens overlay; the item asks to argue and "
                              "declares to_prove=[], so this given may be "
                              "its claim" % (f.get("id"), k)))
        for r in (its or [q]):
            if (_PROOF.search(str(r.get("text") or "")) or
                    argues(r.get("text"))) and not r.get("to_prove"):
                own = [c for c in r.get("given") or [] if isinstance(c, dict)
                       and not c.get("from_item")]
                # v6.7.2 item 5: a claim the relation vocabulary TYPES must
                # be typed -- REVIEW only for what is really undecidable,
                # with a readable reason (and the author's didactic note)
                cl = argued(r.get("text")) or [after_proof_verb(
                    r.get("text"))]
                typ, yesno = [], []
                for a in cl:
                    if a.lstrip().startswith(u"האם"):
                        yesno.append(a)
                        continue
                    if _EXPR.search(norm(a)):
                        # a sum / multiple ('∠APB = ∠DAP + ∠CBP',
                        # '∠DMB = 2∠A'): no relation type states it
                        continue
                    typ += relations(a)
                note = (dj.get(r.get("id")) or {}).get("note")
                if typ:
                    F.append(("FAIL", "D10", r.get("id"), "the asked claim "
                              "%s is typable -- declare it to_prove (the "
                              "relation vocabulary reads it)"
                              % ", ".join(c_txt(x) if x.get("text") else
                                          str(key(x)) for x in typ[:3])))
                    continue
                clt = seen(" ".join(cl)).strip()
                if yesno:
                    why = ("a yes/no question -- the claim may be false (%r)"
                           % seen(yesno[0]).strip()[:60])
                elif not re.search(u"[א-תA-Za-z0-9]", clt):
                    # r1 T6: 'חשבו את $\angle{AOB}$. נמקו.' -- the
                    # justification asks for no claim of its own
                    why = ("the item asks to justify (נמקו / הסבירו) and "
                           "states no claim of its own%s: %r" % (
                               " -- it computes, so its find target is the "
                               "claim to justify" if computes(r.get("text"))
                               else "", str(r.get("text") or "")
                               .strip()[:80]))
                else:
                    why = ("the asked claim is in words no relation type "
                           "reads (%r)" % clt[:60])
                F.append(("REVIEW", "D10", r.get("id"), "the text asks for a "
                          "proof and declares to_prove=[]%s: %s%s" % (
                              " while the item carries %d given(s) of its "
                              "own" % len(own) if own else "", why,
                              " -- note: %s" % note if note else "")))
        # D12 (v6.7.2, BRIEF_V672 items 1-4): compute / find targets -------
        fpts, fids, fvar = set(), set(), set()
        for f in start:
            for o in (f.get("objects") or {}).get("points") or []:
                if o.get("name"):
                    fpts.add(str(o["name"]))
            for o in (f.get("visual_model") or {}).get("objects") or []:
                fids.add(str(o.get("id")))
        for v in nj.get("visuals") or []:
            if v.get("question") == qid:
                fids.add(str(v.get("id")))
                fids.update(str(o.get("id")) for o in v.get("objects") or [])
        for r in allr:
            for kk in ("given", "to_construct"):
                for c in r.get(kk) or []:
                    if isinstance(c, dict):
                        fpts |= names(c)
            vv = r.get("variables") or []
            fvar.update(map(str, vv if isinstance(vv, list) else [vv]))
            fvar.update(re.findall(u"(?<![A-Za-z\\\\])([a-z])(?![A-Za-z])",
                                   str(r.get("text") or "")))
        gq = [c for r in allr for c in r.get("given") or []
              if isinstance(c, dict) and not c.get("from_item")]
        for r in (its or [q]):
            rid = r.get("id")
            tp = r.get("to_prove") or []
            ntr = r.get("no_target_reason")
            if ntr is not None and not str(ntr).strip():
                F.append(("FAIL", "D12", rid, "no_target_reason is empty"))
            elif str(ntr or "").strip():
                # r1 T1: opting out of a find target is never auto-passed
                F.append(("REVIEW", "D12", rid, "declares no find target; "
                          "a human reads its no_target_reason %r"
                          % str(ntr).strip()[:60]))
                dr = dj.get(rid)
                if isinstance(dr, dict) and \
                        dr.get("requires_human_review") is not True:
                    F.append(("FAIL", "D12", rid, "carries a "
                              "no_target_reason and didactic.json does not "
                              "flag it requires_human_review"))
            for k in sorted(r):
                if k in _F_SECRET and k != "value":
                    # r2 m2: an item row never carries its answer
                    F.append(("FAIL", "D12", rid, "noam-ai.json: the item "
                              "carries %r" % k))
            if computes(r.get("text")) and not tp and \
                    not r.get("to_construct") and not str(ntr or "").strip():
                F.append(("FAIL" if strict else "REVIEW", "D12", rid,
                          "the text asks to compute / find and declares no "
                          "find target: to_prove=[{'type': 'find', "
                          "'quantity': ..., 'of': ...}], or an explicit "
                          "no_target_reason"))
            sfind = (srow.get(rid) or {}).get("find") or []
            for c in tp:
                if not isinstance(c, dict) or c.get("type") != "find":
                    continue
                ct = c.get("text") or str(f_key(c))
                bad = f_schema(c)
                if bad:
                    F.append(("FAIL", "D12", rid, "find target %r: %s"
                              % (ct, bad)))
                    continue
                if any(k in c for k in ("value", "answer")):
                    F.append(("FAIL", "D12", rid, "noam-ai.json carries the "
                              "value of the find target %r" % ct))
                val = None
                for sc in sfind:
                    if isinstance(sc, dict) and sc.get("type", "find") == \
                            "find" and f_key(dict(sc, type="find")) == \
                            f_key(c):
                        val = sc.get("value")
                ctx12 = " ".join(str(x) for x in (
                    q.get("text"), q.get("intro"), r.get("text")) if x)
                if val is None or not str(val).strip():
                    # r2 M2: the private value is what every value check
                    # reads -- a target without one is not checkable
                    F.append(("FAIL", "D12", rid, "sheet.json keeps no "
                              "private value for the find target %r: give "
                              "it 'value' (the answer, private)" % ct))
                for t in f_shape(c):
                    F.append(("FAIL", "D12", rid, "noam-ai.json: the find "
                              "target %r %s" % (ct, t)))
                for t in f_objs(nj, qid, rid, c, ctx12):
                    F.append(("FAIL", "D12", rid, t))
                tobj = set(id(o) for _vm, o in f_target_objs(nj, qid, rid,
                                                               c))
                # v6.7.3: only the question's WORDS make a number public;
                # a JSON given never does (M1)
                pub = fvals(_f_qtext(q))
                for t in f_json(nj, qid, val, pub, tobj):
                    F.append(("FAIL", "D12", rid, t))
                for t in f_file(nj, qid, rid, c, val, tobj, public_spec):
                    if t.startswith("REVIEW:"):
                        F.append(("REVIEW", "D12", rid, t[7:]))
                    else:
                        F.append(("FAIL", "D12", rid, t))
                if val is not None and numbers(str(val)) & numbers(
                        c.get("text")) - numbers(r.get("text")):
                    F.append(("FAIL", "D12", rid, "the find target's text %r "
                              "states its value %s" % (ct, val)))
                for t in f_leaks(c, val, " ".join(str(x) for x in (
                        q.get("text"), q.get("intro"), r.get("text")) if x)):
                    F.append(("FAIL", "D12", rid, "noam-ai.json: the find "
                              "target %r %s" % (ct, t)))
                for t in f_cells(nj, qid, c):
                    F.append(("FAIL", "D12", rid, t))
                P, V, I = f_refs(c)
                miss = sorted(P - fpts) + sorted(V - fvar)
                for i in sorted(I):
                    m = _F_CELL.match(i)
                    if i not in fids and not (m and any(
                            x.endswith("-r%sc%s" % m.groups())
                            for x in fids)):
                        miss.append(i)
                if miss:
                    F.append(("FAIL", "D12", rid, "find target %r names %s, "
                              "which the question's model does not hold"
                              % (ct, ", ".join(miss))))
                gk2 = set(key(g) for g in gq)
                for f in qfigs:
                    own = f.get("item") or qid
                    isaux = f in auxf
                    if isaux and own == rid:
                        continue     # its own aux: D7 reads the answer
                    if not isaux and f.get("item") and \
                            f.get("item") != rid and r is not q:
                        continue
                    observed = _source_state_figure_observation(
                        f, svgs.get(f.get("id"), ""), c, val, q, r, public_spec)
                    for sid, txt in f_labels(observed, c, gq, val):
                        F.append(("FAIL", "D12", rid, "%s prints %r on %s, "
                                  "the value the item asks to find"
                                  % (f.get("id"), txt, ct)))
                    if not isaux:
                        for txt in f_svg(svgs.get(f.get("id"), ""), f, c,
                                         val, gq, " ".join(str(x) for x in (
                                             q.get("text"), q.get("intro"),
                                             r.get("text")) if x)):
                            F.append(("FAIL", "D12", rid, "%s's SVG prints "
                                      "%r, the value the item asks to find "
                                      "(%s)" % (f.get("id"), txt, ct)))
                    for t in f_marks(observed, c, gk2):
                        F.append(("FAIL", "D12", rid, "%s %s (%s)"
                                  % (f.get("id"), t, ct)))
        # D5 D6 hints and tools --------------------------------------------
        for r in allr:
            rid = r.get("id")
            dr = dj.get(rid) or {}
            srcrow = srow.get(rid) or {}
            tp = [c for c in r.get("to_prove") or [] if isinstance(c, dict)]
            tc = [c for c in r.get("to_construct") or []
                  if isinstance(c, dict)]
            qtext = " ".join(str(x) for x in (q.get("text"), r.get("text"))
                             if x)
            for txt in (r.get("approved_hint"), dr.get("hint")):
                st, why = verdict(txt, tp, tc, srcrow.get("answer"), qtext)
                if st:
                    F.append((st, "D5", rid, "hint %r %s" % (
                        str(txt)[:50], why)))
            if dr.get("requires_human_review"):
                F.append(("REVIEW", "D5", rid, "didactic.json: requires "
                          "human review (%s)" % "; ".join(
                              dr.get("review_reasons") or ["flagged"])))
            if allowed is not None:
                late = [t for t in dr.get("allowed_tools") or []
                        if t not in allowed]
                if late:
                    F.append(("FAIL", "D6", rid, "allowed_tools %s are not "
                              "taught at this point" % late[:4]))
                for txt in (r.get("approved_hint"), dr.get("hint")):
                    # r3 S2: a theorem the hint names that no allowed tool
                    # accounts for (not in the registry, or a tool whose
                    # keyword list is empty) cannot be placed in the
                    # teaching order -- undecidable, never auto-passed
                    if txt and _THEOREM.search(seen(txt)) and not any(
                            k and k in seen(txt)
                            for tid in allowed
                            for k in list((tools.get(tid) or {}).get(
                                "keywords") or []) + [
                                (tools.get(tid) or {}).get("name_he")]):
                        F.append(("REVIEW", "D6", rid, "the hint names a "
                                  "theorem or method no allowed tool of "
                                  "this package accounts for"))
                    for tid in later:
                        kws = (tools.get(tid) or {}).get("keywords") or []
                        if txt and any(k and k in txt for k in kws):
                            F.append(("FAIL", "D6", rid, "the hint uses %s, "
                                      "not yet taught" % tid))
    # V1-V6 the visual models (§9) -----------------------------------------
    for vm, f in vm_of_level(nj):
        owner = vm.get("item") or vm.get("question") or "-"
        if owner not in rows:
            owner = "-"
        asv = {}
        for a in vm.get("aux") or []:
            asv[a.get("id")] = svgs.get(a.get("id"), "")
        for st, rule, txt in vm_faults(vm, svgs.get((f or {}).get("id"))
                                       if f else None, asv):
            F.append((st, rule, owner, txt))
    for vm, _f in vm_of_level(nj):
        for r in vm.get("relations") or []:
            if r.get("type") == "find" and any(
                    k in r for k in ("value", "answer")):
                F.append(("FAIL", "D12", r.get("item") or vm.get("question")
                          or "-", "%s: the find relation %s carries its "
                          "value" % (vm.get("id"), r.get("id"))))
            if r.get("type") == "find":
                for t in f_shape(r, rel=True):
                    F.append(("FAIL", "D12", r.get("item") or
                              vm.get("question") or "-", "%s: the find "
                              "relation %s %s" % (vm.get("id"), r.get("id"),
                                                  t)))
                own = vm.get("item") or r.get("item")
                ctx = " ".join(str(x.get("text") or "") + " " +
                               str(x.get("intro") or "")
                               for Q in nj.get("questions") or []
                               if Q.get("id") == vm.get("question")
                               for x in [Q] + list(Q.get("items") or [])
                               if x is Q or not own or x.get("id") == own)
                for t in f_leaks(r, None, ctx):
                    F.append(("FAIL", "D12", r.get("item") or
                              vm.get("question") or "-", "%s: the find "
                              "relation %s %s" % (vm.get("id"), r.get("id"),
                                                  t)))
            if r.get("type") == "find" and r.get("id") in (
                    vm.get("highlight_given") or []):
                F.append(("FAIL", "D12", r.get("item") or vm.get("question")
                          or "-", "%s: highlight_given touches the find "
                          "target %s" % (vm.get("id"), r.get("id"))))
    kinds_of = {}
    for vm, _f in vm_of_level(nj):
        kinds_of.setdefault(vm.get("question"), set()).add(vm.get("kind"))
    for q in nj.get("questions") or []:
        txt = " ".join(str(x.get("text") or "") for x in
                       [q] + list(q.get("items") or []))
        for kind, rx in _NEEDS:
            if re.search(rx, txt) and kind not in kinds_of.get(
                    q.get("id"), set()):
                F.append(("REVIEW", "V7", q.get("id"), "the text asks for "
                          "a %s and the package has no %s model -- declare "
                          "visual=dict(kind=%r, ...) (unsupported kinds ship "
                          "the exact model and no drawing)"
                          % (kind, kind, kind)))
    # D7 rarity ------------------------------------------------------------
    nq = len(nj.get("questions") or [])
    aq = sorted(set(f.get("question") for f in figs.values()
                    if f.get("reveal") == "on_request"))
    lim = max(1, int(0.1 * nq + 0.5))
    if len(aq) > lim:
        F.append(("FAIL", "D7", "-", "%d of %d questions carry an aux figure "
                  "(at most %d)" % (len(aq), nq, lim)))
    return F, rows


def report(d, tools=None):
    F, rows = check_level(d, tools)
    st = {}
    for s, _r, rid, _t in F:
        if s == "FAIL" or st.get(rid) != "FAIL":
            st[rid] = s if st.get(rid) != "FAIL" else "FAIL"
    level_rows = list(rows) + (["-"] if any(r == "-" for _s, _x, r, _t in F)
                               else [])
    cnt = {"PASS": 0, "FAIL": 0, "REVIEW": 0}
    for r in level_rows:
        cnt[st.get(r, "PASS")] += 1
    print("%s: PASS %d  FAIL %d  REVIEW %d" % (d, cnt["PASS"], cnt["FAIL"],
                                               cnt["REVIEW"]))
    for s in ("FAIL", "REVIEW"):
        its = [r for r in level_rows if st.get(r) == s]
        if its:
            print("  %s items: %s" % (s, ", ".join(map(str, its))))
    for s, rule, rid, t in F:
        print("    %-6s %-3s %-8s %s" % (s, rule, rid, t))
    return cnt, F


# ------------------------------------------------------------ fixtures ----
_SVG = u"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 120">
<polygon id="poly-ABCD" points="20,100 180,100 180,20 20,20" fill="none" \
stroke="#111"/>
<line id="seg-AB" x1="20" y1="100" x2="180" y2="100" stroke="#111"/>
<line id="seg-BC" x1="180" y1="100" x2="180" y2="20" stroke="#111"/>
<line id="seg-CD" x1="180" y1="20" x2="20" y2="20" stroke="#111"/>
<line id="seg-AD" x1="20" y1="100" x2="20" y2="20" stroke="#111"/>
<line id="seg-MD" x1="100" y1="100" x2="20" y2="20" stroke="#111"/>
<line id="seg-MC" x1="100" y1="100" x2="180" y2="20" stroke="#111"/>
<circle id="pt-A" cx="20" cy="100" r="1.5" fill="#111"/>
<circle id="pt-B" cx="180" cy="100" r="1.5" fill="#111"/>
<circle id="pt-C" cx="180" cy="20" r="1.5" fill="#111"/>
<circle id="pt-D" cx="20" cy="20" r="1.5" fill="#111"/>
<circle id="pt-M" cx="100" cy="100" r="1.5" fill="#111"/>
<path id="ra-A" d="M 26 100 L 26 94 L 20 94" fill="none" stroke="#111"/>
<g id="tick-AM"><line x1="60" y1="96" x2="60" y2="104" stroke="#111"/></g>
<g id="tick-MB"><line x1="140" y1="96" x2="140" y2="104" stroke="#111"/></g>
<text id="lbl-A" x="8" y="112" fill="#111">A</text>
</svg>"""
_AUX = u"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 120">
<line id="seg-AB" x1="20" y1="100" x2="180" y2="100" stroke="#111"/>
<line id="seg-BC" x1="180" y1="100" x2="180" y2="20" stroke="#111"/>
<circle id="pt-A" cx="20" cy="100" r="1.5" fill="#111"/>
<circle id="pt-B" cx="180" cy="100" r="1.5" fill="#111"/>
<circle id="pt-C" cx="180" cy="20" r="1.5" fill="#111"/>
<text id="lbl-S" x="90" y="60" fill="#111">6</text>
</svg>"""


def _pts(names_):
    return [{"svg_id": "pt-%s" % n, "kind": "point", "name": n}
            for n in names_]


def _segs(names_):
    return [{"svg_id": "seg-%s" % n, "kind": "segment", "name": n}
            for n in names_]


def fixture():
    """A clean level: a rectangle with M the midpoint of AB (given, ticks),
    its right angle covered by the given shape, a proof item, a
    construction item with an aux figure (one step, not the result)."""
    nj = {
        "schema_version": "noam-ai/v1", "package": "G9-T18", "level": "a",
        "curriculum": {"grade": "9", "track": u"ט_רגילה",
                       "topic": "rectangle", "unit": u"מלבן",
                       "allowed_tools": [
                           {"id": "thm.rectangle_props", "name": u"מלבן"},
                           {"id": "thm.congruence_sas", "name": u"צ.ז.צ"}],
                       "not_yet_allowed": [
                           {"id": "thm.midsegment", "name": u"קטע אמצעים"},
                           {"id": "thm.rhombus_props", "name": u"מעוין"}]},
        "questions": [{
            "id": "q1", "label": 1, "figure_id": "q1_head",
            "text": u"ABCD מלבן. M אמצע AB.",
            "given": [{"type": "shape", "points": ["A", "B", "C", "D"],
                       "value": "rectangle", "text": u"ABCD מלבן"},
                      {"type": "midpoint", "point": "M", "of": ["A", "B"],
                       "text": u"M אמצע AB"}],
            "to_prove": [], "to_construct": [],
            "items": [
                {"id": "q1a", "label": u"א", "figure_id": "q1_head",
                 "text": u"הוכיחו כי MD = MC.", "given": [],
                 "to_prove": [{"type": "equal_length", "of": ["MD", "MC"],
                               "text": "MD = MC"}],
                 "to_construct": [], "hint_mode": "guiding_question"},
                {"id": "q1b", "label": u"ב", "figure_id": "q1_head",
                 "text": u"העבירו את האלכסון AC.", "given": [],
                 "to_prove": [], "to_construct": [
                     {"type": "segment", "of": "AC", "text": u"האלכסון AC"}],
                 "hint_mode": "guiding_question", "aux": ["q1b_aux1"]},
                {"id": "q1c", "label": u"ג", "figure_id": "q1_head",
                 "text": u"נתון AB = 8, BC = 6. חשבו את AC.",
                 "given": [{"type": "length", "of": "AB", "value": 8,
                            "text": "AB = 8"},
                           {"type": "length", "of": "BC", "value": 6,
                            "text": "BC = 6"}],
                 # v6.7.2: a compute item declares its find target
                 "to_prove": [{"type": "find", "quantity": "length",
                               "of": "AC", "text": u"אורך AC"}],
                 "to_construct": [],
                 "hint_mode": "concept"}]}],
        "figures": [{
            "id": "q1_head", "svg": "figures/q1_head.svg", "question": "q1",
            "view": {},
            "objects": {"points": _pts("ABCDM"),
                        "segments": _segs(["AB", "BC", "CD", "AD", "MD",
                                           "MC"]),
                        "polygons": [{"svg_id": "poly-ABCD",
                                      "kind": "polygon", "name": "ABCD"}],
                        "marks": [{"svg_id": "ra-A", "kind": "right_angle",
                                   "name": "A"},
                                  {"svg_id": "tick-AM", "kind": "ticks"},
                                  {"svg_id": "tick-MB", "kind": "ticks"}]},
            "constraints": [
                {"type": "perpendicular", "of": ["AB", "AD"], "at": "A",
                 "status": "derived", "marked": True, "mark_id": "ra-A"},
                {"type": "midpoint", "point": "M", "of": ["A", "B"],
                 "status": "given", "marked": True, "mark_id": "tick-AM",
                 "mark_ids": ["tick-AM", "tick-MB"]}],
            "given_marks": [{"claim": {"type": "midpoint", "point": "M",
                                       "of": ["A", "B"]}, "mark": "ticks",
                             "n": 1, "svg_ids": ["pt-A", "pt-M", "pt-B"]}]},
            {"id": "q1b_aux1", "svg": "figures/q1b_aux1.svg",
             "question": "q1", "item": "q1b", "reveal": "on_request",
             "label": u"שרטוט עזר", "step": u"מאיזו נקודה יוצא האלכסון",
             "view": {},
             "objects": {"points": _pts("ABC"),
                         "segments": _segs(["AB", "BC"])},
             "constraints": []}]}
    sj = {"questions": [{"id": "q1", "items": [
        {"id": "q1a"}, {"id": "q1b"}, {"id": "q1c", "answer": "10",
                                       "find": [{"quantity": "length",
                                                 "of": "AC", "value": 10}]}]}],
        "figures": [{"id": "q1_head"}, {"id": "q1b_aux1", "aux": True,
                                        "completes": False}]}
    dj = {"schema": "didactic/v1", "items": {
        "q1a": {"hint_type": "guiding_question", "exposure": 1,
                "requires_human_review": False,
                "allowed_tools": ["thm.congruence_sas"],
                "hint": u"אילו משולשים כדאי להשוות?", "approved": False},
        "q1b": {"hint_type": "none", "exposure": 0,
                "requires_human_review": False, "allowed_tools": []},
        "q1c": {"hint_type": "theorem", "exposure": 1,
                "requires_human_review": False, "allowed_tools": []}}}
    return nj, sj, dj, {"q1_head": _SVG, "q1b_aux1": _AUX}


def _fixture_states(vm):
    """(v6.10, C3) the statements deliver.add_shape_states writes for a
    typed-shape given -- the fixtures ship them as a delivered level does."""
    P = dict((str(o.get("name")), tuple(o["svg_xy"]))
             for o in vm.get("objects") or []
             if o.get("type") == "point" and o.get("name") and
             isinstance(o.get("svg_xy"), list) and len(o["svg_xy"]) == 2
             and not isinstance(o["svg_xy"][0], list))
    rels, hg = vm["relations"], vm["highlight_given"]
    goals = c3_goal_keys(vm)
    have = set(c3_key(r) for r in rels if r.get("id") in hg)
    for r in list(rels):
        if r.get("type") != "shape" or r.get("role") != "given" or \
                r.get("from_item"):
            continue
        try:
            st = shape_states(r.get("value"), r.get("points"), P,
                              r.get("text"))
        except ShapeStateError:
            continue
        for k, c in enumerate(st, 1):
            if c3_key(c) in goals or c3_key(c) in have:
                continue
            rels.append(dict(c, id="%s-s%d" % (r["id"], k), role="given",
                             from_given=r["id"], objects=[]))
            hg.append("%s-s%d" % (r["id"], k))
            have.add(c3_key(c))


def _to_vm(nj):
    """The fixture's figures in the v6.7.1 public shape: each starting
    figure carries its visual_model; given_marks become highlight_given, aux
    figures become patches (the shape deliver writes)."""
    start, auxs = [], []
    for f in nj.get("figures") or []:
        (auxs if f.get("reveal") == "on_request" or f.get("step") is not None
         else start).append(f)
    qs = dict((q.get("id"), q) for q in nj.get("questions") or [])
    for f in start:
        q = qs.get(f.get("question")) or {}
        rows = [q] + [it for it in q.get("items") or []
                      if not f.get("item") or it.get("id") == f["item"]]
        rels, seen = [], {}

        def rel(c, role, item):
            r = dict((k, v) for k, v in c.items()
                     if k not in ("status", "mark_id", "mark_ids", "marked"))
            r.update(id="r%d" % (len(rels) + 1), role=role)
            if item:
                r["item"] = item
            rels.append(r)
            seen[(key(c), role)] = r
            return r
        for r in rows:
            for role in ("given", "to_prove", "to_construct"):
                for c in r.get(role) or []:
                    if (key(c), role) not in seen:
                        rel(c, role, r.get("id") if r is not q else None)
        mrole = {}
        for c in f.get("constraints") or []:
            k = key(c)
            hit = seen.get((k, "given")) or seen.get((k, "to_prove")) or \
                seen.get((k, "to_construct"))
            if hit is None:
                hit = rel(c, {"given": "given", "to_prove": "to_prove"}.get(
                    c.get("status"), "context"), None)
            hit["measured"] = True
            for kk in ("marked", "mark_id", "mark_ids"):
                if c.get(kk):
                    hit[kk] = c[kk]
            for m in [c.get("mark_id")] + list(c.get("mark_ids") or []):
                if m:
                    mrole[m] = hit["role"]
        objs = []
        for b, lst in (f.get("objects") or {}).items():
            for o in lst or []:
                d = {"id": o["svg_id"], "svg_id": o["svg_id"],
                     "type": o.get("kind"), "display": "initial",
                     "role": mrole.get(o["svg_id"], "context")}
                for kk in ("name", "xy", "svg_xy", "text", "xyz"):
                    if o.get(kk) is not None:
                        d[kk] = o[kk]
                objs.append(d)
        hg = []
        for gm in f.pop("given_marks", None) or []:
            k = key(gm.get("claim"))
            r = seen.get((k, "given")) or seen.get((k, "to_prove")) or \
                seen.get((k, "to_construct"))
            if r is not None:
                hg.append(r["id"])
        vm = {"schema_version": VM_SCHEMA, "id": f["id"],
              "kind": "construction" if any(
                  r.get("to_construct") for r in rows) else "plane_geometry",
              "visual_support": "full", "question": f.get("question"),
              "svg": f.get("svg"), "view": f.get("view") or {},
              "objects": objs, "relations": rels, "highlight_given": hg,
              "aux": []}
        _fixture_states(vm)
        base = set(o["id"] for o in objs)
        for a in auxs:
            if a.get("question") != f.get("question"):
                continue
            adds, shows, hl, arel = [], [], [], []
            for b, lst in (a.get("objects") or {}).items():
                for o in lst or []:
                    if o["svg_id"] in base:
                        shows.append(o["svg_id"])
                    else:
                        adds.append({"id": o["svg_id"],
                                     "svg_id": o["svg_id"],
                                     "type": o.get("kind"),
                                     "name": o.get("name"),
                                     "role": "context",
                                     "display": "aux_only"})
            for c in a.get("constraints") or []:
                if not c.get("marked"):
                    continue
                k = key(c)
                r = seen.get((k, "given")) or seen.get((k, "to_prove")) or \
                    seen.get((k, "context"))
                if r is None:
                    r = dict(c)
                    r.update(id="aux-r%d" % (len(arel) + 1), role="aux_step")
                    arel.append(r)
                hl.append(r["id"])
            ops = []
            if adds or arel:
                ops.append({"op": "add", "objects": adds,
                            "relations": arel})
            if shows:
                ops.append({"op": "show", "ids": shows})
            if hl:
                ops.append({"op": "highlight", "ids": hl})
            p = {"id": a["id"], "svg": a.get("svg"), "label": a.get("label"),
                 "reveal": a.get("reveal"), "step": a.get("step"),
                 "ops": ops}
            if a.get("item"):
                p["item"] = a["item"]
            vm["aux"].append(p)
        vm["actions"] = {"allowed": ["show", "highlight", "show_aux"],
                         "show": [vm["id"]], "highlight": list(hg),
                         "show_aux": [p["id"] for p in vm["aux"]]}
        f["visual_model"] = vm
    nj["figures"] = start
    return nj


def _decl(kind, objects, relations=(), data=None, text=None, vid="q1_v"):
    """a content-declared visual of `kind` for the fixture's question 1."""
    def fn(nj, sj, dj, sv):
        vm = {"schema_version": VM_SCHEMA, "id": vid, "kind": kind,
              "visual_support": VM_KINDS[kind] if VM_KINDS[kind] != "full"
              else "partial", "question": "q1", "svg": None,
              "objects": [dict(o, role=o.get("role", "given"),
                               display=o.get("display", "initial"),
                               svg_id=o.get("svg_id"))
                          for o in objects],
              "relations": [dict(r, role=r.get("role", "given"))
                            for r in relations],
              "highlight_given": [], "aux": [],
              "actions": {"allowed": ["show", "highlight", "show_aux"],
                          "show": [], "highlight": [], "show_aux": []}}
        if data is not None:
            vm["data"] = data
        nj.setdefault("visuals", []).append(vm)
        if text:
            nj["questions"][0]["text"] += " " + text
    return fn


def _tree(p2="2/3", leaf="1/6"):
    return [{"id": "n0", "type": "node", "parent": None, "label": "start"},
            {"id": "n1", "type": "node", "parent": "n0", "p": "1/3"},
            {"id": "n2", "type": "node", "parent": "n0", "p": p2},
            {"id": "n11", "type": "node", "parent": "n1", "p": "1/2",
             "leaf_p": leaf},
            {"id": "n12", "type": "node", "parent": "n1", "p": "1/2",
             "leaf_p": "1/6"}]


def _vm_cases():
    """(name, status, rule, mutate) applied AFTER the vm conversion."""
    V = lambda nj: nj["figures"][0]["visual_model"]
    O = lambda nj, sid: [o for o in V(nj)["objects"] if o["id"] == sid][0]

    def xy_fig(nj, sj, dj, sv, off=0.0):
        V(nj)["view"] = {"data_to_svg": [20.0, 0.0, 0.0, -20.0, 20.0, 100.0]}
        for nm, xy in (("A", (0, 0)), ("B", (8, 0)), ("C", (8, 4)),
                       ("D", (0, 4)), ("M", (4, 0))):
            o = O(nj, "pt-%s" % nm)
            o["xy"] = [xy[0], xy[1]]
            o["svg_xy"] = [20 + 20 * xy[0] + (off if nm == "C" else 0),
                           100 - 20 * xy[1]]
    unsup_svg = lambda nj, sj, dj, sv: (_decl("venn", [])(nj, sj, dj, sv),
                                        nj["visuals"][0].update(
                                            svg="figures/q1_head.svg"))
    def bd(nj, sj, dj, sv, kind):
        sv["q1_head"] = sv["q1_head"].replace(
            "</svg>", '<line id="seg-BD" x1="180" y1="100" x2="20" y2="20" '
            'stroke="#111"/></svg>')
        nj["figures"][0].setdefault("objects", {}).setdefault(
            "segments", []).append(
            {"svg_id": "seg-BD", "kind": "segment", "name": "BD"})
        V(nj)["kind"] = kind

    it0 = lambda nj: nj["questions"][0]["items"][0]
    return [
        # v6.9: an engine figure's object -> parts (V2), and a TYPED shape
        # stated only by its own word (D10)
        ("v69 control: an engine object whose parts are in the SVG", "PASS",
         "V2", lambda nj, sj, dj, sv: V(nj)["objects"].append(
             {"id": "seg:AM", "svg_id": None, "type": "segment", "name": "AM",
              "parts": [{"svg_id": "pt-A"}, {"svg_id": "pt-M"}],
              "role": "context", "display": "initial"})),
        ("v69 an engine object whose part the SVG lacks", "FAIL", "V2",
         lambda nj, sj, dj, sv: V(nj)["objects"].append(
             {"id": "seg:AM", "svg_id": None, "type": "segment", "name": "AM",
              "parts": [{"svg_id": "e9999"}], "role": "context",
              "display": "initial"}), "part e9999"),
        ("v69 control: prove 'ABCD מקבילית' beside the given 'ABCD מלבן'",
         "PASS", "D10", lambda nj, sj, dj, sv: it0(nj).update(
             text=u"הוכיחו כי המרובע ABCD הוא מקבילית.", to_prove=[
                 {"type": "shape", "points": list("ABCD"),
                  "value": "parallelogram", "text": u"ABCD מקבילית"}])),
        ("v69 prove 'ABCD מלבן' with the given 'ABCD מלבן'", "FAIL", "D10",
         lambda nj, sj, dj, sv: (it0(nj).update(
             text=u"הוכיחו כי המרובע ABCD הוא מלבן.", to_prove=[]),
             it0(nj).setdefault("given", []).append(
                 {"type": "shape", "points": list("ABCD"),
                  "value": "rectangle", "text": u"ABCD מלבן"})),
         "asks to argue"),
        # R2-S2 the helper-line reading (D2 REVIEW) is for plane figures:
        # every edge of a solid is a segment that is no polygon side
        ("R2-S2 a plane figure: an unnamed segment BD is REVIEW", "REVIEW",
         "D2", lambda nj, sj, dj, sv: bd(nj, sj, dj, sv, "plane_geometry"),
         "no side"),
        ("R2-S2 control: a solid_3d figure's edge BD", "PASS", "D2",
         lambda nj, sj, dj, sv: bd(nj, sj, dj, sv, "solid_3d")),
        # V1
        ("control: coordinates that map to the SVG", "PASS", "V2",
         lambda nj, sj, dj, sv: xy_fig(nj, sj, dj, sv)),
        ("a kind the registry does not know", "FAIL", "V1",
         lambda nj, sj, dj, sv: V(nj).update(kind="spiral")),
        ("an unsupported kind that ships an SVG", "FAIL", "V1", unsup_svg),
        ("a kind claiming more support than the skill has", "FAIL", "V1",
         lambda nj, sj, dj, sv: (_decl("probability_tree", _tree())(
             nj, sj, dj, sv), nj["visuals"][0].update(
                 visual_support="full"))),
        ("two objects with one id", "FAIL", "V1",
         lambda nj, sj, dj, sv: V(nj)["objects"].append(
             dict(O(nj, "pt-A")))),
        ("a relation naming an object not in the model", "FAIL", "V1",
         lambda nj, sj, dj, sv: V(nj)["relations"][0].update(
             objects=["pt-Z"])),
        # V2
        ("an object whose svg_id the SVG lacks", "FAIL", "V2",
         lambda nj, sj, dj, sv: V(nj)["objects"].append(
             {"id": "pt-K", "svg_id": "pt-K", "type": "point", "name": "K",
              "role": "context", "display": "initial"})),
        ("a label whose number differs from the SVG", "FAIL", "V2",
         lambda nj, sj, dj, sv: V(nj)["objects"].append(
             {"id": "lbl-A", "svg_id": "lbl-A", "type": "label",
              "text": "7", "role": "context", "display": "initial"})),
        ("xy that does not map to svg_xy", "FAIL", "V2",
         lambda nj, sj, dj, sv: xy_fig(nj, sj, dj, sv, off=9.0)),
        ("a 2D drawing that is no projection of xyz", "FAIL", "V2",
         lambda nj, sj, dj, sv: [O(nj, "pt-%s" % n).update(xyz=p, xy=q)
                                 for n, p, q in (
                                     ("A", [0, 0, 0], [0, 0]),
                                     ("B", [1, 0, 0], [1, 0]),
                                     ("C", [0, 1, 0], [0, 1]),
                                     ("D", [0, 0, 1], [.5, .5]),
                                     ("M", [1, 1, 1], [3, 1]))]),
        # V3
        ("a to_prove object in the starting figure", "FAIL", "V3",
         lambda nj, sj, dj, sv: O(nj, "seg-MD").update(role="to_prove")),
        ("a goal relation marked", "FAIL", "V3",
         lambda nj, sj, dj, sv: [r.update(marked=True) for r in
                                 V(nj)["relations"]
                                 if r["role"] == "to_prove"]),
        # V4
        ("an aux op outside add / show / highlight", "FAIL", "V4",
         lambda nj, sj, dj, sv: V(nj)["aux"][0]["ops"].append(
             {"op": "draw_svg", "svg": "<path/>"})),
        ("an aux that shows an object not in the model", "FAIL", "V4",
         lambda nj, sj, dj, sv: V(nj)["aux"][0]["ops"].append(
             {"op": "show", "ids": ["pt-Q"]})),
        ("an aux that invents a given", "FAIL", "V4",
         lambda nj, sj, dj, sv: V(nj)["aux"][0]["ops"].append(
             {"op": "add", "relations": [{"id": "aux-g", "type": "parallel",
                                          "of": ["AB", "CD"],
                                          "role": "given"}]})),
        ("an aux that adds an object its SVG lacks", "FAIL", "V4",
         lambda nj, sj, dj, sv: V(nj)["aux"][0]["ops"].append(
             {"op": "add", "objects": [{"id": "seg-QQ", "svg_id": "seg-QQ",
                                        "type": "segment", "role": "context",
                                        "display": "aux_only"}]})),
        # V5
        ("an action outside the closed list", "FAIL", "V5",
         lambda nj, sj, dj, sv: V(nj)["actions"].update(
             allowed=["show", "draw"])),
        ("highlight beyond highlight_given", "FAIL", "V5",
         lambda nj, sj, dj, sv: V(nj)["actions"]["highlight"].append("r3")),
        # V6
        ("control: a probability tree that adds up", "PASS", "V6",
         _decl("probability_tree", _tree())),
        ("tree branches that do not add up to 1", "FAIL", "V6",
         _decl("probability_tree", _tree(p2="1/2"))),
        ("a leaf that is not the product of its branches", "FAIL", "V6",
         _decl("probability_tree", _tree(leaf="1/5"))),
        ("control: a sample space of 2 x 2", "PASS", "V6",
         _decl("sample_space", [{"id": "o%d" % i, "type": "outcome",
                                 "value": v} for i, v in enumerate(
                                     ["HH", "HT", "TH", "TT"])],
               data={"size": 4, "stages": [2, 2]})),
        ("a sample space whose size is wrong", "FAIL", "V6",
         _decl("sample_space", [{"id": "o%d" % i, "type": "outcome",
                                 "value": v} for i, v in enumerate(
                                     ["HH", "HT", "TT"])],
               data={"size": 4, "stages": [2, 2]})),
        ("an outcome table missing a cell", "FAIL", "V6",
         _decl("outcome_table", [{"id": "c1", "type": "cell", "row": 1,
                                  "col": 1, "value": 2}],
               data={"rows": [1, 2], "cols": [1, 2]})),
        ("frequencies that miss the total", "FAIL", "V6",
         _decl("frequency_table", [
             {"id": "k1", "type": "category", "frequency": 3},
             {"id": "k2", "type": "category", "frequency": 4}],
             data={"total": 8})),
        ("control: a Venn diagram that adds up", "PASS", "V6",
         _decl("venn", [{"id": "A", "type": "set", "total": 5},
                        {"id": "B", "type": "set", "total": 4},
                        {"id": "ab", "type": "region", "in": ["A", "B"],
                         "count": 2},
                        {"id": "a", "type": "region", "in": ["A"],
                         "count": 3},
                        {"id": "b", "type": "region", "in": ["B"],
                         "count": 2},
                        {"id": "o", "type": "region", "in": [],
                         "count": 1}], data={"universe": 8})),
        ("a Venn set whose regions miss its total", "FAIL", "V6",
         _decl("venn", [{"id": "A", "type": "set", "total": 6},
                        {"id": "a", "type": "region", "in": ["A"],
                         "count": 3}], data={"universe": 3})),
        ("a bar whose height is not value x scale", "FAIL", "V6",
         _decl("bar_chart", [{"id": "b1", "type": "bar", "value": 5,
                              "height_px": 40}], data={"scale": 10})),
        ("a pie sector off its share", "FAIL", "V6",
         _decl("pie_chart", [{"id": "s1", "type": "sector", "value": 1,
                              "angle": 90},
                             {"id": "s2", "type": "sector", "value": 1,
                              "angle": 270}])),
        ("a table row sum that disagrees", "FAIL", "V6",
         _decl("table", [{"id": "t11", "type": "cell", "row": 1, "col": 1,
                          "value": 2},
                         {"id": "t12", "type": "cell", "row": 1, "col": 2,
                          "value": 3}],
               [{"id": "rs1", "type": "row_sum", "row": 1, "value": 6}])),
        ("a point not on its function", "FAIL", "V6",
         _decl("function_graph", [{"id": "f", "type": "curve",
                                   "expr": "2*x+1"},
                                  {"id": "P", "type": "point",
                                   "xy": [1, 4]}],
               [{"id": "og", "type": "on_graph", "point": "P",
                 "curve": "f"}])),
        ("a number-line tick away from its value", "FAIL", "V6",
         lambda nj, sj, dj, sv: nj.setdefault("visuals", []).append({
             "schema_version": VM_SCHEMA, "id": "nl", "kind": "number_line",
             "visual_support": "partial", "question": "q1", "svg": None,
             "objects": [{"id": "tick-1", "svg_id": None, "type": "ticks",
                          "name": "1", "xy": [[1.5, 0.1], [1.5, -0.1]],
                          "role": "given", "display": "initial"}],
             "relations": [], "highlight_given": [], "aux": [],
             "actions": {"allowed": ["show"], "show": [], "highlight": [],
                         "show_aux": []}})),
        ("a given equality the coordinates break", "FAIL", "V6",
         lambda nj, sj, dj, sv: (xy_fig(nj, sj, dj, sv),
                                 V(nj)["relations"].append(
                                     {"id": "rx", "type": "equal_length",
                                      "of": ["AB", "BC"],
                                      "role": "given"}))),
        # V7
        ("a tree question with no tree model", "REVIEW", "V7",
         lambda nj, sj, dj, sv: nj["questions"][0].update(
             text=nj["questions"][0]["text"] + u" סרטטו עץ.")),
        ("control: the tree declared (unsupported, exact)", "PASS", "V7",
         _decl("probability_tree", [dict(o) for o in _tree()],
               text=u"היעזרו בעץ.")),
    ] + _pins(V, O, xy_fig)


def _pins(V, O, xy_fig):
    """r1 S1: one case per check site that deleting left every test green;
    each names the fragment of ITS message, so no other site can stand in
    for it (name, status, rule, mutate, fragment)."""
    def OV(nj):
        ov = [o for o in V(nj)["objects"]
              if o.get("display") == "given_highlight"]
        if not ov:
            ov = [{"id": "hl-r2", "svg_id": None, "type": "overlay_mark",
                   "mark": "ticks", "on": ["tick-AM", "tick-MB"],
                   "for": "r2", "role": "given",
                   "display": "given_highlight"}]
            V(nj)["objects"].append(ov[0])
        return ov[0]

    def AX(nj):
        return V(nj)["aux"][0]

    def dv(kind, objects, relations=(), data=None, view=None, act=None):
        def fn(nj, sj, dj, sv):
            _decl(kind, objects, relations, data)(nj, sj, dj, sv)
            if view is not None:
                nj["visuals"][-1]["view"] = view
            if act:
                nj["visuals"][-1]["actions"].update(act)
        return fn

    def lbl(ax, v, pos):
        return {"id": "lbl-%s%d" % (ax, v), "type": "label", "text": str(v),
                "xy": [pos, 0] if ax == "x" else [0, pos]}

    def mid_off(nj, sj, dj, sv):
        xy_fig(nj, sj, dj, sv)
        O(nj, "pt-M")["xy"] = [3, 0]
        O(nj, "pt-M")["svg_xy"] = [80, 100]
    return [
        ("pin V1 schema_version", "FAIL", "V1",
         lambda nj, sj, dj, sv: V(nj).update(schema_version="x"),
         "schema_version"),
        ("pin V1 visual_support", "FAIL", "V1",
         lambda nj, sj, dj, sv: V(nj).update(visual_support="great"),
         "visual_support 'great'"),
        ("pin V1 an object with no id", "FAIL", "V1",
         lambda nj, sj, dj, sv: V(nj)["objects"].append(
             {"type": "point", "role": "context", "display": "initial"}),
         "with no id"),
        ("pin V1 object role", "FAIL", "V1",
         lambda nj, sj, dj, sv: O(nj, "pt-A").update(role="hero"),
         "role 'hero'"),
        ("pin V1 object display", "FAIL", "V1",
         lambda nj, sj, dj, sv: O(nj, "pt-A").update(display="always"),
         "display 'always'"),
        ("pin V1 one svg_id on two objects", "FAIL", "V1",
         lambda nj, sj, dj, sv: V(nj)["objects"].append(
             dict(O(nj, "pt-B"), id="pt-B2")), "names 2 objects"),
        ("pin V1 a relation id twice", "FAIL", "V1",
         lambda nj, sj, dj, sv: V(nj)["relations"].append(
             dict(V(nj)["relations"][0])), "not unique"),
        ("pin V1 relation role", "FAIL", "V1",
         lambda nj, sj, dj, sv: V(nj)["relations"][0].update(role="x"),
         "relation r1 role"),
        ("pin V1 a point name on two objects", "FAIL", "V1",
         lambda nj, sj, dj, sv: V(nj)["objects"].append(
             {"id": "pt-A2", "svg_id": None, "type": "point", "name": "A",
              "role": "context", "display": "initial"}), "is 2 objects"),
        ("pin V1 a relation naming no point of the model", "FAIL", "V1",
         lambda nj, sj, dj, sv: V(nj)["relations"][0].update(
             points=["A", "B", "C", "Z"]), "no point of the model"),
        ("pin V5 unsupported with something to show", "FAIL", "V5",
         dv("venn", [], act={"show": ["q1_v"]}), "actions offer"),
        ("pin V3 highlight_given on a context relation", "FAIL", "V3",
         lambda nj, sj, dj, sv: V(nj)["highlight_given"].append("r7"),
         "which is no given relation"),
        # v6.10 (Codex C3): a typed-shape given is offered by exactly what
        # it states (the PASS fixture ships its four right angles)
        ("v610 C3 a statement of the given rectangle dropped", "FAIL", "V6",
         lambda nj, sj, dj, sv: V(nj)["highlight_given"].remove(
             [x for x in V(nj)["highlight_given"] if "-s" in x][-1]),
         "does not offer"),
        ("v610 C3 a relation the given rectangle does not state", "FAIL",
         "V6", lambda nj, sj, dj, sv: (V(nj)["relations"].append(
             {"id": "r1-s9", "type": "parallel", "role": "given",
              "of": ["AC", "BD"], "from_given": [
                  r["id"] for r in V(nj)["relations"]
                  if r.get("type") == "shape"][0]}),
             V(nj)["highlight_given"].append("r1-s9")),
         "is not what"),
        ("pin V3 an overlay for a goal", "FAIL", "V3",
         lambda nj, sj, dj, sv: OV(nj).update({"for": "r3"}),
         "marks r3, which is no given"),
        ("pin V1 an overlay on no svg_id", "FAIL", "V1",
         lambda nj, sj, dj, sv: OV(nj).update(on=["nope"]), "sits on nope"),
        ("pin V2 an overlay drawn in the SVG", "FAIL", "V2",
         lambda nj, sj, dj, sv: OV(nj).update(svg_id="seg-AB"),
         "is drawn in the starting SVG"),
        ("pin V4 an aux with no label", "FAIL", "V4",
         lambda nj, sj, dj, sv: AX(nj).pop("label"), "a label, one step"),
        ("pin V4 an aux re-adding a model object", "FAIL", "V4",
         lambda nj, sj, dj, sv: AX(nj)["ops"].append(
             {"op": "add", "objects": [{"id": "pt-A",
                                        "display": "aux_only"}]}),
         "re-adds pt-A"),
        ("pin V4 an aux adding an object for the start", "FAIL", "V4",
         lambda nj, sj, dj, sv: AX(nj)["ops"].append(
             {"op": "add", "objects": [{"id": "aux-X",
                                        "display": "initial"}]}),
         "with display 'initial'"),
        ("pin V4 an aux highlighting what nothing defines", "FAIL", "V4",
         lambda nj, sj, dj, sv: AX(nj)["ops"].append(
             {"op": "highlight", "ids": ["zz"]}), "neither in the model"),
        ("pin V4 an aux highlighting the goal", "FAIL", "V4",
         lambda nj, sj, dj, sv: AX(nj)["ops"].append(
             {"op": "highlight", "ids": ["r3"]}), "highlights the goal"),
        ("pin V5 no actions", "FAIL", "V5",
         lambda nj, sj, dj, sv: V(nj).pop("actions"), "no actions"),
        ("pin V5 show_aux not the aux list", "FAIL", "V5",
         lambda nj, sj, dj, sv: V(nj)["actions"].update(show_aux=[]),
         "is not the aux list"),
        ("pin V5 show names another component", "FAIL", "V5",
         lambda nj, sj, dj, sv: V(nj)["actions"].update(show=["zzz"]),
         "another component"),
        ("pin V6 a number-line point off its name", "FAIL", "V6",
         dv("number_line", [{"id": "p", "type": "point", "name": "2",
                             "value": 3}]), "is named 2 and sits at 3"),
        ("pin V6 number-line ticks off the step", "FAIL", "V6",
         dv("number_line", [{"id": "t0", "type": "ticks", "name": "0",
                             "xy": [0, 0]},
                            {"id": "t1", "type": "ticks", "name": "0.7",
                             "xy": [0.7, 0]}], view={"step": "0.5"}),
         "off the step"),
        ("pin V6 a tick label printing another number", "FAIL", "V6",
         dv("coordinate_plane", [lbl("x", 1, 1), dict(lbl("x", 2, 2),
                                                      text="3")]),
         "prints 3"),
        ("pin V6 a tick label on the wrong tick", "FAIL", "V6",
         dv("coordinate_plane", [lbl("x", 1, 1), lbl("x", 2, 1.0),
                                 lbl("x", 3, 3)]), "nearer another tick"),
        ("pin V6 tick labels off the declared step", "FAIL", "V6",
         dv("coordinate_plane", [lbl("x", 1, 1), lbl("x", 2, 2)],
            view={"step": "2"}), "off the declared step"),
        ("pin V6 on_graph with no curve", "FAIL", "V6",
         dv("function_graph", [{"id": "P", "type": "point", "xy": [1, 1]}],
            [{"id": "og", "type": "on_graph", "point": "P",
              "curve": "nf"}]), "point or curve"),
        ("pin V6 two cells in one place", "FAIL", "V6",
         dv("table", [{"id": "a", "type": "cell", "row": 1, "col": 1,
                       "value": 1},
                      {"id": "b", "type": "cell", "row": 1, "col": 1,
                       "value": 1}]), "share a row and column"),
        ("pin V6 an outcome cell outside the table", "FAIL", "V6",
         dv("outcome_table", [{"id": "a", "type": "cell", "row": 3,
                               "col": 1}], data={"rows": [1], "cols": [1]}),
         "outside the table"),
        ("pin V6 a relative frequency that is not f / total", "FAIL", "V6",
         dv("frequency_table", [{"id": "a", "type": "category",
                                 "frequency": 1, "relative": "1/3"},
                                {"id": "b", "type": "category",
                                 "frequency": 1, "relative": "1/2"}],
            data={"total": 2}), "relative frequency of a"),
        ("pin V6 a tree node hanging on nothing", "FAIL", "V6",
         dv("probability_tree", [{"id": "n1", "type": "node",
                                  "parent": "zz", "p": "1"}]),
         "hangs on zz"),
        ("pin V6 an outcome listed twice", "FAIL", "V6",
         dv("sample_space", [{"id": "a", "type": "outcome", "value": "H"},
                             {"id": "b", "type": "outcome", "value": "H"}]),
         "listed twice"),
        ("pin V6 a sample space of the wrong size", "FAIL", "V6",
         dv("sample_space", [{"id": "a", "type": "outcome", "value": "H"},
                             {"id": "b", "type": "outcome", "value": "T"}],
            data={"size": 3}), "size 3"),
        ("pin V6 stages that give another count", "FAIL", "V6",
         dv("sample_space", [{"id": "a", "type": "outcome", "value": "H"},
                             {"id": "b", "type": "outcome", "value": "T"}],
            data={"stages": [2, 2]}), "stages [2, 2]"),
        ("pin V6 a Venn region of an unknown set", "FAIL", "V6",
         dv("venn", [{"id": "r", "type": "region", "in": ["Q"],
                      "count": 1}]), "names a set"),
        ("pin V6 a Venn universe that disagrees", "FAIL", "V6",
         dv("venn", [{"id": "r", "type": "region", "in": [], "count": 1}],
            data={"universe": 5}), "the universe is 5"),
        ("pin V6 a bar with no scale", "FAIL", "V6",
         dv("bar_chart", [{"id": "b", "type": "bar", "value": 1}]),
         "no scale"),
        ("pin V6 a midpoint the model's xy breaks", "FAIL", "V6", mid_off,
         "midpoint r2 does not hold"),
        ("pin D8 a figure whose SVG is missing", "FAIL", "D8",
         lambda nj, sj, dj, sv: sv.pop("q1_head"), "missing"),
        ("pin D4 a given_mark on a relation that is no given", "FAIL", "D4",
         lambda nj, sj, dj, sv: V(nj)["highlight_given"].append("r7"),
         "given_mark"),
        # S5 the views of a solid (projection_2d, unsupported, validated)
        ("S5 a front view that is not the cubes' projection", "FAIL", "V6",
         dv("projection_2d", [{"id": "vf", "type": "view", "name": "front",
                               "cells": [[0, 0], [1, 0]]}],
            data={"cubes": [[0, 0, 0], [1, 0, 0], [1, 0, 1]]}),
         "the cubes project"),
        ("S5 control: the views of three cubes", "PASS", "V6",
         dv("projection_2d", [{"id": "vf", "type": "view", "name": "front",
                               "cells": [[0, 0], [1, 0], [1, 1]]},
                              {"id": "vt", "type": "view", "name": "top",
                               "cells": [[0, 0], [1, 0]]}],
            data={"cubes": [[0, 0, 0], [1, 0, 0], [1, 0, 1]]})),
        ("S5 a view that is not front / top / side", "FAIL", "V6",
         dv("projection_2d", [{"id": "vb", "type": "view", "name": "back",
                               "cells": [[0, 0]]}],
            data={"cubes": [[0, 0, 0]]}), "is not front / top / side"),
        ("S5 a vertex view off the solid's xyz", "FAIL", "V6",
         dv("projection_2d", [{"id": "vs", "type": "view", "name": "side",
                               "points": {"A": [0, 0], "B": [1, 1]}}],
            data={"vertices": {"A": [0, 0, 0], "B": [2, 1, 0]}}),
         "puts B at"),
        # v6.7.2-noam: the find relation of the model
        ("v672 the model's find relation carries its value", "FAIL", "D12",
         lambda nj, sj, dj, sv: [r for r in V(nj)["relations"]
                                 if r.get("type") == "find"][0].update(
                                     value=10), "carries its value"),
        # r1 T4: the relation's own words carry the value
        ("v672r1 the model's find relation text states the value", "FAIL",
         "D12", lambda nj, sj, dj, sv: [r for r in V(nj)["relations"]
                                        if r.get("type") == "find"][0]
         .update(text=u"אורך AC = 10"), "a number the item's text does not"),
        ("v672r1 the model's find relation carries a numeric unit", "FAIL",
         "D12", lambda nj, sj, dj, sv: [r for r in V(nj)["relations"]
                                        if r.get("type") == "find"][0]
         .update(unit=u"10 ס\"מ"), "unit with a number"),
        ("v672 highlight_given touches the find target", "FAIL", "D12",
         lambda nj, sj, dj, sv: (V(nj)["highlight_given"].append(
             [r for r in V(nj)["relations"] if r.get("type") == "find"][0]
             ["id"]), V(nj)["actions"]["highlight"].append(
             [r for r in V(nj)["relations"] if r.get("type") == "find"][0]
             ["id"])), "highlight_given touches"),
    ] + _v672r2_vm_cases(V, O)


def _v672r2_vm_cases(V, O):
    """r2 M1 / m2: the answer on the target's own model object, or nested
    anywhere a find target / find relation / item / the root carries."""
    FR = lambda nj: [r for r in V(nj)["relations"]
                     if r.get("type") == "find"][0]

    def on_obj(key, val):
        def fn(nj, sj, dj, sv):
            FR(nj)["objects"] = ["pt-A", "pt-C"]
            O(nj, "pt-C")[key] = val
        return fn

    def seg_ac(nj, sj, dj, sv):
        V(nj)["objects"].append({"id": "seg-AC", "svg_id": "seg-AC",
                                 "type": "segment", "name": "AC",
                                 "role": "context", "display": "initial",
                                 "value": 10})
    I = lambda nj: nj["questions"][0]["items"][2]
    return [
        ("v672r2 the target's model object carries value '10'", "FAIL",
         "D12", on_obj("value", "10"), "on the object the item asks"),
        ("v672r2 the target's model object carries label '10'", "FAIL",
         "D12", on_obj("label", "10"), "on the object the item asks"),
        ("v672r2 the target's model object carries frequency 10", "FAIL",
         "D12", on_obj("frequency", 10), "on the object the item asks"),
        ("v672r2 a segment object named like the target carries 10",
         "FAIL", "D12", seg_ac, "on the object the item asks"),
        ("v672r2 control: the target's objects carry only names", "PASS",
         "D12", lambda nj, sj, dj, sv: FR(nj).update(
             objects=["pt-A", "pt-C"])),
        ("v672r2 a value nested in the find target", "FAIL", "D12",
         lambda nj, sj, dj, sv: I(nj)["to_prove"][0].update(
             meta={"v": {"value": 10}}), "nested"),
        ("v672r2 a note field on the find target", "FAIL", "D12",
         lambda nj, sj, dj, sv: I(nj)["to_prove"][0].update(
             note=u"בערך"), "a find target does not have"),
        ("v672r2 an answer on the item row", "FAIL", "D12",
         lambda nj, sj, dj, sv: I(nj).update(answer="10"),
         "the item carries 'answer'"),
        ("v672r2 the value deep in an item's extra field", "FAIL", "D12",
         lambda nj, sj, dj, sv: I(nj).update(
             extra={"a": [{"b": u"התוצאה 10"}]}), "prints the find target"),
        ("v672r2 the value in a root debug field", "FAIL", "D12",
         lambda nj, sj, dj, sv: nj.update(debug={"q1c": "10"}),
         "prints the find target"),
        ("v672r2 an extra field on the model's find relation", "FAIL",
         "D12", lambda nj, sj, dj, sv: FR(nj).update(extra={"sol": 10}),
         "a find relation does not have"),
    ]


def _write(d, nj, sj, dj, svgs):
    os.makedirs(os.path.join(d, "figures"))
    bj = (sj or {}).pop("_build_json", None)
    if bj is not None:
        with open(os.path.join(d, "build.json"), "w",
                  encoding="utf-8") as fh:
            json.dump(bj, fh)
    for name, obj in (("noam-ai.json", nj), ("sheet.json", sj),
                      ("didactic.json", dj)):
        if obj is not None:
            with open(os.path.join(d, name), "w", encoding="utf-8") as fh:
                json.dump(obj, fh, ensure_ascii=False)
    for fid, svg in svgs.items():
        with open(os.path.join(d, "figures", fid + ".svg"), "w",
                  encoding="utf-8") as fh:
            fh.write(svg)


def _cases():
    """(name, status, rule, mutate(nj, sj, dj, svgs))."""
    Q = lambda nj: nj["questions"][0]
    I = lambda nj, k: nj["questions"][0]["items"][k]
    H = lambda nj: nj["figures"][0]
    A = lambda nj: nj["figures"][1]

    def add_q2(nj, sj, dj, sv):
        q2 = json.loads(json.dumps(Q(nj)))
        q2.update(id="q2", figure_id="q2_head", items=[])
        nj["questions"].append(q2)
        f2 = json.loads(json.dumps(H(nj)))
        f2.update(id="q2_head", svg="figures/q2_head.svg", question="q2")
        nj["figures"].append(f2)
        a2 = json.loads(json.dumps(A(nj)))
        a2.update(id="q2_aux1", svg="figures/q2_aux1.svg", question="q2",
                  item=None)
        nj["figures"].append(a2)
        sv["q2_head"] = sv["q1_head"]
        sv["q2_aux1"] = sv["q1b_aux1"]
    return [
        # D1
        ("the conclusion MD = MC is also a given of the question", "FAIL",
         "D1", lambda nj, sj, dj, sv: Q(nj)["given"].append(
             {"type": "equal_length", "of": ["MC", "MD"], "text": "MC=MD"})),
        ("a given that is the item's own claim", "FAIL", "D1",
         lambda nj, sj, dj, sv: (I(nj, 0)["given"].append(
             {"type": "equal_length", "of": ["MD", "MC"]}),
             I(nj, 0).update(to_prove=[]))),
        ("control: an earlier item's result carried with from_item", "PASS",
         "D1", lambda nj, sj, dj, sv: I(nj, 2)["given"].append(
             {"type": "equal_length", "of": ["MD", "MC"],
              "from_item": "q1a", "text": "MD = MC"})),
        # D2
        ("a dashed guide line in the starting figure", "FAIL", "D2",
         lambda nj, sj, dj, sv: sv.update(q1_head=sv["q1_head"].replace(
             "</svg>", '<line id="seg-g1" x1="100" y1="100" x2="100" '
             'y2="20" stroke="#111" stroke-dasharray="4,3"/></svg>'))),
        # r1 S4: the control now has the text call BD dashed (before, a
        # bare dashed=[...] with no word in the text passed)
        ("control: the question itself calls BD dashed", "PASS", "D2",
         lambda nj, sj, dj, sv: (sv.update(q1_head=sv["q1_head"].replace(
             "</svg>", '<line id="seg-BD" x1="180" y1="100" x2="20" '
             'y2="20" stroke="#111" stroke-dasharray="4,3"/></svg>')),
             H(nj)["objects"]["segments"].append(
                 {"svg_id": "seg-BD", "kind": "segment", "name": "BD"}),
             Q(nj).update(text=Q(nj)["text"] + u" הקו BD מקווקו."),
             sj["questions"][0].update(dashed=["BD"]))),
        ("dashed=['BD'] declared, the text never calls BD dashed", "FAIL",
         "D2", lambda nj, sj, dj, sv: (sv.update(
             q1_head=sv["q1_head"].replace(
                 "</svg>", '<line id="seg-BD" x1="180" y1="100" x2="20" '
                 'y2="20" stroke="#111" stroke-dasharray="4,3"/></svg>')),
             H(nj)["objects"]["segments"].append(
                 {"svg_id": "seg-BD", "kind": "segment", "name": "BD"}),
             sj["questions"][0].update(dashed=["BD"])), "never calls"),
        ("a solid segment BD that is no side and not in the text",
         "REVIEW", "D2", lambda nj, sj, dj, sv: (sv.update(
             q1_head=sv["q1_head"].replace(
                 "</svg>", '<line id="seg-BD" x1="180" y1="100" x2="20" '
                 'y2="20" stroke="#111"/></svg>')),
             H(nj)["objects"]["segments"].append(
                 {"svg_id": "seg-BD", "kind": "segment", "name": "BD"})),
         "no side"),
        ("the diagonal AC to construct is already drawn", "FAIL", "D2",
         lambda nj, sj, dj, sv: (H(nj)["objects"]["segments"].append(
             {"svg_id": "seg-AC", "kind": "segment", "name": "AC"}),
             sv.update(q1_head=sv["q1_head"].replace(
                 "</svg>", '<line id="seg-AC" x1="20" y1="100" x2="180" '
                 'y2="20" stroke="#111"/></svg>')))),
        # D3
        ("a highlight colour", "FAIL", "D3",
         lambda nj, sj, dj, sv: sv.update(q1_head=sv["q1_head"].replace(
             'id="seg-MD" x1="100" y1="100" x2="20" y2="20" stroke="#111"',
             'id="seg-MD" x1="100" y1="100" x2="20" y2="20" '
             'stroke="#d0342c"'))),
        ("ticks that mark the goal MD = MC", "FAIL", "D3",
         lambda nj, sj, dj, sv: H(nj)["constraints"].append(
             {"type": "equal_length", "of": ["MD", "MC"],
              "status": "to_prove", "marked": True, "mark_id": "tick-MD"})),
        # D4
        ("a right-angle mark with no given (the shape is not stated)",
         "FAIL", "D4", lambda nj, sj, dj, sv: Q(nj)["given"].pop(0)),
        ("a tick that no constraint and no given accounts for", "FAIL", "D4",
         lambda nj, sj, dj, sv: H(nj)["objects"]["marks"].append(
             {"svg_id": "tick-X", "kind": "ticks"})),
        ("a given_mark on the goal", "FAIL", "D4",
         lambda nj, sj, dj, sv: H(nj)["given_marks"].append(
             {"claim": {"type": "equal_length", "of": ["MD", "MC"]},
              "mark": "ticks", "n": 2, "svg_ids": ["seg-MD", "seg-MC"]})),
        # D5
        ("a hint that states the claim to prove", "FAIL", "D5",
         lambda nj, sj, dj, sv: dj["items"]["q1a"].update(
             hint=u"שימו לב ש-MD = MC כי המשולשים חופפים")),
        ("an approved hint that holds the answer", "FAIL", "D5",
         lambda nj, sj, dj, sv: I(nj, 2).update(
             hint_mode="approved_hint",
             approved_hint=u"האלכסון יוצא 10")),
        ("a hint that names the whole construction", "FAIL", "D5",
         lambda nj, sj, dj, sv: dj["items"]["q1b"].update(
             hint=u"העבירו את AC")),
        ("a hint flagged requires_human_review", "REVIEW", "D5",
         lambda nj, sj, dj, sv: dj["items"]["q1a"].update(
             requires_human_review=True)),
        ("a hint that names the claim's points with a relation", "REVIEW",
         "D5", lambda nj, sj, dj, sv: dj["items"]["q1a"].update(
             hint=u"האם המשולשים MDA ו-MCB חופפים?")),
        # D6
        ("allowed_tools with a tool not yet taught", "FAIL", "D6",
         lambda nj, sj, dj, sv: dj["items"]["q1a"].update(
             allowed_tools=["thm.midsegment"])),
        ("a hint that uses a tool not yet taught", "FAIL", "D6",
         lambda nj, sj, dj, sv: dj["items"]["q1a"].update(
             hint=u"חשבו על קטע אמצעים")),
        ("no curriculum block", "FAIL", "D6",
         lambda nj, sj, dj, sv: nj.pop("curriculum")),
        # D7
        ("an aux figure that marks the to_prove", "FAIL", "D7",
         lambda nj, sj, dj, sv: A(nj)["constraints"].append(
             {"type": "equal_length", "of": ["MD", "MC"], "marked": True,
              "status": "derived"})),
        ("an aux figure that draws the whole construction", "FAIL", "D7",
         lambda nj, sj, dj, sv: A(nj)["objects"]["segments"].append(
             {"svg_id": "seg-AC", "kind": "segment", "name": "AC"})),
        # r1 S4: completes=True is honoured only when the step names the
        # construction; the control's step now does
        ("control: the aux step IS exactly that construction", "PASS",
         "D7", lambda nj, sj, dj, sv: (A(nj)["objects"]["segments"].append(
             {"svg_id": "seg-AC", "kind": "segment", "name": "AC"}),
             sj["figures"][1].update(completes=True),
             A(nj).update(step=u"העבירו את האלכסון AC"),
             sv.update(q1b_aux1=sv["q1b_aux1"].replace(
                 "</svg>", '<line id="seg-AC" x1="20" y1="100" x2="180" '
                 'y2="20" stroke="#111"/></svg>')))),
        ("an aux figure that prints the answer", "FAIL", "D7",
         lambda nj, sj, dj, sv: (A(nj).update(item="q1c"),
                                 sv.update(q1b_aux1=sv["q1b_aux1"].replace(
                                     ">6<", ">10<")))),
        ("completes=True on an aux whose step is another step", "FAIL",
         "D7", lambda nj, sj, dj, sv: (A(nj)["objects"]["segments"].append(
             {"svg_id": "seg-AC", "kind": "segment", "name": "AC"}),
             sj["figures"][1].update(completes=True),
             A(nj).update(step=u"שימו לב לזווית B"),
             sv.update(q1b_aux1=sv["q1b_aux1"].replace(
                 "</svg>", '<line id="seg-AC" x1="20" y1="100" x2="180" '
                 'y2="20" stroke="#111"/></svg>'))), "does not name"),
        ("an aux figure not on request", "FAIL", "D7",
         lambda nj, sj, dj, sv: A(nj).pop("reveal")),
        ("aux on 2 of 2 questions", "FAIL", "D7", add_q2),
        # D8
        ("the text names a point no figure defines", "FAIL", "D8",
         lambda nj, sj, dj, sv: I(nj, 0).update(
             text=u"הוכיחו כי MK = MC.")),
        ("a given names a point the SVG does not carry", "FAIL", "D8",
         lambda nj, sj, dj, sv: Q(nj)["given"].append(
             {"type": "parallel", "of": ["AB", "EF"]})),
        ("a relation in the text that no list classifies", "REVIEW", "D8",
         lambda nj, sj, dj, sv: Q(nj).update(
             text=u"ABCD מלבן. M אמצע AB. נתון BC = AD.")),
        # D9
        ("a construction request with no to_construct", "REVIEW", "D9",
         lambda nj, sj, dj, sv: I(nj, 1).update(to_construct=[])),
        # ---- r1 (verify_D_r1 findings) ------------------------------------
        # M2 a hint that says the claim in words
        ("M2 approved hint 'הקטעים MD ו-MC באותו אורך'", "FAIL", "D5",
         lambda nj, sj, dj, sv: (dj["items"]["q1a"].update(
             hint=u"הקטעים MD ו-MC באותו אורך", approved=True,
             approved_by="noam"), I(nj, 0).update(
                 hint_mode="approved_hint",
                 approved_hint=u"הקטעים MD ו-MC באותו אורך")), "in words"),
        ("M2 hint 'MD ארוך בדיוק כמו MC'", "FAIL", "D5",
         lambda nj, sj, dj, sv: dj["items"]["q1a"].update(
             hint=u"MD ארוך בדיוק כמו MC"), "in words"),
        ("M2 hint naming the claim's points, no relation word", "REVIEW",
         "D5", lambda nj, sj, dj, sv: dj["items"]["q1a"].update(
             hint=u"באילו משולשים נמצאים MD ו-MC?"), "claim's points"),
        # M3 the conclusion moved into given, the claim in words
        # (r2: the isosceles MDC IS MD = MC -- certain, so FAIL; it was
        # REVIEW in r1 before restated() read the isosceles wording)
        ("M3 proof text, to_prove=[], the claim as the item's given",
         "FAIL", "D10", lambda nj, sj, dj, sv: I(nj, 0).update(
             text=u"הוכיחו כי המשולש MDC שווה שוקיים.", to_prove=[],
             given=[{"type": "equal_length", "of": ["MD", "MC"],
                     "text": "MD = MC"}]), "asks to argue"),
        ("M3 proof text, to_prove=[], an own given it does not restate",
         "REVIEW", "D10", lambda nj, sj, dj, sv: I(nj, 0).update(
             text=u"הוכיחו כי המשולש MDC שווה שוקיים.", to_prove=[],
             given=[{"type": "equal_length", "of": ["AD", "BC"],
                     "text": "AD = BC"}]), "of its own"),
        # ---- r2 (verify_D_r2 findings) ------------------------------------
        # R2-M1 the construction's endpoints named apart
        ("R2-M1 hint 'חברו את A עם C' (to_construct AC)", "FAIL", "D5",
         lambda nj, sj, dj, sv: dj["items"]["q1b"].update(
             hint=u"חברו את A עם C"), "every point of the construction"),
        ("R2-M1 hint 'העבירו קטע מ-A אל C'", "FAIL", "D5",
         lambda nj, sj, dj, sv: dj["items"]["q1b"].update(
             hint=u"העבירו קטע מ-A אל C"), "every point of the construction"),
        ("R2-M1 hint 'חברו את הקודקודים הנגדיים A ו-C'", "FAIL", "D5",
         lambda nj, sj, dj, sv: (dj["items"]["q1b"].update(
             hint=u"חברו את הקודקודים הנגדיים A ו-C", approved=True,
             approved_by="noam"), I(nj, 1).update(
                 hint_mode="approved_hint",
                 approved_hint=u"חברו את הקודקודים הנגדיים A ו-C")),
         "every point of the construction"),
        ("R2-M1 hint naming A and C with no construction verb", "REVIEW",
         "D5", lambda nj, sj, dj, sv: dj["items"]["q1b"].update(
             hint=u"מה משותף ל-A ול-C?"), "construction's points"),
        ("R2-M1 control: a hint naming one vertex", "PASS", "D5",
         lambda nj, sj, dj, sv: dj["items"]["q1b"].update(
             hint=u"מאיזה קודקוד, למשל A, כדאי להתחיל?")),
        # R2-M2 the claim in given, asked with another word
        ("R2-M2 'בדקו שהמשולש MDC שווה שוקיים', given MD = MC", "FAIL",
         "D10", lambda nj, sj, dj, sv: I(nj, 0).update(
             text=u"בדקו שהמשולש MDC שווה שוקיים.", to_prove=[],
             given=[{"type": "equal_length", "of": ["MD", "MC"],
                     "text": "MD = MC"}]), "asks to argue"),
        ("R2-M2 'שכנעו ש...', given MD = MC", "FAIL", "D10",
         lambda nj, sj, dj, sv: I(nj, 0).update(
             text=u"שכנעו שהמשולש MDC שווה שוקיים.", to_prove=[],
             given=[{"type": "equal_length", "of": ["MD", "MC"],
                     "text": "MD = MC"}]), "asks to argue"),
        ("R2-M2 'האם המשולש MDC שווה שוקיים?', given MD = MC", "FAIL",
         "D10", lambda nj, sj, dj, sv: I(nj, 0).update(
             text=u"האם המשולש MDC שווה שוקיים?", to_prove=[],
             given=[{"type": "equal_length", "of": ["MD", "MC"],
                     "text": "MD = MC"}]), "asks to argue"),
        ("R2-M2 'האם MD = MC?' with MD = MC a question given", "FAIL",
         "D10", lambda nj, sj, dj, sv: (I(nj, 0).update(
             text=u"האם MD = MC?", to_prove=[]), Q(nj)["given"].append(
             {"type": "equal_length", "of": ["MD", "MC"],
              "text": "MD = MC"})), "asks to argue"),
        ("R2-M2 'בדקו ש...' and to_prove=[], no given", "REVIEW", "D10",
         lambda nj, sj, dj, sv: I(nj, 0).update(
             text=u"בדקו שהמשולש MDC שווה שוקיים.", to_prove=[]),
         # v6.7.2 item 5: the REVIEW now says why it is undecidable
         "no relation type reads"),
        ("R2-M2 the givens overlay offers an own given of such an item",
         "FAIL", "D10", lambda nj, sj, dj, sv: (I(nj, 0).update(
             text=u"בדקו שהמשולש MDC שווה שוקיים.", to_prove=[],
             given=[{"type": "equal_length", "of": ["AD", "BC"],
                     "text": "AD = BC"}]), H(nj)["given_marks"].append(
             {"claim": {"type": "equal_length", "of": ["AD", "BC"]},
              "mark": "ticks", "n": 2, "svg_ids": ["seg-AD", "seg-BC"]})),
         "givens overlay"),
        # R2-S1 the claim said with no point name / in full-width letters
        ("R2-S1 hint 'שני הקטעים ... שווים זה לזה'", "REVIEW", "D5",
         lambda nj, sj, dj, sv: dj["items"]["q1a"].update(
             hint=u"שני הקטעים היוצאים מאמצע הצלע העליונה שווים זה לזה"),
         "without naming"),
        ("R2-S1 hint in full-width letters 'ＭＤ = ＭＣ'", "FAIL", "D5",
         lambda nj, sj, dj, sv: dj["items"]["q1a"].update(
             hint=u"ＭＤ = ＭＣ"), "states the claim"),
        ("R2-S1 hint with a bidi mark 'MD\u200f = MC'", "FAIL", "D5",
         lambda nj, sj, dj, sv: dj["items"]["q1a"].update(
             hint=u"MD\u200f = MC"), "states the claim"),
        # R2-S3 a value in words
        ("R2-S3 'אורך BC הוא 7 ס\"מ' against the given BC = 6", "FAIL",
         "D8", lambda nj, sj, dj, sv: I(nj, 2).update(
             text=u"נתון AB = 8, BC = 6. אורך BC הוא 7 ס\"מ. חשבו את AC."),
         "the model says"),
        ("R2-S3 'אורך MD הוא 5' declared nowhere", "REVIEW", "D8",
         lambda nj, sj, dj, sv: Q(nj).update(
             text=u"ABCD מלבן. M אמצע AB. אורך MD הוא 5."), "in none of"),
        ("R2-S3 'הזווית MDC שווה ל-40' declared nowhere", "REVIEW", "D8",
         lambda nj, sj, dj, sv: Q(nj).update(
             text=u"ABCD מלבן. M אמצע AB. הזווית MDC שווה ל-40."),
         "in none of"),
        # R2-S4 from_item that does not hold
        ("R2-S4 from_item names no item", "FAIL", "D1",
         lambda nj, sj, dj, sv: I(nj, 2)["given"].append(
             {"type": "equal_length", "of": ["MD", "MC"], "text": "MD = MC",
              "from_item": "q7a"}), "no such item"),
        ("R2-S4 from_item names the item itself", "FAIL", "D1",
         lambda nj, sj, dj, sv: I(nj, 2)["given"].append(
             {"type": "equal_length", "of": ["MD", "MC"], "text": "MD = MC",
              "from_item": "q1c"}), "not an earlier item"),
        ("R2-S4 from_item names an item that proves something else", "FAIL",
         "D1", lambda nj, sj, dj, sv: I(nj, 2)["given"].append(
             {"type": "equal_length", "of": ["MD", "MC"], "text": "MD = MC",
              "from_item": "q1b"}), "does not prove"),
        ("R2-S4 control: from_item names the earlier item that proves it",
         "PASS", "D1", lambda nj, sj, dj, sv: I(nj, 2)["given"].append(
             {"type": "equal_length", "of": ["MD", "MC"], "text": "MD = MC",
              "from_item": "q1a"})),
        # S2 a decidable contradiction text / model
        ("S2 the text says BC = 7, the given BC = 6", "FAIL", "D8",
         lambda nj, sj, dj, sv: I(nj, 2).update(
             text=u"נתון AB = 8, BC = 7. חשבו את AC."), "the model says"),
        # m1 a mark covered by a given the text does not state
        ("m1 ticks covered by 'M אמצע AB' while the text says 'M נקודה על "
         "AB'", "REVIEW", "D4", lambda nj, sj, dj, sv: Q(nj).update(
             text=u"ABCD מלבן. M נקודה על AB."), "does not state"),
        # S1 pins: one case per check site the mutants showed unpinned
        ("pin D1: a to_prove that is a given of the question", "FAIL", "D1",
         lambda nj, sj, dj, sv: Q(nj)["given"].append(
             {"type": "equal_length", "of": ["MC", "MD"], "text": "MC=MD"}),
         "is given in"),
        ("pin D8: a lone capital that is no point (a variable?)", "REVIEW",
         "D8", lambda nj, sj, dj, sv: I(nj, 2).update(
             text=u"נתון AB = 8, BC = 6. חשבו את AC. נסמן X."), "variable"),
        # ---- r3 (verify_D_r3 findings) ------------------------------------
        ("R3-M1 the intro states the claim ('נתון: MD = MC')", "FAIL", "D11",
         lambda nj, sj, dj, sv: Q(nj).update(
             text=u"ABCD מלבן. M אמצע AB. נתון: MD = MC."), "as a fact"),
        ("R3-M1 the intro: 'המשולש MDC שווה שוקיים'", "FAIL", "D11",
         lambda nj, sj, dj, sv: Q(nj).update(
             text=u"ABCD מלבן. M אמצע AB. המשולש MDC שווה שוקיים."),
         "as a fact"),
        ("R3-M1 the item: 'נתון MD = MC. הוכיחו כי MD = MC.'", "FAIL", "D11",
         lambda nj, sj, dj, sv: I(nj, 0).update(
             text=u"נתון MD = MC. הוכיחו כי MD = MC."), "as a fact"),
        ("R3-M1 a later item restates it, no from_item", "REVIEW", "D11",
         lambda nj, sj, dj, sv: I(nj, 1).update(
             text=u"ידוע ש-MD = MC. העבירו את האלכסון AC."), "no from_item"),
        ("R3-M1 control: a later item with the from_item given", "PASS",
         "D11", lambda nj, sj, dj, sv: I(nj, 1).update(
             text=u"ידוע ש-MD = MC. העבירו את האלכסון AC.",
             given=[{"type": "equal_length", "of": ["MD", "MC"],
                     "text": "MD = MC", "from_item": "q1a"}])),
        ("R3-M2 'קבעו אם MD = MC.', to_prove=[], given MD = MC", "FAIL",
         "D10", lambda nj, sj, dj, sv: I(nj, 0).update(
             text=u"קבעו אם MD = MC.", to_prove=[],
             given=[{"type": "equal_length", "of": ["MD", "MC"],
                     "text": "MD = MC"}]), "asks to argue"),
        ("R3-M2 'נכון או לא נכון: MD = MC.', given MD = MC", "FAIL", "D10",
         lambda nj, sj, dj, sv: I(nj, 0).update(
             text=u"נכון או לא נכון: MD = MC.", to_prove=[],
             given=[{"type": "equal_length", "of": ["MD", "MC"],
                     "text": "MD = MC"}]), "asks to argue"),
        ("R3-M2 'הכריעו אם MD = MC.', given MD = MC", "FAIL", "D10",
         lambda nj, sj, dj, sv: I(nj, 0).update(
             text=u"הכריעו אם MD = MC.", to_prove=[],
             given=[{"type": "equal_length", "of": ["MD", "MC"],
                     "text": "MD = MC"}]), "asks to argue"),
        ("R3-M3 approved hint 'העבירו אלכסון מ-A' (to_construct AC)",
         "REVIEW", "D5", lambda nj, sj, dj, sv: (dj["items"]["q1b"].update(
             hint=u"העבירו אלכסון מ-A", approved=True, approved_by="noam"),
             I(nj, 1).update(hint_mode="approved_hint",
                             approved_hint=u"העבירו אלכסון מ-A")),
         "construction hint"),
        ("R3-M3 'חברו את הקודקוד השמאלי התחתון עם הימני העליון'", "REVIEW",
         "D5", lambda nj, sj, dj, sv: dj["items"]["q1b"].update(
             hint=u"חברו את הקודקוד השמאלי התחתון עם הימני העליון"),
         "construction hint"),
        ("R3-m1 approved_hint that didactic.json does not approve", "FAIL",
         "D5", lambda nj, sj, dj, sv: I(nj, 0).update(
             hint_mode="approved_hint",
             approved_hint=u"אילו משולשים כדאי להשוות?"), "does not approve"),
        ("R3-S1 the text 'AB הוא 10' against the given AB = 8", "FAIL", "D8",
         lambda nj, sj, dj, sv: I(nj, 2).update(
             text=u"נתון AB = 8, BC = 6. AB הוא 10. חשבו את AC."),
         "the model says"),
        ("R3-S1 control: 'AC = 3x + 4' is no length AC = 3", "PASS", "D8",
         lambda nj, sj, dj, sv: I(nj, 2).update(
             text=u"נתון AB = 8, BC = 6. חשבו את AC (AC = 3x + 4).")),
        ("R3-S2 hint 'השתמשו בחוק הסינוסים' (no tool for it)", "REVIEW",
         "D6", lambda nj, sj, dj, sv: dj["items"]["q1a"].update(
             hint=u"השתמשו בחוק הסינוסים"), "no allowed tool"),
        ("R3-S3 a to_prove its item's text never asks", "REVIEW", "D11",
         lambda nj, sj, dj, sv: I(nj, 2)["to_prove"].append(
             {"type": "equal_length", "of": ["MD", "MA"],
              "text": "MD = MA"}), "not asked"),
    ] + _v672_cases()


def _v672_cases():
    """v6.7.2-noam (BRIEF_V672 items 1-5): find targets, and the D10
    proof requests whose claim the relation vocabulary types."""
    I = lambda nj, k: nj["questions"][0]["items"][k]
    H = lambda nj: nj["figures"][0]

    def xy(nj):
        for o in H(nj)["objects"]["points"]:
            o["xy"] = {"A": [0, 0], "B": [10, 0], "C": [10, 6], "D": [0, 6],
                       "M": [5, 0]}[o["name"]]

    def angle_item(nj, sj, lxy):
        xy(nj)
        I(nj, 2).update(text=u"נתון AB = 8, BC = 6. חשבו את ∠BCM.",
                        to_prove=[{"type": "find", "quantity": "angle",
                                   "of": "BCM", "text": u"גודל הזווית BCM"}])
        sj["questions"][0]["items"][2]["find"] = [
            {"quantity": "angle", "of": "BCM", "value": 40}]
        H(nj)["objects"]["labels"] = [{"svg_id": "lbl-v1", "kind": "label",
                                       "role": "value", "text": u"40°",
                                       "xy": lxy}]

    def lbl_svg(sv):
        sv["q1_head"] = sv["q1_head"].replace(
            "</svg>", '<text id="lbl-v1" x="170" y="40" fill="#111">40'
            u'\u00b0</text></svg>')

    def cell_item(nj, sj, shown, role):
        nj.setdefault("visuals", []).append({
            "schema_version": "visual-model/v1", "id": "q1_table",
            "kind": "table", "visual_support": "partial", "question": "q1",
            "svg": None, "objects": [
                {"id": "q1_table-r%dc%d" % (i, j), "svg_id": None,
                 "type": "cell", "row": i, "col": j,
                 "value": {(1, 1): u"מחברות", (1, 2): "1", (1, 3): "2",
                           (2, 1): u"מחיר", (2, 2): "6"}.get((i, j), shown),
                 "role": role if (i, j) == (2, 3) else "given",
                 "display": "initial"}
                for i in (1, 2) for j in (1, 2, 3)],
            "relations": [], "highlight_given": [], "aux": [],
            "actions": {"allowed": ["show", "highlight", "show_aux"],
                        "show": ["q1_table"], "highlight": [],
                        "show_aux": []}})
        I(nj, 2).update(text=u"השלימו את הטבלה.", given=[], to_prove=[
            {"type": "find", "quantity": "cell", "of": "q1_table-r2c3",
             "text": u"התא q1_table-r2c3"}])
        sj["questions"][0]["items"][2]["find"] = [
            {"quantity": "cell", "of": "q1_table-r2c3", "value": 12}]

    def free_label(nj, sv, txt):
        H(nj)["objects"]["labels"] = [{"svg_id": "lbl-f", "kind": "label",
                                       "role": "value", "text": txt,
                                       "xy": [7, 3]}]
        sv["q1_head"] = sv["q1_head"].replace(
            "</svg>", '<text id="lbl-f" x="140" y="60" fill="#111">%s'
            '</text></svg>' % txt)

    def label_ac(nj, sj, dj, sv):
        H(nj)["objects"]["labels"] = [{"svg_id": "lbl-AC", "kind": "label",
                                       "role": "value", "text": "10",
                                       "for": "AC"}]
        sv["q1_head"] = sv["q1_head"].replace(
            "</svg>", '<text id="lbl-AC" x="100" y="60" fill="#111">10'
            '</text></svg>')
    return [
        # item 4: a compute text with no find target
        ("v672 'חשבו את AC' with to_prove=[] (STRICT)", "FAIL", "D12",
         lambda nj, sj, dj, sv: I(nj, 2).update(to_prove=[]),
         "declares no find target"),
        # r1 T1: opting out is never auto-passed
        ("v672r1 a no_target_reason is REVIEW, never PASS", "REVIEW", "D12",
         lambda nj, sj, dj, sv: (I(nj, 2).update(
             to_prove=[], no_target_reason=u"תשובה פתוחה: כל ערך מתאים"),
             dj["items"]["q1c"].update(requires_human_review=True)),
         "a human reads its no_target_reason"),
        ("v672r1 a no_target_reason didactic.json does not flag", "FAIL",
         "D12", lambda nj, sj, dj, sv: I(nj, 2).update(
             to_prove=[], no_target_reason=u"פתוח"),
         "does not flag it requires_human_review"),
        ("v672 an empty no_target_reason", "FAIL", "D12",
         lambda nj, sj, dj, sv: I(nj, 2).update(to_prove=[],
                                                no_target_reason=u"  "),
         "is empty"),
        ("v672 'מצאו את שיעורי D' with to_prove=[]", "FAIL", "D12",
         lambda nj, sj, dj, sv: I(nj, 2).update(
             text=u"מצאו את שיעורי הנקודה D.", to_prove=[], given=[]),
         "declares no find target"),
        ("v672 'כמה ...' with to_prove=[]", "FAIL", "D12",
         lambda nj, sj, dj, sv: I(nj, 2).update(
             text=u"כמה משולשים יש בשרטוט?", to_prove=[], given=[]),
         "declares no find target"),
        ("v672 'אילו הותרו שברים, כמה ...?' is still a count", "FAIL",
         "D12", lambda nj, sj, dj, sv: I(nj, 2).update(
             text=u"אילו הותרו גם שברים, כמה נקודות היו?", to_prove=[],
             given=[]), "declares no find target"),
        ("v672 control: 'הסבירו כיצד ידעתם מהו ...' asks no value", "PASS",
         "D12", lambda nj, sj, dj, sv: I(nj, 2).update(
             text=u"הסבירו כיצד ידעתם מהו אורך AC.", to_prove=[],
             given=[])),
        ("v672 a non-STRICT build: the same item is REVIEW", "REVIEW",
         "D12", lambda nj, sj, dj, sv: (I(nj, 2).update(to_prove=[]),
                                        sj.update(_build_json={
                                            "strict_figures": False})),
         "declares no find target"),
        # item 1: the vocabulary
        ("v672 a find target of an unknown quantity", "FAIL", "D12",
         lambda nj, sj, dj, sv: I(nj, 2)["to_prove"][0].update(
             quantity="size"), "not in the vocabulary"),
        ("v672 a length target naming 3 points", "FAIL", "D12",
         lambda nj, sj, dj, sv: I(nj, 2)["to_prove"][0].update(of="ACD"),
         "one segment"),
        ("v672 the find target carries its value in noam-ai.json", "FAIL",
         "D12", lambda nj, sj, dj, sv: I(nj, 2)["to_prove"][0].update(
             value=10), "carries the value"),
        ("v672 the find target's text states its value", "FAIL", "D12",
         lambda nj, sj, dj, sv: I(nj, 2)["to_prove"][0].update(
             text=u"אורך AC הוא 10"), "states its value"),
        # item 2: every object it names exists
        ("v672 a find target naming a point the model lacks", "FAIL", "D12",
         lambda nj, sj, dj, sv: I(nj, 2)["to_prove"][0].update(of="AK"),
         "does not hold"),
        ("v672 control: a variable the text declares", "PASS", "D12",
         lambda nj, sj, dj, sv: (I(nj, 2).update(
             text=u"נתון AB = 8, BC = 6, AC = $x$. חשבו את $x$.",
             to_prove=[{"type": "find", "quantity": "variable", "of": "x",
                        "text": u"ערך x"}]),
             sj["questions"][0]["items"][2].update(find=[
                 {"quantity": "variable", "of": "x", "value": 10}]))),
        ("v672 a variable nobody declares", "FAIL", "D12",
         lambda nj, sj, dj, sv: I(nj, 2).update(
             to_prove=[{"type": "find", "quantity": "variable", "of": "y",
                        "text": u"ערך y"}]), "does not hold"),
        ("v672 a table cell no model holds", "FAIL", "D12",
         lambda nj, sj, dj, sv: I(nj, 2).update(
             to_prove=[{"type": "find", "quantity": "cell", "of": "r9c9",
                        "text": u"התא r9c9"}]), "does not hold"),
        # item 3: the neutral figure
        ("v672 the figure prints 10 on AC, the find target", "FAIL", "D12",
         label_ac, "the value the item asks to find"),
        ("v672 the figure marks the length of AC", "FAIL", "D12",
         lambda nj, sj, dj, sv: H(nj)["constraints"].append(
             {"type": "length", "of": ["A", "C"], "value": 10,
              "status": "derived", "marked": True, "mark_id": "ra-A"}),
         "marks its value"),
        ("v672 an angle value label inside the target angle", "FAIL", "D12",
         lambda nj, sj, dj, sv: (angle_item(nj, sj, [9.5, 4.5]),
                                 lbl_svg(sv)), "the value the item asks"),
        # r1 T3: the control's label now prints another angle's value
        # (50°) -- a free '40°' anywhere IS the answer (the case above)
        ("v672 control: the angle label outside the target angle", "PASS",
         "D12", lambda nj, sj, dj, sv: (angle_item(nj, sj, [8.5, 5.8]),
                                        H(nj)["objects"]["labels"][0]
                                        .update(text=u"50°"),
                                        lbl_svg(sv), sv.update(
                                            q1_head=sv["q1_head"].replace(
                                                u">40\u00b0<",
                                                u">50\u00b0<")))),
        # r1 T2: a table cell target shows no number, and is no given
        ("v672r1 the table prints the value of its target cell", "FAIL",
         "D12", lambda nj, sj, dj, sv: cell_item(nj, sj, "12", "context"),
         "in the cell the item asks to find"),
        ("v672r1 the target cell is called a given", "FAIL", "D12",
         lambda nj, sj, dj, sv: cell_item(nj, sj, "?", "given"),
         "calls it a given"),
        ("v672r1 control: a blank '?' target cell (context)", "PASS", "D12",
         lambda nj, sj, dj, sv: cell_item(nj, sj, "?", "context")),
        # r1 T3: a free label (no `for`) that names or prints the value
        ("v672r1 a free label 'AC = 10' on the length target", "FAIL",
         "D12", lambda nj, sj, dj, sv: free_label(nj, sv, "AC = 10"),
         "the value the item asks to find"),
        ("v672r1 a free label '10' = the private value", "FAIL", "D12",
         lambda nj, sj, dj, sv: free_label(nj, sv, "10"),
         "the value the item asks to find"),
        ("v672r1 a free label '40°' = the angle target's value", "FAIL",
         "D12", lambda nj, sj, dj, sv: (angle_item(nj, sj, [8.5, 5.8]),
                                        H(nj)["objects"]["labels"][0]
                                        .update(xy=[1, 1]), lbl_svg(sv)),
         "the value the item asks to find"),
        # r1 T4: the public fields never carry the value
        ("v672r1 the value in the find target's unit", "FAIL", "D12",
         lambda nj, sj, dj, sv: I(nj, 2)["to_prove"][0].update(
             unit=u"10 ס\"מ"), "unit with a number"),
        ("v672r1 the value in the find target's what", "FAIL", "D12",
         lambda nj, sj, dj, sv: I(nj, 2)["to_prove"][0].update(
             what=u"התשובה 10"), "a number the item's text does not"),
        ("v672r1 control: a unit word", "PASS", "D12",
         lambda nj, sj, dj, sv: I(nj, 2)["to_prove"][0].update(
             unit=u"ס\"מ")),
        # r1 T5: the compute asks the detector used to miss
        ("v672r1 'מה אורכו של AC?' with to_prove=[]", "FAIL", "D12",
         lambda nj, sj, dj, sv: I(nj, 2).update(
             text=u"נתון AB = 8, BC = 6. מה אורכו של AC?", to_prove=[]),
         "declares no find target"),
        ("v672r1 'AC = ?' with to_prove=[]", "FAIL", "D12",
         lambda nj, sj, dj, sv: I(nj, 2).update(
             text=u"נתון AB = 8, BC = 6. AC = ?", to_prove=[]),
         "declares no find target"),
        ("v672r1 'באיזה ...?' with to_prove=[]", "FAIL", "D12",
         lambda nj, sj, dj, sv: I(nj, 2).update(
             text=u"באיזה קודקוד הזווית ישרה?", to_prove=[], given=[]),
         "declares no find target"),
        ("v672r1 'פתרו את המשוואה' with to_prove=[]", "FAIL", "D12",
         lambda nj, sj, dj, sv: I(nj, 2).update(
             text=u"פתרו את המשוואה $2x+3=7$.", to_prove=[], given=[]),
         "declares no find target"),
        ("v672r1 'אורך AC הוא ___' with to_prove=[]", "FAIL", "D12",
         lambda nj, sj, dj, sv: I(nj, 2).update(
             text=u"נתון AB = 8, BC = 6. אורך AC הוא ___ ס\"מ.",
             to_prove=[]), "declares no find target"),
        ("v672r1 control: 'אילו AC היה 12, מה היה קורה?' is hypothetical",
         "PASS", "D12", lambda nj, sj, dj, sv: I(nj, 2).update(
             text=u"הסבירו: אילו AC היה ארוך יותר, מה היה קורה לזווית?",
             to_prove=[], given=[])),
        # r1 T6: a readable D10 reason when the claim is all maths
        ("v672r1 'חשבו את $AC$. נמקו.' -- D10 says why, readably",
         "REVIEW", "D10", lambda nj, sj, dj, sv: I(nj, 2).update(
             text=u"נתון AB = 8, BC = 6. חשבו את $AC$. נמקו.",
             to_prove=[]) or sj.update(_build_json={
                 "strict_figures": False}),
         "states no claim of its own -- it computes"),
        # r1 T7: the SVG itself / an angle label tied by `for`
        ("v672r1 the value printed only in the SVG", "FAIL", "D12",
         lambda nj, sj, dj, sv: sv.update(q1_head=sv["q1_head"].replace(
             "</svg>", '<text x="100" y="60" fill="#111">10</text></svg>')),
         "SVG prints"),
        ("v672r1 an angle value label tied to the target by for", "FAIL",
         "D12", lambda nj, sj, dj, sv: (angle_item(nj, sj, [1, 1]),
                                        H(nj)["objects"]["labels"][0]
                                        .update(**{"for": "BCM"}),
                                        lbl_svg(sv)),
         "the value the item asks to find"),
        # item 5: D10 -- typable claims are typed, REVIEW says why
        ("v672 'הוכיחו כי MD = MC' with to_prove=[] is typable", "FAIL",
         "D10", lambda nj, sj, dj, sv: I(nj, 0).update(to_prove=[]),
         "is typable"),
        ("v672 a sum of angles is no typed relation: REVIEW, not FAIL",
         "REVIEW", "D10", lambda nj, sj, dj, sv: I(nj, 0).update(
             text=u"הוכיחו כי $\\angle{AMD} = \\angle{MDC} + "
             u"\\angle{DCM}$.", to_prove=[]), "no relation type reads"),
        ("v672 'האם MD = MC?' with to_prove=[] stays REVIEW (yes/no)",
         "REVIEW", "D10", lambda nj, sj, dj, sv: I(nj, 0).update(
             text=u"האם MD = MC?", to_prove=[]), "yes/no question"),
        # r2 M2: a find target sheet.json keeps no value for
        ("v672r2 a find target with no private value", "FAIL", "D12",
         lambda nj, sj, dj, sv: sj["questions"][0]["items"][2].pop("find"),
         "keeps no private value"),
        # r2 S2: the free-label branch of f_labels, each half pinned
        ("v672r2 a free label 'AC = 7' names the target", "FAIL", "D12",
         lambda nj, sj, dj, sv: free_label(nj, sv, "AC = 7"),
         "the value the item asks to find"),
        ("v672r2 a free label '10' in the JSON only (no SVG text)", "FAIL",
         "D12", lambda nj, sj, dj, sv: H(nj)["objects"].update(labels=[
             {"svg_id": "lbl-f", "kind": "label", "role": "value",
              "text": "10", "xy": [7, 3]}]),
         "the value the item asks to find"),
        # r2 m1 / S1: compute asks the detector used to miss
        ("v672r2 'באיזה קודקוד ...' with no '?' and to_prove=[]", "FAIL",
         "D12", lambda nj, sj, dj, sv: I(nj, 2).update(
             text=u"רשמו באיזה קודקוד הזווית ישרה.", to_prove=[],
             given=[]), "declares no find target"),
        ("v672r2 'רשמו את התוצאה' with to_prove=[]", "FAIL", "D12",
         lambda nj, sj, dj, sv: I(nj, 2).update(
             text=u"נתון AB = 8, BC = 6. רשמו את התוצאה.", to_prove=[]),
         "declares no find target"),
        ("v672r2 'מי מהמספרים גדול יותר?' with to_prove=[]", "FAIL", "D12",
         lambda nj, sj, dj, sv: I(nj, 2).update(
             text=u"מי מהמספרים גדול יותר?", to_prove=[], given=[]),
         "declares no find target"),
        ("v672r2 'איזה ... 0.5 או 0.45?' with to_prove=[]", "FAIL", "D12",
         lambda nj, sj, dj, sv: I(nj, 2).update(
             text=u"איזה מספר גדול יותר, 0.5 או 0.45?", to_prove=[],
             given=[]), "declares no find target"),
        ("v672r2 control: 'מי צודק? נמקו.' asks no value", "PASS", "D12",
         lambda nj, sj, dj, sv: I(nj, 2).update(
             text=u"מי צודק? נמקו.", to_prove=[], given=[])),
        ("v672 an undecidable D10 carries the author's note", "REVIEW",
         "D10", lambda nj, sj, dj, sv: (I(nj, 0).update(
             text=u"הוכיחו כי המשולש MDC שווה שוקיים.", to_prove=[]),
             dj["items"]["q1a"].update(note=u"שוקיים לפי ההגדרה")),
         u"note: שוקיים לפי ההגדרה"),
    ]


def run_fixtures():
    tmp = tempfile.mkdtemp(prefix="didchk_")
    tools = _tools()
    ok, n = True, 0
    # a case may name a 5th element: a fragment its finding must carry, so
    # each check site is pinned by a case of its own (r1 S1)
    cases = [(c[0], c[1], c[2], c[3], False, (c[4:] or [None])[0])
             for c in _cases()] + \
        [(c[0], c[1], c[2], c[3], True, (c[4:] or [None])[0])
         for c in _vm_cases()]
    try:
        p = os.path.join(tmp, "pass")
        nj, sj, dj, sv = fixture()
        _write(p, _to_vm(nj), sj, dj, sv)
        F, _r = check_level(p, tools)
        n += 1
        good = not F
        print("  %-66s %s %s" % ("PASS fixture: a clean rectangle level",
                                 "PASS" if good else "FAIL",
                                 "" if good else F[:3]))
        ok = ok and good
        # r2 m1: no curriculum_tools.json -> said as REVIEW D6, never silent
        F, _r = check_level(p, {})
        n += 1
        good = any(s_ == "REVIEW" and r_ == "D6" and "not found" in t_
                   for s_, r_, _i, t_ in F)
        print("  %-66s %s %s" % ("REVIEW fixture (D6): R2-m1 no tool "
                                 "registry beside the checker",
                                 "PASS" if good else "FAIL",
                                 "" if good else F[:3]))
        ok = ok and good
        for k, (name, want, rule, fn, after, frag) in enumerate(cases):
            nj, sj, dj, sv = fixture()
            if after:
                _to_vm(nj)
                fn(nj, sj, dj, sv)
            else:
                fn(nj, sj, dj, sv)
                _to_vm(nj)
            p = os.path.join(tmp, "c%d" % k)
            _write(p, nj, sj, dj, sv)
            F, _r = check_level(p, tools)
            if want == "PASS":
                good = not any(s == "FAIL" or r == rule
                               for s, r, _i, _t in F)
            else:
                good = any(s == want and r == rule and
                           (frag is None or frag in t)
                           for s, r, _i, t in F)
                if want == "REVIEW":
                    good = good and not any(s == "FAIL" for s, _r, _i, _t
                                            in F)
            n += 1
            print("  %-66s %s %s" % (("%s fixture (%s): %s" % (
                want, rule, name))[:66], "PASS" if good else "FAIL",
                "" if good else F[:3]))
            ok = ok and good
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print("check_didactic fixtures: %d checks, %s"
          % (n, "ALL PASS" if ok else "FAILURES"))
    return ok


if __name__ == "__main__":
    if len(sys.argv) > 1:
        worst = 0
        tools = _tools()
        for d in sys.argv[1:]:
            cnt, _F = report(d, tools)
            worst = max(worst, 1 if cnt["FAIL"] else
                        (2 if cnt["REVIEW"] else 0))
        sys.exit(worst)
    sys.exit(0 if run_fixtures() else 1)
