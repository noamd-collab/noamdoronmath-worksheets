# -*- coding: utf-8 -*-
"""Independent verifier of a v6.5 deliverable level (no skill imports).

Reads sheet.json + figures/*.svg with xml.etree, accumulates transforms, and
checks per figure:
  O1 every object's id exists exactly once in the SVG
  O2 the id's element sits at the claimed svg_xy (<= TOL px)
  O3 an id on the invisible ids layer is corroborated by visible ink
  O4 xy maps to svg_xy through view.data_to_svg (when both given)
  C1 every constraint re-measured on the SVG coordinates (v6.8 final: a
     constraint this file cannot measure is an ERROR, not a note)
  C2 a to_prove constraint is not marked (flag false, no mark id in SVG)
  F1 every file in build.json hashes to its recorded value
v6.8 (BRIEF_V68 G1 G2 G8 G9):
  I1 every exported id is ON INK: its element (or the <g> wrapping it) has
     visible ink within 1 px of each point of its svg_xy (a mark, a label, an
     arc: ink of its own at all). An empty anchor -- a <g/> with nothing in
     it, the ids layer -- fails.
  R1 every figures/<id>.py marked code_runnable is RE-RUN (the skill on
     WORKSHEET_SKILL_DIR, or this file's own folder) and its output must be
     byte-identical to figures/<id>.svg.
  N1 noam-ai.json: exists; no "answer" key at any depth; no code paths; every
     referenced SVG exists; every svg_id in it occurs exactly once in its SVG;
     every question and item carries given/to_prove (lists) and figure;
     package is G<grade>-T<nn> and level one of a, b, c (sheet.json agrees).
  N3 every numeric label (noam-ai.json and sheet.json) carries `for`, the
     id of an object of its own figure (G6). sheet.json rows carry
     given/to_prove lists too.
  H3 (v6.10 fix r2) every given the overlay can mark (a typed given claim
     of a row the figure serves, not carried, whose points the figure
     shows) is a given relation offered in highlight_given and
     actions.highlight -- not only a typed shape's statements (C3)
  N4 (v6.10 fix r2) a numeric label names (`for`) the object whose given /
     context value it prints ('14' for AB: a given AB = 14); its copies in
     sheet.json, the visual_model and an aux patch carry `for` and name the
     same object
  W1 (v6.10 fix r2) wspec/public_spec.json's texts are the texts sheet.json
     and noam-ai.json print, and it is the public model the skill's engine
     re-derives from source/level_spec.json (the spec the build used)
  N2 given several level folders: one package, and a/b/c all present when
     three are given.
v6.8 r2:
  R1 every figure must be code_runnable (a figure flagged false is an error,
     so one JSON flag cannot switch the byte check off).
  B1 build.json records strict_figures True and strict_figures_declared True
     (the contract requires STRICT_FIGURES = True).
  I1 a right_angle carries ink_xy, the corner of its L, on its ink; a label
     that carries ink_box has its text anchor inside it.
  X1 a constraint with space=True is re-measured on the xyz of its points
     (each a point of the SVG); X2 the points' xyz in a figure are one affine
     picture of their svg_xy (1 px), so an xyz cannot say one thing while
     the drawing says another.
  S1 each figure inlined in sheet.html (the document the PDF was printed
     from; ids prefixed <fid>__) is the same drawing as figures/<fid>.svg:
     same elements, same geometry to 0.01 px.
v6.9:
  V1 (fix r1) a visual_model object's parts draw it: a segment's strokes
     carry its ends, an angle's its vertex + an arm point, a polygon's a side.
     (fix r2, C1r) a part's span names the object's OWN points: a segment's
     span lies on the segment, an angle's is [vertex, X] with X on one of
     its rays, a polygon's lies on one side.
  B2 (fix r1) build.json with engine figures carries checks.g79_spec
     approved, OCR on, every engine figure PASS (or ACCEPTED with a reason).
     (fix r2, E2r) "engine figures" is what the package SHIPS
     (figures/*.map.json, wspec/public_spec.json), not only what build.json
     declares: deleting 'wspec' from build.json no longer skips B2.
  O2 a right-angle mark drawn as its own L (a <polyline>/<path>, the wspec
     engine's) sits at its claimed vertex when the L's square closes on it
     (1 px) -- the I1 closure test, applied to O2 as well.
v6.11 fix r1 (the author's wording decisions, APPROVALS_NOAM.json):
  G81 no angle named by its vertex alone (∠A, "זווית A") in sheet.json,
     noam-ai.json or sheet.html's text (anglenames.py of the skill); each
     error names the three-letter form.
v6.11 (Codex v6.10 review, NEW-1):
  G80 the PRINTED sheet.pdf is bound to sheet.json block by block
     (textbind.py): the HTML block of every question / item row is emitted
     from its text, sheet.html is rendered again and each block's text layer
     and raster -- drawn maths included -- must be the sheet.pdf's; the
     rest of each page too. FAIL and REVIEW are errors.
v6.10 (Codex v6.9 review, BRIEF_V610 part 1):
  V2 (C1r2) the UNION of what highlighting a visual_model segment / angle
     / polygon paints -- its parts after span limits, or its svg_id element
     -- is the object: no extra ink, no missing piece, an angle's sector
     shown (the same block as tools/highlight.py and
     selfcheck_noam_package.py K17). Hash-consistent tampering fails.
  E3 (E2) the object maps an engine figure needs are derived from the
     figure list (build.json wspec.figures, sheet.json entries, the
     wspec.render scripts, the engine SVG dialect, the model's engine
     objects) -- not from the map files present or the hash list; each is
     THE figure's map: figure id, engine, public_hash, the SVG's element
     ids and tags, the model's parts, and re-rendered from the public spec
     byte for byte.
  E4 (integrate) a spec question's rows in sheet.json and noam-ai.json
     say what the public spec says: its given lines (none added, none
     dropped; released ones from earlier items), its targets, its
     to_construct lines (a construction target or an unnamed cline). The
     new text-only relations (linear, greater, ...) cannot be re-measured,
     so this binds them.
v6.7-noam:
  I1 a tick / chevron / arc mark carries ink_xy on its own strokes (its
     svg_xy is what it marks).
  M1 every printed mark is named by a marked constraint (mark_id or, for a
     group, mark_ids).
  N1 noam-ai.json carries no answer / solution / hint / code / source /
     hash / built_at / internal key, no path or 40/64-hex value, and each
     question and item has figure_id.
usage: python3 verify_export.py <level_dir> [...]
       (python3 verify_export.py out/deliver/a out/deliver/b out/deliver/c)
"""
import hashlib
import json
import math
import os
import re
import subprocess
import sys
import xml.etree.ElementTree as ET

TOL = 1.0
NS = "{http://www.w3.org/2000/svg}"
NUM = re.compile(r"-?\d*\.?\d+(?:[eE][-+]?\d+)?")



# (v6.10 fix r1, s2) a NUMBER printed in a figure: digits (a sign, a
# fraction, a decimal, a root) with or without its unit -- '48°', '6 ס״מ',
# '6√2' are numbers too (N3 matched digits alone, so a degree value never
# had to name its object)
_NUM_LABEL = re.compile(u"^[\u2212\\-]?[\\d.,/\u2212\\-]*\\d[\\d.,/]*$")
_UNIT_TAIL = re.compile(u"\\s*(?:\u00b0|\u2032|ס\"מ|ס\u05f4מ|סמ\"ר|"
                        u"סמ\u05f4ר|cm|%)$")


def numeric_label(t):
    t = _UNIT_TAIL.sub(u"", str(t or u"").strip())
    t = t.replace(u"\u221a", u"")
    return bool(_NUM_LABEL.match(t))

def mat_mul(m, n):
    a, b, c, d, e, f = m
    A, B, C, D, E, F = n
    return (a * A + c * B, b * A + d * B, a * C + c * D, b * C + d * D,
            a * E + c * F + e, b * E + d * F + f)


def parse_tf(s):
    m = (1, 0, 0, 1, 0, 0)
    for name, args in re.findall(r"(\w+)\s*\(([^)]*)\)", s or ""):
        v = [float(x) for x in NUM.findall(args)]
        if name == "translate":
            t = (1, 0, 0, 1, v[0], v[1] if len(v) > 1 else 0)
        elif name == "scale":
            t = (v[0], 0, 0, v[1] if len(v) > 1 else v[0], 0, 0)
        elif name == "matrix":
            t = tuple(v)
        elif name == "rotate":
            r = math.radians(v[0])
            t = (math.cos(r), math.sin(r), -math.sin(r), math.cos(r), 0, 0)
            if len(v) == 3:
                t = mat_mul(mat_mul((1, 0, 0, 1, v[1], v[2]), t),
                            (1, 0, 0, 1, -v[1], -v[2]))
        else:
            continue
        m = mat_mul(m, t)
    return m


def ap(m, p):
    return (m[0] * p[0] + m[2] * p[1] + m[4], m[1] * p[0] + m[3] * p[1] + m[5])


def tag(el):
    return el.tag.replace(NS, "")


def path_pts(d):
    # absolute M/L/H/V/Z/C/Q/A best effort: collect end points
    pts, cur = [], (0.0, 0.0)
    toks = re.findall(r"[MLHVZCQASTmlhvzcqast]|" + NUM.pattern, d or "")
    cmd, i = None, 0
    while i < len(toks):
        t = toks[i]
        if re.match(r"[A-Za-z]", t):
            cmd = t
            i += 1
            if cmd in "Zz":
                continue
            continue
        n = {"M": 2, "L": 2, "T": 2, "H": 1, "V": 1, "C": 6, "S": 4, "Q": 4,
             "A": 7}[cmd.upper()]
        v = [float(x) for x in toks[i:i + n]]
        i += n
        rel = cmd.islower()
        if cmd.upper() == "H":
            cur = (v[0] + (cur[0] if rel else 0), cur[1])
        elif cmd.upper() == "V":
            cur = (cur[0], v[0] + (cur[1] if rel else 0))
        else:
            x, y = v[-2], v[-1]
            cur = (x + cur[0], y + cur[1]) if rel else (x, y)
        pts.append(cur)
    return pts


class Svg(object):
    def __init__(self, path):
        self.root = ET.parse(path).getroot()
        self.parent = dict((c, p) for p in self.root.iter() for c in p)
        self.ids = {}
        self.dup = set()
        self.ink_pts, self.ink_segs, self.discs = [], [], []
        self.marks = set()
        self.dashed = {}
        self._walk(self.root, (1, 0, 0, 1, 0, 0), False, False)
        for i, (el, m, idl) in self.ids.items():
            self.dashed[i] = self.dashed.get(i, False) or any(
                bool(ch.get("stroke-dasharray")) or
                "dasharray" in (ch.get("style") or "") for ch in el.iter())

    def geom(self, el, m):
        t = tag(el)
        g = lambda k: float(el.get(k, 0))
        if t == "circle":
            return "c", [ap(m, (g("cx"), g("cy")))], g("r") * math.hypot(m[0], m[1])
        if t == "line":
            return "l", [ap(m, (g("x1"), g("y1"))), ap(m, (g("x2"), g("y2")))], 0
        if t == "text":
            return "t", [ap(m, (g("x"), g("y")))], 0
        if t in ("polygon", "polyline"):
            v = [float(x) for x in NUM.findall(el.get("points", ""))]
            return "p", [ap(m, q) for q in zip(v[0::2], v[1::2])], 0
        if t == "path":
            return "p", [ap(m, q) for q in path_pts(el.get("d"))], 0
        if t == "rect":
            x, y, w, h = g("x"), g("y"), g("width"), g("height")
            return "p", [ap(m, q) for q in [(x, y), (x + w, y), (x + w, y + h), (x, y + h)]], 0
        return None, [], 0

    def _walk(self, el, m, idlayer, dash):
        m = mat_mul(m, parse_tf(el.get("transform")))
        dash = dash or bool(el.get("stroke-dasharray")) or \
            "dasharray" in (el.get("style") or "")
        if el.get("class") == "ids":
            idlayer = True
        i = el.get("id")
        if i:
            if i in self.ids:
                self.dup.add(i)
            self.ids[i] = (el, m, idlayer)
            self.dashed[i] = dash
        if not idlayer and tag(el) != "g":
            k, pts, r = self.geom(el, m)
            vis = not (el.get("stroke") == "none" and el.get("fill", "none") == "none")
            if vis and k:
                if k == "c":
                    self.discs.append((pts[0], r))
                else:
                    self.ink_pts += pts
                    for a, b in zip(pts, pts[1:]):
                        self.ink_segs.append((a, b))
                    if k == "p" and len(pts) > 2:
                        self.ink_segs.append((pts[-1], pts[0]))
                        xs = [q[0] for q in pts]
                        ys = [q[1] for q in pts]
                        self.ink_pts.append((sum(xs) / len(xs), sum(ys) / len(ys)))
        for ch in el:
            self._walk(ch, m, idlayer, dash)

    def element_pts(self, i):
        """svg points an id stands for: its own geometry, a group's children,
        or an ids-layer anchor's data-xy."""
        el, m, idl = self.ids[i]
        if el.get("data-xy") is not None:
            v = [float(x) for x in NUM.findall(el.get("data-xy"))]
            return "anchor", [ap(m, q) for q in zip(v[0::2], v[1::2])]
        if tag(el) == "g":
            pts = []
            for ch in el.iter():
                if ch is el:
                    continue
                k, p, _ = self.geom(ch, m if True else None)
                pts += p
            return "group", pts
        k, p, _ = self.geom(el, m)
        return k, p

    def ink_at(self, p, tol=TOL):
        for q in self.ink_pts:
            if math.hypot(p[0] - q[0], p[1] - q[1]) <= tol:
                return True
        for a, b in self.ink_segs:
            if segdist(p, a, b) <= tol:
                return True
        for c, r in self.discs:
            d = math.hypot(p[0] - c[0], p[1] - c[1])
            if abs(d - r) <= tol or (r <= 4.5 and d <= r + tol):
                return True
        return False


def segdist(p, a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    L = dx * dx + dy * dy
    t = 0 if L == 0 else max(0, min(1, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / L))
    return math.hypot(p[0] - a[0] - t * dx, p[1] - a[1] - t * dy)


def near(p, q, tol=TOL):
    return math.hypot(p[0] - q[0], p[1] - q[1]) <= tol


def flat(v):
    if not v:
        return []
    if isinstance(v[0], (int, float)):
        return [tuple(v)]
    return [tuple(q) for q in v]


def oid(o):
    """The object's SVG id: `svg_id` (the spec's name, v6.6), or the v6.5
    `id`."""
    return o.get("svg_id") or o.get("id")


def _native_square_centre(svg, sid):
    """Centre of the actual four-corner closed native square, or None."""
    el = svg.ids[sid][0]
    if tag(el) != "path":
        return None
    commands = re.findall(r"[A-DF-Za-df-z]", el.get("d", ""))
    kind, corners = svg.element_pts(sid)
    if commands != ["M", "L", "L", "L", "Z"] or len(corners) != 4:
        return None
    xs, ys = sorted(set(x for x, y in corners)), sorted(set(y for x, y in corners))
    if len(xs) != 2 or len(ys) != 2 or set(corners) != {(x, y) for x in xs for y in ys}:
        return None
    if any((a[0] == b[0]) == (a[1] == b[1])
           for a, b in zip(corners, corners[1:] + corners[:1])):
        return None  # no diagonal, repeated vertex, or self-crossing order
    if abs(xs[1] - xs[0] - (ys[1] - ys[0])) > 0.01:
        return None
    return ((xs[0] + xs[1]) / 2, (ys[0] + ys[1]) / 2)


def check_object(svg, o, errs, fid):
    i = oid(o)
    if not i or i not in svg.ids:
        errs.append("%s O1 missing id %s" % (fid, i))
        return
    if i in svg.dup:
        errs.append("%s O1 duplicate id %s" % (fid, i))
    claim = flat(o.get("svg_xy"))
    if not claim:
        return
    k, pts = svg.element_pts(i)
    if not pts:
        errs.append("%s O2 %s has no geometry" % (fid, i))
        return
    if o.get("kind") == "right_angle" and k == "p":
        # v6.9: a right-angle mark DRAWN as its L (the wspec engine's
        # polyline, not an anchor): its svg_xy is the vertex it marks, which
        # is by design not on the L -- the claim holds exactly when the L's
        # square closes on it (the I1 closure test, 1 px); nothing looser
        err = _ra_closure(list(zip(pts, pts[1:])), claim[0]) \
            if len(claim) == 1 else None
        ok = err is not None and err <= TOL
    elif k == "c" or k == "t":
        ok = len(claim) == 1 and near(claim[0], pts[0])
    elif o.get("kind") == "point" and o.get("marker") == "square":
        centre = _native_square_centre(svg, i)
        ok = len(claim) == 1 and centre is not None and near(claim[0], centre)
    elif k in ("l", "anchor") and len(claim) == len(pts):
        ok = all(near(a, b) for a, b in zip(claim, pts)) or \
            all(near(a, b) for a, b in zip(claim, pts[::-1])) or \
            (len(claim) > 2 and all(any(near(a, b) for b in pts) for a in claim))
    else:
        # polygon / group / path: every claimed point is a vertex or on ink of the element
        segs = list(zip(pts, pts[1:])) + ([(pts[-1], pts[0])] if len(pts) > 2 else [])
        ok = all(any(near(c, q) for q in pts) or
                 any(segdist(c, a, b) <= TOL for a, b in segs) for c in claim)
    if not ok:
        errs.append("%s O2 %s claimed %s element %s %s" % (fid, i, claim[:3], k, [tuple(round(x, 2) for x in q) for q in pts[:3]]))
    if k == "anchor":
        kind = o.get("kind", "")
        if kind in ("ticks", "parallel", "mark", "equal_ticks") and len(claim) >= 2:
            good = any(svg.ink_at((a[0] + (b[0] - a[0]) * t / 20.0, a[1] + (b[1] - a[1]) * t / 20.0))
                       for a, b in zip(claim, claim[1:]) for t in range(21))
        else:
            good = all(svg.ink_at(c) for c in claim)
        if not good:
            errs.append("%s O3 %s (%s) anchor not on visible ink" % (fid, i, kind))


# ---------------------------------------------------------------- v6.8 I1 --
INK_KINDS_AT = ("point", "segment", "polygon", "dimension", "circle",
                "marker", "line", "ray")


def _visible(el, inh):
    st = dict(inh)
    for k in ("stroke", "fill", "stroke-width", "opacity"):
        if el.get(k) is not None:
            st[k] = el.get(k)
    for kv in (el.get("style") or "").split(";"):
        if ":" in kv:
            k, v = kv.split(":", 1)
            st[k.strip()] = v.strip()
    return st


def _painted(col):
    return col is not None and col.strip().lower() not in ("none",
                                                           "transparent")


def subtree_ink(svg, el, m):
    """(segments, discs, closed polygons, texts) of the VISIBLE ink an
    element and its children draw, in SVG coordinates."""
    segs, discs, polys, texts = [], [], [], []

    def walk(e, mm, inh):
        mm = mat_mul(mm, parse_tf(e.get("transform"))) if e is not el else mm
        st = _visible(e, inh)
        t = tag(e)
        if t in ("defs", "clipPath", "mask", "title", "desc"):
            return
        if t == "text":
            if (e.text or "").strip() or len(list(e)):
                texts.append(ap(mm, (float(e.get("x", 0)),
                                     float(e.get("y", 0)))))
            return
        if t != "g":
            stroke = _painted(st.get("stroke")) and \
                float(NUM.findall(st.get("stroke-width") or "1")[0]) > 0
            fill = (st.get("fill") is None or _painted(st.get("fill"))) \
                if t != "line" else False
            if st.get("opacity") is not None and \
                    float(NUM.findall(st["opacity"])[0]) == 0:
                stroke = fill = False
            k, pts, r = svg.geom(e, mm)
            if k == "c" and (stroke or fill):
                discs.append((pts[0], r, fill))
            elif k in ("l", "p") and (stroke or fill) and pts:
                closed = t in ("polygon", "rect") or (
                    t == "path" and "z" in (e.get("d") or "").lower())
                if stroke or t == "line":
                    for a, b in zip(pts, pts[1:]):
                        segs.append((a, b))
                    if closed and len(pts) > 2:
                        segs.append((pts[-1], pts[0]))
                    if len(pts) == 1:
                        segs.append((pts[0], pts[0]))
                if closed and len(pts) > 2:
                    polys.append(pts)
        for ch in e:
            walk(ch, mm, st)
    chain, a = [], svg.parent.get(el)
    while a is not None:
        chain.append(a)
        a = svg.parent.get(a)
    inh = {}
    for a in reversed(chain):
        inh = _visible(a, inh)
    walk(el, m, inh)
    return segs, discs, polys, texts


def _in_poly(p, pts):
    x, y, inside = p[0], p[1], False
    for (x1, y1), (x2, y2) in zip(pts, pts[1:] + pts[:1]):
        if (y1 > y) != (y2 > y) and \
                x < (x2 - x1) * (y - y1) / ((y2 - y1) or 1e-12) + x1:
            inside = not inside
    return inside


def _ra_closure(segs, v):
    """The distance from `v` to the point the L of a right-angle mark closes
    its square on (two strokes sharing one corner), or None if it is not
    such an L."""
    ss = [(a, b) for a, b in segs if math.hypot(a[0] - b[0], a[1] - b[1]) > 1e-6]
    if len(ss) < 2:
        return None
    best = None
    for j, (a1, b1) in enumerate(ss):
        for a2, b2 in ss[j + 1:]:
            for q1, e1 in ((a1, b1), (b1, a1)):
                for q2, e2 in ((a2, b2), (b2, a2)):
                    if math.hypot(q1[0] - q2[0], q1[1] - q2[1]) > 0.05:
                        continue
                    p = (e1[0] + e2[0] - q1[0], e1[1] + e2[1] - q1[1])
                    d = math.hypot(p[0] - v[0], p[1] - v[1])
                    best = d if best is None else min(best, d)
    return best


def check_on_ink(svg, o, errs, fid):
    """I1: the object's own element carries ink where the object is."""
    i = oid(o)
    if not i or i not in svg.ids:
        return
    el, m, idl = svg.ids[i]
    if idl or (tag(el) == "g" and len(list(el)) == 0):
        errs.append("%s I1 %s is an EMPTY anchor (no ink of its own)"
                    % (fid, i))
        return
    segs, discs, polys, texts = subtree_ink(svg, el, m)
    if not (segs or discs or polys or texts):
        errs.append("%s I1 %s carries no visible ink" % (fid, i))
        return
    kind = o.get("kind", "")
    c0 = (flat(o.get("svg_xy")) or [None])[0]
    if kind == "right_angle" and c0 is not None:
        # v6.8 r1 (I1-right-angle-svg_xy-off-ink): a right-angle mark leaves
        # its vertex bare by design; its svg_xy is the vertex it marks. The
        # ink must be the L whose square (parallelogram, in a projection)
        # closes ON svg_xy: free end + free end - corner = svg_xy, 1 px
        err = _ra_closure(segs, c0)
        if err is None or err > TOL:
            errs.append("%s I1 %s (right_angle): its L %s (%.2f, %.2f)"
                        % (fid, i, "does not close within %g px of" % TOL
                           if err is not None else "is not an L at",
                           c0[0], c0[1]))
        # v6.8 r2: ink_xy, the L's corner, is where its ink IS (1 px)
        q = o.get("ink_xy")
        if not q:
            errs.append("%s I1 %s (right_angle) has no ink_xy" % (fid, i))
        elif not any(segdist(q, a, b) <= TOL for a, b in segs):
            errs.append("%s I1 %s (right_angle) has no ink within %g px of "
                        "its ink_xy (%.2f, %.2f)" % (fid, i, TOL, q[0], q[1]))
        return
    if kind in ("ticks", "parallel", "arc") and o.get("role") == "mark":
        # v6.7-noam (R3-mark-svg_xy-off-ink): a tick / chevron / arc mark's
        # svg_xy is what it marks (the edge, the vertex); ink_xy is a point
        # ON its own strokes, 1 px
        q = o.get("ink_xy")
        if not q:
            errs.append("%s I1 %s (%s) has no ink_xy" % (fid, i, kind))
        elif not (any(segdist(q, a, b) <= TOL for a, b in segs) or
                  any(abs(math.hypot(q[0] - c[0], q[1] - c[1]) - r) <= TOL
                      or (f and math.hypot(q[0] - c[0], q[1] - c[1]) <=
                          r + TOL) for c, r, f in discs) or
                  any(_in_poly(q, P) for P in polys)):
            errs.append("%s I1 %s (%s) has no ink within %g px of its "
                        "ink_xy (%.2f, %.2f)" % (fid, i, kind, TOL, q[0],
                                                 q[1]))
        return
    if kind == "label" and c0 is not None and texts:
        # v6.8 r1: a label's svg_xy is its text's anchor, to 1 px
        if min(math.hypot(c0[0] - t[0], c0[1] - t[1]) for t in texts) > TOL:
            errs.append("%s I1 %s (label) has no text anchored within %g px "
                        "of (%.2f, %.2f)" % (fid, i, TOL, c0[0], c0[1]))
        b = o.get("ink_box")
        if b and not (b[0] - TOL <= c0[0] <= b[2] + TOL and
                      b[1] - TOL <= c0[1] <= b[3] + TOL):
            errs.append("%s I1 %s (label) is anchored at (%.2f, %.2f), "
                        "outside its ink_box %s" % (fid, i, c0[0], c0[1], b))
        return
    if kind not in INK_KINDS_AT:
        return
    for c in flat(o.get("svg_xy")):
        ok = any(segdist(c, a, b) <= TOL for a, b in segs) or \
            any(abs(math.hypot(c[0] - q[0], c[1] - q[1]) - r) <= TOL or
                (r <= 4.5 or f) and math.hypot(c[0] - q[0], c[1] - q[1]) <= r + TOL
                for q, r, f in discs) or \
            any(_in_poly(c, P) for P in polys if kind in ("point", "marker")) or \
            any(segdist(c, P[j], P[(j + 1) % len(P)]) <= TOL
                for P in polys for j in range(len(P)))
        if not ok and kind == "circle":
            ok = bool(discs)
        if not ok:
            errs.append("%s I1 %s (%s) has no ink within %g px of (%.2f, %.2f)"
                        % (fid, i, kind, TOL, c[0], c[1]))
            return


# ---------------------------------------------------------------- v6.8 R1 --
def skill_dir():
    d = os.environ.get("WORKSHEET_SKILL_DIR")
    if d and os.path.isfile(os.path.join(d, "figkit.py")):
        return os.path.abspath(d)   # v6.8 r1: scripts run in the level
    here = os.path.dirname(os.path.abspath(__file__))
    return here if os.path.isfile(os.path.join(here, "figkit.py")) else None


def rerun(level, F, errs):
    """R1: run figures/<id>.py and compare its output with the file."""
    if not F.get("code_runnable"):
        # v6.8 r2: contract rule 8 -- EVERY figure's .py reproduces its SVG
        errs.append("%s R1 is not code_runnable: its figures/<id>.py is not "
                    "re-run, so nothing proves it re-draws the SVG"
                    % F["id"])
        return 0
    sk = skill_dir()
    if sk is None:
        errs.append("%s R1 cannot re-run %s: set WORKSHEET_SKILL_DIR to the "
                    "skill folder" % (F["id"], F.get("code")))
        return 0
    env = dict(os.environ, WORKSHEET_SKILL_DIR=sk)
    try:
        # v6.8 r1: an absolute path, so a relative level folder is not
        # joined twice (cwd is already the level)
        out = subprocess.run([sys.executable,
                              os.path.join(os.path.abspath(level), F["code"])],
                             cwd=level, env=env, capture_output=True,
                             timeout=300)
    except subprocess.TimeoutExpired:
        errs.append("%s R1 %s did not finish in 300 s" % (F["id"], F["code"]))
        return 0
    with open(os.path.join(level, F["svg"]), "rb") as fh:
        want = fh.read()
    if out.returncode != 0:
        errs.append("%s R1 %s exits %d: %s" % (
            F["id"], F["code"], out.returncode,
            out.stderr.decode("utf-8", "replace").strip().splitlines()[-1:]))
        return 0
    if out.stdout != want:
        k = next((j for j, (a, b) in enumerate(zip(out.stdout, want))
                  if a != b), min(len(out.stdout), len(want)))
        errs.append("%s R1 %s re-draws a different file (%d vs %d bytes, "
                    "first difference at byte %d)"
                    % (F["id"], F["code"], len(out.stdout), len(want), k))
        return 0
    return 1


# ---------------------------------------------------------------- v6.8 N1 --
PACKAGE_RE = re.compile(r"^G(?:[7-9]|1[0-2])-T[0-9]{2}$")
NOAM_FORBIDDEN_KEYS = ("answer", "answers", "solution", "solutions", "hint",
                       "hints", "code", "code_runnable", "python", "source",
                       "source_hash", "built_at", "skill_version", "files",
                       "sha", "sha256", "hash", "sheet_id_prefix",
                       "sheet_svg_id", "fam", "report", "strict_figures",
                       "strict_figures_declared", "declared",
                       "given_on_proof_item", "checks")
LEVELS = ("a", "b", "c")


def walk_keys(o, key):
    if isinstance(o, dict):
        for k, v in o.items():
            if k == key:
                yield v
            for x in walk_keys(v, key):
                yield x
    elif isinstance(o, list):
        for v in o:
            for x in walk_keys(v, key):
                yield x


def _strings(o):
    if isinstance(o, dict):
        for v in o.values():
            for x in _strings(v):
                yield x
    elif isinstance(o, list):
        for v in o:
            for x in _strings(v):
                yield x
    elif isinstance(o, str):
        yield o


def check_noam(level, sheet, errs):
    p = os.path.join(level, "noam-ai.json")
    if not os.path.isfile(p):
        errs.append("N1 noam-ai.json missing")
        return None
    with open(p, encoding="utf-8") as fh:
        nj = json.load(fh)
    if list(walk_keys(nj, "answer")):
        errs.append("N1 noam-ai.json carries %d 'answer' key(s)"
                    % len(list(walk_keys(nj, "answer"))))
    # v6.7-noam (BRIEF_V68 §5.3): the public file is a whitelist; none of
    # these keys may appear at any depth
    for k in NOAM_FORBIDDEN_KEYS:
        if list(walk_keys(nj, k)):
            errs.append("N1 noam-ai.json carries a '%s' key" % k)
    paths = [x for x in _strings(nj) if re.search(
        r"\.py\b|/Users/|/private/|/tmp/|source/|[A-Za-z]:\\", x)]
    if paths:
        errs.append("N1 noam-ai.json names code paths (%s)" % paths[:3])
    hx = [x for x in _strings(nj) if re.search(
        r"(?<![0-9a-fA-F])(?:[0-9a-fA-F]{64}|[0-9a-fA-F]{40})"
        r"(?![0-9a-fA-F])", x)]
    if hx:
        errs.append("N1 noam-ai.json carries a hash (%s)" % hx[:2])
    pkg, lv = nj.get("package"), nj.get("level")
    if not (isinstance(pkg, str) and PACKAGE_RE.match(pkg)):
        errs.append("N1 package %r is not G<grade>-T<nn>" % (pkg,))
    if lv not in LEVELS:
        errs.append("N1 level %r is not one of a, b, c" % (lv,))
    if sheet.get("package") != pkg or sheet.get("level") != lv:
        errs.append("N1 sheet.json says %s/%s, noam-ai.json %s/%s"
                    % (sheet.get("package"), sheet.get("level"), pkg, lv))
    figs = dict((F.get("id"), F) for F in nj.get("figures", []))
    for q in nj.get("questions", []):
        for row in [q] + list(q.get("items") or []):
            for k in ("given", "to_prove"):
                if not isinstance(row.get(k), list):
                    errs.append("N1 %s has no %s list" % (row.get("id"), k))
            if "figure_id" not in row:
                errs.append("N1 %s has no figure_id key" % row.get("id"))
            elif row["figure_id"] is not None and \
                    row["figure_id"] not in figs:
                errs.append("N1 %s names figure %s, which is not in the "
                            "package" % (row.get("id"), row["figure_id"]))
    # v6.8 r1 (N1-wrong-item-figure-link-passes): the link is the RIGHT
    # figure, read from sheet.json's own figure records -- an item's own
    # figure (item == its id), else its question's head figure, else null
    # v6.7.1-noam: an aux figure (שרטוט עזר) is a patch shown on request,
    # never a question's or an item's figure
    sfig = [F for F in sheet.get("figures") or [] if not F.get("aux")]
    own = dict((F.get("item"), F.get("id")) for F in sfig if F.get("item"))
    for q in nj.get("questions", []):
        qid = q.get("id")
        heads = [F.get("id") for F in sfig
                 if F.get("question") == qid and not F.get("item")]
        if "figure_id" in q:
            ok = (q["figure_id"] in heads) if heads else \
                q["figure_id"] is None
            if not ok:
                errs.append("N1 %s names figure %s; sheet.json's head "
                            "figure(s) of %s are %s"
                            % (qid, q["figure_id"], qid, heads or [None]))
        head = q.get("figure_id") if q.get("figure_id") in heads else (
            heads[0] if heads else None)
        for it in q.get("items") or []:
            if "figure_id" not in it:
                continue
            want = own.get(it.get("id"), head)
            if it["figure_id"] != want:
                errs.append("N1 item %s names figure %s, and sheet.json "
                            "links it to %s" % (it.get("id"),
                                                it["figure_id"], want))
    for F in sfig:
        if F.get("item") and not str(F["item"]).startswith(
                str(F.get("question") or "\0")):
            errs.append("N1 figure %s: item %s is not in question %s"
                        % (F.get("id"), F["item"], F.get("question")))
    for fid, F in figs.items():
        sp = os.path.join(level, F.get("svg") or "")
        if not F.get("svg") or not os.path.isfile(sp):
            errs.append("N1 %s: SVG %s missing" % (fid, F.get("svg")))
            continue
        with open(sp, encoding="utf-8") as fh:
            ids = re.findall(r'\sid="([^"]+)"', fh.read())
        for kind, lst in (F.get("objects") or {}).items():
            for o in lst:
                sid = o.get("svg_id")
                if sid is not None and ids.count(sid) != 1:
                    errs.append("N1 %s: svg_id %s occurs %d times in %s"
                                % (fid, sid, ids.count(sid), F["svg"]))
    # v6.8 final (G6, R3-G6-not-enforced): a printed number names what it
    # stands for -- every numeric label carries `for`, the id of an object
    # of the same figure, in noam-ai.json AND sheet.json
    for src, doc in (("noam-ai.json", nj), ("sheet.json", sheet)):
        for F in doc.get("figures", []) or []:
            objs = F.get("objects") or {}
            own = set()
            for lst in objs.values():
                for o in (lst if isinstance(lst, list) else []):
                    own.update(x for x in (o.get("svg_id"), o.get("id"),
                                           o.get("name")) if x)
            for o in objs.get("labels", []) or []:
                t = str(o.get("text", o.get("name", "")) or "")
                if not numeric_label(t):
                    continue
                if not o.get("for"):
                    errs.append("N3 %s: %s numeric label %s (%r) has no "
                                "`for`" % (src, F.get("id"),
                                           o.get("svg_id"), t))
                elif o["for"] not in own and not re.match(
                        u"^(?:o0|[xy][\\w.\u2212-]+)$", str(o["for"])):
                    # a plane's axis number names its tick (x3, y-2, o0)
                    errs.append("N3 %s: %s label %s is `for` %s, which is "
                                "not an object of that figure"
                                % (src, F.get("id"), o.get("svg_id"),
                                   o["for"]))
    # v6.8 final (R3-G5-sheet-keys-unverified): sheet.json rows too
    for q in sheet.get("questions", []) or []:
        for row in [q] + list(q.get("items") or []):
            for k in ("given", "to_prove"):
                if not isinstance(row.get(k), list):
                    errs.append("N1 sheet.json %s has no %s list"
                                % (row.get("id"), k))
    return nj


# ---------------------------------------------------------------- v6.8 S1 --
_SVG_BLOCK = re.compile(r"<svg\b.*?</svg>", re.S)
_GEOM_ATTRS = ("x", "y", "x1", "y1", "x2", "y2", "cx", "cy", "r", "rx", "ry",
               "width", "height", "points", "d", "transform")


def _shape_list(svg_text):
    root = ET.fromstring(svg_text)
    out = []
    for e in root.iter():
        t = tag(e)
        if t in ("svg",):
            continue
        g = []
        for k in _GEOM_ATTRS:
            v = e.get(k)
            if v is not None:
                g.append((k, [float(x) for x in NUM.findall(v)]
                          if k in ("points", "d", "transform") or
                          NUM.fullmatch(v.strip()) else v))
        out.append((t, g, (e.text or "").strip()))
    return out


def _same_shapes(a, b):
    if len(a) != len(b):
        return "%d elements in the sheet, %d in the file" % (len(a), len(b))
    for k, ((ta, ga, xa), (tb, gb, xb)) in enumerate(zip(a, b)):
        if ta != tb or xa != xb or [x[0] for x in ga] != [x[0] for x in gb]:
            return "element %d: <%s> %r vs <%s> %r" % (k, ta, xa, tb, xb)
        for (n, va), (_n, vb) in zip(ga, gb):
            if isinstance(va, list) and isinstance(vb, list):
                if len(va) != len(vb) or any(abs(float(p) - float(q)) > 0.01
                                             for p, q in zip(va, vb)):
                    return "element %d <%s> %s differs" % (k, ta, n)
            elif va != vb:
                return "element %d <%s> %s differs" % (k, ta, n)
    return None


def check_sheet_html(level, sheet, errs):
    p = os.path.join(level, "sheet.html")
    if not os.path.isfile(p):
        errs.append("S1 sheet.html missing: the PDF's figures cannot be "
                    "compared with figures/*.svg")
        return 0
    with open(p, encoding="utf-8") as fh:
        doc = fh.read()
    inl = {}
    for blk in _SVG_BLOCK.findall(doc):
        m = re.search(r'\sid="([^"]+?)__', blk)
        if m:
            inl.setdefault(m.group(1), blk)
    n = 0
    for F in sheet.get("figures", []):
        fid = F["id"]
        if F.get("kind") == "unrecorded":
            continue
        if F.get("aux") and F.get("reveal") == "on_request":
            # v6.7.1-noam: an aux figure is shown only on request by Noam
            # AI; it is never printed, so the sheet does not inline it
            continue
        blk = inl.get(fid)
        if blk is None:
            errs.append("S1 %s is not inlined in sheet.html" % fid)
            continue
        blk = re.sub(r'(\sid="|url\(#|href="#)%s__' % re.escape(fid),
                     r"\1", blk)
        with open(os.path.join(level, F["svg"]), encoding="utf-8") as fh:
            f_svg = _SVG_BLOCK.search(fh.read()).group(0)
        try:
            why = _same_shapes(_shape_list(blk), _shape_list(f_svg))
        except ET.ParseError as e:
            why = "unparseable (%s)" % e
        if why:
            errs.append("S1 %s: the sheet's figure and figures/%s.svg "
                        "differ -- %s" % (fid, fid, why))
        else:
            n += 1
    return n


def check_map(view, o, errs, fid):
    M = (view or {}).get("data_to_svg")
    xy, sx = o.get("xy"), o.get("svg_xy")
    if not (M and xy and sx):
        return
    a, b = flat(xy), flat(sx)
    if len(a) != len(b):
        return
    for p, q in zip(a, b):
        r = (M[0] * p[0] + M[2] * p[1] + M[4], M[1] * p[0] + M[3] * p[1] + M[5])
        if not near(r, q, 0.05):
            errs.append("%s O4 %s xy %s -> %s != svg_xy %s" % (fid, oid(o), p, r, q))
            return


class Geo(object):
    def __init__(self, svg, objs):
        self.svg = svg
        self.pt = {}
        self.seg = {}
        self.circ = {}
        self.segid = {}
        self.xyz = {}
        for o in objs.get("points", []):
            if o.get("name") and oid(o) in svg.ids:
                pp = svg.element_pts(oid(o))[1]
                if pp:          # a bare anchor has no ink: I1 reports it
                    self.pt[o["name"]] = pp[0]
            if o.get("xyz") and oid(o) in svg.ids:
                self.xyz[oid(o)] = o["xyz"]
                if o.get("name"):
                    self.xyz[o["name"]] = o["xyz"]
        for o in objs.get("segments", []):
            if oid(o) in svg.ids:
                k, p = svg.element_pts(oid(o))
                if not p:       # a bare anchor has no ink: I1 reports it
                    continue
                if k == "group":
                    p = far_pair(p)
                ends = (p[0], p[-1])
                self.seg[oid(o)] = ends
                self.segid[oid(o)] = oid(o)     # an unnamed edge, by its id
                if o.get("name"):
                    self.seg[o["name"]] = ends
                    self.segid[o["name"]] = oid(o)
        for o in objs.get("circles", []):
            if oid(o) in svg.ids:
                el, m, _ = svg.ids[oid(o)]
                k, p, r = svg.geom(el, m)
                if k == "c":
                    self.circ[oid(o)] = (p[0], r)
                    if o.get("name"):
                        self.circ[o["name"]] = (p[0], r)

    def P(self, n):
        if n in self.pt:
            return self.pt[n]
        for cand in ("pt-" + n, n):
            if cand.startswith("pt-") and cand in self.svg.ids:
                pp = self.svg.element_pts(cand)[1]
                if pp:
                    return pp[0]
        raise KeyError("point " + n)

    def C(self, n):
        """v6.7-noam: a circle operand -- its id or name, or the name of
        its centre point."""
        if n in self.circ:
            return self.circ[n]
        p = self.P(n)
        for cc, r in self.circ.values():
            if near(cc, p):
                return cc, r
        raise KeyError("circle " + n)

    def X(self, n):
        """v6.8 r2: a point operand's xyz (the point must be in the SVG)."""
        self.P(n)
        if n in self.xyz:
            return self.xyz[n]
        raise KeyError("xyz of " + n)

    def XS(self, s):
        if isinstance(s, (list, tuple)):
            return self.X(s[0]), self.X(s[1])
        for k in range(1, len(s)):
            try:
                return self.X(s[:k]), self.X(s[k:])
            except KeyError:
                pass
        raise KeyError("segment in space " + s)

    def S(self, s):
        if isinstance(s, (list, tuple)):
            return self.P(s[0]), self.P(s[1])
        if s in self.seg:
            return self.seg[s]
        # v6.8 r1: a line (ln-) or a ray (ray-) is a straight operand too
        if s.startswith(("seg-", "ln-", "ray-")) and s in self.svg.ids:
            p = self.svg.element_pts(s)[1]
            if p:
                return far_pair(p)
        if len(s) >= 2:
            # split a two-point name like AB, A'B
            for k in range(1, len(s)):
                a, b = s[:k], s[k:]
                try:
                    return self.P(a), self.P(b)
                except KeyError:
                    pass
        raise KeyError("segment " + s)


def far_pair(p):
    best = (0, p[0], p[-1])
    for a in p:
        for b in p:
            d = math.hypot(a[0] - b[0], a[1] - b[1])
            if d > best[0]:
                best = (d, a, b)
    return best[1], best[2]


def vec(s):
    return (s[1][0] - s[0][0], s[1][1] - s[0][1])


def ln(v):
    return math.hypot(*v)


def ang(v, w):
    c = (v[0] * w[0] + v[1] * w[1]) / (ln(v) * ln(w))
    return math.degrees(math.acos(max(-1, min(1, c))))


def measure_space(c, G):
    t = c["type"]
    ss = [G.XS(s) for s in c.get("of") or []]
    vs = [[b[i] - a[i] for i in range(3)] for a, b in ss]
    L = [math.sqrt(sum(x * x for x in v)) for v in vs]
    if t == "equal_length":
        return (max(L) - min(L)) <= 1e-4 * max(L), "3D lengths %s" % [round(x, 4) for x in L]
    if min(L) <= 1e-12:
        return False, "a zero-length operand"
    a = [math.degrees(math.acos(max(-1, min(1, sum(vs[0][i] * v[i] for i in range(3)) / (L[0] * l)))))
         for v, l in zip(vs[1:], L[1:])]
    if t == "perpendicular":
        if c.get("at") is not None:
            G.X(c["at"])
        return abs(a[0] - 90) <= 0.5, "3D angle %.2f" % a[0]
    if t == "parallel":
        w = max(min(x, 180 - x) for x in a)
        return w <= 0.5, "3D angle %.2f" % w
    return None, "unmeasured space type %s" % t


def check_xyz(F, errs):
    """X2: the xyz of a figure's points are one affine picture of their
    svg_xy -- svg_xy = M . xyz + t, fitted, every point within 1 px."""
    rows = []
    for o in (F.get("objects") or {}).get("points", []):
        if o.get("xyz") and o.get("svg_xy"):
            rows.append((o["xyz"], flat(o["svg_xy"])[0], oid(o)))
    if len(rows) < 4:
        return
    A = [[x[0], x[1], x[2], 1.0] for x, _, _ in rows]
    # normal equations, 4x4, solved for each output coordinate
    N = [[sum(r[i] * r[j] for r in A) for j in range(4)] for i in range(4)]
    worst = (0.0, None)
    coef = []
    for k in range(2):
        b = [sum(r[i] * q[k] for r, (_, q, _) in zip(A, rows)) for i in range(4)]
        M = [N[i][:] + [b[i]] for i in range(4)]
        n = 4
        ok = True
        for col in range(n):
            piv = max(range(col, n), key=lambda r: abs(M[r][col]))
            if abs(M[piv][col]) < 1e-9:
                ok = False      # coplanar points: the fit is not unique
                break
            M[col], M[piv] = M[piv], M[col]
            for r in range(n):
                if r != col:
                    f = M[r][col] / M[col][col]
                    M[r] = [a - f * c for a, c in zip(M[r], M[col])]
        if not ok:
            return
        coef.append([M[i][n] / M[i][i] for i in range(n)])
    for (x, q, i), r in zip(rows, A):
        p = [sum(c * v for c, v in zip(coef[k], r)) for k in range(2)]
        d = math.hypot(p[0] - q[0], p[1] - q[1])
        if d > worst[0]:
            worst = (d, i)
    if worst[0] > TOL:
        errs.append("%s X2 the points' xyz are not one projection of the "
                    "drawing: %s is %.2f px off the fitted picture"
                    % (F["id"], worst[1], worst[0]))


def measure(c, G, scale):
    t = c["type"]
    of = c.get("of")
    if c.get("space"):
        return measure_space(c, G)
    if t == "perpendicular":
        a = ang(vec(G.S(of[0])), vec(G.S(of[1])))
        return abs(a - 90) <= 0.6, "angle %.2f" % a
    if t == "parallel":
        a = ang(vec(G.S(of[0])), vec(G.S(of[1])))
        return min(a, 180 - a) <= 0.6, "angle %.2f" % a
    if t == "equal_length":
        L = [ln(vec(G.S(s))) for s in of]
        return (max(L) - min(L)) <= max(0.01 * max(L), 0.6), "lengths %s" % [round(x, 2) for x in L]
    if t == "length":
        L = ln(vec(G.S(of))) / scale
        return abs(L - float(c["value"])) <= max(0.01 * abs(float(c["value"])), 0.05), "len %.3f vs %s" % (L, c["value"])
    if t == "collinear":
        P = [G.P(n) for n in c["points"]]
        a, b = far_pair(P)
        d = max(segdist(p, a, b) if True else 0 for p in P)
        # distance to the infinite line
        v = vec((a, b))
        d = max(abs((p[0] - a[0]) * v[1] - (p[1] - a[1]) * v[0]) / ln(v) for p in P)
        return d <= TOL, "off-line %.2f px" % d
    if t == "midpoint":
        ends = G.S(of)
        m = ((ends[0][0] + ends[1][0]) / 2, (ends[0][1] + ends[1][1]) / 2)
        p = G.P(c["point"])
        return near(p, m), "dist %.2f" % math.hypot(p[0] - m[0], p[1] - m[1])
    if t == "on_segment":
        ends = G.S(of)
        p = G.P(c["point"])
        d = segdist(p, *ends)
        return d <= TOL, "dist %.2f" % d
    if t == "angle":
        at = G.P(c["at"])
        r = [G.P(x) for x in c["rays"]]
        a = ang((r[0][0] - at[0], r[0][1] - at[1]), (r[1][0] - at[0], r[1][1] - at[1]))
        return abs(a - float(c["value"])) <= 0.6, "angle %.2f vs %s" % (a, c["value"])
    if t == "equal_angle":
        vals = []
        for A in c["of"]:
            at = G.P(A["at"]) if isinstance(A, dict) else G.P(A[1])
            rays = A["rays"] if isinstance(A, dict) else [A[0], A[2]]
            r = [G.P(x) for x in rays]
            vals.append(ang((r[0][0] - at[0], r[0][1] - at[1]), (r[1][0] - at[0], r[1][1] - at[1])))
        return max(vals) - min(vals) <= 0.6, "angles %s" % [round(x, 2) for x in vals]
    # v6.7-noam (R3-G7-circle-builder-relations): the circle relations
    if t == "tangent":
        cc, r = G.C(c["circle"])
        a, b = G.S(c["to"])
        v = vec((a, b))
        d = abs((cc[0] - a[0]) * v[1] - (cc[1] - a[1]) * v[0]) / ln(v)
        ok, why = abs(d - r) <= TOL, "centre %.2f px from the line, r %.2f" \
            % (d, r)
        if ok and c.get("at"):
            q = G.P(c["at"])
            e = abs(math.hypot(q[0] - cc[0], q[1] - cc[1]) - r)
            ok = e <= TOL and segdist(q, a, b) <= TOL
            why += "; touch point %.2f px off the circle" % e
        return ok, why
    if t == "concentric":
        cs = [G.C(x)[0] for x in of]
        w = max(math.hypot(p[0] - cs[0][0], p[1] - cs[0][1]) for p in cs)
        return w <= TOL, "centres %.2f px apart" % w
    if t == "ratio":
        L = [ln(vec(G.S(x))) for x in of]
        got = L[0] / L[1] if L[1] else float("inf")
        want = float(c["value"])
        return abs(got - want) <= 0.02 * max(1.0, abs(want)), \
            "ratio %.4f vs %s" % (got, want)
    if t == "hidden_edge":
        i = G.segid.get(of) or G.segid.get(of[::-1])
        if not i:
            return False, "no segment object named %s" % of
        return G.svg.dashed.get(i, False), "dashed=%s" % G.svg.dashed.get(i)
    return None, "unmeasured type %s" % t


def verify(level):
    d = json.load(open(os.path.join(level, "sheet.json"), encoding="utf-8"))
    errs, notes = [], []
    nobj = ncons = nmeas = reran = 0
    by_type = {}
    for F in d["figures"]:
        fid = F["id"]
        path = os.path.join(level, F["svg"])
        if not os.path.exists(path):
            errs.append("%s svg file missing" % fid)
            continue
        svg = Svg(path)
        objs = F.get("objects") or {}
        for k, L in objs.items():
            for o in L:
                nobj += 1
                check_object(svg, o, errs, fid)
                check_on_ink(svg, o, errs, fid)
                check_map(F.get("view"), o, errs, fid)
        reran += rerun(level, F, errs)
        check_xyz(F, errs)
        M = (F.get("view") or {}).get("data_to_svg")
        scale = math.hypot(M[0], M[1]) if M else 1.0
        G = Geo(svg, objs)
        for c in F.get("constraints") or []:
            ncons += 1
            by_type[c["type"]] = by_type.get(c["type"], 0) + 1
            try:
                ok, why = measure(c, G, scale)
            except Exception as e:
                ok, why = False, "unresolvable: %r" % (e,)
            if ok is None:
                # v6.8 final (R3-unmeasured-constraint-is-note): the
                # contract's check 5 -- no constraint ships un-remeasured
                errs.append("%s C1 constraint not re-measured (%s): %s"
                            % (fid, why, json.dumps(c, ensure_ascii=False)))
            else:
                nmeas += 1
                if not ok:
                    errs.append("%s C1 %s fails: %s" % (fid, json.dumps(c, ensure_ascii=False), why))
            if c.get("source") == "to_prove":
                if c.get("marked") or (c.get("mark_id") and c["mark_id"] in svg.ids):
                    errs.append("%s C2 to_prove marked: %s" % (fid, c))
        check_mark_coverage(F, errs)
    nj = check_noam(level, d, errs)
    check_vm_parts(level, nj, errs)
    check_vm_union(level, nj, errs)
    _sfig = dict((x.get("id"), x) for x in (d or {}).get("figures") or []
                 if isinstance(x, dict))
    for _F in (nj or {}).get("figures") or []:
        _vm = (_F or {}).get("visual_model") or {}
        for _why in hg_unmarked(_vm):
            errs.append("H2 %s: %s" % (_vm.get("id") or _F.get("id"), _why))
        # (v6.10 fix r2) H3: every markable given is offered; N4: a numeric
        # label names the object whose value it prints, in every copy
        for _why in hg_missing(_F, _source_state_hg_context(level, _F, nj)):
            errs.append("H3 %s: %s" % (_vm.get("id") or _F.get("id"), _why))
        for _why in label_faults(_F, _sfig.get(_F.get("id"))):
            errs.append("N4 %s" % _why)
    same = check_sheet_html(level, d, errs)
    b = json.load(open(os.path.join(level, "build.json")))
    check_public_spec(level, d, b, nj, errs)
    # v6.8 r2 (B1): the contract requires STRICT_FIGURES = True
    for k in ("strict_figures", "strict_figures_declared"):
        if b.get(k) is not True:
            errs.append("B1 build.json %s is %r, not True: the contract "
                        "requires STRICT_FIGURES = True written in "
                        "content.py" % (k, b.get(k)))
    check_g79(b, errs, level)
    check_g80(level, b, errs, notes)
    check_g81(level, b, errs, notes)
    check_g82(b, errs)
    check_g83_room(b, errs)
    check_g84_num_clear(b, errs)
    check_engine_maps(level, d, b, nj, errs)
    check_spec_rows(level, d, b, nj, errs)
    for rel, h in b.get("files", {}).items():
        p = os.path.join(level, rel)
        if not os.path.exists(p) or hashlib.sha256(open(p, "rb").read()).hexdigest() != h:
            errs.append("F1 hash mismatch %s" % rel)
    return dict(level=level, figures=len(d["figures"]), objects=nobj,
                reran=reran, same_as_sheet=same,
                package=(nj or {}).get("package"), key=(nj or {}).get("level"),
                constraints=ncons, measured=nmeas, by_type=by_type,
                errors=errs, notes=notes, sources={
                    s: sum(1 for F in d["figures"] for c in F.get("constraints") or [] if c.get("source") == s)
                    for s in ("given", "to_prove", "derived", "decorative")})


MARK_KINDS = ("ticks", "parallel", "right_angle", "arc")


def _on_stroke(svg, sid, pts, tol=TOL):
    """Every point lies on the straight stroke(s) of element sid (a line,
    a polygon's / polyline's edges)."""
    k, ep = svg.element_pts(sid)
    if k == "l":
        segs = [(ep[0], ep[1])]
    elif k == "p" and tag(svg.ids[sid][0]) in ("polygon", "polyline"):
        segs = list(zip(ep, ep[1:]))
        if tag(svg.ids[sid][0]) == "polygon" and ep:
            segs.append((ep[-1], ep[0]))
    else:
        return None                       # not a straight stroke
    return all(any(segdist(p, a, b) <= tol for a, b in segs) for p in pts)


def _one_edge(svg, sid, p, q, tol=TOL):
    """p and q lie on ONE straight piece of element sid."""
    k, ep = svg.element_pts(sid)
    if k == "l":
        segs = [(ep[0], ep[1])]
    else:
        segs = list(zip(ep, ep[1:]))
        if tag(svg.ids[sid][0]) == "polygon" and ep:
            segs.append((ep[-1], ep[0]))
    return any(segdist(p, a, b) <= tol and segdist(q, a, b) <= tol
               for a, b in segs)


def _on_ray(v, a, x, tol=TOL):
    ux, uy = a[0] - v[0], a[1] - v[1]
    dx, dy = x[0] - v[0], x[1] - v[1]
    L = math.hypot(ux, uy)
    if L == 0 or math.hypot(dx, dy) <= tol:
        return False
    return (ux * dx + uy * dy) > 0 and abs(ux * dy - uy * dx) / L <= tol


def span_own(ty, names, span, P, tol=TOL):
    """(v6.9 fix r2, C1r) a part's span is a piece of its OWN object (the
    span used to be trusted: seg:CO mapped to the line of BD with span
    [D, O] passed, and highlight drew DO): segment -- both span points lie
    on the segment; angle -- [vertex, X] with X on ray vertex->A or
    vertex->B; polygon -- both on one side."""
    if len(span) != 2 or span[0] == span[1] or \
            any(n not in P for n in span):
        return False
    X, Y = P[span[0]], P[span[1]]
    if ty == "segment":
        a, b = P[names[0]], P[names[-1]]
        return segdist(X, a, b) <= tol and segdist(Y, a, b) <= tol
    if ty == "angle" and len(names) == 3:
        a, v, b = names
        if v not in span:
            return False
        x = P[span[1] if span[0] == v else span[0]]
        return _on_ray(P[v], P[a], x, tol) or _on_ray(P[v], P[b], x, tol)
    if ty == "polygon" and len(names) >= 3:
        return any(segdist(X, P[p], P[q]) <= tol and
                   segdist(Y, P[p], P[q]) <= tol
                   for p, q in zip(names, names[1:] + names[:1]))
    return False



def hg_unmarked(vm):
    """(v6.10 fix r1, m1-hg) [reason] -- every highlight_given entry is a
    MARKED given: its relation's highlight names an overlay_mark object
    'for' it, or it is a statement derived from a given shape (from_given,
    C3). An unmarked given (a bare on_segment) offered as a given
    highlight has nothing of its own to paint."""
    out = []
    rel = dict((r.get("id"), r) for r in vm.get("relations") or []
               if isinstance(r, dict))
    ov = dict((o.get("id"), o) for o in vm.get("objects") or []
              if isinstance(o, dict) and o.get("type") == "overlay_mark")
    for x in vm.get("highlight_given") or []:
        if not isinstance(x, str):
            continue
        r = rel.get(x) or {}
        h = r.get("highlight")
        if r.get("from_given"):
            continue
        if not (h in ov and ov[h].get("for") == x):
            out.append("highlight_given %s (%s) has no given mark of its own "
                       "(no overlay_mark for it)" % (x, r.get("type")))
    return out

from fractions import Fraction as _HBS_Fraction

# ---- v6.18 source-state HG block (identical standalone readers) ----
_HBS_KEYS = {"kind", "from_figure", "source", "ladder", "right_angle",
        "old_height", "new_base", "height_target"}


def _hbs_obsolete_height(spec, figure):
    d = figure.get("state_change")
    if d is None:
        return set()
    def must(value):
        if not value:
            raise ValueError("unproved changed-position reader context")
    def norm(text):
        return " ".join(str(text).replace("$", "").split())
    def blocks(row):
        return [b for b in row.get("bound") or [] if isinstance(b, dict)]
    def bound(block, fact, token):
        return any(b.get("fact") == fact["id"] and _HBS_Fraction(str(b["tok"])) == _HBS_Fraction(token)
                   for b in block.get("bind") or [] if isinstance(b, dict) and b.get("fact") == fact["id"])
    must(isinstance(d, dict) and set(d) == _HBS_KEYS and d["kind"] == "rigid_ladder_base_move")
    must(all(isinstance(d[k], str) and d[k] for k in _HBS_KEYS - {"source"}))
    src = d["source"]
    must(isinstance(src, dict) and set(src) == {"scope", "text"}
         and all(isinstance(src[k], str) and src[k] for k in src))
    owners = [(q, i) for q in spec.get("questions", []) for i in q.get("items", [])
              if i.get("id") == figure.get("scope")]
    must(len(owners) == 1)
    q, item = owners[0]
    must(item.get("figure") == figure["id"] and src["scope"] == item["id"])
    old = [g for g in spec.get("figures", []) if g.get("id") == d["from_figure"]]
    must(len(old) == 1)
    old = old[0]
    must(old["id"] == q.get("figure") and old.get("scope") == q["id"] and "state_change" not in old)
    for frame in (old, figure):
        must(frame.get("figure_accuracy") == "accurate")
        must(not any(k in frame for k in ("frame", "graph", "data", "loci", "base_height")))
    must(set(old.get("entities", [])) == set(figure.get("entities", [])))
    f = {v["id"]: v for v in spec.get("facts", [])}
    e = {v["id"]: v for v in spec.get("entities", [])}
    ladder, right, initial, base, target = [f[d[k]] for k in
                                          ("ladder", "right_angle", "old_height", "new_base", "height_target")]
    for datum, owner in ((ladder, q["id"]), (right, q["id"]), (initial, q["id"]), (base, item["id"])):
        must(datum.get("role") == "given" and datum.get("item") == owner
             and datum.get("source") == {"kind": "stated"})
    for datum in (ladder, initial, base):
        must(datum.get("rel") == "length" and len(datum.get("args", [])) == 1 and datum.get("unit") == "m")
        must(e[datum["args"][0]].get("kind") == "segment")
    h, b, l = initial["args"][0], base["args"][0], ladder["args"][0]
    hv, bv, lv = [set(e[z].get("ends", [])) for z in (h, b, l)]
    vertices = hv | bv
    must(len(hv) == len(bv) == len(lv) == 2 and len(hv & bv) == 1
         and lv == vertices - (hv & bv) and len(vertices) == 3)
    must(all(e[z].get("kind") == "point" for z in vertices))
    must(right.get("rel") == "perpendicular" and set(right.get("args", [])) == {h, b})
    must(target.get("role") == "target" and target.get("rel") == "length"
         and target.get("args") == [h] and target.get("item") == item["id"] and "value" not in target)
    must(target["id"] in [t["id"] for t in item.get("targets", [])])
    listed = set(figure.get("entities", []))
    must(vertices | {h, b, l} <= listed)
    must({z for z in listed if e[z].get("kind") == "point"} == vertices)
    must({z for z in listed if e[z].get("kind") == "segment"} == {h, b, l})
    must(all(e[z].get("kind") in ("point", "segment", "angle", "polygon") for z in listed))
    kept = {right["id"], ladder["id"]}
    must(isinstance(figure.get("inherit_givens"), list) and len(figure["inherit_givens"]) == 2
         and set(figure["inherit_givens"]) == kept)
    must(kept | {base["id"]} <= set(item.get("uses", [])))
    for frame, datum in ((old, initial), (figure, base)):
        shown = set(frame.get("draws", []))
        must(kept | {datum["id"]} <= shown)
        must(all(z in kept | {datum["id"]} or
                 (f[z].get("rel") == "name" and f[z].get("role") == "context"
                  and f[z].get("args", [None])[0] in vertices) for z in shown))
    length, height, distance = [_HBS_Fraction(str(v["value"])) for v in (ladder, initial, base)]
    must(0 < height < length and 0 < distance < length)
    must(distance ** 2 != length ** 2 - height ** 2)  # same-position metadata cannot waive a leak
    atom = r"([0-9]+(?:\.[0-9]+)?)"
    before = r"סולם באורך " + atom + r" מטרים נשען על קיר ומגיע לגובה " + atom + r" מטרים\."
    found = False
    for block in blocks(q):
        m = re.fullmatch(before, norm(block.get("text")))
        if (m and _HBS_Fraction(m[1]) == length and _HBS_Fraction(m[2]) == height
                and bound(block, ladder, m[1]) and bound(block, initial, m[2])
                and right["id"] in block.get("prints", [])):
            found = True
    must(found)
    local = [x for x in blocks(item) if norm(x.get("text")) == norm(src["text"])]
    must(len(local) == 1)
    block = local[0]
    m = re.fullmatch(r"אם מזיזים את הבסיס למרחק " + atom + r" מטרים, חשבו את הגובה החדש\.", norm(block.get("text")))
    must(m and _HBS_Fraction(m[1]) == distance and bound(block, base, m[1])
         and {base["id"], target["id"]} <= set(block.get("prints", [])))
    return {initial["id"]}


def _source_state_hg_view(nj, figure_id, public_spec):
    """Read-only H3/K21 context for one independently proved source state.

    No ordinary claim is waived. Only the precise old head-height claim
    is omitted for the figure's own new-height target. The original rows
    remain in noam-ai.json and every other checker receives them unchanged.
    """
    try:
        figures = [f for f in public_spec.get("figures", []) if f.get("id") == figure_id]
        if len(figures) != 1 or "state_change" not in figures[0]:
            return nj
        fig = figures[0]
        excluded = _hbs_obsolete_height(public_spec, fig)
        d = fig["state_change"]
        facts = {f["id"]: f for f in public_spec["facts"]}
        entities = {e["id"]: e for e in public_spec["entities"]}
        old, target = facts[d["old_height"]], facts[d["height_target"]]
        if old["id"] not in excluded:
            return nj
        qid, rid = old["item"], target["item"]
        q = next(q for q in nj["questions"] if q["id"] == qid)
        item = next(i for i in q["items"] if i["id"] == rid)
        public_q = next(q for q in public_spec["questions"] if q["id"] == qid)
        public_item = next(i for i in public_q["items"] if i["id"] == rid)
        def norm(text):
            if isinstance(text, list):
                text = "\n".join(str(x) for x in text)
            return " ".join(str(text).replace("$", "").split())
        if (norm(q.get("text")) != norm(public_q.get("text"))
                or norm(item.get("text")) != norm(public_item.get("text"))
                or q.get("figure_id") != d["from_figure"]
                or item.get("figure_id") != figure_id):
            return nj
        names = {entities[p].get("name", p) for p in entities[old["args"][0]]["ends"]}
        def same_segment(value):
            parts = value if isinstance(value, list) else re.findall(r"[A-Z][0-9\u2032']*", str(value or ""))
            return len(parts) == 2 and set(parts) == names
        if not any(c.get("type") == "find" and c.get("quantity") == "length"
                   and same_segment(c.get("of")) for c in item.get("to_prove", []) if isinstance(c, dict)):
            return nj
        def is_old(g):
            if (not isinstance(g, dict) or g.get("type") != "length" or g.get("from_item")
                    or not same_segment(g.get("of")) or g.get("unit") not in ("m", "מטר", "מ'", "מ׳")):
                return False
            try:
                return _HBS_Fraction(str(g.get("value"))) == _HBS_Fraction(str(old["value"]))
            except (ValueError, TypeError, ZeroDivisionError):
                return False
        original = q.get("given", [])
        kept = [g for g in original if not is_old(g)]
        if len(kept) == len(original):
            return nj
        replacement = dict(q, given=kept)
        return dict(nj, questions=[replacement if row is q else row for row in nj["questions"]])
    except Exception:
        return nj  # malformed public data cannot authorize dropping any claim


def _source_state_hg_context(level, figure, nj):
    """Portable standalone reader: only standard-library imports are used."""
    try:
        with open(os.path.join(level, "wspec", "public_spec.json"), encoding="utf-8") as stream:
            public_spec = json.load(stream)
        return _source_state_hg_view(nj, figure.get("id"), public_spec)
    except Exception:
        return nj  # missing/malformed source keeps all existing HG requirements

# ---- end of v6.18 source-state HG block ----

# ---- v6.10 fix r2 block (identical in verify_export.py and --------------
# ---- selfcheck_noam_package.py; standard library only) --------------------
_R2_TOK = re.compile(u"[A-Z][0-9\u2032']*")
_R2_MARKED = ("equal_length", "midpoint", "equal_angle", "parallel",
              "perpendicular", "length", "angle")
_R2_NUM = re.compile(u"^[\u2212\\-]?[\\d.,/\u2212\\-]*\\d[\\d.,/]*$")
_R2_UNIT = re.compile(u"\\s*(?:\u00b0|\u2032|ס\"מ|ס\u05f4מ|סמ\"ר|"
                      u"סמ\u05f4ר|cm|%)$")
_R2_DEG = re.compile(u"\\s*[\u00b0\u2032]$")


def r2_numeric(t):
    """a printed number, with or without its unit ('48°', '6 ס״מ', '6√2')"""
    t = _R2_UNIT.sub(u"", str(t or u"").strip()).replace(u"\u221a", u"")
    return bool(_R2_NUM.match(t))


def _r2_seg(s):
    t = _R2_TOK.findall(str(s or ""))
    return frozenset(t) if len(t) == 2 else None


def _r2_ang(a):
    if isinstance(a, dict):
        at, rays = a.get("at"), list(a.get("rays") or [])
        if not at or len(rays) != 2:
            return None
        return (str(at), frozenset(str(r) for r in rays))
    t = _R2_TOK.findall(str(a or ""))
    return (t[1], frozenset((t[0], t[2]))) if len(t) == 3 else None


def _r2_val(v):
    if v is None:
        return None
    try:
        return round(float(str(v).replace(u"\u2212", "-")), 6)
    except ValueError:
        return u"".join(str(v).split())


def r2_key(c):
    """the fact a given claim / a model relation states (None: unmarked)"""
    if not isinstance(c, dict):
        return None
    t = c.get("type")
    if t in ("equal_length", "parallel", "perpendicular"):
        return (t, frozenset(_r2_seg(x) for x in c.get("of") or []))
    if t == "equal_angle":
        return (t, frozenset(_r2_ang(x) for x in c.get("of") or []))
    if t == "length":
        return (t, _r2_seg(c.get("of")), _r2_val(c.get("value")))
    if t == "angle":
        return (t, _r2_ang(c), _r2_val(c.get("value")))
    if t == "midpoint":
        return (t, str(c.get("point")), _r2_seg(c.get("of")))
    return None


def _r2_letters(c):
    out = set()
    for k in ("of", "point", "at", "rays"):
        v = c.get(k)
        for x in (v if isinstance(v, list) else [v]):
            if isinstance(x, dict):
                out.update(_R2_TOK.findall(str(x.get("at") or "")))
                for r in x.get("rays") or []:
                    out.update(_R2_TOK.findall(str(r)))
            else:
                out.update(_R2_TOK.findall(str(x or "")))
    return out


def hg_missing(F, nj):
    """(v6.10 fix r2, hg-completeness) [reason] -- highlight_given lists
    EVERY given the overlay can mark, not only a typed shape's statements
    (C3): each typed given claim of a row the figure serves (the question
    row, and the item rows whose figure it is: every row of a question
    figure, its own row for an item figure), unless carried (from_item) or
    no_overlay, whose kind the overlay marks (ticks / arc / parallel /
    right angle / length / angle) and whose points the figure shows, is a
    given relation of the model offered in highlight_given AND in
    actions.highlight. Derived from the claims of noam-ai.json, not from
    what the model offers; also: an overlay_mark 'for' a given relation is
    offered."""
    vm = F.get("visual_model") if isinstance(F, dict) else None
    if not isinstance(vm, dict) or vm.get("visual_support") == "unsupported":
        return []
    out = []
    fid = vm.get("id") or F.get("id")
    qid = vm.get("question") or F.get("question")
    q = [x for x in nj.get("questions") or []
         if isinstance(x, dict) and x.get("id") == qid]
    if not q:
        return []
    q = q[0]
    rows = [q.get("given") or []]
    for it in q.get("items") or []:
        if not isinstance(it, dict):
            continue
        if vm.get("item"):
            if it.get("id") == vm["item"]:
                rows.append(it.get("given") or [])
        elif it.get("figure_id") in (None, fid):
            rows.append(it.get("given") or [])
    pts = set(_geometry_name(o) for o in vm.get("objects") or []
              if isinstance(o, dict) and o.get("type") == "point")
    hg = set(x for x in vm.get("highlight_given") or [] if isinstance(x, str))
    ah = set(x for x in (vm.get("actions") or {}).get("highlight") or []
             if isinstance(x, str))
    rels = [r for r in vm.get("relations") or []
            if isinstance(r, dict) and r.get("role") == "given"]
    seen = set()
    for cl in rows:
        for c in cl if isinstance(cl, list) else []:
            if not isinstance(c, dict) or c.get("from_item") or \
                    c.get("no_overlay") or c.get("type") not in _R2_MARKED:
                continue
            k = r2_key(c)
            if k is None or k in seen or not (_r2_letters(c) & pts):
                continue
            seen.add(k)
            say = c.get("text") or c.get("type")
            hit = [r for r in rels if r2_key(r) == k]
            if not hit:
                out.append("the given %r of figure %s is no given relation "
                           "of its model (nothing to highlight)" % (say, fid))
                continue
            if not any(r.get("id") in hg for r in hit):
                out.append("the given %s (%r) is not offered in "
                           "highlight_given" % (hit[0].get("id"), say))
            if not any(r.get("id") in ah for r in hit):
                out.append("the given %s (%r) is not in actions.highlight"
                           % (hit[0].get("id"), say))
    gid = dict((r.get("id"), r) for r in rels)
    for o in vm.get("objects") or []:
        if isinstance(o, dict) and o.get("type") == "overlay_mark" and \
                o.get("for") in gid and o.get("for") not in hg:
            out.append("overlay_mark %s marks the given %s, which "
                       "highlight_given does not offer"
                       % (o.get("id"), o.get("for")))
    return out


def _r2_label_value(t):
    t = _R2_UNIT.sub(u"", str(t).strip()).replace(u"\u2212", "-")
    try:
        if "/" in t:
            a, b = t.split("/", 1)
            return round(float(a) / float(b), 6)
        return round(float(t.replace(",", ".")), 6)
    except (ValueError, ZeroDivisionError):
        return None


_R2_TICK = re.compile(u"^(?:o0|[xy][\\w.\u2212-]+)$")


def label_states(o, vm, where):
    """(v6.10 fix r2, label-for-integrity) [reason] -- a numeric label's
    `for` names the RIGHT object. Decided on the model's typed given /
    context values: a degree label ('48°', for the vertex O or its arc
    'arc-O') names an angle at that vertex (between the arms its model
    name says) whose value is 48, a length label ('14', for AB) a segment
    whose length is 14. A label is wrong when the object it names carries
    another value, or carries none while another object carries this one
    (re-tied: '14' moved from AB to AD). A value no typed relation states
    (a text-only given) and an axis number ('2' for its tick y2) are not
    decided here (N3 still requires the `for`)."""
    t = str(o.get("text", o.get("name", "")) or "")
    if not r2_numeric(t) or not o.get("for"):
        return []
    f, v = str(o["for"]), _r2_label_value(t)
    if u"\u221a" in t or v is None or _R2_TICK.match(f):
        return []
    lid = o.get("svg_id") or o.get("id")
    rels = [r for r in vm.get("relations") or [] if isinstance(r, dict) and
            r.get("role") in ("given", "context") and
            isinstance(_r2_val(r.get("value")), float)]
    if _R2_DEG.search(t):
        at = f[4:] if f.startswith("arc-") else f
        nm = _R2_TOK.findall(_geometry_name(o))
        rays = frozenset((nm[0], nm[2])) if len(nm) == 3 and \
            nm[1] == at else None
        kind = [r for r in rels if r.get("type") == "angle"]
        mine = [r for r in kind if str(r.get("at")) == at and
                (rays is None or (_r2_ang(r) or (None, None))[1] == rays)]
        what = "the angle at %s" % at
    else:
        s = _r2_seg(f)
        kind = [r for r in rels if r.get("type") == "length"]
        mine = [r for r in kind if s is not None and
                _r2_seg(r.get("of")) == s]
        what = "the segment %s" % f
    if mine:
        if any(_r2_val(r.get("value")) == v for r in mine):
            return []
        return ["%s: label %s (%r) is `for` %s, but %s is given as %s"
                % (where, lid, t, f, what, ", ".join(
                    str(r.get("value")) for r in mine))]
    other = [r for r in kind if _r2_val(r.get("value")) == v]
    if other:
        return ["%s: label %s (%r) is `for` %s, but %s states no value "
                "and %s is the value of %s" % (
                    where, lid, t, f, what, t,
                    r2_name(other[0]))]
    return []


def r2_name(r):
    if r.get("type") == "angle":
        a = _r2_ang(r)
        return "the angle at %s" % (a[0] if a else "?")
    return "the segment %s" % r.get("of")


def label_faults(F, sheet_fig=None):
    """(v6.10 fix r2, label-for-integrity + R1-vm-for) [reason] -- every
    numeric label of a figure -- objects.labels, its visual_model copy,
    the sheet.json figure's copy and an aux patch's label -- carries `for`,
    names the object whose value it prints (label_states), and every copy
    of one label names the SAME object."""
    vm = F.get("visual_model") if isinstance(F, dict) else None
    if not isinstance(vm, dict) or vm.get("visual_support") == "unsupported":
        return []
    out = []
    fid = F.get("id")
    flat = dict((o.get("svg_id"), o) for o in
                (F.get("objects") or {}).get("labels") or []
                if isinstance(o, dict))
    for o in flat.values():
        out += label_states(o, vm, "noam-ai %s objects.labels" % fid)
    for o in ((sheet_fig or {}).get("objects") or {}).get("labels") or []:
        if not isinstance(o, dict):
            continue
        t = str(o.get("text", o.get("name", "")) or "")
        if not r2_numeric(t):
            continue
        out += label_states(o, vm, "sheet.json %s" % fid)
        fo = flat.get(o.get("svg_id"))
        if fo is not None and fo.get("for") != o.get("for"):
            out.append("sheet.json %s label %s is `for` %s, noam-ai.json "
                       "says %s" % (fid, o.get("svg_id"), o.get("for"),
                                    fo.get("for")))
    for o in vm.get("objects") or []:
        if not isinstance(o, dict) or o.get("type") != "label":
            continue
        t = str(o.get("text", o.get("name", "")) or "")
        if not r2_numeric(t):
            continue
        fo = flat.get(o.get("svg_id"))
        if not o.get("for"):
            out.append("visual_model %s label %s (%r) has no `for`"
                       % (fid, o.get("id"), t))
            continue
        if fo is not None and fo.get("for") != o.get("for"):
            out.append("visual_model %s label %s is `for` %s, "
                       "objects.labels says %s" % (fid, o.get("id"),
                                                   o.get("for"),
                                                   fo.get("for")))
        out += label_states(o, vm, "visual_model %s" % fid)
    for a in vm.get("aux") or []:
        for op in (a.get("ops") or []) if isinstance(a, dict) else []:
            for o in (op.get("objects") or []) if isinstance(op, dict) \
                    else []:
                if not isinstance(o, dict) or o.get("type") != "label":
                    continue
                t = str(o.get("text", o.get("name", "")) or "")
                if not r2_numeric(t):
                    continue
                if not o.get("for"):
                    out.append("aux %s label %s (%r) has no `for`"
                               % (a.get("id"), o.get("id"), t))
                    continue
                out += label_states(o, vm, "aux %s" % a.get("id"))
    return out


def _pt_lines(t):
    """(v6.13 fix_r2) a row's text as its printed lines: a spec stem joined
    by the "\n" connector is the sheet's list of stem lines"""
    if isinstance(t, list):
        return [str(x) for x in t]
    t = str(t or "")
    return t.split("\n") if "\n" in t else t


def public_text_faults(pub, docs):
    """(v6.10 fix r2, R1-s1-consistent) [reason] -- the public spec says
    what the sheet prints: every question / item text of
    wspec/public_spec.json is the text of the same row in each document
    given ([(name, doc)]: sheet.json, noam-ai.json), and every row of a
    spec question is in it."""
    out = []
    pq = {}
    for q in (pub or {}).get("questions") or []:
        if not isinstance(q, dict):
            continue
        pq[q.get("id")] = q
        for it in q.get("items") or []:
            if isinstance(it, dict):
                pq[it.get("id")] = it
    for name, doc in docs:
        for q in (doc or {}).get("questions") or []:
            if not isinstance(q, dict) or q.get("id") not in pq:
                continue
            for r in [q] + [x for x in q.get("items") or []
                            if isinstance(x, dict)]:
                sc = pq.get(r.get("id"))
                if sc is None:
                    out.append("%s row %s of spec question %s is not in "
                               "the public spec" % (name, r.get("id"),
                                                    q.get("id")))
                elif _pt_lines(sc.get("text")) != _pt_lines(r.get("text")):
                    out.append("%s row %s prints %r; the public spec says "
                               "%r" % (name, r.get("id"),
                                       str(r.get("text"))[:70],
                                       str(sc.get("text"))[:70]))
    return out
# ---- end of the v6.10 fix r2 block ----------------------------------------

_W1_DERIVE = (
    "import json, sys\n"
    "sys.path.insert(0, sys.argv[1])\n"
    "from wspec import project as P, templates as T\n"
    "ls = json.load(open(sys.argv[2], encoding='utf-8'))\n"
    "m = (ls.get('public_model') or {}).get('mode')\n"
    "sys.stdout.write(json.dumps(P.public_model(ls['spec'], "
    "T.load_templates(), mode=m), ensure_ascii=False, sort_keys=True))\n")


def _w1_version(b):
    m = re.match(r"\s*(\d+)\.(\d+)", str((b or {}).get("skill_version") or ""))
    return (int(m.group(1)), int(m.group(2))) if m else (0, 0)


def check_public_spec(level, sheet, b, nj, errs):
    """W1 (v6.10 fix r2, R1-s1-consistent): the public spec of a spec level
    is bound to what the sheet PRINTS and to the spec the build USED, so an
    export that is consistent (hashes updated) but wrong fails:
      - every question / item text of wspec/public_spec.json is the text of
        the same row of sheet.json and noam-ai.json (public_text_faults);
      - it is, canonically, the public model re-derived by the skill's
        engine (WORKSHEET_SKILL_DIR or this file's folder, in a separate
        process, as R1 re-runs the figure code) from source/level_spec.json,
        which build.json's wspec.level_spec names -- required from skill
        6.10 on."""
    ws = (b or {}).get("wspec") or {}
    if not ws.get("figures") and not ws.get("level_spec"):
        return
    pp = os.path.join(level, ws.get("public_spec") or
                      os.path.join("wspec", "public_spec.json"))
    try:
        with open(pp, encoding="utf-8") as fh:
            pub = json.load(fh)
    except (OSError, ValueError):
        return                  # E3 names the missing / unreadable spec
    for w in public_text_faults(pub, (("sheet.json", sheet),
                                      ("noam-ai.json", nj))):
        errs.append("W1 " + w)
    lsr = ws.get("level_spec")
    if not lsr:
        if _w1_version(b) >= (6, 10):
            errs.append("W1 build.json wspec names no level_spec: the public "
                        "spec cannot be re-derived from the spec the build "
                        "used")
        return
    lp = os.path.join(level, lsr)
    if not os.path.isfile(lp):
        errs.append("W1 %s (build.json wspec.level_spec) is missing" % lsr)
        return
    sd = skill_dir()
    if sd is None:
        errs.append("W1 no skill folder (WORKSHEET_SKILL_DIR) to re-derive "
                    "the public spec from %s" % lsr)
        return
    r = None
    try:
        r = subprocess.run([sys.executable, "-c", _W1_DERIVE, sd, lp],
                           capture_output=True, timeout=600)
        got = json.loads(r.stdout.decode("utf-8")) if r.returncode == 0 \
            else None
    except (subprocess.TimeoutExpired, ValueError):
        got = None
    if got is None:
        errs.append("W1 %s has no public model (the engine refuses it): %s"
                    % (lsr, r.stderr.decode("utf-8", "replace").strip()
                       .splitlines()[-1:] if r is not None else "timeout"))
        return
    if json.dumps(got, ensure_ascii=False, sort_keys=True) != \
            json.dumps(pub, ensure_ascii=False, sort_keys=True):
        diff = [k for k in sorted(set(got) | set(pub))
                if json.dumps(got.get(k), sort_keys=True) !=
                json.dumps(pub.get(k), sort_keys=True)]
        errs.append("W1 wspec/public_spec.json is not the public model of "
                    "%s (differs in: %s)" % (lsr, ", ".join(diff)))


def check_vm_parts(level, nj, errs):
    """V1 (v6.9 fix r1, C1): the parts of an engine figure's visual_model
    object DRAW that object -- not only exist once in the SVG (K16 / V2 /
    O2 check that). Measured on the delivered SVG against the points'
    svg_xy (TOL px):
      point    its dot part is a circle centred on its svg_xy;
      segment  every straight-stroke part carries both ends (or its span's
               two points) on one straight piece -- so seg:AC mapped to the
               line of BD fails; at least one part is such a stroke;
      angle    every straight-stroke part carries the vertex and one of
               the two arm points on one piece (an arm from the vertex);
      polygon  every straight-stroke part carries a side (two consecutive
               vertices) on one piece.
    A highlight on the wrong line would otherwise pass all three checks."""
    if not nj:
        return
    for F in nj.get("figures") or []:
        vm = F.get("visual_model") or F
        objs = vm.get("objects") or []
        if not any(o.get("parts") for o in objs):
            continue
        fid = vm.get("id") or F.get("id")
        path = os.path.join(level, vm.get("svg") or F.get("svg") or "")
        if not os.path.isfile(path):
            continue
        svg = Svg(path)
        P = dict((_geometry_name(o), tuple(o["svg_xy"])) for o in objs
                 if o.get("type") == "point" and o.get("svg_xy"))
        for o in objs:
            parts = o.get("parts") or []
            if not parts:
                continue
            ty, nm = o.get("type"), _geometry_name(o)
            names = re.findall(r"[A-Z][0-9]*'*", nm)
            if any(n not in P for n in names):
                continue
            strokes = 0
            for pt in parts:
                sid = pt.get("svg_id")
                if sid not in svg.ids:
                    continue                          # K16 / V2 say so
                span = pt.get("span")
                if span and not span_own(ty, names, [str(x) for x in span],
                                         P):
                    errs.append("%s V1 %s: part %s spans %r, which is not a "
                                "piece of %s itself (a span names the "
                                "object's own points: a segment's points, "
                                "an angle's vertex and a point of one of its "
                                "arms, a polygon's side)"
                                % (fid, o["id"], sid, span, nm))
                    continue
                el_tag = tag(svg.ids[sid][0])
                if ty == "point":
                    centre = o.get("svg_xy")
                    if not isinstance(centre, (list, tuple)) or len(centre) != 2:
                        errs.append("%s V1 %s: point has no svg_xy" % (fid, o["id"]))
                        continue
                    if el_tag == "circle":
                        k, ep = svg.element_pts(sid)
                        if not ep or not near(ep[0], centre):
                            errs.append("%s V1 %s: its dot part %s is not at "
                                        "its svg_xy" % (fid, o["id"], sid))
                    elif o.get("marker") == "square" and el_tag == "path":
                        # Unnamed data squares are closed native M/L/Z paths.
                        # Measure the actual four corners, never infer a name.
                        actual = _native_square_centre(svg, sid)
                        if actual is None or not near(actual, centre):
                            errs.append("%s V1 %s: square part %s does not match its svg_xy" % (fid, o["id"], sid))
                    continue
                el = svg.ids[sid][0]
                if el_tag not in ("line", "polygon", "polyline") or not any(
                        el.get(h) is not None for h in (
                            "data-seg", "data-poly", "data-line",
                            "data-ray", "data-locus")):
                    continue      # a caption / arc / tick / right-angle mark
                strokes += 1
                if ty == "segment":
                    ends = [P[n] for n in (span or names[:1] + names[-1:])
                            if n in P]
                    if len(ends) != 2 or not _one_edge(svg, sid, *ends):
                        errs.append("%s V1 %s: part %s does not draw it (its "
                                    "ends %s are not on that stroke)"
                                    % (fid, o["id"], sid, span or nm))
                elif ty == "angle" and len(names) == 3:
                    a, v, b = names
                    two = [P[n] for n in span] if span and all(
                        n in P for n in span) else None
                    ok = (two is not None and v in span and
                          _one_edge(svg, sid, *two)) or (
                        two is None and (_one_edge(svg, sid, P[v], P[a]) or
                                         _one_edge(svg, sid, P[v], P[b])))
                    if not ok:
                        errs.append("%s V1 %s: part %s is not an arm from "
                                    "its vertex %s" % (fid, o["id"], sid, v))
                elif ty == "polygon" and len(names) >= 3:
                    cyc = list(zip(names, names[1:] + names[:1]))
                    ok = any(_one_edge(svg, sid, P[x], P[y]) for x, y in cyc)
                    if not ok:
                        errs.append("%s V1 %s: part %s draws no side of it"
                                    % (fid, o["id"], sid))
            if ty in ("segment", "polygon") and strokes == 0:
                errs.append("%s V1 %s: no part of it is a drawn stroke"
                            % (fid, o["id"]))


# ---- C1r2 (v6.10): what a highlight paints IS its object ------------------
# The same block is in tools/highlight.py, verify_export.py and
# selfcheck_noam_package.py (each file stays stdlib-only and independent;
# selfcheck_v610_gaps.py proves the three copies are identical).
_U_TOL = 1.0
_U_NAMES = re.compile(r"[A-Z][0-9]*'*")
_U_UNITS = re.compile(r"-?\d*\.?\d+(?:[eE][-+]?\d+)?")


def _u_d(p, a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    L = dx * dx + dy * dy
    t = 0 if L == 0 else max(0, min(1, ((p[0] - a[0]) * dx +
                                        (p[1] - a[1]) * dy) / L))
    return math.hypot(p[0] - a[0] - t * dx, p[1] - a[1] - t * dy)


def _u_ray(v, a, x, tol):
    """x lies on the ray from v through a (not at v)."""
    ux, uy = a[0] - v[0], a[1] - v[1]
    dx, dy = x[0] - v[0], x[1] - v[1]
    L = math.hypot(ux, uy)
    if L == 0 or math.hypot(dx, dy) <= tol:
        return False
    return (ux * dx + uy * dy) > 0 and abs(ux * dy - uy * dx) / L <= tol


def _u_cover(pieces, a, b, tol):
    """The part of segment a-b that the pieces (each lying on it) leave
    unpainted: [(t0, t1)] in px along a-b, gaps longer than tol."""
    L = math.hypot(b[0] - a[0], b[1] - a[1])
    if L <= tol:
        return []
    ux, uy = (b[0] - a[0]) / L, (b[1] - a[1]) / L
    iv = sorted(sorted(((p[0] - a[0]) * ux + (p[1] - a[1]) * uy,
                        (q[0] - a[0]) * ux + (q[1] - a[1]) * uy))
                for p, q in pieces)
    gaps, at = [], 0.0
    for s, e in iv:
        if s - at > tol:
            gaps.append((at, s))
        at = max(at, e)
    if L - at > tol:
        gaps.append((at, L))
    return gaps


def _u_mark_angle(s):
    """'arc ACB' / 'right AHB' / 'ang ACB' -> (vertex, {arm, arm})."""
    n = _U_NAMES.findall(str(s or "").split(" ", 1)[-1])
    return (n[1], frozenset((n[0], n[2]))) if len(n) == 3 else None


def _geometry_name(o):
    """Stable native references are separate from learner-facing names.

    An explicitly unnamed foot is a point with part=anchor and its native
    point ID. Native segment/angle IDs still identify their endpoints;
    all normal measured-ink/parts checks continue to run on those endpoints.
    """
    if o.get("name"):
        return str(o["name"])
    ty, oid = o.get("type"), str(o.get("id") or "")
    if ty == "point" and o.get("part") == "anchor" and re.fullmatch(r"[A-Z][0-9]*'*", oid):
        return oid
    prefix = {"segment": "seg:", "angle": "ang:"}.get(ty)
    if prefix and oid.startswith(prefix):
        tail = oid[len(prefix):]
        names = re.findall(r"[A-Z][0-9]*'*", tail)
        if "".join(names) == tail and len(names) == (2 if ty == "segment" else 3):
            return tail
    return ""


def _u_point(o, pts, elem, tol):
    """(v6.10 fix r1, m2) a POINT paints its own dot and its own letter
    only: a circle / point group at the point's place, a label whose
    data-for names it. A point object re-pointed at another point's dot is
    a fault."""
    nm = _geometry_name(o)
    if not nm:
        return []
    P = pts.get(nm)
    if P is None:
        return ["point %s is not a drawn point of the model" % nm]
    P = (float(P[0]), float(P[1]))
    parts = o.get("parts")
    if not (isinstance(parts, list) and parts):
        parts = [{"svg_id": o["svg_id"]}] if o.get("svg_id") else []
    out = []
    for pt in parts:
        sid = pt.get("svg_id") if isinstance(pt, dict) else None
        e = elem(sid) if sid else None
        if e is None:
            out.append("part %s is not one element of the SVG" % sid)
            continue
        tag, a, geom = e
        if tag == "circle":
            # an engine dot names its point (data-pt) and sits at it; a
            # bare circle (a builder's, maybe under a transform this reader
            # does not apply) is judged by its name hook only when it has
            # one
            if a.get("data-pt") is not None and (
                    a.get("data-pt") != nm or not geom or
                    abs(geom[0][0] - P[0]) > tol or
                    abs(geom[0][1] - P[1]) > tol):
                out.append("part %s is not the dot of %s" % (sid, nm))
        elif tag == "text":
            if a.get("data-for") != nm:
                out.append("part %s is not the letter of %s" % (sid, nm))
        elif tag == "g":
            xy = _U_UNITS.findall(a.get("data-xy") or "")
            if a.get("data-kind") != "point" or len(xy) != 2 or \
                    abs(float(xy[0]) - P[0]) > tol or \
                    abs(float(xy[1]) - P[1]) > tol:
                out.append("part %s is not the point %s" % (sid, nm))
        else:
            out.append("part %s (%s) is not a point's ink" % (sid, tag))
    return out


def union_faults(o, pts, elem, tol=_U_TOL):
    """C1r2: the geometric UNION of what highlighting object o paints --
    its parts after span limits (a part without span paints its whole
    element) -- equals the object: no ink outside it, no piece of it left
    unpainted.
      segment  exactly its two points' segment;
      angle    exactly its two arms (vertex -> each named point), plus a
               sector mark: an arc / right-angle mark of THIS angle among
               its parts, or room for the focus arc highlight draws;
               a caption part must be this angle's;
      polygon  exactly its sides, every side.
    A segment may also carry its own tick mark / length caption (the
    engine's data-mark "tick XY" / data-for "seg XY" naming it).
    o     a visual_model object (type, name, parts or svg_id, svg_xy)
    pts   {point name: (x, y)} -- the model's drawn points (svg px)
    elem  svg id -> None | (tag, attrs, [(x, y) ...]) in the same px:
          a line's two ends, a polyline's / polygon's vertices, a path's
          M/L points, a circle's centre, a text's anchor
    Returns [reason, ...]; [] when the highlight IS the object. Anything
    it cannot place is a fault (refuse, never guess)."""
    ty = o.get("type")
    if ty == "point":
        return _u_point(o, pts, elem, tol)
    if ty == "origin":                           # v6.16 gaps, corpus-v2 G2
        return _u_origin(o, elem)
    if ty == "polygon" and o.get("shown") is not None:     # v6.16 gaps, G1
        return _u_partial(o, pts, elem, tol)
    if ty not in ("segment", "angle", "polygon"):
        return []
    parts = o.get("parts")
    if not (isinstance(parts, list) and parts):
        parts = [{"svg_id": o["svg_id"]}] if o.get("svg_id") else []
    if not parts:
        return ["nothing is drawn to highlight"]
    nm = _geometry_name(o)
    names = _U_NAMES.findall(nm)
    P = dict((str(k), tuple(float(c) for c in v)) for k, v in pts.items())
    sx = o.get("svg_xy")
    if ty == "segment" and (not names or "".join(names) != nm) and \
            isinstance(sx, list) \
            and len(sx) == 2 and all(isinstance(p, list) for p in sx):
        # a stroke named by no points (a builder's data line, an axis) is
        # its two svg_xy ends; a name OF points must name drawn points
        names = ["#0", "#1"]
        P["#0"], P["#1"] = [(float(p[0]), float(p[1])) for p in sx]
    elif ty == "polygon" and (not names or "".join(names) != nm) and \
            isinstance(sx, list) and len(sx) >= 3 and \
            all(isinstance(p, list) and len(p) == 2 for p in sx):
        # v6.12 fix_r1 (M3): an UNNAMED data polygon (a bar of a chart)
        # is its svg_xy vertices, as an unnamed data stroke is its two ends
        names = ["#%d" % i for i in range(len(sx))]
        for i, p in enumerate(sx):
            P["#%d" % i] = (float(p[0]), float(p[1]))
    need = {"segment": 2, "angle": 3}.get(ty, 3)
    if len(names) < need or (ty != "polygon" and len(names) != need) or \
            any(n not in P for n in names):
        return ["its name %r does not place %d drawn point(s): the mapping "
                "is ambiguous" % (o.get("name"), need)]
    out, ink, marks = [], [], []
    for pt in parts:
        sid = pt.get("svg_id") if isinstance(pt, dict) else None
        e = elem(sid) if sid else None
        if e is None:
            out.append("part %s is not one element of the SVG" % sid)
            continue
        tag, a, geom = e
        dm = a.get("data-mark")
        span = pt.get("span")
        grp = tag == "g" and a.get("_edges") and not a.get("_other")
        if grp or (not dm and (tag in ("line", "polyline", "polygon") or
                               (tag == "path" and a.get("data-seg")))):
            edges = list(a["_edges"]) if grp else list(zip(geom, geom[1:]))
            if tag == "polygon" and len(geom) > 2:
                edges.append((geom[-1], geom[0]))
            if not edges:
                out.append("part %s draws no stroke" % sid)
                continue
            if span:
                sp = [str(x) for x in span] if isinstance(span, list) else []
                if len(sp) != 2 or sp[0] == sp[1] or \
                        any(x not in P for x in sp):
                    out.append("part %s: span %r is not two drawn points"
                               % (sid, span))
                    continue
                X, Y = P[sp[0]], P[sp[1]]
                if not any(_u_d(X, p, q) <= tol and _u_d(Y, p, q) <= tol
                           for p, q in edges):
                    out.append("part %s: span %s%s is not on that stroke"
                               % (sid, sp[0], sp[1]))
                    continue
                ink.append((X, Y, sid, "%s%s" % tuple(sp)))
            else:
                ink += [(p, q, sid, "whole") for p, q in edges]
        else:
            if span:
                out.append("part %s: a span on a %s (not a stroke)"
                           % (sid, tag))
            marks.append((sid, tag, a, geom))
    if ty == "segment":
        tg = [(names[0], names[1])]
    elif ty == "polygon":
        tg = list(zip(names, names[1:] + names[:1]))
    else:
        tg = [(names[1], names[0]), (names[1], names[2])]
    for p, q, sid, w in ink:
        if not any(_u_d(p, P[x], P[y]) <= tol and _u_d(q, P[x], P[y]) <= tol
                   for x, y in tg):
            out.append("extra ink: part %s (%s) paints (%.1f,%.1f)-(%.1f,%.1f)"
                       ", which is not %s" % (sid, w, p[0], p[1], q[0], q[1],
                                              {"segment": "the segment itself",
                                               "angle": "an arm of it"}.get(
                                                  ty, "a side of it")))
    for x, y in tg:
        on = [(p, q) for p, q, _s, _w in ink
              if _u_d(p, P[x], P[y]) <= tol and _u_d(q, P[x], P[y]) <= tol]
        gaps = _u_cover(on, P[x], P[y], tol)
        if gaps:
            out.append("missing: %s%s is not painted over %.1f of %.1f px"
                       % (x, y, sum(e - s for s, e in gaps),
                          math.hypot(P[y][0] - P[x][0],
                                     P[y][1] - P[x][1])))
    if ty != "angle":
        own = frozenset(names)
        for sid, tag, a, geom in marks:
            dm = str(a.get("data-mark") or "")
            df = str(a.get("data-for") or "")
            if ty == "segment" and tag == "text" and df.startswith("seg ") \
                    and frozenset(_U_NAMES.findall(df[4:])) == own:
                continue
            kd, _s, on = dm.partition(" ")
            if ty == "segment" and re.sub(r"\d+$", "", kd) in (
                    "tick", "par") and geom and \
                    frozenset(_U_NAMES.findall(on)) == own:
                # its own tick / parallel arrow: named for it, on it
                mid = (sum(p[0] for p in geom) / len(geom),
                       sum(p[1] for p in geom) / len(geom))
                if any(_u_d(q, P[names[0]], P[names[1]]) <= tol
                       for q in [mid] + list(geom)):
                    continue
            out.append("extra ink: part %s (a %s%s) is not a stroke or a "
                       "mark of it" % (sid, tag, " " + repr(dm or df)
                                       if dm or df else ""))
        return out
    V, A, B = P[names[1]], P[names[0]], P[names[2]]
    me = (names[1], frozenset((names[0], names[2])))
    sector = False
    for sid, tag, a, geom in marks:
        dm = a.get("data-mark") or ""
        if tag == "text":
            if _u_mark_angle(a.get("data-for")) != me:
                out.append("extra ink: caption %s belongs to %r, not this "
                           "angle" % (sid, a.get("data-for")))
            continue
        if _u_mark_angle(dm) != me:
            out.append("extra ink: part %s (%s %r) is no mark of this angle"
                       % (sid, tag, dm))
            continue
        kind = re.sub(r"\d+$", "", dm.split(" ", 1)[0])
        if kind == "arc" and len(geom) >= 2:
            r = [math.hypot(p[0] - V[0], p[1] - V[1]) for p in geom]
            onr = [p for p in geom if _u_ray(V, A, p, tol) or
                   _u_ray(V, B, p, tol)]
            if max(r) - min(r) > tol or min(r) <= tol or len(onr) < 2:
                out.append("part %s: its arc is not centred on %s from arm "
                           "to arm" % (sid, names[1]))
                continue
            sector = True
        elif kind == "right" and len(geom) == 3:
            e1, e3 = geom[0], geom[2]
            if not ((_u_ray(V, A, e1, tol) and _u_ray(V, B, e3, tol)) or
                    (_u_ray(V, B, e1, tol) and _u_ray(V, A, e3, tol))):
                out.append("part %s: its right-angle mark does not sit on "
                           "the arms at %s" % (sid, names[1]))
                continue
            sector = True
        else:
            out.append("part %s: a %s mark highlight cannot read" % (sid,
                                                                    kind))
    if not sector:
        la = math.hypot(A[0] - V[0], A[1] - V[1])
        lb = math.hypot(B[0] - V[0], B[1] - V[1])
        sw = math.degrees(abs((math.atan2(B[1] - V[1], B[0] - V[0]) -
                               math.atan2(A[1] - V[1], A[0] - V[0]) +
                               math.pi) % (2 * math.pi) - math.pi))
        if not (1.0 <= sw <= 179.0) or min(18.0, 0.45 * min(la, lb)) < 9.0:
            out.append("no sector: no arc / right-angle mark of it among its "
                       "parts and no room for a focus arc (%.1f deg)" % sw)
    return out


def _u_origin(o, elem):
    """(v6.16 gaps, corpus-v2 G2) the ORIGIN of a coordinate plane paints
    the two axis lines (they cross there) and the origin's printed '0' --
    both lines, the '0' when the figure prints one, nothing else."""
    parts = o.get("parts")
    if not (isinstance(parts, list) and parts):
        return ["nothing is drawn to highlight"]
    out, axes, zero = [], set(), False
    for pt in parts:
        sid = pt.get("svg_id") if isinstance(pt, dict) else None
        e = elem(sid) if sid else None
        if e is None:
            out.append("part %s is not one element of the SVG" % sid)
            continue
        tag, a, _geom = e
        if pt.get("span"):
            out.append("part %s: a span on the origin" % sid)
        elif tag == "line" and a.get("data-axis"):
            axes.add(a.get("data-axis"))
        elif tag == "text" and a.get("data-num") == "origin":
            zero = True
        else:
            out.append("extra ink: part %s (a %s) is not an axis line or the "
                       "origin's 0" % (sid, tag))
    if len(axes) != 2:
        out.append("the origin paints %d axis line(s), not the two that "
                   "cross there" % len(axes))
    allel = getattr(elem, "all", None) or {}
    if not zero and any(t == "text" and a.get("data-num") == "origin"
                        for hit in allel.values() for t, a in hit):
        out.append("missing: the origin's printed 0 is not painted")
    return out


def _u_partial(o, pts, elem, tol):
    """(v6.16 gaps, corpus-v2 G1) a PARTIAL polygon -- a polygon the figure
    shows only some vertices of ('shown'; the missing one is the answer) --
    paints exactly its shown part: the dots of its shown vertices, and each
    side between two consecutive shown vertices wholly when the figure draws
    it (a data segment / line / ray over it) -- nothing of a missing vertex,
    no ink off those sides."""
    nm = _geometry_name(o)
    names = _U_NAMES.findall(nm)
    shown = [str(x) for x in o.get("shown") or []] \
        if isinstance(o.get("shown"), list) else []
    P = dict((str(k), tuple(float(c) for c in v)) for k, v in pts.items())
    if "".join(names) != nm or len(names) < 3 or \
            len(set(names)) != len(names):
        return ["partial polygon %r: its name is not a polygon's" % nm]
    if not shown or len(set(shown)) >= len(names) or \
            any(x not in names for x in shown):
        return ["partial polygon %s: shown %r is not a proper part of its "
                "vertices" % (nm, shown)]
    if any(x not in P for x in shown):
        return ["partial polygon %s: a shown vertex is no drawn point" % nm]
    back = [x for x in names if x not in shown and x in P]
    if back:
        return ["partial polygon %s: its missing vertex %s is drawn"
                % (nm, ", ".join(back))]
    tg = [(x, y) for x, y in zip(names, names[1:] + names[:1])
          if x in shown and y in shown]
    parts = o.get("parts")
    if not (isinstance(parts, list) and parts):
        return ["nothing is drawn to highlight"]
    out, ink, dots = [], [], set()
    for pt in parts:
        sid = pt.get("svg_id") if isinstance(pt, dict) else None
        e = elem(sid) if sid else None
        if e is None:
            out.append("part %s is not one element of the SVG" % sid)
            continue
        tag, a, geom = e
        span = pt.get("span")
        if tag == "circle" and not span:
            n = str(a.get("data-pt") or "")
            if n in shown and geom and abs(geom[0][0] - P[n][0]) <= tol and \
                    abs(geom[0][1] - P[n][1]) <= tol:
                dots.add(n)
            else:
                out.append("extra ink: part %s is not the dot of a shown "
                           "vertex" % sid)
            continue
        if tag != "line" or a.get("data-mark") or len(geom) != 2:
            out.append("extra ink: part %s (a %s) is not a side or a dot of "
                       "it" % (sid, tag))
            continue
        if span:
            sp = [str(x) for x in span] if isinstance(span, list) else []
            if len(sp) != 2 or any(x not in P for x in sp) or \
                    not (_u_d(P[sp[0]], geom[0], geom[1]) <= tol and
                         _u_d(P[sp[1]], geom[0], geom[1]) <= tol):
                out.append("part %s: span %r is not two drawn points on "
                           "that stroke" % (sid, span))
                continue
            ink.append((P[sp[0]], P[sp[1]], sid))
        else:
            ink.append((geom[0], geom[1], sid))
    for p, q, sid in ink:
        if not any(_u_d(p, P[x], P[y]) <= tol and _u_d(q, P[x], P[y]) <= tol
                   for x, y in tg):
            out.append("extra ink: part %s paints (%.1f,%.1f)-(%.1f,%.1f), "
                       "which is no side between two shown vertices"
                       % (sid, p[0], p[1], q[0], q[1]))
    allel = getattr(elem, "all", None) or {}
    for x, y in tg:
        on = [(p, q) for p, q, _s in ink
              if _u_d(p, P[x], P[y]) <= tol and _u_d(q, P[x], P[y]) <= tol]
        drawn = any(t == "line" and (a.get("data-seg") or a.get("data-line")
                                     or a.get("data-ray")) and
                    _u_d(P[x], *_u_geom(t, a)) <= tol and
                    _u_d(P[y], *_u_geom(t, a)) <= tol
                    for hit in allel.values() for t, a in hit)
        if on or drawn:
            gaps = _u_cover(on, P[x], P[y], tol)
            if gaps:
                out.append("missing: %s%s is not painted over %.1f px"
                           % (x, y, sum(e_ - s_ for s_, e_ in gaps)))
    for x in shown:
        if x not in dots:
            out.append("missing: the dot of the shown vertex %s" % x)
    return out


def union_elem_of(svg_text):
    """svg id -> (tag, attrs, points) read from the SVG text as written
    (no transforms: the overlay is painted in the same frame)."""
    rx = re.compile(r"<(line|circle|path|polyline|polygon|rect|text|g)\b"
                    r"([^>]*?)/?>", re.S)
    at = re.compile(r'([\w:-]+)="([^"]*)"')
    found = {}
    for m in rx.finditer(svg_text):
        a = dict(at.findall(m.group(2)))
        if a.get("id"):
            if m.group(1) == "g":
                # a builder's group id: its child strokes are its ink
                a = dict(a, _edges=[], _other=0)
                depth = 0 if m.group(0).endswith("/>") else 1
                tok = re.compile(r"</g\s*>|" + rx.pattern, re.S)
                for c in tok.finditer(svg_text, m.end()):
                    if depth <= 0:
                        break
                    if c.group(0).startswith("</"):
                        depth -= 1
                        continue
                    if c.group(1) == "g":
                        depth += 0 if c.group(0).endswith("/>") else 1
                        continue
                    ca = dict(at.findall(c.group(2)))
                    cg = _u_geom(c.group(1), ca)
                    if c.group(1) in ("line", "polyline", "polygon") and \
                            not ca.get("data-mark") and len(cg) >= 2:
                        a["_edges"] += list(zip(cg, cg[1:])) + (
                            [(cg[-1], cg[0])] if c.group(1) == "polygon"
                            and len(cg) > 2 else [])
                    else:
                        a["_other"] += 1
            found.setdefault(a["id"], []).append((m.group(1), a))

    def elem(sid):
        hit = found.get(sid) or []
        if len(hit) != 1:
            return None
        tag, a = hit[0]
        return tag, a, _u_geom(tag, a)
    elem.all = found          # v6.16 gaps: what the figure draws (G1 / G2)
    return elem


def _u_geom(tag, a):
    g = lambda k: float(a.get(k, 0))                     # noqa: E731
    if tag == "line":
        return [(g("x1"), g("y1")), (g("x2"), g("y2"))]
    if tag == "circle":
        return [(g("cx"), g("cy"))]
    if tag == "text":
        return [(g("x"), g("y"))]
    if tag in ("polyline", "polygon"):
        v = [float(x) for x in _U_UNITS.findall(a.get("points", ""))]
        return list(zip(v[0::2], v[1::2]))
    if tag == "path":
        d = a.get("d", "")
        if re.search(r"[^ML\s\d.,eE+-]", d):
            return []                  # a curve: no straight pieces to read
        v = [float(x) for x in _U_UNITS.findall(d)]
        return list(zip(v[0::2], v[1::2]))
    return []
# ---- end of the C1r2 block -------------------------------------------------


def check_vm_union(level, nj, errs):
    """V2 (v6.10, Codex C1r2): for every segment / angle / polygon object
    of every figure's visual_model, the UNION of what tools/highlight.py
    would paint (its parts after span limits; an object without parts is
    its svg_id element) IS the object -- no ink outside it, no piece of it
    unpainted, an angle's sector shown. A package whose hashes were
    updated to match a tampered noam-ai.json fails here (hashes prove
    only that the files are the ones listed)."""
    if not nj:
        return
    for F in nj.get("figures") or []:
        vm = F.get("visual_model") or {}
        rel = vm.get("svg") or F.get("svg")
        path = os.path.join(level, rel or "")
        if not rel or not os.path.isfile(path):
            continue
        with open(path, encoding="utf-8") as fh:
            el = union_elem_of(fh.read())
        pts = dict((_geometry_name(o), tuple(o["svg_xy"]))
                   for o in vm.get("objects") or []
                   if o.get("type") == "point" and _geometry_name(o) and
                   isinstance(o.get("svg_xy"), list) and
                   len(o["svg_xy"]) == 2 and
                   not isinstance(o["svg_xy"][0], list))
        for o in vm.get("objects") or []:
            for why in union_faults(o, pts, el):
                errs.append("%s V2 %s: its highlight is not the object: %s"
                            % (vm.get("id") or F.get("id"), o.get("id"),
                               why))


# ---- E3 (v6.10, Codex E2): every engine figure ships ITS object map ------
_MAP_DRIVER = r'''
import io, runpy, sys
class _Out(object):
    def __init__(self):
        self.buffer = io.BytesIO()
    def write(self, s):
        pass
    def flush(self):
        pass
real = sys.stdout
sys.stdout = _Out()
g = runpy.run_path(sys.argv[1], run_name="__main__")
sys.stdout = real
sys.stdout.buffer.write(g["R"].dumps(g["out"]["object_map"]).encode("utf-8"))
'''
_ENGINE_SVG = re.compile(r'<g data-layer="[a-z]+"')
_ENGINE_ID = re.compile(r'\sid="(e\d{4})"')


# v6.13 integ (D5): frame family -> (engine id, SVG dialect) of its map
_FAMILY_ENGINE = {"coordinate_plane": ("wspec-coord/1.0.0",
                                       "wspec-coord-svg/1"),
                  "number_line": ("wspec-render-nl/1.0.0", "wspec-nl-svg/1"),
                  # (v6.16 integrate) a coordinate_plane figure carrying a
                  # "graph" model is the graph engine's; a pie chart's
                  "graph": ("wspec-graph-render/1.0.0", "wspec-graph-svg/1"),
                  "pie_chart": ("wspec-render-pie/1.0.0", "wspec-pie-svg/1")}


def required_engine_maps(level, sheet, b, nj):
    """{fid: [why ...]} -- the engine figures of the package, derived from
    what DESCRIBES the figures (build.json wspec.figures, sheet.json's
    figure entries, the figure scripts, the SVG dialect, the model's
    engine objects, the spec's own figure list for those), never only from
    the map files that happen to be present or the hash list."""
    req = {}

    def add(f, why):
        if f:
            req.setdefault(str(f), []).append(why)
    for f in ((b or {}).get("wspec") or {}).get("figures") or []:
        add(f, "build.json wspec.figures")
    for F in (sheet or {}).get("figures") or []:
        if F.get("kind") == "wspec" or F.get("map") or F.get("engine"):
            add(F.get("id"), "sheet.json (kind wspec / map / engine)")
    fd = os.path.join(level, "figures")
    for fn in sorted(os.listdir(fd)) if os.path.isdir(fd) else []:
        p = os.path.join(fd, fn)
        if fn.endswith(".py"):
            with open(p, encoding="utf-8", errors="replace") as fh:
                head = fh.read(2000)
            if re.search(r"#\s*kind:\s*wspec\.render\b", head):
                add(fn[:-3], "figures/%s (a wspec.render script)" % fn)
        elif fn.endswith(".svg"):
            with open(p, encoding="utf-8", errors="replace") as fh:
                t = fh.read()
            if _ENGINE_SVG.search(t) and _ENGINE_ID.search(t):
                add(fn[:-4], "figures/%s (the engine's SVG dialect)" % fn)
        elif fn.endswith(".map.json"):
            add(fn[:-len(".map.json")], "figures/%s" % fn)
    for F in (nj or {}).get("figures") or []:
        vm = F.get("visual_model") or {}
        if any(o.get("parts") for o in vm.get("objects") or []):
            add(F.get("id"), "noam-ai.json (engine object parts)")
    return req


def _parts_of_map(o):
    return [dict([("svg_id", p.get("element"))] +
                 ([("span", list(p["span"]))]
                  if p.get("span") not in (None, "whole") else []))
            for p in o.get("parts") or []]


def check_engine_maps(level, sheet, b, nj, errs):
    """E3 (v6.10, Codex E2): the maps an engine figure needs are derived
    from the figure list (required_engine_maps), and each one is ITS map:
      - figures/<fid>.map.json exists, is hashed in build.json, and
        sheet.json's entry names it;
      - map.figure is fid, its engine is the build's, its public_hash is
        wspec/public_spec.json's, whose figure list holds fid;
      - its elements are exactly the SVG's element ids, tag for tag;
      - every engine object of noam-ai.json carries exactly the map's
        parts (svg ids + spans);
      - re-rendered from the PUBLIC spec by figures/<fid>.py, the engine
        writes this map byte for byte (a map edited together with the
        model and the hashes fails here)."""
    req = required_engine_maps(level, sheet, b, nj)
    if not req:
        return
    files = (b or {}).get("files") or {}
    ws = (b or {}).get("wspec") or {}
    sheet_f = dict((F.get("id"), F) for F in (sheet or {}).get("figures")
                   or [])
    nj_f = dict((F.get("id"), F) for F in (nj or {}).get("figures") or [])
    pub = None
    pp = os.path.join(level, "wspec", "public_spec.json")
    if os.path.isfile(pp):
        try:
            with open(pp, encoding="utf-8") as fh:
                pub = json.load(fh)
        except ValueError:
            pub = None
    if pub is None:
        errs.append("E3 the package has engine figures (%s) but no readable "
                    "wspec/public_spec.json" % ", ".join(sorted(req)[:4]))
    pub_figs = set(f.get("id") for f in (pub or {}).get("figures") or []
                   if isinstance(f, dict))
    # v6.13 integ: {figure id: frame family} of the public spec's figures
    pub_fam = dict((f.get("id"), (f.get("frame") or {}).get("family"))
                   for f in (pub or {}).get("figures") or []
                   if isinstance(f, dict) and isinstance(f.get("frame"),
                                                         dict))
    # (v6.16 integrate) a graph figure: its map is hashed to the PUBLIC
    # graph model the public spec carries (itself inside the hashed spec)
    pub_graph = {}
    for f in (pub or {}).get("figures") or []:
        if isinstance(f, dict) and isinstance(f.get("graph"), dict):
            pub_fam[f.get("id")] = "graph"
            pub_graph[f.get("id")] = f["graph"].get("public_hash")
    sk = skill_dir()
    for fid in sorted(req):
        why = "; ".join(req[fid][:3])
        rel = "figures/%s.map.json" % fid
        mp = os.path.join(level, rel)
        if fid not in (ws.get("figures") or []):
            errs.append("E3 %s is an engine figure (%s) but build.json "
                        "wspec.figures does not list it" % (fid, why))
        if not os.path.isfile(mp):
            errs.append("E3 %s: %s is missing -- an engine figure (%s) "
                        "ships its object map" % (fid, rel, why))
            continue
        if rel not in files:
            errs.append("E3 %s: %s is not in build.json files (unhashed)"
                        % (fid, rel))
        F = sheet_f.get(fid)
        if F is None:
            errs.append("E3 %s: an engine figure that sheet.json does not "
                        "list" % fid)
        elif F.get("map") != rel:
            errs.append("E3 %s: sheet.json names map %r, not %s"
                        % (fid, F.get("map"), rel))
        try:
            with open(mp, encoding="utf-8") as fh:
                mtext = fh.read()
            m = json.loads(mtext)
        except ValueError:
            errs.append("E3 %s: %s is not JSON" % (fid, rel))
            continue
        if not isinstance(m, dict):
            errs.append("E3 %s: %s is not a map object" % (fid, rel))
            continue
        if m.get("figure") != fid:
            errs.append("E3 %s: %s is the map of figure %r" % (
                fid, rel, m.get("figure")))
        # v6.12 fix_r1 (t08_b D5) / v6.13 integ: the engine a figure's map
        # must name is decided by the FIGURE, per family: the public spec's
        # frame.family says which engine draws it (coordinate plane ->
        # wspec-coord, number line -> wspec-render-nl, each with its own
        # dialect); any other figure is the geometry engine, build.json's
        # wspec.engine. A family engine on another family's (or a geometry)
        # figure is refused.
        want_eng, want_dia = _FAMILY_ENGINE.get(
            pub_fam.get(fid), (ws.get("engine"), None))
        if want_eng and m.get("engine") != want_eng:
            errs.append("E3 %s: the map's engine %r is not %r, the engine "
                        "of this figure (%s)" % (
                            fid, m.get("engine"), want_eng,
                            pub_fam.get(fid) or "geometry: build.json "
                            "wspec.engine"))
        elif want_dia and m.get("dialect") != want_dia:
            errs.append("E3 %s: the map's dialect %r is not %r (the %s "
                        "engine's)" % (fid, m.get("dialect"), want_dia,
                                       pub_fam.get(fid)))
        if pub is not None:
            want_ph = pub_graph.get(fid) if fid in pub_graph else \
                pub.get("public_hash")
            if m.get("public_hash") != want_ph:
                errs.append("E3 %s: the map's public_hash is not "
                            "wspec/public_spec.json's (a map of another "
                            "spec)" % fid)
            if fid not in pub_figs:
                errs.append("E3 %s: the public spec has no figure %s"
                            % (fid, fid))
        svgp = os.path.join(level, "figures", "%s.svg" % fid)
        if os.path.isfile(svgp):
            with open(svgp, encoding="utf-8") as fh:
                el = union_elem_of(fh.read())
                fh.seek(0)
                ids = set(_ENGINE_ID.findall(fh.read()))
            me = m.get("elements") or {}
            if set(me) != ids:
                errs.append("E3 %s: the map's elements %s are not the SVG's "
                            "element ids %s" % (
                                fid, sorted(set(me) ^ ids)[:6], len(ids)))
            for k, v in sorted(me.items()):
                e = el(k)
                if e is not None and isinstance(v, dict) and \
                        v.get("tag") != e[0]:
                    errs.append("E3 %s: map element %s is a <%s>, the SVG "
                                "draws a <%s>" % (fid, k, v.get("tag"), e[0]))
        else:
            errs.append("E3 %s: figures/%s.svg is missing" % (fid, fid))
        mo = m.get("objects") or {}
        vm = (nj_f.get(fid) or {}).get("visual_model") or {}
        for o in vm.get("objects") or []:
            if not o.get("parts"):
                continue
            if o.get("id") not in mo:
                errs.append("E3 %s: model object %s has parts but the map "
                            "has no such object" % (fid, o.get("id")))
            elif _parts_of_map(mo[o["id"]]) != [
                    dict((k, v) for k, v in p.items() if k in (
                        "svg_id", "span")) for p in o["parts"]]:
                errs.append("E3 %s: model object %s's parts %s are not the "
                            "map's %s" % (fid, o["id"], o["parts"],
                                          _parts_of_map(mo[o["id"]])))
        py = os.path.join(level, "figures", "%s.py" % fid)
        if sk is None:
            errs.append("E3 %s: cannot re-render the map: set "
                        "WORKSHEET_SKILL_DIR" % fid)
            continue
        if not os.path.isfile(py):
            errs.append("E3 %s: figures/%s.py is missing" % (fid, fid))
            continue
        try:
            r = subprocess.run([sys.executable, "-c", _MAP_DRIVER,
                                os.path.abspath(py)], cwd=level,
                               env=dict(os.environ, WORKSHEET_SKILL_DIR=sk),
                               capture_output=True, timeout=300)
        except subprocess.TimeoutExpired:
            errs.append("E3 %s: re-rendering the map took over 300 s" % fid)
            continue
        if r.returncode != 0:
            errs.append("E3 %s: re-rendering the map fails: %s" % (
                fid, r.stderr.decode("utf-8", "replace").strip()
                .splitlines()[-1:]))
        elif r.stdout != mtext.encode("utf-8"):
            errs.append("E3 %s: %s is not the map the engine writes for "
                        "this figure from the public spec (re-rendered by "
                        "figures/%s.py)" % (fid, rel, fid))


_CLINE_LINE = {"parallel": u"המקביל", "perpendicular": u"המאונך"}


def _row_lines(row, k):
    """the claim lines of one row: sheet.json writes strings, noam-ai.json
    claim dicts (their 'text')."""
    out = []
    for c in row.get(k) or []:
        if isinstance(c, str):
            out.append(c)
        elif isinstance(c, dict):
            out.append(str(c.get("text") or ""))
        else:
            out.append(repr(c))
    return out


def _declared_claim_rows(q, scope, role):
    """Read the hashed public declarations independently of the builder."""
    return (((q.get("printed_claims") or {}).get("scopes") or {}).get(scope) or {}).get(role) or []


def _declared_claim_text(claim, role):
    value = claim.get("what" if role == "to_prove" else "text")
    parts = value if isinstance(value, list) else [value]
    return "; ".join(" ".join(x.replace("$", "").split()).strip() for x in parts)


def _declared_claim_line(claim, role):
    return (u"הערך " if role == "to_prove" else "") + _declared_claim_text(claim, role)


def _declared_metadata_rows(q, scope, role):
    """Independently derive every public metadata row, retaining duplicates."""
    rows = []
    for claim in _declared_claim_rows(q, scope, role):
        if role == "to_prove":
            expected = {"type": "find", "quantity": claim.get("quantity", "value"),
                        "what": _declared_claim_text(claim, role),
                        "text": _declared_claim_line(claim, role)}
            for key in ("unit", "of"):
                if key in claim:
                    expected[key] = claim[key]
        else:
            expected = {"type": "polygon" if "points" in claim or "polygon_entity" in claim else "point",
                        "text": _declared_claim_line(claim, role)}
            for key in ("point", "points"):
                if key in claim:
                    expected[key] = claim[key]
        rows.append(expected)
    return rows


def _declared_metadata_exact(q, scope, row, role):
    """Exact multiset for source-declared texts, never membership alone.

    Two legitimate queries may share their printed excerpt while differing
    in quantity. Conversely, appending a contradictory row with the same
    text must not bypass E4's ordinary textual comparison.
    """
    from collections import Counter
    expected = _declared_metadata_rows(q, scope, role)
    if not expected:
        return True
    texts = {r["text"] for r in expected}
    actual = [r for r in row.get(role) or []
              if (r if isinstance(r, str) else str(r.get("text") or "")
                  if isinstance(r, dict) else repr(r)) in texts]
    canonical = lambda r: json.dumps(r, sort_keys=True, ensure_ascii=False)
    return Counter(map(canonical, actual)) == Counter(map(canonical, expected))


def check_spec_rows(level, sheet, b, nj, errs):
    """E4 (v6.10 integrate): a spec question's rows say what its PUBLIC
    spec says. v6.10's new relations (linear, greater, not_parallel,
    inside, classify, ...) travel as text-only claims no figure can
    re-measure, so sheet.json / noam-ai.json edited together with their
    hashes would pass every other rule. For every question built from the
    spec (its id is a public question and a figure of it is in build.json
    wspec.figures), in sheet.json and in noam-ai.json:
      given        every line is a given line of its scope, of its
                   question, or a given / goal of an earlier item of the
                   question (released); every given line of the scope is
                   there (none dropped);
      to_prove     exactly the scope's target descriptions (none added,
                   none dropped);
      to_construct each line is a to_construct target of the scope or an
                   unnamed construction (cline) of the public spec, as
                   wspec_build words it ('ישר דרך P המקביל ל־AD').
    The public spec itself is bound by build.json's hash and E3."""
    ws = (b or {}).get("wspec") or {}
    figs = set(ws.get("figures") or [])
    if not figs:
        return
    pp = os.path.join(level, ws.get("public_spec") or
                      os.path.join("wspec", "public_spec.json"))
    try:
        with open(pp, encoding="utf-8") as fh:
            pub = json.load(fh)
    except (OSError, ValueError):
        return                  # E3 names the missing / unreadable spec
    ents = dict((e.get("id"), e) for e in pub.get("entities") or []
                if isinstance(e, dict))

    def ename(eid):
        e = ents.get(eid) or {}
        if e.get("kind") == "segment":
            return "".join(e.get("ends") or [])
        return str(e.get("name") or eid)
    clines = set()
    for e in ents.values():
        if e.get("kind") == "cline" and e.get("op") in _CLINE_LINE:
            clines.add(u"ישר דרך %s %s ל־%s" % (
                e.get("through"), _CLINE_LINE[e["op"]], ename(e.get("base"))))
    pq = dict((q.get("id"), q) for q in pub.get("questions") or []
              if isinstance(q, dict))

    def desc(sc, roles):
        return [str(t.get("description") or "") for t in
                sc.get("targets") or [] if t.get("role") in roles]
    for fname, doc in (("sheet.json", sheet), ("noam-ai.json", nj)):
        for q in (doc or {}).get("questions") or []:
            sq = pq.get(q.get("id"))
            rows = [q] + list(q.get("items") or [])
            if sq is None or not any((r.get("figure") or r.get(
                    "figure_id")) in figs for r in rows):
                continue
            ps = dict((it.get("id"), it) for it in sq.get("items") or [])
            ps[sq["id"]] = sq
            # (v6.13 fix_r2, NOITEM) a STEM ITEM -- the question's one item,
            # with no text of its own -- has no row: the question's row
            # carries its lines (wspec_build.expand_question)
            its = [it for it in sq.get("items") or [] if isinstance(it,
                                                                    dict)]
            if len(its) == 1 and not str(its[0].get("text") or "").strip() \
                    and not q.get("items"):
                ps[sq["id"]] = dict(sq, targets=list(
                    sq.get("targets") or []) + list(its[0].get("targets") or
                                                    []), given_lines=list(
                    sq.get("given_lines") or []) + list(
                    its[0].get("given_lines") or []))
            earlier = set(sq.get("given_lines") or [])
            for r in rows:
                sc = ps.get(r.get("id"))
                where = "E4 %s %s" % (fname, r.get("id"))
                if sc is None:
                    errs.append("%s: a row of spec question %s that the "
                                "public spec does not have" % (where,
                                                               sq["id"]))
                    continue
                own = list(sc.get("given_lines") or [])
                # (v6.14 F3) the printed scale / quoted calculation of the
                # scope, regenerated here from the public spec's bound
                # blocks (_printed_lines): allowed, and required
                own += [x for x in _printed_lines(pub, sc) if x not in own]
                allowed = earlier | set(own)
                got = _row_lines(r, "given")
                # (v6.10 fix r1, L1) a given an earlier item stated, carried
                # into this one (not printed again): its row line names that
                # item -- '∠OAB = 20° (נתון בסעיף ג)'. Accepted only when the
                # line is a given line of this scope AND of that earlier
                # item of the same question
                got = [_carried_line(x, own, sq) for x in got]
                for x in got:
                    if x not in allowed:
                        errs.append("%s: given %r is not a given of the "
                                    "public spec" % (where, x))
                for x in own:
                    if x not in got:
                        errs.append("%s: the public spec's given %r is "
                                    "missing" % (where, x))
                tp = _row_lines(r, "to_prove")
                want = desc(sc, ("to_prove", "target"))
                # An explicitly unsupported, targetless query can retain
                # its source-backed description. This declaration is
                # schema-checked and rederived from source by E3/W1; no
                # undeclared source substring is accepted here.
                want += [_declared_claim_line(c, "to_prove") for c in
                         _declared_claim_rows(sq, sc["id"], "to_prove")]
                for claim in _declared_claim_rows(sq, sc["id"], "to_prove"):
                    if not q.get("spec_unsupported"):
                        errs.append("%s: preserved targetless query lost its unsupported marker" % where)
                    if fname == "noam-ai.json":
                        expected = {"type": "find", "quantity": claim.get("quantity", "value"),
                                    "what": _declared_claim_text(claim, "to_prove"),
                                    "text": _declared_claim_line(claim, "to_prove")}
                        if "unit" in claim:
                            expected["unit"] = claim["unit"]
                        if "of" in claim:
                            expected["of"] = claim["of"]
                        if expected not in (r.get("to_prove") or []):
                            errs.append("%s: preserved query metadata differs from its public declaration" % where)
                if fname == "noam-ai.json" and not _declared_metadata_exact(sq, sc["id"], r, "to_prove"):
                    errs.append("%s: preserved query metadata multiplicity/content differs from its public declarations" % where)
                # (v6.16 integrate) the GRAPH finds of the scope (public
                # graph models of the spec's figures) are rows too: one
                # metadata line each, which prints no number the scope's
                # text does not print (W-META-LINES-3)
                gf = [f for g in pub.get("figures") or [] if isinstance(
                    g, dict) and isinstance(g.get("graph"), dict)
                    for f in g["graph"].get("finds") or []
                    if f.get("item") == r.get("id")]
                if gf:
                    extra = [x for x in tp if x not in want]
                    if len(extra) != len(gf):
                        errs.append("%s: %d graph find row(s) %r for the "
                                    "public spec's %d graph find(s) %s" % (
                                        where, len(extra), extra, len(gf),
                                        [f.get("id") for f in gf]))
                    txt_nums = set(re.findall(r"\d+(?:\.\d+)?", u" ".join(
                        [str(sc.get("text") or ""),
                         str(sq.get("text") or "")] + [
                            str((c.get("label") or {}).get("text") or "")
                            for g in pub.get("figures") or []
                            if isinstance(g, dict) and
                            isinstance(g.get("graph"), dict)
                            for c in g["graph"].get("curves") or []])))
                    for x in extra:
                        new = set(re.findall(r"\d+(?:\.\d+)?", x)) - \
                            txt_nums
                        if new:
                            errs.append("%s: the graph find row %r prints "
                                        "%s, which the item does not"
                                        % (where, x, sorted(new)))
                    tp = [x for x in tp if x in want]
                if sorted(set(tp)) != sorted(set(want)):
                    errs.append("%s: to_prove %r is not the public spec's "
                                "targets %r" % (where, tp, want))
                # v6.13 integ: a to_plot target (the student marks a point /
                # number) is a construction row, as the builder writes it
                ok_tc = set(desc(sc, ("to_construct", "to_plot"))) | clines
                # (v6.16 fix r1, K1 = T08B-D10; the t08_b skillfix) the point
                # whose coordinates the scope asks, shown in no figure
                # (wspec_build: 'הנקודה D')
                claimed_tc = {c.get("point") or c.get("polygon_entity") or ":".join(c.get("points") or []) or "data_points": _declared_claim_line(c, "to_construct")
                              for c in _declared_claim_rows(sq, sc["id"], "to_construct")}
                ok_tc |= set(claimed_tc.values())
                ok_tc |= set(claimed_tc.get(ename((t.get("args") or [""])[0]),
                                           u"הנקודה %s" % ename((t.get("args") or [""])[0]))
                             for t in sc.get("targets") or []
                             if t.get("rel") == "coordinate" and
                             (ents.get((t.get("args") or [""])[0]) or {}
                              ).get("kind") == "point")
                for x in claimed_tc.values():
                    if x not in _row_lines(r, "to_construct"):
                        errs.append("%s: the public spec's construction description %r is missing"
                                    % (where, x))
                if fname == "noam-ai.json":
                    for claim in _declared_claim_rows(sq, sc["id"], "to_construct"):
                        expected = {"type": "polygon" if "points" in claim or "polygon_entity" in claim else "point",
                                    "text": _declared_claim_line(claim, "to_construct")}
                        for k in ("point", "points"):
                            if k in claim:
                                expected[k] = claim[k]
                        if expected not in (r.get("to_construct") or []):
                            errs.append("%s: construction point metadata differs from its public declaration" % where)
                if fname == "noam-ai.json" and not _declared_metadata_exact(sq, sc["id"], r, "to_construct"):
                    errs.append("%s: construction metadata multiplicity/content differs from its public declarations" % where)
                for x in desc(sc, ("to_plot",)):
                    if x not in _row_lines(r, "to_construct"):
                        errs.append("%s: the public spec's plot target %r "
                                    "is not a to_construct line" % (where, x))
                for x in _row_lines(r, "to_construct"):
                    if x not in ok_tc:
                        errs.append("%s: to_construct %r is neither a "
                                    "construction target nor an unnamed "
                                    "construction of the public spec"
                                    % (where, x))
                if r is not q:
                    earlier |= set(own) | set(want)


_SCALE_UNIT = {"m": u"מטרים", "km": u"קילומטרים", "cm": u"סנטימטרים",
               "mm": u"מילימטרים"}


def _printed_lines(pub, sc):
    """(v6.14 F3) the given lines a spec scope carries beyond its
    given_lines, rebuilt from the public spec alone: each scale fact (rel
    'scale') the scope's bound blocks print, one line per (value, unit) --
    'כל יחידה מייצגת 10 מטרים' ('כל יחידה בציר x ...' for one axis) -- and
    each quoted calculation (bind 'calc') -- 'חישוב התלמיד: 6 − 6 = 0'
    ('החישוב שבשאלה: ...' when no student is named)."""
    facts = dict((f.get("id"), f) for f in pub.get("facts") or []
                 if isinstance(f, dict))
    blocks = [b for b in sc.get("bound") or [] if isinstance(b, dict)]
    printed = []
    for b in blocks:
        for fid in list(b.get("prints") or []) + [
                x for bd in b.get("bind") or [] for x in (
                    bd.get("fact") if isinstance(bd.get("fact"), list)
                    else [bd.get("fact")] if bd.get("fact") else [])]:
            if fid not in printed:
                printed.append(fid)
    out, groups = [], []
    for fid in printed:
        f = facts.get(fid) or {}
        if f.get("rel") != "scale" or f.get("item") != sc.get("id") or \
                f.get("unit") not in _SCALE_UNIT:
            continue
        k = (str(f.get("value")), f.get("unit"))
        for g in groups:
            if g[0] == k:
                g[1].append(f)
                break
        else:
            groups.append((k, [f]))
    for (v, u), fs in groups:
        try:
            x = float(v)
            v = str(int(x)) if x == int(x) else "%g" % x
        except ValueError:
            pass
        axes = [(f.get("args") or [""])[0] for f in fs]
        where = u"" if len(axes) == 2 else u" בציר %s" % axes[0][-1:]
        out.append(u"כל יחידה%s מייצגת %s %s" % (where, v, _SCALE_UNIT[u]))
    for b in blocks:
        for bd in b.get("bind") or []:
            if bd.get("calc"):
                who = u"חישוב התלמיד" if u"תלמיד" in (b.get("text") or "") \
                    else u"החישוב שבשאלה"
                ex = re.sub(r"\s*-\s*", u" \u2212 ", str(bd["calc"])).strip()
                out.append(u"%s: %s = %s" % (who, ex, str(bd.get("tok"))
                                             .replace("-", u"\u2212")))
    return out


_CARRIED = re.compile(u"^(.*) \\(נתון בסעיף (\\S+)\\)$")


def _carried_line(x, own, sq):
    m = _CARRIED.match(x)
    if not m or m.group(1) not in own:
        return x
    for it in sq.get("items") or []:
        if it.get("label") == m.group(2) and \
                m.group(1) in (it.get("given_lines") or []):
            return m.group(1)
    return x


def shipped_engine_figures(level):
    """(fix r2, E2r) the engine figures a package SHIPS, from its files --
    not from what build.json declares: figures/<fid>.map.json (an engine
    object map) and wspec/public_spec.json."""
    if not level:
        return [], False
    fd = os.path.join(level, "figures")
    figs = sorted(f[:-len(".map.json")] for f in (
        os.listdir(fd) if os.path.isdir(fd) else [])
        if f.endswith(".map.json"))
    return figs, os.path.isfile(os.path.join(level, "wspec",
                                             "public_spec.json"))


def check_g80(level, b, errs, notes=None):
    """G80 (v6.11, Codex NEW-1): the PRINTED sheet.pdf is the verified
    text. Every question / item row of sheet.json is one bound block of
    sheet.html, emitted exactly from that row's text; sheet.html is rendered
    again with the skill's fonts, and each block of sheet.pdf is compared
    with the expected print -- its text layer (numbers, variables,
    operators, relations named in the error) and its raster (drawn maths:
    angle signs, fraction bars, roots) -- and so is the rest of each page.
    The build's record (build.json text_binding) must be where the blocks
    print. Runs in a separate process (textbind.py of the skill, as W1 and
    R1 do). FAIL and REVIEW are errors: ambiguity is never PASS. A
    package whose build recorded the binding must also carry
    checks.g80_text PASS."""
    if not os.path.isfile(os.path.join(level, "sheet.html")):
        return                           # S1 names the missing document
    if not os.path.isfile(os.path.join(level, "sheet.pdf")):
        # a package delivered without its PDF (a unit fixture: deliver()
        # with no pdf=) has no print to bind -- unless the build printed one
        if (b or {}).get("text_binding") is not None or (b or {}).get(
                "pages"):
            errs.append("G80 the package has no sheet.pdf, but build.json "
                        "says the build printed one (%s page(s)): the print "
                        "cannot be bound" % (b or {}).get("pages"))
        elif notes is not None:
            notes.append("G80 not run: no sheet.pdf in the package")
        return
    sd = skill_dir()
    tb = os.path.join(sd or "", "textbind.py")
    if not sd or not os.path.isfile(tb):
        errs.append("G80 no textbind.py in the skill folder (%s): the "
                    "printed text cannot be bound to sheet.json" % sd)
        return
    env = dict(os.environ, WORKSHEET_SKILL_DIR=sd)
    r = None
    why = None
    try:
        r = subprocess.run([sys.executable, tb, level, "--json"],
                           capture_output=True, timeout=900, env=env)
        rep = json.loads(r.stdout.decode("utf-8"))
    except subprocess.TimeoutExpired:
        rep, why = None, "timeout (900 s)"
    except ValueError:
        # v6.13 integ (v6.12 open n4): not a timeout -- textbind printed
        # something that is not its JSON report (e.g. WeasyPrint's import
        # warning when DYLD_FALLBACK_LIBRARY_PATH is not set); say so
        out = r.stdout.decode("utf-8", "replace").strip() if r else ""
        err = (r.stderr.decode("utf-8", "replace").strip().splitlines()
               or [""])[-1] if r else ""
        rep, why = None, ("textbind.py wrote no JSON report (exit %s; "
                          "stdout starts %r%s) -- on macOS set "
                          "DYLD_FALLBACK_LIBRARY_PATH=/opt/homebrew/lib"
                          % (r.returncode if r else "?", out[:80],
                             "; stderr: %s" % err[:120] if err else ""))
    if not isinstance(rep, dict):
        errs.append("G80 the binding check did not run: %s" % (
            why or "textbind.py returned %r, not a report" % (rep,)))
        return
    for f in rep.get("findings") or []:
        errs.append("G80 %s %s %s: %s" % (f.get("level"), f.get("code"),
                                          f.get("bind") or "-",
                                          f.get("detail")))
    if notes is not None:
        notes.extend("G80 " + n for n in rep.get("notes") or [])
    g = ((b or {}).get("checks") or {}).get("g80_text")
    if (b or {}).get("text_binding") is not None:
        if not isinstance(g, dict):
            errs.append("G80 build.json records text_binding but no "
                        "checks.g80_text: the build's gate did not run")
        elif g.get("status") != "PASS":
            errs.append("G80 build.json checks.g80_text is %r: a level "
                        "whose print is not bound is not delivered"
                        % g.get("status"))


def check_g81(level, b, errs, notes=None):
    """G81 (v6.11 fix r1, the author's W-ANGLE-3-LETTERS): no angle is
    named by its vertex alone (∠A, "זווית A") in sheet.json, noam-ai.json
    or the visible text of sheet.html; each error names the three-letter
    form. Run in a separate process (anglenames.py of the skill, as G80).
    A package with no sheet.pdf (a unit fixture) is checked only when its
    build recorded checks.g81_angles."""
    g = ((b or {}).get("checks") or {}).get("g81_angles")
    if not os.path.isfile(os.path.join(level, "sheet.pdf")) and g is None:
        if notes is not None:
            notes.append("G81 not run: no sheet.pdf in the package")
        return
    sd = skill_dir()
    an = os.path.join(sd or "", "anglenames.py")
    if not sd or not os.path.isfile(an):
        errs.append("G81 no anglenames.py in the skill folder (%s): the "
                    "angle names cannot be checked" % sd)
        return
    r = None
    try:
        r = subprocess.run([sys.executable, an, level, "--json"],
                           capture_output=True, timeout=300)
        rep = json.loads(r.stdout.decode("utf-8"))
    except (subprocess.TimeoutExpired, ValueError):
        rep = None
    if not isinstance(rep, dict):
        errs.append("G81 the angle-name check did not run: %s" % (
            (r.stderr.decode("utf-8", "replace").strip().splitlines()
             or ["timeout"])[-1] if r is not None else "timeout"))
        return
    for f in rep.get("findings") or []:
        errs.append("G81 %s %s: %r is an angle named by one letter -- "
                    "print %s (author rule W-ANGLE-3-LETTERS)" % (
                        f.get("file"), f.get("question") or f.get("where"),
                        f.get("found"), f.get("three_letters")))
    if isinstance(g, dict) and g.get("status") != "PASS":
        errs.append("G81 build.json checks.g81_angles is %r" %
                    g.get("status"))


def check_g82(b, errs):
    """G82 (v6.16 fix r1, the author's W-FIGURE-DENSITY): a level whose
    build recorded a figure reference PENDING the author (checks.
    g82_fig_ref, the level's fig_ref_pending) is not a finished package:
    each pending question is an error. A build before v6.16 records
    nothing (no error)."""
    g = ((b or {}).get("checks") or {}).get("g82_fig_ref")
    if not isinstance(g, dict) or g.get("status") == "PASS":
        return
    if g.get("status") == "AUTHOR_EXCEPTION" and not g.get("pending"):
        # (v6.16 fix r1 cont., V616-A4) the author's approved exception:
        # every row names an APPROVED decision of the skill's approvals file
        # (re-read here, so an edited build.json cannot grant one)
        import gate_figref as _GF
        rows = g.get("exceptions") or []
        if not rows:
            errs.append("G82 build.json checks.g82_fig_ref is "
                        "AUTHOR_EXCEPTION with no exception row")
        for p in rows:
            if _GF.author_decision(str(p.get("decision"))) is None:
                errs.append("G82 %s: the exception cites %r, which is no "
                            "APPROVED decision of the author "
                            "(wspec/approvals/APPROVALS_NOAM.json)"
                            % (p.get("question"), p.get("decision")))
        return
    for p in g.get("pending") or [{}]:
        errs.append("G82 build.json checks.g82_fig_ref is %r: %s %s refers "
                    "to a figure the sheet does not print (%s) -- the "
                    "author decides (%s)" % (
                        g.get("status"), p.get("question"), p.get("where"),
                        "/".join(p.get("words") or []), p.get("reason")))


def check_g84_num_clear(b, errs):
    """G84 NUM_CLEAR (v6.16 fix r2, verify-print P2-S5): the build measured,
    on the printed PDF, every figure text of every GRAPH figure against the
    figure's data strokes (>= 0.3 pt of blank; gate_numclear). A recorded
    FAIL is an error. A build before this rule, or a sheet with no graph
    figure, records nothing (no error)."""
    g = ((b or {}).get("checks") or {}).get("g84_num_clear")
    if not isinstance(g, dict) or g.get("status") in ("PASS", "NOT_RUN"):
        return
    for r in g.get("rows") or []:
        errs.append("G84 build.json checks.g84_num_clear is %r: %s %r on "
                    "page %s prints %s pt from a data stroke (the rule: at "
                    "least %s pt; cure: a display square for the figure)" % (
                        g.get("status"), r.get("figure"), r.get("glyph"),
                        r.get("page"), r.get("gap_pt"), g.get("min_pt")))
    for fid in g.get("not_located") or []:
        errs.append("G84 build.json checks.g84_num_clear is %r: the graph "
                    "figure %s was not located on the PDF (not measured)" % (
                        g.get("status"), fid))
    if not (g.get("rows") or g.get("not_located")):
        errs.append("G84 build.json checks.g84_num_clear is %r" %
                    (g.get("status"),))


def check_g83_room(b, errs):
    """G83 room (v6.16 fix r1 cont., the author's V616-A7): the build
    measured, on the printed PDF, the blank drawing space of every
    drawing-from-words question (>= 65 mm, no grid, no axes); a FAIL is an
    error. A build before this rule records nothing (no error)."""
    g = ((b or {}).get("checks") or {}).get("g83_room")
    if not isinstance(g, dict) or g.get("status") in ("PASS", "NOT_RUN"):
        return
    for r in g.get("rows") or [{}]:
        if r.get("ok"):
            continue
        errs.append("G83 build.json checks.g83_room is %r: %s leaves %s mm "
                    "of blank drawing space on the PDF (the author's rule: "
                    "at least %s mm, about %s mm)" % (
                        g.get("status"), r.get("question"), r.get("mm"),
                        g.get("min_mm"), g.get("target_mm")))


def check_g79(b, errs, level=None):
    """B2 (v6.9 fix r1, E2): a level with engine figures (build.json
    'wspec') ships only with the PDF gate G79-spec passed: g79_spec present,
    approved, OCR on, status PASS / ACCEPTED, and every engine figure
    judged PASS -- or ACCEPTED with the author's written reason. A REVIEW
    left open, a FAIL, OCR off or a missing record is an error (the build's
    exit code alone did not travel with the package)."""
    ws = b.get("wspec")
    shipped, pub = shipped_engine_figures(level)
    if not ws and (shipped or pub):
        # (fix r2, E2r) B2 used to run only when build.json said 'wspec':
        # deleting that key (with g79_spec) let engine figures through
        what = ["figures/%s.map.json" % f for f in shipped[:4]] + (
            ["wspec/public_spec.json"] if pub else [])
        errs.append("B2 the package ships engine figures (%s) but "
                    "build.json declares no 'wspec': the G79-spec verdict "
                    "cannot be checked" % ", ".join(what))
        ws = {"figures": shipped}
    if not ws:
        return
    missing = [f for f in shipped if f not in (ws.get("figures") or [])]
    if missing:
        errs.append("B2 engine figure(s) %s ship in figures/ but are not in "
                    "build.json wspec.figures (no G79-spec verdict is "
                    "required of them)" % ", ".join(missing))
        ws = dict(ws, figures=list(ws.get("figures") or []) + missing)
    g = (b.get("checks") or {}).get("g79_spec")
    if not isinstance(g, dict):
        errs.append("B2 build.json has engine figures (wspec) but no "
                    "checks.g79_spec: the PDF gate G79-spec did not run")
        return
    if g.get("status") not in ("PASS", "ACCEPTED") or \
            g.get("approved") is not True:
        errs.append("B2 build.json checks.g79_spec is %r (approved=%r): "
                    "a level with an open REVIEW or a FAIL is NOT APPROVED "
                    "and is not delivered" % (g.get("status"),
                                              g.get("approved")))
    if g.get("ocr") is not True:
        errs.append("B2 build.json checks.g79_spec ran with OCR off "
                    "(G79_OCR=0): never for a delivered sheet")
    figs = g.get("figures") or {}
    for fid in ws.get("figures") or []:
        r = figs.get(fid)
        if not isinstance(r, dict):
            errs.append("B2 engine figure %s has no G79-spec verdict" % fid)
            continue
        st = r.get("status")
        if st == "ACCEPTED" and not str(r.get("accepted") or "").strip():
            errs.append("B2 engine figure %s is ACCEPTED without the "
                        "author's reason" % fid)
        elif st not in ("PASS", "ACCEPTED"):
            errs.append("B2 engine figure %s: G79-spec %r" % (fid, st))
    c = g.get("counts") or {}
    if c.get("REVIEW") or c.get("FAIL"):
        errs.append("B2 build.json checks.g79_spec counts REVIEW %s FAIL %s"
                    % (c.get("REVIEW"), c.get("FAIL")))


def check_mark_coverage(F, errs):
    """M1 (v6.7-noam, R3-G7-mark-coverage-unchecked): every mark the figure
    prints (ticks, chevrons, a right angle, an angle arc) states a fact, so
    a MARKED constraint names it (mark_id, or mark_ids for a group) --
    deleting that constraint from the JSON must not pass. A tick group's
    constraint lists every one of its marks."""
    fid = F.get("id")
    named = {}
    for c in F.get("constraints") or []:
        if not c.get("marked"):
            continue
        for m in [c.get("mark_id")] + list(c.get("mark_ids") or []):
            if m:
                named.setdefault(m, c)
    ob = F.get("objects") or {}
    for o in list(ob.get("marks") or []) + list(ob.get("arcs") or []):
        if o.get("kind") not in MARK_KINDS or o.get("role") != "mark":
            continue
        i = oid(o)
        if i not in named:
            errs.append("%s M1 mark %s (%s) states no marked constraint"
                        % (fid, i, o.get("kind")))


def check_levels(results):
    """N2: several level folders are one package, keys a/b/c."""
    errs = []
    pk = set(r.get("package") for r in results)
    if len(pk) > 1:
        errs.append("N2 the levels name different packages: %s"
                    % sorted(map(str, pk)))
    keys = [r.get("key") for r in results]
    if len(set(keys)) != len(keys):
        errs.append("N2 a level key repeats: %s" % keys)
    if len(results) == 3 and sorted(map(str, keys)) != list(LEVELS):
        errs.append("N2 three levels must be a, b, c; got %s" % keys)
    return errs


if __name__ == "__main__":
    bad = 0
    results = []
    for lv in sys.argv[1:]:
        r = verify(lv)
        results.append(r)
        print("%s: figures %d objects %d constraints %d measured %d types %s sources %s re-run identical %d same-as-sheet %d errors %d notes %d"
              % (r["level"], r["figures"], r["objects"], r["constraints"], r["measured"],
                 r["by_type"], r["sources"], r["reran"], r["same_as_sheet"],
                 len(r["errors"]), len(r["notes"])))
        for e in r["errors"][:40] + r["notes"][:10]:
            print("   ", e)
        bad += len(r["errors"])
    if len(results) > 1:
        e2 = check_levels(results)
        for e in e2:
            print("   ", e)
        bad += len(e2)
    print("verify_export: %d error(s)" % bad)
    sys.exit(1 if bad else 0)
