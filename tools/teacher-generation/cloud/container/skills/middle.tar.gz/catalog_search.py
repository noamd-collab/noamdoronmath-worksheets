# -*- coding: utf-8 -*-
u"""catalog_search — v7.2.0. Find the sheet and the section a teacher means, typed the way people type Hebrew.

    python3 catalog_search.py QUERY [--catalog DIR ...] [--json] [--limit N]
    python3 catalog_search.py --selftest

WHY THIS EXISTS
---------------
The live site's teacher search is a substring match on topic titles inside one
grade (website.md §1c: NFKD, strip points, lowercase, `includes`). A teacher who
types "קדקודיות" (ktiv haser), "הזוויות הצמודות" (with the article), "3 אותיות"
or "שלוש אותיות" finds nothing, because none of those strings is a title.
Every v7.2 sheet now ships out/catalog/<sheet_id>/catalog-entry.json with its
sections, registry aliases and spelling variants; this module ranks the
SECTIONS of those entries, so the answer is "sheet G7-ANG-02, section s4,
#angles-vertical" and not just "some angle sheet".

It is stdlib only and reads nothing but catalog-entry.json files (plus, when it
sits next to the skill, curriculum_tashpaz.json to know each subtopic's home
sheet). It also owns the catalog-side vocabulary: `aliases_for` and
`search_variants_for` (the generated spellings stored in each section). They
live here, not in catalog_build, for two reasons: the stored strings and the
query normalization can never drift apart, and G89 (selfcheck_catalog, which
must run under `python3 -I` with the standard library only) loads this one file
and RECOMPUTES them, so an alias or variant that is not exactly what the
registry gives is caught instead of being trusted.

NORMALIZATION (query and catalog strings alike)
-----------------------------------------------
1. glossary_he.json matching.normalize: NFC; strip niqqud and cantillation
   U+0591–U+05C7 except maqaf U+05BE, U+05C0, U+05C3, U+05C6; ASCII ' → ׳,
   " → ״. Plus: drop invisible marks U+200B–U+200F, U+2060, U+FEFF and the
   bidi embeddings — emit_docx puts U+200D/U+200F into runs and a copied title
   may carry them.
2. `search_key`: final letters → regular (ך→כ, ם→מ, ן→נ, ף→פ, ץ→צ), maqaf and
   hyphens → space, geresh/gershayim dropped, other punctuation (°, ∡, $ …)
   → space, Latin lowercased, whitespace collapsed.
3. tokens: stop words (של, את, עם, על, או, גם, כל …) and lone prefix letters
   ("ב" left over from "ב־3") are dropped. Each token gets candidate forms:
   - stems: up to three leading prefixes ו ב כ ל מ ש ה stripped (remainder ≥ 3
     letters, or a number word);
   - number words → digits ("שלוש", "שלושה", "שלושת", "בשלוש" → "3"; "ב3" → "3");
   - fold (singular/plural): -יות → -ית, -ות → -ה, -ים → ∅, then final ה → ת,
     so צמודות/צמודה, קודקודיות/קודקודית, זוויות/זווית meet;
   - skeleton (ktiv male/haser): ו and י removed after the first letter, so
     קודקודיות/קדקודיות and זווית/זוית meet.

SCORING
-------
A query token matches a target token at the best of: same token 1.0 · same stem
0.95 · same fold 0.9 · same skeleton 0.8 · target starts with the query token
(≥ 4 letters, a half-typed word) 0.6. For one target string (a title, an alias,
a spelling variant):  q_cov = mean best match over query tokens,
t_cov = share of target tokens hit,  score = q_cov · (0.75 + 0.25 · t_cov),
times the field weight (title, alias 1.0; generated variant 0.97; a combo's
combined titles 0.5; sheet title 0.7). An exact normalized phrase scores
weight + 0.05. A section also gets 0.85 × the coverage of the query by ALL its
strings together, so "סימון זווית בשלוש אותיות" finds st.g7.angles.naming even
though no single alias holds the whole phrase. Ties: the subtopic's home sheet
(registry `sheet`) first, then real before synthetic, then the more focused
sheet (fewer sections).

PARTIAL HITS. A hit where some content token of the query matched NOTHING in
that section's strings is marked `partial` (with the `unmatched` tokens). Full
hits always rank before partial ones. Why: "ישרים מקבילים" shares only the word
"ישרים" with the vertical-angles alias "ישרים נחתכים"; without the flag it came
back as a confident top hit for a topic that is not in the catalog at all.

Exit status: 0 when at least one FULL hit was found; 1 when catalog entries
were read and searched but nothing matched or only partial hits did (they are
still printed, under a "partial" heading); 2 on a usage error (a --catalog
path that does not exist or is empty included), when no catalog-entry.json is found, when
none could be read, or on an internal error. 1 therefore always means "the
catalog was searched and has no full hit", never "there was nothing to search"
and never a crash.

MALFORMED ENTRIES. A catalog-entry.json that is not valid JSON, or whose fields
have the wrong types (see `entry_problem`: sections that are not objects, an id
or title that is not a string, aliases / search_variants / combines that are not
lists of strings, text that is not valid Unicode such as a lone surrogate) or
that nests too deeply to load, is skipped with a warning on stderr, so one half-written file
cannot hide all the good ones. search() also guards each entry on its own: an
unexpected error inside one entry skips that entry with a warning instead of
ending the run.

--json prints exactly one JSON object on every exit path: {query, normalized,
entries, skipped, full_hits, hits, error}, where `error` is null on exit 0/1 and
the message on exit 2 (then `hits` is empty). When stdout cannot encode Hebrew
(an ASCII or Latin-1 locale), the same object is printed with \\uXXXX escapes,
which is the same JSON value.
"""
import argparse
import json
import os
import re
import sys
import traceback
import unicodedata
from pathlib import Path

HERE = Path(__file__).resolve().parent

# ---------------------------------------------------------------- normalize --
_NIQQUD = re.compile(u"[\u0591-\u05BD\u05BF\u05C1\u05C2\u05C4\u05C5\u05C7]")
_INVISIBLE = re.compile(u"[\u200B-\u200F\u2060\uFEFF\u202A-\u202E\u2066-\u2069]")
_FINALS = str.maketrans(u"ךםןףץ", u"כמנפצ")
_TO_FINAL = {u"כ": u"ך", u"מ": u"ם", u"נ": u"ן", u"פ": u"ף", u"צ": u"ץ"}
_HEB_WORD = re.compile(u"^[א-ת]+$")
_PREFIX = u"ובכלמשה"


def normalize(text):
    """glossary_he.json matching.normalize + invisible marks: the form every term pattern expects."""
    t = unicodedata.normalize("NFC", text or u"")
    t = _INVISIBLE.sub(u"", t)
    t = _NIQQUD.sub(u"", t)
    return t.replace(u"'", u"׳").replace(u'"', u"״") \
            .replace(u"\u2019", u"\u05F3").replace(u"\u201D", u"\u05F4")


def search_key(text):
    """A flat, comparable form of a string: what `title_search` stores and what queries become."""
    t = normalize(text).translate(_FINALS).lower()
    t = re.sub(u"[\u05BE\\-\u2010-\u2015_/]", u" ", t)
    t = re.sub(u"[\u05F3\u05F4]", u"", t)
    t = re.sub(u"[^\\w\\s]", u" ", t)
    return re.sub(u"\\s+", u" ", t).strip()


def finalize(word):
    """Put back a final letter at the end of a Hebrew word (used when a rule strips a suffix)."""
    if word and word[-1] in _TO_FINAL:
        return word[:-1] + _TO_FINAL[word[-1]]
    return word


_NUMBER_WORDS = {
    "1": u"אחד אחת", "2": u"שתיים שתים שניים שתי שני", "3": u"שלוש שלושה שלושת",
    "4": u"ארבע ארבעה ארבעת", "5": u"חמש חמישה חמשת", "6": u"שש שישה ששת",
    "7": u"שבע שבעה שבעת", "8": u"שמונה שמונת", "9": u"תשע תשעה תשעת",
    "10": u"עשר עשרה עשרת", "20": u"עשרים", "30": u"שלושים", "40": u"ארבעים",
    "50": u"חמישים", "60": u"שישים", "70": u"שבעים", "80": u"שמונים", "90": u"תשעים",
    "100": u"מאה",
}
NUMBER_OF = {}
for _d, _ws in _NUMBER_WORDS.items():
    for _w in _ws.split():
        NUMBER_OF[_w.translate(_FINALS)] = _d
STOP = {w.translate(_FINALS) for w in u"של את עם על או גם כל זה זו אל מן אם".split()}


def _stems(w):
    out = [w]
    m = re.match(u"^[%s]{1,3}(\\d+)$" % _PREFIX, w)
    if m:
        return [m.group(1)]
    if not _HEB_WORD.match(w):
        return out
    for i in range(1, 4):
        if len(w) - i < 2 or w[i - 1] not in _PREFIX:
            break
        rest = w[i:]
        if len(rest) >= 3 or rest in NUMBER_OF:
            out.append(rest)
    return [NUMBER_OF.get(s, s) for s in out]


def fold(w):
    """Singular/plural fold on a final-letter-free token (see the module docstring)."""
    if not _HEB_WORD.match(w):
        return w
    if len(w) >= 5 and w.endswith(u"יות"):
        w = w[:-3] + u"ית"
    elif len(w) >= 5 and w.endswith(u"ות"):
        w = w[:-2] + u"ה"
    elif len(w) >= 5 and w.endswith(u"ימ"):
        w = w[:-2]
    if w.endswith(u"ה") and len(w) >= 3:
        w = w[:-1] + u"ת"
    return w


def skeleton(w):
    """ktiv male/haser fold: drop ו and י after the first letter."""
    if not _HEB_WORD.match(w) or len(w) < 3:
        return w
    return w[0] + re.sub(u"[וי]", u"", w[1:])


def tokens(text):
    """[{raw, stems, folds, skels}] for every content token of `text`."""
    out = []
    for w in search_key(text).split():
        if w in STOP or (len(w) == 1 and w in _PREFIX):
            continue
        st = _stems(w)
        fo = {fold(s) for s in st}
        raw = st[0] if st[0].isdigit() else NUMBER_OF.get(w, w)
        out.append({"raw": raw, "stems": set(st), "folds": fo,
                    "skels": {skeleton(f) for f in fo}})
    return out


def token_match(q, t):
    """The best match level between a query token and a target token (0 when none)."""
    if q["raw"] == t["raw"]:
        return 1.0
    if q["stems"] & t["stems"]:
        return 0.95
    if q["folds"] & t["folds"]:
        return 0.9
    if {s for s in q["skels"] if len(s) >= 2} & t["skels"]:
        return 0.8
    for qs in q["folds"]:
        if len(qs) >= 4 and _HEB_WORD.match(qs) and any(ts.startswith(qs[:-1] if qs.endswith(u"ת") else qs)
                                                      for ts in t["folds"] if len(ts) > len(qs)):
            return 0.6
    return 0.0


def phrase_score(qtok, text, weight=1.0, qkey=None):
    """Score of one target string for an already tokenized query."""
    if not qtok:
        return 0.0
    if qkey is not None and qkey == search_key(text):
        return weight + 0.05
    ttok = tokens(text)
    if not ttok:
        return 0.0
    total, hit = 0.0, set()
    for q in qtok:
        best, bi = 0.0, None
        for i, t in enumerate(ttok):
            m = token_match(q, t)
            if m > best:
                best, bi = m, i
        total += best
        if bi is not None:
            hit.add(bi)
    q_cov = total / len(qtok)
    t_cov = len(hit) / len(ttok)
    return weight * q_cov * (0.75 + 0.25 * t_cov)


def coverage(qtok, texts):
    """How much of the query ALL these strings cover together (each token's best match)."""
    if not qtok:
        return 0.0
    pool = [t for s in texts for t in tokens(s)]
    if not pool:
        return 0.0
    return sum(max(token_match(q, t) for t in pool) for q in qtok) / len(qtok)


def unmatched_tokens(qtok, texts):
    """Query tokens that match nothing at all in these strings (what makes a hit `partial`)."""
    pool = [t for s in texts for t in tokens(s)]
    return [finalize(q["raw"]) for q in qtok if not any(token_match(q, t) > 0 for t in pool)]


# ---------------------------------------------------- vocabulary (catalog side) --
# catalog_build stores these in every section; G89 recomputes them (see the docstring).
def dedupe(seq, skip=()):
    """Normalized, non-empty, first-occurrence order; anything equal to a `skip` string dropped."""
    seen = {normalize(x) for x in skip}
    out = []
    for x in seq:
        if not isinstance(x, str) or not x.strip():
            continue
        n = normalize(x).strip()
        if n in seen:
            continue
        seen.add(n)
        out.append(n)
    return out


def aliases_for(entry, glossary):
    """Registry aliases, then the glossary search_variants of every term the subtopic introduces."""
    al = list(entry.get("aliases") or [])
    for term in (entry.get("introduces") or {}).get("terms") or []:
        al += ((glossary or {}).get("terms", {}).get(term) or {}).get("search_variants") or []
    return dedupe(al)


_KTIV = ((u"קודקוד", u"קדקוד"), (u"קדקוד", u"קודקוד"), (u"זוויות", u"זויות"), (u"זויות", u"זוויות"),
         (u"זווית", u"זוית"), (u"זוית", u"זווית"), (u"שווה", u"שוה"), (u"שווי", u"שוי"))
_CONSTRUCT_HEADS = set(u"חוצה חוצי סכום הפרש מדידת סימון סוגי שוקי קודקוד קדקוד בסיס מעריך חילוק "
                       u"בניית סרטוט מיון זיהוי השוואת הגדרת חוקי שורש כתיבה חציית מד חיבור חיסור "
                       u"אומדן נפח שטח גידול סדר תכונות משפט תנאים".split())
_NUM_LEX = {u"חדה": u"חדות", u"חדות": u"חדה", u"קהה": u"קהות", u"קהות": u"קהה", u"שווה": u"שוות",
            u"שוות": u"שווה", u"ישרה": u"ישרות", u"ישרות": u"ישרה", u"אות": u"אותיות", u"אותיות": u"אות",
            u"מתחלפת": u"מתחלפות", u"מתחלפות": u"מתחלפת", u"מתאימה": u"מתאימות", u"מתאימות": u"מתאימה",
            u"משולש": u"משולשים", u"מרובע": u"מרובעים", u"ישר": u"ישרים", u"שוק": u"שוקיים",
            u"שוקיים": u"שוק", u"קרן": u"קרניים", u"קרניים": u"קרן", u"צלע": u"צלעות", u"צלעות": u"צלע",
            u"מעריך": u"מעריכים", u"בסיס": u"בסיסים", u"חזקה": u"חזקות", u"חזקות": u"חזקה"}
_DIGIT_WORD = {"1": u"אחת", "2": u"שתי", "3": u"שלוש", "4": u"ארבע", "5": u"חמש", "6": u"שש",
               "7": u"שבע", "8": u"שמונה", "9": u"תשע", "10": u"עשר", "60": u"שישים", "90": u"תשעים"}
_WORD_DIGIT = [(w, d) for d, w in _DIGIT_WORD.items()] + [(u"שלושה", "3"), (u"שתיים", "2"), (u"ארבעה", "4")]
_WORD_DIGIT.sort(key=lambda x: -len(x[0]))


def _cls(w):
    """Rough agreement class (fs/fp/ms/mp): enough to tell noun+adjective from a construct pair."""
    if w.endswith(u"ות") and len(w) >= 4:   # אות is singular
        return "fp"
    if w.endswith(u"ים"):
        return "mp"
    if w.endswith((u"ה", u"ת")):
        return "fs"
    return "ms"


def _num_word(w):
    if w in _NUM_LEX:
        return _NUM_LEX[w]
    if len(w) >= 5 and w.endswith(u"יות"):
        return w[:-3] + u"ית"
    if len(w) >= 4 and w.endswith(u"ית"):
        return w[:-2] + u"יות"
    if w.startswith(u"מת"):
        return None
    if len(w) >= 5 and w.endswith(u"ות"):
        return w[:-2] + u"ה"
    if len(w) >= 5 and w.endswith(u"ה"):
        return w[:-1] + u"ות"
    if len(w) >= 5 and w.endswith(u"ים"):
        return finalize(w[:-2])
    return None


def _article(words):
    heb = [w for w in words if _HEB_WORD.match(w)]
    if len(heb) != len(words) or not words:
        return []
    if len(words) >= 2 and all(w.startswith(u"ה") and len(w) >= 4 for w in words):
        return [u" ".join(w[1:] for w in words)]
    if any(w.startswith(u"ה") for w in words):
        return []
    if len(words) == 1:
        w = words[0]
        return [u"ה" + w] if len(w) >= 3 and w[0] not in u"ובכלמשה" else []
    if len(words) == 2:
        w1, w2 = words
        if w2[0] in u"בל":
            return []
        if w1 in _CONSTRUCT_HEADS or _cls(w1) != _cls(w2):
            return [u"%s ה%s" % (w1, w2)]
        return [u"ה%s ה%s" % (w1, w2)]
    return []


def _number(words):
    if not (1 <= len(words) <= 3) or not all(_HEB_WORD.match(w) for w in words):
        return []
    sw = [_num_word(w) for w in words]
    return [u" ".join(sw)] if all(sw) else []


def _digits(phrase):
    out = []
    m = re.sub(u"(?<![\\w])([ובכלמשה]{0,2})[־-]?(\\d+)(?!\\d)",
               lambda g: (g.group(1) + _DIGIT_WORD[g.group(2)]) if g.group(2) in _DIGIT_WORD else g.group(0), phrase)
    if m != phrase:
        out.append(m)
    for w, d in _WORD_DIGIT:
        rx = u"(?<![א-ת])([ובכלמשה]{0,2})%s(?![א-ת])" % w
        if re.search(rx, phrase):
            out.append(re.sub(rx, lambda g: (g.group(1) + u"־" if g.group(1) else u"") + d, phrase))
            break
    return out


def _ktiv(phrase):
    out = []
    for a, b in _KTIV:
        if a in phrase:
            v = phrase.replace(a, b)
            if v != phrase:
                out.append(v)
    return out


def _dash(phrase):
    if u"־" in phrase or u"-" in phrase:
        return [phrase.replace(u"־", u" ").replace(u"-", u" "),
                phrase.replace(u"־", u"-") if u"־" in phrase else phrase.replace(u"-", u"־")]
    return []


def search_variants_for(title, aliases, cap=48):
    """Generated spelling variants of the title and aliases, minus anything already an alias.

    Rules: with/without the article ה־, singular/plural, digit/number word
    (3 ↔ שלוש), maqaf/space/hyphen, ktiv male/haser (קודקוד/קדקוד, זווית/זוית).
    Precision first: a small lexicon instead of a morphology engine.
    """
    seeds = dedupe([title] + list(aliases))
    gen = []
    for s in seeds:
        words = s.split()
        gen += _article(words) + _number(words) + _digits(s) + _dash(s) + _ktiv(s)
    second = []
    for v in gen:
        second += _ktiv(v)
    return dedupe(gen + second, skip=seeds)[:cap]


# ---------------------------------------------------------------- catalog ----
def _is_str_list(v):
    return isinstance(v, list) and all(isinstance(x, str) for x in v)


def _bad_text(v):
    """True for a string that cannot be written as UTF-8 (a lone surrogate from a \\ud800 escape)."""
    if isinstance(v, str):
        try:
            v.encode("utf-8")
        except UnicodeEncodeError:
            return True
    return False


def entry_problem(e):
    """Why `e` is not a usable catalog entry (a short reason), or None when it is.

    It checks exactly the fields search() and format_hit() read, with the types
    catalog_build writes: sheet_id a non-empty string, title a string, package /
    landing_slug a string or null, sections a list of objects, each with a
    non-empty string id and a string title, subtopic / kind / anchor a string or
    null, and aliases / search_variants / combines a list of strings or absent.
    Anything else would crash the search (or print garbage), so the entry is
    skipped with this reason instead.
    """
    if not isinstance(e, dict) or not isinstance(e.get("sections"), list):
        return "not a catalog entry (no sections list)"
    if not isinstance(e.get("sheet_id"), str) or not e["sheet_id"].strip():
        return "sheet_id is not a non-empty string"
    if not isinstance(e.get("title"), str):
        return "title is not a string"
    for k in ("package", "landing_slug"):
        if e.get(k) is not None and not isinstance(e[k], str):
            return "%s is not a string" % k
    for k in ("sheet_id", "title", "package", "landing_slug"):
        if _bad_text(e.get(k)):
            return "%s is not valid Unicode text" % k
    for i, s in enumerate(e["sections"]):
        where = "sections[%d]" % i
        if not isinstance(s, dict):
            return "%s is not an object" % where
        if not isinstance(s.get("id"), str) or not s["id"].strip():
            return "%s.id is not a non-empty string" % where
        if not isinstance(s.get("title"), str):
            return "%s.title is not a string" % where
        for k in ("subtopic", "kind", "anchor"):
            if s.get(k) is not None and not isinstance(s[k], str):
                return "%s.%s is not a string" % (where, k)
        for k in ("aliases", "search_variants", "combines"):
            if s.get(k) is not None and not _is_str_list(s[k]):
                return "%s.%s is not a list of strings" % (where, k)
        for k in ("id", "title", "subtopic", "kind", "anchor"):
            if _bad_text(s.get(k)):
                return "%s.%s is not valid Unicode text" % (where, k)
        for k in ("aliases", "search_variants", "combines"):
            if any(_bad_text(x) for x in s.get(k) or []):
                return "%s.%s holds text that is not valid Unicode" % (where, k)
    return None


def load_catalog(dirs, errors=None):
    """Every readable catalog-entry.json under the given folders (or the files themselves).

    A path that does not exist, a file that is not valid JSON, and an entry that
    `entry_problem` rejects are skipped, never fatal: (path, reason) goes to
    `errors` when a list is given, else a warning to stderr.
    """
    entries, seen = [], set()

    def bad(f, why):
        if errors is not None:
            errors.append((str(f), why))
        else:
            print(u"catalog_search: WARNING skipped %s (%s)" % (f, why), file=sys.stderr)
    for d in dirs:
        p = Path(d)
        if not p.exists():
            bad(p, "no such file or folder")
            continue
        files = [p] if p.is_file() else sorted(p.rglob("catalog-entry.json"))
        for f in files:
            rp = f.resolve()
            if rp in seen:
                continue
            seen.add(rp)
            try:
                with open(f, encoding="utf-8") as fh:
                    e = json.load(fh)
            except (OSError, ValueError, RecursionError) as ex:
                bad(f, "%s: %s" % (type(ex).__name__, str(ex)[:120]))
                continue
            why = entry_problem(e)
            if why:
                bad(f, why)
                continue
            e["_file"] = str(f)
            entries.append(e)
    return entries


def home_sheets(curriculum=None):
    """{subtopic_id: registry sheet} from curriculum_tashpaz.json, or {} when it is not there."""
    path = Path(curriculum) if curriculum else HERE / "curriculum_tashpaz.json"
    try:
        with open(path, encoding="utf-8") as fh:
            reg = json.load(fh).get("subtopics", {})
    except (OSError, ValueError):
        return {}
    out = {}
    for topics in reg.get("by_track", {}).values():
        for ents in topics.values():
            for e in ents:
                out[e.get("id")] = e.get("sheet")
    return out


def _section_targets(sec, by_id):
    if sec.get("kind") == "combo":
        t = [(sec.get("title", u""), 1.0, "title")]
        for cid in sec.get("combines") or []:
            if cid in by_id:
                t.append((by_id[cid].get("title", u""), 0.5, "combined"))
        return t
    t = [(sec.get("title", u""), 1.0, "title")]
    t += [(a, 1.0, "alias") for a in sec.get("aliases") or []]
    t += [(v, 0.97, "variant") for v in sec.get("search_variants") or []]
    return t


def search(query, entries, limit=10, homes=None, errors=None):
    """Ranked hits: sections first-class, plus sheet-level hits on the sheet title / id.

    Each entry is checked with `entry_problem` and scored on its own: an entry
    that is rejected, or that raises anything while being scored, contributes no
    hits and is reported as (file or sheet_id, reason) in `errors` when a list
    is given, else as a warning on stderr. One bad entry never ends the search.
    """
    homes = homes if homes is not None else home_sheets()
    qtok = tokens(query)
    qkey = search_key(query)
    hits = []
    for e in entries:
        try:
            why = entry_problem(e)
            if why:
                raise ValueError(why)
            hits += _entry_hits(e, qtok, qkey, homes)
        except Exception as ex:  # deliberately broad: a guard per entry, see the docstring
            where = (e.get("_file") or e.get("sheet_id")) if isinstance(e, dict) else None
            where = str(where) if where else repr(e)[:60]
            reason = "%s: %s" % (type(ex).__name__, str(ex)[:120])
            if errors is not None:
                errors.append((where, reason))
            else:
                print(u"catalog_search: WARNING skipped %s (%s)" % (where, reason), file=sys.stderr)
    hits.sort(key=lambda h: h["_rank"])
    for h in hits:
        h.pop("_rank", None)
    return hits[:limit] if limit else hits


def _entry_hits(e, qtok, qkey, homes):
    """The section and sheet-level hits of one entry (unsorted, each with its `_rank`)."""
    hits = []
    secs = e.get("sections") or []
    by_id = {s.get("id"): s for s in secs}
    n_secs = len(secs)
    synthetic = bool(e.get("synthetic"))
    for order, s in enumerate(secs):
        best, via = 0.0, None
        targets = _section_targets(s, by_id)
        for text, w, field in targets:
            sc = phrase_score(qtok, text, w, qkey)
            if sc > best:
                best, via = sc, (field, text)
        cov = 0.85 * coverage(qtok, [t for t, w, f in targets if w >= 0.97])
        if cov > best:
            best, via = cov, ("union", None)
        if best <= 0.3:
            continue
        miss = unmatched_tokens(qtok, [t for t, w, f in targets])
        home = bool(s.get("subtopic")) and homes.get(s.get("subtopic")) == e.get("sheet_id")
        hits.append({"score": round(best, 4), "sheet_id": e.get("sheet_id"),
                     "section_id": s.get("id"), "subtopic": s.get("subtopic"),
                     "kind": s.get("kind"), "title": s.get("title"),
                     "anchor": s.get("anchor"), "sheet_title": e.get("title"),
                     "landing_slug": e.get("landing_slug"), "synthetic": synthetic,
                     "home": home, "via": via[0] if via else None,
                     "matched": via[1] if via else None,
                     "partial": bool(miss), "unmatched": miss,
                     "_rank": (bool(miss), -round(best, 4), not home, synthetic, n_secs,
                               e.get("sheet_id") or u"", order)})
    sheet_best = 0.0
    sheet_strings = [e.get("title", u""), e.get("sheet_id", u""), e.get("package") or u""]
    if qkey and qkey in (search_key(e.get("sheet_id", "")), search_key(e.get("package") or "")):
        sheet_best = 1.05
    sheet_best = max(sheet_best, phrase_score(qtok, e.get("title", u""), 0.7, qkey))
    if sheet_best > 0.3:
        miss = [] if sheet_best >= 1.05 else unmatched_tokens(qtok, sheet_strings)
        hits.append({"score": round(sheet_best, 4), "sheet_id": e.get("sheet_id"),
                     "section_id": None, "subtopic": None, "kind": "sheet",
                     "title": e.get("title"), "anchor": None, "sheet_title": e.get("title"),
                     "landing_slug": e.get("landing_slug"), "synthetic": synthetic,
                     "home": False, "via": "sheet", "matched": e.get("title"),
                     "partial": bool(miss), "unmatched": miss,
                     "_rank": (bool(miss), -round(sheet_best, 4), True, synthetic, n_secs,
                               e.get("sheet_id") or u"", 999)})
    return hits


def format_hit(i, h):
    sec = (h["section_id"] or u"(whole sheet)")
    tags = []
    if h.get("home"):
        tags.append("home sheet")
    if h.get("synthetic"):
        tags.append("synthetic")
    if h.get("partial"):
        tags.append(u"partial: no match for %s" % u", ".join(u'"%s"' % t for t in h.get("unmatched") or []))
    via = h.get("via") or ""
    if h.get("matched") and via not in ("union", "sheet"):
        via = u'%s "%s"' % (via, h["matched"])
    return u"%2d. %.3f  %s › %s  %s%s%s  %s%s" % (
        i, h["score"], h["sheet_id"], sec, h.get("title") or u"",
        (u"  #" + h["anchor"]) if h.get("anchor") else u"",
        (u"  [" + h["subtopic"] + u"]") if h.get("subtopic") else u"",
        u"via " + via, (u"  (" + u", ".join(tags) + u")") if tags else u"")


def _default_dirs():
    cands = [Path.cwd() / "out" / "catalog", Path.cwd() / "catalog"]
    return [str(c) for c in cands if c.is_dir()]


class _UsageError(Exception):
    """A command-line usage error: main() turns it into exit 2 (and a JSON object under --json)."""


class _Parser(argparse.ArgumentParser):
    def error(self, message):
        raise _UsageError(message)


def _json_record(query, ascii=False, **fields):
    """The one --json object; the same keys on every exit path (see the module docstring)."""
    rec = {"query": query, "normalized": search_key(query) if isinstance(query, str) else u"",
           "entries": 0, "skipped": [], "full_hits": 0, "hits": [], "error": None}
    rec.update(fields)
    return json.dumps(rec, ensure_ascii=ascii, indent=1)


def _print_json(query, **fields):
    """Print the --json object; with \\uXXXX escapes when stdout cannot encode the text."""
    try:
        text = _json_record(query, **fields)
        text.encode(sys.stdout.encoding or "utf-8")
    except (UnicodeEncodeError, LookupError):
        text = _json_record(query, ascii=True, **fields)
    print(text)


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    ap = _Parser(description=__doc__.split("\n")[0])
    ap.add_argument("query", nargs="?")
    ap.add_argument("--catalog", nargs="+", action="extend", default=[],
                    help="folders (searched recursively) or catalog-entry.json files")
    ap.add_argument("--json", action="store_true", help="print the hits as JSON")
    ap.add_argument("--limit", type=int, default=5)
    ap.add_argument("--curriculum", help="curriculum_tashpaz.json (home sheets); default: next to this file")
    ap.add_argument("--selftest", action="store_true")
    # Known before parsing (argparse accepts unambiguous prefixes such as --js), so
    # that even a usage error answers --json with a JSON object.
    state = {"json": any(x.startswith("--j") and "--json".startswith(x) for x in argv), "query": None}

    def fail(msg, usage=False, **fields):
        if usage:
            ap.print_usage(sys.stderr)
        try:
            print(u"catalog_search: %s" % msg, file=sys.stderr)
            if state["json"]:
                _print_json(state["query"], error=msg, **fields)
        except Exception:  # printing the failure must not turn exit 2 into a crash (exit 1)
            pass
        return 2

    try:
        a = ap.parse_args(argv)
    except _UsageError as ex:
        return fail(u"usage error: %s" % ex, usage=True)
    state["json"], state["query"] = a.json, a.query
    if a.selftest:
        return selftest()
    if not a.query:
        return fail(u"usage error: QUERY is required", usage=True)
    try:
        return _run(a, fail)
    except Exception as ex:  # an internal error is exit 2, never the "no match" exit 1
        traceback.print_exc(file=sys.stderr)
        return fail(u"internal error: %s: %s" % (type(ex).__name__, str(ex)[:200]))


def _run(a, fail):
    """The search proper, for parsed arguments `a`; `fail(msg, **json_fields)` returns exit 2."""
    dirs = a.catalog or _default_dirs()
    if not dirs:
        return fail(u"no catalog folder (use --catalog DIR)")
    empty = [d for d in dirs if not str(d).strip()]
    if empty:
        return fail(u"--catalog path is empty (an unset variable?)")
    missing = [d for d in dirs if not Path(d).exists()]
    if missing:
        return fail(u"--catalog path does not exist: %s" % u", ".join(missing))
    errors = []
    entries = load_catalog(dirs, errors)
    for f, why in errors:
        print(u"catalog_search: WARNING skipped %s (%s)" % (f, why), file=sys.stderr)
    skipped = [f for f, _w in errors]
    if not entries:
        if errors:
            return fail(u"no readable catalog entry under %s" % u", ".join(dirs), skipped=skipped)
        return fail(u"no catalog-entry.json under %s" % u", ".join(dirs))
    search_errors = []
    hits = search(a.query, entries, a.limit, home_sheets(a.curriculum), errors=search_errors)
    for f, why in search_errors:
        print(u"catalog_search: WARNING skipped %s (%s)" % (f, why), file=sys.stderr)
    skipped += [f for f, _w in search_errors]
    n_searched = len(entries) - len(search_errors)
    if n_searched <= 0:
        return fail(u"no readable catalog entry under %s" % u", ".join(dirs), skipped=skipped)
    full = [h for h in hits if not h.get("partial")]
    if a.json:
        _print_json(a.query, entries=n_searched, skipped=skipped, full_hits=len(full), hits=hits)
    else:
        print(u"query: %s  (normalized: %s; %d catalog entries)" % (a.query, search_key(a.query), n_searched))
        shown_partial = False
        for i, h in enumerate(hits, 1):
            if h.get("partial") and not shown_partial:
                print(u"  partial matches (some query words matched nothing in the section):")
                shown_partial = True
            print(format_hit(i, h))
        if not hits:
            print("  no match")
        elif not full:
            print("  no full match")
    return 0 if full else 1


# ---------------------------------------------------------------- selftest ---
def _mini_catalog():
    """Two tiny entries shaped like catalog_build output, so the selftest needs no files."""
    def sec(sid, sub, title, aliases, variants=(), kind="subtopic", combines=None):
        s = {"id": sid, "subtopic": sub, "kind": kind, "title": title, "anchor": (sub or "combo").split(".")[-1],
             "aliases": list(aliases), "search_variants": list(variants), "question_ids": {}}
        if combines:
            s["combines"] = combines
        return s
    a = {"sheet_id": "T-ANG-01", "package": "G7-T11", "title": u"מהי זווית וסימון זוויות", "sections": [
        sec("T-ANG-01.s1", "st.g7.angles.what_is_angle", u"מהי זווית", [u"זווית", u"קודקוד", u"קדקוד"]),
        sec("T-ANG-01.s2", "st.g7.angles.naming", u"סימון זוויות",
            [u"סימון זווית", u"שלוש אותיות", u"3 אותיות", u"בשלוש אותיות"])]}
    b = {"sheet_id": "T-ANG-02", "package": "G7-T12", "title": u"זוויות צמודות וזוויות קודקודיות", "sections": [
        sec("T-ANG-02.s1", "st.g7.angles.sum_diff", u"סכום והפרש זוויות", [u"סכום זוויות", u"הפרש זוויות"]),
        sec("T-ANG-02.s2", "st.g7.angles.adjacent", u"זוויות צמודות", [u"צמודות", u"סכום זוויות צמודות"]),
        sec("T-ANG-02.s3", "st.g7.angles.vertical", u"זוויות קודקודיות", [u"קודקודיות", u"ישרים נחתכים"]),
        sec("T-ANG-02.s4", None, u"שילוב", [], kind="combo", combines=["T-ANG-02.s2", "T-ANG-02.s3"])]}
    c = {"sheet_id": "T-ANG-03", "package": "G7-T14", "title": u"סכום הזוויות במשולש", "synthetic": True,
         "sections": [sec("T-ANG-03.s1", "st.g7.angles.triangle_sum", u"סכום הזוויות במשולש",
                          [u"זוויות במשולש", u"סכום זוויות במשולש"])]}
    return [a, b, c]


def selftest():
    import time
    t0 = time.time()
    fails = []

    def eq(got, want, what):
        if got != want:
            fails.append(u"%s: got %r, want %r" % (what, got, want))

    # normalization
    eq(normalize(u"זָוִית‍"), u"זוית", "niqqud + U+200D stripped")
    eq(normalize(u"מד־זווית"), u"מד־זווית", "maqaf kept by normalize")
    eq(search_key(u"מד־זווית"), u"מד זווית", "maqaf → space in search_key")
    eq(search_key(u"∡ABC = 60°"), u"abc 60", "punctuation and Latin")
    eq(search_key(u"רמה א'"), u"רמה א", "geresh dropped")
    eq(search_key(u"זוויות קודקודיות‏"), u"זוויות קודקודיות".translate(_FINALS), "U+200F")
    eq(tokens(u"בשלוש")[0]["stems"] >= {"3"}, True, "בשלוש → 3")
    eq(tokens(u"ב־3 אותיות")[0]["raw"], "3", "ב־3 → 3 (lone prefix dropped)")
    eq(tokens(u"ב3")[0]["raw"], "3", "ב3 → 3")
    eq(fold(u"צמודות".translate(_FINALS)), fold(u"צמודה"), "fold צמודות/צמודה")
    eq(fold(u"קודקודיות"), fold(u"קודקודית"), "fold קודקודיות/קודקודית")
    eq(skeleton(fold(u"קודקודיות")), skeleton(fold(u"קדקודיות")), "skeleton קודקוד/קדקוד")
    eq(skeleton(fold(u"זוית")), skeleton(fold(u"זוויות")), "skeleton זוית/זוויות")
    eq(token_match(tokens(u"הזוויות")[0], tokens(u"זוויות")[0]), 0.95, "article as prefix")
    eq(finalize(u"נחתכ"), u"נחתך", "finalize")
    # ranking on the mini catalog (homes: what the registry would say)
    cat = _mini_catalog()
    homes = {"st.g7.angles.vertical": "T-ANG-02", "st.g7.angles.adjacent": "T-ANG-02",
             "st.g7.angles.naming": "T-ANG-01", "st.g7.angles.sum_diff": "T-ANG-02",
             "st.g7.angles.triangle_sum": "T-ANG-03"}
    cases = [(u"קודקודיות", "st.g7.angles.vertical"), (u"קדקודיות", "st.g7.angles.vertical"),
             (u"הזוויות הקדקודיות", "st.g7.angles.vertical"), (u"צמודות", "st.g7.angles.adjacent"),
             (u"זווית צמודה", "st.g7.angles.adjacent"), (u"3 אותיות", "st.g7.angles.naming"),
             (u"שלוש אותיות", "st.g7.angles.naming"),
             (u"סימון זווית בשלוש אותיות", "st.g7.angles.naming"),
             (u"סכום זוויות", "st.g7.angles.sum_diff"), (u"זוויות במשולש", "st.g7.angles.triangle_sum"),
             (u"זָוִיּוֹת צְמוּדוֹת", "st.g7.angles.adjacent"), (u"קדקוד", "st.g7.angles.what_is_angle")]
    for q, want in cases:
        h = search(q, cat, 3, homes)
        eq(h[0]["subtopic"] if h else None, want, u"top hit for %s" % q)
        eq(bool(h) and h[0]["partial"], False, u"top hit for %s is a full match" % q)
    h = search(u"T-ANG-02", cat, 1, homes)
    eq((h[0]["kind"], h[0]["sheet_id"]) if h else None, ("sheet", "T-ANG-02"), "sheet id query")
    eq(search(u"פרבולה", cat, 3, homes), [], "no false hit")
    # one shared generic word is not a match for a topic that is not in the catalog
    for q, miss in ((u"ישרים מקבילים", u"מקבילים"), (u"זוויות מתחלפות", u"מתחלפות")):
        h = search(q, cat, 5, homes)
        eq(bool(h) and all(x["partial"] for x in h), True, u"%s: only partial hits" % q)
        eq(bool(h) and miss in h[0]["unmatched"], True, u"%s: unmatched token reported" % q)
    # a broken entry is skipped (warning), never a crash; exit codes say which case it was
    import contextlib
    import io
    import shutil
    import tempfile

    def call(argv):
        """main(argv) with stdout/stderr captured; a raise or SystemExit becomes a string rc."""
        out, err = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            try:
                rc = main(argv)
            except SystemExit as ex:
                rc = "SystemExit(%s)" % ex.code
            except Exception as ex:
                rc = "raised %s" % type(ex).__name__
        return rc, out.getvalue(), err.getvalue()

    def js(out):
        try:
            d = json.loads(out)
        except ValueError:
            return None
        return d if isinstance(d, dict) else None

    tmp = Path(tempfile.mkdtemp(prefix="catsearch-selftest-"))
    try:
        good, broken = tmp / "good" / "catalog-entry.json", tmp / "broken" / "catalog-entry.json"
        good.parent.mkdir()
        broken.parent.mkdir()
        good.write_text(json.dumps(cat[1], ensure_ascii=False), encoding="utf-8")
        broken.write_text(u'{"sheet_id": "T-X", "sections": [{', encoding="utf-8")
        errs = []
        eq(len(load_catalog([tmp], errs)), 1, "load_catalog keeps the good entry")
        eq(len(errs), 1, "load_catalog reports the broken file")
        rc_ok = call([u"קודקודיות", "--catalog", str(tmp)])[0]
        rc_partial = call([u"ישרים מקבילים", "--catalog", str(tmp)])[0]
        rc_bad = call([u"קודקודיות", "--catalog", str(broken.parent)])[0]
        eq(rc_ok, 0, "exit 0: a full hit despite one broken file")
        eq(rc_partial, 1, "exit 1: only partial hits")
        eq(rc_bad, 2, "exit 2: no readable entry")

        # F1: nothing to search is exit 2 (never the "no match" 1), with a message and,
        # under --json, one well-formed object whose `error` says why
        empty, plain = tmp / "empty", tmp / "legacy-out" / "deliver" / "a"
        empty.mkdir()
        plain.mkdir(parents=True)
        (plain / "sheet.json").write_text(u"{}", encoding="utf-8")
        nothing = ((u"an empty --catalog folder", [str(empty)]),
                   (u"a --catalog path that does not exist", [str(tmp / "no-such-dir")]),
                   (u"a good folder plus a mistyped one", [str(good.parent), str(tmp / "no-such-dir")]),
                   (u"a folder with no catalog-entry.json (legacy out/)", [str(tmp / "legacy-out")]))
        for what, paths in nothing:
            rc, out, err = call([u"קודקודיות", "--catalog"] + paths)
            eq(rc, 2, u"exit 2 for %s" % what)
            eq(bool(err.strip()), True, u"stderr message for %s" % what)
            rc, out, err = call([u"קודקודיות", "--json", "--catalog"] + paths)
            d = js(out)
            eq(rc, 2, u"exit 2 for %s (--json)" % what)
            eq(bool(d) and isinstance(d.get("error"), str) and bool(d["error"]) and d.get("hits") == [],
               True, u"--json error object for %s" % what)
        rc, out, _err = call([u"פרבולה", "--json", "--catalog", str(good.parent)])
        d = js(out)
        eq((rc, bool(d) and d.get("error"), bool(d) and d.get("entries")), (1, None, 1),
           "exit 1 + error null when entries were searched and nothing matched")
        for what, argv in ((u"no QUERY", ["--json", "--catalog", str(good.parent)]),
                           (u"a non-numeric --limit", [u"קודקודיות", "--limit", "x", "--json"])):
            rc, out, err = call(argv)
            d = js(out)
            eq(rc, 2, u"usage error (%s) is exit 2" % what)
            eq(bool(d) and isinstance(d.get("error"), str), True, u"usage error (%s) answers --json" % what)

        # F2: an entry with the wrong field types is skipped with a reason, never a crash
        mixed = tmp / "mixed"
        bad_entries = {
            "null-sections": ({"sheet_id": "B-1", "title": u"x", "sections": [None, u"s"]},
                              "sections[0] is not an object"),
            "int-title": ({"sheet_id": "B-2", "title": 5, "sections": []}, "title is not a string"),
            "int-section-title": ({"sheet_id": "B-3", "title": u"x", "sections": [{"id": "B-3.s1", "title": 7}]},
                                  "sections[0].title is not a string"),
            "int-alias": ({"sheet_id": "B-4", "title": u"x", "sections": [
                {"id": "B-4.s1", "title": u"קודקודיות", "aliases": [u"a", 1]}]},
                "sections[0].aliases is not a list of strings"),
            "list-combines": ({"sheet_id": "B-5", "title": u"x", "sections": [
                {"id": "B-5.s1", "title": u"שילוב", "kind": "combo", "combines": [["B-5.s1"]]}]},
                "sections[0].combines is not a list of strings"),
            "no-sheet-id": ({"title": u"x", "sections": []}, "sheet_id is not a non-empty string"),
        }
        for name, (ent, _why) in bad_entries.items():
            (mixed / name).mkdir(parents=True)
            (mixed / name / "catalog-entry.json").write_text(json.dumps(ent, ensure_ascii=False), encoding="utf-8")
        errs = []
        eq(len(load_catalog([mixed], errs)), 0, "load_catalog rejects every badly typed entry")
        reasons = sorted(w for _f, w in errs)
        eq(reasons, sorted(w for _e, w in bad_entries.values()), "load_catalog names each type problem")
        (mixed / "good").mkdir()
        (mixed / "good" / "catalog-entry.json").write_text(json.dumps(cat[1], ensure_ascii=False),
                                                          encoding="utf-8")
        rc, out, err = call([u"קודקודיות", "--catalog", str(mixed)])
        eq((rc, "Traceback" in err), (0, False), "exit 0, no traceback: badly typed entries beside a good one")
        eq(err.count("WARNING skipped"), len(bad_entries), "one warning per badly typed entry")
        rc, out, err = call([u"קודקודיות", "--json", "--catalog", str(mixed)])
        d = js(out)
        eq((rc, bool(d) and d.get("entries"), bool(d) and len(d.get("skipped") or [])),
           (0, 1, len(bad_entries)), "--json: 1 entry searched, the bad ones listed as skipped")
        shutil.rmtree(str(mixed / "good"))
        rc, out, err = call([u"קודקודיות", "--catalog", str(mixed)])
        eq((rc, "Traceback" in err), (2, False), "exit 2 when every entry is badly typed")
        # search() guards each entry itself (entries handed over in memory skip load_catalog)
        serr = []
        try:
            h = search(u"קודקודיות", [bad_entries["null-sections"][0], {"sections": "x"}] + cat, 3, homes,
                       errors=serr)
            got = (h[0]["subtopic"] if h else None, len(serr))
        except Exception as ex:
            got = "raised %s" % type(ex).__name__
        eq(got, ("st.g7.angles.vertical", 2), "search() skips bad in-memory entries and reports them")
        # round 2: a file nested too deeply to load, and text that is not valid Unicode
        # (a lone surrogate), are skipped like any malformed entry; the good one still answers
        odd = tmp / "odd"
        for name in ("good", "deep", "surrogate"):
            (odd / name).mkdir(parents=True)
        (odd / "good" / "catalog-entry.json").write_text(json.dumps(cat[1], ensure_ascii=False), encoding="utf-8")
        (odd / "deep" / "catalog-entry.json").write_text("[" * 200000 + "]" * 200000, encoding="utf-8")
        sur = json.loads(json.dumps(cat[1]))
        sur["sheet_id"] = "T-SUR"
        sur["sections"][0]["title"] = sur["sections"][0]["title"] + "\ud800"
        (odd / "surrogate" / "catalog-entry.json").write_text(json.dumps(sur), encoding="utf-8")
        rc, out, err = call([u"קודקודיות", "--json", "--catalog", str(odd)])
        d = js(out)
        eq((rc, bool(d) and d.get("entries"), bool(d) and len(d.get("skipped") or [])), (0, 1, 2),
           "a too-deep file and a lone-surrogate entry are skipped; the good entry answers")
        # an empty --catalog (an unset shell variable) is a usage error, not the current folder
        rc, out, err = call([u"קודקודיות", "--json", "--catalog", ""])
        d = js(out)
        eq((rc, bool(d) and "empty" in str(d.get("error"))), (2, True), "--catalog '' is exit 2")
        # a stdout that cannot encode Hebrew still gets one JSON object (escaped), same value
        bout = io.BytesIO()
        asc = io.TextIOWrapper(bout, encoding="ascii")
        with contextlib.redirect_stdout(asc), contextlib.redirect_stderr(io.StringIO()):
            try:
                rc = main([u"קודקודיות", "--json", "--catalog", str(good.parent)])
            except Exception as ex:
                rc = "raised %s" % type(ex).__name__
            asc.flush()
        d = js(bout.getvalue().decode("ascii", "replace"))
        eq((rc, bool(d) and d.get("query"), bool(d) and d.get("full_hits", 0) > 0), (0, u"קודקודיות", True),
           "--json on an ASCII stdout: escaped JSON, exit 0")
        # any unexpected internal error is exit 2 (and a JSON error object), never exit 1
        g = globals()
        real_search = g["search"]

        def boom(*_a, **_k):
            raise RuntimeError("selftest: simulated internal error")
        g["search"] = boom
        try:
            rc, out, err = call([u"קודקודיות", "--json", "--catalog", str(good.parent)])
        finally:
            g["search"] = real_search
        d = js(out)
        eq(rc, 2, "internal error is exit 2")
        eq(bool(d) and str(d.get("error") or "").startswith("internal error"), True,
           "internal error answers --json with an error object")
    finally:
        shutil.rmtree(str(tmp), ignore_errors=True)
    # vocabulary helpers (stored by catalog_build, recomputed by G89)
    v = search_variants_for(u"זוויות קודקודיות", [u"קודקודיות", u"זווית קודקודית"])
    eq(all(x in v for x in (u"זוויות קדקודיות", u"הזוויות הקודקודיות", u"קדקודיות")), True, "variants")
    eq(u"קודקודיות" in v, False, "variants never repeat an alias")
    eq(aliases_for({"aliases": [u"צמודות", u"צְמוּדוֹת"], "introduces": {"terms": ["t"]}},
                   {"terms": {"t": {"search_variants": [u"זוויות צמודות", u"צמודות"]}}}),
       [u"צמודות", u"זוויות צמודות"], "aliases_for: registry + glossary, normalized, deduped")
    dt = time.time() - t0
    for f in fails:
        print(u"FAIL " + f)
    print("catalog_search selftest: %d checks failed, %.2f s" % (len(fails), dt))
    return 1 if fails or dt > 30 else 0


if __name__ == "__main__":
    sys.exit(main())
