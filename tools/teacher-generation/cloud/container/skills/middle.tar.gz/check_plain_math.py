# -*- coding: utf-8 -*-
"""Fail when an answer page prints math outside a math span.

Right-to-left layout reorders formulas typed as plain text ("BCF△≅ABE△", "4−או"), so on the
answer pages every Latin letter and math sign must sit inside <span class="m">. Also flags a
Hebrew letter glued to a digit or Latin letter. Usage: check_plain_math.py <deliver dir>...
"""
import html, re, sys
bad_total = 0
for d in sys.argv[1:]:
    h = open(d.rstrip("/") + "/sheet.html", encoding="utf-8").read()
    a = h[h.find(u"תשובות סופיות"):]
    out, depth, mdepth = [], 0, None
    for m in re.finditer(r"<(/?)span([^>]*)>|<[^>]+>|[^<]+", a):
        tok = m.group(0)
        if tok.startswith("<span"):
            depth += 1
            if mdepth is None and re.search(r'class="[^"]*\bm\b', tok):
                mdepth = depth
        elif tok.startswith("</span"):
            if mdepth == depth:
                mdepth = None
            depth -= 1
        elif not tok.startswith("<") and mdepth is None:
            out.append(html.unescape(tok))
    txt = "".join(out)
    bad = [b for b in re.findall(u".{0,15}[A-Za-z∠△≅≠√↔∥⊥=<>²^$\\\\].{0,15}", txt) if not re.search("Noam|noam|http|©", b)]
    bad += re.findall(u".{0,10}[א-ת][0-9A-Za-z].{0,10}", txt)
    print("%s: %d plain-text math" % (d, len(bad)) + ("" if not bad else " -- " + " | ".join(bad[:5])))
    bad_total += len(bad)
sys.exit(1 if bad_total else 0)
