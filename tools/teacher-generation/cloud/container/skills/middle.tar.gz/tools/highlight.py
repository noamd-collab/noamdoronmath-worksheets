# -*- coding: utf-8 -*-
"""highlight.py -- v6.9 reference: highlight ONE object of a delivered
figure from noam-ai.json ALONE (no skill import, no engine, stdlib only).

    python3 tools/highlight.py <level_dir> <figure_id> <object_id> [-o F]

<object_id> is an object of the figure's visual_model (an engine figure
names its objects by the engine's ids: A, seg:AB, ang:BAC, poly:ABCD; a
builder figure by svg ids: pt-A, seg-AB) or a relation id the model offers
for highlighting (visual_model.actions.highlight / highlight_given), which
highlights the objects the relation names.

What it does: object id -> its svg ids (the object's `parts`, or its
`svg_id`) -> one overlay element per part, a copy of that element's own
geometry in the highlight paint, inserted as
    <g data-layer="highlight" data-object="ID"> ... </g>
right after the <svg ...> start tag -- painted UNDER the figure, whose bytes
are otherwise unchanged. A part with a span [X, Y] (a piece of a longer
line) is the line between the drawn points X and Y.

PIE CHARTS (v6.16.1, Codex AI-HL-1/2): a pie's wedges are FILLED, so its
overlay lies ABOVE them -- right before <g data-layer="labels"> (labels stay
on top), or right before </svg> when the pie has no labels layer (as
wspec/render/pie_hl.py places it). A pie outline / build circle (data-pie
"outline" / "bcirc") is copied at its OWN radius as an UNFILLED highlight
stroke, so the sector boundaries inside stay visible; a pie centre dot
(data-pie "bdot") gets a ring around it, not a disk over it. Graph and
geometry figures keep the under-the-figure placement and the dot halo.

UNION RULE (v6.10, Codex C1r2): before anything is painted, the union of
what the overlay would paint -- the parts after their span limits -- must
BE the object: a segment its own two points' segment, an angle its two
arms plus a sector (its arc / right-angle mark, or room for the focus
arc), a polygon every side and nothing else. A part without its span on a
longer line, a missing arm or side, an extra element, or a mapping that
cannot be placed is refused (exit 2); it never falls back to a whole line. Output: the highlighted
SVG on stdout (or -o F). Exit 0, or 2 with a message when the object / an
svg id is not in the package (never a guess).

FOCUS ARC (v6.9, Codex F3): an angle object whose parts print no arc and
no right-angle mark (e.g. ang:ACB drawn by its two arms only) also gets ONE
focus arc in the overlay -- <path data-focus="ang:ACB" .../> centred on the
vertex, from one arm to the other through the angle's own (non-reflex)
sector, radius 18 px clipped to 0.45 of the shorter arm, from the points'
svg_xy in noam-ai.json. No number, no equality mark; it is only in this
temporary overlay, never in the printed figure (strip() removes it).

As a module: highlight(level_dir, figure_id, object_id) -> (svg, parts)
and strip(svg) -> the figure without the overlay (the original bytes)."""
import json
import math
import os
import re
import sys

HL = "#ffd400"
HL_W = "6"
_START = re.compile(r"<svg\b[^>]*>")
_EL = re.compile(r"<(line|circle|path|polyline|polygon|rect|text|g)\b([^>]*?)"
                 r"(/?)>", re.S)
_ATTR = re.compile(r'([\w:-]+)="([^"]*)"')
# the overlay holds no nested group (a builder group is flattened)
_OVERLAY = re.compile(r'<g data-layer="highlight" data-object="[^"]*">'
                      r'(?:(?!<g\b).)*?</g>', re.S)
_NUM = re.compile(r"-?\d*\.?\d+(?:[eE][-+]?\d+)?")


class HighlightError(ValueError):
    pass


def _load(level):
    p = os.path.join(level, "noam-ai.json")
    if not os.path.isfile(p):
        raise HighlightError("%s has no noam-ai.json" % level)
    with open(p, encoding="utf-8") as fh:
        return json.load(fh)


def _figure(nj, fid):
    for F in nj.get("figures") or []:
        if F.get("id") == fid:
            return F
    raise HighlightError("figure %s is not in noam-ai.json" % fid)


SPAN_TOL = 1.0          # px, a span point on its object (as verify_export)


def _segdist(p, a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    L = dx * dx + dy * dy
    t = 0 if L == 0 else max(0, min(1, ((p[0] - a[0]) * dx +
                                        (p[1] - a[1]) * dy) / L))
    return ((p[0] - a[0] - t * dx) ** 2 + (p[1] - a[1] - t * dy) ** 2) ** .5


def _on_ray(v, a, x, tol=SPAN_TOL):
    ux, uy = a[0] - v[0], a[1] - v[1]
    dx, dy = x[0] - v[0], x[1] - v[1]
    L = (ux * ux + uy * uy) ** .5
    if L == 0 or (dx * dx + dy * dy) ** .5 <= tol:
        return False
    return (ux * dx + uy * dy) > 0 and abs(ux * dy - uy * dx) / L <= tol


def span_own(o, span, pts, tol=SPAN_TOL):
    """(v6.9 fix r2, C1r) a part's span names a piece of ITS OWN object:
    segment -- both points on the segment; angle -- [vertex, X] with X on
    ray vertex->A or vertex->B; polygon -- both points on one side. A span
    onto another line (seg:CO with span [D, O]) is refused."""
    if not span:
        return True
    names = re.findall(r"[A-Z][0-9]*'*", _geometry_name(o))
    ty = o.get("type")
    if len(span) != 2 or span[0] == span[1] or \
            any(str(n) not in pts for n in span) or \
            any(n not in pts for n in names):
        return False
    X, Y = pts[str(span[0])], pts[str(span[1])]
    if ty == "segment" and len(names) >= 2:
        a, b = pts[names[0]], pts[names[-1]]
        return _segdist(X, a, b) <= tol and _segdist(Y, a, b) <= tol
    if ty == "angle" and len(names) == 3:
        a, v, b = names
        if v not in span:
            return False
        x = pts[str(span[1] if span[0] == v else span[0])]
        return _on_ray(pts[v], pts[a], x, tol) or \
            _on_ray(pts[v], pts[b], x, tol)
    if ty == "polygon" and len(names) >= 3:
        return any(_segdist(X, pts[p], pts[q]) <= tol and
                   _segdist(Y, pts[p], pts[q]) <= tol
                   for p, q in zip(names, names[1:] + names[:1]))
    return False           # a span on any other object is not in the model


def parts_of(F, oid):
    """[(svg_id, span or None)] of one object (or of a relation's
    objects). A span that is no piece of its own object is refused."""
    vm = F.get("visual_model") or {}
    objs = dict((o.get("id"), o) for o in vm.get("objects") or []
                if isinstance(o, dict))
    pts = _points(F)

    def one(o):
        if isinstance(o.get("parts"), list) and o["parts"]:
            for p in o["parts"]:
                if p.get("span") and not span_own(o, p["span"], pts):
                    raise HighlightError(
                        "object %s: part %s spans %r, which is not a piece "
                        "of %s itself" % (o.get("id"), p.get("svg_id"),
                                          p["span"], o.get("name")))
            return [(p["svg_id"], p.get("span")) for p in o["parts"]]
        if o.get("svg_id"):
            return [(o["svg_id"], None)]
        raise HighlightError("object %s has nothing drawn to highlight"
                             % o.get("id"))
    if oid in objs:
        return one(objs[oid])
    rels = dict((r.get("id"), r) for r in vm.get("relations") or [])
    offered = set((vm.get("actions") or {}).get("highlight") or []) | set(
        vm.get("highlight_given") or [])
    if oid in rels and oid in offered:
        out = []
        for x in rels[oid].get("objects") or []:
            if x in objs:
                for p in one(objs[x]):
                    if p not in out:
                        out.append(p)
        if out:
            return out
    raise HighlightError("%s is no object of figure %s (and no relation it "
                         "offers for highlighting)" % (oid, F.get("id")))


def _points(F):
    vm = F.get("visual_model") or {}
    out = {}
    for o in vm.get("objects") or []:
        if o.get("type") == "point" and _geometry_name(o) and \
                isinstance(o.get("svg_xy"), list) and \
                not isinstance(o["svg_xy"][0], list):
            out[_geometry_name(o)] = o["svg_xy"]
    return out


# ---- C1r2 (v6.10): what a highlight paints IS its object ------------------
# The same block is in tools/highlight.py, verify_export.py and
# selfcheck_noam_package.py (each file stays stdlib-only and independent;
# selfcheck_v610_gaps.py proves the three copies are identical).
_U_TOL = 1.0
_U_NAMES = re.compile(r"[A-Z][0-9]*'*")
_U_UNITS = re.compile(r"-?\d*\.?\d+(?:[eE][-+]?\d+)?")


def _u_d(p, a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    L = dx * dx + dy * dy
    t = 0 if L == 0 else max(0, min(1, ((p[0] - a[0]) * dx +
                                        (p[1] - a[1]) * dy) / L))
    return math.hypot(p[0] - a[0] - t * dx, p[1] - a[1] - t * dy)


def _u_ray(v, a, x, tol):
    """x lies on the ray from v through a (not at v)."""
    ux, uy = a[0] - v[0], a[1] - v[1]
    dx, dy = x[0] - v[0], x[1] - v[1]
    L = math.hypot(ux, uy)
    if L == 0 or math.hypot(dx, dy) <= tol:
        return False
    return (ux * dx + uy * dy) > 0 and abs(ux * dy - uy * dx) / L <= tol


def _u_cover(pieces, a, b, tol):
    """The part of segment a-b that the pieces (each lying on it) leave
    unpainted: [(t0, t1)] in px along a-b, gaps longer than tol."""
    L = math.hypot(b[0] - a[0], b[1] - a[1])
    if L <= tol:
        return []
    ux, uy = (b[0] - a[0]) / L, (b[1] - a[1]) / L
    iv = sorted(sorted(((p[0] - a[0]) * ux + (p[1] - a[1]) * uy,
                        (q[0] - a[0]) * ux + (q[1] - a[1]) * uy))
                for p, q in pieces)
    gaps, at = [], 0.0
    for s, e in iv:
        if s - at > tol:
            gaps.append((at, s))
        at = max(at, e)
    if L - at > tol:
        gaps.append((at, L))
    return gaps


def _u_mark_angle(s):
    """'arc ACB' / 'right AHB' / 'ang ACB' -> (vertex, {arm, arm})."""
    n = _U_NAMES.findall(str(s or "").split(" ", 1)[-1])
    return (n[1], frozenset((n[0], n[2]))) if len(n) == 3 else None


def _geometry_name(o):
    """Stable native references are separate from learner-facing names.

    An explicitly unnamed foot is a point with part=anchor and its native
    point ID. Native segment/angle IDs still identify their endpoints;
    all normal measured-ink/parts checks continue to run on those endpoints.
    """
    if o.get("name"):
        return str(o["name"])
    ty, oid = o.get("type"), str(o.get("id") or "")
    if ty == "point" and o.get("part") == "anchor" and re.fullmatch(r"[A-Z][0-9]*'*", oid):
        return oid
    prefix = {"segment": "seg:", "angle": "ang:"}.get(ty)
    if prefix and oid.startswith(prefix):
        tail = oid[len(prefix):]
        names = re.findall(r"[A-Z][0-9]*'*", tail)
        if "".join(names) == tail and len(names) == (2 if ty == "segment" else 3):
            return tail
    return ""


def _u_point(o, pts, elem, tol):
    """(v6.10 fix r1, m2) a POINT paints its own dot and its own letter
    only: a circle / point group at the point's place, a label whose
    data-for names it. A point object re-pointed at another point's dot is
    a fault."""
    nm = _geometry_name(o)
    if not nm:
        return []
    P = pts.get(nm)
    if P is None:
        return ["point %s is not a drawn point of the model" % nm]
    P = (float(P[0]), float(P[1]))
    parts = o.get("parts")
    if not (isinstance(parts, list) and parts):
        parts = [{"svg_id": o["svg_id"]}] if o.get("svg_id") else []
    out = []
    for pt in parts:
        sid = pt.get("svg_id") if isinstance(pt, dict) else None
        e = elem(sid) if sid else None
        if e is None:
            out.append("part %s is not one element of the SVG" % sid)
            continue
        tag, a, geom = e
        if tag == "circle":
            # an engine dot names its point (data-pt) and sits at it; a
            # bare circle (a builder's, maybe under a transform this reader
            # does not apply) is judged by its name hook only when it has
            # one
            if a.get("data-pt") is not None and (
                    a.get("data-pt") != nm or not geom or
                    abs(geom[0][0] - P[0]) > tol or
                    abs(geom[0][1] - P[1]) > tol):
                out.append("part %s is not the dot of %s" % (sid, nm))
        elif tag == "text":
            if a.get("data-for") != nm:
                out.append("part %s is not the letter of %s" % (sid, nm))
        elif tag == "g":
            xy = _U_UNITS.findall(a.get("data-xy") or "")
            if a.get("data-kind") != "point" or len(xy) != 2 or \
                    abs(float(xy[0]) - P[0]) > tol or \
                    abs(float(xy[1]) - P[1]) > tol:
                out.append("part %s is not the point %s" % (sid, nm))
        else:
            out.append("part %s (%s) is not a point's ink" % (sid, tag))
    return out


def union_faults(o, pts, elem, tol=_U_TOL):
    """C1r2: the geometric UNION of what highlighting object o paints --
    its parts after span limits (a part without span paints its whole
    element) -- equals the object: no ink outside it, no piece of it left
    unpainted.
      segment  exactly its two points' segment;
      angle    exactly its two arms (vertex -> each named point), plus a
               sector mark: an arc / right-angle mark of THIS angle among
               its parts, or room for the focus arc highlight draws;
               a caption part must be this angle's;
      polygon  exactly its sides, every side.
    A segment may also carry its own tick mark / length caption (the
    engine's data-mark "tick XY" / data-for "seg XY" naming it).
    o     a visual_model object (type, name, parts or svg_id, svg_xy)
    pts   {point name: (x, y)} -- the model's drawn points (svg px)
    elem  svg id -> None | (tag, attrs, [(x, y) ...]) in the same px:
          a line's two ends, a polyline's / polygon's vertices, a path's
          M/L points, a circle's centre, a text's anchor
    Returns [reason, ...]; [] when the highlight IS the object. Anything
    it cannot place is a fault (refuse, never guess)."""
    ty = o.get("type")
    if ty == "point":
        return _u_point(o, pts, elem, tol)
    if ty == "origin":                           # v6.16 gaps, corpus-v2 G2
        return _u_origin(o, elem)
    if ty == "polygon" and o.get("shown") is not None:     # v6.16 gaps, G1
        return _u_partial(o, pts, elem, tol)
    if ty not in ("segment", "angle", "polygon"):
        return []
    parts = o.get("parts")
    if not (isinstance(parts, list) and parts):
        parts = [{"svg_id": o["svg_id"]}] if o.get("svg_id") else []
    if not parts:
        return ["nothing is drawn to highlight"]
    nm = _geometry_name(o)
    names = _U_NAMES.findall(nm)
    P = dict((str(k), tuple(float(c) for c in v)) for k, v in pts.items())
    sx = o.get("svg_xy")
    if ty == "segment" and (not names or "".join(names) != nm) and \
            isinstance(sx, list) \
            and len(sx) == 2 and all(isinstance(p, list) for p in sx):
        # a stroke named by no points (a builder's data line, an axis) is
        # its two svg_xy ends; a name OF points must name drawn points
        names = ["#0", "#1"]
        P["#0"], P["#1"] = [(float(p[0]), float(p[1])) for p in sx]
    elif ty == "polygon" and (not names or "".join(names) != nm) and \
            isinstance(sx, list) and len(sx) >= 3 and \
            all(isinstance(p, list) and len(p) == 2 for p in sx):
        # v6.12 fix_r1 (M3): an UNNAMED data polygon (a bar of a chart)
        # is its svg_xy vertices, as an unnamed data stroke is its two ends
        names = ["#%d" % i for i in range(len(sx))]
        for i, p in enumerate(sx):
            P["#%d" % i] = (float(p[0]), float(p[1]))
    need = {"segment": 2, "angle": 3}.get(ty, 3)
    if len(names) < need or (ty != "polygon" and len(names) != need) or \
            any(n not in P for n in names):
        return ["its name %r does not place %d drawn point(s): the mapping "
                "is ambiguous" % (o.get("name"), need)]
    out, ink, marks = [], [], []
    for pt in parts:
        sid = pt.get("svg_id") if isinstance(pt, dict) else None
        e = elem(sid) if sid else None
        if e is None:
            out.append("part %s is not one element of the SVG" % sid)
            continue
        tag, a, geom = e
        dm = a.get("data-mark")
        span = pt.get("span")
        grp = tag == "g" and a.get("_edges") and not a.get("_other")
        if grp or (not dm and (tag in ("line", "polyline", "polygon") or
                               (tag == "path" and a.get("data-seg")))):
            edges = list(a["_edges"]) if grp else list(zip(geom, geom[1:]))
            if tag == "polygon" and len(geom) > 2:
                edges.append((geom[-1], geom[0]))
            if not edges:
                out.append("part %s draws no stroke" % sid)
                continue
            if span:
                sp = [str(x) for x in span] if isinstance(span, list) else []
                if len(sp) != 2 or sp[0] == sp[1] or \
                        any(x not in P for x in sp):
                    out.append("part %s: span %r is not two drawn points"
                               % (sid, span))
                    continue
                X, Y = P[sp[0]], P[sp[1]]
                if not any(_u_d(X, p, q) <= tol and _u_d(Y, p, q) <= tol
                           for p, q in edges):
                    out.append("part %s: span %s%s is not on that stroke"
                               % (sid, sp[0], sp[1]))
                    continue
                ink.append((X, Y, sid, "%s%s" % tuple(sp)))
            else:
                ink += [(p, q, sid, "whole") for p, q in edges]
        else:
            if span:
                out.append("part %s: a span on a %s (not a stroke)"
                           % (sid, tag))
            marks.append((sid, tag, a, geom))
    if ty == "segment":
        tg = [(names[0], names[1])]
    elif ty == "polygon":
        tg = list(zip(names, names[1:] + names[:1]))
    else:
        tg = [(names[1], names[0]), (names[1], names[2])]
    for p, q, sid, w in ink:
        if not any(_u_d(p, P[x], P[y]) <= tol and _u_d(q, P[x], P[y]) <= tol
                   for x, y in tg):
            out.append("extra ink: part %s (%s) paints (%.1f,%.1f)-(%.1f,%.1f)"
                       ", which is not %s" % (sid, w, p[0], p[1], q[0], q[1],
                                              {"segment": "the segment itself",
                                               "angle": "an arm of it"}.get(
                                                  ty, "a side of it")))
    for x, y in tg:
        on = [(p, q) for p, q, _s, _w in ink
              if _u_d(p, P[x], P[y]) <= tol and _u_d(q, P[x], P[y]) <= tol]
        gaps = _u_cover(on, P[x], P[y], tol)
        if gaps:
            out.append("missing: %s%s is not painted over %.1f of %.1f px"
                       % (x, y, sum(e - s for s, e in gaps),
                          math.hypot(P[y][0] - P[x][0],
                                     P[y][1] - P[x][1])))
    if ty != "angle":
        own = frozenset(names)
        for sid, tag, a, geom in marks:
            dm = str(a.get("data-mark") or "")
            df = str(a.get("data-for") or "")
            if ty == "segment" and tag == "text" and df.startswith("seg ") \
                    and frozenset(_U_NAMES.findall(df[4:])) == own:
                continue
            kd, _s, on = dm.partition(" ")
            if ty == "segment" and re.sub(r"\d+$", "", kd) in (
                    "tick", "par") and geom and \
                    frozenset(_U_NAMES.findall(on)) == own:
                # its own tick / parallel arrow: named for it, on it
                mid = (sum(p[0] for p in geom) / len(geom),
                       sum(p[1] for p in geom) / len(geom))
                if any(_u_d(q, P[names[0]], P[names[1]]) <= tol
                       for q in [mid] + list(geom)):
                    continue
            out.append("extra ink: part %s (a %s%s) is not a stroke or a "
                       "mark of it" % (sid, tag, " " + repr(dm or df)
                                       if dm or df else ""))
        return out
    V, A, B = P[names[1]], P[names[0]], P[names[2]]
    me = (names[1], frozenset((names[0], names[2])))
    sector = False
    for sid, tag, a, geom in marks:
        dm = a.get("data-mark") or ""
        if tag == "text":
            if _u_mark_angle(a.get("data-for")) != me:
                out.append("extra ink: caption %s belongs to %r, not this "
                           "angle" % (sid, a.get("data-for")))
            continue
        if _u_mark_angle(dm) != me:
            out.append("extra ink: part %s (%s %r) is no mark of this angle"
                       % (sid, tag, dm))
            continue
        kind = re.sub(r"\d+$", "", dm.split(" ", 1)[0])
        if kind == "arc" and len(geom) >= 2:
            r = [math.hypot(p[0] - V[0], p[1] - V[1]) for p in geom]
            onr = [p for p in geom if _u_ray(V, A, p, tol) or
                   _u_ray(V, B, p, tol)]
            if max(r) - min(r) > tol or min(r) <= tol or len(onr) < 2:
                out.append("part %s: its arc is not centred on %s from arm "
                           "to arm" % (sid, names[1]))
                continue
            sector = True
        elif kind == "right" and len(geom) == 3:
            e1, e3 = geom[0], geom[2]
            if not ((_u_ray(V, A, e1, tol) and _u_ray(V, B, e3, tol)) or
                    (_u_ray(V, B, e1, tol) and _u_ray(V, A, e3, tol))):
                out.append("part %s: its right-angle mark does not sit on "
                           "the arms at %s" % (sid, names[1]))
                continue
            sector = True
        else:
            out.append("part %s: a %s mark highlight cannot read" % (sid,
                                                                    kind))
    if not sector:
        la = math.hypot(A[0] - V[0], A[1] - V[1])
        lb = math.hypot(B[0] - V[0], B[1] - V[1])
        sw = math.degrees(abs((math.atan2(B[1] - V[1], B[0] - V[0]) -
                               math.atan2(A[1] - V[1], A[0] - V[0]) +
                               math.pi) % (2 * math.pi) - math.pi))
        if not (1.0 <= sw <= 179.0) or min(18.0, 0.45 * min(la, lb)) < 9.0:
            out.append("no sector: no arc / right-angle mark of it among its "
                       "parts and no room for a focus arc (%.1f deg)" % sw)
    return out


def _u_origin(o, elem):
    """(v6.16 gaps, corpus-v2 G2) the ORIGIN of a coordinate plane paints
    the two axis lines (they cross there) and the origin's printed '0' --
    both lines, the '0' when the figure prints one, nothing else."""
    parts = o.get("parts")
    if not (isinstance(parts, list) and parts):
        return ["nothing is drawn to highlight"]
    out, axes, zero = [], set(), False
    for pt in parts:
        sid = pt.get("svg_id") if isinstance(pt, dict) else None
        e = elem(sid) if sid else None
        if e is None:
            out.append("part %s is not one element of the SVG" % sid)
            continue
        tag, a, _geom = e
        if pt.get("span"):
            out.append("part %s: a span on the origin" % sid)
        elif tag == "line" and a.get("data-axis"):
            axes.add(a.get("data-axis"))
        elif tag == "text" and a.get("data-num") == "origin":
            zero = True
        else:
            out.append("extra ink: part %s (a %s) is not an axis line or the "
                       "origin's 0" % (sid, tag))
    if len(axes) != 2:
        out.append("the origin paints %d axis line(s), not the two that "
                   "cross there" % len(axes))
    allel = getattr(elem, "all", None) or {}
    if not zero and any(t == "text" and a.get("data-num") == "origin"
                        for hit in allel.values() for t, a in hit):
        out.append("missing: the origin's printed 0 is not painted")
    return out


def _u_partial(o, pts, elem, tol):
    """(v6.16 gaps, corpus-v2 G1) a PARTIAL polygon -- a polygon the figure
    shows only some vertices of ('shown'; the missing one is the answer) --
    paints exactly its shown part: the dots of its shown vertices, and each
    side between two consecutive shown vertices wholly when the figure draws
    it (a data segment / line / ray over it) -- nothing of a missing vertex,
    no ink off those sides."""
    nm = _geometry_name(o)
    names = _U_NAMES.findall(nm)
    shown = [str(x) for x in o.get("shown") or []] \
        if isinstance(o.get("shown"), list) else []
    P = dict((str(k), tuple(float(c) for c in v)) for k, v in pts.items())
    if "".join(names) != nm or len(names) < 3 or \
            len(set(names)) != len(names):
        return ["partial polygon %r: its name is not a polygon's" % nm]
    if not shown or len(set(shown)) >= len(names) or \
            any(x not in names for x in shown):
        return ["partial polygon %s: shown %r is not a proper part of its "
                "vertices" % (nm, shown)]
    if any(x not in P for x in shown):
        return ["partial polygon %s: a shown vertex is no drawn point" % nm]
    back = [x for x in names if x not in shown and x in P]
    if back:
        return ["partial polygon %s: its missing vertex %s is drawn"
                % (nm, ", ".join(back))]
    tg = [(x, y) for x, y in zip(names, names[1:] + names[:1])
          if x in shown and y in shown]
    parts = o.get("parts")
    if not (isinstance(parts, list) and parts):
        return ["nothing is drawn to highlight"]
    out, ink, dots = [], [], set()
    for pt in parts:
        sid = pt.get("svg_id") if isinstance(pt, dict) else None
        e = elem(sid) if sid else None
        if e is None:
            out.append("part %s is not one element of the SVG" % sid)
            continue
        tag, a, geom = e
        span = pt.get("span")
        if tag == "circle" and not span:
            n = str(a.get("data-pt") or "")
            if n in shown and geom and abs(geom[0][0] - P[n][0]) <= tol and \
                    abs(geom[0][1] - P[n][1]) <= tol:
                dots.add(n)
            else:
                out.append("extra ink: part %s is not the dot of a shown "
                           "vertex" % sid)
            continue
        if tag != "line" or a.get("data-mark") or len(geom) != 2:
            out.append("extra ink: part %s (a %s) is not a side or a dot of "
                       "it" % (sid, tag))
            continue
        if span:
            sp = [str(x) for x in span] if isinstance(span, list) else []
            if len(sp) != 2 or any(x not in P for x in sp) or \
                    not (_u_d(P[sp[0]], geom[0], geom[1]) <= tol and
                         _u_d(P[sp[1]], geom[0], geom[1]) <= tol):
                out.append("part %s: span %r is not two drawn points on "
                           "that stroke" % (sid, span))
                continue
            ink.append((P[sp[0]], P[sp[1]], sid))
        else:
            ink.append((geom[0], geom[1], sid))
    for p, q, sid in ink:
        if not any(_u_d(p, P[x], P[y]) <= tol and _u_d(q, P[x], P[y]) <= tol
                   for x, y in tg):
            out.append("extra ink: part %s paints (%.1f,%.1f)-(%.1f,%.1f), "
                       "which is no side between two shown vertices"
                       % (sid, p[0], p[1], q[0], q[1]))
    allel = getattr(elem, "all", None) or {}
    for x, y in tg:
        on = [(p, q) for p, q, _s in ink
              if _u_d(p, P[x], P[y]) <= tol and _u_d(q, P[x], P[y]) <= tol]
        drawn = any(t == "line" and (a.get("data-seg") or a.get("data-line")
                                     or a.get("data-ray")) and
                    _u_d(P[x], *_u_geom(t, a)) <= tol and
                    _u_d(P[y], *_u_geom(t, a)) <= tol
                    for hit in allel.values() for t, a in hit)
        if on or drawn:
            gaps = _u_cover(on, P[x], P[y], tol)
            if gaps:
                out.append("missing: %s%s is not painted over %.1f px"
                           % (x, y, sum(e_ - s_ for s_, e_ in gaps)))
    for x in shown:
        if x not in dots:
            out.append("missing: the dot of the shown vertex %s" % x)
    return out


def union_elem_of(svg_text):
    """svg id -> (tag, attrs, points) read from the SVG text as written
    (no transforms: the overlay is painted in the same frame)."""
    rx = re.compile(r"<(line|circle|path|polyline|polygon|rect|text|g)\b"
                    r"([^>]*?)/?>", re.S)
    at = re.compile(r'([\w:-]+)="([^"]*)"')
    found = {}
    for m in rx.finditer(svg_text):
        a = dict(at.findall(m.group(2)))
        if a.get("id"):
            if m.group(1) == "g":
                # a builder's group id: its child strokes are its ink
                a = dict(a, _edges=[], _other=0)
                depth = 0 if m.group(0).endswith("/>") else 1
                tok = re.compile(r"</g\s*>|" + rx.pattern, re.S)
                for c in tok.finditer(svg_text, m.end()):
                    if depth <= 0:
                        break
                    if c.group(0).startswith("</"):
                        depth -= 1
                        continue
                    if c.group(1) == "g":
                        depth += 0 if c.group(0).endswith("/>") else 1
                        continue
                    ca = dict(at.findall(c.group(2)))
                    cg = _u_geom(c.group(1), ca)
                    if c.group(1) in ("line", "polyline", "polygon") and \
                            not ca.get("data-mark") and len(cg) >= 2:
                        a["_edges"] += list(zip(cg, cg[1:])) + (
                            [(cg[-1], cg[0])] if c.group(1) == "polygon"
                            and len(cg) > 2 else [])
                    else:
                        a["_other"] += 1
            found.setdefault(a["id"], []).append((m.group(1), a))

    def elem(sid):
        hit = found.get(sid) or []
        if len(hit) != 1:
            return None
        tag, a = hit[0]
        return tag, a, _u_geom(tag, a)
    elem.all = found          # v6.16 gaps: what the figure draws (G1 / G2)
    return elem


def _u_geom(tag, a):
    g = lambda k: float(a.get(k, 0))                     # noqa: E731
    if tag == "line":
        return [(g("x1"), g("y1")), (g("x2"), g("y2"))]
    if tag == "circle":
        return [(g("cx"), g("cy"))]
    if tag == "text":
        return [(g("x"), g("y"))]
    if tag in ("polyline", "polygon"):
        v = [float(x) for x in _U_UNITS.findall(a.get("points", ""))]
        return list(zip(v[0::2], v[1::2]))
    if tag == "path":
        d = a.get("d", "")
        if re.search(r"[^ML\s\d.,eE+-]", d):
            return []                  # a curve: no straight pieces to read
        v = [float(x) for x in _U_UNITS.findall(d)]
        return list(zip(v[0::2], v[1::2]))
    return []
# ---- end of the C1r2 block -------------------------------------------------


FOCUS_R, FOCUS_MIN_R, FOCUS_SHARE, FOCUS_STEP = 18.0, 9.0, 0.45, 5.0
_NAMES = re.compile(r"[A-Z][1-9]?'{0,3}")


def focus_arc(oid, pts):
    """d= of the focus arc of angle oid ('ang:ACB', vertex C) from the drawn
    points {name: [x, y]}, or None (not an angle / points not drawn / no
    sector: a straight angle / arms too short)."""
    import math
    if not str(oid).startswith("ang:"):
        return None
    ns = _NAMES.findall(oid[4:])
    if "".join(ns) != oid[4:] or len(ns) != 3 or any(n not in pts
                                                      for n in ns):
        return None
    a, v, b = [tuple(float(c) for c in pts[n]) for n in ns]
    la = math.hypot(a[0] - v[0], a[1] - v[1])
    lb = math.hypot(b[0] - v[0], b[1] - v[1])
    ua = math.atan2(a[1] - v[1], a[0] - v[0])
    ub = math.atan2(b[1] - v[1], b[0] - v[0])
    sw = (ub - ua + math.pi) % (2 * math.pi) - math.pi
    if not (1.0 <= abs(math.degrees(sw)) <= 179.0):
        return None
    r = min(FOCUS_R, FOCUS_SHARE * min(la, lb))
    if r < FOCUS_MIN_R:
        return None
    n = max(2, int(math.ceil(abs(math.degrees(sw)) / FOCUS_STEP)))
    return "M " + " L ".join(
        "%s %s" % (_n(v[0] + r * math.cos(ua + sw * k / float(n))),
                   _n(v[1] + r * math.sin(ua + sw * k / float(n))))
        for k in range(n + 1))


def _object_ids(F, oid):
    """the model objects highlighting oid paints (itself, or the objects
    of the relation it offers)."""
    vm = F.get("visual_model") or {}
    objs = dict((o.get("id"), o) for o in vm.get("objects") or []
                if isinstance(o, dict))
    if oid in objs:
        return [objs[oid]]
    rels = dict((r.get("id"), r) for r in vm.get("relations") or [])
    return [objs[x] for x in (rels.get(oid) or {}).get("objects") or []
            if x in objs]


def _angle_ids(F, oid):
    """the angle objects oid highlights (itself, or a relation's)."""
    vm = F.get("visual_model") or {}
    objs = dict((o.get("id"), o) for o in vm.get("objects") or []
                if isinstance(o, dict))
    if oid in objs:
        ids = [oid]
    else:
        rels = dict((r.get("id"), r) for r in vm.get("relations") or [])
        ids = list((rels.get(oid) or {}).get("objects") or [])
    return [i for i in ids if str(i).startswith("ang:") and
            (objs.get(i) or {}).get("type") in (None, "angle")]


def _element(svg, sid):
    for m in _EL.finditer(svg):
        a = dict(_ATTR.findall(m.group(2)))
        if a.get("id") == sid:
            return m.group(1), a, m
    return None


def _n(v):
    return ("%.2f" % float(v)).rstrip("0").rstrip(".")


def _copy(svg, tag, a, m, sid):
    """one overlay element that repeats the geometry of element sid."""
    base = ' data-hl="%s"' % sid
    if tag == "line":
        return ('<line%s x1="%s" y1="%s" x2="%s" y2="%s" stroke="%s" '
                'stroke-width="%s" stroke-linecap="round"/>'
                % (base, a["x1"], a["y1"], a["x2"], a["y2"], HL, HL_W))
    if tag == "circle":
        hook = a.get("data-pie")
        if hook is not None and hook != "bdot":
            # (v6.16.1, Codex AI-HL-2) a PIE outline / build circle is no
            # point: the same circle at its OWN radius, an UNFILLED
            # highlight stroke. A pie overlay lies above the wedges, so the
            # old dot halo (a filled disk r+3) hid every sector boundary.
            return ('<circle%s cx="%s" cy="%s" r="%s" fill="none" '
                    'stroke="%s" stroke-width="%s"/>'
                    % (base, a["cx"], a["cy"], a["r"], HL, HL_W))
        if hook == "bdot":
            # (v6.16.1) a pie's centre dot: the overlay lies ABOVE a pie,
            # so its halo is a ring around the dot (r .. r+3), not a disk
            # over it -- the dot itself stays visible
            r0 = float(a.get("r", 2))
            return ('<circle%s cx="%s" cy="%s" r="%s" fill="none" '
                    'stroke="%s" stroke-width="3"/>'
                    % (base, a["cx"], a["cy"], _n(r0 + 1.5), HL))
        # (fix r2, P4) a corner dot (r 0.75, hidden in the join) gets the
        # same halo as a printed dot
        r = max(float(a.get("r", 2)), 2.0) + 3.0
        return ('<circle%s cx="%s" cy="%s" r="%s" fill="%s" stroke="none"/>'
                % (base, a["cx"], a["cy"], _n(r), HL))
    if tag == "path":
        return ('<path%s d="%s" fill="none" stroke="%s" stroke-width="%s" '
                'stroke-linecap="round" stroke-linejoin="round"/>'
                % (base, a["d"], HL, HL_W))
    if tag in ("polyline", "polygon"):
        return ('<%s%s points="%s" fill="none" stroke="%s" '
                'stroke-width="%s" stroke-linejoin="round"/>'
                % (tag, base, a["points"], HL, HL_W))
    if tag == "rect":
        return ('<rect%s x="%s" y="%s" width="%s" height="%s" fill="%s" '
                'stroke="none"/>' % (base, a.get("x", 0), a.get("y", 0),
                                     a.get("width", 0), a.get("height", 0),
                                     HL))
    if tag == "text":
        end = svg.index("</text>", m.end())
        txt = svg[m.end():end]
        fs = float(a.get("font-size", 12))
        w = 0.62 * fs * max(1, len(txt))
        x, y = float(a.get("x", 0)), float(a.get("y", 0))
        anc = a.get("text-anchor", "start")
        x0 = x - w / 2.0 if anc == "middle" else (x - w if anc == "end"
                                                   else x)
        return ('<rect%s x="%s" y="%s" width="%s" height="%s" fill="%s" '
                'stroke="none"/>' % (base, _n(x0 - 2), _n(y - 0.8 * fs - 2),
                                     _n(w + 4), _n(fs + 4), HL))
    if tag == "g":
        # a builder's group id: every drawn child of the group
        end = _group_end(svg, m)
        inner = svg[m.end():end]
        out = []
        for mm in _EL.finditer(inner):
            t2 = mm.group(1)
            if t2 in ("g",):
                continue
            aa = dict(_ATTR.findall(mm.group(2)))
            try:
                out.append(_copy(inner, t2, aa, mm, sid))
            except (KeyError, ValueError):
                continue
        if not out:
            raise HighlightError("svg id %s draws nothing" % sid)
        return "".join(out)
    raise HighlightError("svg id %s is a <%s>, which has no geometry to "
                         "repeat" % (sid, tag))


def _group_end(svg, m):
    depth, k = 1, m.end()
    if m.group(3) == "/":
        return m.end()
    for mm in re.finditer(r"<(/?)g\b[^>]*?(/?)>", svg[k:]):
        if mm.group(2) == "/":
            continue
        depth += -1 if mm.group(1) else 1
        if depth == 0:
            return k + mm.start()
    raise HighlightError("unbalanced <g>")


def highlight(level, fid, oid):
    """(highlighted svg text, [(svg_id, span)])."""
    nj = _load(level)
    F = _figure(nj, fid)
    p = os.path.join(level, F.get("svg") or "")
    if not F.get("svg") or not os.path.isfile(p):
        raise HighlightError("figure %s: SVG %s missing" % (fid, F.get("svg")))
    with open(p, encoding="utf-8") as fh:
        svg = fh.read()
    parts = parts_of(F, oid)
    pts = _points(F)
    # (v6.10, C1r2) what the overlay paints must BE the object: the union
    # of its parts after span limits, no extra ink, no missing piece --
    # anything else (a part without its span, a missing arm / side, an
    # extra line, a mapping it cannot place) is refused, never drawn
    el = union_elem_of(svg)
    for o in _object_ids(F, oid):
        bad = union_faults(o, pts, el)
        if bad:
            raise HighlightError("object %s of %s: its highlight would not "
                                 "be the object (%s)" % (
                                     o.get("id"), fid, "; ".join(bad[:3])))
    ov = []
    for sid, span in parts:
        if len(re.findall(r'\sid="%s"' % re.escape(sid), svg)) != 1:
            raise HighlightError("svg id %s is not exactly once in %s"
                                 % (sid, F.get("svg")))
        tag, a, m = _element(svg, sid)
        if span:
            if not all(str(x) in pts for x in span):
                raise HighlightError("part %s spans %r: not two drawn points"
                                     % (sid, span))
            (x1, y1), (x2, y2) = pts[str(span[0])], pts[str(span[1])]
            ov.append('<line data-hl="%s" data-span="%s%s" x1="%s" y1="%s" '
                      'x2="%s" y2="%s" stroke="%s" stroke-width="%s" '
                      'stroke-linecap="round"/>'
                      % (sid, span[0], span[1], _n(x1), _n(y1), _n(x2),
                         _n(y2), HL, HL_W))
        else:
            ov.append(_copy(svg, tag, a, m, sid))
    vm_objs = dict((o.get("id"), o) for o in
                   (F.get("visual_model") or {}).get("objects") or []
                   if isinstance(o, dict))
    for aid in _angle_ids(F, oid):
        marks = []
        for p in (vm_objs.get(aid) or {}).get("parts") or []:
            e = _element(svg, p.get("svg_id"))
            if e:
                marks.append((e[1].get("data-mark") or "").split(" ")[0])
        if "arc" in marks or "right" in marks:
            continue                    # the figure prints it: no focus arc
        d = focus_arc(aid, pts)
        if d:
            ov.append('<path data-focus="%s" d="%s" fill="none" stroke="%s" '
                      'stroke-width="3" stroke-linecap="round" '
                      'stroke-linejoin="round"/>' % (aid, d, HL))
    m = _START.search(svg)
    if not m:
        raise HighlightError("no <svg> start tag")
    layer = '<g data-layer="highlight" data-object="%s">%s</g>' % (
        oid, "".join(ov))
    if 'data-pie="' in svg:
        # (v6.16 integrate) a PIE chart: its wedges are FILLED, so an
        # overlay under the figure would be hidden -- it lies on the wedges
        # and under the labels (as render/pie_hl.py places it); strip()
        # removes it the same way.
        # (v6.16.1, Codex AI-HL-1) a pie WITHOUT a labels layer gets it at
        # the end of the file, above every wedge -- it used to fall through
        # to the graph placement below and lie under the opaque wedges
        lab = _PIE_LABELS.search(svg)
        at = lab.start() if lab is not None else svg.rfind("</svg>")
        if at < 0:
            raise HighlightError("pie figure %s has no </svg> end tag" % fid)
        return svg[:at] + layer + svg[at:], parts
    # a graph / geometry figure (unfilled): the overlay goes right after the
    # <svg> start tag, UNDER the figure (unchanged)
    return svg[:m.end()] + layer + svg[m.end():], parts


_PIE_LABELS = re.compile(r'<g data-layer="labels">')


def strip(svg):
    """The figure without the overlay: the original bytes."""
    return _OVERLAY.sub("", svg, count=1)


def main(argv):
    out = None
    if "-o" in argv:
        k = argv.index("-o")
        out = argv[k + 1]
        argv = argv[:k] + argv[k + 2:]
    if len(argv) != 3:
        print(__doc__.strip().splitlines()[2].strip())
        return 2
    try:
        svg, parts = highlight(*argv)
    except HighlightError as e:
        sys.stderr.write("highlight: %s\n" % e)
        return 2
    if out:
        with open(out, "w", encoding="utf-8") as fh:
            fh.write(svg)
        sys.stderr.write("highlight: %s of %s -> %s (%d part(s): %s)\n" % (
            argv[2], argv[1], out, len(parts),
            ", ".join(s + ("[%s%s]" % tuple(sp) if sp else "")
                      for s, sp in parts)))
    else:
        sys.stdout.write(svg)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
