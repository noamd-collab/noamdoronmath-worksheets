// wspec_ocr: macOS Vision OCR for the wspec checker (derived from regen/ocr_probe.swift).
// Build once:  swiftc -O -o tools/wspec_ocr tools/wspec_ocr.swift
// Usage:       wspec_ocr [--lang en-US[,he-IL]] img1.png [img2.png ...]
// Output:      for each image a line "#FILE<TAB>path", then one line per recognised
//              text: candidate<TAB>confidence<TAB>x y w h (Vision normalised box, origin bottom-left),
//              up to 3 candidates per observation joined by <TAB>|<TAB> is NOT used: only the top 3 are
//              printed as separate "#ALT" lines after the main one.
import Foundation
import Vision
import AppKit

var langs = ["en-US"]
var files: [String] = []
var i = 1
let args = CommandLine.arguments
while i < args.count {
    if args[i] == "--lang", i + 1 < args.count { langs = args[i + 1].split(separator: ",").map(String.init); i += 2; continue }
    files.append(args[i]); i += 1
}
for f in files {
    print("#FILE\t\(f)")
    let url = URL(fileURLWithPath: f)
    guard let img = NSImage(contentsOf: url),
          let cg = img.cgImage(forProposedRect: nil, context: nil, hints: nil) else { print("#ERR\tload"); continue }
    let req = VNRecognizeTextRequest()
    req.recognitionLevel = .accurate
    req.usesLanguageCorrection = false
    req.recognitionLanguages = langs
    req.minimumTextHeight = 0.0
    let h = VNImageRequestHandler(cgImage: cg, options: [:])
    do { try h.perform([req]) } catch { print("#ERR\tperform"); continue }
    for o in req.results ?? [] {
        let cands = o.topCandidates(3)
        guard let c = cands.first else { continue }
        let b = o.boundingBox
        print("\(c.string)\t\(c.confidence)\t\(b.origin.x) \(b.origin.y) \(b.size.width) \(b.size.height)")
        for alt in cands.dropFirst() { print("#ALT\t\(alt.string)\t\(alt.confidence)") }
    }
}
