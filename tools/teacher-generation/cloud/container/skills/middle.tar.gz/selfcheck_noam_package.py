# -*- coding: utf-8 -*-
r"""selfcheck_noam_package.py -- an INDEPENDENT checker of the public Noam AI
package (v6.7-noam, BRIEF_V68 §5.6). It imports nothing from the skill:
only the Python standard library reads noam-ai.json and the SVG files the
site will serve.

    python3 selfcheck_noam_package.py out/deliver/a out/deliver/b out/deliver/c
    python3 selfcheck_noam_package.py          # its own pass + fail fixtures

A level folder FAILS when (each rule has a fail fixture below):
  K1  noam-ai.json is missing (or is not JSON)
  K2  a key at any depth is not one the public schema (SCHEMA below)
      names in that place -- a WHITELIST, so answer_text, correct_answer,
      תשובה, solution_steps, md5, generated_at, key ... all fail; a
      given / to_prove entry that is not an object; a dict hidden in a
      value
  K3  a string value at any depth names a path or code ('/private/',
      '/Users/', '/home/', '/tmp/', '~/', any absolute path, 'source/',
      '.py'), is / carries a hex hash of 32+ digits, or a timestamp
  K4  a figure's SVG file is missing
  K5  an object's svg_id does not occur exactly once in its figure's SVG,
      or its element is hidden (display:none, visibility:hidden or
      opacity 0 on it or on an enclosing group, as attribute or style)
  K6  a point, segment, angle or circle named in a question's or an item's
      given / to_prove is not an object of that question's figures -- in
      a typed field, in a field of an unknown claim type, or in the
      claim's printed text (a plain-string claim is read as its text)
  K7  an object has no svg_xy, or its svg_xy is more than 1 px from its
      element in the SVG (a mark may instead carry ink_xy, which must then
      be on its ink)
  K8  an object's xy does not map to its svg_xy through view.data_to_svg
      (1 px); a point of a figure with data_to_svg has no xy
  K9  a question's or an item's figure_id is not a figure of the package
  K10 package is not G<grade>-T<nn>, level not a/b/c, or given / to_prove
      / figure_id missing on a question or item; several folders name
      different packages or repeat a level
  K11 v6.7.1-noam: the PRIVATE didactic record leaks into noam-ai.json --
      a didactic key (hint_type, exposure, requires_human_review,
      forbidden_to_show, aux_allowed, approved, approved_by,
      review_reasons, the didactic/v1 schema) at any depth
  K12 v6.7.1-noam: a hint that is not approved -- hint_mode not one of
      guiding_question / concept / approved_hint; approved_hint text
      without hint_mode approved_hint (or the reverse); an approved_hint
      that the folder's didactic.json does not record as approved (by a
      human, approved_by) with the same text; any hint text of
      didactic.json that is not approved appearing anywhere in the file
  K14 v6.7.1-noam §9: a figure with no visual-model/v1; an action outside
      show / highlight / show_aux; highlight beyond highlight_given; an
      unsupported visual that ships an SVG or something to show; an aux
      patch not on request / unlabelled / without its step; an op outside
      add / show / highlight
  K13 v6.7.1-noam: the givens overlay (visual_model.highlight_given and
      given_highlight objects) marks a relation that is a
      to_prove / to_construct of its question (and not a given carried
      over with from_item), or one that is no given at all
  K15 v6.7.2-noam: a find target ({"type": "find", "quantity": ...}) in
      given / to_prove that carries its value (the value is the answer --
      sheet.json only)
  K17 v6.10 (Codex C1r2): highlighting a visual_model segment / angle /
      polygon would not paint exactly the object -- the union of its
      parts after span limits (or its svg_id element) has ink outside it,
      leaves a piece of it unpainted, shows no sector of an angle, or
      cannot be placed (refused, never guessed)
  K18 v6.10 (Codex E2): an engine figure (derived from the model's parts,
      the wspec.render scripts, the engine SVG dialect, build.json /
      sheet.json -- not from the map files present) ships no
      figures/<id>.map.json, or a map of another figure, with other
      element ids / tags than its SVG, other parts than the model, or
      another public_hash than wspec/public_spec.json
  K19 v6.10 (Codex C3): highlight_given does not hold exactly what a
      typed-shape given states -- a statement missing (one pair of
      parallel sides of a given parallelogram), a relation derived from a
      shape that is no given (to be proved, carried with from_item), or
      one the shape does not state; a statement the figure cannot settle
  K20 v6.10 fix r1: a highlight_given entry with no given mark of its own
  K21 v6.10 fix r2: a given the overlay can mark (a typed given claim of a
      row the figure serves, not carried, whose points the figure shows) is
      not a given relation offered in highlight_given and actions.highlight
  K22 v6.10 fix r2: a numeric label names (`for`) an object whose given /
      context value is not the number it prints, or a copy of the label
      (visual_model, aux patch) has no `for` or names another object
  K23 v6.10 fix r2: a text of wspec/public_spec.json is not the text of the
      same noam-ai.json row (the public spec says what the sheet prints)
  K24 v6.12 fix_r1 (M1-readoff): a coordinate-plane or number-line figure
      (visual_model kind coordinate_plane / number_line) of a question that
      asks to find something (a find target in given / to_prove, or a
      no_target_reason) carries its data frame -- view / visual_model view
      data_to_svg, data_unit_px or step, or an object's xy / xyz /
      measures_xy / value: the read-off answer would be public
  K25 v6.14 fix_r1 (W-META-LINES-3, the author's condition of 25.9): a
      line in one of the three approved UNPRINTED wordings ('המספר שמייצגת
      הנקודה A', 'ההפרש בין הערכים של שני קווי רשת סמוכים על ציר x' [= v],
      'AB ∥ ציר x') that does not restate exactly ONE printed given or
      target of its own row: no `facts` link, a fact the public spec lacks,
      a fact of another row or one the row's bound text does not print, a
      to_prove line linking no target / a given line linking a target, a
      text that is not the wording rebuilt from the fact (a word, a hint, a
      value or another name added), a key beyond text / facts (/ type /
      of), a line the public spec's scope does not list; on a row with no
      public spec (builder) only the typed ∥ given its question prints in
      words; a visual_model relation in such a wording that no row claim
      states
  K16 v6.9: a visual_model object that carries `parts` (an engine figure:
      the object id -> the svg ids that draw it) -- every part's svg_id
      occurs exactly once in its figure's SVG and is printed (not hidden);
      a part's span names two points the model draws; an object with a
      null svg_id and parts carries at least one part; an object id names
      one object of its model
Exit status 0 only when every folder is clean (fixtures: when every pass
fixture passes AND every fail fixture is caught by its own rule).
"""
import json
import math
import os
import re
import shutil
import sys
import tempfile
import xml.etree.ElementTree as ET

TOL = 1.0
NS = "{http://www.w3.org/2000/svg}"
NUM = re.compile(r"-?\d*\.?\d+(?:[eE][-+]?\d+)?")
PACKAGE_RE = re.compile(r"^G(?:[7-9]|1[0-2])-T[0-9]{2}$")
LEVELS = ("a", "b", "c")

# K2 is a WHITELIST: the public schema (noam-ai/v1), written down here
# independently of deliver.py. A key the schema does not name, at any
# depth, fails -- whatever it is called (answer_text, correct_answer,
# תשובה, md5, generated_at, key ...). DENY only words the message.
_CLAIM = ("text", "type", "points", "point", "of", "t", "at", "rays",
          "value", "unit", "circle", "to", "space", "from_item",
          # v6.7.2-noam: a find target (quantity + object; no value)
          "quantity", "what", "curve", "x",
          # v6.14 (F2 / F3): the public fact ids a printed given restates
          "facts")
SCHEMA = {
    "top": ("schema_version", "package", "level", "questions", "figures",
            "curriculum", "visuals"),
    "question": ("id", "label", "text", "figure_id", "given", "to_prove",
                 "items", "table", "example", "to_construct", "hint_mode",
                 "approved_hint", "aux", "no_target_reason", "variables",
                 # v6.9 (Codex F4): the question is spec-unsupported
                 "spec_unsupported"),
    "spec_gap": ("reason", "missing"),
    "item": ("id", "label", "text", "figure_id", "given", "to_prove",
             "to_construct", "hint_mode", "approved_hint", "aux",
             "no_target_reason", "variables"),
    "curriculum": ("grade", "track", "topic", "unit", "allowed_tools",
                   "not_yet_allowed"),
    "tool": ("id", "name"),
    # v6.7.1-noam §9: the general visual layer (visual-model/v1)
    "visual_model": ("schema_version", "id", "kind", "visual_support",
                     "reason", "question", "item", "svg", "view", "data",
                     "objects", "relations", "highlight_given", "aux",
                     "actions"),
    "vm_view": ("viewbox", "data_to_svg", "data_unit_px", "frame", "sketch",
                "rotate", "step"),
    "vm_data": ("size", "stages", "rows", "cols", "total", "universe",
                "scale"),
    "vm_object": ("id", "svg_id", "type", "part", "name", "letter", "text",
                  "xy", "xyz", "svg_xy", "bbox", "r", "n", "for", "series",
                  "legend", "marker", "row", "col", "value", "label",
                  "parent", "p", "leaf_p", "frequency", "relative", "in",
                  "count", "total", "height_px", "angle", "expr",
                  "category", "mark", "on", "role", "display",
                  # v6.9: an engine figure's object -> its svg ids (K16)
                  "parts",
                  # v6.16 gaps (G1): a partial polygon's shown vertices
                  "shown"),
    "vm_part": ("svg_id", "span"),
    "vm_relation": ("id", "type", "role", "item", "points", "point", "of",
                    "t", "at", "rays", "value", "unit", "circle", "to",
                    "space", "text", "from_item", "objects", "measured",
                    "quantity", "what", "x",
                    "marked", "mark_id", "mark_ids", "violated", "highlight",
                    # v6.10 (C3): a relation a typed-shape given states
                    "from_given",
                    "row", "col", "curve", "node", "set", "sets", "bar",
                    "sector"),
    "vm_aux": ("id", "svg", "label", "reveal", "step", "item", "completes",
               "ops"),
    "vm_op": ("op", "ids", "objects", "relations"),
    "vm_actions": ("allowed", "show", "highlight", "show_aux"),
    "claim": _CLAIM,
    "operand": ("at", "rays"),
    "table": ("head", "rows"),
    "example": ("title", "lines"),
    "figure": ("id", "svg", "question", "item", "view", "objects",
               "constraints", "visual_model"),
    "view": ("width_px", "height_px", "unit_px", "viewbox", "rotate",
             "data_to_svg", "data_unit_px", "frame", "rows", "sketch"),
    "view_row": ("row", "id_prefix", "offset", "data_to_svg"),
    "objects": ("points", "segments", "lines", "rays", "angles", "polygons",
                "circles", "arcs", "marks", "labels", "dimensions", "paths"),
    "object": ("svg_id", "kind", "role", "name", "text", "for", "for_part",
               "xy", "xyz", "svg_xy", "ink_xy", "ink_box", "ink_svg_id",
               "measures_xy", "measures_svg_xy", "n", "r", "space",
               "letter_printed", "series", "legend", "marker", "row",
               "letter"),
    "constraint": _CLAIM[1:_CLAIM.index("from_item")] + ("item", "marked", "mark_id", "mark_ids",
                                  "violated", "status"),
}
DENY = re.compile(u"answer|solution|solve|hint|hash|md5|sha|key|code|"
                  u"source|path|file|built|generat|time|date|strict|report|"
                  u"secret|token|python|script|fam|תשוב|פתר|רמז|מפתח",
                  re.I)
BAD_VALUE = re.compile(r"/private/|/Users/|/tmp/|/home/|/var/|/Volumes/|"
                       r"source/|file://|\.(?:py|pyc|ipynb|sh|skill)\b|"
                       r"(?:^|[\s(\[\"'=:,])(?:~|\.{1,2})?/(?:[\w.-]+/)+|"
                       r"(?:^|[\s(\[\"'=:,])~/|[A-Za-z]:\\")
# a run of 32+ hex digits with at least one letter a-f (an md5, a sha1, a
# sha256); a long run of decimal digits alone is a number, not a hash
HEX = re.compile(r"(?<![0-9a-fA-F])(?=[0-9a-fA-F]*[a-fA-F])"
                 r"[0-9a-fA-F]{32,}(?![0-9a-fA-F])")
STAMP = re.compile(r"\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}")
MARK_KINDS = ("right_angle", "ticks", "parallel", "arc", "mark")

# what each claim field names (the contract's constraint types)
FIELD = {
    ("collinear", "points"): "points",
    ("midpoint", "point"): "point", ("midpoint", "of"): "points",
    ("on_segment", "point"): "point", ("on_segment", "of"): "points",
    ("parallel", "of"): "segments",
    ("perpendicular", "of"): "segments", ("perpendicular", "at"): "point",
    ("equal_length", "of"): "segments",
    ("equal_angle", "of"): "angles",
    ("length", "of"): "segment",
    ("angle", "at"): "point", ("angle", "rays"): "points",
    ("ratio", "of"): "segments",
    ("tangent", "circle"): "circle", ("tangent", "to"): "segment",
    ("tangent", "at"): "point",
    ("concentric", "of"): "circles",
    ("hidden_edge", "of"): "segment",
    # v6.14 (F3): a printed scale names the axes it scales (axis-x / axis-y)
    ("scale", "of"): "segments",
}


# ------------------------------------------------------------ the SVG ------
def _mul(m, n):
    a, b, c, d, e, f = m
    A, B, C, D, E, F = n
    return (a * A + c * B, b * A + d * B, a * C + c * D, b * C + d * D,
            a * E + c * F + e, b * E + d * F + f)


def _tf(s):
    m = (1.0, 0.0, 0.0, 1.0, 0.0, 0.0)
    for name, args in re.findall(r"(\w+)\s*\(([^)]*)\)", s or ""):
        v = [float(x) for x in NUM.findall(args)]
        if name == "translate" and v:
            t = (1, 0, 0, 1, v[0], v[1] if len(v) > 1 else 0)
        elif name == "scale" and v:
            t = (v[0], 0, 0, v[1] if len(v) > 1 else v[0], 0, 0)
        elif name == "matrix" and len(v) == 6:
            t = tuple(v)
        elif name == "rotate" and v:
            r = math.radians(v[0])
            t = (math.cos(r), math.sin(r), -math.sin(r), math.cos(r), 0, 0)
            if len(v) == 3:
                t = _mul(_mul((1, 0, 0, 1, v[1], v[2]), t),
                         (1, 0, 0, 1, -v[1], -v[2]))
        else:
            continue
        m = _mul(m, t)
    return m


def _ap(m, p):
    return (m[0] * p[0] + m[2] * p[1] + m[4],
            m[1] * p[0] + m[3] * p[1] + m[5])


def _path(d):
    """[[points of one subpath], ...], closed flags: M/L/H/V/C/S/Q/T/A/Z,
    absolute and relative (the end point of every command)."""
    subs, closed, cur, start = [], [], (0.0, 0.0), (0.0, 0.0)
    toks = re.findall(r"[MLHVZCSQTAmlhvzcsqta]|" + NUM.pattern, d or "")
    cmd, i = None, 0
    n_of = {"M": 2, "L": 2, "T": 2, "H": 1, "V": 1, "C": 6, "S": 4, "Q": 4,
            "A": 7}
    while i < len(toks):
        t = toks[i]
        if re.match(r"[A-Za-z]$", t):
            cmd = t
            i += 1
            if cmd in "Zz":
                if subs:
                    closed[-1] = True
                cur = start
            continue
        if cmd is None:
            break
        n = n_of[cmd.upper()]
        v = [float(x) for x in toks[i:i + n]]
        i += n
        if len(v) < n:
            break
        rel = cmd.islower()
        if cmd.upper() == "H":
            cur = (v[0] + (cur[0] if rel else 0.0), cur[1])
        elif cmd.upper() == "V":
            cur = (cur[0], v[0] + (cur[1] if rel else 0.0))
        else:
            x, y = v[-2], v[-1]
            cur = (x + cur[0], y + cur[1]) if rel else (x, y)
        if cmd.upper() == "M":
            subs.append([cur])
            closed.append(False)
            start = cur
            cmd = "l" if rel else "L"      # implicit lineto after moveto
        else:
            if not subs:
                subs.append([start])
                closed.append(False)
            subs[-1].append(cur)
    return subs, closed


class Svg(object):
    """Every id of one SVG file, with the geometry its element draws."""

    def __init__(self, path):
        self.root = ET.parse(path).getroot()
        self.count = {}
        self.el = {}
        self.hidden = set()
        self._walk(self.root, (1.0, 0.0, 0.0, 1.0, 0.0, 0.0), False)

    @staticmethod
    def _hides(el):
        """True when this element itself is not printed: display none,
        visibility hidden/collapse, or opacity 0 (attribute or style)."""
        st = {}
        for part in (el.get("style") or "").split(";"):
            if ":" in part:
                k, v = part.split(":", 1)
                st[k.strip().lower()] = v.strip().lower()
        get = lambda k: (st.get(k) if k in st else
                         (el.get(k) or "").strip().lower())
        if get("display") == "none":
            return True
        if get("visibility") in ("hidden", "collapse"):
            return True
        op = get("opacity")
        if op:
            try:
                return float(op.rstrip("%")) <= 0.0
            except ValueError:
                return False
        return False

    def _walk(self, el, m, hid):
        m = _mul(m, _tf(el.get("transform")))
        hid = hid or self._hides(el)
        i = el.get("id")
        if i:
            self.count[i] = self.count.get(i, 0) + 1
            self.el[i] = (el, m)
            if hid:
                self.hidden.add(i)
        for ch in el:
            self._walk(ch, m, hid)

    def geometry(self, i):
        """(vertices, segments, circles, text anchors, closed shapes) of the
        element and its children, in SVG coordinates."""
        el, m = self.el[i]
        V, S, C, T, Z = [], [], [], [], []

        def walk(e, mm, top):
            if not top:
                mm = _mul(mm, _tf(e.get("transform")))
            t = e.tag.replace(NS, "")
            if t in ("defs", "clipPath", "mask", "title", "desc"):
                return
            g = lambda k: float(NUM.findall(e.get(k) or "0")[0]
                                if NUM.findall(e.get(k) or "0") else 0.0)
            if t == "circle" or t == "ellipse":
                c = _ap(mm, (g("cx"), g("cy")))
                r = (g("r") or g("rx")) * math.hypot(mm[0], mm[1])
                C.append((c, r))
            elif t == "line":
                a = _ap(mm, (g("x1"), g("y1")))
                b = _ap(mm, (g("x2"), g("y2")))
                V.extend([a, b])
                S.append((a, b))
            elif t in ("polygon", "polyline"):
                v = [float(x) for x in NUM.findall(e.get("points") or "")]
                P = [_ap(mm, q) for q in zip(v[0::2], v[1::2])]
                V.extend(P)
                S.extend(zip(P, P[1:]))
                if t == "polygon" and len(P) > 2:
                    S.append((P[-1], P[0]))
                    Z.append(P)
            elif t == "path":
                subs, closed = _path(e.get("d"))
                for sp, cl in zip(subs, closed):
                    P = [_ap(mm, q) for q in sp]
                    V.extend(P)
                    S.extend(zip(P, P[1:]))
                    if cl and len(P) > 2:
                        S.append((P[-1], P[0]))
                        Z.append(P)
            elif t == "rect":
                x, y, w, h = g("x"), g("y"), g("width"), g("height")
                P = [_ap(mm, q) for q in ((x, y), (x + w, y), (x + w, y + h),
                                          (x, y + h))]
                V.extend(P)
                S.extend(zip(P, P[1:] + P[:1]))
                Z.append(P)
            elif t == "text":
                T.append(_ap(mm, (g("x"), g("y"))))
                return
            for ch in e:
                walk(ch, mm, False)
        walk(el, m, True)
        return V, S, C, T, Z


def _segd(p, a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    L = dx * dx + dy * dy
    t = 0.0 if L == 0 else max(0.0, min(1.0, ((p[0] - a[0]) * dx +
                                              (p[1] - a[1]) * dy) / L))
    return math.hypot(p[0] - a[0] - t * dx, p[1] - a[1] - t * dy)


def _inside(p, P):
    x, y, inside = p[0], p[1], False
    for (x1, y1), (x2, y2) in zip(P, P[1:] + P[:1]):
        if (y1 > y) != (y2 > y) and \
                x < (x2 - x1) * (y - y1) / ((y2 - y1) or 1e-12) + x1:
            inside = not inside
    return inside


def _on(p, geo, tol=TOL):
    V, S, C, T, Z = geo
    return (any(math.hypot(p[0] - q[0], p[1] - q[1]) <= tol for q in V) or
            any(_segd(p, a, b) <= tol for a, b in S) or
            # a dot stands for its centre; a drawn circle for its centre
            # or its rim
            any(math.hypot(p[0] - c[0], p[1] - c[1]) <= tol or
                (r > 4.5 and abs(math.hypot(p[0] - c[0], p[1] - c[1]) - r)
                 <= tol) for c, r in C) or
            any(math.hypot(p[0] - q[0], p[1] - q[1]) <= tol for q in T) or
            # a marker drawn as a closed shape (a triangle, a square) stands
            # for the point inside it
            any(_inside(p, P) for P in Z))


def _ink_on(p, geo, tol=TOL):
    """ink only: strokes, dots and circles (not a circle's centre)."""
    V, S, C, T, Z = geo
    return (any(_segd(p, a, b) <= tol for a, b in S) or
            any(abs(math.hypot(p[0] - c[0], p[1] - c[1]) - r) <= tol or
                (r <= 4.5 and math.hypot(p[0] - c[0], p[1] - c[1]) <= r + tol)
                for c, r in C))


def _pts(v):
    if not isinstance(v, list) or not v:
        return []
    if all(isinstance(c, (int, float)) for c in v) and len(v) == 2:
        return [(float(v[0]), float(v[1]))]
    out = []
    for q in v:
        if isinstance(q, list) and len(q) == 2 and \
                all(isinstance(c, (int, float)) for c in q):
            out.append((float(q[0]), float(q[1])))
    return out


# ------------------------------------------------------------ the rules ----
def _walk(o, path=""):
    if isinstance(o, dict):
        for k, v in o.items():
            yield "key", path + "." + str(k), k
            for x in _walk(v, path + "." + str(k)):
                yield x
    elif isinstance(o, list):
        for j, v in enumerate(o):
            for x in _walk(v, "%s[%d]" % (path, j)):
                yield x
    elif isinstance(o, str):
        yield "str", path, o


def _names(fig_list):
    """Point, segment and circle names/ids of a question's figures."""
    P, S, C = set(), set(), set()
    for F in fig_list:
        ob = F.get("objects") or {}
        for o in (ob.get("points") or []):
            for k in ("name", "svg_id", "letter"):
                if o.get(k):
                    P.add(str(o[k]))
        for b in ("segments", "lines", "rays", "polygons"):
            for o in (ob.get(b) or []):
                for k in ("name", "svg_id"):
                    if o.get(k):
                        S.add(str(o[k]))
        for o in (ob.get("circles") or []):
            for k in ("name", "svg_id"):
                if o.get(k):
                    C.add(str(o[k]))
        # v6.14 (F2): an engine plane's axes are visual_model objects
        # (type axis, name x / y), not recorded segments; a claim names
        # them as the builder does: axis-x / axis-y
        for o in (F.get("visual_model") or {}).get("objects") or []:
            if isinstance(o, dict) and o.get("type") == "axis" and \
                    str(o.get("name")) in ("x", "y"):
                S.add("axis-" + str(o["name"]))
            # (v6.16 integrate) a pie chart's sector is named by its printed
            # label ('A'): a claim may name it as it names a point
            if isinstance(o, dict) and o.get("type") == "sector" and \
                    isinstance(o.get("name"), str) and o.get("parts"):
                P.add(o["name"])
            # (v6.16 fix r1, D3/S4/M2) a GRAPH figure's drawn curve or mark
            # is named by its printed label ('M', 'G', 'A', 'P'): a find
            # line "the slope of the line M" names that curve, not a point
            # no figure defines (curve:M / mark:P, type curve / mark, with
            # parts = its stroke / dot and its label)
            if isinstance(o, dict) and o.get("type") in ("curve", "mark") \
                    and isinstance(o.get("name"), str) and o.get("name") \
                    and o.get("parts") and (F.get("visual_model") or {}).get(
                        "kind") == "function_graph":
                P.add(o["name"])
    return P, S, C


def _split(s, P):
    """A run of point names ('AMB', "A'B") split on the names the figures
    define, longest first; None when it does not split."""
    s = s.replace("$", "").replace(" ", "")
    names = sorted((n for n in P if not n.startswith("pt-")), key=len,
                   reverse=True)
    out, i = [], 0
    while i < len(s):
        for n in names:
            if s.startswith(n, i):
                out.append(n)
                i += len(n)
                break
        else:
            return None
    return out


def _check_operand(kind, v, P, S, C):
    """Names in one operand that are not defined, [] when all are."""
    if kind in ("points", "segments", "angles", "circles"):
        one = kind[:-1]
        out = []
        for x in (v if isinstance(v, list) else [v]):
            out += _check_operand(one, x, P, S, C)
        return out
    if kind == "point":
        return [] if str(v) in P else [str(v)]
    if kind == "segment":
        if isinstance(v, list):
            return [str(x) for x in v if str(x) not in P]
        v = str(v)
        if v in S or (len(v) >= 2 and v[::-1] in S):
            return []
        sp = _split(v, P)
        return [] if sp is not None and len(sp) == 2 else [v]
    if kind == "angle":
        if isinstance(v, dict):
            names = [v.get("at")] + list(v.get("rays") or [])
            return [str(x) for x in names if str(x) not in P]
        sp = _split(str(v).replace(u"∠", ""), P)
        return [] if sp is not None and len(sp) in (1, 3) else [str(v)]
    if kind == "circle":
        return [] if (str(v) in C or str(v) in P) else [str(v)]
    return []


def _schema(nj):
    """K2: every key at every depth is one the public schema names in that
    place; a claim is a dict; no dict hides inside a leaf value."""
    errs = []

    def bad(where, k):
        why = "forbidden" if DENY.search(str(k)) else "not in the public"
        errs.append("K2 key %r at %s is %s schema" % (
            k, where, why + (" by the" if why == "forbidden" else "")))

    def leaf(v, where, ctx=None):
        if isinstance(v, dict):
            if ctx:
                node(v, where, ctx)
            else:
                errs.append("K2 a dict inside a value at %s" % where)
        elif isinstance(v, list):
            for j, x in enumerate(v):
                leaf(x, "%s[%d]" % (where, j), ctx)

    def node(o, where, ctx):
        if not isinstance(o, dict):
            errs.append("K2 %s must be an object (%s), got %s"
                        % (where, ctx, type(o).__name__))
            return
        for k, v in o.items():
            w = where + "." + str(k)
            if k not in SCHEMA[ctx]:
                bad(w, k)
                continue
            sub = CHILD.get((ctx, k))
            if sub == "list":
                continue
            if sub:
                lst = v if isinstance(v, list) else None
                if (ctx, k) == ("top", "visuals"):
                    if lst is None:
                        errs.append("K2 %s must be a list" % w)
                        continue
                    for j, x in enumerate(lst):
                        node(x, "%s[%d]" % (w, j), "visual_model")
                    continue
                if sub in LISTED:
                    if lst is None:
                        errs.append("K2 %s must be a list" % w)
                        continue
                    for j, x in enumerate(lst):
                        node(x, "%s[%d]" % (w, j), sub)
                elif sub == "objects":
                    node(v, w, "objects")
                else:
                    node(v, w, sub)
            elif ctx == "objects":
                if not isinstance(v, list):
                    errs.append("K2 %s must be a list" % w)
                    continue
                for j, x in enumerate(v):
                    node(x, "%s[%d]" % (w, j), "object")
            else:
                leaf(v, w, "operand" if ctx in ("claim", "constraint",
                                                "vm_relation")
                     else None)
    node(nj, "", "top")
    return errs


CHILD = {("top", "questions"): "question", ("top", "figures"): "figure",
         ("question", "items"): "item", ("question", "given"): "claim",
         ("question", "to_prove"): "claim", ("item", "given"): "claim",
         ("item", "to_prove"): "claim", ("question", "table"): "table",
         ("question", "example"): "example", ("figure", "view"): "view",
         ("figure", "objects"): "objects",
         ("figure", "constraints"): "constraint",
         ("view", "rows"): "view_row",
         ("question", "to_construct"): "claim",
         ("item", "to_construct"): "claim",
         ("top", "curriculum"): "curriculum",
         ("curriculum", "allowed_tools"): "tool",
         ("curriculum", "not_yet_allowed"): "tool",
         ("figure", "visual_model"): "visual_model",
         ("top", "visuals"): "visual_model",
         ("visual_model", "view"): "vm_view",
         ("visual_model", "data"): "vm_data",
         ("visual_model", "objects"): "vm_object",
         ("visual_model", "relations"): "vm_relation",
         ("visual_model", "aux"): "vm_aux",
         ("visual_model", "actions"): "vm_actions",
         ("vm_aux", "ops"): "vm_op",
         ("vm_op", "objects"): "vm_object",
         ("vm_op", "relations"): "vm_relation",
         ("vm_object", "parts"): "vm_part",
         ("question", "spec_unsupported"): "spec_gap"}
LISTED = ("question", "figure", "item", "claim", "constraint", "view_row",
          "tool", "vm_object", "vm_relation", "vm_aux", "vm_op", "vm_part")
HINT_MODES = ("guiding_question", "concept", "approved_hint")
# K11: what only the private didactic.json may carry
DIDACTIC_KEYS = ("hint_type", "exposure", "requires_human_review",
                 "forbidden_to_show", "aux_allowed", "approved",
                 "approved_by", "review_reasons", "didactic")


_TOK = re.compile(u"(?:[A-Z][0-9]*[\'\u2032]*)+")


def _text_names(s):
    """Point-name runs in a claim's printed text ('AB ⊥ CD', '$AM = MB$',
    '△XYZ ≅ △ABC'); LaTeX commands and \\text{} are dropped."""
    s = re.sub(r"\\text\{[^}]*\}", " ", s or "")
    s = re.sub(r"\\[A-Za-z]+", " ", s)
    s = re.sub(r"[A-Za-z](?=_)", " ", s)
    return _TOK.findall(s)


def _pub_fact_ids(d):
    """the fact ids of a level folder's wspec/public_spec.json (empty set
    when it has none)"""
    try:
        with open(os.path.join(d, "wspec", "public_spec.json"),
                  encoding="utf-8") as fh:
            pub = json.load(fh)
    except (OSError, ValueError):
        return set()
    return set(f.get("id") for f in pub.get("facts") or []
               if isinstance(f, dict))


def _undefined_names(v, P, S, C):
    """Names in a free value (a string or a nested list of strings) that the
    figures do not define."""
    out = []
    if isinstance(v, list):
        for x in v:
            out += _undefined_names(x, P, S, C)
        return out
    if isinstance(v, dict):
        return _check_operand("angle", v, P, S, C)
    if not isinstance(v, str):
        return out
    if v in P or v in S or v in C:
        return out
    toks = _text_names(v)
    if not toks:
        return [] if re.match(r"^[\d\s.,+\-/]*$", v) else [v]
    for t in toks:
        if t in P or t in S or t in C or \
                (t[::-1] in S) or _split(t, P) is not None:
            continue
        out.append(t)
    return out


def check_level(d):
    """[error strings] for one level folder."""
    errs = []
    p = os.path.join(d, "noam-ai.json")
    if not os.path.isfile(p):
        return ["K1 noam-ai.json missing in %s" % d], None
    try:
        with open(p, encoding="utf-8") as fh:
            nj = json.load(fh)
    except ValueError as e:
        return ["K1 noam-ai.json is not JSON (%s)" % e], None
    # K2: the key whitelist; K3: forbidden values, at any depth
    errs += _schema(nj)
    for what, where, v in _walk(nj):
        if what == "str":
            if BAD_VALUE.search(v):
                errs.append("K3 a path / code value at %s: %r"
                            % (where, v[:60]))
            if HEX.search(v):
                errs.append("K3 a hash value at %s: %r" % (where, v[:70]))
            if STAMP.search(v):
                errs.append("K3 a timestamp value at %s: %r"
                            % (where, v[:60]))
    if not isinstance(nj, dict):
        return errs, None
    # K10: the package's own shape
    if not (isinstance(nj.get("package"), str) and
            PACKAGE_RE.match(nj["package"])):
        errs.append("K10 package %r is not G<grade>-T<nn>"
                    % (nj.get("package"),))
    if nj.get("level") not in LEVELS:
        errs.append("K10 level %r is not a, b or c" % (nj.get("level"),))
    figs = {}
    for F in nj.get("figures") or []:
        figs[F.get("id")] = F
    # K4 / K5 / K7 / K8: every figure against its SVG
    for fid, F in figs.items():
        rel = F.get("svg")
        sp = os.path.join(d, rel) if isinstance(rel, str) else None
        if not sp or not os.path.isfile(sp):
            errs.append("K4 %s: SVG %r missing" % (fid, rel))
            continue
        try:
            svg = Svg(sp)
        except ET.ParseError as e:
            errs.append("K4 %s: SVG %s does not parse (%s)" % (fid, rel, e))
            continue
        M = (F.get("view") or {}).get("data_to_svg")
        for b, lst in (F.get("objects") or {}).items():
            for o in lst or []:
                sid = o.get("svg_id")
                n = svg.count.get(sid, 0)
                if not sid or n != 1:
                    errs.append("K5 %s: svg_id %s occurs %d times in %s"
                                % (fid, sid, n, rel))
                    continue
                if sid in svg.hidden:
                    errs.append("K5 %s: svg_id %s is hidden in %s (not "
                                "printed: display/visibility/opacity)"
                                % (fid, sid, rel))
                    continue
                geo = svg.geometry(sid)
                claim = _pts(o.get("svg_xy"))
                if not claim:
                    errs.append("K7 %s: %s has no svg_xy (its position "
                                "cannot be checked)" % (fid, sid))
                    continue
                bad = [q for q in claim if not _on(q, geo)]
                kind = o.get("kind")
                if kind in MARK_KINDS or o.get("role") == "mark" and \
                        b == "marks":
                    ink = _pts(o.get("ink_xy"))
                    if bad and not ink:
                        errs.append("K7 %s: mark %s has svg_xy %s off its "
                                    "ink and no ink_xy" % (fid, sid, bad[0]))
                    elif ink and not all(_ink_on(q, geo) for q in ink):
                        errs.append("K7 %s: mark %s ink_xy %s is not on its "
                                    "ink" % (fid, sid, ink[0]))
                elif bad:
                    errs.append("K7 %s: %s svg_xy (%.2f, %.2f) is more than "
                                "%g px from its element" %
                                (fid, sid, bad[0][0], bad[0][1], TOL))
                if M and len(M) == 6:
                    xy = _pts(o.get("xy"))
                    if b == "points" and not xy and not o.get("xyz"):
                        errs.append("K8 %s: point %s has no xy" % (fid, sid))
                    if xy and claim and len(xy) == len(claim):
                        for a, q in zip(xy, claim):
                            r = (M[0] * a[0] + M[2] * a[1] + M[4],
                                 M[1] * a[0] + M[3] * a[1] + M[5])
                            if math.hypot(r[0] - q[0], r[1] - q[1]) > TOL:
                                errs.append(
                                    "K8 %s: %s xy %s maps to (%.2f, %.2f), "
                                    "svg_xy is (%.2f, %.2f)" % (
                                        fid, sid, list(a), r[0], r[1],
                                        q[0], q[1]))
                                break
    # K24 (v6.12 fix_r1): a read-off question's family figure is public in
    # svg pixels only -- never its data frame
    _ro = set()
    for q in nj.get("questions") or []:
        for row in [q] + list(q.get("items") or []):
            cl = list(row.get("given") or []) + list(row.get("to_prove")
                                                      or [])
            if row.get("no_target_reason") or any(
                    isinstance(c, dict) and c.get("type") == "find"
                    for c in cl):
                _ro.add(q.get("id"))
    for fid, F in figs.items():
        vm = F.get("visual_model") if isinstance(F.get("visual_model"),
                                                 dict) else {}
        if F.get("question") not in _ro or vm.get("kind") not in (
                "coordinate_plane", "number_line"):
            continue
        leak = [k for k in ("data_to_svg", "data_unit_px", "step")
                if k in (F.get("view") or {}) or k in (vm.get("view") or {})]
        leak += ["row data_to_svg" for r in (F.get("view") or {}).get(
            "rows") or [] if isinstance(r, dict) and "data_to_svg" in r][:1]
        objs = [o for lst in (F.get("objects") or {}).values()
                for o in lst or []] + list(vm.get("objects") or [])
        for o in objs:
            ks = [k for k in ("xy", "xyz", "measures_xy", "value")
                  if isinstance(o, dict) and k in o]
            if ks:
                leak.append("%s %s" % (o.get("svg_id") or o.get("id"),
                                       "/".join(ks)))
        if leak:
            errs.append("K24 %s: question %s asks to find something, and "
                        "its %s figure carries its data frame (%s)"
                        % (fid, F.get("question"), vm.get("kind"),
                           ", ".join(leak[:4])))
    # K9 / K10 / K6: questions and items
    for q in nj.get("questions") or []:
        qid = q.get("id")
        mine = [F for F in figs.values() if F.get("question") == qid]
        P, S, C = _names(mine)
        # v6.13-noam (integration): a point the question's to_construct
        # makes (a point to plot / construct -- "סימון E") is not drawn
        # yet; a given / to_prove may name it (its coordinates are data).
        # A name nothing draws AND nothing constructs is still K6.
        made = set()
        for r2 in [q] + list(q.get("items") or []):
            for g in r2.get("to_construct") or []:
                if isinstance(g, dict):
                    made.update(_tk([g.get(x) for x in (
                        "point", "points", "of", "at")]))
                    made.update(_text_names(g.get("text") or ""))
                elif isinstance(g, str):
                    made.update(_text_names(g))
        made -= P
        for row in [q] + list(q.get("items") or []):
            rid = row.get("id")
            if "figure_id" not in row:
                errs.append("K10 %s has no figure_id" % rid)
            elif row["figure_id"] is not None and \
                    row["figure_id"] not in figs:
                errs.append("K9 %s: figure_id %s is not a figure of the "
                            "package" % (rid, row["figure_id"]))
            for key in ("given", "to_prove"):
                lst = row.get(key)
                if not isinstance(lst, list):
                    errs.append("K10 %s has no %s list" % (rid, key))
                    continue
                for c in lst:
                    if not isinstance(c, dict):
                        # K2 already refuses the shape; K6 still reads it
                        c = {"text": c if isinstance(c, str) else ""}
                    if c.get("type") == "find" and any(
                            k in c for k in ("value", "answer")):
                        # v6.7.2-noam: the value of a find target is the
                        # answer -- sheet.json only
                        errs.append("K15 %s %s: the find target %r carries "
                                    "its value" % (rid, key, c.get("text")))
                    if c.get("type") == "find":
                        # r1 T2/T4: its public words print no number the
                        # item's text does not; a unit is a word; a table
                        # cell it asks for shows no number
                        for e in _find_leaks(c, q, row, nj) + \
                                _find_obj_leaks(c, q, row, nj):
                            errs.append("K15 %s %s: %s" % (rid, key, e))
                    if c.get("type") == "find":
                        # v6.7.2-noam: a find target names points of the
                        # figures or points its question's given /
                        # to_construct names (a vertex still to be found);
                        # a variable / cell / model id is D12's to check
                        decl = set()
                        for r2 in [q] + list(q.get("items") or []):
                            for k2 in ("given", "to_construct"):
                                for g in r2.get(k2) or []:
                                    if isinstance(g, dict):
                                        decl.update(_tk([g.get(x) for x in (
                                            "of", "points", "point", "at",
                                            "rays")]))
                        miss = sorted(set(
                            t for f in ("of", "at", "rays")
                            for t in _tk(c.get(f)) if t not in P and
                            t not in decl))
                        if miss:
                            errs.append("K6 %s %s: the find target names %s, "
                                        "which no figure of %s defines"
                                        % (rid, key, ", ".join(miss), qid))
                        continue
                    miss = []
                    for f, v in c.items():
                        kind = FIELD.get((c.get("type"), f))
                        if kind is not None:
                            miss += _check_operand(kind, v, P, S, C)
                        elif f == "text":
                            miss += _undefined_names(
                                _text_names(v if isinstance(v, str)
                                            else ""), P, S, C)
                        elif f == "facts":
                            # v6.14 (F2 / F3): the public spec fact ids a
                            # printed given restates -- each one a fact of
                            # the package's wspec/public_spec.json
                            pf = _pub_fact_ids(d)
                            bad = [x for x in (v if isinstance(v, list)
                                               else [v])
                                   if not isinstance(x, str) or x not in pf]
                            if bad or not v:
                                errs.append("K6 %s %s links %s, not a fact "
                                            "of wspec/public_spec.json"
                                            % (rid, key, bad or "nothing"))
                        elif f not in ("type", "unit", "space", "t",
                                       "value", "from_item"):
                            miss += _undefined_names(v, P, S, C)
                    # (v6.16 fix r1, K1) a run of letters whose every
                    # point is drawn OR made by the question (a to_construct
                    # point: the G1 partial polygon's vertex to find, c q5
                    # ABCD with C, D to find) is defined
                    miss = sorted(set(m for m in miss if m not in made and
                                      _split(m, P | made) is None))
                    if miss:
                        errs.append("K6 %s %s names %s, which no figure "
                                    "of %s defines" % (
                                        rid, key, ", ".join(miss), qid))
    errs += _didactic_rules(d, nj)
    return errs, nj


_KNUM = re.compile(u"(?<![\\w.])-?\\d+(?:[.,]\\d+)?(?!\\w|[.,]\\d)")


def _knums(s):
    out = set()
    for x in _KNUM.findall(str(s or "")):
        try:
            out.add("%g" % float(x.replace(",", ".")))
        except ValueError:
            out.add(x)
    return out


def _find_leaks(c, q, row, nj):
    """K15 (r1): what of a find target's value its public side can show."""
    out = []
    if re.search(r"\d", str(c.get("unit") or "")):
        out.append("the find target's unit %r carries a number"
                   % c.get("unit"))
    ctx = _knums(" ".join(str(x) for x in (q.get("text"), q.get("intro"),
                                           row.get("text")) if x))
    for k in ("text", "what"):
        ex = _knums(c.get(k)) - ctx
        if ex:
            out.append("the find target's %s %r prints %s, which the item's "
                       "text does not" % (k, c.get(k), sorted(ex)))
    if c.get("quantity") == "cell":
        of = c.get("of")
        want = [str(x) for x in (of if isinstance(of, list) else [of])]
        for v in nj.get("visuals") or []:
            if v.get("question") != q.get("id"):
                continue
            for o in v.get("objects") or []:
                oid = str(o.get("id"))
                if o.get("type") == "cell" and any(
                        oid == w or oid.endswith("-" + w) for w in want) \
                        and re.search(r"\d", str(o.get("value") or "")):
                    out.append("the table shows %r in %s, the cell the item "
                               "asks to find" % (o.get("value"), oid))
    return out


_KGEOM = frozenset(("xy", "xyz", "svg_xy", "ink_box", "bbox", "view",
                    "viewbox", "data_to_svg", "data_unit_px", "rotate", "row",
                    "col", "r", "n", "width_px", "height_px", "unit_px",
                    "frame", "id", "svg_id", "svg"))
_KDATA = ("bar_chart", "pie_chart", "line_chart", "table", "function_graph",
          "number_line")


def _kleaves(o, path=""):
    if isinstance(o, dict):
        for k, v in o.items():
            if k in _KGEOM:
                continue
            if isinstance(v, (dict, list)):
                for x in _kleaves(v, "%s.%s" % (path, k)):
                    yield x
            elif v is not None and not isinstance(v, bool):
                yield "%s.%s" % (path, k), k, v
    elif isinstance(o, list):
        for i, v in enumerate(o):
            for x in _kleaves(v, "%s[%d]" % (path, i)) if isinstance(
                    v, (dict, list)) else ([("%s[%d]" % (path, i), "", v)]
                                           if v is not None else []):
                yield x


def _find_obj_leaks(c, q, row, nj):
    """K15 (r2 M1): the model objects of a find target's own find relation
    print no number the item's text does not print (value / label / text /
    frequency ... = the answer); exact geometry is the model."""
    out = []
    ctx = _knums(" ".join(str(x) for x in (q.get("text"), q.get("intro"),
                                           row.get("text")) if x))
    vms = [f.get("visual_model") for f in nj.get("figures") or []
           if isinstance(f.get("visual_model"), dict)] + \
        list(nj.get("visuals") or [])
    for vm in vms:
        if vm.get("question") != q.get("id"):
            continue
        ids = set()
        for r in vm.get("relations") or []:
            if r.get("type") == "find" and r.get("item", row.get("id")) == \
                    row.get("id") and r.get("quantity") == \
                    c.get("quantity") and r.get("of") == c.get("of"):
                ids.update(str(x) for x in r.get("objects") or [])
        for o in vm.get("objects") or []:
            if str(o.get("id")) not in ids:
                continue
            for p, k, v in _kleaves(o):
                if o.get("type") == "cell" and k == "value":
                    continue
                if vm.get("kind") in _KDATA and k in ("value", "angle") \
                        and isinstance(v, (int, float)):
                    continue
                ex = _knums(v) - ctx
                if ex:
                    out.append("the model object %s (%s) carries %s = %r on "
                               "the object the item asks to find"
                               % (o.get("id"), vm.get("id"), p.lstrip("."),
                                  v))
    return out


# -------------------------------------------- v6.7.1-noam: K11 K12 K13 -----
_PTN = re.compile(u"[A-Z][0-9]*[\u2032\u2033']*")


def _tk(v):
    if isinstance(v, (list, tuple)):
        return [x for y in v for x in _tk(y)]
    return _PTN.findall(str(v or ""))


def _seg(v):
    t = _tk(v)
    return "".join(sorted(t)) if len(t) == 2 else "|".join(t)


def _ang(v):
    if isinstance(v, dict):
        return (str(v.get("at")), tuple(sorted(map(str, v.get("rays") or []))))
    t = _tk(v)
    return (t[1], tuple(sorted((t[0], t[2])))) if len(t) == 3 else (str(v),)


def _key(c):
    """An independent canonical form of one claim (K13)."""
    if not isinstance(c, dict):
        return None
    t, of = c.get("type"), c.get("of")
    if t in ("equal_length", "parallel", "perpendicular", "concentric"):
        return (t, tuple(sorted(_seg(x) for x in of or [])))
    if t == "equal_angle":
        return (t, tuple(sorted(_ang(x) for x in of or [])))
    if t == "length":
        return (t, _seg(of), str(c.get("value")))
    if t == "angle":
        return (t, _ang({"at": c.get("at"), "rays": c.get("rays")}),
                str(c.get("value")))
    if t in ("midpoint", "on_segment"):
        return (t, str(c.get("point")), _seg(of))
    if t in ("segment", "line", "ray"):
        return ("segment", _seg(of))
    if t:
        return (t, json.dumps(dict((k, v) for k, v in sorted(c.items())
                                   if k not in ("text", "from_item")),
                              sort_keys=True))
    return ("text", re.sub(r"[\s$]+", "", str(c.get("text") or "")))


def _didactic_rules(d, nj):
    errs = []
    # K11: no didactic key at any depth
    for what, where, v in _walk(nj):
        if what == "key" and str(v) in DIDACTIC_KEYS:
            errs.append("K11 didactic key %r at %s -- didactic.json is "
                        "private" % (v, where))
        if what == "str" and v.strip() == "didactic/v1":
            errs.append("K11 the didactic/v1 record is inside noam-ai.json "
                        "at %s" % where)
    # K12: hints
    dj = None
    p = os.path.join(d, "didactic.json")
    if os.path.isfile(p):
        try:
            with open(p, encoding="utf-8") as fh:
                dj = json.load(fh)
        except ValueError:
            dj = None
    drows = (dj or {}).get("items") or {}
    if not isinstance(drows, dict):
        drows = {}
    rows = []
    for q in nj.get("questions") or []:
        rows.append(q)
        rows += list(q.get("items") or [])
    for r in rows:
        rid = r.get("id")
        mode = r.get("hint_mode")
        if mode is not None and mode not in HINT_MODES:
            errs.append("K12 %s hint_mode %r is not one of %s"
                        % (rid, mode, ", ".join(HINT_MODES)))
        has = "approved_hint" in r
        if has and mode != "approved_hint":
            errs.append("K12 %s carries approved_hint with hint_mode %r"
                        % (rid, mode))
        if mode == "approved_hint" and not has:
            errs.append("K12 %s hint_mode approved_hint names no text" % rid)
        if has:
            row = drows.get(rid)
            if not isinstance(row, dict) or row.get("approved") is not True \
                    or not str(row.get("approved_by") or "").strip() or \
                    row.get("hint") != r.get("approved_hint"):
                errs.append("K12 %s approved_hint is not a hint didactic.json "
                            "records as approved by a human (approved=True, "
                            "approved_by, the same text)" % rid)
    unapproved = [str(v.get("hint")) for v in drows.values()
                  if isinstance(v, dict) and v.get("hint") and
                  not (v.get("approved") is True and
                       str(v.get("approved_by") or "").strip())]
    for what, where, v in _walk(nj):
        if what == "str":
            for h in unapproved:
                if len(h) >= 6 and h in v:
                    errs.append("K12 a hint that is not approved appears at "
                                "%s: %r" % (where, h[:60]))
    # K13: the givens overlay (highlight_given, §4 + §9) comes from `given`
    # only
    for F in nj.get("figures") or []:
        vm = F.get("visual_model") if isinstance(F, dict) else None
        if not isinstance(vm, dict):
            continue
        rel = dict((r.get("id"), r) for r in vm.get("relations") or []
                   if isinstance(r, dict))
        # r1 m1: an id list holds ids -- a dict entry is named, not a crash
        hgl = vm.get("highlight_given") or []
        for i, x in enumerate(hgl if isinstance(hgl, list) else [hgl]):
            if not isinstance(x, str):
                errs.append("K13 %s: visual_model.highlight_given[%d] is a "
                            "%s (%s), not a relation id" % (
                                F.get("id"), i, type(x).__name__,
                                str(x)[:40]))
        gms = [rel.get(x) or {"id": x} for x in
               (hgl if isinstance(hgl, list) else [])
               if isinstance(x, str)]
        for o in vm.get("objects") or []:
            if isinstance(o, dict) and o.get("display") == "given_highlight":
                gms.append(rel.get(o.get("for")) or {"id": o.get("for")})
        if not gms:
            continue
        qid = F.get("question")
        qs = [q for q in nj.get("questions") or [] if q.get("id") == qid]
        rr = []
        for q in qs:
            rr.append(q)
            rr += [it for it in q.get("items") or []
                   if not F.get("item") or it.get("id") == F.get("item")]
        given, carried, goal = set(), set(), set()
        for r in rr:
            for c in r.get("given") or []:
                (carried if isinstance(c, dict) and c.get("from_item")
                 else given).add(_key(c))
            for k in ("to_prove", "to_construct"):
                for c in r.get(k) or []:
                    goal.add(_key(c))
        for gm in gms:
            claim = dict((k, v) for k, v in gm.items()
                         if k in _CLAIM and k != "from_item")
            k = _key(claim)
            if gm.get("from_given") and gm.get("role") == "given":
                # v6.10 (C3): stated by a typed-shape given -- that shape
                # must be a given of the question (K19 checks the
                # statement itself)
                src = rel.get(gm["from_given"]) or {}
                ks = _key(dict((a, b) for a, b in src.items()
                               if a in _CLAIM and a != "from_item"))
                if src.get("type") != "shape" or ks not in given:
                    errs.append("K13 %s highlight %s is derived from %s, "
                                "which is no given shape of %s"
                                % (F.get("id"), gm.get("id"),
                                   gm.get("from_given"), qid))
                continue
            if gm.get("role") != "given":
                errs.append("K13 %s highlights %s, a %s relation (the "
                            "givens overlay marks givens only)"
                            % (F.get("id"), gm.get("id"), gm.get("role")))
            elif k in goal:
                errs.append("K13 %s highlight %s marks a to_prove / "
                            "to_construct relation" % (F.get("id"), k))
            elif k in carried and k not in given:
                errs.append("K13 %s highlight %s is an earlier item's "
                            "result carried with from_item: the figure-level"
                            " overlay would mark it as a given while the "
                            "earlier item still has to prove it"
                            % (F.get("id"), k))
            elif k not in given:
                errs.append("K13 %s highlight %s is no given of %s"
                            % (F.get("id"), k, qid))
    errs += _vm_rules(nj)
    errs += _part_rules(d, nj)
    errs += _union_rules(d, nj)
    for _F in nj.get("figures") or []:
        _vm = _F.get("visual_model") if isinstance(_F, dict) else None
        if isinstance(_vm, dict):
            errs += ["K20 %s: %s" % (_F.get("id"), w)
                     for w in hg_unmarked(_vm)]
            # (v6.10 fix r2) K21: every markable given is offered;
            # K22: a numeric label names the object whose value it prints
            errs += ["K21 %s: %s" % (_F.get("id"), w)
                     for w in hg_missing(_F, _source_state_hg_context(d, _F, nj))]
            errs += ["K22 %s" % w for w in label_faults(_F)]
    # K23 (v6.10 fix r2, R1-s1-consistent): the public spec's texts are
    # the texts noam-ai.json carries (what the sheet prints)
    _pp = os.path.join(d, "wspec", "public_spec.json")
    if os.path.isfile(_pp):
        try:
            with open(_pp, encoding="utf-8") as fh:
                _pub = json.load(fh)
        except ValueError:
            _pub = None
            errs.append("K23 wspec/public_spec.json is not JSON")
        if _pub is not None:
            errs += ["K23 %s" % w for w in public_text_faults(
                _pub, (("noam-ai.json", nj),))]
    else:
        _pub = None
    # K25 (v6.14 fix_r1, W-META-LINES-3): an approved unprinted wording
    # restates one printed given / target of its row, linked to its fact
    errs += ["K25 %s" % w for w in meta_line_rules(nj, _pub)]
    errs += _map_rules(d, nj)
    # K19 (v6.10, Codex C3): a typed-shape given is offered by EXACTLY
    # what it states
    for F in nj.get("figures") or []:
        vm = F.get("visual_model") if isinstance(F, dict) else None
        if isinstance(vm, dict):
            for t in c3_faults(vm):
                errs.append("K19 %s: %s" % (F.get("id"), t))
    return errs


def _part_rules(d, nj):
    """K16 (v6.9): object id -> parts of an engine figure's model."""
    errs = []
    for F in nj.get("figures") or []:
        vm = F.get("visual_model") if isinstance(F, dict) else None
        if not isinstance(vm, dict):
            continue
        objs = [o for o in vm.get("objects") or [] if isinstance(o, dict)]
        if not any("parts" in o for o in objs):
            continue
        rel = F.get("svg")
        sp = os.path.join(d, rel) if isinstance(rel, str) else None
        try:
            svg = Svg(sp) if sp and os.path.isfile(sp) else None
        except ET.ParseError:
            svg = None
        if svg is None:
            errs.append("K16 %s: parts name svg ids of an SVG that is "
                        "missing" % F.get("id"))
            continue
        pts = set(_geometry_name(o) for o in objs
                  if o.get("type") == "point" and o.get("svg_id"))
        ids = {}
        for o in objs:
            ids[o.get("id")] = ids.get(o.get("id"), 0) + 1
        for o in objs:
            if "parts" not in o:
                continue
            oid = o.get("id")
            if ids.get(oid, 0) != 1:
                errs.append("K16 %s: object id %s names %d objects"
                            % (F.get("id"), oid, ids.get(oid, 0)))
            ps = o.get("parts")
            if not isinstance(ps, list) or (not ps and not o.get("svg_id")):
                errs.append("K16 %s: object %s has no parts to show"
                            % (F.get("id"), oid))
                continue
            for p in ps:
                sid = p.get("svg_id") if isinstance(p, dict) else None
                n = svg.count.get(sid, 0)
                if not sid or n != 1:
                    errs.append("K16 %s: object %s part %s occurs %d times "
                                "in %s" % (F.get("id"), oid, sid, n, rel))
                    continue
                if sid in svg.hidden:
                    errs.append("K16 %s: object %s part %s is hidden in %s"
                                % (F.get("id"), oid, sid, rel))
                sp_ = p.get("span")
                if sp_ is not None and not (
                        isinstance(sp_, list) and len(sp_) == 2 and
                        all(str(x) in pts for x in sp_)):
                    errs.append("K16 %s: object %s part %s spans %r, not two"
                                " drawn points" % (F.get("id"), oid, sid,
                                                   sp_))
    return errs


# ---- C1r2 (v6.10): what a highlight paints IS its object ------------------
# The same block is in tools/highlight.py, verify_export.py and
# selfcheck_noam_package.py (each file stays stdlib-only and independent;
# selfcheck_v610_gaps.py proves the three copies are identical).
_U_TOL = 1.0
_U_NAMES = re.compile(r"[A-Z][0-9]*'*")
_U_UNITS = re.compile(r"-?\d*\.?\d+(?:[eE][-+]?\d+)?")


def _u_d(p, a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    L = dx * dx + dy * dy
    t = 0 if L == 0 else max(0, min(1, ((p[0] - a[0]) * dx +
                                        (p[1] - a[1]) * dy) / L))
    return math.hypot(p[0] - a[0] - t * dx, p[1] - a[1] - t * dy)


def _u_ray(v, a, x, tol):
    """x lies on the ray from v through a (not at v)."""
    ux, uy = a[0] - v[0], a[1] - v[1]
    dx, dy = x[0] - v[0], x[1] - v[1]
    L = math.hypot(ux, uy)
    if L == 0 or math.hypot(dx, dy) <= tol:
        return False
    return (ux * dx + uy * dy) > 0 and abs(ux * dy - uy * dx) / L <= tol


def _u_cover(pieces, a, b, tol):
    """The part of segment a-b that the pieces (each lying on it) leave
    unpainted: [(t0, t1)] in px along a-b, gaps longer than tol."""
    L = math.hypot(b[0] - a[0], b[1] - a[1])
    if L <= tol:
        return []
    ux, uy = (b[0] - a[0]) / L, (b[1] - a[1]) / L
    iv = sorted(sorted(((p[0] - a[0]) * ux + (p[1] - a[1]) * uy,
                        (q[0] - a[0]) * ux + (q[1] - a[1]) * uy))
                for p, q in pieces)
    gaps, at = [], 0.0
    for s, e in iv:
        if s - at > tol:
            gaps.append((at, s))
        at = max(at, e)
    if L - at > tol:
        gaps.append((at, L))
    return gaps


def _u_mark_angle(s):
    """'arc ACB' / 'right AHB' / 'ang ACB' -> (vertex, {arm, arm})."""
    n = _U_NAMES.findall(str(s or "").split(" ", 1)[-1])
    return (n[1], frozenset((n[0], n[2]))) if len(n) == 3 else None


def _geometry_name(o):
    """Stable native references are separate from learner-facing names.

    An explicitly unnamed foot is a point with part=anchor and its native
    point ID. Native segment/angle IDs still identify their endpoints;
    all normal measured-ink/parts checks continue to run on those endpoints.
    """
    if o.get("name"):
        return str(o["name"])
    ty, oid = o.get("type"), str(o.get("id") or "")
    if ty == "point" and o.get("part") == "anchor" and re.fullmatch(r"[A-Z][0-9]*'*", oid):
        return oid
    prefix = {"segment": "seg:", "angle": "ang:"}.get(ty)
    if prefix and oid.startswith(prefix):
        tail = oid[len(prefix):]
        names = re.findall(r"[A-Z][0-9]*'*", tail)
        if "".join(names) == tail and len(names) == (2 if ty == "segment" else 3):
            return tail
    return ""


def _u_point(o, pts, elem, tol):
    """(v6.10 fix r1, m2) a POINT paints its own dot and its own letter
    only: a circle / point group at the point's place, a label whose
    data-for names it. A point object re-pointed at another point's dot is
    a fault."""
    nm = _geometry_name(o)
    if not nm:
        return []
    P = pts.get(nm)
    if P is None:
        return ["point %s is not a drawn point of the model" % nm]
    P = (float(P[0]), float(P[1]))
    parts = o.get("parts")
    if not (isinstance(parts, list) and parts):
        parts = [{"svg_id": o["svg_id"]}] if o.get("svg_id") else []
    out = []
    for pt in parts:
        sid = pt.get("svg_id") if isinstance(pt, dict) else None
        e = elem(sid) if sid else None
        if e is None:
            out.append("part %s is not one element of the SVG" % sid)
            continue
        tag, a, geom = e
        if tag == "circle":
            # an engine dot names its point (data-pt) and sits at it; a
            # bare circle (a builder's, maybe under a transform this reader
            # does not apply) is judged by its name hook only when it has
            # one
            if a.get("data-pt") is not None and (
                    a.get("data-pt") != nm or not geom or
                    abs(geom[0][0] - P[0]) > tol or
                    abs(geom[0][1] - P[1]) > tol):
                out.append("part %s is not the dot of %s" % (sid, nm))
        elif tag == "text":
            if a.get("data-for") != nm:
                out.append("part %s is not the letter of %s" % (sid, nm))
        elif tag == "g":
            xy = _U_UNITS.findall(a.get("data-xy") or "")
            if a.get("data-kind") != "point" or len(xy) != 2 or \
                    abs(float(xy[0]) - P[0]) > tol or \
                    abs(float(xy[1]) - P[1]) > tol:
                out.append("part %s is not the point %s" % (sid, nm))
        else:
            out.append("part %s (%s) is not a point's ink" % (sid, tag))
    return out


def union_faults(o, pts, elem, tol=_U_TOL):
    """C1r2: the geometric UNION of what highlighting object o paints --
    its parts after span limits (a part without span paints its whole
    element) -- equals the object: no ink outside it, no piece of it left
    unpainted.
      segment  exactly its two points' segment;
      angle    exactly its two arms (vertex -> each named point), plus a
               sector mark: an arc / right-angle mark of THIS angle among
               its parts, or room for the focus arc highlight draws;
               a caption part must be this angle's;
      polygon  exactly its sides, every side.
    A segment may also carry its own tick mark / length caption (the
    engine's data-mark "tick XY" / data-for "seg XY" naming it).
    o     a visual_model object (type, name, parts or svg_id, svg_xy)
    pts   {point name: (x, y)} -- the model's drawn points (svg px)
    elem  svg id -> None | (tag, attrs, [(x, y) ...]) in the same px:
          a line's two ends, a polyline's / polygon's vertices, a path's
          M/L points, a circle's centre, a text's anchor
    Returns [reason, ...]; [] when the highlight IS the object. Anything
    it cannot place is a fault (refuse, never guess)."""
    ty = o.get("type")
    if ty == "point":
        return _u_point(o, pts, elem, tol)
    if ty == "origin":                           # v6.16 gaps, corpus-v2 G2
        return _u_origin(o, elem)
    if ty == "polygon" and o.get("shown") is not None:     # v6.16 gaps, G1
        return _u_partial(o, pts, elem, tol)
    if ty not in ("segment", "angle", "polygon"):
        return []
    parts = o.get("parts")
    if not (isinstance(parts, list) and parts):
        parts = [{"svg_id": o["svg_id"]}] if o.get("svg_id") else []
    if not parts:
        return ["nothing is drawn to highlight"]
    nm = _geometry_name(o)
    names = _U_NAMES.findall(nm)
    P = dict((str(k), tuple(float(c) for c in v)) for k, v in pts.items())
    sx = o.get("svg_xy")
    if ty == "segment" and (not names or "".join(names) != nm) and \
            isinstance(sx, list) \
            and len(sx) == 2 and all(isinstance(p, list) for p in sx):
        # a stroke named by no points (a builder's data line, an axis) is
        # its two svg_xy ends; a name OF points must name drawn points
        names = ["#0", "#1"]
        P["#0"], P["#1"] = [(float(p[0]), float(p[1])) for p in sx]
    elif ty == "polygon" and (not names or "".join(names) != nm) and \
            isinstance(sx, list) and len(sx) >= 3 and \
            all(isinstance(p, list) and len(p) == 2 for p in sx):
        # v6.12 fix_r1 (M3): an UNNAMED data polygon (a bar of a chart)
        # is its svg_xy vertices, as an unnamed data stroke is its two ends
        names = ["#%d" % i for i in range(len(sx))]
        for i, p in enumerate(sx):
            P["#%d" % i] = (float(p[0]), float(p[1]))
    need = {"segment": 2, "angle": 3}.get(ty, 3)
    if len(names) < need or (ty != "polygon" and len(names) != need) or \
            any(n not in P for n in names):
        return ["its name %r does not place %d drawn point(s): the mapping "
                "is ambiguous" % (o.get("name"), need)]
    out, ink, marks = [], [], []
    for pt in parts:
        sid = pt.get("svg_id") if isinstance(pt, dict) else None
        e = elem(sid) if sid else None
        if e is None:
            out.append("part %s is not one element of the SVG" % sid)
            continue
        tag, a, geom = e
        dm = a.get("data-mark")
        span = pt.get("span")
        grp = tag == "g" and a.get("_edges") and not a.get("_other")
        if grp or (not dm and (tag in ("line", "polyline", "polygon") or
                               (tag == "path" and a.get("data-seg")))):
            edges = list(a["_edges"]) if grp else list(zip(geom, geom[1:]))
            if tag == "polygon" and len(geom) > 2:
                edges.append((geom[-1], geom[0]))
            if not edges:
                out.append("part %s draws no stroke" % sid)
                continue
            if span:
                sp = [str(x) for x in span] if isinstance(span, list) else []
                if len(sp) != 2 or sp[0] == sp[1] or \
                        any(x not in P for x in sp):
                    out.append("part %s: span %r is not two drawn points"
                               % (sid, span))
                    continue
                X, Y = P[sp[0]], P[sp[1]]
                if not any(_u_d(X, p, q) <= tol and _u_d(Y, p, q) <= tol
                           for p, q in edges):
                    out.append("part %s: span %s%s is not on that stroke"
                               % (sid, sp[0], sp[1]))
                    continue
                ink.append((X, Y, sid, "%s%s" % tuple(sp)))
            else:
                ink += [(p, q, sid, "whole") for p, q in edges]
        else:
            if span:
                out.append("part %s: a span on a %s (not a stroke)"
                           % (sid, tag))
            marks.append((sid, tag, a, geom))
    if ty == "segment":
        tg = [(names[0], names[1])]
    elif ty == "polygon":
        tg = list(zip(names, names[1:] + names[:1]))
    else:
        tg = [(names[1], names[0]), (names[1], names[2])]
    for p, q, sid, w in ink:
        if not any(_u_d(p, P[x], P[y]) <= tol and _u_d(q, P[x], P[y]) <= tol
                   for x, y in tg):
            out.append("extra ink: part %s (%s) paints (%.1f,%.1f)-(%.1f,%.1f)"
                       ", which is not %s" % (sid, w, p[0], p[1], q[0], q[1],
                                              {"segment": "the segment itself",
                                               "angle": "an arm of it"}.get(
                                                  ty, "a side of it")))
    for x, y in tg:
        on = [(p, q) for p, q, _s, _w in ink
              if _u_d(p, P[x], P[y]) <= tol and _u_d(q, P[x], P[y]) <= tol]
        gaps = _u_cover(on, P[x], P[y], tol)
        if gaps:
            out.append("missing: %s%s is not painted over %.1f of %.1f px"
                       % (x, y, sum(e - s for s, e in gaps),
                          math.hypot(P[y][0] - P[x][0],
                                     P[y][1] - P[x][1])))
    if ty != "angle":
        own = frozenset(names)
        for sid, tag, a, geom in marks:
            dm = str(a.get("data-mark") or "")
            df = str(a.get("data-for") or "")
            if ty == "segment" and tag == "text" and df.startswith("seg ") \
                    and frozenset(_U_NAMES.findall(df[4:])) == own:
                continue
            kd, _s, on = dm.partition(" ")
            if ty == "segment" and re.sub(r"\d+$", "", kd) in (
                    "tick", "par") and geom and \
                    frozenset(_U_NAMES.findall(on)) == own:
                # its own tick / parallel arrow: named for it, on it
                mid = (sum(p[0] for p in geom) / len(geom),
                       sum(p[1] for p in geom) / len(geom))
                if any(_u_d(q, P[names[0]], P[names[1]]) <= tol
                       for q in [mid] + list(geom)):
                    continue
            out.append("extra ink: part %s (a %s%s) is not a stroke or a "
                       "mark of it" % (sid, tag, " " + repr(dm or df)
                                       if dm or df else ""))
        return out
    V, A, B = P[names[1]], P[names[0]], P[names[2]]
    me = (names[1], frozenset((names[0], names[2])))
    sector = False
    for sid, tag, a, geom in marks:
        dm = a.get("data-mark") or ""
        if tag == "text":
            if _u_mark_angle(a.get("data-for")) != me:
                out.append("extra ink: caption %s belongs to %r, not this "
                           "angle" % (sid, a.get("data-for")))
            continue
        if _u_mark_angle(dm) != me:
            out.append("extra ink: part %s (%s %r) is no mark of this angle"
                       % (sid, tag, dm))
            continue
        kind = re.sub(r"\d+$", "", dm.split(" ", 1)[0])
        if kind == "arc" and len(geom) >= 2:
            r = [math.hypot(p[0] - V[0], p[1] - V[1]) for p in geom]
            onr = [p for p in geom if _u_ray(V, A, p, tol) or
                   _u_ray(V, B, p, tol)]
            if max(r) - min(r) > tol or min(r) <= tol or len(onr) < 2:
                out.append("part %s: its arc is not centred on %s from arm "
                           "to arm" % (sid, names[1]))
                continue
            sector = True
        elif kind == "right" and len(geom) == 3:
            e1, e3 = geom[0], geom[2]
            if not ((_u_ray(V, A, e1, tol) and _u_ray(V, B, e3, tol)) or
                    (_u_ray(V, B, e1, tol) and _u_ray(V, A, e3, tol))):
                out.append("part %s: its right-angle mark does not sit on "
                           "the arms at %s" % (sid, names[1]))
                continue
            sector = True
        else:
            out.append("part %s: a %s mark highlight cannot read" % (sid,
                                                                    kind))
    if not sector:
        la = math.hypot(A[0] - V[0], A[1] - V[1])
        lb = math.hypot(B[0] - V[0], B[1] - V[1])
        sw = math.degrees(abs((math.atan2(B[1] - V[1], B[0] - V[0]) -
                               math.atan2(A[1] - V[1], A[0] - V[0]) +
                               math.pi) % (2 * math.pi) - math.pi))
        if not (1.0 <= sw <= 179.0) or min(18.0, 0.45 * min(la, lb)) < 9.0:
            out.append("no sector: no arc / right-angle mark of it among its "
                       "parts and no room for a focus arc (%.1f deg)" % sw)
    return out


def _u_origin(o, elem):
    """(v6.16 gaps, corpus-v2 G2) the ORIGIN of a coordinate plane paints
    the two axis lines (they cross there) and the origin's printed '0' --
    both lines, the '0' when the figure prints one, nothing else."""
    parts = o.get("parts")
    if not (isinstance(parts, list) and parts):
        return ["nothing is drawn to highlight"]
    out, axes, zero = [], set(), False
    for pt in parts:
        sid = pt.get("svg_id") if isinstance(pt, dict) else None
        e = elem(sid) if sid else None
        if e is None:
            out.append("part %s is not one element of the SVG" % sid)
            continue
        tag, a, _geom = e
        if pt.get("span"):
            out.append("part %s: a span on the origin" % sid)
        elif tag == "line" and a.get("data-axis"):
            axes.add(a.get("data-axis"))
        elif tag == "text" and a.get("data-num") == "origin":
            zero = True
        else:
            out.append("extra ink: part %s (a %s) is not an axis line or the "
                       "origin's 0" % (sid, tag))
    if len(axes) != 2:
        out.append("the origin paints %d axis line(s), not the two that "
                   "cross there" % len(axes))
    allel = getattr(elem, "all", None) or {}
    if not zero and any(t == "text" and a.get("data-num") == "origin"
                        for hit in allel.values() for t, a in hit):
        out.append("missing: the origin's printed 0 is not painted")
    return out


def _u_partial(o, pts, elem, tol):
    """(v6.16 gaps, corpus-v2 G1) a PARTIAL polygon -- a polygon the figure
    shows only some vertices of ('shown'; the missing one is the answer) --
    paints exactly its shown part: the dots of its shown vertices, and each
    side between two consecutive shown vertices wholly when the figure draws
    it (a data segment / line / ray over it) -- nothing of a missing vertex,
    no ink off those sides."""
    nm = _geometry_name(o)
    names = _U_NAMES.findall(nm)
    shown = [str(x) for x in o.get("shown") or []] \
        if isinstance(o.get("shown"), list) else []
    P = dict((str(k), tuple(float(c) for c in v)) for k, v in pts.items())
    if "".join(names) != nm or len(names) < 3 or \
            len(set(names)) != len(names):
        return ["partial polygon %r: its name is not a polygon's" % nm]
    if not shown or len(set(shown)) >= len(names) or \
            any(x not in names for x in shown):
        return ["partial polygon %s: shown %r is not a proper part of its "
                "vertices" % (nm, shown)]
    if any(x not in P for x in shown):
        return ["partial polygon %s: a shown vertex is no drawn point" % nm]
    back = [x for x in names if x not in shown and x in P]
    if back:
        return ["partial polygon %s: its missing vertex %s is drawn"
                % (nm, ", ".join(back))]
    tg = [(x, y) for x, y in zip(names, names[1:] + names[:1])
          if x in shown and y in shown]
    parts = o.get("parts")
    if not (isinstance(parts, list) and parts):
        return ["nothing is drawn to highlight"]
    out, ink, dots = [], [], set()
    for pt in parts:
        sid = pt.get("svg_id") if isinstance(pt, dict) else None
        e = elem(sid) if sid else None
        if e is None:
            out.append("part %s is not one element of the SVG" % sid)
            continue
        tag, a, geom = e
        span = pt.get("span")
        if tag == "circle" and not span:
            n = str(a.get("data-pt") or "")
            if n in shown and geom and abs(geom[0][0] - P[n][0]) <= tol and \
                    abs(geom[0][1] - P[n][1]) <= tol:
                dots.add(n)
            else:
                out.append("extra ink: part %s is not the dot of a shown "
                           "vertex" % sid)
            continue
        if tag != "line" or a.get("data-mark") or len(geom) != 2:
            out.append("extra ink: part %s (a %s) is not a side or a dot of "
                       "it" % (sid, tag))
            continue
        if span:
            sp = [str(x) for x in span] if isinstance(span, list) else []
            if len(sp) != 2 or any(x not in P for x in sp) or \
                    not (_u_d(P[sp[0]], geom[0], geom[1]) <= tol and
                         _u_d(P[sp[1]], geom[0], geom[1]) <= tol):
                out.append("part %s: span %r is not two drawn points on "
                           "that stroke" % (sid, span))
                continue
            ink.append((P[sp[0]], P[sp[1]], sid))
        else:
            ink.append((geom[0], geom[1], sid))
    for p, q, sid in ink:
        if not any(_u_d(p, P[x], P[y]) <= tol and _u_d(q, P[x], P[y]) <= tol
                   for x, y in tg):
            out.append("extra ink: part %s paints (%.1f,%.1f)-(%.1f,%.1f), "
                       "which is no side between two shown vertices"
                       % (sid, p[0], p[1], q[0], q[1]))
    allel = getattr(elem, "all", None) or {}
    for x, y in tg:
        on = [(p, q) for p, q, _s in ink
              if _u_d(p, P[x], P[y]) <= tol and _u_d(q, P[x], P[y]) <= tol]
        drawn = any(t == "line" and (a.get("data-seg") or a.get("data-line")
                                     or a.get("data-ray")) and
                    _u_d(P[x], *_u_geom(t, a)) <= tol and
                    _u_d(P[y], *_u_geom(t, a)) <= tol
                    for hit in allel.values() for t, a in hit)
        if on or drawn:
            gaps = _u_cover(on, P[x], P[y], tol)
            if gaps:
                out.append("missing: %s%s is not painted over %.1f px"
                           % (x, y, sum(e_ - s_ for s_, e_ in gaps)))
    for x in shown:
        if x not in dots:
            out.append("missing: the dot of the shown vertex %s" % x)
    return out


def union_elem_of(svg_text):
    """svg id -> (tag, attrs, points) read from the SVG text as written
    (no transforms: the overlay is painted in the same frame)."""
    rx = re.compile(r"<(line|circle|path|polyline|polygon|rect|text|g)\b"
                    r"([^>]*?)/?>", re.S)
    at = re.compile(r'([\w:-]+)="([^"]*)"')
    found = {}
    for m in rx.finditer(svg_text):
        a = dict(at.findall(m.group(2)))
        if a.get("id"):
            if m.group(1) == "g":
                # a builder's group id: its child strokes are its ink
                a = dict(a, _edges=[], _other=0)
                depth = 0 if m.group(0).endswith("/>") else 1
                tok = re.compile(r"</g\s*>|" + rx.pattern, re.S)
                for c in tok.finditer(svg_text, m.end()):
                    if depth <= 0:
                        break
                    if c.group(0).startswith("</"):
                        depth -= 1
                        continue
                    if c.group(1) == "g":
                        depth += 0 if c.group(0).endswith("/>") else 1
                        continue
                    ca = dict(at.findall(c.group(2)))
                    cg = _u_geom(c.group(1), ca)
                    if c.group(1) in ("line", "polyline", "polygon") and \
                            not ca.get("data-mark") and len(cg) >= 2:
                        a["_edges"] += list(zip(cg, cg[1:])) + (
                            [(cg[-1], cg[0])] if c.group(1) == "polygon"
                            and len(cg) > 2 else [])
                    else:
                        a["_other"] += 1
            found.setdefault(a["id"], []).append((m.group(1), a))

    def elem(sid):
        hit = found.get(sid) or []
        if len(hit) != 1:
            return None
        tag, a = hit[0]
        return tag, a, _u_geom(tag, a)
    elem.all = found          # v6.16 gaps: what the figure draws (G1 / G2)
    return elem


def _u_geom(tag, a):
    g = lambda k: float(a.get(k, 0))                     # noqa: E731
    if tag == "line":
        return [(g("x1"), g("y1")), (g("x2"), g("y2"))]
    if tag == "circle":
        return [(g("cx"), g("cy"))]
    if tag == "text":
        return [(g("x"), g("y"))]
    if tag in ("polyline", "polygon"):
        v = [float(x) for x in _U_UNITS.findall(a.get("points", ""))]
        return list(zip(v[0::2], v[1::2]))
    if tag == "path":
        d = a.get("d", "")
        if re.search(r"[^ML\s\d.,eE+-]", d):
            return []                  # a curve: no straight pieces to read
        v = [float(x) for x in _U_UNITS.findall(d)]
        return list(zip(v[0::2], v[1::2]))
    return []
# ---- end of the C1r2 block -------------------------------------------------


def _union_rules(d, nj):
    """K17 (v6.10, Codex C1r2): what highlighting a visual_model segment /
    angle / polygon paints -- the union of its parts after span limits (or
    its svg_id element) -- IS the object: no extra ink, no missing piece,
    an angle's sector shown. The same block as tools/highlight.py."""
    errs = []
    for F in nj.get("figures") or []:
        vm = F.get("visual_model") if isinstance(F, dict) else None
        if not isinstance(vm, dict) or not isinstance(vm.get("svg"), str):
            continue
        p = os.path.join(d, vm["svg"])
        if not os.path.isfile(p):
            continue
        with open(p, encoding="utf-8") as fh:
            el = union_elem_of(fh.read())
        objs = [o for o in vm.get("objects") or [] if isinstance(o, dict)]
        pts = dict((_geometry_name(o), tuple(o["svg_xy"])) for o in objs
                   if o.get("type") == "point" and _geometry_name(o) and
                   isinstance(o.get("svg_xy"), list) and
                   len(o["svg_xy"]) == 2 and
                   not isinstance(o["svg_xy"][0], list))
        for o in objs:
            for why in union_faults(o, pts, el):
                errs.append("K17 %s: highlighting %s would not paint the "
                            "object: %s" % (F.get("id"), o.get("id"), why))
    return errs


_K18_ID = re.compile(r'\sid="([^"]+)"')
_K18_TAG = re.compile(r'<([A-Za-z]+)\b[^>]*\sid="([^"]+)"')


def _map_rules(d, nj):
    """K18 (v6.10, Codex E2): every engine figure ships ITS object map.
    Which figures need one is derived from what describes them -- the
    model (objects with parts), the wspec.render figure scripts, the
    engine's SVG dialect, and build.json / sheet.json when the folder
    has them -- never from the map files present. Each map: exists, is
    JSON, names this figure, lists exactly the SVG's element ids (same
    tags), carries exactly the model's parts, and (when the folder ships
    wspec/public_spec.json) its public_hash."""
    errs = []
    req = {}

    def add(f, why):
        if f:
            req.setdefault(str(f), []).append(why)
    for F in nj.get("figures") or []:
        vm = (F or {}).get("visual_model") if isinstance(F, dict) else None
        if isinstance(vm, dict) and any(
                isinstance(o, dict) and o.get("parts")
                for o in vm.get("objects") or []):
            add(F.get("id"), "its model names engine parts")
    fd = os.path.join(d, "figures")
    for fn in sorted(os.listdir(fd)) if os.path.isdir(fd) else []:
        p = os.path.join(fd, fn)
        if fn.endswith(".py"):
            with open(p, encoding="utf-8", errors="replace") as fh:
                if re.search(r"#\s*kind:\s*wspec\.render\b", fh.read(2000)):
                    add(fn[:-3], "a wspec.render script")
        elif fn.endswith(".svg"):
            with open(p, encoding="utf-8", errors="replace") as fh:
                t = fh.read()
            if re.search(r'<g data-layer="[a-z]+"', t) and \
                    re.search(r'\sid="e\d{4}"', t):
                add(fn[:-4], "the engine's SVG dialect")
        elif fn.endswith(".map.json"):
            add(fn[:-len(".map.json")], "a map file")
    for name, key in (("build.json", "wspec"), ("sheet.json", "figures")):
        p = os.path.join(d, name)
        if not os.path.isfile(p):
            continue
        try:
            with open(p, encoding="utf-8") as fh:
                j = json.load(fh)
        except ValueError:
            continue
        if name == "build.json":
            for f in (j.get("wspec") or {}).get("figures") or []:
                add(f, "build.json wspec.figures")
        else:
            for F in j.get("figures") or []:
                if isinstance(F, dict) and (F.get("kind") == "wspec" or
                                            F.get("map")):
                    add(F.get("id"), "sheet.json")
    pubh = None
    graph_h = {}
    pp = os.path.join(d, "wspec", "public_spec.json")
    if os.path.isfile(pp):
        try:
            with open(pp, encoding="utf-8") as fh:
                _pj = json.load(fh)
            pubh = _pj.get("public_hash")
            # (v6.16 integrate) a graph figure's map is hashed to the PUBLIC
            # graph model its public figure carries (inside the hashed spec)
            for _g in _pj.get("figures") or []:
                if isinstance(_g, dict) and isinstance(_g.get("graph"),
                                                        dict):
                    graph_h[_g.get("id")] = _g["graph"].get("public_hash")
        except (ValueError, AttributeError):
            pubh = None
    vms = dict((F.get("id"), F.get("visual_model") or {})
               for F in nj.get("figures") or [] if isinstance(F, dict))
    # each figure is drawn with its own settings (the figure id is one of
    # them): two maps with one settings_hash are one figure's map twice
    seen_sh = {}
    for fn in sorted(os.listdir(fd)) if os.path.isdir(fd) else []:
        if fn.endswith(".map.json"):
            try:
                with open(os.path.join(fd, fn), encoding="utf-8") as fh:
                    sh = (json.load(fh) or {}).get("settings_hash")
            except (ValueError, AttributeError):
                continue
            if sh:
                seen_sh.setdefault(sh, []).append(fn[:-len(".map.json")])
    for fid in sorted(req):
        py = os.path.join(fd, "%s.py" % fid)
        if os.path.isfile(py):
            with open(py, encoding="utf-8", errors="replace") as fh:
                mfig = re.search(r'SETTINGS = json\.loads\(.{0,4}\{\s*'
                                 r'"figure":\s*"([^"]+)"', fh.read())
            if mfig and mfig.group(1) != fid:
                errs.append("K18 %s: figures/%s.py draws figure %r"
                            % (fid, fid, mfig.group(1)))
        rel = "figures/%s.map.json" % fid
        p = os.path.join(d, rel)
        if not os.path.isfile(p):
            errs.append("K18 %s: %s is missing (an engine figure: %s)"
                        % (fid, rel, "; ".join(req[fid][:3])))
            continue
        try:
            with open(p, encoding="utf-8") as fh:
                m = json.load(fh)
        except ValueError:
            errs.append("K18 %s: %s is not JSON" % (fid, rel))
            continue
        if not isinstance(m, dict):
            errs.append("K18 %s: %s is not a map" % (fid, rel))
            continue
        if m.get("figure") != fid:
            errs.append("K18 %s: %s is the map of figure %r"
                        % (fid, rel, m.get("figure")))
        twins = [f for f in seen_sh.get(m.get("settings_hash"), [])
                 if f != fid]
        if twins:
            errs.append("K18 %s: %s has the settings_hash of the map of %s "
                        "(the map of another figure)" % (fid, rel,
                                                         ", ".join(twins)))
        if pubh is not None and m.get("public_hash") != (
                graph_h[fid] if fid in graph_h else pubh):
            errs.append("K18 %s: the map's public_hash is not "
                        "wspec/public_spec.json's" % fid)
        sp = os.path.join(d, "figures", "%s.svg" % fid)
        if os.path.isfile(sp):
            with open(sp, encoding="utf-8") as fh:
                t = fh.read()
            tags = dict((i, g) for g, i in _K18_TAG.findall(t))
            me = m.get("elements") or {}
            if set(me) != set(tags):
                errs.append("K18 %s: the map's elements are not the SVG's "
                            "ids (%s)" % (fid, sorted(set(me) ^
                                                      set(tags))[:6]))
            for k, v in sorted(me.items()):
                if k in tags and isinstance(v, dict) and \
                        v.get("tag") != tags[k]:
                    errs.append("K18 %s: map element %s is a <%s>, the SVG "
                                "draws a <%s>" % (fid, k, v.get("tag"),
                                                  tags[k]))
        mo = m.get("objects") or {}
        for o in (vms.get(fid) or {}).get("objects") or []:
            if not isinstance(o, dict) or not o.get("parts"):
                continue
            want = [dict([("svg_id", q.get("element"))] + (
                [("span", list(q["span"]))]
                if q.get("span") not in (None, "whole") else []))
                for q in (mo.get(o.get("id")) or {}).get("parts") or []]
            got = [dict((k, v) for k, v in q.items() if k in (
                "svg_id", "span")) for q in o["parts"] if isinstance(q, dict)]
            if o.get("id") not in mo:
                errs.append("K18 %s: model object %s is not in the map"
                            % (fid, o.get("id")))
            elif want != got:
                errs.append("K18 %s: model object %s's parts %s are not the "
                            "map's %s" % (fid, o.get("id"), got, want))
    return errs


def _fixture_map(nj, svg):
    """the object map an engine would ship beside the fixture figure."""
    vm = nj["figures"][0]["visual_model"]
    return {"figure": vm["id"], "dialect": "wspec-svg/5",
            "engine": "wspec-render/1.0.2",
            "elements": dict((i, {"tag": g})
                             for g, i in _K18_TAG.findall(svg)),
            "objects": dict((o["id"], {
                "kind": o.get("type"), "parts": [
                    {"element": p["svg_id"],
                     "span": list(p["span"]) if p.get("span") else "whole"}
                    for p in o["parts"]]})
                for o in vm["objects"] if o.get("parts"))}


def hg_unmarked(vm):
    """(v6.10 fix r1, m1-hg) [reason] -- every highlight_given entry is a
    MARKED given: its relation's highlight names an overlay_mark object
    'for' it, or it is a statement derived from a given shape (from_given,
    C3). An unmarked given (a bare on_segment) offered as a given
    highlight has nothing of its own to paint."""
    out = []
    rel = dict((r.get("id"), r) for r in vm.get("relations") or []
               if isinstance(r, dict))
    ov = dict((o.get("id"), o) for o in vm.get("objects") or []
              if isinstance(o, dict) and o.get("type") == "overlay_mark")
    for x in vm.get("highlight_given") or []:
        if not isinstance(x, str):
            continue
        r = rel.get(x) or {}
        h = r.get("highlight")
        if r.get("from_given"):
            continue
        if not (h in ov and ov[h].get("for") == x):
            out.append("highlight_given %s (%s) has no given mark of its own "
                       "(no overlay_mark for it)" % (x, r.get("type")))
    return out

from fractions import Fraction as _HBS_Fraction

# ---- v6.18 source-state HG block (identical standalone readers) ----
_HBS_KEYS = {"kind", "from_figure", "source", "ladder", "right_angle",
        "old_height", "new_base", "height_target"}


def _hbs_obsolete_height(spec, figure):
    d = figure.get("state_change")
    if d is None:
        return set()
    def must(value):
        if not value:
            raise ValueError("unproved changed-position reader context")
    def norm(text):
        return " ".join(str(text).replace("$", "").split())
    def blocks(row):
        return [b for b in row.get("bound") or [] if isinstance(b, dict)]
    def bound(block, fact, token):
        return any(b.get("fact") == fact["id"] and _HBS_Fraction(str(b["tok"])) == _HBS_Fraction(token)
                   for b in block.get("bind") or [] if isinstance(b, dict) and b.get("fact") == fact["id"])
    must(isinstance(d, dict) and set(d) == _HBS_KEYS and d["kind"] == "rigid_ladder_base_move")
    must(all(isinstance(d[k], str) and d[k] for k in _HBS_KEYS - {"source"}))
    src = d["source"]
    must(isinstance(src, dict) and set(src) == {"scope", "text"}
         and all(isinstance(src[k], str) and src[k] for k in src))
    owners = [(q, i) for q in spec.get("questions", []) for i in q.get("items", [])
              if i.get("id") == figure.get("scope")]
    must(len(owners) == 1)
    q, item = owners[0]
    must(item.get("figure") == figure["id"] and src["scope"] == item["id"])
    old = [g for g in spec.get("figures", []) if g.get("id") == d["from_figure"]]
    must(len(old) == 1)
    old = old[0]
    must(old["id"] == q.get("figure") and old.get("scope") == q["id"] and "state_change" not in old)
    for frame in (old, figure):
        must(frame.get("figure_accuracy") == "accurate")
        must(not any(k in frame for k in ("frame", "graph", "data", "loci", "base_height")))
    must(set(old.get("entities", [])) == set(figure.get("entities", [])))
    f = {v["id"]: v for v in spec.get("facts", [])}
    e = {v["id"]: v for v in spec.get("entities", [])}
    ladder, right, initial, base, target = [f[d[k]] for k in
                                          ("ladder", "right_angle", "old_height", "new_base", "height_target")]
    for datum, owner in ((ladder, q["id"]), (right, q["id"]), (initial, q["id"]), (base, item["id"])):
        must(datum.get("role") == "given" and datum.get("item") == owner
             and datum.get("source") == {"kind": "stated"})
    for datum in (ladder, initial, base):
        must(datum.get("rel") == "length" and len(datum.get("args", [])) == 1 and datum.get("unit") == "m")
        must(e[datum["args"][0]].get("kind") == "segment")
    h, b, l = initial["args"][0], base["args"][0], ladder["args"][0]
    hv, bv, lv = [set(e[z].get("ends", [])) for z in (h, b, l)]
    vertices = hv | bv
    must(len(hv) == len(bv) == len(lv) == 2 and len(hv & bv) == 1
         and lv == vertices - (hv & bv) and len(vertices) == 3)
    must(all(e[z].get("kind") == "point" for z in vertices))
    must(right.get("rel") == "perpendicular" and set(right.get("args", [])) == {h, b})
    must(target.get("role") == "target" and target.get("rel") == "length"
         and target.get("args") == [h] and target.get("item") == item["id"] and "value" not in target)
    must(target["id"] in [t["id"] for t in item.get("targets", [])])
    listed = set(figure.get("entities", []))
    must(vertices | {h, b, l} <= listed)
    must({z for z in listed if e[z].get("kind") == "point"} == vertices)
    must({z for z in listed if e[z].get("kind") == "segment"} == {h, b, l})
    must(all(e[z].get("kind") in ("point", "segment", "angle", "polygon") for z in listed))
    kept = {right["id"], ladder["id"]}
    must(isinstance(figure.get("inherit_givens"), list) and len(figure["inherit_givens"]) == 2
         and set(figure["inherit_givens"]) == kept)
    must(kept | {base["id"]} <= set(item.get("uses", [])))
    for frame, datum in ((old, initial), (figure, base)):
        shown = set(frame.get("draws", []))
        must(kept | {datum["id"]} <= shown)
        must(all(z in kept | {datum["id"]} or
                 (f[z].get("rel") == "name" and f[z].get("role") == "context"
                  and f[z].get("args", [None])[0] in vertices) for z in shown))
    length, height, distance = [_HBS_Fraction(str(v["value"])) for v in (ladder, initial, base)]
    must(0 < height < length and 0 < distance < length)
    must(distance ** 2 != length ** 2 - height ** 2)  # same-position metadata cannot waive a leak
    atom = r"([0-9]+(?:\.[0-9]+)?)"
    before = r"סולם באורך " + atom + r" מטרים נשען על קיר ומגיע לגובה " + atom + r" מטרים\."
    found = False
    for block in blocks(q):
        m = re.fullmatch(before, norm(block.get("text")))
        if (m and _HBS_Fraction(m[1]) == length and _HBS_Fraction(m[2]) == height
                and bound(block, ladder, m[1]) and bound(block, initial, m[2])
                and right["id"] in block.get("prints", [])):
            found = True
    must(found)
    local = [x for x in blocks(item) if norm(x.get("text")) == norm(src["text"])]
    must(len(local) == 1)
    block = local[0]
    m = re.fullmatch(r"אם מזיזים את הבסיס למרחק " + atom + r" מטרים, חשבו את הגובה החדש\.", norm(block.get("text")))
    must(m and _HBS_Fraction(m[1]) == distance and bound(block, base, m[1])
         and {base["id"], target["id"]} <= set(block.get("prints", [])))
    return {initial["id"]}


def _source_state_hg_view(nj, figure_id, public_spec):
    """Read-only H3/K21 context for one independently proved source state.

    No ordinary claim is waived. Only the precise old head-height claim
    is omitted for the figure's own new-height target. The original rows
    remain in noam-ai.json and every other checker receives them unchanged.
    """
    try:
        figures = [f for f in public_spec.get("figures", []) if f.get("id") == figure_id]
        if len(figures) != 1 or "state_change" not in figures[0]:
            return nj
        fig = figures[0]
        excluded = _hbs_obsolete_height(public_spec, fig)
        d = fig["state_change"]
        facts = {f["id"]: f for f in public_spec["facts"]}
        entities = {e["id"]: e for e in public_spec["entities"]}
        old, target = facts[d["old_height"]], facts[d["height_target"]]
        if old["id"] not in excluded:
            return nj
        qid, rid = old["item"], target["item"]
        q = next(q for q in nj["questions"] if q["id"] == qid)
        item = next(i for i in q["items"] if i["id"] == rid)
        public_q = next(q for q in public_spec["questions"] if q["id"] == qid)
        public_item = next(i for i in public_q["items"] if i["id"] == rid)
        def norm(text):
            if isinstance(text, list):
                text = "\n".join(str(x) for x in text)
            return " ".join(str(text).replace("$", "").split())
        if (norm(q.get("text")) != norm(public_q.get("text"))
                or norm(item.get("text")) != norm(public_item.get("text"))
                or q.get("figure_id") != d["from_figure"]
                or item.get("figure_id") != figure_id):
            return nj
        names = {entities[p].get("name", p) for p in entities[old["args"][0]]["ends"]}
        def same_segment(value):
            parts = value if isinstance(value, list) else re.findall(r"[A-Z][0-9\u2032']*", str(value or ""))
            return len(parts) == 2 and set(parts) == names
        if not any(c.get("type") == "find" and c.get("quantity") == "length"
                   and same_segment(c.get("of")) for c in item.get("to_prove", []) if isinstance(c, dict)):
            return nj
        def is_old(g):
            if (not isinstance(g, dict) or g.get("type") != "length" or g.get("from_item")
                    or not same_segment(g.get("of")) or g.get("unit") not in ("m", "מטר", "מ'", "מ׳")):
                return False
            try:
                return _HBS_Fraction(str(g.get("value"))) == _HBS_Fraction(str(old["value"]))
            except (ValueError, TypeError, ZeroDivisionError):
                return False
        original = q.get("given", [])
        kept = [g for g in original if not is_old(g)]
        if len(kept) == len(original):
            return nj
        replacement = dict(q, given=kept)
        return dict(nj, questions=[replacement if row is q else row for row in nj["questions"]])
    except Exception:
        return nj  # malformed public data cannot authorize dropping any claim


def _source_state_hg_context(level, figure, nj):
    """Portable standalone reader: only standard-library imports are used."""
    try:
        with open(os.path.join(level, "wspec", "public_spec.json"), encoding="utf-8") as stream:
            public_spec = json.load(stream)
        return _source_state_hg_view(nj, figure.get("id"), public_spec)
    except Exception:
        return nj  # missing/malformed source keeps all existing HG requirements

# ---- end of v6.18 source-state HG block ----

# ---- v6.10 fix r2 block (identical in verify_export.py and --------------
# ---- selfcheck_noam_package.py; standard library only) --------------------
_R2_TOK = re.compile(u"[A-Z][0-9\u2032']*")
_R2_MARKED = ("equal_length", "midpoint", "equal_angle", "parallel",
              "perpendicular", "length", "angle")
_R2_NUM = re.compile(u"^[\u2212\\-]?[\\d.,/\u2212\\-]*\\d[\\d.,/]*$")
_R2_UNIT = re.compile(u"\\s*(?:\u00b0|\u2032|ס\"מ|ס\u05f4מ|סמ\"ר|"
                      u"סמ\u05f4ר|cm|%)$")
_R2_DEG = re.compile(u"\\s*[\u00b0\u2032]$")


def r2_numeric(t):
    """a printed number, with or without its unit ('48°', '6 ס״מ', '6√2')"""
    t = _R2_UNIT.sub(u"", str(t or u"").strip()).replace(u"\u221a", u"")
    return bool(_R2_NUM.match(t))


def _r2_seg(s):
    t = _R2_TOK.findall(str(s or ""))
    return frozenset(t) if len(t) == 2 else None


def _r2_ang(a):
    if isinstance(a, dict):
        at, rays = a.get("at"), list(a.get("rays") or [])
        if not at or len(rays) != 2:
            return None
        return (str(at), frozenset(str(r) for r in rays))
    t = _R2_TOK.findall(str(a or ""))
    return (t[1], frozenset((t[0], t[2]))) if len(t) == 3 else None


def _r2_val(v):
    if v is None:
        return None
    try:
        return round(float(str(v).replace(u"\u2212", "-")), 6)
    except ValueError:
        return u"".join(str(v).split())


def r2_key(c):
    """the fact a given claim / a model relation states (None: unmarked)"""
    if not isinstance(c, dict):
        return None
    t = c.get("type")
    if t in ("equal_length", "parallel", "perpendicular"):
        return (t, frozenset(_r2_seg(x) for x in c.get("of") or []))
    if t == "equal_angle":
        return (t, frozenset(_r2_ang(x) for x in c.get("of") or []))
    if t == "length":
        return (t, _r2_seg(c.get("of")), _r2_val(c.get("value")))
    if t == "angle":
        return (t, _r2_ang(c), _r2_val(c.get("value")))
    if t == "midpoint":
        return (t, str(c.get("point")), _r2_seg(c.get("of")))
    return None


def _r2_letters(c):
    out = set()
    for k in ("of", "point", "at", "rays"):
        v = c.get(k)
        for x in (v if isinstance(v, list) else [v]):
            if isinstance(x, dict):
                out.update(_R2_TOK.findall(str(x.get("at") or "")))
                for r in x.get("rays") or []:
                    out.update(_R2_TOK.findall(str(r)))
            else:
                out.update(_R2_TOK.findall(str(x or "")))
    return out


def hg_missing(F, nj):
    """(v6.10 fix r2, hg-completeness) [reason] -- highlight_given lists
    EVERY given the overlay can mark, not only a typed shape's statements
    (C3): each typed given claim of a row the figure serves (the question
    row, and the item rows whose figure it is: every row of a question
    figure, its own row for an item figure), unless carried (from_item) or
    no_overlay, whose kind the overlay marks (ticks / arc / parallel /
    right angle / length / angle) and whose points the figure shows, is a
    given relation of the model offered in highlight_given AND in
    actions.highlight. Derived from the claims of noam-ai.json, not from
    what the model offers; also: an overlay_mark 'for' a given relation is
    offered."""
    vm = F.get("visual_model") if isinstance(F, dict) else None
    if not isinstance(vm, dict) or vm.get("visual_support") == "unsupported":
        return []
    out = []
    fid = vm.get("id") or F.get("id")
    qid = vm.get("question") or F.get("question")
    q = [x for x in nj.get("questions") or []
         if isinstance(x, dict) and x.get("id") == qid]
    if not q:
        return []
    q = q[0]
    rows = [q.get("given") or []]
    for it in q.get("items") or []:
        if not isinstance(it, dict):
            continue
        if vm.get("item"):
            if it.get("id") == vm["item"]:
                rows.append(it.get("given") or [])
        elif it.get("figure_id") in (None, fid):
            rows.append(it.get("given") or [])
    pts = set(_geometry_name(o) for o in vm.get("objects") or []
              if isinstance(o, dict) and o.get("type") == "point")
    hg = set(x for x in vm.get("highlight_given") or [] if isinstance(x, str))
    ah = set(x for x in (vm.get("actions") or {}).get("highlight") or []
             if isinstance(x, str))
    rels = [r for r in vm.get("relations") or []
            if isinstance(r, dict) and r.get("role") == "given"]
    seen = set()
    for cl in rows:
        for c in cl if isinstance(cl, list) else []:
            if not isinstance(c, dict) or c.get("from_item") or \
                    c.get("no_overlay") or c.get("type") not in _R2_MARKED:
                continue
            k = r2_key(c)
            if k is None or k in seen or not (_r2_letters(c) & pts):
                continue
            seen.add(k)
            say = c.get("text") or c.get("type")
            hit = [r for r in rels if r2_key(r) == k]
            if not hit:
                out.append("the given %r of figure %s is no given relation "
                           "of its model (nothing to highlight)" % (say, fid))
                continue
            if not any(r.get("id") in hg for r in hit):
                out.append("the given %s (%r) is not offered in "
                           "highlight_given" % (hit[0].get("id"), say))
            if not any(r.get("id") in ah for r in hit):
                out.append("the given %s (%r) is not in actions.highlight"
                           % (hit[0].get("id"), say))
    gid = dict((r.get("id"), r) for r in rels)
    for o in vm.get("objects") or []:
        if isinstance(o, dict) and o.get("type") == "overlay_mark" and \
                o.get("for") in gid and o.get("for") not in hg:
            out.append("overlay_mark %s marks the given %s, which "
                       "highlight_given does not offer"
                       % (o.get("id"), o.get("for")))
    return out


def _r2_label_value(t):
    t = _R2_UNIT.sub(u"", str(t).strip()).replace(u"\u2212", "-")
    try:
        if "/" in t:
            a, b = t.split("/", 1)
            return round(float(a) / float(b), 6)
        return round(float(t.replace(",", ".")), 6)
    except (ValueError, ZeroDivisionError):
        return None


_R2_TICK = re.compile(u"^(?:o0|[xy][\\w.\u2212-]+)$")


def label_states(o, vm, where):
    """(v6.10 fix r2, label-for-integrity) [reason] -- a numeric label's
    `for` names the RIGHT object. Decided on the model's typed given /
    context values: a degree label ('48°', for the vertex O or its arc
    'arc-O') names an angle at that vertex (between the arms its model
    name says) whose value is 48, a length label ('14', for AB) a segment
    whose length is 14. A label is wrong when the object it names carries
    another value, or carries none while another object carries this one
    (re-tied: '14' moved from AB to AD). A value no typed relation states
    (a text-only given) and an axis number ('2' for its tick y2) are not
    decided here (N3 still requires the `for`)."""
    t = str(o.get("text", o.get("name", "")) or "")
    if not r2_numeric(t) or not o.get("for"):
        return []
    f, v = str(o["for"]), _r2_label_value(t)
    if u"\u221a" in t or v is None or _R2_TICK.match(f):
        return []
    lid = o.get("svg_id") or o.get("id")
    rels = [r for r in vm.get("relations") or [] if isinstance(r, dict) and
            r.get("role") in ("given", "context") and
            isinstance(_r2_val(r.get("value")), float)]
    if _R2_DEG.search(t):
        at = f[4:] if f.startswith("arc-") else f
        nm = _R2_TOK.findall(_geometry_name(o))
        rays = frozenset((nm[0], nm[2])) if len(nm) == 3 and \
            nm[1] == at else None
        kind = [r for r in rels if r.get("type") == "angle"]
        mine = [r for r in kind if str(r.get("at")) == at and
                (rays is None or (_r2_ang(r) or (None, None))[1] == rays)]
        what = "the angle at %s" % at
    else:
        s = _r2_seg(f)
        kind = [r for r in rels if r.get("type") == "length"]
        mine = [r for r in kind if s is not None and
                _r2_seg(r.get("of")) == s]
        what = "the segment %s" % f
    if mine:
        if any(_r2_val(r.get("value")) == v for r in mine):
            return []
        return ["%s: label %s (%r) is `for` %s, but %s is given as %s"
                % (where, lid, t, f, what, ", ".join(
                    str(r.get("value")) for r in mine))]
    other = [r for r in kind if _r2_val(r.get("value")) == v]
    if other:
        return ["%s: label %s (%r) is `for` %s, but %s states no value "
                "and %s is the value of %s" % (
                    where, lid, t, f, what, t,
                    r2_name(other[0]))]
    return []


def r2_name(r):
    if r.get("type") == "angle":
        a = _r2_ang(r)
        return "the angle at %s" % (a[0] if a else "?")
    return "the segment %s" % r.get("of")


def label_faults(F, sheet_fig=None):
    """(v6.10 fix r2, label-for-integrity + R1-vm-for) [reason] -- every
    numeric label of a figure -- objects.labels, its visual_model copy,
    the sheet.json figure's copy and an aux patch's label -- carries `for`,
    names the object whose value it prints (label_states), and every copy
    of one label names the SAME object."""
    vm = F.get("visual_model") if isinstance(F, dict) else None
    if not isinstance(vm, dict) or vm.get("visual_support") == "unsupported":
        return []
    out = []
    fid = F.get("id")
    flat = dict((o.get("svg_id"), o) for o in
                (F.get("objects") or {}).get("labels") or []
                if isinstance(o, dict))
    for o in flat.values():
        out += label_states(o, vm, "noam-ai %s objects.labels" % fid)
    for o in ((sheet_fig or {}).get("objects") or {}).get("labels") or []:
        if not isinstance(o, dict):
            continue
        t = str(o.get("text", o.get("name", "")) or "")
        if not r2_numeric(t):
            continue
        out += label_states(o, vm, "sheet.json %s" % fid)
        fo = flat.get(o.get("svg_id"))
        if fo is not None and fo.get("for") != o.get("for"):
            out.append("sheet.json %s label %s is `for` %s, noam-ai.json "
                       "says %s" % (fid, o.get("svg_id"), o.get("for"),
                                    fo.get("for")))
    for o in vm.get("objects") or []:
        if not isinstance(o, dict) or o.get("type") != "label":
            continue
        t = str(o.get("text", o.get("name", "")) or "")
        if not r2_numeric(t):
            continue
        fo = flat.get(o.get("svg_id"))
        if not o.get("for"):
            out.append("visual_model %s label %s (%r) has no `for`"
                       % (fid, o.get("id"), t))
            continue
        if fo is not None and fo.get("for") != o.get("for"):
            out.append("visual_model %s label %s is `for` %s, "
                       "objects.labels says %s" % (fid, o.get("id"),
                                                   o.get("for"),
                                                   fo.get("for")))
        out += label_states(o, vm, "visual_model %s" % fid)
    for a in vm.get("aux") or []:
        for op in (a.get("ops") or []) if isinstance(a, dict) else []:
            for o in (op.get("objects") or []) if isinstance(op, dict) \
                    else []:
                if not isinstance(o, dict) or o.get("type") != "label":
                    continue
                t = str(o.get("text", o.get("name", "")) or "")
                if not r2_numeric(t):
                    continue
                if not o.get("for"):
                    out.append("aux %s label %s (%r) has no `for`"
                               % (a.get("id"), o.get("id"), t))
                    continue
                out += label_states(o, vm, "aux %s" % a.get("id"))
    return out


def _pt_lines(t):
    """(v6.13 fix_r2) a row's text as its printed lines: a spec stem joined
    by the "\n" connector is the sheet's list of stem lines"""
    if isinstance(t, list):
        return [str(x) for x in t]
    t = str(t or "")
    return t.split("\n") if "\n" in t else t


def public_text_faults(pub, docs):
    """(v6.10 fix r2, R1-s1-consistent) [reason] -- the public spec says
    what the sheet prints: every question / item text of
    wspec/public_spec.json is the text of the same row in each document
    given ([(name, doc)]: sheet.json, noam-ai.json), and every row of a
    spec question is in it."""
    out = []
    pq = {}
    for q in (pub or {}).get("questions") or []:
        if not isinstance(q, dict):
            continue
        pq[q.get("id")] = q
        for it in q.get("items") or []:
            if isinstance(it, dict):
                pq[it.get("id")] = it
    for name, doc in docs:
        for q in (doc or {}).get("questions") or []:
            if not isinstance(q, dict) or q.get("id") not in pq:
                continue
            for r in [q] + [x for x in q.get("items") or []
                            if isinstance(x, dict)]:
                sc = pq.get(r.get("id"))
                if sc is None:
                    out.append("%s row %s of spec question %s is not in "
                               "the public spec" % (name, r.get("id"),
                                                    q.get("id")))
                elif _pt_lines(sc.get("text")) != _pt_lines(r.get("text")):
                    out.append("%s row %s prints %r; the public spec says "
                               "%r" % (name, r.get("id"),
                                       str(r.get("text"))[:70],
                                       str(sc.get("text"))[:70]))
    return out
# ---- end of the v6.10 fix r2 block ----------------------------------------


# K25 (v6.14 fix_r1): the three wordings of W-META-LINES-3, found by their
# words (a line that lost its link or gained a word is still found); the
# line each must BE is rebuilt below from the fact it links
_K25_ANY = re.compile(u"שמייצגת הנקודה|קווי רשת סמוכים|∥\\s*(?:ציר|axis)")
_K25_NL = u"המספר שמייצגת הנקודה %s"
_K25_GRID = u"ההפרש בין הערכים של שני קווי רשת סמוכים על ציר %s"
_K25_PAR = u"%s ∥ ציר %s"
_K25_PAR_WORDS = re.compile(u"מקביל\\S*\\s+ל(?:ציר|צירים)")


def _k25_num(v):
    """'1/2' -> '0.5', '3' -> '3' (a printed value as the phrase writes it;
    the module stays on its own import list: selfcheck_v68 K7)"""
    s = str(v).strip()
    try:
        n, _sl, dn = s.partition("/")
        x = float(n) / float(dn) if _sl else float(s)
    except (ValueError, ZeroDivisionError):
        return None
    return str(int(x)) if x == int(x) else "%g" % x


def _k25_lines(f, ents, key):
    """the lines (text, typed of) fact f may be restated as in `key`"""
    a = list(f.get("args") or [])
    nm = lambda x: (ents.get(x) or {}).get("name") or u"".join(
        (ents.get(x) or {}).get("ends") or [])
    rel, out = f.get("rel"), []
    if rel == "coordinate" and len(a) == 2 and \
            (ents.get(a[1]) or {}).get("kind") == "axis" and \
            nm(a[1]) not in ("x", "y"):
        out.append((_K25_NL % nm(a[0]), None))
    elif rel == "interval_value" and len(a) == 1 and nm(a[0]) in ("x", "y"):
        out.append((_K25_GRID % nm(a[0]), None))
        if key == "given" and _k25_num(f.get("value")) is not None:
            out.append((_K25_GRID % nm(a[0]) + u" = " +
                        _k25_num(f.get("value")), None))
    elif rel == "axis_parallel" and len(a) == 2 and nm(a[1]) in ("x", "y"):
        out.append((_K25_PAR % (nm(a[0]), nm(a[1])),
                    [nm(a[0]), "axis-" + nm(a[1])]))
    return out


def meta_line_rules(nj, pub):
    """K25: see the module doc (W-META-LINES-3)."""
    pub = pub if isinstance(pub, dict) else {}
    facts = dict((f.get("id"), f) for f in pub.get("facts") or []
                 if isinstance(f, dict))
    es = pub.get("entities") or []
    ents = dict(es) if isinstance(es, dict) else dict(
        (e.get("id"), e) for e in es if isinstance(e, dict))
    pscope = {}
    for pq in pub.get("questions") or []:
        pscope[pq.get("id")] = (pq, None)
        for it in pq.get("items") or []:
            pscope[it.get("id")] = (it, pq)
    errs, rows = [], {}

    def printed(sc):
        ids = set()
        for s_ in sc:
            for b in s_.get("bound") or []:
                ids.update(b.get("prints") or [])
                for bd in b.get("bind") or []:
                    fx = bd.get("fact")
                    ids.update(fx if isinstance(fx, list) else
                               [fx] if fx else [])
        return ids
    for q in nj.get("questions") or []:
        if not isinstance(q, dict):
            continue
        own = set(it.get("id") for it in q.get("items") or []
                  if isinstance(it, dict))
        for row in [q] + [it for it in q.get("items") or []
                          if isinstance(it, dict)]:
            rid = row.get("id")
            rows[rid] = (q, row)
            if row is q:
                sc = [pscope[rid][0]] + [
                    it for it in pscope[rid][0].get("items") or []
                    if it.get("id") not in own] if rid in pscope else []
            else:
                sc = [pscope[rid][0]] if rid in pscope else []
            for key in ("given", "to_prove", "to_construct"):
                for c in row.get(key) or []:
                    t = c.get("text") if isinstance(c, dict) else c
                    if not (isinstance(t, str) and _K25_ANY.search(t)):
                        continue
                    w = "%s %s %r" % (rid, key, t)
                    if not isinstance(c, dict):
                        errs.append("%s is a plain string, linked to no "
                                    "fact" % w)
                        continue
                    if key == "to_construct":
                        errs.append("%s: such a line restates a given or a "
                                    "target, never a construction" % w)
                        continue
                    if not sc:
                        # builder row: the typed ∥ given its question prints
                        m = re.match(u"^(\\S+) ∥ (?:ציר |axis-)([xy])$", t)
                        qt = u" ".join(x if isinstance(x, str) else u" ".join(
                            x or []) for x in (q.get("text"), row.get("text")
                                         if row is not q else u""))
                        if not m or key != "given" or c.get("type") != \
                                "parallel" or c.get("of") != [
                                    m.group(1), "axis-" + m.group(2)] or \
                                set(c) - set(("text", "type", "of")) or \
                                not _K25_PAR_WORDS.search(qt):
                            errs.append("%s: on a row with no public spec "
                                        "only the typed ∥ given its question"
                                        " prints may stand (no source id "
                                        "otherwise)" % w)
                        continue
                    fl = c.get("facts")
                    if not (isinstance(fl, list) and len(fl) == 1 and
                            fl[0] in facts):
                        errs.append("%s links %r, not ONE fact of "
                                    "wspec/public_spec.json" % (w, fl))
                        continue
                    f = facts[fl[0]]
                    ids = [s_.get("id") for s_ in sc]
                    if f.get("item") not in ids or fl[0] not in printed(sc):
                        errs.append("%s restates %s, which its row %s does "
                                    "not print" % (w, fl[0], "/".join(ids)))
                    want = ("target",) if key == "to_prove" else \
                        ("given", "context")
                    # A printed parallelism proposition is a proof task;
                    # its role remains to_prove, with no numeric answer.
                    if key == "to_prove" and f.get("rel") == "axis_parallel":
                        want = ("target", "to_prove")
                    if f.get("role") not in want:
                        errs.append("%s restates %s of role %s (%s wants %s)"
                                    % (w, fl[0], f.get("role"), key,
                                       "/".join(want)))
                    ok = [x for x in _k25_lines(f, ents, key) if x[0] == t]
                    if not ok:
                        errs.append("%s is not the line of %s (%s): a word, "
                                    "value, hint or name added" % (
                                        w, fl[0], [x[0] for x in _k25_lines(
                                            f, ents, key)]))
                    extra = set(c) - set(("text", "facts") + (
                        ("type", "of") if ok and ok[0][1] else ()))
                    if extra:
                        errs.append("%s carries %s beyond the line" % (
                            w, sorted(extra)))
                    if ok and ok[0][1] and (c.get("type") != "parallel" or
                                            c.get("of") != ok[0][1]):
                        errs.append("%s is not the typed parallel %s" % (
                            w, ok[0][1]))
                    pub_side = [tg.get("description") for s_ in sc
                                for tg in s_.get("targets") or []
                                if tg.get("id") == fl[0]] \
                        if key == "to_prove" else \
                        [x for s_ in sc for x in s_.get("given_lines") or []]
                    if t not in pub_side:
                        errs.append("%s is not a line the public spec's %s "
                                    "carries" % (w, "/".join(ids)))
    for F in nj.get("figures") or []:
        vm = (F.get("visual_model") if isinstance(F, dict) else None) or {}
        for r in vm.get("relations") or []:
            t = r.get("text") if isinstance(r, dict) else None
            if not (isinstance(t, str) and _K25_ANY.search(t)):
                continue
            qid = vm.get("question") or F.get("question")
            key = r.get("role")
            cand = [r.get("item")] if r.get("item") in rows else [qid] + [
                it.get("id") for it in (rows.get(qid) or ({}, {}))[0]
                .get("items") or [] if isinstance(it, dict)]
            if key not in ("given", "to_prove") or not any(
                    isinstance(c, dict) and c.get("text") == t
                    for x in cand for c in (rows.get(x) or ({}, {}))[1]
                    .get(key) or []):
                errs.append("%s relation %s %r (%s): no %s claim of %s "
                            "states it" % (F.get("id"), r.get("id"), t, key,
                                           key, "/".join(map(str, cand))))
    return errs


# ---- C3 (v6.10): what a typed-shape given states ---------------------------
# The same block is in deliver.py, check_didactic.py and
# selfcheck_noam_package.py (each file stays independent; the v6.10 suite
# proves the three copies are identical). The statements are the
# definitions the school course uses (PENDING the author's approval):
#   parallelogram  both pairs of opposite sides parallel
#   rectangle      four right angles (as AB ⊥ BC ..., no number)
#                                           square  + four equal sides
#   rhombus        four equal sides         kite    two pairs of adjacent
#                                                   equal sides (read off the
#                                                   figure; ambiguous: refused)
#   trapezoid      the one pair of parallel sides (read off the figure;
#                  "שווה־שוקיים" in its text adds the equal legs)
#   equilateral    three equal sides        isosceles  the two equal sides
#   right_triangle the right angle          (read off the figure)
# A statement that IS a goal of the figure's question (a find / to_prove:
# 'what is the angle ABC?' of a given rectangle) is never offered --
# highlighting it would answer the question.
C3_SHAPES = ("parallelogram", "rectangle", "square", "rhombus", "kite",
             "trapezoid", "equilateral", "isosceles", "right_triangle")
_C3_TOK = re.compile(r"[A-Z][0-9]*'*")


class ShapeStateError(ValueError):
    pass


def _c3_len(P, a, b):
    return math.hypot(P[b][0] - P[a][0], P[b][1] - P[a][1])


def _c3_par(P, a, b, c, d):
    u = (P[b][0] - P[a][0], P[b][1] - P[a][1])
    v = (P[d][0] - P[c][0], P[d][1] - P[c][1])
    nu, nv = math.hypot(*u), math.hypot(*v)
    return nu > 0 and nv > 0 and \
        abs(u[0] * v[1] - u[1] * v[0]) / (nu * nv) < math.sin(
            math.radians(0.5))


def _c3_eq(P, s, t):
    a, b = _c3_len(P, *s), _c3_len(P, *t)
    return abs(a - b) <= 0.01 * max(a, b, 1e-9)


def _c3_right(P, v, a, b):
    u = (P[a][0] - P[v][0], P[a][1] - P[v][1])
    w = (P[b][0] - P[v][0], P[b][1] - P[v][1])
    nu, nw = math.hypot(*u), math.hypot(*w)
    return nu > 0 and nw > 0 and \
        abs(u[0] * w[0] + u[1] * w[1]) / (nu * nw) < math.sin(
            math.radians(0.5))


def shape_states(value, points, P=None, text=""):
    """The claims a GIVEN 'points are a <value>' states, as claim dicts
    ({type: parallel / equal_length / perpendicular, of: [..], at} --
    no number, so the overlay prints no value). P {name: (x, y)} reads the figure where the definition
    leaves a choice (which pair of a trapezoid, which vertex of an
    isosceles / right triangle, which pairs of a kite); a choice the
    figure does not settle raises ShapeStateError (refuse, never guess)."""
    pts = [str(p) for p in points or []]
    n = len(pts)
    side = [(pts[i], pts[(i + 1) % n]) for i in range(n)]

    def seg(s):
        return s[0] + s[1]

    def par(s, t):
        return {"type": "parallel", "of": [seg(s), seg(t)],
                "text": u"%s ∥ %s" % (seg(s), seg(t))}

    def eq(*ss):
        return {"type": "equal_length", "of": [seg(s) for s in ss],
                "text": " = ".join(seg(s) for s in ss)}

    def right(i):
        a, v, b = pts[i - 1], pts[i], pts[(i + 1) % n]
        return {"type": "perpendicular", "of": [a + v, v + b], "at": v,
                "text": u"%s%s ⊥ %s%s" % (a, v, v, b)}

    def need(k):
        if n != k or len(set(pts)) != k:
            raise ShapeStateError("a %s names %d distinct points, not %d"
                                  % (value, len(set(pts)), k))

    def figure():
        if not P or any(p not in P for p in pts):
            raise ShapeStateError("which sides a %s's given states is read "
                                  "off the figure, and its points are not "
                                  "all drawn" % value)
    if value == "parallelogram":
        need(4)
        return [par(side[0], side[2]), par(side[1], side[3])]
    if value == "rectangle":
        need(4)
        return [right(i) for i in range(4)]
    if value == "square":
        need(4)
        return [right(i) for i in range(4)] + [eq(*side)]
    if value == "rhombus":
        need(4)
        return [eq(*side)]
    if value == "trapezoid":
        need(4)
        figure()
        pairs = [(side[0], side[2]), (side[1], side[3])]
        hit = [pq for pq in pairs if _c3_par(P, *(pq[0] + pq[1]))]
        if len(hit) != 1:
            raise ShapeStateError("the figure shows %d parallel pair(s) of "
                                  "the trapezoid %s: its bases are not "
                                  "settled" % (len(hit), "".join(pts)))
        out = [par(*hit[0])]
        if re.search(u"שווה[־\\s-]?שוק"
                     u"יים", str(text or "")):
            legs = [s for s in side if s not in hit[0]]
            out.append(eq(*legs))
        return out
    if value == "kite":
        need(4)
        figure()
        cfg = [((side[0], side[1]), (side[2], side[3])),
               ((side[1], side[2]), (side[3], side[0]))]
        ok = [c for c in cfg if _c3_eq(P, *c[0]) and _c3_eq(P, *c[1])]
        if len(ok) != 1:
            raise ShapeStateError("the figure does not settle the equal "
                                  "pairs of the kite %s" % "".join(pts))
        return [eq(*ok[0][0]), eq(*ok[0][1])]
    if value == "equilateral":
        need(3)
        return [eq(*side)]
    if value == "isosceles":
        need(3)
        figure()
        at = [i for i in range(3) if _c3_eq(P, side[i - 1], side[i])]
        if len(at) != 1:
            raise ShapeStateError("the figure does not settle the apex of "
                                  "the isosceles %s (%d candidates)"
                                  % ("".join(pts), len(at)))
        i = at[0]
        return [eq(side[i - 1], side[i])]
    if value == "right_triangle":
        need(3)
        figure()
        at = [i for i in range(3) if _c3_right(P, pts[i], pts[i - 1],
                                                pts[(i + 1) % 3])]
        if len(at) != 1:
            raise ShapeStateError("the figure does not settle the right "
                                  "angle of %s" % "".join(pts))
        return [right(at[0])]
    raise ShapeStateError("no statement is known for the shape %r" % value)


def c3_key(c):
    """A canonical key of a stated claim (order of names ignored)."""
    t = (c or {}).get("type")
    if t in ("parallel", "equal_length", "perpendicular"):
        segs = sorted("".join(sorted(_C3_TOK.findall(str(s))))
                      for s in c.get("of") or [])
        if t != "perpendicular":
            return (t, tuple(segs))
        at = c.get("at")
        if not at and len(segs) == 2:
            common = set(_C3_TOK.findall(segs[0])) & set(
                _C3_TOK.findall(segs[1]))
            at = list(common)[0] if len(common) == 1 else None
        return (t, tuple(segs), str(at))
    if t == "angle" and str(c.get("value")) in ("90", "90.0") and \
            c.get("at") and len(c.get("rays") or []) == 2:
        v = str(c["at"])
        return c3_key({"type": "perpendicular", "at": v, "of": [
            str(c["rays"][0]) + v, v + str(c["rays"][1])]})
    if t == "angle":
        return (t, str(c.get("at")), tuple(sorted(
            str(x) for x in c.get("rays") or [])), str(c.get("value")))
    return (t, repr(sorted((k, str(v)) for k, v in (c or {}).items()
                           if k not in ("text", "id", "objects"))))


def c3_goal_keys(vm):
    """keys of what the figure's question asks (to_prove / to_construct /
    find): a statement with one of them is not offered (it answers)."""
    out = set()
    for r in vm.get("relations") or []:
        if not isinstance(r, dict) or r.get("role") not in (
                "to_prove", "to_construct"):
            continue
        out.add(c3_key(r))
        at, rays = r.get("at"), r.get("rays") or []
        if at and len(rays) == 2 and (r.get("type") == "angle" or (
                r.get("type") == "find" and r.get("quantity") == "angle")):
            v = str(at)
            out.add(c3_key({"type": "perpendicular", "at": v,
                            "of": [str(rays[0]) + v, v + str(rays[1])]}))
    return out


def c3_faults(vm):
    """[reason] -- highlight_given of one visual_model holds EXACTLY what
    each typed-shape given states: every statement of every given shape
    (role given, not carried with from_item) that is not the question's
    own goal is offered -- by a relation
    derived from it (from_given = the shape's id) or by an explicit given
    relation saying the same -- and every derived relation is a statement
    of a given shape, nothing else."""
    out = []
    rels = [r for r in vm.get("relations") or [] if isinstance(r, dict)]
    rid = dict((r.get("id"), r) for r in rels)
    hg = [x for x in vm.get("highlight_given") or [] if isinstance(x, str)]
    P = dict((str(o.get("name")), tuple(o["svg_xy"]))
             for o in vm.get("objects") or []
             if isinstance(o, dict) and o.get("type") == "point" and
             o.get("name") and isinstance(o.get("svg_xy"), list) and
             len(o["svg_xy"]) == 2 and not isinstance(o["svg_xy"][0], list))
    offered = {}
    for x in hg:
        r = rid.get(x) or {}
        if r.get("role") == "given":
            offered.setdefault(c3_key(r), []).append(r)
    want = {}
    goals = c3_goal_keys(vm)
    for r in rels:
        if r.get("type") != "shape" or r.get("role") != "given" or \
                r.get("from_item") or r.get("no_overlay"):
            continue
        try:
            st = shape_states(r.get("value"), r.get("points"), P,
                              r.get("text"))
        except ShapeStateError as e:
            out.append("given %s (%s): %s" % (r.get("id"), r.get("text"), e))
            continue
        st = [c for c in st if c3_key(c) not in goals]
        want[r.get("id")] = set(c3_key(c) for c in st)
        for c in st:
            if c3_key(c) not in offered:
                out.append("given %s (%s) states %s, which highlight_given "
                           "does not offer" % (r.get("id"), r.get("text"),
                                               c.get("text")))
    for x in hg:
        r = rid.get(x) or {}
        src = r.get("from_given")
        if src is None:
            continue
        if src not in want:
            s = rid.get(src) or {}
            out.append("%s is derived from %s, which is no given shape "
                       "(%s %s%s)" % (x, src, s.get("role"), s.get("value"),
                                      ", carried from_item"
                                      if s.get("from_item") else ""))
        elif c3_key(r) not in want[src]:
            out.append("%s (%s) is not what the given %s states"
                       % (x, r.get("text"), src))
    for r in rels:
        if r.get("from_given") and r.get("id") not in hg:
            out.append("%s is derived from %s but not offered in "
                       "highlight_given" % (r.get("id"), r.get("from_given")))
    return out
# ---- end of the C3 block ---------------------------------------------------


VM_ACTIONS = ("show", "highlight", "show_aux")


def _vm_rules(nj):
    """K14 (v6.7.1-noam §9): every figure carries a visual-model/v1; the
    closed action list; an unsupported visual ships no drawing; an aux is a
    patch shown on request with one step."""
    errs = []
    vms = []
    for F in nj.get("figures") or []:
        if not isinstance(F, dict):
            continue
        vm = F.get("visual_model")
        if not isinstance(vm, dict):
            errs.append("K14 figure %s has no visual_model" % F.get("id"))
            continue
        if vm.get("id") != F.get("id") or vm.get("svg") != F.get("svg"):
            errs.append("K14 figure %s: its visual_model names %s / %s"
                        % (F.get("id"), vm.get("id"), vm.get("svg")))
        vms.append(vm)
    vms += [v for v in nj.get("visuals") or [] if isinstance(v, dict)]
    for vm in vms:
        w = vm.get("id")
        if vm.get("schema_version") != "visual-model/v1":
            errs.append("K14 %s: schema_version %r" % (w, vm.get(
                "schema_version")))
        sup = vm.get("visual_support")
        if sup not in ("full", "partial", "unsupported"):
            errs.append("K14 %s: visual_support %r" % (w, sup))
        act = vm.get("actions") or {}
        if not isinstance(act, dict) or any(
                x not in VM_ACTIONS for x in act.get("allowed") or []):
            errs.append("K14 %s: actions outside show / highlight / "
                        "show_aux" % w)
        hg = vm.get("highlight_given") or []
        if isinstance(act, dict) and any(
                x not in hg for x in act.get("highlight") or []):
            errs.append("K14 %s: highlight offers ids beyond "
                        "highlight_given" % w)
        if sup == "unsupported" and (vm.get("svg") or vm.get("aux") or (
                isinstance(act, dict) and (act.get("show") or
                                           act.get("highlight")))):
            errs.append("K14 %s: an unsupported visual ships a drawing / "
                        "something to show" % w)
        for a in vm.get("aux") or []:
            if not isinstance(a, dict) or a.get("reveal") != "on_request" \
                    or not a.get("label") or not str(a.get("step") or
                                                     "").strip():
                errs.append("K14 %s: an aux patch is shown on request, "
                            "labelled, with its one step" % w)
            for op in (a or {}).get("ops") or []:
                if op.get("op") not in ("add", "show", "highlight"):
                    errs.append("K14 %s: aux op %r" % (w, op.get("op")))
    return errs


def check_dirs(dirs):
    total, seen = 0, []
    for d in dirs:
        errs, nj = check_level(d)
        seen.append(nj or {})
        print("%s: %d error(s)" % (d, len(errs)))
        for e in errs[:60]:
            print("    " + e)
        if len(errs) > 60:
            print("    ... %d more" % (len(errs) - 60))
        total += len(errs)
    if len(dirs) > 1:
        pk = set(str(j.get("package")) for j in seen)
        lv = [j.get("level") for j in seen]
        if len(pk) > 1:
            print("    K10 the folders name different packages: %s"
                  % sorted(pk))
            total += 1
        if len(set(lv)) != len(lv):
            print("    K10 a level repeats: %s" % lv)
            total += 1
    print("selfcheck_noam_package: %d error(s)" % total)
    return total


# ------------------------------------------------------------ fixtures -----
_SVG = u"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 120" \
width="200" height="120">
<g id="poly-ABC"><line id="seg-AB" x1="20" y1="100" x2="180" y2="100" \
stroke="#000"/><line id="seg-AC" x1="20" y1="100" x2="100" y2="20" \
stroke="#000"/><line id="seg-BC" x1="180" y1="100" x2="100" y2="20" \
stroke="#000"/></g>
<circle id="pt-A" cx="20" cy="100" r="2" fill="#000"/>
<circle id="pt-B" cx="180" cy="100" r="2" fill="#000"/>
<g transform="translate(100,20)"><circle id="pt-C" cx="0" cy="0" r="2" \
fill="#000"/></g>
<circle id="pt-M" cx="100" cy="100" r="2" fill="#000"/>
<g id="tick-1"><line x1="60" y1="96" x2="60" y2="104" stroke="#000"/></g>
<path id="ra-M" d="M 94 100 L 94 94 L 100 94" fill="none" stroke="#000"/>
<text id="lbl-A" x="8" y="112">A</text>
</svg>"""


def _fixture_json():
    M = [20.0, 0.0, 0.0, -20.0, 20.0, 100.0]       # data (0..8, 0..4) -> svg
    return {
        "schema_version": "noam-ai/v1", "package": "G7-T08", "level": "a",
        "questions": [{
            "id": "q1", "label": 1, "text": u"נתון משולש ABC.",
            "figure_id": "q1_head",
            "given": [{"text": "CM \u22a5 AB", "type": "perpendicular",
                       "of": ["AB", "CM"], "at": "M"}],
            "to_prove": [], "to_construct": [],
            "table": {"head": [u"יום", "1"], "rows": [[u"משחקים", "3"]]},
            "items": [{
                "id": "q1a", "label": u"א", "text": u"הוכיחו כי AM = MB.",
                "figure_id": "q1_head", "given": [],
                "to_prove": [{"text": "$AM = MB$", "type": "equal_length",
                              "of": ["AM", "MB"]}],
                "to_construct": [], "hint_mode": "approved_hint",
                "approved_hint": u"אילו משולשים רואים בשרטוט?"}]}],
        "curriculum": {"grade": "9", "track": u"ט_רגילה",
                       "topic": "rectangle", "unit": u"מלבן",
                       "allowed_tools": [{"id": "thm.rectangle_props",
                                          "name": u"תכונות המלבן"}],
                       "not_yet_allowed": [{"id": "thm.rhombus_props",
                                            "name": u"תכונות המעוין"}]},
        "figures": [{
            "id": "q1_head", "svg": "figures/q1_head.svg", "question": "q1",
            "view": {"width_px": 200, "height_px": 120,
                     "viewbox": [200, 120], "data_to_svg": M},
            "objects": {
                "points": [
                    {"svg_id": "pt-A", "kind": "point", "name": "A",
                     "xy": [0.0, 0.0], "svg_xy": [20.0, 100.0]},
                    {"svg_id": "pt-B", "kind": "point", "name": "B",
                     "xy": [8.0, 0.0], "svg_xy": [180.0, 100.0]},
                    {"svg_id": "pt-C", "kind": "point", "name": "C",
                     "xy": [4.0, 4.0], "svg_xy": [100.0, 20.0]},
                    {"svg_id": "pt-M", "kind": "point", "name": "M",
                     "xy": [4.0, 0.0], "svg_xy": [100.0, 100.0]}],
                "segments": [
                    {"svg_id": "seg-AB", "kind": "segment", "name": "AB",
                     "xy": [[0.0, 0.0], [8.0, 0.0]],
                     "svg_xy": [[20.0, 100.0], [180.0, 100.0]]},
                    {"svg_id": "seg-AC", "kind": "segment", "name": "AC",
                     "svg_xy": [[20.0, 100.0], [100.0, 20.0]]},
                    {"svg_id": "seg-BC", "kind": "segment", "name": "BC",
                     "svg_xy": [[180.0, 100.0], [100.0, 20.0]]}],
                "polygons": [
                    {"svg_id": "poly-ABC", "kind": "polygon", "name": "ABC",
                     "svg_xy": [[20.0, 100.0], [180.0, 100.0],
                                [100.0, 20.0]]}],
                "marks": [
                    {"svg_id": "tick-1", "kind": "ticks", "role": "mark",
                     "svg_xy": [[20.0, 100.0], [100.0, 100.0]],
                     "ink_xy": [60.0, 100.0]},
                    {"svg_id": "ra-M", "kind": "right_angle", "role": "mark",
                     "svg_xy": [100.0, 100.0], "ink_xy": [94.0, 94.0]}],
                "labels": [
                    {"svg_id": "lbl-A", "kind": "label", "text": "A",
                     "for": "pt-A", "svg_xy": [8.0, 112.0]}]},
            "constraints": [
                {"type": "perpendicular", "of": ["AB", "CM"], "at": "M",
                 "status": "given", "marked": True, "mark_id": "ra-M"}],
            "visual_model": _fixture_vm(M)}],
    }


def _fixture_vm(M):
    """the figure's visual-model/v1 (§9): objects with roles and displays,
    the given perpendicular with its overlay, the goal AM = MB unmarked."""
    O = lambda i, t, nm, xy, sv, role="given": {
        "id": i, "svg_id": i, "type": t, "name": nm, "xy": xy,
        "svg_xy": sv, "role": role, "display": "initial"}
    return {
        "schema_version": "visual-model/v1", "id": "q1_head",
        "kind": "plane_geometry", "visual_support": "full",
        "question": "q1", "svg": "figures/q1_head.svg",
        "view": {"viewbox": [200, 120], "data_to_svg": M},
        "objects": [O("pt-A", "point", "A", [0.0, 0.0], [20.0, 100.0]),
                    O("pt-B", "point", "B", [8.0, 0.0], [180.0, 100.0]),
                    O("pt-C", "point", "C", [4.0, 4.0], [100.0, 20.0]),
                    O("pt-M", "point", "M", [4.0, 0.0], [100.0, 100.0]),
                    {"id": "hl-perp", "svg_id": None,
                     "type": "overlay_mark", "mark": "right_angle",
                     "on": ["seg-AB", "pt-M"], "for": "r-perp",
                     "role": "given", "display": "given_highlight"},
                    # v6.9 (K16): an engine figure's objects -- the id and
                    # the svg ids that draw it (a piece by its span)
                    {"id": "ang:BAC", "svg_id": None, "type": "angle",
                     "name": "BAC", "parts": [{"svg_id": "seg-AB"},
                                              {"svg_id": "seg-AC"}],
                     "role": "context", "display": "initial"},
                    {"id": "seg:AM", "svg_id": None, "type": "segment",
                     "name": "AM", "parts": [{"svg_id": "seg-AB",
                                              "span": ["A", "M"]}],
                     "role": "context", "display": "initial"}],
        "relations": [
            {"id": "r-perp", "type": "perpendicular", "of": ["AB", "CM"],
             "at": "M", "role": "given", "objects": ["pt-M"],
             "marked": True, "mark_id": "ra-M", "highlight": "hl-perp"},
            {"id": "r-goal", "type": "equal_length", "of": ["AM", "MB"],
             "role": "to_prove", "item": "q1a",
             "objects": ["pt-A", "pt-M", "pt-B"]}],
        "highlight_given": ["r-perp"], "aux": [],
        "actions": {"allowed": ["show", "highlight", "show_aux"],
                    "show": ["q1_head"], "highlight": ["r-perp"],
                    "show_aux": []}}


def _fixture_didactic():
    return {"schema": "didactic/v1", "package": "G7-T08", "level": "a",
            "items": {"q1a": {"hint_type": "guiding_question",
                              "exposure": 1, "requires_human_review": False,
                              "hint": u"אילו משולשים רואים בשרטוט?",
                              "approved": True, "approved_by": u"נועם"}}}


def _write(d, nj, svg=_SVG):
    os.makedirs(os.path.join(d, "figures"))
    dj = _fixture_didactic()
    if isinstance(nj, dict) and "_dj" in nj:
        fn = nj.pop("_dj")
        dj = fn(dj)
    # v6.10 K18: the engine map beside the figure (a case may edit / drop it)
    mfn = nj.pop("_map", None) if isinstance(nj, dict) else None
    # v6.10 fix r2 K23: a public spec beside the package (a case sets it)
    pub = nj.pop("_pub", None) if isinstance(nj, dict) else None
    if pub is not None:
        os.makedirs(os.path.join(d, "wspec"))
        with open(os.path.join(d, "wspec", "public_spec.json"), "w",
                  encoding="utf-8") as fh:
            json.dump(pub, fh, ensure_ascii=False)
    if dj is not None:
        with open(os.path.join(d, "didactic.json"), "w",
                  encoding="utf-8") as fh:
            json.dump(dj, fh, ensure_ascii=False)
    if nj is not None:
        with open(os.path.join(d, "noam-ai.json"), "w",
                  encoding="utf-8") as fh:
            json.dump(nj, fh, ensure_ascii=False)
    if svg is not None:
        with open(os.path.join(d, "figures", "q1_head.svg"), "w",
                  encoding="utf-8") as fh:
            fh.write(svg)
    if isinstance(nj, dict) and svg is not None and nj.get("figures") and             any(o.get("parts") for o in (nj["figures"][0].get(
                "visual_model") or {}).get("objects") or []):
        m = _fixture_map(nj, svg)
        m = mfn(m) if mfn else m
        if m is not None:
            with open(os.path.join(d, "figures", "q1_head.map.json"), "w",
                      encoding="utf-8") as fh:
                json.dump(m, fh, ensure_ascii=False)


def _pt(j, name):
    for o in j["figures"][0]["objects"]["points"]:
        if o["name"] == name:
            return o


def _fail_cases():
    """(name, rule it must be caught by, mutate json, svg text or None)."""
    def J(fn):
        def go(j):
            fn(j)
            return j
        return go
    F = lambda j: j["figures"][0]
    VM = lambda j: j["figures"][0]["visual_model"]
    it = lambda j: j["questions"][0]["items"][0]
    VO = lambda j, i: [o for o in VM(j)["objects"] if o["id"] == i][0]
    def _drop_perp(j):
        VM(j)["relations"] = [r for r in VM(j)["relations"]
                              if r["id"] != "r-perp"]
        VM(j)["objects"] = [o for o in VM(j)["objects"]
                            if o["id"] != "hl-perp"]
        VM(j)["highlight_given"] = []
        VM(j)["actions"]["highlight"] = []
    _lbl8 = {"svg_id": "pt-A", "kind": "label", "text": "8", "for": "AC",
             "svg_xy": [20.0, 100.0]}
    return [
        # v6.10 fix r2 K21 (hg-completeness): a marked given not offered
        ("K21 a marked given dropped from highlight_given", "K21",
         J(lambda j: (VM(j).__setitem__("highlight_given", []),
                      VM(j)["actions"].__setitem__("highlight", []))),
         _SVG, "r-perp"),
        ("K21 a marked given dropped from actions.highlight only", "K21",
         J(lambda j: VM(j)["actions"].__setitem__("highlight", [])), _SVG,
         "actions.highlight"),
        ("K21 a marked given's relation and overlay removed", "K21",
         J(_drop_perp), _SVG, "no given relation"),
        # v6.10 fix r2 K22 (label-for-integrity / R1-vm-for)
        ("K22 a numeric label re-tied (AB's '8' names AC)", "K22",
         J(lambda j: (VM(j)["relations"].append(
             {"id": "r-len", "type": "length", "of": "AB", "value": 8,
              "role": "given", "objects": ["pt-A", "pt-B"]}),
             F(j)["objects"]["labels"].append(dict(_lbl8)))), _SVG,
         "is the value of"),
        ("K22 the model's copy of a numeric label has no for", "K22",
         J(lambda j: (F(j)["objects"]["labels"].append(dict(_lbl8)),
                      VM(j)["objects"].append({
                          "id": "pt-A", "svg_id": "pt-A", "type": "label",
                          "text": "8", "role": "context",
                          "display": "initial"}))), _SVG, "has no `for`"),
        # v6.10 fix r2 K23 (R1-s1-consistent): the public text is printed
        ("K23 the public spec's text is not the printed text", "K23",
         J(lambda j: j.__setitem__("_pub", {"questions": [{
             "id": "q1", "text": u"נתון משולש ABC.", "items": [{
                 "id": "q1a", "text": u"הוכיחו כי AM = MC."}]}]})), _SVG,
         "q1a"),
        # v6.10 K17 (C1r2): the highlight IS the object
        ("K17 a part without its span paints the whole line", "K17",
         J(lambda j: VO(j, "seg:AM")["parts"][0].pop("span")), _SVG,
         "seg:AM"),
        ("K17 a span longer than the segment (extra ink)", "K17",
         J(lambda j: VO(j, "seg:AM")["parts"][0].update(span=["A", "B"])),
         _SVG, "extra ink"),
        ("K17 an angle that lost an arm", "K17",
         J(lambda j: VO(j, "ang:BAC").update(parts=[{"svg_id": "seg-AB"}])),
         _SVG, "missing"),
        ("K17 an extra part (another line)", "K17",
         J(lambda j: VO(j, "seg:AM")["parts"].append({"svg_id": "seg-BC"})),
         _SVG, "extra ink"),
        ("K17 an unplaceable mapping is refused", "K17",
         J(lambda j: VO(j, "seg:AM").update(name="AZ")), _SVG, "ambiguous"),
        # v6.10 K19 (C3): a typed-shape given offered by exactly what it states
        ("K19 a given isosceles triangle whose equal sides are not offered",
         "K19", J(lambda j: VM(j)["relations"].append(
             {"id": "r-iso", "type": "shape", "role": "given",
              "points": ["A", "B", "C"], "value": "isosceles",
              "text": u"\u25b3ABC \u05e9\u05d5\u05d5\u05d4\u05be"
                      u"\u05e9\u05d5\u05e7\u05d9\u05d9\u05dd"})),
         _SVG, "does not offer"),
        ("K19 a relation derived from a shape that is no given", "K19",
         J(lambda j: (VM(j)["relations"].append(
             {"id": "r-x-s1", "type": "parallel", "role": "given",
              "of": ["AB", "CM"], "from_given": "r-goal"}),
             VM(j)["highlight_given"].append("r-x-s1"))), _SVG,
         "no given shape"),
        # v6.10 K18 (E2): an engine figure ships ITS map
        ("K18 the map is missing", "K18",
         J(lambda j: j.update(_map=lambda m: None)), _SVG, "missing"),
        ("K18 the map of another figure", "K18",
         J(lambda j: j.update(_map=lambda m: dict(m, figure="q9_head"))),
         _SVG, "map of figure"),
        ("K18 the map's parts are not the model's", "K18",
         J(lambda j: j.update(_map=lambda m: (m["objects"]["seg:AM"][
             "parts"][0].update(span="whole"), m)[1])), _SVG, "parts"),
        ("K18 a map element with another tag", "K18",
         J(lambda j: j.update(_map=lambda m: (m["elements"]["seg-AB"].update(
             tag="path"), m)[1])), _SVG, "tag" if False else "<path>"),
        # v6.9 K16: object id -> parts
        ("K16 a part whose svg id is not in the SVG", "K16",
         J(lambda j: VO(j, "ang:BAC")["parts"].append({"svg_id": "seg-XY"})),
         _SVG),
        ("K16 a part hidden in the SVG", "K16", J(lambda j: None),
         _SVG.replace('<line id="seg-AC"', '<line id="seg-AC" '
                      'style="display:none"')),
        ("K16 a span over a point the model does not draw", "K16",
         J(lambda j: VO(j, "seg:AM")["parts"][0].update(span=["A", "Z"])),
         _SVG),
        ("K16 one object id names two objects", "K16",
         J(lambda j: VM(j)["objects"].append(dict(VO(j, "ang:BAC")))), _SVG),
        ("K16 an engine object with nothing to show", "K16",
         J(lambda j: VO(j, "ang:BAC").update(parts=[])), _SVG),
        ("noam-ai.json missing", "K1", None, _SVG),
        ("an answer on an item", "K2",
         J(lambda j: it(j).update(answer="$AM = 4$")), _SVG),
        ("a solution nested in a table", "K2",
         J(lambda j: j["questions"][0]["table"].update(
             solution=["3"])), _SVG),
        ("a hint on a question", "K2",
         J(lambda j: j["questions"][0].update(hint=u"שימו לב")), _SVG),
        ("figure code reference", "K2",
         J(lambda j: F(j).update(code="figures/q1_head.py")), _SVG),
        ("code_runnable flag", "K2",
         J(lambda j: F(j).update(code_runnable=True)), _SVG),
        ("a constraint's source", "K2",
         J(lambda j: F(j)["constraints"][0].update(source="derived")),
         _SVG),
        ("source_hash", "K2",
         J(lambda j: j.update(source_hash="ab" * 32)), _SVG),
        ("built_at", "K2",
         J(lambda j: j.update(built_at="2026-09-22T02:27:02")), _SVG),
        ("a files table", "K2",
         J(lambda j: j.update(files={"sheet.pdf": "x"})), _SVG),
        ("sha", "K2", J(lambda j: F(j).update(sha="x")), _SVG),
        ("sheet_id_prefix", "K2",
         J(lambda j: F(j).update(sheet_id_prefix="q1_head__")), _SVG),
        ("a report row", "K2",
         J(lambda j: j.update(report=[{"where": "q1"}])), _SVG),
        ("strict flag", "K2",
         J(lambda j: j.update(strict_figures=True)), _SVG),
        ("value /private/ path", "K3",
         J(lambda j: it(j).update(text="/private/tmp/x/level.py")), _SVG),
        ("value /Users/ path", "K3",
         J(lambda j: F(j).update(svg_note="/Users/noam/x")), _SVG),
        ("value .py", "K3",
         J(lambda j: F(j)["view"].update(frame="see make_fig.py")), _SVG),
        ("value source/ path", "K3",
         J(lambda j: F(j)["view"].update(frame="source/level_a")), _SVG),
        ("value 64-hex hash", "K3",
         J(lambda j: j["questions"][0].update(text="ab12" * 16)), _SVG),
        ("value 40-hex hash", "K3",
         J(lambda j: j["questions"][0].update(text="v " + "c0ffee12" * 5)),
         _SVG),
        ("SVG file missing", "K4", J(lambda j: None), None),
        ("svg_id absent from the SVG", "K5",
         J(lambda j: _pt(j, "A").update(svg_id="pt-Z")), _SVG),
        ("svg_id twice in the SVG", "K5", J(lambda j: None),
         _SVG.replace('<text id="lbl-A"', '<text id="pt-A"', 1)),
        ("object hidden by style display:none", "K5", J(lambda j: None),
         _SVG.replace('<circle id="pt-M"',
                      '<circle style="display:none" id="pt-M"', 1)),
        ("object hidden by visibility=hidden", "K5", J(lambda j: None),
         _SVG.replace('<circle id="pt-M"',
                      '<circle visibility="hidden" id="pt-M"', 1)),
        ("object inside a group with opacity 0", "K5", J(lambda j: None),
         _SVG.replace('<g transform="translate(100,20)">',
                      '<g opacity="0" transform="translate(100,20)">', 1)),
        ("to_prove names an undefined point", "K6",
         J(lambda j: it(j)["to_prove"][0].update(of=["AK", "KB"])), _SVG),
        # v6.13-noam: to_construct exempts only the point it makes
        ("given names a point nothing draws; to_construct makes another",
         "K6", J(lambda j: (it(j)["given"].append(
             {"text": u"שיעור x של K = 3"}), it(j).setdefault(
             "to_construct", []).append({"text": u"סימון W"}))), _SVG,
         "names K"),
        ("given names an undefined segment", "K6",
         J(lambda j: it(j)["given"].append(
             {"type": "parallel", "of": ["AB", "DE"]})), _SVG),
        ("to_prove names an undefined angle", "K6",
         J(lambda j: it(j)["to_prove"].append(
             {"type": "equal_angle",
              "of": [{"at": "A", "rays": ["B", "C"]},
                     {"at": "Q", "rays": ["B", "C"]}]})), _SVG),
        ("svg_xy 3 px off its element", "K7",
         J(lambda j: _pt(j, "B").update(svg_xy=[183.0, 100.0],
                                        xy=[8.15, 0.0])), _SVG),
        ("svg_xy of a transformed point ignores its translate", "K7",
         J(lambda j: None),
         _SVG.replace('translate(100,20)', 'translate(104,20)')),
        ("a mark off its ink with no ink_xy", "K7",
         J(lambda j: F(j)["objects"]["marks"][0].pop("ink_xy")), _SVG),
        ("a mark whose ink_xy is off its ink", "K7",
         J(lambda j: F(j)["objects"]["marks"][1].update(
             ink_xy=[80.0, 80.0])), _SVG),
        ("xy disagrees with svg_xy through data_to_svg", "K8",
         J(lambda j: _pt(j, "M").update(xy=[4.2, 0.0])), _SVG),
        ("item figure_id not a figure", "K9",
         J(lambda j: it(j).update(figure_id="q9_head")), _SVG),
        ("question figure_id not a figure", "K9",
         J(lambda j: j["questions"][0].update(figure_id="q2_head")), _SVG),
        ("package not a topic id", "K10",
         J(lambda j: j.update(package="z08")), _SVG),
        ("level not a/b/c", "K10", J(lambda j: j.update(level="x")), _SVG),
        ("item without to_prove", "K10",
         J(lambda j: it(j).pop("to_prove")), _SVG),
        # r1: K2 is a whitelist -- variant names are caught too
        ("key answer_text", "K2",
         J(lambda j: it(j).update(answer_text="4")), _SVG),
        ("key correct_answer", "K2",
         J(lambda j: it(j).update(correct_answer="4")), _SVG),
        (u"Hebrew key תשובה", "K2",
         J(lambda j: it(j).update({u"תשובה": "4"})), _SVG),
        ("key solution_steps", "K2",
         J(lambda j: it(j).update(solution_steps=["x"])), _SVG),
        ("key hint_text", "K2",
         J(lambda j: j["questions"][0].update(hint_text="x")), _SVG),
        ("answer-key dict 'key'", "K2",
         J(lambda j: j.update(key={"q1a": "4"})), _SVG),
        ("key md5", "K2", J(lambda j: F(j).update(md5="x")), _SVG),
        ("key generated_at", "K2",
         J(lambda j: j.update(generated_at="x")), _SVG),
        ("unknown key inside an object", "K2",
         J(lambda j: _pt(j, "A").update(value=4)), _SVG),
        ("unknown key inside view", "K2",
         J(lambda j: F(j)["view"].update(note="x")), _SVG),
        ("a dict hidden in a table cell", "K2",
         J(lambda j: j["questions"][0]["table"]["rows"][0].append(
             {"a": "4"})), _SVG),
        ("a claim that is a plain string", "K2",
         J(lambda j: it(j)["to_prove"].append("AM = MB")), _SVG),
        ("value 32-hex md5", "K3",
         J(lambda j: it(j).update(text="x " + "0cc175b9" * 4)), _SVG),
        ("value /home/ path", "K3",
         J(lambda j: it(j).update(text="see /home/noam/x.svg")), _SVG),
        ("value ~/Downloads path", "K3",
         J(lambda j: it(j).update(text="see ~/Downloads/x")), _SVG),
        ("value timestamp", "K3",
         J(lambda j: it(j).update(text="2026-09-22T03:08:50")), _SVG),
        ("given of an unknown type names undefined points", "K6",
         J(lambda j: it(j)["given"].append(
             {"type": "congruent", "of": ["XYZ", "ABC"]})), _SVG),
        ("given as plain text names an undefined point", "K6",
         J(lambda j: it(j)["given"].append("XY \u22a5 AB")), _SVG),
        ("claim text names an undefined point", "K6",
         J(lambda j: it(j)["to_prove"].append(
             {"text": "$AK = KB$"})), _SVG),
        ("svg_xy dropped from a point", "K7",
         J(lambda j: _pt(j, "A").pop("svg_xy")), _SVG),
        ("xy dropped from a point", "K8",
         J(lambda j: _pt(j, "A").pop("xy")), _SVG),
        # v6.12 fix_r1 (M1-readoff): a read-off figure keeps its data frame
        ("a number-line figure of a find question keeps xy / data_to_svg",
         "K24", J(lambda j: (F(j)["visual_model"].update(kind="number_line"),
                             it(j)["to_prove"].append(
                                 {"type": "find", "quantity": "coordinates",
                                  "of": "M", "text": u"שיעורי הנקודה M"}))),
         _SVG),
        # v6.7.1-noam: the didactic record stays private (K11)
        ("didactic key hint_type on an item", "K11",
         J(lambda j: it(j).update(hint_type="construction")), _SVG),
        ("didactic key exposure on a figure", "K11",
         J(lambda j: F(j).update(exposure=2)), _SVG),
        ("didactic key requires_human_review on a question", "K11",
         J(lambda j: j["questions"][0].update(requires_human_review=True)),
         _SVG),
        ("didactic.json embedded whole", "K11",
         J(lambda j: j.update(didactic=_fixture_didactic())), _SVG),
        ("the didactic/v1 schema as a value", "K11",
         J(lambda j: it(j).update(text="didactic/v1")), _SVG),
        # K12 hints that are not approved
        ("hint_mode that is not a mode", "K12",
         J(lambda j: it(j).update(hint_mode="free_hint")), _SVG),
        ("approved_hint under hint_mode guiding_question", "K12",
         J(lambda j: it(j).update(hint_mode="guiding_question")), _SVG),
        ("hint_mode approved_hint with no text", "K12",
         J(lambda j: it(j).pop("approved_hint")), _SVG),
        ("approved_hint the didactic.json did not approve", "K12",
         J(lambda j: j.update(_dj=lambda dj: (dj["items"]["q1a"].update(
             approved=False), dj)[1])), _SVG),
        ("approved without approved_by (not a human)", "K12",
         J(lambda j: j.update(_dj=lambda dj: (dj["items"]["q1a"].pop(
             "approved_by"), dj)[1])), _SVG),
        ("approved_hint text differs from the approved one", "K12",
         J(lambda j: it(j).update(approved_hint=u"AM = MB כי המשולשים "
                                                u"חופפים")), _SVG),
        ("no didactic.json to prove the approval", "K12",
         J(lambda j: j.update(_dj=lambda dj: None)), _SVG),
        ("an unapproved hint text inside an item text", "K12",
         J(lambda j: (j.update(_dj=lambda dj: (dj["items"].update(q1b={
             "hint": u"המשולשים AMC ו-BMC חופפים", "approved": False}),
             dj)[1]), it(j).update(text=u"הוכיחו. המשולשים AMC ו-BMC "
                                        u"חופפים"))), _SVG),
        # K13 the givens overlay only from given (visual_model, §9)
        ("a highlight on the to_prove AM = MB", "K13",
         J(lambda j: VM(j)["highlight_given"].append("r-goal")), _SVG),
        ("a highlight on a relation that is no given", "K13",
         J(lambda j: (VM(j)["relations"].append(
             {"id": "r-x", "type": "parallel", "of": ["AB", "AC"],
              "role": "given"}), VM(j)["highlight_given"].append("r-x"))),
         _SVG),
        ("unknown key in a visual_model object", "K2",
         J(lambda j: VM(j)["objects"][0].update(colour="red")), _SVG),
        ("an svg drawing string inside the visual_model", "K2",
         J(lambda j: VM(j).update(svg_code="<path d='M0 0'/>")), _SVG),
        # K14 the visual model's closed contract
        ("a figure with no visual_model", "K14",
         J(lambda j: F(j).pop("visual_model")), _SVG),
        ("an action outside show / highlight / show_aux", "K14",
         J(lambda j: VM(j)["actions"]["allowed"].append("draw")), _SVG),
        ("highlight beyond highlight_given", "K14",
         J(lambda j: VM(j)["actions"]["highlight"].append("r-goal")), _SVG),
        ("an unsupported visual that ships an SVG", "K14",
         J(lambda j: j.update(visuals=[{
             "schema_version": "visual-model/v1", "id": "q1_visual",
             "kind": "probability_tree", "visual_support": "unsupported",
             "question": "q1", "svg": "figures/q1_head.svg", "objects": [],
             "relations": [], "highlight_given": [], "aux": [],
             "actions": {"allowed": ["show"], "show": [], "highlight": [],
                         "show_aux": []}}])), _SVG),
        ("an aux patch shown at once", "K14",
         J(lambda j: VM(j)["aux"].append(
             {"id": "q1_aux1", "svg": "figures/q1_aux1.svg",
              "label": u"שרטוט עזר", "reveal": "always", "step": "x",
              "ops": []})), _SVG),
        ("unknown key in the curriculum block", "K2",
         J(lambda j: j["curriculum"].update(hint_policy="x")), _SVG),
        # ---- r1: each check site pinned by the fragment of its message --
        ("pin K12 hint_mode that is not a mode", "K12",
         J(lambda j: it(j).update(hint_mode="free_hint")), _SVG,
         "is not one of"),
        ("pin K13 a given-role relation that is the to_prove", "K13",
         J(lambda j: (VM(j)["relations"].append(
             {"id": "r-g2", "type": "equal_length", "of": ["AM", "MB"],
              "role": "given"}), VM(j)["highlight_given"].append("r-g2"))),
         _SVG, "marks a to_prove"),
        # r2 m2: the role branch on its own -- the key IS a given, so only
        # the role says it is no given relation
        ("R2-m2 a highlight on a context-role copy of the given", "K13",
         J(lambda j: (VM(j)["relations"].append(
             {"id": "r-c2", "type": "perpendicular", "of": ["AB", "CM"],
              "at": "M", "role": "context"}),
             VM(j)["highlight_given"].append("r-c2"))), _SVG,
         "a context relation"),
        ("M1 an earlier item's result (from_item) in the overlay", "K13",
         J(lambda j: (j["questions"][0]["items"].append(
             {"id": "q1b", "label": u"ב", "text": u"חשבו את AM.",
              "figure_id": "q1_head", "to_prove": [], "to_construct": [],
              "given": [{"type": "equal_length", "of": ["AM", "MB"],
                         "from_item": "q1a", "text": "AM = MB"}]}),
             F(j).update(item="q1b"), VM(j).update(item="q1b"),
             VM(j)["relations"].append(
                 {"id": "r-g2", "type": "equal_length", "of": ["AM", "MB"],
                  "role": "given", "from_item": "q1a"}),
             VM(j)["highlight_given"].append("r-g2"))), _SVG,
         "carried with from_item"),
        ("pin K14 a visual_model naming another figure", "K14",
         J(lambda j: VM(j).update(id="q9_head")), _SVG,
         "its visual_model names"),
        ("pin K14 schema_version", "K14",
         J(lambda j: VM(j).update(schema_version="v0")), _SVG,
         "schema_version"),
        ("pin K14 visual_support", "K14",
         J(lambda j: VM(j).update(visual_support="most")), _SVG,
         "visual_support"),
        ("pin K14 an aux op outside add / show / highlight", "K14",
         J(lambda j: (VM(j)["aux"].append(
             {"id": "q1_aux1", "svg": "figures/q1_aux1.svg",
              "label": u"שרטוט עזר", "reveal": "on_request", "step": "x",
              "ops": [{"op": "draw"}]}),
             VM(j)["actions"]["show_aux"].append("q1_aux1"))), _SVG,
         "aux op"),
        # v6.7.2-noam: a find target never carries its value
        ("v672 a find target with its value", "K15",
         J(lambda j: j["questions"][0]["items"][0]["to_prove"].append(
             {"type": "find", "quantity": "length", "of": "AM",
              "text": u"אורך AM", "value": 5})), _SVG, "carries its value"),
        # r1 T4 / T2: the public words, the unit, the table cell
        ("v672r1 a find target's unit carries the value", "K15",
         J(lambda j: j["questions"][0]["items"][0]["to_prove"].append(
             {"type": "find", "quantity": "length", "of": "AM",
              "text": u"אורך AM", "unit": u"5 ס\"מ"})), _SVG,
         "carries a number"),
        ("v672r1 a find target's what prints a number", "K15",
         J(lambda j: j["questions"][0]["items"][0]["to_prove"].append(
             {"type": "find", "quantity": "length", "of": "AM",
              "text": u"אורך AM", "what": u"התשובה 5"})), _SVG,
         "which the item's text does not"),
        ("v672r1 the table shows the target cell's value", "K15",
         J(lambda j: (j.setdefault("visuals", []).append(
             {"schema_version": "visual-model/v1", "id": "q1_table",
              "kind": "table", "visual_support": "partial",
              "question": j["questions"][0]["id"], "svg": None,
              "objects": [{"id": "q1_table-r1c1", "svg_id": None,
                           "type": "cell", "row": 1, "col": 1,
                           "value": "12", "role": "context",
                           "display": "initial"}],
              "relations": [], "highlight_given": [], "aux": [],
              "actions": {"allowed": ["show", "highlight", "show_aux"],
                          "show": ["q1_table"], "highlight": [],
                          "show_aux": []}}),
             j["questions"][0]["items"][0]["to_prove"].append(
                 {"type": "find", "quantity": "cell",
                  "of": "q1_table-r1c1", "text": u"התא r1c1"}))), _SVG,
         "the cell the item asks to find"),
        # r2 M1: the answer on the target's own model object
        ("v672r2 the find target's model object carries the value", "K15",
         J(lambda j: _k15_obj(j, VM(j), "value", "5")), _SVG,
         "on the object the item asks to find"),
        ("v672r2 the find target's model object carries a label 5", "K15",
         J(lambda j: _k15_obj(j, VM(j), "label", "5")), _SVG,
         "on the object the item asks to find"),
    ]


def _k15_obj(j, vm, key, val):
    it = j["questions"][0]["items"][0]
    it["to_prove"].append({"type": "find", "quantity": "length",
                           "of": "AM", "text": u"אורך AM"})
    ob = vm["objects"][0]
    vm["relations"].append({"id": "r-find-AM", "type": "find",
                            "role": "to_prove", "item": it["id"],
                            "quantity": "length", "of": "AM",
                            "text": u"אורך AM", "objects": [ob["id"]]})
    ob[key] = val


# ---- K25 fixtures (v6.14 fix_r1, W-META-LINES-3) ---------------------------
_K25_G = u"ההפרש בין הערכים של שני קווי רשת סמוכים על ציר x"
_K25_T = u"המספר שמייצגת הנקודה M"
_K25_FG, _K25_FT = "q1:interval_value(axis:x)#g", "q1a:coordinate(M,axis:n)#t"
_K25_FX = "q1a:interval_value(axis:x)#t"


def _k25_base(j, pub=True):
    """the fixture with the three kinds of line a spec level ships: a given
    line with its printed value (q1: the grid step 1/2), a number-line point
    target and a grid-step target (q1a) -- each linked to its fact, each
    fact printed by its row's bound text -- and the public spec beside it"""
    q, it = j["questions"][0], j["questions"][0]["items"][0]
    q["given"].append({"text": _K25_G + u" = 0.5", "facts": [_K25_FG]})
    it["to_prove"] += [{"text": _K25_T, "facts": [_K25_FT]},
                       {"text": _K25_G, "facts": [_K25_FX]}]
    if pub:
        j["_pub"] = {
            "entities": [{"id": "M", "kind": "point", "name": "M"},
                         {"id": "axis:n", "kind": "axis", "name": "n"},
                         {"id": "axis:x", "kind": "axis", "name": "x"}],
            "facts": [
                {"id": _K25_FG, "item": "q1", "rel": "interval_value",
                 "role": "given", "args": ["axis:x"], "value": "1/2"},
                {"id": _K25_FT, "item": "q1a", "rel": "coordinate",
                 "role": "target", "args": ["M", "axis:n"]},
                {"id": _K25_FX, "item": "q1a", "rel": "interval_value",
                 "role": "target", "args": ["axis:x"]}],
            "questions": [{
                "id": "q1", "text": q["text"],
                "given_lines": [_K25_G + u" = 0.5"],
                "bound": [{"text": q["text"], "prints": [_K25_FG],
                           "bind": []}],
                "items": [{
                    "id": "q1a", "text": it["text"], "given_lines": [],
                    "bound": [{"text": it["text"], "bind": [],
                               "prints": [_K25_FT, _K25_FX]}],
                    "targets": [{"id": _K25_FT, "description": _K25_T},
                                {"id": _K25_FX,
                                 "description": _K25_G}]}]}]}
    return j


def _k25_fail_cases():
    """(name, rule, mutate, svg, fragment) -- W-META-LINES-3's condition"""
    def K(fn, pub=True):
        def go(j):
            _k25_base(j, pub)
            fn(j)
            return j
        return go
    it = lambda j: j["questions"][0]["items"][0]
    tp = lambda j, i: it(j)["to_prove"][-2 + i]     # 0: the point, 1: grid
    qg = lambda j: j["questions"][0]["given"][-1]
    pq = lambda j: j["_pub"]["questions"][0]
    return [
        ("K25 a target line lost its link (no facts)", "K25",
         K(lambda j: tp(j, 0).pop("facts")), _SVG, "not ONE fact"),
        ("K25 a target line links a fact the public spec lacks", "K25",
         K(lambda j: tp(j, 0).update(facts=["q1a:coordinate(Z,axis:n)#t"])),
         _SVG, "not ONE fact"),
        ("K25 a target line links two facts", "K25",
         K(lambda j: tp(j, 0).update(facts=[_K25_FT, _K25_FX])), _SVG,
         "not ONE fact"),
        ("K25 a hint added to a target line", "K25",
         K(lambda j: tp(j, 0).update(text=_K25_T + u" (היא בין 2 ל־3)")),
         _SVG, "hint"),
        ("K25 a target line states a value (the answer)", "K25",
         K(lambda j: tp(j, 1).update(text=_K25_G + u" = 0.5")), _SVG,
         "hint"),
        ("K25 a given line states another value than printed", "K25",
         K(lambda j: qg(j).update(text=_K25_G + u" = 2")), _SVG, "hint"),
        ("K25 a target line names another point than its fact", "K25",
         K(lambda j: tp(j, 0).update(text=u"המספר שמייצגת הנקודה A")),
         _SVG, "not the line of"),
        ("K25 a to_prove line restates a GIVEN fact", "K25",
         K(lambda j: tp(j, 1).update(facts=[_K25_FG])), _SVG,
         "of role given"),
        ("K25 a given line restates a TARGET (a conclusion as given)",
         "K25", K(lambda j: j["questions"][0]["given"].append(
             {"text": _K25_T, "facts": [_K25_FT]})), _SVG, "of role target"),
        ("K25 a line whose fact its row does not print", "K25",
         K(lambda j: pq(j)["items"][0]["bound"][0].update(
             prints=[_K25_FX])), _SVG, "does not print"),
        ("K25 a value key on a target line", "K25",
         K(lambda j: tp(j, 0).update(value=3)), _SVG, "beyond the line"),
        ("K25 a line the public spec's scope does not list", "K25",
         K(lambda j: pq(j).update(given_lines=[])), _SVG,
         "not a line the public spec"),
        ("K25 a line as a to_construct", "K25",
         K(lambda j: it(j)["to_construct"].append(
             {"text": _K25_T, "facts": [_K25_FT]})), _SVG,
         "never a construction"),
        ("K25 the lines on a level with no public spec (no source id)",
         "K25", K(lambda j: None, pub=False), _SVG, "no public spec"),
        ("K25 a builder ∥ axis given its question does not print", "K25",
         lambda j: (j["questions"][0]["given"].append(
             {"text": u"AB ∥ axis-x", "type": "parallel",
              "of": ["AB", "axis-x"]}), j)[1], _SVG, "only the typed ∥"),
        ("K25 a visual_model relation in the wording no claim states",
         "K25", K(lambda j: j["figures"][0]["visual_model"]["relations"]
                  .append({"id": "r-statement-C", "type": "statement",
                           "role": "to_prove", "item": "q1a",
                           "text": u"המספר שמייצגת הנקודה C",
                           "objects": []})), _SVG, "no to_prove claim"),
    ]


def run_fixtures():
    tmp = tempfile.mkdtemp(prefix="noamchk_")
    ok, n = True, 0
    try:
        d = os.path.join(tmp, "pass")
        _write(d, _fixture_json())
        errs, _ = check_level(d)
        n += 1
        print("  %-62s %s %s" % ("PASS fixture: a clean level", "PASS" if not
                                 errs else "FAIL", errs[:3]))
        ok = ok and not errs
        # v6.13-noam: a point to plot (to_construct "סימון W") may be named
        # by the question's givens before any figure draws it
        j = _fixture_json()
        j["questions"][0]["items"][0]["given"].append(
            {"text": u"שיעור x של W = 3"})
        j["questions"][0]["items"][0].setdefault("to_construct", []).append(
            {"text": u"סימון W"})
        d = os.path.join(tmp, "pass_plot")
        _write(d, j)
        errs, _ = check_level(d)
        n += 1
        print("  %-62s %s %s" % ("PASS fixture: a given names a point to plot",
                                 "PASS" if not errs else "FAIL", errs[:3]))
        ok = ok and not errs
        # v6.14 fix_r1 (K25): the W-META-LINES-3 lines linked to the facts
        # their rows print pass
        d = os.path.join(tmp, "pass_k25")
        _write(d, _k25_base(_fixture_json()))
        errs, _ = check_level(d)
        n += 1
        print("  %-62s %s %s" % ("PASS fixture: W-META-LINES-3 lines linked "
                                 "to printed facts", "PASS" if not errs
                                 else "FAIL", errs[:3]))
        ok = ok and not errs
        # the three levels together, and a repeated level
        dd = []
        for lv in LEVELS:
            j = _fixture_json()
            j["level"] = lv
            p = os.path.join(tmp, "lv_" + lv)
            _write(p, j)
            dd.append(p)
        tot = check_dirs(dd)
        n += 1
        print("  %-62s %s" % ("PASS fixture: a, b, c of one package",
                              "PASS" if tot == 0 else "FAIL"))
        ok = ok and tot == 0
        j = _fixture_json()
        j["package"] = "G7-T09"
        p = os.path.join(tmp, "other")
        _write(p, j)
        tot = check_dirs([dd[0], p])
        n += 1
        print("  %-62s %s" % ("FAIL fixture: two packages across folders "
                              "(K10)", "PASS" if tot else "FAIL"))
        ok = ok and bool(tot)
        for k, case in enumerate(_fail_cases() + _k25_fail_cases()):
            # r1: an optional 5th element is a fragment the error must
            # carry, so a case pins ITS check site and no other
            name, rule, fn, svg = case[:4]
            frag = (list(case[4:]) or [None])[0]
            p = os.path.join(tmp, "f%d" % k)
            j = _fixture_json()
            _write(p, fn(j) if fn else None, svg)
            errs, _ = check_level(p)
            caught = any(e.startswith(rule + " ") and
                         (frag is None or frag in e) for e in errs)
            n += 1
            print("  %-62s %s %s" % (("FAIL fixture (%s): %s" % (rule, name))
                                     [:62], "PASS" if caught else "FAIL",
                                     "" if caught else errs[:2]))
            ok = ok and caught
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print("selfcheck_noam_package fixtures: %d checks, %s"
          % (n, "ALL PASS" if ok else "FAILURES"))
    return ok


if __name__ == "__main__":
    if len(sys.argv) > 1:
        sys.exit(1 if check_dirs(sys.argv[1:]) else 0)
    sys.exit(0 if run_fixtures() else 1)
