# -*- coding: utf-8 -*-
u"""gate_situation -- CHANGED SITUATION, the narrow exact detector (v6.16.1,
BRIEF_V6161 T3; Codex review v6.16 finding 3).

THE AUTHOR'S RULE (W-FIGURE-DENSITY): "Every sub-item whose situation
differs (another function, other data, another pie or shape) gets its own
figure." G82 / G83 check that a question HAS a figure; neither checks that
the figure it prints for an item is the item's situation. v6.16 shipped
G9-T06 b 21ב (p = 5) under q21_head drawn for p = 1, and a 21ג (the line
y = 36) under q21_head drawn with y = 16.

WHAT IS DETECTED (spec path only; exact, no heuristics). For every item of a
spec question whose question has a GRAPH head figure H, and which prints no
figure of its own (the item's "figure" is absent or is H):

  CS1_PARAM_CHANGED  a math island of the item is exactly "$v = n$" -- one
      lower-case parameter letter (not x / y), "=", one number -- with v
      bound to var:v and n bound to anything but a graph part of H, while a
      block of the SAME question binds a printed number to the graph part
      "H/curve:C/v" of a curve C that H DRAWS, and n differs from C's v.
      (G9-T06 b 21ב: "$p = 5$"; 21א binds its "1" to q21_head/curve:P/p.)
  CS2_LINE_CHANGED   a math island of the item is exactly "$y = n$" (or
      "$x = n$") with the letter bound to axis:y (axis:x) and n bound to
      anything but a graph part of H, while H DRAWS a constant line
      y = b (line, m = 0) -- or a vertical line x = c -- whose b (c) a block
      of the same question binds to "H/curve:C/b" ("/x"), and n differs.
      (G9-T06 a 21ג: "$y = 36$"; the stem binds its "16" to
      q21_head/curve:L/b.)

A finding is FAIL unless the item is listed in `exempt` ({item id: reason},
the reason printed with the finding as EXEMPT). An item with its own figure
is never a finding (whether that figure is right is the engine's and the
corpus's business: empty / givens-only, MUST_NOT_DRAW).

WHAT IS NOT DETECTED (documented limits -- REVIEW by eye / the author):
  * a whole new equation of another form under a head that draws a
    different curve ("$y = 2x + 7$" under G8-T15 b q11's worked-example line
    y = 3x - 5), a function given in words, a shift described in words;
  * a symbolic value ("$y = m$", "$p = a$") -- the general case;
  * other data of a pie, a table or a shape (a new whole, other sectors);
  * builder-path questions (no bindings), and a head whose parameter value
    is printed but not bound to the graph part (value-only binding);
  * whether an own figure is large enough for the new situation.

    python3 gate_situation.py <level dir | level_spec.json> [...] [--json]
    exit 0: PASS on every argument; 1: a FAIL; 2: an input that cannot be
    read.
"""
import json
import os
import re
import sys
from fractions import Fraction

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

from wspec import schema_bound as SB             # noqa: E402

PASS, FAIL, EXEMPT = "PASS", "FAIL", "EXEMPT"
GATE = "CS"                     # changed situation
_ISLAND = re.compile(r"(?<!\\)\$([^$]*)\$")
_ASSIGN = re.compile(u"^\\s*([a-z])\\s*=\\s*([\u2212+\\-]?\\d+(?:\\.\\d+)?)\\s*$")
_GRAPH_REF = re.compile(r"^(?P<fig>[^/]+)/(?P<obj>curve:[^/]+)/(?P<part>[^/]+)$")


def _val(tok):
    try:
        v = SB.atom_value("number", tok)
    except Exception:                               # noqa: BLE001
        return None
    return v if isinstance(v, Fraction) else None


def _num(v):
    try:
        return Fraction(str(v))
    except (ValueError, ZeroDivisionError, TypeError):
        return None


def _segments(scope):
    """the bound blocks of one question / item text: [block]"""
    out = []
    for seg in scope.get("text") or []:
        if isinstance(seg, dict) and isinstance(seg.get("bound"), dict):
            out.append(seg["bound"])
    return out


def assignments(block):
    """[(letter, number token, letter binding, number binding)] of the math
    islands of a bound block that are exactly '<letter> = <number>'."""
    text = block.get("text")
    bind = block.get("bind")
    if not isinstance(text, str) or not isinstance(bind, list):
        return []
    if len(SB.atoms(text)) != len(bind):
        return []                       # G80 / schema say why; not ours
    out = []
    for m in _ISLAND.finditer(text):
        if not _ASSIGN.match(SB._untex(m.group(1))):
            continue
        at = SB.atoms(m.group(0))
        if [k for k, _t in at] != ["var", "number"]:
            continue
        i = len(SB.atoms(text[:m.start()]))
        out.append((at[0][1], at[1][1], bind[i], bind[i + 1]))
    return out


def _graph_ref(b):
    g = b.get("graph") if isinstance(b, dict) else None
    m = _GRAPH_REF.match(g) if isinstance(g, str) else None
    return (m.group("fig"), m.group("obj"), m.group("part")) if m else None


def _drawn_curves(fig):
    """{curve id: curve record} of the curves a graph figure DRAWS"""
    g = fig.get("graph") if isinstance(fig, dict) else None
    if not isinstance(g, dict):
        return {}
    return dict((c.get("id"), c) for c in g.get("curves") or []
                if isinstance(c, dict) and c.get("drawn", True) is not False)


def head_values(q, head_id, head_fig):
    """{(curve id, part): value} -- the parameters of H's DRAWN curves that
    a block of question q binds a printed number to ('H/curve:C/part')."""
    drawn = _drawn_curves(head_fig)
    out = {}
    for sc in [q] + [it for it in q.get("items") or []
                     if isinstance(it, dict)]:
        for blk in _segments(sc):
            for b in blk.get("bind") or []:
                r = _graph_ref(b)
                if not r or r[0] != head_id or r[1] not in drawn:
                    continue
                v = _num(drawn[r[1]].get(r[2]))
                if v is not None:
                    out[(r[1], r[2])] = v
    return out


def _finding(code, q, it, head_id, letter, tok, old, cid, exempt):
    why = (exempt or {}).get(it.get("id"))
    return {"code": code, "status": EXEMPT if why else FAIL,
            "question": q.get("id"), "item": it.get("id"),
            "head": head_id, "printed": u"%s = %s" % (letter, tok),
            "head_value": u"%s = %s" % (letter, old), "curve": cid,
            "why": (u"%s prints %s = %s but prints no figure of its own; "
                    u"its figure %s draws %s with %s = %s" % (
                        it.get("id"), letter, tok, head_id, cid, letter,
                        old)) + (u" -- EXEMPT: %s" % why if why else u"")}


def check_spec(spec, exempt=None):
    """the CS check of one wspec spec. exempt: {item id: reason}.
    -> {"gate", "status", "findings", "n_items", "n_heads"}"""
    figs = dict((f.get("id"), f) for f in spec.get("figures") or []
                if isinstance(f, dict))
    findings, n_items, n_heads = [], 0, 0
    for q in spec.get("questions") or []:
        if not isinstance(q, dict):
            continue
        head_id = q.get("figure")
        head = figs.get(head_id)
        if not head_id or not isinstance((head or {}).get("graph"), dict):
            continue
        n_heads += 1
        hv = head_values(q, head_id, head)
        drawn = _drawn_curves(head)
        for it in q.get("items") or []:
            if not isinstance(it, dict):
                continue
            own = it.get("figure")
            if own and own != head_id:
                continue
            n_items += 1
            for blk in _segments(it):
                for letter, tok, lb, nb in assignments(blk):
                    r = _graph_ref(nb)
                    if r and r[0] == head_id:
                        continue            # the head's own printed value
                    n = _val(tok)
                    if n is None:
                        continue
                    ent = lb.get("entity") if isinstance(lb, dict) else None
                    if letter not in ("x", "y") and ent == "var:%s" % letter:
                        for (cid, part), old in sorted(hv.items()):
                            if part == letter and old != n:
                                findings.append(_finding(
                                    "CS1_PARAM_CHANGED", q, it, head_id,
                                    letter, tok, old, cid, exempt))
                    elif letter in ("x", "y") and ent == "axis:%s" % letter:
                        for (cid, part), old in sorted(hv.items()):
                            c = drawn.get(cid) or {}
                            const = (letter == "y" and part == "b" and
                                     c.get("fn") == "line" and
                                     _num(c.get("m")) == 0) or (
                                letter == "x" and part == "x" and
                                c.get("fn") == "vline")
                            if const and old != n:
                                findings.append(_finding(
                                    "CS2_LINE_CHANGED", q, it, head_id,
                                    letter, tok, old, cid, exempt))
    st = FAIL if any(f["status"] == FAIL for f in findings) else PASS
    return {"gate": GATE, "status": st, "findings": findings,
            "n_items": n_items, "n_heads": n_heads}


def load_spec(path):
    """a wspec spec from a delivered level dir (source/level_spec.json), a
    level_spec.json ({"spec": ...}) or a bare spec file"""
    if os.path.isdir(path):
        path = os.path.join(path, "source", "level_spec.json")
    with open(path, encoding="utf-8") as fh:
        d = json.load(fh)
    return d.get("spec") if isinstance(d.get("spec"), dict) else d


def line(name, rep):
    fl = [f for f in rep["findings"] if f["status"] == FAIL]
    ex = [f for f in rep["findings"] if f["status"] == EXEMPT]
    return u"%s %s: %s (%d items under %d graph heads; %d FAIL, %d EXEMPT)%s" % (
        GATE, name, rep["status"], rep["n_items"], rep["n_heads"], len(fl),
        len(ex), "".join(u"\n    %s %s %s" % (f["status"], f["code"], f["why"])
                         for f in rep["findings"]))


def main(argv):
    as_json = "--json" in argv
    paths = [a for a in argv if a != "--json"]
    if not paths:
        print(__doc__)
        return 2
    rc, out = 0, {}
    for p in paths:
        try:
            rep = check_spec(load_spec(p))
        except (OSError, ValueError, KeyError) as e:
            print("CS %s: cannot read (%s)" % (p, e))
            rc = max(rc, 2)
            continue
        out[p] = rep
        if not as_json:
            print(line(p, rep))
        if rep["status"] == FAIL:
            rc = max(rc, 1)
    if as_json:
        print(json.dumps(out, ensure_ascii=False, indent=1))
    return rc


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
