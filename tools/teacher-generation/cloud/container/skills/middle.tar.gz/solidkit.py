# -*- coding: utf-8 -*-
r"""solidkit — v6.4. shapekit's pattern in three dimensions: every solid a
ז׳–ט׳ sheet needs, built FROM ITS DATA, drawn in ONE cabinet projection, with
the hidden edges COMPUTED and the volume/surface area coming from the same
numbers the picture came from.

WHY THIS FILE EXISTS
--------------------
The skill had no solid at all. A sheet that needed a prism wrote its own kit:
`P/regen/work/z47_a/level.py` (PRISMKIT) is 470 lines of package-local
drawing — a projection constant, a visibility test, a fit loop, a
label-inside-a-face search, a dimension line with barbs, an italic rule — all
of it done by hand because `figkit.Figure` draws in two dimensions and nothing
above it knew what a solid was. Everything that file had to do by hand is a
requirement here, and this file is where it lives from now on.

    from solidkit import box, cube, prism, cylinder, cone, pyramid, finish

    s, d = box(9, 4, 5, pose=('base', 0), fam='solid.box+names')
    d.names()
    d.space_diagonal('A', 'G', via='ABCD', label='d')
    print(finish(s, 'solid.box+names+spacediag(AG)'))

THE PROJECTION (one convention for the whole skill)
---------------------------------------------------
CABINET oblique, fixed: the front plane (z = 0) is drawn TRUE SIZE, the depth
axis runs at 45° and is drawn at HALF length. `CAB_DEG` and `CAB_K` are module
constants, not parameters — only `side` ('right' or 'left') varies, and it
only mirrors the depth direction.

    project((x, y, z)) = (x + s·K·cos45·z,  y + K·sin45·z)        s = ±1

These are MATHS coordinates (y up), the frame `euclid._Fig` and this file both
work in; the flip to SVG's y-down happens once, in `Scene._render`. The
author's sketch wrote `sy = y − z·K·sin45` with the comment "SVG y grows
down", which is a statement about the wrong layer: in the maths frame that
sends the depth axis DOWN and to the right, and the box comes out seen from
below. Rendered and looked at (v64/look/solids/probe_projection.png): depth
runs UP and to the RIGHT, behind the front face, at half length.

WHAT IS COMPUTED, NEVER TABULATED
---------------------------------
Hidden edges come from the face normals (convex solids) or from true
occlusion (everything else), for the pose the figure is actually in. The
author's brief proposed a fixed per-shape table — "at this fixed camera angle
a box always hides the same three edges". That is true of a box standing on
its base and false of everything else: a prism lying on a lateral face, a
trough (an inverted prism), a cube rolled by a yaw of 30° and an L-prism each
hide a different set, and a table cannot know which. `Solid.hidden_edges()`
recomputes per pose, and `selfcheck_solidkit.py` proves it by rendering the
same solid at several poses and reading the dashes back out of the SVG.

POSES
-----
A solid is placed like a real object: `pose=(rest, yaw)` — which face rests on
the ground, and how far it is turned about the vertical. `pose='base'` is the
canonical rest face; `pose=('ABFE', 30)` lays the solid on face ABFE and turns
it 30°. The pose is a parameter exactly as `rotate=` is in 2D, and every
add-on is computed in the POSED frame, so the whole figure turns as one rigid
body.

RULES (shapekit's list, which came from euclid.py's doctrine)
-------------------------------------------------------------
1. The data fixes the drawing. `box(9, 4, 5)` draws 9 : 5 : 4·K and
   `selfcheck_solidkit` re-measures it from the finished SVG. Data that
   cannot be a solid is REFUSED with a message naming data that would work.
2. `fam=` is required on every call (G76 counts objects by it).
3. Every computed point is worked out in the posed 3D frame, before the
   projection, so add-ons rotate with the solid.
4. Latin letters, digits, ° and U+2212 in the SVG; Hebrew stays in the HTML.
5. Nothing here weakens an existing check: every figure goes through
   `figkit.Figure.render` (label solver, font floor, svgcheck) and
   `figkit_plus.assert_unstruck`, and carries `<!--fam:...-->` plus
   `<!--proj:cabinet45:side-->`.
6. A refusal names a call that RENDERS. Never "leave the label out".
"""
import copy
import math
import re
import sys
import time

import shapekit
from euclid import _tag
from figkit import Figure
from figkit_plus import assert_unstruck

__all__ = [
    # projection + 3D maths
    "project", "CAB_DEG", "CAB_K", "eye_vector",
    "dist3d", "dot", "cross", "sub3", "add3", "scale3", "unit3", "norm3",
    "angle_between", "volume_tetra", "point_on3d", "midpoint3d",
    "plane_normal", "perpendicular", "parallel", "angle_line_plane",
    # scene + solids
    "Scene", "Solid", "finish", "SolidError", "SOLIDS",
    "cube", "box", "prism", "cylinder", "cone", "pyramid",
    "open_box", "container", "unit_cubes", "notch_prism", "extrude",
    # visibility, for a checker that wants both methods
    "visible_faces", "hidden_by_normals", "edge_pieces",

    # nets
    "net", "net_faces", "unfold",
]

# ------------------------------------------------------------- constants ---
CAB_DEG = 45.0                 # the depth axis on screen
CAB_K = 0.5                    # half length: cabinet, not cavalier
_CA = CAB_K * math.cos(math.radians(CAB_DEG))    # 0.353553
_SA = CAB_K * math.sin(math.radians(CAB_DEG))    # 0.353553

HID = "3.2,2.4"                # a hidden edge
AUX = "4,3"                    # an altitude, a construction line
INTER = "5,2"                  # a segment through the interior
SHADE = "#e1e1e1"              # a shaded face: background, never ink
WATER = "#e0eef4"              # a liquid: a WASH, lighter than svgcheck's
                               # LIGHT (0.85) so it is background, not ink.
                               # v6.6 S: luma (Rec.709) 0.923 >= 0.92, so it
                               # survives a B/W print as a pale wash (the old
                               # dcebf1 was 0.911)
WATER_LUMA_MIN = 0.92          # every liquid wash a kit emits is at least this
LABEL_PX = 10.6                # 7.95pt on the page, on every figure
_EDGE_GAP = 4.6                # clears the edge itself at the first radius

# The tier's width is emit_plus's (an item figure beside a writing band, a
# head figure beside the lead text, a block across the page). The HEIGHT had
# to be measured, not guessed: a cube is as tall as it is wide once the
# projection has added the depth, and its letters add another 40px, so at a
# 140px cap the fit came back with a drawing 65px across — under the size
# floor, with no tier able to cure it (cube(6) + a face diagonal).
ITEM_MAX, ITEM_H = 150.0, 120.0
SIDE_MAX, SIDE_H = 210.0, 180.0
BLOCK_MAX, BLOCK_H = 420.0, 320.0
TIERS = {"item": (ITEM_MAX, ITEM_H), "side": (SIDE_MAX, SIDE_H),
         "block": (BLOCK_MAX, BLOCK_H)}
_FLOOR = {"item": 60.0, "side": 80.0, "block": 110.0}   # the drawing, px
_EDGE_FLOOR = 8.0              # no edge may print as a dot
# v6.7 (DETERMINISM): whether a figure renders or is refused never depends on
# the clock. The fit is bounded by COUNTS -- at most 18 calibration calls of
# at most 8 draws each; a caller with other routes (describe) sets
# `scene._fail_fast = n`, the number of FAILING draws after which this fit
# gives up; a refusal's route probe tries at most _PROBE_MAX candidates. The
# wall clock is only a safety net: past _FIT_SECONDS the fit raises
# SolidMachineError, which is NOT an AssertionError and names the machine,
# never the figure.
_FIT_SECONDS = 60.0            # safety net only (SolidMachineError)
_PROBE_MAX = 6                 # route candidates a refusal draws, at most
_PROBE_FAILS = 3               # failing draws one route candidate may take


class SolidError(AssertionError):
    """Data that cannot be the solid it claims, or a drawing that would
    contradict its own numbers. An AssertionError, so every `raises(...)`
    harness in the skill still catches it."""


class SolidUndrawable(SolidError):
    """v6.7 r1: DATA no view, tier, pose of labels can draw (a cone so flat
    its apex falls inside its base ellipse). A caller that tries variants
    (describe) stops at the first one: every other variant is the same
    geometry and would draw -- and probe for a route -- all over again."""


class SolidMachineError(RuntimeError):
    """v6.7: the MACHINE ran out of time, not the figure out of room. Raised
    only by the wall-clock safety net; deliberately not an AssertionError,
    so no caller can mistake it for a content refusal and route around it."""


def _bad(where, said, fix):
    raise SolidError("solidkit.%s: %s — %s" % (where, said, fix))


def _n(x):
    """A number the way an author wrote it (6, not 6.0)."""
    return "%g" % float(x)


def _f(where, name, v, lo=0.0):
    try:
        x = float(v)
    except (TypeError, ValueError):
        _bad(where, "%s=%r is not a number" % (name, v),
             "give it as a number, e.g. %s=6" % name)
    if not x > lo:
        _bad(where, "%s=%s" % (name, _n(x)),
             "every length must be greater than %s" % _n(lo))
    return x


# ============================================================= 3D maths ====
# The author's sketch had these; they were RUN and are correct. They are
# re-derived here (not retyped) with the degenerate cases refused instead of
# dividing by zero, because a worksheet's answer key is computed from them.

def sub3(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def add3(a, b):
    return (a[0] + b[0], a[1] + b[1], a[2] + b[2])


def scale3(a, k):
    return (a[0] * k, a[1] * k, a[2] * k)


def dot(u, v):
    return u[0] * v[0] + u[1] * v[1] + u[2] * v[2]


def cross(u, v):
    return (u[1] * v[2] - u[2] * v[1],
            u[2] * v[0] - u[0] * v[2],
            u[0] * v[1] - u[1] * v[0])


def norm3(u):
    return math.sqrt(dot(u, u))


def dist3d(A, B):
    return norm3(sub3(A, B))


def unit3(u):
    L = norm3(u)
    if L < 1e-12:
        _bad("unit3", "the zero vector has no direction",
             "give a vector with a length, e.g. (1, 0, 0)")
    return scale3(u, 1.0 / L)


def angle_between(u, v):
    """Degrees between two 3D vectors. A zero vector is refused, not
    silently 90°."""
    lu, lv = norm3(u), norm3(v)
    if lu < 1e-12 or lv < 1e-12:
        _bad("angle_between", "one of the vectors is zero",
             "an angle needs two directions: give both vectors a length")
    c = max(-1.0, min(1.0, dot(u, v) / (lu * lv)))
    return math.degrees(math.acos(c))


def volume_tetra(A, B, C, D):
    """|(AB × AC) · AD| / 6. A flat (degenerate) tetrahedron is REFUSED, not
    drawn as a solid with volume 0 — the sheet that asks for it has wrong
    data."""
    v = abs(dot(sub3(B, A), cross(sub3(C, A), sub3(D, A)))) / 6.0
    scale = max(dist3d(A, B), dist3d(A, C), dist3d(A, D), 1e-9)
    if v < 1e-9 * scale ** 3:
        _bad("volume_tetra", "the four points are in one plane (volume 0)",
             "a tetrahedron needs a fourth point off the plane of the other "
             "three, e.g. volume_tetra((0,0,0), (1,0,0), (0,1,0), (0,0,1))")
    return v


def point_on3d(A, B, t):
    """The point at ratio t along AB (0 -> A, 1 -> B, 0.5 the midpoint)."""
    t = float(t)
    if not -1e-9 <= t <= 1 + 1e-9:
        _bad("point_on3d", "t=%s is off the segment" % _n(t),
             "t runs 0 (at A) to 1 (at B); 0.5 is the midpoint. For a point "
             "beyond B, name the longer segment instead")
    return tuple(a + (b - a) * t for a, b in zip(A, B))


def midpoint3d(A, B):
    return point_on3d(A, B, 0.5)


def plane_normal(A, B, C):
    """The normal of the plane ABC. Three collinear points are refused."""
    n = cross(sub3(B, A), sub3(C, A))
    if norm3(n) < 1e-12 * max(dist3d(A, B), dist3d(A, C), 1e-9):
        _bad("plane_normal", "A, B and C are on one line",
             "three points fix a plane only when they are not collinear")
    return n


def perpendicular(u, v, tol=0.5):
    """True when the angle between two vectors (or two plane normals) is
    90° within `tol` degrees."""
    return abs(angle_between(u, v) - 90.0) <= tol


def parallel(u, v, tol=0.5):
    a = angle_between(u, v)
    return min(a, 180.0 - a) <= tol


def angle_line_plane(u, n):
    """The angle between a line of direction `u` and a plane of normal `n`:
    90° minus the angle between the line and the normal."""
    return abs(90.0 - angle_between(u, n))


# =========================================================== projection ====
def _side_sign(side):
    if side not in ("right", "left"):
        _bad("projection", "side=%r" % side,
             "side is 'right' (depth up and to the right) or 'left'")
    return 1.0 if side == "right" else -1.0


def project(p, side="right", k=None):
    """A 3D point -> the 2D point it is drawn at, in MATHS coordinates
    (y up). Cabinet: the front plane true size, depth at 45° and half length.
    Depth runs UP and to the right (side='right').

    v6.7: `k` is the depth factor (CAB_K when None). Only a FLAT cone draws
    with a smaller one (a lower eye): see _cone_depth."""
    x, y, z = p
    s = _side_sign(side)
    if k is None or k == CAB_K:
        return (x + s * _CA * z, y + _SA * z)
    c = k * math.cos(math.radians(CAB_DEG))
    return (x + s * c * z, y + k * math.sin(math.radians(CAB_DEG)) * z)


def eye_vector(side="right", k=None):
    """The direction from the drawing TOWARDS the reader: the projection's
    own ray, reversed. A face is visible when its outward normal has a
    positive component along it."""
    if k is None or k == CAB_K:
        return (_side_sign(side) * _CA, _SA, -1.0)
    return (_side_sign(side) * k * math.cos(math.radians(CAB_DEG)),
            k * math.sin(math.radians(CAB_DEG)), -1.0)


# ================================================================ poses ====
def _rot_axis(v, axis, deg):
    """Rodrigues: turn `v` about `axis` by `deg` degrees."""
    k = unit3(axis)
    th = math.radians(deg)
    c, s = math.cos(th), math.sin(th)
    return add3(add3(scale3(v, c), scale3(cross(k, v), s)),
                scale3(k, dot(k, v) * (1.0 - c)))


def _rest_rotation(n):
    """The rotation taking the outward normal `n` of the resting face to
    (0, −1, 0) — the face put flat on the ground."""
    n = unit3(n)
    target = (0.0, -1.0, 0.0)
    c = max(-1.0, min(1.0, dot(n, target)))
    if c > 1 - 1e-12:
        return lambda v: v
    if c < -1 + 1e-12:                 # already the ceiling: turn it over
        return lambda v: _rot_axis(v, (1.0, 0.0, 0.0), 180.0)
    axis = cross(n, target)
    deg = math.degrees(math.acos(c))
    return lambda v: _rot_axis(v, axis, deg)


def _apply_pose(V, faces, pose):
    """`pose` is None, a face name, or (face name | 'base' | 'front' | ...,
    yaw). Returns the vertices in the posed frame, sitting on y = 0."""
    rest, yaw = None, 0.0
    if pose is None:
        rest, yaw = None, 0.0
    elif isinstance(pose, (int, float)):
        rest, yaw = None, float(pose)
    elif isinstance(pose, str):
        rest = pose
    else:
        try:
            rest, yaw = pose[0], float(pose[1])
        except (TypeError, IndexError, ValueError, KeyError):
            # a crash is not a refusal: pose={'on': 'ABCD'} used to raise a
            # bare KeyError out of the middle of the kit
            _bad("pose", "pose=%r" % (pose,),
                 "a pose is a face name, or (face, yaw) — e.g. "
                 "pose=('ABFE', 30), pose='base', pose=('top', 0)")
    R = (lambda v: v)
    if rest not in (None, "base", "bottom", ""):
        fc = _pose_face(faces, rest, V)
        R = _rest_rotation(_face_normal(V, fc, _centroid3([V[k] for k in V])))
    out = dict((k, R(v)) for k, v in V.items())
    if yaw:
        out = dict((k, _rot_axis(v, (0.0, 1.0, 0.0), yaw))
                   for k, v in out.items())
    return _settle(out)


_POSE_DIR = {"top": (0.0, 1.0, 0.0), "bottom": (0.0, -1.0, 0.0),
             "base": (0.0, -1.0, 0.0), "front": (0.0, 0.0, -1.0),
             "back": (0.0, 0.0, 1.0), "right": (1.0, 0.0, 0.0),
             "left": (-1.0, 0.0, 0.0)}


def _pose_face(faces, name, V):
    """The face a pose names: its letters, or one of the words `Solid.face`
    already answers to — 'base', 'top', 'front', 'back', 'right', 'left'.

    r-T1: `_apply_pose`'s own docstring promised pose=('top', 0), and
    `_find_face` matches letters only, so every named pose was refused. The
    word is resolved HERE, from the geometry (the face whose outward normal
    points that way in the solid's own frame), so it works for any solid
    with such a face and not only for a box's table of names."""
    key = name if isinstance(name, str) else "".join(name)
    want = tuple(sorted(key))
    for f in faces:
        if tuple(sorted(f)) == want:
            return f
    d = _POSE_DIR.get(key.lower())
    if d is not None:
        c = _centroid3([V[k] for k in V])
        best, bc = None, 0.9
        for f in faces:
            n = _face_normal(V, f, c)
            v = dot(unit3(n), d)
            if v > bc:
                best, bc = f, v
        if best is not None:
            return best
    have = [w for w in ("base", "top", "front", "back", "right", "left")
            if w != key.lower() and
            _pose_face_exists(faces, V, _POSE_DIR[w])]
    _bad("face", "no face %r in this solid" % key,
         "its faces are %s%s" % (", ".join("".join(f) for f in faces),
                                 (" — or by name: " + ", ".join(have))
                                 if have else ""))


def _pose_face_exists(faces, V, d):
    c = _centroid3([V[k] for k in V])
    return any(dot(unit3(_face_normal(V, f, c)), d) > 0.9 for f in faces)


def _settle(V):
    """Put the solid on the ground (lowest y at 0) and centre it in x and z,
    so every pose of one solid is drawn in the same place."""
    ys = [p[1] for p in V.values()]
    xs = [p[0] for p in V.values()]
    zs = [p[2] for p in V.values()]
    dx = (max(xs) + min(xs)) / 2.0
    dz = (max(zs) + min(zs)) / 2.0
    dy = min(ys)
    return dict((k, (p[0] - dx, p[1] - dy, p[2] - dz)) for k, p in V.items())


def _find_face(faces, name, V=None):
    """A face by its letters in any rotation or reversal, or by one of the
    names a solid's own `face_names` gives it."""
    key = name if isinstance(name, str) else "".join(name)
    want = tuple(sorted(key))
    for f in faces:
        if tuple(sorted(f)) == want:
            return f
    _bad("face", "no face %r in this solid" % key,
         "its faces are %s" % ", ".join("".join(f) for f in faces))


def _ring_area(ring):
    """The area of a flat ring of 3D points."""
    c = _centroid3(ring)
    return sum(0.5 * norm3(cross(sub3(ring[i], c),
                                 sub3(ring[(i + 1) % len(ring)], c)))
               for i in range(len(ring)))


def _centroid3(pts):
    n = float(len(pts))
    return (sum(p[0] for p in pts) / n, sum(p[1] for p in pts) / n,
            sum(p[2] for p in pts) / n)


def _face_normal(V, f, inside):
    """The OUTWARD normal of face `f`: the plane normal, turned to point away
    from `inside` (the solid's centroid)."""
    pts = [V[k] for k in f]
    n = None
    for i in range(len(pts) - 2):
        try:
            n = plane_normal(pts[i], pts[i + 1], pts[i + 2])
            break
        except SolidError:
            continue
    if n is None:
        _bad("face", "face %r is a line, not a polygon" % "".join(f),
             "give the face at least three vertices that are not collinear")
    if dot(n, sub3(_centroid3(pts), inside)) < 0:
        n = scale3(n, -1.0)
    return n


# =========================================================== visibility ====
# THE PART THE AUTHOR'S BRIEF WANTED AS A TABLE. Two methods, and the
# selftest proves they agree on every convex solid:
#   * normals   — a face is visible iff outward normal · eye > 0; an edge is
#                 hidden iff every face it bounds is hidden. Exact on a
#                 convex solid, at any pose.
#   * occlusion — general: each edge is cut at every crossing of every
#                 projected face outline, and a piece is hidden when a face
#                 that does not hold it passes in front of it. This is the
#                 one a notch, an L-prism, an open box or a stack needs, and
#                 it gives PART of an edge dashed where that is the truth.

def _lift_z(m2, n, p0, side):
    """The z of the point on plane (p0, n) that is drawn at the 2D point m2.
    Returns None when the plane is edge-on (its projection is a line)."""
    s = _side_sign(side)
    den = n[0] * s * _CA + n[1] * _SA - n[2]
    if abs(den) < 1e-12:
        return None
    return (n[0] * m2[0] + n[1] * m2[1] - dot(n, p0)) / den


def _in_poly(pt, poly):
    x, y = pt
    inside, j = False, len(poly) - 1
    for i in range(len(poly)):
        xi, yi = poly[i]
        xj, yj = poly[j]
        if (yi > y) != (yj > y):
            if x < xi + (y - yi) * (xj - xi) / ((yj - yi) or 1e-12):
                inside = not inside
        j = i
    return inside


def _cross2(o, a, b):
    return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])


def _seg_hits(p, q, a, b):
    """Where segment pq meets segment ab, as a fraction along pq (or None)."""
    d1, d2 = (q[0] - p[0], q[1] - p[1]), (b[0] - a[0], b[1] - a[1])
    den = d1[0] * d2[1] - d1[1] * d2[0]
    if abs(den) < 1e-12:
        return None
    t = ((a[0] - p[0]) * d2[1] - (a[1] - p[1]) * d2[0]) / den
    u = ((a[0] - p[0]) * d1[1] - (a[1] - p[1]) * d1[0]) / den
    if -1e-9 <= t <= 1 + 1e-9 and -1e-9 <= u <= 1 + 1e-9:
        return t
    return None


def _edges_of(faces):
    """Every edge of the solid, with the faces that bound it."""
    edges = {}
    for i, f in enumerate(faces):
        for k in range(len(f)):
            key = tuple(sorted((f[k], f[(k + 1) % len(f)])))
            edges.setdefault(key, []).append(i)
    return edges


def visible_faces(V, faces, side="right"):
    """Which faces face the reader. Outward normals are found from the
    solid's own centroid, so no face list has to be given wound a particular
    way."""
    c = _centroid3(list(V.values()))
    eye = eye_vector(side)
    return [dot(_face_normal(V, f, c), eye) > 1e-9 for f in faces]


def hidden_by_normals(V, faces, side="right"):
    """The hidden EDGE set of a convex solid: an edge is hidden when every
    face meeting there looks away."""
    vis = visible_faces(V, faces, side)
    out = set()
    for key, fs in _edges_of(faces).items():
        if not any(vis[i] for i in fs):
            out.add(key)
    return out


def edge_pieces(V, faces, side="right", opaque=True):
    """Every edge, cut into the stretches that are SEEN and the stretches
    that are hidden behind a face. Returns
    {edge key: [(t0, t1, visible), ...]} with t along the sorted key."""
    P = dict((k, project(v, side)) for k, v in V.items())
    polys = [[P[k] for k in f] for f in faces]
    planes = []
    c = _centroid3(list(V.values()))
    for f in faces:
        planes.append((_face_normal(V, f, c), V[f[0]], set(f)))
    out = {}
    for key in sorted(_edges_of(faces)):
        a, b = key
        p, q = P[a], P[b]
        cuts = set([0.0, 1.0])
        for poly in polys:
            for k in range(len(poly)):
                t = _seg_hits(p, q, poly[k], poly[(k + 1) % len(poly)])
                if t is not None and 1e-6 < t < 1 - 1e-6:
                    cuts.add(round(t, 9))
        ts = sorted(cuts)
        pieces = []
        for i in range(len(ts) - 1):
            t0, t1 = ts[i], ts[i + 1]
            if t1 - t0 < 1e-6:
                continue
            tm = 0.5 * (t0 + t1)
            m2 = (p[0] + tm * (q[0] - p[0]), p[1] + tm * (q[1] - p[1]))
            ze = V[a][2] + tm * (V[b][2] - V[a][2])
            seen = True
            if opaque:
                for (n, p0, owns), poly in zip(planes, polys):
                    if a in owns and b in owns:
                        continue
                    if not _in_poly(m2, poly):
                        continue
                    zf = _lift_z(m2, n, p0, side)
                    if zf is None:
                        continue
                    if zf < ze - 1e-6:
                        seen = False
                        break
            if pieces and pieces[-1][2] == seen:
                pieces[-1] = (pieces[-1][0], t1, seen)
            else:
                pieces.append((t0, t1, seen))
        out[key] = pieces
    return out


# ================================================================ labels ===
def _italic(text):
    """A letter standing for a quantity (a, 2b, h, L, V, x) is italic; a
    number or a unit is upright."""
    return bool(re.fullmatch(r"\d*[a-zA-Z]", text or ""))


def _hull2(pts):
    """The convex hull of 2D points, counter-clockwise (monotone chain)."""
    P = sorted(set((float(p[0]), float(p[1])) for p in pts))
    if len(P) < 3:
        return P

    def cr(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    lo, up = [], []
    for p in P:
        while len(lo) >= 2 and cr(lo[-2], lo[-1], p) <= 0:
            lo.pop()
        lo.append(p)
    for p in reversed(P):
        while len(up) >= 2 and cr(up[-2], up[-1], p) <= 0:
            up.pop()
        up.append(p)
    return lo[:-1] + up[:-1]


def _face_object(f, tp, role="face"):
    """The face `tp` as an export object (v6.6 E r1): once per face, its ink
    the fill drawn for it (if the scene shades it)."""
    key = sorted((round(p[0], 3), round(p[1], 3)) for p in tp)
    for it in f.ex.items:
        if it.kind == "polygon" and sorted(
                (round(p[0], 3), round(p[1], 3)) for p in it.pts) == key:
            return it
    parts = [i for i, (k, pts, w, _d, _e) in enumerate(f.parts)
             if k == "poly" and (w or 0) <= 0 and sorted(
                 (round(p[0], 3), round(p[1], 3)) for p in pts) == key]
    meta = {"_parts": parts[:1]} if parts else {}
    return f.ex.add("polygon", [tuple(p) for p in tp], role=role, meta=meta)


def _ray_label(f, m, text, n, font, extra=0.0):
    """Register a label whose first candidate puts the CENTRE of its text box
    on the ray m + r·n, just clear of whatever stroke runs through m. (The
    solver measures from anchor to baseline and tries every direction at the
    smallest radius first, so without this a label meant for the outside of
    an edge takes the first free spot INSIDE the solid.)"""
    hx = max(len(text), 1) * 0.58 * font / 2.0
    hy = font * 0.51
    ext = abs(n[0]) * hx + abs(n[1]) * hy
    gap = max(1.0, ext + 3.2 - 0.62 * font) + extra
    f.label((m[0], m[1] + 0.27 * font), text, size=font, prefer=n,
            italic=_italic(text), gap=gap)


def _dim(f, A, B, offset, text, size, pts=(), lanes=None, lane_key=None,
         dry=False, wit=False, ref=None):
    """A dimension line OUTSIDE the solid. z47's PRISMKIT drew its own shaft
    and four barbs (`_dim_px`) because `figkit.Figure` had none; v6 stage 1
    added `Figure.dimension` (E9) with witness lines, arrowheads at the
    printed floor, registered ink and the text owning the line — the very
    thing that file was told it replaces. This is the one route now.

    `offset='out'` is the offset a SOLID needs: figkit refuses a dimension
    that runs through the drawing, and how far out "outside" is depends on
    what the projection made of the figure. It is measured here, from the
    ink: the line stands clear of every stroke, on the side with room."""
    between = 0.0
    if offset == "out" or offset == "out-" or (isinstance(offset, tuple)
                                               and offset[0] == "out"):
        ux, uy = (B[0] - A[0]), (B[1] - A[1])
        L = math.hypot(ux, uy) or 1.0
        nx, ny = uy / L, -ux / L              # the page-left of A -> B
        m = ((A[0] + B[0]) / 2.0, (A[1] + B[1]) / 2.0)
        far = [0.0, 0.0]
        cross = [0.0, 0.0]
        # r1: only the ink the dimension would actually CROSS pushes it out
        # -- the ink lying across its own span (with room for its text).
        # Measured against every stroke of the drawing, the short base
        # edge of a tall prism had its dimension pushed out by the whole
        # height of the solid: the arrow stood 50px from its edge with no
        # witness line, and "5" could be read against nothing.
        hx = max(len(text or ""), 1) * 0.58 * size / 2.0
        mg = max(6.0, hx - L / 2.0 + 4.0)
        pts = list(pts)
        pairs = (list(zip(pts[0::2], pts[1::2])) if len(pts) % 2 == 0
                 else [(q, q) for q in pts])
        for p0, p1 in pairs:          # each stroke, clipped to the band
            s0 = ((p0[0] - A[0]) * ux + (p0[1] - A[1]) * uy) / L
            s1 = ((p1[0] - A[0]) * ux + (p1[1] - A[1]) * uy) / L
            lo, hi = -mg, L + mg
            if max(s0, s1) < lo or min(s0, s1) > hi:
                continue
            ends = []
            for q, sq in ((p0, s0), (p1, s1)):
                if lo <= sq <= hi:
                    ends.append(q)
            if abs(s1 - s0) > 1e-9:
                for sc_ in (lo, hi):
                    tt = (sc_ - s0) / (s1 - s0)
                    if 0.0 < tt < 1.0:
                        ends.append((p0[0] + tt * (p1[0] - p0[0]),
                                     p0[1] + tt * (p1[1] - p0[1])))
            ds = [(q[0] - m[0]) * nx + (q[1] - m[1]) * ny for q in ends]
            for d in ds:
                far[0] = min(far[0], d)
                far[1] = max(far[1], d)
            # what stands BETWEEN the edge and its shaft and can be misread
            # for it: a stroke across the MIDDLE of the span that is not an
            # equal parallel edge (a box's opposite edge measures the same
            # number, so reading the number against it is still true; the
            # short connectors at the two ends are where the arrowheads
            # point, not what they measure)
            sl, sh = min(s0, s1), max(s0, s1)
            par = (abs(math.hypot(p1[0] - p0[0], p1[1] - p0[1]) - L) < 2.5
                   and abs((p1[0] - p0[0]) * nx + (p1[1] - p0[1]) * ny)
                   < 0.035 * L)
            if not par and ds and sh > 0.3 * L and sl < 0.7 * L:
                cross[0] = min([cross[0]] + ds)
                cross[1] = max([cross[1]] + ds)
        # r6: each dimension standing outside the drawing takes its own
        # LANE. Two of them a few px apart put each number as near the other
        # one's shaft as its own, and the whole figure was refused for it
        # (the hexagonal prism on a lateral face, a tipped open box, a box
        # measured on three edges).
        # close-out: dimensions that SHARE a lane_key share one lane. Two
        # halves of one base, written end to end under it, are one lane —
        # given a lane each they came out at two different offsets, and the
        # pair read as two unrelated measurements instead of one split side.
        lane = 0
        if lanes is not None:
            here = (nx, ny)
            seen = []
            for dd, key, A2, B2 in lanes:
                if dd[0] * here[0] + dd[1] * here[1] <= 0.35:
                    continue
                # r1: a dimension whose span lies clear of this one's (the
                # other end of the drawing) does not share its paper, so it
                # takes no lane from it
                s2 = [((q[0] - A[0]) * ux + (q[1] - A[1]) * uy) / L
                      for q in (A2, B2)]
                if max(s2) <= 2.0 or min(s2) >= L - 2.0:
                    continue
                if lane_key is not None and key == lane_key:
                    continue
                k = key if key is not None else object()
                if k not in seen:
                    seen.append(k)
            lane = len(seen)
            if not dry:
                lanes.append((here, lane_key, A, B))
        pad = 12.0 + 15.0 * lane
        if isinstance(offset, tuple):
            # a named PAGE direction ("put the level's dimension on the
            # right, where the height's is not" — S-R10)
            sgn = 1.0 if (nx * offset[1] + ny * offset[2]) > 0 else -1.0
            offset = sgn * ((far[1] if sgn > 0 else -far[0]) + pad)
        else:
            between = -cross[0] if offset == "out-" else cross[1]
            offset = far[0] - pad if offset == "out-" else far[1] + pad
    # r2 (short dimension refused): a dimension's own arrowheads are strokes,
    # and figkit only lets a stroke standing ON the shaft off the ownership
    # contest while it is under 0.35 of the shaft. A liquid level 9 deep in a
    # 40-deep tank is a 17px shaft with 5px heads, and the text could not be
    # nearer the shaft than the head beside it, so the figure was refused.
    # The heads follow the shaft instead.
    if dry:
        return between
    L = math.hypot(B[0] - A[0], B[1] - A[1])
    # r3: witness lines run from the edge OUT to the shaft, so a dimension
    # standing clear of the drawing cannot have them — they would cross
    # everything it was moved out to avoid (figkit refuses that itself).
    if wit:
        # v6.7 r1: a flat cone's dimensions stand far from what they
        # measure (the rim is in the way), so each witness line starts at
        # the LAST ink it meets on its way out and runs to the shaft --
        # figkit checks that it crosses nothing on the way
        import svgcheck
        nx_, ny_ = (B[1] - A[1]) / L, -(B[0] - A[0]) / L
        starts = []
        for e in (A, B):
            far_ = (e[0] + nx_ * offset, e[1] + ny_ * offset)
            best_t = 0.0
            for c_, d_ in f.segs:
                x = svgcheck._cross_pt(e, far_, c_, d_)
                if x and 0.0 < x[0] < 0.98 and -1e-6 <= x[1] <= 1 + 1e-6:
                    best_t = max(best_t, x[0])
            starts.append((e[0] + (far_[0] - e[0]) * best_t,
                           e[1] + (far_[1] - e[1]) * best_t))
        f.dimension(A, B, offset=offset, text=text, size=size,
                    head=max(2.6, min(5.0, 0.18 * L)), witness=True,
                    witness_from=starts, ref=ref)
        return between
    f.dimension(A, B, offset=offset, text=text, size=size,
                head=max(2.6, min(5.0, 0.18 * L)),
                witness=abs(offset) < 14.0, ref=ref)
    return between


def _inside_spot(f, poly, text, font, want, taken=(), near=None,
                 lenient=False):
    """The point inside `poly` nearest `want` where the text box, grown by
    the solver's own clearance, lies wholly inside the face and touches no
    stroke. A hidden edge crosses a front face at most poses, so the centroid
    is usually not free."""
    from figkit import _seg_box
    hx = max(len(text), 1) * 0.58 * font / 2.0 + 2.2
    hy = font * 0.51 + 2.2
    xs = [p[0] for p in poly]
    ys = [p[1] for p in poly]
    best, bd = None, 1e18
    x = min(xs)
    while x <= max(xs):
        y = min(ys)
        while y <= max(ys):
            bx = (x - hx, y - hy, x + hx, y + hy)
            corners = [(bx[0], bx[1]), (bx[2], bx[1]), (bx[2], bx[3]),
                       (bx[0], bx[3])]
            if all(_in_poly(qq, poly) for qq in corners) and \
                    not any(_seg_box(u, v, bx) for u, v in f.segs) and \
                    not any(bx[0] < o[2] + 5 and o[0] < bx[2] + 5 and
                            bx[1] < o[3] + 5 and o[1] < bx[3] + 5
                            for o in taken):
                dd = (x - want[0]) ** 2 + (y - want[1]) ** 2
                if dd < bd:
                    best, bd = (x, y), dd
            y += 0.9
        x += 0.9
    if (best is None or (near is not None and bd > near * near)) and lenient:
        return want
    if best is None or (near is not None and bd > near * near):
        raise SolidError(
            "solidkit: no room for %r inside its face — draw it at a bigger "
            "tier (tier='side' or 'block'), or label the edge instead of the "
            "face" % text)
    return best


def _box_clear_of_poly(bx, poly):
    """True when the text box does not touch the silhouette at all: no corner
    inside it and no side of it crossed."""
    corners = [(bx[0], bx[1]), (bx[2], bx[1]), (bx[2], bx[3]), (bx[0], bx[3])]
    if any(_in_poly(c, poly) for c in corners):
        return False
    for k in range(len(poly)):
        a, b = poly[k], poly[(k + 1) % len(poly)]
        for j in range(4):
            if _seg_hits(a, b, corners[j], corners[(j + 1) % 4]) is not None:
                return False
    return True


def _place_letter(f, P, text, font, poly, taken, outside=True, prefer=None):
    """A vertex letter, placed where it cannot be read as belonging to the
    solid's surface: OUTSIDE the silhouette for a vertex on it, and in the
    widest free wedge between its own edges for the hidden inner corner.

    Looked at first (v64/look/solids/probe_projection.png): letting
    `figkit.vertex_label` choose put B and F INSIDE the box's front face —
    the solver takes the first free spot and the inside of a drawn solid is
    the freest paper there is. A letter inside a face reads as naming the
    face, not the corner (S-R6)."""
    from figkit import _seg_box
    hw = max(len(text), 1) * 0.58 * font / 2.0
    hh = font * 0.51
    if prefer is None:
        c = (sum(q[0] for q in poly) / len(poly),
             sum(q[1] for q in poly) / len(poly))
        L = math.hypot(P[0] - c[0], P[1] - c[1]) or 1.0
        prefer = ((P[0] - c[0]) / L, (P[1] - c[1]) / L)
    a0 = math.degrees(math.atan2(prefer[1], prefer[0]))
    for extra in (0.0, 2.5, 5.5, 9.0):
        for dd in sorted(range(-180, 180, 15), key=abs):
            th = math.radians(a0 + dd)
            n = (math.cos(th), math.sin(th))
            ext = abs(n[0]) * hw + abs(n[1]) * hh
            r = ext + 3.2 + extra
            cx, cy = P[0] + n[0] * r, P[1] + n[1] * r
            bx = (cx - hw, cy - hh, cx + hw, cy + hh)
            if outside and not _box_clear_of_poly(bx, poly):
                continue
            if any(_seg_box(u, v, bx) for u, v in f.segs):
                continue
            if any(bx[0] < o[2] + 3 and o[0] < bx[2] + 3 and
                   bx[1] < o[3] + 3 and o[1] < bx[3] + 3 for o in taken):
                continue
            _ray_label(f, P, text, n, font, extra=extra)
            taken.append(bx)
            return n
    raise SolidError(
        "solidkit: no free paper for the letter %r outside the solid — draw "
        "it at tier='side' or 'block', or leave the letters off this figure "
        "(names=False) and name the lengths instead" % text)


def _edge_number(f, A, B, text, nn, font, ink, taken, own=True,
                 force_dim=False, lanes=None, at=None):
    """A length beside its edge — or, when no spot beside it can be read as
    ITS length, on a dimension line outside the drawing.

    THE LADDER, and why it exists. E24 says a number must be nearer its own
    stroke than any other by 1.5, or it reads as the other stroke's length.
    In a plane figure there is always room; in a projection there is often
    not — a prism's base edge has the receding edge of the next face running
    a few px away from it all along, and every spot beside the base edge is
    nearly as near that one. The v6.4 catalogue found five figures refused
    for exactly this (the upright triangular prism, the hexagonal prism on a
    lateral face, the triangular pyramid, a tipped open box, a box labelled
    with dimensions). The cure is not a smaller font or a dropped number: it
    is the dimension line the house already has — outside the solid, with
    witness lines back to the edge it measures (doctrine 4)."""
    from figkit import _seg_box
    hw = max(len(text), 1) * 0.58 * font / 2.0
    hh = font * 0.51
    # `at` is where along the edge the number sits (Scene.value's t=). The
    # midpoint is the default; a hypotenuse whose middle is crowded by the
    # receding edges is named nearer one end instead.
    m = tuple(at) if at else ((A[0] + B[0]) / 2.0, (A[1] + B[1]) / 2.0)
    # E24 is about a NUMBER being read as another stroke's length. A NAME
    # (the 'd' of a space diagonal, the 'f' of a face diagonal, an area's
    # 'S') is not a length a reader could attach to the wrong edge, and
    # holding it to the ownership rule pushed it onto a dimension line
    # metres from the segment it names (the v6.4 catalogue: 'd' and 'f' on
    # long arrows out in the margin).
    if not re.fullmatch(r"[\u2212-]?\d+(?:[.,]\d+)?", text or ""):
        own = False
    if own and not force_dim:
        for extra in (0.0, 2.0, 4.5):
            ext = abs(nn[0]) * hw + abs(nn[1]) * hh
            r = ext + 3.2 + extra
            c = (m[0] + nn[0] * r, m[1] + nn[1] * r)
            bx = (c[0] - hw, c[1] - hh, c[0] + hw, c[1] + hh)
            if any(_seg_box(u, v, bx) for u, v in f.segs):
                continue
            if not f._owns(bx, (tuple(A), tuple(B))):
                continue
            _ray_label(f, m, text, nn, font, extra=extra)
            f.labels[-1].owner = (tuple(A), tuple(B))       # E24
            taken.append(bx)
            return "beside"
        # nothing beside the edge can be read as ITS number: measure it from
        # outside instead
        _moved_dim(f, A, B, nn, text, font, ink, lanes)
        return "dimension"
    if force_dim:
        _moved_dim(f, A, B, nn, text, font, ink, lanes)
        return "dimension"
    _ray_label(f, m, text, nn, font)
    # v6.6 E (X1R2-03): tied to its edge in the export (lbl-AB / for), even
    # where the ownership rule does not hold it (a name, a radius)
    f.labels[-1].export_owner = (tuple(A), tuple(B))
    return "beside"


def _moved_dim(f, A, B, nn, text, font, ink, lanes):
    """The number moved onto a dimension line: on the side away from the
    solid, or -- r1 -- on the other side when only there does nothing stand
    between the edge and the line; refused when neither side is clear."""
    side = "out" if _side_of(nn, A, B) else "out-"
    other = "out-" if side == "out" else "out"
    for sd in (side, other):
        if _dim(f, A, B, sd, text, font, pts=ink, lanes=lanes,
                dry=True) <= 2.0:
            return _dim(f, A, B, sd, text, font, pts=ink, lanes=lanes)
    _detached(text, _dim(f, A, B, side, text, font, pts=ink, lanes=lanes,
                         dry=True))


def _detached(text, between):
    """r1: a number the kit MOVED onto a dimension line must still be read
    against its own edge. When other strokes of the drawing stand between
    the edge and the line (a triangular prism's back base edge, measured
    from below the whole base), the arrow is out on the paper with no
    witness line and nothing ties it to the edge -- refused, so the fit
    and the routes look for a figure where it reads."""
    if between > 2.0:
        raise SolidError(
            "solidkit: label '%s' can only go on a dimension line %.0fpx "
            "out, with other edges between it and the edge it measures -- "
            "read against nothing. Write it inside a face, turn the solid "
            "so that edge is on the outline, or leave the number out of the "
            "drawing" % (text, between))


def _side_of(nn, A, B):
    """True when the direction `nn` is the page-left of A -> B (the sense
    `Figure.dimension`'s positive offset moves in)."""
    ux, uy = B[0] - A[0], B[1] - A[1]
    L = math.hypot(ux, uy) or 1.0
    return (uy / L) * nn[0] + (-ux / L) * nn[1] > 0


def _biggest_unit(box, ex, ey):
    """The largest px-per-unit a tier box could give this drawing, labels
    aside: what the fit aims at before the labels take their room."""
    W, H = box
    return min(W / max(ex, 1e-9), H / max(ey, 1e-9))


def _roundup(v):
    """A number an author can type: 1 significant step up."""
    if v <= 0:
        return 0.0
    step = 10.0 ** math.floor(math.log10(v))
    step = step / 2.0 if v / step < 3 else step
    return math.ceil(v / step - 1e-9) * step


def _RAW(scene, key):
    """The real length of the edge named by two letters (the datum the
    author typed, not the drawn one)."""
    for d in scene.solids:
        if key[0] in d.V and key[1] in d.V:
            return dist3d(d.V[key[0]], d.V[key[1]])
    return 0.0


# ================================================================= Scene ===
class Scene(object):
    """The drawing surface: everything is collected in REAL units, maths
    orientation (y up), and fitted to the page once, at render.

    A scene is 2D — it holds what will be drawn. `Solid` is what knows about
    three dimensions; it projects onto this. Nets and companion triangles put
    plain 2D geometry on the same scene at the same unit, which is how a net
    and its solid print at one scale."""

    def __init__(self, side="right", tier="side", unit=None, hidden="dashed"):
        if tier not in TIERS:
            _bad("Scene", "tier=%r" % tier,
                 "tier is 'item' (beside a writing band), 'side' or 'block'")
        if hidden not in ("dashed", "omit"):
            _bad("Scene", "hidden=%r" % hidden,
                 "hidden is 'dashed' (the default) or 'omit' (an opaque "
                 "stack of unit cubes)")
        _side_sign(side)
        self.side, self.tier, self.unit, self.hidden = side, tier, unit, hidden
        # v6.7: the depth factor of this scene's projection. CAB_K for every
        # figure but a flat cone, whose apex would fall inside its own base
        # ellipse at CAB_K (see _cone_depth); the proj tag states it.
        self.depth = CAB_K
        self.fills, self.strokes, self.labels, self.checks = [], [], [], []
        self.solids = []
        # the ANGLES this figure claims, so a reader can recompute them from
        # the points the figure also declares: (kind, names, face, text).
        # Without them the printed value of angle_mark() was checked by
        # nothing at all — svgcheck stands down on a projected figure (a
        # real 90 deg prints as 117 deg in cabinet), and only the builder
        # knew which triple the number belonged to.
        self.angles = []
        # the numbers this scene has had to move onto a dimension line
        # because no spot beside their edge could be read as THEIR number
        self._dim_texts = set()
        # v6.6 S r1: the points add-ons NAME (a midpoint M, a pyramid's foot
        # O), so the export calls them pt-M / pt-O and the letter printed
        # beside one is tied to it -- they used to leave as an unnamed
        # pt-<hash> with a letter the JSON could not attach to anything.
        self.named = []
        # r1: equal parallel edges an AUTOMATIC length may move to
        self.alt_edges = {}

    # -- projection ---------------------------------------------------------
    def pr(self, p3):
        return project(p3, self.side, getattr(self, "depth", None))

    def eye(self):
        return eye_vector(self.side, getattr(self, "depth", None))

    # -- strokes ------------------------------------------------------------
    def line(self, a, b, w=1.5, dash=None, hid=False):
        # v6.5 X2: `hid` says this stroke is a HIDDEN EDGE of the solid, not
        # merely a dashed line -- the one fact about a solid that the
        # cabinet projection does state, and the deliverable exports it so
        # the author's AI can say "the dashed edge CG is the hidden one"
        # without reading the picture.
        self.strokes.append(dict(kind="line", a=a, b=b, w=w, dash=dash,
                                 hid=bool(hid)))

    def poly(self, pts, w=1.5, dash=None):
        pts = list(pts)
        for k in range(len(pts)):
            self.line(pts[k], pts[(k + 1) % len(pts)], w, dash)

    def curve(self, pts, w=1.4, dash=None):
        """A sampled curve (an ellipse arc of a cylinder or cone). Drawn as
        ONE path, so nothing reads it as a row of little segments."""
        self.strokes.append(dict(kind="curve", pts=list(pts), w=w, dash=dash))

    def fill(self, pts, colour=SHADE):
        self.fills.append((list(pts), colour))

    def right(self, v, a, b, size=6.0):
        """A right angle that IS square on the page (a net, a companion
        triangle): figkit measures it and refuses a mark the drawing
        contradicts."""
        self.strokes.append(dict(kind="right", v=v, a=a, b=b, size=size))

    def rmark(self, v, a, b, size=7.0, sp=None):
        """A right angle that is square IN SPACE. Under a cabinet projection
        a real 90° almost never prints as 90° — the angle ACG of a box comes
        out 117° on the page — so the mark is drawn as the projected square:
        the little parallelogram between the two rays. The claim itself is
        checked in 3D by `Solid.right_mark` before this is ever called;
        figkit's own 2D test is the wrong test here and would refuse every
        true right angle in the figure."""
        # v6.8 r2 (G7): `sp` is the same corner IN SPACE (three xyz), so
        # the export states perpendicular(..., space=True) and a reader
        # re-measures it on the points' xyz
        self.strokes.append(dict(kind="rmark", v=v, a=a, b=b, size=size,
                                 sp=sp))

    def arc(self, v, a, b, n=1, r=17.0):
        self.strokes.append(dict(kind="arc", v=v, a=a, b=b, n=n, r=r))

    def ticks(self, a, b, n=1, t=0.5, sp=None):
        # v6.8 r2 (G7): `sp` is the ticked edge's two ends in space: ticks
        # with the same count state equal_length(..., space=True)
        self.strokes.append(dict(kind="ticks", a=a, b=b, n=n, t=t, sp=sp))

    def dot(self, a):
        self.strokes.append(dict(kind="dot", a=a))

    def dim(self, a, b, off="out", text=None, w=1.0, lane=None, wit=False,
            ref=None):
        """A dimension line for a-b, `off` px to its LEFT as the page reads
        it walking from a to b (negative: to its right), named by `text`.
        This is how a length is written OUTSIDE the solid instead of inside
        a face that has no room for it."""
        self.strokes.append(dict(kind="dim", a=a, b=b, w=w,
                                 off=off if isinstance(off, (str, tuple))
                                 else float(off), text=text, lane=lane,
                                 wit=bool(wit), ref=ref))

    # -- labels -------------------------------------------------------------
    def value(self, a, b, text, away, gap=_EDGE_GAP, t=0.5, own=True):
        """A length beside the segment a-b, on the far side from `away`.

        `own=False` is for a segment whose only near neighbour is a CURVE.
        E24 ownership asks that a number be nearer its own stroke than any
        other by 1.5, so that "12" between two edges cannot be read as the
        other edge's length. A cylinder's radius has the rim ellipse at both
        ends of it and a hand's breadth of paper nowhere: the cap of
        cylinder(3, 8) is 27px tall and the number is 11px, so no spot on
        the page satisfies the rule and the figure was refused outright. An
        arc carries no printed length, so it is not a competitor a reader
        could confuse the number with — the rule that matters there (and the
        one selfcheck_solidkit measures) is that the number is nearer the
        radius than any other STRAIGHT stroke."""
        self.labels.append(("edge", a, b, text, away, gap, t, bool(own)))

    def edge_in(self, a, b, text, poly):
        self.labels.append(("edge_in", a, b, text, list(poly)))

    def inside(self, pts, text, at=None):
        self.labels.append(("inside", list(pts), text, at))

    def text(self, at, text, prefer=None, gap=2.0):
        self.labels.append(("free", at, text, prefer, gap))

    def vertex(self, v, text, poly=None):
        self.labels.append(("vertex", v, text, list(poly) if poly else None))

    def alt_value(self, poly, text, top, foot):
        """The length of an altitude, written beside it INSIDE the face it
        falls in, and on a dimension line outside the drawing when the face
        has no room. z47's PRISMKIT had to write this by hand (`alt_label`);
        it is here because an altitude is short, is drawn inside a
        foreshortened face, and has the base's own edges on both sides of it
        — the one label in a solid that cannot simply stand beside its
        stroke and own it."""
        self.labels.append(("alt", list(poly), text, top, foot))

    def letter(self, v, text, poly, outside=True, prefer=None):
        """A vertex letter that must stay OFF the solid's surface."""
        self.labels.append(("letter", v, text, list(poly), bool(outside),
                            prefer))

    # -- proportions --------------------------------------------------------
    def check(self, name, a, b, given, factor=1.0):
        """`given` is what the sheet says the length IS; `factor` divides the
        drawn length first (K for a receding edge). figkit.Figure.expect
        refuses a drawing that contradicts its own number."""
        self.checks.append((name, a, b, float(given), float(factor)))

    # -- size ---------------------------------------------------------------
    def _extent(self):
        xs, ys = [], []
        for s in self.strokes:
            if s["kind"] in ("line", "dim", "ticks"):
                xs += [s["a"][0], s["b"][0]]
                ys += [s["a"][1], s["b"][1]]
            elif s["kind"] == "curve":
                xs += [p[0] for p in s["pts"]]
                ys += [p[1] for p in s["pts"]]
            elif s["kind"] == "dot":
                xs.append(s["a"][0])
                ys.append(s["a"][1])
        for pts, _c in self.fills:
            xs += [p[0] for p in pts]
            ys += [p[1] for p in pts]
        if not xs:
            _bad("render", "the scene is empty", "draw a solid before "
                 "rendering, e.g. box(9, 4, 5, fam='solid.box')")
        return max(xs) - min(xs), max(ys) - min(ys)

    @staticmethod
    def width_of(svg):
        return float(re.search(r'<svg[^>]*\bwidth="([\d.]+)', svg).group(1))

    @staticmethod
    def height_of(svg):
        return float(re.search(r'<svg[^>]*\bheight="([\d.]+)', svg).group(1))

    # -- render -------------------------------------------------------------
    def render(self, fam, unit=None, max_width=None, max_h=None):
        """Draw. `unit` is px per real unit; left None the figure is FITTED
        to its tier (the largest unit whose finished SVG fits the tier box),
        which is what makes two solids of one sheet share a scale when they
        are given the same unit and differ honestly when they are not."""
        if not fam:
            _bad("render", "fam= is missing",
                 "every figure declares its configuration, e.g. "
                 "fam='solid.box+names' — G76 counts objects by it")
        W, H = TIERS[self.tier]
        W = float(max_width or W)
        H = float(max_h or H)
        asked = dict(unit=unit, max_width=max_width, max_h=max_h)
        unit = self.unit if unit is None else unit
        if unit is None:
            unit = self._fit(fam, W, H)
        # The SIZE rules run before the drawing is attempted: a figure drawn
        # too small fails first in the label solver, whose message is about
        # labels and names no tier (r5 — the refusal has to name the route
        # that renders, doctrine 4).
        self._floors(fam, unit)
        try:
            svg = self._draw(fam, unit)
        except SolidError as e:
            if "read against nothing" not in str(e) or \
                    getattr(self, "_probing", False):
                raise
            raise SolidError(str(e) + self._nothing_routes(fam, str(e),
                                                           asked))
        w, h = self.width_of(svg), self.height_of(svg)
        if w > W + 1e-6 or h > H + 1e-6:
            _bad("render", "%s comes out %.0fx%.0fpx, over the %s tier "
                 "(%.0fx%.0f)" % (fam, w, h, self.tier, W, H),
                 "draw it at tier='side' or tier='block', or give a smaller "
                 "unit=")
        return svg

    def _draw(self, fam, unit, lenient=False):
        """Render, and when a NUMBER cannot be placed beside the edge it
        names, move that number to a dimension line outside the drawing and
        draw again. (The label solver is the only thing that can decide
        this: it knows where every label and every stroke ended up. So the
        kit asks it, reads which number it could not place, and offers the
        house's other way of writing that number — never a smaller font, and
        never one number fewer.)"""
        for _ in range(4):
            try:
                return self._render(fam, unit, lenient=lenient)
            except AssertionError as e:
                m = re.search(r"label '([^']+)'", str(e))
                if not m or m.group(1) in self._dim_texts:
                    raise
                if not any(lb[0] == "edge" and lb[3] == m.group(1)
                           for lb in self.labels):
                    raise
                self._dim_texts.add(m.group(1))
        return self._render(fam, unit, lenient=lenient)

    def _floors(self, fam, unit):
        ex, ey = self._extent()
        long = max(ex, ey) * unit
        if long < _FLOOR[self.tier] - 1e-6:
            bigger = {"item": "tier='side'", "side": "tier='block'",
                      "block": "a bigger unit="}[self.tier]
            _bad("render", "the drawing comes out %.0fpx across, under the "
                 "%.0fpx floor for tier=%r" % (long, _FLOOR[self.tier],
                                               self.tier),
                 "draw it at %s (tier='side' is 210px, tier='block' 420px) "
                 "— never at a smaller font" % bigger)
        # r1 (a floor on the SHORT side refused prism('triangle', L=10) at
        # every tier: a 6-wide, 10-tall prism fitted to the tier's height is
        # 40px wide and no tier changes that — the aspect ratio does, and the
        # author cannot). What must never happen is a SLIVER: an edge drawn
        # so short that it reads as a dot.
        thin = None
        for d in self.solids:
            for a, b in _edges_of(d.faces):
                A, B = d.p2(a), d.p2(b)
                Lpx = math.hypot(B[0] - A[0], B[1] - A[1]) * unit
                if thin is None or Lpx < thin[0]:
                    thin = (Lpx, a + b, math.hypot(B[0] - A[0],
                                                   B[1] - A[1]))
        if thin and thin[0] < _EDGE_FLOOR - 1e-6:
            # r-T1 (doctrine 4): this used to answer every sliver with
            # "draw it at tier='block'", and tier='block' refused the same
            # data with the same sentence — the author reading the refusal
            # went round in a circle. A bigger tier only helps when the
            # bigger tier really clears the floor, so work out what the
            # edge would measure there and say which it is.
            # the unit THIS render really got is the honest scale (the
            # tier's own box over-states it: the labels take room too), so
            # the other tiers are read off it.
            grow = dict((t, min(TIERS[t][0] / TIERS[self.tier][0],
                                TIERS[t][1] / TIERS[self.tier][1]))
                        for t in TIERS)
            big = max(((unit * grow[t], t) for t in TIERS),
                      key=lambda x: x[0])
            at_big = thin[2] * big[0]                  # honest: labels paid
            hope = thin[2] * _biggest_unit(TIERS[big[1]], ex, ey)  # best case
            if at_big >= _EDGE_FLOOR and big[1] != self.tier:
                fix = ("draw it at tier=%r, where that edge comes out "
                       "%.0fpx" % (big[1], at_big))
            elif hope >= _EDGE_FLOOR and big[1] != self.tier:
                fix = ("draw it at tier=%r — that edge comes out about %.0fpx "
                       "there, right on the floor; if it is refused again "
                       "the proportion is the cause and that edge needs a "
                       "bigger number (it is %s against a figure %.0f times "
                       "its size)" % (big[1], hope, _n(_RAW(self, thin[1])),
                                      max(ex, ey) / (thin[2] or 1e-9)))
            else:
                # the proportion is the cause; name the smallest datum that
                # reads, in the author's own units, and the way out that
                # does not need one.
                # the datum that clears the floor, allowing for the fact
                # that a longer edge also makes the drawing bigger and so
                # takes the unit back down (a fixed point in three steps;
                # naming a value that is refused again is the very fault
                # this message is fixing)
                W0, H0 = TIERS[big[1]]
                base = _biggest_unit((W0, H0), ex, ey)
                seen = thin[2] or 1e-9
                need = seen * _EDGE_FLOOR / max(at_big, 1e-9)
                for _ in range(24):
                    dd = max(need - seen, 0.0)
                    u2 = big[0] * _biggest_unit((W0, H0), ex + dd, ey + dd) \
                        / max(base, 1e-9)
                    nxt = _EDGE_FLOOR / max(u2, 1e-9)
                    if abs(nxt - need) < 1e-4 * max(need, 1e-9):
                        need = nxt
                        break
                    need = nxt
                fix = ("that edge is %.0f times shorter than the figure, so "
                       "no tier can show it: give it at least %s (it is %s "
                       "now, drawn %.1fpx at the widest tier %r), or leave "
                       "that direction out and draw the face flat with "
                       "shapekit/rectkit"
                       % (max(ex, ey) / seen,
                          _n(_roundup(1.12 * need * _RAW(self, thin[1])
                                      / seen)),
                          _n(_RAW(self, thin[1])), at_big, big[1]))
            _bad("render", "edge %s is drawn %.1fpx long, under the %.0fpx "
                 "floor" % (thin[1], thin[0], _EDGE_FLOOR), fix)

    def _fit(self, fam, W, H):
        """The largest unit whose finished figure fits the tier box.

        BOUNDED. The first version was a 30-step solve over a 40-step retry
        inside a 60-step shrink: a figure whose label placement failed took
        thousands of renders and minutes of wall clock (prism + base
        altitude, measured). Every figure in this skill renders or REFUSES in
        about three seconds, so the fit counts its renders and its seconds,
        and when it runs out it refuses with the drawing's own reason."""
        ex, ey = self._extent()
        t0 = time.time()
        self._fit_fails = 0
        u = min(W / max(ex, 1e-9), H / max(ey, 1e-9)) * 0.72
        for _ in range(6):
            svg = self._lenient(fam, u, t0)
            w, h = self.width_of(svg), self.height_of(svg)
            cx, cy = w - ex * u, h - ey * u          # what the labels add
            u2 = min((W - 1.0 - cx) / max(ex, 1e-9),
                     (H - 1.0 - cy) / max(ey, 1e-9))
            if abs(u2 - u) < 0.02 * u:
                u = u2
                break
            u = u2
        for _ in range(12):
            svg = self._lenient(fam, u, t0)
            if self.width_of(svg) <= W + 1e-6 and \
                    self.height_of(svg) <= H + 1e-6:
                return u
            u *= 0.94
        return u

    def _lenient(self, fam, u, t0=None):
        """A calibration render: a face too small for its text still draws."""
        last = None
        quick = getattr(self, "_fail_fast", None)
        for _ in range(8):
            if last is not None and quick is not None and \
                    getattr(self, "_fit_fails", 0) >= quick:
                # v6.7: a caller with other routes to try (describe tries the
                # next tier) stops a FAILING fit after `quick` failed draws --
                # a COUNT, so the outcome is the same on a busy machine; a
                # fit that is succeeding is never cut short
                _bad("render", "%s could not be fitted: %d draws failed"
                     % (fam, self._fit_fails),
                     "the last thing in the way was: %s" % last)
            if t0 is not None and time.time() - t0 > _FIT_SECONDS:
                raise SolidMachineError(
                    "solidkit.render: MACHINE PROBLEM, not a refusal -- the "
                    "fit of %s ran over the %.0f s safety net (the figure's "
                    "work is bounded by counts; this machine is overloaded "
                    "or stalled). Run it again on an idle machine."
                    % (fam, _FIT_SECONDS))
            try:
                return self._draw(fam, u, lenient=True)
            except AssertionError as e:
                # v6.6 S: the WHOLE message. It used to be cut at 160
                # characters, mid-word, and the escape the inner refusal
                # names was the part that was cut ("Enlarge the figure (si").
                last = str(e)
                self._fit_fails = getattr(self, "_fit_fails", 0) + 1
                u *= 1.08
        _bad("render", "%s cannot be drawn at any size the fit tried" % fam,
             "the drawing itself refuses: %s%s" % (last or "—",
                                                   self._routes(fam, last)))

    def _routes(self, fam, msg):
        """v6.6 S: the solid-level routes for a fit refusal, each one TRIED
        before it is named (doctrine 4). figkit's own advice ("Enlarge the
        figure (size=)") names a knob solidkit does not have, and the static
        list this replaced offered tier='block' to a figure already at
        block. A route is: the next tier up; the automatic label the refusal
        is about moved onto a dimension line; that label left out (its
        length then stated in the question's words)."""
        if getattr(self, "_probing", False):
            return ""
        texts = set(re.findall(r"'([^']{1,12})'", msg or ""))
        cands = []
        order = ["item", "side", "block"]
        if self.tier != "block":
            cands.append(("tier=%r" % order[order.index(self.tier) + 1],
                          "tier", order[order.index(self.tier) + 1]))
        nxt = (order[order.index(self.tier) + 1]
               if self.tier != "block" else None)
        for si, sol in enumerate(self.solids):
            for ek, rec in sorted(sol._edge_labels.items(),
                                  key=lambda kv: kv[1]["edge"]):
                if rec["text"] not in texts:
                    continue
                if not rec["auto"]:
                    # r1: a number the AUTHOR put there can be left out
                    # too -- it used to be skipped, and the refusal then
                    # named nothing but an option solidkit does not have
                    said = ("leave out the edge_label(%r) call (state %s = "
                            "%s in the question's text instead)"
                            % (rec["edge"], rec["edge"], rec["text"]))
                    cands.append((said, "drop", (si, ek)))
                    if nxt:
                        cands.append(("tier=%r and %s" % (nxt, said),
                                      "drop+tier", (si, ek, nxt)))
                    continue
                k = rec.get("key") or "?"
                if nxt:
                    cands.append(("tier=%r with labels={%r: None} (state %s "
                                  "= %s in the question's text instead)"
                                  % (nxt, k, rec["edge"], rec["text"]),
                                  "drop+tier", (si, ek, nxt)))
                if rec["mode"] != "dim":
                    cands.append(("labels={%r: None} on the solid, then "
                                  "edge_label(%r, dim=True)" % (k, rec["edge"]),
                                  "dim", (si, ek)))
                cands.append(("labels={%r: None} (state %s = %s in the "
                              "question's text instead)"
                              % (k, rec["edge"], rec["text"]),
                              "drop", (si, ek)))
        good = []
        import export as _xp                 # a probe is not a figure
        saved = (dict(_xp._FIGS), list(_xp._ORDER))
        try:
            self._probe(fam, cands, good)
        finally:
            _xp._FIGS.clear()
            _xp._FIGS.update(saved[0])
            _xp._ORDER[:] = saved[1]
        if "read against nothing" in (msg or ""):
            more = self._nothing_routes(fam, msg, {})
            if more:
                return more
        if good:
            return (" || in solidkit, tried and renders: %s"
                    % "; or ".join(good))
        return (" || in solidkit, none of %s renders either: the data "
                "itself is too thin to draw readably at a printed size -- "
                "give the thin length a bigger number, or leave the solid "
                "out and draw the face that matters flat (shapekit / "
                "rectkit)"
                % (", ".join(c[0] for c in cands) or "the solid-level "
                   "routes"))

    def _nothing_routes(self, fam, msg, rkw):
        """v6.7 (S2-read-against-nothing-placeholder-routes): the routes for
        a number that could only float off the drawing, as CALLS WITH THEIR
        VALUES, each one drawn before it is named: the number written inside
        each face that has the edge (edge_label(..., inside='BCFE')), and --
        a scene holding one solid and its labels -- the solid turned onto
        each lateral face (pose=('ABED', 90)). It used to name
        'inside=<face>' and a bare 'pose=', which the author then had to
        guess. Bounded by counts (_PROBE_MAX renders of each kind)."""
        if getattr(self, "_probing", False):
            return ""
        texts = set(re.findall(r"label '([^']{1,12})'", msg or ""))
        good, tried = [], []
        import export as _xp                 # a probe is not a figure
        saved = (dict(_xp._FIGS), list(_xp._ORDER))
        try:
            for si, sol in enumerate(self.solids):
                if sol.curved:
                    continue
                for ek, rec in sorted(sol._edge_labels.items(),
                                      key=lambda kv: kv[1]["edge"]):
                    if rec["text"] not in texts or "ends" not in rec:
                        continue
                    a, b = rec["ends"]
                    faces = ["".join(f) for f in sol.faces
                             if a in f and b in f]
                    for face in faces[:_PROBE_MAX]:
                        said = ("edge_label(%r, %r, inside=%r)"
                                % (rec["edge"], rec["text"], face))
                        tried.append(said)
                        try:
                            trial = copy.deepcopy(self)
                            trial._probing = True
                            trial._fail_fast = _PROBE_FAILS
                            ts = trial.solids[si]
                            ts._unlabel(ek)
                            ts.edge_label(rec["edge"], text=rec["text"],
                                          given=rec["given"], inside=face,
                                          check=rec["check"])
                            trial.render(fam, **rkw)
                        except AssertionError:
                            continue
                        good.append(said)
                        break
                    for pose in self._poses_for(sol)[:_PROBE_MAX]:
                        said = ("the same solid built with pose=%r" % (pose,))
                        tried.append(said)
                        try:
                            trial = self._reposed(sol, pose)
                            if trial is None:
                                break
                            trial.render(fam, **rkw)
                        except AssertionError:
                            continue
                        good.append(said)
                        break
        finally:
            _xp._FIGS.clear()
            _xp._FIGS.update(saved[0])
            _xp._ORDER[:] = saved[1]
        if good:
            return (" || in solidkit, tried and renders: %s"
                    % "; or ".join(good))
        return (" || in solidkit, none of %s renders either -- leave the "
                "number out of the drawing and state it in the question's "
                "text" % (", ".join(tried) or "the face and pose routes"))

    def _poses_for(self, sol):
        """The poses a lying solid can take: on each lateral face (4+
        corners first), turned either way."""
        if len(self.solids) != 1 or sol.data.get("pose") not in (None, "",
                                                                 "base"):
            return []
        fs = sorted(("".join(f) for f in sol.faces),
                    key=lambda f: (-len(f), f))
        return [(f, y) for f in fs if len(f) >= 4 for y in (90, -90)]

    def _reposed(self, sol, pose):
        """A copy of this scene with its one solid re-built in `pose`, its
        letters and its edge labels re-applied -- or None when the scene
        holds anything else (an add-on this cannot re-draw)."""
        sc2 = Scene(side=self.side, tier=self.tier, unit=self.unit,
                    hidden=self.hidden)
        sc2._probing, sc2._fail_fast = True, _PROBE_FAILS
        sc2.kindname = getattr(self, "kindname", None)
        d2 = Solid(sc2, _posed(sol.V, sol.faces, pose), sol.faces, sol.kind,
                   dict(sol.data, pose=pose), convex=sol.convex,
                   opaque=sol.opaque, metrics=sol.metrics)
        d2.draw()
        if sol._named:
            d2.names()
        for _ek, rec in sorted(sol._edge_labels.items(),
                               key=lambda kv: kv[1]["edge"]):
            d2.edge_label(rec["edge"], text=rec["text"], given=rec["given"],
                          dim=rec["dim"], t=rec["t"], check=rec["check"],
                          inside=rec["inside"], _auto=rec["auto"])
        # the scene must be exactly the solid, its letters and its labels
        if len(sc2.strokes) != len(self.strokes) or \
                len(sc2.labels) != len(self.labels) or self.fills or \
                self.angles or self.named or sol.extra:
            return None
        return sc2

    def _probe(self, fam, cands, good):
        # v6.7: a COUNT of candidates (and of failing draws per candidate),
        # never the 1.2 s it used to be -- the routes a refusal names are
        # the same on every machine
        for said, how, arg in cands[:_PROBE_MAX]:
            if len(good) >= 2:
                break
            try:
                trial = copy.deepcopy(self)
                trial._probing = True
                trial._fail_fast = _PROBE_FAILS
                if how == "tier":
                    trial.tier = arg
                else:
                    if how == "drop+tier":
                        trial.tier = arg[2]
                    sol = trial.solids[arg[0]]
                    rec = sol._edge_labels[arg[1]]
                    sol._unlabel(arg[1])
                    if how == "dim":
                        sol.edge_label(rec["edge"], text=rec["text"],
                                       dim=True)
                trial.render(fam)
            except AssertionError:
                continue
            good.append(said)

    def _render(self, fam, unit, font=LABEL_PX, lenient=False):
        T = lambda p: (p[0] * unit, -p[1] * unit)     # maths y up -> SVG y down
        f = Figure()
        f.projection = "cabinet%g:%s" % (CAB_DEG, self.side)
        if getattr(self, "depth", CAB_K) != CAB_K:
            f.projection += ":k%.6g" % self.depth
        self.ex = f.ex                       # v6.5: the objects export
        # v6.6 E (X1R2-04): `xy` is in THE SOLID'S OWN UNITS -- the cabinet
        # picture of the solid measured in the numbers the question prints
        # (a front-face edge of 5 reads 5; a depth edge reads its projected
        # CAB_K share) -- so view.data_to_svg and data_unit_px are real, and
        # every named point also carries its `xyz` in the posed 3D frame.
        _u = float(unit)
        f.ex.set_data(lambda q, _u=_u: (q[0] / _u, -q[1] / _u))
        f.ex.kindname = getattr(self, "kindname", None) or (
            "solidkit.%s" % "+".join(sorted(set(
                str(getattr(d, "kind", "solid")) for d in self.solids)))
            if self.solids else "solidkit.solid")
        f.ex.fam = fam
        # a solid is placed by its POSE, not by a plane rotation; the view
        # reports the yaw so a caller can undo it
        f.rotate = float((getattr(self, "pose", None) or (None, 0.0))[1] or 0.0)
        dims, lanes = [], []
        _space = []
        for pts, col in self.fills:
            f.poly([T(p) for p in pts], width=0.0, fill=col, record=False)
        for s in self.strokes:
            k = s["kind"]
            if k == "line":
                f.line(T(s["a"]), T(s["b"]), s["w"], dash=s["dash"])
                if s.get("hid"):
                    f.ex.constrain("hidden_edge",
                                   of=[T(s["a"]), T(s["b"])], strict=False)
            elif k == "curve":
                f.curve([T(p) for p in s["pts"]], width=s["w"],
                        dash=s["dash"])
            elif k == "right":
                f.right_angle(T(s["v"]), T(s["a"]), T(s["b"]), size=s["size"])
            elif k == "rmark":
                V0, A0, B0 = T(s["v"]), T(s["a"]), T(s["b"])
                d = float(s["size"])
                u = []
                for Q in (A0, B0):
                    L = math.hypot(Q[0] - V0[0], Q[1] - V0[1]) or 1.0
                    u.append(((Q[0] - V0[0]) / L, (Q[1] - V0[1]) / L))
                P1 = (V0[0] + u[0][0] * d, V0[1] + u[0][1] * d)
                P2 = (V0[0] + u[1][0] * d, V0[1] + u[1][1] * d)
                P3 = (P1[0] + u[1][0] * d, P1[1] + u[1][1] * d)
                # v6.6 E r1 (E-solid-ra-export): the two strokes are the
                # MARK's ink (role "mark"), not two 7px data segments, and
                # the mark's id wraps them (V2-N4)
                _ra_parts = [len(f.parts), len(f.parts) + 1]
                f.line(P1, P3, 1.0, role="mark")
                f.line(P2, P3, 1.0, role="mark")
                # v6.6 S r1: the mark printed on paper is an OBJECT of the
                # export (ra-<vertex>). Its perpendicular is a fact about the
                # solid, which the cabinet projection does not keep at 90
                # degrees, so it is recorded in the figure's v3dang tag
                # (Solid.right_mark) and not as a re-measurable constraint
                # (spec section 8).
                _ra = f.ex.add("right_angle", [V0], role="mark",
                               meta={"_k": "space:%.3f,%.3f"
                                     % (math.atan2(u[0][1], u[0][0]),
                                        math.atan2(u[1][1], u[1][0])),
                                     "space": True, "_parts": _ra_parts,
                                     "_corner": tuple(P3)})
                if s.get("sp"):
                    # v6.8 r2 (G7): the corner's three points are points of
                    # the export with their xyz, and the mark's fact is
                    # stated in space after the ids are known
                    _space.append(("perpendicular",
                                   _space_pts(f, (V0, A0, B0), s["sp"]),
                                   _ra, None))
            elif k == "arc":
                f.arc(T(s["v"]), T(s["a"]), T(s["b"]), r=s["r"], n=s["n"])
            elif k == "dot":
                f.dot(T(s["a"]), r=2.4)
            elif k == "ticks":
                A, B, tt = T(s["a"]), T(s["b"]), s["t"]
                if tt < 0.5:                 # figkit ticks a segment's middle
                    B = (A[0] + 2 * tt * (B[0] - A[0]),
                         A[1] + 2 * tt * (B[1] - A[1]))
                elif tt > 0.5:
                    A = (A[0] + (2 * tt - 1) * (B[0] - A[0]),
                         A[1] + (2 * tt - 1) * (B[1] - A[1]))
                f.ticks(A, B, n=s["n"], size=6)
                if s.get("sp"):
                    _tk = [it for it in f.ex.items if it.kind == "ticks"][-1]
                    _space.append(("equal_length",
                                   _space_pts(f, (T(s["a"]), T(s["b"])),
                                              s["sp"]), _tk, s["n"]))
            elif k == "dim":
                dims.append((T(s["a"]), T(s["b"]), s["off"], s["text"],
                             s.get("lane"), s.get("wit", False),
                             [T(q) for q in s["ref"]] if s.get("ref")
                             else None))
        for p_, n_ in self.named:
            f.ex.name_point(T(p_), n_, role="point")
        # v6.6 E (z47): every vertex of every solid is a NAMED point of the
        # export (pt-A, and so seg-AB for its edges) whether or not its
        # letter is printed -- the author's AI can say "the edge AB" of a
        # prism drawn without letters. A letter two solids of one scene
        # share is left out (it would name two points).
        _cnt = {}
        for _d in self.solids:
            for _k in _d.V:
                _cnt[_k] = _cnt.get(_k, 0) + 1
        # only a vertex the drawing has ink at (hidden='omit' leaves the
        # back corner undrawn: there is nothing to point at)
        _ends = []
        for _pk in f.parts:
            if _pk[0] in ("line", "poly", "path") and _pk[2] > 0:
                _ends += list(_pk[1])
        for _d in self.solids:
            for _k, _v in sorted(_d.V.items()):
                _q = T(_d.p2(_k))
                if _cnt.get(_k) == 1 and any(
                        abs(_e[0] - _q[0]) < 0.05 and abs(_e[1] - _q[1]) < 0.05
                        for _e in _ends):
                    f.ex.name_point(_q, _k, role="vertex")
        ink = []
        for q in list(f.segs):
            ink += [q[0], q[1]]
        for A, B, off, text, lane, wit, ref in dims:
            _dim(f, A, B, off, text, font, pts=ink, lanes=lanes,
                 lane_key=lane, wit=wit, ref=ref)
        inside_checks, taken = [], []
        for lb in self.labels:
            kind = lb[0]
            if kind == "edge":
                _, a, b, text, away, gap, tt, own = lb
                A, B, Wp = T(a), T(b), T(away)
                m = (A[0] + tt * (B[0] - A[0]), A[1] + tt * (B[1] - A[1]))
                L = math.hypot(B[0] - A[0], B[1] - A[1]) or 1.0
                nn = (-(B[1] - A[1]) / L, (B[0] - A[0]) / L)
                if nn[0] * (m[0] - Wp[0]) + nn[1] * (m[1] - Wp[1]) < 0:
                    nn = (-nn[0], -nn[1])
                alts = self.alt_edges.get((tuple(a), tuple(b), text), [])
                try:
                    _edge_number(f, A, B, text, nn, font, ink, taken,
                                 own=own, force_dim=text in self._dim_texts,
                                 lanes=lanes,
                                 at=None if abs(tt - 0.5) < 1e-9 else m)
                except SolidError as e:
                    # r1: a length the SOLID chose where to print (a box's
                    # c on AE) may go on an equal parallel edge instead,
                    # when on AE it could only float off the drawing
                    if "read against nothing" not in str(e) or not alts:
                        raise
                    for k, (a2, b2) in enumerate(alts):
                        A, B = T(a2), T(b2)
                        m = ((A[0] + B[0]) / 2.0, (A[1] + B[1]) / 2.0)
                        L = math.hypot(B[0] - A[0], B[1] - A[1]) or 1.0
                        nn = (-(B[1] - A[1]) / L, (B[0] - A[0]) / L)
                        if nn[0] * (m[0] - Wp[0]) + \
                                nn[1] * (m[1] - Wp[1]) < 0:
                            nn = (-nn[0], -nn[1])
                        try:
                            _edge_number(f, A, B, text, nn, font, ink,
                                         taken, own=own,
                                         force_dim=text in self._dim_texts,
                                         lanes=lanes)
                            break
                        except SolidError as e2:
                            if "read against nothing" not in str(e2) or \
                                    k == len(alts) - 1:
                                raise
            elif kind == "edge_in":
                _, a, b, text, poly = lb
                A, B = T(a), T(b)
                tp = [T(p) for p in poly]
                cen = (sum(p[0] for p in tp) / len(tp),
                       sum(p[1] for p in tp) / len(tp))
                L = math.hypot(B[0] - A[0], B[1] - A[1]) or 1.0
                nn = (-(B[1] - A[1]) / L, (B[0] - A[0]) / L)
                m = ((A[0] + B[0]) / 2.0, (A[1] + B[1]) / 2.0)
                if nn[0] * (cen[0] - m[0]) + nn[1] * (cen[1] - m[1]) < 0:
                    nn = (-nn[0], -nn[1])                 # nn points inward
                hx = max(len(text), 1) * 0.58 * font / 2.0
                off = abs(nn[0]) * hx + abs(nn[1]) * 0.51 * font + 5.0
                c = None
                for tt in (0.5, 0.62, 0.38, 0.74, 0.26):
                    want = (A[0] + tt * (B[0] - A[0]) + nn[0] * off,
                            A[1] + tt * (B[1] - A[1]) + nn[1] * off)
                    try:
                        c = _inside_spot(f, tp, text, font, want, taken,
                                         near=6.0)
                        break
                    except AssertionError:
                        continue
                if c is None:                 # no room inside: go outside
                    _ray_label(f, m, text, (-nn[0], -nn[1]), font)
                    # v6.6 E r1 (X1R2-03): tied to its edge
                    f.labels[-1].export_owner = (tuple(A), tuple(B))
                    continue
                taken.append((c[0] - hx, c[1] - 0.51 * font,
                              c[0] + hx, c[1] + 0.51 * font))
                start = font * 0.62 + 2.0
                f.label((c[0], c[1] + 0.27 * font - start), text, size=font,
                        prefer=(0.0, 1.0), italic=_italic(text))
                f.labels[-1].export_owner = (tuple(A), tuple(B))
                inside_checks.append((f.labels[-1], tp, text))
            elif kind == "inside":
                _, pts, text, at = lb
                tp = [T(p) for p in pts]
                want = T(at) if at else (sum(p[0] for p in tp) / len(tp),
                                         sum(p[1] for p in tp) / len(tp))
                c = _inside_spot(f, tp, text, font, want, taken,
                                 lenient=lenient)
                hx = max(len(text), 1) * 0.58 * font / 2.0
                taken.append((c[0] - hx, c[1] - 0.51 * font,
                              c[0] + hx, c[1] + 0.51 * font))
                start = font * 0.62 + 2.0
                f.label((c[0], c[1] + 0.27 * font - start), text, size=font,
                        prefer=(0.0, 1.0), italic=_italic(text))
                # v6.6 E r1 (X1R2-03): a number inside a face names the face
                # -- the face is an object (poly-..., role face, wrapping its
                # fill where it has one) and the number's `for` is its id
                _face_object(f, tp)
                f.labels[-1].export_face = [tuple(p) for p in tp]
                inside_checks.append((f.labels[-1], tp, text))
            elif kind == "free":
                _, at, text, prefer, gap = lb[:5]
                pr = (prefer[0], -prefer[1]) if prefer else (0.0, -1.0)
                nn = math.hypot(*pr) or 1.0
                _ray_label(f, T(at), text, (pr[0] / nn, pr[1] / nn), font,
                           extra=gap - 2.0)
                if len(lb) > 5:                  # a solid's caption
                    hull = [T(p) for p in lb[5]]
                    _face_object(f, hull, role="solid")
                    f.labels[-1].export_face = hull
                if any(n_ == text and p_ == at for p_, n_ in self.named):
                    f.labels[-1].export_point = T(at)     # lbl-M for pt-M
            elif kind == "alt":
                _, poly, text, top, foot = lb
                tp = [T(p) for p in poly]
                Tt, Tf = T(top), T(foot)
                hx = max(len(text), 1) * 0.58 * font / 2.0
                placed = False
                for sgn in (1.0, -1.0):
                    want = (Tf[0] + sgn * (hx + 5.0),
                            (Tt[1] + Tf[1]) / 2.0)
                    try:
                        c = _inside_spot(f, tp, text, font, want, taken,
                                         near=max(18.0, 1.6 * font))
                    except AssertionError:
                        continue
                    taken.append((c[0] - hx, c[1] - 0.51 * font,
                                  c[0] + hx, c[1] + 0.51 * font))
                    start = font * 0.62 + 2.0
                    f.label((c[0], c[1] + 0.27 * font - start), text,
                            size=font, prefer=(0.0, 1.0),
                            italic=_italic(text))
                    # v6.6 E r1 (X1R2-03): the altitude's number is tied to
                    # the altitude (for = its segment id)
                    f.labels[-1].export_owner = (tuple(Tt), tuple(Tf))
                    inside_checks.append((f.labels[-1], tp, text))
                    placed = True
                    break
                if not placed:
                    # the dimension lines were emitted before this loop, so
                    # this one is drawn here, not queued behind them (r4: the
                    # altitude's number simply vanished from the figure)
                    _dim(f, Tf, Tt, "out-", text, font, pts=ink,
                         lanes=lanes)
            elif kind == "letter":
                _, v, text, poly, outside, prefer = lb
                f.ex.name_point(T(v), text, role="vertex")
                _place_letter(f, T(v), text, font, [T(p) for p in poly],
                              taken, outside=outside,
                              prefer=(prefer[0], -prefer[1]) if prefer
                              else None)
            elif kind == "vertex":
                _, v, text, poly = lb
                # v6.5: a solid's vertex names ITSELF where it is drawn, so
                # the export's `pt-A` is the A of the 3D data, not a guess
                # from the letter that happens to stand near it
                f.ex.name_point(T(v), text, role="vertex")
                if poly:
                    f.vertex_label(T(v), text, poly=[T(p) for p in poly],
                                   size=font)
                else:
                    f.label(T(v), text, size=font, kind="vertex")
        for name, a, b, given, factor in self.checks:
            A, B = T(a), T(b)
            f.expect(name, math.hypot(B[0] - A[0], B[1] - A[1]) / factor,
                     given)
        if lenient:
            return f.render()
        svg = f.render()
        self._export_xyz(f.ex)
        _space_cons(f.ex, _space)
        for L, tp, text in inside_checks:
            bx = L.box
            cc = ((bx[0] + bx[2]) / 2.0, (bx[1] + bx[3]) / 2.0)
            if not _in_poly(cc, tp):
                raise SolidError(
                    "solidkit: %r was pushed outside its face (%s) — draw it "
                    "at tier='side' or 'block', or label the edge instead"
                    % (text, fam))
        svg = _tag(svg, self._fam_nts(fam))
        svg += "<!--v3d:%s-->" % self._v3d()
        if self.angles:
            svg += "<!--v3dang:%s-->" % self._v3dang()
        return assert_unstruck(svg, self._fam_nts(fam))

    def _export_xyz(self, ex):
        """v6.6 E (X1R2-04): each named point's 3D coordinates, in the
        solid's units and posed frame (the same numbers the v3d tag
        claims), and the view says what `xy` is."""
        at = {}
        for d in self.solids:
            pts = dict(d.V)
            pts.update(d.extra)
            for k, v in pts.items():
                at.setdefault(str(k), v)
        printed = set(it.meta.get("for") for it in ex.items
                      if it.kind == "label")
        for it in ex.items:
            if it.kind == "point" and it.name in at:
                v = at[it.name]
                it.meta["xyz"] = [round(float(c), 6) + 0.0 for c in v]
                # a vertex named in the export whose letter the figure does
                # not print: the reader sees no 'A' there
                it.meta["letter_printed"] = it.name in printed
        # a point the PICTURE puts on a segment is a fact about the solid
        # only when it is so in space: a back vertex projected onto a front
        # edge (a lying isosceles prism's D on BC) is a coincidence of the
        # projection, and the export does not state it
        def _on3(p, a, b, t=None):
            ab = [b[i] - a[i] for i in range(3)]
            ap = [p[i] - a[i] for i in range(3)]
            L2 = sum(x * x for x in ab) or 1e-12
            tt = sum(ab[i] * ap[i] for i in range(3)) / L2
            off = math.sqrt(sum((ap[i] - tt * ab[i]) ** 2 for i in range(3)))
            return off <= 1e-6 * max(1.0, math.sqrt(L2)) and (
                t is None or abs(tt - t) <= 2e-3)
        keep = []
        for c in ex.cons:
            if c.source == "derived" and c.type in ("on_segment", "midpoint",
                                                    "collinear"):
                f = c.f
                try:
                    if c.type == "collinear":
                        P = [at[str(n)] for n in f["points"]]
                        ok = all(_on3(q, P[0], P[-1]) for q in P[1:-1])
                    else:
                        t = f.get("t", 0.5 if c.type == "midpoint" else None)
                        ok = _on3(at[str(f["point"])], at[str(f["of"][0])],
                                  at[str(f["of"][1])], t)
                except KeyError:
                    ok = False
                if not ok:
                    continue
            keep.append(c)
        ex.cons = keep
        if ex.view is not None:
            ex.view["frame"] = (
                "a net laid flat in the solid's units (xy); no projection"
                if str(getattr(self, "kindname", "") or "").startswith(
                    "solidkit.net") else
                "cabinet projection in the solid's units "
                "(xy); named points carry xyz in 3D")
        return ex

    def _fam_nts(self, fam):
        """A figure whose numbers are NOT all at one scale says so.

        In this projection a length is drawn true (in the front plane) or at
        half length (along the depth axis) — and a reader can measure either.
        Turn the solid by a yaw and neither holds: every edge is drawn at
        some angle's worth of its length, so two numbers on one figure stand
        beside strokes whose ratio is not their own. That is the "not to
        scale" case the house already has a tag for (`+nts`; emit_plus
        prints the Hebrew caption from it). It is DETECTED, from the same
        shrink factors the proportion checks are made of, not declared by
        the caller."""
        if "+nts" in (fam or ""):
            return fam
        for _name, _a, _b, _given, factor in self.checks:
            if min(abs(factor - 1.0), abs(factor - CAB_K)) > 0.02:
                return fam + "+nts"
        return fam

    def _v3d(self):
        """What the figure CLAIMS its points are, in the posed 3D frame, so
        an independent reader can check the drawing against the solid: the
        projection of every claim must land on the ink, the dashed set must
        be the hidden set that follows from them, and a right-angle mark or
        an angle text must be the angle they make in SPACE. Written last, as
        a comment, exactly like the fam tag."""
        out = []
        for d in self.solids:
            pts = dict(d.V)
            pts.update(d.extra)
            out.append("%s{%s}" % (d.kind, ";".join(
                "%s=%.6g,%.6g,%.6g" % (k, v[0], v[1], v[2])
                for k, v in sorted(pts.items()))))
        return "|".join(out)

    def _v3dang(self):
        """The angle claims, as `kind:names=printed text`, separated by ';'.

            angle:C,A,G=90                (three named points)
            linface:A,G|ABCD=35.3         (a segment and a face)
            right:C,A,G=90                (a right-angle MARK, no text)

        A reader recomputes each one from the `v3d` points and compares it
        with the text the figure prints. A text that is not a number (x, 2x)
        is an unknown and is left alone, exactly as the 2D rule does."""
        out = []
        for kind, names, face, text in self.angles:
            key = ",".join(names) + (("|" + face) if face else "")
            out.append("%s:%s=%s" % (kind, key, text or ""))
        return ";".join(out)


def _space_pts(f, p2s, p3s):
    """v6.8 r2 (G7): register the points of a claim made in space as points
    of the export (a vertex keeps the name the solid gives it later; a foot
    with no letter gets an id), each carrying its xyz."""
    out = []
    for q2, q3 in zip(p2s, p3s):
        it = f.ex.add("point", [q2], role="point")
        it.meta.setdefault("xyz", [round(float(c), 6) + 0.0 for c in q3])
        out.append(it)
    return out


def _space_cons(ex, claims):
    """v6.8 r2 (G7): what a solid's marks state, as constraints measured in
    SPACE: a right-angle mark is perpendicular(..., space=True) and ticks of
    one count are equal_length(..., space=True). Every operand is a point of
    the SVG with xyz, so export.recheck and verify_export re-measure them."""
    import export as _xp

    def ref(it):
        if it.name and it.id == "pt-%s" % _xp.slug(it.name):
            return it.name
        return it.id

    def seg(a, b):
        ra, rb = ref(a), ref(b)
        if a.name and b.name and ra == a.name and rb == b.name and \
                len(ra) == 1 and len(rb) == 1:
            return "".join(sorted([ra, rb]))
        return sorted([ra, rb])

    new = []
    ticks = {}
    for kind, pts, mark, n in claims:
        if any(not p.id for p in pts):
            continue
        if kind == "perpendicular":
            V, A, B = pts
            new.append(_xp.Con("perpendicular",
                               {"of": sorted([seg(V, A), seg(V, B)],
                                             key=repr),
                                "at": ref(V), "space": True},
                               "derived", None, True, mark))
        else:
            L = math.sqrt(sum((pts[1].meta["xyz"][i] - pts[0].meta["xyz"][i])
                              ** 2 for i in range(3)))
            ticks.setdefault(n, []).append((seg(*pts), mark, L))
    for n in sorted(ticks, key=lambda v: (v is None, v)):
        # one tick count is one length; two midpoints of unequal edges in
        # one scene both ticked once are two facts, not one
        clusters = []
        for sg, mk, L in ticks[n]:
            for cl in clusters:
                if abs(cl[0] - L) <= 1e-6 * max(1.0, L):
                    if sg not in cl[1]:
                        cl[1].append(sg)
                    if mk not in cl[2]:
                        cl[2].append(mk)
                    break
            else:
                clusters.append([L, [sg], [mk]])
        for L, ops, mks in clusters:
            if len(ops) >= 2:
                c = _xp.Con("equal_length",
                            {"of": sorted(ops, key=repr), "space": True},
                            "derived", None, True, mks[0])
                # v6.7-noam (R3-G7-mark-coverage): every tick of the group
                c.mark_ids = list(mks)
                new.append(c)
    have = set(c.key() for c in ex.cons)
    for c in new:
        _xp.check_fields(c.type, c.f)
        c._pending = False
        c.mark_id = getattr(c.mark_id, "id", c.mark_id)
        if c.mark_ids:
            c.mark_ids = [getattr(m, "id", m) for m in c.mark_ids]
        c._born = (c.source, c.item)
        if c.key() not in have:
            have.add(c.key())
            ex.cons.append(c)
    ex.cons.sort(key=lambda c: (c.type, repr(sorted(c.f.items()))))
    return ex


def finish(scene, fam, unit=None, max_width=None, max_h=None):
    """Render. Named, like `shapekit.finish`, so a page reads
    `finish(s, fam)` and the `fam` is impossible to forget."""
    return scene.render(fam, unit=unit, max_width=max_width, max_h=max_h)


# ================================================================= Solid ===
_MODE_SAID = {"beside": "beside it", "dim": "on a dimension line",
              "inside": "inside a face"}


def _label_call(edge, text, mode, inside, t):
    extra = ""
    if not re.match(r"^-?\d+(\.\d+)?$", str(text)):
        extra += ", text=%r" % text
    if mode == "dim":
        extra += ", dim=True"
    elif mode == "inside":
        extra += ", inside=%r" % (inside,)
    elif abs(t - 0.5) > 1e-9:
        extra += ", t=%s" % _n(t)
    return "edge_label(%r%s)" % (edge, extra)


class Solid(object):
    """One solid on a scene: its vertices in the POSED 3D frame, its faces,
    the maths that goes with it, and the add-ons.

    Every add-on takes vertex NAMES (or 3D points) and computes in the posed
    frame before projecting — shapekit's rule 3, one dimension up, so a
    figure and its extras turn as one rigid body when the pose changes."""

    def __init__(self, sc, V, faces, kind, data, convex=True, opaque=False,
                 metrics=None, curved=None):
        self.sc, self.V, self.faces = sc, dict(V), [tuple(f) for f in faces]
        self.kind, self.data = kind, dict(data or {})
        self.convex, self.opaque = bool(convex), bool(opaque)
        self.metrics = dict(metrics or {})
        self.curved = curved            # round solids draw themselves
        self.extra = {}                 # computed points added by add-ons
        self._named = set()             # vertices whose letter is already on
        # v6.6 S: the number each edge already carries, so a second
        # edge_label() on it ships ONE number (or is refused), and an
        # explicit call replaces the automatic one instead of contending
        # with it: {frozenset(a, b): dict(text, mode, entry, check, auto)}
        self._edge_labels = {}
        sc.solids.append(self)

    # -- access -------------------------------------------------------------
    def p3(self, x):
        """A 3D point from a vertex name, a named add-on point, or a triple."""
        if isinstance(x, str):
            if x in self.V:
                return self.V[x]
            if x in self.extra:
                return self.extra[x]
            _bad("point", "no point named %r in this solid" % x,
                 "its points are %s" % ", ".join(sorted(self.V) +
                                                 sorted(self.extra)))
        if len(x) == 3:
            return tuple(float(v) for v in x)
        _bad("point", "%r is not a point" % (x,),
             "give a vertex letter or an (x, y, z) triple")

    def p2(self, x):
        return self.sc.pr(self.p3(x))

    def face(self, name):
        """A face by its letters in any order, or by the name its own solid
        gives it ('base', 'top', 'front', 'back', 'right', 'left' on a box
        or a cube)."""
        named = getattr(self, "named_faces", None)
        if named and isinstance(name, str) and name.lower() in named:
            name = named[name.lower()]
        elif isinstance(name, str) and name.lower() in _POSE_DIR:
            # r-T1: the same words a POSE may name, resolved from the
            # geometry, so a prism answers to face('base') as a box does
            return _pose_face(self.faces, name, self.V)
        return _find_face(self.faces, name, self.V)

    def poly2(self, face):
        return [self.p2(k) for k in self.face(face)]

    def outline(self):
        """The silhouette: the convex hull of the projected vertices. What a
        vertex letter is placed OUTSIDE of."""
        pts = sorted(set(self.p2(k) for k in self.V))
        if len(pts) < 3:
            return pts
        low = []
        for p in pts:
            while len(low) >= 2 and _cross2(low[-2], low[-1], p) <= 0:
                low.pop()
            low.append(p)
        up = []
        for p in reversed(pts):
            while len(up) >= 2 and _cross2(up[-2], up[-1], p) <= 0:
                up.pop()
            up.append(p)
        return low[:-1] + up[:-1]

    # -- visibility ---------------------------------------------------------
    def visible(self, face):
        f = self.face(face)
        i = self.faces.index(f)
        return visible_faces(self.V, self.faces, self.sc.side)[i]

    def hidden_edges(self):
        """The edges that are hidden IN THIS POSE, computed — never looked up
        in a per-shape table. A convex solid is settled by the face normals;
        anything else (a notch, an L, an open box, a stack) by occlusion, and
        an edge that is hidden only along part of its length is reported by
        the fraction that is hidden."""
        if self.convex:
            return hidden_by_normals(self.V, self.faces, self.sc.side)
        out = set()
        for key, pieces in edge_pieces(self.V, self.faces, self.sc.side,
                                       opaque=True).items():
            if not any(seen for _t0, _t1, seen in pieces):
                out.add(key)
        return out

    # -- drawing ------------------------------------------------------------
    def draw(self, w=1.5, hw=1.0):
        """The solid itself: every visible stretch solid, every hidden one
        dashed (or left out, when the sheet's policy is 'omit')."""
        if self.curved:
            self.curved(self, w, hw)
            return self
        dashed = self.sc.hidden == "dashed"
        if self.convex:
            hid = self.hidden_edges()
            for key in sorted(_edges_of(self.faces)):
                a, b = key
                if key in hid:
                    if dashed:
                        self.sc.line(self.p2(a), self.p2(b), hw, HID, hid=True)
                else:
                    self.sc.line(self.p2(a), self.p2(b), w)
            return self
        for key, pieces in edge_pieces(self.V, self.faces, self.sc.side,
                                       opaque=True).items():
            a, b = key
            A, B = self.p2(a), self.p2(b)
            for t0, t1, seen in pieces:
                p = (A[0] + t0 * (B[0] - A[0]), A[1] + t0 * (B[1] - A[1]))
                q = (A[0] + t1 * (B[0] - A[0]), A[1] + t1 * (B[1] - A[1]))
                if seen:
                    self.sc.line(p, q, w)
                elif dashed:
                    self.sc.line(p, q, hw, HID)
        return self

    def shade(self, face, colour=SHADE):
        self.sc.fill(self.poly2(face), colour)
        return self

    def emph(self, edge, w=2.2):
        a, b = self._edge(edge)
        self.sc.line(self.p2(a), self.p2(b), w)
        return self

    def _edge(self, edge):
        if isinstance(edge, str):
            if len(edge) != 2:
                _bad("edge", "edge=%r" % edge,
                     "an edge is two letters, e.g. edge='AB'")
            a, b = edge[0], edge[1]
        else:
            a, b = edge
        for k in (a, b):
            if k not in self.V and k not in self.extra:
                _bad("edge", "no point %r in this solid" % k,
                     "its vertices are %s" % ", ".join(sorted(self.V)))
        return a, b

    # -- names --------------------------------------------------------------
    def names(self, letters=True, skip=()):
        """A letter at every vertex, outside the silhouette where the vertex
        is on it, and in the widest free wedge between its own edges where it
        is not (the hidden corner).

        IDEMPOTENT (r-T1): `box()` and friends already call this when
        `names=True` (the default), and the docstring example above calls it
        again. Without a guard the second call queued a SECOND letter for
        every vertex, placed at the next free spot up to 19px away, and the
        box printed A A B B C C ... — the solver was right both times and
        nothing was struck, so no check caught it. A vertex whose letter is
        already on the scene is skipped; `skip=` still works, and a vertex
        skipped the first time is lettered by a later call."""
        if not letters:
            return self
        # close-out: two solids on ONE scene (scene=/at=) must not both print
        # A..F at different places — the reader cannot tell which A is which.
        for other in self.sc.solids:
            if other is self:
                continue
            for k in sorted(other._named):
                if k in self.V and k not in skip and k not in self._named:
                    P, Q = self.p2(k), other.p2(k)
                    if math.hypot(P[0] - Q[0], P[1] - Q[1]) > 0.5:
                        free = [c for c in _UP + "KLMNPQRSTUVW"
                                if c not in self.V and c not in other.V]
                        _bad("names", "the letter %r is already on this "
                             "scene, on another solid" % k,
                             "give the second solid its own letters, e.g. "
                             "names=('%s', '%s'), or leave it unlettered "
                             "with names=False"
                             % ("".join(free[:len(self.V) // 2]),
                                "".join(free[len(self.V) // 2:len(self.V)])))
        out = self.outline()
        inc = {}
        for key in _edges_of(self.faces):
            inc.setdefault(key[0], []).append(key[1])
            inc.setdefault(key[1], []).append(key[0])
        for k in sorted(self.V):
            if k in skip or k in self._named:
                continue
            self._named.add(k)
            P = self.p2(k)
            if _in_poly(P, out):
                # an inner (hidden) corner: away from every edge that meets it
                dirs = []
                for o in inc.get(k, []):
                    Q = self.p2(o)
                    L = math.hypot(Q[0] - P[0], Q[1] - P[1]) or 1.0
                    dirs.append(math.atan2((Q[1] - P[1]) / L,
                                           (Q[0] - P[0]) / L))
                best, gap = 0.0, -1.0
                dirs = sorted(dirs) or [0.0]
                for i in range(len(dirs)):
                    a0 = dirs[i]
                    a1 = dirs[(i + 1) % len(dirs)] + (2 * math.pi
                                                      if i == len(dirs) - 1
                                                      else 0.0)
                    if a1 - a0 > gap:
                        gap, best = a1 - a0, 0.5 * (a0 + a1)
                self.sc.letter(P, k, out, outside=False,
                               prefer=(math.cos(best), math.sin(best)))
            else:
                self.sc.letter(P, k, out, outside=True)
        return self

    # -- add-ons ------------------------------------------------------------
    # Every one of these is shapekit's vocabulary, one dimension up: a point
    # at a ratio along an edge, a midpoint, a diagonal, an altitude with its
    # right angle, an angle with its arc and its number, a length written
    # outside the figure. They take NAMES and compute in the posed 3D frame.

    def centre2(self):
        pts = [self.p2(k) for k in self.V]
        return (sum(p[0] for p in pts) / len(pts),
                sum(p[1] for p in pts) / len(pts))

    def _shrink(self, u3):
        """How much the projection shortens a direction: |projected| / |real|.
        1 in the front plane, CAB_K along the depth axis, something between
        on a slant. Computed from the data, so a proportion check compares a
        number with the length the drawing really has."""
        p = project(u3, self.sc.side, getattr(self.sc, "depth", None))
        return math.hypot(p[0], p[1]) / max(norm3(u3), 1e-12)

    def edge_label(self, edge, text=None, given=None, key=None, dim=False,
                   off=13.0, check=True, t=0.5, inside=None, _auto=False):
        """A length beside an edge, OUTSIDE the solid (`dim=True` puts it on
        a dimension line with witness lines, clear of the drawing). The
        number is checked against the edge it names: a label that contradicts
        its own edge is refused, not printed.

        `inside=<face>` writes it INSIDE that face instead. The far side of a
        hypotenuse on a lying prism is a lateral face full of receding and
        hidden edges, and a number pushed out past all of them lands on a
        dimension shaft as wide as the whole drawing — measured on z47's 5א,
        where "15" ended up under the solid on a 90px arrow. Written in the
        triangle it belongs to, it is beside its own edge and nothing else.

        ONE EDGE, ONE NUMBER (v6.6 S). `box()`, `cube()`, `prism()` and
        `pyramid()` already label their edges (labels=True), so a second
        call on the same edge used to print the same number twice ~16px
        apart and ship. Now: the same text in the same form ships once; an
        explicit call on an edge the SOLID labelled automatically replaces
        that label (this is how `edge_label('AB', dim=True)` renders on a
        default box — the auto '9' and the dimension '9' no longer contend
        for one edge); a second, DIFFERENT label on an edge the author
        labelled himself is refused, naming the first."""
        a, b = self._edge(edge)
        A3, B3 = self.p3(a), self.p3(b)
        real = dist3d(A3, B3)
        if given is None:
            given = real
        elif abs(float(given) - real) > 1e-6 * max(real, 1.0):
            _bad("edge_label", "%s is %s long, not %s"
                 % ("".join((a, b)), _n(round(real, 4)), _n(given)),
                 "label the edge it is (given=%s), or name the edge the "
                 "number belongs to" % _n(round(real, 4)))
        if text is None:
            text = _n(round(given, 4))
        mode = ("inside" if inside else "dim" if dim else "beside")
        ek = frozenset((a, b))
        prev = self._edge_labels.get(ek)
        if prev is not None:
            nm = "".join((a, b))
            if prev["text"] == text and (prev["mode"] == mode or _auto):
                return self                  # the same number: ships once
            if prev["auto"] and not _auto:
                self._unlabel(ek)            # the explicit call wins
            elif prev["text"] == text:
                # r1: the same number asked for in a second FORM used to be
                # dropped without a word (the dimension line never came)
                _bad("edge_label", "%s already carries %r %s; a second call "
                     "asks for the same number %s" % (
                         nm, text, _MODE_SAID[prev["mode"]],
                         _MODE_SAID[mode]),
                     "one edge, one number in ONE form: keep a single call, "
                     "%s" % _label_call(prev["edge"], text, mode, inside,
                                        t))
            else:
                if prev["auto"]:
                    fix = ("draw the solid with labels={%r: None} and label "
                           "the edge once: %s" % (prev.get("key") or "?",
                                                  _label_call(nm, text, mode,
                                                              inside, t)))
                else:
                    fix = ("drop one of the two edge_label(%r, ...) calls; "
                           "the number the edge IS is %s" % (
                               prev["edge"], _n(round(real, 4))))
                _bad("edge_label", "%s already carries %r (%s); a second "
                     "number %r beside one edge reads as a second length"
                     % (nm, prev["text"], prev["mode"], text),
                     "one edge, one number: %s" % fix)
        nl, ns, nc = (len(self.sc.labels), len(self.sc.strokes),
                      len(self.sc.checks))
        self._edge_label_draw(a, b, A3, B3, text, given, dim, t, inside,
                              check)
        if _auto and mode == "beside" and not self.curved:
            alts = []
            for e2 in _edges_of(self.faces):
                p, q = self.p3(e2[0]), self.p3(e2[1])
                if frozenset(e2) == ek or abs(dist3d(p, q) - real) > \
                        1e-6 * max(real, 1.0):
                    continue
                u, v = unit3(sub3(B3, A3)), unit3(sub3(q, p))
                if abs(abs(dot(u, v)) - 1.0) < 1e-9:
                    alts.append((self.p2(e2[0]), self.p2(e2[1])))
            if alts:
                self.sc.alt_edges[(tuple(self.p2(a)), tuple(self.p2(b)),
                                   text)] = alts
        self._edge_labels[ek] = dict(
            text=text, mode=mode, auto=bool(_auto), key=key,
            edge="".join((a, b)), ends=(a, b), given=given, dim=bool(dim),
            inside=inside, t=t, check=check,
            labels=self.sc.labels[nl:], strokes=self.sc.strokes[ns:],
            checks=self.sc.checks[nc:])
        return self

    def _unlabel(self, ek):
        """Withdraw the automatic label of one edge (and its proportion
        check) before an explicit one takes its place."""
        rec = self._edge_labels.pop(ek)
        for attr in ("labels", "strokes", "checks"):
            gone = rec[attr]
            setattr(self.sc, attr, [x for x in getattr(self.sc, attr)
                                    if not any(x is g for g in gone)])

    def _edge_label_draw(self, a, b, A3, B3, text, given, dim, t, inside,
                         check):
        A, B = self.p2(a), self.p2(b)
        if inside:
            face = self.face(inside) if inside is not True else None
            if face is None:
                for f in self.faces:
                    if a in f and b in f:
                        face = f
                        break
            if face is None:
                _bad("edge_label", "%s%s is on no face of this solid"
                     % (a, b), "name the face to write in, e.g. inside='ABC'")
            if a not in face or b not in face:
                _bad("edge_label", "%s%s is not a side of face %s"
                     % (a, b, "".join(face)),
                     "write the number in a face the edge belongs to: %s"
                     % ", ".join("".join(f) for f in self.faces
                                 if a in f and b in f))
            self.sc.edge_in(A, B, text, [self.p2(k) for k in face])
            if check:
                self.sc.check("".join((a, b)), A, B, given,
                              self._shrink(sub3(B3, A3)))
            return self
        if dim:
            c2 = self.centre2()
            m = ((A[0] + B[0]) / 2.0, (A[1] + B[1]) / 2.0)
            L = math.hypot(B[0] - A[0], B[1] - A[1]) or 1.0
            nn = (-(B[1] - A[1]) / L, (B[0] - A[0]) / L)   # page-left of A->B
            outward = 1.0 if (nn[0] * (m[0] - c2[0])
                              + nn[1] * (m[1] - c2[1])) > 0 else -1.0
            # Scene.dim takes the page's own sense (y down), the scene's is
            # y up, so the outward sign flips with the flip.
            self.sc.dim(A, B, off="out" if outward > 0 else "out-",
                        text=text)
        else:
            self.sc.value(A, B, text, away=self.centre2(), t=t)
        if check:
            self.sc.check("".join((a, b)), A, B, given,
                          self._shrink(sub3(B3, A3)))
        return self

    def dimension_set(self, spec, labels, where):
        """The lengths a solid's own definition carries (a box's a, b, c; a
        cube's e), each written once, outside the solid."""
        for key in sorted(spec):
            item = spec[key]
            edge, value = item[0], item[1]
            primary = item[2] if len(item) > 2 else True
            asked = isinstance(labels, dict) and key in labels
            if not primary and not asked:
                continue           # there for the asking, not printed unasked
            text = _label_text(where, key, value, labels)
            if text is None:
                continue
            self.edge_label(edge, text=text, given=value, key=key,
                            _auto=True)
        return self

    def face_label(self, face, text, at=None):
        """Text INSIDE a face (an area, a name). Refused — with a renderable
        fix — when the face has no room for it, never squeezed."""
        self.sc.inside(self.poly2(face), text, at=at)
        return self

    def point_at(self, edge, t, name, dot=True, mark=True):
        """A point at ratio `t` along an edge: 'K on AA' so that AK = 2KA''
        is t = 2/3. Computed in 3D, so it stays on its edge at every pose."""
        a, b = self._edge(edge)
        P = point_on3d(self.p3(a), self.p3(b), t)
        self._add_point(name, P, dot, mark)
        return P

    def midpoint(self, edge, name="M", ticks=True, dot=True, mark=True):
        """The midpoint of an edge, with a tick on each half saying so."""
        a, b = self._edge(edge)
        P = midpoint3d(self.p3(a), self.p3(b))
        # v6.6 S: a point already standing there (a second midpoint() call,
        # or point_at(edge, 0.5, name) first) ships once -- but the ticks
        # that SAY it is the midpoint are drawn once per edge all the same
        # (r1: after point_at they were silently dropped).
        if not self._same_point(name, P):
            self._add_point(name, P, dot, mark)
        done = self.__dict__.setdefault("_mid_ticked", set())
        if ticks and frozenset((a, b)) not in done:
            done.add(frozenset((a, b)))
            A, B, Pp = self.p2(a), self.p2(b), self.sc.pr(P)
            self.sc.ticks(A, Pp, 1, sp=(self.p3(a), P))
            self.sc.ticks(Pp, B, 1, sp=(P, self.p3(b)))
        return P

    def _same_point(self, name, P):
        """True when `name` already stands at P (the add-on was called
        twice): the point ships once. A letter already used for a DIFFERENT
        point is refused by _add_point."""
        Q = self.extra.get(name)
        return Q is not None and name not in self.V and \
            dist3d(Q, P) <= 1e-9 * max(1.0, norm3(P))

    def _add_point(self, name, P, dot=True, mark=True):
        if self._same_point(name, P):
            return P
        if name in self.extra and name not in self.V:
            free = [c for c in "KLMNPQRSTUVW" if c not in self.V
                    and c not in self.extra][:4]
            _bad("point", "the letter %r already names another point of "
                 "this solid" % name,
                 "two points with one letter cannot be told apart: use one "
                 "of %s" % ", ".join(free))
        if name in self.V:
            free = [c for c in "KLMNPQRSTUVW" if c not in self.V
                    and c not in self.extra][:4]
            _bad("point", "the letter %r already names a vertex" % name,
                 "two points with one letter cannot be told apart: use one "
                 "of %s" % ", ".join(free))
        self.extra[name] = tuple(P)
        p2 = self.sc.pr(P)
        self.sc.named.append((p2, name))
        if dot:
            self.sc.dot(p2)
        if mark:
            self.sc.text(p2, name, prefer=self._away(p2))
        return P

    def _away(self, p2):
        c = self.centre2()
        dx, dy = p2[0] - c[0], p2[1] - c[1]
        L = math.hypot(dx, dy) or 1.0
        return (dx / L, dy / L)

    def face_diagonal(self, face, frm, to=None, label=None, dash=None,
                      w=1.4):
        """A diagonal of one face. On a face that looks away it is drawn as
        an interior segment (long dashes), never as a hidden edge — a
        hidden EDGE and a segment through the body are two different claims."""
        f = self.face(face)
        if frm not in f:
            _bad("face_diagonal", "%s is not a vertex of face %s"
                 % (frm, "".join(f)),
                 "its vertices are %s" % ", ".join(f))
        if to is None:
            to = f[(list(f).index(frm) + 2) % len(f)]
        if to not in f or to == frm:
            _bad("face_diagonal", "%s and %s are not opposite on face %s"
                 % (frm, to, "".join(f)),
                 "a face diagonal joins two vertices of the face that are "
                 "not neighbours, e.g. %s%s"
                 % (frm, f[(list(f).index(frm) + 2) % len(f)]))
        if dash is None:
            dash = None if self.visible(face) else INTER
        self.sc.line(self.p2(frm), self.p2(to), w, dash)
        if label:
            self.sc.value(self.p2(frm), self.p2(to), label,
                          away=self.centre2())
        self.extra.setdefault(frm, self.p3(frm))
        return dist3d(self.p3(frm), self.p3(to))

    def space_diagonal(self, frm, to, via=None, label="d", triangle=True,
                       right=True, shade=True):
        """A diagonal through the body, with the right triangle that solves
        it: the face diagonal on `via` from `frm`, the edge from there to
        `to`, and the right angle between them — the figure a sheet actually
        asks about.

        `via` decides the triangle: `space_diagonal('A', 'G', via='ABCD')`
        draws AG over the BASE diagonal AC (the ז׳–ט׳ figure), `via='ABFE'`
        over the front face's diagonal AF. On a triangular face, which has
        no diagonal, the second side of the face is used instead."""
        A3, G3 = self.p3(frm), self.p3(to)
        # v6.6 S: two vertices on ONE face have no body diagonal between
        # them, whatever via= says. The old code drew A->C of a box's base
        # as a "space diagonal d" when via was left out, and with via= it
        # died inside angle_between (a zero vector) -- neither tells the
        # author what the figure is. Name the call that draws it.
        if frm in self.V and to in self.V and frm != to:
            for x in self.faces:
                if frm in x and to in x:
                    fx = "".join(x)
                    j, k, nx = list(x).index(frm), list(x).index(to), len(x)
                    if (j - k) % nx in (1, nx - 1):
                        # r1: emph() adds no text, so it draws on every
                        # solid; a NUMBER on the edge may not fit (a
                        # hexagonal prism's short edge), so it is offered
                        # second, as what to call when the length is wanted
                        _bad("space_diagonal", "%s%s is an EDGE of face %s, "
                             "not a diagonal through the body"
                             % (frm, to, fx),
                             "stress the edge instead: emph(%r) -- and "
                             "where its length is wanted too, "
                             "edge_label(%r)" % (frm + to, frm + to))
                    _bad("space_diagonal", "%s and %s are both on face %s, "
                         "so %s%s is a FACE diagonal -- there is no body "
                         "diagonal to draw" % (frm, to, fx, frm, to),
                         "draw it with face_diagonal(%r, %r, %r%s)"
                         % (fx, frm, to, (", label=%r" % label)
                            if label else ""))
        if via is not None:
            f = self.face(via)
            if frm not in f:
                opts = [ "".join(x) for x in self.faces if frm in x ]
                _bad("space_diagonal", "%s is not a vertex of face %s"
                     % (frm, "".join(f)),
                     "via one of %s" % ", ".join(opts))
            # r-T1: the corner is the FACE'S OWN DIAGONAL from `frm`, not
            # "the first vertex of the face that happens to be square". The
            # old scan took B for via='ABCD' as well as for via='ABFE' —
            # both give a valid right triangle, so both shipped, and the
            # classic figure (space diagonal AG over the BASE diagonal AC)
            # could not be drawn through via= at all.
            if to in f:
                opts = ["".join(x) for x in self.faces
                        if frm in x and to not in x]
                _bad("space_diagonal", "%s and %s are both on face %s, so "
                     "there is no body diagonal to draw through it"
                     % (frm, to, "".join(f)),
                     ("via one of %s" % ", ".join(opts)) if opts else
                     "draw it with face_diagonal(%r, %r, %r) instead"
                     % ("".join(f), frm, to))
            i = list(f).index(frm)
            n = len(f)
            if n >= 4:
                order = sorted(range(2, n - 1),
                               key=lambda k: abs(k - n / 2.0))
                cands = [f[(i + k) % n] for k in order]
                what = "diagonal"
            else:                       # a triangular face has no diagonal
                cands = [f[(i + 1) % n], f[(i + n - 1) % n]]
                what = "second side"
            corner = None
            for k in cands:
                if k in self.V and k != to and \
                        perpendicular(sub3(self.p3(k), A3),
                                                 sub3(G3, self.p3(k)),
                                                 tol=0.5):
                    corner = k
                    break
            if corner is None:
                good = []
                for x in self.faces:
                    if frm not in x:
                        continue
                    j, nx = list(x).index(frm), len(x)
                    ks = ([x[(j + k) % nx] for k in range(2, nx - 1)]
                          if nx >= 4 else
                          [x[(j + 1) % nx], x[(j + nx - 1) % nx]])
                    if any(k in self.V and k != to and
                           perpendicular(sub3(self.p3(k), A3),
                                         sub3(G3, self.p3(k)), tol=0.5)
                           for k in ks):
                        good.append("".join(x))
                _bad("space_diagonal", "the %s of face %s from %s does not "
                     "meet %s at a right angle"
                     % (what, "".join(f), frm, to),
                     ("draw it through %s" % " or ".join(
                         "via=%r" % g for g in good)) if good else
                     ("name a face that holds a right triangle to %s, or "
                      "drop via= and draw the diagonal alone "
                      "(via=None)" % to))
            self.sc.line(self.p2(frm), self.p2(corner), 1.4, INTER)
            self.sc.line(self.p2(corner), self.p2(to), 1.4)
            if right:
                self.right_mark(corner, frm, to)
            if shade and triangle:
                self.sc.fill([self.p2(frm), self.p2(corner), self.p2(to)],
                             SHADE)
        self.sc.line(self.p2(frm), self.p2(to), 1.6, INTER)
        if label:
            self.sc.value(self.p2(frm), self.p2(to), label,
                          away=self.centre2(), t=0.62)
        return dist3d(A3, G3)

    def right_mark(self, v, a, b):
        """A right angle CLAIMED in 3D and drawn as the projected square: the
        angle is measured on the real vertices first, so a mark that would be
        a lie is refused before it is drawn (a projected 90° that is not one
        in space is exactly the mistake a cabinet drawing invites)."""
        u1 = sub3(self.p3(a), self.p3(v))
        u2 = sub3(self.p3(b), self.p3(v))
        ang = angle_between(u1, u2)
        if abs(ang - 90.0) > 0.5:
            _bad("right_mark", "angle %s%s%s = %.1f° in 3D, not 90°"
                 % (a, v, b, ang),
                 "mark a corner that really is square, or draw the angle "
                 "with angle_mark(...) and its number")
        self.sc.rmark(self.p2(v), self.p2(a), self.p2(b),
                      sp=(self.p3(v), self.p3(a), self.p3(b)))
        self._claim("right", (v, a, b), None, "90")
        return ang

    def _claim(self, kind, names, face, text):
        """Record an angle the figure asserts, when every point of it has a
        name the `v3d` tag also carries (an add-on's computed point is in
        `extra`, which the tag carries too)."""
        if not all(isinstance(k, str) and
                   (k in self.V or k in self.extra) for k in names):
            return
        if face is not None and not all(k in self.V for k in face):
            return
        self.sc.angles.append((kind, tuple(names), face,
                               "" if text in (None, True) else str(text)))

    def angle_mark(self, v, a, b, text=None, n=1, r=17.0, decimals=1):
        """The angle at `v` between the rays to `a` and `b`, MEASURED in 3D
        and printed as its real value — never the flattened one the drawing
        happens to show."""
        ang = angle_between(sub3(self.p3(a), self.p3(v)),
                            sub3(self.p3(b), self.p3(v)))
        self.sc.arc(self.p2(v), self.p2(a), self.p2(b), n=n, r=r)
        if text is None:
            text = "%s\u00b0" % _n(round(ang, decimals))
        if text:
            self.sc.text(self.p2(v), text, prefer=self._into(v, a, b))
        self._claim("angle", (v, a, b), None, text)
        return ang

    def _into(self, v, a, b):
        """A direction into the wedge at v between the rays to a and b."""
        P, A, B = self.p2(v), self.p2(a), self.p2(b)
        d = []
        for Q in (A, B):
            L = math.hypot(Q[0] - P[0], Q[1] - P[1]) or 1.0
            d.append(((Q[0] - P[0]) / L, (Q[1] - P[1]) / L))
        vx, vy = d[0][0] + d[1][0], d[0][1] + d[1][1]
        L = math.hypot(vx, vy) or 1.0
        return (vx / L, vy / L)

    def angle_to_face(self, frm, to, face, text=None, n=1):
        """The angle a segment makes WITH A FACE: the segment, its projection
        onto the face (the foot, marked square), and the arc with the real
        value. `angle_line_plane` decides the number; the drawing only
        shows it."""
        A3, B3 = self.p3(frm), self.p3(to)
        f = self.face(face)
        nrm = _face_normal(self.V, f, _centroid3(list(self.V.values())))
        ang = angle_line_plane(sub3(B3, A3), nrm)
        if ang < 3.0:
            _bad("angle_to_face", "%s%s lies in face %s (angle %.1f°)"
                 % (frm, to, "".join(f), ang),
                 "name a segment that leaves the face, e.g. a space diagonal")
        # the foot: B projected onto the plane of the face
        p0 = self.p3(f[0])
        t = dot(sub3(B3, p0), nrm) / dot(nrm, nrm)
        F3 = sub3(B3, scale3(nrm, t))
        self.sc.line(self.p2(frm), self.p2(to), 1.5, INTER)
        self.sc.line(self.sc.pr(F3), self.p2(to), 1.1, AUX)
        self.sc.line(self.p2(frm), self.sc.pr(F3), 1.1, AUX)
        u1, u2 = sub3(B3, F3), sub3(A3, F3)
        if abs(angle_between(u1, u2) - 90.0) <= 0.5:
            self.sc.rmark(self.sc.pr(F3), self.p2(to), self.p2(frm),
                          sp=(F3, self.p3(to), self.p3(frm)))
        self.sc.arc(self.p2(frm), self.p2(to), self.sc.pr(F3), n=n)
        if text is None:
            text = "%s\u00b0" % _n(round(ang, 1))
        if text:
            self.sc.text(self.p2(frm), text,
                         prefer=self._into(frm, to, "_foot")
                         if False else self._dir2(self.p2(frm),
                                                  self.sc.pr(F3)))
        self._claim("linface", (frm, to), "".join(f), text)
        return ang

    def _dir2(self, P, Q):
        L = math.hypot(Q[0] - P[0], Q[1] - P[1]) or 1.0
        return ((Q[0] - P[0]) / L, (Q[1] - P[1]) / L)

    # -- the plane cuts: a liquid level, a cross-section ---------------------
    def _clip_below(self, pts3, y):
        """The part of a face that is under the plane y = `y`
        (Sutherland-Hodgman on one half-space)."""
        out = []
        n = len(pts3)
        for i in range(n):
            P, Q = pts3[i], pts3[(i + 1) % n]
            pin, qin = P[1] <= y + 1e-9, Q[1] <= y + 1e-9
            if pin:
                out.append(P)
            if pin != qin:
                t = (y - P[1]) / (Q[1] - P[1])
                out.append(point_on3d(P, Q, t))
        return out

    def _plane_section(self, inside):
        """The polygon where a plane cuts this solid: every face crossing it
        gives one segment, and the segments are walked into a ring. `inside`
        maps a 3D point to a signed value, negative inside."""
        segs = []
        for f in self.faces:
            pts = [self.p3(k) for k in f]
            hit = []
            for i in range(len(pts)):
                P, Q = pts[i], pts[(i + 1) % len(pts)]
                a, b = inside(P), inside(Q)
                if a == 0.0:
                    hit.append(P)
                elif a * b < 0:
                    hit.append(point_on3d(P, Q, a / (a - b)))
            if len(hit) >= 2:
                segs.append((hit[0], hit[-1]))
        if not segs:
            return []
        pts = []
        for a, b in segs:
            for p in (a, b):
                if not any(dist3d(p, q) < 1e-7 for q in pts):
                    pts.append(p)
        c = _centroid3(pts)
        n = plane_normal(pts[0], pts[1], pts[2]) if len(pts) >= 3 else None
        if n is None:
            return pts
        u = unit3(sub3(pts[0], c))
        v = unit3(cross(n, u))
        return sorted(pts, key=lambda p: math.atan2(dot(sub3(p, c), v),
                                                    dot(sub3(p, c), u)))

    def liquid(self, level, label=True, colour=WATER, dim=True):
        """A liquid filled to `level` above the ground. The surface is a real
        horizontal plane cut through the solid, so a container standing on a
        lateral face or turned by a yaw still holds LEVEL water."""
        ys = [p[1] for p in self.V.values()]
        lo, hi = min(ys), max(ys)
        lv = _f("liquid", "level", level)
        if not lo < lo + lv < hi:
            _bad("liquid", "level=%s is not inside the container (0 to %s)"
                 % (_n(lv), _n(hi - lo)),
                 "give a level between 0 and %s, or a taller container"
                 % _n(hi - lo))
        y = lo + lv
        for f in self.faces:
            if not self.visible(f):
                continue
            wet = self._clip_below([self.p3(k) for k in f], y)
            if len(wet) >= 3:
                self.sc.fill([self.sc.pr(p) for p in wet], colour)
        ring = self._plane_section(lambda p: p[1] - y)
        for i in range(len(ring)):
            P, Q = ring[i], ring[(i + 1) % len(ring)]
            mid = midpoint3d(P, Q)
            seen = any(self.visible(f) and
                       abs(dot(_face_normal(self.V, f,
                                            _centroid3(list(self.V.values()))),
                               sub3(mid, self.p3(f[0])))) < 1e-6
                       for f in self.faces)
            self.sc.line(self.sc.pr(P), self.sc.pr(Q), 1.2,
                         None if seen else HID)
        if label:
            text = None if label is True else str(label)
            self.level_dimension(lv, text=text) if dim else None
        self.metrics["liquid_level"] = lv
        base = self.metrics.get("base_area")
        if base:
            self.metrics["liquid_volume"] = base * lv
        return lv

    def level_dimension(self, lv, text=None):
        """How deep the liquid is, written on the side of the figure OPPOSITE
        the container's own height, so the two numbers are never read as one
        (S-R10).

        r3 (the dimension line was refused): a level 9 deep in a 40-deep tank
        is a 17px shaft, and a dimension line's own arrowheads then sit
        nearer its number than the shaft does — figkit's ownership rule, and
        it is right: that number would read as belonging to the barb beside
        it. So the depth is written against the WETTED PART OF THE EDGE
        itself, which is a stroke of the drawing and long enough to own its
        number. A container with no upright edge (one lying on its side) does
        fall back to a dimension line, which is long enough there."""
        ys = [p[1] for p in self.V.values()]
        lo = min(ys)
        best = None
        for a, b in _edges_of(self.faces):
            P, Q = self.p3(a), self.p3(b)
            if abs(P[1] - lo) > 1e-6 and abs(Q[1] - lo) > 1e-6:
                continue
            low, high = (P, Q) if P[1] <= Q[1] else (Q, P)
            u = sub3(high, low)
            if norm3(u) < 1e-9 or abs(u[1]) < 0.999 * norm3(u):
                continue                       # not an upright edge
            if lo + lv > high[1] - 1e-9:
                continue
            x = self.sc.pr(low)[0]
            if best is None or x > best[0]:
                best = (x, low)
        text = text or _n(lv)
        if best is None:
            A = self.sc.pr(min((self.p3(k) for k in self.V),
                               key=lambda p: self.sc.pr(p)[0]))
            self.sc.dim(A, (A[0], A[1] + lv), off=("out", 1.0, 0.0),
                        text=text)
            return self
        low = best[1]
        top = (low[0], low[1] + lv, low[2])
        A, B = self.sc.pr(low), self.sc.pr(top)
        self.sc.value(A, B, text, away=self.centre2())
        self.sc.check("level", A, B, lv, self._shrink(sub3(top, low)))
        return self

    def cross_section(self, points=None, level=None, label=None, shade=True,
                      dash=INTER, w=1.4):
        """A cut through the solid: through three of its own vertices, or
        horizontally at a height. The section is COMPUTED (the polygon where
        the plane meets the faces), so it cannot disagree with the solid."""
        if points:
            P = [self.p3(k) for k in points]
            nrm = plane_normal(P[0], P[1], P[2])
            p0 = P[0]
            inside = lambda q: dot(sub3(q, p0), nrm)
        elif level is not None:
            ys = [p[1] for p in self.V.values()]
            y = min(ys) + _f("cross_section", "level", level)
            if y >= max(ys):
                _bad("cross_section", "level=%s is above the solid" % _n(level),
                     "cut it between 0 and %s" % _n(max(ys) - min(ys)))
            inside = lambda q: q[1] - y
        else:
            _bad("cross_section", "no plane was given",
                 "cut through three vertices (points=('A', 'C', 'G')) or at "
                 "a height (level=4)")
        ring = self._plane_section(inside)
        if len(ring) < 3:
            _bad("cross_section", "the plane misses the solid",
                 "name three vertices of this solid, or a level inside it")
        if shade:
            self.sc.fill([self.sc.pr(p) for p in ring], SHADE)
        for i in range(len(ring)):
            P, Q = ring[i], ring[(i + 1) % len(ring)]
            self.sc.line(self.sc.pr(P), self.sc.pr(Q), w, dash)
        if label:
            m = _centroid3(ring)
            self.sc.text(self.sc.pr(m), label, prefer=(0.0, 1.0))
        area = 0.0
        c = _centroid3(ring)
        for i in range(len(ring)):
            area += 0.5 * norm3(cross(sub3(ring[i], c),
                                      sub3(ring[(i + 1) % len(ring)], c)))
        self.metrics["section_area"] = area
        return area

    def base_altitude(self, apex, a, b, name="P", label=None, right=True,
                      dash=AUX, draw=True, dim=False):
        """The altitude of the BASE from `apex` to the line ab, with its foot
        and its right-angle mark — the height a prism's volume is computed
        from, drawn where the reader can measure it.

        `draw=False` computes the height and writes it WITHOUT the segment:
        the sheet whose question is "find the height" must not answer itself
        by drawing it. `dim=True` puts that number on a dimension line beside
        the solid (the height is then measurable and still not drawn)."""
        A3, B3, S3 = self.p3(a), self.p3(b), self.p3(apex)
        u = sub3(B3, A3)
        t = dot(sub3(S3, A3), u) / dot(u, u)
        F3 = add3(A3, scale3(u, t))
        h = dist3d(S3, F3)
        if h < 1e-9:
            _bad("base_altitude", "%s is on the line %s%s" % (apex, a, b),
                 "drop the altitude from a vertex off that side")
        # z47's own lesson: an upright prism's base lies in the horizontal
        # plane, so its altitude is drawn at half length and lands among the
        # hidden edges — the sheet that needed it had to draw the prism lying
        # down, with the triangle facing the reader. The kit says so instead
        # of printing a height nobody can measure.
        k = self._shrink(sub3(F3, S3))
        if k < 0.62 and draw:
            # the lateral face through the SIDE the altitude falls on: laid
            # on that face, the base stands up, and a quarter turn brings it
            # square to the reader. (Naming any other lateral face gives a
            # call that is refused again — doctrine 4: a refusal names a
            # route that RENDERS, and this one was checked by rendering it.)
            lat = [f for f in self.faces
                   if a in f and b in f and apex not in f and len(f) == 4]
            fix = ("lay the solid on a lateral face so the base faces the "
                   "reader: pose=('%s', 90)" % "".join(lat[0])) if lat else \
                ("turn the solid so the face holding this altitude faces "
                 "the reader")
            _bad("base_altitude", "the altitude from %s is drawn at %.0f%% of "
                 "its length by the projection" % (apex, 100 * k), fix)
        if draw:
            self.sc.line(self.p2(apex), self.sc.pr(F3), 1.1, dash)
            # name=None: the foot carries no letter. A height that is drawn
            # only so the reader can see WHERE it is measured does not need
            # one, and an unasked-for letter is a datum the sheet never gave.
            if name:
                self._add_point(name, F3, dot=True, mark=True)
            if right and 0.02 < t < 0.98:
                self.sc.rmark(self.sc.pr(F3), self.p2(b), self.p2(apex),
                              sp=(F3, self.p3(b), self.p3(apex)))
        if dim:
            # a dimension line as long as the altitude, beside the solid,
            # parallel to it: the reader measures the height without the
            # segment being drawn across the face.
            # the dimension runs along the altitude itself and is pushed
            # OUT by figkit, which measures the whole scene's ink — a second
            # solid beside this one included. (Measuring only this solid's
            # own vertices put the line straight through its neighbour.)
            text = label if isinstance(label, str) else _n(round(h, 4))
            A2, B2 = self.sc.pr(F3), self.p2(apex)
            self.sc.dim(A2, B2, off="out", text=text,
                        lane="alt:%s%s%s" % (apex, a, b))
            self.sc.check("altitude", A2, B2, h, self._shrink(sub3(S3, F3)))
        elif label:
            text = label if label is not True else _n(round(h, 4))
            face = None
            for fc in self.faces:
                if apex in fc and a in fc and b in fc:
                    face = fc
                    break
            poly = [self.p2(k) for k in face] if face else \
                [self.p2(apex), self.p2(a), self.p2(b)]
            self.sc.alt_value(poly, text, self.p2(apex), self.sc.pr(F3))
        self.metrics["base_height"] = h
        return h

    def equal_edges(self, edges, n=1, t=0.5, check=True):
        """Two or more edges MARKED EQUAL, with `n` ticks each — shapekit's
        equal-sides marks, one dimension up. The lengths are re-measured in
        3D first: marking edges equal that are not is refused, not drawn.

            d.equal_edges(('CA', 'CB'))          the two legs
            d.equal_edges(('AD', 'BE', 'CF'))    the lateral edges of a prism
        """
        if isinstance(edges, str) or len(edges) < 2:
            _bad("equal_edges", "%r is one edge" % (edges,),
                 "a mark that says 'equal' needs at least two, e.g. "
                 "edges=('CA', 'CB')")
        L, keys = [], []
        for e in edges:
            a, b = self._edge(e)
            keys.append((a, b))
            L.append(dist3d(self.p3(a), self.p3(b)))
        if check and max(L) - min(L) > 1e-6 * max(L):
            i, j = L.index(min(L)), L.index(max(L))
            _bad("equal_edges", "%s is %s and %s is %s"
                 % ("".join(keys[i]), _n(round(L[i], 4)),
                    "".join(keys[j]), _n(round(L[j], 4))),
                 "mark equal only the edges that ARE equal, or label each "
                 "length with edge_label('%s') and edge_label('%s')"
                 % ("".join(keys[i]), "".join(keys[j])))
        for a, b in keys:
            self.sc.ticks(self.p2(a), self.p2(b), n, t=t,
                          sp=(self.p3(a), self.p3(b)))
        self.metrics["equal_marked"] = ["".join(k) for k in keys]
        return self

    def slices(self, along, n, w=1.1, labels=None, hidden=False):
        """`n` cuts across the solid, in planes square to the edge `along`,
        at the n places that divide it into n+1 equal parts: the loaf of
        bread a volume question is built on ("how many slices of 1 cm?").

        Each cut is COMPUTED face by face. A cut is not an EDGE of the
        solid: it is a line drawn ON it, so by default it is drawn only where
        the reader can see the surface it is drawn on, and the stretches
        round the back are left out. `hidden=True` dashes them instead —
        which is the truth about a transparent solid, and which fills the
        front face with dashes a shaded face cannot then hold a letter in
        (measured: `S` inside the base of a 4-slice prism has no free spot at
        ANY size, because every slice projects across the front face)."""
        a, b = self._edge(along)
        A3, B3 = self.p3(a), self.p3(b)
        nrm = sub3(B3, A3)
        if norm3(nrm) < 1e-9:
            _bad("slices", "%s%s has no length" % (a, b),
                 "name an edge the cuts run along, e.g. along='AD'")
        n = int(n)
        if n < 1:
            _bad("slices", "n=%d" % n,
                 "one cut at least: n=1 halves the solid")
        dashed = hidden and self.sc.hidden == "dashed"
        rings = []
        for k in range(1, n + 1):
            p0 = point_on3d(A3, B3, k / float(n + 1))
            ring = self._plane_section(lambda q: dot(sub3(q, p0), nrm))
            rings.append(ring)
            for f in self.faces:
                seg = self._face_cut(f, lambda q: dot(sub3(q, p0), nrm))
                if seg is None:
                    continue
                if self.visible(f):
                    self.sc.line(self.sc.pr(seg[0]), self.sc.pr(seg[1]), w)
                elif dashed:
                    self.sc.line(self.sc.pr(seg[0]), self.sc.pr(seg[1]),
                                 0.8, HID)
            if labels and k - 1 < len(labels) and labels[k - 1]:
                self.sc.text(self.sc.pr(_centroid3(ring)), labels[k - 1],
                             prefer=(0.0, 1.0))
        self.metrics["slices"] = n
        if rings and len(rings[0]) >= 3:
            self.metrics["slice_area"] = _ring_area(rings[0])
        return rings

    def _face_cut(self, face, inside):
        """The segment where a plane crosses ONE face, or None."""
        pts = [self.p3(k) for k in face]
        hit = []
        for i in range(len(pts)):
            P, Q = pts[i], pts[(i + 1) % len(pts)]
            va, vb = inside(P), inside(Q)
            if va == 0.0:
                hit.append(P)
            elif va * vb < 0:
                hit.append(point_on3d(P, Q, va / (va - vb)))
        if len(hit) < 2 or dist3d(hit[0], hit[-1]) < 1e-9:
            return None
        return (hit[0], hit[-1])

    def edge_parts(self, edge, parts, labels=None, dim=False, off=None,
                   check=True):
        """An edge cut into `parts` equal pieces, each piece named — the
        length divided into segments ("three pieces of 4 cm each"), or a base
        halved under two dimension lines that meet where the halves do.

        `dim=True` writes them on dimension lines end to end below the edge;
        otherwise each number sits beside its own piece, outside the solid."""
        a, b = self._edge(edge)
        parts = int(parts)
        if parts < 2:
            _bad("edge_parts", "parts=%d" % parts,
                 "two pieces at least; for one length use "
                 "edge_label(%r)" % ("".join((a, b))))
        if labels is not None and len(labels) != parts:
            _bad("edge_parts", "%d label(s) for %d piece(s)"
                 % (len(labels), parts),
                 "give one label per piece (None leaves a piece unnamed), "
                 "e.g. labels=%r" % ([None] * parts,))
        A3, B3 = self.p3(a), self.p3(b)
        whole = dist3d(A3, B3)
        step = whole / parts
        cuts = [point_on3d(A3, B3, k / float(parts)) for k in range(parts + 1)]
        if dim:
            # the same outward test edge_label(dim=True) uses: a dimension
            # line on the far side of the edge from the solid, never across
            # it. (Scene.dim reads the page's sense, y down; the scene's is
            # y up, so the sign flips with the flip.)
            A2, B2 = self.p2(a), self.p2(b)
            c2 = self.centre2()
            m = (0.5 * (A2[0] + B2[0]), 0.5 * (A2[1] + B2[1]))
            Ln = math.hypot(B2[0] - A2[0], B2[1] - A2[1]) or 1.0
            nn = (-(B2[1] - A2[1]) / Ln, (B2[0] - A2[0]) / Ln)
            off = "out" if (nn[0] * (m[0] - c2[0])
                            + nn[1] * (m[1] - c2[1])) > 0 else "out-"
        for k in range(parts):
            P, Q = self.sc.pr(cuts[k]), self.sc.pr(cuts[k + 1])
            txt = labels[k] if labels else _n(round(step, 4))
            if txt is None:
                continue
            if dim:
                self.sc.dim(P, Q, off=off, text=txt,
                            lane="parts:%s%s" % (a, b))
            else:
                self.sc.value(P, Q, txt, away=self.centre2())
            if check:
                self.sc.check("%s%s/%d" % (a, b, k + 1), P, Q, step,
                              self._shrink(sub3(cuts[k + 1], cuts[k])))
        self.metrics["part"] = step
        return step

    def ghost(self, points, close=True, dash=AUX, w=1.1, label=None):
        """A dashed outline drawn INSIDE the solid, through points of its own
        3D frame: the shape it used to be before a dimension was doubled, the
        piece that was cut away, the part a question asks about. Every point
        must be on or inside this solid — a 'ghost' hanging outside it is a
        second figure, not a mark on this one, and is refused."""
        P = [self.p3(x) for x in points]
        if len(P) < 2:
            _bad("ghost", "%d point(s)" % len(P),
                 "an outline needs at least two points, e.g. "
                 "ghost([(0, 0, 0), (6, 0, 0), (2, 4, 0)])")
        if self.convex:
            c = _centroid3([v for v in self.V.values()])
            for f in self.faces:
                q = [self.p3(k) for k in f]
                nrm = plane_normal(q[0], q[1], q[2])
                if dot(sub3(c, q[0]), nrm) > 0:
                    nrm = scale3(nrm, -1.0)
                scale = max(norm3(nrm), 1e-9)
                for v in P:
                    if dot(sub3(v, q[0]), nrm) > 1e-6 * scale:
                        _bad("ghost", "the point (%s) is outside the solid"
                             % ", ".join(_n(round(t, 3)) for t in v),
                             "a ghost outline marks THIS solid: keep every "
                             "point on or inside it, or draw the other shape "
                             "as a solid of its own on the same scene "
                             "(scene=s, at=...)")
        for i in range(len(P) - 1 + (1 if close else 0)):
            self.sc.line(self.sc.pr(P[i]), self.sc.pr(P[(i + 1) % len(P)]),
                         w, dash)
        if label:
            self.sc.text(self.sc.pr(_centroid3(P)), label, prefer=(0.0, 1.0))
        return self

    def caption(self, text, gap=8.0):
        """A name UNDER the solid ('מנסרה א׳'), clear of the drawing: the
        label a comparison figure needs to say which solid is which."""
        pts = [self.p2(k) for k in self.V]
        x = 0.5 * (min(p[0] for p in pts) + max(p[0] for p in pts))
        y = min(p[1] for p in pts)
        self.sc.text((x, y), text, prefer=(0.0, -1.0), gap=gap)
        # v6.6 E r1 (X1R2-03): the caption names THIS solid -- tied to its
        # outline (poly-..., role solid) in the export
        self.sc.labels[-1] = self.sc.labels[-1] + (_hull2(pts),)
        return self

    # -- metrics ------------------------------------------------------------
    def volume(self):
        """The volume from the DATA the figure was built from, so an answer
        key and a drawing can never disagree."""
        if "V" not in self.metrics:
            _bad("volume", "no volume is defined for %r" % self.kind,
                 "the solids with a volume are cube, box, prism, cylinder, "
                 "cone, pyramid, open_box, container, unit_cubes, "
                 "notch_prism")
        return self.metrics["V"]

    def surface_area(self):
        if "S" not in self.metrics:
            _bad("surface_area", "no surface area is defined for %r"
                 % self.kind, "see Solid.metrics for what this solid knows")
        return self.metrics["S"]


# ============================================================== builders ===
# THE NAMING CONVENTION (one, checked):
#   box / cube: ABCD is the BOTTOM face, anticlockwise seen from above,
#   starting front-left; E F G H sit above A B C D. Faces: bottom ABCD, top
#   EFGH, front ABFE, back DCGH, right BCGF, left ADHE.
#   prism: ABC... is the base, DEF... its copy along the prism's axis.
#   pyramid: ABCD... the base, S the apex.
_BOX_FACES = ("ABCD", "EFGH", "ABFE", "DCGH", "BCGF", "ADHE")
_BOX_NAMED = {"base": "ABCD", "bottom": "ABCD", "top": "EFGH",
              "front": "ABFE", "back": "DCGH", "right": "BCGF",
              "left": "ADHE"}


def _scene(side, tier, unit, hidden, scene=None):
    """The scene a builder draws on. `scene=` puts a SECOND solid on a scene
    a previous builder returned, so two solids are drawn at ONE scale and one
    fit — the comparison figure ("the prism is half the box", "which holds
    more") that z47 had to write by hand because every builder made a scene
    of its own."""
    if scene is not None:
        if not isinstance(scene, Scene):
            _bad("scene", "scene=%r is not a Scene" % (scene,),
                 "pass the scene the first builder returned: "
                 "s, d = box(9, 4, 5); s, d2 = prism('triangle', L=5, "
                 "scene=s, at=(11, 0, 0))")
        return scene
    return Scene(side=("right" if side == "auto" else side), tier=tier,
                 unit=unit, hidden=hidden)


def _at(V, at, where):
    """Move a whole solid in its own posed frame — how a second solid is put
    beside the first instead of inside it."""
    if at is None:
        return V
    try:
        dx, dy, dz = (float(v) for v in at)
    except (TypeError, ValueError):
        _bad(where, "at=%r is not a point" % (at,),
             "at is where the solid goes, as (x, y, z), e.g. at=(11, 0, 0)")
    return dict((k, (v[0] + dx, v[1] + dy, v[2] + dz)) for k, v in V.items())


def _label_text(where, key, given, labels):
    """What to print for a named length. `labels` may rename it (a letter, an
    expression); a NUMBER that contradicts the data is refused — the drawing
    and its numbers must be the same figure."""
    if labels is True or labels is None:
        return _n(given)
    if labels is False:
        return None
    if not isinstance(labels, dict):
        _bad(where, "labels=%r" % (labels,),
             "labels is True (print the data), False (print none) or a dict, "
             "e.g. labels={'a': 'x'}")
    if key not in labels:
        return _n(given)
    t = labels[key]
    if t in (None, False, ""):
        return None
    if t is True:                  # "print this one too", with its own value
        return _n(given)
    t = str(t)
    if re.fullmatch(r"−?\d+(?:[.,]\d+)?", t):
        if abs(float(t.replace("−", "-").replace(",", ".")) - given) > 1e-9:
            _bad(where, "label %s bound to %s = %s" % (t, key, _n(given)),
                 "print the data (labels={'%s': '%s'}) or an unknown "
                 "(labels={'%s': 'x'})" % (key, _n(given), key))
    return t


def _box_V(a, b, c):
    return {"A": (0.0, 0.0, 0.0), "B": (a, 0.0, 0.0), "C": (a, 0.0, b),
            "D": (0.0, 0.0, b), "E": (0.0, c, 0.0), "F": (a, c, 0.0),
            "G": (a, c, b), "H": (0.0, c, b)}


def _posed(V, faces, pose):
    return _apply_pose(V, [tuple(f) for f in faces], pose)


def box(a, b, c, names=True, labels=True, pose=None, side="auto",
        tier="side", unit=None, hidden="dashed", fam=None, shade=None,
        draw=True, scene=None, at=None):
    """A box (תיבה): `a` = AB (width), `b` = BC (depth), `c` = AE (height).

        s, d = box(9, 4, 5, fam='solid.box')
        print(finish(s, 'solid.box'))

    Returns `(scene, solid)`. The depth edge is drawn at half length, so the
    drawing reads 9 : 5 : 2 while the data says 9 : 5 : 4 — every proportion
    check divides a receding length by CAB_K first."""
    a = _f("box", "a", a)
    b = _f("box", "b", b)
    c = _f("box", "c", c)
    sc = _scene(side, tier, unit, hidden, scene)
    V = _at(_posed(_box_V(a, b, c), _BOX_FACES, pose), at, "box")
    m = dict(V=a * b * c, S=2.0 * (a * b + a * c + b * c),
             space_diagonal=math.sqrt(a * a + b * b + c * c),
             base_area=a * b, a=a, b=b, c=c)
    d = Solid(sc, V, _BOX_FACES, "box", dict(a=a, b=b, c=c, pose=pose),
              convex=True, metrics=m)
    d.named_faces = dict(_BOX_NAMED)
    if shade:
        d.shade(shade)
    if draw:
        d.draw()
    if names:
        d.names()
    if labels is not False:
        d.dimension_set(dict(a=("AB", a, 1.0), b=("BC", b, CAB_K),
                             c=("AE", c, 1.0)), labels, "box")
    return sc, d


def cube(e, names=True, label=True, pose=None, side="auto", tier="side",
         unit=None, hidden="dashed", fam=None, shade=None, draw=True,
         scene=None, at=None):
    """A cube (קובייה) of edge `e`. One edge carries the length — a cube's
    twelve edges are one number, and twelve copies of it is not a figure."""
    e = _f("cube", "e", e)
    sc = _scene(side, tier, unit, hidden, scene)
    V = _at(_posed(_box_V(e, e, e), _BOX_FACES, pose), at, "cube")
    m = dict(V=e ** 3, S=6.0 * e * e, space_diagonal=e * math.sqrt(3.0),
             face_diagonal=e * math.sqrt(2.0), base_area=e * e,
             a=e, b=e, c=e)
    d = Solid(sc, V, _BOX_FACES, "cube", dict(e=e, pose=pose), convex=True,
              metrics=m)
    d.named_faces = dict(_BOX_NAMED)
    if shade:
        d.shade(shade)
    if draw:
        d.draw()
    if names:
        d.names()
    if label is not False:
        d.dimension_set({"e": ("AB", e, 1.0)}, label, "cube")
    return sc, d


# ----------------------------------------------------------- prism kit ----
_UP = "ABCDEFGHIJKL"


def _base_polygon(where, base, data):
    """The prism's / pyramid's base, taken FROM SHAPEKIT — one shape family
    for the whole skill. `shapekit._GEOM` returns the vertex list in the
    DATA's own units (before shapekit normalises it for the page), which is
    exactly what a solid needs: the base of a prism whose sides are 6, 5, 5
    must come out 6, 5, 5."""
    if base not in shapekit.SHAPES or base == "circle":
        _bad(where, "base=%r" % base,
             "a base is one of %s" % ", ".join(
                 k for k in shapekit.SHAPES if k != "circle"))
    pts, extra = shapekit._GEOM[base](dict(data))
    pts = shapekit._ccw(pts)
    return pts, extra


def _poly_area(pts):
    s = sum(pts[i][0] * pts[(i + 1) % len(pts)][1]
            - pts[(i + 1) % len(pts)][0] * pts[i][1] for i in range(len(pts)))
    return abs(s) / 2.0


def _poly_perimeter(pts):
    return sum(math.hypot(pts[(i + 1) % len(pts)][0] - pts[i][0],
                          pts[(i + 1) % len(pts)][1] - pts[i][1])
               for i in range(len(pts)))


def _prism_V(pts2, L, names=None):
    """Base ABC… on the ground (y = 0), its copy DEF… a height L above it.
    D is above A, E above B, and so on: ONE convention, checked."""
    n = len(pts2)
    nm = names or (_UP[:n], _UP[n:2 * n])
    low, up = nm[0], nm[1]
    V = {}
    for i, (x, y) in enumerate(pts2):
        V[low[i]] = (x, 0.0, y)
        V[up[i]] = (x, float(L), y)
    faces = [tuple(low), tuple(up)]
    for i in range(n):
        j = (i + 1) % n
        faces.append((low[i], low[j], up[j], up[i]))
    return V, faces, low, up


def prism(base="triangle", L=10.0, names=None, labels=True, pose=None,
          side="auto", tier="side", unit=None, hidden="dashed", fam=None,
          shade=None, draw=True, scene=None, at=None, **data):
    """A RIGHT prism (מנסרה ישרה) on any shapekit base.

        prism('triangle', L=10, variant='sss', a=6, b=5, c=5)
        prism('trapezoid', L=12, variant='iso', a=9, b=4, h=6)
        prism('polygon', L=8, n=6, a=3)

    Standing on its base is `pose=None`; `pose=('ABED', 90)` lays it on that
    lateral face and turns it so the base faces the reader (the classic
    "triangle in front" prism); `pose=('DEF', 0)` stands it on its head."""
    L = _f("prism", "L", L)
    pts2, extra = _base_polygon("prism", base, data)
    V0, faces, low, up = _prism_V(pts2, L, names)
    area, per = _poly_area(pts2), _poly_perimeter(pts2)
    sc = _scene(side, tier, unit, hidden, scene)
    V = _at(_posed(V0, faces, pose), at, "prism")
    m = dict(V=area * L, S=2.0 * area + per * L, base_area=area,
             base_perimeter=per, L=L, lateral=per * L)
    d = Solid(sc, V, faces, "prism.%s" % base,
              dict(base=base, L=L, pose=pose, **extra), convex=_is_convex(pts2),
              metrics=m)
    d.base_names, d.top_names = low, up
    if shade:
        d.shade(shade)
    if draw:
        d.draw()
    if names is not False:
        d.names()
    if labels is not False:
        spec = {"L": (low[0] + up[0], L, True)}
        if base == "triangle":
            sides = extra.get("sides")
            for i, key in enumerate(("a", "b", "c")):
                pass
        spec.update(_base_label_spec(low, pts2, base, extra, solid=d))
        d.dimension_set(spec, labels, "prism")
    return sc, d


def _base_label_spec(low, pts2, base, extra, solid=None):
    """Which of the base's own lengths the solid CAN print, and which it
    prints by default.

    The default is ONE: the base edge. A triangle's other two sides are
    there for the asking (`labels={'a': True, 'b': True}`), but they are not
    printed unasked, because a base is drawn foreshortened and three numbers
    crowded round it cannot each be read as belonging to their own side —
    E24 refuses them, and it is right. Measured, not guessed: the upright
    6-5-5 prism, the same prism laid down with an altitude on it, and the
    triangular pyramid were each refused when all three were printed."""
    out = {}
    a = math.hypot(pts2[1][0] - pts2[0][0], pts2[1][1] - pts2[0][1])
    out["base"] = (low[0] + low[1], a, True)
    if base == "triangle":
        for i, key in enumerate(("c", "a", "b")):
            j = (i + 1) % 3
            out[key] = (low[i] + low[j],
                        math.hypot(pts2[j][0] - pts2[i][0],
                                   pts2[j][1] - pts2[i][1]), key == "c")
        del out["base"]
    return out


def _is_convex(pts):
    n = len(pts)
    sgn = 0
    for i in range(n):
        o, a, b = pts[i], pts[(i + 1) % n], pts[(i + 2) % n]
        c = _cross2(o, a, b)
        if abs(c) < 1e-12:
            continue
        s = 1 if c > 0 else -1
        if sgn and s != sgn:
            return False
        sgn = s
    return True


def pyramid(base="square", h=8.0, a=None, names=None, apex="S", labels=True,
            pose=None, side="auto", tier="side", unit=None, hidden="dashed",
            fam=None, shade=None, draw=True, **data):
    """A right pyramid (פירמידה) on a shapekit base, apex above the base's
    centre. `pyramid('square', a=6, h=8)`, `pyramid('triangle', h=9,
    variant='equilateral', a=6)`."""
    h = _f("pyramid", "h", h)
    if a is not None:
        data.setdefault("a", a)
    pts2, extra = _base_polygon("pyramid", base, data)
    n = len(pts2)
    nm = names or _UP[:n]
    V = dict((nm[i], (p[0], 0.0, p[1])) for i, p in enumerate(pts2))
    cx = sum(p[0] for p in pts2) / n
    cz = sum(p[1] for p in pts2) / n
    if apex in V:
        _bad("pyramid", "the apex letter %r already names a base vertex"
             % apex, "name the apex something else, e.g. apex='S'")
    V[apex] = (cx, h, cz)
    faces = [tuple(nm)]
    for i in range(n):
        faces.append((nm[i], nm[(i + 1) % n], apex))
    area, per = _poly_area(pts2), _poly_perimeter(pts2)
    # the slant height of each lateral face, from the true 3D triangle
    slant = []
    for i in range(n):
        p, q = (pts2[i][0], 0.0, pts2[i][1]), (pts2[(i + 1) % n][0], 0.0,
                                               pts2[(i + 1) % n][1])
        mid = midpoint3d(p, q)
        slant.append(dist3d(mid, V[apex]))
    lat = sum(0.5 * math.hypot(pts2[(i + 1) % n][0] - pts2[i][0],
                               pts2[(i + 1) % n][1] - pts2[i][1]) * slant[i]
              for i in range(n))
    sc = _scene(side, tier, unit, hidden)
    Vp = _posed(V, faces, pose)
    m = dict(V=area * h / 3.0, S=area + lat, base_area=area,
             base_perimeter=per, h=h, lateral=lat, slant=tuple(slant))
    d = Solid(sc, Vp, faces, "pyramid.%s" % base,
              dict(base=base, h=h, apex=apex, pose=pose, **extra),
              convex=_is_convex(pts2), metrics=m)
    d.base_names, d.apex = nm, apex
    if shade:
        d.shade(shade)
    if draw:
        d.draw()
    if names is not False:
        d.names()
    if labels is not False:
        d.dimension_set(_base_label_spec(nm, pts2, base, extra, solid=d),
                        labels, "pyramid")
    return sc, d


# ------------------------------------------------------- round solids ----
# A circle in space projects to an ellipse; which part of it the reader SEES
# is decided the same way a polyhedron's faces are — by the surface normal
# against the eye. Nothing here is a special case of "the cabinet angle is
# 45°, so the ellipse is such-and-such": the rim is sampled, the normal is
# computed at every sample, and the arc is cut where the normal turns away.
# That is what lets a cylinder LIE DOWN or a cone stand on its head without
# a second implementation.

_ARC_N = 240


def _frame(axis):
    """Two unit vectors across `axis`, so a circle about it can be walked."""
    a = unit3(axis)
    t = (0.0, 0.0, 1.0) if abs(a[2]) < 0.9 else (1.0, 0.0, 0.0)
    u = unit3(cross(a, t))
    return u, cross(a, u)


def _circle3(C, r, axis, n=_ARC_N):
    u, v = _frame(axis)
    return [add3(C, add3(scale3(u, r * math.cos(2 * math.pi * k / n)),
                         scale3(v, r * math.sin(2 * math.pi * k / n))))
            for k in range(n + 1)]


def _arcs_by_normal(pts, normals, eye):
    """Cut a sampled rim into runs that face the reader and runs that do
    not. Returns [(points, visible), ...]."""
    out, cur, sgn = [], [], None
    for p, n in zip(pts, normals):
        s = dot(n, eye) > 0
        if sgn is None or s == sgn:
            cur.append(p)
        else:
            cur.append(p)
            out.append((cur, sgn))
            cur = [p]
        sgn = s
    if len(cur) > 1:
        out.append((cur, sgn))
    return out


def _draw_rim(sc, C, r, axis, cap_visible, w=1.5, hw=1.0, lateral=None):
    """A rim circle: solid where the surface behind it faces the reader (or
    where its own cap does), dashed where the body hides it."""
    eye = sc.eye()
    pts = _circle3(C, r, axis)
    if lateral is None:
        normals = [unit3(sub3(p, C)) for p in pts]
    else:
        normals = [lateral(p) for p in pts]
    if cap_visible:
        sc.curve([sc.pr(p) for p in pts], w)
        return
    for run, seen in _arcs_by_normal(pts, normals, eye):
        if seen:
            sc.curve([sc.pr(p) for p in run], w)
        elif sc.hidden == "dashed":
            sc.curve([sc.pr(p) for p in run], hw, HID)


def _silhouette(C, r, axis, eye, lateral=None):
    """The two rim points where the surface turns away — where a cylinder's
    generators stand and a cone's slant lines touch."""
    pts = _circle3(C, r, axis, n=720)
    f = []
    for p in pts:
        n = unit3(sub3(p, C)) if lateral is None else lateral(p)
        f.append(dot(n, eye))
    out = []
    for k in range(len(pts) - 1):
        if f[k] == 0.0 or f[k] * f[k + 1] < 0:
            t = f[k] / (f[k] - f[k + 1]) if f[k] != f[k + 1] else 0.0
            out.append(tuple(a + (b - a) * t for a, b in zip(pts[k],
                                                             pts[k + 1])))
    return out[:2]


def _round_pose(pose):
    """'upright' (default), 'lying', 'inverted', or (one of those, yaw)."""
    rest, yaw = pose, 0.0
    if isinstance(pose, (tuple, list)):
        rest, yaw = pose[0], float(pose[1])
    if rest in (None, "", "base", "upright"):
        rest = "upright"
    if rest not in ("upright", "lying", "inverted"):
        _bad("pose", "pose=%r for a round solid" % (pose,),
             "a round solid rests 'upright', 'lying' or 'inverted' — e.g. "
             "pose=('lying', 20)")
    return rest, yaw


def _round_axis(rest, yaw):
    a = {"upright": (0.0, 1.0, 0.0), "inverted": (0.0, -1.0, 0.0),
         "lying": (1.0, 0.0, 0.0)}[rest]
    if yaw:
        a = _rot_axis(a, (0.0, 1.0, 0.0), yaw)
    return a


def cylinder(r, h, pose=None, open_top=False, liquid=None, labels=True,
             side="auto", tier="side", unit=None, hidden="dashed", fam=None,
             names=False, draw=True):
    """A cylinder (גליל) of radius `r` and height `h`.

        cylinder(3, 8)                  upright
        cylinder(3, 8, pose='lying')    on its side
        cylinder(4, 10, liquid=6)       with water 6 high

    The bottom rim is cut at the silhouette: the front arc is drawn, the
    back arc dashed. The top rim is one unbroken ellipse, because the top
    face is turned towards the reader."""
    r = _f("cylinder", "r", r)
    h = _f("cylinder", "h", h)
    rest, yaw = _round_pose(pose)
    a = _round_axis(rest, yaw)
    sc = _scene(side, tier, unit, hidden)
    C0 = (0.0, 0.0, 0.0)
    C1 = add3(C0, scale3(a, h))
    # v6.7: the base centre is O and the top centre O1 (the names a sheet
    # uses), so the radius exports as seg-OR and the height as OO1
    V = {"O": C0, "O1": C1}
    m = dict(V=math.pi * r * r * h, S=2 * math.pi * r * (r + h),
             lateral=2 * math.pi * r * h, base_area=math.pi * r * r, r=r, h=h)
    if liquid is not None:
        # r-T1: the drawing had a water line and the metrics had nothing —
        # `d.liquid()` on a box records the level and its volume, so the
        # round solids record theirs too, from the same number the wash is
        # drawn from.
        _lv = _f("cylinder.liquid", "liquid", liquid)
        if _lv >= h:                           # checked here too: draw=False
            _bad("cylinder", "liquid=%s is not below the height %s"
                 % (_n(_lv), _n(h)),
                 "the level is between 0 and %s, or the cylinder is taller: "
                 "cylinder(%s, %s, liquid=%s)"
                 % (_n(h), _n(r), _n(_lv + 1), _n(_lv)))
        _no_lying_liquid("cylinder", rest, r, h, _lv)
        m["liquid_level"] = _lv
        m["liquid_volume"] = math.pi * r * r * _lv

    def drawer(d, w, hw):
        eye = sc.eye()
        top_seen = dot(a, eye) > 0
        bot_seen = dot(scale3(a, -1.0), eye) > 0
        _draw_rim(sc, C0, r, a, bot_seen and not open_top, w, hw)
        _draw_rim(sc, C1, r, a, top_seen and not open_top, w, hw)
        for p in _silhouette(C0, r, a, eye):
            sc.line(sc.pr(p), sc.pr(add3(p, scale3(a, h))), w)
        if liquid is not None:
            lv = _f("cylinder.liquid", "liquid", liquid)
            if lv >= h:
                _bad("cylinder", "liquid=%s is not below the height %s"
                     % (_n(lv), _n(h)),
                     "the level is between 0 and %s, or the cylinder is "
                     "taller: cylinder(%s, %s, liquid=%s)"
                     % (_n(h), _n(r), _n(lv + 1), _n(lv)))
            # r1: the level is `lv` above the GROUND. Standing on its head
            # the cylinder's ground rim is C1 (the axis points down), and
            # the water was washed from the TOP rim downwards.
            G = C1 if rest == "inverted" else C0
            up = scale3(a, -1.0) if rest == "inverted" else a
            L = add3(G, scale3(up, lv))
            front = _run(_circle3(L, r, a), L, eye)
            botf = _run(_circle3(G, r, a), G, eye)
            if front and botf:
                sc.fill([sc.pr(p) for p in front] +
                        [sc.pr(p) for p in reversed(botf)], WATER)
            _draw_rim(sc, L, r, a, False, 1.2, 1.0)

    d = Solid(sc, V, [], "cylinder",
              dict(r=r, h=h, pose=pose, liquid=liquid), convex=True,
              metrics=m, curved=drawer)
    d.round = dict(axis=a, centre=C0, top=C1, r=r, h=h, cname="O",
                   tname="O1")
    if draw:
        d.draw()
    if labels is not False:
        _round_labels(sc, d, labels, "cylinder")
    return sc, d


def _no_lying_liquid(kind, rest, r, h, lv):
    """r1: water in a LYING round solid is a horizontal plane cutting the
    curved wall -- a segment of a circle on each round face, which is not
    what the wash draws (it washed vertical slivers, with a level and a
    volume that meant an upright solid). Refused, naming the upright call."""
    if rest == "lying":
        _bad(kind, "liquid=%s on a %s lying on its side" % (_n(lv), kind),
             "the wash and its metrics are for a %s standing up: "
             "%s(%s, %s, liquid=%s)" % (kind, kind, _n(r), _n(h), _n(lv)))


def _run(pts, C, eye):
    """The rim samples whose outward normal looks away from the eye (the
    same half a cylinder's wash is bounded by), as ONE contiguous run in
    order round the circle. A plain filter returns the half split in two
    wherever the sampling starts, and a wash polygon built from it crosses
    itself (a cone standing on its point washed a sliver, measured)."""
    keep = [dot(unit3(sub3(p, C)), eye) <= 0 for p in pts]
    n = len(pts)
    if all(keep) or not any(keep):
        return [p for p, k in zip(pts, keep) if k]
    s0 = next(i for i in range(n) if keep[i] and not keep[i - 1])
    out = []
    i = s0
    while keep[i % n] and len(out) < n:
        out.append(pts[i % n])
        i += 1
    return out


def _cone_r_at(r, h, lv, rest):
    """The radius of the cone's cross-section at height `lv`: the water's
    own surface. Narrowing upward on a cone standing on its base, widening
    upward on one standing on its point."""
    return r * lv / h if rest == "inverted" else r * (1.0 - lv / h)


def cone(r, h, pose=None, liquid=None, labels=True, side="auto", tier="side",
         unit=None, hidden="dashed", fam=None, apex="S", draw=True,
         names=False):
    """A cone (חרוט): radius `r`, height `h`. The two slant lines are the
    TANGENTS from the apex — found where the cone's own surface normal turns
    away from the reader, so they touch the base ellipse instead of ending at
    its widest points (the kink a hand-drawn cone always has)."""
    r = _f("cone", "r", r)
    h = _f("cone", "h", h)
    rest, yaw = _round_pose(pose)
    a = _round_axis(rest, yaw)
    sc = _scene(side, tier, unit, hidden)
    C0 = (0.0, 0.0, 0.0)
    S = add3(C0, scale3(a, h))
    # v6.7 (S2-flat-cone-no-sides): a FLAT cone's apex falls inside its own
    # base ellipse at the cabinet depth factor, and the drawing had no apex
    # and no slant sides -- a bare ellipse, with the h dimension measuring
    # to ink that was not there. The eye is LOWERED for that figure (a
    # smaller depth factor flattens the ellipse) until the apex stands
    # clear of it; a cone no view can show is refused, naming the call that
    # renders.
    sc.depth = _cone_depth(r, h, a, sc.side, pose, tier, labels)
    slant = math.sqrt(r * r + h * h)
    m = dict(V=math.pi * r * r * h / 3.0, S=math.pi * r * (r + slant),
             lateral=math.pi * r * slant, base_area=math.pi * r * r,
             r=r, h=h, l=slant)
    if liquid is not None:
        _lv = _f("cone.liquid", "liquid", liquid)
        if _lv >= h:
            _bad("cone", "liquid=%s is not below the height %s"
                 % (_n(_lv), _n(h)),
                 "the level is between 0 and %s" % _n(h))
        _no_lying_liquid("cone", rest, r, h, _lv)
        m["liquid_level"] = _lv
        if abs(a[1]) > 0.999:
            _rl = _cone_r_at(r, h, _lv, rest)
            m["liquid_volume"] = (
                math.pi * _rl * _rl * _lv / 3.0 if rest == "inverted"
                else math.pi * _lv * (r * r + r * _rl + _rl * _rl) / 3.0)

    def lateral_normal(p):
        e = unit3(sub3(p, C0))
        return unit3(add3(scale3(e, h), scale3(a, r)))

    def drawer(d, w, hw):
        eye = sc.eye()
        base_seen = dot(scale3(a, -1.0), eye) > 0
        _draw_rim(sc, C0, r, a, base_seen, w, hw, lateral=lateral_normal)
        for p in _silhouette(C0, r, a, eye, lateral=lateral_normal):
            sc.line(sc.pr(p), sc.pr(S), w)
        if liquid is not None:
            lv = _f("cone.liquid", "liquid", liquid)
            if lv >= h:
                _bad("cone", "liquid=%s is not below the height %s"
                     % (_n(lv), _n(h)),
                     "the level is between 0 and %s" % _n(h))
            rl = _cone_r_at(r, h, lv, rest)
            # v6.6 S: the level is `lv` above the GROUND. Standing on its
            # base that is lv up the axis from the base; standing on its
            # point it is lv up from the apex, i.e. h - lv from the base --
            # the drawn ellipse used to sit at lv from the base with the
            # radius of lv from the apex, off the cone's own wall.
            L = add3(C0, scale3(a, h - lv if rest == "inverted" else lv))
            # ... and the liquid is WASHED, as a cylinder's and a
            # container's are: two ellipses and no wash left the reader to
            # guess which side of the line was water.
            lvl = _run(_circle3(L, rl, a), L, eye)
            if rest == "inverted":
                if lvl:
                    sc.fill([sc.pr(p) for p in lvl] + [sc.pr(S)], WATER)
            else:
                botf = _run(_circle3(C0, r, a), C0, eye)
                if lvl and botf:
                    sc.fill([sc.pr(p) for p in lvl] +
                            [sc.pr(p) for p in reversed(botf)], WATER)
            _draw_rim(sc, L, rl, a, False, 1.2, 1.0)

    cn = "O" if apex != "O" else "C"       # v6.7: the base centre is O
    d = Solid(sc, {cn: C0, apex: S}, [], "cone",
              dict(r=r, h=h, pose=pose, apex=apex), convex=True, metrics=m,
              curved=drawer)
    d.round = dict(axis=a, centre=C0, top=S, r=r, h=h, slant=slant,
                   cname=cn, tname=apex)
    if draw:
        d.draw()
    if labels is not False:
        _round_labels(sc, d, labels, "cone")
    return sc, d


_CONE_KEEP = 1.25       # the apex this far out (x the ellipse): cabinet view
_CONE_WANT = 1.5        # a lowered eye puts it at least this far out
_CONE_DEPTHS = (0.4, 0.3, 0.25, 0.2, 0.16, 0.13, 0.1, 0.08, 0.065, 0.05)


def _apex_clear(r, h, axis, side, k):
    """How far the apex stands from the base centre, in units of the base
    ellipse's own reach in that direction (on the page). Under 1 the apex
    is inside the ellipse and no slant side can be drawn."""
    C2 = project((0.0, 0.0, 0.0), side, k)
    S2 = project(scale3(axis, h), side, k)
    dx, dy = S2[0] - C2[0], S2[1] - C2[1]
    L = math.hypot(dx, dy)
    if L < 1e-12:
        return 0.0
    ux, uy = dx / L, dy / L
    reach = 0.0
    for p in _circle3((0.0, 0.0, 0.0), r, axis, n=360):
        q = project(p, side, k)
        reach = max(reach, (q[0] - C2[0]) * ux + (q[1] - C2[1]) * uy)
    return L / max(reach, 1e-12)


def _cone_depth(r, h, axis, side, pose, tier="side", labels=True):
    """The depth factor a cone is drawn at: CAB_K when its apex stands
    clear of the base ellipse (every cone a sheet usually has), else the
    first smaller one that puts the apex _CONE_WANT ellipse-reaches out."""
    if _apex_clear(r, h, axis, side, CAB_K) >= _CONE_KEEP:
        return CAB_K
    for k in _CONE_DEPTHS:
        if _apex_clear(r, h, axis, side, k) >= _CONE_WANT:
            return k
    # no view shows the apex: name a call that RENDERS -- each candidate is
    # drawn and finished before it is named (doctrine 4)
    every = (CAB_K,) + _CONE_DEPTHS
    up = (0.0, 1.0, 0.0)
    cands = []
    if pose not in (None, "", "upright", "base"):
        if any(_apex_clear(r, h, up, side, k) >= _CONE_WANT for k in every):
            cands.append(("cone(%s, %s) standing upright (no pose=)"
                          % (_n(r), _n(h)), h, None))
    h2 = h
    for _ in range(40):
        if any(_apex_clear(r, h2, axis, side, k) >= _CONE_WANT
               for k in every):
            break
        h2 = _roundup(h2 * 1.25)
    for _ in range(8):
        cands.append(("cone(%s, %s), a height the drawing can show"
                      % (_n(r), _n(h2)), h2, pose))
        h2 = _roundup(h2 * 1.5)
    key = (round(r, 9), round(h, 9), tuple(round(x, 9) for x in axis),
           side, str(pose), tier, repr(labels))
    if key in _FLAT_ROUTE:               # the same data, the same answer
        named = _FLAT_ROUTE[key]
        cands = []
    else:
        named = None
    import export as _xp                 # a probe is not a figure
    saved = (dict(_xp._FIGS), list(_xp._ORDER))
    try:
        for said, hh, pp in cands:
            # r1: the BIGGER drawing only -- one that fails at 'block'
            # fails at 'side' too, and each failed draw of the probe cost
            # the refusal about a second
            for t in ["block"]:
                try:
                    sc2, _d2 = cone(r, hh, pose=pp, labels=labels, side=side,
                                    tier=t)
                    sc2._probing, sc2._fail_fast = True, _PROBE_FAILS
                    finish(sc2, "solidkit.cone.probe")
                except AssertionError:
                    continue
                named = said + ("" if t == tier else ", tier='block'")
                break
            if named:
                break
    finally:
        _xp._FIGS.clear()
        _xp._FIGS.update(saved[0])
        _xp._ORDER[:] = saved[1]
    _FLAT_ROUTE[key] = named
    # v6.7 r1 (V67F-abstract-routes): the route that keeps the question's
    # numbers comes first; a different height is offered only as what it
    # is -- a change to the question's data
    raise SolidUndrawable(
        "solidkit.cone: r=%s, h=%s is so flat that its apex falls inside "
        "its own base ellipse in every view this kit draws -- no slant side "
        "and no apex could be drawn, and the height would measure to "
        "nothing — keep the numbers and state the cone in words with no "
        "figure (the text «חרוט שרדיוס בסיסו %s וגובהו %s», no fig=)%s"
        % (_n(r), _n(h), _n(r), _n(h),
           ("; or, only if the question's height may change, draw %s "
            "(drawn and checked)" % named) if named else
           ": no height near %s draws it readably" % _n(h)))


_FLAT_ROUTE = {}        # (r, h, axis, side, pose, tier, labels) -> route


def _radius_point(C, r, axis, side, k=None):
    """Where the radius is DRAWN to: the rim point whose radius comes out
    HORIZONTAL on the page (and therefore at its true length, which is what
    a printed `r` claims).

    r1, found by rendering: the front-most rim point — the natural choice,
    the one whose normal faces the reader — projects to the BOTTOM of the
    ellipse, and a radius drawn straight down from the centre lies along the
    ellipse's own flat, so its number could not be kept nearer the radius
    than the rim (figkit's ownership rule refused the figure). The
    horizontal radius has the whole body above it and nothing else near."""
    C2 = project(C, side, k)
    best, score = None, None
    for p in _circle3(C, r, axis, n=720):
        q = project(p, side, k)
        if q[0] <= C2[0]:
            continue
        sc_ = abs(q[1] - C2[1])
        if score is None or sc_ < score:
            best, score = p, sc_
    return best


def _round_labels(sc, d, labels, where):
    """r and h, each owned by the stroke it names: the radius is DRAWN (from
    the centre dot to the rim) so its number has something to own, and the
    height is a dimension line beside the axis, outside the solid."""
    R = d.round
    a, C, r, h = R["axis"], R["centre"], R["r"], R["h"]
    best = _radius_point(C, r, a, sc.side, sc.depth)
    tr = _label_text(where, "r", r, labels)
    # v6.7 (S2-round-solid-labels-untied): the centre is a NAMED point (O),
    # the radius runs to a named rim point (R), and the height to the top
    # centre or apex, so the numbers export as lbl-OR / lbl-OS with `for`
    # the segment or dimension they measure -- not lbl-<hash>. (O and the
    # apex are vertices, named where they have ink; a cylinder's top centre
    # has none, so its height stays tied to its dimension's id.)
    cn, tn = R.get("cname", "O"), R.get("tname")
    rn = [c for c in "RQPK" if c not in (cn, tn) and c not in d.V][0]
    # v6.7 r1 (V67F-flat-cone-r-label-on-rim): a cone drawn with a lowered
    # eye (flat) has no paper inside its thin ellipse for the radius's
    # number -- it landed under the rim, read against the rim. Its r and h
    # are written on dimension lines outside the drawing, each with witness
    # lines from the last ink they cross (the rim, the apex).
    flat = getattr(sc, "depth", CAB_K) != CAB_K
    if tr:
        sc.dot(sc.pr(C))
        sc.line(sc.pr(C), sc.pr(best), 1.1)
        d.extra[rn] = best
        sc.named.append((sc.pr(best), rn))
        if flat:
            sc.dim(sc.pr(C), sc.pr(best), off="out-", text=tr, wit=True)
        else:
            # the number goes on the far side from the rim it would
            # otherwise be read against — INTO the body, where the paper is
            # empty
            sc.value(sc.pr(C), sc.pr(best), tr,
                     away=sc.pr(add3(C, scale3(a, -0.6 * h))), own=False)
        sc.check("r", sc.pr(C), sc.pr(best), r,
                 _shrink_dir(sub3(best, C), sc.side, sc.depth))
    th = _label_text(where, "h", h, labels)
    if th:
        top = add3(C, scale3(a, h))
        A, B = sc.pr(C), sc.pr(top)
        if where == "cone" and not tr:
            # v6.8 r1 (flat-cone-dim-off-ink): the height of a cone whose
            # radius is not drawn still runs from the base centre -- give
            # that end its ink (the centre dot the drawn radius starts at)
            sc.dot(A)
        dA, dB = A, B
        wit_h = flat
        ref_h = None
        if where == "cylinder" and not flat and h < 1.5 * r:
            # a SHORT cylinder: the generator is too short for its number
            # to be read against its dimension rather than against the
            # generator beside it (same length, 12px away), so the shaft
            # stays level with the centres and its witness lines run from
            # the last ink they meet -- the ends are still tied to ink
            wit_h = True
            # v6.8 (V67F3-short-cylinder-json-undrawn): ...and what it
            # MEASURES, in the JSON, is that drawn generator (O1 has no ink)
            g = _near_generator(sc, C, r, a, A, B)
            if g is not None:
                ref_h = [g, (g[0] + B[0] - A[0], g[1] + B[1] - A[1])]
        elif where == "cylinder" and not flat:
            # (a FLAT cylinder already gets witness lines from the last ink
            # they meet, so its ends are tied to ink that way)
            # v6.7 r2 (V67F-cylinder-height-untied): a cylinder's top
            # centre O1 has no ink, so its height is measured along the
            # GENERATOR on the side the dimension stands (page-left of
            # A -> B): both ends of the dimension are drawn ends of that
            # line, and the generator is exactly h long in the drawing
            L = math.hypot(B[0] - A[0], B[1] - A[1]) or 1.0
            nx, ny = (B[1] - A[1]) / L, -(B[0] - A[0]) / L
            gens = [sc.pr(p) for p in _silhouette(C, r, a, sc.eye())]
            gens = [g for g in gens
                    if (g[0] - A[0]) * nx + (g[1] - A[1]) * ny < -0.5]
            if gens:
                # (sc.pr is y-up; _dim's page-left is -n in this frame --
                # checked on the drawn SVG by selfcheck_v67 T1)
                g = min(gens, key=lambda q: (q[0] - A[0]) * nx +
                        (q[1] - A[1]) * ny)
                dA = g
                dB = (g[0] + B[0] - A[0], g[1] + B[1] - A[1])
        sc.dim(dA, dB, off="out", text=th, wit=wit_h, ref=ref_h)
        sc.check("h", A, B, h, _shrink_dir(sub3(top, C), sc.side, sc.depth))


def _near_generator(sc, C, r, a, A, B):
    """The drawn generator on the dimension's side (page-left of A -> B),
    or None -- the same choice the tall cylinder's dimension makes."""
    L = math.hypot(B[0] - A[0], B[1] - A[1]) or 1.0
    nx, ny = (B[1] - A[1]) / L, -(B[0] - A[0]) / L
    gens = [sc.pr(p) for p in _silhouette(C, r, a, sc.eye())]
    gens = [g for g in gens
            if (g[0] - A[0]) * nx + (g[1] - A[1]) * ny < -0.5]
    if not gens:
        return None
    return min(gens, key=lambda q: (q[0] - A[0]) * nx + (q[1] - A[1]) * ny)


def _shrink_dir(u3, side, k=None):
    p = project(u3, side, k)
    return math.hypot(p[0], p[1]) / max(norm3(u3), 1e-12)


# --------------------------------------------------- composite solids ----
def open_box(a, b, c, names=True, labels=True, pose=None, side="auto",
             tier="side", unit=None, hidden="dashed", fam=None, draw=True):
    """A box with no lid (a קופסה פתוחה / an open tank). The five faces are
    opaque, so what the reader sees through the opening is COMPUTED: the far
    bottom edge is hidden behind the front wall exactly when the wall is tall
    enough to hide it, and a vertical back edge comes out part solid, part
    dashed — which is the truth, and which no per-shape table can say."""
    a = _f("open_box", "a", a)
    b = _f("open_box", "b", b)
    c = _f("open_box", "c", c)
    faces = ("ABCD", "ABFE", "DCGH", "BCGF", "ADHE")      # no lid EFGH
    sc = _scene(side, tier, unit, hidden)
    V = _posed(_box_V(a, b, c), faces, pose)
    m = dict(V=a * b * c, S=a * b + 2 * (a * c + b * c), base_area=a * b,
             a=a, b=b, c=c, rim=2 * (a + b))
    d = Solid(sc, V, faces, "open_box", dict(a=a, b=b, c=c, pose=pose),
              convex=False, metrics=m)
    d.named_faces = dict(_BOX_NAMED)
    if draw:
        d.draw()
    if names:
        d.names()
    if labels is not False:
        d.dimension_set({"a": ("AB", a), "b": ("BC", b), "c": ("AE", c)},
                        labels, "open_box")
    return sc, d


def container(a, b, c, level=None, names=True, labels=True, pose=None,
              side="auto", tier="side", unit=None, hidden="dashed", fam=None,
              open_top=True, level_label=True, draw=True):
    """A container with a liquid in it (z20's water tank): a box, open or
    closed, filled to `level`. The surface is a real horizontal plane in the
    solid's own frame, so the water in a tilted (yawed) container is still
    level and the drawing says so."""
    sc, d = (open_box if open_top else box)(
        a, b, c, names=names, labels=labels, pose=pose, side=side, tier=tier,
        unit=unit, hidden=hidden, fam=fam, draw=draw)
    if level is not None:
        d.liquid(level, label=level_label)
    return sc, d


def unit_cubes(a, b, c, names=False, labels=False, pose=None, side="auto",
               tier="side", unit=None, hidden="omit", fam=None, draw=True):
    """A solid built of unit cubes, `a` x `b` x `c` of them. An opaque stack
    shows no hidden edges at all (a dashed line inside it would be read as an
    edge of a transparent box), so `hidden` must be 'omit' — and the unit
    grid is drawn on the three faces the reader can see."""
    a, b, c = (int(round(_f("unit_cubes", k, v)))
               for k, v in (("a", a), ("b", b), ("c", c)))
    if hidden != "omit":
        _bad("unit_cubes", "hidden=%r" % hidden,
             "an opaque stack shows no hidden edges: unit_cubes(%d, %d, %d)"
             % (a, b, c))
    sc = _scene(side, tier, unit, hidden)
    V = _posed(_box_V(float(a), float(b), float(c)), _BOX_FACES, pose)
    m = dict(V=float(a * b * c), S=2.0 * (a * b + a * c + b * c),
             cubes=a * b * c, a=a, b=b, c=c)
    d = Solid(sc, V, _BOX_FACES, "unit_cubes",
              dict(a=a, b=b, c=c, pose=pose), convex=True, metrics=m)
    d.named_faces = dict(_BOX_NAMED)
    if draw:
        d.draw()
        # the unit grid, only on the faces that face the reader
        for f in d.faces:
            if not d.visible(f):
                continue
            P = [d.p3(k) for k in f]
            u, v = sub3(P[1], P[0]), sub3(P[3], P[0])
            nu = int(round(norm3(u)))
            nv = int(round(norm3(v)))
            for i in range(1, nu):
                p = add3(P[0], scale3(u, float(i) / nu))
                sc.line(sc.pr(p), sc.pr(add3(p, v)), 0.7)
            for j in range(1, nv):
                p = add3(P[0], scale3(v, float(j) / nv))
                sc.line(sc.pr(p), sc.pr(add3(p, u)), 0.7)
    if names:
        d.names()
    if labels:
        d.dimension_set({"a": ("AB", float(a)), "b": ("BC", float(b)),
                         "c": ("AE", float(c))}, labels, "unit_cubes")
    return sc, d


def extrude(poly2d, depth, names=None, labels=None, pose=None, side="auto",
            tier="side", unit=None, hidden="dashed", fam=None, draw=True,
            kind="extrude", scene=None, at=None):
    """A prism on ANY 2D outline, convex or not — the L, the notch, the step.
    `poly2d` is the cross-section in the x-y plane, anticlockwise; `depth`
    runs along z (away from the reader).

    `names=('GHI', 'JKL')` CHOOSES the letters (a second solid on the same
    scene needs its own); `labels=False` leaves them unprinted. They were one
    switch until z47's port asked for named-but-unlettered solids."""
    pts = shapekit._ccw([(float(x), float(y)) for x, y in poly2d])
    depth = _f("extrude", "depth", depth)
    n = len(pts)
    nm = names or (_UP[:n], _UP[n:2 * n])
    front, back = nm[0], nm[1]
    V = {}
    for i, (x, y) in enumerate(pts):
        V[front[i]] = (x, y, 0.0)
        V[back[i]] = (x, y, depth)
    faces = [tuple(front), tuple(reversed(back))]
    for i in range(n):
        j = (i + 1) % n
        faces.append((front[i], front[j], back[j], back[i]))
    sc = _scene(side, tier, unit, hidden, scene)
    Vp = _at(_posed(V, faces, pose), at, "extrude")
    area, per = _poly_area(pts), _poly_perimeter(pts)
    m = dict(V=area * depth, S=2 * area + per * depth, base_area=area,
             base_perimeter=per, depth=depth)
    d = Solid(sc, Vp, faces, kind, dict(depth=depth, pose=pose),
              convex=_is_convex(pts), metrics=m)
    if draw:
        d.draw()
    if names is not False and labels is not False:
        d.names()
    return sc, d


def notch_prism(a, c, depth, cut=None, corner="top-right", **kw):
    """An L-prism: a `a` x `c` rectangle with a `cut` bitten out of one
    corner, extruded `depth` deep. The notch's own two edges are the reason
    the hidden-edge test has to be occlusion and not normals: the solid is
    not convex, and part of an edge is seen while the rest of it is not."""
    a = _f("notch_prism", "a", a)
    c = _f("notch_prism", "c", c)
    cw, ch = cut or (a / 3.0, c / 3.0)
    cw = _f("notch_prism", "cut width", cw)
    ch = _f("notch_prism", "cut height", ch)
    if cw >= a or ch >= c:
        _bad("notch_prism", "the notch %s x %s does not fit in %s x %s"
             % (_n(cw), _n(ch), _n(a), _n(c)),
             "make the notch smaller than the rectangle, e.g. "
             "cut=(%s, %s)" % (_n(a / 3.0), _n(c / 3.0)))
    if corner == "top-right":
        pts = [(0, 0), (a, 0), (a, c - ch), (a - cw, c - ch), (a - cw, c),
               (0, c)]
    elif corner == "top-left":
        pts = [(0, 0), (a, 0), (a, c), (cw, c), (cw, c - ch), (0, c - ch)]
    else:
        _bad("notch_prism", "corner=%r" % corner,
             "the notch is bitten out of 'top-right' or 'top-left'")
    sc, d = extrude(pts, depth, kind="notch_prism", **kw)
    d.metrics.update(a=a, c=c, cut=(cw, ch), V=(a * c - cw * ch) * depth,
                     cut_volume=cw * ch * depth)
    d.data.update(a=a, c=c, cut=(cw, ch), corner=corner)
    return sc, d


SOLIDS = ("cube", "box", "prism", "cylinder", "cone", "pyramid", "open_box",
          "container", "unit_cubes", "notch_prism", "extrude")


# ================================================================== nets ===
# A net is NOT a drawing of a solid — it is the solid's own faces, UNFOLDED.
# Each face is placed in the plane by an ISOMETRY of that face (its 2D image
# keeps every distance of the 3D original), attached to the face before it
# along their shared edge. Folding back is then true by construction, and
# what is left to check is what can actually go wrong: a face used twice, a
# face left out, and two faces landing on top of each other.

def _face_local(pts3):
    """A face's own 2D coordinates: an isometry of its plane."""
    o = pts3[0]
    u = unit3(sub3(pts3[1], o))
    n = None
    for i in range(2, len(pts3)):
        try:
            n = plane_normal(o, pts3[1], pts3[i])
            break
        except SolidError:
            continue
    v = unit3(cross(n, u))
    return [(dot(sub3(p, o), u), dot(sub3(p, o), v)) for p in pts3]


def _place_face(local, idx_p, idx_q, P2, Q2, away):
    """Put a face's local 2D image so that its edge (idx_p, idx_q) lands on
    the already-placed segment P2-Q2, on the far side from `away`."""
    p, q = local[idx_p], local[idx_q]
    d1 = (q[0] - p[0], q[1] - p[1])
    d2 = (Q2[0] - P2[0], Q2[1] - P2[1])
    L1 = math.hypot(*d1) or 1.0
    L2 = math.hypot(*d2) or 1.0
    out = []
    for mirror in (1.0, -1.0):
        co = (d1[0] * d2[0] + mirror * d1[1] * d2[1]) / (L1 * L2)
        si = (d1[0] * d2[1] - mirror * d1[1] * d2[0]) / (L1 * L2)
        pts = []
        for x, y in local:
            x0, y0 = x - p[0], (y - p[1]) * mirror
            pts.append((P2[0] + co * x0 - si * y0, P2[1] + si * x0 + co * y0))
        out.append(pts)
    best = None
    for pts in out:
        c = (sum(x for x, _ in pts) / len(pts), sum(y for _, y in pts) / len(pts))
        ex, ey = Q2[0] - P2[0], Q2[1] - P2[1]
        side = (c[0] - P2[0]) * ey - (c[1] - P2[1]) * ex
        aside = (away[0] - P2[0]) * ey - (away[1] - P2[1]) * ex
        if side * aside < 0:
            best = pts
    return best or out[0]


def _polys_overlap(A, B):
    """Two placed faces sharing more than an edge."""
    for i in range(len(A)):
        for j in range(len(B)):
            a1, a2 = A[i], A[(i + 1) % len(A)]
            b1, b2 = B[j], B[(j + 1) % len(B)]
            t = _seg_hits(a1, a2, b1, b2)
            if t is None:
                continue
            P = (a1[0] + t * (a2[0] - a1[0]), a1[1] + t * (a2[1] - a1[1]))
            if any(math.hypot(P[0] - q[0], P[1] - q[1]) < 1e-6
                   for q in list(A) + list(B)):
                continue
            return True
    for poly, other in ((A, B), (B, A)):
        c = (sum(x for x, _ in poly) / len(poly),
             sum(y for _, y in poly) / len(poly))
        if _in_poly(c, other):
            return True
    return False


def unfold(solid, root=None):
    """The faces of a solid, laid flat. Returns (placed, order): `placed`
    maps a face (tuple of letters) to its 2D polygon, in the same vertex
    order as the face."""
    faces = list(solid.faces)
    if not faces:
        _bad("net", "%s has no flat faces to unfold" % solid.kind,
             "a cylinder's or a cone's net is drawn by net(solid) itself, "
             "not by unfolding faces")
    adj = {}
    for key, fs in _edges_of(faces).items():
        if len(fs) == 2:
            adj.setdefault(fs[0], []).append((fs[1], key))
            adj.setdefault(fs[1], []).append((fs[0], key))
    roots = list(range(len(faces)))
    if root is not None:
        roots = [faces.index(_find_face(faces, root, solid.V))] + roots
    # A spanning tree of the face graph IS the net, and different trees give
    # different shapes: an L-prism's faces overlap under the obvious
    # breadth-first tree and lie flat under another. Four orders per root are
    # tried (breadth and depth first, each taking the neighbours in both
    # orders) — bounded, deterministic, and enough for every solid this kit
    # draws.
    for r in roots:
        for how in ("bfs", "bfs-rev", "dfs", "dfs-rev"):
            placed, order, ok = {}, [], True
            placed[r] = _face_local([solid.p3(k) for k in faces[r]])
            order.append(r)
            queue = [r]
            while queue and ok:
                i = queue.pop(0) if how.startswith("bfs") else queue.pop()
                nb = list(adj.get(i, []))
                if how.endswith("rev"):
                    nb = list(reversed(nb))
                for j, key in nb:
                    if j in placed:
                        continue
                    f, g = faces[i], faces[j]
                    a, b = key
                    P2 = placed[i][list(f).index(a)]
                    Q2 = placed[i][list(f).index(b)]
                    away = (sum(x for x, _ in placed[i]) / len(placed[i]),
                            sum(y for _, y in placed[i]) / len(placed[i]))
                    loc = _face_local([solid.p3(k) for k in g])
                    pts = _place_face(loc, list(g).index(a), list(g).index(b),
                                      P2, Q2, away)
                    if any(_polys_overlap(pts, q) for q in placed.values()):
                        ok = False
                        break
                    placed[j] = pts
                    order.append(j)
                    queue.append(j)
            if ok and len(placed) == len(faces):
                return dict((faces[i], placed[i]) for i in placed), \
                    [faces[i] for i in order]
    _bad("net", "no unfolding this kit tried lays the faces of this %s flat "
         "without overlap" % solid.kind,
         "net(solid, root='ABCD') starts from another face; a solid with a "
         "notch may need its net drawn from its own rectangle pieces "
         "(extrude the pieces and net each)")


def net(solid, labels=True, marks=True, tier="block", unit=None, side=None,
        fam=None, root=None, fold_check=True, only=None):
    """The net of a solid: every face once, folded flat.

        s, d = box(6, 4, 3, fam='solid.box')
        ns, nd = net(d, fam='net.box')

    A cylinder's and a cone's nets are the curved pair (a rectangle 2πr wide
    and the two circles; a sector and the base circle)."""
    if getattr(solid, "round", None):
        return _round_net(solid, labels=labels, tier=tier, unit=unit,
                          fam=fam)
    sc = Scene(side=side or solid.sc.side, tier=tier, unit=unit,
               hidden="dashed")
    placed, order = unfold(solid, root=root)
    if only is not None:
        # a PARTIAL net: the lateral strip alone (מעטפת), the faces a
        # surface-area question asks for. The rest is dropped AFTER the
        # unfolding, so what is left is still laid flat by the same isometry.
        keep = [_find_face(solid.faces, f, solid.V) for f in only]
        missing = [f for f in keep if f not in placed]
        if missing:
            _bad("net", "face %s is not in this net"
                 % "".join(missing[0]),
                 "name faces of this solid: %s"
                 % ", ".join("".join(f) for f in sorted(placed)))
        if len(set(keep)) < 2:
            _bad("net", "only= names %d face(s)" % len(set(keep)),
                 "a strip is two faces or more; for one face draw it with "
                 "shapekit instead")
        placed = dict((f, pts) for f, pts in placed.items() if f in keep)
        order = [o for o in order if o in placed]
    if fold_check:
        _fold_check(solid, placed, partial=only is not None)
    for f, pts in placed.items():
        sc.poly(pts, 1.5)
    if labels:
        # ONE number per distinct length, on the net's outline. A pyramid's
        # net has eight equal slants; eight copies of "9.06" is noise, and
        # the author reads a net for its measurements, not for its arithmetic.
        seen = set()
        for f, pts in sorted(placed.items()):
            c = (sum(x for x, _ in pts) / len(pts),
                 sum(y for _, y in pts) / len(pts))
            for i in range(len(pts)):
                a, b = f[i], f[(i + 1) % len(f)]
                P, Q = pts[i], pts[(i + 1) % len(pts)]
                if not _is_boundary(P, Q, placed, f):
                    continue
                real = round(dist3d(solid.p3(a), solid.p3(b)), 2)
                if real in seen:
                    continue
                seen.add(real)
                sc.value(P, Q, _n(real), away=c, own=False)
    net_obj = _Net(sc, solid, placed, order)
    sc.kindname = "solidkit.net"        # v6.7.1 r1: a net, not a solid
    return sc, net_obj


def _is_boundary(P, Q, placed, mine):
    """An edge of the net's OUTLINE: no other face has that same segment."""
    for f, pts in placed.items():
        if f == mine:
            continue
        for i in range(len(pts)):
            A, B = pts[i], pts[(i + 1) % len(pts)]
            if (math.hypot(A[0] - P[0], A[1] - P[1]) < 1e-6 and
                math.hypot(B[0] - Q[0], B[1] - Q[1]) < 1e-6) or \
               (math.hypot(A[0] - Q[0], A[1] - Q[1]) < 1e-6 and
                    math.hypot(B[0] - P[0], B[1] - P[1]) < 1e-6):
                return False
    return True


def _fold_check(solid, placed, partial=False):
    """Every face exactly once, and every face placed by an ISOMETRY: the
    distance between two of its corners in the net is the distance between
    them on the solid. That is what "it folds back" means."""
    if not partial and len(placed) != len(solid.faces):
        _bad("net", "the net has %d faces and the solid has %d"
             % (len(placed), len(solid.faces)),
             "every face is used exactly once — net(solid) does that itself")
    if partial:
        for f in placed:
            if f not in solid.faces:
                _bad("net", "%s is not a face of this solid" % "".join(f),
                     "a partial net holds faces of the solid it came from")
    for f, pts in placed.items():
        for i in range(len(f)):
            for j in range(i + 1, len(f)):
                d2 = math.hypot(pts[i][0] - pts[j][0], pts[i][1] - pts[j][1])
                d3 = dist3d(solid.p3(f[i]), solid.p3(f[j]))
                if abs(d2 - d3) > 1e-6 * max(d3, 1.0):
                    _bad("net", "face %s comes out %s wide in the net and %s "
                         "on the solid" % ("".join(f), _n(round(d2, 4)),
                                           _n(round(d3, 4))),
                         "a net is the faces themselves, unfolded — this one "
                         "was not placed by an isometry (a bug, not data)")
    return True


class _Net(object):
    """A folded-flat solid: the faces, where they landed, and the maths."""

    def __init__(self, sc, solid, placed, order):
        self.sc, self.solid, self.placed, self.order = sc, solid, placed, order
        self.metrics = dict(faces=len(placed),
                            S=solid.metrics.get("S"),
                            area=sum(_poly_area(p) for p in placed.values()))

    # close-out: a net could be drawn and measured but never NAMED. z47's
    # net pages write a name inside each face ("the base", "S = 24"), a
    # letter beside one side of one face, and a dimension of the height —
    # every one of them a mark on a face the caller names.
    def _placed(self, face):
        f = _find_face(list(self.placed), face, self.solid.V)
        return f, self.placed[f]

    def face_label(self, face, text, at=None):
        """Text INSIDE one face of the net, named as the solid names it
        ('ABC', 'base', 'ABED')."""
        _f0, pts = self._placed(face)
        self.sc.inside(pts, text, at=at)
        return self

    def side_label(self, face, edge, text, inside=False):
        """A name beside ONE side of ONE face of the net: the letter that
        says which side of the solid this edge of the net is. `inside=True`
        writes it in the face instead of outside it — what a shared edge
        needs, because outside it would sit in the neighbouring face."""
        f, pts = self._placed(face)
        a, b = (edge[0], edge[1]) if isinstance(edge, str) else edge
        try:
            i, j = f.index(a), f.index(b)
        except ValueError:
            _bad("net.side_label", "%s is not a side of face %s"
                 % (edge, "".join(f)),
                 "its sides are %s" % ", ".join(
                     f[k] + f[(k + 1) % len(f)] for k in range(len(f))))
        if (j - i) % len(f) not in (1, len(f) - 1):
            _bad("net.side_label", "%s and %s are not next to each other on "
                 "face %s" % (a, b, "".join(f)),
                 "name a side, not a diagonal")
        P, Q = pts[i], pts[j]
        c = (sum(x for x, _y in pts) / len(pts),
             sum(y for _x, y in pts) / len(pts))
        if inside:
            self.sc.edge_in(P, Q, text, pts)
        else:
            self.sc.value(P, Q, text, away=c, own=False)
        return self

    def dimension(self, face, edge, text=None):
        """A dimension line for one side of one face, outside the net."""
        f, pts = self._placed(face)
        a, b = (edge[0], edge[1]) if isinstance(edge, str) else edge
        i, j = f.index(a), f.index(b)
        real = dist3d(self.solid.p3(a), self.solid.p3(b))
        self.sc.dim(pts[i], pts[j], off="out",
                    text=text if text is not None else _n(round(real, 4)))
        self.sc.check("net %s%s" % (a, b), pts[i], pts[j], real)
        return self

    def folds_to(self, solid=None):
        """True when this net folds back onto `solid` — each face once, each
        placed by an isometry."""
        return _fold_check(solid or self.solid, self.placed)


def _round_net(solid, labels=True, tier="block", unit=None, fam=None):
    """A cylinder's net (a rectangle 2*pi*r by h, with the two base circles)
    or a cone's (the sector of radius l and the base circle)."""
    R = solid.round
    r, h = R["r"], R["h"]
    sc = Scene(side=solid.sc.side, tier=tier, unit=unit, hidden="dashed")
    if solid.kind == "cylinder":
        W = 2.0 * math.pi * r
        sc.poly([(0, 0), (W, 0), (W, h), (0, h)], 1.5)
        for cy, sgn in ((h + r, 1), (-r, -1)):
            sc.curve([(W / 2.0 + r * math.cos(t * math.pi / 60.0),
                       cy + r * math.sin(t * math.pi / 60.0))
                      for t in range(121)], 1.5)
        if labels:
            # rule 7: the SVG carries Latin letters, digits, the degree sign
            # and U+2212 — no Greek. The circumference is printed as the
            # NUMBER it is, and the Hebrew question says what it measures.
            sc.value((0, 0), (W, 0), _n(round(W, 2)), away=(W / 2.0, h),
                     own=False)
            sc.value((W, 0), (W, h), _n(round(h, 2)), away=(0, h / 2.0),
                     own=False)
        # r-T1: 'area' is the area of the PIECES as drawn — a rectangle and
        # two circles. It was missing here, so an answer key written as
        # net(solid).metrics['area'] read 0 for every round solid and the
        # right number for every other one.
        m = dict(S=solid.metrics["S"], lateral=solid.metrics["lateral"],
                 width=W, h=h, r=r,
                 area=W * h + 2.0 * math.pi * r * r)
    else:
        l = R["slant"]
        ang = 2.0 * math.pi * r / l                 # the sector's own angle
        pts = [(0.0, 0.0)] + [(l * math.cos(-math.pi / 2 + ang * k / 60.0),
                               l * math.sin(-math.pi / 2 + ang * k / 60.0))
                              for k in range(61)] + [(0.0, 0.0)]
        sc.curve(pts, 1.5)
        cy = -l - r - 0.3 * r
        sc.curve([(0.0 + r * math.cos(t * math.pi / 60.0),
                   cy + r * math.sin(t * math.pi / 60.0))
                  for t in range(121)], 1.5)
        if labels:
            sc.value((0.0, 0.0), pts[1], _n(round(l, 2)),
                     away=pts[30], own=False)
        m = dict(S=solid.metrics["S"], lateral=solid.metrics["lateral"],
                 slant=l, r=r, sector_deg=math.degrees(ang),
                 area=0.5 * ang * l * l + math.pi * r * r)
    obj = _Net(sc, solid, {}, [])
    obj.metrics.update(m)
    if abs(obj.metrics["area"] - obj.metrics["S"]) > 1e-6 * max(
            obj.metrics["S"], 1.0):
        _bad("net", "the net's pieces come to %s and the surface area is %s"
             % (_n(round(obj.metrics["area"], 4)),
                _n(round(obj.metrics["S"], 4))),
             "a net is the surface opened flat — the two are the same "
             "number; this is the kit's own arithmetic, report it")
    sc.kindname = "solidkit.net"        # v6.7.1 r1: a net, not a solid
    return sc, obj


def net_faces(solid):
    """The faces a net of this solid would have, in the order it lays them
    out — for a question that asks 'which of these nets folds into the
    solid?'."""
    _placed, order = unfold(solid)
    return ["".join(f) for f in order]


# v6.5 X2 r1 (MUST-3, spec rule 6): the author's call into this module
# is recorded as source, so figures/<id>.py can re-draw the figure.
import export as _export_rec  # noqa: E402
box = _export_rec.seq(box, start=True)
cube = _export_rec.seq(cube, start=True)
prism = _export_rec.seq(prism, start=True)
pyramid = _export_rec.seq(pyramid, start=True)
cylinder = _export_rec.seq(cylinder, start=True)
cone = _export_rec.seq(cone, start=True)
open_box = _export_rec.seq(open_box, start=True)
container = _export_rec.seq(container, start=True)
unit_cubes = _export_rec.seq(unit_cubes, start=True)
extrude = _export_rec.seq(extrude, start=True)
notch_prism = _export_rec.seq(notch_prism, start=True)
finish = _export_rec.seq(finish)
net = _export_rec.seq(net, start=True)
# v6.6 E (z47): the author's steps on a solid (d.draw(), d.edge_label(...))
# and on a net are logged too, so figures/<id>.py re-makes the whole figure
for _cls in (Solid, _Net):
    for _nm, _fn in list(vars(_cls).items()):
        if callable(_fn) and not _nm.startswith("_") and \
                not isinstance(_fn, (staticmethod, classmethod, property)):
            setattr(_cls, _nm, _export_rec.seq_method(_fn))
del _cls, _nm, _fn


def _scene_setattr(self, k, v):
    object.__setattr__(self, k, v)
    if k != "_seq" and "_seq" in self.__dict__ and \
            _export_rec._is_user(sys._getframe(1).f_code.co_filename):
        _export_rec.seq_set(self, k, v)


Scene.__setattr__ = _scene_setattr
