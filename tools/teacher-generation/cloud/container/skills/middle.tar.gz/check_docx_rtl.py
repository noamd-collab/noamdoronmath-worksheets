#!/usr/bin/env python3
# -*- coding: utf-8 -*-
u"""check_docx_rtl -- v7.2.0 gate G90: static RTL checks for a Hebrew worksheet .docx.

WHY THIS EXISTS
    Word for Mac 16.114 -- the program teachers actually open -- was measured
    on probe documents (scratchpad/understand/docx.md section 4). It renders
    several perfectly valid OOXML constructs WRONG in a Hebrew document:
      * `w:jc="right"` (and "end") under `w:bidi` is read as logical END, so
        the paragraph comes out LEFT-aligned;
      * a Hebrew `w:rtl` run takes its size and bold from szCs / bCs, so `sz`
        and `b` alone are silently ignored (title printed 11 pt, not bold);
      * a table follows only a DIRECT `tblPr/bidiVisual` -- style-level flags
        are not inherited;
      * digits, signs and parentheses typed into an RTL run reorder
        (`-5 + 3` prints as `3 + 5-`, `(2, -3)` as `(3-, 2)`);
      * two OMML zones separated only by neutral/LTR runs swap places.
    None of this is visible to python-docx, LibreOffice or a schema validator,
    and a Mac with Word is not CI. So the defects are caught here, statically,
    from the XML, with one rule per measured failure (R1-R17, docx.md 7.2).

WHY STDLIB ONLY
    The gate runs as `python3 -I check_docx_rtl.py ...`. `-I` hides the user
    site, where python-docx and lxml live, and also drops the script folder
    from sys.path -- so this file imports nothing but the standard library
    and no sibling module.

USAGE
    python3 -I check_docx_rtl.py SHEET.docx [--source sheet.json]
            [--glossary glossary_he.json] [--ltr-tables q3:t1,t5]
            [--fonts David,"Cambria Math"] [--allow-latin Word,PDF]
            [--scope sectioned|broad] [--grade 7] [--pkg PACKAGE_DIR]
            [--r9-word-only] [--no-terms] [--json OUT] [--render]
    python3 -I -B check_docx_rtl.py --selftest [--fixtures DIR] [--write-synthetic DIR]
    (-B: -I ignores PYTHONDONTWRITEBYTECODE, so importers would write __pycache__)

    exit 0 = no errors, 1 = errors, 2 = the .docx (or --source) cannot be read
    -- a damaged zip member, a sheet.json that is not {questions: [...]}, or
    any input the rules did not foresee (record id READ / CRASH). Exit 2
    always comes with the JSON report, never a bare traceback.
    Output (stdout, and --json OUT): {file, sha256, errors, warnings, stats}.
    Every record: {id, rule, part, para_index, xpath, excerpt, msg}.

    Scope and grade (R17): --scope / --grade win; else sheet_meta.SHEET of
    --pkg, or of the package folder found up to three levels above the
    .docx / sheet.json (needs content.py and sheet_meta.py there; read with
    ast, never executed); else sheet.json. stats.scope / stats.grade say
    which. Without a scope, house-spelling hits are warnings only.

CONVENTIONS THIS CHECKER EXPECTS FROM emit_docx (documented, not guessed)
    * bookmarks `q<n>` around a whole question (text, example box, table and
      items) and `q<n><latin>` around each sub-item -- the ids of sheet.json
      (`deliver.item_id`);
    * answer rows: bookmarks `ans_q<n>` (and optionally `ans_q<n><latin>` per
      segment). Without them the answer page is found by its band text
      "תשובות סופיות" and its `(n)` rows are counted. Inside a row the
      marker `(n)` comes first; each answer is its item label (emit_docx
      item_label_text) + a space or NBSP + the answer, at the start of a
      paragraph or after two or more spaces (emit_docx puts three between
      segments); a paragraph without a label is an answer note;
    * a question table: one w:tbl, head row then rows, every row padded to
      the widest with empty cells (emit_docx.q_table);
    * an LTR table carries `w:bidiVisual w:val="0"` AND is listed with
      --ltr-tables, or says `ltr` in its `w:tblCaption` / `w:tblDescription`.

MEASURED REFINEMENTS (Word 16.114, tests/docxcheck/render/)
    * R9: two OMML zones whose separator is empty, LTR (rtl=0) or UNMARKED
      (a run with no w:rtl anywhere in its style chain, even inside a bidi
      paragraph) glue/swap -- always an ERROR, --r9-word-only included. Only
      a separator whose every non-empty run resolves to w:rtl=on and holds
      neutrals alone (", " "; " ": " " (") keeps the order in Word; the
      docx.md rule text still rejects it, so it is an ERROR by default with
      its own message (fix: U+200F RLM in the separator run), and a WARNING
      under --r9-word-only.
    * R16 parity runs both ways: every sheet.json question/item needs its
      bookmark, every q<n> / q<n><x> bookmark needs its sheet.json row, and
      ans_q<n> rows must match the questions with answers by name, not only
      by count.
    * R16 (G91) compares what is printed, not only that it is there. Its
      tokens are numbers, Latin/Greek point and segment names and math signs
      -- brackets '(' ')', the ':' division sign and the primes U+2032/U+2033
      included -- read from the Word text (w:t, OMML m:t, and the brackets an
      OMML m:d prints from m:begChr/m:sepChr/m:endChr).
        - Each question and item bookmark: the token multiset EQUALS the one
          of sheet.json (marker (n) and item labels included) and every
          sheet.json string's own token sequence appears contiguously; the
          Hebrew words of sheet.json are contained.
        - Order across strings, where order is the mathematics: the worked
          example's title and lines print one after the other in sheet.json
          order; the question's table is compared CELL BY CELL (a w:tbl of
          the sheet.json shape inside the bookmark, head row then rows, each
          cell's tokens in order and its Hebrew words).
        - Each answer row (ans_q<n>, or the (n) row after the answer-page
          band) binds every answer to its item by the printed label: the
          row opens with (n) alone; each answered item's label prints once
          and the tokens up to the next label EQUAL its answer, in order,
          with its Hebrew words. A label missing, doubled or unknown to
          sheet.json is an error; the right labels in another order are a
          warning. A label-less paragraph (an answer note) that prints
          tokens is a warning: deliver does not copy notes into sheet.json.
          A question-level answer (no labels): (n) then the answer, token for
          token. ans_q<n><x> segment bookmarks: multiset + sequence.
      Not compared: the order of Hebrew words, and order between two
      different strings of one question bookmark other than example lines
      and table cells (two single-token strings there may trade values).
      Normalized on both sides: NFC, ZWJ/RLM/LRM/isolates dropped, NBSP and
      thin spaces, '-' / U+2011 / U+2212 as one minus, U+2220 as the printed
      U+2221, \\angle{ABC} as ∡ABC (any DSL macro, also when leaked raw into
      Word), thousands commas; numbers never merge across OMML parts
      (10^3 is 10 and 3, \\f{1}{2} is 1 and 2).
    * R17 reads glossary_he.json by its own `matching` section (compile
      template, normalisation, house_spelling.forbidden_patterns) over all
      text: paragraphs of every story (headers, footers, text boxes), image
      alt text (wp:docPr, pic:cNvPr), table alt text (tblCaption,
      tblDescription) and core/app properties. --selftest replays the
      glossary's embedded test vectors when the file is present.
      No glossary -> R17 is SKIP plus a warning, never a silent pass.
      --no-terms (build_v72 passes it for a legacy package: no SHEET, so no
      glossary contract) -> R17 is SKIP with that reason in stats.skipped,
      no warning; every other rule runs as usual.
"""
from __future__ import print_function

import argparse
import hashlib
import io
import json
import os
import re
import struct
import sys
import tempfile
import unicodedata
import zipfile
import zlib
import xml.etree.ElementTree as ET
from collections import Counter

VERSION = "7.2.0-noam"

# ---------------------------------------------------------------- names ----
NS = {
    "w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
    "m": "http://schemas.openxmlformats.org/officeDocument/2006/math",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    "wp": "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
    "pic": "http://schemas.openxmlformats.org/drawingml/2006/picture",
    "mc": "http://schemas.openxmlformats.org/markup-compatibility/2006",
    "asvg": "http://schemas.microsoft.com/office/drawing/2016/SVG/main",
    "wps": "http://schemas.microsoft.com/office/word/2010/wordprocessingShape",
    "v": "urn:schemas-microsoft-com:vml",
    "ct": "http://schemas.openxmlformats.org/package/2006/content-types",
    "pr": "http://schemas.openxmlformats.org/package/2006/relationships",
    "cp": "http://schemas.openxmlformats.org/package/2006/metadata/core-properties",
    "dc": "http://purl.org/dc/elements/1.1/",
}
_PFX = dict((v, k) for k, v in NS.items())


def q(tag):
    p, l = tag.split(":")
    return "{%s}%s" % (NS[p], l)


def pfx(tag):
    if tag.startswith("{"):
        uri, l = tag[1:].split("}", 1)
        return "%s:%s" % (_PFX.get(uri, "ns"), l)
    return tag


W_P, W_R, W_T, W_PPR, W_RPR = q("w:p"), q("w:r"), q("w:t"), q("w:pPr"), q("w:rPr")
W_TBL, W_TBLPR, W_TC, W_TR = q("w:tbl"), q("w:tblPr"), q("w:tc"), q("w:tr")
W_SECTPR, W_VAL = q("w:sectPr"), q("w:val")
W_BMS, W_BME = q("w:bookmarkStart"), q("w:bookmarkEnd")
W_ID, W_NAME = q("w:id"), q("w:name")
M_OMATH, M_OMATHPARA, M_T, M_R = q("m:oMath"), q("m:oMathPara"), q("m:t"), q("m:r")
MC_ALT, MC_CHOICE, MC_FALLBACK = q("mc:AlternateContent"), q("mc:Choice"), q("mc:Fallback")
WP_INLINE, WP_ANCHOR, WP_DOCPR, WP_EXTENT = (q("wp:inline"), q("wp:anchor"),
                                             q("wp:docPr"), q("wp:extent"))
A_BLIP, ASVG_BLIP = q("a:blip"), q("asvg:svgBlip")
R_EMBED, R_LINK = q("r:embed"), q("r:link")
# OMML argument slots (and the zone itself): a boundary between two numbers
# that Word prints apart (fraction parts, base/script, radicand) although
# their m:t texts follow each other in the XML.
OMML_ARGS = set(q("m:" + t) for t in ("oMath", "e", "num", "den", "sup", "sub", "deg",
                                      "fName", "lim"))
# An OMML delimiter (m:d, emit_docx's \g{...}) prints its brackets from
# m:dPr/m:begChr, m:endChr and m:sepChr, not from any m:t. R16 reads them so
# that \g{-3}^2 and a literal (−3)^2 both print '(' and ')' as tokens.
M_D, M_DPR, M_E = q("m:d"), q("m:dPr"), q("m:e")
M_VAL = q("m:val")

# Revision-tracking and fallback subtrees hold old or duplicate content; the
# printed document is what is left without them.
SKIP_SUBTREES = set(q(t) for t in (
    "mc:Fallback", "w:pPrChange", "w:rPrChange", "w:sectPrChange",
    "w:tblPrChange", "w:trPrChange", "w:tcPrChange", "w:tblGridChange",
    "w:numberingChange", "w:del", "w:moveFrom"))
# Inline containers a run may sit in, inside one paragraph.
CONTAINERS = set(q(t) for t in (
    "w:hyperlink", "w:ins", "w:smartTag", "w:sdt", "w:sdtContent",
    "w:fldSimple", "w:customXml", "w:dir", "w:bdo", "w:moveTo"))

STORY_CT = {
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml": "document",
    "application/vnd.ms-word.document.macroEnabled.main+xml": "document",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.template.main+xml": "document",
    "application/vnd.ms-word.template.macroEnabledTemplate.main+xml": "document",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml": "header",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml": "footer",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.footnotes+xml": "footnotes",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.endnotes+xml": "endnotes",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.comments+xml": "comments",
}
STORY_ORDER = {"document": 0, "header": 1, "footer": 2, "footnotes": 3,
               "endnotes": 4, "comments": 5}

RULES = {
    "R1": "SECT_BIDI", "R2": "DEFAULTS", "R3": "PARA_BIDI", "R4": "JC_FLIP",
    "R5": "TABLE_DIR", "R6": "CS_PAIRS", "R7": "RTL_MATH_LEAK",
    "R8": "LTR_RUN_EDGES", "R9": "OMML_ADJACENT", "R10": "OMML_CONTENT",
    "R11": "MARKERS", "R12": "FONTS", "R13": "PACKAGE", "R14": "IMAGES",
    "R15": "SCHEMA_ORDER", "R16": "PARITY", "R17": "TERMS",
}
MAX_RECORDS_PER_RULE = 60

DEFAULT_FONTS = ("David", "Cambria Math", "Segoe UI Symbol")
# Product names that may stand inside Hebrew prose (the elementary v1.0.3
# footer says "גרסת Word"). Everything else Latin belongs inside $...$.
DEFAULT_LATIN_ALLOW = ("Word", "PDF", "Excel", "GeoGebra", "Desmos", "AI")

HEB = u"\u05d0-\u05ea"
HEB_RE = re.compile(u"[%s]" % HEB)
ANY_HEB_BLOCK = re.compile(u"[\u0590-\u05ff]")
NIQQUD = re.compile(u"[\u0591-\u05bd\u05bf\u05c1\u05c2\u05c4\u05c5\u05c7]")
INVISIBLE = re.compile(u"[\u00ad\u200b-\u200f\u202a-\u202e\u2060-\u2064\u2066-\u2069\ufeff]")
BIDI_MARKS = re.compile(u"[\u200e\u200f\u061c\u202a-\u202e\u2066-\u2069]")
GERESH = re.compile(u"[\u05f3\u05f4'\"`\u2019\u201d]")
LRM, RLM = u"\u200e", u"\u200f"
SEMANTIC_ANS_HEAD = u"תשובות"

# R7 -- text that reorders inside an RTL run (docx.md 4-E)
R7_SIGN = re.compile(u"(?<![\\w)])[+\\-\u2212\u00b1][0-9A-Za-z(]")
R7_BINOP = re.compile(u"[0-9A-Za-z)]\\s*[+\\-\u2212\u00d7\u00b7*/=<>\u2264\u2265\u2260\u2248^\u2236]\\s*[0-9A-Za-z(]")
R7_PAREN = re.compile(u"\\([^()]*\\d[^()]*[,;\u2212\\-][^()]*\\)")
R7_SLASH = re.compile(u"\\d\\s*/\\s*\\d")
R7_LATIN = re.compile(u"[A-Za-z]+")
THOUSANDS = re.compile(u"(?<![\\d.,])\\d{1,3}(?:,\\d{3})+(?![\\d,]|\\.\\d)")
LEAD_QMARK = re.compile(u"^\\s*\\(\\d+\\)")
LEAD_QMARK_N = re.compile(u"^\\s*\\((\\d+)\\)")
Q_BM = re.compile(r"^q\d+$")                   # bookmark of a whole question
ITEM_BM = re.compile(r"^q\d+[^\W\d_]+$")       # bookmark of a sub-item (q3b)
NUM_DOT_MARKER = re.compile(u"^\\d+\\.(?!\\d)")
DSL_LEAK = re.compile(u"[$\\\\{}]")

# R16 token parity: the printed math of a question / item / answer row --
# numbers, Latin (and Greek) point/segment names and math signs -- must be the
# same multiset in the Word text as in sheet.json. Hebrew words alone miss a
# changed angle value (40 -> 41) or answer (115 -> 114).
PAR_SEP = u"\x1f"       # a structural boundary: an OMML argument or a $...$ edge
# printed form of the DSL macros, as emit_docx writes them into OMML m:t
# (emit_docx._BARE, ANGLE_SIGN, RATIO_COLON)
PAR_BARE = {
    "para": u"∥", "npara": u"∦", "perp": u"⊥", "cong": u"≅", "sim": u"∼",
    "tri": u"△", "pi": u"π", "leq": u"≤", "geq": u"≥", "neq": u"≠",
    "approx": u"≈", "cdot": u"·", "times": u"×", "pm": u"±", "mp": u"∓",
    "deg": u"°", "infty": u"∞"}
# '(' ')', ASCII ':' (the Israeli division sign, 12:4) and the primes
# U+2032 / U+2033 are tokens too: (−3)^2 and −3^2, 12:4 and 12 4, A′B′ and AB
# are different mathematics. (The Hebrew geresh U+05F3 and the ASCII
# apostrophe are not: they also abbreviate Hebrew words.)
PAR_SIGNS = frozenset(u"+−×·=≠<>≤≥≈±∓∡°∥∦⊥≅∼△∞∶%():′″")
PAR_MINUS = re.compile(u"[\\-\u2010\u2011\u2212\ufe63\uff0d]")
PAR_SPACE = re.compile(u"[\u00a0\u2000-\u200a\u202f\u205f\u3000]")
PAR_NUM = re.compile(u"(?<![0-9])(?:[0-9]{1,3}(?:,[0-9]{3})+(?![0-9])|[0-9]+)(?:\\.[0-9]+)?")
PAR_NAME = re.compile(u"[A-Za-z\u0391-\u03a9\u03b1-\u03c9]+")
# item labels (emit_docx.HEB_LABEL / item_label_text): a Hebrew label prints
# as the letter and a period, any other label as `(1)`. In an answer row a
# label opens a segment at the start of a paragraph or after the run of
# spaces between segments; any single Hebrew letter + period found there
# counts as a label too, so a label sheet.json does not have is seen.
HEB_LABEL = re.compile(u"^[\u05d0-\u05ea]{1,3}[\u05f3'\u2032\u05f4\"]?$")
ANS_GENERIC_LABEL = u"[\u05d0-\u05ea]\\."
ANS_MARKER_LEAD = re.compile(u"^\\s*\u2605?\\s*\\(\\d+\\)\\s*\u2605?")   # (n) opening a row

# ECMA-376 child sequences (R15). Unknown children (w14:..., etc.) are ignored.
PPR_ORDER = ("pStyle keepNext keepLines pageBreakBefore framePr widowControl numPr "
             "suppressLineNumbers pBdr shd tabs suppressAutoHyphens kinsoku wordWrap "
             "overflowPunct topLinePunct autoSpaceDE autoSpaceDN bidi adjustRightInd "
             "snapToGrid spacing ind contextualSpacing mirrorIndents suppressOverlap jc "
             "textDirection textAlignment textboxTightWrap outlineLvl divId cnfStyle "
             "rPr sectPr pPrChange").split()
RPR_ORDER = ("ins del moveFrom moveTo rStyle rFonts b bCs i iCs caps smallCaps strike "
             "dstrike outline shadow emboss imprint noProof snapToGrid vanish webHidden "
             "color spacing w kern position sz szCs highlight u effect bdr shd fitText "
             "vertAlign rtl cs em lang eastAsianLayout specVanish oMath rPrChange").split()
TBLPR_ORDER = ("tblStyle tblpPr tblOverlap bidiVisual tblStyleRowBandSize "
               "tblStyleColBandSize tblW jc tblCellSpacing tblInd tblBorders shd "
               "tblLayout tblCellMar tblLook tblCaption tblDescription tblPrChange").split()
SECTPR_ORDER = ("headerReference footnotePr endnotePr type pgSz pgMar paperSrc "
                "pgBorders lnNumType pgNumType cols formProt vAlign noEndnote titlePg "
                "textDirection bidi rtlGutter docGrid printerSettings sectPrChange").split()


def _rank(order):
    d = dict((q("w:" + n), i) for i, n in enumerate(order))
    return d


PPR_RANK, RPR_RANK, TBLPR_RANK = _rank(PPR_ORDER), _rank(RPR_ORDER), _rank(TBLPR_ORDER)
SECTPR_RANK = _rank(SECTPR_ORDER)
SECTPR_RANK[q("w:footerReference")] = SECTPR_RANK[q("w:headerReference")]


class CannotRead(Exception):
    pass


# Everything zipfile/zlib raise for a damaged archive or member.
ZIP_ERRORS = (zipfile.BadZipFile, zipfile.LargeZipFile, zlib.error, EOFError,
              NotImplementedError, RuntimeError, ValueError, OSError, struct.error)


def to_int(v):
    """An integer XML attribute, or None when it is missing or not an integer
    (`3.6e6`, `12mm`): the caller reports it instead of crashing."""
    if v is None:
        return None
    try:
        return int(str(v).strip())
    except (TypeError, ValueError):
        return None


# --------------------------------------------------------------- helpers ----
def on(el):
    """ST_OnOff of a toggle element: None if absent."""
    if el is None:
        return None
    v = el.get(W_VAL)
    if v is None:
        return True
    return v.strip().lower() not in ("0", "false", "off", "none")


def norm_he(s):
    s = unicodedata.normalize("NFC", s or u"")
    s = NIQQUD.sub(u"", s)
    return INVISIBLE.sub(u"", s)


def he_words(s):
    """Hebrew word tokens: NFC, no niqqud, no geresh/quotes (they join, not split)."""
    return re.findall(u"[%s]+" % HEB, GERESH.sub(u"", norm_he(s)))


def show(s, n=90):
    if s is not None and not isinstance(s, str):     # sheet.json text as list/dict
        s = u" ".join(_strings(s))
    s = (s or u"").replace(LRM, u"‹LRM›").replace(RLM, u"‹RLM›")
    s = s.replace(u"\n", u" ⏎ ").replace(u"\t", u" ⇥ ")
    return s if len(s) <= n else s[:n - 1] + u"…"


def strong_rtl(s):
    return any(unicodedata.bidirectional(c) in ("R", "AL") for c in s)


def is_neutral(c):
    return unicodedata.bidirectional(c) in ("WS", "ON", "CS", "ES", "B", "S")


def png_size(b):
    if b[:8] == b"\x89PNG\r\n\x1a\n" and len(b) >= 24:
        return struct.unpack(">II", b[16:24])
    return None


def jpeg_size(b):
    if b[:2] != b"\xff\xd8":
        return None
    i = 2
    while i + 9 < len(b):
        if b[i] != 0xFF:
            i += 1
            continue
        marker = b[i + 1]
        if marker in (0xD8, 0xD9, 0x01) or 0xD0 <= marker <= 0xD7:
            i += 2
            continue
        seg = struct.unpack(">H", b[i + 2:i + 4])[0]
        if 0xC0 <= marker <= 0xCF and marker not in (0xC4, 0xC8, 0xCC):
            h, w = struct.unpack(">HH", b[i + 5:i + 9])
            return (w, h)
        i += 2 + seg
    return None


# --------------------------------------------------------------- package ----
class Package(object):
    def __init__(self, path):
        self.path = path
        try:
            with open(path, "rb") as f:
                self.data = f.read()
        except (IOError, OSError) as e:
            raise CannotRead("cannot open %s: %s" % (path, e))
        self.sha256 = hashlib.sha256(self.data).hexdigest()
        try:
            self.z = zipfile.ZipFile(io.BytesIO(self.data))
            self.names = set(self.z.namelist())
        except ZIP_ERRORS as e:
            raise CannotRead("not a zip/docx: %s: %s" % (type(e).__name__, e))
        self._xml = {}
        ctx = self.xml("[Content_Types].xml")
        if ctx is None:
            raise CannotRead("no [Content_Types].xml")
        self.ct_default, self.ct_override = {}, {}
        for d in ctx.findall(q("ct:Default")):
            self.ct_default[(d.get("Extension") or "").lower()] = d.get("ContentType")
        for o in ctx.findall(q("ct:Override")):
            self.ct_override[(o.get("PartName") or "").lstrip("/")] = o.get("ContentType")
        stories = []
        for name in self.names:
            kind = STORY_CT.get(self.content_type(name))
            if kind:
                stories.append((STORY_ORDER[kind], name, kind))
        stories.sort()
        self.stories = [(n, k) for _o, n, k in stories]
        if not any(k == "document" for _n, k in self.stories):
            raise CannotRead("no main document part")
        self.main = [n for n, k in self.stories if k == "document"][0]

    def content_type(self, name):
        if name in self.ct_override:
            return self.ct_override[name]
        ext = name.rsplit(".", 1)[-1].lower() if "." in name else ""
        return self.ct_default.get(ext)

    def read(self, name):
        """Member bytes, None when absent. A member that is present but cannot
        be inflated (bad deflate data, bad CRC, truncated, encrypted, unknown
        method) makes the whole package unreadable: exit 2, never a traceback
        with the 'errors found' exit 1."""
        try:
            return self.z.read(name)
        except KeyError:
            return None
        except ZIP_ERRORS as e:
            raise CannotRead("cannot inflate %s: %s: %s" % (name, type(e).__name__, e))

    def xml(self, name):
        if name not in self._xml:
            raw = self.read(name)
            if raw is None:
                self._xml[name] = None
            else:
                try:
                    self._xml[name] = ET.fromstring(raw)
                except (ET.ParseError, ValueError) as e:
                    raise CannotRead("XML error in %s: %s" % (name, e))
        return self._xml[name]

    def rels(self, name):
        d, b = os.path.split(name)
        root = self.xml(os.path.join(d, "_rels", b + ".rels").lstrip("/"))
        out = {}
        if root is None:
            return out
        for r in root.findall(q("pr:Relationship")):
            tgt = r.get("Target") or ""
            mode = r.get("TargetMode") or "Internal"
            if mode != "External":
                tgt = os.path.normpath(os.path.join(d, tgt)).replace("\\", "/").lstrip("/") \
                    if not tgt.startswith("/") else tgt.lstrip("/")
            out[r.get("Id")] = (r.get("Type") or "", tgt, mode)
        return out


class Styles(object):
    def __init__(self, root):
        self.root = root
        self.by_id = {}
        self.default = {}
        self.ppr_default = self.rpr_default = None
        if root is None:
            return
        for st in root.findall(q("w:style")):
            sid = st.get(q("w:styleId"))
            if sid:
                self.by_id[sid] = st
            if st.get(q("w:default")) in ("1", "true", "on"):
                self.default.setdefault(st.get(q("w:type")), sid)
        dd = root.find(q("w:docDefaults"))
        if dd is not None:
            self.ppr_default = dd.find("%s/%s" % (q("w:pPrDefault"), q("w:pPr")))
            self.rpr_default = dd.find("%s/%s" % (q("w:rPrDefault"), q("w:rPr")))

    def chain(self, sid):
        out, seen = [], set()
        while sid and sid not in seen and sid in self.by_id:
            seen.add(sid)
            st = self.by_id[sid]
            out.append(st)
            b = st.find(q("w:basedOn"))
            sid = b.get(W_VAL) if b is not None else None
        return out

    def normal(self):
        sid = self.default.get("paragraph") or ("Normal" if "Normal" in self.by_id else None)
        return self.by_id.get(sid) if sid else None


# ------------------------------------------------------------ the walker ----
class Para(object):
    __slots__ = ("part", "idx", "el", "xpath", "in_table", "tokens", "text",
                 "style", "bidi_direct", "bidi", "first_text_run")


class Story(object):
    """One story part, walked once in document order."""

    def __init__(self, pkg, styles, name, kind):
        self.pkg, self.styles, self.name, self.kind = pkg, styles, name, kind
        self.root = pkg.xml(name)
        self.xp = {}
        self.paras, self.tables, self.sects, self.drawings = [], [], [], []
        self.wt, self.mt = [], []           # (element, para index)
        self.stream = []                    # bookmark/text stream
        self.bm_names = {}                  # id -> name
        self._open = {}
        if self.root is not None:
            self._walk(self.root, "/" + pfx(self.root.tag), None, 0, False)
        for p in self.paras:
            self._para_info(p)

    def _walk(self, el, path, para, depth_tbl, skip_note):
        counts = {}
        delims = omml_delims(el) if el.tag == M_D else None
        n_e = 0
        for ch in el:
            tag = ch.tag
            if not isinstance(tag, str) or tag in SKIP_SUBTREES:
                continue
            counts[tag] = counts.get(tag, 0) + 1
            cpath = "%s/%s[%d]" % (path, pfx(tag), counts[tag])
            self.xp[ch] = cpath
            if tag in (q("w:footnote"), q("w:endnote")) and \
                    ch.get(q("w:type")) in ("separator", "continuationSeparator",
                                            "continuationNotice"):
                continue
            if tag == W_P:
                p = Para()
                p.part, p.idx, p.el, p.xpath = self.name, len(self.paras), ch, cpath
                p.in_table = depth_tbl > 0
                self.paras.append(p)
                self._walk(ch, cpath, p.idx, depth_tbl, skip_note)
                self.stream.append(("t", u"\n", p.idx))
                continue
            if tag == W_TBL:
                self.tables.append((ch, cpath, para, sorted(set(self._open.values()))))
                self._walk(ch, cpath, para, depth_tbl + 1, skip_note)
                continue
            if tag == W_SECTPR:
                self.sects.append((ch, cpath, para))
            elif tag in (WP_INLINE, WP_ANCHOR):
                self.drawings.append((ch, cpath, para))
            elif tag == W_BMS:
                bid, name = ch.get(W_ID), ch.get(W_NAME) or u""
                self.bm_names[bid] = name
                self._open[bid] = name
                self.stream.append(("bs", bid, name, para))
            elif tag == W_BME:
                bid = ch.get(W_ID)
                self._open.pop(bid, None)
                self.stream.append(("be", bid))
            elif tag == W_T:
                self.wt.append((ch, para))
                self.stream.append(("t", ch.text or u"", para))
            elif tag == M_T:
                self.mt.append((ch, para))
                self.stream.append(("t", ch.text or u"", para))
            elif tag in (q("w:tab"), q("w:br"), q("w:cr"), q("w:ptab")):
                self.stream.append(("t", u" ", para))
            elif tag == q("w:noBreakHyphen"):
                self.stream.append(("t", u"\u2011", para))
            # R16 token parity only (bookmark ptext): OMML argument boundaries
            # ("mb") and the printed brackets of an m:d delimiter ("mp")
            if tag == M_D:
                self.stream.append(("mp", omml_delims(ch)[0], para))
            if delims is not None and tag == M_E:
                if n_e:
                    self.stream.append(("mp", delims[1], para))
                n_e += 1
            if tag in OMML_ARGS:
                self.stream.append(("mb", para))
            self._walk(ch, cpath, para, depth_tbl, skip_note)
            if tag in OMML_ARGS:
                self.stream.append(("mb", para))
            if tag == M_D:
                self.stream.append(("mp", omml_delims(ch)[2], para))
            if tag == W_TC:
                self.stream.append(("t", u" ", para))

    # -- paragraph inline content (runs, math zones), nested paragraphs excluded
    def inline_tokens(self, p_el):
        toks = []

        def rec(el):
            for ch in el:
                t = ch.tag
                if not isinstance(t, str) or t == W_PPR or t in SKIP_SUBTREES:
                    continue
                if t == W_R:
                    toks.append(("r", ch))
                elif t in (M_OMATHPARA, M_OMATH):
                    toks.append(("m", ch))
                elif t == W_BMS:
                    toks.append(("bs", ch))
                elif t == MC_ALT:
                    c = ch.find(MC_CHOICE)
                    if c is not None:
                        rec(c)
                elif t in CONTAINERS:
                    rec(ch)
        rec(p_el)
        return toks

    def _para_info(self, p):
        st = self.styles
        ppr = p.el.find(W_PPR)
        sid = None
        if ppr is not None:
            ps = ppr.find(q("w:pStyle"))
            if ps is not None:
                sid = ps.get(W_VAL)
        p.style = sid or st.default.get("paragraph")
        p.bidi_direct = on(ppr.find(q("w:bidi"))) if ppr is not None else None
        b = self.p_lookup(p, q("w:bidi"))
        p.bidi = bool(on(b))
        p.tokens = self.inline_tokens(p.el)
        parts = []
        p.first_text_run = None
        for kind, el in p.tokens:
            if kind == "r":
                t = run_text(el)
                if p.first_text_run is None and t.strip(u" \t" + LRM + RLM):
                    p.first_text_run = el
                parts.append(t)
            elif kind == "m":
                if p.first_text_run is None:
                    p.first_text_run = el
                parts.append(math_text(el))
        p.text = u"".join(parts)

    def p_lookup(self, p, tag):
        ppr = p.el.find(W_PPR)
        if ppr is not None:
            el = ppr.find(tag)
            if el is not None:
                return el
        for s in self.styles.chain(p.style):
            sp = s.find(W_PPR)
            if sp is not None and sp.find(tag) is not None:
                return sp.find(tag)
        if self.styles.ppr_default is not None:
            return self.styles.ppr_default.find(tag)
        return None

    def r_chain(self, run, p):
        out = []
        rpr = run.find(W_RPR)
        if rpr is not None:
            out.append(rpr)
        rs = rpr.find(q("w:rStyle")) if rpr is not None else None
        sid = rs.get(W_VAL) if rs is not None else self.styles.default.get("character")
        for s in self.styles.chain(sid):
            x = s.find(W_RPR)
            if x is not None:
                out.append(x)
        for s in self.styles.chain(p.style if p is not None else None):
            x = s.find(W_RPR)
            if x is not None:
                out.append(x)
        if self.styles.rpr_default is not None:
            out.append(self.styles.rpr_default)
        return out


def r_el(chain, tag):
    for rpr in chain:
        el = rpr.find(tag)
        if el is not None:
            return el
    return None


def r_attr(chain, tag, attrs):
    for rpr in chain:
        el = rpr.find(tag)
        if el is not None:
            for a in attrs:
                if el.get(a) is not None:
                    return el.get(a)
    return None


def run_text(r):
    out = []
    for ch in r:
        t = ch.tag
        if t == W_T:
            out.append(ch.text or u"")
        elif t in (q("w:tab"), q("w:ptab")):
            out.append(u"\t")
        elif t in (q("w:br"), q("w:cr")):
            out.append(u"\n")
        elif t == q("w:noBreakHyphen"):
            out.append(u"\u2011")
    return u"".join(out)


def math_text(zone):
    return u"".join(t.text or u"" for t in zone.iter(M_T))


def omml_delims(d):
    """(begin, separator, end) characters an m:d delimiter prints: m:dPr
    m:begChr / m:sepChr / m:endChr, defaults '(' '|' ')' (ECMA-376 22.1.2);
    an empty m:val prints nothing."""
    out = [u"(", u"|", u")"]
    dpr = d.find(M_DPR)
    if dpr is not None:
        for k, name in enumerate(("begChr", "sepChr", "endChr")):
            c = dpr.find(q("m:" + name))
            if c is not None:
                out[k] = c.get(M_VAL) or u""
    return tuple(out)


def el_text(el, sep=False):
    """Printed text of any subtree (a table row, a paragraph) the way
    Story._walk streams it; sep=True adds PAR_SEP at OMML argument
    boundaries and the brackets of m:d delimiters (R16 token parity)."""
    out = []

    def rec(e):
        n_e = 0
        delims = omml_delims(e) if sep and e.tag == M_D else None
        for ch in e:
            t = ch.tag
            if not isinstance(t, str) or t in SKIP_SUBTREES:
                continue
            if t in (W_T, M_T):
                out.append(ch.text or u"")
            elif t in (q("w:tab"), q("w:br"), q("w:cr"), q("w:ptab")):
                out.append(u" ")
            elif t == q("w:noBreakHyphen"):
                out.append(u"\u2011")
            if sep and t == M_D:
                out.append(omml_delims(ch)[0])
            if delims is not None and t == M_E:
                if n_e:
                    out.append(delims[1])
                n_e += 1
            if sep and t in OMML_ARGS:
                out.append(PAR_SEP)
            rec(ch)
            if sep and t in OMML_ARGS:
                out.append(PAR_SEP)
            if sep and t == M_D:
                out.append(omml_delims(ch)[2])
            if t == W_P:
                out.append(u"\n")
            elif t == W_TC:
                out.append(u" ")
    rec(el)
    if el.tag == W_P:
        out.append(u"\n")
    return u"".join(out)


# ---------------------------------------------------------------- glossary --
_SEP = u"[\\s\u05be-]"


def widen_spaces(pat):
    """Word gaps OUTSIDE character classes become [\\s maqaf -]: a literal space
    run or \\s(+,*,?) -- the contract's "words joined by space/maqaf/hyphen".
    Classes are left alone: glossary patterns already carry [\\s\u05be-]+ inside
    them, and rewriting the \\s there would nest a set and change the match."""
    out, i, n, in_cls = [], 0, len(pat), False
    while i < n:
        c = pat[i]
        if c == "\\" and i + 1 < n:
            tok = pat[i:i + 2]
            if not in_cls and tok == "\\s":
                nxt = pat[i + 2:i + 3]
                if nxt in ("+", "*"):
                    out.append(_SEP + nxt)
                    i += 3
                elif nxt == "?":
                    out.append(_SEP + "*")
                    i += 3
                elif nxt == "{":
                    out.append(_SEP)
                    i += 2
                else:
                    out.append(_SEP + "+")
                    i += 2
                continue
            out.append(tok)
            i += 2
            continue
        if in_cls:
            out.append(c)
            if c == "]":
                in_cls = False
            i += 1
            continue
        if c == "[":
            in_cls = True
            out.append(c)
            i += 1
            if pat[i:i + 1] == "^":
                out.append("^")
                i += 1
            if pat[i:i + 1] == "]":
                out.append("]")
                i += 1
            continue
        if c == " ":
            while i < n and pat[i] == " ":
                i += 1
            out.append(_SEP + "+")
            continue
        out.append(c)
        i += 1
    return u"".join(out)


def compile_term(pattern, prefixes):
    """glossary matching.compile: (?<![\u05d0-\u05ea])(?:prefixes)(?:pattern)(?![\u05d0-\u05ea])."""
    return re.compile(u"(?<![%s])(?:%s)(?:%s)(?![%s])"
                      % (HEB, prefixes, widen_spaces(pattern), HEB))


def norm_terms(s):
    """glossary matching.normalize: NFC, no niqqud (maqaf kept), ' -> \u05f3, " -> \u05f4."""
    return norm_he(s).replace(u"'", u"\u05f3").replace(u'"', u"\u05f4")


def grade_number(g):
    if g is None:
        return None
    s = GERESH.sub(u"", str(g))
    m = re.search(r"\b(1[0-2]|[1-9])\b", s)
    if m:
        return m.group(1)
    m = re.search(u"([%s]{1,2})\\s*$" % HEB, s.strip())
    if m:
        heb = {u"א": "1", u"ב": "2", u"ג": "3", u"ד": "4", u"ה": "5", u"ו": "6",
               u"ז": "7", u"ח": "8", u"ט": "9", u"י": "10", u"יא": "11", u"יב": "12"}
        return heb.get(m.group(1))
    return None


def load_source(path):
    """sheet.json for R16, validated: a JSON object whose `questions` is a list
    of objects (each `items`, when present, a list of objects). Anything else
    is an input that cannot be read (exit 2), not an RTL error."""
    try:
        with open(path, "rb") as f:
            data = json.loads(f.read().decode("utf-8"))
    except (IOError, OSError, ValueError) as e:
        raise CannotRead("cannot read --source %s: %s" % (path, e))
    if not isinstance(data, dict):
        raise CannotRead("--source %s: top level is a JSON %s, not an object"
                         % (path, type(data).__name__))
    qs = data.get("questions")
    if not isinstance(qs, list):
        raise CannotRead("--source %s: 'questions' is %s, not a list"
                         % (path, "missing" if qs is None else type(qs).__name__))
    for i, qd in enumerate(qs):
        if not isinstance(qd, dict):
            raise CannotRead("--source %s: questions[%d] is not an object" % (path, i))
        items = qd.get("items")
        if items is not None and not (isinstance(items, list) and
                                      all(isinstance(it, dict) for it in items)):
            raise CannotRead("--source %s: questions[%d].items is not a list of objects"
                             % (path, i))
    return data


def sheet_meta_path(pkg, near):
    """The package's sheet_meta.py: <pkg>/sheet_meta.py for an explicit --pkg,
    else the first folder at most three levels above the .docx or sheet.json
    that holds BOTH content.py and sheet_meta.py (the package layout of the
    contract: <pkg>/out/docx/<k>/sheet.docx, <pkg>/out/deliver/<k>/sheet.json).
    None for a legacy package without a sections manifest."""
    if pkg:
        if not os.path.isdir(pkg):
            raise CannotRead("--pkg %s is not a folder" % pkg)
        p = os.path.join(pkg, "sheet_meta.py")
        return p if os.path.isfile(p) else None
    for start in near:
        if not start:
            continue
        d = os.path.dirname(os.path.abspath(start))
        for _ in range(4):
            if os.path.isfile(os.path.join(d, "sheet_meta.py")) and \
                    os.path.isfile(os.path.join(d, "content.py")):
                return os.path.join(d, "sheet_meta.py")
            parent = os.path.dirname(d)
            if parent == d:
                break
            d = parent
    return None


def read_sheet_meta(path):
    """{scope, grade} of sheet_meta.SHEET, read with ast -- never executed (the
    gate runs under -I and must not run package code). Keys whose values are
    not literals are skipped; an unreadable file gives {}."""
    import ast
    try:
        with open(path, "rb") as f:
            tree = ast.parse(f.read().decode("utf-8"), path)
    except (IOError, OSError, ValueError, SyntaxError):
        return {}
    for node in tree.body:
        targets = []
        if isinstance(node, ast.Assign):
            targets, value = node.targets, node.value
        elif isinstance(node, ast.AnnAssign) and node.value is not None:
            targets, value = [node.target], node.value
        if not any(isinstance(t, ast.Name) and t.id == "SHEET" for t in targets):
            continue
        if not isinstance(value, ast.Dict):
            return {}
        out = {}
        for k, v in zip(value.keys, value.values):
            if isinstance(k, ast.Constant) and k.value in ("scope", "grade"):
                try:
                    out[k.value] = ast.literal_eval(v)
                except (ValueError, SyntaxError, TypeError):
                    pass
        return out
    return {}


# ----------------------------------------------------------------- checker --
class Report(object):
    def __init__(self):
        self.errors, self.warnings = [], []
        self.counts = {}
        self.skipped = {}

    def add(self, sev, rid, msg, part=None, para=None, xpath=None, excerpt=None, **extra):
        key = (sev, rid)
        self.counts[key] = self.counts.get(key, 0) + 1
        lst = self.errors if sev == "error" else self.warnings
        n = self.counts[key]
        if n > MAX_RECORDS_PER_RULE:
            return
        rec = {"id": rid, "rule": RULES.get(rid, rid), "part": part,
               "para_index": para, "xpath": xpath,
               "excerpt": show(excerpt) if excerpt is not None else None, "msg": msg}
        rec.update(extra)
        lst.append(rec)

    def finish(self):
        for (sev, rid), n in sorted(self.counts.items()):
            if n > MAX_RECORDS_PER_RULE:
                lst = self.errors if sev == "error" else self.warnings
                lst.append({"id": rid, "rule": RULES.get(rid, rid), "part": None,
                            "para_index": None, "xpath": None, "excerpt": None,
                            "msg": "%d more %s record(s) of %s not listed"
                                   % (n - MAX_RECORDS_PER_RULE, sev, rid)})

    def status(self):
        out = {}
        for rid in RULES:
            if rid in self.skipped:
                out[rid] = "SKIP"
            elif self.counts.get(("error", rid)):
                out[rid] = "FAIL"
            elif self.counts.get(("warn", rid)):
                out[rid] = "WARN"
            else:
                out[rid] = "PASS"
        return out


class Checker(object):
    def __init__(self, path, source=None, glossary=None, ltr_tables=(), fonts=None,
                 allow_latin=None, scope=None, grade=None, r9_word_only=False, pkg=None,
                 no_terms=False):
        self.path = path
        self.no_terms = bool(no_terms)
        self.r9_word_only = bool(r9_word_only)
        self.pkg = Package(path)
        self.styles = Styles(self.pkg.xml(self._styles_part()))
        self.stories = [Story(self.pkg, self.styles, n, k) for n, k in self.pkg.stories]
        self.rep = Report()
        self.source_path, self.glossary_path = source, glossary
        self.ltr_tables = set(x.strip() for x in ltr_tables if x.strip())
        self.fonts = set(fonts or DEFAULT_FONTS)
        self.allow_latin = set(allow_latin if allow_latin is not None else DEFAULT_LATIN_ALLOW)
        self.scope, self.grade = scope, grade_number(grade) if grade else None
        self.scope_from = "--scope" if scope else None
        self.grade_from = "--grade" if self.grade else None
        self.source = None
        if source:
            self.source = load_source(source)
            if self.grade is None:
                self.grade = grade_number(self.source.get("grade"))
                self.grade_from = "sheet.json grade" if self.grade else None
        # sections manifest (sheet_meta.SHEET): explicit --pkg, else the package
        # folder found above the .docx / sheet.json (out/docx/<k>/sheet.docx,
        # out/deliver/<k>/sheet.json). It supplies scope (house spelling ERROR
        # for 'sectioned') and grade when the caller did not pass them.
        self.meta_path = sheet_meta_path(pkg, [path, source])
        self.sheet_meta = read_sheet_meta(self.meta_path) if self.meta_path else None
        if self.sheet_meta:
            if self.scope is None and self.sheet_meta.get("scope") in ("sectioned", "broad"):
                self.scope = self.sheet_meta["scope"]
                self.scope_from = self.meta_path
            if self.grade is None and self.sheet_meta.get("grade"):
                self.grade = grade_number(self.sheet_meta.get("grade"))
                self.grade_from = self.meta_path if self.grade else None
        if self.scope is None and self.source is not None and \
                self.source.get("scope") in ("sectioned", "broad"):
            self.scope, self.scope_from = self.source["scope"], "sheet.json scope"
        self._bookmarks = None
        self.bm_duplicates = Counter()

    def _styles_part(self):
        for _t, tgt, _m in self.pkg.rels(self.pkg.main).values():
            if _t.endswith("/styles"):
                return tgt
        return "word/styles.xml"

    def _settings_part(self):
        for _t, tgt, _m in self.pkg.rels(self.pkg.main).values():
            if _t.endswith("/settings"):
                return tgt
        return "word/settings.xml"

    def _font_table_part(self):
        for _t, tgt, _m in self.pkg.rels(self.pkg.main).values():
            if _t.endswith("/fontTable"):
                return tgt
        return "word/fontTable.xml"

    # ------------------------------------------------------------------ run
    def run(self, render=False):
        for fn in (self.r1, self.r2, self.r3_r4, self.r5, self.runs_r6_r7_r8,
                   self.r9, self.r10, self.r11, self.r12, self.r13, self.r14,
                   self.r15, self.r16, self.r17):
            fn()
        render_info = run_render(self.path, self.rep) if render else None
        self.rep.finish()
        res = self.result()
        if render_info is not None:
            res["stats"]["render"] = render_info
        return res

    def result(self):
        paras = sum(len(s.paras) for s in self.stories)
        runs = sum(1 for s in self.stories for p in s.paras for k, _e in p.tokens if k == "r")
        omath = sum(1 for s in self.stories for p in s.paras for k, e in p.tokens
                    if k == "m" for _z in ([e] if e.tag == M_OMATH else e.findall(M_OMATH)))
        stats = {
            "checker": "check_docx_rtl %s" % VERSION,
            "parts": [n for n, _k in self.pkg.stories],
            "paragraphs": paras, "runs": runs,
            "tables": sum(len(s.tables) for s in self.stories),
            "omath": omath,
            "images": sum(len(s.drawings) for s in self.stories),
            "bookmarks": len(self.bookmarks()),
            "scope": {"value": self.scope, "from": self.scope_from},
            "grade": {"value": self.grade, "from": self.grade_from},
            "rules": self.rep.status(),
            "skipped": self.rep.skipped,
            "rule_counts": dict(("%s:%s" % (rid, sev), n)
                                for (sev, rid), n in sorted(self.rep.counts.items())),
        }
        return {"file": os.path.abspath(self.path), "sha256": self.pkg.sha256,
                "errors": self.rep.errors, "warnings": self.rep.warnings, "stats": stats}

    def err(self, rid, msg, **kw):
        self.rep.add("error", rid, msg, **kw)

    def warn(self, rid, msg, **kw):
        self.rep.add("warn", rid, msg, **kw)

    def _where(self, story, p):
        return dict(part=story.name, para=p.idx, xpath=p.xpath, excerpt=p.text)

    # ------------------------------------------------------------------- R1
    def r1(self):
        found = 0
        for s in self.stories:
            if s.kind != "document":
                continue
            for el, xp, para in s.sects:
                found += 1
                if not on(el.find(q("w:bidi"))):
                    p = s.paras[para] if para is not None else None
                    self.err("R1", "w:sectPr without an enabled w:bidi (page order and "
                             "gutter stay LTR)", part=s.name, para=para, xpath=xp,
                             excerpt=p.text if p else None)
        if not found:
            self.err("R1", "the document has no w:sectPr at all", part=self.pkg.main)

    # ------------------------------------------------------------------- R2
    def r2(self):
        st, part = self.styles, self._styles_part()
        if st.root is None:
            self.err("R2", "no styles part: docDefaults cannot carry bidi/lang", part=part)
            return
        pd = st.ppr_default
        if pd is None or not on(pd.find(q("w:bidi"))):
            self.err("R2", "docDefaults/pPrDefault has no enabled w:bidi", part=part,
                     xpath="/w:styles/w:docDefaults/w:pPrDefault/w:pPr")
        if pd is not None and pd.find(q("w:jc")) is not None and \
                pd.find(q("w:jc")).get(W_VAL) in ("right", "end"):
            self.err("R2", "pPrDefault has jc=%s (renders LEFT under bidi)"
                     % pd.find(q("w:jc")).get(W_VAL), part=part)
        nm = st.normal()
        if nm is None:
            self.err("R2", "no default paragraph style (Normal)", part=part)
        else:
            nppr = nm.find(W_PPR)
            nid = nm.get(q("w:styleId"))
            if nppr is None or not on(nppr.find(q("w:bidi"))):
                self.err("R2", "style %s has no enabled w:bidi" % nid, part=part,
                         xpath="/w:styles/w:style[@w:styleId='%s']" % nid)
            jc = nppr.find(q("w:jc")) if nppr is not None else None
            if jc is not None and jc.get(W_VAL) in ("right", "end"):
                self.err("R2", "style %s has jc=%s" % (nid, jc.get(W_VAL)), part=part)
        rd = st.rpr_default
        lang = rd.find(q("w:lang")) if rd is not None else None
        if lang is None or lang.get(q("w:bidi")) != "he-IL":
            self.err("R2", "rPrDefault has no w:lang w:bidi=\"he-IL\" (found %r)"
                     % (lang.get(q("w:bidi")) if lang is not None else None), part=part,
                     xpath="/w:styles/w:docDefaults/w:rPrDefault/w:rPr")
        if rd is not None and on(rd.find(q("w:rtl"))):
            self.err("R2", "rPrDefault has w:rtl: every typed run (digits too) "
                     "would become RTL", part=part)

    # -------------------------------------------------------------- R3 / R4
    def r3_r4(self):
        for s in self.stories:
            for p in s.paras:
                if not p.bidi_direct:
                    self.err("R3", "paragraph without a direct enabled w:bidi",
                             **self._where(s, p))
                if p.bidi:
                    jc = s.p_lookup(p, q("w:jc"))
                    if jc is not None and jc.get(W_VAL) in ("right", "end"):
                        src = "direct" if (p.el.find(W_PPR) is not None and
                                           p.el.find(W_PPR).find(q("w:jc")) is jc) \
                            else "style/default"
                        self.err("R4", "jc=%s (%s) on a bidi paragraph: Word reads it as "
                                 "logical END and renders the paragraph LEFT-aligned"
                                 % (jc.get(W_VAL), src), **self._where(s, p))

    # ------------------------------------------------------------------- R5
    def r5(self):
        g = 0
        for s in self.stories:
            perq = {}
            for el, xp, para, open_bm in s.tables:
                g += 1
                ids = ["t%d" % g] if s.kind == "document" else []
                for name in open_bm:
                    if re.match(r"^q\d+$", name):
                        perq[name] = perq.get(name, 0) + 1
                        ids.append("%s:t%d" % (name, perq[name]))
                tp = el.find(W_TBLPR)
                bv = tp.find(q("w:bidiVisual")) if tp is not None else None
                flag = u""
                if tp is not None:
                    for t in (q("w:tblCaption"), q("w:tblDescription")):
                        x = tp.find(t)
                        if x is not None:
                            flag += u" " + (x.get(W_VAL) or u"")
                ir_ltr = bool(re.search(r"\bltr\b", flag, re.I))
                listed = bool(self.ltr_tables.intersection(ids))
                where = dict(part=s.name, para=para, xpath=xp,
                             excerpt=u"table %s" % (",".join(ids) or "?"))
                if bv is None:
                    sty = tp.find(q("w:tblStyle")) if tp is not None else None
                    extra = ""
                    if sty is not None:
                        for st in self.styles.chain(sty.get(W_VAL)):
                            stp = st.find(W_TBLPR)
                            if stp is not None and stp.find(q("w:bidiVisual")) is not None:
                                extra = " (style %s has bidiVisual, but Word ignores " \
                                        "style-level table direction)" % sty.get(W_VAL)
                    self.err("R5", "table without a direct tblPr/bidiVisual: columns run "
                             "left-to-right" + extra, **where)
                elif not on(bv):
                    if not (listed or ir_ltr):
                        self.err("R5", "table has bidiVisual=0 (LTR) but is not listed in "
                                 "--ltr-tables nor flagged ltr in tblCaption/tblDescription",
                                 **where)
                elif listed or ir_ltr:
                    self.err("R5", "table is declared LTR but has bidiVisual on", **where)

    # ------------------------------------------------------ R6 / R7 / R8
    def runs_r6_r7_r8(self):
        for s in self.stories:
            for p in s.paras:
                seq, seq_runs = [], []
                started = False

                def flush():
                    if seq:
                        self._r7_text(s, p, u"".join(seq), seq_at_start[0], seq_runs[:])
                    del seq[:]
                    del seq_runs[:]
                seq_at_start = [True]
                for kind, el in p.tokens:
                    if kind == "bs":
                        continue
                    if kind == "m":
                        flush()
                        started = True
                        continue
                    text = run_text(el)
                    chain = s.r_chain(el, p)
                    rtl_el = r_el(chain, q("w:rtl"))
                    rtl_on = on(rtl_el)
                    is_rtl = rtl_on if rtl_on is not None else p.bidi
                    has_heb = bool(ANY_HEB_BLOCK.search(text))
                    if rtl_on or has_heb:
                        self._r6(s, p, el, chain, text)
                    if rtl_on is False and p.bidi and text:
                        self._r8(s, p, el, text)
                    if is_rtl:
                        if not seq:
                            seq_at_start[0] = not started
                        seq.append(text)
                        seq_runs.append(el)
                    else:
                        flush()
                    if text.strip():
                        started = True
                flush()

    def _r6(self, s, p, run, chain, text):
        where = dict(part=s.name, para=p.idx, xpath=s.xp.get(run, p.xpath),
                     excerpt=text or p.text)
        probs = []
        cs = r_attr(chain, q("w:rFonts"), (q("w:cs"), q("w:cstheme")))
        if cs is None:
            probs.append("no rFonts@cs")
        for a, b in (("b", "bCs"), ("i", "iCs")):
            va, vb = on(r_el(chain, q("w:" + a))), on(r_el(chain, q("w:" + b)))
            if bool(va) != bool(vb):
                probs.append("%s=%s but %s=%s" % (a, bool(va), b, bool(vb)))
        sz = r_attr(chain, q("w:sz"), (W_VAL,))
        szcs = r_attr(chain, q("w:szCs"), (W_VAL,))
        if sz != szcs:
            probs.append("sz=%s but szCs=%s" % (sz, szcs))
        lb = r_attr(chain, q("w:lang"), (q("w:bidi"),))
        if lb != "he-IL":
            probs.append("lang@bidi=%s (expected he-IL)" % lb)
        if probs:
            self.err("R6", "Hebrew/RTL run: " + "; ".join(probs) +
                     " -- Word formats RTL runs from the cs properties", **where)

    def _r8(self, s, p, run, text):
        core = text
        bounded = core.startswith(LRM) and core.endswith(LRM) and len(core) >= 2
        inner = core[1:-1] if bounded else core
        where = dict(part=s.name, para=p.idx, xpath=s.xp.get(run, p.xpath), excerpt=text)
        if not core.strip(LRM):
            return
        if is_neutral(core[0]) or is_neutral(core[-1]):
            self.warn("R8", "LTR run starts or ends with whitespace/neutral; in an RTL "
                      "paragraph it migrates to the other side", **where)
        elif not bounded and any(is_neutral(c) for c in inner):
            self.warn("R8", "LTR run holds neutrals but is not LRM-bounded", **where)

    def _r7_text(self, s, p, text, at_start, runs):
        t = BIDI_MARKS.sub(u"", text)
        if at_start:
            m = LEAD_QMARK.match(t)
            if m:
                t = u" " * m.end() + t[m.end():]
        for w in self.allow_latin:
            t = re.sub(r"(?<![A-Za-z])%s(?![A-Za-z])" % re.escape(w), u"א", t)
        t = THOUSANDS.sub(u"0", t)
        hits = []
        for code, rx in (("a", R7_SIGN), ("b", R7_BINOP), ("d", R7_SLASH)):
            m = rx.search(t)
            if m:
                hits.append("(%s) %r" % (code, m.group(0)))
        for m in R7_PAREN.finditer(t):
            if not HEB_RE.search(m.group(0)):
                hits.append("(c) %r" % m.group(0))
                break
        m = R7_LATIN.search(t)
        if m:
            hits.append("(e) Latin %r" % m.group(0))
        if hits:
            self.err("R7", "math/Latin inside an RTL run reorders in Word: " +
                     ", ".join(hits) + " -- move it into $...$ (OMML) or an LRM-bounded "
                     "rtl=0 run", part=s.name, para=p.idx,
                     xpath=s.xp.get(runs[0], p.xpath) if runs else p.xpath, excerpt=text)

    # ------------------------------------------------------------------- R9
    def r9(self):
        u"""Measured in Word 16.114 (tests/docxcheck/render/zoom_r9_separators.png,
        tests/docxcheck/render/zoom_r9_unmarked.png): a separator between two
        zones that is empty, rtl=0, or a run with NO w:rtl at all glues/swaps
        them -- the unmarked run is LTR to Word even in a bidi paragraph, so
        paragraph direction never stands in for the run flag here. Only an
        explicit w:rtl run holding neutrals (", " "; " ": " " (") keeps the
        order in Word. The rule text (docx.md 7.2) rejects both classes; the
        second is reported with its own message, and --r9-word-only makes
        (only) it a warning. A U+200F RLM in the separator run satisfies the
        rule everywhere."""
        for s in self.stories:
            for p in s.paras:
                last_math, between, sep_ltr = None, [], False
                for kind, el in p.tokens:
                    if kind == "m":
                        if last_math is not None:
                            sep = u"".join(between)
                            if not strong_rtl(sep):
                                where = dict(part=s.name, para=p.idx,
                                             xpath=s.xp.get(el, p.xpath), excerpt=p.text)
                                if sep_ltr or not sep:
                                    self.err("R9", "two OMML zones separated only by %r "
                                             "in an empty, rtl=0 or unmarked (no w:rtl) run: "
                                             "Word glues or swaps them (measured) -- make it "
                                             "one zone, or an explicit w:rtl run with U+200F "
                                             "RLM" % sep, **where)
                                else:
                                    self.rep.add(
                                        "warn" if self.r9_word_only else "error", "R9",
                                        "two OMML zones separated only by the neutral RTL "
                                        "run %r: Word keeps the order (measured) but other "
                                        "renderers may not -- add U+200F RLM to the "
                                        "separator run" % sep, **where)
                        last_math, between, sep_ltr = el, [], False
                    elif kind == "r":
                        t = run_text(el)
                        between.append(t)
                        if t:
                            # RTL only when w:rtl RESOLVES on; missing counts as LTR
                            rtl = on(r_el(s.r_chain(el, p), q("w:rtl")))
                            if rtl is not True:
                                sep_ltr = True

    # ------------------------------------------------------------------ R10
    def r10(self):
        for s in self.stories:
            for el, para in s.wt + s.mt:
                t = el.text or u""
                m = DSL_LEAK.search(t)
                if m:
                    self.err("R10", "DSL leak %r in %s" % (m.group(0), pfx(el.tag)),
                             part=s.name, para=para, xpath=s.xp.get(el), excerpt=t)
            mr_of = {}
            for p in s.paras:
                for kind, z in p.tokens:
                    if kind == "m":
                        for mr in z.iter(M_R):
                            for t in mr.findall(M_T):
                                mr_of[t] = (mr, p.idx)
            for el, para in s.mt:
                t = el.text or u""
                if ANY_HEB_BLOCK.search(t):
                    mr = mr_of.get(el, (None, para))[0]
                    ok = False
                    if mr is not None:
                        mrpr = mr.find(q("m:rPr"))
                        nor = mrpr is not None and on(mrpr.find(q("m:nor")))
                        wrpr = mr.find(W_RPR)
                        rtl = wrpr is not None and on(wrpr.find(q("w:rtl")))
                        ok = bool(nor and rtl)
                    if not ok:
                        self.err("R10", "Hebrew inside OMML without m:nor + w:rtl (Word "
                                 "would italicise and reverse it)", part=s.name,
                                 para=para, xpath=s.xp.get(el), excerpt=t)
                if u"-" in t:
                    self.warn("R10", "ASCII '-' in OMML text (expected U+2212 minus)",
                              part=s.name, para=para, xpath=s.xp.get(el), excerpt=t)

    # ------------------------------------------------------------------ R11
    def r11(self):
        for s in self.stories:
            for p in s.paras:
                fr = p.first_text_run
                if fr is None or fr.tag != W_R:
                    continue
                t = BIDI_MARKS.sub(u"", p.text).lstrip(u" \t★")
                if not NUM_DOT_MARKER.match(t):
                    continue
                chain = s.r_chain(fr, p)
                rtl = on(r_el(chain, q("w:rtl")))
                if rtl is False or (rtl is None and not p.bidi):
                    self.err("R11", "paragraph-initial 'N.' in an rtl=0 run: the period "
                             "flips (the '.1' class); house markers are (N)",
                             **self._where(s, p))
                else:
                    self.err("R11", "paragraph-initial 'N.' marker: house markers are "
                             "(N) (emit_html MARKER_RE), never N.", **self._where(s, p))
        # question markers, bound by bookmark q<n>
        bms = self.bookmarks()
        for name, info in sorted(bms.items()):
            m = re.match(r"^q(\d+)$", name)
            if not m:
                continue
            n = m.group(1)
            want = re.compile(u"^\\s*★?\\s*\\(%s\\)" % n)
            ok = any(want.match(BIDI_MARKS.sub(u"", pt)) for pt in info["para_texts"])
            if not ok:
                self.err("R11", "no paragraph of bookmark %s starts with the marker (%s)"
                         % (name, n), part=info["part"], para=info["first_para"],
                         excerpt=info["para_texts"][0] if info["para_texts"] else u"")

    # ------------------------------------------------------------------ R12
    def r12(self):
        used = Counter()
        attrs = (q("w:ascii"), q("w:hAnsi"), q("w:cs"))

        def take(rpr):
            if rpr is None:
                return
            rf = rpr.find(q("w:rFonts"))
            if rf is None:
                return
            for a in attrs:
                v = rf.get(a)
                if v:
                    used[v] += 1
        take(self.styles.rpr_default)
        styles_used = set()
        for s in self.stories:
            for p in s.paras:
                if p.style:
                    styles_used.add(p.style)
                ppr = p.el.find(W_PPR)
                if ppr is not None:
                    take(ppr.find(W_RPR))
                for kind, el in p.tokens:
                    if kind == "r":
                        rpr = el.find(W_RPR)
                        take(rpr)
                        rs = rpr.find(q("w:rStyle")) if rpr is not None else None
                        if rs is not None:
                            styles_used.add(rs.get(W_VAL))
                    elif kind == "m":
                        for mr in el.iter(M_R):
                            take(mr.find(W_RPR))
        for sid in styles_used:
            for st in self.styles.chain(sid):
                take(st.find(W_RPR))
        embedded = set()
        ft = self.pkg.xml(self._font_table_part())
        if ft is not None:
            for f in ft.findall(q("w:font")):
                if f.find(q("w:embedRegular")) is not None:
                    embedded.add(f.get(W_NAME))
        for font, n in sorted(used.items()):
            if font in self.fonts:
                continue
            if font == "David Libre" and font in embedded:
                continue
            self.warn("R12", "font %r used %d time(s) is not in the allowed set %s%s"
                      % (font, n, sorted(self.fonts),
                         " and is not embedded in fontTable (Word substitutes Times New "
                         "Roman)" if font == "David Libre" else ""),
                      part=self.pkg.main, excerpt=font)

    # ------------------------------------------------------------------ R13
    def r13(self):
        sp = self._settings_part()
        st = self.pkg.xml(sp)
        mode = None
        tfl = None
        if st is not None:
            for cs in st.iter(q("w:compatSetting")):
                if cs.get(W_NAME) == "compatibilityMode":
                    mode = cs.get(W_VAL)
            t = st.find(q("w:themeFontLang"))
            tfl = t.get(q("w:bidi")) if t is not None else None
        if mode != "15":
            self.warn("R13", "compatibilityMode=%s (expected 15; Word opens it in "
                      "Compatibility Mode)" % mode, part=sp)
        if tfl != "he-IL":
            self.warn("R13", "themeFontLang@bidi=%s (expected he-IL)" % tfl, part=sp)
        core = self.pkg.xml("docProps/core.xml")
        if core is not None:
            c = core.find(q("dc:creator"))
            if c is not None and (c.text or "").strip().lower() == "python-docx":
                self.warn("R13", "core.xml creator is 'python-docx' (template leak)",
                          part="docProps/core.xml")
        for n in sorted(self.pkg.names):
            if re.match(r"^docProps/thumbnail\.", n):
                self.warn("R13", "package carries %s (python-docx template thumbnail)" % n,
                          part=n)

    # ------------------------------------------------------------------ R14
    def r14(self):
        ids = Counter()
        tw_emu = self._text_width_emu()
        for s in self.stories:
            rels = self.pkg.rels(s.name)
            for el, xp, para in s.drawings:
                where = dict(part=s.name, para=para, xpath=xp,
                             excerpt=s.paras[para].text if para is not None else None)
                dp = el.find(WP_DOCPR)
                if dp is None:
                    self.err("R14", "drawing without wp:docPr", **where)
                else:
                    did, descr = dp.get("id"), (dp.get("descr") or u"").strip()
                    if not did:
                        self.err("R14", "wp:docPr without id", **where)
                    else:
                        ids[did] += 1
                        if ids[did] == 2:
                            self.err("R14", "wp:docPr id=%s is not unique" % did, **where)
                    if not descr:
                        self.err("R14", "image without alt text (wp:docPr@descr empty)",
                                 **where)
                ext = el.find(WP_EXTENT)
                cx = to_int(ext.get("cx")) if ext is not None else 0
                if cx is None or cx < 0:
                    self.err("R14", "wp:extent cx=%r is not a non-negative integer EMU "
                             "(ECMA-376 ST_PositiveCoordinate); size and dpi not checked"
                             % ext.get("cx"), **where)
                    cx = 0
                if tw_emu and cx > tw_emu * 1.005:
                    self.err("R14", "image extent %.1f mm is wider than the text width "
                             "%.1f mm" % (cx / 36000.0, tw_emu / 36000.0), **where)
                for blip in el.iter(A_BLIP):
                    if blip.get(R_LINK) and not blip.get(R_EMBED):
                        self.err("R14", "linked (external) image %s" % blip.get(R_LINK),
                                 **where)
                        continue
                    rid = blip.get(R_EMBED)
                    raster_ok = False
                    rel = rels.get(rid)
                    if not rid or rel is None or rel[2] == "External":
                        self.err("R14", "a:blip r:embed=%r does not resolve" % rid, **where)
                    else:
                        data = self.pkg.read(rel[1])
                        ct = self.pkg.content_type(rel[1])
                        size = None
                        if data is None:
                            self.err("R14", "image part %s is missing" % rel[1], **where)
                        elif ct not in ("image/png", "image/jpeg"):
                            self.err("R14", "image part %s is %s (PNG or JPEG only)"
                                     % (rel[1], ct), **where)
                        else:
                            size = png_size(data) if ct == "image/png" else jpeg_size(data)
                            if size is None:
                                self.err("R14", "image part %s is not a valid %s"
                                         % (rel[1], ct), **where)
                            else:
                                raster_ok = True
                        if size and cx:
                            dpi = size[0] / (cx / 914400.0)
                            if dpi < 150:
                                self.err("R14", "effective resolution %.0f dpi < 150 "
                                         "(%d px over %.1f mm)" % (dpi, size[0], cx / 36000.0),
                                         **where)
                            elif dpi < 299.5:
                                self.warn("R14", "effective resolution %.0f dpi < 300"
                                          % dpi, **where)
                    for sb in blip.iter(ASVG_BLIP):
                        srel = rels.get(sb.get(R_EMBED))
                        svg = self.pkg.read(srel[1]) if srel else None
                        if svg is None:
                            self.err("R14", "asvg:svgBlip does not resolve", **where)
                        elif ANY_HEB_BLOCK.search(svg.decode("utf-8", "replace")):
                            self.err("R14", "embedded SVG contains Hebrew: Word's SVG "
                                     "renderer reverses it", **where)
                        if not raster_ok:
                            self.err("R14", "asvg:svgBlip without a valid raster fallback",
                                     **where)

    def _text_width_emu(self):
        doc = [s for s in self.stories if s.kind == "document"]
        if not doc or not doc[0].sects:
            return None
        sp = doc[0].sects[-1][0]
        sz, mar = sp.find(q("w:pgSz")), sp.find(q("w:pgMar"))
        try:
            w = int(sz.get(q("w:w")))
            left = int(mar.get(q("w:left")) or 0)
            right = int(mar.get(q("w:right")) or 0)
        except (AttributeError, TypeError, ValueError):
            return None
        return (w - left - right) * 635

    # ------------------------------------------------------------------ R15
    def r15(self):
        def scan(root, part, xp_map):
            agg = {}
            for kind, tag, rank in (("pPr", W_PPR, PPR_RANK), ("rPr", W_RPR, RPR_RANK),
                                    ("tblPr", W_TBLPR, TBLPR_RANK),
                                    ("sectPr", W_SECTPR, SECTPR_RANK)):
                for el in root.iter(tag):
                    last, bad = -1, None
                    for ch in el:
                        r = rank.get(ch.tag)
                        if r is None:
                            continue
                        if r < last:
                            bad = pfx(ch.tag)
                            break
                        last = r
                    if bad:
                        a = agg.setdefault(kind, [0, xp_map.get(el), bad])
                        a[0] += 1
            for kind, (n, xp, bad) in sorted(agg.items()):
                self.warn("R15", "%d w:%s element(s) with children out of ECMA-376 order "
                          "(first: w:%s misplaced; Word tolerates it, strict readers may "
                          "not)" % (n, kind, bad.split(":")[-1]), part=part, xpath=xp,
                          count=n)
        for s in self.stories:
            if s.root is not None:
                scan(s.root, s.name, s.xp)
        if self.styles.root is not None:
            scan(self.styles.root, self._styles_part(), {})

    # ------------------------------------------------------------------ R16
    def bookmarks(self):
        """{name: {part, text, ptext, first_para, para_texts}} over every story.
        `ptext` is `text` plus PAR_SEP at every OMML argument boundary, for
        the token parity of R16."""
        if self._bookmarks is not None:
            return self._bookmarks
        out = {}
        self.bm_duplicates = Counter()
        for s in self.stories:
            # keyed by bookmark ID: two bookmarks that share a NAME are two
            # ranges (Word keeps only one of them), never one merged range
            open_ids, bufs, pbufs, paras, order = {}, {}, {}, {}, []
            for tok in s.stream:
                if tok[0] == "bs":
                    _k, bid, name, para = tok
                    key = (bid, len(order))
                    open_ids[bid] = key
                    bufs[key], pbufs[key], paras[key] = [], [], []
                    order.append((key, name))
                elif tok[0] == "be":
                    open_ids.pop(tok[1], None)
                elif tok[0] == "mb":
                    for key in open_ids.values():
                        pbufs[key].append(PAR_SEP)
                elif tok[0] == "mp":
                    for key in open_ids.values():
                        pbufs[key].append(tok[1])
                else:
                    _k, text, para = tok
                    for key in open_ids.values():
                        bufs[key].append(text)
                        pbufs[key].append(text)
                        if para is not None and (not paras[key] or paras[key][-1] != para):
                            paras[key].append(para)
            for key, name in order:
                if name in out:
                    self.bm_duplicates[name] += 1
                    continue
                pidx = paras[key]
                ptexts = [s.paras[i].text for i in pidx if s.paras[i].text.strip()]
                out[name] = {"part": s.name, "text": u"".join(bufs[key]),
                             "ptext": u"".join(pbufs[key]),
                             "first_para": pidx[0] if pidx else None,
                             "para_texts": ptexts, "paras": pidx, "story": s}
        self._bookmarks = out
        return out

    def r16(self):
        if self.source is None:
            self.rep.skipped["R16"] = "no --source"
            return
        bms = self.bookmarks()
        for name, n in sorted(self.bm_duplicates.items()):
            if re.match(r"^(ans_)?q\d+[a-z]*$", name):
                self.err("R16", "bookmark name %s is used %d more time(s): Word keeps one, "
                         "so the binding to sheet.json is ambiguous" % (name, n),
                         part=self.pkg.main)
        qs = self.source.get("questions") or []
        src_rows = src_segs = 0
        src_q, src_i, src_ans = set(), set(), set()
        ans_of, seg_of = {}, {}         # ans_q<n> -> question, ans_q<n><x> -> item
        for qd in qs:
            qid = qd.get("id") or "q%s" % qd.get("n")
            items = qd.get("items") or []
            src_q.add(qid)
            src_i.update(it.get("id") for it in items if it.get("id"))
            # emit_docx names the row ans_q<n> by the printed number
            ans_name = "ans_q%s" % qd["n"] if qd.get("n") is not None else "ans_" + qid
            if items and any(it.get("answer") not in (None, "") for it in items):
                src_rows += 1
                src_ans.add(ans_name)
                ans_of[ans_name] = qd
                for it in items:
                    if it.get("id") and it.get("answer") not in (None, ""):
                        seg_of["ans_" + it["id"]] = it
            elif qd.get("answer") not in (None, ""):
                src_rows += 1
                src_ans.add(ans_name)
                ans_of[ans_name] = qd
            src_segs += sum(1 for it in items if it.get("answer") not in (None, ""))
            if not items and qd.get("answer") not in (None, ""):
                src_segs += 1
            if qid not in bms:
                self.err("R16", "bookmark %s (question %s) is missing" % (qid, qd.get("n")),
                         part=self.pkg.main, excerpt=qd.get("text"))
            for it in items:
                iid = it.get("id")
                if iid and iid not in bms:
                    self.err("R16", "bookmark %s (item %s of question %s) is missing"
                             % (iid, it.get("label"), qd.get("n")), part=self.pkg.main,
                             excerpt=it.get("text"))
            if qid in bms:
                src = Counter(he_words(u" ".join(_question_strings(qd))))
                got = Counter(he_words(bms[qid]["text"]))
                missing = src - got
                if missing:
                    words = sorted(missing.elements())
                    self.err("R16", "question %s: %d Hebrew word(s) of sheet.json missing "
                             "from bookmark %s: %s" % (qd.get("n"), len(words), qid,
                                                      u" ".join(words[:12])),
                             part=bms[qid]["part"], para=bms[qid]["first_para"],
                             excerpt=bms[qid]["text"])
            if qid in bms:
                self._par_check("question %s" % qd.get("n"), qid,
                                _question_strings(qd) + _labels(items), bms[qid],
                                marker=qd.get("n"))
                # strings whose ORDER carries meaning: the worked example's
                # title and lines, and the table cell by cell
                ex = qd.get("example")
                if isinstance(ex, dict):
                    self._order_check("question %s" % qd.get("n"), qid,
                                      _strings(ex.get("title")) + _strings(ex.get("lines")),
                                      "worked-example lines", bms[qid])
                self._table_check("question %s" % qd.get("n"), qid, qd.get("table"),
                                  bms[qid])
            for it in items:
                iid = it.get("id")
                if iid in bms:
                    src = Counter(he_words(u" ".join(_strings(it.get("text")) +
                                                     _strings(it.get("table")))))
                    missing = src - Counter(he_words(bms[iid]["text"]))
                    if missing:
                        self.warn("R16", "item %s: Hebrew word(s) not inside its own "
                                  "bookmark: %s" % (iid, u" ".join(sorted(missing.elements())[:8])),
                                  part=bms[iid]["part"], para=bms[iid]["first_para"])
                    self._par_check("item %s" % iid, iid,
                                    _strings(it.get("text")) + _strings(it.get("table")) +
                                    _labels([it]), bms[iid])
        # the other direction: a question or item the DOCX prints (bookmarked)
        # that sheet.json does not have -- counts must be EQUAL (docx.md 6.6)
        for name in sorted(bms, key=_bm_sort_key):
            info = bms[name]
            where = dict(part=info["part"], para=info["first_para"],
                         excerpt=info["para_texts"][0] if info["para_texts"] else info["text"])
            if Q_BM.match(name) and name not in src_q:
                self.err("R16", "bookmark %s: the DOCX prints a question that sheet.json "
                         "does not have" % name, **where)
            elif ITEM_BM.match(name) and name not in src_i:
                self.err("R16", "bookmark %s: the DOCX prints an item that sheet.json "
                         "does not have" % name, **where)
        # answers
        rows_bm = [n for n in bms if re.match(r"^ans_q\d+$", n)]
        segs_bm = [n for n in bms if re.match(r"^ans_q\d+[a-z]+$", n)]
        if rows_bm or segs_bm:
            got_rows, how = len(rows_bm), "bookmarks ans_q<n>"
            if segs_bm and len(segs_bm) != src_segs:
                self.err("R16", "answer segments: DOCX has %d ans_q<n><x> bookmark(s), "
                         "sheet.json has %d item answer(s)" % (len(segs_bm), src_segs),
                         part=self.pkg.main)
            if not rows_bm:
                got_rows = None
            else:
                # equal counts can still pair the wrong rows: compare by name
                extra = sorted(set(rows_bm) - src_ans, key=_bm_sort_key)
                lost = sorted(src_ans - set(rows_bm), key=_bm_sort_key)
                why = []
                if extra:
                    why.append("DOCX rows with no sheet.json answer: %s" % ", ".join(extra))
                if lost:
                    why.append("sheet.json answers with no DOCX row: %s" % ", ".join(lost))
                if why:
                    self.err("R16", "answer rows by name: " + "; ".join(why),
                             part=self.pkg.main)
            # what each row prints: every answer bound to its item by the
            # printed label, its numbers, names and signs equal and in order,
            # its Hebrew words contained -- counts alone let a wrong answer
            # through, a multiset lets two items' answers trade places
            for name in sorted(set(rows_bm) & set(ans_of), key=_bm_sort_key):
                self._answer_row_check("answer row %s" % name, name, ans_of[name], bms[name])
            for name in sorted(set(segs_bm) & set(seg_of), key=_bm_sort_key):
                self._answer_check("answer segment %s" % name, name, [seg_of[name]], None,
                                   bms[name])
        else:
            got_rows, how, by_n = self._answer_rows_by_band()
            for name in sorted(ans_of, key=_bm_sort_key):
                n = ans_of[name].get("n")
                if n is not None and str(n) in by_n:
                    self._answer_row_check("answer row (%s)" % n, name, ans_of[name],
                                           by_n[str(n)])
        if got_rows is not None and got_rows != src_rows:
            self.err("R16", "answer rows: DOCX has %d (%s), sheet.json has %d question(s) "
                     "with answers" % (got_rows, how, src_rows), part=self.pkg.main)

    def _par_check(self, label, name, strings, info, marker=None):
        """R16 token parity of one bookmarked range (or band-found answer
        row) against its sheet.json strings: the multiset of numbers, names
        and math signs printed in Word must equal sheet.json's, and each
        string's own sequence must appear in that order (two values swapped
        inside one sentence keep the multiset)."""
        want = par_tokens_of(strings, marker=marker)
        seq = par_seq(par_canon(info["ptext"]))
        got = Counter(seq)
        where = info.get("where") or u"bookmark %s" % name
        excerpt = info["para_texts"][0] if info["para_texts"] else info["text"]
        if got == want:
            for s in strings:
                need = par_seq(par_canon(s))
                if len(need) > 1 and not _par_run_in(seq, need):
                    self.err("R16", u"%s: the numbers/names/signs of sheet.json %r are in "
                             u"Word but not in this order in %s -- sheet.json: %s"
                             % (label, show(s, 60), where, _par_show_seq(need)),
                             part=info["part"], para=info["first_para"], excerpt=excerpt)
                    break
            return
        why = []
        if want - got:
            why.append(u"sheet.json only: %s" % _par_show(want - got))
        if got - want:
            why.append(u"DOCX only: %s" % _par_show(got - want))
        self.err("R16", u"%s: printed numbers/names/signs differ from sheet.json in %s "
                 u"-- %s" % (label, where, u"; ".join(why)),
                 part=info["part"], para=info["first_para"], excerpt=excerpt)

    def _answer_check(self, label, name, rows, marker, info):
        """One answer row/segment against sheet.json: token parity (equal) and
        the answers' Hebrew words (contained). `rows` are the sheet.json
        objects (items, or the question itself) whose `answer` it prints."""
        strings = [s for r in rows for s in _strings(r.get("answer"))]
        self._par_check(label, name, strings + _labels(rows), info, marker=marker)
        missing = Counter(he_words(u" ".join(strings))) - Counter(he_words(info["text"]))
        if missing:
            words = sorted(missing.elements())
            self.err("R16", u"%s: %d Hebrew word(s) of the sheet.json answer missing: %s"
                     % (label, len(words), u" ".join(words[:12])), part=info["part"],
                     para=info["first_para"], excerpt=info["text"])

    def _answer_row_check(self, label, name, qd, info):
        """One answer row (ans_q<n>, or the (n) row after the band) of
        question `qd` against sheet.json.

        With item labels, each answer is bound to its item by the label
        emit_docx prints before it (a Hebrew letter and a period, or `(1)`):
        the row opens with the marker (n) and nothing else that prints a
        token; every item with an answer has its label exactly once; the
        tokens from a label up to the next label EQUAL that item's answer, in
        order, and its Hebrew words are there. Two items' answers that trade
        places, or two labels that do, are errors. A paragraph with no label after the marker is an
        answer note (emit_docx prints `("", text)` segments that way);
        deliver never copies notes into sheet.json, so a note that prints
        tokens is a warning, not a parity error.

        Without labels (a question-level answer) the row must print the
        marker and then the answer, token for token."""
        rows = _answer_items(qd)
        marker = qd.get("n")
        where = info.get("where") or u"bookmark %s" % name
        loc = dict(part=info["part"], para=info["first_para"],
                   excerpt=info["para_texts"][0] if info["para_texts"] else info["text"])
        mseq = par_seq(par_canon(u"(%s)" % marker)) if marker is not None else []
        labeled = [r for r in rows if r is not qd and r.get("label") not in (None, "")]
        if not labeled:
            strings = [s for r in rows for s in _strings(r.get("answer"))]
            want = mseq + _par_cat(strings)
            got = par_seq(par_canon(info["ptext"]))
            if got != want:
                self.err("R16", u"%s: %s prints %s -- sheet.json: the marker and the answer, "
                         u"%s" % (label, where, _par_show_seq(got) or u"no token",
                                  _par_show_seq(want)), **loc)
            missing = Counter(he_words(u" ".join(strings))) - Counter(he_words(info["text"]))
            if missing:
                words = sorted(missing.elements())
                self.err("R16", u"%s: %d Hebrew word(s) of the sheet.json answer missing: %s"
                         % (label, len(words), u" ".join(words[:12])), **loc)
            return
        exp = [(label_text(r["label"]), r) for r in labeled]
        known = sorted(set(t for t, _r in exp), key=len, reverse=True)
        pat = re.compile(u"(?:%s)(?=[\\s%s]|$)" % (
            u"|".join([re.escape(t) for t in known] + [ANS_GENERIC_LABEL]), PAR_SEP))
        head, segs, notes, stray = u"", [], [], []
        for k, piece in enumerate(info["ptext"].split(u"\n")):
            piece = par_canon(piece)
            base = 0
            if k == 0:
                mk = ANS_MARKER_LEAD.match(piece)
                base = mk.end() if mk else 0
            starts = []
            for m in pat.finditer(piece, base):
                before = piece[base:m.start()]
                if not before.strip() or re.search(u"\\s\\s$", before):
                    starts.append((m.start(), m.end(), m.group(0)))
            pre = piece[:starts[0][0]] if starts else piece
            if k == 0:
                head = pre
            elif par_seq(pre):
                (stray if starts else notes).append(pre)
            for j, (s0, e0, lt) in enumerate(starts):
                stop = starts[j + 1][0] if j + 1 < len(starts) else len(piece)
                segs.append((lt, piece[e0:stop]))
        if par_seq(head) != mseq:
            self.err("R16", u"%s: the row should open with the marker (%s) alone; before its "
                     u"first item label %s prints %s" % (label, marker, where,
                                                         _par_show_seq(par_seq(head)) or
                                                         u"no token"), **loc)
        for s in stray:
            self.err("R16", u"%s: %s prints %s in an answer paragraph before its first item "
                     u"label -- bound to no item of sheet.json"
                     % (label, where, _par_show_seq(par_seq(s))), **loc)
        found = [lt for lt, _s in segs]
        want_labels = [lt for lt, _r in exp]
        if Counter(found) != Counter(want_labels):
            self.err("R16", u"%s: item labels printed in %s: %s; sheet.json has answers for "
                     u"%s -- an answer is printed under the wrong item, twice, or not at all"
                     % (label, where, u" ".join(found) or u"none", u" ".join(want_labels)),
                     **loc)
        elif found != want_labels:
            self.warn("R16", u"%s: item labels printed in the order %s, sheet.json order %s"
                      % (label, u" ".join(found), u" ".join(want_labels)), **loc)
        for lt, r in exp:
            if found.count(lt) != 1 or want_labels.count(lt) != 1:
                continue
            seg = [s for f, s in segs if f == lt][0]
            strings = _strings(r.get("answer"))
            want, got = _par_cat(strings), par_seq(seg)
            if got != want:
                self.err("R16", u"%s: item %s prints %s in %s -- sheet.json answer %r: %s"
                         % (label, lt, _par_show_seq(got) or u"no token", where,
                            show(r.get("answer"), 50), _par_show_seq(want) or u"no token"),
                         **loc)
            missing = Counter(he_words(u" ".join(strings))) - Counter(he_words(seg))
            if missing:
                words = sorted(missing.elements())
                self.err("R16", u"%s: item %s: %d Hebrew word(s) of its sheet.json answer "
                         u"missing after its label: %s" % (label, lt, len(words),
                                                            u" ".join(words[:12])), **loc)
        for nt in notes:
            self.warn("R16", u"%s: a paragraph with no item label (an answer note) prints %s; "
                      u"deliver does not copy answer notes into sheet.json, so it is compared "
                      u"with nothing" % (label, _par_show_seq(par_seq(nt))), **loc)

    def _order_check(self, label, name, strings, what, info):
        """Strings whose order is meaning (a worked example's title and lines)
        must print in sheet.json order: each one's token sequence, one after
        the other, never overlapping, inside the bookmark."""
        seq = par_seq(par_canon(info["ptext"]))
        lost = _par_blocks_in_order(seq, [(s, par_seq(par_canon(s))) for s in strings])
        if lost is not None:
            self.err("R16", u"%s: the %s of sheet.json are not all printed in this order in "
                     u"bookmark %s -- changed, or out of order: %r (%s)"
                     % (label, what, name, show(lost[0], 50), _par_show_seq(lost[1])),
                     part=info["part"], para=info["first_para"],
                     excerpt=info["para_texts"][0] if info["para_texts"] else info["text"])

    def _table_check(self, label, name, tb, info):
        """The question's table cell by cell. emit_docx.q_table prints the
        head row then the rows, each padded to the widest row with empty
        cells, in sheet.json order (a bidiVisual table keeps logical order in
        the XML). Some w:tbl inside the bookmark must have that shape and, in
        every cell, the cell's tokens in order and its Hebrew words."""
        if not isinstance(tb, dict):
            return
        rows = ([tb.get("head")] if tb.get("head") else []) + list(tb.get("rows") or [])
        rows = [[_cell_text(c) for c in (r if isinstance(r, list) else [])] for r in rows]
        rows = [r for r in rows if r]
        ncol = max([len(r) for r in rows] or [0])
        if not ncol:
            return
        want = [r + [u""] * (ncol - len(r)) for r in rows]
        s, inside = info.get("story"), set(info.get("paras") or ())
        if s is None:
            return
        pidx = dict((id(p.el), p.idx) for p in s.paras)
        best = None
        for el, _xp, _para, _open in s.tables:
            ps = [pidx.get(id(p)) for p in el.iter(W_P)]
            if not ps or any(i not in inside for i in ps):
                continue
            got = [tr.findall(W_TC) for tr in el.findall(W_TR)]
            if len(got) != len(want) or any(len(r) != ncol for r in got):
                continue
            bad = []
            for ri, (wr, gr) in enumerate(zip(want, got)):
                for ci, (wc, tc) in enumerate(zip(wr, gr)):
                    wt = el_text(tc, sep=True)
                    if par_seq(par_canon(wt)) != par_seq(par_canon(wc)) or \
                            Counter(he_words(wc)) - Counter(he_words(wt)):
                        bad.append(u"row %d cell %d prints %r, sheet.json %r"
                                   % (ri + 1, ci + 1, show(wt.strip(), 24), show(wc, 24)))
            if not bad:
                return
            if best is None or len(bad) < len(best):
                best = bad
        loc = dict(part=info["part"], para=info["first_para"],
                   excerpt=info["para_texts"][0] if info["para_texts"] else info["text"])
        if best is None:
            self.err("R16", u"%s: bookmark %s holds no %d x %d table, the shape of its sheet.json "
                     u"table" % (label, name, len(want), ncol), **loc)
        else:
            self.err("R16", u"%s: the table in bookmark %s differs from sheet.json cell by cell: "
                     u"%s" % (label, name, u"; ".join(best[:4]) +
                             (u"; …" if len(best) > 4 else u"")), **loc)

    def _answer_rows_by_band(self):
        """(row count, how, {n: row info}) of the answer page found by its band,
        for a DOCX without ans_q<n> bookmarks. Each row is bound to its
        question by the printed marker (n)."""
        doc = [s for s in self.stories if s.kind == "document"][0]
        start = None
        for p in doc.paras:
            if not p.in_table and norm_he(p.text).strip().startswith(SEMANTIC_ANS_HEAD):
                start = p.idx
        if start is None:
            return 0, "no answer page (no 'תשובות' band)", {}
        rows, by_n = 0, {}

        def keep(n, els, para):
            if n not in by_n:
                text = u"\n".join(el_text(e) for e in els)
                by_n[n] = {"part": doc.name, "text": text,
                           "ptext": u"\n".join(el_text(e, sep=True) for e in els),
                           "first_para": para, "para_texts": [text],
                           "where": u"the row (%s) after the 'תשובות' band" % n}
        seen_tr = set()
        for el, _xp, para, _bm in doc.tables:
            if para is not None and para < start:
                continue
            for tr in el.findall(W_TR):
                if id(tr) in seen_tr:
                    continue
                seen_tr.add(id(tr))
                tc = tr.find(W_TC)
                if tc is None:
                    continue
                t = BIDI_MARKS.sub(u"", u"".join(x.text or u"" for x in tc.iter(W_T)))
                m = re.match(u"^\\s*★?\\s*\\((\\d+)\\)", t)
                if m:
                    rows += 1
                    keep(m.group(1), [tr], para)
        if not rows:
            # paragraph rows: a row runs from its (n) paragraph to the next one
            prows = []
            for p in doc.paras[start + 1:]:
                if p.in_table:
                    continue
                m = LEAD_QMARK_N.match(BIDI_MARKS.sub(u"", p.text))
                if m:
                    prows.append((m.group(1), [p.el], p.idx))
                elif prows:
                    prows[-1][1].append(p.el)
            rows = len(prows)
            for n, els, para in prows:
                keep(n, els, para)
        return rows, "rows after the 'תשובות' band", by_n

    # ------------------------------------------------------------------ R17
    def r17(self):
        if self.no_terms:
            self.rep.skipped["R17"] = "terms not checked: --no-terms (legacy package, no glossary contract)"
            return
        gp = self.glossary_path
        if not gp:
            here = os.path.dirname(os.path.abspath(__file__))
            gp = os.path.join(here, "glossary_he.json")
        if not os.path.isfile(gp):
            self.rep.skipped["R17"] = "glossary not found: %s" % gp
            self.warn("R17", "R17 SKIPPED: glossary file not found (%s) -- forbidden terms "
                      "were NOT checked" % gp, part=None)
            return
        try:
            with open(gp, "rb") as f:
                g = json.loads(f.read().decode("utf-8"))
        except (IOError, OSError, ValueError) as e:
            self.err("R17", "glossary unreadable (%s): %s" % (gp, e))
            return
        if not isinstance(g, dict):
            self.err("R17", "glossary %s is a JSON %s, not an object: forbidden terms were "
                     "NOT checked" % (gp, type(g).__name__))
            return
        checks, bad = glossary_checks(g, grade=self.grade, scope=self.scope)
        for pat, e in bad:
            self.err("R17", "glossary pattern %r does not compile: %s" % (pat, e))
        if not checks:
            return
        for s in self.stories:
            for p in s.paras:
                self._r17_scan(checks, norm_terms(p.text), dict(
                    part=s.name, para=p.idx, xpath=p.xpath, excerpt=p.text))
            # alt text a screen reader (and Word's Alt Text pane) reads aloud
            for el, xp, para in s.drawings:
                dp = el.find(WP_DOCPR)
                if dp is not None:
                    for a in ("descr", "title", "name"):
                        if dp.get(a):
                            self._r17_scan(checks, norm_terms(dp.get(a)), dict(
                                part=s.name, para=para, xpath=xp + "/@" + a,
                                excerpt=dp.get(a)))
                for nv in el.iter():
                    if isinstance(nv.tag, str) and nv.tag.endswith("}cNvPr"):
                        for a in ("descr", "title"):
                            if nv.get(a):
                                self._r17_scan(checks, norm_terms(nv.get(a)), dict(
                                    part=s.name, para=para,
                                    xpath=s.xp.get(nv, xp) + "/@" + a, excerpt=nv.get(a)))
            for el, xp, para, _bm in s.tables:
                tp = el.find(W_TBLPR)
                for t in (q("w:tblCaption"), q("w:tblDescription")):
                    x = tp.find(t) if tp is not None else None
                    if x is not None and x.get(W_VAL):
                        self._r17_scan(checks, norm_terms(x.get(W_VAL)), dict(
                            part=s.name, para=para, xpath=s.xp.get(x, xp) + "/@w:val",
                            excerpt=x.get(W_VAL)))
        for part in ("docProps/core.xml", "docProps/app.xml"):
            root = self.pkg.xml(part)
            if root is None:
                continue
            for el in root.iter():
                if el.text and el.text.strip():
                    self._r17_scan(checks, norm_terms(el.text), dict(
                        part=part, xpath=pfx(el.tag), excerpt=el.text))

    def _r17_scan(self, checks, text, where):
        seen = []           # spans already reported in this text unit
        for rx, label, sev in checks:
            for m in rx.finditer(text):
                if any(m.start() < e and s < m.end() for s, e in seen):
                    continue    # forbidden_patterns and forbidden_forms overlap
                seen.append((m.start(), m.end()))
                self.rep.add(sev, "R17", "%s: %r" % (label, m.group(0)),
                             part=where.get("part"), para=where.get("para"),
                             xpath=where.get("xpath"), excerpt=where.get("excerpt"))


def glossary_checks(g, grade=None, scope=None, all_scopes=False):
    """[(compiled, label, severity)] from glossary_he.json, per its `matching`:
    forbidden[].pattern for the sheet's grade (all grades when unknown), then
    house_spelling.forbidden_patterns + forbidden_forms -- an ERROR when the
    sheet scope is in applies_to_scope, a WARNING when the scope is unknown,
    nothing for another scope. all_scopes=True compiles everything (tests)."""
    prefixes = g.get("hebrew_prefixes") or u"[ובכלמשה]{0,3}"
    checks, bad = [], []
    for fb in _list(g.get("forbidden")):
        if not isinstance(fb, dict):
            bad.append((repr(fb)[:60], "forbidden entry is not an object"))
            continue
        pat = fb.get("pattern")
        if not pat:
            continue
        if not isinstance(pat, str):
            bad.append((repr(pat)[:60], "pattern is not a string"))
            continue
        sc = fb.get("scope") if isinstance(fb.get("scope"), dict) else {}
        grades = [str(x) for x in _list(sc.get("grades"))]
        if not all_scopes and grades and grade and grade not in grades:
            continue
        try:
            checks.append((compile_term(norm_terms(pat), prefixes),
                           "forbidden term %s (use: %s)" % (
                               fb.get("id") or pat, fb.get("use_instead") or "-"),
                           "error"))
        except re.error as e:
            bad.append((pat, e))
    hs = g.get("house_spelling") if isinstance(g.get("house_spelling"), dict) else {}
    scopes = _list(hs.get("applies_to_scope"))
    if all_scopes or not scope or not scopes or scope in scopes:
        sev = "error" if (all_scopes or scope) else "warn"
        pats = [x for x in _list(hs.get("forbidden_patterns")) if isinstance(x, str)]
        pats += [u"\\s+".join(re.escape(w) for w in norm_terms(f).split())
                 for f in _list(hs.get("forbidden_forms")) if isinstance(f, str)]
        for pat in pats:
            try:
                checks.append((compile_term(norm_terms(pat), prefixes),
                               "house spelling (use %s)%s" % (
                                   hs.get("preferred") or "?",
                                   "" if sev == "error" else
                                   " -- a warning because the sheet scope is unknown "
                                   "(pass --scope or --pkg)"), sev))
            except re.error as e:
                bad.append((pat, e))
    return checks, bad


def _list(x):
    """A JSON value that should be a list: [] when missing or of another type."""
    return x if isinstance(x, list) else []


def glossary_selfcheck(g):
    """Run the glossary's own test vectors through glossary_checks: proves this
    checker reads the glossary exactly as its `matching` section prescribes."""
    fails = []
    prefixes = g.get("hebrew_prefixes") or u"[ובכלמשה]{0,3}"
    allc, bad = glossary_checks(g, all_scopes=True)
    fails += ["pattern %r does not compile: %s" % (p, e) for p, e in bad]
    entries = [(fb.get("id"), fb.get("pattern"), fb.get("tests") or {})
               for fb in g.get("forbidden") or []]
    hs = g.get("house_spelling") or {}
    for t in hs.get("forbidden_patterns") or []:
        entries.append(("house", t, {}))
    for ident, pat, tests in entries:
        try:
            rx = compile_term(norm_terms(pat), prefixes)
        except re.error:
            continue
        for s in tests.get("match") or []:
            if not rx.search(norm_terms(s)):
                fails.append("%s: should match %r" % (ident, s))
        for s in tests.get("no_match") or []:
            if rx.search(norm_terms(s)):
                fails.append("%s: should NOT match %r" % (ident, s))
    ht = hs.get("tests") or {}
    house = [rx for rx, label, _s in allc if label.startswith("house")]
    for s in ht.get("match") or []:
        if not any(rx.search(norm_terms(s)) for rx in house):
            fails.append("house_spelling: should match %r" % s)
    for s in ht.get("no_match") or []:
        if any(rx.search(norm_terms(s)) for rx in house):
            fails.append("house_spelling: should NOT match %r" % s)
    for s in (g.get("tests") or {}).get("must_not_match_any_forbidden") or []:
        hit = [label for rx, label, _s in allc if rx.search(norm_terms(s))]
        if hit:
            fails.append("must_not_match_any_forbidden %r hit %s" % (s, hit[0]))
    return fails


def _bm_sort_key(name):
    """q2 < q10 < q10a < ans_q2: bookmark names in reading order."""
    m = re.match(r"^(\D*?)(\d+)(.*)$", name)
    return (m.group(1), int(m.group(2)), m.group(3)) if m else (name, 0, "")


def _strings(x):
    """The printed strings of a sheet.json value. A bare number (an answer
    written as 3) prints as its text, as emit_docx prints it; booleans are
    flags, not text."""
    if x is None or isinstance(x, bool):
        return []
    if isinstance(x, str):
        return [x]
    if isinstance(x, (int, float)):
        return [u"%s" % (x,)]
    if isinstance(x, dict):
        out = []
        for v in x.values():
            out.extend(_strings(v))
        return out
    if isinstance(x, (list, tuple)):
        out = []
        for v in x:
            out.extend(_strings(v))
        return out
    return []


def _question_strings(qd):
    """The printed strings of one sheet.json question (never given/find/answer)."""
    out = _strings(qd.get("text")) + _strings(qd.get("intro"))
    ex = qd.get("example")
    if isinstance(ex, dict):
        out += _strings(ex.get("title")) + _strings(ex.get("lines"))
    elif ex:
        out += _strings(ex)
    out += _strings(qd.get("table"))
    for it in qd.get("items") or []:
        out += _strings(it.get("text")) + _strings(it.get("table"))
    return out


def _answer_items(qd):
    """The sheet.json objects whose answers emit_docx prints in the row
    ans_q<n>: the items that have an answer, else the question itself."""
    items = [it for it in qd.get("items") or [] if it.get("answer") not in (None, "")]
    return items or [qd]


def label_text(lab):
    """An item label as emit_docx prints it (emit_docx.item_label_text):
    Hebrew letters keep the letter + period form, anything else is the
    mirrored-pair form `(1)`."""
    lab = u"%s" % lab
    return (u"%s." % lab) if HEB_LABEL.match(lab) else (u"(%s)" % lab)


def _labels(objs):
    """Item labels as printed: Hebrew letter + period (no tokens), else
    `(1)` / `(a)`."""
    return [label_text(o["label"]) for o in objs if o.get("label") not in (None, "")]


# ------------------------------------------------------- token parity ----
def _par_brace(s, i):
    """s[i] == '{' -> (inner, index after the matching '}'). Lenient: an
    unbalanced brace takes the rest of the string (a broken DSL leak in the
    Word text is R10's error, not a crash here)."""
    d = 0
    for j in range(i, len(s)):
        if s[j] == "{":
            d += 1
        elif s[j] == "}":
            d -= 1
            if d == 0:
                return s[i + 1:j], j + 1
    return s[i + 1:], len(s)


def _par_script(s, i):
    """s[i] is '^' or '_' -> (script, index after it): {...} or one character."""
    if s[i + 1] == "{":
        return _par_brace(s, i + 1)
    return s[i + 1], i + 2


def _par_expand(s):
    """DSL macros in their printed form (what emit_docx.parse_math/omml put
    into m:t), with PAR_SEP where the OMML has an argument boundary: fraction
    parts, scripts, roots and groups. Applied to sheet.json strings and to the
    Word text alike, so a DSL leak (\\angle{ABC} printed raw) normalizes to
    the same tokens as its intended form (R10 still reports the leak)."""
    out, i, n = [], 0, len(s)
    while i < n:
        c = s[i]
        if c == "\\":
            m = re.match(r"\\([A-Za-z]+)", s[i:])
            if not m:                            # \% \$ \& \# \_ : the character
                out.append(s[i + 1:i + 2])
                i += 2
                continue
            nm, j = m.group(1), i + m.end()
            braced = s[j:j + 1] == "{"
            if nm in ("f", "d", "rat") and braced:
                a, j = _par_brace(s, j)
                b, j = _par_brace(s, j) if s[j:j + 1] == "{" else (u"", j)
                if nm == "rat":
                    out.append(_par_expand(a) + u"∶" + _par_expand(b))
                else:
                    out.append(PAR_SEP + _par_expand(a) + PAR_SEP + _par_expand(b) + PAR_SEP)
            elif nm == "g" and braced:           # m:d: its brackets print
                a, j = _par_brace(s, j)
                out.append(u"(" + PAR_SEP + _par_expand(a) + PAR_SEP + u")")
            elif nm == "sqrt" and braced:
                a, j = _par_brace(s, j)
                out.append(PAR_SEP + _par_expand(a) + PAR_SEP)
            elif nm == "angle" and braced:
                a, j = _par_brace(s, j)
                out.append(u"∡" + _par_expand(a))
            elif nm == "text" and braced:
                a, j = _par_brace(s, j)
                out.append(a)
            elif nm in PAR_BARE:
                out.append(PAR_BARE[nm])
                if nm == "tri":
                    while j < n and s[j] == " ":
                        j += 1
            else:
                out.append(nm)                   # unknown macro: its name stays visible
            i = j
        elif s.startswith("___", i):             # a blank line: no tokens
            out.append(u" ")
            i += 3
        elif c in "^_" and i + 1 < n:            # script: printed apart from its base
            a, j = _par_script(s, i)
            other = u"_" if c == u"^" else u"^"
            if s[j:j + 1] == other and j + 1 < n and not s.startswith("___", j):
                b, j = _par_script(s, j)         # x^2_1 is m:sSubSup: sub, then sup
                a = b + PAR_SEP + a if c == u"^" else a + PAR_SEP + b
            out.append(PAR_SEP + _par_expand(a) + PAR_SEP)
            i = j
        else:
            out.append(c)
            i += 1
    return u"".join(out)


def par_canon(s):
    """One printed text in canonical form for token parity: NFC; no ZWJ, RLM,
    LRM, isolates or soft hyphen; every non-breaking/thin space a space; '$'
    a boundary; DSL macros expanded; the angle sign U+2220 read as U+2221 (the
    printed \\angle); hyphen, non-breaking hyphen and U+2212 one minus."""
    s = unicodedata.normalize("NFC", s or u"")
    s = INVISIBLE.sub(u"", s)
    s = PAR_SPACE.sub(u" ", s).replace(u"$", PAR_SEP)
    if "\\" in s or "^" in s or "_" in s:
        s = _par_expand(s)
    return PAR_MINUS.sub(u"−", s.replace(u"∠", u"∡"))


def par_seq(s):
    """The printed math of one canonical text, in reading (logical) order:
    numbers ('#40'; thousands commas dropped), Latin/Greek names ('@AOC') and
    math signs. Numbers never run across a boundary (10^3 is 10 and 3); names
    ignore boundaries, because emit_docx may split one name over OMML parts."""
    out, i, n = [], 0, len(s)
    while i < n:
        c = s[i]
        if u"0" <= c <= u"9":
            m = PAR_NUM.match(s, i)
            if m:
                out.append(u"#" + m.group(0).replace(u",", u""))
                i = m.end()
                continue
        elif PAR_NAME.match(c):
            j, name = i, []
            while j < n and (s[j] == PAR_SEP or PAR_NAME.match(s[j])):
                if s[j] != PAR_SEP:
                    name.append(s[j])
                j += 1
            out.append(u"@" + u"".join(name))
            i = j
            continue
        elif c in PAR_SIGNS:
            out.append(c)
        i += 1
    return out


def par_tokens(s):
    """Counter of par_seq(s): the multiset R16 compares."""
    return Counter(par_seq(s))


def _par_run_in(hay, needle):
    """True when the token list `needle` occurs contiguously in `hay`."""
    k = len(needle)
    return any(hay[i:i + k] == needle for i in range(len(hay) - k + 1))


def _par_cat(strings):
    """The token sequences of sheet.json strings, one after the other."""
    out = []
    for s in strings:
        out.extend(par_seq(par_canon(s)))
    return out


def _par_blocks_in_order(hay, blocks):
    """blocks: [(string, token list)]. None when every non-empty token list
    occurs contiguously in `hay`, each after the end of the one before
    (leftmost match: if any in-order placement exists, this finds one);
    else the first (string, tokens) that cannot be placed."""
    i = 0
    for s, b in blocks:
        k = len(b)
        if not k:
            continue
        j = i
        while j + k <= len(hay) and hay[j:j + k] != b:
            j += 1
        if j + k > len(hay):
            return s, b
        i = j + k
    return None


def _cell_text(c):
    """A sheet.json table cell as printed text (deliver._cell)."""
    return u"" if c is None else (c if isinstance(c, str) else u"%s" % (c,))


def par_tokens_of(strings, marker=None):
    """Summed tokens of sheet.json strings (+ the printed marker '(n)')."""
    c = Counter()
    if marker is not None:
        c.update(par_tokens(par_canon(u"(%s)" % marker)))
    for s in strings:
        c.update(par_tokens(par_canon(s)))
    return c


def _par_show_seq(seq):
    out = [t[1:] if t[:1] in "#@" else t for t in seq]
    return u" ".join(out[:16]) + (u" …" if len(out) > 16 else u"")


def _par_show(counter):
    out = []
    for tok in sorted(counter.elements(), key=lambda t: (t[:1] not in "#@", t)):
        out.append(tok[1:] if tok[:1] in "#@" else tok)
    return u" ".join(out[:14]) + (u" …" if len(out) > 14 else u"")


# ---------------------------------------------------------------- render ----
def run_render(path, rep):
    """--render: hand the file to docx_render.py (needs Word + PyMuPDF; not -I)."""
    import subprocess
    here = os.path.dirname(os.path.abspath(__file__))
    script = os.path.join(here, "docx_render.py")
    out = tempfile.mkdtemp(prefix="cdr_render_")
    js = os.path.join(out, "render.json")
    env = dict(os.environ)
    env.setdefault("DYLD_FALLBACK_LIBRARY_PATH", "/opt/homebrew/lib")
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    cmd = [sys.executable, script, path, "--assert", "--out", out, "--json", js]
    try:
        cp = subprocess.run(cmd, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            timeout=900)
    except Exception as e:     # never blocks the static gate
        rep.add("warn", "RENDER", "render step failed to run: %s" % e)
        return {"status": "error", "detail": str(e)}
    try:
        with open(js, "rb") as f:
            data = json.loads(f.read().decode("utf-8"))
    except Exception:
        rep.add("warn", "RENDER", "render step produced no report (exit %d): %s"
                % (cp.returncode, cp.stderr.decode("utf-8", "replace")[-400:]))
        return {"status": "error", "exit": cp.returncode}
    for f in data.get("files", []):
        for name, a in (f.get("asserts") or {}).items():
            if a.get("status") == "FAIL":
                rep.add("warn", "RENDER", "render assert %s failed: %s"
                        % (name, "; ".join(str(x) for x in a.get("failures", [])[:5])))
        if f.get("error"):
            rep.add("warn", "RENDER", "Word conversion failed: %s" % f["error"])
    return {"status": "ok", "exit": cp.returncode, "out": out, "report": js}


def check(path, **kw):
    """Library entry point: returns the result dict (raises CannotRead)."""
    return Checker(path, **kw).run()


# ------------------------------------------------------------- selftest ----
_W = ('xmlns:w="%s" xmlns:m="%s" xmlns:r="%s" xmlns:wp="%s" xmlns:a="%s" xmlns:pic="%s" '
      'xmlns:asvg="%s"' % (NS["w"], NS["m"], NS["r"], NS["wp"], NS["a"], NS["pic"],
                           NS["asvg"]))


def _esc(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def _r(text, rtl=True, b=False, sz=24, pair=True, cs=True, lang=True):
    f = 'w:ascii="David" w:hAnsi="David"' + (' w:cs="David"' if cs else "")
    rpr = '<w:rFonts %s/>' % f
    if b:
        rpr += "<w:b/>" + ("<w:bCs/>" if pair else "")
    rpr += '<w:sz w:val="%d"/>' % sz + ('<w:szCs w:val="%d"/>' % sz if pair else "")
    if rtl is not None:          # None: no w:rtl at all (an "unmarked" run)
        rpr += "<w:rtl/>" if rtl else '<w:rtl w:val="0"/>'
    if lang:
        rpr += '<w:lang w:val="he-IL" w:bidi="he-IL"/>'
    return '<w:r><w:rPr>%s</w:rPr><w:t xml:space="preserve">%s</w:t></w:r>' % (rpr, _esc(text))


def _tab_run():
    return ('<w:r><w:rPr><w:rFonts w:ascii="David" w:hAnsi="David" w:cs="David"/>'
            '<w:sz w:val="24"/><w:szCs w:val="24"/><w:rtl/><w:lang w:val="he-IL" '
            'w:bidi="he-IL"/></w:rPr><w:tab/></w:r>')


def _mr(text, nor=False, heb=False, sty="p"):
    mrpr = "<m:rPr><m:nor/></m:rPr>" if nor else '<m:rPr><m:sty m:val="%s"/></m:rPr>' % sty
    if heb:
        wr = ('<w:rPr><w:rFonts w:ascii="David" w:hAnsi="David" w:cs="David"/><w:rtl/>'
              '<w:lang w:val="he-IL" w:bidi="he-IL"/></w:rPr>')
    else:
        wr = ('<w:rPr><w:rFonts w:ascii="Cambria Math" w:hAnsi="Cambria Math"/>'
              '<w:rtl w:val="0"/></w:rPr>')
    return '<m:r>%s%s<m:t xml:space="preserve">%s</m:t></m:r>' % (mrpr, wr, _esc(text))


def _om(inner):
    return "<m:oMath>%s</m:oMath>" % inner


def _p(inner, bidi=True, jc=None, keep=False, pbb=False, after=120):
    ppr = ("<w:keepNext/>" if keep else "") + ("<w:pageBreakBefore/>" if pbb else "")
    ppr += "<w:bidi/>" if bidi else ""
    ppr += '<w:spacing w:before="0" w:after="%d"/>' % after
    ppr += '<w:jc w:val="%s"/>' % jc if jc else ""
    return "<w:p><w:pPr>%s</w:pPr>%s</w:p>" % (ppr, inner)


def _bs(i, name):
    return '<w:bookmarkStart w:id="%d" w:name="%s"/>' % (i, name)


def _be(i):
    return '<w:bookmarkEnd w:id="%d"/>' % i


def _tbl(rows, bidi_visual="1", style=None, caption=None, widths=None):
    ncol = max(len(r) for r in rows)
    widths = widths or [int(9000 / ncol)] * ncol
    tp = '<w:tblStyle w:val="%s"/>' % style if style else ""
    if bidi_visual == "1":
        tp += "<w:bidiVisual/>"
    elif bidi_visual == "0":
        tp += '<w:bidiVisual w:val="0"/>'
    tp += '<w:tblW w:w="%d" w:type="dxa"/>' % sum(widths)
    tp += ('<w:tblBorders>' + "".join(
        '<w:%s w:val="single" w:sz="4" w:space="0" w:color="000000"/>' % s
        for s in ("top", "left", "bottom", "right", "insideH", "insideV")) + '</w:tblBorders>')
    tp += '<w:tblLayout w:type="fixed"/>'
    if caption:
        tp += '<w:tblCaption w:val="%s"/>' % caption
    grid = "".join('<w:gridCol w:w="%d"/>' % w for w in widths)
    trs = ""
    for row in rows:
        tcs = ""
        for i, cell in enumerate(row):
            tcs += ('<w:tc><w:tcPr><w:tcW w:w="%d" w:type="dxa"/></w:tcPr>%s</w:tc>'
                    % (widths[i], cell))
        trs += "<w:tr><w:trPr><w:cantSplit/></w:trPr>%s</w:tr>" % tcs
    return "<w:tbl><w:tblPr>%s</w:tblPr><w:tblGrid>%s</w:tblGrid>%s</w:tbl>" % (tp, grid, trs)


def _img(rid, cx, cy, did, descr, pic_descr=None):
    d = ' descr="%s"' % _esc(descr) if descr is not None else ""
    pd = ' descr="%s"' % _esc(pic_descr) if pic_descr is not None else ""
    return ('<w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0">'
            '<wp:extent cx="%d" cy="%d"/><wp:docPr id="%d" name="fig%d"%s/>'
            '<a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">'
            '<pic:pic><pic:nvPicPr><pic:cNvPr id="%d" name="fig%d.png"%s/><pic:cNvPicPr/></pic:nvPicPr>'
            '<pic:blipFill><a:blip r:embed="%s"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>'
            '<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="%d" cy="%d"/></a:xfrm>'
            '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic>'
            '</a:graphicData></a:graphic></wp:inline></w:drawing></w:r>'
            % (cx, cy, did, did, d, did, did, pd, rid, cx, cy))


def _png(w, h):
    """A grey-frame PNG written with zlib only (no PIL under -I)."""
    rows = []
    for y in range(h):
        if y < 6 or y >= h - 6:
            rows.append(b"\x00" + b"\x40" * w)
        else:
            rows.append(b"\x00" + b"\x40" * 6 + b"\xf0" * (w - 12) + b"\x40" * 6)
    raw = b"".join(rows)

    def chunk(t, d):
        c = struct.pack(">I", len(d)) + t + d
        return c + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 0, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b""))


SYN_SHEET = {
    "package": "G7-T99", "level": "a", "grade": u"כיתה ז׳", "title": u"זוויות צמודות",
    "questions": [
        {"id": "q1", "n": 1, "text": u"נתונה הזווית $\\angle{ABC}$ שגודלה $40°$.",
         "items": [
             {"id": "q1a", "label": u"א", "text": u"חשבו את הזווית הצמודה לה.",
              "answer": u"$140°$"},
             {"id": "q1b", "label": u"ב", "text": u"כתבו תרגיל מתאים: $180°−40°=140°$",
              "answer": u"$140°$"}]},
        {"id": "q2", "n": 2, "text": u"השלימו את הטבלה.",
         "table": {"head": [u"שעה", u"1", u"2"], "rows": [[u"זווית", u"10°", u"20°"]]},
         "items": [{"id": "q2a", "label": u"א", "text": u"מה הגודל בשעה 3?",
                    "answer": u"$30°$"}]}]}

SYN_GLOSSARY = {
    "schema": "noam-glossary/v1", "hebrew_prefixes": u"[ובכלמשה]{0,3}",
    "terms": {},
    "forbidden": [{"id": "nishlamot", "pattern": u"נשלמות", "scope": {"grades": ["7", "8", "9"]},
                   "reason": u"מונח לא בשימוש", "use_instead": u"משלימות זו את זו"}],
    "house_spelling": {"preferred": u"סרטוט", "forbidden_forms": [u"שרטוט", u"שרטטו", u"משורטט"],
                       "applies_to_scope": ["sectioned"]},
    "symbols": {"minus": "U+2212", "degree": u"°"}}


def synthetic_docx(**o):
    """A minimal, schema-ordered worksheet docx that passes every rule; each
    keyword switches on ONE defect so the selftest can prove each rule fires."""
    q1 = o.get("q1_text_runs") or (
        _r(u"נתונה הזווית ") + _om(_mr(u"∡") + _mr(u"ABC")) + _r(u" שגודלה ") +
        _om(_mr(u"40°")) + _r(u"."))
    marker = o.get("marker", _r(u"(1)") + _tab_run())
    if o.get("ltr_marker"):
        marker = _r(u"1. ", rtl=False)
    title_jc = "right" if o.get("jc_right") else "center"
    title = _p(_r(u"זוויות צמודות", b=True, sz=38, pair=not o.get("cs_missing")),
               jc=title_jc)
    item_a_text = o.get("item_a_text", u"חשבו את הזווית הצמודה לה.")
    item_a = _p(_r(u"א. ") + _r(item_a_text))
    if o.get("rtl_leak"):
        item_a = _p(_r(u"א. ") + _r(u"חשבו את −5 + 3 ואת הזווית הצמודה לה."))
    item_b_math = (_mr(o.get("item_b_first", u"180°")) + _mr(u"−") + _mr(u"40°") + _mr(u"=") +
                   _mr(o.get("item_b_result", u"140°")))
    if o.get("ascii_minus"):
        item_b_math = _mr(u"180°-40°=140°")
    if o.get("heb_in_math"):
        item_b_math = item_b_math + _mr(u"מעלות")
    if o.get("omath_adjacent"):
        item_b = _p(_r(u"ב. ") + _r(u"כתבו תרגיל מתאים: ") + _om(_mr(u"180°")) +
                    _r(u" − ", rtl=False) + _om(_mr(u"40°=140°")))
    else:
        item_b = _p(_r(u"ב. ") + _r(u"כתבו תרגיל מתאים: ") + _om(item_b_math))
    if o.get("dollar_leak"):
        item_b = _p(_r(u"ב. ") + _r(u"כתבו תרגיל מתאים: $180°−40°=140°$"))
    q1_block = (_bs(1, "q1") + _p(marker + q1, keep=True) +
                ("" if o.get("drop_q1b") else _bs(2, "q1a")) + item_a +
                ("" if o.get("drop_q1b") else _be(2)) +
                ("" if o.get("drop_q1b") else _bs(3, "q1b")) + item_b +
                ("" if o.get("drop_q1b") else _be(3)) + _be(1))
    if o.get("drop_q1b"):
        q1_block = (_bs(1, "q1") + _p(marker + q1, keep=True) + _bs(2, "q1a") + item_a +
                    _be(2) + item_b + _be(1))
    cell_bidi = not o.get("cell_no_bidi")
    tbl_rows = [[_p(_r(u"שעה", b=True), bidi=cell_bidi, jc="center", after=0),
                 _p(_r(u"1", rtl=False), jc="center", after=0),
                 _p(_r(u"2", rtl=False), jc="center", after=0)],
                [_p(_r(u"זווית"), jc="center", after=0),
                 _p(_om(_mr(u"10°")), jc="center", after=0),
                 _p(_om(_mr(u"20°")), jc="center", after=0)]]
    tv = o.get("table_bidi", "1")
    table = _tbl(tbl_rows, bidi_visual=None if tv in ("none", "style") else tv,
                 style="RtlGrid" if tv == "style" else None, caption=o.get("table_caption"))
    figure = _p(_img(o.get("img_rid", "rIdImg1"), o.get("img_cx", 3600000),
                     o.get("img_cy", 1219200), 1, o.get("img_descr", u"סרטוט לשאלה 2"),
                     pic_descr=o.get("pic_descr")), jc="center")
    if o.get("img_cx_text"):
        figure = figure.replace('cx="%d"' % o.get("img_cx", 3600000),
                                'cx="%s"' % o["img_cx_text"], 1)
    if o.get("dup_docpr"):
        figure += _p(_img("rIdImg1", 3600000, 1219200, 1, u"סרטוט נוסף"), jc="center")
    q2_block = (_bs(4, "q2") + _p(_r(u"(2)") + _tab_run() + _r(u"השלימו את הטבלה."),
                                  keep=True) +
                table + figure + _bs(5, "q2a") +
                _p(_r(u"א. ") + _r(u"מה הגודל בשעה 3?")) + _be(5) + _be(4))
    extra = o.get("extra_paras", "")
    ans_rows = [[_p(_bs(6, "ans_q1") + _r(u"(1)"), after=0),
                 _p(_r(u"א. ") + _om(_mr(u"140°")) + _r(u"  ב. ") +
                    _om(_mr(o.get("ans_q1_b", u"140°"))) + _be(6), after=0)]]
    if not o.get("drop_answer_row"):
        ans_rows.append([_p(_bs(7, o.get("ans2_name", "ans_q2")) + _r(u"(2)"), after=0),
                         _p(_r(u"א. ") + _om(_mr(u"30°")) + _be(7), after=0)])
    if o.get("ans_no_bookmarks"):        # answer page found by its band only
        ans_rows = [[re.sub(u"<w:bookmark(?:Start|End) [^>]*/>", u"", c) for c in r]
                    for r in ans_rows]
    answers = (_p(_r(u"תשובות סופיות", b=True, sz=26), pbb=True, keep=True) +
               _tbl(ans_rows, widths=[1000, 8000]))
    body = title + q1_block + q2_block + extra + answers
    if "replace_body" in o:          # same package shell, caller's body only
        body = o["replace_body"]
    sect_bidi = "" if o.get("sect_no_bidi") else "<w:bidi/>"
    document = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                '<w:document %s><w:body>%s<w:sectPr><w:headerReference w:type="default" '
                'r:id="rIdH1"/><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="907" '
                'w:right="850" w:bottom="794" w:left="850" w:header="397" w:footer="397" '
                'w:gutter="0"/>%s<w:docGrid w:linePitch="360"/></w:sectPr></w:body></w:document>'
                % (_W, body, sect_bidi))
    header = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:hdr %s>%s</w:hdr>'
              % (_W, _p(_r(u"בס״ד", sz=18), after=0)))
    rpr_default_rtl = "<w:rtl/>" if o.get("rpr_default_rtl") else ""
    styles = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles %s>'
              '<w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="David" w:hAnsi="David" '
              'w:cs="David"/><w:sz w:val="24"/><w:szCs w:val="24"/>%s<w:lang w:val="he-IL" '
              'w:bidi="he-IL"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:bidi/></w:pPr>'
              '</w:pPrDefault></w:docDefaults>'
              '<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/>'
              '<w:pPr><w:bidi/></w:pPr></w:style>'
              '<w:style w:type="table" w:default="1" w:styleId="TableNormal"><w:name w:val="Normal Table"/>'
              '</w:style>'
              '<w:style w:type="table" w:styleId="RtlGrid"><w:name w:val="RtlGrid"/>'
              '<w:basedOn w:val="TableNormal"/><w:tblPr><w:bidiVisual/></w:tblPr></w:style>'
              '</w:styles>' % (_W, rpr_default_rtl))
    settings = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:settings %s>'
                '<w:themeFontLang w:val="he-IL" w:bidi="he-IL"/><w:compat><w:compatSetting '
                'w:name="compatibilityMode" w:uri="http://schemas.microsoft.com/office/word" '
                'w:val="15"/></w:compat></w:settings>' % _W)
    creator = "python-docx" if o.get("python_docx_creator") else u"מתמטיקה · נועם דורון"
    core = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties '
            'xmlns:cp="%s" xmlns:dc="%s"><dc:title>%s</dc:title><dc:creator>%s</dc:creator>'
            '</cp:coreProperties>' % (NS["cp"], NS["dc"], u"זוויות צמודות", _esc(creator)))
    ctypes = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="%s">'
              '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
              '<Default Extension="xml" ContentType="application/xml"/>'
              '<Default Extension="png" ContentType="image/png"/>'
              '<Default Extension="jpeg" ContentType="image/jpeg"/>'
              '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
              '<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>'
              '<Override PartName="/word/settings.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml"/>'
              '<Override PartName="/word/header1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml"/>'
              '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'
              '</Types>' % NS["ct"])
    rels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="%s">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
            '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>'
            '</Relationships>' % NS["pr"])
    docrels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="%s">'
               '<Relationship Id="rIdS" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
               '<Relationship Id="rIdSet" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings" Target="settings.xml"/>'
               '<Relationship Id="rIdH1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/header" Target="header1.xml"/>'
               '<Relationship Id="rIdImg1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/image1.png"/>'
               '</Relationships>' % NS["pr"])
    bio = io.BytesIO()
    with zipfile.ZipFile(bio, "w", zipfile.ZIP_DEFLATED) as z:
        for name, data in (("[Content_Types].xml", ctypes), ("_rels/.rels", rels),
                           ("word/document.xml", document), ("word/styles.xml", styles),
                           ("word/settings.xml", settings), ("word/header1.xml", header),
                           ("word/_rels/document.xml.rels", docrels),
                           ("docProps/core.xml", core)):
            z.writestr(name, data.encode("utf-8"))
        z.writestr("word/media/image1.png", _png(o.get("img_px", 1181), 400))
        if o.get("thumbnail"):
            z.writestr("docProps/thumbnail.jpeg", b"\xff\xd8\xff\xd9")
    return bio.getvalue()


SYN_CASES = [
    # (name, options, checker kwargs, expected error ids (exact), warning ids that must appear)
    ("baseline", {}, {}, set(), set()),
    ("R1-sect-no-bidi", {"sect_no_bidi": True}, {}, {"R1"}, set()),
    ("R2-rprdefault-rtl", {"rpr_default_rtl": True}, {}, {"R2"}, set()),
    ("R3-cell-para-no-bidi", {"cell_no_bidi": True}, {}, {"R3"}, set()),
    ("R4-jc-right", {"jc_right": True}, {}, {"R4"}, set()),
    ("R5-no-bidivisual", {"table_bidi": "none"}, {}, {"R5"}, set()),
    ("R5-style-only", {"table_bidi": "style"}, {}, {"R5"}, set()),
    ("R5-ltr-unlisted", {"table_bidi": "0"}, {}, {"R5"}, set()),
    ("R5-ltr-listed", {"table_bidi": "0"}, {"ltr_tables": ["q2:t1"]}, set(), set()),
    ("R5-ltr-ir-flag", {"table_bidi": "0", "table_caption": "ltr"}, {}, set(), set()),
    ("R6-no-cs-pairs", {"cs_missing": True}, {}, {"R6"}, set()),
    ("R7-rtl-leak", {"rtl_leak": True}, {}, {"R7"}, set()),
    ("R9-omath-adjacent", {"omath_adjacent": True}, {}, {"R9"}, {"R8"}),
    ("R9-rtl-neutral-sep", {"extra_paras": _p(_r(u"נתון ") + _om(_mr(u"36°")) + _r(u", ") +
                                              _om(_mr(u"62°")) + _r(u" כאן."))},
     {}, {"R9"}, set()),
    ("R9-rtl-neutral-word-only", {"extra_paras": _p(_r(u"נתון ") + _om(_mr(u"36°")) +
                                                    _r(u", ") + _om(_mr(u"62°")) +
                                                    _r(u" כאן."))},
     {"r9_word_only": True}, set(), {"R9"}),
    ("R9-rlm-sep-ok", {"extra_paras": _p(_r(u"נתון ") + _om(_mr(u"36°")) +
                                         _r(u"‏, ") + _om(_mr(u"62°")) + _r(u" כאן."))},
     {}, set(), set()),
    # an unmarked separator (no w:rtl anywhere) is LTR to Word even in a bidi
    # paragraph (measured, zoom_r9_unmarked.png): an ERROR in both modes
    ("R9-sep-unmarked", {"extra_paras": _p(_r(u"נתון ") + _om(_mr(u"36°")) +
                                           _r(u", ", rtl=None) + _om(_mr(u"62°")) +
                                           _r(u" כאן."))},
     {}, {"R9"}, set()),
    ("R9-sep-unmarked-word-only", {"extra_paras": _p(_r(u"נתון ") + _om(_mr(u"36°")) +
                                                     _r(u", ", rtl=None) +
                                                     _om(_mr(u"62°")) + _r(u" כאן."))},
     {"r9_word_only": True}, {"R9"}, set()),
    ("R9-sep-ltr-word-only", {"extra_paras": _p(_r(u"נתון ") + _om(_mr(u"36°")) +
                                                _r(u", ", rtl=False) + _om(_mr(u"62°")) +
                                                _r(u" כאן."))},
     {"r9_word_only": True}, {"R9"}, {"R8"}),
    ("R10-dollar-leak", {"dollar_leak": True}, {}, {"R10", "R7"}, set()),
    ("R10-hebrew-in-math", {"heb_in_math": True}, {}, {"R10"}, set()),
    ("R10-ascii-minus", {"ascii_minus": True}, {}, set(), {"R10"}),
    ("R11-ltr-N-dot", {"ltr_marker": True}, {}, {"R11"}, {"R8"}),
    ("R11-wrong-marker", {"marker": _r(u"1. ")}, {}, {"R11"}, set()),
    ("R13-package", {"python_docx_creator": True, "thumbnail": True}, {}, set(), {"R13"}),
    ("R14-no-alt", {"img_descr": None}, {}, {"R14"}, set()),
    ("R14-low-dpi", {"img_px": 300}, {}, {"R14"}, set()),
    ("R14-mid-dpi", {"img_px": 800}, {}, set(), {"R14"}),
    ("R14-bad-rid", {"img_rid": "rIdNope"}, {}, {"R14"}, set()),
    ("R14-dup-id", {"dup_docpr": True}, {}, {"R14"}, set()),
    ("R14-too-wide", {"img_cx": 7200000, "img_px": 2400}, {}, {"R14"}, set()),
    ("R14-bad-extent", {"img_cx_text": "3.6e6"}, {}, {"R14"}, set()),
    ("R16-missing-bookmark", {"drop_q1b": True}, {"source": "SHEET"}, {"R16"}, set()),
    ("R16-missing-word", {"item_a_text": u"חשבו את הזווית."}, {"source": "SHEET"},
     {"R16"}, {"R16"}),
    ("R16-answer-count", {"drop_answer_row": True}, {"source": "SHEET"}, {"R16"}, set()),
    ("R16-duplicate-name", {"extra_paras": _bs(90, "q1") + _p(_r(u"שוב")) + _be(90)},
     {"source": "SHEET"}, {"R16"}, set()),
    ("R16-extra-question", {"extra_paras": _bs(91, "q3") + _p(_r(u"(3)") + _tab_run() +
                                                            _r(u"שאלה נוספת")) + _be(91)},
     {"source": "SHEET"}, {"R16"}, set()),
    ("R16-extra-item", {"extra_paras": _bs(92, "q2b") + _p(_r(u"ב. ") + _r(u"סעיף נוסף")) +
                        _be(92)}, {"source": "SHEET"}, {"R16"}, set()),
    ("R16-answer-row-renamed", {"ans2_name": "ans_q3"}, {"source": "SHEET"}, {"R16"}, set()),
    ("R16-baseline-source", {}, {"source": "SHEET", "glossary": "GLOSS",
                                 "scope": "sectioned"}, set(), set()),
    # G91 token parity: a changed number / name / answer keeps every Hebrew
    # word, so only the numbers-names-signs comparison can catch it
    ("R16-number-changed", {"q1_text_runs": _r(u"נתונה הזווית ") + _om(_mr(u"∡") + _mr(u"ABC")) +
                            _r(u" שגודלה ") + _om(_mr(u"41°")) + _r(u".")},
     {"source": "SHEET"}, {"R16"}, set()),
    ("R16-name-changed", {"q1_text_runs": _r(u"נתונה הזווית ") + _om(_mr(u"∡") + _mr(u"ABD")) +
                          _r(u" שגודלה ") + _om(_mr(u"40°")) + _r(u".")},
     {"source": "SHEET"}, {"R16"}, set()),
    ("R16-item-number-changed", {"item_b_result": u"150°"}, {"source": "SHEET"}, {"R16"}, set()),
    ("R16-answer-number-changed", {"ans_q1_b": u"150°"}, {"source": "SHEET"}, {"R16"}, set()),
    # same multiset, values swapped inside one sentence: 140°−40°=180°
    ("R16-values-swapped", {"item_b_first": u"140°", "item_b_result": u"180°"},
     {"source": "SHEET"}, {"R16"}, set()),
    ("R16-minus-normalized", {"ascii_minus": True}, {"source": "SHEET"}, set(), {"R10"}),
    ("R16-band-answers", {"ans_no_bookmarks": True}, {"source": "SHEET"}, set(), set()),
    ("R16-band-answer-changed", {"ans_no_bookmarks": True, "ans_q1_b": u"150°"},
     {"source": "SHEET"}, {"R16"}, set()),
    ("R17-forbidden", {"extra_paras": _p(_r(u"הזוויות הנשלמות שוות."))},
     {"glossary": "GLOSS"}, {"R17"}, set()),
    ("R17-forbidden-split-runs", {"extra_paras": _p(_r(u"הזוויות הנשל") + _r(u"מות שוות."))},
     {"glossary": "GLOSS"}, {"R17"}, set()),
    ("R17-forbidden-niqqud", {"extra_paras": _p(_r(u"זוויות נִשְׁלָמוֹת"))},
     {"glossary": "GLOSS"}, {"R17"}, set()),
    ("R17-table-caption", {"table_caption": u"טבלת זוויות נשלמות"}, {"glossary": "GLOSS"},
     {"R17"}, set()),
    ("R17-pic-alt-text", {"pic_descr": u"שתי זוויות נשלמות"}, {"glossary": "GLOSS"},
     {"R17"}, set()),
    ("R17-official-verb-ok", {"extra_paras": _p(_r(u"הזוויות משלימות זו את זו לזווית שטוחה."))},
     {"glossary": "GLOSS"}, set(), set()),
    ("R17-house-sectioned", {"extra_paras": _p(_r(u"התבוננו בשרטוט."))},
     {"glossary": "GLOSS", "scope": "sectioned"}, {"R17"}, set()),
    ("R17-house-no-scope", {"extra_paras": _p(_r(u"התבוננו בשרטוט."))},
     {"glossary": "GLOSS"}, set(), {"R17"}),
    ("R17-house-broad", {"extra_paras": _p(_r(u"התבוננו בשרטוט."))},
     {"glossary": "GLOSS", "scope": "broad"}, set(), set()),
    ("R17-glossary-missing", {}, {"glossary": "MISSING"}, set(), {"R17"}),
    ("R17-no-terms", {"extra_paras": _p(_r(u"הזוויות הנשלמות שוות. התבוננו בשרטוט."))},
     {"glossary": "GLOSS", "scope": "sectioned", "no_terms": True}, set(), set()),
]

# an R16 error of these cases must come from the token parity, named so
SYN_NEEDLES = {
    "R16-number-changed": u"sheet.json only: 40; DOCX only: 41",
    "R16-name-changed": u"sheet.json only: ABC; DOCX only: ABD",
    "R16-item-number-changed": u"bookmark q1b -- sheet.json only: 140; DOCX only: 150",
    "R16-answer-number-changed": u"answer row ans_q1: item ב. prints 150 ° in bookmark ans_q1",
    "R16-band-answer-changed": u"answer row (1): item ב. prints 150 °",
    "R16-values-swapped": u"but not in this order in bookmark q1b -- sheet.json: : 180 ° − 40 ° = 140 °",
}

# (name, sheet.json DSL, Word text as bookmarks() reads it, same tokens in the
# same order?)
PAR_VECTORS = [
    ("angle-macro", u"$\\angle{ABC}=40°$", u"∡ABC=40°", True),
    ("angle-u2220", u"∠ABC = 40°", u"∡ABC=40°", True),
    ("angle-leaked-dsl", u"$\\angle{ABC}$", u"\\angle{ABC}", True),
    ("minus-hyphen", u"$180°-40°$", u"180°\u221240°", True),
    ("minus-nobreak-hyphen", u"$-5$", u"\u20115", True),
    ("nbsp-zwj-rlm-lrm", u"ו־$OD$, $65°$", u"ו־\u200dOD\u200f,\u00a0\u200e65°", True),
    ("thousands", u"$1,000$ ו־$12,500$", u"1000 ו־12500", True),
    ("deg-macro", u"$40\\deg$", u"40°", True),
    ("cdot-macro", u"$2\\cdot 3$", u"2·3", True),
    ("text-macro", u"$5\\text{ ס״מ}$", u"5 ס״מ", True),
    ("script-apart", u"$10^3$", u"10" + PAR_SEP + u"3", True),
    ("fraction-apart", u"$\\f{1}{2}$", PAR_SEP + u"1" + PAR_SEP + PAR_SEP + u"2" + PAR_SEP, True),
    ("name-over-omml-parts", u"$AB$", u"A" + PAR_SEP + u"B", True),
    ("decimal", u"$3.5$", u"3.5", True),
    ("subsup-order", u"$x^2_1$", u"x" + PAR_SEP + u"1" + PAR_SEP + u"2", True),
    ("values-swapped", u"$\\angle{AOC}=40°$, $\\angle{BOD}=65°$", u"∡AOC=65°, ∡BOD=40°", False),
    ("number-changed", u"$\\angle{AOC}=40°$", u"∡AOC=41°", False),
    ("name-changed", u"$\\angle{AOC}$", u"∡AOD", False),
    ("sign-changed", u"$5-3$", u"5+3", False),
    ("minus-lost", u"$-5$", u"5", False),
    ("degree-lost", u"$40°$", u"40", False),
    ("script-glued", u"$10^3$", u"103", False),
    ("decimal-changed", u"$3.5$", u"3.6", False),
    ("number-added", u"$40°$", u"40°, 5°", False),
    # brackets, the ':' division sign and primes are printed mathematics
    ("paren-literal", u"$(−3)^2$", u"(−3" + PAR_SEP + u")" + PAR_SEP + PAR_SEP + u"2" + PAR_SEP,
     True),
    ("paren-g-macro", u"$\\g{-3}^2$", PAR_SEP + u"(" + PAR_SEP + u"−3" + PAR_SEP + u")" +
     PAR_SEP + PAR_SEP + u"2" + PAR_SEP, True),
    ("paren-lost", u"$(−3)^2$", u"−3" + PAR_SEP + u"2", False),
    ("colon-division", u"$12:4=3$", u"12:4=3", True),
    ("colon-lost", u"$12:4=3$", u"12 4=3", False),
    ("ratio-not-colon", u"$\\rat{2}{3}$", u"2:3", False),
    ("prime-kept", u"$A′B′=5$", u"A′B′=5", True),
    ("prime-lost", u"$A′B′$", u"A′B", False),
]


# A question with a worked example, a table, three items and one answer row,
# laid out the way emit_docx prints them (label + NBSP + answer, segments
# three spaces apart; (−3)^2 as m:t "(−3" + sSup(")", 2); \g{} as m:d).
BIND_SHEET = {"questions": [{
    "id": "q1", "n": 1, "text": u"חשבו $(−3)^2$ ואת $12:4$ ואת $\\g{-2}^2$.",
    "example": {"title": u"דוגמה", "lines": [u"$180°−47°=133°$", u"$180°−40°=140°$"]},
    "table": {"head": [u"מצב", u"1", u"2"], "rows": [[u"$\\angle{AOC}$", u"$35°$", u"$100°$"]]},
    "items": [
        {"id": "q1a", "label": u"א", "text": u"מצאו את הזווית.", "answer": u"$51°$"},
        {"id": "q1b", "label": u"ב", "text": u"מצאו את הזווית.", "answer": u"$129°$"},
        {"id": "q1c", "label": u"ג", "text": u"חשבו.", "answer": u"$(−3)^2=9$, $12:4=3$"}]}]}


def _bind_sup(base, sup):
    return u"<m:sSup><m:e>%s</m:e><m:sup>%s</m:sup></m:sSup>" % (base, _mr(sup))


def _bind_delim(inner, beg=u"(", end=u")"):
    return (u'<m:d><m:dPr><m:begChr m:val="%s"/><m:endChr m:val="%s"/></m:dPr><m:e>%s</m:e>'
            u'</m:d>' % (beg, end, _mr(inner)))


def bind_docx(**o):
    """The BIND_SHEET question as a docx; each keyword changes one thing."""
    sq = _mr(u"(−3") + _bind_sup(_mr(u")"), u"2")
    if o.get("q_paren_lost"):
        sq = _mr(u"−3") + _bind_sup(u"", u"2")
    beg, end = o.get("delim", (u"(", u")"))
    qtext = (_r(u"(1)") + _tab_run() + _r(u"חשבו ") + _om(sq) + _r(u" ואת ") +
             _om(_mr(o.get("q_div", u"12:4"))) + _r(u" ואת ") +
             _om(_bind_sup(_bind_delim(u"−2", beg, end), u"2")) + _r(u"."))
    lines = [u"180°−47°=133°", u"180°−40°=140°"]
    if o.get("example_swap"):
        lines.reverse()
    example = _p(_r(u"דוגמה", b=True)) + u"".join(_p(_om(_mr(x))) for x in lines)
    head = o.get("table_head", [u"1", u"2"])
    vals = o.get("table_vals", [u"35°", u"100°"])
    rows = [[_p(_r(u"מצב", b=True), after=0)] + [_p(_r(h, rtl=False), after=0) for h in head],
            [_p(_om(_mr(u"∡") + _mr(u"AOC")), after=0)] + [_p(_om(_mr(v)), after=0)
                                                          for v in vals]]
    if o.get("table_col_dropped"):
        rows = [r[:-1] for r in rows]
    items = u""
    for i, (lab, txt) in enumerate(((u"א", u"מצאו את הזווית."), (u"ב", u"מצאו את הזווית."),
                                    (u"ג", u"חשבו."))):
        items += (_bs(11 + i, u"q1" + u"abc"[i]) + _p(_r(lab + u". ") + _r(txt)) + _be(11 + i))
    q1 = (_bs(10, "q1") + _p(qtext, keep=True) + example + _tbl(rows) + items + _be(10))
    ans_c = (_om(_mr(u"(−3") + _bind_sup(_mr(u")"), u"2") + _mr(u"=9")) + _r(u", ") +
             _om(_mr(o.get("a_div", u"12:4=3"))))
    if o.get("a_paren_lost"):
        ans_c = (_om(_mr(u"−3") + _bind_sup(u"", u"2") + _mr(u"=9")) + _r(u", ") +
                 _om(_mr(u"12:4=3")))
    segs = o.get("segs", [(u"א", u"51°"), (u"ב", u"129°")])
    body = u""
    for lab, val in segs:
        body += _r(lab + u".") + _r(u"\u00a0") + _om(_mr(val)) + _r(u"   ")
    body = _r(o.get("stray", u"")) + body + _r(u"ג.") + _r(u"\u00a0") + ans_c
    cell = _p(body + ("" if o.get("note") else _be(20)), after=0)
    if o.get("note"):
        cell += _p(_r(o["note"]) + _be(20), after=0)
    answers = (_p(_r(u"תשובות סופיות", b=True), pbb=True) +
               _tbl([[_p(_bs(20, "ans_q1") + _r(u"(1)"), after=0), cell]], widths=[1000, 8000]))
    return synthetic_docx(replace_body=q1 + answers)


# (name, bind_docx options, R16 status, needle in an R16 error or warning)
BIND_CASES = [
    ("R16-bind-baseline", {}, "PASS", None),
    ("R16-bind-answers-swapped", {"segs": [(u"א", u"129°"), (u"ב", u"51°")]}, "FAIL",
     u"item א. prints 129 ° in bookmark ans_q1"),
    ("R16-bind-labels-swapped", {"segs": [(u"ב", u"51°"), (u"א", u"129°")]}, "FAIL",
     u"item ב. prints 51 °"),
    ("R16-bind-label-twice", {"segs": [(u"א", u"51°"), (u"א", u"129°")]}, "FAIL",
     u"item labels printed in bookmark ans_q1: א. א. ג.; sheet.json has answers for א. ב. ג."),
    ("R16-bind-stray-number", {"stray": u"114   "}, "FAIL",
     u"prints 114 in an answer paragraph before its first item label"),
    ("R16-bind-note-number", {"note": u"הערה: נבדק ב־2 דרכים."}, "WARN",
     u"a paragraph with no item label (an answer note) prints : 2"),
    ("R16-bind-answer-paren-lost", {"a_paren_lost": True}, "FAIL",
     u"item ג. prints − 3 2 = 9 12 : 4 = 3"),
    ("R16-bind-answer-colon-lost", {"a_div": u"12 4=3"}, "FAIL",
     u"item ג. prints ( − 3 ) 2 = 9 12 4 = 3"),
    ("R16-bind-question-paren-lost", {"q_paren_lost": True}, "FAIL",
     u"sheet.json only: ( )"),
    ("R16-bind-question-colon-lost", {"q_div": u"12 4"}, "FAIL", u"sheet.json only: :"),
    ("R16-bind-delim-brackets", {"delim": (u"[", u"]")}, "FAIL", u"sheet.json only: ( )"),
    ("R16-bind-table-head-swapped", {"table_head": [u"2", u"1"]}, "FAIL",
     u"row 1 cell 2 prints '2', sheet.json '1'"),
    ("R16-bind-table-cells-swapped", {"table_vals": [u"100°", u"35°"]}, "FAIL",
     u"row 2 cell 2 prints '100°', sheet.json '$35°$'"),
    ("R16-bind-table-shape", {"table_col_dropped": True}, "FAIL", u"holds no 2 x 3 table"),
    ("R16-bind-example-swapped", {"example_swap": True}, "FAIL",
     u"the worked-example lines of sheet.json are not all printed in this order"),
]


def _ids(lst):
    return set(r["id"] for r in lst)


def selftest(fixtures=None, write_dir=None, verbose=True):
    import time
    t0 = time.time()
    tmp = tempfile.mkdtemp(prefix="check_docx_rtl_selftest_")
    sheet = os.path.join(tmp, "sheet.json")
    gloss = os.path.join(tmp, "glossary_he.json")
    with open(sheet, "wb") as f:
        f.write(json.dumps(SYN_SHEET, ensure_ascii=False).encode("utf-8"))
    with open(gloss, "wb") as f:
        f.write(json.dumps(SYN_GLOSSARY, ensure_ascii=False).encode("utf-8"))
    fails, lines = [], []

    def verdict(name, ok, detail):
        lines.append("%s %-28s %s" % ("PASS" if ok else "FAIL", name, detail))
        if not ok:
            fails.append(name)

    for name, opts, kw, want_err, want_warn in SYN_CASES:
        path = os.path.join(write_dir or tmp, "synth_%s.docx" % name)
        with open(path, "wb") as f:
            f.write(synthetic_docx(**opts))
        kw = dict(kw)
        if kw.get("source") == "SHEET":
            kw["source"] = sheet
        g = kw.get("glossary")
        kw["glossary"] = {"GLOSS": gloss, "MISSING": os.path.join(tmp, "nope.json"),
                          None: gloss}.get(g, g)
        res = check(path, **kw)
        got_e, got_w = _ids(res["errors"]), _ids(res["warnings"])
        ok = got_e == want_err and want_warn <= got_w
        if name == "baseline" or name == "R16-baseline-source":
            ok = ok and not got_w      # the reference document is fully clean
        if name == "R17-glossary-missing":
            ok = ok and res["stats"]["rules"]["R17"] == "SKIP"
        if name == "R17-no-terms":
            ok = ok and res["stats"]["rules"]["R17"] == "SKIP" and not any(
                r["id"] == "R17" for r in res["warnings"]) and \
                "--no-terms" in res["stats"]["skipped"].get("R17", "")
        if name == "R16-baseline-source":
            ok = ok and res["stats"]["rules"]["R16"] == "PASS" and \
                res["stats"]["rules"]["R17"] == "PASS"
        if name in SYN_NEEDLES:
            ok = ok and any(SYN_NEEDLES[name] in r["msg"] for r in res["errors"]
                            if r["id"] == "R16")
        verdict(name, ok, "errors=%s warnings=%s" % (sorted(got_e), sorted(got_w)) +
                ("" if ok else "  want errors=%s warnings>=%s  first=%s" % (
                    sorted(want_err), sorted(want_warn),
                    [r["msg"] for r in res["errors"][:3] + res["warnings"][:3]])))

    # R16 token parity: the normalizations it applies and the changes it sees
    for vname, src, wtext, same in PAR_VECTORS:
        ta, tb = par_seq(par_canon(src)), par_seq(par_canon(wtext))
        verdict("par-" + vname, (ta == tb) == same, "%s: sheet=%s word=%s" % (
            "equal" if same else "differs", _par_show_seq(ta), _par_show_seq(tb)))

    # ... and on OMML structure: a script and a fraction print their numbers
    # apart; an answer's Hebrew words must be in its row; band-found rows too
    msheet = os.path.join(tmp, "sheet_math.json")
    with open(msheet, "wb") as f:
        f.write(json.dumps({"questions": [
            {"id": "q1", "n": 1, "text": u"חשבו $10^3+\\f{1}{2}$.",
             "answer": u"$1000\\f{1}{2}$ בערך"}]}, ensure_ascii=False).encode("utf-8"))
    sup = u"<m:sSup><m:e>%s</m:e><m:sup>%s</m:sup></m:sSup>" % (_mr(u"10"), _mr(u"3"))

    def frac(a, b):
        return u"<m:f><m:num>%s</m:num><m:den>%s</m:den></m:f>" % (_mr(a), _mr(b))

    def mdoc(q_math, ans_math, ans_word=u" בערך", bookmarks=True):
        b1, e1 = (_bs(1, "q1"), _be(1))
        b2, e2 = (_bs(2, "ans_q1"), _be(2)) if bookmarks else (u"", u"")
        body = (b1 + _p(_r(u"(1)") + _tab_run() + _r(u"חשבו ") + _om(q_math) + _r(u".")) + e1 +
                _p(_r(u"תשובות סופיות", b=True), pbb=True) +
                _tbl([[_p(b2 + _r(u"(1)"), after=0),
                       _p(_om(ans_math) + _r(ans_word) + e2, after=0)]], widths=[1000, 8000]))
        return synthetic_docx(replace_body=body)
    good_q, good_a = sup + _mr(u"+") + frac(u"1", u"2"), _mr(u"1000") + frac(u"1", u"2")
    for name, data, want, needle in (
            ("R16-omml-structure", mdoc(good_q, good_a), "PASS", None),
            ("R16-script-glued", mdoc(_mr(u"103+") + frac(u"1", u"2"), good_a), "FAIL",
             u"sheet.json only: 10 3; DOCX only: 103"),
            ("R16-answer-hebrew-word", mdoc(good_q, good_a, ans_word=u""), "FAIL",
             u"Hebrew word(s) of the sheet.json answer missing: בערך"),
            ("R16-band-structure", mdoc(good_q, good_a, bookmarks=False), "PASS", None),
            ("R16-band-fraction-changed",
             mdoc(good_q, _mr(u"1000") + frac(u"1", u"3"), bookmarks=False), "FAIL",
             u"answer row (1): the row (1) after the 'תשובות' band prints ( 1 ) 1000 1 3")):
        path = os.path.join(tmp, "par_%s.docx" % name)
        with open(path, "wb") as f:
            f.write(data)
        res = check(path, source=msheet, glossary=gloss)
        got = res["stats"]["rules"]["R16"]
        msgs = [r["msg"] for r in res["errors"] if r["id"] == "R16"]
        ok = got == want and (needle is None or any(needle in m for m in msgs))
        verdict(name, ok, "R16=%s %s" % (got, "; ".join(m[:100] for m in msgs[:2])))

    # ... and where ORDER is the mathematics: answers bound to their items by
    # the printed label, table cells, worked-example lines; plus brackets
    # (literal and m:d), the ':' division sign and answer notes
    bsheet = os.path.join(write_dir or tmp, "sheet_bind.json")
    with open(bsheet, "wb") as f:
        f.write(json.dumps(BIND_SHEET, ensure_ascii=False).encode("utf-8"))
    for name, opts, want, needle in BIND_CASES:
        path = os.path.join(write_dir or tmp, "bind_%s.docx" % name)
        with open(path, "wb") as f:
            f.write(bind_docx(**opts))
        res = check(path, source=bsheet, glossary=gloss)
        got = res["stats"]["rules"]["R16"]
        msgs = [r["msg"] for r in res["errors"] + res["warnings"] if r["id"] == "R16"]
        ok = got == want and (needle is None or any(needle in m for m in msgs))
        verdict(name, ok, "R16=%s %s" % (got, "; ".join(m[:100] for m in msgs[:2])))

    # an answer written as a bare number (3, not "$3$") prints as "3"
    isheet = os.path.join(write_dir or tmp, "sheet_intans.json")
    with open(isheet, "wb") as f:
        f.write(json.dumps({"questions": [{
            "id": "q1", "n": 1, "text": u"חשבו.", "items": [
                {"id": "q1a", "label": u"א", "text": u"חשבו.", "answer": 3}]}]},
            ensure_ascii=False).encode("utf-8"))
    for name, printed, want in (("R16-int-answer", u"3", "PASS"),
                                ("R16-int-answer-changed", u"4", "FAIL")):
        body = (_bs(1, "q1") + _p(_r(u"(1)") + _tab_run() + _r(u"חשבו.")) + _bs(2, "q1a") +
                _p(_r(u"א. ") + _r(u"חשבו.")) + _be(2) + _be(1) +
                _p(_r(u"תשובות סופיות", b=True), pbb=True) +
                _tbl([[_p(_bs(3, "ans_q1") + _r(u"(1)"), after=0),
                       _p(_r(u"א.") + _r(u"\u00a0") + _om(_mr(printed)) + _be(3), after=0)]],
                     widths=[1000, 8000]))
        path = os.path.join(write_dir or tmp, "%s.docx" % name)
        with open(path, "wb") as f:
            f.write(synthetic_docx(replace_body=body))
        res = check(path, source=isheet, glossary=gloss)
        got = res["stats"]["rules"]["R16"]
        msgs = [r["msg"] for r in res["errors"] if r["id"] == "R16"]
        verdict(name, got == want, "R16=%s %s" % (got, "; ".join(m[:100] for m in msgs[:2])))

    # the three Word-verified fixtures (docx.md 7.3), when present
    if fixtures is None:
        here = os.path.dirname(os.path.abspath(__file__))
        fixtures = os.path.normpath(os.path.join(here, "..", "tests", "docxcheck", "fixtures"))
    real = [("probe.docx", {"R4", "R6", "R7", "R9"}, None, set()),
            ("elem_v10.docx", {"R4", "R6"}, None, {"R13"}),
            ("elem_v103.docx", set(), {"R1", "R2", "R3", "R4", "R5", "R6", "R7", "R9"},
             {"R12", "R15"})]
    for fname, must_err, must_pass, must_warn in real:
        path = os.path.join(fixtures, fname)
        if not os.path.isfile(path):
            lines.append("SKIP %-28s fixture not found in %s" % (fname, fixtures))
            continue
        res = check(path, glossary=gloss)
        got_e, got_w = _ids(res["errors"]), _ids(res["warnings"])
        ok = must_err <= got_e and must_warn <= got_w
        if must_pass:
            ok = ok and not (got_e & must_pass)
        verdict(fname, ok, "errors=%s warnings=%s" % (sorted(got_e), sorted(got_w)))

    # the shipped glossary's own test vectors, read the way R17 reads it
    gpath = os.path.join(os.path.dirname(os.path.abspath(__file__)), "glossary_he.json")
    if os.path.isfile(gpath):
        gl = {}
        try:
            with open(gpath, "rb") as f:
                gl = json.loads(f.read().decode("utf-8"))
            gf = glossary_selfcheck(gl)
        except ValueError as e:
            gf = ["unreadable: %s" % e]
        verdict("glossary_he.json vectors", not gf, "%d forbidden + house_spelling: %s" % (
            len(gl.get("forbidden") or []),
            "all vectors agree" if not gf else "; ".join(gf[:4])))
    else:
        lines.append("SKIP %-28s not found beside the checker" % "glossary_he.json vectors")

    # scope/grade from the package's sheet_meta.SHEET (house spelling is an
    # ERROR for a sectioned sheet even when the caller passes no --scope)
    pkg = os.path.join(tmp, "G7-T99")
    ddir = os.path.join(pkg, "out", "docx", "a")
    os.makedirs(ddir)
    with open(os.path.join(pkg, "content.py"), "w") as f:
        f.write("from sheet_meta import SHEET\nLEVELS = []\n")
    with open(os.path.join(pkg, "sheet_meta.py"), "wb") as f:
        f.write(u'SHEET = {"schema": "noam-sheet-sections/v1", "grade": "7", '
                u'"scope": "sectioned", "title": "זוויות", "sections": [dict(id="s1")]}\n'
                .encode("utf-8"))
    house = os.path.join(ddir, "sheet.docx")
    with open(house, "wb") as f:
        f.write(synthetic_docx(extra_paras=_p(_r(u"התבוננו בשרטוט."))))
    for name, kw, want_sev, want_from in (
            ("scope-from-sheet_meta", {}, "error", "sheet_meta.py"),
            ("scope-explicit-wins", {"scope": "broad"}, None, "--scope"),
            ("scope-from---pkg", {"pkg": pkg}, "error", "sheet_meta.py")):
        res = check(house, glossary=gloss, **kw)
        r17e = [r for r in res["errors"] if r["id"] == "R17"]
        r17w = [r for r in res["warnings"] if r["id"] == "R17"]
        sev = "error" if r17e else ("warn" if r17w else None)
        frm = res["stats"]["scope"]["from"] or ""
        ok = sev == want_sev and frm.endswith(want_from) and res["stats"]["grade"]["value"] == "7"
        verdict(name, ok, "R17=%s scope=%s from %s" % (sev, res["stats"]["scope"]["value"],
                                                      os.path.basename(frm)))
    os.remove(os.path.join(pkg, "sheet_meta.py"))       # legacy package: no manifest
    res = check(house, glossary=gloss)
    ok = not [r for r in res["errors"] if r["id"] == "R17"] and \
        [r for r in res["warnings"] if r["id"] == "R17"] and res["stats"]["scope"]["value"] is None
    verdict("scope-legacy-warns", bool(ok), "no sheet_meta.py -> house spelling is a warning")

    # unreadable input -> CannotRead (exit 2)
    bad = os.path.join(tmp, "bad.docx")
    with open(bad, "wb") as f:
        f.write(b"not a zip")
    try:
        check(bad)
        verdict("unreadable", False, "no CannotRead raised")
    except CannotRead:
        verdict("unreadable", True, "CannotRead -> exit 2")

    # damaged inputs through the CLI: exit 2 and a JSON report, never a traceback/exit 1
    import contextlib
    base = os.path.join(tmp, "synth_baseline.docx") if not write_dir else \
        os.path.join(write_dir, "synth_baseline.docx")
    with open(base, "rb") as f:
        data = bytearray(f.read())
    zi = zipfile.ZipFile(io.BytesIO(bytes(data))).getinfo("word/document.xml")
    n_len, e_len = struct.unpack("<HH", bytes(data[zi.header_offset + 26:zi.header_offset + 30]))
    data[zi.header_offset + 30 + n_len + e_len + 20] ^= 0xFF
    corrupt = os.path.join(tmp, "corrupt_member.docx")
    with open(corrupt, "wb") as f:
        f.write(bytes(data))
    as_list = os.path.join(tmp, "list.json")
    with open(as_list, "w") as f:
        f.write("[1, 2]")
    no_q = os.path.join(tmp, "noq.json")
    with open(no_q, "w") as f:
        f.write('{"questions": {"q1": 1}}')

    def boom(_self):
        raise KeyError("forced")
    for name, argv, patch in (
            ("cli-corrupt-member", [corrupt], None),
            ("cli-source-not-object", [base, "--source", as_list], None),
            ("cli-source-bad-questions", [base, "--source", no_q], None),
            ("cli-unexpected-exception", [base], "r13")):
        js = os.path.join(tmp, name + ".json")
        orig = getattr(Checker, patch) if patch else None
        if patch:
            setattr(Checker, patch, boom)
        err = io.StringIO()
        try:
            with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(err):
                code = main(argv + ["--json", js])
        finally:
            if patch:
                setattr(Checker, patch, orig)
        try:
            with open(js, "rb") as f:
                rep = json.loads(f.read().decode("utf-8"))
            rid = rep["errors"][0]["id"]
        except (IOError, OSError, ValueError, LookupError):
            rid = None
        ok = code == 2 and rid in ("READ", "CRASH")
        verdict(name, ok, "exit %s, report %s" % (code, rid))

    dt = time.time() - t0
    lines.append("%s: %d case(s), %d failed, %.1f s" % (
        "SELFTEST PASS" if not fails else "SELFTEST FAIL", len(lines), len(fails), dt))
    if verbose:
        print("\n".join(lines))
    return not fails


# ------------------------------------------------------------------- main ----
def main(argv=None):
    ap = argparse.ArgumentParser(description="RTL checks for a Hebrew worksheet .docx (G90)")
    ap.add_argument("docx", nargs="?")
    ap.add_argument("--source", help="sheet.json of the same level (R16)")
    ap.add_argument("--glossary", help="glossary_he.json (R17); default: beside this script")
    ap.add_argument("--ltr-tables", default="", help="tables allowed LTR: q3:t1,t5")
    ap.add_argument("--fonts", default=None, help="allowed fonts, comma separated (R12)")
    ap.add_argument("--allow-latin", default=None,
                    help="Latin words allowed inside RTL runs (R7), comma separated")
    ap.add_argument("--scope", choices=("sectioned", "broad"), default=None,
                    help="sheet scope; house spelling is an ERROR for 'sectioned'")
    ap.add_argument("--grade", default=None, help="grade for glossary scope (else sheet.json)")
    ap.add_argument("--pkg", default=None,
                    help="package folder: scope/grade from its sheet_meta.SHEET (read with "
                         "ast, never executed); default: found above the .docx/sheet.json")
    ap.add_argument("--r9-word-only", action="store_true",
                    help="R9: an RTL run of neutrals between two zones (Word renders it "
                         "right, measured) is a warning instead of an error")
    ap.add_argument("--no-terms", action="store_true",
                    help="skip R17 (glossary terms), e.g. for a legacy package with no SHEET")
    ap.add_argument("--json", dest="json_out", help="also write the report here")
    ap.add_argument("--render", action="store_true",
                    help="also run docx_render.py --assert (local Mac with Word; warnings only)")
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--fixtures", default=None, help="selftest: folder with the Word fixtures")
    ap.add_argument("--write-synthetic", default=None,
                    help="selftest: keep the synthetic fixtures in this folder")
    a = ap.parse_args(argv)
    if a.selftest:
        if a.write_synthetic:
            os.makedirs(a.write_synthetic, exist_ok=True)
        return 0 if selftest(a.fixtures, a.write_synthetic) else 1
    if not a.docx:
        ap.error("a .docx path is required (or --selftest)")

    def failed(rid, rule, msg):
        """The report of a file that was NOT checked (exit 2): still JSON."""
        sha = None
        try:
            with open(a.docx, "rb") as f:
                sha = hashlib.sha256(f.read()).hexdigest()
        except (IOError, OSError):
            pass
        return {"file": os.path.abspath(a.docx), "sha256": sha,
                "errors": [{"id": rid, "rule": rule, "part": None, "para_index": None,
                            "xpath": None, "excerpt": None, "msg": msg}],
                "warnings": [], "stats": {"checker": "check_docx_rtl %s" % VERSION}}
    try:
        ck = Checker(a.docx, source=a.source, glossary=a.glossary,
                     ltr_tables=a.ltr_tables.split(","),
                     fonts=[f.strip() for f in a.fonts.split(",")] if a.fonts else None,
                     allow_latin=[w.strip() for w in a.allow_latin.split(",") if w.strip()]
                     if a.allow_latin is not None else None,
                     scope=a.scope, grade=a.grade, r9_word_only=a.r9_word_only, pkg=a.pkg,
                     no_terms=a.no_terms)
        res = ck.run(render=a.render)
    except CannotRead as e:
        res, code = failed("READ", "CANNOT_READ", str(e)), 2
    except Exception as e:     # malformed input the rules did not foresee
        import traceback
        traceback.print_exc()
        res, code = failed("CRASH", "CHECKER_EXCEPTION",
                           "the checker could not finish (%s: %s) -- the file was NOT "
                           "checked; treat as unreadable" % (type(e).__name__, e)), 2
    else:
        code = 1 if res["errors"] else 0
    out = json.dumps(res, ensure_ascii=False, indent=1)
    if a.json_out:
        with open(a.json_out, "wb") as f:
            f.write(out.encode("utf-8"))
    sys.stdout.write(out + "\n")
    sys.stderr.write("check_docx_rtl: %s -- %d error(s), %d warning(s), exit %d\n"
                     % (a.docx, len(res["errors"]), len(res["warnings"]), code))
    return code


if __name__ == "__main__":
    sys.exit(main())
