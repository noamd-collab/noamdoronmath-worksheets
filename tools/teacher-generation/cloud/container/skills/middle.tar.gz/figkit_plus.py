# -*- coding: utf-8 -*-
r"""figkit_plus — v5.3. What an analytic-geometry sheet needs and `coord_plane`
could not draw, built ON `figkit.Figure` instead of beside it.

WHY THIS FILE EXISTS
--------------------
v5.2 shipped `coord_plane()` precisely so that a package would stop writing its
own plotting helper — SKILL.md's own warning: "a package-local helper is outside
figkit", and six figures that contradicted their own question came from exactly
that. Authoring three new כיתה ח׳ packages (Sep 2026) hit the wall again: the
sheets needed the image of a transformation, a circle, a mirror line with a
caption, and ticks every 2 on one axis — and `coord_plane` has no parameter for
any of them. The author was one keystroke away from writing helper number seven.

So this module adds those primitives INSIDE the engine: every stroke registered,
every label solved by the placer, the font floor measured, and — new here — the
finished SVG re-swept by `figkit._struck` before it is returned.

Nothing in this file edits `figkit.py`, `emit_html.py` or the gates. `plane()`
is a superset of `coord_plane()`: existing calls keep working through the old
function, new sheets call this one.

    from figkit_plus import plane, assert_unstruck

    # a shape and its image under a reflection, with the mirror line named
    plane((-2, 6), (-1, 5),
          polys=[[(-1, 0), (1, 4), (3, 1)]],
          dpolys=[[(5, 0), (3, 4), (1, 1)]],
          dashed=[((2, -1), (2, 5))],
          points=[((-1, 0), "A"), ((1, 4), "B"), ((3, 1), "C")],
          labels=[((2, 4.7), "x = 2", (1, 0))])

    # a lattice circle: every point at distance 5 from P
    plane((-5, 7), (-5, 7), circles=[((1, 1), 5, "4,3")],
          points=[((1, 1), "P")],
          dots=[(1, 6), (5, 4), (6, 1), (5, -2), (1, -4), (-3, -2), (-4, 1)])

    # a length written on an edge: upright, not italic
    plane((-1, 7), (-1, 5), polys=[[(0, 0), (6, 0), (6, 3)]],
          values=[((3, -0.4), "6"), ((6.5, 1.5), "3")])

WHAT IT ADDS OVER coord_plane
-----------------------------
1. A DOT IS INK, AND THE PLACER DID NOT KNOW IT.
   `Figure.dot()` appends to `parts` and NOT to `segs`, so the label solver
   treats a plotted point as empty space. `coord_plane` draws a dot at every
   named point, so the first drawing built here printed a vertex letter `C`
   directly on the dot of a neighbouring point — invisible to `verify()`
   (which checks strokes, the font floor and label-label gaps) and invisible
   to G72 (a filled disc is not a stroked path). Here every dot registers a
   small square of its own in `segs`, so the solver walks around it.

2. THE FINISHED SVG IS RE-SWEPT, NOT TRUSTED.
   `figkit._struck()` exists and is used by figkit's own selftest, but no
   builder calls it at emit time. This one does: the SVG it is about to return
   is read back with an independent sweep, and a struck label raises. Same
   doctrine as `python3 figkit.py` — a gate that trusts the thing it is gating
   is not a gate.

3. PRIMITIVES THE SHEETS ACTUALLY NEEDED.
   `dpolys` — a dashed closed shape: the image of a הזזה / שיקוף / סיבוב /
   הגדלה, a bounding rectangle, a counter-example drawn beside the original.
   `circles` — a circle from its centre and radius, in grid units.
   `labels` / `values` — free text at a coordinate: `labels` is italic, for a
   line's name or equation (`y = x`, `x = 2`); `values` is upright, for a
   length or an area written on the drawing. Both go through the placer, so
   neither can land on a stroke. Latin and digits only, as everywhere in
   figkit — the Hebrew caption belongs in the question text.
   `dots` — plotted points with no letter.
   `xticks` / `yticks` — the two axes may be numbered independently, which a
   tall narrow range needs.

4. THE FONT FLOOR IS RAISED FOR AN EXPLICIT WIDTH TOO.
   `coord_plane` enlarges the labels before shrinking only when `width` is
   None. Pass it a narrow explicit width and the tick numbers go under 7pt and
   `verify()` refuses the drawing — the author's fix is then to delete ticks.
   Here the same enlargement runs for an explicit width, so a narrow figure
   stays legal and keeps its numbers.

Every other rule of figkit still applies and is not re-implemented here: one
`size` drives both axes so a slope reads true, gridlines are cut around labels,
Hebrew inside `<text>` raises, and `verify()` owns the font floor and the
label-label gap.
"""
import math
import re

import figkit
import svgcheck
from figkit import Figure, GRID, MIN_PT, _PX_TO_PT, _num, _dist, _unit

__all__ = ["plane", "assert_unstruck", "ticks_every", "row", "wide",
           "auto_step", "clip_polyline", "intersections", "stop_short"]

# G76 RIDES ALONG (v5.4). The variety gate lives in `gate_variety.py` and is
# installed by `build_plus.py`, which is the documented entry. But a package
# that draws with `plane()` and is built with the stock `build.py` would then
# silently skip it — and a gate that silently skips is indistinguishable from a
# gate that passed, which is this skill's oldest lesson. So importing this
# module installs it too. A failure here is printed, never swallowed.
try:
    import gate_variety as _gate_variety
    _gate_variety.install()
except Exception as _e:                      # pragma: no cover
    import sys as _sys
    print("figkit_plus: G76 NOT installed (%r) — build with build_plus.py or "
          "fix the import before shipping" % (_e,), file=_sys.stderr)

SIDE_MAX = 210.0                 # emit_html.SIDE_MAX: a figure beside the text
PAGE_MAX = 430.0                 # ... and the full page width a block figure
                                 # may take (what max_width=None asks for)
MIN_SQUARE_PX = 10.0             # a grid square a student can still count
_DOT_PAD = 0.6                   # clearance around a plotted dot, figure units


def ticks_every(lo, hi, step):
    """Multiples of `step` inside [lo, hi] — the numbering an axis usually wants
    when the range is wide enough that every integer would collide."""
    return [v for v in range(int(lo), int(hi) + 1) if v % step == 0]


def auto_step(lo, hi):
    """v6 stage 1b (the author's rule 3): the numbering step an axis takes when
    the author names none.

    Every 2 squares on an axis long enough to carry two numbers that way (the
    v5.8 reading rules still hold: regular, end to end, anchored at 0, at most
    max(2, ceil(squares/6)) squares apart, at least two numbers); every 1 on a
    short axis, where every 2 would leave too few numbers to read a value off.
    Each axis decides for itself, so a wide x and a short y do not force each
    other; on equal scales two long axes always land on the same step.

    Numbering every 2 is also what keeps a stroke and a number apart: with a
    number on every square a line through the origin has the '-1' of both axes
    in its way, and since v6 stage 1b nothing is cut to make room."""
    two = [v for v in range(int(math.floor(lo)), int(math.ceil(hi)) + 1)
           if v % 2 == 0 and v != 0 and lo - 1e-9 <= v <= hi + 1e-9]
    return 2 if len(two) >= 2 else 1


# ------------------------------------------------- curves (v6 stage 1b) ---
_CURVE_TOL = 0.006       # sampling tolerance, in units of the window's width
_CURVE_MAX = 900         # most samples one curve may take


def _at(fn, x):
    """fn(x) as a point, or None where the function has no value there."""
    try:
        y = fn(x)
    except (ValueError, ZeroDivisionError, OverflowError):
        return None
    if y is None or y != y or abs(y) > 1e9:
        return None
    return (x, float(y))


def _pole(fn, a, b, big):
    """The x in (a, b) where fn blows up, or None (v6 stage 1b r2).

    A gap in the samples is not enough to tell a POLE from a merely steep
    stretch: y = 1/x misses x = 0 unless the grid lands on it, and tan x
    reads a few hundred a thousandth away from pi/2. So the interval is
    scanned, the scan narrows on the largest |y| it found, and a pole is
    declared only when that maximum keeps GROWING as the window narrows
    (1/x, tan) and not when it merely stands high (x^7 near the window's
    edge). A point where fn has no value at all is a pole at once."""
    lo, hi, first, best = a, b, None, None
    for _ in range(5):
        n = 32
        vals = []
        for k in range(n + 1):
            x = lo + (hi - lo) * k / n
            p = _at(fn, x)
            if p is None:
                return x
            vals.append((abs(p[1]), x))
        m, xm = max(vals)
        first = m if first is None else first
        best = (m, xm)
        h = (hi - lo) / n
        lo, hi = xm - h, xm + h
    return best[1] if (best[0] > big
                       and best[0] > 1e3 * max(first, 1e-12)) else None


def _sample(fn, x0, x1, tol, ylim=None):
    """The RUNS of y = fn(x) over [x0, x1], refined where the curve bends.

    Uniform sampling either wastes points on a straight stretch or corners a
    parabola's vertex; this splits an interval whenever its midpoint is
    further than `tol` from the chord.

    A pole or a negative root ENDS a run and the next piece starts a new one
    (v6 stage 1b r2): the two branches of y = k/x are two runs, never one
    path welded across x = 0. Joined, the drawing printed a straight stroke
    down the asymptote and claimed the function has a value (0) where it has
    none -- and no gate saw it, because the stroke was whole.

    C6 r6: a run ends AT the break, not at the last coarse sample before it.
    The window was stepped in 16 intervals and an interval with an undefined
    end was thrown away whole, so y = 1/x on -5..5 stopped at y = -1.6 (it
    leaves the window at -5), a semicircle sqrt(9 - x^2) stopped 0.66 above
    the axis it meets, sqrt(x) started at x = 0.375 and a dotted O(0, 0) sat
    off its own curve -- all by amounts that depended on the window. Now the
    edge of the domain, or the point where the curve runs off to a pole, is
    found by bisection and the run is walked right up to it; and wherever a
    run leaves or enters the window's height the exact crossing is solved on
    fn itself (not read off a chord), so the clip that follows is exact."""
    yc = 0.5 * (ylim[0] + ylim[1]) if ylim else 0.0
    big = 1e3 * max(abs(ylim[1] - ylim[0]) if ylim else 1.0, 1.0)

    def at(x):
        # a value further than `big` from the window is no value to draw: it
        # is where a pole took the curve, and the run stops there
        p = _at(fn, x)
        return p if p is not None and abs(p[1] - yc) <= big else None

    runs, cur = [], []
    count = [0]

    def flush():
        if len(cur) > 1:
            runs.append(list(cur))
        del cur[:]

    def add(p):
        if not cur or abs(p[0] - cur[-1][0]) > 1e-12:
            cur.append(p)
            count[0] += 1

    def steep(p, q):
        """Might these two neighbouring samples straddle a pole? Only a step
        that crosses more than twice the window's height is even asked; the
        answer is _pole's, so a steep line is not broken."""
        return (ylim is not None and abs(q[1] - p[1])
                > 2.0 * max(abs(ylim[1] - ylim[0]), 1e-9))

    def jump(u, pu, v, pv):
        """Stage-1 fix r1: a finite JUMP between two neighbouring samples
        (a piecewise f, floor x), or None. The interval is halved toward the
        half that holds the larger step until the two ends are neighbouring
        floats; a continuous curve's step shrinks to nothing on the way (even
        a vertical tangent, cbrt x), a jump's does not. Joined, the run drew a
        riser through values the function never takes, and intersections()
        -- which is right -- disagreed with the picture."""
        if abs(pv[1] - pu[1]) <= tol:
            return None
        lo, hi, flo, fhi = u, v, pu, pv
        for _ in range(1100):
            m = 0.5 * (lo + hi)
            if m == lo or m == hi:
                break
            pm = at(m)
            if pm is None:
                return None
            if abs(pm[1] - flo[1]) >= abs(fhi[1] - pm[1]):
                hi, fhi = m, pm
            else:
                lo, flo = m, pm
        if abs(fhi[1] - flo[1]) > 0.5 * tol:
            return flo, fhi
        return None

    def edge(a, b):
        """The x nearest the break between a (a value) and b (none), and its
        point: bisected until the interval stops shrinking."""
        lo, hi = a, b
        for _ in range(200):
            m = 0.5 * (lo + hi)
            if m == lo or m == hi:
                break
            if at(m) is not None:
                lo = m
            else:
                hi = m
        return lo, at(lo)

    def walk(a, pa, b, pb, d):
        """Emit the curve over (a, b]; pa is already emitted."""
        if d > 60:
            flush()
            return
        m = 0.5 * (a + b)
        pm = at(m)
        if pm is None:
            reach(a, pa, m, d + 1)
            leave(m, b, pb, d + 1)
            return
        if d < 14 and count[0] <= _CURVE_MAX:
            cy = 0.5 * (pa[1] + pb[1])
            if abs(pm[1] - cy) > tol or (b - a) > 0.25 * (x1 - x0):
                walk(a, pa, m, pm, d + 1)
                walk(m, pm, b, pb, d + 1)
                return
        for u, pu, v, pv in ((a, pa, m, pm), (m, pm, b, pb)):
            xp = _pole(fn, u, v, big) if steep(pu, pv) else None
            if xp is not None:
                reach(u, pu, xp, d + 1)
                leave(xp, v, pv, d + 1)
                continue
            j = jump(u, pu, v, pv)
            if j is not None:
                # a finite JUMP ends the run at the left limit and starts the
                # next at the right one; no riser is drawn between them
                add(j[0])
                flush()
                add(j[1])
                if j[1][0] != v:
                    walk(j[1][0], j[1], v, pv, d + 1)
            else:
                add(pv)

    def reach(a, pa, b, d):
        """From a (a value) up to the break before b, then end the run."""
        xe, pe = edge(a, b)
        if not cur:
            add(pa)
        if xe != a:
            walk(a, pa, xe, pe, d)
        flush()

    def leave(a, b, pb, d):
        """Start a run at the break after a (no value) and walk on to b."""
        xs, ps = edge(b, a)
        flush()
        add(ps)
        if xs != b:
            walk(xs, ps, b, pb, d)

    n = 16
    xs = [x0 + (x1 - x0) * k / n for k in range(n + 1)]
    ps = [at(x) for x in xs]
    if ps[0] is not None:
        add(ps[0])
    for k in range(n):
        a, b = xs[k], xs[k + 1]
        pa, pb = ps[k], ps[k + 1]
        count[0] = 0
        if pa is None and pb is None:
            # a piece of the curve can live wholly between two coarse samples
            inner = [a + (b - a) * j / 16.0 for j in range(1, 16)]
            got = [(x, at(x)) for x in inner]
            got = [(x, p) for x, p in got if p is not None]
            if not got:
                continue
            (xa, qa), (xb, qb) = got[0], got[-1]
            leave(a, xa, qa, 1)
            if xb != xa:
                walk(xa, qa, xb, qb, 1)
            reach(xb, qb, b, 1)
        elif pb is None:
            reach(a, pa, b, 0)
        elif pa is None:
            leave(a, b, pb, 0)
        else:
            if not cur:
                add(pa)
            walk(a, pa, b, pb, 0)
    flush()
    if ylim is None:
        return runs
    return [_exact_exits(fn, r, ylim) for r in runs]


def _exact_exits(fn, run, ylim):
    """C6 r6: put the exact points where a run crosses the window's bottom or
    top into it, solved on fn by bisection, so clip_polyline cuts the curve at
    the frame where the CURVE meets it and not where a chord between two
    samples does (near a pole the chord's crossing was visibly off)."""
    lo, hi = ylim
    out = [run[0]]
    for p, q in zip(run, run[1:]):
        found = []
        for yb in (lo, hi):
            sp, sq = p[1] - yb, q[1] - yb
            if sp == 0 or sq == 0 or (sp < 0) == (sq < 0):
                continue
            a, b, fa = p[0], q[0], sp
            for _ in range(200):
                m = 0.5 * (a + b)
                if m == a or m == b:
                    break
                v = _at(fn, m)
                if v is None:
                    break
                if (v[1] - yb < 0) == (fa < 0):
                    a, fa = m, v[1] - yb
                else:
                    b = m
            x = 0.5 * (a + b)
            if p[0] < x < q[0] or q[0] < x < p[0]:
                found.append((x, yb))
        found.sort(key=lambda t: abs(t[0] - p[0]))
        out.extend(found)
        out.append(q)
    return out


def clip_polyline(pts, win):
    """The pieces of a polyline that lie inside win = (x0, y0, x1, y1), the
    crossing points computed EXACTLY (Liang-Barsky per segment), as a list of
    polylines. A curve that leaves the window and comes back gives two pieces;
    nothing is stretched to the frame and nothing inside is dropped."""
    x0, y0, x1, y1 = win

    def clip(p, q):
        dx, dy = q[0] - p[0], q[1] - p[1]
        t0, t1 = 0.0, 1.0
        for num, den in ((p[0] - x0, -dx), (x1 - p[0], dx),
                         (p[1] - y0, -dy), (y1 - p[1], dy)):
            if abs(den) < 1e-12:
                if num < -1e-12:
                    return None
                continue
            t = num / den
            if den < 0:
                if t > t1:
                    return None
                t0 = max(t0, t)
            else:
                if t < t0:
                    return None
                t1 = min(t1, t)
        if t1 < t0:
            return None
        return ((p[0] + t0 * dx, p[1] + t0 * dy),
                (p[0] + t1 * dx, p[1] + t1 * dy))

    pieces, cur = [], []
    for p, q in zip(pts, pts[1:]):
        got = clip(p, q)
        if got is None:
            if len(cur) > 1:
                pieces.append(cur)
            cur = []
            continue
        a, b = got
        if cur and _dist(cur[-1], a) < 1e-9:
            cur.append(b)
        else:
            if len(cur) > 1:
                pieces.append(cur)
            cur = [a, b]
    if len(cur) > 1:
        pieces.append(cur)
    return pieces


def intersections(f, g, x0, x1, n=400, tol=1e-12):
    """Where two callables cross on [x0, x1], as exact-as-bisection (x, y)
    pairs — the points a question dots and letters. Sign changes of f - g are
    bracketed on a fine grid and bisected; a touching point (a double root)
    is found when the difference reaches zero.

    v6 stage 1b r2: a grid point that lands exactly ON a root is recorded as
    that root and no longer BRACKETS the next interval as well. It used to:
    [root, root + h] was bisected with f(a) = 0 read as 'not negative', the
    search ran to the far end, and the helper returned a point that is not a
    crossing -- x^2 = 4 on (-5, 5) came back with 2.025 beside 2, and
    plane(points=...) drew and lettered a dot there, off both curves. Every
    answer is now put back into the two functions before it is returned.

    P3: a function with a POLE on the scan grid used to raise
    ZeroDivisionError out of the helper (a hyperbola against a line on a
    symmetric window is the textbook case), and two roots inside one scan
    interval came back as one. Values are read through the sampler's guard,
    an interval with no value at an end is not bracketed, and an interval
    whose inside DIPS through zero is split at the dip and both halves
    bisected."""
    out = []

    def d(x):
        """f(x) - g(x), or None where either has no value there (a pole, a
        square root outside its domain, an overflow)."""
        a, b = _at(f, x), _at(g, x)
        if a is None or b is None:
            return None
        v = a[1] - b[1]
        return v if v == v and abs(v) < 1e15 else None

    def keep(r, tight=1e-6):
        # an answer is a crossing only where the two really meet
        fa, ga, dr = _at(f, r), _at(g, r), d(r)
        if fa is None or ga is None or dr is None:
            return
        scale = max(abs(fa[1]), abs(ga[1]), 1.0)
        if abs(dr) > tight * scale:
            return
        if all(abs(r - q[0]) > 1e-7 for q in out):
            out.append((r, f(r)))

    def brack(a, b):
        """Bisect [a, b], which the caller has shown to hold a sign change."""
        fa, fb = d(a), d(b)
        if fa is None or fb is None or fa == 0.0 or fb == 0.0 or \
                (fa < 0) == (fb < 0):
            if fa == 0.0:
                keep(a)
            if fb == 0.0:
                keep(b)
            return
        for _ in range(80):
            m = 0.5 * (a + b)
            fm = d(m)
            if fm is None:
                return
            if abs(b - a) < tol or fm == 0.0:
                a = b = m
                break
            if (fa < 0) != (fm < 0):
                b = m
            else:
                a, fa = m, fm
        keep(0.5 * (a + b))

    def touch(a, b):
        """C6 r6: a TOUCHING point (a double root, a tangent line) has no sign
        change to bracket; it used to be found only when a scan point landed
        exactly on it, so y = x^2 and y = 2x - 1 met at (1, 1) on -5..5 and
        not at all on -3..6. A dip of |f - g| between two scan points is
        narrowed by golden section and kept only if it reaches zero."""
        gr = (math.sqrt(5.0) - 1.0) / 2.0
        a0, b0, s0 = a, b, d(a)
        c, e = b - gr * (b - a), a + gr * (b - a)
        for _ in range(200):
            if abs(b - a) < 1e-13 * max(1.0, abs(a)):
                break
            dc, de = d(c), d(e)
            if dc is None or de is None:
                return
            if abs(dc) <= abs(de):
                b, e = e, c
                c = b - gr * (b - a)
            else:
                a, c = c, e
                e = a + gr * (b - a)
        r = 0.5 * (a + b)
        # P3 (close-roots-merged): the dip may go THROUGH zero -- two simple
        # roots inside one scan interval, not a tangency. Bracket each half.
        dr = d(r)
        if dr is not None and s0 is not None and dr != 0.0 and \
                (dr < 0) != (s0 < 0):
            brack(a0, r)
            brack(r, b0)
            return
        # a tangency is only as sharp as sqrt(machine eps); a nearby short
        # decimal that meets at least as closely is the point the author wrote
        for nd in (6, 9):
            q = round(r, nd)
            if abs(q - r) < 1e-6 and abs(d(q)) <= abs(d(r)):
                r = q
                break
        keep(r, tight=1e-9)
    xs = [x0 + (x1 - x0) * k / n for k in range(n + 1)]
    ds = [d(x) for x in xs]
    for k in range(1, n):
        if (None not in (ds[k - 1], ds[k], ds[k + 1])
                and ds[k - 1] != 0.0 and ds[k] != 0.0 and ds[k + 1] != 0.0
                and (ds[k - 1] < 0) == (ds[k] < 0) == (ds[k + 1] < 0)
                and abs(ds[k]) <= abs(ds[k - 1])
                and abs(ds[k]) <= abs(ds[k + 1])):
            touch(xs[k - 1], xs[k + 1])
    prev_x, prev = x0, ds[0]
    if prev == 0.0:
        keep(x0)
    for k in range(1, n + 1):
        x = xs[k]
        cur = ds[k]
        if cur is None or prev is None:
            # a pole (or a point outside a domain) between the two: no
            # bracket spans it, and the scan picks up on the far side
            prev_x, prev = x, cur
            continue
        if cur == 0.0:
            keep(x)
            # P3: a root sitting exactly ON a grid point used to swallow the
            # interval after it -- (x-1)(x-1.001) returned only x = 1
            if k < n and ds[k + 1] is not None and ds[k + 1] != 0.0 and \
                    k >= 1 and ds[k - 1] is not None and ds[k - 1] != 0.0 \
                    and (ds[k - 1] < 0) == (ds[k + 1] < 0):
                touch(x, xs[k + 1])
        elif prev != 0.0 and (prev < 0) != (cur < 0):
            brack(prev_x, x)
        prev_x, prev = x, cur
    return sorted(out)


def _curve_pieces(entry, win):
    """One `curves=` entry -> (pieces inside the window, name).

    An entry is (f, "name") with f callable, or (points, "name") with points a
    list of (x, y) already in data units. `None` for the name draws it
    unnamed."""
    if not isinstance(entry, (tuple, list)) or len(entry) != 2:
        raise AssertionError(
            "figkit_plus.plane: curves= takes (f, 'name') pairs -- f a "
            "callable y = f(x), or a list of (x, y) points; name None for an "
            "unnamed curve. Got %r." % (entry,))
    src, nm = entry
    x0, y0, x1, y1 = win
    if callable(src):
        runs = _sample(src, x0, x1, _CURVE_TOL * max(x1 - x0, 1e-9),
                       ylim=(y0, y1))
    else:
        pts = [(float(p[0]), float(p[1])) for p in src]
        if len(pts) < 2:
            raise AssertionError(
                "figkit_plus.plane: curves=%r gives %d point(s); a curve "
                "given as points needs at least two." % (nm or src, len(pts)))
        runs = [pts]
    # each RUN is clipped on its own, so the two branches of a pole never
    # join across it (v6 stage 1b r2)
    return [pc for run in runs for pc in clip_polyline(run, win)], nm


def _curve_anchor(pieces, win, back=0.75):
    """Where a curve's name goes: walked `back` data units in from the END of
    its last piece, so the letter sits beside the curve's free end and the
    ring search only has to step off it. Typst's figlib does the same walk."""
    piece = pieces[-1]
    k, acc = len(piece) - 1, 0.0
    while k > 0 and acc < back:
        acc += _dist(piece[k], piece[k - 1])
        k -= 1
    p = piece[k]
    x0, y0, x1, y1 = win
    return p, (1 if p[0] < 0.5 * (x0 + x1) else -1,
               1 if p[1] < 0.5 * (y0 + y1) else -1)


_ARROW_GAP_PT = 2.0      # printed; svgcheck refuses under 1.5pt


def stop_short(a, b, stops):
    """Public: the point where a shaft a->b must end so its tip stops outside
    every (centre, radius) disc in `stops` — pass a dot as (centre, r + gap)
    and the next arrow's start as (start, gap). This is the fix the
    arrowhead sweep's refusal names."""
    return _stop_short(a, b, stops)


def _stop_short(a, b, stops):
    """Pull the tip `b` of the shaft a->b back to where it first enters any
    (centre, radius) disc in `stops` — the arrow still points at the same
    place, it just no longer lands on it."""
    dx, dy = b[0] - a[0], b[1] - a[1]
    L2 = dx * dx + dy * dy
    if L2 <= 0:
        return b
    t_end = 1.0
    for c, R in stops:
        if _dist(b, c) >= R or _dist(a, c) < R:
            continue
        fx, fy = a[0] - c[0], a[1] - c[1]
        B = 2 * (fx * dx + fy * dy)
        C = fx * fx + fy * fy - R * R
        disc = B * B - 4 * L2 * C
        if disc < 0:
            continue
        t = (-B - math.sqrt(disc)) / (2 * L2)
        if 0.0 < t < t_end:
            t_end = t
    return (a[0] + dx * t_end, a[1] + dy * t_end)


def assert_unstruck(svg, where="figure"):
    """Independent re-sweep of a finished SVG. Raises if any label has ink
    through it. Uses figkit's own sweep, which reads the emitted file rather
    than the solver's bookkeeping."""
    bad = figkit._struck(svg)
    if bad:
        raise AssertionError(
            "figkit_plus: %s emits struck label(s) %r — a letter with a line "
            "through it extracts perfectly and prints ambiguously. Re-place "
            "the label (another anchor or side), halo it or cut the stroke "
            "behind it, or enlarge the figure or widen the range so it has "
            "room — never delete the label: the reader needs it." % (where, bad))
    return svg


# P3 leftovers r1 (P3-DATA-TICKS-STRIPS-AXIS, open item c6 #17): how many
# values data_ticks= may list when NONE of them sits on a grid line. Its
# shipped uses list the two or three DATA values an item points at
# (xticks=[1.5, 4.5] beside a point at (1.5, 2)). A longer list with nothing
# on the grid is an alternative NUMBERING drawn off the squares -- what
# xticks=[-4.5, -1.5, 2.5, 4.5] did to a 12-square axis that was refused for
# its '-3', printing no integer at all with problems() == [].
_DATA_TICKS_MAX = 2


def _assert_axis_numbers(axis, ts, lo, hi, unit, data_ticks, step=1):
    """Both axes numbered, at one regular step, from end to end.

    The first rebuilt slope sheet dropped numbers wherever one touched a line:
    an axis numbered only at 4 and -4, another with no numbers at all. That is
    what a reader calls a broken coordinate system."""
    v = sorted(t for t in ts if t != 0 and lo - 1e-9 <= t <= hi + 1e-9)
    u = unit * step
    room = [k for k in range(int(math.ceil(lo / u - 1e-9)),
                             int(math.floor(hi / u + 1e-9)) + 1) if k != 0]
    if len(room) >= 2 and len(v) < 2:
        raise AssertionError(
            "figkit_plus.plane: the %s-axis carries %d number(s) %s. Number it "
            "at a regular step (default: every `step` squares); to keep a value "
            "from being read, do not mark it -- never strip the axis." %
            (axis, len(v), v))
    # C6 r4: data_ticks=True excuses numbers at DATA values, off the grid
    # (1.5, 4, 7.5). An axis whose every number sits on a grid line is an
    # ordinary numbering and is judged as one: data_ticks=True with
    # xticks=[-8, 8] printed two numbers on a 16-square axis and cleared an
    # axis-number refusal by dropping the other six.
    off_grid = any(abs(t / unit - round(t / unit)) > 1e-6 for t in v)
    if data_ticks and off_grid:
        # stage-1 fix r1: ONE data value off the grid excused the whole axis
        # -- xticks=[-6, -4.5, -1, 2] printed four numbers on a 12-square
        # axis and cleared a refusal for the '-3' it left out. The numbers
        # that DO sit on grid lines are an ordinary numbering beside the data
        # values, and are judged as one when there are two or more of them.
        on = [t for t in v if abs(t / unit - round(t / unit)) <= 1e-6]
        # P3 leftovers r1 (P3-DATA-TICKS-STRIPS-AXIS, open item c6 #17):
        # with FEWER than two values on grid lines this returned at once, so
        # no regularity, density or completeness rule ran on the axis at
        # all -- one keyword and a list of off-grid values numbered a
        # 12-square axis [-4.5, -1.5, 2.5, 4.5], with no integer anywhere on
        # it, and svgcheck called the file clean. That is the hide= escape
        # under another name (rule 2). data_ticks excuses a number from the
        # GRID; at least one number must still SIT on the grid, or the
        # reader has nothing to tie the squares to and the values printed
        # are simply the ones the item did not mind giving away.
        # Stage review (must): this fired only ABOVE the cap, so exactly two
        # off-grid values -- the commonest shape -- fell through the `return`
        # below with no density, regularity or completeness rule run on the
        # axis at all: a 20-square axis numbered '-4.5' and '1.5', not one
        # number on a grid line, problems() clean. Two dots at those x
        # values cleared the didactic guard, so it was two edits from any
        # refusal. The rule this branch states -- at least one number stands
        # on the grid -- now holds whatever the count.
        if not on:
            raise AssertionError(
                "figkit_plus.plane: the data_ticks %s-axis prints %d numbers "
                "%s and not one of them sits on a grid line -- that is a "
                "NUMBERING drawn off the squares, not the handful of data "
                "values data_ticks= is for, and it is the way a crowded "
                "number gets left out (an axis number is never deleted). "
                "Number the axis regularly (xticks/yticks left to the step) "
                "and give the crowded number room: a larger size= with a "
                "wider figure (max_width=), or step=2. data_ticks= adds at "
                "most %d values off the grid BESIDE the axis's own numbers: "
                "at least one number stands on a grid line."
                % (axis, len(v), [float("%g" % t) for t in v],
                   _DATA_TICKS_MAX))
        # exactly one number on the grid: the off-grid values are still a
        # HANDFUL of data values, not a numbering of their own
        off = [t for t in v if t not in on]
        if len(on) < 2 and len(off) > _DATA_TICKS_MAX:
            raise AssertionError(
                "figkit_plus.plane: the data_ticks %s-axis prints %d values "
                "off the grid (%s) against one on it -- that is a NUMBERING "
                "drawn off the squares, not the handful of data values "
                "data_ticks= is for. Number the axis regularly "
                "(xticks/yticks left to the step) and give the crowded "
                "number room: a larger size= with a wider figure "
                "(max_width=), or step=2; an axis number is never deleted."
                % (axis, len(off), [float("%g" % t) for t in off]))
        # v6.2 Q1 (L1-P3r3-01 / L3-Stage-02): the on-grid numbers are the
        # axis's OWN numbering and are judged as one WHATEVER their count.
        # This branch used to `return` here whenever fewer than two values
        # sat on the grid, so ONE on-grid value switched off the density,
        # regularity and completeness rules for the whole axis:
        # data_ticks=True, xticks=[2, -4.5] numbered a 12-square axis '2'
        # and '-4.5' and cleared a real refusal for a crowded '-3'
        # (problems() == []). The recursion below reaches the head rule
        # ("the x-axis carries 1 number(s)") on exactly that shape.
        try:
            _assert_axis_numbers(axis, on, lo, hi, unit, False, step)
        except AssertionError as e:
            raise AssertionError(
                "%s (data_ticks=True excuses the values OFF the grid, %s; "
                "the ones on grid lines are the axis's numbering, and they "
                "are numbering enough on their own or the axis has none)"
                % (e, [float("%g" % t) for t in off]))
        return
    if len(v) < 2:
        return
    for t in v:
        if abs(t / unit - round(t / unit)) > 1e-6:
            raise AssertionError(
                "figkit_plus.plane: %s-axis number %g is not on a grid line at "
                "%sscale=%g (pass data_ticks=True for data values)" %
                (axis, t, axis, unit))
    pts = sorted(set(v + [0.0]))
    d = min(b - a for a, b in zip(pts, pts[1:]))
    want = [k * d for k in range(int(math.ceil(lo / d - 1e-9)),
                                 int(math.floor(hi / d + 1e-9)) + 1) if k != 0]
    squares = (hi - lo) / unit
    most = max(2, int(math.ceil(squares / 6.0)))
    if d / unit > most + 1e-9:
        raise AssertionError(
            "figkit_plus.plane: the %s-axis is numbered every %g squares across "
            "%g squares -- too sparse to read a value off. Number at most every "
            "%d squares." % (axis, d / unit, squares, most))
    if len(want) != len(v) or any(abs(a - b) > 1e-6 for a, b in zip(want, v)):
        raise AssertionError(
            "figkit_plus.plane: the %s-axis numbers %s skip values -- a regular "
            "step of %g across %s would be %s. An axis numbered with gaps reads "
            "as broken; number every step (a crowded number steps aside -- nothing "
            "is cut and nothing is dropped) or choose a larger step." %
            (axis, [float("%g" % t) for t in v], d, (lo, hi),
             [float("%g" % t) for t in want]))


def _assert_sparse_numbers(axis, ts, lo, hi, unit, data_ticks, zero=True):
    """v6 (E13): a sparse axis is DECLARED -- it may skip numbers, but each
    number it prints sits on a grid line and at least one is printed.

    C6 r5: a scale is read from TWO printed values. The origin's '0' is one
    of them when it prints; when it does not (origin=False, a hidden 0, or a
    window that does not hold the origin) a sparse axis must list two or more
    -- the floor numberline.NL(sparse=True) already holds. One lone number on
    an axis without its '0' gives the reader nothing to infer a scale from."""
    v = sorted(t for t in ts if t != 0 and lo - 1e-9 <= t <= hi + 1e-9)
    if not v:
        raise AssertionError(
            "figkit_plus.plane: the sparse %s-axis prints no number. An "
            "'infer the scale' axis still shows at least one value besides "
            "0; list it in %sticks=." % (axis, axis))
    if len(v) < 2 and not zero:
        raise AssertionError(
            "figkit_plus.plane: the sparse %s-axis prints one number (%g) and "
            "no '0' beside it -- a scale is inferred from two or more printed "
            "values. List a second value in %sticks= (or let the origin's 0 "
            "print)." % (axis, v[0], axis))
    if data_ticks:
        return
    for t in v:
        if abs(t / unit - round(t / unit)) > 1e-6:
            raise AssertionError(
                "figkit_plus.plane: %s-axis number %g is not on a grid line at "
                "%sscale=%g (pass data_ticks=True for data values)"
                % (axis, t, axis, unit))
    # stage-1 fix r1: a sparse list that is a REGULAR numbering with a few
    # values left out is no scale to infer -- it is an axis with a number
    # deleted (the author's rule 2). An author refused for the odd '-3' at
    # step=1 passed sparse=True with every value but -3 and the axis printed
    # -6..6 without it; the unprinted numbers are solved only every 2.
    pts = sorted(set(v + [0.0]))
    d = min(b - a for a, b in zip(pts, pts[1:])) if len(pts) > 1 else 0
    if d > 1e-9:
        want = [k * d for k in range(int(math.ceil(lo / d - 1e-9)),
                                     int(math.floor(hi / d + 1e-9)) + 1)
                if k != 0]
        miss = [w for w in want if all(abs(w - t) > 1e-6 for t in v)]
        if miss and 2 * len(v) > len(want):
            raise AssertionError(
                "figkit_plus.plane: the sparse %s-axis lists %d of the %d "
                "numbers of a step of %g and leaves out %s -- that is an axis "
                "numbered every %g with a number deleted, not a scale to "
                "infer (a number is never deleted). Number every value "
                "(xticks/yticks left to the step, sparse off) and let the "
                "engine move a crowded number aside, or give it room: a larger "
                "size= with a wider figure (max_width=), or step=2. A sparse "
                "axis lists at most half the values of its step."
                % (axis, len(v), len(want), d,
                   [float("%g" % w) for w in miss], d))


def _dot_entry(d):
    """dots= entry -> ((x, y), style or None). (x, y) is a plain dot;
    ((x, y), 'open') a marker (v6 C3, E8)."""
    if len(d) == 2 and isinstance(d[0], (tuple, list)):
        st = d[1]
        if st is not None and st not in figkit.MARKER_STYLES:
            raise AssertionError("figkit_plus.plane: dots style %r -- one of %s"
                                 % (st, figkit.MARKER_STYLES))
        return tuple(d[0]), st
    return tuple(d), None


def plane(xr, yr, polys=(), dpolys=(), solid=(), dashed=(), points=(), dots=(),
          right=(), circles=(), labels=(), values=(), xticks=None, yticks=None,
          step=None, size=16, font=12, width=None, max_width=SIDE_MAX,
          grid=True, ticks=True, axis_labels=("x", "y"), arcs=(), tickmarks=(),
          shaded=(), arrows=(), xscale=1, yscale=1, data_ticks=False,
          sketch=False, hide=(), sparse=False, origin=None, fam=None,
          curves=(), number_pt=None, axis_arrows=None):
    """A coordinate plane with shapes on it, drawn from the coordinates.

    xr, yr      integer ranges of the axes
    polys       closed shapes drawn solid, each a list of (x, y)
    dpolys      closed shapes drawn dashed — the image of a transformation, a
                bounding rectangle, a counter-example
    solid       extra solid segments (p, q) — an open path, a given side
    dashed      dashed segments — diagonals, altitudes, medians, mirror lines
    points      ((x, y), "A") — a dot plus a letter the placer positions; a
                point that is a vertex of a drawn shape is labelled away from it.
                v6 C3 (E8): ((x, y), "A", style) draws a MARKER, style one of
                "filled" | "open" | "tri" | "square" | "cross" (open = white
                disc, dark rim; half its extent >= 3.5pt printed; painted
                above every stroke). Name "" for a marker with no letter.
    dots        (x, y) — a plotted point with no letter; ((x, y), style) a
                marker
    right       (vertex, to1, to2) — a right-angle mark
    arcs        (vertex, to1, to2) or (..., n) — an angle arc, `n` strokes for
                the "these two angles are equal" marking
    tickmarks   ((p, q), n) or ((p, q), n, t) — n equality ticks across a side
                at fraction t (0.5), the standard way
                to say "these sides are equal" without writing a number. v6 C3
                (E5): sides sharing a count must measure the same as drawn
                (1.5%); (E9) ticks print at least 5pt long, 2.5pt apart
    right       (vertex, to1, to2): v6 C3 (E5) the angle as drawn is 90 +- 0.5
    shaded      a polygon filled a light grey — the region a question is about
                (the part of a figure whose area is asked for); the fill is too
                light to count as ink, so no label can be struck by it
    arrows      (p, q) — a segment with an arrowhead at q: a translation vector,
                a direction, a ray. v6 stage 1b: neither the head nor the
                shaft is ever cut -- the number moves, crosses its axis, steps
                out, or the figure is refused
    circles     ((cx, cy), r) or ((cx, cy), r, "4,3") for a dashed rim; r is in
                grid units, so a circle of radius 5 passes through the lattice
                points a distance 5 away. Refused on unequal scales (an
                ellipse); ((cx, cy), "open") is a marker and is not (E8)
    fam         v6 C3 (E10): tag the figure `<!--fam:NAME-->` (figkit.tag)
    labels      ((x, y), "text") or ((x, y), "text", prefer) — italic, for a
                line's name or equation
    values      the same, upright, for a length or an area on the drawing;
                v6 C3 (E24): ((x, y), "6", prefer, (p, q)) also binds the value
                to the segment p-q, which it must stay nearer than any other
                stroke by x1.5 (checked on the finished SVG)
    xticks /
    yticks      explicit tick lists; default is every `step` on both axes
    width       display width in px; None = the viewBox width capped at
                `max_width` so the drawing sits beside the text
    xscale /
    yscale      real units per grid square (a price axis where each square is
                5 shekels: yscale=5). Ranges, ticks and every coordinate stay in
                REAL units, so a figure is drawn from the same numbers the
                question prints; `step` counts squares. Circles need equal scales.
    data_ticks  allow axis numbers at data values (1.5, 4, 7.5) instead of a
                regular step
    sketch      a deliberately unnumbered picture. Without it both axes must
                carry regular numbers: a review found most figures on a slope
                sheet with an unnumbered axis, and they read as broken.
    hide        GONE (P3, the author's rule 2): every call RAISES. An axis
                number is never deleted. Hide the ANSWER by not marking it --
                the point out of points=/dots=, its trace out of dashed=, its
                number out of values= -- and ask for it in the Hebrew text.
                The parameter is kept so an old call fails loudly with that
                message instead of silently dropping a number.
    sparse      v6 (E13): an "infer the scale" axis -- marks at every `step`,
                numbers only at the values listed in xticks=/yticks=.
    origin      v6 (E6): '0' printed once, in a corner of the origin. None
                (the default) prints it when both axes print a number;
                True always, False never.

    curves      v6 stage 1b: named curves, each `(f, "name")` with f a callable
                y = f(x) sampled adaptively, or `(points, "name")` with points
                a list of (x, y). Clipped EXACTLY to the window (Liang-Barsky
                on the polyline) and emitted as ONE smooth path per piece; the
                name goes at a free end of the curve (a ring search around it,
                never on the curve). `(f, None)` draws it unnamed. See
                `intersections()` for the exact crossing points to dot.
    step        squares between numbers. None (the default) lets each axis
                choose (auto_step): every 2 where the axis is long enough,
                every 1 on a short one. An explicit number is honoured.

    v6 (E1): every axis number is PINNED to its tick (figkit.Figure.tick_label).
    v6 stage 1b (the author's rule of 2026-09-16): a data stroke -- a line, a
    polygon edge, a curve, a circle, an arc, an arrow -- is NEVER cut, broken,
    shortened or hidden by a number, and a number is never dropped. Only the
    light grid is knocked out under a number. A number a stroke reaches slides
    along its axis, crosses it, or steps a little out; if nothing frees it the
    figure is refused with a message naming fixes that keep both.

    number_pt   stage-1 fix r1 (PR3): the PRINTED size of the axis numbers, in
                pt; the drawing's font and pen are scaled together until the
                numbers print at it (strokes keep their ratio to the text).
                None takes the sheet's (new_sheet(number_pt=...)); with
                neither, the HOUSE size (P1, the author 2026-09-17): the
                numbers print at HOUSE["number_pt"] (8pt), the letters at
                9.5pt, the data strokes 1pt, the axes 0.8pt, the grid a
                visible 0.35pt grey, short 0.6pt tick marks, 2pt dots and
                2.4pt open markers -- whatever the width. One sheet, one
                look. new_sheet(house=False) restores the v6.0 behaviour
                (everything in proportion to width / viewBox).
    axis_arrows P1: arrowheads at the positive ends of both axes with the
                letters beside them (house look only). None = the sheet's
                (new_sheet(axis_arrows=...), on by default); False = off.

    Returns the SVG string, already re-swept for struck labels.
    """
    kw = dict(locals())
    _npt_floor(number_pt, "plane")
    _sparse_is_didactic(kw)
    _data_ticks_is_didactic(kw)
    # P1 (4): axis arrowheads -- None inherits the enclosing call (a hint
    # probe re-drawing this figure) or the sheet's setting
    on = axis_arrows if axis_arrows is not None else (
        _ARROWS[-1] if _ARROWS else SHEET["axis_arrows"])
    if not _ARROWS:
        _PINNED.clear()          # PERF: a new top-level figure
    _ARROWS.append(bool(on))
    _NPT.append(number_pt)
    try:
        try:
            svg = _fallback_hint(_plane_house_or_v60(kw, width), kw, width)
        except AssertionError as e:
            # P1 r2: a refused item figure whose hint found a width that
            # still fits an item (<= 150px) is drawn at it, as a fallback's
            # is (_fallback_hint) -- the same figure, a few px wider
            m = re.search(r"A WIDER figure does: width=([\d.]+) renders it "
                          r"\([\d.]+px: still an item figure", str(e))
            if not m or len(_ARROWS) > 1 or _PROBING or _HINTING or _SIZING \
                    or _FBHINT:
                raise
            w = float(m.group(1))
            svg = _plane_house_or_v60(dict(kw, width=w), w)
            if FALLBACK_TAG.split("%")[0] in svg:
                raise e
            svg = svg.replace(">", ">" + WIDENED_TAG % (
                "from=%g,to=%g" % (width, w)), 1)
        # P1 r2: the figure says it is a coordinate plane, so G78 reads it
        # however it is drawn -- axes that do not meet (a window without
        # 0), an unnumbered sketch with no tick marks
        if svgcheck.PLANE_TAG not in svg:
            svg = svg.replace(">", ">" + svgcheck.PLANE_TAG, 1)
        if sketch:
            # v6.7-noam r1 (C-R2-Q15B/Q14-SKETCH): an unnumbered sketch says
            # so in its export -- its coordinates give the SHAPE, not sizes
            # the question states, so Noam AI must not read lengths or an
            # area off them
            _r = _export_rec.lookup(svg)
            _ob = getattr(_r, "objects", None)
            if _ob is not None and isinstance(getattr(_ob, "view", None),
                                              dict):
                _ob.view["sketch"] = True
        return svg
    finally:
        _ARROWS.pop()
        _NPT.pop()


_FBHINT = []             # P1 r1: a fallback's width probe is in progress
_PINNED = {}             # P1 r1 PERF: figure key -> steps refused when pinned
ITEM_MAX_PX = 150.0      # emit_plus.ITEM_FIG_MAX (not imported: emit_plus
                         # imports this module)


def _fallback_hint(svg, kw, width):
    """P1 r1: a narrow figure that fell back is told WHICH width prints it in
    the house look -- the next widths up to an item figure's 150px, then the
    side column's 180px -- tried in that order, at most six renders, the
    first that renders with no fallback named in its tag. G78 reads the tag,
    so its refusal names a width that renders, not 'more room'."""
    if _FBHINT or width is None or FALLBACK_TAG.split("%")[0] not in svg:
        return svg
    tries = sorted(set([w for w in (width + 6, width + 12, width + 20, 140.0,
                                    ITEM_MAX_PX) if width < w <= ITEM_MAX_PX]
                       + [HOUSE["narrow_px"]]))[-6:]
    found, found_svg = "none", None
    _FBHINT.append(1)
    saved = HOUSE_FALLBACKS[:]
    try:
        for w in tries:
            try:
                out = plane(**dict(kw, width=w))
            except AssertionError:
                continue
            if FALLBACK_TAG.split("%")[0] not in out:
                found, found_svg = "%g" % w, out
                break
    finally:
        _FBHINT.pop()
        HOUSE_FALLBACKS[:] = saved
    if found_svg is not None and float(found) <= ITEM_MAX_PX:
        # P1 r2 (z08a-broken-by-G78): a width that prints the house look
        # and still fits an item figure (<= 150px) is TAKEN, not only named.
        # G78 refused the shipped z08_a for item figures at 148/140/124px
        # whose house render was 150/150/130px away; every level with a
        # narrow item plane broke until someone edited its widths by hand.
        # The figure grows by at most a few px within the item's own limit;
        # past 150px it stays a fallback and G78 names the move.
        HOUSE_FALLBACKS[:] = [r for r in HOUSE_FALLBACKS
                              if r.get("width") != width]
        return found_svg.replace(">", ">" + WIDENED_TAG % (
            "from=%g,to=%s" % (width, found)), 1)
    for r in HOUSE_FALLBACKS:
        if r.get("width") == width:
            r["renders_at"] = found
    return re.sub(r"<!--house-fallback:([^>]*?)-->",
                  lambda m: "<!--house-fallback:%s,renders_at=%s-->"
                  % (m.group(1), found), svg, count=1)


def _plane_house_or_v60(kw, width):
    """plane() at the sheet look; a narrow item figure with no room for it
    falls back to the v6.0 look (tagged, listed)."""
    try:
        return _plane_top(**kw)
    except AssertionError as e:
        # P1 backward compatibility: an ITEM figure a level sized narrower
        # than the side column (width=140 beside a sub-item) that has no
        # room for the house look at all -- 8pt numbers, a 5pt arrowhead
        # and its letter take a third of 105pt -- is drawn as v6.0 drew
        # it, and listed in HOUSE_FALLBACKS for the gate and the author.
        if not (SHEET.get("house") and width is not None
                and width < HOUSE["narrow_px"] and not _PROBING
                and not _HINTING and not _SIZING and not _FBHINT):
            raise
        SHEET["house"] = False
        try:
            svg = _plane_top(**kw)
        except AssertionError:
            raise e
        finally:
            SHEET["house"] = True
        # P1 r2: the target is the sheet's (or the call's) size -- on
        # new_sheet(number_pt=7) the tag said target=8.0 and G78 quoted it
        tgt = kw.get("number_pt") or SHEET.get("number_pt") or HOUSE["number_pt"]
        return _fallback(svg, dict(target=float(tgt), got=round(
            printed_number_pt(svg) or 0.0, 2), width=width, look="v6.0"))


def _plane_top(xr, yr, polys=(), dpolys=(), solid=(), dashed=(), points=(),
               dots=(), right=(), circles=(), labels=(), values=(), xticks=None,
               yticks=None, step=None, size=16, font=12, width=None,
               max_width=SIDE_MAX, grid=True, ticks=True,
               axis_labels=("x", "y"), arcs=(), tickmarks=(), shaded=(),
               arrows=(), xscale=1, yscale=1, data_ticks=False, sketch=False,
               hide=(), sparse=False, origin=None, fam=None, curves=(),
               number_pt=None, axis_arrows=None):

    target = number_pt if number_pt is not None else SHEET.get("number_pt")
    if target is None and SHEET.get("house"):
        target = HOUSE["number_pt"]
    # P1: the house look sizes the font and the printed scale PER RUNG of
    # the ladder below (_house_rung): sizing the whole ladder from outside
    # oscillated, because the rung the ladder settles on changes with the
    # font and with the stroke sizes, and each rung prints at another scale
    house_t = float(target) if (target and SHEET.get("house")) else None
    if target and not _SIZING and house_t is None:
        kw = dict(locals())
        for k in ("target", "number_pt", "house_t"):
            kw.pop(k, None)
        return _plane_at_pt(float(target), kw)
    # Enlarge the labels BEFORE the drawing shrinks, so the tick numbers still
    # clear MIN_PT, and if the estimate was optimistic, try again bigger.
    #
    # coord_plane computes this once, from the x-range alone, and lets
    # `verify()` refuse the result — at which point the author's cheapest fix is
    # to delete ticks, which is the wrong outcome. The estimate cannot be exact:
    # the viewBox is only known after the labels are placed, and a tall drawing
    # scales by its height. So estimate, then LOOP: `verify()` still decides,
    # and nothing here weakens it.
    # v6 stage 1b (the author's rule 5): when a number still has nowhere to go,
    # the figure is not refused until the two tiers that keep every number AND
    # every stroke have been tried -- an automatic step of 2 squares instead of
    # 1, and then bigger squares (up to what max_width can print). Only then
    # does the refusal reach the author, naming the fixes.
    _check_window(xr, yr, step, polys, dpolys, solid, dashed, points, dots,
                  circles, arrows, xscale, yscale)
    first, tried = None, []
    # PERF (P1 r1): shared by every _plane_top of ONE plane() call (a hint
    # probe tries each size in its own call), keyed by the figure but size
    pkey = repr((xr, yr, polys, dpolys, solid, dashed, points, dots, right,
                 circles, labels, values, xticks, yticks, step, width,
                 max_width, grid, ticks, axis_labels, arcs, tickmarks, shaded,
                 arrows, xscale, yscale, data_ticks, sketch, hide, sparse,
                 origin, curves, _ARROWS[-1:], _NPT[-1:], _PEN_SCALE[0]))
    pinned_refused = _PINNED.setdefault(pkey, set())
    rungs = _ladder(xr, yr, step, size, max_width, width)
    if sketch and not grid:
        # C6 r6: a sketch with no grid has no square floor, so the bigger
        # rungs (which shrink the squares) drew 8 of 22 figures refused for a
        # NUMBER with no numbers at all. The rungs exist to give printed
        # numbers room; a sketch is solved as drawn, at the size asked for.
        rungs = [r for r in rungs if r[1] == size]
    last_pin = {}
    for tier, (tstep, tsize) in enumerate(rungs):
        if house_t and tstep in pinned_refused and \
                tsize < last_pin.get(tstep, 0) * _PIN_SAMPLE and tier < len(rungs) - 1:
            # PERF (P1 r2): a pinned rung prints the figure of the pinned
            # rung before it; once refused, the next pinned rungs of that
            # step are sampled >= 15% apart (the ladder went on to 3.5x)
            continue
        tried.append((tstep, tsize))
        def att(fnt, tstep=tstep, tsize=tsize):
            return _attempts(xr, yr, polys, dpolys, solid, dashed, points,
                             dots, right, circles, labels, values, xticks,
                             yticks, tstep, tsize, fnt, width, max_width,
                             grid, ticks, axis_labels, arcs, tickmarks,
                             shaded, arrows, xscale, yscale, data_ticks,
                             sketch, hide, sparse, origin, fam, curves,
                             # C6 r5: a rung that grew the squares keeps the
                             # PRINTED pen of the figure as asked
                             pen=float(tsize) / size * _PEN_SCALE[0])
        try:
            if house_t:
                # PERF (P1 r1): a rung whose display width is pinned (width=
                # or max_width reached) prints the same figure as the pinned
                # rung before it, one size up; once such a rung was refused,
                # the next is tried at its first font only -- the step-downs
                # cost 18 renders a call on a -20..20 plane
                est = (((xr[1] - xr[0]) / float(xscale or 1) + 1.1) * tsize
                       + 64.0)
                pinned = width is not None or est >= (max_width or SIDE_MAX)
                return _house_rung(house_t, att, xr, xscale, tsize, width,
                                   max_width, down=(
                                       0 if pinned and tsize > 2.01 * size
                                       else 1 if (pinned and tstep in
                                                  pinned_refused)
                                       else None))
            return att(font)
        except AssertionError as e:
            # v6 stage 1b r2: the CLASS says whether a bigger drawing could
            # cure it. Matching on a phrase ("Do NOT drop the number") meant
            # every refusal svgcheck raised off the finished file -- a number
            # driven off its tick, a struck label, two numbers that read as
            # one -- stopped the ladder at its first rung, though a later
            # rung rendered the same figure cleanly.
            layout = (isinstance(e, svgcheck.LayoutError)
                      or "Do NOT drop the number" in str(e))
            if house_t and layout:
                est = (((xr[1] - xr[0]) / float(xscale or 1) + 1.1) * tsize
                       + 64.0)
                if width is not None or est >= (max_width or SIDE_MAX):
                    pinned_refused.add(tstep)
                    last_pin[tstep] = tsize
            if _PROBING or (not layout and first is None):
                raise
            # C6 r5: a LATER rung's own refusal (a bigger square's labels
            # widen the figure until a grid square prints under 10px) is that
            # rung failing, not the figure: it used to escape the ladder and
            # replace the refusal of the figure as asked -- a triangle on
            # -10..10 was told to 'show fewer squares' instead of which
            # number had no room, and never reached the wider-figure probe.
            if not layout:
                continue
            # C6 r4: the refusal reported is the one for the figure AS ASKED
            # (the first rung), not whatever the last, biggest rung tripped on
            first = first or e
    if first is None:
        raise AssertionError("figkit_plus.plane: unreachable")
    # v6 stage 1b r3: say what the ladder ALREADY turned. The refusal lists
    # the knobs that make room -- a step of 2 squares, a larger size=, a
    # wider figure -- and plane() has just tried them all; an author who
    # reads "a larger size=" and answers it with size=23 gets the same
    # refusal back and concludes the engine is broken. Naming the rungs
    # leaves only the fixes that are still his: the data, the window, the
    # letters.
    # C6 r4: and name the ONE knob it may not turn by itself -- a wider
    # figure. Measured over 19 axis-number refusals, "a larger size=" alone
    # cured 6 and was not monotonic (size=16 refused, 20 and 24 drew, 32
    # refused), while size=24 WITH max_width=420 cured 18. So the wider
    # figure is probed here, and the message prints the exact call that
    # renders -- or says that none does, and only then turns the author to
    # the figure itself.
    steps = sorted(set(s for s, _ in tried if s))
    knobs = ", ".join(
        (["step=%s" % "/".join(str(s) for s in steps)] if steps else [])
        + ["size=" + "/".join(str(z) for z in sorted(set(z for _, z in tried)))])
    if _HINTING:
        raise first
    wider = _wider_hint(dict(
        xr=xr, yr=yr, polys=polys, dpolys=dpolys, solid=solid, dashed=dashed,
        points=points, dots=dots, right=right, circles=circles, labels=labels,
        values=values, xticks=xticks, yticks=yticks, step=step, font=font,
        grid=grid, ticks=ticks, axis_labels=axis_labels, arcs=arcs,
        tickmarks=tickmarks, shaded=shaded, arrows=arrows, xscale=xscale,
        yscale=yscale, data_ticks=data_ticks, sketch=sketch, hide=hide,
        sparse=sparse, origin=origin, fam=fam, curves=curves),
        [z for _, z in tried], max_width, width)
    first = _checked_stretch(first, dict(
        xr=xr, yr=yr, polys=polys, dpolys=dpolys, solid=solid, dashed=dashed,
        points=points, dots=dots, right=right, circles=circles, labels=labels,
        values=values, xticks=xticks, yticks=yticks, step=step, font=font,
        grid=grid, ticks=ticks, axis_labels=axis_labels, arcs=arcs,
        tickmarks=tickmarks, shaded=shaded, arrows=arrows, xscale=xscale,
        yscale=yscale, data_ticks=data_ticks, sketch=sketch, hide=hide,
        sparse=sparse, origin=origin, fam=fam, curves=curves))
    first = _checked_even(first, dict(
        xr=xr, yr=yr, polys=polys, dpolys=dpolys, solid=solid, dashed=dashed,
        points=points, dots=dots, right=right, circles=circles, labels=labels,
        values=values, xticks=xticks, yticks=yticks, font=font,
        grid=grid, ticks=ticks, axis_labels=axis_labels, arcs=arcs,
        tickmarks=tickmarks, shaded=shaded, arrows=arrows, xscale=xscale,
        yscale=yscale, data_ticks=data_ticks, sketch=sketch, hide=hide,
        sparse=sparse, origin=origin, fam=fam, curves=curves),
        steps, size, width, max_width)
    # C6 r6: the fixes that remain are the author's, and they never move the
    # data. "a shape moved off the axes" and "the point's letter placed by
    # hand" were offered on every refusal -- the first redraws the question,
    # the second when no letter was involved, with no argument that does it.
    # P3 leftovers r1: name a call that RENDERS, probed -- not "a window
    # with fewer squares", which never rendered these figures and is itself
    # refused when the data fills the window.
    # ... and only when the ladder has NOT already found a nearer call that
    # renders: a message that names width=180 should not also send the
    # author to the full page.
    last = "" if wider else _last_resort(dict(
        xr=xr, yr=yr, polys=polys, dpolys=dpolys, solid=solid, dashed=dashed,
        points=points, dots=dots, right=right, circles=circles, labels=labels,
        values=values, xticks=xticks, yticks=yticks, step=step, font=font,
        grid=grid, ticks=ticks, axis_labels=axis_labels, arcs=arcs,
        tickmarks=tickmarks, shaded=shaded, arrows=arrows, xscale=xscale,
        yscale=yscale, data_ticks=data_ticks, sketch=sketch, hide=hide,
        sparse=sparse, origin=origin, fam=fam, curves=curves),
        max_width, width)
    rest = [last] if last else [
        _fewer_objects_helps(dict(
            xr=xr, yr=yr, step=step, size=size, font=font, grid=grid,
            ticks=ticks, axis_labels=axis_labels, xticks=xticks,
            yticks=yticks, xscale=xscale, yscale=yscale, origin=origin,
            sketch=sketch, sparse=sparse, data_ticks=data_ticks), width,
            max_width)]
    if any(len(p) > 1 and p[1] for p in points) and "letter" in str(first):
        rest.append("a letter placed by hand: the point in dots=[p] and "
                    "its letter in labels=[(p, 'A', (dx, dy))]")
    rest = " or ".join(rest)
    # stage-1 fix r1: the knobs the ladder has just turned are not printed as
    # fixes above the line that says they were tried
    if house_t:
        # P1 r2 (L3-04): at the house look the numbers print at house_t pt
        # whatever size= is -- they are scaled with the squares -- so 'a
        # larger size=' never parts them at a fixed width: size=20/26/34/50
        # at width=130 were all refused and a builder raised size= until he
        # gave up. The wider figure and the step remain.
        t2 = re.sub(r"a larger size=(?: \(ticks are \d+ units apart for "
                    r"numbers \d+ units wide\))?, ", "", str(first))
        t2 = t2.replace("a larger size= or a wider figure (width=)",
                        "a wider figure (width=)")
        if t2 != str(first):
            first = type(first)(t2)
    if len(set(z for _, z in tried)) > 1:
        cls = type(first)
        t = str(first)
        for a in ("a larger size= or a wider figure (width=), ",
                  "a larger size= or a wider figure (width=)",
                  "enlarge the figure (size= / width=), "):
            t = t.replace(a, "")
        first = cls(t)
    # v6.2 Q1 r1: same crash as in _wider_hint -- a call that named neither
    # width= nor max_width= reached these messages with None in a %g
    shown = width or max_width or WIDE_MAX
    # v6.2 Q1 r1 (letter-refusal-names-an-impossible-width / pilot-refusal-
    # route): an ITEM figure is capped at 150px by emit_plus, so a refusal
    # whose headline fix is "width=180" sends the author into a hard
    # AssertionError ("item figure is 180px wide, over the 150 limit"), then
    # a second rebuild at 150, and only then does G78 name the two routes
    # that actually work. Three build cycles and two wrong turns for a fix
    # that was never available. Name those routes here, probed, so the FIRST
    # message the author reads names something that renders at an item width.
    item = _item_route(dict(
        xr=xr, yr=yr, polys=polys, dpolys=dpolys, solid=solid, dashed=dashed,
        points=points, dots=dots, right=right, circles=circles, labels=labels,
        values=values, xticks=xticks, yticks=yticks, font=font,
        grid=grid, ticks=ticks, axis_labels=axis_labels, arcs=arcs,
        tickmarks=tickmarks, shaded=shaded, arrows=arrows, xscale=xscale,
        yscale=yscale, data_ticks=data_ticks, sketch=sketch, hide=hide,
        sparse=sparse, origin=origin, fam=fam, curves=curves),
        [z for _, z in tried], step, width, wider)
    if wider:
        raise svgcheck.LayoutError(
            "%s\nfigkit_plus.plane already tried %s within max_width=%g and "
            "did not find room. A WIDER figure does: %s renders it%s with "
            "every number and every stroke.%s Otherwise change the FIGURE "
            "around the data, never the data: %s."
            % (first, knobs, shown, wider, _wider_note(wider), item,
               rest))
    # v6.2 Q1 r1 (L3-01): before sending the author to the FIGURE -- which
    # means splitting the item, i.e. taking the drawing apart -- try the
    # sizes the message is about to claim were tried, as the author's own
    # call would make them
    plain = _explicit_size_route(dict(
        xr=xr, yr=yr, polys=polys, dpolys=dpolys, solid=solid, dashed=dashed,
        points=points, dots=dots, right=right, circles=circles, labels=labels,
        values=values, xticks=xticks, yticks=yticks, step=step, font=font,
        grid=grid, ticks=ticks, axis_labels=axis_labels, arcs=arcs,
        tickmarks=tickmarks, shaded=shaded, arrows=arrows, xscale=xscale,
        yscale=yscale, data_ticks=data_ticks, sketch=sketch, hide=hide,
        sparse=sparse, origin=origin, fam=fam, curves=curves),
        [z for _, z in tried], width, max_width,
        on=bool(arcs) or "figkit.arc" in str(first))
    if plain:
        raise svgcheck.LayoutError(
            "%s\nfigkit_plus.plane's own ladder (%s within max_width=%g) did "
            "not find room, but %s. Nothing is dropped and nothing is split."
            % (first, knobs, shown, plain))
    raise svgcheck.LayoutError(
        "%s\nfigkit_plus.plane already tried %s within max_width=%g, and a "
        "full-width figure (max_width=%g) at those sizes did not find room "
        "either -- so change the FIGURE, not these knobs, and never the "
        "data: %s."
        % (first, knobs, shown, max(WIDE_MAX, shown), rest))


SHEET = {"number_pt": None, "house": True, "axis_arrows": True}
_SIZING = []
_PEN_SCALE = [1.0]
_DEBUG = False
_HOUSE_U = [None]        # P1: figure units per printed pt while house-sizing
_TARGET = []             # P1: the printed number size being sized for
_NPT = []                # P1: the number_pt= of the plane() call in progress
_ARROWS = []             # P1: axis arrowheads on/off for the call in progress
# P1 (the author, 2026-09-17, comparing v6.0 with Typst): ONE printed look for
# every plane on a sheet, in pt. v6.0 printed a 9 cm plane's numbers at 15.4pt
# and its strokes at 2.3pt, the same plane beside the text at 7.8pt: the size
# followed the width. These are the Typst/LaTeX sizes the author chose.
HOUSE = dict(
    number_pt=8.0,       # axis numbers
    letter_pt=9.5,       # point names, axis letters, curve names
    main_pt=1.0,         # data strokes: polygon edges, segments, curves, arrows
    dashed_pt=0.8, dash_on_pt=3.0, dash_off_pt=2.0,
    axis_pt=0.8,         # the axes
    grid_pt=0.35,        # the grid (svgcheck.GRID_GREY)
    tick_half_pt=2.2,    # half a tick mark (4.4pt across the axis)
    tick_pt=0.6,         # a tick mark's stroke
    tick_gap_pt=1.4,     # tick end to number
    dot_pt=2.0,          # a plotted point / filled marker, radius
    open_pt=2.4,         # an open (white) marker, half extent
    marker_pt=0.8,       # a marker's rim
    head_pt=5.0, head_deg=20.0,    # axis arrowheads (filled)
    arrow_head_pt=5.0,   # a data arrow's barbs
    mark_pt=0.9,         # P1 r1: right-angle marks, angle arcs, equality ticks
    narrow_px=180.0,     # an explicit width= under this may fall back (>= 7pt)
)
HOUSE_TOL_PT = 0.35      # a house render's numbers within this of target. P1 r2:
                         # 0.25 refused gallery figures that print 7.68pt at
                         # width=200; the 7.34-vs-7.00 mix at number_pt=7 was
                         # the font clamp in _plane, now off at the house look
HOUSE_FALLBACKS = []     # P1: narrow figures printed under the house size
FALLBACK_TAG = "<!--house-fallback:%s-->"   # P1 r1: read by G78 (gate_variety)
WIDENED_TAG = "<!--house-widened:%s-->"     # P1 r2: an item width taken up to 150px


def _npt_floor(number_pt, where):
    """P1 r1: number_pt under the 7pt floor is refused AT ONCE. It was sized
    for: the refusal came after the ladder and its hint probes (310s at sheet
    level) and named 'a larger width= or a window with fewer squares' --
    fixes that make the numbers BIGGER."""
    if number_pt is not None and float(number_pt) < MIN_PT - 1e-9:
        raise AssertionError(
            "figkit_plus.%s: number_pt=%g is under the %gpt floor a printed "
            "number may not go below -- no figure prints it. Use number_pt=%g "
            "or more, or leave it out for the house %gpt."
            % (where, float(number_pt), MIN_PT, MIN_PT, HOUSE["number_pt"]))


def _fallback(svg, rec):
    """P1 r1: record a narrow figure printed under the house look -- once per
    figure (a level's retry loop logged each five times) -- and tag the SVG
    so the sheet gate G78 sees it in the finished figure, whatever process
    or sheet built it."""
    strip = lambda r: {k: v for k, v in r.items() if k != "renders_at"}
    if strip(rec) not in [strip(r) for r in HOUSE_FALLBACKS]:
        HOUSE_FALLBACKS.append(rec)
    body = ",".join("%s=%s" % (k, rec[k]) for k in sorted(rec))
    return svg.replace(">", ">" + FALLBACK_TAG % body, 1)


def new_sheet(number_pt=None, house=True, axis_arrows=True):
    """Stage-1 fix r1 (PR3, doctrine 6): one printed size for the axis
    numbers of every plane()/wide() on the sheet, as numberline holds one
    TICK_PT on every tier. Planes printed their text and strokes in
    proportion to width / viewBox, so one sheet mixed 16.7pt numbers (F4 at
    9 cm) with 7.8pt ones (a side figure); a shipped level wrapped plane() in
    its own re-run loop to get 7.6pt. new_sheet(number_pt=7.6) sets it for
    every later figure; new_sheet() clears it.

    P1: with number_pt=None the sheet prints at the HOUSE sizes (8pt
    numbers, 1pt strokes ...); house=False restores v6.0's width-following
    look; axis_arrows=False drops the axis arrowheads on every plane."""
    _npt_floor(number_pt, "new_sheet")
    SHEET["number_pt"] = number_pt
    SHEET["house"] = bool(house)
    # P1 r1: a sheet's records start empty -- they piled up across sheets
    # built in one process, and G78 reads the figures themselves
    del HOUSE_FALLBACKS[:]
    SHEET["axis_arrows"] = bool(axis_arrows)
    _sheet_to_numberline(number_pt)


def _sheet_to_numberline(number_pt):
    """Stage review (the author, 2026-09-18): ONE look per sheet, on every
    figure kind. new_sheet(number_pt=8.0) used to leave the sheet's number
    lines at numberline's own 7.5pt, so a plane above a number line printed
    two sizes and G78 -- which only reads coordinate planes -- passed. The
    number line's own sheet is set here, without touching its arrows."""
    try:
        import numberline as _N
    except Exception:                                       # pragma: no cover
        return
    tick_pt = float(number_pt) if number_pt else HOUSE["number_pt"]
    _N._SHEET.update(tick_pt=tick_pt, lines=0)


def house_text_pt(key="number_pt"):
    """Stage review: the printed pt a sheet's TEXT of kind `key` prints at --
    HOUSE, moved with the sheet's own number size (new_sheet(number_pt=7.6)
    prints the letters in proportion, as plane() already did). Strokes are
    not scaled: a 1pt line is a 1pt line whatever the numbers print at.

    Every figure kind reads its sizes here, so "one look per sheet" is one
    number in one place instead of a constant per module (numberline printed
    7.5pt numbers beside a plane's 8.0pt ones until this landed)."""
    tgt = float(SHEET.get("number_pt") or HOUSE["number_pt"])
    return HOUSE[key] * tgt / HOUSE["number_pt"]


def printed_number_pt(svg):
    """The printed size (pt) of a figure's axis numbers, read off the SVG:
    the median font-size of its numeric texts x display / viewBox x 0.75."""
    w = re.search(r'<svg[^>]*\bwidth="([\d.]+)', svg)
    vb = re.search(r'viewBox="[-\d.]+ [-\d.]+ ([\d.]+)', svg)
    fs = sorted(float(m.group(1)) for m in re.finditer(
        r'<text[^>]*font-size="([\d.]+)"[^>]*>[\-\u2212]?\d+(?:\.\d+)?</text>',
        svg))
    if not (w and vb and fs):
        return None
    return fs[len(fs) // 2] * float(w.group(1)) / float(vb.group(1)) * 0.75


def printed_letter_pt(svg):
    """Stage review: the printed size (pt) of a figure's LETTERS -- point
    names, axis letters, curve and shape names -- the median font-size of
    every text that is not a bare number. A figure kind with no axis numbers
    at all (a triangle with vertices A, B, C) is judged on these, so that
    "one look per sheet" is not only a rule about coordinate planes."""
    w = re.search(r'<svg[^>]*\bwidth="([\d.]+)', svg)
    vb = re.search(r'viewBox="[-\d.]+ [-\d.]+ ([\d.]+)', svg)
    fs = []
    for m in re.finditer(r'<text([^>]*)font-size="([\d.]+)"[^>]*>(.*?)</text>',
                         svg, re.S):
        body = re.sub(r"<[^>]*>", "", m.group(3)).strip()
        # v6.1: class="value" is a values= text. The engine prints it at the
        # AXIS NUMBERS' size on purpose, so counting a non-numeric one
        # ('x > 0', '3 cm') among the letters made a figure report letters at
        # the number size and G78 refused a sheet the engine itself drew.
        if 'class="value"' in m.group(1):
            continue
        # '?' and '_' stand IN FOR a number (a hidden value on a double
        # line, a blank to fill in) and print at the number size.
        # (v6.16 fix r1, D-R2-G78) a pie's VALUE label '24%' is a number too
        # (the pie prints its values at the number size, its names at the
        # letter size): '°?' -> '[°%]?', or every names-none pie reads as
        # letters at 8.0 pt beside 9.5 pt names and G78 refuses G8-T30
        if body and not re.fullmatch(
                r"(?:[\-−+]?\d+(?:[.,]\d+)?[°%]?|[?_□])", body):
            fs.append(float(m.group(2)))
    fs.sort()
    if not (w and vb and fs):
        return None
    return fs[len(fs) // 2] * float(w.group(1)) / float(vb.group(1)) * 0.75


def _printed_scale(svg):
    """pt per figure unit of a finished SVG (display / viewBox x 0.75)."""
    w = re.search(r'<svg[^>]*\bwidth="([\d.]+)', svg)
    vb = re.search(r'viewBox="[-\d.]+ [-\d.]+ ([\d.]+)', svg)
    return float(w.group(1)) / float(vb.group(1)) * 0.75 if w and vb else None


def _plane_at_pt(target, kw):
    """plane() with its font and pen scaled until the numbers print at
    `target` pt (within 0.1pt), new_sheet(house=False) only (the house look
    sizes each rung, _house_rung). The pen follows the font (pen = font /
    12), so a figure scaled for its text keeps strokes in the default ratio
    to it. The closest render is kept; one more than 0.35pt off is refused."""
    _TARGET.append(target)
    try:
        return _legacy_at_pt(target, kw)
    finally:
        _TARGET.pop()


def _legacy_at_pt(target, kw):
    font = float(kw.get("font") or 12)
    best, first_err = None, None
    _SIZING.append(1)
    try:
        for _ in range(8):
            _PEN_SCALE[0] = font / 12.0
            kw["font"] = font
            try:
                svg = plane(**kw)
            except AssertionError as e:
                first_err = first_err or e
                if best is None:
                    raise
                font = 0.5 * (font + best[2])      # back toward what rendered
                continue
            got = printed_number_pt(svg)
            if got is None:
                return svg
            if best is None or abs(got - target) < abs(best[0] - target):
                best = (got, svg, font)
            if abs(got - target) <= 0.1:
                break
            font *= (target / got) ** 1.3
    finally:
        _SIZING.pop()
        _PEN_SCALE[0] = 1.0
    if abs(best[0] - target) > 0.35:
        raise AssertionError(
            "figkit_plus.plane: the axis numbers print at %.1fpt at best and "
            "no font brings them to number_pt=%g within this figure%s -- give "
            "it a larger width= (or max_width=), bigger squares (size=) or "
            "a coarser numbering (step=2)"
            % (best[0], target, (" (a larger font was refused: %s)"
                                 % str(first_err).split("\n")[0][:160])
                                if first_err else ""))
    return best[1]


_STEPS = (1.0, 0.88, 0.7744, 0.6815, 0.5997)   # a rung's font step-downs (x0.88)


def _house_rung(target, draw, xr, xscale, size, width, max_width, down=None):
    """P1: one rung of plane()'s ladder at the house look. `draw(font)`
    renders the rung; this finds the font whose numbers print at `target` pt
    AND the printed scale `u` (figure units per pt) the strokes, ticks, dots
    and markers are drawn for, and returns that render.

    The rung is fixed, so the printed scale moves only a little with the font
    (labels widen the viewBox): u is taken from each render, the font is
    corrected by the printed size and kept inside the bracket of fonts known
    to print small / large / to be refused. A render is accepted when its
    numbers are within 0.35pt of target and it was drawn for its own scale
    (3%). When the rung renders only at a smaller size it is REFUSED with the
    layout refusal of the nearest larger font, so the ladder climbs on and
    the author reads the refusal that names the room -- never a figure whose
    numbers quietly follow its width."""
    est = ((xr[1] - xr[0]) / float(xscale or 1) + 1.1) * size + 64.0
    disp = float(width or min(est, max_width or SIDE_MAX))
    sc = disp / est * _PX_TO_PT
    u, font = 1.0 / sc, target / (0.92 * sc)
    best = None                  # (got, svg, font, err, u_ok)
    first_err, errs = None, []
    lo = hi = bad = None
    narrow = width is not None and width < HOUSE["narrow_px"]
    _TARGET_PT.append(target)
    try:
        for i in range(14):
            _HOUSE_U[0] = u
            _PEN_SCALE[0] = 1.0
            try:
                svg = draw(font)
            except AssertionError as e:
                first_err = first_err or e
                errs.append((font, e))
                if best is None:
                    # the first guess from the squares alone can over-size
                    # a narrow plane's font: step down before refusing
                    # PERF (P1 r1): only as far down as a render could
                    # still be accepted -- two steps for the estimate's own
                    # error, three for a narrow item figure's 7pt fallback.
                    # Stepping on to 3pt cost 7 renders a rung, 60+ a call
                    if i >= (down if down is not None else
                             3 if narrow else 2):
                        raise first_err
                    f0 = font / _STEPS[i] if i < len(_STEPS) else font
                    font = f0 * _STEPS[i + 1]
                    u = u / _STEPS[i] * _STEPS[i + 1]
                    continue
                bad = font if bad is None else min(bad, font)
                if abs(font - best[2]) <= 0.01 * best[2]:
                    # refused at the font that rendered, once drawn for its
                    # own scale: the room is smaller than that font needs
                    if lo is not None and font * 0.94 <= lo:
                        break
                    font *= 0.94
                    continue
                font = 0.5 * (font + best[2])
                continue
            u_meas = 1.0 / _printed_scale(svg)
            err_u = abs(u_meas - u) / u_meas
            u_ok = err_u <= 0.03
            got = printed_number_pt(svg)
            if got is None:
                # stage review: a figure with NO axis numbers (a sketch
                # plane, ticks=False) had nothing to size against, so the
                # loop accepted its first guess and its LETTERS printed at
                # whatever the width gave -- z08_a's item sketches at 8.4pt
                # beside the sheet's 9.5pt. Its letters are measured instead,
                # converted to the number size this loop works in.
                let = printed_letter_pt(svg)
                if let:
                    got = let * HOUSE["number_pt"] / HOUSE["letter_pt"]
            g = target if got is None else got
            err = abs(g - target)
            if _DEBUG:
                print("  " * len(_NPT) + "rung size=%s font=%.2f u=%.3f/%.3f got=%s"
                      % (size, font, u, u_meas, got))
            if best is None or (u_ok, -err) > (best[4], -best[3]):
                best = (g, svg, font, err, u_ok, err_u)
            if err <= 0.1 and u_ok:
                break
            if not u_ok:
                # draw for the scale it prints at, with the font corrected by
                # the size it printed; only a render drawn for its own scale
                # moves the bracket (re-drawing the SAME font at the new scale
                # first fell into a refusal pocket the corrected font clears)
                u = u_meas
                if err > 0.1:
                    font = font * (target / g) ** 1.3
                    if bad is not None and font >= bad:
                        font = 0.5 * (best[2] + bad)
                continue
            if g < target:
                lo = font if lo is None else max(lo, font)
            else:
                hi = font if hi is None else min(hi, font)
            new = font * (target / g) ** 1.3
            top = min([v for v in (hi, bad) if v is not None] or [None]) \
                if (hi is not None or bad is not None) else None
            if lo is not None and top is not None:
                if top - lo <= 0.005 * lo:
                    break
                if not (lo < new < top):
                    new = 0.5 * (lo + top)
            elif top is not None and new >= top:
                new = 0.5 * (font + top) if font < top else font * 0.95
            font = new
    finally:
        _TARGET_PT.pop()
        _HOUSE_U[0] = None
        _PEN_SCALE[0] = 1.0
    if best is not None and best[3] <= HOUSE_TOL_PT and best[4]:
        return best[1]
    if best is not None and best[5] <= 0.12 and width is not None and \
            width < HOUSE["narrow_px"] and MIN_PT - 0.05 <= best[0] < target:
        # an ITEM figure the author sized narrower than the side column
        # (width=148 beside a sub-item) with no room for 8pt numbers: the
        # nearest size that renders, never under the 7pt floor, and the
        # sheet is told (HOUSE_FALLBACKS) so a gate or the author can see
        # it. Levels built before the house look drew these at 7.2-7.6pt.
        return _fallback(best[1], dict(target=target, got=round(best[0], 2),
                                       width=width, look="house"))
    above = sorted([fe for fe in errs if best is None or fe[0] > best[2]],
                   key=lambda fe: fe[0])
    e = above[0][1] if above else first_err
    note = ("\n(P1 house look: the axis numbers print at %gpt on every plane; "
            "this figure fits them only at %.1fpt. A wider figure, bigger "
            "squares (size=) or a coarser numbering (step=2) gives them room; "
            "new_sheet(number_pt=...) "
            "sets another size for the whole sheet.)" % (target, best[0])
            if best is not None else "")
    if e is not None:
        raise type(e)("%s%s" % (e, note))
    raise svgcheck.LayoutError(
        "figkit_plus.plane: the axis numbers print at %.1fpt at best, not "
        "%gpt, at size=%s -- give it a larger width= (or max_width=), "
        "bigger squares (size=) or a coarser numbering (step=2)"
        % (best[0], target, size))



def _checked_stretch(err, kw):
    """C6 r6: the stretch a figkit refusal names ('size=18 and width=300') is
    an estimate from the squares alone, and was refused again in 2 of 7
    cases, so the author looped. plane() tries it; a stretch that does not
    render is taken out of the message rather than offered."""
    m = re.search(r"; or stretch the squares by x[\d.]+ with the numbers kept "
                  r"at their size: size=(\d+) and width=(\d+) \(an explicit "
                  r"width= stops coord_plane/plane from enlarging the numbers "
                  r"with the squares, which is why size= alone never parts "
                  r"them\)", str(err))
    if not m:
        return err
    global _PROBING
    _PROBING = [1]
    try:
        _probe_plane(size=int(m.group(1)), width=int(m.group(2)), max_width=max(
            int(m.group(2)), SIDE_MAX), **kw)
        return err
    except AssertionError:
        cls = type(err)
        return cls(str(err).replace(m.group(0), ""))
    finally:
        _PROBING = []


_EVEN_PHRASES = (
    ("number the axis every 2 squares, so no number stands at this tick, or ",
     ""),
    ("number the axis every 2 squares, so no number stands at this tick",
     "draw the figure at another step"),
    (", or a regular step of 2 squares", ""),
    (", a regular step of 2 squares,", ","),
    ("number every 2 squares, ", ""))


def _checked_even(err, kw, steps, size, width, max_width):
    """Stage-1 open issue C2 doctrine4-move-hint-fails: a refusal that names
    'number the axis every 2 squares' must name a step that renders. With
    points on both sides of every tick (a dense scatter hugging the axis) the
    even step was refused too, and the author who followed it looped. The step
    is tried here -- or known tried, when the ladder's own rungs used it -- and
    taken out of the message when it does not render."""
    msg = str(err)
    if not any(a in msg for a, _ in _EVEN_PHRASES):
        return err
    ok = False
    if 2 not in steps:
        # the call the author would make, ladder and all, with no hint of its
        # own (the rungs of step=2 are its sizes)
        global _HINTING
        _HINTING = [1]
        try:
            _probe_plane(step=2, size=size, width=width, max_width=max_width, **kw)
            ok = True
        except AssertionError:
            ok = False
        finally:
            _HINTING = []
    if ok:
        return err
    for a, b in _EVEN_PHRASES:
        msg = msg.replace(a, b)
    return type(err)(msg)


WIDE_MAX = 430.0                   # wide(): a full-width block figure


def _check_window(xr, yr, step, polys, dpolys, solid, dashed, points, dots,
                  circles, arrows, xscale, yscale):
    """C6 r6 (doctrine 1): the data must fit the window it is drawn in.

    A point, a vertex or a circle outside the declared ranges was drawn
    beyond the last grid line, off the numbered axes, while a curve outside
    them was refused; a reversed range drew a plane with one axis unnumbered,
    and step=0 crashed. Each is refused here, naming the window that holds
    the data."""
    for ax, r in (("x", xr), ("y", yr)):
        if not (len(r) == 2 and all(isinstance(v, (int, float)) and v == v
                                    for v in r) and r[0] < r[1]):
            raise AssertionError(
                "figkit_plus.plane: the %s-range %r must be (low, high) with "
                "low < high -- a reversed or empty range draws an axis with "
                "no numbers on it." % (ax, r))
    if step is not None and not (isinstance(step, (int, float)) and step > 0):
        raise AssertionError(
            "figkit_plus.plane: step=%r -- the numbering step is a positive "
            "number of squares (None lets each axis choose)." % (step,))
    (x0, x1), (y0, y1) = xr, yr
    bad = []

    def put(what, p, over=0.0):
        # `over`: how far past the grid a STROKE may run, in squares -- a
        # side that overhangs the frame by less than half a square (the axes
        # themselves overhang by 0.55), a hand-drawn scale's tick stub. A
        # POINT is a value to read and gets none.
        ex, ey = 1e-9 + over * abs(xscale), 1e-9 + over * abs(yscale)
        try:
            x, y = float(p[0]), float(p[1])
        except (TypeError, ValueError, IndexError):
            return
        if not (x == x and y == y) or not (x0 - ex <= x <= x1 + ex
                                           and y0 - ey <= y <= y1 + ey):
            bad.append((what, (p[0], p[1])))
    for pts in list(polys) + list(dpolys):
        for p in pts:
            put("polygon vertex", p, 0.5)
    for grp, nm in ((solid, "segment end"), (dashed, "segment end"),
                    (arrows, "arrow end")):
        for s in grp:
            put(nm, s[0], 0.5)
            put(nm, s[1], 0.5)
    for pt in points:
        put("point %s" % (pt[1] if len(pt) > 1 and pt[1] else ""), pt[0])
    for dt in dots:
        put("dot", _dot_entry(dt)[0])
    for c in circles:
        if len(c) > 1 and isinstance(c[1], str):
            put("marker", c[0])
            continue
        (cx, cy), r = c[0], float(c[1])
        for p in ((cx - r, cy), (cx + r, cy), (cx, cy - r), (cx, cy + r)):
            put("circle ((%g, %g), %g)" % (cx, cy, r), p, 0.5)
    if bad:
        xs = [p[0] for _, p in bad if p[0] == p[0]] + [x0, x1]
        ys = [p[1] for _, p in bad if p[1] == p[1]] + [y0, y1]
        # P3 leftovers r1 (c6 #20, scaled-window-refusal-names-an-invalid-
        # window): the window named was built from the DATA VALUE, so on an
        # axis with xscale=/yscale= other than 1 it was not a whole number
        # of squares -- and the very next call was refused for exactly that.
        # Two refusals for one figure, the second blaming the author for the
        # number the first one handed them. The window is rounded OUT to a
        # whole square on each axis.
        def out_lo(v, u):
            k = v / float(u)
            return (round(k) if abs(k - round(k)) < 1e-9
                    else math.floor(k)) * u

        def out_hi(v, u):
            k = v / float(u)
            return (round(k) if abs(k - round(k)) < 1e-9
                    else math.ceil(k)) * u
        wx = (out_lo(min(xs), xscale), out_hi(max(xs), xscale))
        wy = (out_lo(min(ys), yscale), out_hi(max(ys), yscale))
        raise AssertionError(
            "figkit_plus.plane: %s lies outside the window x %s, y %s -- it "
            "would print beyond the grid, off the numbered axes, where no "
            "value can be read. Draw it inside a window that holds it, e.g. "
            "xr=(%g, %g), yr=(%g, %g); never move the data to fit the window."
            % ("; ".join("%s at %s" % b for b in bad[:3]), xr, yr,
               wx[0], wx[1], wy[0], wy[1]))


def _probe_plane(**kw):
    """P1: a hint's trial render is the AUTHOR'S call, sized as the author's
    call is. Inside _plane_at_pt a bare plane() skipped the sizing (its
    _SIZING flag was up) and drew at the enclosing loop's font and printed
    scale -- at a different width that is a different printed size, so a
    'max_width=430 renders it' was named that the author's call then
    refused. The trial runs its own sizing loop at the sheet's size and the
    enclosing loop's state is restored after it."""
    saved = (_SIZING[:], _HOUSE_U[0], _PEN_SCALE[0])
    if "number_pt" not in kw:
        if _SIZING and _TARGET:
            kw["number_pt"] = _TARGET[-1]
        elif _NPT and _NPT[-1] is not None:
            kw["number_pt"] = _NPT[-1]
    if _SIZING:
        kw.pop("font", None)
    del _SIZING[:]
    _HOUSE_U[0] = None
    try:
        return plane(**kw)
    finally:
        _SIZING[:] = saved[0]
        _HOUSE_U[0], _PEN_SCALE[0] = saved[1], saved[2]


_WIDER_PX = []           # P1 r2: the printed width of the call _wider_hint named


def _wider_note(wider):
    """P1 r2: where the named call puts the figure, AFTER 'renders it' (a
    test parses the call between 'does:' and 'renders it')."""
    px = _WIDER_PX[0] if _WIDER_PX else None
    if wider.startswith("width=") and "drop" not in wider:
        return (" (%gpx: still an item figure, up to %gpx)" % (px, ITEM_MAX_PX)
                if px and px <= ITEM_MAX_PX else
                " (%gpx: beside the text, not inside an item)" % px if px else "")
    return (" (%.0fpx wide%s)" % (px, ": a block above the items, not beside "
                                  "them" if px > SIDE_MAX else "") if px else "")


def _sparse_is_didactic(kw):
    """P3 leftovers r1 (sparse-is-the-surviving-hide): sparse= is a DECLARED
    didactic mode ("infer the scale"), not a way past a crowded figure.

    hide= is now a hard refusal whose stated reason is that a reader who
    cannot read one tick cannot read the figure -- and sparse=True with a
    coarser list reached the same drawing in one more token, on the very
    figure C7r3-P3 was written about: the x '2' and the y '2' gone from a
    plane whose only marked point is Q(2, -1), problems() empty. It was a
    live exit from crowding too (it rescued 4 of 36 refusals in a random
    sweep, including the in-shape refusal polys/dpolys/solid/closed curves
    share).

    The test is the one the mode's own meaning gives: the same figure with
    every number must RENDER. Then sparse was chosen for the item; if it is
    refused, sparse is being used to escape that refusal, and the crowding
    is what has to be fixed. (`ghosts=` already put the unprinted numbers
    through the pin solver; it does not see the sweeps that read the
    finished file, which is where these four escaped.)"""
    global _PROBING
    if not kw.get("sparse") or _PROBING or _HINTING or _SIZING or _FBHINT:
        return
    if kw.get("xticks") is None and kw.get("yticks") is None:
        return
    # the LIST's own rules first, so the more specific message wins (a list
    # that is a regular numbering with a hole is a deleted number, not a
    # scale to infer)
    x0, x1 = kw["xr"]
    y0, y1 = kw["yr"]
    zero = (x0 <= 0 <= x1 and y0 <= 0 <= y1 and kw.get("origin") is not False)
    for axis, ticks, lo, hi, unit in (
            ("x", kw.get("xticks"), x0, x1, kw.get("xscale") or 1),
            ("y", kw.get("yticks"), y0, y1, kw.get("yscale") or 1)):
        if ticks is not None:
            _assert_sparse_numbers(axis, [float(t) for t in ticks], lo, hi,
                                   unit, kw.get("data_ticks"), zero=zero)
    # step= goes back to the engine too: on a sparse figure the author's
    # step= often only says where the TICK MARKS go (every square), and
    # numbering every square is not what the full numbering would be
    full = dict(kw, sparse=False, xticks=None, yticks=None, step=None)
    _PROBING = [1]
    try:
        try:
            plane(**full)
        except AssertionError as e:
            raise AssertionError(
                "figkit_plus.plane: sparse=True leaves numbers off an axis so "
                "the reader INFERS the scale -- it is not a way past a "
                "crowded figure, and the same figure numbered in full is "
                "refused:\n  %s\nFix that first (the message names what "
                "renders); a number is never left out to make room."
                % str(e).splitlines()[0])
    finally:
        _PROBING = []


def _data_coords(kw):
    """Every x and y a figure's own DATA stands at: the coordinates handed
    to points/dots/polys/solid/dashed/circles/arcs/values/labels/curves."""
    xs, ys = set(), set()

    def eat(o, depth=0):
        if depth > 4 or o is None:
            return
        if isinstance(o, (int, float)):
            return
        if (isinstance(o, (tuple, list)) and len(o) == 2
                and all(isinstance(q, (int, float)) for q in o)):
            xs.add(float(o[0]))
            ys.add(float(o[1]))
            return
        if isinstance(o, (tuple, list)):
            for q in o:
                eat(q, depth + 1)
    for k in ("points", "dots", "polys", "dpolys", "solid", "dashed",
              "circles", "right", "arcs", "values", "labels", "shaded",
              "arrows", "tickmarks", "curves"):
        eat(kw.get(k))
    return xs, ys


def _data_ticks_is_didactic(kw):
    """P3 leftovers r2 (L1-P3r2-03, half-closed in r1): data_ticks= with NO
    listed value on a grid line still stripped an axis, and the r1 count cap
    (_DATA_TICKS_MAX = 2) only stopped the wide version of it.

    Two values are enough to strip an axis and to clear a real refusal:
    plane((-6,6),(-6,6), polys=[[(2,-5),(-1,3),(-6,2)]], step=1) is refused
    for its crowded '-3'; the same call with data_ticks=True,
    xticks=[-4.5, 1.5] rendered with an x-axis carrying -4.5 and 1.5 and not
    one integer -- the eleven regular numbers gone, problems() == [].

    What tells that apart from the figure data_ticks= is FOR is the
    parameter's own meaning: it prints the numbers of the DATA. The shipped
    (0,6) figure lists 1.5 beside its point A(1.5, 2); the refusal-clearing
    list names neither a vertex nor an end of anything in the drawing --
    the values were chosen for standing where no number was in the way. So
    when NOT ONE listed value sits on a grid line, at least one of them must
    be a coordinate the figure was given."""
    if not kw.get("data_ticks") or _PROBING or _HINTING or _SIZING or _FBHINT:
        return
    dxs, dys = _data_coords(kw)
    for axis, ticks, unit, data in (
            ("x", kw.get("xticks"), kw.get("xscale") or 1, dxs),
            ("y", kw.get("yticks"), kw.get("yscale") or 1, dys)):
        if not ticks:
            continue
        v = [float(t) for t in ticks]
        if any(abs(t / unit - round(t / unit)) <= 1e-6 for t in v):
            continue          # a number on the grid: an ordinary numbering
        if any(any(abs(t - q) <= 1e-6 for q in data) for t in v):
            continue          # at least one of them IS a data value
        raise AssertionError(
            "figkit_plus.plane: the data_ticks %s-axis prints %s, not one of "
            "them sits on a grid line AND not one of them is a coordinate of "
            "anything drawn -- so the axis carries no numbering and names no "
            "data either. That is how a crowded number gets left out (an "
            "axis number is never deleted). Number the %s-axis regularly "
            "(drop %sticks=, or leave step= to the engine, which prefers "
            "every 2 squares -- step=2 says it outright) and give the "
            "crowded number room: a larger "
            "size= with a wider figure (max_width=). data_ticks= prints the "
            "DATA's own values beside a numbered axis."
            % (axis, [float("%g" % t) for t in v], axis, axis))


def _fewer_objects_helps(bare, width, max_width):
    """The last line of a dead end: "fewer objects" -- or the truth, when
    the WINDOW is what cannot be drawn at this width.

    P3 leftovers r2 (P3r2-DEADEND-BLAMES-OBJECTS-NOT-WINDOW): on a window
    whose numbering does not fit the width at all, the empty plane is
    refused too, and so is every one-object split. A builder under deadline
    split the item, was refused again, dropped the poly, was refused again.
    The probe is one empty figure on the same window: if that is refused,
    splitting cannot help and the message says which knob must give."""
    global _PROBING
    if not (_HINTING or _PROBING):
        _PROBING = [1]
        # the probe RENDERS, and a render sets the sheet's house-look state;
        # leaving a probe's values behind changed how later figures on the
        # same sheet were sized (four shipped checks went red on figures
        # that had settled)
        keep = (list(_HOUSE_U), list(_TARGET_PT), list(_NPT))
        try:
            _probe_plane(width=width, max_width=max_width, **bare)
        except AssertionError:
            return ("the WINDOW, not the objects: this window is refused at "
                    "this width with NOTHING drawn on it (%s alone, no "
                    "points, no shapes), so splitting the item into two "
                    "figures is refused as well -- give the figure the room "
                    "above, or draw the same data on a window whose "
                    "numbering fits it (a larger xscale=/yscale= prints the "
                    "same range in fewer squares)"
                    % ("xr=%s, yr=%s" % (bare["xr"], bare["yr"])))
        finally:
            _PROBING = []
            _HOUSE_U[:], _TARGET_PT[:], _NPT[:] = keep
    return ("the drawing itself: fewer objects in ONE figure (the item split "
            "in two, each with its own plane), never fewer numbers")


def _last_resort(kw, max_width, width):
    """P3 leftovers r1 (crowding-dead-end-names-the-wrong-direction): the
    call that still renders when the ladder has run out, probed, or ''.

    When every rung failed the refusal used to end "change the FIGURE, not
    these knobs ... a window with fewer squares (each prints bigger)". A
    window with fewer squares never rendered these cases, and since P3 added
    assert_data_inside it is itself refused whenever the data fills the
    window -- so the LAST fix the message named was unreachable by
    construction. The two that do render are named here instead, in the
    order the brief's rule 5 puts them: a COARSER STEP at full width, then a
    WIDER WINDOW at full width (of 120 random plane figures, 36 were refused
    and these two rescued most of them).

    The probes are the author's own call, ladder and all (_PROBING), so a
    call this names is a call that renders."""
    global _PROBING
    if _HINTING or _PROBING:
        return ""
    xr, yr = kw["xr"], kw["yr"]
    xs = kw.get("xscale") or 1
    ys = kw.get("yscale") or 1
    cap = max(max_width or 0.0, WIDE_MAX)
    # Stage review (L3-Stage-05): every call probed here DROPS the explicit
    # width= (the probe passes width=None), but the clause printed only the
    # other knobs -- so "step=3, max_width=430" applied as written, with the
    # width= still in the call, is refused again. The sibling clause ("A
    # WIDER figure does:") already says "width=None (drop width=150)"; both
    # say it now.
    drop = "width=None (drop width=%g), " % width if width is not None else ""
    tries = []
    for st in (2, 3, 4):
        if kw.get("step") and kw["step"] >= st:
            continue
        tries.append(("%sstep=%d, max_width=%g (a coarser numbering at the "
                      "full width)" % (drop, st, cap),
                      dict(kw, step=st, width=None, max_width=cap)))
    for k in (1, 2, 3):
        wx = (xr[0] - k * xs, xr[1] + k * xs)
        wy = (yr[0] - k * ys, yr[1] + k * ys)
        tries.append(("%sxr=(%g, %g), yr=(%g, %g), max_width=%g (a WIDER "
                      "window at the full width -- the drawing keeps its "
                      "size and the crowding spreads out)"
                      % (drop, wx[0], wx[1], wy[0], wy[1], cap),
                      dict(kw, xr=wx, yr=wy, width=None, max_width=cap)))
    _PROBING = [1]
    try:
        for name, call in tries:
            try:
                out = _probe_plane(**call)
            except AssertionError:
                continue
            if FALLBACK_TAG.split("%")[0] in out:
                continue
            return name
    finally:
        _PROBING = []
    return ""


def _explicit_size_route(kw, sizes, width, max_width, on=True):
    """v6.2 Q1 r1 (L3-01): the size the ladder says it TRIED, called the way
    an author would call it -- and only named when it really renders.

    `on=` keeps the probe off the common path: it costs a full ladder per
    size, and the ANGLE-ARC nest is the one thing whose layout still differs
    between a rung and an explicit size= (a rung stays at the house look).
    Everything else is tied to the page's real scale at render.

    The ladder's last message ends 'already tried size=16/18/.../32 ... so
    change the FIGURE, not these knobs' and then offers to split the item in
    two, which destroys the drawing. For an arc nest that was false: the rung
    the ladder walks and the author's own plane(size=24, ...) are not the
    same call (a rung stays at the house look; an explicit size falls back to
    the v6.0 look when the house look will not fit), and size=24 rendered the
    figure the ladder had just sent away. Probed here, so the message names a
    call that works or says nothing."""
    global _HINTING
    if not on or _PROBING or _HINTING or _FBHINT:
        return ""
    # _HINTING, not _PROBING: the probe has to be the AUTHOR'S call, ladder,
    # fallbacks and all. Under _PROBING the house fallback is switched off,
    # which is the very thing that renders these figures.
    _HINTING = [1]
    try:
        for z in sorted(set(sizes)):
            try:
                _probe_plane(size=z, width=width, max_width=max_width, **kw)
            except AssertionError:
                continue
            return ("size=%g renders it as it stands (an explicit size= is "
                    "not the rung the ladder walks: it may print the figure "
                    "at the v6.0 look rather than the house look)" % z)
    finally:
        _HINTING = []
    return ""


def _item_route(kw, sizes, step, width, wider):
    """v6.2 Q1 r1: what an ITEM figure can actually do when the width the
    ladder names is wider than an item figure may be.

    emit_plus caps an item figure at ITEM_MAX_PX (150px). A refusal that
    names width=180 is, for an item, a fix that does not render: the build
    stops with 'item figure is 180px wide, over the 150 limit'. The two
    routes that DO work are the ones G78 names three build cycles later --
    move the figure to the question head, or number every 2 squares -- and
    the second is probed here at the author's own width, so it is named only
    when it renders (doctrine 4).

    Returns a sentence to add to the refusal, or ''."""
    if width is None or width > ITEM_MAX_PX or not wider:
        return ""
    m = re.match(r"(?:width|max_width)=([\d.]+)", str(wider))
    at = float(m.group(1)) if m else (_WIDER_PX[0] if _WIDER_PX else None)
    if at is None or at <= ITEM_MAX_PX:
        return ""
    got = ""
    if step is None or float(step) < 2:
        global _PROBING
        _PROBING = [1]
        try:
            for z in ([sizes[0]] if sizes else []) + [None]:
                try:
                    _probe_plane(step=2, width=width,
                                 max_width=max(width, ITEM_MAX_PX),
                                 **(dict(kw, size=z) if z else kw))
                except AssertionError:
                    continue
                got = ("step=2 at width=%g renders it as an item figure "
                       "(every 2 squares numbered -- a coarser numbering, "
                       "never fewer numbers); " % width)
                break
        finally:
            _PROBING = []
    return (" If this is an ITEM figure it may not be wider than %gpx: %s"
            "move it to the question head (q['fig']) at width=%g instead."
            % (ITEM_MAX_PX, got, at))


def _wider_hint(kw, sizes, max_width, width):
    """C6 r4: the exact wider call that renders a figure the ladder refused,
    or '' when none does (or the figure is already full width)."""
    global _PROBING, _HINTING
    _WIDER_PX[:] = []
    # v6.2 Q1 r1: a call with neither width= nor max_width= (figkit.
    # coord_plane(max_width=None) is one) used to crash here with a
    # TypeError the moment the ladder was exhausted -- the hint machinery was
    # only ever reached by calls that named a width
    cur = width or max_width or WIDE_MAX
    if cur >= WIDE_MAX - 1e-6:
        return ""
    if width is not None:
        # P1 r2 (hint-misses-item-width, narrow-hint-overshoots): the
        # NEAREST width that renders comes first. A 0..10 x 0..6 plane
        # refused at width=124 was sent to 'width=None, max_width=430, a
        # full-width block above the items', though width=150 -- still an
        # item figure -- printed it; a 12x12 plane at width=140 renders at
        # 160. The call is the author's, ladder and all (_HINTING).
        tries = sorted(set(w for w in (math.ceil((width + 10) / 10.0) * 10,
                                       ITEM_MAX_PX, HOUSE["narrow_px"],
                                       SIDE_MAX) if width < w <= SIDE_MAX))
        _HINTING = [1]
        try:
            for w in tries:
                try:
                    out = _probe_plane(size=sizes[0], width=w,
                                       max_width=max(max_width, w), **kw)
                except AssertionError:
                    continue
                if FALLBACK_TAG.split("%")[0] in out:
                    continue
                _WIDER_PX[:] = [w]
                return "width=%g" % w
        finally:
            _HINTING = []
    _PROBING = [1]
    try:
        for sz in sorted(set(sizes)):
            try:
                ok_svg = _probe_plane(size=sz, width=None, max_width=WIDE_MAX,
                                      **kw)
            except AssertionError:
                continue
            # P1 r1: the probe drew with NO width=; an author who keeps his
            # width=130 and adds max_width=430 got the same refusal and the
            # same hint back. Say the width goes.
            if sz != sizes[0]:
                # P1 r2: the author's own size with max_width=430 climbs the
                # ladder too; when that renders, it is the call to name
                # ('size=56' read as the knob to turn)
                _PROBING = []
                _HINTING = [1]
                try:
                    ok_svg = _probe_plane(size=sizes[0], width=None,
                                          max_width=WIDE_MAX, **kw)
                    sz = sizes[0]
                except AssertionError:
                    pass
                finally:
                    _HINTING = []
                    _PROBING = [1]
            got = re.search(r'<svg[^>]*\bwidth="([\d.]+)', ok_svg)
            _WIDER_PX[:] = [float(got.group(1))] if got else []
            return ("%s%s%s" % ("width=None (drop width=%g), " % width
                                if width is not None else "",
                                "max_width=%d" % WIDE_MAX if sz == sizes[0] else
                                "size=%d, max_width=%d" % (sz, WIDE_MAX),
                                ""))
    finally:
        _PROBING = []


def _ladder(xr, yr, step, size, max_width, width):
    """The (step, size) pairs plane() tries, in order: what the author asked
    for, then -- only when the step was automatic and an axis was on every 1 --
    every 2, then bigger squares, up to twice the size asked for.

    C6 r4: the bigger-squares tier used to be gated on (span x size + 34) <=
    max_width, reading `size` as PRINTED pixels. It is not: _plane scales the
    viewBox down to max_width (width=) and raises the font to the printed
    floor, so every size prints within max_width. The gate let nothing above
    size=16 through on a 17-square window -- the tier was dead on every window
    that produced an axis-number refusal, while plane(size=20) on the refused
    figure rendered at exactly width 210. Now every rung is tried; the printed
    width never exceeds max_width, which is what 'enlarge the figure within
    max_width' means. An explicit width= still stops the tier."""
    out = [(step, size)]
    if step is None and (auto_step(xr[0], xr[1]) == 1
                         or auto_step(yr[0], yr[1]) == 1):
        out.append((2, size))
    # v6 stage 1b r2: finer rungs. With 1.25 / 1.6 / 2.0 alone a figure that
    # renders at size=24 was refused because 20 was too small and 26 did not
    # fit the page. The room a size buys is not monotonic (a stroke's crossing
    # moves against the tick as the squares grow), so the rungs are dense.
    if width is not None and not _WIDE:
        # an explicit width= is the author's printed figure, as an explicit
        # step= is his numbering: the ladder does not re-draw it bigger.
        # C6 r6: wide() is not an author's width -- it is the full-width
        # placement, and the squares may grow inside it (below)
        return out
    # P1 r2 (auto-size-false-refusal-big-plane): a bigger square is tried
    # at the author's own step FIRST, then at every 2. The grown rungs used
    # to carry the last rung's step -- every 2 once it was added -- so a
    # -10..10 plane with a circle was refused 'at size=16..32 within
    # max_width=430' while plane(size=30, max_width=430), numbered as asked,
    # rendered it.
    steps = []
    for st, _ in out:
        if st not in steps:
            steps.append(st)
    for k in _GROW:
        grown = int(round(size * k))
        if grown > out[-1][1]:
            for st in steps:
                out.append((st, grown))
    # P1 r2: at the house look a rung whose display is already pinned at
    # max_width prints the SAME figure at a finer figure-unit resolution,
    # and the label placer's fixed-unit pads make that non-monotonic: the
    # -10..10 plane with a circle refused at 16..52 drew at size=56. Pinned
    # rungs go on to 3.5x, own step only (one render each once refused).
    if SHEET.get("house"):
        span = (xr[1] - xr[0]) / 1.0
        for k in _GROW_PINNED:
            grown = int(round(size * k))
            if grown > out[-1][1] and \
                    (span + 1.1) * grown * 0.5 >= (max_width or SIDE_MAX):
                out.append((steps[0], grown))
    return out


_GROW = (1.15, 1.25, 1.4, 1.5, 1.6, 1.75, 1.875, 2.0)
_GROW_PINNED = (2.25, 2.5, 3.0, 3.5)   # P1 r2: house look, display pinned
_TARGET_PT = []          # P1 r2: the house rung's target pt, for _plane's font clamp
_PIN_SAMPLE = 1.15      # P1 r2 PERF: pinned refused rungs sampled this far apart


def _attempts(xr, yr, polys, dpolys, solid, dashed, points, dots, right,
              circles, labels, values, xticks, yticks, step, size, font,
              width, max_width, grid, ticks, axis_labels, arcs, tickmarks,
              shaded, arrows, xscale, yscale, data_ticks, sketch, hide,
              sparse, origin, fam, curves, pen=1.0):
    for attempt in range(8):
        try:
            return _plane(xr, yr, polys, dpolys, solid, dashed, points, dots,
                          right, circles, labels, values, xticks, yticks, step,
                          size, font * (1.08 ** attempt), width, max_width,
                          grid, ticks, axis_labels, arcs, tickmarks, shaded,
                          arrows, xscale, yscale, data_ticks, sketch,
                          hide, sparse, origin, fam, curves, pen)
        except AssertionError as e:
            # verify()'s floor says "below the"; the emitted-SVG sweep says
            # "prints at ...pt, under" — both are cured by a larger font
            if "has no clear spot nearer its own stroke" in str(e) and \
                    not _PROBING and not _HINTING:
                raise AssertionError(str(e) + _owned_size_hint(
                    dict(xr=xr, yr=yr, polys=polys, dpolys=dpolys, solid=solid,
                         dashed=dashed, points=points, dots=dots, right=right,
                         circles=circles, labels=labels, values=values,
                         xticks=xticks, yticks=yticks, step=step, font=font,
                         grid=grid, ticks=ticks, axis_labels=axis_labels,
                         arcs=arcs, tickmarks=tickmarks, shaded=shaded,
                         arrows=arrows, xscale=xscale, yscale=yscale,
                         data_ticks=data_ticks, sketch=sketch, hide=hide,
                         sparse=sparse, origin=origin, fam=fam,
                         curves=curves),
                    size, max_width, _refused_text(str(e))))
            if ("below the" not in str(e) and "pt, under" not in str(e)) \
                    or attempt == 7:
                raise
    raise AssertionError("unreachable")


_PROBING = []
# v6 open issues: set while _owned_size_hint tries a size. The trial climbs
# plane()'s ladder as the author's call would (under _PROBING it stopped at
# the first rung, so a size that renders was reported as refused), but asks
# for no hint of its own.
_HINTING = []


def _refused_text(msg):
    m = re.search(r"label '([^']*)' has no clear spot", msg)
    return m.group(1) if m else None


def _owned_size_hint(kw, size, max_width, text=None):
    """C3 r3: a length that has no spot nearer its own side names the size
    that has one, tried, instead of 'enlarge the figure' (a 2x1 triangle's
    base at the origin needed size=40-50 and the author had to guess).

    v6 open issues: the width named is the one the figure takes at that size,
    read from a trial render (an estimate from the squares alone came out
    short, the render shrank back and the named call was refused again), and
    the curves ride along. When no size renders it the hint says so and names
    the fixes that remain, so 'enlarge the figure' is never the last word."""
    global _HINTING
    _HINTING = [1]
    try:
        # C7P-06: the fix that keeps the figure beside its text comes first.
        # A 3x1 triangle's base length was sent to size=31, max_width=470 --
        # a 12 cm figure of mostly empty grid -- where a prefer= on the label
        # rendered at the author's own size. The prefer= that renders is
        # named, then the SMALLEST larger size that does.
        vals = list(kw.get("values") or ())
        for i, v in enumerate(vals):
            if text is None or len(v) < 2 or v[1] != text:
                continue
            for d in ((0, -1), (0, 1), (-1, 0), (1, 0), (1, -1), (-1, -1),
                      (1, 1), (-1, 1)):
                nv = list(v) + [None] * (4 - len(v))
                nv[2] = d
                trial = dict(kw, values=vals[:i] + [tuple(nv)] + vals[i + 1:])
                try:
                    _probe_plane(size=size, width=None, max_width=max_width, **trial)
                except AssertionError:
                    continue
                return (" (tried: the value %r with prefer=%s -- values=[..., "
                        "(%s, %r, %s%s), ...] -- renders at this size and "
                        "width)" % (text, d, v[0], text, d,
                                    ", %s" % (nv[3],) if nv[3] is not None else ""))
        tried = []
        for k in (1.15, 1.3, 1.4, 1.65, 1.9, 2.5, 3.2, 4.2):
            sz = int(math.ceil(size * k))
            tried.append(sz)
            try:
                svg = _probe_plane(size=sz, width=None, max_width=100000, **kw)
                m = re.search(r'<svg[^>]*\bwidth="([\d.]+)', svg)
                mw = int(max(max_width, math.ceil(float(m.group(1)) / 10.0) * 10))
                _probe_plane(size=sz, width=None, max_width=mw, **kw)
            except AssertionError:
                continue
            far = ""
            if mw > 2 * max_width:
                far = ("; at %dpx it no longer sits beside its text -- a shape "
                       "moved off the axis needs less (a side lying along "
                       "an axis puts its length beside that axis's numbers)"
                       % mw)
            return (" (tried: size=%d, max_width=%d and no width= renders it -- the squares "
                    "grow, the text stays its size%s)" % (sz, mw, far))
        # P3 leftovers r1 (c6 #18, minor): "move the shape off the axis" was
        # asking the author to move DATA -- what every other message in this
        # file forbids. The fix that keeps the data is the finer scale, and
        # (where the coordinates are the author's own to choose) a window
        # that does not lay a side along the row of numbers.
        return (" (tried: size=%s at full width -- none renders it, so enlarging is not "
                "the fix here: draw the side longer in squares (a finer "
                "xscale=/yscale=), or -- where the coordinates are yours to "
                "choose -- a window that does not lay a side along the row of "
                "numbers; never move given data and never drop the label)"
                % "/".join(str(t) for t in tried))
    finally:
        _HINTING = []


def _plane(xr, yr, polys, dpolys, solid, dashed, points, dots, right, circles,
           labels, values, xticks, yticks, step, size, font, width, max_width,
           grid, ticks, axis_labels, arcs, tickmarks, shaded, arrows,
           xscale=1, yscale=1, data_ticks=False, sketch=False, hide=(),
           sparse=False, origin=None, fam=None, curves=(), pen=1.0):
    x_min, x_max = xr
    y_min, y_max = yr
    xs, ys = xscale, yscale
    for lo, hi, s, ax in ((x_min, x_max, xs, "x"), (y_min, y_max, ys, "y")):
        if s <= 0 or abs(lo / s - round(lo / s)) > 1e-9 \
                or abs(hi / s - round(hi / s)) > 1e-9:
            raise AssertionError(
                "figkit_plus.plane: the %s-range %s is not a whole number of "
                "squares at %sscale=%g" % (ax, (lo, hi), ax, s))
    # v6 C3 (E8): a circle given with a marker STYLE instead of a radius,
    # ((cx, cy), "open"), is a point marker -- screen-space, printed at its
    # own floor on any scales. Only a data circle (a radius in grid units)
    # would print as an ellipse on unequal scales, so only it is refused.
    marks_from_circles = [c for c in circles if len(c) > 1 and
                          isinstance(c[1], str)]
    circles = [c for c in circles if not (len(c) > 1 and isinstance(c[1], str))]
    if circles and xs != ys:
        raise AssertionError(
            "figkit_plus.plane: a circle of radius %g on unequal axis scales "
            "(xscale=%g, yscale=%g) would print as an ellipse. For a hollow or "
            "filled POINT use a marker -- points=[(p, 'A', 'open')], "
            "dots=[(p, 'open')] or circles=[(p, 'open')] -- which prints the "
            "same on any scales; for a real circle use equal scales."
            % (circles[0][1], xs, ys))
    dots = list(dots) + [(c[0], c[1]) for c in marks_from_circles]
    gx0, gx1 = int(round(x_min / xs)), int(round(x_max / xs))
    gy0, gy1 = int(round(y_min / ys)), int(round(y_max / ys))
    est = (gx1 - gx0 + 1.1) * size + 2 * 9 + 16
    # P3 leftovers r1 (max-width-none-raises-typeerror, minor): max_width=None
    # is the natural spelling of "no cap" on a parameter whose default is a
    # number, and one shipped level already passes it to another builder. It
    # used to crash with a raw TypeError out of the ladder ("'>' not
    # supported between instances of 'float' and 'NoneType'"), which is not
    # a refusal that names a fix. It means the full page width here, as it
    # does everywhere else in this module ((max_width or SIDE_MAX)).
    target = width if width is not None else (max_width or PAGE_MAX)
    if est > target:
        # P1 r2 (number-pt-tolerance): at the house look the 5% margin is
        # capped by the sheet's own size. It held a number_pt=7 sheet's
        # planes at 7.3-7.4pt beside axes() at 7.0, and the rung spent 14
        # renders lowering a font that never reached the page. At 8pt it
        # binds as before (the rungs' step-downs rely on it).
        k = target / est
        margin = 1.05
        if _HOUSE_U[0] is not None and _TARGET_PT:
            margin = max(1.0, min(1.05, _TARGET_PT[-1] / MIN_PT - 0.01))
        font = max(font, MIN_PT / (_PX_TO_PT * k * 0.92) * margin)

    f = Figure(width=width)
    if xs == 1 and ys == 1:
        X = lambda v: v * size
        Y = lambda v: -v * size
    else:
        X = lambda v: v / xs * size
        Y = lambda v: -v / ys * size
    P = lambda p: (X(p[0]), Y(p[1]))
    # P3 leftovers r2 (P3r2-PIXEL-COORDS-IN-REFUSALS): the way back, so a
    # refusal can name the object it blames by the coordinates the AUTHOR
    # wrote ("a plotted point at (2, -1)") instead of the figure's own units.
    f._data_at = lambda q: (q[0] / float(size) * xs, -q[1] / float(size) * ys)
    # v6.5 X2: the same way back hands the export the DATA frame, so a
    # plotted A(2, 6) is exported as xy [2, 6] -- the coordinates the question
    # prints -- and a constraint about it (a length of 5 squares, a midpoint)
    # is measured in the plane's own units. `kind` says what the figure is.
    f.ex.set_data(f._data_at)
    f.ex.kindname = "plane"

    # P1 (the house look): `u` is figure units per PRINTED pt, set by
    # _plane_at_pt from the finished render. With it every stroke, tick,
    # dot, marker and letter is drawn at a printed size, whatever the width.
    hu = _HOUSE_U[0]
    hw = (lambda key, legacy: HOUSE[key] * hu) if hu else \
        (lambda key, legacy: legacy)
    lf = font * HOUSE["letter_pt"] / HOUSE["number_pt"] * 0.92 if hu else font
    if hu:
        # marks (arrowheads, markers, equality ticks) start from the printed
        # scale this figure is known to print at, not the 1px = 0.75pt guess
        # whose floors only ever grow (a 9 cm plane's 5pt arrowhead printed 7.3pt)
        f._upt = hu
    for poly in shaded:
        # Drawn FIRST so every stroke sits on top of it -- the GRID (stage
        # review: the shade was emitted after the grid lines and painted
        # over them, so the squares could not be counted inside the very
        # region the question is about and a black-and-white print showed a
        # flat grey block), and the axes and their tick marks too (C2:
        # painted after them, a shaded triangle over the y-axis hid the axis
        # and its ticks at 2 and 4) -- and recorded as an
        # obstacle so a label never lands inside the shaded region and reads as
        # a caption for it. The shade (svgcheck.SHADE_FILL, #dcdcdc) is above
        # the 0.85 luminance line both G72 and figkit._struck use, so it can
        # never be mistaken for ink. Stage-1 fix r1 (PR10): it was #eeeeee,
        # half numberline's grey on the same sheet and faint on a laser
        # printer, on the very region the question asks about.
        f.poly([P(p) for p in poly], width=0.0, fill=svgcheck.SHADE_FILL,
               record=True)
    if grid:
        for gx in range(gx0, gx1 + 1):
            f.line((X(gx * xs), Y(y_min)), (X(gx * xs), Y(y_max)),
                   hw("grid_pt", 0.4), record=False, colour=GRID)
        for gy in range(gy0, gy1 + 1):
            f.line((X(x_min), Y(gy * ys)), (X(x_max), Y(gy * ys)),
                   hw("grid_pt", 0.4), record=False, colour=GRID)
    over = size * 0.55
    heads_on = bool(hu and _ARROWS and _ARROWS[-1])
    # P1: the positive ends carry a 5pt arrowhead; its base stands clear of
    # the last tick (2.5pt of axis between them) whatever the square's size --
    # at size=34 a 0.55-square overshoot put the head ON the tick at x = 8
    over_p = max(over, (HOUSE["head_pt"] + 2.5) * hu) if heads_on else over
    aw = hw("axis_pt", 1.4 * pen)
    f.line((X(x_min) - over, 0), (X(x_max) + over_p, 0), aw, role="axis",
           name="axis-x")
    f.line((0, Y(y_min) + over), (0, Y(y_max) - over_p), aw, role="axis",
           name="axis-y")
    if heads_on:
        # P1 (4): arrowheads at the positive ends and the letters beside
        # them, as Typst and LaTeX print a coordinate system
        tipx, tipy = (X(x_max) + over_p, 0), (0, Y(y_max) - over_p)
        f.arrowhead(tipx, (1, 0), size=HOUSE["head_pt"] * hu, style="filled",
                    angle=HOUSE["head_deg"], width=aw)
        f.arrowhead(tipy, (0, -1), size=HOUSE["head_pt"] * hu, style="filled",
                    angle=HOUSE["head_deg"], width=aw)
        # centred on the ray (a baseline on it put the letter's box across
        # the axis, and the solver swung it 45 degrees up, away from the tip)
        f.label(tipx, axis_labels[0], size=lf, italic=True,
                prefer=(1, 0.2), gap=1.5 * hu, centred=True)
        # beyond its arrowhead the letter is the axis's name, not the row's
        # next number ('6 ->x' as Typst and LaTeX print it)
        f.labels[-1].past_head = True
        f.label(tipy, axis_labels[1], size=lf, italic=True,
                prefer=(-1, 0.2), gap=2.0 * hu, centred=True)
    else:
        f.label((X(x_max) + over, 0), axis_labels[0], size=lf, italic=True,
                prefer=(1, -0.6), gap=3.0)
        f.label((0, Y(y_max) - over), axis_labels[1], size=lf, italic=True,
                prefer=(-0.6, -1), gap=3.0)
    # P1 (2): tick marks sized to the numbers -- short and thin
    tick_kw = dict(tick_half=HOUSE["tick_half_pt"] * hu,
                   ink=HOUSE["tick_pt"] * hu,
                   gap=HOUSE["tick_gap_pt"] * hu) if hu else {}

    if not ticks and not sketch:
        # C6 r4: this message used to end "pass sketch=True only for a
        # deliberately unscaled picture" -- and sketch=True with ticks=False
        # then drew a refused figure on a gridded plane with ZERO numbers, all
        # sweeps clean: two steps from an axis-number refusal to the artefact
        # the author called broken. It now names the real paths first.
        raise AssertionError(
            "figkit_plus.plane: ticks=False leaves both axes unnumbered. A "
            "coordinate plane on a sheet carries numbers. If a number had no "
            "room, the refusal that sent you here names the fix (plane() "
            "already tries step 2 and bigger squares, and names the wider "
            "figure that renders); unnumbering the axes is not one of them, "
            "and neither is sketch=True: a sketch, with or without its grid, "
            "is solved as if numbered and refused wherever its numbered "
            "figure would be. Keep ticks=False for a picture that truly has "
            "no scale, with sketch=True.")
    if sparse and (not ticks or (xticks is None and yticks is None)):
        raise AssertionError(
            "figkit_plus.plane: sparse=True numbers only the values you list "
            "-- pass xticks=[...] and/or yticks=[...] (the marks still go at "
            "every `step` squares)")
    # v6 stage 1b (rule 3): step=None lets each axis choose -- every 2
    # squares when it is long enough, every 1 when it is short
    stepx = auto_step(gx0, gx1) if step is None else step
    stepy = auto_step(gy0, gy1) if step is None else step
    reg_x = [k * xs for k in ticks_every(gx0, gx1, stepx)]
    reg_y = [k * ys for k in ticks_every(gy0, gy1, stepy)]
    # C6 r4 (doctrine 4): the numbers an axis leaves unprinted by
    # DECLARATION -- a sparse axis, or a sketch drawn on a grid -- are solved
    # as hidden numbers (figkit.number_axes ghosts=), at the regular step the
    # axis would be numbered at. So neither declaration renders a figure the
    # fully numbered plane refuses: sparse=True with one value per axis and
    # sketch=True with ticks=False used to clear every axis-number refusal
    # by printing (almost) no numbers.
    # C6 r6: a sketch with grid=False as well. It was left alone ("no scale
    # to read"), and plane(..., sketch=True, grid=False, ticks=False) then
    # drew every refused figure tried (22 of 22) with ZERO numbers, clean
    # on every sweep -- the one-kwarg escape the ticks=False refusal itself
    # named. Its vertices are still the question's lattice coordinates, so
    # it is solved as numbered too: a sketch is a drawing without printed
    # numbers, never a way past a number that has no room.
    ghost_x = [k * xs for k in ticks_every(
        gx0, gx1, max(stepx, auto_step(gx0, gx1)))]
    ghost_y = [k * ys for k in ticks_every(
        gy0, gy1, max(stepy, auto_step(gy0, gy1)))]
    gridded_sketch = sketch          # C6 r6: every sketch (the name is kept)
    if not ticks and gridded_sketch:
        figkit.number_axes(
            f, X, Y, xr, yr, [], [], font, hide=(), origin=False,
            where="figkit_plus.plane", square=size,
            pitch=(stepx * size, stepy * size), page=width or max_width,
            ghosts=(ghost_x, ghost_y), **tick_kw)
    if ticks:

        def judged_step(given, unit, auto):
            """An axis the author numbered HIMSELF is judged at the step his
            own values imply, not at the automatic one: xticks=[-2] on a
            5-square axis is one number every 2 squares, which is what the
            'is there room for two numbers?' rule must weigh."""
            if given is None:
                return auto
            v = sorted(set([float(t) for t in given] + [0.0]))
            if len(v) < 2:
                return auto
            d = min(b - a for a, b in zip(v, v[1:])) / float(unit)
            return max(1, int(round(d))) if d >= 0.99 else auto
        xt = list(xticks) if xticks is not None else reg_x
        yt = list(yticks) if yticks is not None else reg_y
        # P3 (L1-XTICKS-DROPPED): a listed value outside the window has no
        # tick, and was quietly left out -- of the sketch too, which is why
        # this runs before the sketch branch
        if xticks is not None:
            figkit.assert_ticks_inside("x", xticks, x_min, x_max,
                                       "figkit_plus.plane")
        if yticks is not None:
            figkit.assert_ticks_inside("y", yticks, y_min, y_max,
                                       "figkit_plus.plane")
        if not sketch:
            for axis, t, lo, hi, u, sp in (("x", xt, x_min, x_max, xs,
                                            sparse and xticks is not None),
                                           ("y", yt, y_min, y_max, ys,
                                            sparse and yticks is not None)):
                if sp:
                    _hx, _hy = figkit.hide_sets(hide, "figkit_plus.plane")
                    _assert_sparse_numbers(
                        axis, t, lo, hi, u, data_ticks,
                        zero=(x_min <= 0 <= x_max and y_min <= 0 <= y_max
                              and origin is not False
                              and 0.0 not in _hx and 0.0 not in _hy))
                else:
                    _assert_axis_numbers(
                        axis, t, lo, hi, u, data_ticks,
                        judged_step(xticks, xs, stepx) if axis == "x"
                        else judged_step(yticks, ys, stepy))
        figkit.number_axes(
            f, X, Y, xr, yr, xt, yt, font,
            xmarks=sorted(set(reg_x) | set(xt)) if sparse and xticks is not None
            else None,
            ymarks=sorted(set(reg_y) | set(yt)) if sparse and yticks is not None
            else None,
            hide=hide, origin=origin, where="figkit_plus.plane", square=size,
            pitch=(stepx * size, stepy * size), page=width or max_width,
            # C6 r4: a sparse axis's unprinted regular numbers are solved as
            # hidden ones, so sparse=True cannot clear a collision
            ghosts=(ghost_x if gridded_sketch or (sparse and xticks is not None)
                    else (),
                    ghost_y if gridded_sketch or (sparse and yticks is not None)
                    else ()), **tick_kw)

    # C6 r5 (rule 5): `pen` is how much the ladder grew the squares over the
    # size asked for. The drawing is scaled down to the same max_width, so
    # at pen 1.9 an unscaled 1.6-unit edge printed at 0.67pt, a point's dot
    # at a 1pt radius and the axes as hairlines -- the numbers got their
    # room and the figure lost its ink. Every data stroke, dot, dash and
    # arrowhead is drawn pen x thicker, so it prints as the figure asked for
    # would have. pen == 1 (every figure that renders as asked) is unchanged.
    dash43 = "4,3" if pen == 1.0 else "%g,%g" % (4 * pen, 3 * pen)
    if hu:
        dash43 = "%.2f,%.2f" % (HOUSE["dash_on_pt"] * hu, HOUSE["dash_off_pt"] * hu)
    shapes = []
    # v6 stage 1b r3: the DATA geometry, in the figure's own units, kept so
    # the finished file can be measured against what the call asked for
    # (svgcheck.assert_draws below). Figure.check_complete already compares
    # the same lengths from the builder's own records; this is the
    # independent read of the file doctrine 3 asks for, and it is what makes
    # the brief's clause (b) run on a render instead of waiting for a builder
    # to remember to call it.
    geom = []

    def _chain(sp, closed=False):
        run = list(sp) + ([sp[0]] if closed and len(sp) > 2 else [])
        geom.extend(zip(run, run[1:]))

    for pts in polys:
        sp = [P(p) for p in pts]
        f.poly(sp, width=hw("main_pt", 1.6 * pen))
        shapes.append(sp)
        _chain(sp, closed=True)
    for pts in dpolys:
        sp = [P(p) for p in pts]
        f.poly(sp, width=hw("dashed_pt", 1.2 * pen), dash=dash43)
        shapes.append(sp)
        _chain(sp, closed=True)
    for a, b in solid:
        f.line(P(a), P(b), hw("main_pt", 1.5 * pen))
        geom.append((P(a), P(b)))
    for a, b in dashed:
        f.line(P(a), P(b), hw("dashed_pt", 1.2 * pen), dash=dash43)
        geom.append((P(a), P(b)))
    # v6 stage 1b: curves. Sampled adaptively, clipped EXACTLY to the window,
    # each piece ONE path -- never a chain of <line>s, and never cut.
    curve_ends = []
    for entry in curves:
        pieces, nm = _curve_pieces(entry, (x_min, y_min, x_max, y_max))
        if not pieces:
            raise AssertionError(
                "figkit_plus.plane: curves=%r has no piece inside the window "
                "x %s, y %s -- widen the window (a window that holds a "
                "piece of it, and a yscale= that brings its values into "
                "reach); a curve "
                "the window cannot show is not drawn as an empty stretch."
                % (nm or entry, (x_min, x_max), (y_min, y_max)))
        for pc in pieces:
            fp_pc = [P(q) for q in pc]
            f.curve(fp_pc, width=hw("main_pt", 1.5 * pen))
            _chain(fp_pc)
        if nm:
            curve_ends.append((nm, pieces))
    for c in circles:
        centre, r = c[0], c[1]
        dash = c[2] if len(c) > 2 else None
        f.circle(P(centre), r / xs * size, width=hw("main_pt", 1.4 * pen),
                 dash=dash)
        # C6 r6: a circle is data too -- its rim goes into the geometry the
        # finished file is measured against (a half circle used to pass)
        rr, cc = r / xs * size, P(centre)
        nr = max(48, int(2 * math.pi * rr / 2.0))
        _chain([(cc[0] + rr * math.cos(2 * math.pi * k / nr),
                 cc[1] + rr * math.sin(2 * math.pi * k / nr))
                for k in range(nr + 1)])
    for v, a, b in right:
        # v6 C3 (E5): measured as DRAWN -- on unequal scales a right angle in
        # the data does not print square, and a mark there would lie
        ang = figkit._angle_deg(P(v), P(a), P(b))
        if abs(ang - 90.0) > figkit.RIGHT_TOL:
            raise AssertionError(
                "figkit_plus.plane: right=[(%s, %s, %s)] marks an angle that "
                "prints at %.1f°%s -- a right-angle mark claims 90°. Name the "
                "vertex whose angle is 90° (the vertex first), or correct the "
                "coordinates; never keep a mark the drawing contradicts."
                % (v, a, b, ang, "" if xs == ys else
                   " (xscale=%g, yscale=%g: a right angle does not print "
                   "square on unequal scales)" % (xs, ys)))
        f.right_angle(P(v), P(a), P(b), size=size * 0.36,
                      width=hw("mark_pt", 1.1))
    def _span(arc):
        # P1 r2: smallest angle first, so an angle that contains others at
        # the same vertex is drawn outside them (Figure.arc steps an arc
        # off any earlier one it would lie on)
        v, a, b = P(arc[0]), P(arc[1]), P(arc[2])
        d = abs(math.atan2(b[1] - v[1], b[0] - v[0])
                - math.atan2(a[1] - v[1], a[0] - v[0])) % (2 * math.pi)
        return min(d, 2 * math.pi - d)
    _arc0 = len(f.parts)
    for arc in sorted(arcs, key=_span):
        v, a, b = arc[0], arc[1], arc[2]
        n = arc[3] if len(arc) > 3 else 1
        # v6.2 Q1 (arc-size-follows-width): at the house look the nest is
        # laid out in PRINTED pt (figkit.ARC_R_PT / ARC_STEP_PT), like every
        # other mark on the sheet. size*0.55 with a 0.25 step printed 4.2pt
        # rings 2.1pt apart at an item width and 14pt rings 7.1pt apart at
        # 430px -- the same marking, twice the look.
        f.arc(P(v), P(a), P(b), r=None if hu else size * 0.55, n=n,
              step=None if hu else None,
              width=hw("mark_pt", 1.2))
    # C6 r6: an angle arc is data too. v6.2 Q1: chained AFTER the last arc,
    # because a nest is laid out again (and its earlier rings redrawn at a
    # compressed radius) every time an arc joins it -- chaining inside the
    # loop handed the lost-ink gate the radii of a nest that no longer
    # existed.
    for part in f.parts[_arc0:]:
        if part[0] == "path":
            _chain(part[1])
    for tm in tickmarks:
        (p, q) = tm[0]
        n = tm[1] if len(tm) > 1 else 1
        t = tm[2] if len(tm) > 2 else None     # v6 C3: where along the side (C3 r2: None = middle, or between axis ticks)
        f.ticks(P(p), P(q), n=n, size=size * 0.34, t=t,
                width=hw("mark_pt", 1.1))
    # v6 (E29): an arrow's tip stops short of a dot and of the next arrow's
    # start. svgcheck.arrowhead_clearance refuses a tip within 1.5pt of either
    # (the z08 '->->' hop chain; heads buried in the vertex dots A, B, C), so
    # the correct drawing is the default here rather than a refusal the
    # author has to route around by deleting the dots or the arrows.
    k_est = min(1.0, target / est) * 0.9
    gap = _ARROW_GAP_PT / (_PX_TO_PT * k_est)
    dots = [_dot_entry(d) for d in dots]
    mk_r = figkit.MARKER_R_PT / (_PX_TO_PT * k_est)
    if hu:
        gap = _ARROW_GAP_PT * hu
        mk_r = HOUSE["open_pt"] * hu
    discs = [(P(v), mk_r if st else hw("dot_pt", 2.0 * pen)) for v, st in dots] + \
        [(P(pt[0]), mk_r if len(pt) > 2 and pt[2] else hw("dot_pt", 2.4 * pen))
         for pt in points]
    ends = [(P(p), P(q)) for p, q in arrows]
    # A tip is pulled back from a dot (and from the start of an arrow that is
    # not its own next hop); the gap to its OWN next hop is made at that hop's
    # START instead, so the tip still lands on its value.
    nxt = {}
    for i, (a, b) in enumerate(ends):
        for j, (t, tip) in enumerate(ends):
            if i != j and _dist(b, t) < 1e-6 and not _dist(tip, a) < 1e-6:
                nxt[i] = j
    pulled = []
    for i, (p, q) in enumerate(arrows):
        a, b = ends[i]
        stops = [(c, r + gap) for c, r in discs]
        stops += [(t, gap) for j, (t, tip) in enumerate(ends)
                  if j != i and j != nxt.get(i)
                  and not (_dist(t, b) < 1e-6 and _dist(tip, a) < 1e-6)]
        pulled.append(_dist(b, _stop_short(a, b, stops)))
    # Hops in one chain (a tip where the next starts) keep ONE length and land
    # on their values. Pulling only the tips that land on something printed
    # equal hops at unequal lengths (z08 fig 20, the hops that set the
    # x-scale, ended at 9.2 and 10 units); pulling every tip back by the same
    # amount left the LAST tip short of its gridline (53.58 against the 20
    # tick at 56.55). So each hop of a chain loses the same amount: its tip
    # comes back by the largest dot pull D in the chain, and its start moves
    # up by what the gap to the previous tip still needs, max(0, gap - D).
    # With no dots every tip is exactly on its value.
    chain = list(range(len(ends)))

    def root(i):
        while chain[i] != i:
            chain[i] = chain[chain[i]]
            i = chain[i]
        return i
    for i, j in nxt.items():
        chain[root(i)] = root(j)
    most, linked = {}, set()
    for i in range(len(ends)):
        most[root(i)] = max(most.get(root(i), 0.0), pulled[i])
        if i in nxt:
            linked.add(root(i))
    for i, (p, q) in enumerate(arrows):
        a, b = ends[i]
        L = _dist(a, b)
        d = most[root(i)] if L > 0 else 0.0
        s0 = max(0.0, gap - d) if root(i) in linked and L > 0 else 0.0
        if d + s0 > 0.6 * L and L > 0:
            k = 0.6 * L / (d + s0)
            d, s0 = d * k, s0 * k
        if s0 > 0:
            a = (a[0] + (b[0] - a[0]) / L * s0, a[1] + (b[1] - a[1]) / L * s0)
        if d > 0:
            b = (b[0] - (b[0] - ends[i][0][0]) / L * d,
                 b[1] - (b[1] - ends[i][0][1]) / L * d)
        f.line(a, b, hw("main_pt", 1.5 * pen))
        geom.append((a, b))             # C6 r6: the shaft is data ...
        ux, uy = _unit(a, b)
        head = max(5.0 * pen, size * 0.42) if not hu else \
            max(HOUSE["arrow_head_pt"] * hu, size * 0.3)
        for sgn in (1, -1):
            # the two barbs, at ±28° from the shaft. C2 round 2: an arrowhead
            # is never cut. A pinned number the head covers slides, crosses
            # its axis or is refused; cut, the barbs of an arrow along the row
            # of x numbers printed as 1.4-unit stubs and the arrow as dashes.
            th = math.radians(28.0 * sgn)
            hx = -(ux * math.cos(th) - uy * math.sin(th)) * head
            hy = -(ux * math.sin(th) + uy * math.cos(th)) * head
            f.line(b, (b[0] + hx, b[1] + hy), hw("main_pt", 1.4 * pen),
                   role="head")
            geom.append((b, (b[0] + hx, b[1] + hy)))     # ... and so is its head
        # the shaft under the head is part of the head
        L = _dist(a, b)
        if L > 0:
            k = min(1.0, head * math.cos(math.radians(28.0)) / L)
            f._reg((b[0] - (b[0] - a[0]) * k, b[1] - (b[1] - a[1]) * k), b,
                   "head")

    def _dot(p, r):
        """Draw a point AND tell the placer it is there. Since v6 (E2) the
        core `Figure.dot` registers the disc itself, as a dot a tick number
        knows it may not cut."""
        f.dot(p, r=r, pad=_DOT_PAD)

    def _marker(p, st):
        if hu:
            # P1 (5): a marker at its printed house size, white-filled
            r_pt = HOUSE["dot_pt"] if st == "filled" else HOUSE["open_pt"]
            f.marker(p, st, r=r_pt * hu, width=HOUSE["marker_pt"] * hu,
                     r_pt=r_pt)
        else:
            f.marker(p, st)

    for v, st in dots:
        if st:
            _marker(P(v), st)
        else:
            _dot(P(v), hw("dot_pt", 2.0 * pen))
    for pt in points:
        v, name = pt[0], (pt[1] if len(pt) > 1 else None)
        st = pt[2] if len(pt) > 2 else None
        if st:
            _marker(P(v), st)           # v6 C3 (E8)
        else:
            _dot(P(v), hw("dot_pt", 2.4 * pen))
        if not name:
            continue
        owner = None
        for sp in shapes:
            if any(_dist(P(v), q) < 1e-6 for q in sp):
                owner = sp
                break
        if owner and len(owner) >= 3:
            f.vertex_label(P(v), name, poly=owner, size=lf)
        else:
            f.label(P(v), name, size=lf, kind="vertex")

    # v6 stage 1b: a curve's name, at a free end of it. The anchor is walked
    # back along the curve so the letter lands beside the end and the placer's
    # ring search only steps OFF the curve -- it never sits on it.
    for nm, pieces in curve_ends:
        at, prefer = _curve_anchor(pieces, (x_min, y_min, x_max, y_max),
                                   back=0.75 * max(xs, ys))
        f.label(P(at), nm, size=lf, italic=True, prefer=prefer)

    for group, italic in ((labels, True), (values, False)):
        for lb in group:
            at, txt = lb[0], lb[1]
            prefer = lb[2] if len(lb) > 2 else None
            # C2 r3: an upright NUMBER set straight beside its anchor is a
            # value scale's number ('20' right of a hand-drawn tick): centred
            # on the anchor's height, as a pinned axis number is. On its
            # baseline it stood 0.19 of a square above its tick, and the tick
            # sweep refused the pilot's figure 57 with a fix its author could
            # not apply.
            centred = (not italic and prefer is not None
                       and abs(prefer[1]) < 1e-9 and abs(prefer[0]) > 0
                       and figkit._numeric(figkit.svgcheck.true_minus(txt)))
            # stage review: a values= label is a NUMBER and prints at the
            # axis numbers' size (figkit.axes uses font * 0.92). At 0.95 it
            # printed 0.26pt LARGER than them at every width, so one figure
            # showed two sizes of the same-looking digit -- a '-4' standing
            # free in the grid read as an axis number that had slid into the
            # drawing.
            # ... and with the clearance the 0.95 box used to give the ring
            # search, so a shrunken number does not creep toward a
            # neighbouring stroke and lose its ownership
            f.label(P(at), txt, size=lf if italic else font * 0.92,
                    italic=italic, prefer=prefer,
                    gap=2.0 if italic else 2.0 + 0.03 * font,
                    centred=centred)
            # v6.1: mark it in the FILE as a value text. It prints at the
            # axis-number size by the decision just above; printed_letter_pt
            # used to count a non-numeric one ('x > 0', '3 cm') as a LETTER
            # and G78 then refused the sheet for the engine's own choice.
            if not italic:
                f.labels[-1].value_text = True
            if len(lb) > 3 and lb[3]:
                # v6 C3 (E24): ((x, y), "6", prefer, (p, q)) binds the value
                # to the segment p-q: kept nearer it than any other stroke
                f.labels[-1].owner = (P(lb[3][0]), P(lb[3][1]))

    svg = f.render(width=width)
    if width is None:
        cap = max_width or PAGE_MAX        # max_width=None: the page width
        m = re.search(r'<svg[^>]*\bwidth="([\d.]+)', svg)
        if m and float(m.group(1)) > cap:
            svg = f.render(width=cap)
    m = re.search(r'<svg[^>]*\bwidth="([\d.]+)"[^>]*viewBox="0 0 ([\d.]+)', svg)
    # C6 r5: a sketch drawn ON A GRID keeps the floor -- its squares are the
    # scale the reader counts, numbered or not. Lifted for every sketch, it
    # let sketch=True, ticks=False draw a 21-square plane in the side column
    # the numbered figure could not have, with no numbers at all.
    if m and (not sketch or grid):
        sq = float(m.group(1)) / float(m.group(2)) * size
        if sq < MIN_SQUARE_PX - 1e-6:
            raise AssertionError(
                "figkit_plus.plane(%s, %s): a grid square prints at %.1fpx, under "
                "the %.0fpx a student can count. Show fewer squares (a smaller "
                "range or a larger xscale/yscale) or give the figure more width."
                % (xr, yr, sq, MIN_SQUARE_PX))
    svg = assert_unstruck(svg, "plane(%s, %s)" % (xr, yr))
    # v6 stage 1b r3 (the brief's lost-ink clause (b)): the finished FILE is
    # measured against the lines, edges and curves the call handed in, moved
    # into the frame the render emitted them in. svgcheck walks the geometry
    # and asks whether ink lies ON it, so a hole in the middle of a curve is
    # seen -- comparing the two TOTALS alone, the axes and ticks would pay
    # for the missing piece.
    ox, oy = f.frame0
    svgcheck.assert_draws(svg, [((p[0] - ox, p[1] - oy), (q[0] - ox, q[1] - oy))
                                for p, q in geom],
                          "plane(%s, %s)" % (xr, yr))
    if not grid and svgcheck.GRID_OFF_TAG not in svg:
        # P1 r1: a plane with no grid says so, so house_look can tell a
        # deliberate one from a grid lost in print
        svg = svg.replace(">", ">" + svgcheck.GRID_OFF_TAG, 1)
    return figkit.tag(svg, fam) if fam else svg


# --------------------------------------------------------------- layout ---
# v5.6. Two placements the sheet never had. `emit_html` puts a figure narrower
# than SIDE_MAX beside the text and anything wider in a centred block, and the
# author measured the result: 49 figures in three packages, every one of them
# in the same column at the same size. Shapes varied; the page did not.

def row(figs, caps=None, gap=7):
    """A ROW of small figures with captions — returned as HTML for `fig=`.

        fig=row([f1, f2, f3], caps=["א", "ב", "ג"])

    Uses `table.figrow / .figbox / .figcap`, classes the house stylesheet has
    defined since v5 and nothing ever used. A caption may be Hebrew: it is
    HTML beside the SVG, not text inside it, so the no-Hebrew rule that governs
    figure interiors does not apply and G45 is not at risk.
    """
    if not figs:
        raise AssertionError("figkit_plus.row: no figures")
    caps = list(caps or [])
    cells = []
    for i, f in enumerate(figs):
        cap = ('<div class="figcap">%s</div>' % caps[i]) if i < len(caps) else ""
        cells.append('<td><div class="figbox">%s</div>%s</td>' % (f, cap))
    return ('<table class="figrow" style="border-spacing:%dpt 0"><tr>%s</tr>'
            '</table>' % (gap, "".join(cells)))


_WIDE = []


def wide(*args, **kw):
    """A FULL-WIDTH block figure: `plane()` with the side limit lifted, so the
    emitter places it above the items instead of beside them. The second
    placement a sheet needs in order not to read as one column of identical
    boxes (G77 check 3).

    C6 r6 (rule 5): wide() prints at width=max_width, and an explicit width=
    stops plane()'s enlarge rungs -- so wide() refused figures plane() drew
    in the side column, and told the author every knob was exhausted while
    wide(size=22) rendered. The width wide() sets is its own, not the
    author's: the squares still grow inside it. An author who passes width=
    to wide() keeps the old meaning."""
    kw.setdefault("max_width", WIDE_MAX)
    own = "width" not in kw
    kw.setdefault("width", kw["max_width"])
    if not own:
        return plane(*args, **kw)
    _WIDE.append(1)
    try:
        return plane(*args, **kw)
    finally:
        _WIDE.pop()


# v6.5 X2 r1 (MUST-3, spec rule 6): the author's call into this module
# is recorded as source, so figures/<id>.py can re-draw the figure.
import export as _export_rec  # noqa: E402
plane = _export_rec.entry(plane)
wide = _export_rec.entry(wide)
