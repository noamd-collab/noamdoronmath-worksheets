# -*- coding: utf-8 -*-
r"""rectkit — v1.0. A parametric rectangle for euclid._Fig, so the ט׳ rectangle
page stops drawing the same 2.3x1.35 box thirteen times.

WHY THIS FILE EXISTS
--------------------
`euclid.quad("rectangle")` is a fixed shape ([(0,0),(2.3,0),(2.3,1.35),(0,1.35)])
because `quad()` serves the whole quadrilateral family and every kind in it is
verified from that one fixed vertex list (see euclid.py's V dict). A rectangle
page needs a DIFFERENT proportion per question (15x6, 16x12, a square-ish one
for the equilateral-triangle diagonal case, ...) plus computed extras a fixed
quad never has: the diagonals' intersection O, a point at a given ratio along
a side (E, F, M), the true perpendicular foot of an altitude to a diagonal
(H), an interior point (P). None of that is a new geometry primitive — it is
all `euclid._Fig`, used directly, the same way `euclid.triangle_with` computes
its altitude's foot instead of placing it at a fixed fraction.

This file does not touch `euclid.py`. `euclid.quad("rectangle", ...)` keeps
working exactly as before; nothing here changes its signature or its output.

    from rectkit import rect_base, point_on, foot_to_line, angle_mark
    g, d = rect_base(w=2.5, h=1.0, rotate=0, fam="quad.rectangle+diagonals+E-on-DC")
    E = point_on(g, d["D"], d["C"], 0.4, "E")
    svg = g.render("quad.rectangle+diagonals+E-on-DC")

RULES THIS FILE FOLLOWS (from euclid.py's own doctrine)
--------------------------------------------------------
1. `w, h` are the DATA's proportion (AB=15, AD=6 -> w=2.5, h=1.0), not a fixed
   look. `rect_base` never returns the same w:h for two different questions.
2. `rotate=` is a parameter of every builder here, same as euclid.py's own
   ("rotation must not buy variety from the gate" — G76 keys on `fam`, not on
   coordinates). Every call below passes `rotate=` explicitly.
3. Every computed point (O, and anything point_on/foot_to_line places) is
   worked out in the SAME pre-rotation coordinate frame as the base rectangle
   (`g.pts[handle]`, before `_Fig._render_once` rotates and fits the whole
   point set) — exactly how `euclid.triangle_with`'s altitude/median/bisector
   compute their extra points from `A0, B0, C0`. That is what makes rotation
   move the whole figure, extras included, as one rigid body instead of
   leaving a computed point behind.
4. `fam=` is required on every call site (not defaulted here) so G76 counts a
   rotated copy of the same configuration as ONE object, per euclid.py's own
   `_tag` / gate_variety.figure_family_plus contract.
5. Labels are Latin letters and digits only, as everywhere in figkit; Hebrew
   stays in the question text.
"""
import math

import euclid
from euclid import _Fig

__all__ = ["rect_base", "point_on", "foot_to_line", "angle_mark"]


def rect_base(w=2.3, h=1.35, rotate=0.0, names="ABCD", diagonals=True,
              width=None, marks=True, fam=None):
    """A real w:h rectangle (not euclid.quad's fixed 2.3x1.35), diagonals and
    their intersection O optional. `w, h` are figure units in the SAME
    pre-rotation frame every helper below reads from `g.pts`.

    `marks=False` (mirrors euclid.quad's own parameter of the same name)
    drops the four "opposite sides equal" ticks and the right-angle mark at
    A, drawing the bare rectangle + diagonals only. Use it for a question
    that puts its OWN point(s) on a ticked side: a tick sits at the side's
    exact middle, and svgcheck's independent reader re-measures which piece
    of the side a tick names from every dot that lands on it (v6.1's own
    doctrine: "read back from the finished SVG"). Two points placed
    symmetrically about a side's midpoint (DE=CF on DC, say) make that
    middle piece read as what the tick names instead of the whole side — a
    genuine ambiguity, not a false alarm, and `render()` refuses it (caught
    here at rotate=37 in rectkit's own selfcheck; euclid.quad never hits it
    because it never puts a caller's point on one of its own fixed sides).

    Returns `(g, d)`: `g` is the open `_Fig` (call `g.render(fam)` yourself
    once every extra for this question has been added — see the module
    docstring); `d` has the vertex handles `A, B, C, D`, the diagonals'
    intersection `O` (`None` if `diagonals=False`), and `w, h` themselves.
    """
    g = _Fig(rotate, euclid._SIZE, width)
    A, B, C, D = g.P((0, 0), (w, 0), (w, h), (0, h))
    idx = [A, B, C, D]
    g.poly(idx)
    for i, nm in zip(idx, names):
        g.name(i, nm, poly=idx)
    if marks:
        # 1 tick on AB/CD, 2 on BC/DA — the same convention euclid.quad uses
        # for "parallelogram"/"rectangle" (opposite sides equal, adjacent
        # sides not).
        g.ticks(A, B, 1)
        g.ticks(C, D, 1)
        g.ticks(B, C, 2)
        g.ticks(D, A, 2)
        g.right(A, B, D)
    O = None
    if diagonals:
        g.line(A, C, dash="4,3", w=1.2)
        g.line(B, D, dash="4,3", w=1.2)
        O = g.P((w / 2.0, h / 2.0))
        g.dot(O)
        g.mark(O, "O", prefer=(0.4, -0.5))
    return g, dict(A=A, B=B, C=C, D=D, O=O, w=w, h=h)


def point_on(g, P, Q, t, name, prefer=None):
    """A point on segment PQ at ratio `t` from P (0..1; 0.5 is the midpoint).
    Computed from `g.pts`, so it rotates and scales with the rest of the
    figure instead of being pasted on afterwards."""
    x1, y1 = g.pts[P]
    x2, y2 = g.pts[Q]
    R = g.P((x1 + (x2 - x1) * t, y1 + (y2 - y1) * t))
    g.dot(R)
    g.mark(R, name, prefer=prefer)
    return R


def foot_to_line(g, P, A, B):
    """The true perpendicular foot of P onto line AB — computed by
    projection, not placed at a fixed fraction of AB. Marks the right angle
    at the foot; `figkit.Figure.right_angle` itself measures that angle and
    raises if it is not 90 degrees (+/- 0.5), so a wrong projection refuses
    to render rather than shipping a picture that contradicts its own claim.
    """
    px, py = g.pts[P]
    ax, ay = g.pts[A]
    bx, by = g.pts[B]
    vx, vy = bx - ax, by - ay
    t = ((px - ax) * vx + (py - ay) * vy) / float(vx * vx + vy * vy)
    H = g.P((ax + vx * t, ay + vy * t))
    g.dot(H)
    g.line(P, H, w=1.2)
    g.right(H, A, P)
    return H


def angle_mark(g, V, A, B, deg_text, n=1):
    """Arc the wedge at V between rays VA and VB and print its degree number
    at V. The number is a bare figure (e.g. "28°"), which `_Fig._label_pt`
    already prints at the sheet's NUMBER size, same as every other angle
    number in euclid.py."""
    g.arc(V, A, B, n=n)
    g.mark(V, deg_text)
