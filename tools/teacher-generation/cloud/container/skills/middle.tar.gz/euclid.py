# -*- coding: utf-8 -*-
r"""euclid — v5.6. Geometry without a coordinate system: the figures a ז׳–ט׳
sheet is actually made of.

WHY THIS FILE EXISTS
--------------------
Everything v5.3–v5.5 added draws on a grid. But most of middle-school geometry
is not on a grid: two parallels cut by a transversal, a triangle with its
altitude, a pair of congruent triangles, a circle with a tangent. Before this
file the skill could draw exactly two of those objects — `figkit.triangle` and
`trapz_kit.trapezoid` — and everything else was hand-built SVG, which is
outside every check the engine has.

WHAT A EUCLIDEAN FIGURE MUST SATISFY, AND IT IS NOT THE SAME LIST
-----------------------------------------------------------------
1. **The givens must determine the drawing.** `trapz_kit` retired
   `quad_from_angles` for exactly this: two supplementary angles do not fix a
   trapezoid, the old construction closed the freedom by symmetry, and it
   shipped a PARALLELOGRAM on a sheet whose question was "prove AB ∥ DC" — the
   picture answered the question. Every builder here is laid out from
   parameters that fix the shape, and asserts the property it claims.
2. **It must rotate.** A page of upright triangles reads as one picture.
   `trapz_kit` calls rotation "the cheapest honest variety there is: same
   mathematics, different picture", and it is right — so `rotate=` is a
   parameter of EVERY builder here, not of some. `selfcheck_plus` walks
   `__all__` and checks each one at 0° and 37°.
3. **Rotation must not buy variety from the gate.** G76 counts objects; if a
   rotated copy were a new object, an author could satisfy it by turning one
   triangle five ways — which is the drill the gate exists to stop. So every
   figure here DECLARES its configuration in an SVG comment
   (`<!--fam:triangle.right+altitude-->`) and `gate_variety.figure_family_plus`
   keys on that. Rotation and scale collapse to one object; a right triangle
   with an altitude and an isosceles triangle with a median stay two.
   v6 C3 r2 (E10): every builder here takes `fam=` to declare another name.

    from euclid import (parallels, angles_at_point, triangle_with,
                        congruent_pair, circle_fig, quad)

    parallels(angle=58, mark=(1, 5), rotate=12)
    triangle_with("right", cevian="altitude", rotate=-20)
    congruent_pair("sas", rotate=8)
    circle_fig(("centre", "radius", "tangent"), rotate=30)
    quad("rhombus", diagonals=True, rotate=18)

Labels inside a figure are Latin and digits, as everywhere in figkit; the
Hebrew belongs in the question text.
"""
import math
import re

import figkit
from figkit import Figure, _fit, _fit_k
from figkit_plus import assert_unstruck

__all__ = ["parallels", "angles_at_point", "triangle_with", "congruent_pair",
           "circle_fig", "quad"]

_SIZE = 150.0
# svgcheck._marked_length counts a stroke end as standing ON a line when it is
# within this many SVG units of it (its on_line tolerance). The tick solver
# has to use the same number or it dodges the wrong things.
_ON_LINE = 0.8


# --------------------------------------------------------------- helpers ---
def _rot(pts, deg, centre=None):
    if not deg:
        return list(pts)
    if centre is None:
        centre = (sum(p[0] for p in pts) / float(len(pts)),
                  sum(p[1] for p in pts) / float(len(pts)))
    a = math.radians(deg)
    ca, sa = math.cos(a), math.sin(a)
    cx, cy = centre
    return [(cx + (x - cx) * ca - (y - cy) * sa,
             cy + (x - cx) * sa + (y - cy) * ca) for x, y in pts]


def _tag(svg, fam):
    """Declare the configuration, once, right after the opening tag. v6 C3
    (E10): now `figkit.tag`, public; this name stays for existing levels."""
    return figkit.tag(svg, fam)


class _TickCrowded(AssertionError):
    """No position ON the side reads as the whole side (v6.3 r1). It is an
    AssertionError, so every harness that catches one still catches it; the
    tick is NOT dropped -- `_tick_plan` turns it into a span bracket."""


class _Fig(object):
    """A Euclidean drawing in maths coordinates (y up), rotated as a whole and
    fitted to the page once. Every stroke goes through `figkit.Figure`, so the
    label solver, the font floor and the struck-label sweep all still apply."""

    def __init__(self, rotate=0.0, size=_SIZE, width=None, font=12):
        self.rotate, self.size, self.width, self.font = rotate, size, width, font
        self.pts, self.ops = [], []
        # pt per figure unit once the house solver knows it (None = draw the
        # v5.6 way, in figure units)
        self.house = None
        # Checks that can only be judged in PRINTED pt (doctrine 6): they are
        # registered while the figure is built and run by render(), which is
        # the first moment the fit scale and the display width both exist.
        self._late = []
        # v6.5 X2: the constraints an add-on states while the figure is still
        # a list of ops. They are kept in HANDLES (indices into self.pts),
        # because the drawing frame does not exist until _render_once fits
        # the figure; the handles are mapped there, from the same Q() that
        # places the ink.
        self._cons = []
        self._objs = []          # v6.8 G7: lines / rays, in handles
        self._unit = None        # drawing units per data unit, set by the fit

    def constrain(self, ctype, source="derived", item=None, marked=False,
                  strict=False, **fields):
        """State a fact about this figure, in point HANDLES.

        `shapekit.side_label(g, d, "A", "B", "5")` says so here; at render
        the handles become the coordinates the ink was drawn at, and
        export.py resolves them into names (`length of="AB" value=5`) and
        re-measures the claim on the finished SVG."""
        self._cons.append((ctype, dict(fields), source, item, marked, strict))
        return self

    def export_obj(self, kind, handles, name=None, role="data"):
        """v6.8 G7: an object the figure draws as more than one stroke (a
        ray: a side and its extension) -- exported with its own id (ray-AB,
        from A through B), on the ink it runs along."""
        self._objs.append((kind, list(handles), name, role))
        return self

    def _replay_cons(self, f, Q):
        for kind, hs, name, role in getattr(self, "_objs", []):
            f.ex.add(kind, [tuple(Q(h)) for h in hs], role=role, name=name)
        def m(v):
            if isinstance(v, int) and not isinstance(v, bool):
                return tuple(Q(v))
            if isinstance(v, (list, tuple)):
                return [m(x) for x in v]
            return v
        for ctype, fields, source, item, marked, strict in self._cons:
            f.ex.constrain(ctype, source=source, item=item, marked=marked,
                           strict=strict,
                           **dict((k, m(v)) for k, v in fields.items()))

    def _w(self, w):
        """A stroke's width in figure units. Under the house look every
        weight is pinned in PRINTED pt around HOUSE['main_pt'], keeping the
        builder's relative weights (1.5 is the main line)."""
        if not self.house:
            return w
        import figkit_plus as FP
        return FP.HOUSE["main_pt"] / self.house * (float(w) / 1.5)

    def _text_pt(self, key):
        """A text size in figure units at the house printed size."""
        import figkit_plus as FP
        return FP.house_text_pt(key) / self.house

    def _label_pt(self, text):
        """A bare number (an angle, a length) prints at the sheet's NUMBER
        size; everything else is a name and prints at its LETTER size."""
        t = (text or "").strip()
        num = re.fullmatch(u"[\u2212+-]?\\d+(?:[.,]\\d+)?\u00b0?", t)
        return self._text_pt("number_pt" if num else "letter_pt")

    def P(self, *pts):
        """Register points and get back handles (indices into the fitted set)."""
        out = []
        for p in pts:
            self.pts.append((float(p[0]), float(p[1])))
            out.append(len(self.pts) - 1)
        return out[0] if len(out) == 1 else out

    def defer(self, fn, who="figure"):
        """Register a check that needs the PRINTED size. `fn(ptu, disp)` is
        called once by render() with the printed pt per DATA unit and the
        display width in px, and refuses by raising, exactly as an immediate
        check does. A ratio judged at build time cannot stand in for this:
        the same ratio prints at 4.6pt on a 194px figure and at 10.3pt on a
        430px one, and only the second number says whether a reader sees the
        gap."""
        self._late.append((fn, who))

    def _run_late(self, svg):
        if not self._late or not svg:
            return
        import figkit_plus as FP
        ppu = FP._printed_scale(svg)
        if not ppu or not self._unit:
            return
        disp = float(re.search(r'<svg[^>]*\bwidth="([\d.]+)', svg).group(1))
        for fn, _who in self._late:
            fn(self._unit * ppu, disp)

    def _op(self, kind, **kw):
        self.ops.append((kind, kw))

    def line(self, a, b, **kw):
        self._op("line", a=a, b=b, **kw)

    def poly(self, idx, **kw):
        self._op("poly", idx=idx, **kw)

    def circle(self, c, rim, **kw):
        """`rim` is a point handle on the circle — so the radius rotates and
        scales with everything else instead of being a second unit."""
        self._op("circle", c=c, rim=rim, **kw)

    def dot(self, a):
        self._op("dot", a=a)

    def right(self, v, a, b):
        self._op("right", v=v, a=a, b=b)

    def arc(self, v, a, b, n=1, r=17):
        self._op("arc", v=v, a=a, b=b, n=n, r=r)

    def ticks(self, a, b, n=1, t=None):
        """`t` is the fraction along a->b the group stands at. v6.3: left
        None, it is SOLVED at render time (see `_tick_t`) so that a tick on a
        side that carries named points still reads as naming the WHOLE side."""
        self._op("ticks", a=a, b=b, n=n, t=t)

    def parallel(self, a, b, n=1, t=None):
        """v6.3: parallel-arrow chevrons on a->b — the mark that says "these
        two sides are parallel". `_Fig` had no way to draw it, so every
        builder that needed one had to leave the claim unmarked."""
        self._op("parallel", a=a, b=b, n=n, t=t)

    # ------------------------------------------------ v6.3: tick-vs-point ---
    # THE DEFECT. svgcheck reads a tick back from the finished SVG and asks
    # which PIECE of the carrier it names: of the pieces between a stop behind
    # it and one ahead of it (the ends, every vertex, every cevian foot, every
    # dot), the tick names the one whose middle it stands nearest, and the
    # shorter wins a tie (svgcheck._marked_length). A tick sits at the side's
    # exact middle. Put two points on that side SYMMETRICALLY about its middle
    # (DE = CF on DC — an everyday ז׳–ט׳ configuration) and the middle piece EF
    # has its middle in the same place: a tie, won by the shorter piece, so the
    # tick reads as "EF = AB". That is a genuine ambiguity on paper, not a
    # false alarm, and render() refused the figure.
    #
    # rectkit worked around it with marks=False, which deletes the four
    # equality ticks AND the right angle — doctrine 4's forbidden escape: the
    # cure threw away the information the sheet needs. The fix belongs here:
    # only the tick moves. Slid a little off the middle, the whole side wins
    # the nearest-middle contest outright (its score grows as |d|/L, the inner
    # piece's as |d|/L_inner, and L_inner < L), so the tick goes on saying what
    # it always said and svgcheck reads it that way with no rule relaxed.
    # `marks=False` stays available; it is no longer the cure.
    # Measured on the shapes gallery, not guessed. At 0.055 the tick landed
    # right beside the dot it was dodging (a square's AB tick 5% past its
    # midpoint M) and at a win margin of 0.015 it slid so little that a reader
    # still saw it as centred on the inner piece -- the ambiguity it exists to
    # remove. 0.10 keeps it visibly clear of any point, 0.04 makes the whole
    # side win by a margin a reader can see, and the search starts at the
    # middle and works outwards, so the slide is always the smallest that works.
    _TICK_CLEAR = 0.10         # keep the group this far (of L) from any stop
    _TICK_MAX = 0.30           # never slide further than this from the middle
    _TICK_WIN = 0.04           # the whole side must win by this much, rounded
    # r1 (solved-tick-still-reads-as-the-inner-piece). The three above are
    # svgcheck's arithmetic; this one is the EYE. svgcheck compares a tick's
    # offset from a piece's middle as a FRACTION of that piece, so a slide of
    # 0.04 of the side beats a piece half as long. On paper both middles are
    # the same number of millimetres away, and for a symmetric pair (E at
    # 0.25, F at 0.75) they are the SAME POINT: the tick sat between E and F
    # and a student read EF, not DC. So the whole side must also win by a
    # distance a reader can see -- and when no position does, the mark is not
    # squeezed onto the side at all: it goes on a span bracket tied to the two
    # endpoints (figkit.Figure.span_ticks), which is the second route
    # BRIEF_V63 2 offers and the only one that is unambiguous to a reader.
    _TICK_EYE = 0.06           # of the side, on paper, over any piece holding it
    _TICK_INK = 0.02           # ... but a circle grazing it only needs ink room
    # Re-deriving these later: svgcheck's nearest-middle rule does NOT fire at
    # axis-aligned rotations (a side lying on a page axis is read by
    # _axis_edge_groups, which asks a different question), so the symmetric
    # E,F figure was refused at 5, 15 and 37 degrees and rendered clean at 0
    # and 90. A level shipped only at rotate=0 was never protected by it.
    # Measure any new value at an off-axis rotation, or it will look as though
    # nothing is wrong. (r1, svgcheck-tick-rule-rotation-dependent.)
    _SPAN_OUT = 11.0           # how far outside the shape a span bracket sits
    # v6.4 T2-6: ... and how far the NEXT one out sits. Two brackets on one
    # line was the whole of the polygon+incircle+midpoint defect: the side
    # A-B and its half M-B both ran out of room on the side (the incircle
    # stands on the middle of every side), both went on a span bracket, and
    # a piece's bracket is parallel to its side at the same offset as the
    # whole side's -- so the two lay ON each other, svgcheck read one carrier
    # 93.4 long carrying both groups, and the figure was refused at 16 of 26
    # rotations for marks that were each right. Stacked, the shortest sits
    # innermost, the way a drawing office chains dimensions.
    _SPAN_STEP = 9.0

    def _tick_stops(self, a, b, kinds="all", win=None):
        """The stops svgcheck will find on segment a->b, as fractions along
        it: every dot and every stroke end that lands strictly inside it.
        Read from the ops, the same objects svgcheck reads from the SVG.

        v6.4 T2-6: `win=(lo, hi)` widens the window past the segment's own
        ends -- the reader does not stop at them. It reads the whole CARRIER
        the segment lies on (see _tick_extent), so a stop just outside a
        half-side cuts a piece that competes with that half.""" 
        ax, ay = self.pts[a]
        bx, by = self.pts[b]
        vx, vy = bx - ax, by - ay
        L2 = vx * vx + vy * vy
        if L2 <= 0:
            return []
        L = math.sqrt(L2)
        tol = 0.006 * L
        cand = []
        for kind, kw in self.ops:
            if kind == "dot":
                cand.append(kw["a"])
            elif kind == "line":
                cand += [kw["a"], kw["b"]]
            elif kind == "poly":
                cand += list(kw["idx"])
        out = []
        lo_w, hi_w = win or (0.0, 1.0)
        for i in cand:
            px, py = self.pts[i]
            s = ((px - ax) * vx + (py - ay) * vy) / L2
            if not lo_w + 1e-6 < s < hi_w - 1e-6:
                continue
            if abs((px - ax) * vy - (py - ay) * vx) / L > tol:
                continue
            out.append(s)
        if kinds == "points":
            # what a READER sees cutting the side: a dot, a vertex, a cevian's
            # foot. A circle grazing the side is a stop for svgcheck (its
            # 48-gon drops a vertex there) but not a piece a reader reads, so
            # the eye rule in _tick_t asks for this list, not the full one.
            return sorted(set(round(v, 6) for v in out))
        # r1 fix (polygon-incircle-refused-at-rot0): a CIRCLE standing on the
        # side stops it too, and the solver could not dodge what it could not
        # see -- it collected dots and stroke ends only, so a regular
        # polygon's incircle (which touches every side at its MIDDLE, exactly
        # where the tick stands) had the figure refused at rotate 0 and 90.
        #
        # svgcheck reads a <circle> as a 48-gon and counts every vertex of it
        # that lands within 0.8 of the side as a stop, so the stops are not
        # just the contact point: near a tangency the chords hug the side and
        # several vertices land on it, in a cluster whose width depends on the
        # radius AND whose phase depends on the rotation (which is why the
        # defect was rotation-dependent). The same 48 points are built here,
        # in the same PAGE frame svgcheck reads, so the solver sees exactly
        # what the checker will see -- no safety margin guessed, and no
        # figure refused for a stop that is not really there.
        circ = [kw for kind, kw in self.ops if kind == "circle"]
        if circ:
            pg = self._page_pts()
            (pax, pay), (pbx, pby) = pg[a], pg[b]
            pvx, pvy = pbx - pax, pby - pay
            pL2 = pvx * pvx + pvy * pvy
            pL = math.sqrt(pL2) if pL2 > 0 else 0.0
            for kw in circ:
                cx, cy = pg[kw["c"]]
                rx, ry = pg[kw["rim"]]
                R = math.hypot(rx - cx, ry - cy)
                if R <= 0 or pL <= 0:
                    continue
                for i in range(48):
                    th = 2.0 * math.pi * i / 48.0
                    px = cx + R * math.cos(th)
                    py = cy + R * math.sin(th)
                    if abs((px - pax) * pvy - (py - pay) * pvx) / pL > _ON_LINE:
                        continue
                    sfrac = ((px - pax) * pvx + (py - pay) * pvy) / pL2
                    if lo_w + 1e-6 < sfrac < hi_w - 1e-6:
                        out.append(sfrac)
        return sorted(set(round(s, 6) for s in out))

    def _span_offsets(self):
        """{(a, b): offset} for every equality mark this figure will put on a
        span bracket. Brackets that would land on ONE line are stacked, the
        shortest innermost (see _SPAN_STEP)."""
        spans = []
        for kind, kw in self.ops:
            if kind != "ticks" or kw.get("t") is not None:
                continue
            if self._tick_plan(kw["a"], kw["b"])[0] == "span":
                spans.append((kw["a"], kw["b"]))
        groups = []
        for a, b in spans:
            ax, ay = self.pts[a]
            bx, by = self.pts[b]
            L = math.hypot(bx - ax, by - ay) or 1.0
            ux, uy = (bx - ax) / L, (by - ay) / L
            for grp in groups:
                (ga, gb) = grp[0]
                gax, gay = self.pts[ga]
                gbx, gby = self.pts[gb]
                gL = math.hypot(gbx - gax, gby - gay) or 1.0
                gux, guy = (gbx - gax) / gL, (gby - gay) / gL
                if abs(ux * guy - uy * gux) > 1e-3:
                    continue
                if abs((ax - gax) * guy - (ay - gay) * gux) > 0.01 * gL:
                    continue
                grp.append((a, b))
                break
            else:
                groups.append([(a, b)])
        out = {}
        for grp in groups:
            grp.sort(key=lambda s: math.hypot(
                self.pts[s[1]][0] - self.pts[s[0]][0],
                self.pts[s[1]][1] - self.pts[s[0]][1]))
            for k, s in enumerate(grp):
                out[s] = self._SPAN_OUT + k * self._SPAN_STEP
        return out

    def _tick_extent(self, a, b):
        """(lo, hi): the CARRIER a->b lies on, in a->b's own fractions -- the
        whole side is (0.0, 2.0) for its half A-M, and (0.0, 1.0) when
        nothing continues it. svgcheck reads a tick's carrier this way (it
        chains collinear strokes end to end), so the solver has to.

        v6.4 T2-6 (polygon-incircle-midpoint-refused-at-most-rotations): the
        solver below made a group read as naming its own segment against the
        pieces INSIDE it, and never against the longer segment it lies on.
        svgcheck reads every segment of the figure, so a group on the half
        A-M that slid towards M scored better against the WHOLE side than
        against its half, and one 2-tick group then claimed 93.4 while its
        twin claimed 46.7 -- refused at 16 of 26 rotations, with the counts
        the message sent the author to (n=3, n=4) refused as well."""
        ax, ay = self.pts[a]
        bx, by = self.pts[b]
        vx, vy = bx - ax, by - ay
        L2 = vx * vx + vy * vy
        if L2 <= 0:
            return []
        L = math.sqrt(L2)
        tol = 0.006 * L
        segs = []
        for kind, kw in self.ops:
            if kind == "line":
                segs.append((kw["a"], kw["b"]))
            elif kind == "poly":
                idx = list(kw["idx"])
                segs += [(idx[i], idx[(i + 1) % len(idx)])
                         for i in range(len(idx))]
        lo, hi = 0.0, 1.0
        grew = True
        while grew:
            grew = False
            for i, j in segs:
                ss = []
                for h in (i, j):
                    px, py = self.pts[h]
                    if abs((px - ax) * vy - (py - ay) * vx) / L > tol:
                        ss = None
                        break
                    ss.append(((px - ax) * vx + (py - ay) * vy) / L2)
                if not ss:
                    continue
                s0, s1 = min(ss), max(ss)
                if s1 < lo - 1e-6 or s0 > hi + 1e-6:
                    continue          # collinear but not touching the run
                if s0 < lo - 1e-6:
                    lo, grew = s0, True
                if s1 > hi + 1e-6:
                    hi, grew = s1, True
        return lo, hi

    def _page_pts(self):
        """The figure's points in the frame the SVG is written in -- exactly
        the transform _render_once uses, so a stop solved here is a stop the
        finished SVG really has."""
        pts = _rot(self.pts, self.rotate)
        return _fit([(x, -y) for x, y in pts], self.size)

    def _tick_t(self, a, b, eye=True):
        """The fraction along a->b where a group of equality ticks still reads
        as naming the WHOLE side. None means "the middle" (nothing is on the
        side, so nothing can steal the tick) — the v5.6 behaviour, unchanged
        for every figure that has no point on a ticked side."""
        ext = self._tick_extent(a, b)
        stops = self._tick_stops(a, b, win=ext)
        if not stops and ext == (0.0, 1.0):
            return None
        S = sorted(set([0.0, 1.0, ext[0], ext[1]] + list(stops)))
        # the ends and every stop a reader can SEE: only a piece bounded by
        # two of these is a piece the eye rule is about
        seen = set([0.0, 1.0, ext[0], ext[1]]) | \
            set(self._tick_stops(a, b, "points", win=ext))

        def score(lo, hi, t):
            return round(abs((t - lo) / (hi - lo) - 0.5), 2)

        def wins(t):
            # clearance is about the READER: a tick must not crowd a point
            # that cuts the side. A circle grazing the side is not such a
            # point -- it is a stop svgcheck counts (its 48-gon drops
            # vertices there) but nothing a reader reads as a division -- so
            # it only has to stay clear of its ink.
            for v in S:
                if abs(t - v) < (self._TICK_CLEAR if v in seen
                                 else self._TICK_INK):
                    return False
            whole = score(0.0, 1.0, t)
            for i in range(len(S)):
                for j in range(i + 1, len(S)):
                    if (S[i], S[j]) == (0.0, 1.0):
                        continue          # the segment this mark names
                    if not S[i] < t < S[j]:
                        continue
                    if score(S[i], S[j], t) - whole < self._TICK_WIN:
                        return False
                    # the eye: this piece holds the tick, so its middle must
                    # be further from the tick than the side's middle is, by
                    # a distance on PAPER and not only in svgcheck's score
                    if eye and S[i] in seen and S[j] in seen and \
                            abs(t - (S[i] + S[j]) / 2.0) - abs(t - 0.5) \
                            < self._TICK_EYE:
                        return False
            return True

        if wins(0.5):
            return None
        step = 0.005
        k = 1
        while k * step <= self._TICK_MAX:
            for t in (0.5 + k * step, 0.5 - k * step):
                if 0.0 < t < 1.0 and wins(t):
                    return t
            k += 1
        raise _TickCrowded(
            "euclid: no position ON this side reads as naming the WHOLE side "
            "— the points already on it own every one (stops at %s). "
            "_tick_plan catches this and puts the mark on a span bracket tied "
            "to the two endpoints instead; a caller that reaches _tick_t "
            "directly has to handle it, or pass an explicit t=."
            % ", ".join("%.2f" % s for s in stops))

    def _arrow_t(self, a, b):
        """Where the parallel-arrow chevrons on a->b go. They dodge whatever
        stands on the segment, but they never need a span bracket and are
        never refused: a chevron claims a DIRECTION, and every piece of a
        segment runs the same way as the whole, so a chevron read as naming a
        piece says nothing false. (An equality tick claims a LENGTH, which is
        exactly the claim a piece breaks -- that is the defect _tick_plan
        exists for.)"""
        if not self._tick_stops(a, b):
            return None
        try:
            return self._tick_t(a, b, eye=False)
        except _TickCrowded:
            return None

    def _tick_plan(self, a, b):
        """How the equality mark on a->b is drawn. `("tick", t)` puts the
        group ON the side at fraction `t` (`None` = the exact middle, the
        v5.6 behaviour of a side with nothing on it). `("span", None)` says
        no position on the side reads as the WHOLE side -- the points on it
        own every one -- so the mark goes on a span bracket tied to a and b.
        Nothing is ever dropped and `marks=False` is never the cure."""
        if not self._tick_stops(a, b):
            return ("tick", None)
        try:
            return ("tick", self._tick_t(a, b))
        except _TickCrowded:
            return ("span", None)

    @staticmethod
    def _outward(pts, a, b):
        """A unit normal to a->b pointing AWAY from the figure (page frame),
        so a span bracket never lands inside the shape."""
        cx = sum(p[0] for p in pts) / float(len(pts))
        cy = sum(p[1] for p in pts) / float(len(pts))
        (ax, ay), (bx, by) = pts[a], pts[b]
        vx, vy = bx - ax, by - ay
        L = math.hypot(vx, vy) or 1.0
        nx, ny = vy / L, -vx / L
        mx, my = (ax + bx) / 2.0, (ay + by) / 2.0
        if (mx - cx) * nx + (my - cy) * ny < 0:
            nx, ny = -nx, -ny
        return (nx, ny)

    def name(self, a, text, poly=None):
        self._op("name", a=a, text=text, poly=poly)

    def mark(self, a, text, prefer=None, owner=None):
        """A text at handle `a`. `owner=(i, j)`: the segment it states
        something about (a side's length), for the deliverable's
        lbl-<side> id -- it does not change where the text is placed."""
        if owner is None:
            self._op("mark", a=a, text=text, prefer=prefer)
        else:
            self._op("mark", a=a, text=text, prefer=prefer,
                     owner=tuple(owner))

    def render(self, fam):
        """Draw, then run the checks that could only be judged once the
        figure had a printed size (`defer`)."""
        svg = self._render_body(fam)
        self._run_late(svg)
        return svg

    def _render_body(self, fam):
        """Draw at the SHEET'S HOUSE SIZE, and only if that cannot be drawn,
        fall back to the old grow-from-below loop and say so in the SVG.

        Stage review (the author, 2026-09-18): v6.1 gave plane()/wide() one
        printed look per sheet and left every other figure kind following its
        own width. On the skill's own gallery page 6 the two figures of ONE
        question printed their angle numbers at 7.2pt and 8.9pt and their
        strokes at 0.91 and 1.24pt — the author's "numbers the same printed
        size on every figure of a sheet", failing on the showcase document.
        The printed size is font x display / viewBox x 0.75, and the viewBox
        is only known after the labels are placed, so the font is solved by
        re-drawing: two or three passes settle it."""
        import figkit_plus as FP
        font0 = self.font
        try:
            if FP.SHEET.get("house", True):
                svg = self._house_render(fam)
                if svg is not None:
                    return svg
                # the house size cannot be drawn here: draw the old way and
                # SAY SO in the figure, so G78 reports it to the author
                # instead of letting a second look ship silently
                self.house = None
                self.font = font0
                return FP._fallback(
                    self._grow(fam),
                    dict(fig=fam, width=self.width or "auto", renders_at="none"))
            return self._grow(fam)
        finally:
            self.font = font0
            self.house = None

    def _grow(self, fam):
        """v5.6: if the labels come out under the 7pt floor, draw again
        bigger. The author's cheapest fix for a refusal is to delete labels —
        the wrong outcome. `verify()` still decides."""
        font0 = self.font
        for attempt in range(8):
            self.font = font0 * (1.09 ** attempt)
            try:
                return self._render_once(fam)
            except AssertionError as e:
                if "below the" not in str(e) or attempt == 7:
                    raise
        raise AssertionError("unreachable")

    def _house_render(self, fam):
        """Solve the font so the figure's text prints at the house size.
        Returns None (and leaves nothing behind) when the house size cannot
        be drawn — the caller then draws the old way and the SVG carries
        figkit_plus's fallback tag, which G78 reads."""
        import figkit_plus as FP
        want = FP.house_text_pt("letter_pt")
        # the first pass only has to EXIST -- it is read for pt-per-unit --
        # so it is drawn the v5.6 way, floor loop and all
        svg = self._grow(fam)
        ppu = FP._printed_scale(svg)
        if not ppu:
            return None
        for _ in range(5):
            self.house, self.font = ppu, want / ppu
            try:
                got = self._render_once(fam)
            except AssertionError:
                return None
            p = FP._printed_scale(got)
            if not p:
                return None
            svg = got
            if abs(p - ppu) <= 0.004 * ppu:
                return svg
            ppu = p
        return svg

    def _render_once(self, fam):
        pts = _rot(self.pts, self.rotate)
        flip = [(x, -y) for x, y in pts]
        self._unit = _fit_k(flip, self.size)   # drawing units per data unit
        pts = _fit(flip, self.size)            # y down for figkit
        f = Figure(width=self.width)
        f.critique = getattr(self, "critique", None)
        # v6.5: the objects this figure draws, readable by the caller after
        # render (the packaging step writes them into sheet.json)
        self.ex = f.ex
        # v6.5 X2: what KIND of figure this is ("shapekit.trapezoid"), set by
        # the builder that assembled the ops -- sheet.json says what a
        # drawing is instead of leaving a reader to guess from the ink
        f.ex.kindname = getattr(self, "kindname", None) or "euclid.figure"
        # v6.6 E (X1R2-06): the figure's fam reaches its export on this path
        # too (the inner Figure is rendered without one)
        f.ex.fam = fam
        # v6.5: the rotation is reported in the export's view so a caller can
        # undo it, and the vertex names are declared where they are DRAWN --
        # `name` below -- instead of being guessed from the label text.
        f.rotate = float(self.rotate)
        # v6.5: the way back to the data frame (pre-rotation maths
        # coordinates): p_fig = k * flip(rot(p_data)) about the handles'
        # centroid, so the inverse is a scale, a flip and a turn by -rotate.
        if self.pts:
            _k = self._unit or 1.0
            _cx = sum(p[0] for p in self.pts) / float(len(self.pts))
            _cy = sum(p[1] for p in self.pts) / float(len(self.pts))
            _a = math.radians(self.rotate)
            _ca, _sa = math.cos(_a), math.sin(_a)

            # v6.5 r1 (X1-06): a builder that normalised its data before
            # handing it over (shapekit scales every shape to one span)
            # declares the way back in `data_units`, so `xy` comes out in the
            # units the question prints -- |AB| = 5, not 2.042.
            _du = getattr(self, "data_units", None) or (1.0, 0.0, 0.0)

            def _to_data(q, _k=_k, _cx=_cx, _cy=_cy, _ca=_ca, _sa=_sa,
                         _du=_du):
                x, y = q[0] / _k, -q[1] / _k
                dx, dy = x - _cx, y - _cy
                x, y = (_cx + dx * _ca + dy * _sa, _cy - dx * _sa + dy * _ca)
                return (x / _du[0] + _du[1], y / _du[0] + _du[2])

            f.ex.set_data(_to_data)
        Q = lambda i: pts[i]
        self._replay_cons(f, Q)
        spans = self._span_offsets()
        for kind, kw in self.ops:
            if kind == "line":
                f.line(Q(kw["a"]), Q(kw["b"]), self._w(kw.get("w", 1.5)),
                       dash=kw.get("dash"))
            elif kind == "poly":
                f.poly([Q(i) for i in kw["idx"]], width=self._w(kw.get("w", 1.6)),
                       dash=kw.get("dash"))
            elif kind == "circle":
                c, r = Q(kw["c"]), Q(kw["rim"])
                f.circle(c, math.hypot(r[0] - c[0], r[1] - c[1]),
                         width=self._w(kw.get("w", 1.4)), dash=kw.get("dash"))
            elif kind == "dot":
                p = Q(kw["a"])
                f.dot(p, r=2.4)
                for d in ((-3.2, -3.2), (3.2, -3.2), (3.2, 3.2), (-3.2, 3.2)):
                    pass
                box = [(p[0] - 3.0, p[1] - 3.0), (p[0] + 3.0, p[1] - 3.0),
                       (p[0] + 3.0, p[1] + 3.0), (p[0] - 3.0, p[1] + 3.0)]
                for k in range(4):
                    f.segs.append((box[k], box[(k + 1) % 4]))
            elif kind == "right":
                f.right_angle(Q(kw["v"]), Q(kw["a"]), Q(kw["b"]), size=9)
            elif kind == "arc":
                f.arc(Q(kw["v"]), Q(kw["a"]), Q(kw["b"]), r=kw.get("r", 17),
                      n=kw["n"])
            elif kind == "ticks":
                t = kw.get("t")
                if t is None:
                    how, t = self._tick_plan(kw["a"], kw["b"])
                    if how == "span":
                        f.span_ticks(Q(kw["a"]), Q(kw["b"]), n=kw["n"], size=5,
                                     side=self._outward(pts, kw["a"], kw["b"]),
                                     offset=spans.get((kw["a"], kw["b"]),
                                                      self._SPAN_OUT))
                        continue
                f.ticks(Q(kw["a"]), Q(kw["b"]), n=kw["n"], size=5, t=t)
            elif kind == "parallel":
                t = kw.get("t")
                if t is None:
                    t = self._arrow_t(kw["a"], kw["b"])
                f.parallel_arrows(Q(kw["a"]), Q(kw["b"]), n=kw["n"], t=t)
            elif kind == "name":
                f.ex.name_point(Q(kw["a"]), kw["text"], role="vertex")
                poly = [Q(i) for i in kw["poly"]] if kw["poly"] else None
                if poly:
                    f.vertex_label(Q(kw["a"]), kw["text"], poly=poly,
                                   size=self._text_pt("letter_pt")
                                   if self.house else self.font)
                else:
                    f.label(Q(kw["a"]), kw["text"],
                            size=self._text_pt("letter_pt") if self.house
                            else self.font, kind="vertex")
            elif kind == "mark":
                # A placement hint is given in MATHS coordinates, so it has to
                # turn with the figure. Left unrotated it pointed into the
                # drawing at 180° and the solver had to fight its way out —
                # which is how a numbered angle ended up on the transversal.
                pr = kw.get("prefer")
                if pr:
                    a = math.radians(self.rotate)
                    pr = (pr[0] * math.cos(a) - pr[1] * math.sin(a),
                          -(pr[0] * math.sin(a) + pr[1] * math.cos(a)))
                # Stage review: the size follows the TEXT, not the call --
                # a mark carries an angle ('58') on one builder and a line's
                # name ('m', 'O', 'r') on another, and the sheet's one look
                # is "numbers at the number size, letters at the letter
                # size" whichever builder printed them.
                mk = self._label_pt(kw["text"]) if self.house \
                    else self.font * 0.9
                f.label(Q(kw["a"]), kw["text"], size=mk, prefer=pr)
                if kw.get("owner"):
                    f.labels[-1].export_owner = (Q(kw["owner"][0]),
                                                 Q(kw["owner"][1]))
        return assert_unstruck(_tag(f.render(width=self.width), fam), fam)


# -------------------------------------------------------------- builders ---
def parallels(angle=58.0, mark=(), names=("m", "n", "t"), rotate=0.0,
              size=175.0, width=None, numbered=True, fam=None):
    """Two parallels cut by a transversal — the ז׳–ח׳ figure, and the one the
    skill could not draw at all.

    `angle` is the acute angle the transversal makes with the parallels, and it
    is asserted against the drawing. `mark` is a list of the numbered angle
    positions (1-8) to arc. Positions 1-4 are at the upper intersection,
    5-8 at the lower, counted anticlockwise from the right.
    """
    if not 28.0 <= angle <= 80.0:
        raise AssertionError(
            "euclid.parallels: an angle of %s is outside 28-80. Below 28 the "
            "wedge is too narrow for its number to sit clear of both lines "
            "(measured: it fails at 22 and 24), and near 90 a student reads the "
            "wrong pair as equal. Both ends were swept, not guessed." % angle)
    g = _Fig(rotate, size, width)
    half, gap = 1.35, 0.9
    t = math.tan(math.radians(angle))
    # the transversal crosses y=+gap/2 and y=-gap/2
    xs = [(gap / 2.0) / t, -(gap / 2.0) / t]
    A = g.P((-half, gap / 2.0), (half, gap / 2.0))
    B = g.P((-half, -gap / 2.0), (half, -gap / 2.0))
    P = g.P((xs[0], gap / 2.0))
    Q = g.P((xs[1], -gap / 2.0))
    T = g.P((xs[0] + 1.05 / t, gap / 2.0 + 1.05),
            (xs[1] - 1.05 / t, -gap / 2.0 - 1.05))
    g.line(A[0], A[1])
    g.line(B[0], B[1])
    g.line(T[0], T[1])
    g.dot(P)
    g.dot(Q)
    ref = {1: (A[1], T[0]), 2: (T[0], A[0]), 3: (A[0], T[1]), 4: (T[1], A[1]),
           5: (B[1], T[0]), 6: (T[0], B[0]), 7: (B[0], T[1]), 8: (T[1], B[1])}
    for k in (mark or []):
        v = P if k <= 4 else Q
        a, b = ref[k]
        g.arc(v, a, b, n=1 if k <= 4 else 2)
    if numbered:
        # A number placed by a fixed offset landed ON the transversal — the
        # struck-label class, from the one direction the offset could not know
        # about. Each number now sits on the BISECTOR of its own wedge.
        up, dn = (xs[0], gap / 2.0), (xs[1], -gap / 2.0)
        tvec = (1.0 / t, 1.0)
        wedge = {1: ((1, 0), tvec), 2: (tvec, (-1, 0)),
                 3: ((-1, 0), (-tvec[0], -tvec[1])),
                 4: ((-tvec[0], -tvec[1]), (1, 0)),
                 5: ((1, 0), tvec), 6: (tvec, (-1, 0)),
                 7: ((-1, 0), (-tvec[0], -tvec[1])),
                 8: ((-tvec[0], -tvec[1]), (1, 0))}
        for k in (1, 3, 5, 7):
            v = up if k <= 4 else dn
            u1, u2 = wedge[k]
            n1 = math.hypot(*u1) or 1.0
            n2 = math.hypot(*u2) or 1.0
            bx = u1[0] / n1 + u2[0] / n2
            by = u1[1] / n1 + u2[1] / n2
            nb = math.hypot(bx, by) or 1.0
            # far enough out that the label box clears both lines, and aimed
            # along the bisector so the solver starts where the wedge is open.
            # (figkit draws y down; the render flips, so the hint flips too.)
            # The narrower the wedge, the further out its number has to sit
            # before the box clears both lines: at 25° a fixed radius put the
            # '1' on the transversal. r grows as 1/sin(half-wedge).
            r = max(0.62, 0.22 / math.sin(math.radians(angle / 2.0)))
            g.mark(g.P((v[0] + r * bx / nb, v[1] + r * by / nb)), str(k),
                   prefer=(bx / nb, by / nb))
    # A line's name anchored ON the line is struck by it. Each name sits just
    # past the end and off to the side, with the hint pointing away.
    g.mark(g.P((half + 0.10, gap / 2.0 + 0.20)), names[0], prefer=(1, 1))
    g.mark(g.P((half + 0.10, -gap / 2.0 + 0.20)), names[1], prefer=(1, 1))
    g.mark(g.P((xs[0] + 1.05 / t + 0.12, gap / 2.0 + 1.05 + 0.12)), names[2],
           prefer=(1, 1))
    # v6.5 X2 r1 (MINOR-15): the figure IS two parallel lines cut by a
    # transversal -- a fact of its construction, not a mark, so it exports
    # as derived (a question that states "m ∥ n" labels it given)
    g.constrain("parallel", of=[[A[0], A[1]], [B[0], B[1]]])
    return g.render(fam or "parallels.transversal")


def angles_at_point(rays=(0, 55, 130, 215), labels=None, rotate=0.0,
                    size=_SIZE, width=None, straight=False, arcs=None,
                    fam=None):
    """Rays from one point — vertical angles, angles on a line, angles round a
    point. `straight=True` asserts that two of the rays are opposite, which is
    what makes the figure an "angles on a straight line" question rather than a
    fan."""
    if len(rays) < 2:
        raise AssertionError("euclid.angles_at_point: at least two rays")
    if straight:
        ok = any(abs(((a - b) % 360) - 180) < 0.5
                 for i, a in enumerate(rays) for b in rays[i + 1:])
        if not ok:
            raise AssertionError(
                "euclid.angles_at_point: straight=True but no two rays are "
                "opposite — the figure would not show a straight line")
    g = _Fig(rotate, size, width)
    O = g.P((0.0, 0.0))
    ends = [g.P((math.cos(math.radians(a)), math.sin(math.radians(a))))
            for a in rays]
    for e in ends:
        g.line(O, e)
    g.dot(O)
    # Every wedge arced at the SAME radius drew one continuous ring round the
    # vertex — a figure that says "one angle" where the question says four.
    # `arcs` picks the wedges (0-based, anticlockwise from the first ray); the
    # default alternates the radius so adjacent arcs read as separate.
    rs = sorted(rays)
    want = range(len(rs)) if arcs is None else arcs
    for i in want:
        a, b = rs[i % len(rs)], rs[(i + 1) % len(rs)]
        # v6.2 Q1 r1: the radius alternates, the STROKE COUNT does not. It
        # used to be n = 1 + (i % 2), so a fan of four wedges printed one
        # stroke, two, one, two -- which on paper says wedge 0 = wedge 2 and
        # wedge 1 = wedge 3, two claims nobody made and (0, 55, 130, 215)
        # makes false. A single arc names a wedge; two strokes mean equal.
        g.arc(O, ends[rays.index(a)], ends[rays.index(b)],
              n=1, r=16 + 8 * (i % 2))
    for i, e in enumerate(ends):
        txt = (labels or {}).get(i)
        if txt:
            g.name(e, txt)
    return g.render(fam or "angles.at-point%s" % (".straight" if straight else ""))


def triangle_with(kind="scalene", cevian=None, names="ABC", rotate=0.0,
                  marks=True, size=_SIZE, width=None, fam=None):
    """A triangle and, optionally, one line inside it.

    kind    "scalene" | "right" | "iso" | "equilateral"
    cevian  None | "altitude" | "median" | "bisector" | "midsegment"

    The shape is asserted (an isosceles triangle really has two equal sides), and
    so is the cevian: a median really lands on the midpoint, an altitude really
    meets the base at a right angle. A drawing that says "altitude" and lands
    somewhere convenient is the defect this skill has been chasing since v5.1.
    """
    V = {"scalene": [(0, 0), (2.2, 0), (0.62, 1.5)],
         "right": [(0, 0), (2.2, 0), (0, 1.6)],
         "iso": [(0, 0), (2.2, 0), (1.1, 1.65)],
         "equilateral": [(0, 0), (2.0, 0), (1.0, math.sqrt(3.0))]}
    if kind not in V:
        raise AssertionError("euclid.triangle_with: kind %r" % kind)
    A0, B0, C0 = V[kind]
    d2 = lambda p, q: (p[0] - q[0]) ** 2 + (p[1] - q[1]) ** 2
    if kind in ("iso", "equilateral") and abs(d2(A0, C0) - d2(B0, C0)) > 1e-9:
        raise AssertionError("euclid.triangle_with: %s legs differ" % kind)
    g = _Fig(rotate, size, width)
    A, B, C = g.P(A0, B0, C0)
    g.poly([A, B, C])
    for i, nm in zip((A, B, C), names):
        g.name(i, nm, poly=[A, B, C])
    if kind == "right":
        g.right(A, B, C)
    if marks and kind in ("iso", "equilateral") and cevian != "midsegment":
        g.ticks(A, C, 1)
        g.ticks(B, C, 1)
    if marks and kind == "equilateral":
        g.ticks(A, B, 1)
    if cevian:
        if cevian == "altitude":
            # onto the LONGEST side, from the vertex opposite it. Dropping it
            # from a fixed vertex put the foot ON a vertex of the right
            # triangle (the altitude WAS a leg) — a figure that draws the word
            # "altitude" as something the student already has.
            tri = [A0, B0, C0]
            hh = [A, B, C]
            j = max(range(3), key=lambda i: d2(tri[i], tri[(i + 1) % 3]))
            p0, q0, ap0 = tri[j], tri[(j + 1) % 3], tri[(j + 2) % 3]
            ph, qh, aph = hh[j], hh[(j + 1) % 3], hh[(j + 2) % 3]
            t = ((ap0[0] - p0[0]) * (q0[0] - p0[0])
                 + (ap0[1] - p0[1]) * (q0[1] - p0[1])) / d2(p0, q0)
            if not 0.02 < t < 0.98:
                raise AssertionError(
                    "euclid.triangle_with: on a %s triangle the altitude's "
                    "foot falls at %.2f of the side — at or outside a vertex, "
                    "where the drawing contradicts the word 'altitude'"
                    % (kind, t))
            F = g.P((p0[0] + t * (q0[0] - p0[0]), p0[1] + t * (q0[1] - p0[1])))
            g.line(aph, F, dash="4,3", w=1.2)
            g.right(F, ph, aph)
            g.name(F, "H")
        elif cevian == "median":
            M0 = ((A0[0] + B0[0]) / 2.0, (A0[1] + B0[1]) / 2.0)
            M = g.P(M0)
            g.line(C, M, dash="4,3", w=1.2)
            g.ticks(A, M, 2)
            g.ticks(M, B, 2)
            g.name(M, "M")
        elif cevian == "bisector":
            ab, ac = math.sqrt(d2(A0, B0)), math.sqrt(d2(A0, C0))
            # the bisector from A meets BC at the ratio AB∶AC — asserted by
            # construction, not placed by eye
            t = ab / (ab + ac)
            D0 = (B0[0] + t * (C0[0] - B0[0]), B0[1] + t * (C0[1] - B0[1]))
            D = g.P(D0)
            g.line(A, D, dash="4,3", w=1.2)
            g.arc(A, B, D, n=1)
            g.arc(A, D, C, n=1)
            # v6.6 E (V2-M1): equal stroke counts ARE the claim "these angles are
            # equal"; the sheet's JSON says so as a MARKED equal_angle, so a
            # to_prove of that equality is refused like a ticked one.
            g.constrain("equal_angle", of=[[A, B, D], [A, D, C]], marked=True)
            g.name(D, "D")
        elif cevian == "midsegment":
            M0 = ((A0[0] + C0[0]) / 2.0, (A0[1] + C0[1]) / 2.0)
            N0 = ((B0[0] + C0[0]) / 2.0, (B0[1] + C0[1]) / 2.0)
            M, N = g.P(M0, N0)
            g.line(M, N, dash="4,3", w=1.2)
            # v6 C3 (E5): one tick count says one length. The halves of AC
            # and of BC are equal to each other only when AC = BC; and on an
            # equilateral triangle AB already carries the single tick for the
            # whole side. The legs' own ticks, which fell exactly on M and N,
            # are implied by the halves and not drawn (euclid audit: six
            # single ticks said AM = AC).
            legs_equal = abs(d2(A0, C0) - d2(B0, C0)) < 1e-9
            h1 = 2 if kind == "equilateral" else 1
            h2 = h1 if legs_equal else h1 + 1
            g.ticks(A, M, h1)
            g.ticks(M, C, h1)
            g.ticks(B, N, h2)
            g.ticks(N, C, h2)
            g.name(M, "M")
            g.name(N, "N")
        else:
            raise AssertionError("euclid.triangle_with: cevian %r" % cevian)
    return g.render(fam or "triangle.%s%s" % (kind, "+" + cevian if cevian else ""))


def congruent_pair(kind="sas", names=("ABC", "DEF"), rotate=0.0, flip=True,
                   size=185.0, width=None, fam=None):
    """Two congruent triangles side by side, with the marks that say WHICH
    parts are given equal — צ.ז.צ, ז.צ.ז, צ.צ.צ.

    The second triangle is drawn reflected by default, because a pair that is
    merely translated is read as "the same picture twice" and hides the whole
    difficulty of matching vertices.
    """
    if kind not in ("sas", "asa", "sss"):
        raise AssertionError("euclid.congruent_pair: kind %r" % kind)
    base = [(0.0, 0.0), (1.9, 0.0), (0.55, 1.35)]
    g = _Fig(rotate, size, width)
    shift = 2.7
    second = [(shift + (base[1][0] - p[0] if flip else p[0]), p[1])
              for p in base]
    A, B, C = g.P(*base)
    D, E, F = g.P(*second)
    g.poly([A, B, C])
    g.poly([D, E, F])
    for i, nm in zip((A, B, C), names[0]):
        g.name(i, nm, poly=[A, B, C])
    for i, nm in zip((D, E, F), names[1]):
        g.name(i, nm, poly=[D, E, F])
    if kind == "sss":
        pairs = (((A, B), (D, E), 1), ((B, C), (E, F), 2), ((A, C), (D, F), 3))
        for p, q, n in pairs:
            g.ticks(p[0], p[1], n)
            g.ticks(q[0], q[1], n)
    elif kind == "sas":
        g.ticks(A, B, 1)
        g.ticks(D, E, 1)
        g.ticks(A, C, 2)
        g.ticks(D, F, 2)
        g.arc(A, B, C, n=1)
        g.arc(D, E, F, n=1)
        # v6.6 E (V2-M1): equal stroke counts ARE the claim "these angles are
        # equal"; the sheet's JSON says so as a MARKED equal_angle, so a
        # to_prove of that equality is refused like a ticked one.
        g.constrain("equal_angle", of=[[A, B, C], [D, E, F]], marked=True)
    else:                                   # asa
        g.ticks(A, B, 1)
        g.ticks(D, E, 1)
        g.arc(A, B, C, n=1)
        g.arc(D, E, F, n=1)
        g.arc(B, C, A, n=2)
        g.arc(E, F, D, n=2)
        # v6.6 E (V2-M1): equal stroke counts ARE the claim "these angles are
        # equal"; the sheet's JSON says so as a MARKED equal_angle, so a
        # to_prove of that equality is refused like a ticked one.
        g.constrain("equal_angle", of=[[A, B, C], [D, E, F]], marked=True)
        g.constrain("equal_angle", of=[[B, C, A], [E, F, D]], marked=True)
    return g.render(fam or "congruent.pair.%s" % kind)


def circle_fig(parts=("centre", "radius"), rotate=0.0, size=_SIZE, width=None,
               at=(55.0, 200.0, 310.0), fam=None):
    """A circle and the objects on it.

    parts   any of "centre", "radius", "diameter", "chord", "tangent",
            "two-tangents", "central", "inscribed"
    at      the angles (degrees) of the points the parts are built on, so two
            circle figures on one sheet can genuinely differ.

    "central" and "inscribed" draw the two angles that subtend the SAME arc —
    the configuration a sheet needs in order to ask why one is twice the other.
    """
    known = {"centre", "radius", "diameter", "chord", "tangent",
             "two-tangents", "central", "inscribed"}
    parts = tuple(parts)
    bad = set(parts) - known
    if bad:
        raise AssertionError("euclid.circle_fig: unknown part(s) %s" % sorted(bad))
    g = _Fig(rotate, size, width)
    O = g.P((0.0, 0.0))
    on = lambda deg: (math.cos(math.radians(deg)), math.sin(math.radians(deg)))
    rim = g.P(on(at[0]))
    g.circle(O, rim)
    if "centre" in parts:
        g.dot(O)
        # away from the mean direction of whatever is drawn out of the centre:
        # at 180° the plain vertex label landed on a radius.
        used = [at[0]] if ("radius" in parts or "diameter" in parts or
                           "tangent" in parts) else []
        if "central" in parts:
            used += [at[1], at[2]]
        if not used:
            used = [at[0]]
        mx = sum(math.cos(math.radians(a)) for a in used) / len(used)
        my = sum(math.sin(math.radians(a)) for a in used) / len(used)
        n = math.hypot(mx, my) or 1.0
        # anchored a little way off the centre, not on it: with two radii
        # leaving O the hint alone was not enough and the solver put the 'O'
        # on one of them (measured at 180° and 214°).
        dx, dy = -mx / n, -my / n
        g.mark(g.P((0.20 * dx, 0.20 * dy)), "O", prefer=(dx, dy))
    if "radius" in parts:
        g.line(O, rim)
        g.dot(rim)
        g.mark(rim, "A", prefer=on(at[0]))
    if "diameter" in parts:
        opp = g.P(on(at[0] + 180.0))
        g.line(rim, opp)
        g.dot(opp)
        g.mark(opp, "B", prefer=on(at[0] + 180.0))
        # v6.7-noam (R3-G7-circle-builder-relations): the centre halves the
        # diameter, from the data that drew it; its ends and O are points
        # of the export (on the diameter's ink) so the facts re-measure
        g.export_obj("point", [rim], role=None)
        g.export_obj("point", [O], role=None)
        g.constrain("midpoint", point=O, of=[rim, opp], strict=True)
        g.constrain("collinear", points=[rim, O, opp], strict=True)
    if "chord" in parts:
        p = g.P(on(at[1]))
        q = g.P(on(at[2]))
        g.line(p, q)
        g.dot(p)
        g.dot(q)
        g.mark(p, "C", prefer=on(at[1]))
        g.mark(q, "D", prefer=on(at[2]))
    if "tangent" in parts:
        a = at[0]
        t1 = g.P((math.cos(math.radians(a)) - 0.95 * math.sin(math.radians(a)),
                  math.sin(math.radians(a)) + 0.95 * math.cos(math.radians(a))))
        t2 = g.P((math.cos(math.radians(a)) + 0.95 * math.sin(math.radians(a)),
                  math.sin(math.radians(a)) - 0.95 * math.cos(math.radians(a))))
        g.line(t1, t2)
        g.line(O, rim, dash="4,3", w=1.2)
        g.right(rim, O, t1)
        # v6.7-noam: the line touches the circle at the radius's end
        g.export_obj("point", [rim], role=None)
        g.constrain("tangent", circle=O, to=[t1, t2], at=rim, strict=True)
    if "two-tangents" in parts:
        d = 2.05
        Pp = g.P((d * math.cos(math.radians(at[1])),
                  d * math.sin(math.radians(at[1]))))
        half = math.degrees(math.acos(1.0 / d))
        touch = []
        for s in (+1, -1):
            k = g.P(on(at[1] + s * half))
            g.line(Pp, k)
            g.dot(k)
            touch.append(k)
        g.dot(Pp)
        g.mark(Pp, "P", prefer=on(at[1]))
        # v6.7-noam (R3-G7-circle-builder-relations): each segment from P
        # touches the circle at its end (the radius there is perpendicular
        # to it: acos(1/d) above), and the two tangent segments are equal
        for k in touch:
            g.constrain("tangent", circle=O, to=[Pp, k], at=k, strict=True)
        g.constrain("equal_length", of=[[Pp, touch[0]], [Pp, touch[1]]],
                    strict=True)
    if "central" in parts or "inscribed" in parts:
        b = g.P(on(at[1]))
        c = g.P(on(at[2]))
        g.dot(b)
        g.dot(c)
        g.mark(b, "C", prefer=on(at[1]))
        g.mark(c, "D", prefer=on(at[2]))
        if "central" in parts:
            g.line(O, b)
            g.line(O, c)
            g.arc(O, b, c, n=1)
        if "inscribed" in parts:
            e = g.P(on(at[0]))
            g.line(e, b)
            g.line(e, c)
            g.dot(e)
            g.mark(e, "E", prefer=on(at[0]))
            g.arc(e, b, c, n=2)
    return g.render(fam or "circle." + "+".join(sorted(parts)))


def quad(kind="parallelogram", diagonals=False, names="ABCD", rotate=0.0,
         marks=True, size=_SIZE, width=None, fam=None):
    """The quadrilateral family, off the grid.

    kind  "parallelogram" | "rhombus" | "rectangle" | "square" | "trapezoid"
          | "kite"

    Each shape is verified before it is drawn: a rhombus has four equal sides, a
    rectangle four right angles, a trapezoid exactly one parallel pair. A figure
    that says rhombus and draws a kite gives a proof question its answer.
    """
    V = {"parallelogram": [(0, 0), (2.2, 0), (2.85, 1.25), (0.65, 1.25)],
         "rhombus": [(0, 0), (1.8, 0), (2.4, 1.697056), (0.6, 1.697056)],
         "rectangle": [(0, 0), (2.3, 0), (2.3, 1.35), (0, 1.35)],
         "square": [(0, 0), (1.7, 0), (1.7, 1.7), (0, 1.7)],
         "trapezoid": [(0, 0), (2.6, 0), (2.0, 1.3), (0.65, 1.3)],
         "kite": [(1.1, 0), (2.1, 1.15), (1.1, 2.25), (0.1, 1.15)]}
    if kind not in V:
        raise AssertionError("euclid.quad: kind %r" % kind)
    p = V[kind]
    d2 = lambda a, b: (a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2
    s = [d2(p[i], p[(i + 1) % 4]) for i in range(4)]
    if kind in ("rhombus", "square") and max(s) - min(s) > 1e-5:
        raise AssertionError("euclid.quad: %s sides %s are not equal" % (kind, s))
    if kind == "kite" and (abs(s[0] - s[3]) > 1e-6 or abs(s[1] - s[2]) > 1e-6
                           or abs(s[0] - s[1]) < 1e-6):
        raise AssertionError("euclid.quad: kite pairs came out %s" % s)
    if kind == "trapezoid":
        slope = lambda a, b: (b[1] - a[1]) / (b[0] - a[0]) if b[0] != a[0] else None
        if slope(p[0], p[1]) != slope(p[3], p[2]):
            raise AssertionError("euclid.quad: the trapezoid's bases are not "
                                 "parallel")
        if slope(p[1], p[2]) == slope(p[0], p[3]):
            raise AssertionError("euclid.quad: both pairs are parallel — that "
                                 "is a parallelogram, and a sheet asking the "
                                 "student to prove it is a trapezoid would be "
                                 "answered by the picture")
    g = _Fig(rotate, size, width)
    idx = list(g.P(*p))
    g.poly(idx)
    for i, nm in zip(idx, names):
        g.name(i, nm, poly=idx)
    if marks:
        if kind in ("rhombus", "square"):
            for i in range(4):
                g.ticks(idx[i], idx[(i + 1) % 4], 1)
        elif kind in ("parallelogram", "rectangle"):
            g.ticks(idx[0], idx[1], 1)
            g.ticks(idx[2], idx[3], 1)
            g.ticks(idx[1], idx[2], 2)
            g.ticks(idx[3], idx[0], 2)
        elif kind == "kite":
            g.ticks(idx[0], idx[1], 1)
            g.ticks(idx[3], idx[0], 1)
            g.ticks(idx[1], idx[2], 2)
            g.ticks(idx[2], idx[3], 2)
        if kind in ("rectangle", "square"):
            g.right(idx[0], idx[1], idx[3])
    if diagonals:
        g.line(idx[0], idx[2], dash="4,3", w=1.2)
        g.line(idx[1], idx[3], dash="4,3", w=1.2)
    return g.render(fam or "quad.%s%s" % (kind, "+diagonals" if diagonals else ""))


# v6.5 X2 r1 (MUST-3, spec rule 6): the author's call into this module
# is recorded as source, so figures/<id>.py can re-draw the figure.
import export as _export_rec  # noqa: E402
parallels = _export_rec.entry(parallels)
angles_at_point = _export_rec.entry(angles_at_point)
triangle_with = _export_rec.entry(triangle_with)
congruent_pair = _export_rec.entry(congruent_pair)
circle_fig = _export_rec.entry(circle_fig)
quad = _export_rec.entry(quad)
