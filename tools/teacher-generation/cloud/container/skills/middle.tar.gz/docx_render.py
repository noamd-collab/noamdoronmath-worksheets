#!/usr/bin/env python3
# -*- coding: utf-8 -*-
u"""docx_render -- v7.2.0: DOCX -> PDF through Microsoft Word, then PNG pages.

WHY WORD, AND WHY THIS WAY
    The DOCX is for teachers, and teachers open it in Word. LibreOffice and
    python-docx do not reproduce Word's RTL quirks (docx.md section 4), so the
    only honest visual check is Word's own PDF export. Driving Word for Mac
    by AppleScript works only under conditions found by testing (docx.md 8):
      * Word must be ACTIVATED before `save as`, or it answers -1708;
      * Word is sandboxed: writing a new file outside its container raises a
        hidden "Grant File Access" prompt and the call hangs. So every input
        is staged inside ~/Library/Containers/com.microsoft.Word/Data/tmp/,
        converted there, copied back, and the stage removed;
      * a hung call must not hang the pipeline: 120 s watchdog per file.
    Several agents share this Mac, so Word is held under one mkdir lock
    (claude-word.lock) for the whole batch. Documents are closed without
    saving, only OUR document (matched by its unique staged name) is ever
    saved or closed, and Word is quit only if it was not running before AND
    no other document is open in it when the batch ends (someone may have
    opened one during the render; quitting would discard it unsaved). The
    quit re-checks that count inside Word, and any doubt (no answer, a
    timeout) leaves Word running; every result records the outcome as
    word_quit / word_open_documents / word_note.

USAGE
    python3 docx_render.py A.docx [B.docx ...] [--dpi 110] [--out DIR]
                           [--assert] [--json REPORT.json] [--timeout 120]
    Writes <name>.word.pdf and <name>_p<N>.png next to each input (or in --out).
    An input that is already a Word PDF (<name>.word.pdf) skips Word and is only
    rasterised / asserted (the sibling <name>.docx supplies page geometry).
    Two inputs that would write the same <name> into one folder (--out with
    a/sheet.docx b/sheet.docx) are both renamed <parent>_<name> (the report
    keeps renamed_from); stale pages are removed only as <name>_p<N>.png.

    --assert (docx.md 7.4):
      right_edge     every Hebrew, non-centred body line ends at the RIGHT text
                     edge (3 pt); a line that touches the LEFT margin and stops
                     short -- the jc=right flip, at any width -- fails unless it
                     ends at right - (an indent the DOCX declares: w:ind, cell
                     margin, tblInd); a page whose Hebrew lines never reach the
                     right edge fails as a whole
      blank_pages    no page without body content (text, image or drawing)
      bold_headings  every all-bold Hebrew paragraph of the DOCX (bold direct,
                     by character style or by paragraph style) prints in a
                     -Bold font (Word drops bold when bCs is missing); SKIP when
                     the DOCX has no such paragraph, REVIEW when one is not
                     found in the PDF -- never a silent PASS

    exit 0 = converted (and asserts passed or SKIP/REVIEW), 1 = an assert
    failed, 2 = conversion failed / Word or the lock unavailable.
    Needs: macOS + Microsoft Word + PyMuPDF (user site; do not run with -I).
"""
from __future__ import print_function

import argparse
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import time
import unicodedata
import zipfile
import xml.etree.ElementTree as ET

VERSION = "7.2.0-noam"
WORD_TMP = os.path.expanduser("~/Library/Containers/com.microsoft.Word/Data/tmp")
LOCK_DIR = os.path.join(WORD_TMP, "claude-word.lock")
W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
HEB_WORD = re.compile(u"[\u05d0-\u05ea]+")
NIQQUD = re.compile(u"[\u0591-\u05bd\u05bf\u05c1\u05c2\u05c4\u05c5\u05c7]")

CONVERT_SCRIPT = u'''
on run argv
  set inPath to item 1 of argv
  set outPath to item 2 of argv
  set wantName to item 3 of argv
  tell application "Microsoft Word"
    activate
    open (POSIX file inPath)
    -- wait until OUR document is the active one; never touch another document
    set ok to false
    repeat 60 times
      try
        if (name of active document) is wantName then
          set ok to true
          exit repeat
        end if
      end try
      delay 0.5
    end repeat
    if not ok then error "document did not become active: " & wantName
    delay 1
    save as active document file name outPath file format format PDF
    set closed to false
    repeat with d in (get documents)
      try
        if (name of d) is wantName then
          close d saving no
          set closed to true
          exit repeat
        end if
      end try
    end repeat
    if not closed then
      if (name of active document) is wantName then close active document saving no
    end if
  end tell
  return "ok"
end run
'''

CLOSE_SCRIPT = u'''
on run argv
  set wantName to item 1 of argv
  tell application "Microsoft Word"
    repeat with d in (get documents)
      try
        if (name of d) is wantName then close d saving no
      end try
    end repeat
  end tell
  return "ok"
end run
'''

# End of a batch that started Word. argv: the staged-name prefix of THIS batch,
# then "count" or "quit". Replies "not running", the number of documents that
# are not ours, or "quit". The quit happens only when that number is 0 at the
# moment of quitting, so a document opened after the "count" call is never
# discarded. Variable names are camelCase so no Word dictionary term shadows them.
IDLE_SCRIPT = u'''
on run argv
  set ownPrefix to item 1 of argv
  set wantMode to item 2 of argv
  if application "Microsoft Word" is not running then return "not running"
  set otherCount to 0
  tell application "Microsoft Word"
    with timeout of 20 seconds
      repeat with d in (get documents)
        set isMine to false
        try
          if (name of d) starts with ownPrefix then set isMine to true
        end try
        if not isMine then set otherCount to otherCount + 1
      end repeat
      if wantMode is "quit" and otherCount is 0 then
        quit saving no
        return "quit"
      end if
    end timeout
  end tell
  return otherCount as text
end run
'''


class RenderError(Exception):
    pass


# ------------------------------------------------------------------ lock ----
class WordLock(object):
    """mkdir lock shared with every agent that drives Word on this Mac."""

    def __init__(self, max_wait=1800.0, poll=5.0):
        self.max_wait, self.poll = max_wait, poll
        self.held = False
        self.waited = 0.0

    def __enter__(self):
        os.makedirs(WORD_TMP, exist_ok=True)
        t0 = time.time()
        while True:
            try:
                os.mkdir(LOCK_DIR)
                self.held = True
                break
            except FileExistsError:
                if time.time() - t0 > self.max_wait:
                    raise RenderError("Word lock %s still held after %.0f s" %
                                      (LOCK_DIR, self.max_wait))
                time.sleep(self.poll)
        self.waited = time.time() - t0
        return self

    def __exit__(self, *exc):
        if self.held:
            try:
                os.rmdir(LOCK_DIR)
            except OSError:
                pass
            self.held = False
        return False


def _on_signal(signum, _frame):
    raise SystemExit(128 + signum)


def word_running():
    return subprocess.call(["pgrep", "-xq", "Microsoft Word"]) == 0


def osa(script, args, timeout):
    cp = subprocess.run(["osascript", "-"] + list(args), input=script.encode("utf-8"),
                        stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
    return cp.returncode, cp.stdout.decode("utf-8", "replace").strip(), \
        cp.stderr.decode("utf-8", "replace").strip()


def release_word(was_running, own_prefix, log=print, timeout=30.0):
    u"""End of a batch, still under the lock: quit Word only when it is safe.

    Word is quit (saving no) only when THIS batch found it not running AND no
    document other than our own staged ones (names starting with own_prefix)
    is open. Someone may have opened a document in Word during the render;
    quitting would close it without saving. The count is asked first, and the
    quit call re-checks it inside Word, so a document opened in between is
    not lost either. Any doubt (no answer, a timeout, an unreadable reply)
    leaves Word running. If the quit call itself reports an error, pgrep is
    asked for a few seconds whether Word went away anyway (osascript can lose
    the reply of an app that is quitting, error -609), so the note says what
    really happened. Never raises. Returns the fields every result of
    the batch carries:
      word_quit            True only when Word confirmed the quit
      word_open_documents  other documents still open (None: not asked/unknown)
      word_note            one line for the report
    """
    def info(quit, n, note):
        return {"word_quit": quit, "word_open_documents": n, "word_note": note}

    def ask(mode):
        try:
            code, out, err = osa(IDLE_SCRIPT, [own_prefix, mode], timeout)
        except subprocess.TimeoutExpired:
            return None, "no answer within %.0f s" % timeout
        except Exception as e:
            return None, "osascript failed: %s" % e
        if code != 0:
            return None, "osascript exit %d: %s" % (code, err or out)
        if out == "not running" or (out == "quit" and mode == "quit"):
            return out, None
        try:
            n = int(out)
        except ValueError:
            n = -1
        if n < 0:
            return None, "unexpected reply %r" % out[:80]
        return n, None

    def kept(n, why):
        note = "Word left running (not quit): %s" % why
        try:
            log("docx_render: " + note)
        except Exception:
            pass
        return info(False, n, note)

    if was_running:
        return info(False, None, "Word was running before the batch: left running")
    try:
        if not word_running():
            return info(False, 0, "Word is no longer running")
    except Exception:
        pass        # no pgrep: the script checks "is running" itself
    n, why = ask("count")
    if n == "not running":
        return info(False, 0, "Word is no longer running")
    if not isinstance(n, int):
        return kept(None, "could not count the documents open in it (%s)" % why)
    if n > 0:
        return kept(n, "%d document(s) opened by someone else during the render "
                       "are still open" % n)
    reply, why = ask("quit")
    if reply == "quit":
        return info(True, 0, "Word quit (this batch started it; no document was open)")
    if reply == "not running":
        return info(False, 0, "Word is no longer running")
    if isinstance(reply, int):
        return kept(reply, "%d document(s) were opened just before the quit" % reply)
    try:
        for _i in range(6):
            if not word_running():
                return info(True, 0, "Word quit (the reply was lost: %s; pgrep confirms Word is gone)" % why)
            time.sleep(0.5)
    except Exception:
        pass
    return kept(None, "the quit was not confirmed (%s)" % why)


# ------------------------------------------------------------- convert ----
def convert_batch(docx_paths, dests, timeout=120.0, lock_wait=1800.0, log=print):
    """Convert docx_paths[i] to the PDF path dests[i] (<out>/<name>.word.pdf,
    names already made unique by the caller). Returns the results in input
    order (a list, so one DOCX given twice keeps two results)."""
    results = []
    own_prefix = "dr%d_" % os.getpid()       # every staged name of this batch
    with WordLock(max_wait=lock_wait) as lock:
        was_running = word_running()
        stage = os.path.join(WORD_TMP, "docx_render-%d-%d" % (os.getpid(), int(time.time())))
        os.makedirs(stage)
        try:
            for i, src in enumerate(docx_paths):
                staged_name = "%s%02d.docx" % (own_prefix, i)
                staged = os.path.join(stage, staged_name)
                staged_pdf = os.path.join(stage, staged_name[:-5] + ".pdf")
                dest = dests[i]
                t0 = time.time()
                res = {"docx": os.path.abspath(src), "pdf": None, "error": None}
                try:
                    shutil.copyfile(src, staged)
                    code, out, err = osa(CONVERT_SCRIPT, [staged, staged_pdf, staged_name],
                                         timeout)
                    if code != 0:
                        raise RenderError("osascript exit %d: %s" % (code, err or out))
                    # Word writes synchronously, but give the file system a moment
                    last = -1
                    for _ in range(30):
                        size = os.path.getsize(staged_pdf) if os.path.exists(staged_pdf) else -1
                        if size > 0 and size == last:
                            break
                        last = size
                        time.sleep(0.5)
                    if not os.path.exists(staged_pdf) or os.path.getsize(staged_pdf) == 0:
                        raise RenderError("Word reported success but wrote no PDF")
                    os.makedirs(os.path.dirname(dest), exist_ok=True)
                    shutil.copyfile(staged_pdf, dest)
                    res["pdf"] = dest
                except subprocess.TimeoutExpired:
                    res["error"] = "watchdog: Word did not finish within %.0f s" % timeout
                    try:
                        osa(CLOSE_SCRIPT, [staged_name], 30)
                    except Exception:
                        pass
                except (RenderError, OSError) as e:
                    res["error"] = str(e)
                    try:
                        osa(CLOSE_SCRIPT, [staged_name], 30)
                    except Exception:
                        pass
                res["seconds"] = round(time.time() - t0, 1)
                log("docx_render: %s -> %s (%.1f s)%s" % (
                    src, dest if res["pdf"] else "-", res["seconds"],
                    "" if not res["error"] else "  ERROR " + res["error"]))
                results.append(res)
        finally:
            shutil.rmtree(stage, ignore_errors=True)
            # quit Word only if this batch started it and nobody has a
            # document open in it now (S-F7); otherwise leave it running
            word = release_word(was_running, own_prefix, log)
        for r in results:
            r["word_was_running"] = was_running
            r["lock_wait_s"] = round(lock.waited, 1)
            r.update(word)
    return results


# ------------------------------------------------------------ geometry ----
def _on(el):
    """ST_OnOff toggle: None when the element is absent."""
    if el is None:
        return None
    v = el.get(W + "val")
    return v is None or v.strip().lower() not in ("0", "false", "off", "none")


def _twips(v):
    try:
        return int(str(v).strip()) / 20.0
    except (TypeError, ValueError):
        return None


class _Styles(object):
    """Just enough of styles.xml to resolve a run's bold the way Word does for
    a heading: direct rPr, then the character style chain (rStyle/basedOn),
    then the paragraph style chain (pStyle/basedOn, or the default paragraph
    style), then docDefaults -- first hit wins, as in check_docx_rtl.r_chain."""

    def __init__(self, root):
        self.by_id, self.default = {}, {}
        self.rpr_default = None
        if root is None:
            return
        for st in root.findall(W + "style"):
            sid = st.get(W + "styleId")
            if sid:
                self.by_id[sid] = st
            if (st.get(W + "default") or "").lower() in ("1", "true", "on"):
                self.default.setdefault(st.get(W + "type"), sid)
        self.rpr_default = root.find("%sdocDefaults/%srPrDefault/%srPr" % (W, W, W))

    def chain(self, sid):
        out, seen = [], set()
        while sid and sid not in seen and sid in self.by_id:
            seen.add(sid)
            st = self.by_id[sid]
            x = st.find(W + "rPr")
            if x is not None:
                out.append(x)
            b = st.find(W + "basedOn")
            sid = b.get(W + "val") if b is not None else None
        return out

    def run_rprs(self, run, pstyle):
        rpr = run.find(W + "rPr")
        out = [rpr] if rpr is not None else []
        rs = rpr.find(W + "rStyle") if rpr is not None else None
        out += self.chain(rs.get(W + "val") if rs is not None else self.default.get("character"))
        out += self.chain(pstyle or self.default.get("paragraph"))
        if self.rpr_default is not None:
            out.append(self.rpr_default)
        return out

    def bold(self, run, pstyle):
        rprs = self.run_rprs(run, pstyle)
        for tag in ("b", "bCs"):
            for x in rprs:
                el = x.find(W + tag)
                if el is not None:
                    if _on(el):
                        return True
                    break
        return False


def _indents(roots):
    """Every start/end distance (pt) a line can stop at on the right side:
    w:ind left/start/right/end, with hanging/firstLine applied, from the
    document, its styles and numbering (Word puts w:left on the RIGHT of a
    bidi paragraph -- measured on the G7-T13 sheet: w:left=1440 hanging=560
    prints first lines 44 pt and the rest 72 pt in from the right edge), plus
    table cell margins (default 5.4 pt), table indents and, for a
    right-to-left table (w:bidiVisual), where each column after the first
    starts: the summed widths of the columns to its right, alone and plus
    the table indent and cell margins. The answers table of every sheet has a
    36 pt number column on the right, so a full answer line spans from the
    left margin to right - 36 pt (G7-T13 levels b/c, integration 2026-11-09)."""
    out = {5.4}
    for root in roots:
        if root is None:
            continue
        for ind in root.iter(W + "ind"):
            h = _twips(ind.get(W + "hanging")) or 0.0
            f = _twips(ind.get(W + "firstLine")) or 0.0
            for a in ("left", "start", "right", "end"):
                v = _twips(ind.get(W + a))
                if v is not None:
                    out.update((v, v - h, v + f))
        for tag in ("tblCellMar", "tcMar"):
            for m in root.iter(W + tag):
                for side in m:
                    v = _twips(side.get(W + "w"))
                    if v is not None:
                        out.add(v)
        for ti in root.iter(W + "tblInd"):
            v = _twips(ti.get(W + "w"))
            if v is not None:
                out.add(abs(v))
        for tbl in root.iter(W + "tbl"):
            tpr = tbl.find(W + "tblPr")
            if tpr is None or tpr.find(W + "bidiVisual") is None:
                continue
            ind = tpr.find(W + "tblInd")
            base = abs(_twips(ind.get(W + "w")) or 0.0) if ind is not None else 0.0
            mars = {0.0}
            cm = tpr.find(W + "tblCellMar")
            for side in (list(cm) if cm is not None else []):
                v = _twips(side.get(W + "w"))
                if v is not None:
                    mars.add(v)
            grid = tbl.find(W + "tblGrid")
            cols = [(_twips(g.get(W + "w")) or 0.0)
                    for g in (grid.findall(W + "gridCol") if grid is not None else [])]
            acc = 0.0
            for wcol in cols[:-1]:
                acc += wcol
                for m in mars:
                    out.update((acc + m, base + acc + m))
    return sorted(round(v, 2) for v in out if v > 0)


def docx_layout(docx):
    """Page geometry (pt), right-side stops (indents) and the all-bold Hebrew
    paragraphs of a DOCX -- stdlib only."""
    lay = {"page_w": 595.3, "page_h": 841.9, "left": 72.0, "right": 72.0,
           "top": 72.0, "bottom": 72.0, "headings": [], "indents": [], "parsed": False}
    if not docx or not os.path.isfile(docx):
        return lay
    try:
        z = zipfile.ZipFile(docx)
        root = ET.fromstring(z.read("word/document.xml"))
    except Exception:
        return lay
    lay["parsed"] = True
    extra = {}
    for part in ("word/styles.xml", "word/numbering.xml"):
        try:
            extra[part] = ET.fromstring(z.read(part))
        except Exception:
            extra[part] = None
    styles = _Styles(extra["word/styles.xml"])
    lay["indents"] = _indents([root] + list(extra.values()))
    sects = list(root.iter(W + "sectPr"))
    if sects:
        sp = sects[-1]
        sz, mar = sp.find(W + "pgSz"), sp.find(W + "pgMar")
        try:
            lay["page_w"] = int(sz.get(W + "w")) / 20.0
            lay["page_h"] = int(sz.get(W + "h")) / 20.0
            for k in ("left", "right", "top", "bottom"):
                lay[k] = abs(int(mar.get(W + k))) / 20.0
        except (AttributeError, TypeError, ValueError):
            pass
    body = root.find(W + "body")
    for p in (body.iter(W + "p") if body is not None else []):
        ppr = p.find(W + "pPr")
        ps = ppr.find(W + "pStyle") if ppr is not None else None
        pstyle = ps.get(W + "val") if ps is not None else None
        texts, all_bold = [], True
        for r in p.iter(W + "r"):
            t = "".join(x.text or "" for x in r.findall(W + "t"))
            if not t.strip():
                continue
            if not styles.bold(r, pstyle):
                all_bold = False
            texts.append(t)
        text = "".join(texts)
        words = HEB_WORD.findall(NIQQUD.sub("", unicodedata.normalize("NFC", text)))
        if all_bold and texts and sum(len(w) for w in words) >= 3:
            lay["headings"].append({"text": text, "words": words})
    return lay


def _stem(path):
    """sheet.docx / sheet.word.pdf / sheet.pdf -> sheet."""
    b = os.path.basename(path)
    for ext in (".word.pdf", ".docx", ".pdf"):
        if b.lower().endswith(ext):
            return b[:-len(ext)]
    return b


def _unique_names(recs):
    u"""Give every output a name of its own inside its output folder. With
    --out, the contract layout out/docx/<k>/sheet.docx sends every level to
    one folder under the same stem; the second would silently overwrite the
    first one's PDF and pages. Every colliding record (never just the later
    one) is renamed <parent folder>_<stem>, then _2, _3 ... if that still
    collides; the report keeps the original as renamed_from."""
    from collections import Counter
    key = lambda r: (r["_out"], r["name"].lower())
    clash = Counter(key(r) for r in recs)
    taken = set(k for k, n in clash.items() if n == 1)
    for r in recs:
        if clash[key(r)] < 2:
            continue
        src = r.get("pdf") if r.get("from_pdf") else r.get("docx")
        parent = os.path.basename(os.path.dirname(src)) or "x"
        base = "%s_%s" % (parent, r["name"])
        name, i = base, 1
        while (r["_out"], name.lower()) in taken:
            i += 1
            name = "%s_%d" % (base, i)
        taken.add((r["_out"], name.lower()))
        r["renamed_from"], r["name"] = r["name"], name
        print("docx_render: output name %r is used by several inputs in %s; this one "
              "is written as %r" % (r["renamed_from"], r["_out"], name), file=sys.stderr)


def _sibling_docx(pdf, dirs=()):
    base = pdf[:-len(".word.pdf")] if pdf.endswith(".word.pdf") else pdf[:-4]
    for cand in [base + ".docx"] + [os.path.join(d, os.path.basename(base) + ".docx")
                                    for d in dirs]:
        if os.path.isfile(cand):
            return cand
    return None


# ---------------------------------------------------------------- render ----
def _pymupdf():
    try:
        import pymupdf
    except ImportError:
        import fitz as pymupdf     # older alias
    return pymupdf


def render_pngs(pdf, out_dir, name, dpi):
    """<name>_p<N>.png for every page. Stale pages of an earlier, longer
    render of THIS name are removed -- exactly <name>_p<digits>.png, never
    another file that merely starts with "<name>_p" (sheet_pdf_p1.png)."""
    pm = _pymupdf()
    own = re.compile(r"^%s_p\d+\.png$" % re.escape(name))
    for old in os.listdir(out_dir):
        if own.match(old):
            os.remove(os.path.join(out_dir, old))
    doc = pm.open(pdf)
    out = []
    for i, page in enumerate(doc):
        path = os.path.join(out_dir, "%s_p%d.png" % (name, i + 1))
        page.get_pixmap(dpi=dpi).save(path)
        out.append(path)
    return out


def _rows(page, lay):
    """Visual text rows of the BODY area: [{y, x0, x1, text, spans}]."""
    top, bottom = lay["top"], lay["page_h"] - lay["bottom"]
    segs = []
    for b in page.get_text("dict")["blocks"]:
        if b.get("type") != 0:
            continue
        for l in b["lines"]:
            for s in l["spans"]:
                t = s["text"]
                if not t:
                    continue
                x0, y0, x1, y1 = s["bbox"]
                yc = (y0 + y1) / 2.0
                if yc < top or yc > bottom:
                    continue        # header / footer zone
                segs.append((yc, x0, x1, t, s))
    segs.sort(key=lambda z: z[0])
    rows = []
    for yc, x0, x1, t, s in segs:
        if rows and abs(rows[-1]["y"] - yc) <= 4.0:
            rows[-1]["spans"].append((x0, x1, t, s))
        else:
            rows.append({"y": yc, "spans": [(x0, x1, t, s)]})
    out = []
    for r in rows:
        # Whitespace spans (the word gaps, and the paragraph-mark glyph Word
        # prints at the visual end of every line) keep the words apart in the
        # text but never count for the line's extent.
        ink = [z for z in r["spans"] if z[2].strip()]
        if not ink:
            continue
        r["x0"] = min(z[0] for z in ink)
        r["x1"] = max(z[1] for z in ink)
        r["spans"].sort(key=lambda z: -z[1])        # visual right to left
        r["text"] = "".join(z[2] for z in r["spans"])
        out.append(r)
    return out


def assert_right_edge(doc, lay, tol=3.0, centre_tol=6.0, max_indent=0.4):
    u"""docx.md 7.4: every non-centred Hebrew line ends at the RIGHT text edge
    (x1 >= right - 3 pt). The one legitimate exception is a paragraph indent:
    a line of an indented item ends at right - indent. So a line that misses
    the right edge passes only when
      * it is centred (|mid - centre| <= 6 pt), or
      * it does not touch the left margin (an indented item's short line, a
        table cell, a centred block with asymmetric indents), or
      * it touches the left margin AND ends within 3 pt of right - indent for
        an indent this DOCX actually declares (w:ind, cell margins, tblInd):
        a full line that spans margin to indent.
    Anything else hugs the LEFT margin and stops short -- the jc=right flip,
    whatever the line's width (a 99%-wide flipped line fails too). Measured
    on Word PDFs: every flipped line of elem_v10/probe fails, no line of
    elem_v103 or of the 14-page emit_docx G7-T13 sheet does."""
    left = lay["left"]
    right = lay["page_w"] - lay["right"]
    centre = (left + right) / 2.0
    width = right - left
    stops = [i for i in lay.get("indents") or () if i <= max_indent * width]
    fails, stats = [], {"checked": 0, "right_aligned": 0, "centred": 0, "indented": 0,
                        "full_lines": 0}
    heb_rows = right_hits = 0
    for pno, page in enumerate(doc):
        for r in _rows(page, lay):
            if not HEB_WORD.search(r["text"]):
                continue
            stats["checked"] += 1
            mid = (r["x0"] + r["x1"]) / 2.0
            if r["x1"] >= right - tol:
                stats["right_aligned"] += 1
                heb_rows += 1
                right_hits += 1
                continue
            if abs(mid - centre) <= centre_tol:
                stats["centred"] += 1
                continue
            heb_rows += 1
            if r["x0"] > left + tol:
                stats["indented"] += 1
                continue
            gap = right - r["x1"]
            if any(abs(gap - i) <= tol for i in stops):
                stats["full_lines"] += 1
                continue
            fails.append("p%d y=%.0f: left-aligned line x0=%.1f x1=%.1f ends %.1f pt short "
                         "of the right edge %.1f (no declared indent of that size): %s"
                         % (pno + 1, r["y"], r["x0"], r["x1"], gap, right, r["text"][:40]))
    if heb_rows >= 3 and right_hits == 0:
        fails.append("none of the %d Hebrew body lines reaches the right edge %.1f"
                     % (heb_rows, right))
    stats["right_edge_pt"] = round(right, 1)
    stats["indent_stops_pt"] = stops[:20]
    return {"status": "FAIL" if fails else "PASS", "failures": fails, **stats}


def assert_blank_pages(doc, lay):
    top, bottom = lay["top"], lay["page_h"] - lay["bottom"]
    fails = []
    for pno, page in enumerate(doc):
        has = bool(_rows(page, lay))
        if not has:
            for im in page.get_image_info():
                y0, y1 = im["bbox"][1], im["bbox"][3]
                if y1 > top and y0 < bottom:
                    has = True
                    break
        if not has:
            for d in page.get_drawings():
                rc = d.get("rect")
                if rc is not None and rc.y1 > top and rc.y0 < bottom:
                    has = True
                    break
        if not has:
            fails.append("p%d has no body content (blank page)" % (pno + 1))
    return {"status": "FAIL" if fails else "PASS", "failures": fails, "pages": doc.page_count}


def _span_bold(s):
    return "bold" in s["font"].lower() or bool(s["flags"] & 16)


def _pdf_words(t):
    """Hebrew words of PDF text, in both orders: Word stores logical order, other
    producers (PyMuPDF insert_text among them) store visual order."""
    ws = HEB_WORD.findall(NIQQUD.sub("", t))
    return set(ws) | set(w[::-1] for w in ws)


def assert_bold_headings(doc, lay):
    heads = lay["headings"]
    rows = [(pno, r) for pno, page in enumerate(doc) for r in _rows(page, lay)]
    fails, found, missing = [], 0, []
    used = set()
    for h in heads:
        want = [w for w in h["words"] if len(w) >= 2] or h["words"]
        # Rank rows by coverage of the heading words, then by how few OTHER words
        # the row holds. Without the second key a one-word heading ("תזכורת")
        # matched the first body line that merely mentions the word (the "מה בדף"
        # box, integration 2026-11-09) and reported a false FAIL. Each printed
        # heading line is used once, so repeated headings map to distinct lines.
        cands = []
        for idx, (pno, r) in enumerate(rows):
            if idx in used:
                continue
            got = _pdf_words(r["text"])
            hit = sum(1 for w in want if w in got)
            score = hit / float(len(want))
            if score >= 0.6:
                extra = len(set(HEB_WORD.findall(NIQQUD.sub("", r["text"])))) - hit
                cands.append((-score, extra, idx, pno, r))
        if not cands:
            missing.append(h["text"][:40])
            continue
        cands.sort(key=lambda c: (c[0], c[1], c[2]))
        _s, _e, idx, pno, r = cands[0]
        used.add(idx)
        found += 1
        nonbold = []
        for _x0, _x1, t, s in r["spans"]:
            if _pdf_words(t) & set(want) and not _span_bold(s):
                nonbold.append("%s[%s %.1f]" % (t.strip(), s["font"], s["size"]))
        if nonbold:
            fails.append("p%d heading %r printed without bold: %s"
                         % (pno + 1, h["text"][:40], ", ".join(nonbold[:4])))
    # a heading that cannot be found was not checked: REVIEW, never a silent PASS;
    # a DOCX with no bold heading at all leaves nothing to check: SKIP
    if not heads:
        return {"status": "SKIP", "failures": [], "headings": 0, "matched": 0,
                "not_found": [], "reason": "the DOCX has no all-bold Hebrew paragraph "
                                           "(direct, character or paragraph style)"}
    status = "FAIL" if fails else ("REVIEW" if missing else "PASS")
    return {"status": status, "failures": fails,
            "headings": len(heads), "matched": found, "not_found": missing[:10]}


def run_asserts(pdf, docx):
    pm = _pymupdf()
    if not docx or not os.path.isfile(docx):
        # margins and headings come from the DOCX; guessing them would turn
        # right_edge and bold_headings into silent passes
        skip = {"status": "SKIP", "failures": [],
                "reason": "no DOCX beside the PDF (use --docx-dir)"}
        return {"right_edge": dict(skip), "blank_pages": dict(skip),
                "bold_headings": dict(skip)}
    lay = docx_layout(docx)
    doc = pm.open(pdf)
    return {"right_edge": assert_right_edge(doc, lay),
            "blank_pages": assert_blank_pages(doc, lay),
            "bold_headings": assert_bold_headings(doc, lay)}


# -------------------------------------------------------------- selftest ----
_FONT_CANDIDATES = (
    ("/System/Library/Fonts/Supplemental/Arial.ttf",
     "/System/Library/Fonts/Supplemental/Arial Bold.ttf"),
    ("/Applications/Microsoft Word.app/Contents/Resources/DFonts/david.ttf",
     "/Applications/Microsoft Word.app/Contents/Resources/DFonts/davidbd.ttf"),
)


def _selftest_docx(path, heading, bold="direct", indent=None, rtl_table=None):
    """Minimal DOCX: A4, 15 mm side margins, one heading paragraph that is
    bold directly (b/bCs), through its paragraph style ("style"), or not at
    all (None); optionally one paragraph with w:ind left=<indent> twips, and
    optionally a right-to-left table whose first (rightmost) column is
    <rtl_table> twips wide, like the answers table."""
    w = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
    if bold == "direct":
        head = (u'<w:p><w:pPr><w:bidi/></w:pPr><w:r><w:rPr><w:b/><w:bCs/></w:rPr>'
                u'<w:t>%s</w:t></w:r></w:p>' % heading)
    elif bold == "style":
        head = (u'<w:p><w:pPr><w:pStyle w:val="Head"/><w:bidi/></w:pPr><w:r>'
                u'<w:t>%s</w:t></w:r></w:p>' % heading)
    else:
        head = u'<w:p><w:pPr><w:bidi/></w:pPr><w:r><w:t>%s</w:t></w:r></w:p>' % heading
    if indent:
        head += (u'<w:p><w:pPr><w:bidi/><w:ind w:left="%d"/></w:pPr><w:r><w:t>פריט</w:t>'
                 u'</w:r></w:p>' % indent)
    if rtl_table:
        rest = 10206 - rtl_table
        cell = (u'<w:tc><w:tcPr><w:tcW w:w="%d" w:type="dxa"/></w:tcPr><w:p><w:pPr><w:bidi/>'
                u'</w:pPr><w:r><w:t>%s</w:t></w:r></w:p></w:tc>')
        head += (u'<w:tbl><w:tblPr><w:bidiVisual/><w:tblW w:w="10206" w:type="dxa"/>'
                 u'<w:tblCellMar><w:left w:w="0" w:type="dxa"/><w:right w:w="0" w:type="dxa"/>'
                 u'</w:tblCellMar></w:tblPr><w:tblGrid><w:gridCol w:w="%d"/><w:gridCol w:w="%d"/>'
                 u'</w:tblGrid><w:tr>%s%s</w:tr></w:tbl>'
                 % (rtl_table, rest, cell % (rtl_table, u"(1)"), cell % (rest, u"תשובה")))
    doc = (u'<?xml version="1.0" encoding="UTF-8"?><w:document xmlns:w="%s"><w:body>%s'
           u'<w:sectPr><w:pgSz w:w="11906" w:h="16838"/>'
           u'<w:pgMar w:top="907" w:right="850" w:bottom="794" w:left="850"/><w:bidi/>'
           u'</w:sectPr></w:body></w:document>' % (w, head))
    styles = (u'<?xml version="1.0" encoding="UTF-8"?><w:styles xmlns:w="%s">'
              u'<w:style w:type="paragraph" w:styleId="Base"><w:name w:val="Base"/>'
              u'<w:rPr><w:b/><w:bCs/></w:rPr></w:style>'
              u'<w:style w:type="paragraph" w:styleId="Head"><w:name w:val="Head"/>'
              u'<w:basedOn w:val="Base"/></w:style></w:styles>' % w)
    with zipfile.ZipFile(path, "w") as z:
        z.writestr("word/document.xml", doc.encode("utf-8"))
        z.writestr("word/styles.xml", styles.encode("utf-8"))


def _selftest_word_quit(tmp):
    u"""S-F7: convert_batch must not quit Word over someone else's document.
    Runs the real convert_batch with Word simulated in Python: the module's
    osa / word_running and the lock folder are swapped for the duration, so
    no osascript, no pgrep and no real Word lock is touched. The simulated
    Word discards every open document when it is quit without a guard (as the
    real one does with 'quit saving no'), which is how the old unconditional
    quit lost the document someone opened during the render."""
    g = globals()
    saved = {k: g[k] for k in ("osa", "word_running", "WORD_TMP", "LOCK_DIR")}
    src = os.path.join(tmp, "word_in.docx")
    with open(src, "wb") as fh:
        fh.write(b"PK stand-in docx")
    # (name, running at start, other documents, count fails, doc opens before quit,
    #  expected: quit executed, word_quit, word_open_documents, options)
    # options: "noguard" = the simulated quit request quits whatever is open (a
    # broken in-script guard), so only the Python-side count can save the
    # document; "lost-reply" = Word quits but osascript reports error -609.
    cases = [("word-quit-idle", False, 0, False, False, True, True, 0, ()),
             ("word-kept-open-doc", False, 1, False, False, False, False, 1, ()),
             ("word-python-guard", False, 1, False, False, False, False, 1, ("noguard",)),
             ("word-was-running", True, 2, False, False, False, False, None, ()),
             ("word-count-fails", False, 0, True, False, False, False, None, ()),
             ("word-race-on-quit", False, 0, False, True, False, False, 1, ()),
             ("word-quit-reply-lost", False, 0, False, False, True, True, 0, ("lost-reply",))]
    ok_all, lines = True, []
    # The simulated Word above stands in for IDLE_SCRIPT, so the script text's own
    # guard is checked here: the quit must sit inside "quit mode AND no other document".
    body = IDLE_SCRIPT.split("\n")
    guard = [i for i, l in enumerate(body) if l.strip() == 'if wantMode is "quit" and otherCount is 0 then']
    quits = [i for i, l in enumerate(body) if l.strip() == "quit saving no"]
    ok = (len(guard) == 1 and len(quits) == 1 and quits[0] == guard[0] + 1 and
          body[quits[0] + 2].strip() == "end if")
    ok_all &= ok
    lines.append("%s %-18s IDLE_SCRIPT quits only under its document-count guard" %
                 ("PASS" if ok else "FAIL", "word-script-guard"))
    try:
        for name, running, docs, fail, race, want_quit, want_flag, want_n, opts in cases:
            st = {"running": running, "docs": docs, "quits": 0, "lost": 0, "idle": 0}

            def fake_osa(script, args, timeout, st=st, fail=fail, race=race, opts=opts):
                if script == CONVERT_SCRIPT:            # Word starts and writes the PDF
                    st["running"] = True
                    with open(args[1], "wb") as fh:
                        fh.write(b"%PDF-1.4 stand-in\n")
                    return 0, "ok", ""
                if script == CLOSE_SCRIPT:
                    return 0, "ok", ""
                if script == IDLE_SCRIPT:
                    st["idle"] += 1
                    if fail:
                        raise subprocess.TimeoutExpired("osascript", timeout)
                    if not st["running"]:
                        return 0, "not running", ""
                    if args[1] == "quit" and race:
                        st["docs"] = 1
                    if args[1] == "count" or (st["docs"] and "noguard" not in opts):
                        return 0, str(st["docs"]), ""
                    if "lost-reply" in opts:
                        st["quits"] += 1
                        st["lost"] += st["docs"]
                        st["running"] = False
                        return 1, "", "execution error: Connection is invalid. (-609)"
                if "quit" in script and st["running"]:  # any quit that reaches Word
                    st["quits"] += 1
                    st["lost"] += st["docs"]
                    st["running"] = False
                    return 0, "quit", ""
                return 0, "ok", ""

            g["osa"], g["word_running"] = fake_osa, (lambda st=st: st["running"])
            g["WORD_TMP"] = os.path.join(tmp, "wordtmp_" + name)
            g["LOCK_DIR"] = os.path.join(g["WORD_TMP"], "claude-word.lock")
            res = convert_batch([src], [os.path.join(tmp, "word_out", name + ".word.pdf")],
                                timeout=5, lock_wait=5, log=lambda s: None)
            r = res[0]
            ok = (r.get("error") is None and (st["quits"] == 1) == want_quit and
                  st["lost"] == 0 and r.get("word_quit") is want_flag and
                  r.get("word_open_documents") == want_n and bool(r.get("word_note")) and
                  st["running"] == (not want_quit) and
                  (st["idle"] == 0 if running else st["idle"] >= 1) and
                  not os.path.exists(g["LOCK_DIR"]))
            ok_all &= ok
            lines.append("%s %-18s quit=%s lost=%d word_quit=%s open=%s" % (
                "PASS" if ok else "FAIL", name, st["quits"] == 1, st["lost"],
                r.get("word_quit"), r.get("word_open_documents")))
    finally:
        g.update(saved)
    return ok_all, lines


def selftest():
    u"""Offline proof of the asserts on PDFs drawn with PyMuPDF (no Word):
    each case is the clean page plus ONE defect (or one legitimate variant),
    and exactly the listed asserts may fail; plus the output-naming rules and
    the Word-quit rule (simulated Word, see _selftest_word_quit)."""
    import tempfile
    tmp = tempfile.mkdtemp(prefix="docx_render_selftest_")
    word_ok, word_lines = _selftest_word_quit(tmp)
    pm = _pymupdf()
    fonts = [f for f in _FONT_CANDIDATES if os.path.isfile(f[0]) and os.path.isfile(f[1])]
    if not fonts:
        print("\n".join(word_lines))
        print("SKIP docx_render selftest asserts: no Hebrew-capable TTF found")
        return word_ok
    reg, bold = fonts[0]
    heading = u"זוויות צמודות"
    docxs = {}
    for key, kw in (("direct", {}), ("style", {"bold": "style"}), ("none", {"bold": None}),
                    ("indent", {"indent": 880}), ("rtl-table", {"rtl_table": 720})):
        docxs[key] = os.path.join(tmp, "case_%s.docx" % key)
        _selftest_docx(docxs[key], heading, **kw)
    lay = docx_layout(docxs["direct"])
    left, right = lay["left"], lay["page_w"] - lay["right"]
    width = right - left
    fr, fb = pm.Font(fontfile=reg), pm.Font(fontfile=bold)
    body = [u"נתונה הזווית שגודלה ארבעים מעלות", u"חשבו את הזווית הצמודה לה",
            u"כתבו תרגיל מתאים", u"השלימו את הטבלה שלפניכם"]
    long_t = u"נתונה הזווית"
    while fr.text_length(long_t, 12) < 0.80 * width:
        long_t += u" שגודלה מעלות"

    def fill_to(gap):
        u"""Words up to a line ending `gap` pt short of the right edge, then the
        size that makes it end there exactly (spans margin to that indent)."""
        t = u"פריט"
        while fr.text_length(t + u" מעלות", 12) < width - gap:
            t += u" מעלות"
        return t, 12.0 * (width - gap) / fr.text_length(t, 12)

    def page(doc, flip=None, plain_heading=False, indent_line=None):
        p = doc.new_page(width=lay["page_w"], height=lay["page_h"])
        hf = fr if plain_heading else fb
        hw = hf.text_length(heading, 18)
        p.insert_text(((lay["page_w"] - hw) / 2.0, 90), heading, fontsize=18,
                      fontfile=reg if plain_heading else bold,
                      fontname="h0" if plain_heading else "h1")
        lines = list(body) + ([flip] if flip and flip != "short" else [])
        for i, t in enumerate(lines):
            tw = fr.text_length(t, 12)
            x = left if (flip == "short" and i == 1) or (flip and t == flip) else right - tw
            p.insert_text((x, 130 + 22 * i), t, fontsize=12, fontfile=reg, fontname="r0")
        if indent_line:
            t, fs = fill_to(indent_line)
            p.insert_text((left, 130 + 22 * len(lines)), t, fontsize=fs, fontfile=reg,
                          fontname="r0")
        return p

    # (name, page options, docx, asserts that must FAIL, asserts that must SKIP)
    cases = [("clean", {}, "direct", set(), set()),
             ("flipped-short", {"flip": "short"}, "direct", {"right_edge"}, set()),
             ("flipped-80pct", {"flip": long_t}, "direct", {"right_edge"}, set()),
             ("indent-full-line", {"indent_line": 44.0}, "indent", set(), set()),
             ("undeclared-indent", {"indent_line": 44.0}, "direct", {"right_edge"}, set()),
             # a full answer line in the second column of a right-to-left table
             # ends 36 pt short of the right edge: legitimate; the same line in a
             # DOCX without that table is a flip
             ("rtl-table-column", {"indent_line": 36.0}, "rtl-table", set(), set()),
             ("no-table-36pt", {"indent_line": 36.0}, "direct", {"right_edge"}, set()),
             ("plain-heading", {"plain_heading": True}, "direct", {"bold_headings"}, set()),
             ("style-bold-plain", {"plain_heading": True}, "style", {"bold_headings"}, set()),
             ("style-bold-ok", {}, "style", set(), set()),
             ("no-headings", {}, "none", set(), {"bold_headings"}),
             ("blank-page", {"blank": True}, "direct", {"blank_pages"}, set())]
    ok_all, lines = word_ok, list(word_lines)
    for name, opt, dk, want, want_skip in cases:
        pdf = os.path.join(tmp, name + ".pdf")
        doc = pm.open()
        page(doc, flip=opt.get("flip"), plain_heading=opt.get("plain_heading"),
             indent_line=opt.get("indent_line"))
        if opt.get("blank"):
            doc.new_page(width=lay["page_w"], height=lay["page_h"])
        doc.save(pdf)
        res = run_asserts(pdf, docxs[dk])
        failed = set(k for k, v in res.items() if v["status"] == "FAIL")
        skipped = set(k for k, v in res.items() if v["status"] == "SKIP")
        ok = failed == want and skipped == want_skip and \
            not any(v["status"] == "REVIEW" for v in res.values()) and \
            (res["bold_headings"]["matched"] == 1 or "bold_headings" in want_skip)
        ok_all &= ok
        lines.append("%s %-18s failed=%s skipped=%s" % ("PASS" if ok else "FAIL", name,
                                                       sorted(failed), sorted(skipped)))
    # Regression (integration 2026-11-09): a one-word bold heading ("תזכורת")
    # below a plain body line that merely mentions the word (the "מה בדף" box).
    # The heading must be matched to its own bold line, not to the body line.
    one = u"תזכורת"
    d1 = os.path.join(tmp, "case_oneword.docx")
    _selftest_docx(d1, one)
    p1 = os.path.join(tmp, "oneword-heading.pdf")
    doc = pm.open()
    pg = doc.new_page(width=lay["page_w"], height=lay["page_h"])
    mention = u"בכל קטע יש " + one + u" ודוגמה פתורה"
    pg.insert_text((right - fr.text_length(mention, 12), 70), mention, fontsize=12,
                   fontfile=reg, fontname="r0")
    pg.insert_text(((lay["page_w"] - fb.text_length(one, 16)) / 2.0, 110), one,
                   fontsize=16, fontfile=bold, fontname="h1")
    for i, t in enumerate(body):
        pg.insert_text((right - fr.text_length(t, 12), 140 + 22 * i), t, fontsize=12,
                       fontfile=reg, fontname="r0")
    doc.save(p1)
    bh = run_asserts(p1, d1)["bold_headings"]
    ok = bh["status"] == "PASS" and bh["matched"] == 1
    ok_all &= ok
    lines.append("%s %-18s %s" % ("PASS" if ok else "FAIL", "one-word-heading",
                                  bh["status"] if ok else bh))

    res = run_asserts(os.path.join(tmp, "clean.pdf"), None)
    ok = all(v["status"] == "SKIP" for v in res.values())
    ok_all &= ok
    lines.append("%s %-18s %s" % ("PASS" if ok else "FAIL", "no-docx", "all SKIP" if ok else res))

    # stale-page cleanup touches only <name>_p<N>.png
    od = os.path.join(tmp, "pngs")
    os.makedirs(od)
    keep = ["sheet_pdf_p1.png", "sheet_print_p2.png", "other_p1.png", "sheet_p1.png.bak"]
    for n in keep + ["sheet_p7.png"]:
        with open(os.path.join(od, n), "wb") as fh:
            fh.write(b"x")
    render_pngs(os.path.join(tmp, "blank-page.pdf"), od, "sheet", 20)
    after = sorted(os.listdir(od))
    ok = after == sorted(keep + ["sheet_p1.png", "sheet_p2.png"])
    ok_all &= ok
    lines.append("%s %-18s %s" % ("PASS" if ok else "FAIL", "png-cleanup", after))

    # one output folder, two inputs with the same stem -> two distinct names
    recs = [{"docx": "/x/a/sheet.docx", "_out": "/o", "name": "sheet"},
            {"docx": "/x/b/sheet.docx", "_out": "/o", "name": "sheet"},
            {"pdf": "/x/c/sheet.word.pdf", "from_pdf": True, "_out": "/o", "name": "sheet"},
            {"docx": "/x/a/other.docx", "_out": "/o", "name": "a_sheet"},
            {"docx": "/x/d/sheet.docx", "_out": "/p", "name": "sheet"}]
    import contextlib
    import io
    with contextlib.redirect_stderr(io.StringIO()):
        _unique_names(recs)
    names = [r["name"] for r in recs]
    ok = len(set(names[:4])) == 4 and names[4] == "sheet" and "renamed_from" in recs[0]
    ok_all &= ok
    lines.append("%s %-18s %s" % ("PASS" if ok else "FAIL", "name-collision", names))
    lines.append("DOCX_RENDER SELFTEST %s (font %s)" % ("PASS" if ok_all else "FAIL",
                                                       os.path.basename(reg)))
    print("\n".join(lines))
    return ok_all


# ------------------------------------------------------------------ main ----
def main(argv=None):
    if argv is None and sys.argv[1:] == ["--selftest"] or argv == ["--selftest"]:
        return 0 if selftest() else 1
    ap = argparse.ArgumentParser(description="DOCX -> Word PDF -> PNG (+ visual asserts)")
    ap.add_argument("inputs", nargs="+", help=".docx files (or existing <name>.word.pdf)")
    ap.add_argument("--dpi", type=int, default=110)
    ap.add_argument("--out", default=None, help="output folder (default: beside each input)")
    ap.add_argument("--assert", dest="do_assert", action="store_true",
                    help="run the docx.md 7.4 checks on the Word PDF")
    ap.add_argument("--json", dest="json_out", default=None)
    ap.add_argument("--timeout", type=float, default=120.0, help="watchdog per file (s)")
    ap.add_argument("--lock-wait", type=float, default=1800.0, help="max wait for the Word lock (s)")
    ap.add_argument("--no-png", action="store_true")
    ap.add_argument("--docx-dir", action="append", default=[],
                    help="for .word.pdf inputs: folder(s) holding the source .docx")
    a = ap.parse_args(argv)
    for sig in (signal.SIGTERM, signal.SIGHUP):
        signal.signal(sig, _on_signal)

    files = []
    for inp in a.inputs:
        inp = os.path.abspath(inp)
        if not os.path.isfile(inp):
            files.append({"docx": inp, "error": "input not found"})
            continue
        out_dir = os.path.abspath(a.out) if a.out else os.path.dirname(inp)
        low = inp.lower()
        if low.endswith(".pdf"):
            files.append({"docx": _sibling_docx(inp, [os.path.abspath(d) for d in a.docx_dir]),
                          "pdf": inp, "error": None, "from_pdf": True, "_out": out_dir,
                          "name": _stem(inp)})
        elif low.endswith(".docx"):
            files.append({"docx": inp, "pdf": None, "error": None, "_out": out_dir,
                          "name": _stem(inp)})
        else:
            files.append({"docx": inp, "error": "not a .docx or .pdf"})
    _unique_names([f for f in files if f.get("_out")])
    todo = [f for f in files if f.get("_out") and not f.get("from_pdf")]
    code = 0
    if todo:
        if sys.platform != "darwin" or not os.path.isdir("/Applications/Microsoft Word.app"):
            for f in todo:
                f["error"] = "Microsoft Word for Mac is not available"
        else:
            srcs = [f["docx"] for f in todo]
            dests = [os.path.join(f["_out"], f["name"] + ".word.pdf") for f in todo]
            try:
                res = convert_batch(srcs, dests, timeout=a.timeout, lock_wait=a.lock_wait,
                                    log=lambda s: print(s, file=sys.stderr))
            except RenderError as e:
                res = []
                for f in todo:
                    f["error"] = str(e)
            for f, r in zip(todo, res):
                f.update(r)
    for f in files:
        if f.get("error") or not f.get("pdf"):
            code = 2
            continue
        out_dir = f.get("_out") or os.path.dirname(f["pdf"])
        os.makedirs(out_dir, exist_ok=True)
        pm = _pymupdf()
        f["pages"] = pm.open(f["pdf"]).page_count
        if not a.no_png:
            f["pngs"] = render_pngs(f["pdf"], out_dir, f["name"], a.dpi)
        if a.do_assert:
            f["asserts"] = run_asserts(f["pdf"], f.get("docx"))
            for k, x in f["asserts"].items():
                if x["status"] in ("SKIP", "REVIEW"):
                    print("docx_render: assert %s %s for %s: %s" % (
                        k, x["status"], f["pdf"], x.get("reason") or
                        "not found in the PDF: %s" % "; ".join(x.get("not_found") or [])),
                        file=sys.stderr)
            if any(x["status"] == "FAIL" for x in f["asserts"].values()) and code == 0:
                code = 1
    for f in files:
        f.pop("_out", None)
    report = {"tool": "docx_render %s" % VERSION, "dpi": a.dpi, "files": files, "exit": code}
    txt = json.dumps(report, ensure_ascii=False, indent=1)
    if a.json_out:
        with open(a.json_out, "w", encoding="utf-8") as fh:
            fh.write(txt)
    print(txt)
    return code


if __name__ == "__main__":
    sys.exit(main())
