# -*- coding: utf-8 -*-
r"""figkit — figures drawn FROM THE NUMBERS, with labels PLACED, not posed.

WHY THIS FILE EXISTS (Sep 2026, after the 447-sheet audit).
The audit's single largest defect class, 120 sheets of 447, was a label with
a line through it: a vertex letter, an axis number or a length label whose
glyphs are crossed by a stroke. `60` on a diagonal then reads as `-60`, and
the text layer extracts perfectly, so no text gate can see it.

`trapz_kit._Canvas.check()` already looked for this and was not enough, for
two reasons that this module fixes:

  1. It DETECTED and raised. The author still had to nudge the label by hand,
     and a figure that is hand-nudged once is hand-nudged wrong later. Here
     placement is SOLVED: every label is given an anchor and a preferred
     side, and the engine searches outward for a position that touches no
     stroke and no other label. It raises only when no such position exists,
     which means the figure itself is too crowded.

  2. It exempted vertex letters from the stroke sweep, on the theory that a
     letter may legitimately hug its edge. That exemption is precisely where
     the 120 sheets went: `A` printed on the hypotenuse is not hugging, it is
     unreadable. Here EVERY label is swept, and "hugging" is expressed as a
     smaller clearance, not as an exemption.

Two more gates the old canvas did not have:

  * FONT FLOOR. The audit found labels rendered at 4-5pt, and one figure at
    ~2pt. A figure is emitted at a display width, so the effective point size
    is `size * display/viewBox * 0.75`. That number, not the raw attribute,
    is what a reader sees, and it must clear MIN_PT.

  * PROPORTIONS. `trapz_kit` asserts drawn-vs-given ratios for trapezoids.
    The same law applies to every shape: if the sheet says 3, 4, 5 then the
    drawing measures 3, 4, 5. Any builder here computes coordinates from the
    data and re-measures the result before emitting a byte.

SVG carries GEOMETRY ONLY (G49): WeasyPrint does not run the bidi algorithm
inside <svg><text>, so a Hebrew label prints reversed. Latin letters, digits
and ° only; Hebrew captions belong in the HTML beneath the figure.
"""
import math
import re

import export
import svgcheck

INK = "#111"
# A grid is background, not ink. The value matters: at #c9c9c9 the grid
# reads 0.79 luminance, which is BELOW the 0.85 threshold G72 uses on the
# finished PDF, so the two checkers disagreed about whether a numeral on a
# gridline was struck. Two checkers with two thresholds is how the original
# defects survived, so the grid is now light enough that both agree.
# P1 (the author, 2026-09-17, against Typst): at #e8e8e8 and 0.4 units the
# grid printed almost invisible and could vanish on a laser printer. The grid
# is now a light but VISIBLE grey (0.78 luminance, svgcheck.GRID_BAND) and is
# recognised as background BY ITS COLOUR (svgcheck.GRID_GREY), not by being
# too faint to see -- so every checker still agrees a number on a gridline is
# not struck (the grid is knocked out under every label anyway).
GRID = svgcheck.GRID_GREY
MIN_PT = 7.0
# Two labels closer than this read as one word.
_LABEL_GAP_PT = 2.0            # smallest effective point size a reader may be given
_TOL = 0.02             # drawn-vs-given proportion tolerance
_CHAR_W = 0.58          # advance width per char, in units of font size
# An axis number that slides along its axis reads as the neighbouring value
# (a review found the x-axis "2" printed between ticks, under a plotted line).
_TICK_SLIDE = 0.6       # max drift ALONG the axis, in units of font size
_TICK_STEPS = 2          # max outward steps: further out it reads as another row
# v6 (E1): a PINNED tick number is centred on its tick. It may slide along its
# axis only to clear another number or a dot, and never by more than this
# fraction of the tick spacing -- under svgcheck.TICK_TOL (0.15), which the
# finished SVG is held to at every render.
PIN_SLIDE = 0.14
# v6 stage 1b (the author's rule of 2026-09-16): a data stroke is NEVER cut,
# broken, shortened or hidden by a number, and a number is never dropped, so
# the NUMBER is what moves. A number a stroke reaches may slide up to this
# fraction of the tick spacing (still well inside half a spacing, so its centre
# stays nearer its own tick than any other -- svgcheck.tick_alignment checks
# that on the finished file), then cross its axis, then step this far out from
# the axis; only then is the figure refused.
PIN_SLIDE_INK = 0.34      # under svgcheck.MOVED_TOL (0.35), as PIN_SLIDE is under TICK_TOL
_FILL_BLOCKS = True     # C6 r6: a shaded region's edge blocks a number
PIN_DROP_EM = 0.70      # max step away from the axis, in units of font size
# P3 leftovers r2: a number that left its row reads as the label of whatever
# it landed beside -- when it stands WITHIN _ROW_NEAR_EM of a data stroke
# (the reading distance; the plate already keeps it off the ink) and that
# stroke is _ROW_INK times nearer than the tick it names.
# The BUILDER is the stricter of the two: it passes over a crossed spot
# whose stroke is 1.6 x nearer than the tick and keeps looking, while
# svgcheck.ROW_INK refuses a finished file only at 3 x -- so a figure with
# no better spot still prints, and only a number truly handed to a stroke
# is refused.
_ROW_INK = 1.6
# OFF by default (-1). At 0.75 the solver passes over a crossed spot whose
# stroke is _ROW_INK x nearer than the tick and keeps looking -- which is
# what moves a number like the gallery `divide` figure's '2' back into its
# row -- but it also re-places numbers across figures that had settled, and
# five shipped checks of stage 1b went red on placements that read fine.
# svgcheck.number_on_data(svg) reports the result either way, and that is
# what a sheet should be audited with.
_ROW_NEAR_EM = -1.0
#                         (well under svgcheck._rows' 0.75 em, so a number that
#                         stepped out is still read as one of its own row)
# Ink metrics of the shipped face (DavidLibre-Regular, measured with fontTools):
# digits and U+2212 advance 0.50 em, '.' and ',' 0.36 em; digit ink spans
# 0.63 em above the baseline and 0.02 below. Two numbers are tested against
# each other by this ink, a dot and an uncuttable stroke against it padded as
# svgcheck.struck reads a number (NUM_PAD_EM), and a stroke is CUT back to it
# plus _PLATE_EDGE (C2 round 2; round 1 cut to the solver's 0.58 x 1.02 em box).
_GLYPH_ADV = dict([(c, 0.50) for c in "0123456789−+"] +
                  [(".", 0.36), (",", 0.36)])
_GLYPH_TOP, _GLYPH_BOT = 0.66, 0.03
_GLYPH_BOT_COMMA = 0.20   # a comma's tail (0.19 em measured)
# C2 round 2: a stroke is cut back to the digits' INK plus svgcheck's
# NUM_PAD_EM plus this edge (half the widest data stroke, 0.8, and 0.4 of
# white), not to the solver's 0.58 x 1.02 em box grown 1.5 x 1.0 units.
_PLATE_EDGE = 1.2
# A row of numbers crosses to the other side of its axis when that saves at
# least this many tick spacings of ink from the cut, and at least half of it.
_FLIP_GAIN = 0.7
# C2 round 3: ... or half an em of stroke, whichever is less. With the
# numbers two squares apart (step=2) 0.7 spacings is 22 units, and a line
# along the row cut behind '2', '4' and '6' (9.4 units each) printed as
# dashes '0 - 2 -- 4 -- 6' with the other side of the axis empty.
_FLIP_EM = 0.5
_MERGE_EM = 0.45        # '0' closer than this to a number on its band merges
_PIN_PAD = 1.2          # smallest gap between two pinned numbers' ink, units
_COMPLETE = 0.995       # E4: emitted + covered stroke length >= this x input
_PX_TO_PT = 0.75        # 1 CSS px = 0.75pt
ASC_SUP = 0.78          # ascent of a raised run, em (svgcheck.ASC)
# v6 C3 (E5): a mark is a CLAIM about the geometry, checked against it.
RIGHT_TOL = 0.5         # a right-angle mark sits on 90 +- this many degrees
EQUAL_TOL = 0.015       # segments sharing a tick count agree within 1.5%
PARALLEL_TOL = 0.5      # segments sharing an arrow count agree within 0.5 deg
# v6 C3 (E9): printed floors of the marks, independent of the display scale.
# h36/h38 printed equality ticks 3.7pt long and 2.5 units apart: two ticks
# read as one thick one.
TICK_LEN_PT = 5.0       # an equality tick / a chevron is at least this long
ON_AXIS_TICK_LEAN = 25.0  # equality ticks on a side along an axis lean off it
TICK_GAP_PT = 2.5       # clear paper between two ticks of one group
HEAD_PT = 4.0           # an arrowhead's barbs
# v6.4 T2-2: the span bracket's turned ends. SPAN_SERIF is a fraction of the
# bracket's own offset (so the end is always about half the way back to the
# side it names, at any figure size), SPAN_SERIF_LEAN the tilt off the
# perpendicular that keeps the serif's line clear of the vertex -- see
# Figure.span_ticks.
SPAN_SERIF = 0.55
SPAN_SERIF_LEAN = 32.0
SPAN_SERIF_MAX = 7.0     # ... and never longer than this, so a bracket
#                          stacked outside another does not reach back into it
SPAN_SERIF_INSET = 0.8   # ... and never reaching more than this fraction of
#                          the offset back towards the side it names, so the
#                          `size` floor cannot poke the serif through it
# v6 C3 (E8): a point MARKER (open, triangle, square, cross, or a filled one
# beside them) is at least this big, half its extent, as printed.
MARKER_R_PT = 3.5
# v6.2 Q1 (arc-size-follows-width, adjacent-equal-arcs-read-as-one,
# r3-arc-stepout-unbounded): an ANGLE ARC is printed at a printed size like
# every other mark. r=18 units with a 4.5-unit step printed 4.2pt with 2.1pt
# between the rings at an item width and 14pt with 7.1pt at 430px, so the
# same triple arc was a hairline stack on one sheet and two squares wide on
# the next. The nest at a vertex is laid out in PRINTED pt and then
# compressed, never past the floors, to stay inside the angle's own rays.
ARC_R_PT = 7.5          # the innermost angle arc, printed radius
# v6.2 Q1 r1 (arcs-no-grouping): the gap INSIDE one marking and the gap
# BETWEEN two markings at one vertex are different sizes, or the page shows
# one even fan and 'two strokes' cannot be counted. The two angles the
# author marked equal printed as five uniformly spaced rings across one
# wedge and two + three across the other, 2.6pt apart everywhere.
ARC_STEP_PT = 2.1       # printed paper between two rings of ONE marking
ARC_GROUP_PT = 4.4      # ... and between one marking and the next (~2x)
ARC_R_MIN_PT = 4.5      # ... compressed no further than this
# v6.2 Q1 r1 (arc-floor-too-tight): 1.7pt centre to centre left 0.8pt of
# paper (0.28mm) between two 0.9pt rings -- a screen judgement, not a print
# one: photocopied, the rings merge and the marking cannot be counted.
# Typst and LaTeX draw one angle arc at ~9pt and never subdivide below 2pt.
ARC_STEP_MIN_PT = 2.0   # (0.9pt of pen leaves 1.1pt of paper, 0.39mm)
ARC_GROUP_MIN_PT = 3.2  # ... a marking boundary stays readable as a boundary
ARC_INSIDE = 0.5        # an arc stays this far inside the SHORTER of its own
                        # two rays -- the bound the step-out never had: on a
                        # -1..3 window the outer ring of a containing angle
                        # ran through a vertex dot and along a side
ARC_LABEL_GAP_PT = 6.0  # the angle's own text, outside the OUTERMOST ring
ARC_SAME_TOL = 0.0087   # rad (0.5 deg): the same angle listed twice
# P2-02: the paper a marker's LETTER keeps from its rim, printed (see
# Figure._letter_owns). The marker's box pad was 0.6 figure units for every
# label, so a ±7 plane shrunk to fit printed its 'Q' 0.36pt from the open ring
# ('QO'); svgcheck.marker_clearance wants MARKER_CLEAR_PT (1.0pt).
MARKER_PAD_PT = 1.8
LETTER_REACH_EM = 1.0   # a point's letter box within this x its size of the point
MARKER_STYLES = ("filled", "open", "tri", "square", "cross")
# v6 C3 (E24): two labels on one baseline band closer than this read as one
# word ('5 16', '4 Q', 'B D').
MERGE_EM = 0.6
AXIS_MARK_CLEAR = 0.35  # C3 r2: a mark on an axis, from its tick marks (spacings)
_FAM_TAG_RE = re.compile(r"<!--\s*fam:[^>]*?-->")


def tag(svg, fam):
    """v6 C3 (E10): declare WHAT a figure draws, as `<!--fam:NAME-->` right
    after the opening tag, so `gate_variety.figure_family_plus` counts objects
    by configuration instead of by coordinates. Public since v6 (it was
    `euclid._tag`). A figure already tagged is re-tagged, never tagged twice.
    `fam` is Latin, digits and `.+-_:`; it names the object ("triangle.right",
    "numberline.points"), not the question."""
    fam = str(fam).strip()
    if not fam or not re.match(r"^[A-Za-z0-9.+\-_:=,]+$", fam):
        raise AssertionError(
            "figkit.tag: fam=%r -- name the object with Latin letters, digits "
            "and . + - _ : (e.g. 'triangle.right+altitude')" % (fam,))
    svg = _FAM_TAG_RE.sub("", svg, count=1)
    return svg.replace(">", "><!--fam:%s-->" % fam, 1)


def _angle_deg(v, a, b):
    """The angle a-v-b in degrees, 0..180."""
    ux, uy = a[0] - v[0], a[1] - v[1]
    wx, wy = b[0] - v[0], b[1] - v[1]
    n = math.hypot(ux, uy) * math.hypot(wx, wy)
    if n <= 0:
        return 0.0
    return math.degrees(math.acos(max(-1.0, min(1.0, (ux * wx + uy * wy) / n))))


# P3 leftovers r1 (origin-letter-flies-off-its-point): letters and digits
# drawn from the same pen that a reader cannot tell apart at 8pt. The
# origin's letter 'O' printed 0.67 em from the axis '0' on 12 pilot figures:
# two near-identical rings one glyph-width apart, which read as one mark or
# as a doubled zero. Such a pair needs a whole em, not the 0.6 that parts
# two ordinary labels.
CONFUSE_EM = 1.0
_CONFUSABLE = {"O": "0", "o": "0", "I": "1", "l": "1", "S": "5", "Z": "2",
               "B": "8"}


def _confusable(ta, tb):
    """Do the two label texts print as the same mark ('O' and '0')?"""
    a = (ta or "").strip().lstrip("\u2212-")
    b = (tb or "").strip().lstrip("\u2212-")
    return _CONFUSABLE.get(a) == b or _CONFUSABLE.get(b) == a


def merge_em(ta=None, tb=None):
    """The paper two labels need between them, in ems of the larger."""
    return CONFUSE_EM if _confusable(ta, tb) else MERGE_EM


def _reading_merge(a, sa, b, sb, ta=None, tb=None):
    """E24: the gap between boxes a and b (font sizes sa, sb) when they share a
    baseline band -- their heights overlap by at least half the smaller one --
    and stand closer than MERGE_EM of the larger size; else None.

    P3 leftovers r1: a CONFUSABLE pair ('O' beside the axis '0') needs
    CONFUSE_EM instead."""
    h = min(a[3] - a[1], b[3] - b[1])
    if min(a[3], b[3]) - max(a[1], b[1]) < 0.5 * h:
        return None
    gap = max(a[0] - b[2], b[0] - a[2])
    em = merge_em(ta, tb)
    return gap if gap < em * max(sa, sb) - 1e-9 else None


def _fs(v):
    """A font size as written into the SVG: rounded UP to 0.01. Written with
    '%.1f', a 9.34 label that verify() had passed at 7.004pt was emitted as
    9.3 and read back by svgcheck at 6.98pt."""
    return "%.2f" % (math.ceil(v * 100.0 - 1e-6) / 100.0)


# ------------------------------------------------------------- geometry ---
def _dist(p, q):
    return math.hypot(p[0] - q[0], p[1] - q[1])


def _mid(p, q):
    return ((p[0] + q[0]) / 2.0, (p[1] + q[1]) / 2.0)


def _mark_ink_point(s):
    """A point on a tick / chevron mark's own strokes (v6.7-noam ink_xy)."""
    g = s.get("geom")
    if not g:
        return None
    lines, fills, opens, rings = g
    if lines:
        a, b = lines[0]
        return ((a[0] + b[0]) / 2.0, (a[1] + b[1]) / 2.0)
    for P in list(fills) + list(opens):
        if P:
            return tuple(P[0])
    for c, r, _ in rings:
        return (c[0] + r, c[1])
    return None


def _arc_ink_point(e):
    """The middle of an angle arc's inner stroke (v6.7-noam ink_xy)."""
    rr = min(e["radii"]) if e.get("radii") else None
    if rr is None:
        return None
    a = (e["a1"] + e["a2"]) / 2.0
    v = e["at"]
    return (v[0] + rr * math.cos(a), v[1] + rr * math.sin(a))


def _unit(a, b):
    L = _dist(a, b) or 1.0
    return ((b[0] - a[0]) / L, (b[1] - a[1]) / L)


def _seg_box(p, q, box):
    """Does segment p-q intersect axis-aligned box (x0,y0,x1,y1)?"""
    x0, y0, x1, y1 = box
    if max(p[0], q[0]) < x0 or min(p[0], q[0]) > x1:
        return False
    if max(p[1], q[1]) < y0 or min(p[1], q[1]) > y1:
        return False
    dx, dy = q[0] - p[0], q[1] - p[1]
    t0, t1 = 0.0, 1.0
    for pk, qk in ((-dx, p[0] - x0), (dx, x1 - p[0]),
                   (-dy, p[1] - y0), (dy, y1 - p[1])):
        if abs(pk) < 1e-12:
            if qk < 0:
                return False
        else:
            t = qk / pk
            if pk < 0:
                if t > t1:
                    return False
                t0 = max(t0, t)
            else:
                if t < t0:
                    return False
                t1 = min(t1, t)
    return t0 < t1


def _segs_cross(a, b, p, q):
    """Do segments a-b and p-q intersect (touching counts)?"""
    def orient(u, v, w):
        return (v[0] - u[0]) * (w[1] - u[1]) - (v[1] - u[1]) * (w[0] - u[0])
    d1, d2 = orient(p, q, a), orient(p, q, b)
    d3, d4 = orient(a, b, p), orient(a, b, q)
    return d1 * d2 <= 1e-9 and d3 * d4 <= 1e-9


def _num_pair(p):
    """"(2, -1)" -- a point named by the coordinates the author wrote."""
    out = []
    for v in p:
        if abs(v - round(v)) < 0.02:
            v = round(v)
        out.append(("%.6g" % v).replace("-", "\u2212"))
    return "(%s, %s)" % tuple(out)


def _seg_key(a, b):
    return (round(a[0], 6), round(a[1], 6), round(b[0], 6), round(b[1], 6))


_NUMERIC_MEMO = {}


def _numeric(text):
    """A text svgcheck reads by its ink: digits, U+2212, '+', '.', ','.
    PERF (P1 r1): memoised -- the pin solver asks ~3 million times a figure
    about a few dozen strings."""
    r = _NUMERIC_MEMO.get(text)
    if r is None:
        t = text.strip()
        r = _NUMERIC_MEMO[text] = bool(t) and t == text and all(
            c in _GLYPH_ADV for c in t)
    return r


def _glyph_width(text, size):
    return sum(_GLYPH_ADV.get(c, _CHAR_W) for c in text) * size


def _boxes_overlap(a, b, pad=0.0):
    return not (a[2] + pad < b[0] or b[2] + pad < a[0]
                or a[3] + pad < b[1] or b[3] + pad < a[1])


def _centroid(pts):
    return (sum(p[0] for p in pts) / len(pts),
            sum(p[1] for p in pts) / len(pts))


def _point_in_poly(pt, pts):
    x, y = pt
    inside, j = False, len(pts) - 1
    for i in range(len(pts)):
        xi, yi = pts[i]
        xj, yj = pts[j]
        if (yi > y) != (yj > y):
            if x < xi + (y - yi) * (xj - xi) / ((yj - yi) or 1e-12):
                inside = not inside
        j = i
    return inside


def assert_no_hebrew(svg):
    """G49 — WeasyPrint does not run bidi inside <svg><text>."""
    for m in re.finditer(r"<text[^>]*>(.*?)</text>", svg, re.S):
        for ch in m.group(1):
            if 0x0590 <= ord(ch) <= 0x05FF:
                raise AssertionError(
                    "Hebrew %r inside <svg><text> — it will print reversed; "
                    "put the caption in the HTML beneath the figure" % ch)
    return svg


# ------------------------------------------------------------ the engine ---
class Label(object):
    """A label is an ANCHOR plus a preference, never a fixed position. The
    engine decides where it actually goes."""

    __slots__ = ("anchor", "text", "size", "italic", "prefer", "kind",
                 "pos", "box", "gap", "sector", "halo", "cut", "sup", "pin",
                 "glyph", "plate", "centred", "owner", "phantom", "past_head",
                 "export_owner", "export_point", "export_face",
                 "value_text", "exid")

    def __init__(self, anchor, text, size, italic, prefer, kind, gap,
                 sector=None, halo=False):
        self.anchor, self.text, self.size = anchor, text, float(size)
        self.italic, self.prefer, self.kind, self.gap = italic, prefer, kind, gap
        # `sector` caps how far from `prefer` the engine may swing, in
        # degrees. An axis tick label MUST stay on its own side of the axis:
        # allowed to flip, the solver dodged a plotted line by putting the
        # x-label `-1` above the axis, where it reads as a y-value.
        self.sector = sector
        # A gridline running through an axis number is the corpus audit's
        # single most common finding, and the label solver does not move for
        # it: the grid is deliberately too light to count as a strike. So the
        # number gets a paper-coloured plate under it instead. Only labels the
        # solver has already cleared of every dark stroke ask for one, which
        # is why the plate can never erase a curve.
        self.halo = halo
        self.cut = False
        self.pos = self.box = None
        # v6 (E3): the size a superscript run prints at, in figure units.
        # None is the plain 0.72 em; render raises it to the printed floor.
        self.sup = None
        # v6 (E1): a tick number is PINNED to its tick, not solved. `pin` is a
        # dict (axis 'x' | 'y' | 'o' for the origin, tick point, side, spacing,
        # tick half-length); `glyph` is its ink box from the shipped face's
        # metrics, used only when two numbers are tested against each other.
        self.pin = None
        self.glyph = None
        # C6 r4: a number hide= blanks, solved with the printed ones and then
        # left unprinted (see Figure.place)
        self.phantom = False
        self.plate = None       # C2 r2: what a stroke is cut back to
        # C2 r3: a number set BESIDE its anchor (a value scale's '20' right of
        # its tick) has its box centred on the ray, as an axis number does; on
        # the baseline it stood 0.19 of a square above its tick
        self.centred = False
        # v6 C3 (E24): the stroke (p, q) a value label names; the solver keeps
        # the label nearer it than any other stroke by svgcheck.OWN_FACTOR and
        # render hands it to svgcheck.label_ownership
        self.owner = None
        # v6.5 X2 r1 (SHOULD-9): the segment this label NAMES for the
        # deliverable (lbl-BC, for: BC) without entering the placement's
        # ownership contest -- a side length placed off its side
        self.export_owner = None
        self.export_point = None      # v6.6 S r1: the point a letter names
        self.export_face = None       # v6.6 E r1: the face a number sits in
        # v6.5: the export.Item this label became, so render can print its id
        self.exid = None

    def box_at(self, pos):
        w = max(len(self.text), 1) * _CHAR_W * self.size
        h = self.size
        top = h * 0.78
        if "^" in self.text and _SUP_RE.search(self.text):
            # v6 (E3): the box reserves the RAISED run, as it prints — lifted
            # 0.36 em, at its own size, with its own ascent. A box for plain
            # text let the exponent poke out, and once render raised a small
            # exponent to the 7pt floor it reached a line the solver thought
            # was clear ('y = x^2 − 1' at width=100 was refused as struck).
            s2 = self.sup if self.sup else 0.72 * h
            top = max(top, 0.36 * h + ASC_SUP * s2)
            nsup = sum(len(m.group(1) if m.group(1) is not None
                           else m.group(2))
                       for m in _SUP_RE.finditer(self.text))
            plain = len(_SUP_RE.sub("", self.text))
            w = max(w, (plain * h + nsup * s2) * _CHAR_W)
        return (pos[0] - w / 2.0, pos[1] - top,
                pos[0] + w / 2.0, pos[1] + h * 0.24)


def _stacked_on_number(box, size, N):
    """C6 r6: does a letter box stand in the column of the pinned number N,
    beyond it on the same side of its axis, within STACK_EM of it?"""
    P = N.pin
    if P.get("axis") not in ("x", "y") or not N.box or \
            not svgcheck._NUMTXT.match(N.text.strip()):
        return False
    i, j = (0, 1) if P["axis"] == "x" else (1, 0)   # i along, j across
    at = P["tick"][j]
    nb = N.box
    over = min(box[i + 2], nb[i + 2]) - max(box[i], nb[i])
    if over < 0.5 * min(box[i + 2] - box[i], nb[i + 2] - nb[i]):
        return False
    ns = 1 if (nb[j] + nb[j + 2]) / 2.0 > at else -1
    bs = 1 if (box[j] + box[j + 2]) / 2.0 > at else -1
    if ns != bs:
        return False
    gap = (box[j] - nb[j + 2]) if ns > 0 else (nb[j] - box[j + 2])
    return -1e-9 <= gap < svgcheck.STACK_EM * max(size, N.size) or \
        _boxes_overlap(box, nb, 0.0)


def _as_number(text):
    """The number a mark's text states, or None when it states something
    else. v6.5 X2: `text="12"` on a dimension is a length the JSON can
    export and re-measure; `text="x"` or `text="2a"` is an unknown and stays
    one -- the same rule v6.3 gave angle texts."""
    if text is None:
        return None
    t = str(text).strip().replace("\u2212", "-").replace("\u00b0", "")
    t = t.replace(" ", "")
    if not t:
        return None
    try:
        return float(t)
    except ValueError:
        return None


class Figure(object):
    """Collect primitives, then SOLVE label placement before rendering.

    v6.5: while it collects, it also REGISTERS what it is drawing in
    `self.ex` (an `export.Objects`), so the finished SVG carries a stable id
    on every point, segment, polygon edge, circle, arc, mark, dimension and
    label, and the caller can read back what was drawn with both coordinate
    frames. The id rule lives in `export.py`'s docstring — name-derived
    wherever a name exists, keyed by the object's own geometry where none
    does, never by an index. A builder that draws through this class gets all
    of that without asking; `render` refuses a figure whose export and file
    disagree.

    `min_pt` is the effective point size floor, checked after the final
    scale is known — a 10-unit label in a 300-unit viewBox shown 150px wide
    reaches the reader at 3.75pt, and that is what the audit kept finding."""

    # The tick-number sweep (svgcheck.tick_alignment) has two halves: the
    # WRONG-TICK vote (a number printed on another number's tick) and the
    # DISTANCE half (centred within 0.15 x spacing). Until E1 only the vote ran
    # at render, because the v5 solver let an axis number slide 0.6 em. Tick
    # numbers are now pinned (tick_label), so both halves run at every render.
    # Values: True (both halves), "values" (the vote only), False.
    TICK_SWEEP = True

    def __init__(self, min_pt=MIN_PT, width=None):
        self.parts = []          # (kind, pts, width, dash, extra)
        self.segs = []           # strokes labels must avoid
        self.labels = []
        self.width = width       # display width in px; None = viewBox width
        self.min_pt = min_pt
        self._checks = []        # (name, drawn, given) proportion pairs
        self.tick_sweep = Figure.TICK_SWEEP
        # v6 (E1/E4): what a registered stroke IS, so a pinned tick number
        # knows whether it may cut it (a data line, an edge, a curve, a rim)
        # or must refuse (an axis, a tick mark, a dot). Keyed by segment.
        self._cuttable = set()
        # v6.3: a figure MAY declare that one of its marks is deliberately
        # wrong (a "find the mistake" item). None is every figure that ships
        # today; "find_error:marks" makes the two mark-vs-geometry claims
        # below report instead of raise -- and then REQUIRES one of them to
        # have fired, because a correct drawing beside a find-the-error item
        # gives the answer away (the giveaway rule, L7).
        self.critique = None
        # v6.4: "cabinet45:right" for a solid drawn by solidkit; None for
        # every plane figure, which is every figure that shipped before.
        self.projection = None
        self._crit_seen = []
        self._role = {}
        self._dashed = set()     # C2 r2: dashed lines (a guide may end at a number)
        self.ink_report = None   # E4 bookkeeping of the last render
        self.frame0 = (0.0, 0.0)  # where the last render's coordinates start
        # v6 C3 (E5/E8/E9): marks drawn at their printed floors. Each spec is
        # re-drawn at render once the display scale is known (see _fit_marks).
        self._marks = []
        self._dims = []          # C3 r2: dimension lines, judged at verify
        self._rmarks = []        # C3 r3: (vertex, piece key, piece key)
        self._upt = 1.0 / _PX_TO_PT   # figure units per printed pt, first guess
        # v6.5 (DELIVERABLE_SPEC 1-2): what this figure DREW, with a stable id
        # per object and both coordinate frames. One module (export.py) for
        # every builder, filled by the primitives below, so a new builder
        # cannot forget it. `rotate` is the builder's rotation, reported in
        # the view so a caller can undo it.
        self.ex = export.Objects()
        self.ex.projection = self._projection
        self.rotate = None

    # v6.5 X2: the projection a builder declares (v6.4) is what tells the
    # constraint layer which facts the picture can state, so it is mirrored
    # onto the export. A builder keeps writing `f.projection = ...`.
    _projection = None

    @property
    def projection(self):
        return self._projection

    @projection.setter
    def projection(self, v):
        self._projection = v
        ex = self.__dict__.get("ex")
        if ex is not None:
            ex.projection = v

    # -- primitives ---------------------------------------------------------
    def _reg(self, a, b, role=None):
        self.segs.append((a, b))
        k = _seg_key(a, b)
        if role:
            self._role[k] = role
        else:
            self._cuttable.add(k)

    def poly(self, pts, width=1.5, dash=None, fill="none", record=True):
        # v6.5: the shape and EVERY edge of it are objects (the edge is what a
        # caller highlights: "the side AB"). The polygon keeps the part index
        # (it is one <polygon>); an edge has no element of its own and takes
        # an id anchor.
        if width > 0:
            self.ex.add("polygon", list(pts), part=len(self.parts))
            for k in range(len(pts)):
                # v6.6 E (V2-N4): the edge's id rides a <g> WRAPPING the
                # polygon that draws it (with data-xy for the edge itself),
                # not an empty anchor
                self.ex.add("segment", [pts[k], pts[(k + 1) % len(pts)]],
                            role="edge", meta={"_parts": [len(self.parts)]})
        self.parts.append(("poly", list(pts), width, dash, fill))
        if record:
            for k in range(len(pts)):
                a, b = pts[k], pts[(k + 1) % len(pts)]
                if width > 0:
                    self._reg(a, b)
                else:                   # a shaded region: obstacle, not ink
                    self._reg(a, b, "fill")
        return self

    def line(self, p, q, width=1.2, dash=None, record=True, colour=None,
             role=None, name=None):
        """`role` (v6): "axis" or "tick" for a coordinate system's own
        strokes. v6 stage 1b: a pinned tick number cuts nothing at all -- the
        role now only shapes the refusal's wording."""
        if width > 0 and role in (None, "axis") and \
                svgcheck._dark(colour or INK):
            # a data stroke or an axis; a tick, a mark piece and the grid are
            # ink of their own object (the mark, the axis) and are not
            # exported one line at a time
            self.ex.add("segment", [p, q], role=role or "data",
                        name=name, part=len(self.parts))
        self.parts.append(("line", [p, q], width, dash,
                           ("c", colour or INK, role)))
        if record:
            self._reg(p, q, role)
            if dash and not role:
                self._dashed.add(_seg_key(p, q))
        return self

    def circle(self, c, r, width=1.4, dash=None, fill="none", record=True):
        if width > 0:
            self.ex.add("circle", [c], part=len(self.parts),
                        meta={"r": round(float(r), 3),
                              "_k": "r%.3f" % float(r)})
        self.parts.append(("circle", [c], width, dash, (r, fill)))
        if record:                      # approximate the rim for collisions
            n = 48
            pts = [(c[0] + r * math.cos(2 * math.pi * k / n),
                    c[1] + r * math.sin(2 * math.pi * k / n)) for k in range(n)]
            for k in range(n):
                self._reg(pts[k], pts[(k + 1) % n])
        return self

    def dot(self, p, r=2.6, pad=0.6):
        """A filled point. v6 (E2): a dot is INK. It used to go into `parts`
        only, so the solver treated it as empty paper and put letters on it
        (coord_plane with A printed on B's dot); figkit_plus and euclid each
        patched this locally. Now the core registers a square around the disc
        in `segs`, so every builder's labels walk round it."""
        self.ex.add("point", [p], role="point", part=len(self.parts))
        self.parts.append(("dot", [p], 0, None, r))
        h = r + pad
        box = [(p[0] - h, p[1] - h), (p[0] + h, p[1] - h),
               (p[0] + h, p[1] + h), (p[0] - h, p[1] + h)]
        for k in range(4):
            self._reg(box[k], box[(k + 1) % 4], ("dot", tuple(p), r))
        return self

    def right_angle(self, vertex, to1, to2, size=9, check=True, width=1.1):
        """A right-angle mark at `vertex` between the rays to `to1` and `to2`.

        v6 C3 (E5): the mark is a claim, and the angle is measured before it is
        drawn: 90 +- RIGHT_TOL (0.5) degrees or refused. The SKILL.md example
        `triangle(sides=(3, 4, 5), right_angle="A")` marked a 53.1 degree
        angle, and a coord_plane right= mark sat on 69 degrees; nothing
        measured either. `check=False` exists for FAIL fixtures only.
        The mark is never cut behind a number (role "mark")."""
        ang = _angle_deg(vertex, to1, to2)
        if check and abs(ang - 90.0) > RIGHT_TOL:
            raise AssertionError(
                "figkit: a right-angle mark at (%.1f, %.1f) sits on an angle of "
                "%.1f° -- the mark says 90° (± %.1f°). Put the mark on the "
                "vertex whose angle IS 90°, or draw the figure from numbers that "
                "make this angle right (on unequal axis scales a right angle "
                "does not print square). Never keep a mark the drawing "
                "contradicts." % (vertex[0], vertex[1], ang, RIGHT_TOL))
        u1, u2 = _unit(vertex, to1), _unit(vertex, to2)
        p1 = (vertex[0] + u1[0] * size, vertex[1] + u1[1] * size)
        p3 = (vertex[0] + u2[0] * size, vertex[1] + u2[1] * size)
        p2 = (p1[0] + u2[0] * size, p1[1] + u2[1] * size)
        # P1 r1: `width` -- plane() at the house look passes a printed pen
        # (a fixed 1.1 printed 2.2pt on a 400px coord_plane)
        _ra = self.ex.add("right_angle", [vertex], role="mark",
                          meta={"_k": "%.3f,%.3f"
                                % (math.atan2(u1[1], u1[0]),
                                   math.atan2(u2[1], u2[0])),
                                "_corner": tuple(p2)})
        # v6.5 X2: the mark IS a constraint -- it says these two rays meet at
        # 90 degrees, and the angle was measured above before it was drawn.
        # `marked` is what stops a sheet from marking what it asks the
        # student to prove (DELIVERABLE_SPEC rule 2).
        self.ex.constrain("perpendicular",
                          of=[[tuple(vertex), tuple(to1)],
                              [tuple(vertex), tuple(to2)]],
                          at=tuple(vertex), marked=True, mark_id=_ra,
                          strict=False)
        _ra.meta["_parts"] = [len(self.parts), len(self.parts) + 1]  # V2-N4
        self.line(p1, p2, width, role="mark")
        self.line(p2, p3, width, role="mark")
        self._rmarks.append((tuple(vertex), _seg_key(p1, p2), _seg_key(p2, p3)))
        return self

    def arc(self, vertex, to1, to2, r=18, n=1, width=1.2, step=None):
        """An angle arc at `vertex` between the rays to `to1` and `to2`,
        `n` concentric strokes ("this angle is equal to the other angles
        marked with n strokes"). `r=None` sizes the nest in printed pt (what
        figkit_plus.plane passes at the house look); a number is a radius in
        figure units, as before, and `step=` its spacing (default r/4).

        v6.2 Q1. Three things were wrong with the old rule, all of them
        things the author saw on paper:

        * ADJACENT angles marked equal at one vertex joined into ONE arc.
          arcs=[(A,B,D,1), (A,D,C,1), (A,B,C,3)] drew BAD and DAC at the
          SAME radius, end to end along the shared ray AD, so the page
          showed one unbroken ring across the whole of BAC with the triple
          arc outside it: four arcs on the containing angle and no way to
          read 'BAD = DAC'. Arcs at one vertex whose angles OVERLAP OR TOUCH
          now take separate radii (_arc_nest below). Breaking the ring with
          a gap instead was tried and dropped: svgcheck measures an arc's
          span against its angle TEXT to ANGLE_TOL = 0.6 degrees, and a
          readable 1.5pt gap is 7 degrees at a 12pt radius.
        * The step-out was UNBOUNDED and nothing checked what the moved arc
          crossed. On a -1..3 window the outer ring of BAC landed at r 22.3
          with D's dot 22.63 away and side BC 22.63 away: the arc ran
          through the dot and along the side, mark_geometry and svgcheck
          silent. The nest is now bounded by ARC_INSIDE of the SHORTER ray
          of every angle at the vertex, and the whole nest is compressed
          (the earlier arcs redrawn) to fit, down to the printed floors;
          only then is it refused, with LayoutError so plane()'s ladder
          climbs -- a wider figure is fewer figure units per printed pt, so
          it really does cure this one.
        * The radius was in FIGURE UNITS (18, step 4.5), so it printed
          4.2pt with 2.1pt between the rings at an item width and 14pt with
          7.1pt at 430px. `r=None` (what figkit_plus.plane passes at the
          house look) sizes the nest in printed pt, like every other mark.

        The same angle listed TWICE is merged when both ask for the same
        number of strokes (it used to become a DOUBLE arc, which on the page
        means 'equal to the other double-arc angles' -- a meaning nobody
        wrote), and refused when the two disagree.

        Returns the anchor for the angle's own text: outside the OUTERMOST
        ring of this arc, not the innermost."""
        a1 = math.atan2(to1[1] - vertex[1], to1[0] - vertex[0])
        a2 = math.atan2(to2[1] - vertex[1], to2[0] - vertex[0])
        while a2 - a1 > math.pi:
            a1 += 2 * math.pi
        while a1 - a2 > math.pi:
            a2 += 2 * math.pi
        lo, hi = min(a1, a2), max(a1, a2)
        d1 = math.hypot(to1[0] - vertex[0], to1[1] - vertex[1])
        d2 = math.hypot(to2[0] - vertex[0], to2[1] - vertex[1])
        nests = self.__dict__.setdefault("_arc_nest", {})
        key = (round(vertex[0], 3), round(vertex[1], 3))
        nest = nests.setdefault(key, [])
        # -- the same angle twice ------------------------------------------
        for e in nest:
            for sh in (-2 * math.pi, 0.0, 2 * math.pi):
                if abs(e["lo"] + sh - lo) <= ARC_SAME_TOL and \
                        abs(e["hi"] + sh - hi) <= ARC_SAME_TOL:
                    if e["n"] == n:
                        return self._arc_anchor(e)      # merged: one marking
                    raise AssertionError(
                        "figkit.arc: the angle at (%.3g, %.3g) is marked "
                        "twice over, once with %d stroke(s) and once with "
                        "%d -- on the page the number of strokes IS the "
                        "marking ('equal to the other angles with the same "
                        "number'), so the two readings contradict each "
                        "other and the second would print as a %d-stroke "
                        "arc nobody asked for. Mark it once: drop one of "
                        "the two entries from arcs= (the same angle written "
                        "the other way round, (v, b, a), is the same "
                        "angle), or mark a different angle at that vertex."
                        % (vertex[0], vertex[1], e["n"], n, e["n"] + n))
        nest.append({"lo": lo, "hi": hi, "a1": a1, "a2": a2, "n": n,
                     "width": width, "cap": ARC_INSIDE * max(min(d1, d2), 1e-6),
                     "parts": [], "segs": [], "level": 0, "radii": []})
        self._arc_layout(key, r, step)
        return self._arc_anchor(nest[-1])

    @staticmethod
    def _arc_anchor(e):
        mid = (e["a1"] + e["a2"]) / 2.0
        rr = (max(e["radii"]) if e["radii"] else 0.0) + e["gap"]
        return (e["at"][0] + rr * math.cos(mid), e["at"][1] + rr * math.sin(mid))

    def _arc_layout(self, key, r, step, strict=False):
        """Lay the whole nest at one vertex out again and redraw it.

        Every arc at the vertex is redrawn on every call, because the LAST
        arc is the one that decides how deep the nest is and the nest is
        compressed as a whole. The paths and the registered ink of the
        earlier arcs are overwritten in place (same sampling, same count), so
        nothing is ever left at a stale radius.

        Each entry keeps its OWN base radius when the caller gave one
        (euclid.angles_at_point alternates r=16 and r=24 round a point, and
        that alternation is its own answer to the same defect); entries that
        asked for the house look share the nest's printed base. An entry
        steps out only past the radii of the arcs at that vertex whose angles
        OVERLAP OR TOUCH it."""
        nest = self._arc_nest[key]
        vertex = (key[0], key[1])
        upt = self._upt or 1.0
        self.__dict__.setdefault("_arc_args", {})[key] = (r, step)
        if r is None:
            base, st = ARC_R_PT * upt, ARC_STEP_PT * upt
            grp = ARC_GROUP_PT * upt
            fl_r, fl_s = ARC_R_MIN_PT * upt, ARC_STEP_MIN_PT * upt
            fl_g = ARC_GROUP_MIN_PT * upt
            gap = ARC_LABEL_GAP_PT * upt
            # v6.2 Q1 r1 (arc-step-floor-never-binds): the floors are PRINTED
            # sizes and do not move with the compression scale. They used to
            # be multiplied by k with everything else, so ARC_STEP_MIN_PT was
            # dead (2.6 > 1.7 means max(k*2.6, k*1.7) is always k*2.6) and the
            # only real floor was the k lower bound -- rings bottomed out
            # 1.56pt apart against a declared 1.7pt floor.
            def floors(k):
                return fl_r, fl_s, fl_g
        else:
            base = float(r)
            # 4.5 figure units: the spacing the step-out used before v6.2,
            # kept exactly for the callers that pass a radius in units
            # (euclid.angles_at_point alternates r=16/24 round a point, and
            # svgcheck's angle-text reach is measured against those radii)
            st = float(step) if step is not None else 4.5
            grp = st
            fl_r, fl_s, gap = base * 0.55, st * 0.45, base * 0.67
            fl_g = fl_s
            # a radius given in FIGURE UNITS has no printed floor to keep --
            # unchanged from v6.1, so euclid's nests are byte-for-byte
            def floors(k):
                return fl_r * min(k, 1.0), fl_s * min(k, 1.0), \
                    fl_g * min(k, 1.0)
        for e in nest:
            e.setdefault("r0", None if r is None else base)
            e.setdefault("s0", None if r is None else st)
            e.setdefault("g0", None if r is None else grp)

        def touches(u, v):
            for sh in (-2 * math.pi, 0.0, 2 * math.pi):
                if min(u["hi"], v["hi"] + sh) - max(u["lo"], v["lo"] + sh) \
                        > -1e-4:
                    return True
            return False

        def lay(k):
            """Assign every entry's radii at scale `k`; return the outermost.

            The rings of ONE marking are a tight group (sp) and the next
            marking at that vertex starts a clearly bigger step out (gp), so
            the boundary between two markings is visible and the strokes of
            each can be counted (v6.2 Q1 r1)."""
            f_r, f_s, f_g = floors(k)
            done, top = [], 0.0
            for e in nest:
                b = (e["r0"] if e["r0"] is not None else base) * k
                sp = (e["s0"] if e["s0"] is not None else st) * k
                gp = (e["g0"] if e["g0"] is not None else grp) * k
                b, sp, gp = max(b, f_r), max(sp, f_s), max(gp, f_g)
                used = [x for f, rs in done if touches(e, f) for x in rs]
                rad = [b + i * sp for i in range(e["n"])]
                # only a marking that would land ON another marking steps out
                # (euclid.angles_at_point alternates r=16/24 round a point and
                # its 16s are already clear of the 24s: it keeps them), and
                # when it does step out it steps out by the GROUP gap, so the
                # boundary between the two markings is wider than the gap
                # inside either of them
                if any(abs(x - u) < 0.75 * gp for x in rad for u in used):
                    b = max(b, max(used) + gp)
                    rad = [b + i * sp for i in range(e["n"])]
                e["radii"] = rad
                done.append((e, rad))
                top = max(top, rad[-1])
            return top
        cap = min(e["cap"] for e in nest)
        top = lay(1.0)
        if top > cap:
            # v6.2 Q1 r1: bisect for the LARGEST scale that fits. One shot at
            # k = cap/top was right only while nothing had a floor: with the
            # printed floors honoured (and a group gap that stops shrinking
            # at ARC_GROUP_MIN_PT) the single guess overshot by a fraction of
            # a point and refused a nest that fitted at its floors.
            lo, hi = 0.0, 1.0
            best = None
            for _ in range(14):
                k = (lo + hi) / 2.0
                if lay(k) <= cap:
                    best, lo = k, k
                else:
                    hi = k
            top = lay(best if best is not None else 0.0)
            # v6.2 Q1 r1 (L3-01, the other half): at BUILD time _upt is still
            # the 4/3 first guess, so a nest judged against the cap here was
            # judged at a scale the page never shows -- and plane()'s ladder,
            # whose rungs all build before they render, was refused at every
            # rung at that one wrong scale while size=24 rendered by hand.
            # The verdict belongs to render, where the real scale is known
            # (see _fit_arcs); the layout is kept, compressed, until then.
            if top > cap * 1.001 and strict:
                raise svgcheck.LayoutError(
                    "figkit.arc: %d angle arc(s) are marked at the vertex "
                    "(%.3g, %.3g) and the outermost ring would stand %.1fpt "
                    "out, past the sides and points of the figure itself "
                    "(an arc stays inside its own angle: at most %.1fpt "
                    "here, %g of the shorter ray). Nothing is dropped -- "
                    "give the drawing room so the rings fit: a WIDER figure "
                    "(width=/max_width=) or bigger squares (size=), which "
                    "is fewer figure units per printed pt; or mark fewer "
                    "angles at that one vertex (the containing angle reads "
                    "on its own in a second figure)."
                    % (len(nest), vertex[0], vertex[1], top / upt,
                       cap / upt, ARC_INSIDE))
        for e in nest:
            e["at"] = vertex
            e["gap"] = gap
            self._arc_draw(e)

    def _wrap_ids(self, out, at, at2, drawn):
        """v6.6 E (V2-N4): an object whose id no single element carries --
        a polygon's edge or corner, a tick group, a right-angle mark, a
        multi-stroke arc, a line cut into pieces behind a number -- gets a
        <g id=...> WRAPPING the ink that draws it (with data-xy saying
        exactly where the object is), instead of an empty anchor. Spans
        that would cross another wrapper keep the anchor."""
        order = [i for i in range(len(self.parts))]
        nxt = {}
        for k, i in enumerate(order):
            nxt[i] = at[order[k + 1]] if k + 1 < len(order) else at["end"]

        def span(parts):
            parts = sorted(set(int(i) for i in parts))
            if not parts:
                return None
            if all(i in at2 for i in parts):
                if len(parts) != 1:
                    return None
                return at2[parts[0]]
            if any(i not in at for i in parts):
                return None
            if parts != list(range(parts[0], parts[-1] + 1)):
                return None
            s0, s1 = at[parts[0]], nxt[parts[-1]]
            return (s0, s1) if s1 > s0 else None

        # v6.6 E r1 (E-N4-nesting): a wrapper claims ink that is its object's
        # ALONE. A polygon's edge is drawn by the <polygon> that also draws
        # the other edges and carries its own id, so a wrapper round it named
        # the whole triangle "seg-PQ" and nested the edges inside each other;
        # and a vertex with no ink of its own used to borrow an edge line
        # (g#pt-A > g#pt-B > line#seg-AB). Such objects keep their anchor in
        # the ids layer, and the anchor names the element that inks them
        # (data-ink), so a reader still finds the stroke without a wrapper
        # claiming anything that is not the object's.
        claims = {}
        for it in self.ex.items:
            if not it.id or it.kind == "label":
                continue
            ps = it.meta.get("_parts")
            if ps is None and it.part is not None:
                ps = [it.part]
            for i in (ps or []):
                claims.setdefault(int(i), []).append(it)
        owner = self.ex.by_part()

        wraps = []
        for it in self.ex.items:
            if not it.id or it.id in drawn or it.kind == "label":
                continue
            parts = it.meta.get("_parts")
            if parts is None and it.part is not None:
                parts = [it.part]
            if not parts:
                continue
            shared = [i for i in parts if len(claims.get(int(i), ())) > 1]
            if shared:
                ink = sorted(set(owner[int(i)] for i in shared
                                 if int(i) in owner and owner[int(i)] != it.id))
                if ink:
                    it.meta["_ink"] = ink
                continue
            sp = span(parts)
            if sp is None:
                continue
            wraps.append((sp[0], sp[1], it))
        # outer first at one start; drop any span that crosses a kept one
        wraps.sort(key=lambda w: (w[0], -w[1], w[2].id))
        kept = []
        for a, b, it in wraps:
            if any(a < b2 and a2 < b and not (a2 <= a and b <= b2) and
                   not (a <= a2 and b2 <= b) for a2, b2, _ in kept):
                continue
            kept.append((a, b, it))
        if not kept:
            return out
        opens, closes = {}, {}
        for a, b, it in kept:
            xy = " ".join("%.2f %.2f" % (p[0], p[1]) for p in (it.ends or []))
            opens.setdefault(a, []).append(
                (b, '<g id="%s" data-kind="%s" data-role="%s" data-xy="%s">'
                 % (it.id, it.kind, it.role or "data", xy)))
            closes.setdefault(b, []).append(a)
            drawn.add(it.id)
        new = []
        for k in range(len(out) + 1):
            for _a in sorted(closes.get(k, []), reverse=True):
                new.append("</g>")
            for _b, tag in sorted(opens.get(k, []), key=lambda t: -t[0]):
                new.append(tag)
            if k < len(out):
                new.append(out[k])
        return new

    def _arc_draw(self, e):
        a1, a2, vertex = e["a1"], e["a2"], e["at"]
        if not e.get("exid"):
            # v6.7-noam: ink_xy, the middle of the inner arc's stroke
            e["exid"] = self.ex.add(
                "arc", [vertex], role="mark",
                meta={"_k": "%.3f,%.3f" % (a1, a2), "n": len(e["radii"]),
                      "_corner": lambda e=e: _arc_ink_point(e)})
            # V2-N4: the strokes it draws (filled in below, same list)
            e["exid"].meta["_parts"] = e["parts"]
        fresh = not e["parts"]
        for i, rr in enumerate(e["radii"]):
            pts = [(vertex[0] + rr * math.cos(a1 + (a2 - a1) * k / 18.0),
                    vertex[1] + rr * math.sin(a1 + (a2 - a1) * k / 18.0))
                   for k in range(19)]
            part = ("path", pts, e["width"], None, None)
            # v6 (E2): an arc is ink. Unregistered, the solver put the angle's
            # own number on it and the sweep then refused the figure (the arc
            # test struck '60'; plane arcs refused 351 of 792 sweep cases).
            # Registered, the solver simply re-places the label.
            if fresh:
                e["parts"].append(len(self.parts))
                self.parts.append(part)
                e["segs"].append(len(self.segs))
                for a, b in zip(pts, pts[1:]):
                    self._reg(a, b)
            else:
                self.parts[e["parts"][i]] = part
                j = e["segs"][i]
                for m, (a, b) in enumerate(zip(pts, pts[1:])):
                    self.segs[j + m] = (a, b)
                    self._cuttable.add(_seg_key(a, b))

    # -- marks (v6 C3: E5, E8, E9) ------------------------------------------
    def _add_mark(self, spec):
        # v6.5: a mark is an object too -- a caller highlights "the equal
        # ticks on AB". A marker IS a point and is exported as one, so a
        # plotted point has a single id whether it was drawn as a dot or as
        # an open ring.
        k = spec.get("kind")
        if k == "marker":
            self.ex.add("point", [spec["at"]], role="marker",
                        meta={"_parts": [len(self.parts)]})
        elif k in ("ticks", "parallel"):
            meta = {"n": spec.get("n"), "_k": "n%s" % spec.get("n")}
            if spec.get("real") is not None:
                # v6.5 X2: ticks with real= claim equal TRUE lengths of a
                # projected edge, which the drawing does not show; no
                # drawing-level equal_length is derived from them
                meta["_real"] = float(spec["real"])
            meta["_parts"] = [len(self.parts)]              # V2-N4
            # v6.7-noam (R3-mark-svg_xy-off-ink): the mark's svg_xy is the
            # edge it marks; ink_xy is a point ON its strokes, read from the
            # geometry the mark is finally drawn with (a redraw moves it)
            meta["_corner"] = lambda s=spec: _mark_ink_point(s)
            self.ex.add(k, [spec["p"], spec["q"]], role="mark", meta=meta)
        # an arrowhead is not an object a caller highlights (it is part of
        # the axis or of the dimension it ends) and is not exported
        spec.setdefault("upt", self._upt)
        spec["segs"] = []
        spec["part"] = len(self.parts)
        self.parts.append(("mark", [], spec.get("width", 1.1), None, spec))
        self._marks.append(spec)
        self._draw_mark(spec)
        return self

    def _mark_geom(self, s, upt):
        """(lines, filled shapes, open shapes, rings) of a mark at `upt` figure
        units per printed pt. Floors are printed sizes, so a mark drawn in a
        figure shown small is drawn longer in figure units."""
        k = s["kind"]
        lines, fills, opens, rings = [], [], [], []
        if k in ("ticks", "parallel"):
            p, q, n = s["p"], s["q"], s["n"]
            t = s["t"] if s["t"] is not None else self._auto_t(s, upt)
            ux, uy = _unit(p, q)
            nx, ny = -uy, ux
            c = (p[0] + (q[0] - p[0]) * t, p[1] + (q[1] - p[1]) * t)
            ln = max(s["size"], TICK_LEN_PT * upt)
            if k == "ticks":
                sp = max(3.4, TICK_GAP_PT * upt + s["width"])
                if self._axis_ticks_along(p, q):
                    # stage-1 fix r1 (PR8): on a side lying ALONG an axis the
                    # strokes lean 25 degrees off the perpendicular. Straight
                    # across, half-way between the axis ticks (x = 3 on an
                    # axis numbered every 2) the mark printed as one more,
                    # unnumbered axis tick, not as a mark on side OA
                    a_ = math.radians(ON_AXIS_TICK_LEAN)
                    nx, ny = (nx * math.cos(a_) - ny * math.sin(a_),
                              nx * math.sin(a_) + ny * math.cos(a_))
                for i in range(n):
                    off = (i - (n - 1) / 2.0) * sp
                    b = (c[0] + ux * off, c[1] + uy * off)
                    lines.append(((b[0] - nx * ln / 2, b[1] - ny * ln / 2),
                                  (b[0] + nx * ln / 2, b[1] + ny * ln / 2)))
            else:
                # a chevron pointing p -> q: arms of `ln` at +-35 degrees
                th = math.radians(35.0)
                back = ln * math.cos(th)
                sp = back + TICK_GAP_PT * upt + s["width"]
                for i in range(n):
                    off = (i - (n - 1) / 2.0) * sp + back / 2.0
                    ap = (c[0] + ux * off, c[1] + uy * off)
                    for sg in (1, -1):
                        lines.append((ap, (ap[0] - ux * back + nx * sg * ln * math.sin(th),
                                           ap[1] - uy * back + ny * sg * ln * math.sin(th))))
        elif k == "head":
            tip, (ux, uy) = s["at"], s["dir"]
            hl = max(s["size"], HEAD_PT * upt)
            th = math.radians(s["angle"])
            barbs = []
            for sg in (1, -1):
                hx = -(ux * math.cos(th * sg) - uy * math.sin(th * sg)) * hl
                hy = -(ux * math.sin(th * sg) + uy * math.cos(th * sg)) * hl
                barbs.append((tip[0] + hx, tip[1] + hy))
            if s["style"] == "filled":
                fills.append([tip, barbs[0], barbs[1]])
            else:
                lines += [(tip, barbs[0]), (tip, barbs[1])]
        elif k == "marker":
            p, st = s["at"], s["style"]
            r = max(s["r"] or 0.0, s.get("r_pt", MARKER_R_PT) * upt)
            if st == "filled":
                rings.append((p, r, "fill"))
            elif st == "open":
                rings.append((p, r, "open"))
            elif st == "tri":
                R = r / math.cos(math.radians(30.0))
                opens.append([(p[0] + R * math.cos(math.radians(a)),
                               p[1] + R * math.sin(math.radians(a)))
                              for a in (-90.0, 30.0, 150.0)])
            elif st == "square":
                opens.append([(p[0] - r, p[1] - r), (p[0] + r, p[1] - r),
                              (p[0] + r, p[1] + r), (p[0] - r, p[1] + r)])
            else:                                        # cross
                lines += [((p[0] - r, p[1] - r), (p[0] + r, p[1] + r)),
                          ((p[0] - r, p[1] + r), (p[0] + r, p[1] - r))]
            s["r_drawn"] = r
        return lines, fills, opens, rings

    def _draw_mark(self, s):
        """(Re)draw a mark at its spec's `upt` and register its ink."""
        drop = set(id(x) for x in s["segs"])
        if drop:
            self.segs = [x for x in self.segs if id(x) not in drop]
        lines, fills, opens, rings = self._mark_geom(s, s["upt"])
        s["segs"] = []

        def reg(a, b, role):
            seg = (a, b)
            self.segs.append(seg)
            self._role[_seg_key(a, b)] = role
            s["segs"].append(seg)
        role = "head" if s["kind"] == "head" else "mark"
        if s["kind"] == "marker":
            # C3 r2: a marker's outline is a POINT, not an equality mark: a
            # pinned number it covers slides or crosses its axis like a dot's
            # (a square marker at 2 refused the '2' as "an equality tick")
            role = ("mseg", tuple(s["at"]), s["r_drawn"])
        for a, b in lines:
            reg(a, b, role)
        for pts in fills + opens:
            for i in range(len(pts)):
                reg(pts[i], pts[(i + 1) % len(pts)], role)
        if s["kind"] == "marker":
            p, h = s["at"], s["r_drawn"] + s["pad"]
            box = [(p[0] - h, p[1] - h), (p[0] + h, p[1] - h),
                   (p[0] + h, p[1] + h), (p[0] - h, p[1] + h)]
            for i in range(4):
                reg(box[i], box[(i + 1) % 4], ("dot", tuple(p), s["r_drawn"]))
        flat = [v for ab in lines for v in ab] + [v for P in fills + opens
                                                  for v in P]
        for c, r, _ in rings:
            flat += [(c[0] - r, c[1] - r), (c[0] + r, c[1] + r)]
        s["geom"] = (lines, fills, opens, rings)
        self.parts[s["part"]] = ("mark", flat, s.get("width", 1.1), None, s)

    def _axis_ticks_along(self, p, q):
        """C3 r2: when segment p-q lies along a registered axis, the positions
        (figure units from p, along p -> q) of that axis's tick marks and of
        any axis crossing it, and their spacing; else None."""
        L = _dist(p, q)
        ux, uy = _unit(p, q)

        def off(e):
            return abs((e[0] - p[0]) * uy - (e[1] - p[1]) * ux)
        axis = [(a, b) for a, b in self.segs
                if self._role.get(_seg_key(a, b)) == "axis"]
        if not any(off(a) < 0.6 and off(b) < 0.6 for a, b in axis):
            return None
        pos = []
        for a, b in self.segs:
            role = self._role.get(_seg_key(a, b))
            if role not in ("tick", "axis"):
                continue
            m = _mid(a, b)
            la = _dist(a, b)
            if la <= 1e-9 or off(m) > 0.6 + (la / 2.0 if role == "axis" else 0.0):
                continue
            d = (b[0] - a[0]) / la, (b[1] - a[1]) / la
            if abs(d[0] * ux + d[1] * uy) > 0.2:
                continue                        # along the axis: not a tick
            if role == "axis":
                x = svgcheck._cross_pt(p, q, a, b)
                if not x or not -0.01 <= x[1] <= 1.01:
                    continue
                m = x[2]
            pos.append((m[0] - p[0]) * ux + (m[1] - p[1]) * uy)
        pos = sorted(set(round(v, 3) for v in pos))
        gaps = [b - a for a, b in zip(pos, pos[1:]) if b - a > 1e-6]
        if len(pos) < 2 or not gaps:
            return None
        return pos, min(gaps), L

    def _mark_half(self, s, upt):
        """Half the extent of a ticks / parallel group along its segment."""
        if s["kind"] == "ticks":
            sp = max(3.4, TICK_GAP_PT * upt + s["width"])
            return (s["n"] - 1) / 2.0 * sp + s["width"] / 2.0
        ln = max(s["size"], TICK_LEN_PT * upt)
        back = ln * math.cos(math.radians(35.0))
        sp = back + TICK_GAP_PT * upt + s["width"]
        return (s["n"] - 1) / 2.0 * sp + back / 2.0 + s["width"]

    def _mark_clear(self, s, t, upt, info=None):
        """Is a group at fraction t clear of every axis tick on its axis?
        Its centre at least AXIS_MARK_CLEAR x the tick spacing away, with
        2 x TICK_GAP_PT of paper beyond its outer stroke."""
        info = info or self._axis_ticks_along(s["p"], s["q"])
        if not info:
            return True
        pos, sp, L = info
        c = t * L
        if s["kind"] == "parallel":
            c += max(s["size"], TICK_LEN_PT * upt) * \
                math.cos(math.radians(35.0)) / 2.0      # chevrons lean ahead
        half = self._mark_half(s, upt)
        for v in pos:
            d = abs(v - c)
            if d < AXIS_MARK_CLEAR * sp - 1e-6 or \
                    d - half < 2 * TICK_GAP_PT * upt:
                return False
        return True

    def _auto_t(self, s, upt):
        """C3 r2: t for a group given t=None: 0.5, or on an axis the point
        half-way between two axis ticks nearest the middle that is clear."""
        info = self._axis_ticks_along(s["p"], s["q"])
        if not info or self._mark_clear(s, 0.5, upt, info):
            return 0.5
        pos, sp, L = info
        cands = [(a + b) / 2.0 / L for a, b in zip(pos, pos[1:])]
        cands = [c for c in cands if 0.12 <= c <= 0.88 and
                 self._mark_clear(s, c, upt, info)]
        if not cands:
            return 0.5
        return min(cands, key=lambda c: (abs(c - 0.5), c))

    def _fit_marks(self, scale):
        """Raise every mark to its printed floor at display `scale` (px per
        figure unit). Marks only grow, so the loop in render settles."""
        upt = 1.0 / max(scale * _PX_TO_PT, 1e-9)
        grew = False
        for s in self._marks:
            if upt > s["upt"] * (1 + 1e-6):
                old = s["geom"]
                # 3% headroom: the frame grows with the mark, the scale drops
                s["upt"] = upt * 1.03
                self._draw_mark(s)
                grew = grew or s["geom"] != old
        return grew

    def _fit_arcs(self, scale):
        """Lay every angle-arc nest out again at the display `scale` (px per
        figure unit), the way _fit_marks re-draws the marks.

        v6.2 Q1 r1 (L3-01 / L3-06). Figure._upt is a first guess (4/3, the
        scale of a figure printed 1:1) until the frame is known, and the nest
        was laid out once, at that guess, and never again. Two things broke:
        a nest asked for in printed pt (r=None) printed at the guess's size
        on the raw Figure path -- 19.4pt at width=150 and 55.6pt at width=430
        for an intended 7.5pt -- and, worse, EVERY rung of plane()'s ladder
        laid the same nest at the same wrong scale, so the ladder refused a
        figure ('already tried size=16/18/.../32 ... change the FIGURE') that
        rendered when one of those very sizes was passed by hand.

        Unlike a mark, a nest can SHRINK, so this returns True only while
        something actually moved and render's loop is bounded anyway."""
        nests = self.__dict__.get("_arc_nest") or {}
        if not nests:
            return False
        upt = 1.0 / max(scale * _PX_TO_PT, 1e-9)
        # ... and it runs EVERY time, even when the scale has not moved: this
        # is where the nest is judged against its own rays (strict=True)
        self._upt = upt
        moved = False
        for key in list(nests):
            old = [tuple(e["radii"]) for e in nests[key]]
            r, step = self.__dict__.get("_arc_args", {}).get(key, (18, None))
            self._arc_layout(key, r, step, strict=True)
            moved = moved or old != [tuple(e["radii"]) for e in nests[key]]
        return moved

    def ticks(self, p, q, n=1, size=5, t=None, width=1.1, real=None):
        """Equality ticks: `n` strokes across segment p-q at fraction `t` (the
        middle by default).

        C3 r2: `t=None` (the default) is the middle, except on a segment lying
        along an axis: there the group goes half-way between two of the
        axis's tick marks, nearest the middle. At the middle it stood on the
        axis tick (and its number), and moved a little it read as one more
        tick ('|| |'). A group within AXIS_MARK_CLEAR (0.35) of a tick spacing
        of an axis tick is refused, naming the t that works.

        v6 C3 (E9): drawn at their PRINTED floors -- each at least TICK_LEN_PT
        (5pt) long with TICK_GAP_PT (2.5pt) of paper between two of a group,
        whatever the display scale (h36/h38 printed two ticks that read as
        one). `size` is a minimum in figure units. Never cut behind a number.
        v6 C3 (E5): ticks are a claim. Every segment carrying the same count n
        must measure the same, within EQUAL_TOL (1.5%), or verify() refuses
        the figure. `real` is the segment's true length when the drawing is a
        projection (a receding edge of a solid): then the claim is checked on
        the real lengths."""
        if n < 1 or _dist(p, q) <= 0:
            raise AssertionError("figkit.ticks: need n >= 1 and p != q")
        return self._add_mark(dict(kind="ticks", p=tuple(p), q=tuple(q),
                                   n=int(n), t=None if t is None else float(t),
                                   size=float(size), width=float(width),
                                   real=real))

    def span_ticks(self, p, q, n=1, side=None, offset=10.0,
                   size=5, width=1.1, tick_width=1.1):
        """v6.3 r1: equality ticks on a SPAN BRACKET tied to p and q.

        The defect this exists for: a tick drawn ON a segment names the piece
        of it whose middle the tick stands nearest (that is how a reader
        reads it, and how `svgcheck._marked_length` reads it). Put two points
        on a side symmetrically about its middle -- DE = CF on DC, an
        everyday configuration -- and the side's middle and the middle piece's
        middle are THE SAME PLACE: no position on the side says "the whole
        side" to a reader. Sliding the group off the middle only wins on
        svgcheck's normalised score; on paper the tick still sits between E
        and F and reads as EF (verifier r1, `solved-tick-still-reads-as-the-
        inner-piece`). The other route BRIEF_V63 2 names is this one: tie the
        mark to the ENDPOINTS. A short line parallel to the segment, offset
        `offset` units to the side `side` (a unit vector; the page's left of
        p -> q by default), with witness lines dropping back towards p and q,
        carries the ticks at ITS middle. Its ends ARE p and q, nothing stands
        on it, so both the reader and the checker read the whole segment --
        and `_marked_length` measures |pq|, so the claim compares with a plain
        tick on a clean side of the same length.

        The bracket is one straight stroke, long enough never to be read as
        a mark itself, and parallel to the side it names, so it is never
        collinear with anything the figure already draws."""
        L = _dist(p, q)
        if n < 1 or L <= 0:
            raise AssertionError("figkit.span_ticks: need n >= 1 and p != q")
        if side is None:
            ux, uy = _unit(p, q)
            nx, ny = uy, -ux
        else:
            nx, ny = _unit((0.0, 0.0), side)
        P = (p[0] + nx * offset, p[1] + ny * offset)
        Q = (q[0] + nx * offset, q[1] + ny * offset)
        # r1 note on the SHAPE of the bracket: witness lines back to p and q
        # are the drawing-office look, and they cost more than they are
        # worth here. Cornered, the bracket bends, and two brackets round a
        # polygon read to svgcheck._broken_curves as ONE curve printed in two
        # pieces (their witness ends face each other across a small gap);
        # straight, a witness at a vertex is COLLINEAR with the next side and
        # lost_ink reads the two as a cut stroke. The bare offset line has
        # neither problem: it is straight, it is parallel to the side it
        # names (never collinear with anything), and its ends stand over p
        # and q, which is what ties it to them.
        self.line(P, Q, float(width))
        # v6.4 T2-2 (span-bracket-reads-as-a-stray-segment): ENDS. Looked at
        # on paper, the bare offset line was a second edge of the figure --
        # same weight, parallel to the side, no end anywhere (v63 look/
        # defects/D1_span_bracket_rectangle.png: a reader sees a duplicate
        # AB below the rectangle). A bracket has turned ends, and they are
        # what say "this mark runs from p to q and stops".
        # They are turned TOWARDS the side and leaned OUT by SERIF_LEAN from
        # the perpendicular. A square end at P would lie on the line through
        # p at right angles to p-q, and on a rectangle that IS the next
        # side: the serif and the side then print as one line with a gap in
        # it, which a reader takes for a cut stroke. Leaned, the serif's
        # line misses p altogether and is collinear with nothing the figure
        # draws.
        # v6.4 r1, measured, because the first version of this comment said
        # svgcheck.lost_ink refuses the square-ended drawing: it does NOT --
        # that figure comes back with problems() == [] and lost_ink() == [].
        # The lean is a drawing decision, and selfcheck_v64_t2_r1.py section
        # 2 proves it by MEASURING the collinearity (0.000 units off the
        # side's line at lean 0, 3.20 at the shipped 32 deg) rather than by
        # asking a rule that does not fire.
        ux, uy = _unit(P, Q)
        a = math.radians(SPAN_SERIF_LEAN)
        ca, sa = math.cos(a), math.sin(a)
        ln = min(SPAN_SERIF * float(offset), SPAN_SERIF_MAX)
        if ln > 0:
            # The size floor keeps a serif on a small bracket visible -- but
            # it must never override the offset (v6.4 T2 r1). The serif
            # reaches ln*cos(LEAN) back towards the side, and the bracket
            # stands `offset` away from it, so at offset=3 the 5.0 floor
            # drew a serif that poked 4.2 units through the very segment the
            # bracket names. Nothing in the tree calls it that close
            # (euclid._SPAN_OUT is 11), which is why only an API edge was
            # ever exposed; the floor is clamped under the offset all the
            # same.
            ln = min(max(float(size), ln),
                     SPAN_SERIF_INSET * float(offset) / max(ca, 1e-6))
        for E, sgn in ((P, -1.0), (Q, 1.0)):
            if ln <= 0:
                break          # SPAN_SERIF = 0 draws v6.3's bare line
            dx = (-nx * ca + sgn * ux * sa) * ln
            dy = (-ny * ca + sgn * uy * sa) * ln
            self.line(E, (E[0] + dx, E[1] + dy), float(width))
        self.ticks(P, Q, n=n, size=size, t=0.5, width=tick_width)
        return self

    def parallel_arrows(self, p, q, n=1, t=None, size=6, width=1.2):
        """v6 C3 (E9): `n` chevrons on segment p-q at fraction `t`, pointing
        p -> q -- the mark that says "these segments are parallel" (h43-h45,
        t12). Printed floors as ticks. E5: every segment carrying the same
        count must be parallel within PARALLEL_TOL (0.5 degrees). `t=None`:
        the middle, or half-way between axis ticks on an axis (as ticks)."""
        if n < 1 or _dist(p, q) <= 0:
            raise AssertionError("figkit.parallel_arrows: need n >= 1 and p != q")
        return self._add_mark(dict(kind="parallel", p=tuple(p), q=tuple(q),
                                   n=int(n), t=None if t is None else float(t),
                                   size=float(size), width=float(width)))

    def arrowhead(self, at, dir, size=6, style="open", angle=28.0, width=1.4):
        """v6 C3 (E9): an arrowhead with its tip at `at`, pointing along `dir`
        (a vector, or a point the arrow comes FROM given as ('from', p)).
        Registered ink (role "head": never cut, a pinned number moves or is
        refused). `style` "open" (two barbs) or "filled" (a dark triangle,
        emitted as a <path>, so it never reads as a polygon object).
        Barbs at least HEAD_PT (4pt) printed."""
        if isinstance(dir, tuple) and len(dir) == 2 and dir[0] == "from":
            dx, dy = at[0] - dir[1][0], at[1] - dir[1][1]
        else:
            dx, dy = dir
        L = math.hypot(dx, dy)
        if L <= 0:
            raise AssertionError("figkit.arrowhead: dir has no length")
        if style not in ("open", "filled"):
            raise AssertionError("figkit.arrowhead: style %r (open|filled)" % style)
        return self._add_mark(dict(kind="head", at=tuple(at),
                                   dir=(dx / L, dy / L), size=float(size),
                                   style=style, angle=float(angle),
                                   width=float(width)))

    def marker(self, p, style="filled", r=None, width=1.2, pad=0.6,
               r_pt=None):
        """v6 C3 (E8): a point marker -- "filled", "open" (a white disc with a
        dark rim: a hollow end point, an excluded value), "tri", "square"
        (white with a dark outline) or "cross". A black-and-white page tells
        open from closed by shape, never colour.

        Half its extent is at least MARKER_R_PT (3.5pt) printed, whatever the
        display scale (`r` is a minimum in figure units). Markers are painted
        ABOVE every stroke, so a line through an open end point stops at its
        rim instead of showing through. Registered as a dot: labels walk round
        it and a pinned number never covers it."""
        if style not in MARKER_STYLES:
            raise AssertionError(
                "figkit.marker: style %r -- one of %s" % (style, MARKER_STYLES))
        spec = dict(kind="marker", at=tuple(p), style=style,
                    r=r, width=float(width), pad=float(pad))
        if r_pt is not None:
            # P1: a builder with a house look prints its markers at its own
            # printed radius (plane: open 2.4pt, filled 2.0pt), never under
            # svgcheck.MARKER_R_PT (the readability floor, 2.4pt, for the
            # white-filled kinds)
            spec["r_pt"] = float(r_pt)
        return self._add_mark(spec)

    def bezier(self, p0, c, p1, width=1.4, dash=None, n=24):
        """v6 C3 (E9): a quadratic Bezier p0 -> p1 with control point `c`, or a
        cubic one when `c` is a pair of control points. Flattened to a
        polyline and registered like every curve: labels avoid it, a pinned
        number cuts it and every other piece is kept (E4)."""
        cubic = isinstance(c[0], (tuple, list))
        pts = []
        for i in range(n + 1):
            u = i / float(n)
            if cubic:
                c1, c2 = c
                a, b, cc, d = (1 - u) ** 3, 3 * u * (1 - u) ** 2, \
                    3 * u * u * (1 - u), u ** 3
                pts.append((a * p0[0] + b * c1[0] + cc * c2[0] + d * p1[0],
                            a * p0[1] + b * c1[1] + cc * c2[1] + d * p1[1]))
            else:
                a, b, d = (1 - u) ** 2, 2 * u * (1 - u), u * u
                pts.append((a * p0[0] + b * c[0] + d * p1[0],
                            a * p0[1] + b * c[1] + d * p1[1]))
        self.parts.append(("path", pts, width, dash, "smooth"))
        for a, b in zip(pts, pts[1:]):
            self._reg(a, b)
        return self

    def curve(self, pts, width=1.4, dash=None):
        """v6 stage 1b: a sampled curve, emitted as ONE path element (never a
        chain of separate <line>s, which a reader sees break up when any of
        them is lost). Every piece is registered ink: labels walk around it,
        and since stage 1b a number never cuts it -- the number moves."""
        pts = [tuple(p) for p in pts]
        if len(pts) < 2:
            raise AssertionError(
                "figkit.Figure.curve: a curve needs at least two points "
                "(got %d) -- sample it inside the window, or drop it from "
                "curves=" % len(pts))
        # P3 leftovers r1 (curves-print-as-faceted-polylines, c6 #10): the
        # samples are the CURVE's own points, so the path through them is
        # drawn with CUBIC segments, not chords. 2cos x at width=430 turned
        # 24.8 degrees between neighbouring L segments (about 1pt, 0.36mm,
        # off the true curve) and the F4 parabola printed a flat-bottomed
        # vertex -- what the author compared against Typst/LaTeX.
        self.parts.append(("path", pts, width, dash, "smooth"))
        for a, b in zip(pts, pts[1:]):
            self._reg(a, b)
        return self

    def dimension(self, p, q, offset=10.0, text=None, witness=True, size=11,
                  gap=2.0, head=5.0, style="open", witness_from=None,
                  ref=None):
        # v6.7 r1: with `witness_from` the witness lines END at the shaft
        # (no overshoot), so a short shaft's own number, printed beyond it,
        # meets each witness line at the shaft's end -- the joint -- and is
        # not read against it (a 22px h of a flat cone was refused)
        """v6 C3 (E9): a dimension line for segment p-q, `offset` figure units
        to its LEFT as seen on the page walking from p to q (negative: to its
        right; for p left of q, positive is above), with an arrowhead at each end,
        witness lines from the segment out past the dimension line, and
        `text` written beside its middle, on the far side from the segment.
        The text OWNS the dimension line (E24: nearer it than any other stroke
        by x1.5). Replaces the package-local dims() of z08 and _dim_px of z47.
        Every stroke is registered ink and never cut."""
        L = _dist(p, q)
        if L <= 0:
            raise AssertionError("figkit.dimension: p == q")
        ux, uy = _unit(p, q)
        nx, ny = uy, -ux                 # the page's left of p -> q (y down)
        sg = 1.0 if offset >= 0 else -1.0
        P = (p[0] + nx * offset, p[1] + ny * offset)
        Q = (q[0] + nx * offset, q[1] + ny * offset)
        # v6.5 r1 (X1-01): the object IS the dimension line the reader sees,
        # at P-Q, and it takes the id of the <line> that is about to be drawn
        # (the next part). It used to export p-q -- the segment it MEASURES --
        # so a caller asked to highlight a dimension was sent `offset` units
        # away, onto blank paper, while the drawn line carried no id at all.
        # The measured segment is kept as `ref` and exported as measures_xy,
        # and it is still what names the object: dim-AB.
        # v6.8 (V67F3-short-cylinder-json-undrawn): `ref` = the segment the
        # dimension MEASURES when that is not p-q itself (a short cylinder's
        # h is drawn level with the centres, and measures its generator)
        _ref = [tuple(ref[0]), tuple(ref[1])] if ref is not None else [p, q]
        _dm = self.ex.add("dimension", [P, Q], role="mark", ref=_ref,
                          part=len(self.parts),
                          meta={"_k": "off%.2f" % float(offset)})
        # v6.5 X2: a dimension whose text is a NUMBER states that length.
        _v = _as_number(text)
        if _v is not None:
            self.ex.constrain("length", of=[tuple(_ref[0]), tuple(_ref[1])],
                              value=_v,
                              marked=True, mark_id=_dm, strict=False)
        # v6.7 r1 (V67F-flat-cone-r-label-on-rim): `witness_from` = the two
        # points each witness line STARTS at -- on the normal through p and
        # through q, nearer the shaft than p / q: the last ink the witness
        # meets on its way out (a cone's rim), so a dimension standing well
        # clear of a drawing is still tied to the ink it measures.
        wf = None
        if witness_from is not None:
            wf = []
            for e, w in zip((p, q), witness_from):
                w = tuple(w)
                along = (w[0] - e[0]) * ux + (w[1] - e[1]) * uy
                out_ = ((w[0] - e[0]) * nx + (w[1] - e[1]) * ny) * sg
                if abs(along) > 0.5 or out_ < -0.5 or \
                        out_ > abs(offset) - gap:
                    raise AssertionError(
                        "figkit.dimension: witness_from %r is not on the "
                        "normal through %r between it and the dimension "
                        "line" % (w, e))
                wf.append(w)
            wf = tuple(wf)
        self._dims.append(dict(p=tuple(p), q=tuple(q), offset=float(offset),
                               gap=float(gap), witness=bool(witness),
                               witness_from=wf,
                               ext=0.0 if wf else 2.5))
        self.line(P, Q, 1.0, role="mark")
        self.arrowhead(P, (-ux, -uy), size=head, style=style, width=1.0)
        self.arrowhead(Q, (ux, uy), size=head, style=style, width=1.0)
        if witness and abs(offset) > gap + 0.5:
            ext = 0.0 if wf else 2.5
            for i, e in enumerate((p, q)):
                s0 = wf[i] if wf else e
                self.line((s0[0] + nx * sg * gap, s0[1] + ny * sg * gap),
                          (e[0] + nx * (offset + sg * ext),
                           e[1] + ny * (offset + sg * ext)), 0.7, role="mark")
        if text:
            self.label(_mid(P, Q), text, size=size, prefer=(nx * sg, ny * sg),
                       gap=2.0)
            self.labels[-1].owner = (P, Q)
            # v6.6 S r1: the number on a dimension line is tied to the
            # segment it MEASURES (lbl-AB, for AB), as dim-AB already is --
            # the shaft's own ends are offset points nothing names.
            self.labels[-1].export_owner = (tuple(_ref[0]), tuple(_ref[1]))
        return self

    # v6.8 G1 -------------------------------------------------------------
    _COPY_HALF = 2.5          # px of stroke copied each side of a vertex

    @staticmethod
    def _dash_on(dash, at):
        """Is distance `at` along a stroke (from its dash origin) in a dash?"""
        if not dash:
            return True
        v = [float(x) for x in re.findall(r"\d*\.?\d+", str(dash))]
        v = [x for x in v if x >= 0]
        if len(v) % 2:
            v = v + v
        per = sum(v)
        if per <= 0:
            return True
        t = at % per
        for k, x in enumerate(v):
            if t <= x + 0.05:
                return k % 2 == 0 or t >= x - 0.05
            t -= x
        return True

    def _ink_copies(self, prims, drawn):
        """v6.8 G1 (ids ON INK). An object whose id no element of its own
        carries -- a polygon's edge drawn by the <polygon>, a solid's vertex
        where edges meet, a face whose edges are separate lines -- used to
        ride an EMPTY <g/> anchor in the ids layer. It now gets an element
        of ink: an exact overdraw (same stroke, width, dash phase) of the
        printed stroke(s) at the object, written right after the stroke it
        copies (z-order unchanged) and marked class="ink-copy" so the
        drawing's own sweeps do not count the same ink twice.

        segment / dimension : the printed stroke(s) along it, clipped to it
        polygon            : <g> of its edges' copies
        point              : a short copy of the last stroke through it (a
                             stroke-width dot only where that stroke's dash
                             leaves a gap at the point)
        Anything with no printed stroke there keeps its anchor, and the
        verifier refuses it."""
        out = {}
        if not prims:
            return out

        def fmt(p):
            return "%.2f %.2f" % (p[0], p[1])

        def copy(pr, t0, t1):
            a, b, w, dash, col, off, k = pr
            L = _dist(a, b)
            u = ((b[0] - a[0]) / L, (b[1] - a[1]) / L)
            p = (a[0] + u[0] * t0, a[1] + u[1] * t0)
            q = (a[0] + u[0] * t1, a[1] + u[1] * t1)
            dd = ""
            if dash:
                dd = ' stroke-dasharray="%s"' % dash
                if off + t0 > 1e-3:
                    dd += ' stroke-dashoffset="%.2f"' % (off + t0)
            return ('<line class="ink-copy" x1="%.2f" y1="%.2f" x2="%.2f" '
                    'y2="%.2f" stroke="%s" stroke-width="%.2f"%s/>'
                    % (p[0], p[1], q[0], q[1], col, w, dd))

        def along(e0, e1):
            """(prim, t0, t1) for every printed stroke lying on e0-e1."""
            L = _dist(e0, e1)
            if L < 1e-6:
                return []
            u = ((e1[0] - e0[0]) / L, (e1[1] - e0[1]) / L)
            got = []
            for pr in prims:
                a, b = pr[0], pr[1]
                if any(abs((q[0] - e0[0]) * u[1] - (q[1] - e0[1]) * u[0])
                       > 0.35 for q in (a, b)):
                    continue
                sa = (a[0] - e0[0]) * u[0] + (a[1] - e0[1]) * u[1]
                sb = (b[0] - e0[0]) * u[0] + (b[1] - e0[1]) * u[1]
                lo, hi = max(0.0, min(sa, sb)), min(L, max(sa, sb))
                if hi - lo < 0.3:
                    continue
                # back into the stroke's own parameter (dash phase)
                t0, t1 = abs(lo - sa), abs(hi - sa)
                got.append((pr, min(t0, t1), max(t0, t1)))
            return got

        def place(it, body):
            k = max(pr[6] for pr, _a, _b in body)
            xy = " ".join(fmt(p) for p in it.ends)
            lines = "".join(copy(pr, t0, t1) for pr, t0, t1 in body)
            if it.kind in ("segment", "dimension", "line", "ray") and \
                    len(body) == 1:
                pr, t0, t1 = body[0]
                el = lines.replace('<line class="ink-copy"',
                                   '<line class="ink-copy" id="%s"' % it.id, 1)
                # a <line> carrying the id must run end to end of the object
                a, b = pr[0], pr[1]
                L = _dist(a, b)
                u = ((b[0] - a[0]) / L, (b[1] - a[1]) / L)
                p = (a[0] + u[0] * t0, a[1] + u[1] * t0)
                q = (a[0] + u[0] * t1, a[1] + u[1] * t1)
                e = it.ends
                if (_dist(p, e[0]) < 0.6 and _dist(q, e[-1]) < 0.6) or \
                        (_dist(p, e[-1]) < 0.6 and _dist(q, e[0]) < 0.6):
                    out[k] = out.get(k, "") + el
                    drawn.add(it.id)
                    return
            out[k] = out.get(k, "") + (
                '<g class="ink-copy" id="%s" data-kind="%s" data-role="%s" '
                'data-xy="%s">%s</g>' % (it.id, it.kind, it.role or "data",
                                         xy, lines))
            drawn.add(it.id)

        for it in self.ex.items:
            if not it.id or it.id in drawn or it.kind == "label" or \
                    not it.ends:
                continue
            e = it.ends
            if it.kind in ("segment", "dimension", "line", "ray") and \
                    len(e) >= 2:
                body = along(e[0], e[-1])
                if body:
                    place(it, body)
            elif it.kind == "polygon" and len(e) >= 3:
                body = []
                for a, b in zip(e, e[1:] + e[:1]):
                    body += along(a, b)
                if body:
                    place(it, body)
            elif it.kind == "point":
                p = e[0]
                best = None
                for pr in prims:
                    a, b = pr[0], pr[1]
                    L = _dist(a, b)
                    t = ((p[0] - a[0]) * (b[0] - a[0]) +
                         (p[1] - a[1]) * (b[1] - a[1])) / (L * L)
                    t = max(0.0, min(1.0, t)) * L
                    u = ((b[0] - a[0]) / L, (b[1] - a[1]) / L)
                    q = (a[0] + u[0] * t, a[1] + u[1] * t)
                    if _dist(p, q) > 0.35:
                        continue
                    inked = self._dash_on(pr[3], pr[5] + t)
                    key = (inked, pr[6])
                    if best is None or key > best[0]:
                        best = (key, pr, t)
                if best is None:
                    continue
                (inked, _k), pr, t = best
                L = _dist(pr[0], pr[1])
                h = min(self._COPY_HALF, L)
                body = [(pr, max(0.0, t - h), min(L, t + h))]
                xy = fmt(p)
                extra = "" if inked else (
                    '<circle class="ink-copy" cx="%.2f" cy="%.2f" r="%.2f" '
                    'fill="%s" stroke="none"/>' % (p[0], p[1], pr[2] / 2.0,
                                                   pr[4]))
                out[pr[6]] = out.get(pr[6], "") + (
                    '<g class="ink-copy" id="%s" data-kind="point" '
                    'data-role="%s" data-xy="%s">%s%s</g>'
                    % (it.id, it.role or "data", xy,
                       copy(pr, body[0][1], body[0][2]), extra))
                drawn.add(it.id)
        return out

    def _anchor_ink(self, drawn):
        """v6.7 (E-r2-anchor-claim): an anchor names the ink it stands on.
        A vertex with no ink of its own gets `data-ink` = the drawn strokes
        that END at it; an undrawn hull (a solid's outline, a face) gets the
        drawn strokes that run along its boundary. Only an anchor with no
        stroke there at all is left without one."""
        inked = [it for it in self.ex.items
                 if it.id in drawn and it.kind in ("segment", "polygon",
                                                   "dimension", "path")
                 and it.ends and len(it.ends) >= 2]

        def edges(it):
            e = it.ends
            out = list(zip(e, e[1:]))
            if it.kind == "polygon":
                out.append((e[-1], e[0]))
            return out

        def dseg(p, a, b):
            dx, dy = b[0] - a[0], b[1] - a[1]
            L2 = dx * dx + dy * dy or 1e-12
            t = max(0.0, min(1.0, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy)
                             / L2))
            return math.hypot(p[0] - a[0] - t * dx, p[1] - a[1] - t * dy)

        for it in self.ex.items:
            if not it.id or it.id in drawn or it.kind == "label" or \
                    not it.ends or it.meta.get("_ink"):
                continue
            got = []
            if it.kind == "point":
                p = it.ends[0]
                for o in inked:
                    if any(math.hypot(q[0] - p[0], q[1] - p[1]) < 0.06
                           for q in o.ends):
                        got.append(o.id)
            elif it.kind == "polygon" and len(it.ends) >= 3:
                ring = edges(it)
                for o in inked:
                    if o.kind != "segment":
                        continue
                    a, b = o.ends[0], o.ends[-1]
                    if all(min(dseg(q, u, v) for u, v in ring) < 0.3
                           for q in (a, b, ((a[0] + b[0]) / 2.0,
                                            (a[1] + b[1]) / 2.0))):
                        got.append(o.id)
            if got:
                it.meta["_ink"] = sorted(set(got))

    def _hand_arrows(self):
        """v6.7 (E-r2-arrowheads-data): a dimension line drawn BY HAND -- a
        shaft plus two short barbs at each end, all plain line() calls (z47's
        own _dim_px) -- exported as data: 27 five-pixel "segments" a reader
        of the JSON took for edges of the figure. The export now reads the
        shape itself: a barb (a short stroke from a shaft's END, 15-45 deg
        off it, under a third of it, with its mirror barb on the other side)
        is the mark it is (role 'mark'), and a shaft barbed at BOTH ends is a
        dimension (kind 'dimension', role 'mark'). Nothing is redrawn; only
        what the JSON calls the strokes changes. Idempotent."""
        segs = [it for it in self.ex.items
                if it.kind == "segment" and it.role == "data" and
                len(it.pts) == 2]
        if len(segs) < 3:
            return

        def L(it):
            (a, b) = it.pts
            return math.hypot(b[0] - a[0], b[1] - a[1])

        def near(p, q, tol):
            return abs(p[0] - q[0]) <= tol and abs(p[1] - q[1]) <= tol

        barbs_at = {}
        for sh in segs:
            ls = L(sh)
            if ls <= 0:
                continue
            for e, o in ((sh.pts[0], sh.pts[1]), (sh.pts[1], sh.pts[0])):
                ux, uy = (o[0] - e[0]) / ls, (o[1] - e[1]) / ls
                found = []
                for b in segs:
                    if b is sh:
                        continue
                    lb = L(b)
                    if lb <= 0 or lb > 0.34 * ls or lb > 14.0:
                        continue
                    tol = 0.02 * lb + 1e-6
                    if near(b.pts[0], e, tol):
                        far = b.pts[1]
                    elif near(b.pts[1], e, tol):
                        far = b.pts[0]
                    else:
                        continue
                    vx, vy = (far[0] - e[0]) / lb, (far[1] - e[1]) / lb
                    c = max(-1.0, min(1.0, ux * vx + uy * vy))
                    ang = math.degrees(math.acos(c))
                    if 15.0 <= ang <= 45.0:
                        found.append((b, ux * vy - uy * vx))
                left = [b for b, sgn in found if sgn > 0]
                right = [b for b, sgn in found if sgn < 0]
                if left and right:
                    barbs_at.setdefault(id(sh), []).append(
                        (left[0], right[0]))
        done = set()
        for sh in segs:
            ends = barbs_at.get(id(sh), [])
            if not ends or id(sh) in done:
                continue
            for pair in ends:
                for b in pair:
                    if b.role == "data":
                        b.role = "mark"
                        done.add(id(b))
            if len(ends) == 2 and sh.role == "data":
                sh.kind, sh.role = "dimension", "mark"
                sh.ref = list(sh.pts)

    # -- labels -------------------------------------------------------------
    def label(self, anchor, text, size=12, italic=False, prefer=None,
              kind="value", gap=2.0, sector=None, halo=False, centred=False):
        """Register a label. `prefer` is a unit vector the engine tries
        first; `kind` only tunes how tightly it may sit ("vertex" may hug a
        little closer than a "value", but neither may be struck)."""
        # v6 (E7): a figure prints U+2212, never the ASCII hyphen, whoever
        # typed the text. At 400 dpi '-2' printed as a short dash (t17 had 184
        # such tick labels); converting here makes the right glyph the only one.
        text = svgcheck.true_minus(text)
        L = Label(anchor, text, size, italic, prefer, kind, gap, sector, halo)
        L.centred = bool(centred)
        L.past_head = False
        L.value_text = False          # v6.1: set by a values= caller
        self.labels.append(L)
        return self

    def tick_label(self, tick, text, axis="x", size=11, gap=2.5, side=None,
                   spacing=None, tick_half=3.0):
        """v6 (E1): a tick number PINNED to its tick.

        `tick` is the tick's point ON its axis. An x-axis number is centred
        under it (`side=+1`, the default; -1 puts it above), a y-axis number is
        right-aligned left of it with its ink centred on the tick (`side=-1`,
        the default; +1 puts it to the right). The label solver never moves
        it: in v5 a number could swing 32° and slide 0.6 em, and z09, h19 and
        z01 28ב printed numbers a student read as the neighbouring value.

        What happens when something is in the way (v6 stage 1b, the author's
        rule of 2026-09-16: a data stroke is NEVER cut, broken, shortened or
        hidden by a number, and a number is never dropped -- the NUMBER moves,
        and only the one that is in the way):
          * another pinned number (the x -1 and y -1 at a four-quadrant
            origin) parts from it by the least slide, never more than
            PIN_SLIDE (0.14) x `spacing`;
          * a stroke, a dot, an axis, a tick mark, a mark or an arrowhead: the
            number slides along its axis up to PIN_SLIDE_INK (0.34) x
            `spacing`, then takes the other side of the axis, then steps up to
            PIN_DROP_EM (0.70 em) further out with a slide -- whichever comes
            first. A number that crosses may not land in the other axis's row
            of numbers, where it would read as one of them;
          * the whole ROW crosses when staying would scatter it (more than one
            number in svgcheck.MOVED_SHARE blocked, and the other side suits
            strictly more of them). A row split more than one in four across
            the axis, or one whose numbers have nearly all stood aside, is
            refused: it no longer reads as a row;
          * still blocked: refused, naming what blocks it and a fix that keeps
            the number AND the stroke (for a dot: how many squares to move it,
            and the size= / width= that part it only when that width fits
            the page the builder may print at). Never 'drop the number'."""
        text = svgcheck.true_minus(text)
        L = Label(tick, text, size, False, None, "value", max(gap, 0.0))
        L.pin = dict(axis=axis, tick=tuple(tick), half=float(tick_half),
                     side=side if side is not None else
                     (1 if axis == "x" else -1),
                     spacing=spacing)
        self.labels.append(L)
        return self

    def origin_label(self, at=(0.0, 0.0), text="0", size=11, gap=2.5,
                     tick_half=3.0, spacing=None):
        """v6 (E6): the origin's '0', printed ONCE, in a corner of the
        crossing (below-left by convention; the corner is chosen in
        _place_pins), in the y-axis numbers' column. svgcheck reads a '0' in a
        corner as the origin number of both axes and judges it against both
        numberings.

        `spacing` is the (x, y) tick spacing of the two axes. v6 stage 1b r2:
        the '0' slides like any other number -- along the x-axis, along the
        y-axis, or both -- inside PIN_SLIDE_INK of that spacing. Without a
        slide tier it could only step OUT along the diagonal of its corner,
        which is exactly where a 45 degree stroke through the origin lies: a
        square with both diagonals, and y = x with y = -x, were refused at
        every size, and the only keyword that cleared them was origin=False,
        i.e. deleting the '0'."""
        L = Label(at, svgcheck.true_minus(text), size, False, None, "value",
                  max(gap, 0.0))
        L.pin = dict(axis="o", tick=tuple(at), half=float(tick_half),
                     side=(-1, 1), spacing=spacing)
        self.labels.append(L)
        return self

    def edge_label(self, p, q, text, poly=None, size=12, own=True, **kw):
        """Label an edge from OUTSIDE the shape, when the shape is known.

        v6 C3 (E24): the label OWNS the edge (`own=True`): the solver keeps it
        nearer p-q than any other stroke by svgcheck.OWN_FACTOR (1.5) and
        render checks that on the finished SVG. A length printed between two
        edges reads as the other edge's."""
        prefer = None
        if poly:
            ux, uy = _unit(p, q)
            n1 = (-uy, ux)
            probe = (_mid(p, q)[0] + n1[0] * 6, _mid(p, q)[1] + n1[1] * 6)
            prefer = n1 if not _point_in_poly(probe, poly) else (uy, -ux)
        self.label(_mid(p, q), text, size=size, prefer=prefer, **kw)
        if own:
            self.labels[-1].owner = (tuple(p), tuple(q))
        return self

    def vertex_label(self, v, text, poly=None, size=12, **kw):
        prefer = None
        if poly:
            c = _centroid(poly)
            d = _dist(c, v) or 1.0
            prefer = ((v[0] - c[0]) / d, (v[1] - c[1]) / d)
        return self.label(v, text, size=size, prefer=prefer,
                          kind="vertex", **kw)

    # -- proportions --------------------------------------------------------
    def expect(self, name, drawn, given):
        self._checks.append((name, float(drawn), float(given)))
        return self

    def expect_edges(self, pts, given):
        """`given` maps edge index -> real length. Verifies the drawing is to
        scale: every drawn/given ratio must agree within _TOL."""
        for i, g in given.items():
            a, b = pts[i], pts[(i + 1) % len(pts)]
            self.expect("edge%d" % i, _dist(a, b), g)
        return self

    # -- the placement solver ----------------------------------------------
    _RING = [0, 30, -30, 60, -60, 90, -90, 120, -120, 150, -150, 180]

    def _clear(self, box, placed, seg_pad, kind="value", cross_pad=1.5,
               size=None, owner=None, row=False):
        """`placed` is a list of (box, kind). Two labels of the SAME kind may
        sit as close as the flat pad — consecutive tick numbers on an axis are
        evenly spaced by construction and read fine. A value next to a vertex
        letter is the pair that printed as one cluster in a review, so those
        get the wider pad."""
        grown = (box[0] - seg_pad, box[1] - seg_pad,
                 box[2] + seg_pad, box[3] + seg_pad)
        for a, b in self.segs:
            if _seg_box(a, b, grown):
                return False
        for pl in placed:
            ob, ok = pl[0], pl[1]
            pad = cross_pad if ok != kind else 1.5
            if _boxes_overlap(box, ob, pad):
                return False
            # v6 C3 (E24): on one baseline band, closer than 0.6 em, two labels
            # read as one word ('5 16', '4 Q'): not a clear spot either
            if size is not None and len(pl) > 2 and \
                    not (row and len(pl) > 3 and pl[3]) and \
                    _reading_merge(box, size, ob, pl[2]) is not None:
                return False
            # C6 r6: a point's LETTER stacked on a tick number, on the same
            # side of the axis and in its column, reads with it as a pair
            # ('P' over '-2': P's x read as -2)
            if kind == "vertex" and len(pl) > 4 and pl[4] is not None and \
                    _stacked_on_number(box, size or 12.0, pl[4]):
                return False
        if owner is not None and not self._owns(box, owner):
            return False
        return True

    @staticmethod
    def _pin_rows(pins):
        """E24: the rows of pinned numbers, each (axis, band lo, band hi, span
        lo, span hi): the band across the axis the numbers' boxes fill, and
        their run along it, past the end numbers by half a spacing or 0.6 em,
        whichever is less."""
        rows = []
        for ax in ("x", "y"):
            ps = [L for L in pins if L.pin["axis"] == ax and L.box]
            if len(ps) < 2:
                continue
            i, k0, k1 = (0, 1, 3) if ax == "x" else (1, 0, 2)
            at = sorted(L.pin["tick"][i] for L in ps)
            sp = min([b - a for a, b in zip(at, at[1:]) if b - a > 1e-6] or [0.0])
            # past the end numbers by half a spacing, but never more than
            # 0.6 em: an axis letter above the last y number is not in the row
            over = min(0.5 * sp, MERGE_EM * max(L.size for L in ps))
            b0, b1 = min(L.box[k0] for L in ps), max(L.box[k1] for L in ps)
            s0, s1 = at[0] - over, at[-1] + over
            # C3 r3: the origin's '0' printed in the band, within a spacing
            # and a half of the end number, is the row's first number: a
            # value between it and '2' reads '0 2 2 4 6'
            for O in pins:
                if O.pin["axis"] != "o" or not O.box:
                    continue
                ext = O.box[k1] - O.box[k0]
                if min(O.box[k1], b1) - max(O.box[k0], b0) < 0.25 * ext:
                    continue
                c = (O.box[i] + O.box[i + 2]) / 2.0
                if at[0] - 1.5 * sp <= c < at[0]:
                    s0 = min(s0, c - over)
                elif at[-1] < c <= at[-1] + 1.5 * sp:
                    s1 = max(s1, c + over)
            rows.append((ax, b0, b1, s0, s1))
        return rows

    @staticmethod
    def _num_rows(pins):
        """C3 r2: for each axis with two or more pinned NUMBERS, (axis, across
        coordinate of the axis, band lo, band hi, spacing, value -> position
        along the axis, em). What svgcheck.tick_alignment joins to the row."""
        out = []
        for ax in ("x", "y"):
            ps = [L for L in pins if L.pin["axis"] == ax and L.box and
                  svgcheck._NUMTXT.match(L.text.strip())]
            i, j, k0, k1 = (0, 1, 1, 3) if ax == "x" else (1, 0, 0, 2)
            vp = sorted(set((svgcheck._value(L.text.strip()), L.pin["tick"][i])
                            for L in ps))
            if len(set(v for v, _ in vp)) < 2:
                continue
            n = float(len(vp))
            mv = sum(v for v, _ in vp) / n
            mp = sum(q for _, q in vp) / n
            den = sum((v - mv) ** 2 for v, _ in vp)
            k = sum((v - mv) * (q - mp) for v, q in vp) / den
            at = sorted(L.pin["tick"][i] for L in ps)
            sp = min([b - a for a, b in zip(at, at[1:]) if b - a > 1e-6] or [0.0])
            if sp <= 0:
                continue
            out.append((ax, ps[0].pin["tick"][j], min(L.box[k0] for L in ps),
                        max(L.box[k1] for L in ps), sp,
                        (lambda v, k=k, mv=mv, mp=mp: mp + k * (v - mv)),
                        max(L.size for L in ps), at[0], at[-1],
                        (frozenset(v for v, _ in vp), tuple(at))))
        return out

    def _in_slot(self, box, text, pins, anchor=None):
        """Stage-1 fix r1 (PR2): does a point's letter stand in the regular
        slot of an axis number (where that number stands, or would stand had
        a stroke not moved it aside)? There it reads as the tick's name: F4's
        P of (-1, 0) sat under tick -2 after the '-2' stepped above the axis.
        svgcheck.letter_in_slot reads the same off the file."""
        t = text.strip()
        if not svgcheck._POINT_NAME.match(t) or t in ("x", "y"):
            return False
        area = max((box[2] - box[0]) * (box[3] - box[1]), 1e-9)
        for P in pins:
            pn = P.pin or {}
            hb = pn.get("home")
            if pn.get("axis") not in ("x", "y") or not hb:
                continue
            ov = (max(0.0, min(box[2], hb[2]) - max(box[0], hb[0])) *
                  max(0.0, min(box[3], hb[3]) - max(box[1], hb[1])))
            if ov > 0.1 * area:
                return True
            # ... or, in the row's band, nearer that tick than any point
            tk = pn.get("tick")
            if anchor is None or not tk:
                continue
            pts = [tuple(q[1][0]) for q in self.parts if q[0] == "dot"]
            pts += [tuple(mk["at"]) for mk in self._marks
                    if mk["kind"] == "marker"]
            if not pts or any(_dist(tk, q) < 0.5 for q in pts):
                continue
            c = ((box[0] + box[2]) / 2.0, (box[1] + box[3]) / 2.0)
            # svgcheck reads the text box (1.1 em tall), not the tight glyph
            hh = max((hb[3] - hb[1]) / 2.0, 0.55 * (P.size or 12.0))
            # the band as svgcheck.letter_in_slot reads it, a unit wider
            if pn["axis"] == "x":
                band = abs(c[1] - (hb[1] + hb[3]) / 2.0) <= 2.0 * hh + 2.0
            else:
                band = abs(c[0] - (hb[0] + hb[2]) / 2.0) <= \
                    (hb[2] - hb[0]) / 2.0 + 2.0 * hh + 2.0
            if not band:
                continue
            if _dist(c, tk) < min(_dist(c, q) for q in pts) + 0.5:
                return True
        return False

    @staticmethod
    def _reads_as_tick(box, text, nrows):
        """C3 r2: would svgcheck read this free NUMBER as one of an axis's
        tick numbers slid off its tick? It does when the number stands in the
        numbers' band, or in the same band mirrored across the axis (where a
        crossed tick number goes), within 1.5 spacings of the tick its value
        names but not on it. A length '5' re-placed off the row of '2 4 6 8'
        to just above the axis at 4.5 was refused as 'tick label 5 sits 0.25
        x spacing from its tick' -- the solver and the sweep disagreed. A
        number stacked a line beyond the row, under its span, reads as a
        second row of axis numbers and is kept out too."""
        t = text.strip()
        if not nrows or not svgcheck._NUMTXT.match(t):
            return False
        v = svgcheck._value(t)
        for ax, at, b0, b1, sp, pos, em, s0, s1, vals in nrows:
            k0, k1, c = (1, 3, (box[0] + box[2]) / 2.0) if ax == "x" else \
                (0, 2, (box[1] + box[3]) / 2.0)
            ext = box[k1] - box[k0]
            pad = 0.35 * em
            h = b1 - b0
            side = 1.0 if (b0 + b1) / 2.0 > at else -1.0
            # the row's band, the band a line farther out (a second row under
            # '2 4 6 8'), and the row's band mirrored across the axis
            bands = [(b0, b1, True), (b0 + side * h, b1 + side * h, False),
                     (2 * at - b1, 2 * at - b0, True)]
            for n, (lo, hi, slid_only) in enumerate(bands):
                if min(box[k1], hi + pad) - max(box[k0], lo - pad) < 0.25 * ext:
                    continue
                if n == 1 and s0 - 0.5 * sp <= c <= s1 + 0.5 * sp:
                    return True     # stacked under the row: '4' over '7'
                if n == 2 and v in vals[0] and all(
                        abs(c - q) > (svgcheck.TICK_TOL + 0.05) * sp for q in vals[1]):
                    # C3 r3: across the axis, a number whose tick already
                    # carries it in the row is no slid tick number
                    # (svgcheck._judge_row: 'the tick already carries this
                    # number'); refusing it left a 2x1 triangle's base '2'
                    # no spot below size=60. It must stand off every
                    # numbered tick by more than the sweep's tolerance, or
                    # the sweep votes it onto that tick
                    continue
                d = abs(pos(v) - c)
                if d < svgcheck.SLID_REACH * sp and (
                        not slid_only or d > svgcheck.TICK_TOL * sp * 0.8):
                    return True
        return False

    @staticmethod
    def _continues_row(box, nrows):
        """Stage-1 open issue (C2 flipped-row-meets-axis-letter): an axis
        letter on the band of the x numbers, within a spacing and a quarter
        past the end number, reads as the row's next member ('1 2 3 4 5 6 x',
        '2 4 6 x'). It happened when the row flipped above the axis, into the
        letter's usual corner; the letter now takes the other side."""
        for row in nrows:
            ax, _, b0, b1, sp, _, _, at0, at1 = row[:9]
            if ax != "x":
                continue
            ext = box[3] - box[1]
            if min(box[3], b1) - max(box[1], b0) < 0.25 * ext:
                continue
            c = (box[0] + box[2]) / 2.0
            if at1 < c <= at1 + 1.25 * sp or at0 - 1.25 * sp <= c < at0:
                return True
        return False

    @staticmethod
    def _in_row(box, rows):
        """E24: does `box` stand in a row of axis numbers ('4 Q 6')?"""
        for ax, b0, b1, s0, s1 in rows:
            k0, k1, c = (1, 3, (box[0] + box[2]) / 2.0) if ax == "x" else \
                (0, 2, (box[1] + box[3]) / 2.0)
            ext = box[k1] - box[k0]
            # a quarter of the label in the band is enough: staggered half a
            # line below the row, '2 6 4' still reads as a row of numbers
            if min(box[k1], b1) - max(box[k0], b0) >= 0.25 * ext and s0 <= c <= s1:
                return True
        return False

    def _owns(self, box, owner, factor=None):
        """E24: is `box` nearer the stroke `owner` than any other registered
        stroke by svgcheck.OWN_FACTOR? The same reading as
        svgcheck.label_ownership: a short stroke crossing the owner or standing
        on it (its equality tick, its arrows, an axis tick under an edge on the
        axis), strokes lying along it, and an adjacent stroke whose nearest
        point is the joint (svgcheck._beyond_joint) do not compete; neither does
        a dot's box or a shaded region's edge.""" 
        factor = svgcheck.OWN_FACTOR if factor is None else factor
        p, q = owner
        own = svgcheck._box_seg_dist(box, p, q)
        Lpq = _dist(p, q)
        # C3 r3, as svgcheck.label_ownership: a right-angle mark standing on
        # the owner, and a stroke the owner stands between, do not compete
        mine = set(k for v, k1, k2 in getattr(self, "_rmarks", ())
                   if svgcheck._pt_seg(v, p, q) < 0.8 for k in (k1, k2))
        # v6.7 r2 (V67F2-cold-cylinder-refusal-over-3s): a stroke whose
        # bounding box is already too far from `box` can never win the
        # contest below (its distance is at least the box-to-box gap), so
        # it is passed over before the exact reading. Same answer, faster:
        # the dense rim polylines were most of a cold refusal's time.
        thr = own * factor
        bx0, by0, bx1, by1 = box
        for a, b in self.segs:
            gx = max(0.0, min(a[0], b[0]) - bx1, bx0 - max(a[0], b[0]))
            gy = max(0.0, min(a[1], b[1]) - by1, by0 - max(a[1], b[1]))
            if gx >= thr or gy >= thr or gx * gx + gy * gy >= thr * thr:
                continue
            role = self._role.get(_seg_key(a, b))
            if role == "fill" or isinstance(role, tuple):
                continue
            if svgcheck._along_owner(a, b, p, q):
                continue
            if _dist(a, b) < 0.35 * Lpq and svgcheck._on_owner(a, b, p, q):
                continue                # its own tick, arrow or mark
            # v6.4: a dimension's OWN arrowhead. The docstring above always
            # meant to let "its arrows" off the contest, but `_on_owner`
            # asks for an end standing on the owner's INTERIOR (over 1.0
            # from either end) -- and an arrowhead's tip is exactly AT the
            # end. So a short dimension's barbs competed with its own
            # number, and a 20px shaft could not own the number printed
            # between its two heads (v6.4: a tipped open box, a hexagonal
            # prism on a lateral face, a box measured on three edges). A
            # head is not a stroke a reader could read the number against:
            # it is part of the very object the number names.
            if role == "head" and _dist(a, b) < 0.35 * Lpq and \
                    min(_dist(a, p), _dist(a, q), _dist(b, p),
                        _dist(b, q)) < 0.8:
                continue
            if svgcheck._beyond_joint(box, a, b, p, q):
                continue
            if _seg_key(a, b) in mine or svgcheck._shielded(box, a, b, p, q):
                continue
            if own * factor > svgcheck._box_seg_dist(box, a, b) + 1e-6:
                return False
        return True

    def place(self, scale=1.0):
        """Give every label a position that no stroke crosses and no other
        label overlaps. Search is outward from the anchor, preferred
        direction first, so a figure keeps the layout its author intended
        and only moves what would otherwise be unreadable."""
        placed = []
        pins = [L for L in self.labels if L.pin]
        rows = []
        # v6 stage 1b r4: a number hide= (or origin=False) blanks is solved
        # WITH the printed ones, as a full participant, and only then left
        # unprinted. Solving it afterwards as a phantom against the layout
        # the hide itself produced let the neighbours re-place into its room
        # and the phantom find a spot there, so hide=[('x', -2)] -- the very
        # number a refusal had just named -- turned that refusal green and
        # printed the row '-8 -6 -4 _ 2 4 6 8'. Now the printed numbers stand
        # exactly where they would with the hidden one printed, so hide=
        # renders a figure if and only if the unhidden figure renders.
        hidden = list(getattr(self, "hidden_pins", ()))
        if pins or hidden:
            self._place_pins(pins + hidden)
            placed += [(L.box, L.kind, L.size, True, L) for L in pins]
            rows = self._pin_rows(pins)
        nrows = self._num_rows(pins) if pins else []
        # Most constrained first: long labels and vertex letters (whose
        # anchor sits ON two strokes) get the free space before short values.
        # Axis numbers go first of all: each has one legal spot beside its tick,
        # while a line name or a value can move anywhere.
        order = sorted(range(len(self.labels)),
                       key=lambda i: (not self.labels[i].sector,
                                      self.labels[i].kind != "vertex",
                                      -len(self.labels[i].text)))
        for i in order:
            L = self.labels[i]
            if L.pin:
                continue
            base = L.prefer or (0.0, -1.0)
            a0 = math.degrees(math.atan2(base[1], base[0]))
            seg_pad = 1.0 if L.kind == "vertex" else 2.0
            # Keep a value clear of a vertex letter by the point floor the
            # verifier enforces, expressed in this drawing's units.
            cross_pad = max(1.5, _LABEL_GAP_PT / max(scale * _PX_TO_PT, 1e-6))
            start = L.size * 0.62 + L.gap
            if L.sector:
                # a wide number (1140, -7.5) must clear its own tick mark
                bx = L.box_at((0.0, 0.0))
                ux, uy = base[0], base[1]
                n = math.hypot(ux, uy) or 1.0
                half = (abs(ux) * (bx[2] - bx[0]) + abs(uy) * (bx[3] - bx[1])) / (2 * n)
                start = max(L.size * 0.62, half) + L.gap
            ring = ([d for d in self._RING if abs(d) <= L.sector]
                    if L.sector else self._RING)
            found = None
            # stage-1 fix r1 (PR2): a point's letter held to its reach gets a
            # second, finer ring once the 30-degree one has failed -- between
            # two strokes crossing at the point the free wedge can be narrower
            # than 30 degrees (F4's P between the parabola and the line)
            fine = [d for d in sorted(range(-175, 181, 5), key=abs)
                    if d not in self._RING]
            # A plain dot's letter tries its reach first (both rings) and
            # only then the old open search; a marker's letter never leaves it
            mark_ = L.kind == "vertex" and not L.sector and \
                self._is_marker(L.anchor)
            dot_ = L.kind == "vertex" and not L.sector and not mark_ and \
                self._is_dot(L.anchor)
            # P3 leftovers r2: the third field is the READING distance --
            # held in the FIRST pass only, so a point with no near spot at
            # all still gets its letter (dropped in every later pass).
            passes = [(ring, mark_ or dot_, dot_)]
            if mark_ or dot_:
                # v6.2 Q1: the FINE ring keeps the reading distance too. The
                # 30-degree ring can miss a free spot a 5-degree one finds,
                # and dropping the rule at the first miss is what printed
                # the origin's 'O' 1.9 em out with the axis '0' beside its
                # dot. The no-reach pass below still drops it, so a point
                # with no near spot at any width still gets its letter.
                passes.append((fine, True, dot_))
            # v6.2 Q1 (L1-P3r3-03): the last NEAR pass lets a point's letter
            # stand in the band the axis numbers keep to, when that is the
            # only free paper within reading distance. At the ORIGIN the
            # four near spots are the '0' itself, the x number row, the y
            # number column and the data, so the ring search ran out of near
            # spots and the fallback printed 'O' 1.7-2.9 em out with the
            # axis '0' beside the dot -- the point read as named by the
            # NUMBER. A letter is not a number: it is italic and alphabetic,
            # and _reads_as_tick (the '0'/'O' confusion) still holds, as do
            # _clear and _in_slot, so it never lands ON a number.
            if dot_:
                passes.append((ring, False, False))
            passes = [tuple(p) + (False,) * (4 - len(p)) for p in passes]
            for step, (ring, reach, near_, rows_) in [
                    (st, rg) for rg in passes for st in
                    range(_TICK_STEPS + 1 if L.sector else 22)]:
                if found:
                    break
                r = start + step * max(2.4, L.size * 0.24)
                for da in ring:
                    th = math.radians(a0 + da)
                    if L.sector and abs(r * math.sin(math.radians(da))) > \
                            _TICK_SLIDE * L.size:
                        continue
                    pos = (L.anchor[0] + r * math.cos(th),
                           L.anchor[1] + r * math.sin(th))
                    if L.sector or L.centred:
                        # centre the text box on the ray, not the baseline:
                        # a y-axis number otherwise sits above its own tick
                        pos = (pos[0], pos[1] + 0.27 * L.size)
                    box = L.box_at(pos)
                    if reach and \
                            not self._letter_owns(box, L.anchor, L.size):
                        continue
                    # P3 leftovers r2 (origin-letter-far-from-its-point): in
                    # the FIRST pass a point's letter also stays within
                    # reading distance of its point (svgcheck.LETTER_NEAR_EM
                    # measures the same off the finished file). The fallback
                    # pass drops it, so a figure whose point has no near spot
                    # at all -- a triangle's vertex ON the origin -- still
                    # prints, as it must: no width cures that one. Only a
                    # plain DOT's letter is held to it, since only that
                    # search has the no-reach pass to fall back on.
                    if near_ and not L.sector and \
                            not self._letter_near(box, L.anchor, L.size):
                        continue
                    # P3: even the no-reach fallback keeps the letter on its
                    # point's side of the data ink, and within reach of it
                    if L.kind == "vertex" and not L.sector and \
                            not self._letter_reaches(box, L.anchor, L.size):
                        continue
                    if self._clear(box, placed, seg_pad, L.kind, cross_pad,
                                   size=L.size, owner=L.owner,
                                   row=bool(L.sector)) and \
                            (L.sector or rows_ or
                             not self._in_row(box, rows)) and \
                            (L.sector or not self._reads_as_tick(box, L.text,
                                                                 nrows)) and \
                            (L.sector or not self._in_slot(box, L.text,
                                                           pins + hidden,
                                                           L.anchor)) and \
                            not (L.italic and len(L.text.strip()) == 1 and
                                 not getattr(L, "past_head", False) and
                                 self._continues_row(box, nrows)):
                        found = (pos, box)
                        break
                if found:
                    break
            if not found and L.owner is not None:
                raise AssertionError(
                    "figkit: label %r has no clear spot nearer its own stroke "
                    "than any other by x%.1f -- beside another edge it reads as "
                    "that edge's length. Enlarge the figure (size= / width=), "
                    "give the label a prefer= away from the neighbouring "
                    "stroke, or shorten the text; never drop the label."
                    % (L.text, svgcheck.OWN_FACTOR))
            if not found and L.sector:
                found = self._cut_behind(L, a0, start, placed, cross_pad)
            if not found and L.sector:
                raise AssertionError(
                    "figkit: axis number %r has no clear spot beside its own "
                    "tick at %s -- a stroke, a plotted point, a curve, a "
                    "circle, an axis or another label covers it (v6 stage 1b: "
                    "nothing is ever cut behind a number). Do NOT drop the "
                    "number: move that point's letter, change the range or the "
                    "step, or enlarge the figure."
                    % (L.text, tuple(round(c, 1) for c in L.anchor)))
            if not found:
                # stage-1 fix r1: WHERE a label goes is a layout matter a
                # bigger drawing can cure, so plane()'s ladder gets to try
                # P3 (C7r3-P2): the old text named "enlarge it, widen the
                # range, or shorten the label". Enlarging at the same width
                # gave the drawing this rule now refuses, a one-letter name
                # cannot be shortened, and shortening a label is dropping
                # information (doctrine 4). What cures crowding is ROOM, and
                # the ladder appends the width it measured to render.
                raise svgcheck.LayoutError(
                    "figkit: no clear position for label %r — every candidate "
                    "within %.0f units%s is crossed by a stroke or another "
                    "label, or lies across a stroke from its own point. The "
                    "figure is too crowded: give it room (a wider figure, "
                    "width=/max_width=; bigger squares, size=; a coarser "
                    "numbering, step=2). Never drop, shorten or move a label away "
                    "from its point."
                    % (L.text, r, " on its own side of the axis"
                       if L.sector else ""))
            L.pos, L.box = found
            placed.append((found[1], L.kind, L.size, bool(L.sector)))
        return self

    def check_complete(self, svg):
        """v6 (E4): the finished SVG still draws what was asked for.

        The emitted dark stroke length is measured by svgcheck's own parser,
        not by the renderer, and must reach 99.5% of what the figure's
        primitives draw once the numbers' plates (and a guide's stub between a
        number and its axis) are set aside. That expected length is derived
        again from the primitives and the plates (_expected_ink), never from
        what the renderer booked while it emitted (C2 round 2: a renderer that
        dropped short pieces and booked them as 'stubs' passed its own
        bookkeeping). v5.8 failed this silently twice: a rectangle edge cut
        into pieces and every piece dropped, and a parabola chain that lost
        5.4% of itself beside '-2'. Raises, naming the loss."""
        rep = self.ink_report
        if not rep or rep.get("expected", 0) <= 0:
            return svg
        got = svgcheck.stroke_length(svg)
        want = rep["expected"]
        if got + 1e-6 < _COMPLETE * want:
            raise AssertionError(
                "figkit: the drawing lost %.1f%% of its strokes (%.1f of %.1f "
                "units) outside the numbers' plates -- a polygon edge or a "
                "piece of a curve was deleted, not cut. A cut takes only what a "
                "label covers; every other piece stays in the file, however "
                "short. Report it: this is an engine defect, not the figure's."
                % (100.0 * (1 - got / want), want - got, want))
        return svg

    # -- the cut (E4) --------------------------------------------------------
    @staticmethod
    def _cut_box(L, x0, y0):
        """A cut label's plate in SVG coordinates: a pinned number's ink plate,
        or (a legacy `sector` label) its solver box grown 1.5 x 1.0 units."""
        if L.plate is not None and L.pin:
            b = L.plate
            return (b[0] - x0, b[1] - y0, b[2] - x0, b[3] - y0)
        return (L.box[0] - x0 - 1.5, L.box[1] - y0 - 1.0,
                L.box[2] - x0 + 1.5, L.box[3] - y0 + 1.0)

    def _cut_plan(self, cut_labels, cut_boxes, x0, y0):
        ends, dots = {}, []
        for kind, pts, w, dash, extra in self.parts:
            if kind == "dot":
                dots.append((pts[0][0] - x0, pts[0][1] - y0))
            if kind in ("line", "poly", "path") and not (
                    kind == "line" and extra and extra[0] == "c"
                    and (extra[1] == GRID or len(extra) > 2 and extra[2])):
                for p in pts:
                    k = (round(p[0] - x0, 4), round(p[1] - y0, 4))
                    ends[k] = ends.get(k, 0) + 1
        return dict(labels=cut_labels, boxes=cut_boxes, x0=x0, y0=y0,
                    ends=ends, dots=dots,
                    stub=1.1 * max([L.size for L in cut_labels] or [0]))

    @staticmethod
    def _stub(p, q, a, b, plan):
        """Is piece p-q of the DASHED guide a-b its stub: the last piece before
        the end of the guide on an axis at a pinned number, continued by no
        other stroke there and ending at no plotted point? 'P ---- 8|', never
        '- 8 -'. A solid segment is never stubbed, and neither is a guide that
        ends on a dot (AB with B on the axis keeps its piece up to B)."""
        if _dist(p, q) >= plan["stub"]:
            return False
        for e in (a, b):
            on = (_dist(p, e) < 1e-6) or (_dist(q, e) < 1e-6)
            if not on or plan["ends"].get((round(e[0], 4),
                                           round(e[1], 4)), 0) > 1:
                continue
            if any(_dist(e, d) < 1e-3 for d in plan["dots"]):
                continue
            for L in plan["labels"]:
                P = L.pin
                if not P or P["axis"] not in ("x", "y"):
                    continue
                i = 1 if P["axis"] == "x" else 0
                off = plan["y0"] if i else plan["x0"]
                if abs(e[i] - (P["tick"][i] - off)) > 0.5:
                    continue
                bx = Figure._cut_box(L, plan["x0"], plan["y0"])
                bx = (bx[0] - 1.0, bx[1] - 1.0, bx[2] + 1.0, bx[3] + 1.0)
                far = q if _dist(p, e) < 1e-6 else p
                if bx[0] <= far[0] <= bx[2] and bx[1] <= far[1] <= bx[3]:
                    return True
        return False

    def _expected_ink(self, plan):
        """The dark stroke length the finished SVG must hold, derived again
        from the primitives and the plates alone (C2 round 2)."""
        x0, y0, boxes = plan["x0"], plan["y0"], plan["boxes"]
        T = lambda p: (p[0] - x0, p[1] - y0)

        def outside(a, b, guide=False):
            got = _clip_out(a, b, boxes) if boxes else [(a, b)]
            return sum(_dist(p, q) for p, q in got
                       if not (guide and got != [(a, b)]
                               and self._stub(p, q, a, b, plan)))
        tot = 0.0
        for kind, pts, w, dash, extra in self.parts:
            if kind == "line":
                col = extra[1] if (extra and extra[0] == "c") else INK
                role = extra[2] if (extra and len(extra) > 2) else None
                if col == GRID or not svgcheck._dark(col) or w <= 0:
                    continue
                a, b = T(pts[0]), T(pts[1])
                tot += _dist(a, b) if role else outside(a, b, bool(dash))
            elif kind == "poly" and w > 0:
                tp = [T(p) for p in pts]
                tot += sum(outside(tp[k], tp[(k + 1) % len(tp)])
                           for k in range(len(tp)))
            elif kind == "path":
                tp = [T(p) for p in pts]
                tot += sum(outside(a, b) for a, b in zip(tp, tp[1:]))
            elif kind == "circle" and w > 0:
                c, r = T(pts[0]), extra[0]
                n = max(48, int(2 * math.pi * r / 2.0))
                ring = [(c[0] + r * math.cos(2 * math.pi * k / n),
                         c[1] + r * math.sin(2 * math.pi * k / n))
                        for k in range(n + 1)]
                chord = sum(_dist(a, b) for a, b in zip(ring, ring[1:]))
                kept = sum(outside(a, b) for a, b in zip(ring, ring[1:]))
                tot += 2 * math.pi * r * kept / max(chord, 1e-9)
            elif kind == "mark":
                # v6 C3: a mark is never cut; its strokes print whole
                lines, fills, opens, rings = extra["geom"]
                tot += sum(_dist(a, b) for a, b in lines)
                for P in opens:
                    tot += sum(_dist(P[i], P[(i + 1) % len(P)])
                               for i in range(len(P)))
                for P in fills:
                    tot += sum(_dist(P[i], P[(i + 1) % len(P)])
                               for i in range(len(P)))
                for c, r, how in rings:
                    if how == "open":
                        tot += 2 * math.pi * r
        return tot

    # -- pinned tick numbers (v6, E1/E6) -------------------------------------
    def _pin_geometry(self, L, slide=0.0, side=None, drop=0.0):
        """(pos, box, glyph, plate) of a pinned number slid `slide` along its
        axis and stepped `drop` further from it, on `side` (default: the pin's
        own side).

        `L.gap` is the INK clearance a reader sees between the tick's end and
        the digits. The solver's box is taller and wider than the digits, so
        the box itself may come closer, but never nearer the tick than 0.6
        units. `plate` is what a stroke is cut back to (C2 round 2): the
        digits' ink, padded by svgcheck's NUM_PAD_EM and by _PLATE_EDGE (half
        the widest stroke and a margin), which is exactly what svgcheck.struck
        reads a number as. A text that is not a number keeps the old plate,
        the solver's box grown 1.5 x 1.0 units."""
        P, s = L.pin, L.size
        side = P["side"] if side is None else side
        tx, ty = P["tick"]
        th, g = P["half"], L.gap
        # C6 r5: the gap is the clearance of the INK svgcheck reads -- the
        # digits padded by NUM_PAD_EM, plus half the tick's 1-unit stroke and
        # a margin. With a fixed 2-unit gap the pad outgrew it once the font
        # passed ~18 units, so on a bigger drawing (rule 5's enlarge tier,
        # size=30 on a 17-square window) every y number touched the end of
        # its OWN tick and the file was refused 'struck label 2, 4, 6' --
        # which is why a larger size= could turn a rendering figure back
        # into a refusal. Below that font size nothing moves.
        if _numeric(L.text):
            g = max(g, svgcheck.NUM_PAD_EM * s + 0.9)
        w = max(len(L.text), 1) * _CHAR_W * s          # as box_at measures it
        gw = _glyph_width(L.text, s)
        below = max(0.6, g - (0.78 - _GLYPH_TOP) * s)  # box top under a tick
        above = max(0.6, g - (0.24 - _GLYPH_BOT) * s)
        beside = max(0.6, g - (w - gw) / 2.0)
        if P["axis"] == "x":
            cx = tx + slide
            base = (ty + th + below + drop + 0.78 * s) if side > 0 else \
                (ty - th - above - drop - 0.24 * s)
        elif P["axis"] == "y":
            # the box is centred on the tick, as svgcheck measures a centre
            base = ty + slide + 0.27 * s
            cx = (tx - th - beside - drop - w / 2.0) if side < 0 else \
                (tx + th + beside + drop + w / 2.0)
        else:                                          # the origin's corner
            # in the y numbers' column; vertically as near the x-axis as its
            # 1.4-unit stroke allows (there is no tick at the origin), which
            # keeps it off the '1' above or the row of numbers below.
            # v6 stage 1b r2: `slide` may be a pair here -- the '0' slides
            # along the x-axis, along the y-axis, or both, as rule 4 asks
            sx, sy = side
            sl = slide if isinstance(slide, (tuple, list)) else (slide, 0.0)
            cx = tx + sx * (th + beside + drop + w / 2.0) + sl[0]
            base = ((ty + 0.7 + below + drop + 0.78 * s) if sy > 0 else
                    (ty - 0.7 - above - drop - 0.24 * s)) + sl[1]
        pos = (cx, base)
        bot = _GLYPH_BOT_COMMA if "," in L.text else _GLYPH_BOT
        glyph = (cx - gw / 2.0, base - _GLYPH_TOP * s,
                 cx + gw / 2.0, base + bot * s)
        box = L.box_at(pos)
        if _numeric(L.text):
            pd = svgcheck.NUM_PAD_EM * s + _PLATE_EDGE
            plate = (glyph[0] - pd, glyph[1] - pd, glyph[2] + pd, glyph[3] + pd)
        else:
            plate = (box[0] - 1.5, box[1] - 1.0, box[2] + 1.5, box[3] + 1.0)
        return pos, box, glyph, plate

    def _put_pin(self, L, slide=0.0, side=None, drop=0.0):
        L.pos, L.box, L.glyph, L.plate = self._pin_geometry(L, slide, side,
                                                            drop)

    def _number_on_data(self, L):
        """P3 leftovers r2 (number-leaves-its-row-into-the-drawing): a number
        that has LEFT ITS ROW may not stand nearer a data stroke than the
        tick it names -- there it reads as that stroke's label.

        Rule 4 lets one number slide, and then take the other side of the
        axis. Neither step says it may land on the drawing: the gallery's
        `divide` printed the x '2' 1.5 squares above the row, inside the
        triangle beside the dashed median, and the rebuilt pilot's run/rise
        figure printed its x '2' 6.1px from the dashed RISER and 13.3px from
        its own tick -- 2.2 x nearer the data stroke than the tick it names,
        in the one figure where a number beside the vertical leg reads as
        the rise. The plate rules only keep a number OFF the ink; this says
        whose number it is. Measured from the digits' centre, as a reader
        reads it, and only against DATA strokes (self._cuttable: the axes,
        the tick marks, the marks and the arrowheads are furniture)."""
        if L.pin.get("axis") not in ("x", "y") or not L.glyph \
                or not L.pin.get("tick"):
            return False
        c = ((L.glyph[0] + L.glyph[2]) / 2.0,
             (L.glyph[1] + L.glyph[3]) / 2.0)
        dt = _dist(c, L.pin["tick"])
        if dt <= 1e-9:
            return False
        # the gap from the DIGITS to the stroke, analytically (the solver
        # asks this of thousands of candidates: sampling each segment cost
        # 8 of the 18 seconds a crowded refusal took)
        g = L.glyph
        half = math.hypot(g[2] - g[0], g[3] - g[1]) / 2.0
        near = dt / _ROW_INK + half
        cache = getattr(self, "_datasegs", None)
        if cache is None or cache[0] != len(self.segs):
            cache = (len(self.segs),
                     [(a, b) for a, b in self.segs
                      if _seg_key(a, b) in self._cuttable])
            self._datasegs = cache
        for a, b in cache[1]:
            if min(a[0], b[0]) - near > c[0] or max(a[0], b[0]) + near < c[0] \
                    or min(a[1], b[1]) - near > c[1] \
                    or max(a[1], b[1]) + near < c[1]:
                continue
            d = max(0.0, svgcheck._pt_seg(c, a, b) - half)
            if d <= _ROW_NEAR_EM * L.size and d * _ROW_INK < dt:
                return True
        return False

    def _pin_blockers(self, L):
        """What registered ink a pinned number's PLATE meets: (loss, hard).

        v6 stage 1b: NOTHING may be cut. A data line, a polygon edge, a curve,
        an arc or a circle rim the plate reaches is `hard` too -- the number
        moves, the stroke stays whole. `loss` (the length such strokes have
        under the plate) is kept only as the measure _choose_sides uses to
        decide that a whole ROW of numbers is better off across its axis; a
        dashed guide that ends on the axis at this very tick is not counted.
        The other `hard` entries are as before: an axis, a neighbouring tick
        mark, a dot (tested by its disc against the digits' ink, as svgcheck
        reads it), an arrowhead, a mark, or a stroke added to `segs` by hand.
        The number's own tick mark ends short of the plate by construction."""
        plate, own = L.plate, L.pin["tick"]
        loss, hard, touched = 0.0, [], False
        num = _numeric(L.text)
        if num:
            pd = svgcheck.NUM_PAD_EM * L.size
            ink = (L.glyph[0] - pd, L.glyph[1] - pd,
                   L.glyph[2] + pd, L.glyph[3] + pd)
        else:
            ink = (L.box[0] + 0.3, L.box[1] + 0.3, L.box[2] - 0.3,
                   L.box[3] - 0.3)

        def near(a, b, m):
            # an uncuttable stroke meets the number when its INK edge (half
            # its width, and 0.3 of white) reaches what svgcheck reads
            return _seg_box(a, b, (ink[0] - m, ink[1] - m, ink[2] + m,
                                   ink[3] + m))
        for a, b in self.segs:
            if not _seg_box(a, b, plate):
                continue
            k = _seg_key(a, b)
            role = self._role.get(k)
            if k in self._cuttable:         # (a shaded region's edge may
                touched = True              # also be a drawn polygon's)
                # v6 stage 1b: a dashed guide that ENDS on the axis at this
                # very tick used to be exempt -- it was cut behind the number
                # and the stub between the number and the axis thrown away
                # ('P ---- 8|'). A guide is a data stroke: it stays whole and
                # the number crosses its axis instead.
                under = _dist(a, b) - sum(_dist(p, q) for p, q in
                                          _clip_out(a, b, [plate]))
                loss += under
                # v6 stage 1b: a data stroke is never cut, so ink under the
                # plate BLOCKS the number instead of losing the drawing a piece
                if under > 1e-9 and ("stroke", None, 0.0) not in hard:
                    hard.append(("stroke", None, 0.0))
                continue
            if role == "fill":
                # C6 r6: a shaded region's EDGE is where the shape is. It was
                # no ink at all to a number, so shaded=[P] in place of
                # polys=[P] cleared every refusal and printed the shape as a
                # #eeeeee patch with no outline -- all but invisible in black
                # and white. A number may not stand on the edge of a region
                # any more than on a drawn side; an edge along an axis is
                # judged as the axis is (clear of its ink).
                if _FILL_BLOCKS and near(a, b, 1.0) and \
                        ("stroke", None, 0.0) not in hard:
                    hard.append(("stroke", None, 0.0))
                continue
            if role == "tick" and \
                    abs(_dist(a, own) + _dist(own, b) - _dist(a, b)) < 1e-6:
                continue
            if isinstance(role, tuple) and role[0] == "mseg":
                if near(a, b, 0.5) and ("dot", role[1], role[2]) not in hard:
                    hard.append(("dot", role[1], role[2]))
                continue
            if isinstance(role, tuple) and role[0] == "dot":
                # the DISC against the ink svgcheck reads (a point on the axis
                # at a tick (6, 0) sits clear of its number)
                (cx, cy), r = role[1], role[2]
                if num:
                    pd = svgcheck.NUM_PAD_EM * L.size
                    bx = (L.glyph[0] - pd, L.glyph[1] - pd,
                          L.glyph[2] + pd, L.glyph[3] + pd)
                else:
                    bx = L.box
                nx = min(max(cx, bx[0]), bx[2])
                ny = min(max(cy, bx[1]), bx[3])
                if math.hypot(cx - nx, cy - ny) < r + 0.5 and \
                        ("dot", role[1], r) not in hard:
                    hard.append(("dot", role[1], r))
            elif role == "head":
                if near(a, b, 1.0):
                    hard.append(("head", (a, b), 0.0))
            elif role in ("axis", "tick"):
                if near(a, b, 1.0 if role == "axis" else 0.8):
                    hard.append((role, None, 0.0))
            elif role == "mark":
                # v6 C3: an equality tick, a chevron, a right-angle mark or a
                # dimension line is never cut -- cut, the mark is deleted
                if near(a, b, 1.2) and ("mark", None, 0.0) not in hard:
                    hard.append(("mark", None, 0.0))
            elif near(a, b, 1.2):
                hard.append(("ink", None, 0.0))
        # P2-02: a number standing wholly INSIDE a point's box meets none of
        # the box's sides, so the loop above never asked about the point -- a
        # marker padded in printed pt on a shrunk plane grew a box bigger
        # than the digits, and the x '2' was printed on the open ring of Q
        if num:
            pd = svgcheck.NUM_PAD_EM * L.size
            bx = (L.glyph[0] - pd, L.glyph[1] - pd, L.glyph[2] + pd,
                  L.glyph[3] + pd)
        else:
            bx = L.box
        pts = [(tuple(q[1][0]), q[4]) for q in self.parts if q[0] == "dot"]
        pts += [(tuple(mk["at"]), mk.get("r_drawn") or 0.0)
                for mk in self._marks if mk["kind"] == "marker"]
        for (cx, cy), r in pts:
            nx = min(max(cx, bx[0]), bx[2])
            ny = min(max(cy, bx[1]), bx[3])
            if math.hypot(cx - nx, cy - ny) < r + 0.5 \
                    and not any(h[0] == "dot" and tuple(h[1]) == (cx, cy)
                                for h in hard):
                hard.append(("dot", (cx, cy), r))
        del touched                         # v6 stage 1b: a number never cuts
        L.cut = False
        return loss, hard

    @staticmethod
    def _pin_away(A, B):
        """Unit slide of A along its own axis, away from B's number."""
        ax = A.pin["axis"]
        if ax not in ("x", "y"):
            return 0.0
        i = 0 if ax == "x" else 1
        d = A.pin["tick"][i] - (B.glyph[i] + B.glyph[i + 2]) / 2.0
        if abs(d) < 1e-9:
            d = A.pin["tick"][i]
        return 1.0 if d >= 0 else -1.0

    _CORNERS = [(-1, 1), (-1, -1), (1, -1), (1, 1)]

    def _choose_sides(self, pins):
        """C2 round 2: which side of its axis a whole ROW of numbers goes.

        The row stays where the convention puts it (x numbers below, y numbers
        left) unless the other side of the axis saves the drawing at least
        _FLIP_GAIN tick spacings of ink from the cut, and at least half of
        what it would lose. A rectangle edge along the row of x numbers
        printed as dashes between them ('1_2_3_4_5'), and a line at x = -0.4
        through the y numbers printed dotted; across the axis both draw whole.
        The row flips as one, so it still reads as one row. C2 round 3: the
        gain needed is _FLIP_GAIN spacings OR half an em of stroke, whichever
        is less (numbers two squares apart left '0 - 2 -- 4 -- 6'). And
        uncuttable ink across the axis no longer keeps the row home: a dot
        over one number there is handled by that number (it slides, or
        crosses back alone), and ink nothing handles makes the flipped layout
        unsolvable, which _place_pins answers by putting every row back. In
        round 2 a dot above '3' kept a whole row under a line it cut into
        dashes."""
        for ax in ("x", "y"):
            group = [L for L in pins if L.pin["axis"] == ax]
            if not group:
                continue
            home = group[0].pin["side"]

            def score(side):
                """How many of the row have ink on their regular spot. v6
                stage 1b scores the row by BLOCKED NUMBERS, not by the length
                of stroke a cut would take: nothing is cut any more, so what a
                flip buys is numbers that need not dodge one by one."""
                n = 0
                for L in group:
                    self._put_pin(L, 0.0, side)
                    if self._pin_blockers(L)[1] or \
                            (side != L.pin["side"]
                             and self._in_other_row(L, pins)):
                        n += 1
                return n
            # the row moves as one only when staying would scatter it: more
            # than one number in svgcheck.MOVED_SHARE would have to dodge, and
            # the other side of the axis suits strictly more of them
            n0 = score(home)
            if n0 <= max(1, len(group) // svgcheck.MOVED_SHARE):
                continue
            n1 = score(-home)
            if n1 < n0:
                for L in group:
                    L.pin["side"] = -home

    def _place_pins(self, pins):
        """Pinned numbers first, then the origin's '0'.

        Each row of numbers first takes its side of the axis (_choose_sides).
        The '0' then goes in the corner of that row and column (below-left by
        convention), else above-left, above-right, below-right: the first
        corner where it neither touches nor READS INTO a neighbour (at size=16
        a four-quadrant plane has no room below-left: '0' beside the x-axis
        '−1' printed as '−10') and, C2 round 2, where it cuts no stroke. A
        line through the origin used to lose its crossing to a '0' in a corner
        the line runs through while the opposite corner was free; a corner
        that cuts is taken only when every free corner is refused, and then
        the one that cuts least."""
        homes = [(L, L.pin["side"]) for L in pins]
        self._choose_sides(pins)
        origins = [L for L in pins if L.pin["axis"] == "o"]
        try:
            if not origins:
                return self._solve_pins(pins)
            return self._solve_origin(pins, origins[0])
        except AssertionError:
            if all(L.pin["side"] == s for L, s in homes):
                raise
            for L, s in homes:              # a flipped row that cannot be
                L.pin["side"] = s           # solved: back to the convention
                # stage-1 open issue (C2 stale-flipped-on-fallback): and
                # forget the flip. Left set, the re-solve popped it and turned
                # the number to the far side again, so a number that had
                # crossed for a reason that no longer holds started across
                L.pin.pop("flipped", None)
            if not origins:
                return self._solve_pins(pins)
            return self._solve_origin(pins, origins[0])

    def _solve_origin(self, pins, O):
        # P3 leftovers r2 (L1-P3r2-02): the whole corner search runs FIRST
        # with the strict bound on a '0' pushed along an axis (nearer the
        # crossing than any other tick, _ZERO_SLIDE) and only then with the
        # old corner margin. A figure whose every corner is filled -- the
        # plane with both diagonals drawn -- still prints; one that has a
        # nearer spot now takes it instead of standing 1.06 squares along
        # the x-axis, where it reads as the number of a tick that is not
        # drawn (svgcheck.zero_owner_strict reads that back).
        # r2: the strict bound is OFF by default. Solving the corner with it
        # first did move the '0' in where there was room, but it also moved
        # it in figures that had settled -- and one of them then tripped the
        # confusable '0'/'O' rule, another the crossed-number rules. Set
        # Figure._ZERO_STRICT = True to solve with it (svgcheck's public
        # zero_owner_strict(svg) reads the result back either way).
        self._zero_strict = self._ZERO_STRICT
        return self._solve_origin_at(pins, O)

    def _solve_origin_at(self, pins, O):
        want = tuple(O.pin["side"])
        xs = [L.pin["side"] for L in pins if L.pin["axis"] == "x"]
        ys = [L.pin["side"] for L in pins if L.pin["axis"] == "y"]
        natural = (ys[0] if ys else want[0], xs[0] if xs else want[1])
        order = [natural] + [c for c in [want] + self._CORNERS if c != natural]
        seen, first, best = [], None, None
        for c in order:
            if c in seen:
                continue
            seen.append(c)
            O.pin["side"] = c
            try:
                self._solve_pins(pins)
            except AssertionError as e:
                first = first or e
                continue
            loss = self._pin_blockers(O)[0]
            if loss <= 0.5:
                return None
            if best is None or loss < best[0] - 1e-9:
                best = (loss, c)
        if best is None:
            O.pin["side"] = want
            raise first
        O.pin["side"] = best[1]
        return self._solve_pins(pins)

    def _pin_spots(self, L, s0, m, wide=0.0):
        """Where a blocked number may go, nearest first (v6 stage 1b):
        its own spot; slides along its axis (a); the same across the axis (b);
        then the nearest diagonal spots -- a step out of up to PIN_DROP_EM
        combined with a slide (c), its own side before the other. Each spot is
        (slide, side, drop).

        v6 stage 1b r2: `m` is the slide budget measured in GRID SQUARES and
        `wide` the one measured in TICK SPACINGS (the author's literal
        "~0.35 tick spacing", which with the automatic step of 2 squares is
        twice as far). The square's budget is spent first, and the wider
        slides come only after crossing the axis and stepping out have been
        tried: a number that must stand 0.6 of a square from its tick prints
        better across the axis than beside it, and the row-mates on their own
        ticks are what a reader compares it with.

        v6 stage 1b r2: the origin's '0' slides too. `m` is then a PAIR (the
        budget along x and along y) and a slide is a pair: along the x-axis,
        along the y-axis, and the two together. Its corner is its side, so it
        cannot 'cross the axis'; without a slide its only tier was a step out
        along the diagonal of its corner -- which is where a 45 degree stroke
        through the origin runs, so both diagonals of a square blocked all
        four corners for good."""
        home = L.pin["side"]
        on_axis = L.pin["axis"] in ("x", "y")
        if not on_axis:
            mx, my = m if isinstance(m, (tuple, list)) else (m or 0.0, 0.0)
            wx, wy = wide if isinstance(wide, (tuple, list)) else (mx, my)
            slides = [(0.0, 0.0)]
            for hix, hiy in ((mx, my), (max(wx, mx), max(wy, my))):
                for k in range(1, 9):
                    for sg in (1, -1):
                        if hix > 0:
                            slides.append((sg * k / 8.0 * hix, 0.0))
                        if hiy > 0:
                            slides.append((0.0, sg * k / 8.0 * hiy))
                        if hix > 0 and hiy > 0:
                            for sg2 in (1, -1):
                                slides.append((sg * k / 8.0 * hix,
                                               sg2 * k / 8.0 * hiy))
            seen, uniq = set(), []
            for s in slides:
                k = (round(s[0], 6), round(s[1], 6))
                if k not in seen:
                    seen.add(k)
                    uniq.append(s)
            slides = uniq
            sides = [home]
            drops = [0.0] + [k / 4.0 * PIN_DROP_EM * L.size for k in (1, 2, 3, 4)]
            return [(s, side, d) for d in drops for side in sides
                    for s in slides]
        def ladder(lo, hi):
            got = []
            if hi <= lo + 1e-9:
                return got
            for k in range(1, 9):
                for sg in (1, -1):
                    v = max(-hi, min(hi, s0 + sg * (lo + k / 8.0 * (hi - lo))))
                    if abs(v) > lo + 1e-9 and \
                            all(abs(v - u) > 1e-9 for u in got):
                        got.append(v)
            return got
        slides = [0.0] + ladder(0.0, m)
        sides = [home, -home]
        drops = [0.0] + [k / 4.0 * PIN_DROP_EM * L.size for k in (1, 2, 3, 4)]
        out = []
        for d in drops:
            for side in sides:
                for s in slides:
                    out.append((s, side, d))
        for s in ladder(m, wide):           # the wider slides, last
            for d in drops:
                for side in sides:
                    out.append((s, side, d))
        return out

    @staticmethod
    def _row_reads(pins, ax):
        """Does the row of `ax` numbers still read as ONE row?

        v6 stage 1b r2. The old test only counted the numbers standing across
        the axis and allowed one in four, so a steep line printed a y row of
        10, 8, 6 on the right, 4 and 2 on the left and -2 .. -10 on the right
        again: the two that crossed were NEIGHBOURS, and a reader sees a
        second row of numbers, not two numbers dodging. A lone number that
        steps across (rule 4) reads as what it is, however many of them there
        are along the row, so the test is now both: at most one in four, and
        no two of them side by side. A row that parts into two blocks and
        changes side once is a row as well. C6 r6: two side by side are
        allowed (a shape dipping under the axis blocks a pair); three are
        not."""
        grp = [L for L in pins if L.pin["axis"] == ax and L.pin.get("tick")]
        if len(grp) < 3:
            return True
        i = 0 if ax == "x" else 1
        order = sorted(grp, key=lambda L: L.pin["tick"][i])
        sides = [L.pin["side"] for L in order]
        few = 1 if sides.count(1) <= sides.count(-1) else -1
        if sides.count(few) <= 1:
            return True
        changes = sum(1 for a, b in zip(sides, sides[1:]) if a != b)
        # P3 leftovers r2 (number-row-straddles-its-axis): a block holding
        # more than one number in ROW_CROSS_SHARE is a second ROW, and
        # svgcheck.row_straddles(svg) reports it. Held HERE it re-placed
        # rows across the shipped figures -- planes that had settled were
        # solved differently and eight checks of stage 1b went red -- so
        # the builder keeps the rule it shipped with (a row that changes
        # side once is a row) and the sweep is what tells the author.
        if changes <= 1:                     # two blocks, one change
            return True
        if sides.count(few) > max(1, len(grp) // 4):
            return False
        # C6 r6: a PAIR of neighbours may cross together. A V-shaped figure
        # that dips just under the x-axis blocks two neighbouring numbers,
        # and each of them crossing is exactly what rule 4 asks for; refusing
        # it refused 28 of 156 such triangles in the side column (all 28
        # clean with the pair allowed: '-8 -6' below, '-4 -2' above, '2 .. 8'
        # below) and pushed the author to a shaded region with no outline or
        # to a sketch with no numbers. A run of THREE is a second row.
        run = best = 0
        for sd in sides:
            run = run + 1 if sd == few else 0
            best = max(best, run)
        return best <= 2

    @staticmethod
    def _zero_out_of_corner(L):
        """v6 stage 1b r2: has the origin's '0' been slid so far from the
        crossing that it no longer READS as the crossing's zero?

        svgcheck (_zero_corner) takes a '0' for the origin's while its nearest
        box corner is within one em of the crossing, plus the step-aside
        allowance. Past that it is judged as an ordinary tick number and
        refused as slid -- which is exactly what a reader would do with it. So
        the '0' may dodge, but only inside that reach."""
        if L.pin["axis"] != "o" or not L.box:
            return False
        cx, cy = L.pin["tick"]
        b = L.box
        dx = min(abs(b[0] - cx), abs(b[2] - cx))
        dy = min(abs(b[1] - cy), abs(b[3] - cy))
        sp = L.pin.get("spacing") or 0.0
        sx, sy = sp if isinstance(sp, (tuple, list)) else (sp, sp)
        reach = L.size + svgcheck.MOVED_TOL * min(sx or 0.0, sy or 0.0) - 1.0
        return max(dx, dy) > reach

    @staticmethod
    def _pin_budget(L, frac, square=True):
        """How far a number may slide along its axis: `frac` of its tick
        spacing, but never more than `frac` of a GRID SQUARE.

        v6 stage 1b r2. The budget used to be `frac` x the number PITCH, and
        with the automatic step of 2 squares that let a dodging number stand
        0.68 of a square from its tick -- a full glyph height at print size,
        its own tick left bare and its row-mates exactly on theirs. svgcheck
        measures the same offset against the tick spacing it reads off the
        file, which on a figure whose grid it measures is ONE square, so the
        solver also produced layouts its own gate then refused. The square is
        the unit both now use. For the origin's '0' the budget is the (x, y)
        pair, since it slides in either direction."""
        sp, sq = L.pin.get("spacing"), (L.pin.get("square") if square else None)
        if L.pin["axis"] == "o":
            if not sp:
                return (0.0, 0.0)
            sx, sy = sp if isinstance(sp, (tuple, list)) else (sp, sp)
            lim = (lambda v: frac * (min(v, sq) if sq else v) if v else 0.0)
            return (lim(sx), lim(sy))
        if not sp:
            return 0.0
        return frac * (min(sp, sq) if sq else sp)

    def _in_other_row(self, L, pins):
        """v6 stage 1b (the author's rule 4): a number that has CROSSED its
        axis must not land in the other axis's row of numbers -- there it
        reads as one of them, which svgcheck.reading_merge refuses off the
        finished file. Measured against that row's whole band, not only
        against its nearest member: an x number sent above the axis at x = -1
        sits in the y numbers' column even when the nearest y number is an em
        away."""
        ax = L.pin["axis"]
        if ax not in ("x", "y"):
            return False
        i = 0 if ax == "x" else 1          # across this number's own axis
        others = [o for o in pins if o.pin["axis"] not in (ax, "o")
                  and o is not L and o.glyph]
        if not others or not L.glyph:
            return False
        pad = 0.35 * L.size
        lo = min(o.glyph[i] for o in others) - pad
        hi = max(o.glyph[i + 2] for o in others) + pad
        return L.glyph[i + 2] > lo and L.glyph[i] < hi

    _OWN_MARGIN = 0.80      # under svgcheck.OWN_RATIO (0.90), as PIN_SLIDE is under TICK_TOL

    _ZERO_MARGIN = 1.2      # under svgcheck.ZERO_RATIO (1.25)
    # P3 leftovers r1: draw a sampled curve with CUBIC segments. The
    # switch exists so a test can print the faceted drawing this fix
    # ended and measure it.
    _SMOOTH_CURVES = True
    # P3 leftovers r2: smoothing may never move the printed line off the
    # geometry the figure was GIVEN. `curves=` also takes a LIST OF POINTS,
    # and there the polyline IS the data: a Catmull-Rom hand that bows it
    # draws something the author did not ask for (and the lost-ink gate
    # then refuses the figure at every width). Two bounds:
    #   * a vertex whose turn is sharper than _CORNER_DEG is a CORNER --
    #     both hands there are zero, so the drawn line keeps the corner;
    #   * every hand's component ACROSS its chord is capped, so a cubic
    #     can never stand further than ~_SMOOTH_DEV viewBox units off the
    #     chord it replaces (a dense sample's own hands are far shorter
    #     than that, so a real curve still prints smooth).
    _CORNER_DEG = 20.0
    _SMOOTH_DEV = 0.30
    _ZERO_SQ = 0.80         # under svgcheck.ZERO_SQ (0.85): a corner '0'
                            # stands within this many SQUARES of the crossing
                            # across at least one axis ...
    _ZERO_ALONG = 0.45      # ... or, pushed ALONG an axis, this close to it
    _ZERO_FAR = 1.15        # and never further out than this
    # P3 leftovers r2 (L1-P3r2-02): and, whatever the squares say, a '0'
    # never walks past the midpoint between the crossing and the next
    # TICK. On a step-2 axis _ZERO_FAR alone let it stand 1.06 squares
    # along the x-axis -- nearer the tick at x = -2 (1.00 square) than the
    # crossing it belongs to (1.12), which is rule 4 read backwards.
    _ZERO_STRICT = False     # v6.2 Q1: see _solve_origin
    _ZERO_SLIDE = 1.02      # r2: the margin for a '0' pushed ALONG an
                            # axis, where the corner diagonal does not
                            # excuse it (svgcheck.ZERO_SLIDE 1.05)
                            # (under svgcheck.ZERO_ALONG 0.50 / ZERO_FAR 1.20)

    def _zero_owns(self, L, pins):
        """O3-01 / P2-01: the origin's '0' stands nearer the crossing than
        _ZERO_MARGIN x its distance to any other tick of either axis (the
        numbers' pins and the blanked ones carry every tick near the origin).
        svgcheck._zero_owner reads the same off the finished file.

        P3 (L1-ZERO-STEP2): the tick comparison alone only bites at step 1.
        At the default step of 2 the ticks are two squares apart, so a '0'
        that walked a full square out -- onto the grid point (-1, -1), under
        the point at x=-1, or into the x-number row where it reads as the
        number of -1 -- measured a ratio of 1.06 and passed. A corner is a
        corner: the '0' stays within _ZERO_SQ of the crossing in SQUARES,
        whatever the numbering step."""
        if L.pin["axis"] != "o" or not L.glyph:
            return True
        c = ((L.glyph[0] + L.glyph[2]) / 2.0, (L.glyph[1] + L.glyph[3]) / 2.0)
        own = L.pin["tick"]
        dm = math.hypot(c[0] - own[0], c[1] - own[1])
        ticks = []
        xs, ys = [own[0]], [own[1]]
        for o in list(pins) + list(getattr(self, "hidden_pins", ())):
            if o is L or not o.pin or not o.pin.get("tick") or \
                    o.pin["axis"] not in ("x", "y"):
                continue
            t = o.pin["tick"]
            ticks.append(t)
            (xs if o.pin["axis"] == "x" else ys).append(
                t[0] if o.pin["axis"] == "x" else t[1])
        # an axis with fewer than three tick marks is read off its GRID (as
        # svgcheck._axes does): every square is then a tick position, and a
        # '0' standing on the unnumbered square reads as its number
        sq = L.pin.get("square")
        if sq:
            dx, dy = abs(c[0] - own[0]) / sq, abs(c[1] - own[1]) / sq
            # a '0' pushed ALONG one axis still reads as the crossing's (the
            # plane whose two diagonals fill every corner has nowhere else);
            # a '0' a square out along BOTH is the grid point beside the
            # origin, where it reads as a coordinate or as the number of the
            # unnumbered tick under it
            if not (max(dx, dy) <= self._ZERO_SQ or
                    (min(dx, dy) <= self._ZERO_ALONG and
                     max(dx, dy) <= self._ZERO_FAR)):
                return False
        if sq:
            for k in (-2, -1, 1, 2):
                x, y = own[0] + k * sq, own[1] + k * sq
                if len(xs) < 4 and min(xs) - 1e-6 <= x <= max(xs) + 1e-6:
                    ticks.append((x, own[1]))
                if len(ys) < 4 and min(ys) - 1e-6 <= y <= max(ys) + 1e-6:
                    ticks.append((own[0], y))
        # r2 (L1-P3r2-02): a '0' pushed ALONG an axis is held to the
        # literal rule 4 -- nearer the crossing than any other tick --
        # while a corner '0' on the diagonal keeps the old margin
        lim = self._ZERO_MARGIN
        if sq and getattr(self, "_zero_strict", True):
            dx, dy = abs(c[0] - own[0]) / sq, abs(c[1] - own[1]) / sq
            if min(dx, dy) <= self._ZERO_ALONG:
                lim = self._ZERO_SLIDE
        for t in ticks:
            if math.hypot(t[0] - own[0], t[1] - own[1]) < 0.5:
                continue
            if dm >= lim * math.hypot(c[0] - t[0], c[1] - t[1]):
                return False
        return True

    def _is_dot(self, p):
        """Stage-1 fix r1 (PR2): a plotted dot's letter is held to the same
        reach as a marker's -- F4's P, pushed out of the tick slot, walked two
        squares up the curve and named nothing in particular."""
        return any(q[0] == "dot" and _dist(tuple(q[1][0]), tuple(p)) < 0.5
                   for q in self.parts)

    def _is_marker(self, p):
        return any(mk["kind"] == "marker" and _dist(tuple(mk["at"]), tuple(p)) < 0.5
                   for mk in self._marks)

    def _letter_owns(self, box, anchor, size=None):
        """P2-02 follow-up: a point's letter stands nearer ITS point than any
        other plotted point or polygon vertex. Padded in printed pt, the open
        marker of Q on a +-7 plane lost its near spots to the x '2', and the
        ring search walked the letter 1.3 squares out, beside the triangle's
        corner (3, -2), where it named the corner."""
        def d(q):
            dx = max(box[0] - q[0], 0.0, q[0] - box[2])
            dy = max(box[1] - q[1], 0.0, q[1] - box[3])
            return math.hypot(dx, dy)
        own = d(anchor)
        # ... and within an em of it: farther, it names nothing in particular
        if size:
            # measured from the point's own ink (a marker's rim and its pad);
            # P2-02: the letter keeps MARKER_PAD_PT of printed paper from the
            # rim (the marker's own box pad is figure units, and is what
            # every other label -- a legacy tick number -- is placed against)
            rim = 0.0
            for mk in self._marks:
                if mk["kind"] == "marker" and \
                        _dist(tuple(mk["at"]), tuple(anchor)) < 0.5:
                    edge = (mk.get("r_drawn") or 0.0) + mk.get("width", 1.2) / 2.0
                    if own < edge + MARKER_PAD_PT * mk["upt"] - 1e-6:
                        return False
                    rim = max(rim, edge + MARKER_PAD_PT * mk["upt"])
            for q in self.parts:
                if q[0] == "dot" and _dist(tuple(q[1][0]), tuple(anchor)) < 0.5:
                    rim = max(rim, q[4] + 0.6)
            if own - rim > LETTER_REACH_EM * size:
                return False
        pts = [tuple(q[1][0]) for q in self.parts if q[0] == "dot"]
        pts += [tuple(mk["at"]) for mk in self._marks if mk["kind"] == "marker"]
        pts += [tuple(v) for q in self.parts if q[0] == "poly" for v in q[1]]
        for q in pts:
            if math.hypot(q[0] - anchor[0], q[1] - anchor[1]) < 0.5:
                continue
            if d(q) < own - 1e-6:
                return False
        return True

    def _data_segments(self):
        """Every DATA stroke as segments (polygon edges, solid and dashed
        lines, curve polylines, a circle's rim) -- the axis, its ticks and
        the light grid left out. P3: used to keep a point's letter on the
        same side of the ink as its point."""
        segs = []
        for k, pts, w, dash, extra in self.parts:
            if not w or w <= 0 or len(pts) < 2 and k != "circle":
                continue
            if k == "poly":
                segs += [(tuple(pts[i]), tuple(pts[(i + 1) % len(pts)]))
                         for i in range(len(pts))]
            elif k == "path":
                segs += [(tuple(pts[i]), tuple(pts[i + 1]))
                         for i in range(len(pts) - 1)]
            elif k == "line":
                if extra and extra[0] == "c" and (extra[2] or
                                                  not svgcheck._dark(extra[1])):
                    continue            # an axis, a tick, the grid
                segs.append((tuple(pts[0]), tuple(pts[-1])))
            elif k == "circle":
                c, r = tuple(pts[0]), extra[0]
                n = 32
                rim = [(c[0] + r * math.cos(2 * math.pi * i / n),
                        c[1] + r * math.sin(2 * math.pi * i / n))
                       for i in range(n)]
                segs += [(rim[i], rim[(i + 1) % n]) for i in range(n)]
        return segs

    _LETTER_FAR_EM = 3.0    # the no-reach fallback's own cap
    # P3 leftovers r2 (origin-letter-far-from-its-point): 3 em is a cap on
    # NONSENSE, not a reading rule. Across the rebuilt pilot the origin's
    # 'O' printed up to 2.27 squares (1.92 em) from the origin dot while
    # the axis '0' sat beside that dot, so the dot's nearest text was a
    # NUMBER and the letter read as naming something else -- 24 of 209
    # plane figures put 'O' a full square or more from its point. Measured
    # over the same corpus, every letter that was NOT the origin's stood
    # within 1.26 em of its point, and the engine's own answer for those
    # same origins at a wider width is 0.5-0.6 em. svgcheck.LETTER_NEAR_EM
    # (1.4) re-reads it off the finished file.
    # Set to 1.3 to hold a point's letter to the READING distance inside
    # the ring search; OFF (99) by default -- see _ROW_NEAR_EM below, the
    # same story: it re-placed letters across figures that had settled and
    # eight shipped checks went red. svgcheck.letter_side(svg) reports the
    # distance either way.
    _LETTER_NEAR_EM = 99.0

    def _letter_near(self, box, anchor, size=None):
        """P3 leftovers r2: is the letter within READING distance of its
        point (_LETTER_NEAR_EM)? Across the rebuilt pilot the origin's 'O'
        printed up to 2.27 squares (1.92 em) from the origin dot while the
        axis '0' sat beside that dot, so the dot's nearest text was a
        number; every letter of that corpus that was not the origin's stood
        within 1.26 em."""
        if not size:
            return True
        c = ((box[0] + box[2]) / 2.0, (box[1] + box[3]) / 2.0)
        return math.hypot(c[0] - anchor[0], c[1] - anchor[1]) <= \
            self._LETTER_NEAR_EM * size

    def _letter_reaches(self, box, anchor, size=None):
        """P3 (L2C7r3-04 / C7r3-P2): the ring search has a second pass that
        drops the reach rule when the first finds no spot. It let 'Q' print
        on the far side of the triangle's base, where it names the point the
        base crosses, and 'O' stand 1.5 squares from the origin with the
        axis '0' between letter and point. Whatever pass places a letter, it
        may not be parted from its point by DATA INK, and it never wanders
        beyond _LETTER_FAR_EM of its point: a letter nobody can trace back to
        a dot names nothing."""
        c = ((box[0] + box[2]) / 2.0, (box[1] + box[3]) / 2.0)
        d = math.hypot(c[0] - anchor[0], c[1] - anchor[1])
        if size and d > self._LETTER_FAR_EM * size:
            return False
        # P3 leftovers r2 (origin-letter-far-from-its-point): the READING
        # distance (_LETTER_NEAR_EM, svgcheck.LETTER_NEAR_EM) is judged on
        # the finished file instead of here. Held during the ring search it
        # refused figure after figure whose point sits beside its axis --
        # the tick number is nearer such a point than any free spot for the
        # letter -- while the same figures render once the ladder gives them
        # a bigger size or width, which is what the refusal now asks for.
        graze = 0.6 * (size or 12.0)
        for a, b in self._data_segments():
            # a stroke that ends AT the point, or grazes it (a thin
            # triangle's far edge past its middle vertex), parts nothing
            if _dist(a, anchor) < graze or _dist(b, anchor) < graze:
                continue
            if svgcheck._pt_seg(anchor, a, b) < graze:
                continue
            if _segs_cross(anchor, c, a, b):
                return False
        return True

    def _in_shape(self, L):
        """C7P2-04: does the number's glyph centre lie inside a drawn closed
        polygon (a stroked poly part, not a light fill)?"""
        if not L.glyph:
            return False
        c = ((L.glyph[0] + L.glyph[2]) / 2.0, (L.glyph[1] + L.glyph[3]) / 2.0)
        return any(_point_in_poly(c, P) for P in self._closed_shapes())

    def _closed_shapes(self):
        """Stage-1 fix r1: every drawn closed shape, solid or dashed: a poly,
        a path back at its start (a closed curve), a loop of line segments
        (solid= edges). svgcheck.closed_shapes reads the same off the file."""
        out, segs = [], []
        for k, pts, w, dash, extra in self.parts:
            if not w or w <= 0 or len(pts) < 2:
                continue
            if k == "poly" and len(pts) >= 3:
                out.append([tuple(p) for p in pts])
            elif k == "path" and len(pts) >= 4 and _dist(pts[0], pts[-1]) < 1e-3:
                out.append([tuple(p) for p in pts])
            elif k == "line" and not (extra and extra[0] == "c" and
                                      (extra[1] == GRID or
                                       not svgcheck._dark(extra[1]))):
                segs.append((tuple(pts[0]), tuple(pts[-1])))
        out += [list(r) for r in svgcheck._loops(segs)]
        return out

    def _owns_tick(self, L, pins):
        """C6 r6 (the author's rule 4): does a number that stepped aside still
        stand clearly nearest its OWN tick -- nearer it than _OWN_MARGIN x the
        distance to any tick of the OTHER axis?

        The slide budget only bounds how far a number moves ALONG its axis. A
        diagonal step out (a slide, then up to PIN_DROP_EM away) could put an
        x '-1' nearer the y tick 1 than its own, or a y '-1' right under the
        x '-1': the reader then sees one value numbered twice and another
        not at all, and svgcheck (_foreign_tick) refuses the file. Such a
        spot is not free; the next one is tried."""
        if L.pin["axis"] not in ("x", "y") or not L.glyph:
            return True
        c = ((L.glyph[0] + L.glyph[2]) / 2.0, (L.glyph[1] + L.glyph[3]) / 2.0)
        own = L.pin["tick"]
        dm = math.hypot(c[0] - own[0], c[1] - own[1])
        for o in pins:
            # only the OTHER axis's ticks: along its own axis the slide
            # budget already keeps a number nearest its own tick
            if o is L or not o.pin.get("tick") or \
                    o.pin["axis"] in (L.pin["axis"], "o"):
                continue
            t = o.pin["tick"]
            if math.hypot(t[0] - own[0], t[1] - own[1]) < 0.5:
                continue
            if dm >= self._OWN_MARGIN * math.hypot(c[0] - t[0], c[1] - t[1]):
                return False
        return True

    def _owns_tick(self, L, pins):
        """C6 r6 (the author's rule 4): does a number that stepped aside still
        stand clearly nearest its OWN tick -- nearer it than _OWN_MARGIN x the
        distance to any tick of the OTHER axis?

        The slide budget only bounds how far a number moves ALONG its axis. A
        diagonal step out (a slide, then up to PIN_DROP_EM away) could put an
        x '-1' nearer the y tick 1 than its own, or a y '-1' right under the
        x '-1': the reader then sees one value numbered twice and another
        not at all, and svgcheck (_foreign_tick) refuses the file. Such a
        spot is not free; the next one is tried."""
        if L.pin["axis"] not in ("x", "y") or not L.glyph:
            return True
        c = ((L.glyph[0] + L.glyph[2]) / 2.0, (L.glyph[1] + L.glyph[3]) / 2.0)
        own = L.pin["tick"]
        dm = math.hypot(c[0] - own[0], c[1] - own[1])
        for o in pins:
            # only the OTHER axis's ticks: along its own axis the slide
            # budget already keeps a number nearest its own tick
            if o is L or not o.pin.get("tick") or \
                    o.pin["axis"] in (L.pin["axis"], "o"):
                continue
            t = o.pin["tick"]
            if math.hypot(t[0] - own[0], t[1] - own[1]) < 0.5:
                continue
            if dm >= self._OWN_MARGIN * math.hypot(c[0] - t[0], c[1] - t[1]):
                return False
        return True

    def _marker_discs(self):
        """((cx, cy), r) of every registered point marker (a dot, or the rim
        of an open/square/tri marker)."""
        out = []
        for role in self._role.values():
            if isinstance(role, tuple) and role[0] in ("dot", "mseg") \
                    and isinstance(role[1], (tuple, list)) and len(role[1]) == 2:
                out.append((tuple(role[1]), role[2] or 0.0))
        return out

    def _solve_pins(self, pins):
        slide = dict((id(L), 0.0) for L in pins)
        drop = dict((id(L), 0.0) for L in pins)
        # step 1 (number against number) parts a PAIR along one axis, so the
        # origin's '0' takes no slide there: it parts by taking another corner
        most = dict((id(L), self._pin_budget(L, PIN_SLIDE)
                     if L.pin["axis"] in ("x", "y") else 0.0) for L in pins)
        # a number a stroke, a dot or an arrowhead reaches may slide further
        # than one merely parting from its neighbour: nothing is cut for it
        ink_slide = dict((id(L), self._pin_budget(L, PIN_SLIDE_INK))
                         for L in pins)
        # ... and the wider slide the author's words allow (PIN_SLIDE_INK of
        # the TICK SPACING), tried only after crossing and stepping out
        wide_slide = dict((id(L), self._pin_budget(L, PIN_SLIDE_INK,
                                                   square=False))
                          for L in pins)

        def put(L, s, side=None, d=0.0):
            self._put_pin(L, s, side, d)

        def clash(A, B, pad=_PIN_PAD):
            if _boxes_overlap(A.glyph, B.glyph, pad):
                return True
            # stage-1 fix r1 (PR11): two numbers' TEXT boxes may not overlap
            # (svgcheck.number_boxes): the y '1' stood on the origin's '0'
            a, b = A.box, B.box
            if a and b and _numeric(A.text) and _numeric(B.text) and \
                    (A.pin["axis"] != B.pin["axis"] or "o" in
                     (A.pin["axis"], B.pin["axis"])) and \
                    min(a[2], b[2]) - max(a[0], b[0]) >= \
                    0.85 * min(a[2] - a[0], b[2] - b[0]) and \
                    min(a[3], b[3]) - max(a[1], b[1]) > 0.3:
                return True
            # C7P-01: two numbers side by side on one band keep a gap of
            # svgcheck.ROW_GAP_EM between their text boxes (as svgcheck reads
            # them). The glyph pad alone let a slid '-2' print 0.6pt from
            # '-1', and the row read '-2-1'.
            a, b = A.box, B.box
            if a and b and _numeric(A.text) and _numeric(B.text):
                over = min(a[3], b[3]) - max(a[1], b[1])
                if over >= 0.5 * min(a[3] - a[1], b[3] - b[1]) and \
                        max(a[0] - b[2], b[0] - a[2]) < \
                        svgcheck.ROW_GAP_EM * max(A.size, B.size) - 1e-6:
                    return True
            if "o" not in (A.pin["axis"], B.pin["axis"]):
                return False
            # the origin's '0' must not read INTO a number on its band:
            # '−1' and '0' a digit's width apart print as '−10'
            a, b = A.glyph, B.glyph
            over = min(a[3], b[3]) - max(a[1], b[1])
            if over <= 0.3 * min(a[3] - a[1], b[3] - b[1]):
                return False
            return max(a[0] - b[2], b[0] - a[2]) < _MERGE_EM * max(A.size,
                                                                   B.size)

        for L in pins:
            if L.pin.pop("flipped", None):  # a re-solve starts from the row
                L.pin["side"] = -L.pin["side"]
            put(L, 0.0)
            # stage-1 fix r1 (PR2): the number's own SLOT, kept even when the
            # number steps aside -- a letter placed there reads as its name
            if L.glyph or L.box:
                L.pin["home"] = tuple(L.glyph or L.box)
        # 1. number against number. Each of the pair may slide away from the
        # other along its own axis; the least slide that parts them wins.
        steps = [k / 8.0 for k in range(9)]
        for _ in range(4):
            moved = False
            for i in range(len(pins)):
                for j in range(i + 1, len(pins)):
                    A, B = pins[i], pins[j]
                    if not clash(A, B):
                        continue
                    dA, dB = self._pin_away(A, B), self._pin_away(B, A)
                    sa0, sb0 = slide[id(A)], slide[id(B)]
                    best = None
                    for fa in steps:
                        for fb in steps:
                            sa = max(-most[id(A)], min(most[id(A)], sa0 + dA *
                                                       fa * most[id(A)]))
                            sb = max(-most[id(B)], min(most[id(B)], sb0 + dB *
                                                       fb * most[id(B)]))
                            put(A, sa)
                            put(B, sb)
                            if clash(A, B):
                                continue
                            key = (max(fa, fb), fa + fb)
                            if best is None or key < best[0]:
                                best = (key, sa, sb)
                    if best:
                        slide[id(A)], slide[id(B)] = best[1], best[2]
                        moved = True
                    put(A, slide[id(A)])
                    put(B, slide[id(B)])
            if not moved:
                break
        # 2. number against ink (v6 stage 1b). NOTHING is cut behind a
        # number, so the NUMBER is what moves, and as little as it can:
        #   a) it slides along its own axis, up to PIN_SLIDE_INK x the tick
        #      spacing -- under half a spacing, so its centre stays nearer its
        #      own tick than any other, which svgcheck re-reads off the file;
        #   b) failing that, the other side of its axis, at the same slides;
        #   c) failing that, the nearest diagonal spots: a step of up to
        #      PIN_DROP_EM away from the axis together with a slide, on its
        #      own side first and then across.
        # Everything else on the axis stays in the regular position. A row
        # still reads as a row, so when more than a quarter of it (at least
        # one) would stand alone across the axis, none does.
        alone = {}
        for L in pins:
            put(L, slide[id(L)], L.pin["side"], drop[id(L)])
            loss, hard = self._pin_blockers(L)
            if not hard:
                continue
            home = L.pin["side"]
            m = ink_slide[id(L)]
            best, crossed, onink = None, None, None
            for s, side, d in self._pin_spots(L, slide[id(L)], m,
                                              wide_slide[id(L)]):
                L.pin["side"] = side
                put(L, s, side, d)
                if self._zero_out_of_corner(L) or \
                        not self._zero_owns(L, pins):
                    continue        # too far out to read as the crossing's 0
                lo2, h2 = self._pin_blockers(L)
                if h2:
                    if side != home and all(h[0] in ("dot", "head")
                                            for h in h2):
                        crossed = crossed or h2
                    continue
                if (side != home or d or s != slide[id(L)]) and \
                        not self._owns_tick(L, pins):
                    crossed = crossed or [("reads", None, 0.0)]
                    continue
                # r2: ... and it did not land ON the drawing (rule 4 moves a
                # number a little; it never hands it to another object). A
                # spot that does is kept as a LAST RESORT only: refusing it
                # outright dead-ended figures whose every crossed spot has
                # some stroke near it, while svgcheck refuses a finished
                # file only when the stroke is ROW_INK x nearer than the
                # tick (_ROW_INK here is the stricter builder's bar).
                if side != home and self._number_on_data(L):
                    onink = onink or (s, side, d)
                    continue
                pad = _PIN_PAD if side == home else L.size
                if any(clash(L, o, _PIN_PAD if (side == home or o.pin["axis"]
                                                == L.pin["axis"]) else pad)
                       for o in pins if o is not L):
                    if side != home:
                        crossed = crossed or [("reads", None, 0.0)]
                    continue
                if side != home and self._in_shape(L):
                    # C7P2-04: across its axis a number standing INSIDE a
                    # drawn shape reads as that shape's length (the y '2'
                    # between edges AC and BC); it is not a free spot
                    crossed = crossed or [("reads", None, 0.0)]
                    continue
                if side != home and self._in_other_row(L, pins):
                    crossed = crossed or [("reads", None, 0.0)]
                    continue
                best = (s, side, d)
                break
            L.pin["side"] = home
            if best is None and onink is not None:
                best = onink          # nothing clear of the drawing: take it
            if best is None:
                put(L, slide[id(L)], home, 0.0)
                drop[id(L)] = 0.0
                self._pin_blockers(L)
                self._pin_refuse(L, hard, crossed)
            s, side, d = best
            if side != home:
                L.pin["side"] = side
                L.pin["flipped"] = True
                alone.setdefault(L.pin["axis"], []).append(
                    (L, slide[id(L)], drop[id(L)], home))
            slide[id(L)], drop[id(L)] = s, d
            put(L, s, L.pin["side"], d)
            self._pin_blockers(L)
        for ax, moved in alone.items():
            if self._row_reads(pins, ax):
                continue
            for L, s0, d0, home in moved:
                L.pin.pop("flipped", None)
                L.pin["side"] = home
                slide[id(L)], drop[id(L)] = s0, d0
                put(L, s0, home, d0)
                self._pin_blockers(L)
        for i in range(len(pins)):
            for j in range(i + 1, len(pins)):
                if clash(pins[i], pins[j]):
                    self._pin_refuse(pins[i], [("number", pins[j], 0.0)])
        # v6 stage 1b: the solver does not get to trust its own search. Every
        # number is read again where it FINALLY stands -- a later step (a row
        # put back, a re-solve for another corner of the origin) could have
        # returned one to a spot ink covers, and with nothing cut any more
        # that is a struck number, not a cut line.
        for L in pins:
            hard = self._pin_blockers(L)[1]
            if hard:
                self._pin_refuse(L, hard)
            # O3-01 / P2-01: ... and the origin's '0' stands where it reads as
            # the crossing's (a refusal here sends _solve_origin to the next
            # corner; svgcheck._zero_owner reads the same off the file)
            if not self._zero_owns(L, pins):
                self._pin_refuse(L, [("zero", None, 0.0)])
        # ... and a ROW still reads as one row: at most one number in
        # svgcheck.MOVED_SHARE may stand across the axis from the rest. A row
        # split 5 / 2 is two rows to a reader, and the smaller one is then
        # read against the OTHER axis's numbers (svgcheck.reading_merge).
        for ax in ("x", "y"):
            grp = [L for L in pins if L.pin["axis"] == ax]
            # v6 stage 1b r2: TWO numbers are a row as well. The guard used to
            # be `< 3`, which made the whole-row clause below dead code on
            # exactly the rows the automatic step of 2 squares produces on a
            # short axis -- the solver slid both numbers off their ticks,
            # believed the layout fine, and svgcheck refused the finished file
            # with a message that names no fix the author can apply.
            if len(grp) < 2:
                continue
            sides = [L.pin["side"] for L in grp]
            few = 1 if sides.count(1) <= sides.count(-1) else -1
            odd = [L for L in grp if L.pin["side"] == few]
            if not self._row_reads(pins, ax):
                self._pin_refuse(odd[0], [("split", None, 0.0)])
            # ... and a row whose numbers have all had to step aside has slid
            # off its ticks, which svgcheck.tick_alignment refuses off the
            # finished file. Refuse it here, where the message can name a fix.
            sp = self._pin_budget(grp[0], 1.0)
            if not sp:
                continue
            aside = [L for L in grp
                     if abs(slide[id(L)]) > svgcheck.TICK_TOL * sp]
            if len(aside) > max(svgcheck.MOVED_LEAST,
                                len(grp) // svgcheck.MOVED_SHARE) or \
                    (len(aside) == len(grp) and len(grp) >= 2):
                self._pin_refuse(aside[0], [("row", None, 0.0)])

    def _stretch(self, L, items):
        """The least factor the squares must grow by, the numbers keeping
        their size, for every dot / arrowhead in `items` to clear the number
        on the side it is on. None when one of them sits on the axis itself."""
        P = L.pin
        j = 1 if P["axis"] == "x" else 0
        at = P["tick"][j]
        pl = L.plate
        far_home = max(abs(pl[j] - at), abs(pl[j + 2] - at))
        k = 1.0
        for kind, d, r in items:
            if kind == "dot":
                c = d[j] - at
                if abs(c) <= r:
                    return None
                k = max(k, (far_home + 0.5 + r) / abs(c))
            elif kind == "head":
                lo, hi = sorted((d[0][j] - at, d[1][j] - at))
                if lo <= 0 <= hi:
                    return None
                near = min(abs(lo), abs(hi))
                k = max(k, (far_home + 0.5) / max(near, 1e-6))
        return math.ceil(k * 20.0) / 20.0

    def _move_hint(self, L, items):
        """C2 round 3: the move that parts a dot or an arrowhead from a pinned
        number, in grid squares (the builder's `square`): so far from the
        axis, or so far along it from the tick, that the number's ink on
        either side of the axis stays clear. None without a square."""
        sq = L.pin.get("square")
        if not sq or not items:
            return None
        P = L.pin
        j = 1 if P["axis"] == "x" else 0          # across the axis
        at = P["tick"][j]
        pl = L.plate
        far = max(abs(pl[j] - at), abs(pl[j + 2] - at))
        half = (L.glyph[2] - L.glyph[0]) / 2.0 if j else \
            (L.glyph[3] - L.glyph[1]) / 2.0
        r = max([h[2] for h in items if h[0] == "dot"] or [0.0])
        pd = svgcheck.NUM_PAD_EM * L.size
        across = (far + 0.5 + r) / sq
        along = (half + pd + 0.5 + r) / sq
        axis = "x" if P["axis"] == "x" else "y"
        what = "each point" if any(h[0] == "dot" for h in items) \
            else "each arrow"
        return ("move %s off the number's spot: at least %.2f squares along "
                "the %s-axis from the tick of %s, or at least %.2f squares "
                "from the %s-axis on either side where no other number stands"
                % (what, math.ceil(along * 20) / 20.0, axis, L.text,
                   math.ceil(across * 20) / 20.0, axis))

    def _pin_refuse(self, L, hard, crossed=None, hidden=False):
        hidden = hidden or getattr(L, "phantom", False)
        name = {"x": "x-axis number", "y": "y-axis number",
                "o": "origin number"}[L.pin["axis"]]
        if hidden:
            name = ("the blanked %s (hide=/origin=False/sparse=True/a sketch)"
                    % {"x": "x-axis number", "y": "y-axis number",
                       "o": "origin number"}[L.pin["axis"]])
        what, fixes = [], []
        items = [h for h in list(hard) + [c for c in crossed or ()
                                          if c[0] in ("dot", "head")]
                 if h[0] in ("dot", "head")]
        for kind, d, _ in hard:
            if kind == "number":
                other = {"x": "x-axis", "y": "y-axis", "o": "origin"}[
                    d.pin["axis"]]
                what.append("its ink overlaps (or reads into) the %s number %r"
                            % (other, d.text))
                sp = L.pin["spacing"] or d.pin["spacing"]
                if isinstance(sp, (tuple, list)):     # the origin's (x, y)
                    sp = min(v for v in sp if v) if any(sp) else None
                fixes.append("give each square more room than these numbers "
                             "need: a larger size=%s, a wider figure (width=), "
                             "or a regular step of 2 squares"
                             % ("" if not sp else " (ticks are %.0f units apart "
                                "for numbers %.0f units wide)"
                                % (sp, L.glyph[2] - L.glyph[0])))
            elif kind == "dot":
                at = getattr(self, "_data_at", None)
                what.append("a plotted point at %s covers it"
                            % (_num_pair(at(d)) if at else "this tick")
                            if at else "a plotted point covers it")
            elif kind == "head":
                what.append("an arrowhead covers it")
            elif kind in ("axis", "tick"):
                what.append("an axis line runs through it" if kind == "axis"
                            else "a neighbouring tick mark runs through it")
                fixes.append("give each square more room than the numbers "
                             "need: a larger size=, a wider figure (width=), "
                             "or a regular step of 2 squares")
            elif kind == "row":
                what.append("too many of its row would have to stand aside "
                            "from their ticks, so the row itself reads as "
                            "slid")
                fixes.append("give the row room: number every 2 squares, a "
                             "larger size=, a wider figure (width=), or -- "
                             "where the coordinates are yours to choose -- a "
                             "shape placed off the row of numbers")
            elif kind == "split":
                what.append("its row of numbers would be split across the "
                            "axis, and the smaller half reads as the other "
                            "axis's numbers")
                fixes.append("give the row one clear side: number every 2 "
                             "squares, widen the range, or -- where the "
                             "coordinates are yours to choose -- a shape "
                             "placed off the row of numbers")
            elif kind == "stroke":
                # v6 stage 1b: this used to be answered by cutting the stroke
                what.append("a line, a polygon edge, a curve or a circle runs "
                            "through it (a data stroke is never cut, broken "
                            "or hidden by a number)")
                fixes.append("give the number room: a larger size= or a wider "
                             "figure (width=), a regular step of 2 squares, a "
                             "window that does not run a stroke along the row "
                             "of numbers, or -- where the coordinates are "
                             "yours to choose -- a shape placed off it; never "
                             "move given data, never drop the number and "
                             "never cut the stroke")
            elif kind == "zero":
                what.append("in every free spot it would stand nearer another "
                            "tick than the axes' crossing and read as that "
                            "tick's number")
                fixes.append("give the number room: a larger size= or a wider "
                             "figure (width=), a regular step of 2 squares, "
                             "or -- where the coordinates are yours to choose "
                             "-- a shape placed off the corners of the origin; "
                             "never move given data and never drop the '0'")
            elif kind == "mark":
                what.append("a mark (an equality tick, a parallel arrow, a "
                            "right-angle mark or a dimension line) covers it")
                fixes.append("move the mark along its segment (ticks(..., t=) "
                             "/ parallel_arrows(..., t=); in plane(), "
                             "tickmarks=[((p, q), n, t)]), or give the figure "
                             "room (size= / width=); a mark is never cut and "
                             "never dropped")
            else:
                what.append("a stroke added to Figure.segs by hand (not a "
                            "Figure primitive, so it cannot be cut) covers it")
                fixes.append("draw that stroke with Figure.line/poly/arc so the "
                             "engine can cut it behind the number, or a larger "
                             "size=")
        if items:
            if crossed and crossed[0][0] == "reads":
                what.append("across the axis it would stand within an em of "
                            "the other axis's numbers and read as one of them")
            elif crossed:
                what.append("across the axis %s as well" % (
                    "a plotted point" if any(h[0] == "dot" for h in crossed)
                    else "an arrowhead"))
            k = self._stretch(L, items)
            sq = L.pin.get("square")
            page = L.pin.get("page")
            # C6 r6 (doctrine 1): the refusal no longer says "move each point
            # off the number's spot". A plotted point and an arrow's end are
            # the DATA the question prints; a builder under deadline who
            # followed it drew B(-4, -1) somewhere else. What keeps the data
            # is room: a step that leaves this tick unnumbered, bigger
            # squares, a wider figure. (_move_hint stays for callers who
            # place decorative points.)
            even = ("every 2 squares, so no number stands at this tick"
                    if L.pin["axis"] in ("x", "y") else None)
            # stage-1 fix r1: only where every 2 squares really skips this
            # tick -- the '-4' was told a step of 2 would unnumber it
            if even and sq:
                i_ = 0 if L.pin["axis"] == "x" else 1
                k_sq = L.pin["tick"][i_] / float(sq)
                if abs(k_sq - round(k_sq)) < 1e-6 and int(round(k_sq)) % 2 == 0:
                    even = None
            if k is None:
                fixes.append("the point or arrowhead lies ON the axis beside "
                             "this number, so no stretch parts them -- and it "
                             "is data, so it stays: number the axis %s, or "
                             "draw it at a finer scale (xscale=/yscale=) so "
                             "it stands further from the tick in squares"
                             % (even or "at another step"))
            else:
                xs = [q[0] for kind, pts, w, dash, extra in self.parts
                      for q in pts]
                span = (max(xs) - min(xs)) if xs else 100.0
                width = int(math.ceil((span * k + 18 + 4.0 * L.size) / 10.0)
                            * 10)
                if page and width > page + 1e-6:
                    # C2 round 3: never name only a stretch no page holds
                    # (size=44 and width=560 for a plane capped at 210px):
                    # the author's easy escape was then hide=, which drops
                    # the number
                    fixes.append(
                        "%s is data and stays where it is: number the "
                        "axis %s, or give the figure the room (stretching the "
                        "squares by x%.2f would need width=%d, wider than the "
                        "%dpx this figure may print at)"
                        % ("the point" if any(h[0] == "dot" for h in items)
                           else "the arrow's end", even or "at another step",
                           k, width, int(page)))
                elif sq:
                    fixes.append(
                        "stretch the squares by x%.2f with the numbers kept "
                        "at their size: size=%d and width=%d (an explicit "
                        "width= stops coord_plane/plane from enlarging the "
                        "numbers with the squares, which is why size= alone "
                        "never parts them)" % (k, int(math.ceil(sq * k)), width))
                else:
                    fixes.append(
                        "stretch the figure by x%.2f with the numbers kept at "
                        "their size (about width=%d)" % (k, width))
        # C6 r6: a knob already turned is not a fix. An axis numbered every
        # 2 squares was still told "a regular step of 2 squares".
        sp, sq = L.pin.get("spacing"), L.pin.get("square")
        if isinstance(sp, (tuple, list)):
            sp = min([v for v in sp if v] or [0.0])
        # stage-1 fix r1: ... nor is a step that numbers this tick anyway:
        # a '-4' was told 'a regular step of 2 squares'
        even_tick = False
        if sq and L.pin["axis"] in ("x", "y"):
            k_sq = L.pin["tick"][0 if L.pin["axis"] == "x" else 1] / float(sq)
            even_tick = abs(k_sq - round(k_sq)) < 1e-6 and \
                int(round(k_sq)) % 2 == 0
        if (sp and sq and sp / sq >= 1.99) or even_tick:
            def _no_two(t):
                for a, b in ((", or a regular step of 2 squares", ""),
                             (", a regular step of 2 squares,", ","),
                             ("number every 2 squares, ", ""),
                             ("every 2 squares, so no number stands at this "
                              "tick", "at a step that leaves this tick "
                              "unnumbered")):
                    t = t.replace(a, b)
                return t
            fixes = [_no_two(t) for t in fixes]
        seen = []
        for f in fixes:
            if f not in seen:
                seen.append(f)
        tail = ("A tick number stays on its tick (within %.2f x the tick "
                "spacing) and is never dropped -- Do NOT drop the number."
                % PIN_SLIDE)
        if hidden:
            tail = ("hide= (and origin=False) blanks a value the item must "
                    "not give away; it does not make room for one. This "
                    "number has nowhere to stand even unprinted, so the "
                    "drawing, not the numbering, is what has to change -- "
                    "Do NOT drop the number.")
        # v6 stage 1b r2: a LayoutError, so plane()'s ladder knows it may try
        # a bigger drawing (rule 5) without reading the prose
        raise svgcheck.LayoutError(
            "figkit: %s %r has no room %s: %s. %s Fix the drawing: %s."
            # P3 leftovers r1 (minor): the tick was named in SVG pixels
            # ("beside its tick at (-48, 0)"), which an author cannot map back
            # to anything in their call. It is named by its DATA VALUE now --
            # the number itself, which is what they wrote.
            % (name, L.text, "in any corner of the axes' crossing"
               if L.pin["axis"] == "o" else "beside its tick at %s = %s"
               % (L.pin["axis"], L.text),
               "; ".join(sorted(set(what))), tail, "; or ".join(seen)))

    def _cut_behind(self, L, a0, start, placed, cross_pad):
        """LEGACY (a `label(..., sector=)` number; the builders pin theirs
        with `tick_label` since v6). Last resort for such a number: its place
        beside its tick, taken only when NOTHING is there.

        v6 stage 1b: it no longer cuts. Until then the number kept this spot
        and the line, edge or rim under it was cut away at render -- the
        comparison's F5 printed two sides of a triangle in pieces. A stroke
        here now refuses the figure (the caller's message names the fixes)."""
        th = math.radians(a0)
        pos = (L.anchor[0] + start * math.cos(th),
               L.anchor[1] + start * math.sin(th) + 0.27 * L.size)
        box = L.box_at(pos)
        grown = (box[0] - 2.0, box[1] - 2.0, box[2] + 2.0, box[3] + 2.0)
        for a, b in self.segs:
            if _seg_box(a, b, grown):
                return None
        for pl in placed:
            ob, ok = pl[0], pl[1]
            if _boxes_overlap(box, ob, cross_pad if ok != L.kind else 1.5):
                return None
        return (pos, box)

    def _cross_kind_gap(self):
        """Smallest gap, in figure units, between two labels of different kind."""
        best = 1e9
        ls = [L for L in self.labels if L.box and L.kind in ("vertex", "value")]
        for i in range(len(ls)):
            for j in range(i + 1, len(ls)):
                a, b = ls[i], ls[j]
                if a.kind == b.kind:
                    continue
                gx = max(a.box[0] - b.box[2], b.box[0] - a.box[2])
                gy = max(a.box[1] - b.box[3], b.box[1] - a.box[3])
                best = min(best, max(gx, gy))
        return best

    def _extent(self, margin):
        x0 = y0 = 1e9
        x1 = y1 = -1e9
        for kind, pts, w, dash, extra in self.parts:
            if kind == "circle":
                r = extra[0]
                pts = [(pts[0][0] - r, pts[0][1] - r), (pts[0][0] + r, pts[0][1] + r)]
            for q in pts:
                x0, y0 = min(x0, q[0]), min(y0, q[1])
                x1, y1 = max(x1, q[0]), max(y1, q[1])
        for L in self.labels:
            if L.box:
                x0, y0 = min(x0, L.box[0]), min(y0, L.box[1])
                x1, y1 = max(x1, L.box[2]), max(y1, L.box[3])
        return max(x1 - x0 + 2 * margin, 1.0)

    # -- verification -------------------------------------------------------
    def verify(self, scale=1.0):
        """Everything that must be true before a byte is emitted."""
        bad = []
        for name, drawn, given in self._checks:
            if given == 0:
                continue
            bad.append((name, drawn, given))
        if len(bad) >= 2:
            # Compare RATIOS, not absolutes: the drawing is to scale, not to
            # size. Anchor on the first pair and check the rest against it.
            n0, d0, g0 = bad[0]
            k = d0 / g0
            for name, drawn, given in bad[1:]:
                got = drawn / given
                if abs(got - k) / k > _TOL:
                    raise AssertionError(
                        "figkit: the drawing contradicts its own data — %s is "
                        "%.1f units for %g, but %s is %.1f for %g (%.0f%% off). "
                        "A student who measures gets a different sheet from "
                        "the one they read."
                        % (name, drawn, given, n0, d0, g0,
                           100 * abs(got - k) / k))
        for L in self.labels:
            eff = L.size * scale * _PX_TO_PT
            if eff < self.min_pt - 1e-6:
                raise AssertionError(
                    "figkit: label %r reaches the reader at %.1fpt, below the "
                    "%.1fpt floor. The audit found figure labels at 4-5pt and "
                    "one at ~2pt; raise the font size or the display width."
                    % (L.text, eff, self.min_pt))

        # LABEL AGAINST LABEL. The solver keeps a label off every STROKE and
        # the output gate re-checks that, but neither looks at two labels that
        # end up reading as one. A review found a vertex letter and a length
        # value 2.6pt apart in an 11pt face, printing as "C 5 G".
        #
        # Scope matters here. A first cut applied this to every pair and to the
        # placer as well; it then refused three drawings whose axis ticks are
        # SUPPOSED to sit close (consecutive numbers on one axis) and pushed a
        # fourth under the font floor by widening it. Two labels of the same
        # kind, evenly spaced, are not the defect. Only a value crowding a
        # vertex is.
        placed = [L for L in self.labels if L.box and L.kind in ("vertex", "value")]
        for i in range(len(placed)):
            for j in range(i + 1, len(placed)):
                a, b = placed[i], placed[j]
                if a.kind == b.kind:
                    continue
                gap_x = max(a.box[0] - b.box[2], b.box[0] - a.box[2])
                gap_y = max(a.box[1] - b.box[3], b.box[1] - a.box[3])
                gap = max(gap_x, gap_y)
                if gap * scale * _PX_TO_PT < _LABEL_GAP_PT:
                    # stage-1 fix r1: where two labels sit is a layout matter
                    raise svgcheck.LayoutError(
                        "figkit: labels %r and %r end up %.1fpt apart, under "
                        "the %.1fpt floor -- at that distance they read as one "
                        "cluster, not two labels. Move an anchor or widen the "
                        "drawing." % (a.text, b.text,
                                      max(gap, 0) * scale * _PX_TO_PT,
                                      _LABEL_GAP_PT))
        self._verify_marks(scale)
        self._verify_dims()
        self._verify_merges()
        return self

    @staticmethod
    def _dim_strokes(d, offset, witness=None):
        """The dimension line and witness lines of dimension `d` drawn at
        `offset`, as segments."""
        p, q, gap = d["p"], d["q"], d["gap"]
        ux, uy = _unit(p, q)
        nx, ny = uy, -ux
        sg = 1.0 if offset >= 0 else -1.0
        out = [((p[0] + nx * offset, p[1] + ny * offset),
                (q[0] + nx * offset, q[1] + ny * offset))]
        if witness is None:
            witness = d["witness"]
        if witness and abs(offset) > gap + 0.5:
            wf = d.get("witness_from")
            for i, e in enumerate((p, q)):
                s0 = wf[i] if wf else e
                ext = d.get("ext", 2.5)
                out.append(((s0[0] + nx * sg * gap, s0[1] + ny * sg * gap),
                            (e[0] + nx * (offset + sg * ext),
                             e[1] + ny * (offset + sg * ext))))
        return out

    def _dim_hit(self, d, offset, witness=None):
        """A drawn stroke (an edge, a line, a curve) the dimension at `offset`
        crosses or lies along, as a point; else None. Marks, arrowheads,
        axes, ticks and fills are not judged.

        C3 r3: a WITNESS line lying along a drawn stroke is not a hit: the
        stroke already carries the eye out to the dimension line (the foot
        of a height on its base -- the base is the witness). Every z47-style
        height dimension was refused at every offset for it."""
        polys = [pts for kind, pts, w, _, _ in self.parts
                 if kind == "poly" and w and w > 0 and len(pts) >= 3]
        for n, (a, b) in enumerate(self._dim_strokes(d, offset, witness)):
            la = _dist(a, b)
            if la <= 1e-9:
                continue
            if n == 0:
                # a dimension line INSIDE a shape, ending on two of its edges,
                # crosses nothing -- it is still inside
                for t in (0.25, 0.5, 0.75):
                    m = (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)
                    if any(svgcheck._in_poly(m, P) and
                           min(svgcheck._pt_seg(m, P[k], P[(k + 1) % len(P)])
                               for k in range(len(P))) > 0.5 for P in polys):
                        return m
            # the strokes a witness line lies along carry it; where it meets
            # another stroke ON them (the base's own vertex) is no crossing
            carriers = [] if n == 0 else [
                (c, e) for c, e in self.segs
                if self._role.get(_seg_key(c, e)) not in
                ("mark", "head", "fill", "axis", "tick")
                and _dist(c, e) > 1e-9 and svgcheck._along_owner(c, e, a, b)]
            for c, e in self.segs:
                role = self._role.get(_seg_key(c, e))
                if role in ("mark", "head", "fill", "axis", "tick") or \
                        isinstance(role, tuple):
                    continue
                if _dist(c, e) <= 1e-9:
                    continue
                if svgcheck._along_owner(c, e, a, b):
                    if n > 0:
                        continue            # a witness on its stroke
                    # lying along it for more than a unit
                    ux, uy = (b[0] - a[0]) / la, (b[1] - a[1]) / la
                    s0 = sorted(((c[0] - a[0]) * ux + (c[1] - a[1]) * uy,
                                 (e[0] - a[0]) * ux + (e[1] - a[1]) * uy))
                    if min(s0[1], la) - max(s0[0], 0.0) > 1.0:
                        return _mid(a, b)
                    continue
                x = svgcheck._cross_pt(a, b, c, e)
                if x and 0.02 < x[0] < 0.98 and -1e-6 <= x[1] <= 1 + 1e-6:
                    if any(svgcheck._pt_seg(x[2], g, h) < 0.5 for g, h in carriers):
                        continue
                    return x[2]
        return None

    def _verify_dims(self):
        """C3 r2: a dimension line stands OUTSIDE the drawing: neither it nor a
        witness line crosses or lies along a drawn stroke. With the documented
        page-left sign, offset=+14 on an edge drawn upward put the line inside
        the triangle and a witness line on its side."""
        for d in self._dims:
            hit = self._dim_hit(d, d["offset"])
            if hit is None:
                continue
            raise AssertionError(
                "figkit.dimension: the dimension line for (%.0f, %.0f)-(%.0f, "
                "%.0f) at offset=%g runs through a stroke of the drawing (or lies inside a shape) near "
                "(%.0f, %.0f) -- a dimension stands outside the shape. %s "
                "(offset is to the page-LEFT walking from p to q); never drop "
                "the dimension." % (
                    d["p"][0], d["p"][1], d["q"][0], d["q"][1], d["offset"],
                    hit[0], hit[1], self._dim_fix(d)))

    def _dim_fix(self, d):
        """C3 r3: the call that clears the drawing, tried and named: the
        other side, witness=False (the witness lines were what crossed), then
        the offset that stands beyond every stroke on either side."""
        off = d["offset"]
        for o, w, say in ((-off, None, "put it on the other side: offset=%g"
                           % -off),
                          (off, False, "draw it without witness lines: "
                           "offset=%g, witness=False" % off),
                          (-off, False, "offset=%g, witness=False" % -off)):
            if self._dim_hit(d, o, w) is None:
                return say[0].upper() + say[1:]
        p, q = d["p"], d["q"]
        ux, uy = _unit(p, q)
        nx, ny = uy, -ux
        proj = [(c[0] - p[0]) * nx + (c[1] - p[1]) * ny
                for a, b in self.segs for c in (a, b)
                if self._role.get(_seg_key(a, b)) not in ("mark", "head")]
        sg = 1.0 if off >= 0 else -1.0
        for s_ in (sg, -sg):
            far = max([v * s_ for v in proj] + [0.0])
            o = s_ * math.ceil(far + max(abs(off), 8.0))
            if self._dim_hit(d, o) is None:
                return "Stand it beyond the drawing: offset=%g" % o
            if self._dim_hit(d, o, False) is None:
                return "Stand it beyond the drawing: offset=%g, witness=False" % o
        return ("Every offset crosses a stroke: dimension this length with a "
                "label on the segment itself (edge_label) instead of a "
                "dimension line")

    def _declares_wrong_marks(self):
        return "marks" in str(self.critique or "").split(":")

    def _mark_claim(self, msg):
        """A mark that contradicts the drawing: a refusal, unless the figure
        DECLARED that it would (generate.violate)."""
        if self._declares_wrong_marks():
            self._crit_seen.append(msg)
            return
        raise AssertionError(msg)

    def _verify_marks(self, scale):
        """v6 C3 (E5/E9/E8): the marks' claims against the drawing, and their
        printed floors against the final scale."""
        groups = {}
        for s in self._marks:
            if s["kind"] in ("ticks", "parallel"):
                groups.setdefault((s["kind"], s["n"]), []).append(s)
        for (kind, n), ss in sorted(groups.items()):
            if len(ss) < 2:
                continue
            if kind == "ticks":
                real = [s["real"] is not None for s in ss]
                if any(real) and not all(real):
                    raise AssertionError(
                        "figkit: equality ticks n=%d mix real= lengths with drawn "
                        "ones -- give real= on every segment of the group or on "
                        "none" % n)
                L = [(float(s["real"]) if s["real"] is not None
                      else _dist(s["p"], s["q"])) for s in ss]
                lo, hi = min(L), max(L)
                if hi > 0 and (hi - lo) / hi > EQUAL_TOL:
                    a, b = ss[L.index(lo)], ss[L.index(hi)]
                    self._mark_claim(
                        "figkit: %d equality tick(s) say two segments are equal, "
                        "but one measures %.2f and the other %.2f (%.1f%% apart, "
                        "at (%.0f, %.0f) and (%.0f, %.0f)) -- the marks contradict "
                        "the drawing. Give each different length its own tick "
                        "count (n=1, n=2, ...), or draw the figure from numbers "
                        "that make them equal; pass real= for a projected edge."
                        % (n, lo, hi, 100.0 * (hi - lo) / hi,
                           _mid(a["p"], a["q"])[0], _mid(a["p"], a["q"])[1],
                           _mid(b["p"], b["q"])[0], _mid(b["p"], b["q"])[1]))
            else:
                ang = [math.degrees(math.atan2(s["q"][1] - s["p"][1],
                                               s["q"][0] - s["p"][0])) % 180.0
                       for s in ss]
                for i in range(1, len(ang)):
                    d = abs(ang[i] - ang[0]) % 180.0
                    d = min(d, 180.0 - d)
                    if d > PARALLEL_TOL:
                        self._mark_claim(
                            "figkit: parallel arrows n=%d say two segments are "
                            "parallel, but they differ by %.1f° -- the marks "
                            "contradict the drawing. Give each direction its own "
                            "arrow count, or draw the figure from numbers that "
                            "make them parallel." % (n, d))
        upt = 1.0 / max(scale * _PX_TO_PT, 1e-9)
        for s in self._marks:
            if s["kind"] not in ("ticks", "parallel"):
                continue
            t = s["t"] if s["t"] is not None else self._auto_t(s, s["upt"])
            if not self._mark_clear(s, t, s["upt"]):
                info = self._axis_ticks_along(s["p"], s["q"])
                good = [(a + b) / 2.0 / info[2] for a, b in
                        zip(info[0], info[0][1:])]
                good = [g for g in good if 0.12 <= g <= 0.88 and
                        self._mark_clear(s, g, s["upt"], info)]
                raise AssertionError(
                    "figkit: %s n=%d on the segment (%.0f, %.0f)-(%.0f, %.0f) "
                    "stand%s in line with a tick mark of the axis it lies on "
                    "-- beside the axis tick they read as one more tick "
                    "('|| |'). Put them half-way between two axis ticks: %s "
                    "(or leave t=None and figkit places them); never drop the "
                    "marks." % ("equality ticks" if s["kind"] == "ticks"
                                else "parallel arrows", s["n"], s["p"][0],
                                s["p"][1], s["q"][0], s["q"][1],
                                "" if s["n"] > 1 else "s",
                                ("t=" + " or t=".join("%.3g" % g for g in good))
                                if good else "a larger figure (size= / width=)"))
        for s in self._marks:
            if s["upt"] < upt * (1 - 1e-4):
                raise AssertionError(
                    "figkit: a %s mark was drawn for a larger print than this "
                    "one (%.3f < %.3f units per pt) -- render() did not settle; "
                    "report it" % (s["kind"], s["upt"], upt))
        # NOTE the giveaway half of the declaration is NOT decided here: an
        # angle text that contradicts its arc is measured by svgcheck and not
        # by this method, so a figure whose declared error is of that kind
        # would be refused for having no error at all. svgcheck.problems --
        # which runs on the finished string of every checked render and sees
        # every mark sweep there is -- owns that decision.

    def _verify_merges(self):
        """v6 C3 (E24): no two labels on one baseline band closer than
        MERGE_EM (0.6 em). Two numbers pinned to the same axis are a row, not a
        merge; every other pair is judged (a point letter beside a tick
        number, '5 16', '4 Q')."""
        ls = [L for L in self.labels if L.box]
        for i in range(len(ls)):
            for j in range(i + 1, len(ls)):
                a, b = ls[i], ls[j]
                if a.pin and b.pin and a.pin["axis"] == b.pin["axis"]:
                    continue
                if a.pin and b.pin and "o" in (a.pin["axis"], b.pin["axis"]):
                    continue
                # legacy axis numbers (label(..., sector=)) are a row too
                if (a.sector or a.pin) and (b.sector or b.pin):
                    continue
                g = _reading_merge(a.box, a.size, b.box, b.size,
                                   a.text, b.text)
                if g is not None:
                    raise AssertionError(
                        "figkit: labels %r and %r share a baseline %.2f em apart "
                        "(needs %.1f em%s) -- they read as one %s, '%s %s'. "
                        "Re-place one (another anchor or prefer=), put them on "
                        "different sides of the stroke, or enlarge the figure; "
                        "never drop either." % (
                            a.text, b.text,
                            max(g, 0.0) / max(a.size, b.size),
                            merge_em(a.text, b.text),
                            ": they print as the same mark"
                            if _confusable(a.text, b.text) else "",
                            "mark" if _confusable(a.text, b.text) else "word",
                            a.text, b.text))

    # -- render -------------------------------------------------------------
    def render(self, margin=9, width=None, check=True, dot_values=None,
               owners=None, irregular=False, fam=None, critique=None):
        """Place, verify, emit — and then READ THE EMITTED SVG BACK.

        v6 (E3/E29): `check=True` runs `svgcheck.assert_clean` on the finished
        string: struck labels (tspans and every path command included), ASCII
        minus, printed font floor per run, tick-number alignment, arrowhead
        clearance and dots touching a neighbouring tick. It used to run only in
        selftests, so builders that forgot `assert_unstruck` shipped unswept.
        `dot_values` (values the dots on an axis must read as) and `owners`
        ([(text, (p, q))] in figure coordinates) switch on the two sweeps that
        need to be told the intent. `irregular=True` declares a figure whose
        content IS a wrongly numbered axis (a critique item): the wrong-tick
        vote is skipped for it, nothing else is.

        v6 C3: every label bound to a stroke (`edge_label`, a `dimension`'s
        text) is added to `owners` automatically (E24); the sweep also reads
        the marks against the geometry (svgcheck.mark_geometry, E5), the
        markers (svgcheck.markers, E8) and reading merges
        (svgcheck.reading_merge, E24). `fam` tags the result with
        `figkit.tag` (E10)."""
        if critique is not None:
            self.critique = critique
        if check:
            # C3 r3: a dimension inside the shape is refused by its own
            # message, before the label solver fails to place its text
            self._verify_dims()
        self.place()
        est = self._extent(margin)
        disp0 = width if width is not None else (self.width or est)
        sc = disp0 / max(est, 1e-6)
        place_scale = 1.0
        if self._cross_kind_gap() * sc * _PX_TO_PT < _LABEL_GAP_PT:
            # Only re-place when the first pass actually produced the cluster.
            # Doing it unconditionally widened a drawing enough to push a label
            # under the 7pt font floor in a package that had been passing.
            self.place(scale=sc)
            place_scale = sc

        def frame():
            bx = [1e9, 1e9, -1e9, -1e9]

            def grow(*pts):
                for p in pts:
                    bx[0], bx[1] = min(bx[0], p[0]), min(bx[1], p[1])
                    bx[2], bx[3] = max(bx[2], p[0]), max(bx[3], p[1])

            for kind, pts, w, dash, extra in self.parts:
                if kind == "circle":
                    r = extra[0]
                    grow((pts[0][0] - r, pts[0][1] - r),
                         (pts[0][0] + r, pts[0][1] + r))
                else:
                    grow(*pts)
            for L in self.labels:
                grow((L.box[0], L.box[1]), (L.box[2], L.box[3]))
            return (bx[0] - margin, bx[1] - margin, bx[2] + margin,
                    bx[3] + margin)

        # v6 (E3): a superscript is a run of its own and is read at its own
        # printed size. At 0.72 em the exponent of `y = x^2` printed at 6.15pt
        # while its base cleared the floor. Raise the run to the floor instead
        # of refusing the label (the correct path is the default one) — and
        # re-place with the raised run in the box, so the solver keeps the
        # exponent it is about to print off every stroke. The floor depends on
        # the frame, and the frame on the placement, so iterate: it settles in
        # one or two passes because a raised run only ever grows a box.
        sups = [L for L in self.labels if "^" in L.text and _SUP_RE.search(L.text)]
        # v6 C3 (E9/E8): marks are drawn at printed floors, known only with the
        # frame -- the same loop raises them (they only ever grow).
        for _ in range(6):
            x0, y0, x1, y1 = frame()
            vw, vh = max(x1 - x0, 1.0), max(y1 - y0, 1.0)
            disp = width if width is not None else (self.width or vw)
            sup_floor = math.ceil(self.min_pt / max(disp / vw * _PX_TO_PT,
                                                    1e-6) * 100.0) / 100.0
            grew = False
            for L in sups:
                want = max(0.72 * L.size, sup_floor)
                if want > (L.sup or 0.72 * L.size) + 1e-9:
                    L.sup, grew = want, True
            if self._marks and self._fit_marks(disp / vw):
                grew = True
            # v6.2 Q1 r1: the angle-arc nests, at the scale the page really
            # shows (see _fit_arcs)
            if self._fit_arcs(disp / vw):
                grew = True
            if not grew:
                break
            self.place(scale=place_scale)
        else:
            x0, y0, x1, y1 = frame()
            vw, vh = max(x1 - x0, 1.0), max(y1 - y0, 1.0)
            disp = width if width is not None else (self.width or vw)

        self.verify(scale=disp / vw)
        # v6 stage 1b r3: the corner the emitted coordinates are measured
        # from. A builder that hands its INPUT geometry to svgcheck.draws has
        # to put it in the file's frame first; without this it could only
        # compare lengths, which a figure's axes and ticks pay for -- a hole
        # cut out of a curve passed.
        self.frame0 = (x0, y0)

        def T(p):
            return (p[0] - x0, p[1] - y0)

        # v6.5 (DELIVERABLE_SPEC items 1-2): the ids and the objects export.
        # It happens HERE, in the one place that knows the finished frame, so
        # `svg_xy` is the position in the file and `unit_px` converts it to
        # the page. Labels are registered now because a label's position is
        # only known after place().
        # v6.5 r1 (X1-05): a second render of the same Figure re-registers
        # the labels. Without this the second pass put lbl-A-2 on the glyph
        # and left lbl-A -- the id the caller already holds -- as an anchor
        # over nothing.
        self.ex._rerender("label")
        self._hand_arrows()
        self.ex.harvest(self.labels)
        for L in self.labels:
            if L.phantom:
                continue
            meta = {"text": L.text}
            owner = None
            if L.owner is not None:
                a = self.ex.name_of(L.owner[0])
                b = self.ex.name_of(L.owner[1])
                if a and b and a != b:
                    owner = export.pair_name(a, b)
            if owner is None and L.export_owner is not None:
                a = self.ex.name_of(L.export_owner[0])
                b = self.ex.name_of(L.export_owner[1])
                if a and b and a != b:
                    owner = export.pair_name(a, b)
            if owner is None and L.pin:
                # an axis number: the caller asks for "the 3 on the x axis"
                owner = "%s%s" % (L.pin.get("axis", ""), export.slug(L.text))
            if owner is None and L.owner is None and \
                    L.export_owner is None:
                n = self.ex.name_of(L.anchor)
                if n and L.text == n:
                    owner = n
            if owner is None and getattr(L, "export_point", None) is not None:
                # v6.6 S r1: a point's letter set off from the point itself
                # (solidkit's add-on points) is tied to the point it names
                n = self.ex.name_of(L.export_point)
                if n and L.text == n:
                    owner = n
            if owner:
                meta["for"] = owner
            else:
                # v6.6 E (X1R2-03): a number printed on a segment or a
                # dimension whose ends have no letters (a cylinder's h, a
                # plane's unnamed side) is still tied to what it labels: the
                # export resolves these ends to that object's id at finish
                _own = L.export_owner if L.export_owner is not None \
                    else L.owner
                if _own is not None:
                    meta["_for_pts"] = (tuple(_own[0]), tuple(_own[1]))
                elif getattr(L, "export_face", None):
                    # v6.6 E r1: a number written INSIDE a face (an area, a
                    # net's face value) is tied to that face's polygon
                    meta["_for_poly"] = tuple(tuple(p) for p in L.export_face)
                elif L.anchor is not None:
                    # v6.8 G6: a number beside a plotted point is tied to it
                    meta["_for_at"] = tuple(L.anchor)
            meta["_k"] = "%s@%.2f,%.2f" % (L.text, L.pos[0], L.pos[1])
            if L.box is not None:
                meta["_box"] = tuple(float(c) for c in L.box)   # v6.8 r2
            L.exid = self.ex.add("label", [L.pos], role=L.kind, meta=meta)
        # The view states the numbers THE FILE states (the header is written
        # at one decimal), so unit_px is the scale a renderer really applies:
        # file width / file viewBox width. Taken from the unrounded frame it
        # was 0.1% out, which is a fifth of a pixel on a 200px figure -- and
        # this export exists to be exact.
        _w_f, _h_f = float("%.1f" % disp), float("%.1f" % (disp * vh / vw))
        _vw_f, _vh_f = float("%.1f" % vw), float("%.1f" % vh)
        self.ex.finish(T, {"width_px": _w_f,
                           "height_px": _h_f,
                           "unit_px": round(_w_f / _vw_f, 6),
                           "viewbox": [_vw_f, _vh_f],
                           "rotate": self.rotate},
                       frame0=(x0, y0), rotate=self.rotate, fam=fam)
        part_id = self.ex.by_part()
        drawn = set()

        def idof(i):
            """The id attribute for the ONE element a part emits. A part cut
            into pieces by a number gets no id on any piece (no piece is the
            object); its id rides the anchor layer instead."""
            x = part_id.get(i)
            if not x or x in drawn:
                return ""
            drawn.add(x)
            return ' id="%s"' % x

        # EVERY label, not only the ones that ask: the grid is decoration and
        # must never run through a character. Keying this off a per-label flag
        # left the packages that build their own axes on top of Figure still
        # printing gridlines through their tick numbers, which is exactly the
        # defect this was meant to end.
        halo_boxes = [(L.box[0] - x0 - 1.0, L.box[1] - y0 - 0.6,
                       L.box[2] - x0 + 1.0, L.box[3] - y0 + 0.6)
                      for L in self.labels]
        cut_labels = [L for L in self.labels if L.cut]
        cut_boxes = [self._cut_box(L, x0, y0) for L in cut_labels]
        # v6 (E4): what the cut takes is only what lies under a number's plate.
        # v5.8 dropped EVERY leftover piece shorter than 1.1 em: a rectangle
        # edge running along the row of x-axis numbers lost all of its pieces
        # (coord_plane((0,6),(-2,4)) printed a three-sided box) and a parabola
        # drawn as a chain of short segments lost 5.4% of its length. Now a
        # polygon, a curve and a circle keep every piece. The ONE piece still
        # dropped is a guide's stub (see _stub).
        plan = self._cut_plan(cut_labels, cut_boxes, x0, y0)
        ink = {"in": 0.0, "covered": 0.0, "stubs": 0.0}

        def pieces(a, b, guide=False):
            """Pieces of a-b outside every plate, and the length they lose."""
            got = _clip_out(a, b, cut_boxes) if cut_boxes else [(a, b)]
            L0 = _dist(a, b)
            if len(got) == 1 and got[0] == (a, b):
                return got
            keep = []
            for p, q in got:
                if guide and self._stub(p, q, a, b, plan):
                    ink["stubs"] += _dist(p, q)
                    continue
                keep.append((p, q))
            ink["covered"] += L0 - sum(_dist(p, q) for p, q in got)
            return keep

        def subpaths(segs, smooth=False):
            """Chain pieces into M..L.. runs, joining where they meet.

            P3 leftovers r1: `smooth` draws a run of CURVE samples with cubic
            segments (Catmull-Rom control points, C commands) instead of
            chords. The samples are points of the curve, so the path still
            passes through every one of them and the clipping, the cutting
            and the length booking are unchanged -- what changes is that
            neighbouring pieces meet with the curve's own tangent instead of
            a visible corner."""
            runs = []
            for p, q in segs:
                if runs and _dist(runs[-1][-1], p) < 1e-6:
                    runs[-1].append(q)
                else:
                    runs.append([p, q])
            out_d = []
            for r in runs:
                if smooth:
                    # a zero-length step (the clip leaves one at each end)
                    # has no direction, and a cubic built on it doubles back
                    r = [p for k, p in enumerate(r)
                         if k == 0 or _dist(p, r[k - 1]) > 1e-6]
                if not smooth or len(r) < 3:
                    out_d.append("M" + " L".join("%.2f,%.2f" % v for v in r))
                    continue
                d = ["M%.2f,%.2f" % r[0]]
                n = len(r)

                def corner(k):
                    """True where the run turns sharper than _CORNER_DEG.

                    P3 leftovers r2: a point list handed in by an author
                    (curves=[([(-3,3),(0,0),(3,3)],'f')]) has real corners
                    in it. A hand at such a vertex points along neither
                    side and bows the line off BOTH of them; the corner is
                    kept instead."""
                    if k <= 0 or k >= n - 1:
                        return True
                    a, b, c = r[k - 1], r[k], r[k + 1]
                    u = (b[0] - a[0], b[1] - a[1])
                    v = (c[0] - b[0], c[1] - b[1])
                    mu, mv = math.hypot(*u), math.hypot(*v)
                    if mu < 1e-9 or mv < 1e-9:
                        return True
                    cs = (u[0] * v[0] + u[1] * v[1]) / (mu * mv)
                    cs = max(-1.0, min(1.0, cs))
                    return math.degrees(math.acos(cs)) > self._CORNER_DEG

                def across(p, h, a, b):
                    """Pull the hand `h` at `p` back until it stands at most
                    _SMOOTH_DEV*4/3 ACROSS the chord a->b. A cubic keeps
                    within 3/4 of its control points' distance from the
                    chord, so this bounds how far the printed line can be
                    from the geometry the figure was given."""
                    dx, dy = b[0] - a[0], b[1] - a[1]
                    m = math.hypot(dx, dy)
                    if m < 1e-9:
                        return h
                    off = abs(h[0] * (-dy / m) + h[1] * (dx / m))
                    lim = self._SMOOTH_DEV * 4.0 / 3.0
                    if off > lim > 0:
                        return (h[0] * lim / off, h[1] * lim / off)
                    return h

                def hand(p, t, lim):
                    """p plus the tangent t, never further than `lim` -- an
                    unclamped Catmull-Rom hand overshoots where the adaptive
                    sampler crowds points (the F4 vertex looped back on
                    itself, a 180 degree turn in the finished file)."""
                    m = math.hypot(t[0], t[1])
                    if m > lim > 0:
                        t = (t[0] * lim / m, t[1] * lim / m)
                    return (p[0] + t[0], p[1] + t[1])
                for k in range(n - 1):
                    p0 = r[k - 1] if k > 0 else r[0]
                    p1, p2 = r[k], r[k + 1]
                    p3 = r[k + 2] if k + 2 < n else r[n - 1]
                    lim = _dist(p1, p2) / 3.0
                    t1 = (0.0, 0.0) if corner(k) else (
                        (p2[0] - p0[0]) / 6.0, (p2[1] - p0[1]) / 6.0)
                    t2 = (0.0, 0.0) if corner(k + 1) else (
                        -(p3[0] - p1[0]) / 6.0, -(p3[1] - p1[1]) / 6.0)
                    c1 = hand(p1, across(p1, t1, p1, p2), lim)
                    c2 = hand(p2, across(p2, t2, p1, p2), lim)
                    d.append("C%.2f,%.2f %.2f,%.2f %.2f,%.2f"
                             % (c1[0], c1[1], c2[0], c2[1], p2[0], p2[1]))
                out_d.append(" ".join(d))
            return " ".join(out_d)

        out = ['<svg xmlns="http://www.w3.org/2000/svg" width="%.1f" '
               'height="%.1f" viewBox="0 0 %.1f %.1f">'
               % (disp, disp * vh / vw, vw, vh)]
        _at = {}                      # v6.6 E (V2-N4): part -> out span
        # v6.8 G1: every straight stroke as it is PRINTED (after the cut),
        # with the out slot it was written in, so an object no element of
        # its own carries (a polygon's edge, a solid's vertex) gets an id ON
        # INK: an exact overdraw of the stroke there (class="ink-copy")
        prims = []

        def slot(k):
            return "\x00%d\x00" % k

        def prim(a, b, w_, dash_, col, off=0.0):
            a = (round(a[0], 2), round(a[1], 2))
            b = (round(b[0], 2), round(b[1], 2))
            if w_ <= 0 or col == GRID or _dist(a, b) < 1e-6:
                return ""
            prims.append((a, b, w_, dash_, col, off, len(prims)))
            return slot(len(prims) - 1)
        for _pi, (kind, pts, w, dash, extra) in enumerate(self.parts):
            _at[_pi] = len(out)
            d = ' stroke-dasharray="%s"' % dash if dash else ""
            if kind == "poly":
                pl = " ".join("%.2f,%.2f" % T(p) for p in pts)
                tp = [T(p) for p in pts]
                edges = [(tp[k], tp[(k + 1) % len(tp)]) for k in range(len(tp))]
                if w > 0:
                    ink["in"] += sum(_dist(a, b) for a, b in edges)
                if cut_boxes and w > 0 and any(
                        _clip_out(a, b, cut_boxes) != [(a, b)] for a, b in edges):
                    # E4: the shape stays a <polygon> (its fill, and the key
                    # G75 reads) and its outline is ONE path of every piece.
                    out.append('<polygon points="%s" fill="%s" stroke="none"/>'
                               % (pl, extra or "none"))
                    segs = []
                    for a, b in edges:
                        segs += pieces(a, b)
                    out.append('<path d="%s" fill="none" stroke="%s" '
                               'stroke-width="%.2f" stroke-linejoin="round"%s/>'
                               % (subpaths(segs), INK, w, d) +
                               ("" if dash else "".join(
                                   prim(sa, sb, w, None, INK)
                                   for sa, sb in segs)))
                    continue
                if w <= 0:
                    out.append('<polygon points="%s" fill="%s" stroke="none"/>'
                               % (pl, extra or "none"))
                    continue
                _run, _tok = 0.0, ""
                for a, b in edges:
                    _tok += prim(a, b, w, dash, INK, _run)
                    _run += _dist(a, b)
                out.append('<polygon points="%s" fill="%s" stroke="%s" '
                           'stroke-width="%.2f"%s%s/>' % (pl, extra or "none",
                                                          INK, w, d,
                                                          idof(_pi)) + _tok)
            elif kind == "line":
                a, b = T(pts[0]), T(pts[1])
                col = extra[1] if (extra and extra[0] == "c") else INK
                role = extra[2] if (extra and len(extra) > 2) else None
                if col == GRID:
                    # Painting a white plate over the number hides the
                    # gridline but leaves the geometry intact, so a checker
                    # that intersects strokes with glyph boxes -- the one that
                    # produced the corpus audit -- still reports a crossed
                    # label. Cut the segment instead: same picture, and the
                    # crossing is gone from the file as well as from the page.
                    for sa, sb in _cut_segment(a, b, halo_boxes):
                        out.append('<line x1="%.2f" y1="%.2f" x2="%.2f" '
                                   'y2="%.2f" stroke="%s" '
                                   'stroke-width="%.2f"%s/>'
                                   % (sa[0], sa[1], sb[0], sb[1], col, w, d))
                    continue
                if svgcheck._dark(col) and w > 0:
                    ink["in"] += _dist(a, b)
                got = [(a, b)] if role else pieces(a, b, guide=bool(dash))
                whole = len(got) == 1 and got[0][0] == a and got[0][1] == b
                for sa, sb in got:
                    out.append('<line x1="%.2f" y1="%.2f" x2="%.2f" '
                               'y2="%.2f" stroke="%s" stroke-width="%.2f"%s%s/>'
                               % (sa[0], sa[1], sb[0], sb[1], col, w, d,
                                  idof(_pi) if whole else "") +
                               prim(sa, sb, w, dash, col))
            elif kind == "path":
                tp = [T(p) for p in pts]
                ink["in"] += sum(_dist(a, b) for a, b in zip(tp, tp[1:]))
                segs = []
                for a, b in zip(tp, tp[1:]):
                    segs += pieces(a, b)
                out.append('<path d="%s" fill="none" stroke="%s" '
                           'stroke-width="%.2f"%s/>'
                           % (subpaths(segs, extra == "smooth"
                                        and self._SMOOTH_CURVES),
                              INK, w, d) +
                           ("" if dash or (extra == "smooth" and
                                           self._SMOOTH_CURVES) else
                            "".join(prim(sa, sb, w, None, INK)
                                    for sa, sb in segs)))
            elif kind == "circle":
                c = T(pts[0])
                r = extra[0]
                if w > 0:
                    ink["in"] += 2 * math.pi * r
                n = max(48, int(2 * math.pi * r / 2.0))
                ring = [(c[0] + r * math.cos(2 * math.pi * k / n),
                         c[1] + r * math.sin(2 * math.pi * k / n))
                        for k in range(n + 1)]
                rim = list(zip(ring, ring[1:]))
                if cut_boxes and w > 0 and any(
                        _clip_out(a, b, cut_boxes) != [(a, b)] for a, b in rim):
                    # a curve is never deleted around a number: the rim is
                    # drawn as one path with a gap under the number's plate
                    if extra[1] and extra[1] != "none":
                        out.append('<circle cx="%.2f" cy="%.2f" r="%.2f" '
                                   'fill="%s" stroke="none"/>'
                                   % (c[0], c[1], r, extra[1]))
                    segs = []
                    for a, b in rim:
                        segs += pieces(a, b)
                    out.append('<path d="%s" fill="none" stroke="%s" '
                               'stroke-width="%.2f"%s/>'
                               % (subpaths(segs), INK, w, d))
                    continue
                out.append('<circle cx="%.2f" cy="%.2f" r="%.2f" fill="%s" '
                           'stroke="%s" stroke-width="%.2f"%s%s/>'
                           % (c[0], c[1], r, extra[1], INK, w, d, idof(_pi)))
            elif kind == "dot":
                c = T(pts[0])
                out.append('<circle cx="%.2f" cy="%.2f" r="%.2f" fill="%s" '
                           'stroke="none"%s/>'
                           % (c[0], c[1], extra, INK, idof(_pi)))
            elif kind == "mark" and extra["kind"] != "marker":
                out += self._emit_mark(extra, T)
        _at["end"] = len(out)
        # v6 C3 (E8): markers are painted ABOVE every stroke
        _at2 = {}
        for _pi, (kind, pts, w, dash, extra) in enumerate(self.parts):
            if kind == "mark" and extra["kind"] == "marker":
                _at2[_pi] = (len(out), None)
                out += self._emit_mark(extra, T)
                _at2[_pi] = (_at2[_pi][0], len(out))
        out = self._wrap_ids(out, _at, _at2, drawn)
        def idof_label(L):
            x = getattr(L, "exid", None)
            x = x.id if x is not None else None
            if not x or x in drawn:
                return ""
            drawn.add(x)
            return ' id="%s"' % x

        for L in self.labels:
            p = T(L.pos)
            # The label font must be one the SKILL SHIPS. Asking for a face
            # the machine does not have is the original v4.3 defect: the
            # first cut of this file said "DejaVu Serif" and WeasyPrint
            # silently substituted Times New Roman, which G70 caught.
            # v6.1: a values= text is a VALUE -- the engine prints it at the
            # axis numbers' size on purpose (figkit_plus, font * 0.92). Without
            # a mark in the FILE, printed_letter_pt read 'x > 0' as a LETTER
            # and G78 refused the sheet for a size the engine itself chose
            # (pilot work_c q11 ג/ד, q12 ג). The class is emitted so the
            # independent parser sees it, not the solver's records.
            out.append('<text x="%.2f" y="%.2f"%s font-family="David Libre,'
                       'serif" font-size="%s"%s text-anchor="middle" '
                       'fill="%s"%s>%s</text>'
                       % (p[0], p[1],
                          ' class="value"' if getattr(L, "value_text", False)
                          else "",
                          _fs(L.size),
                          ' font-style="italic"' if L.italic else "",
                          INK, idof_label(L),
                          _sup(L.text, L.size,
                               max(L.sup or 0.0, sup_floor))))
        # v6.8 G1: an object no element of its own carries is put ON INK --
        # an exact overdraw of the printed stroke there -- before anything
        # is left to the ids layer
        copies = self._ink_copies(prims, drawn)
        # v6.5: every object whose id no drawn element carries
        self._anchor_ink(drawn)
        anchors = self.ex.anchors(drawn)
        if anchors:
            out.append(anchors)
        out.append("</svg>")
        svg = "".join(out)
        svg = re.sub("\x00(\\d+)\x00",
                     lambda m_: copies.get(int(m_.group(1)), ""), svg)
        svg = assert_no_hebrew(svg)
        # v6.5 (spec rule 8): a figure that cannot say truthfully what it drew
        # does not ship. Re-read from the finished string, not from the
        # registry's own bookkeeping.
        export.verify(svg, self.ex, "figkit.Figure.render")
        # v6.5 X2 (spec section 8): every constraint this figure exports is
        # re-measured ON THE FILE, and the figure is kept with the SVG it
        # produced so the packaging step never has to re-run a build.
        # A figure that is WRONG ON PURPOSE keeps its claim, flagged
        # `violated`: a find-the-error figure (critique) and a FAIL fixture
        # rendered with check=False -- the house's one declared way to draw a
        # mark the geometry contradicts, so an independent sweep can be shown
        # catching it.
        self.ex.critique = (self.critique or None) if check else \
            (self.critique or "check_off")
        export.recheck(svg, self.ex, "figkit.Figure.render",
                       lenient=bool(self.ex.critique))
        svg = export.stamp(svg, self.ex, export.callsite())
        ink["expected"] = self._expected_ink(plan)
        self.ink_report = ink
        if check:
            self.check_complete(svg)
            if not cut_labels:
                # C6 r6 (the lost-ink gate's clause (b), for EVERY builder):
                # the file is read back against the strokes the figure was
                # given. check_complete compares totals booked by the
                # renderer; this walks each primitive and asks whether ink
                # lies ON it, so a hole cut in an edge by coord_plane, euclid,
                # shapelib or a number line is seen even where the axes and
                # ticks would make the totals come out whole.
                svgcheck.assert_draws(svg, self._data_geometry(T),
                                      "figkit.Figure.render")
            # v6 C3 (E24): every label bound to a stroke (edge_label, a
            # dimension's text) is judged for ownership, for every builder
            own = [(t, (T(p), T(q))) for t, (p, q) in (owners or [])]
            own += [(L.text, (T(L.owner[0]), T(L.owner[1])),
                     T(((L.box[0] + L.box[2]) / 2.0, (L.box[1] + L.box[3]) / 2.0)))
                    for L in self.labels if L.owner is not None]
            if self.critique:
                # the declaration has to reach the sweep, exactly as it does
                # for a number line (svgcheck.problems reads it off the
                # string): a sweep run on the finished figure would otherwise
                # report the item as a defect. ":seen" says THIS side already
                # found the declared error (an unequal pair of equality
                # ticks), so svgcheck does not have to find it a second time
                # to be satisfied that the figure really is wrong.
                # v6.3 r1 (S2-4): ":seen" carries the COUNT this side found.
                # A bare ":seen" (which only a hand-written tag can be) is
                # worth nothing to svgcheck, so the tag alone can no longer
                # waive the giveaway rule on a correct figure.
                svg = svg.replace(">", "><!--critique:%s-->" % (
                    self.critique + (":seen=%d" % len(self._crit_seen)
                                     if self._crit_seen else "")), 1)
            if self.projection:
                # v6.4: a figure drawn in a PROJECTION declares it in the
                # file, the same way a critique figure declares itself, and
                # for the same reason: the sweep that runs next must read the
                # figure as what it is. A cabinet drawing's 2D angles and
                # lengths are not its claims (a box's real 90° prints 117°),
                # and svgcheck.mark_geometry delegates those two readings to
                # the 3D reader when the tag is there. It has to be in the
                # string BEFORE the sweep, not added by the caller after.
                svg = svg.replace(">", "><!--proj:%s-->" % self.projection, 1)
            svgcheck.assert_clean(svg, "figkit.Figure.render",
                                  min_pt=self.min_pt, dot_values=dot_values,
                                  owners=own or None, ticks=self.tick_sweep,
                                  irregular=irregular,
                                  marks=("angles" if any(
                                      s["kind"] == "ticks" and s["real"] is not None
                                      for s in self._marks) else True))
            self._sweep_hidden(svg, T, sup_floor)
        if fam:
            svg = tag(svg, fam)
        return svg

    def _data_geometry(self, T):
        """C6 r6: the data strokes this figure was given, as (p, q) segments
        in the emitted frame -- lines (not the grid, an axis or a tick mark),
        polygon outlines, paths (curves, arcs) and circle rims. Marks and
        dots are left to their own sweeps."""
        geom = []
        for kind, pts, w, dash, extra in self.parts:
            if w is None or w <= 0:
                continue
            if kind == "line":
                col = extra[1] if (extra and extra[0] == "c") else INK
                role = extra[2] if (extra and len(extra) > 2) else None
                if col == GRID or not svgcheck._dark(col) or \
                        role in ("axis", "tick"):
                    continue
                geom.append((T(pts[0]), T(pts[1])))
            elif kind == "poly":
                tp = [T(p) for p in pts]
                geom += [(tp[k], tp[(k + 1) % len(tp)]) for k in range(len(tp))]
            elif kind == "path":
                tp = [T(p) for p in pts]
                geom += list(zip(tp, tp[1:]))
            elif kind == "circle":
                c, r = T(pts[0]), extra[0]
                n = max(48, int(2 * math.pi * r / 2.0))
                ring = [(c[0] + r * math.cos(2 * math.pi * k / n),
                         c[1] + r * math.sin(2 * math.pi * k / n))
                        for k in range(n + 1)]
                geom += list(zip(ring, ring[1:]))
        return geom

    def _sweep_hidden(self, svg, T, sup_floor):
        """C6 r4: a number hide=, sparse=True or a gridded sketch leaves
        unprinted is read back like a printed one.

        The pin solver places it with the printed numbers (Figure.place), but
        the file-level sweep only ever saw what was printed: where the solver
        and svgcheck disagree -- a '2' the solver cleared that the file shows
        struck -- the printed figure was refused and the same figure with that
        number blanked rendered. So the blanked numbers are written, at the
        spots the solver gave them, into a probe copy of the file with every
        printed text taken out, and svgcheck.struck reads it. The probe is
        never returned."""
        hid = [L for L in getattr(self, "hidden_pins", ()) if L.pos is not None]
        if not hid:
            return
        body = re.sub(r"<text\b.*?</text>", "", svg[:svg.rindex("</svg>")],
                      flags=re.S)
        texts = []
        for L in hid:
            p = T(L.pos)
            texts.append('<text x="%.2f" y="%.2f" font-family="David Libre,'
                         'serif" font-size="%s" text-anchor="middle" '
                         'fill="%s">%s</text>'
                         % (p[0], p[1], _fs(L.size), INK,
                            _sup(L.text, L.size, max(L.sup or 0.0, sup_floor))))
        bad = svgcheck.struck(body + "".join(texts) + "</svg>")
        # stage-1 fix r1: a blanked origin '0' is also judged where it would
        # print WITH the printed numbers -- the crossing's zero-ownership
        # sweep only read printed files, so origin=False turned a refusal of
        # the '0' green by deleting it
        zs = [t for L, t in zip(hid, texts) if L.pin.get("axis") == "o"]
        if zs and not bad:
            full = svg[:svg.rindex("</svg>")] + "".join(zs) + "</svg>"
            zero = [m for m in svgcheck.tick_alignment(full)
                    if "'0'" in m and m not in svgcheck.tick_alignment(svg)]
            if zero:
                L = [h for h in hid if h.pin.get("axis") == "o"][0]
                raise svgcheck.LayoutError(
                    "figkit: the blanked origin number '0' (origin=False) "
                    "does not read as the crossing's where it would print: %s. "
                    "A number an axis leaves unprinted must still have its "
                    "place -- blanking it is not a way past the sweep. Fix the "
                    "drawing: a larger size= with a wider figure (max_width= "
                    "/ width=) or a coarser numbering (step=2)." % zero[0])
        if bad:
            L = [h for h in hid if h.text in bad][0]
            name = {"x": "x-axis number", "y": "y-axis number",
                    "o": "origin number"}[L.pin["axis"]]
            raise svgcheck.LayoutError(
                "figkit: the blanked %s %r (hide= / origin=False / sparse=True "
                "/ a sketch) has no room beside its tick at %s: in "
                "the finished file ink runs through the spot it would print "
                "at. A number an axis leaves unprinted must still have its "
                "place -- blanking it is not a way past a stroke. Do NOT drop "
                "the number. Fix the drawing: give the number room: a larger "
                "size= with a wider figure (max_width= / width=), a regular "
                "step of 2 squares, a window that does not run a stroke along "
                "the row of numbers, or -- where the coordinates are yours to "
                "choose -- a shape placed off it."
                % (name, L.text, "%s = %s" % (L.pin["axis"], L.text)
                   if L.pin["axis"] in ("x", "y") else "the crossing"))

    def _emit_mark(self, s, T):
        lines, fills, opens, rings = s["geom"]
        w = s.get("width", 1.1)
        out = []
        for a, b in lines:
            a, b = T(a), T(b)
            out.append('<line x1="%.2f" y1="%.2f" x2="%.2f" y2="%.2f" '
                       'stroke="%s" stroke-width="%.2f" stroke-linecap="round"/>'
                       % (a[0], a[1], b[0], b[1], INK, w))
        for P in fills:
            out.append('<path d="M%s Z" fill="%s" stroke="%s" '
                       'stroke-width="0.60" stroke-linejoin="round"/>'
                       % (" L".join("%.2f,%.2f" % T(p) for p in P), INK, INK))
        for P in opens:
            out.append('<path d="M%s Z" fill="#fff" stroke="%s" '
                       'stroke-width="%.2f" stroke-linejoin="round"/>'
                       % (" L".join("%.2f,%.2f" % T(p) for p in P), INK, w))
        for c, r, how in rings:
            c = T(c)
            if how == "fill":
                out.append('<circle cx="%.2f" cy="%.2f" r="%.2f" fill="%s" '
                           'stroke="none"/>' % (c[0], c[1], r, INK))
            else:
                out.append('<circle cx="%.2f" cy="%.2f" r="%.2f" fill="#fff" '
                           'stroke="%s" stroke-width="%.2f"/>'
                           % (c[0], c[1], r, INK, w))
        return out


_SUP_RE = re.compile(r"\^\{([^}]*)\}|\^(\w)")


def _sup(text, size, floor=0.0):
    """Render `x^2` / `x^{10}` as a real raised run.

    A figure label could not carry an exponent at all: U+00B2 is absent from
    the bundled face (so writing it silently pulls another font and fails the
    font gate), and a label never goes through the HTML math emitter. Two
    packages dropped a formula from a caption because of this. `<tspan>` with
    a baseline shift costs nothing and keeps the label in David Libre.
    """
    out, i = [], 0
    for m in _SUP_RE.finditer(text):
        out.append(_esc(text[i:m.start()]))
        out.append('<tspan dy="%.2f" font-size="%s">%s</tspan>'
                   '<tspan dy="%.2f"></tspan>'
                   % (-size * 0.36, _fs(max(size * 0.72, floor)),
                      _esc(m.group(1) if m.group(1) is not None else m.group(2)),
                      size * 0.36))
        i = m.end()
    out.append(_esc(text[i:]))
    return "".join(out)


def _clip_out(a, b, boxes):
    """The pieces of segment a-b outside every box, for any slope."""
    spans = []
    dx, dy = b[0] - a[0], b[1] - a[1]
    for x0, y0, x1, y1 in boxes:
        t0, t1, ok = 0.0, 1.0, True
        for pk, qk in ((-dx, a[0] - x0), (dx, x1 - a[0]),
                       (-dy, a[1] - y0), (dy, y1 - a[1])):
            if abs(pk) < 1e-12:
                if qk < 0:
                    ok = False
                    break
            else:
                tt = qk / pk
                if pk < 0:
                    t0 = max(t0, tt)
                else:
                    t1 = min(t1, tt)
        if ok and t0 < t1:
            spans.append((t0, t1))
    if not spans:
        return [(a, b)]
    spans.sort()
    out, cur = [], 0.0
    for s, e in spans:
        if s > cur + 1e-9:
            out.append((cur, s))
        cur = max(cur, e)
    if cur < 1.0 - 1e-9:
        out.append((cur, 1.0))
    P = lambda k: (a[0] + dx * k, a[1] + dy * k)
    return [(P(s), P(e)) for s, e in out]


def _cut_segment(a, b, boxes):
    """Return the pieces of segment a-b that fall outside every box.

    Only axis-parallel segments are cut (the grid is exactly that); anything
    else is returned whole, because a slanted cut needs real clipping and a
    grid never asks for one."""
    horiz = abs(a[1] - b[1]) < 1e-6
    vert = abs(a[0] - b[0]) < 1e-6
    if not (horiz or vert):
        return [(a, b)]
    lo, hi = (min(a[0], b[0]), max(a[0], b[0])) if horiz else \
             (min(a[1], b[1]), max(a[1], b[1]))
    fixed = a[1] if horiz else a[0]
    cuts = []
    for x0, y0, x1, y1 in boxes:
        across = (y0 <= fixed <= y1) if horiz else (x0 <= fixed <= x1)
        if not across:
            continue
        c0, c1 = (x0, x1) if horiz else (y0, y1)
        if c1 > lo and c0 < hi:
            cuts.append((max(c0, lo), min(c1, hi)))
    if not cuts:
        return [(a, b)]
    cuts.sort()
    pieces, cur = [], lo
    for c0, c1 in cuts:
        if c0 > cur:
            pieces.append((cur, c0))
        cur = max(cur, c1)
    if cur < hi:
        pieces.append((cur, hi))
    if horiz:
        return [((s, fixed), (e, fixed)) for s, e in pieces]
    return [((fixed, s), (fixed, e)) for s, e in pieces]


def _esc(s):
    return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


# ======================================================================
#  BUILDERS — each computes coordinates FROM THE DATA, then re-measures.
# ======================================================================
def _fit_k(pts, target):
    """The factor `_fit` would scale this point list by: DRAWING units per
    DATA unit. A caller that has to judge a distance in PRINTED pt (doctrine
    6) needs it, because a builder's own frame is normalised (shapekit lays
    every polygon out on a unit side) and the printed size only exists after
    the fit and the display width."""
    xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
    span = max(max(xs) - min(xs), max(ys) - min(ys)) or 1.0
    return target / span


def _fit(pts, target):
    """Scale a point list so its longest extent is `target` units."""
    k = _fit_k(pts, target)
    return [(p[0] * k, p[1] * k) for p in pts]


def triangle(sides=None, angles=None, names="ABC", labels=None,
             right_angle=None, ticks=None, size=150, font=12, width=None,
             show_lengths=True, fam=None):
    """A triangle laid out from its OWN numbers.

        triangle(sides=(3, 4, 5), right_angle="B")
        triangle(sides=(6, 6, 8), ticks=[("A","B"),("B","C")])
        triangle(angles=(50, 60, 70))

    `sides` is (AB, BC, CA). The drawing is verified against them, so a
    3-4-5 never renders as 3-4-4.6.

    v6 C3 (E5): the marks are measured too. `right_angle` must name a vertex
    of 90 +- 0.5 degrees -- in a 3-4-5 with sides (AB, BC, CA) that is B, not
    A (this very docstring and SKILL.md once said "A" and "C", and the mark
    printed on 53.1 degrees). `ticks` pairs sharing the one tick count must be
    equal sides. `fam=` tags the figure (E10)."""
    if sides:
        c, a, b = float(sides[0]), float(sides[1]), float(sides[2])
        if c + a <= b or c + b <= a or a + b <= c:
            raise AssertionError(
                "figkit: sides %s cannot form a triangle — the sheet would "
                "pose a question with no answer" % (sides,))
        A = (0.0, 0.0)
        B = (c, 0.0)
        cosA = (b * b + c * c - a * a) / (2 * b * c)
        cosA = max(-1.0, min(1.0, cosA))
        C = (b * math.cos(math.acos(cosA)), -b * math.sin(math.acos(cosA)))
    elif angles:
        aA, aB = math.radians(angles[0]), math.radians(angles[1])
        if abs(sum(angles) - 180) > 1e-6:
            raise AssertionError("figkit: angles %s do not sum to 180" % (angles,))
        c = 1.0
        A, B = (0.0, 0.0), (c, 0.0)
        # intersection of the two rays
        k = c * math.sin(aB) / max(math.sin(math.pi - aA - aB), 1e-9)
        C = (k * math.cos(aA), -k * math.sin(aA))
    else:
        raise ValueError("triangle() needs sides= or angles=")

    A, B, C = _fit([A, B, C], size)
    poly = [A, B, C]
    f = Figure(width=width)
    f.poly(poly)
    if sides:
        f.expect_edges(poly, {0: sides[0], 1: sides[1], 2: sides[2]})

    labels = labels or {}
    for nm, v in zip(names, poly):
        f.vertex_label(v, labels.get(nm, nm), poly=poly, size=font)
    if sides and show_lengths:
        for i, (p, q) in enumerate(((A, B), (B, C), (C, A))):
            key = names[i] + names[(i + 1) % 3]
            txt = labels.get(key, _num(sides[i]))
            if txt:
                f.edge_label(p, q, txt, poly=poly, size=font)
    if right_angle:
        i = names.index(right_angle)
        v = poly[i]
        angs = [_angle_deg(poly[k], poly[(k + 1) % 3], poly[(k - 1) % 3])
                for k in range(3)]
        if abs(angs[i] - 90.0) > RIGHT_TOL:
            right = [names[k] for k in range(3) if abs(angs[k] - 90.0) <= RIGHT_TOL]
            raise AssertionError(
                "figkit.triangle: right_angle=%r, but angle %s = %.1f° (%s). "
                "%s -- a mark on a vertex that is not 90° tells the student a "
                "falsehood." % (
                    right_angle, right_angle, angs[i],
                    ", ".join("%s %.1f°" % (names[k], angs[k]) for k in range(3)),
                    ("With sides=(AB, BC, CA) the right angle is at %s: pass "
                     "right_angle=%r" % (right[0], right[0])) if right else
                    "This triangle has no right angle: correct the numbers or "
                    "drop right_angle="))
        f.right_angle(v, poly[(i + 1) % 3], poly[(i - 1) % 3])
    for pair in (ticks or []):
        i, j = names.index(pair[0]), names.index(pair[1])
        f.ticks(poly[i], poly[j], n=1)
    return f.render(width=width, fam=fam)


def rect(w, h, names="ABCD", labels=None, size=170, font=12, width=None,
         diagonal=None, show_lengths=True, fam=None):
    """Rectangle to scale: a 12x5 never renders square."""
    w, h = float(w), float(h)
    pts = _fit([(0, 0), (w, 0), (w, -h), (0, -h)], size)
    f = Figure(width=width)
    f.poly(pts)
    f.expect_edges(pts, {0: w, 1: h, 2: w, 3: h})
    labels = labels or {}
    for nm, v in zip(names, pts):
        f.vertex_label(v, labels.get(nm, nm), poly=pts, size=font)
    if show_lengths:
        f.edge_label(pts[0], pts[1], labels.get("w", _num(w)), poly=pts, size=font)
        f.edge_label(pts[1], pts[2], labels.get("h", _num(h)), poly=pts, size=font)
    for i in range(4):
        f.right_angle(pts[i], pts[(i + 1) % 4], pts[(i - 1) % 4], size=8)
    if diagonal:
        i, j = names.index(diagonal[0]), names.index(diagonal[1])
        f.line(pts[i], pts[j], 1.1, dash="4 3")
    return f.render(width=width, fam=fam)


def _num(v):
    """A tick or length as printed in a figure: `%g`, with U+2212 (E7)."""
    v = float(v)
    return svgcheck.true_minus("%g" % v)


def anchored_ticks(lo, hi, step):
    """v6 (E13): the multiples of `step` inside [lo, hi], anchored at 0.
    `range(lo, hi + 1, step)` anchored the step at the range's END, so
    step=2 on (-5, 5) numbered -5 -3 -1 1 3 5 and the origin fell between
    two numbers."""
    step = float(step)
    if step <= 0:
        raise AssertionError("figkit: step must be positive, got %g" % step)
    k0 = int(math.ceil(lo / step - 1e-9))
    k1 = int(math.floor(hi / step + 1e-9))
    return [_clean(k * step) for k in range(k0, k1 + 1)]


def _clean(v):
    r = round(v)
    return int(r) if abs(v - r) < 1e-9 else round(v, 9)


def assert_ticks_inside(axis, vals, lo, hi, where="figkit"):
    """P3 (L1-XTICKS-DROPPED): every value an author LISTS in xticks=/yticks=
    is printed, or the call is refused. A value outside the window has no
    tick to stand on, and the axis quietly printed fewer numbers than the
    author wrote -- rule 2 ("a number is NEVER deleted") broken by the very
    keyword that names the numbers. (The legacy `ticks=`, one list shared by
    two axes of different lengths, still clips: it was written to.)"""
    out = sorted(set(float(v) for v in (vals or ())
                     if not (lo - 1e-9 <= float(v) <= hi + 1e-9)))
    if out:
        wide = (min(lo, *out), max(hi, *out))
        raise AssertionError(
            "%s: %sticks=%s lists %s, outside the %s-range (%g, %g) -- there "
            "is no tick there, so the number would be dropped and the axis "
            "would print fewer numbers than you asked for (a number is never "
            "deleted). Widen the window to %sr=(%g, %g) so the value has a "
            "tick, or list only values inside it."
            % (where, axis, [float("%g" % float(v)) for v in (vals or ())],
               [float("%g" % v) for v in out], axis, lo, hi, axis,
               wide[0], wide[1]))


def assert_ticks_complete(axis, vals, lo, hi, where="figkit", sparse=False):
    """P3 leftovers r1 (P3-NATIVE-CP-DROPS-LISTED-TICK, minor): a list that is
    a REGULAR numbering with a hole prints an axis with a number missing.

    figkit_plus.plane has refused this since stage 1 (_assert_sparse_numbers /
    _assert_axis_numbers); the NATIVE coord_plane/axes path -- reachable
    through _probe=False and _ink= -- did not, so
    coord_plane((-6, 6), (-6, 6), step=1, xticks=[t for t in range(-6, 7)
    if t != -3], _probe=False) printed the x row without its -3, with no
    refusal and problems() == []. A DECLARED sparse axis is a different
    thing and keeps its own rule."""
    v = sorted(set(float(t) for t in (vals or ())
                   if lo - 1e-9 <= float(t) <= hi + 1e-9 and float(t) != 0.0))
    if sparse or len(v) < 2:
        return
    pts = sorted(set(v + [0.0]))
    d = min(b - a for a, b in zip(pts, pts[1:]))
    if d <= 1e-9:
        return
    want = [k * d for k in range(int(math.ceil(lo / d - 1e-9)),
                                 int(math.floor(hi / d + 1e-9)) + 1) if k != 0]
    # only a HOLE inside the stretch the author numbered: an axis numbered
    # 1, 2, 3 on (-1, 3) is a short numbering, not a numbering with a
    # number taken out of it (and the old builders draw those)
    miss = [w for w in want if all(abs(w - t) > 1e-6 for t in v)
            and min(v) < w < max(v)]
    if not miss or 2 * len(v) <= len(want):
        return
    raise AssertionError(
        "%s: %sticks=%s is a regular numbering every %g with %s left out -- "
        "an axis with a number deleted, not a numbering (a number is never "
        "deleted). List every value of the step (or leave %sticks= to the "
        "engine) and let the crowded number step aside; if the axis really "
        "is an 'infer the scale' one, declare it with sparse=True and list "
        "at most half the values."
        % (where, axis, [float("%g" % t) for t in v], d,
           [float("%g" % w) for w in miss], axis))


def assert_data_inside(where, xr, yr, points=(), polys=(), solid=(),
                       dashed=(), right=(), circles=()):
    """P3 (L1-CP-OUTSIDE-WINDOW): data outside the window is refused, not
    drawn past the axis arrow. figkit_plus.plane has always refused it; the
    native coord_plane/axes path (house=False, and the explicit-ink rungs)
    drew a point beyond the grid, off the numbered axes, where no value can
    be read -- and every independent sweep called the file clean."""
    (x_min, x_max), (y_min, y_max) = xr, yr

    def bad(p):
        return not (x_min - 1e-9 <= p[0] <= x_max + 1e-9 and
                    y_min - 1e-9 <= p[1] <= y_max + 1e-9)
    items = []
    for pt in points or ():
        p = pt[0] if isinstance(pt[0], (tuple, list)) else pt
        nm = pt[1] if len(pt) > 1 and pt[1] else None
        items.append(("point %s" % nm if nm else "point", p))
    for pts in polys or ():
        items += [("polygon vertex", p) for p in pts]
    for a, b in list(solid or ()) + list(dashed or ()):
        items += [("segment end", a), ("segment end", b)]
    for tri in right or ():
        items += [("right-angle mark", p) for p in tri]
    for c in circles or ():
        (cx, cy), r = c[0], c[1]
        items += [("circle rim", (cx - r, cy)), ("circle rim", (cx + r, cy)),
                  ("circle rim", (cx, cy - r)), ("circle rim", (cx, cy + r))]
    off = [(k, p) for k, p in items if bad(p)]
    if off:
        xs = [p[0] for _, p in items] or [x_min, x_max]
        ys = [p[1] for _, p in items] or [y_min, y_max]
        wx = (min(x_min, math.floor(min(xs))), max(x_max, math.ceil(max(xs))))
        wy = (min(y_min, math.floor(min(ys))), max(y_max, math.ceil(max(ys))))
        k, p = off[0]
        raise AssertionError(
            "%s: %s at (%g, %g) lies outside the window x (%g, %g), y (%g, "
            "%g) -- it would print beyond the grid, off the numbered axes, "
            "where no value can be read. Draw it inside a window that holds "
            "it, e.g. xr=(%g, %g), yr=(%g, %g); never move the data to fit "
            "the window.%s"
            % (where, k, p[0], p[1], x_min, x_max, y_min, y_max,
               wx[0], wx[1], wy[0], wy[1],
               "" if len(off) == 1 else " (%d more outside: %s)"
               % (len(off) - 1, ", ".join("(%g, %g)" % (q[0], q[1])
                                          for _, q in off[1:4]))))


def hide_sets(hide, where="figkit"):
    """`hide=[v, ('x', v), ('y', v)]` -> (x values, y values).

    P3 (the author's rule 2, 2026-09-16): an axis number is NEVER deleted, so
    hide= no longer blanks one — it is refused, and the refusal names the way
    to hide an answer that keeps the axis whole. hide= survived every earlier
    round as "a giveaway blanked, the axis still numbered regularly", and it
    kept being the one-token edit that turned a crowding refusal into a
    rendered figure with two numbers gone (C7r3-P3: the Q plane rendered with
    the x '2' AND the y '2' missing, and every sweep called it clean). An
    answer is hidden by NOT MARKING the point or the value; the numbers on
    the axes are the scale the reader needs to read everything else.

    Kept as a function (and still used by callers that must know an axis is
    fully numbered) so every entry point — axes, coord_plane, plane, wide —
    refuses in one place and with one wording."""
    hx, hy = set(), set()
    bad = []
    for h in hide or ():
        if isinstance(h, (tuple, list)):
            ax, v = h
            if ax not in ("x", "y"):
                raise AssertionError("figkit: hide=%r -- tag a value with 'x' "
                                     "or 'y', e.g. hide=[('x', 3)]" % (h,))
            (hx if ax == "x" else hy).add(float(v))
            bad.append("%s=%g" % (ax, float(v)))
        else:
            hx.add(float(h))
            hy.add(float(h))
            bad.append("%g on both axes" % float(h))
    if bad:
        raise AssertionError(
            "%s: hide=%s would print an axis without its number (%s). An axis "
            "number is NEVER deleted -- the numbering is the scale, and a "
            "reader who cannot read one tick cannot read the figure. Hide the "
            "ANSWER instead, by not marking it: on a PLANE, leave the point "
            "out of points=/dots= (or drop its letter), leave the dashed "
            "trace to it out of dashed=, and leave its number out of values=; "
            "on a NUMBER LINE, numberline.NL(...).point(v, value_label=False) "
            "and answer_hidden=. Either way, ask for the value in the Hebrew "
            "question text. If the number "
            "is in the way of ink, the fixes are room, not deletion: a wider "
            "figure (width=/max_width=), bigger squares (size=), a finer "
            "xscale=/yscale=, or a window that moves the crowding off the "
            "axis." % (where, bad, ", ".join(bad)))
    return hx, hy


def number_axes(f, X, Y, xr, yr, xt, yt, font, xmarks=None, ymarks=None,
                hide=(), origin=None, gap=2.0, tick_half=3.0, where="figkit",
                square=None, pitch=None, page=None, ghosts=None, ink=1.0):
    """v6 (E1/E6/E13): tick marks and PINNED tick numbers for a coordinate
    system whose axes cross at (X(0), Y(0)). Shared by `axes`, `coord_plane`
    and `figkit_plus.plane`, so the three cannot disagree.

    xt, yt        the numbered values (real units)
    xmarks/ymarks where tick marks go; default = the numbered values. A sparse
                  axis marks every step and numbers only a few (E13).
    hide          values whose tick keeps its mark but prints no number (E13):
                  a giveaway blanked, the axis still numbered regularly.
    origin        print '0' once, in a corner of the crossing (E6), when both
                  ranges hold 0 and 0 is not hidden. None (the default): only
                  when both axes print at least one number -- an axis with no
                  numbers needs no '0', and in the column of y numbers that
                  column did not have, the '0' widened the figure (a pilot
                  plane fell under the 10px square). True: always; False: never.
    square        the builder's grid square in figure units (its `size=`), so
                  a refusal can name the size= that parts a point from a
                  number.
    pitch         C2 round 3: the axes' regular tick spacing in figure units
                  (`step` squares), a number or an (x, y) pair. A number may
                  slide PIN_SLIDE x its tick spacing, and that spacing is never
                  taken wider than the pitch: with xticks=[6] alone the spacing
                  was the 6 squares from the origin, and a point beside the
                  tick pushed '6' 0.42 of a square onto the grid (it read 6.4).
    page          the widest the builder may print this figure (px), so a
                  refusal never names a stretch no page can hold.
    ghosts        C6 r4: (xvals, yvals) a SPARSE axis leaves unprinted -- the
                  numbers its regular numbering would print. Each is solved
                  with the printed numbers, as a hidden one is, so sparse=True
                  renders a figure only if the fully numbered figure renders:
                  it declares an "infer the scale" item, it is not a way past
                  a number a stroke is standing on."""
    hx, hy = hide_sets(hide, where)
    ox, oy = X(0), Y(0)
    (x_min, x_max), (y_min, y_max) = xr, yr

    def shown(vals, hid, lo, hi):
        return [t for t in vals if abs(t) > 1e-12 and lo - 1e-9 <= t <= hi + 1e-9
                and not any(abs(t - h) < 1e-9 for h in hid)]
    zero = x_min <= 0 <= x_max and y_min <= 0 <= y_max \
        and 0.0 not in hx and 0.0 not in hy
    if origin is None:
        origin = bool(shown(xt, hx, x_min, x_max) and shown(yt, hy, y_min, y_max))
    zero = zero and bool(origin)
    for axis, vals, hid, lo, hi in (("x", xt, hx, x_min, x_max),
                                    ("y", yt, hy, y_min, y_max)):
        bad = sorted(v for v in hid if v != 0 and
                     not any(abs(v - t) < 1e-9 for t in vals))
        if bad:
            raise AssertionError(
                "%s: hide=%s names no numbered %s-axis tick (numbers: %s). "
                "hide blanks a number the axis would print; it cannot add or "
                "move one." % (where, [float("%g" % v) for v in bad], axis,
                               [float("%g" % v) for v in vals]))
        # a printed '0' stands between -1 and 1: hiding both is two single
        # blanks, not a gap (C2 round 2)
        inside = sorted(t for t in vals if (t != 0 or zero)
                        and lo - 1e-9 <= t <= hi + 1e-9)
        if zero and 0 not in inside:
            inside = sorted(inside + [0])
        blank = [t != 0 and any(abs(t - h) < 1e-9 for h in hid) for t in inside]
        for i in range(1, len(inside)):
            if blank[i] and blank[i - 1]:
                raise AssertionError(
                    "%s: hide= blanks the neighbouring %s-axis numbers %g and "
                    "%g -- that is a gap, not one hidden value. Declare the "
                    "axis sparse=True and list the numbers it shows in %sticks="
                    % (where, axis, inside[i - 1], inside[i], axis))

    def spacing(marks, P):
        pos = sorted(set([P(0)] + [P(v) for v in marks]))
        d = [b - a for a, b in zip(pos, pos[1:]) if b - a > 1e-6]
        return min(d) if d else None

    xm = list(xt if xmarks is None else xmarks)
    ym = list(yt if ymarks is None else ymarks)
    # C6 r4: an unprinted (ghost) number measures its spacing like a printed
    # one; with ticks=False there are no marks, and a spacing of None gave the
    # ghosts an unbounded slide
    gx_, gy_ = ghosts if ghosts else ((), ())
    sx = spacing([v for v in list(xm) + list(gx_)
                  if x_min - 1e-9 <= v <= x_max + 1e-9], X)
    sy = spacing([v for v in list(ym) + list(gy_)
                  if y_min - 1e-9 <= v <= y_max + 1e-9], Y)
    if pitch is not None:
        px, py = pitch if isinstance(pitch, (tuple, list)) else (pitch, pitch)
        sx = min(sx, abs(px)) if sx and px else sx
        sy = min(sy, abs(py)) if sy and py else sy
    size = font * 0.92
    for gx in xm:
        if abs(gx) < 1e-12 or gx < x_min - 1e-9 or gx > x_max + 1e-9:
            continue
        f.line((X(gx), oy - tick_half), (X(gx), oy + tick_half), 1.0 * ink,
               role="tick")
    for gy in ym:
        if abs(gy) < 1e-12 or gy < y_min - 1e-9 or gy > y_max + 1e-9:
            continue
        f.line((ox - tick_half, Y(gy)), (ox + tick_half, Y(gy)), 1.0 * ink,
               role="tick")
    # v6 stage 1b r2: a number hide= blanks is still solved, as a PHANTOM --
    # see Figure.place (C6 r4). hide= blanks a giveaway; it may not be the
    # keyword that clears a collision by deleting the number.
    hidden = []

    def phantom(at, text, axis, spacing):
        L = Label(at, svgcheck.true_minus(text), size, False, None, "value",
                  max(gap, 0.0))
        L.phantom = True
        L.pin = dict(axis=axis, tick=tuple(at), half=float(tick_half),
                     side=(1 if axis == "x" else -1) if axis != "o" else (-1, 1),
                     spacing=spacing)
        hidden.append(L)
    for gx in xt:
        if abs(gx) < 1e-12 or gx < x_min - 1e-9 or gx > x_max + 1e-9:
            continue
        if any(abs(gx - h) < 1e-9 for h in hx):
            phantom((X(gx), oy), _num(gx), "x", sx)
            continue
        f.tick_label((X(gx), oy), _num(gx), axis="x", size=size, gap=gap,
                     spacing=sx, tick_half=tick_half)
    for gy in yt:
        if abs(gy) < 1e-12 or gy < y_min - 1e-9 or gy > y_max + 1e-9:
            continue
        if any(abs(gy - h) < 1e-9 for h in hy):
            phantom((ox, Y(gy)), _num(gy), "y", sy)
            continue
        f.tick_label((ox, Y(gy)), _num(gy), axis="y", size=size, gap=gap,
                     spacing=sy, tick_half=tick_half)
    for gx in gx_:
        if abs(gx) < 1e-12 or gx < x_min - 1e-9 or gx > x_max + 1e-9 or \
                any(abs(gx - t) < 1e-9 for t in xt):
            continue
        phantom((X(gx), oy), _num(gx), "x", sx)
    for gy in gy_:
        if abs(gy) < 1e-12 or gy < y_min - 1e-9 or gy > y_max + 1e-9 or \
                any(abs(gy - t) < 1e-9 for t in yt):
            continue
        phantom((ox, Y(gy)), _num(gy), "y", sy)
    if zero:
        f.origin_label((ox, oy), "0", size=size, gap=gap, tick_half=tick_half,
                       spacing=(sx, sy))
    elif x_min <= 0 <= x_max and y_min <= 0 <= y_max:
        phantom((ox, oy), "0", "o", (sx, sy))
    f.hidden_pins = list(getattr(f, "hidden_pins", [])) + hidden
    for L in list(f.labels) + hidden:
        if L.pin and square is not None:
            L.pin["square"] = square
        if L.pin and page is not None:
            L.pin["page"] = page
    return f


def _house_builder():
    """P1 r1: figkit_plus when the sheet prints the HOUSE look, else None.

    The author's rule (2026-09-17) is ONE printed look for every coordinate
    plane on a sheet: 8pt numbers, 1pt strokes, a visible grid, axis
    arrowheads. `axes()` and `coord_plane()` sized all of it by width /
    viewBox (a 400px coord_plane printed 20.4pt numbers, the default axes()
    7.59pt, no arrowheads), so a sheet using them beside plane() printed two
    looks. At the house look both are drawn BY figkit_plus.plane -- the same
    sizing, arrowheads, number rules and refusals; new_sheet(house=False)
    restores their v6.0 bodies below."""
    try:
        import figkit_plus as FP
    except ImportError:                          # pragma: no cover
        return None
    return FP if FP.SHEET.get("house") else None


def _via_plane(FP, where, kw):
    """Draw an old builder's call with figkit_plus.plane; a refusal names the
    builder the author called."""
    try:
        return FP.plane(**kw)
    except AssertionError as e:
        msg = str(e)
        if where == "figkit.axes":
            # P1 r2 (L3-05): axes() has no max_width=; the hint plane()
            # names for its own call ('width=None (drop width=130),
            # max_width=430') raised TypeError when copied. axes() draws at
            # the full-width cap by itself, so dropping width= is the call.
            msg = re.sub(r"(width=None \(drop width=[\d.]+\)), max_width=\d+",
                         r"\1", msg)
            msg = re.sub(r"(width=None \(drop width=[\d.]+\)), (size=\d+), "
                         r"max_width=\d+", r"\1, \2", msg)
        raise type(e)("%s (drawn at the house look by figkit_plus.plane): %s"
                      % (where, msg))


def axes(xr=(-5, 5), yr=(-5, 5), points=None, lines=None, step=1,
         size=26, font=11, width=None, grid=True, xlabel="x", ylabel="y",
         xticks=None, yticks=None, hide=(), sparse=False, origin=None,
         fam=None):
    """A coordinate system whose axes CARRY NUMBERS.

    The audit found 19 sheets asking the student to read a value off a graph
    that had no numbers on either axis, and several whose grid squares were
    not square (ratios up to 2.9:1), so a slope could not be read. Both are
    impossible here: one `size` drives both axes, and every tick is printed.

    v6: tick numbers are pinned to their ticks (E1), '0' is printed once at
    the origin (E6), `step` is anchored at 0 and `xticks`/`yticks` number the
    two axes independently; `sparse=True` marks every step but numbers only
    the listed values; `hide=` is GONE (P3) -- every call RAISES, an axis
    number is never deleted.
    v6 C3: points=[((x, y), "A", style)] draws a marker (E8: "filled", "open",
    "tri", "square", "cross"); `fam=` tags the figure (E10)."""
    x_min, x_max = xr
    y_min, y_max = yr
    if sparse and xticks is None and yticks is None:
        raise AssertionError(
            "figkit.axes: sparse=True numbers only the values you list -- "
            "pass xticks=[...] and/or yticks=[...]")
    FP = _house_builder()
    if FP is not None:
        pts, dts = [], []
        for pt in (points or []):
            name = pt[1] if len(pt) > 1 else None
            style = pt[2] if len(pt) > 2 else None
            if name:
                pts.append((pt[0], name, style) if style else (pt[0], name))
            else:
                dts.append((pt[0], style) if style else pt[0])
        sol, lab = [], []
        for ln in (lines or []):
            (p, q) = ln[:2]
            sol.append((p, q))
            if len(ln) > 2 and ln[2]:
                lab.append((((p[0] + q[0]) / 2.0, (p[1] + q[1]) / 2.0), ln[2]))
        # axes() drew at its viewBox width, uncapped: the full-width cap
        return _via_plane(FP, "figkit.axes", dict(
            xr=xr, yr=yr, points=pts, dots=dts, solid=sol, labels=lab,
            step=step, size=size, font=font, width=width,
            max_width=FP.WIDE_MAX, grid=grid, axis_labels=(xlabel, ylabel),
            xticks=xticks, yticks=yticks, hide=hide, sparse=sparse,
            origin=origin, fam=fam))
    f = Figure(width=width)
    X = lambda v: v * size
    Y = lambda v: -v * size
    if grid:
        for gx in range(int(math.ceil(x_min)), int(math.floor(x_max)) + 1):
            f.line((X(gx), Y(y_min)), (X(gx), Y(y_max)), 0.4,
                   record=False, colour=GRID)
        for gy in range(int(math.ceil(y_min)), int(math.floor(y_max)) + 1):
            f.line((X(x_min), Y(gy)), (X(x_max), Y(gy)), 0.4,
                   record=False, colour=GRID)
    # The axis overhangs its last tick. Without it the end tick sits at the
    # very tip of the line, the solver cannot find room beneath it, and the
    # label slides up to axis height where `5` ends up touching `x`.
    over = size * 0.55
    f.line((X(x_min) - over, 0), (X(x_max) + over, 0), 1.4, role="axis",
           name="axis-x")
    f.line((0, Y(y_min) + over), (0, Y(y_max) - over), 1.4, role="axis",
           name="axis-y")
    f.label((X(x_max) + over, 0), xlabel, size=font, italic=True,
            prefer=(1, -0.6), gap=3.0)
    f.label((0, Y(y_max) - over), ylabel, size=font, italic=True,
            prefer=(-0.6, -1), gap=3.0)
    reg_x, reg_y = anchored_ticks(x_min, x_max, step), \
        anchored_ticks(y_min, y_max, step)
    xt = list(xticks) if xticks is not None else reg_x
    yt = list(yticks) if yticks is not None else reg_y
    # P3: a listed number is printed or refused; data stays inside the window
    if xticks is not None:
        assert_ticks_inside("x", xticks, x_min, x_max, "figkit.axes")
        assert_ticks_complete("x", xticks, x_min, x_max, "figkit.axes",
                              sparse)
    if yticks is not None:
        assert_ticks_inside("y", yticks, y_min, y_max, "figkit.axes")
        assert_ticks_complete("y", yticks, y_min, y_max, "figkit.axes",
                              sparse)
    assert_data_inside("figkit.axes", xr, yr, points=points or (),
                       solid=[ln[:2] for ln in (lines or [])])
    number_axes(f, X, Y, xr, yr, xt, yt, font,
                xmarks=reg_x if sparse and xticks is not None else None,
                ymarks=reg_y if sparse and yticks is not None else None,
                hide=hide, origin=origin, where="figkit.axes",
                ghosts=(reg_x if sparse and xticks is not None else (),
                        reg_y if sparse and yticks is not None else ()),
                square=size, pitch=abs(X(step) - X(0)),
                page=width or 430.0)
    for ln in (lines or []):
        (p, q) = ln[:2]
        f.line((X(p[0]), Y(p[1])), (X(q[0]), Y(q[1])), 1.6)
        if len(ln) > 2 and ln[2]:
            f.label((X((p[0] + q[0]) / 2.0), Y((p[1] + q[1]) / 2.0)), ln[2],
                    size=font, italic=True)
    for pt in (points or []):
        (v, name) = pt[0], (pt[1] if len(pt) > 1 else None)
        if len(pt) > 2 and pt[2]:
            f.marker((X(v[0]), Y(v[1])), pt[2])        # v6 C3 (E8)
        else:
            f.dot((X(v[0]), Y(v[1])))
        if name:
            f.label((X(v[0]), Y(v[1])), name, size=font)
    return f.render(width=width, fam=fam)


COORD_SIZES = (16, 18, 20, 22, 24, 26, 28, 30, 32)   # coord_plane's own ladder


def _layout_refusal(e):
    """A refusal a different size could cure (see svgcheck.LayoutError)."""
    return isinstance(e, svgcheck.LayoutError) or \
        "Do NOT drop the number" in str(e)


def _coord_probe(draw, sizes, page, knob):
    """C7P-02 (author pressure): what a refusal about room may say about
    larger squares, TRIED: the first of `sizes` that renders is named, with
    how big its squares print; else that none does at this width. The ladder
    used to say 'a wider figure or fewer squares' while size=40 rendered +-8
    at the same width, and an explicit size=34 named 'a larger size=' with no
    hint how large."""
    for z in sizes:
        try:
            svg = draw(z)
        except AssertionError as e:
            if not _layout_refusal(e):
                return "", None
            continue
        w = re.search(r'<svg[^>]*\bwidth="([\d.]+)"', svg)
        vb = re.search(r'viewBox="[-\d.]+ [-\d.]+ ([\d.]+)', svg)
        sq = ""
        if w and vb:
            sq = ", squares printing %.1f mm" % (
                z * float(w.group(1)) / float(vb.group(1)) * 25.4 / 96.0)
        return ("\nTried larger squares: size=%d renders within %s=%g%s."
                % (z, knob, page, sq)), z
    return ("\nTried larger squares: none of size=%s renders within %s=%g "
            "either -- widen the figure (width=) or number every 2 "
            "squares (step=2)."
            % ("/".join(str(z) for z in sizes), knob, page)), None


def _larger_size(msg, z):
    """The refusal's 'a larger size=' made true: the size that renders, or
    the phrase removed when none does (C7P-02, author pressure)."""
    if z is not None:
        return re.sub(r"a larger size=", "size=%d" % z, msg)
    # C7P2-05 / P2-05: every list shape the refusals use, so no list is left
    # with an empty slot ('give the number room:  or a wider figure')
    msg = re.sub(r"a larger size=( \([^)]*\))?(, | or )", "", msg)
    msg = re.sub(r"(,? or |, )a larger size=( \([^)]*\))?", "", msg)
    msg = re.sub(r"a larger size=( \([^)]*\))?", "", msg)
    msg = re.sub(r":\s+(or |, )", ": ", msg)
    msg = re.sub(r"\(\s*(or |, )", "(", msg)
    msg = re.sub(r"  +", " ", msg)
    return msg


def coord_plane(xr, yr, polys=(), dashed=(), solid=(), points=(), right=(),
                step=2, size=None, font=12, width=None, grid=True, ticks=None,
                max_width=210.0, xticks=None, yticks=None, hide=(),
                sparse=False, origin=None, fam=None, _ink=None, _probe=True):
    """A coordinate plane with SHAPES ON IT, drawn from the coordinates.

    v5.2. `axes()` plots points and lines; an analytic-geometry sheet needs a
    polygon, a dashed diagonal or altitude, a right-angle mark and a labelled
    extra point — and the package that rebuilt three such sheets wrote its own
    helper to get them, which is exactly the "package-local helper outside
    figkit" this file warns about. So it lives here now, on Figure: every
    stroke is registered, every label is solved, the proportions are true by
    construction (one `size` drives both axes) and the font floor is measured.

        coord_plane((0, 11), (0, 5),
                    polys=[[(1, 1), (6, 1), (10, 4), (5, 4)]],
                    dashed=[((1, 1), (10, 4)), ((6, 1), (5, 4))],
                    points=[((1, 1), "A"), ((6, 1), "B"),
                            ((10, 4), "C"), ((5, 4), "D"), ((5.5, 2.5), "O")])
        coord_plane((0, 7), (0, 9), polys=[[(0, 0), (6, 0), (0, 8)]],
                    right=[((0, 0), (6, 0), (0, 8))],
                    dashed=[((0, 0), (3.84, 2.88))],
                    points=[((0, 0), "K"), ((6, 0), "L"), ((0, 8), "M"),
                            ((3.84, 2.88), "N")])

    xr, yr    integer ranges of the axes (ticks every `step`, anchored at 0)
    ticks     one explicit list for BOTH axes (kept for old calls);
    xticks /
    yticks    v6 (E13): each axis's own list, overriding `ticks`
    sparse    v6: mark every `step`, number only the listed values (an
              "infer the scale" item); needs xticks= or yticks=
    hide      GONE (P3, the author's rule 2): every call RAISES. An axis
              number is never deleted. Hide the ANSWER by not marking it
              (the point out of points=/dots=, its trace out of dashed=,
              its number out of values=) and ask for it in the Hebrew
              text. Kept only so an old call fails loudly.
    origin    v6 (E6): print '0' once, below-left of the origin
    polys     closed shapes, each a list of (x, y)
    solid     extra solid segments (p, q); dashed — dashed ones (diagonals,
              altitudes, medians); right — (vertex, to1, to2) right-angle marks
              (v6 C3, E5: measured, 90 +- 0.5 degrees or refused)
    points    ((x, y), "A") — a dot, and a label the solver places; a point
              that is a vertex of a polygon is labelled AWAY from the shape;
              ((x, y), "A", style) a marker (v6 C3, E8)
    fam       v6 C3 (E10): tag the figure (figkit.tag)
    size      figure units per square. None (the default) is 16, and when the
              numbers have no room at 16 the engine tries 18 ... 32 inside the
              same width before refusing; an explicit size= is drawn as given
    width     display width in px. None = the viewBox width, capped at
              `max_width` so the drawing sits beside the text (SIDE_MAX);
              when a wide range must shrink to fit, the labels are enlarged
              FIRST so every tick number still clears the 7pt floor.
    """
    FP = _house_builder() if (_probe and _ink is None) else None
    if FP is not None:
        if sparse and xticks is None and yticks is None:
            raise AssertionError(
                "figkit.coord_plane: sparse=True numbers only the values you "
                "list -- pass xticks=[...] and/or yticks=[...]")
        return _via_plane(FP, "figkit.coord_plane", dict(
            xr=xr, yr=yr, polys=polys, dashed=dashed, solid=solid,
            points=points, right=right, step=step,
            size=16 if size is None else size, font=font, width=width,
            max_width=max_width, grid=grid,
            # P3: the legacy `ticks=`, ONE list for two axes of different
            # lengths, was written to be clipped per axis; it is clipped here
            # so the strict "a listed number is printed" rule can hold for
            # the per-axis xticks=/yticks= the author writes today
            xticks=(xticks if xticks is not None else
                    ([t for t in ticks if xr[0] - 1e-9 <= t <= xr[1] + 1e-9]
                     if ticks else None)),
            yticks=(yticks if yticks is not None else
                    ([t for t in ticks if yr[0] - 1e-9 <= t <= yr[1] + 1e-9]
                     if ticks else None)),
            hide=hide, sparse=sparse, origin=origin, fam=fam))
    if size is None:
        # Stage-1 open issue (C2 E6-default-refused-range6): a four-quadrant
        # plane of +-6 to +-8 at the default size was refused on the '-1'/'-1'
        # collision at the origin, although size=17 or more printed it at the
        # same width. When the caller leaves size= to the engine, the engine
        # turns that knob itself -- the squares grow inside the same width,
        # the numbers keep their size -- before refusing. An explicit size= is
        # honoured as given.
        first, tried = None, []
        for sz in COORD_SIZES:
            tried.append(sz)
            try:
                return coord_plane(xr, yr, polys, dashed, solid, points, right,
                                   step, sz, font, width, grid, ticks,
                                   max_width, xticks, yticks, hide, sparse,
                                   origin, fam, _probe=False)
            except AssertionError as e:
                if not _layout_refusal(e):
                    if first is None:
                        raise
                    continue
                first = first or e
        tail, z = _coord_probe(lambda z: coord_plane(
            xr, yr, polys, dashed, solid, points, right, step, z, font,
            width, grid, ticks, max_width, xticks, yticks, hide, sparse,
            origin, fam, _probe=False), (40, 48, 64, 96),
            width or max_width, "width" if width else "max_width")
        raise type(first)(
            "%s\nfigkit.coord_plane already tried size=%s within %s=%g and "
            "did not find room -- a wider figure (width=) or step=2.%s"
            % (_larger_size(str(first), z), "/".join(str(z) for z in tried),
               "width" if width else "max_width", width or max_width, tail))
    if _probe:
        # C7P-02 (author pressure): an explicit size= refused on room named 'a
        # larger size=' with no hint how large; the sizes that render are
        # tried, and named -- or the refusal says none does at this width
        try:
            return coord_plane(xr, yr, polys, dashed, solid, points, right,
                               step, size, font, width, grid, ticks, max_width,
                               xticks, yticks, hide, sparse, origin, fam,
                               _ink=_ink, _probe=False)
        except AssertionError as e:
            if not _layout_refusal(e):
                raise
            big = sorted(set(int(z) for z in (size * 1.25, size * 1.5, size * 2,
                                               size * 3) if z <= 120))
            tail, z = _coord_probe(lambda z: coord_plane(
                xr, yr, polys, dashed, solid, points, right, step, z, font,
                width, grid, ticks, max_width, xticks, yticks, hide, sparse,
                origin, fam, _probe=False), big, width or max_width,
                "width" if width else "max_width")
            raise type(e)("%s%s" % (_larger_size(str(e), z), tail))
    x_min, x_max = xr
    y_min, y_max = yr
    # P3 (L1-CP-OUTSIDE-WINDOW): the drawing is refused, never drawn past the
    # axis arrow -- the same rule figkit_plus.plane has always applied
    assert_data_inside("figkit.coord_plane", xr, yr, points=points,
                       polys=polys, solid=solid, dashed=dashed, right=right)
    if sparse and xticks is None and yticks is None:
        raise AssertionError(
            "figkit.coord_plane: sparse=True numbers only the values you "
            "list -- pass xticks=[...] and/or yticks=[...]")
    est = (x_max - x_min + 1.1) * size + 2 * 9 + 16
    if width is None and est > max_width:
        s = max_width / est
        need = MIN_PT / (_PX_TO_PT * s * 0.92) * 1.05
        font = max(font, need)
    if _ink is None:
        # C7P-02: squares larger than 16 inside the same width shrink the
        # display scale, and every stroke, tick mark and dot with it -- the
        # size ladder printed +-7 with 0.47pt edges, a 0.13pt grid and
        # r=0.81pt dots, half the ink of +-5 on the same sheet. The ink grows
        # with the squares, so it prints as heavy as the size-16 drawing of
        # this window at this width would (never lighter; a figure that is not
        # shrunk, or is drawn at size <= 16, is unchanged).
        page = float(width) if width else max_width
        est16 = (x_max - x_min + 1.1) * 16 + 2 * 9 + 16
        s_now = min(1.0, page / est) if width is None else page / est
        s_16 = min(1.0, page / est16) if width is None else page / est16
        _ink = max(1.0, s_16 / s_now)
    f = Figure(width=width)
    X = lambda v: v * size
    Y = lambda v: -v * size
    P = lambda p: (X(p[0]), Y(p[1]))
    if grid:
        for gx in range(int(math.ceil(x_min)), int(math.floor(x_max)) + 1):
            f.line((X(gx), Y(y_min)), (X(gx), Y(y_max)), 0.4 * _ink,
                   record=False, colour=GRID)
        for gy in range(int(math.ceil(y_min)), int(math.floor(y_max)) + 1):
            f.line((X(x_min), Y(gy)), (X(x_max), Y(gy)), 0.4 * _ink,
                   record=False, colour=GRID)
    over = size * 0.55
    f.line((X(x_min) - over, 0), (X(x_max) + over, 0), 1.4 * _ink,
           role="axis", name="axis-x")
    f.line((0, Y(y_min) + over), (0, Y(y_max) - over), 1.4 * _ink,
           role="axis", name="axis-y")
    f.label((X(x_max) + over, 0), "x", size=font, italic=True,
            prefer=(1, -0.6), gap=3.0)
    f.label((0, Y(y_max) - over), "y", size=font, italic=True,
            prefer=(-0.6, -1), gap=3.0)
    reg_x, reg_y = anchored_ticks(x_min, x_max, step), \
        anchored_ticks(y_min, y_max, step)
    xt = list(xticks) if xticks is not None else (list(ticks) if ticks
                                                  else reg_x)
    yt = list(yticks) if yticks is not None else (list(ticks) if ticks
                                                  else reg_y)
    # P3 (L1-XTICKS-DROPPED): a value the author listed is printed or refused
    if xticks is not None:
        assert_ticks_inside("x", xticks, x_min, x_max, "figkit.coord_plane")
        assert_ticks_complete("x", xticks, x_min, x_max, "figkit.coord_plane",
                              sparse)
    if yticks is not None:
        assert_ticks_inside("y", yticks, y_min, y_max, "figkit.coord_plane")
        assert_ticks_complete("y", yticks, y_min, y_max, "figkit.coord_plane",
                              sparse)
    number_axes(f, X, Y, xr, yr, xt, yt, font,
                xmarks=reg_x if sparse and xticks is not None else None,
                ymarks=reg_y if sparse and yticks is not None else None,
                hide=hide, origin=origin, where="figkit.coord_plane",
                ghosts=(reg_x if sparse and xticks is not None else (),
                        reg_y if sparse and yticks is not None else ()),
                square=size, pitch=abs(X(step) - X(0)),
                page=width or max_width, ink=_ink,
                # P2-03: the tick marks' LENGTH grows with the ink too (a ±6
                # plane at size=30 printed 2.3pt ticks against 3.7pt) -- by
                # the square root: grown in full, every number stood 1.5 units
                # further out and 8 of 38 random ±7 triangles that render
                # were refused; at the root none is. The gap keeps the digits
                # clear of the tick's thicker end.
                tick_half=3.0 * _ink ** 0.5, gap=1.5 + 0.5 * _ink)
    shapes = []
    for pts in polys:
        sp = [P(p) for p in pts]
        f.poly(sp, width=1.6 * _ink)
        shapes.append(sp)
    for a, b in solid:
        f.line(P(a), P(b), 1.4 * _ink)
    for a, b in dashed:
        f.line(P(a), P(b), 1.2 * _ink, dash="%g,%g" % (4 * _ink, 3 * _ink))
    for v, a, b in right:
        ang = _angle_deg(P(v), P(a), P(b))
        if abs(ang - 90.0) > RIGHT_TOL:
            raise AssertionError(
                "figkit.coord_plane: right=[(%s, %s, %s)] marks an angle of "
                "%.1f° -- a right-angle mark claims 90° (± %.1f°). Name the "
                "vertex whose angle is 90° first, or correct the coordinates."
                % (v, a, b, ang, RIGHT_TOL))
        f.right_angle(P(v), P(a), P(b), size=size * 0.36)
    for pt in points:
        v, name = pt[0], (pt[1] if len(pt) > 1 else None)
        if len(pt) > 2 and pt[2]:
            # v6 C3 (E8); P2-03: its outline scales with the rest of the ink
            f.marker(P(v), pt[2], width=1.2 * _ink)
        else:
            f.dot(P(v), r=2.4 * _ink)
        if not name:
            continue
        owner = None
        for sp in shapes:
            if any(_dist(P(v), q) < 1e-6 for q in sp):
                owner = sp
                break
        if owner:
            f.vertex_label(P(v), name, poly=owner, size=font)
        else:
            f.label(P(v), name, size=font, kind="vertex")
    svg = f.render(width=width, fam=fam)
    if width is None:
        m = re.search(r'<svg[^>]*\bwidth="([\d.]+)', svg)
        if m and float(m.group(1)) > max_width:
            svg = f.render(width=max_width, fam=fam)
    return svg


_POLY_PTS_RE = re.compile(r'<polygon[^>]*\bpoints="([^"]+)"')
# v6.13 integ: an arrowhead of the wspec family engines -- an axis head
# (wspec-coord-svg/1 <polygon data-arrow="x">, wspec-nl-svg/1 <polygon
# data-nl="arrow">) or the head of a number line's jump arc (data-nl=
# "jump-head"; the arc itself stays a stroke of the key)
_ENGINE_HEAD_RE = re.compile(
    r'<polygon\b[^>]*\b(?:data-arrow="[xy]"|data-nl="(?:arrow|jump-head)")'
    r'[^>]*>')


def figure_family(svg):
    """The OBJECT a figure draws — a key that ignores labels, dashed
    additions, where the viewBox happened to start and (v6 C3) how big the
    figure was drawn (v5.2, G75).

    Two drawings of the same rhombus, one with a diagonal added, are one
    family; a rhombus and a trapezoid are two. A figure built from polygons
    is keyed by its polygons, translated to the origin, scaled to a unit
    extent and rounded; a shaded region (a light fill with no outline) is not
    an object. A figure with no polygon -- a number line, a plane of points,
    a circle -- is keyed by its solid dark strokes (a dashed guide is an
    addition, not a new object), its DOTS and MARKERS (filled and open told
    apart) and its CIRCLES, normalised the same way: on those figures the
    points are the content.

    v6 C3 (E10) repros this fixes: two different circles on the same axes
    shared a key (the rim was never read), six number lines with different
    marks were one family, a triangle drawn larger was a new object, and a
    shaded copy of a polygon was another. Family counts are what G75 and G76
    use to insist that a sheet shows more than one object; a builder that
    knows what it drew declares it with `fam=` (figkit.tag), which
    gate_variety.figure_family_plus reads first.

    C3 round 2: a figure with no polygon is scale-invariant too. Tick marks,
    axis overshoot, arrowheads and marker radii are drawn in fixed units, so
    the key is framed by what scales -- the midpoints of ticks on their
    lines, the points, the circles -- long strokes are clipped to that frame,
    ticks are keyed by their midpoints, other ornaments (arrowhead barbs,
    right-angle marks) by count, and a small marker by its style and centre.
    A light-filled polygon whose outline one dark element traces (an edge
    cut behind a number) is still a shape, not shading."""
    svg = _FAM_TAG_RE.sub("", svgcheck.strip_copies(svg))
    # v6.13 integ (t01_b D2): the wspec FAMILY engines draw an axis head as
    # a filled <polygon> (coordinate plane: data-arrow="x|y"; number line:
    # data-nl="arrow"). It is an ornament, like the builder's filled <path>
    # head below -- counted, never the figure's shape: keyed as a polygon it
    # made every engine number line (and every engine plane without a data
    # polygon) ONE object, and G76 refused a sheet of different lines.
    eng_heads = _ENGINE_HEAD_RE.findall(svg)
    svg = _ENGINE_HEAD_RE.sub("", svg)
    polys = []
    for m in re.finditer(r"<polygon\b([^>]*)>", svg):
        a = m.group(1)
        pm = re.search(r'\bpoints="([^"]+)"', a)
        if not pm:
            continue
        fm = re.search(r'\bfill="([^"]*)"', a)
        sm = re.search(r'\bstroke="([^"]*)"', a)
        fill = fm.group(1) if fm else None
        stroke = sm.group(1) if sm else None
        pts = [tuple(float(v) for v in p.split(","))
               for p in pm.group(1).replace("\n", " ").split() if "," in p]
        if (stroke is None or stroke.strip().lower() == "none") and fill and \
                fill.strip().lower() != "none" and not svgcheck._dark(fill) \
                and not _outlined(svg, pts):
            continue                                  # shading, not a shape
        if len(pts) >= 3:
            polys.append(pts)
    if polys:
        allp = [p for P in polys for p in P]
        x0 = min(p[0] for p in allp)
        y0 = min(p[1] for p in allp)
        ext = max(max(p[0] for p in allp) - x0,
                  max(p[1] for p in allp) - y0) or 1.0
        return ("poly",) + tuple(sorted(set(
            tuple(sorted((round((p[0] - x0) / ext, 3), round((p[1] - y0) / ext, 3))
                         for p in P)) for P in polys)))
    solid = re.sub(r"<(?:line|path|polyline)\b[^>]*stroke-dasharray[^>]*>", "", svg)
    spots = []
    heads = len(eng_heads)
    # small closed white-filled paths are markers (tri, square), not strokes
    for m in re.finditer(r"<path\b([^>]*)>", solid):
        a = m.group(1)
        fm = re.search(r'\bfill="([^"]*)"', a)
        dm = re.search(r'\bd="([^"]+)"', a)
        if fm and dm and svgcheck._dark(fm.group(1)) and \
                "z" in dm.group(1).lower():
            # P1: a small FILLED closed path is an arrowhead (plane's axis
            # arrowheads print at a fixed pt): an ornament, counted -- its
            # base edge standing on the axis was read as a tick and moved
            # the frame with the figure's size
            nums = [float(x) for x in re.findall(r"-?\d+\.?\d*", dm.group(1))]
            xs_, ys_ = nums[0::2], nums[1::2]
            if xs_ and max(max(xs_) - min(xs_), max(ys_) - min(ys_)) <= 32.0:
                heads += 1
                solid = solid.replace(m.group(0), "")
                continue
        if not fm or not dm or fm.group(1).strip().lower() in ("none", "") or \
                svgcheck._dark(fm.group(1)) or "z" not in dm.group(1).lower():
            continue
        nums = [float(x) for x in re.findall(r"-?\d+\.?\d*", dm.group(1))]
        pts = list(zip(nums[0::2], nums[1::2]))
        if len(pts) < 3:
            continue
        xs_, ys_ = [p[0] for p in pts], [p[1] for p in pts]
        if max(max(xs_) - min(xs_), max(ys_) - min(ys_)) > 32.0:
            continue
        if _dist(pts[0], pts[-1]) < 0.05:
            pts = pts[:-1]
        spots.append(("t%d" % len(pts), sum(xs_[:len(pts)]) / len(pts),
                      sum(ys_[:len(pts)]) / len(pts), None))   # vertex mean
        solid = solid.replace(m.group(0), "")
    segs = [(a, b) for a, b in _svg_segments(solid) if _dist(a, b) > 1e-9]
    for m in re.finditer(r"<circle\b([^>]*)>", svg):
        a = m.group(1)
        v = dict(re.findall(r'\b(cx|cy|r)="([-\d.]+)"', a))
        if "r" not in v:
            continue
        cx, cy, r = float(v.get("cx", 0)), float(v.get("cy", 0)), float(v["r"])
        fm = re.search(r'\bfill="([^"]*)"', a)
        sm = re.search(r'\bstroke="([^"]*)"', a)
        fill = fm.group(1) if fm else None
        stroke = sm.group(1) if sm else None
        if svgcheck._dark(fill):
            spots.append(("d", cx, cy, None))
        elif stroke and svgcheck._dark(stroke):
            open_mark = fill and fill.strip().lower() != "none" and r <= 16.0
            spots.append(("o", cx, cy, None) if open_mark else ("c", cx, cy, r))
    if not segs and not spots:
        return ("none", svg.strip())
    # a cross marker: two short strokes of the same length crossing SQUARE at
    # their common midpoint.
    # v6 P2 r2 (P2-L2-r2-01): 'same length, same midpoint' alone also paired a
    # tick with one arm of the cross standing on it -- a cross the size of the
    # ticks was read as three crosses and ate its tick, so the family key moved
    # with the figure's size. Two strokes are one marker only if they are
    # perpendicular (a tick meets an arm at 45 degrees), and each stroke joins
    # at most one marker.
    mid = lambda a, b: ((a[0] + b[0]) / 2.0, (a[1] + b[1]) / 2.0)
    ang = lambda a, b: math.degrees(math.atan2(b[1] - a[1], b[0] - a[0])) % 180.0
    crossed = set()
    for i in range(len(segs)):
        if i in crossed:
            continue
        for j in range(i + 1, len(segs)):
            if j in crossed:
                continue
            (a, b), (c, d) = segs[i], segs[j]
            turn = abs(ang(a, b) - ang(c, d))
            turn = min(turn, 180.0 - turn)
            if max(_dist(a, b), _dist(c, d)) <= 32.0 and \
                    _dist(mid(a, b), mid(c, d)) < 0.3 and \
                    abs(_dist(a, b) - _dist(c, d)) < 0.1 * _dist(a, b) and \
                    abs(turn - 90.0) <= 15.0:
                crossed.update((i, j))
                spots.append(("x",) + mid(a, b) + (None,))
                break
    segs = [sg for k, sg in enumerate(segs) if k not in crossed]
    # ornaments: short strokes (fixed units) standing on a longer stroke
    ticks, orn, longs = [], heads, []
    for i, (a, b) in enumerate(segs):
        L = _dist(a, b)
        host = [(c, d) for j, (c, d) in enumerate(segs)
                if j != i and _dist(c, d) >= 2.0 * L] if L <= 30.0 else []
        m_ = mid(a, b)
        if any(svgcheck._pt_seg(m_, c, d) < 0.8 for c, d in host):
            ticks.append(m_)
        elif any(svgcheck._pt_seg(e, c, d) < 0.8 for c, d in host for e in (a, b)):
            orn += 1
        else:
            longs.append((a, b))
    anchors = list(ticks) + [(cx, cy) for _, cx, cy, _ in spots]
    for k, cx, cy, r in spots:
        if r:
            anchors += [(cx - r, cy - r), (cx + r, cy + r)]
    if len(anchors) < 2 or max(
            max(p[0] for p in anchors) - min(p[0] for p in anchors),
            max(p[1] for p in anchors) - min(p[1] for p in anchors)) < 1e-6:
        anchors += [p for ab in longs for p in ab]
    if not anchors:
        anchors = [p for ab in segs for p in ab]
    xs = [p[0] for p in anchors]
    ys = [p[1] for p in anchors]
    x0, y0 = min(xs), min(ys)
    ext = max(max(xs) - x0, max(ys) - y0) or 1.0
    box = (x0 - 0.03 * ext, y0 - 0.03 * ext, max(xs) + 0.03 * ext,
           max(ys) + 0.03 * ext)
    N = lambda x, y: (round((x - x0) / ext, 3), round((y - y0) / ext, 3))
    norm = set()
    for a, b in longs:
        c = _clip_seg(a, b, box)
        if c:
            norm.add(tuple(sorted((N(*c[0]), N(*c[1])))))
    key = ("segs",) + tuple(sorted(norm))
    if ticks or orn:
        key += (("marks", orn) + tuple(sorted(set(N(*t) for t in ticks))),)
    if spots:
        key += (("spots",) + tuple(sorted(
            (k,) + N(cx, cy) + ((round(r / ext, 3),) if r else ())
            for k, cx, cy, r in spots)),)
    return key


def _clip_seg(a, b, box):
    """Segment a-b clipped to box (x0, y0, x1, y1) (Liang-Barsky), or None."""
    t0, t1 = 0.0, 1.0
    dx, dy = b[0] - a[0], b[1] - a[1]
    for p, q in ((-dx, a[0] - box[0]), (dx, box[2] - a[0]),
                 (-dy, a[1] - box[1]), (dy, box[3] - a[1])):
        if abs(p) < 1e-12:
            if q < 0:
                return None
            continue
        t = q / p
        if p < 0:
            t0 = max(t0, t)
        else:
            t1 = min(t1, t)
        if t0 > t1:
            return None
    return ((a[0] + t0 * dx, a[1] + t0 * dy), (a[0] + t1 * dx, a[1] + t1 * dy))


def _outlined(svg, pts, cover=0.9):
    """True when ONE dark stroked element traces at least `cover` of the
    closed outline `pts` (a filled polygon whose edges render cut)."""
    if len(pts) < 3:
        return False
    edges = list(zip(pts, pts[1:] + pts[:1]))
    per = sum(_dist(a, b) for a, b in edges)
    if per <= 0:
        return False
    for m in re.finditer(r"<(?:path|polyline|polygon|line)\b[^>]*>", svg):
        el = m.group(0)
        sm = re.search(r'\bstroke="([^"]*)"', el)
        if not sm or not svgcheck._dark(sm.group(1)):
            continue
        es = _svg_segments(el if el.endswith("/>") else el + "</x>")
        if not es:
            continue
        got = 0.0
        for a, b in edges:
            L = _dist(a, b)
            n = max(2, int(L / 2.0))
            on = sum(1 for k in range(n + 1)
                     if any(svgcheck._pt_seg((a[0] + (b[0] - a[0]) * k / n,
                                              a[1] + (b[1] - a[1]) * k / n),
                                             c, d) < 0.6 for c, d in es))
            got += L * on / float(n + 1)
        if got >= cover * per:
            return True
    return False


def number_line(lo, hi, marks=None, step=1, size=30, font=None, width=None,
                fam=None, house=True):
    """A number line with every tick numbered -- v6 C4: a COMPATIBILITY SHIM
    over `numberline.NL` (the number-line builder). Existing calls keep their
    meaning: a tick and a number every `step`, `size` figure units per step,
    `font` units per number, the whole drawing shown `width` px wide, no
    arrowheads, marks=[(v, "A", style)] with style "filled" (default), "open",
    "tri", "square" or "cross". `size` is figure units per UNIT (v5.8's
    X = v * size), whatever the step; a mark between two ticks (2.5 on a
    step-1 line, a v5.8 call) is drawn as an estimate between them.

    v6.2b: `font=` is the SEED of the printed size, not the size. The drawing
    prints at the sheet's look (`numberline.TICK_PT` / `LETTER_PT`), found by
    rendering and measuring the finished file; `house=False` keeps the caller's
    own px. The geometry is unchanged either way.

    What changed underneath: ticks are anchored at multiples of `step` from 0
    (E13); a mark off the line or on a reversed range is refused instead of
    drawn silently; the figure is tagged
    `<!--fam:numberline[...]{marks}-->` unless `fam=` names it. New sheets
    should call numberline.NL directly (fractions, jumps, sets, tiers)."""
    import numberline as _nl
    # v6.2 Q1b (the verifier's V2): the shim prints at THE SHEET'S LOOK.
    # It used to print the caller's own font= whatever the drawing was shown
    # at, so a v5.x number_line on a v6 sheet printed its numbers at 7.5pt
    # where every other figure printed 8.0 and its letters at 7.5 where they
    # printed 9.5 -- G78 refused the whole level (z08_a q2 item bet) and
    # doctrine 5 (the shim keeps existing levels working) was broken. A
    # font= a v5.x call chose was chosen to be READABLE at that width, which
    # is what the house look now settles for every figure on the sheet, so
    # it is the seed of the search and not the answer; house=False keeps the
    # raw px for a caller who really wants it. The geometry -- size= units
    # per unit, width=, the ticks, the marks -- is the caller's exactly as
    # before; only the printed SIZE follows the sheet, and it is found by
    # rendering and measuring what came out, not by arithmetic on trust.
    px = 11.0 if font is None else float(font)
    for _ in range(8):
        nl = _nl.NL(lo, hi, tick=step, label_every=1, fam=fam,
                    _legacy=dict(size=size, font=px, width=width,
                                 house=house))
        for m in (marks or []):
            v, name = m[0], (m[1] if len(m) > 1 else None)
            st = m[2] if len(m) > 2 and m[2] else "filled"
            try:
                off = (_nl._F(v, "mark") / nl.tick).denominator != 1
            except AssertionError:
                off = True               # an inexact float: an estimate
            nl.point(v, name or None, st, between=off)
        out = nl.svg()
        if not house:
            return out
        pt = _number_line_pt(out, px)
        if pt is None or abs(pt - _nl.TICK_PT) <= 0.05:
            return out
        px *= _nl.TICK_PT / pt
    return out


def _number_line_pt(svg_text, px):
    """What the shim's numbers actually PRINT at, off the finished file:
    the label px, the display width and the viewBox width."""
    w = re.search(r'<svg[^>]*\swidth="([\d.]+)"', svg_text)
    vb = re.search(r'viewBox="[-\d.]+ [-\d.]+ ([\d.]+) ', svg_text)
    if not w or not vb or float(vb.group(1)) <= 0:
        return None
    return px * float(w.group(1)) / float(vb.group(1)) * _PX_TO_PT


def cylinder(r, h, size=150, font=12, width=None, labels=None,
             show_lengths=True, fam=None):
    """A cylinder drawn to its own numbers. RADIUS first, then height.

    The worst regression of the whole corpus rebuild came from a package-local
    helper with this signature: `cyl(14, 7)` was called with the DIAMETER in
    the radius slot, and six sheets printed a cylinder half the height their
    own text stated — one of them under a heading reading "the axial section
    is a square". No gate saw it; a second reader measuring the drawing did.
    figkit cannot police a helper it does not own, so it owns this one: the
    drawn body is measured against h and 2r before a byte is emitted, and a
    mismatch raises instead of printing.
    """
    r, h = float(r), float(h)
    if r <= 0 or h <= 0:
        raise AssertionError(
            "cylinder: radius and height must both be positive, got r=%g h=%g. "
            "A common cause is passing the diameter, or swapping the two."
            % (r, h))
    w = 2.0 * r
    k = size / max(w, h)                      # ONE scale for both axes
    bw, bh = w * k, h * k
    ry = bw * 0.16                            # the ellipse's minor axis
    left, right, top, bot = -bw / 2.0, bw / 2.0, 0.0, bh

    def _oval(cy, dash):
        pts = [(bw / 2.0 * math.cos(2 * math.pi * i / 48.0),
                cy + ry * math.sin(2 * math.pi * i / 48.0))
               for i in range(49)]
        f.parts.append(("path", pts, 1.4, dash, None))
        f.segs.extend(zip(pts, pts[1:]))

    f = Figure(width=width)
    f.line((left, top), (left, bot))
    f.line((right, top), (right, bot))
    _oval(top, None)
    _oval(bot, "3,3")                         # the hidden half of the base
    # The two measurements a reader can take off the page, checked against the
    # two numbers the question states.
    f.expect("height", bh, h)
    f.expect("diameter", bw, w)
    labels = labels or {}
    if show_lengths:
        f.label((right, bh / 2.0), labels.get("h", _num(h)),
                size=font, prefer=(1, 0), gap=5.0)
        f.label((0.0, top), labels.get("r", _num(r)),
                size=font, prefer=(0, -1), gap=5.0)
    return f.render(width=width, fam=fam)


# ---------------------------------------------------------------- selftest ---
def _struck(svg):
    """Independent re-sweep of a finished SVG: which labels have ink through
    them? Deliberately does NOT reuse the solver's own bookkeeping — a gate
    that trusts the thing it is gating is not a gate.

    v6 (E3): delegates to `svgcheck.struck`, which has its own tokenizer. The
    regex this replaced read `<text>` bodies as `[^<]*`, so any label with a
    tspan (`y = x<tspan>2</tspan>`) was skipped outright, and read path data
    as M/L/Q/C only, so an arc written with `A`, a relative `l`, or an `H`/`V`
    run was invisible. Curves, rims and filled dots are all ink here."""
    return svgcheck.struck(svg)


def selftest():
    ok = True

    def check(name, cond, detail=""):
        nonlocal ok
        print("  %-46s %s %s" % (name, "PASS" if cond else "FAIL", detail))
        ok = ok and cond

    # 1. every builder emits figures with no struck label
    figs = {
        "triangle 3-4-5": triangle(sides=(3, 4, 5), right_angle="B", width=150),
        "triangle 6-6-8": triangle(sides=(6, 6, 8), ticks=[("A", "B")], width=150),
        "triangle 20-20-2": triangle(sides=(20, 20, 2), width=170),
        "rect 12x5 + diagonal": rect(12, 5, diagonal="AC", width=170),
        "axes with a line clear of the tick numbers":
            axes((-5, 5), (-4, 4), points=[((2, 3), "A")],
                 lines=[((-4, 2), (2, 4), "f")], width=300),
        "number line": number_line(-5, 5, marks=[(-2, "A")], width=300),
        "coord plane: rhombus, diagonals, O":
            coord_plane((0, 11), (0, 5), polys=[[(1, 1), (6, 1), (10, 4), (5, 4)]],
                        dashed=[((1, 1), (10, 4)), ((6, 1), (5, 4))],
                        points=[((1, 1), "A"), ((6, 1), "B"), ((10, 4), "C"),
                                ((5, 4), "D"), ((5.5, 2.5), "O")]),
        "coord plane: altitude foot, right angle":
            coord_plane((0, 7), (0, 9), polys=[[(0, 0), (6, 0), (0, 8)]],
                        dashed=[((0, 0), (3.84, 2.88))],
                        right=[((3.84, 2.88), (6, 0), (0, 0))],
                        points=[((0, 0), "K"), ((6, 0), "L"), ((0, 8), "M"),
                                ((3.84, 2.88), "N")]),
        "coord plane: negative x, open path":
            coord_plane((-2, 6), (0, 6), solid=[((1, 1), (5, 2)), ((5, 2), (3, 5))],
                        points=[((1, 1), "P"), ((5, 2), "Q"), ((3, 5), "R")]),
    }
    for nm, svg in figs.items():
        b = _struck(svg)
        check("no struck label: " + nm, not b, b or "")

    # 2. proportions really are enforced
    svg = triangle(sides=(3, 4, 5), width=150)
    pts = [tuple(map(float, p.split(",")))
           for p in re.search(r'points="([^"]+)"', svg).group(1).split()]
    L = [_dist(pts[0], pts[1]), _dist(pts[1], pts[2]), _dist(pts[2], pts[0])]
    check("3-4-5 drawn to scale",
          abs(L[1] / L[0] - 4 / 3.0) < 0.02 and abs(L[2] / L[0] - 5 / 3.0) < 0.02,
          "%.2f %.2f" % (L[1] / L[0], L[2] / L[0]))

    # 2b. an axis number a plotted line runs through stays at its tick; the
    #     line is cut around it and leaves no stub (a stub read "- 8 -" as -8)
    _ax = axes((-5, 5), (-4, 4), lines=[((-4, -3), (4, 4), "f")], width=300)
    check("axis number under a line kept, line cut, no struck label",
          not _struck(_ax) and all(">%s</text>" % _num(v) in _ax
                                   for v in (-4, -3, -2, -1, 1, 2, 3, 4)))

    # 3. an impossible triangle is refused rather than drawn
    try:
        triangle(sides=(1, 2, 5))
        check("impossible triangle refused", False)
    except AssertionError:
        check("impossible triangle refused", True)

    # 4. the font floor bites, both by size and by display width
    try:
        triangle(sides=(3, 4, 5), font=6, width=150)
        check("font floor by size", False)
    except AssertionError:
        check("font floor by size", True)
    try:
        triangle(sides=(3, 4, 5), font=12, width=40)
        check("font floor by display width", False)
    except AssertionError:
        check("font floor by display width", True)

    # 4b. a wide plane shrinks to the side column and the tick numbers still
    #     clear the font floor (the labels are enlarged before the shrink)
    try:
        svg = coord_plane((0, 11), (0, 5), polys=[[(1, 1), (6, 1), (10, 4), (5, 4)]])
        w = float(re.search(r'<svg[^>]*\bwidth="([\d.]+)"', svg).group(1))
        check("coord plane fits the side column", w <= 210.0, "%.0fpx" % w)
    except AssertionError as e:
        check("coord plane fits the side column", False, str(e)[:60])

    # 4c. the object key behind G75: labels and dashed additions do not make
    #     a new object; a different shape does
    rh = [[(1, 1), (6, 1), (10, 4), (5, 4)]]
    f1 = figure_family(coord_plane((0, 11), (0, 5), polys=rh))
    f2 = figure_family(coord_plane((0, 11), (0, 5), polys=rh,
                                   dashed=[((1, 1), (10, 4))],
                                   points=[((5.5, 2.5), "O")]))
    f3 = figure_family(coord_plane((0, 11), (0, 5), polys=[[(0, 0), (10, 0), (7, 4), (3, 4)]]))
    check("figure family ignores labels and dashes", f1 == f2 and f1 != f3)

    # 5. Hebrew inside <text> is refused (G49)
    try:
        assert_no_hebrew('<svg><text x="0" y="0">שלום</text></svg>')
        check("Hebrew in SVG refused", False)
    except AssertionError:
        check("Hebrew in SVG refused", True)

    print("SELFTEST", "PASS" if ok else "FAILED")
    return 0 if ok else 1



# ================================================================
#  RETROFIT — de-collide labels in an SVG that figkit did not draw
# ================================================================
def _svg_segments(svg):
    """Stroked geometry of a raw SVG, as segments. Light strokes are
    background and are skipped, by the same luminance rule G72 uses."""
    segs = []

    def light(tag):
        m = re.search(r'stroke="#?([0-9a-fA-F]{6})"', tag)
        if not m:
            return False
        c = m.group(1)
        if ("#" + c.lower()) == svgcheck.GRID_GREY:
            return True                       # P1: the grid, by its colour
        return min(int(c[i:i + 2], 16) for i in (0, 2, 4)) / 255.0 > 0.85

    for m in re.finditer(r"<line\b([^>]*)/?>", svg):
        t = m.group(1)
        if light(t):
            continue
        v = dict(re.findall(r'(x1|y1|x2|y2)="([-\d.]+)"', t))
        if len(v) == 4:
            segs.append(((float(v["x1"]), float(v["y1"])),
                         (float(v["x2"]), float(v["y2"]))))
    for tag, attr in (("polygon", True), ("polyline", False)):
        for m in re.finditer(r"<%s\b([^>]*)/?>" % tag, svg):
            t = m.group(1)
            if light(t):
                continue
            pm = re.search(r'points="([^"]+)"', t)
            if not pm:
                continue
            pts = [tuple(map(float, p.split(",")))
                   for p in pm.group(1).replace("\n", " ").split()
                   if "," in p]
            if len(pts) < 2:
                continue
            n = len(pts) if attr else len(pts) - 1
            segs += [(pts[i], pts[(i + 1) % len(pts)]) for i in range(n)]
    for m in re.finditer(r"<rect\b([^>]*)/?>", svg):
        t = m.group(1)
        if light(t) or 'fill="none"' not in t and "stroke" not in t:
            continue
        v = dict(re.findall(r'(x|y|width|height)="([-\d.]+)"', t))
        if len(v) == 4:
            x, y = float(v["x"]), float(v["y"])
            w, h = float(v["width"]), float(v["height"])
            c = [(x, y), (x + w, y), (x + w, y + h), (x, y + h)]
            segs += [(c[i], c[(i + 1) % 4]) for i in range(4)]
    for m in re.finditer(r'<path\b[^>]*\bd="([^"]+)"[^>]*>', svg):
        nums = [float(x) for x in re.findall(r"-?\d+\.?\d*", m.group(1))]
        pts = list(zip(nums[0::2], nums[1::2]))
        segs += [(pts[i], pts[i + 1]) for i in range(len(pts) - 1)]
    return segs


_TEXT_RE = re.compile(r'<text\b([^>]*)>(.*?)</text>', re.S)


def deconflict_svg(svg, max_shift=14.0, min_pt=None, scale=1.0):
    """Move labels in an EXISTING svg off the strokes that cross them.

    The corpus is mostly raw SVG written by hand in the content files, so
    figkit's solver never sees it — and that is where the audit's largest
    defect class lives (120 sheets: a vertex letter or a length label with a
    line through it). This retrofits the same clearance rule onto a finished
    SVG: parse the geometry, find every struck label, and nudge it the
    shortest distance that clears it. Nothing else about the figure changes.

    Returns (svg, moved, still_struck)."""
    segs = _svg_segments(svg)
    if not segs:
        return svg, 0, []
    texts = list(_TEXT_RE.finditer(svg))
    boxes, moved, stuck = [], 0, []
    out, last = [], 0

    for m in texts:
        attrs, body = m.group(1), re.sub(r"<[^>]+>", "", m.group(2)).strip()
        xm = re.search(r'\bx="([-\d.]+)"', attrs)
        ym = re.search(r'\by="([-\d.]+)"', attrs)
        fm = re.search(r'font-size="([\d.]+)"', attrs)
        if not (xm and ym and body):
            continue
        x, y = float(xm.group(1)), float(ym.group(1))
        size = float(fm.group(1)) if fm else 12.0
        anchor = re.search(r'text-anchor="(\w+)"', attrs)
        mid = (anchor.group(1) if anchor else "start") == "middle"
        w = max(len(body), 1) * _CHAR_W * size

        def box(px, py):
            x0 = px - w / 2 if mid else px
            return (x0, py - size * 0.78, x0 + w, py + size * 0.24)

        # RETROFIT RULE: move a label ONLY when a stroke actually crosses it.
        # The first cut also moved labels that merely overlapped a neighbour
        # by this module's approximate width model, and that model is too
        # crude to second-guess a human layout: it relocated origin labels
        # that were perfectly placed, straight onto an axis, and four
        # packages came out WORSE than before the retrofit. Label-label
        # crowding in an existing figure stays the author's call.
        if not any(_seg_box(a, b, box(x, y)) for a, b in segs):
            boxes.append(box(x, y))
            continue
        best = None
        for r in [d * 1.6 for d in range(1, int(max_shift / 1.6) + 1)]:
            for ang in range(0, 360, 15):
                th = math.radians(ang)
                nx, ny = x + r * math.cos(th), y + r * math.sin(th)
                bb = box(nx, ny)
                if any(_seg_box(a, b, bb) for a, b in segs):
                    continue
                if any(_boxes_overlap(bb, ob, 1.0) for ob in boxes):
                    continue
                best = (nx, ny, bb)
                break
            if best:
                break
        if not best:
            stuck.append(body)
            boxes.append(box(x, y))
            continue
        nx, ny, bb = best
        boxes.append(bb)
        moved += 1
        new_attrs = re.sub(r'\bx="[-\d.]+"', 'x="%.2f"' % nx, attrs, count=1)
        new_attrs = re.sub(r'\by="[-\d.]+"', 'y="%.2f"' % ny, new_attrs, count=1)
        out.append(svg[last:m.start()])
        out.append("<text%s>%s</text>" % (new_attrs, m.group(2)))
        last = m.end()
    out.append(svg[last:])
    return "".join(out), moved, stuck



# v6.5 X2 r1 (MUST-3, spec rule 6): the author's call into this module
# is recorded as source, so figures/<id>.py can re-draw the figure.
axes = export.entry(axes)
coord_plane = export.entry(coord_plane)
number_line = export.entry(number_line)

if __name__ == "__main__":
    import sys
    sys.exit(selftest())
