# -*- coding: utf-8 -*-
"""describe — v6.3 section 3: a figure from a sentence.

    from describe import build
    svg = build("ריבוע ABCD; G על AD; ∠GBA = 37°")

`build` parses the description with the EXPLICIT grammar below, hands it to
`generate.Generator` (section 4) to solve, draws the result with `shapekit`
and returns the finished SVG — checked by the engine that already ships
(`euclid._Fig.render` -> `figkit` -> `svgcheck`), not by a second opinion.

WHY A GRAMMAR AND NOT A GUESS
-----------------------------
The author's complaint about every drawing tool he tried is that it invents.
A sheet's figure is a CLAIM about the question's data; a figure that quietly
reinterprets a sentence it did not understand is worse than no figure. So:

  * every sentence is ONE datum, and every datum has to match one of the
    patterns listed under GRAMMAR below;
  * a sentence that matches nothing is REFUSED, and the refusal prints the
    whole list of what IS understood, with an example of each. Nothing is
    skipped, softened, or approximated;
  * Hebrew goes in the description and in the refusals; the SVG that comes
    out carries Latin letters, digits, U+2212 and ° only (doctrine 7).

GRAMMAR
-------
A description is a list of sentences separated by `;` or by newlines (a
sentence that does not parse whole is retried split on `,`). The FIRST
sentence declares the shape; every later sentence is one datum about it.

  the shape (exactly one, first)
    ריבוע ABCD                 square
    מלבן ABCD                  rectangle
    מקבילית ABCD               parallelogram
    מעוין ABCD                 rhombus
    דלתון ABCD                 kite
    טרפז ABCD                  trapezoid (scalene unless said otherwise)
    טרפז שווה־שוקיים ABCD      isosceles trapezoid
    טרפז ישר־זווית ABCD        right trapezoid
    משולש ABC                  triangle
    משולש ישר־זווית ABC        right triangle (the right angle at A)
    משולש שווה־שוקיים ABC      isosceles triangle (apex C)
    משולש שווה־צלעות ABC       equilateral triangle
    מצולע משוכלל ABCDEF        regular polygon (one letter per vertex)
    מעגל O                     circle

  the data (any number, any order)
    AB = 15                    a length            -> the side carries it
    AB = 15 ס״מ                the same (unit dropped from the drawing)
    ∠ABC = 37°                 an angle at B       -> arc + the number
    זווית ABC = 37             the same, in words
    ∠A = 60°                   the angle at a vertex, between its own sides
    AB = CD                    two segments are equal   -> equality ticks
                               (a shape that already marks the pair says so
                               once: on a kite ABCD those are AB = AD and
                               CB = CD, and AB = BC is a rhombus)
    G על AD                    a point on a segment
    M אמצע AB                  the midpoint        -> the two ticks
    AG : GD = 2 : 3            a ratio along a segment
    AB ∥ CD                    parallel            -> chevrons
    AB מקביל ל־CD              the same, in words
    BD ⊥ AB                    perpendicular       -> the right-angle mark
    BD מאונך ל־AB              the same, in words
    אלכסונים                   both diagonals
    אלכסון AC                  one diagonal
    M מפגש האלכסונים           the diagonals and their intersection
    AE חוצה זווית A            the bisector of A: it BUILDS E, on the side
                               it meets (say 'E על BC' first to pin it)
    CM תיכון אל AB             the median from C
    CH גובה אל AB              the altitude from C
    H היטל C על AB             the perpendicular foot, no segment drawn
    מעגל חסום                  the inscribed circle
    מעגל חוסם                  the circumscribed circle
    גובה = 6                   the height of a trapezoid

  modifier (on a length or an angle)
    AB = 15 (לא בשרטוט)        constrains the figure, prints nothing

WHAT A DATUM MEANS
------------------
A datum both CONSTRAINS and (unless `(לא בשרטוט)`) is SHOWN: `AB = 15`
fixes the side and writes 15 beside it, `∠GBA = 37°` fixes the point G and
arcs the wedge with 37° in it. That is how the author's own sheets read —
the numbers in the drawing are the question's data — and it is what makes a
wrong figure impossible to hide: the number printed is the number solved.

SOLIDS (v6.6)
-------------
The first sentence may declare a SOLID instead; the figure is then drawn by
`solidkit` from the same data, and every printed number passes solidkit's
own proportion check (a number that contradicts its edge is refused):

    תיבה ABCDEFGH              box: ABCD the base, E above A ... H above D
    קובייה ABCDEFGH            cube
    גליל r=2 h=5               cylinder (r / h inline, or as sentences)
    חרוט r=3 h=4               cone
    פירמידה ריבועית SABCD      square pyramid, apex first (default SABCD)
    פירמידה משולשת SABC        triangular pyramid (default SABC)
    מנסרה משולשת ABCDEF        right triangular prism, D above A (default)

  and its data, one per sentence:
    AB = 4                     an EDGE (a box's parallel edges are one
                               length: AB = 4 and DC = 5 is refused)
    r = 2  /  רדיוס = 2        the radius of a cylinder or a cone
    h = 5  /  גובה = 5         the height (a pyramid's is drawn from the
                               apex to the base's centre, O)
    SA = 10                    a pyramid's lateral edge (fixes its height)
    ... (לא בשרטוט)            constrains the solid, prints nothing

A solid needs ALL of its defining lengths or NONE of them: none draws the
solid unnumbered (nothing printed, nothing claimed); some-but-not-all is
refused, naming the missing ones, because a figure with one real number and
invented proportions next to it prints a claim no datum made.

Anything the grammar does not list is refused. In particular the layer does
NOT do: free text, several data in one sentence, areas, coordinates,
tangents, circles through named points, or add-ons on a solid (diagonals,
sections, liquids -- those are solidkit calls). Those are refusals with a
message, not silent omissions.
"""
import math
import re
import time
import unicodedata
from collections import namedtuple

__all__ = ["build", "parse", "Description", "Datum", "DescribeError",
           "GRAMMAR", "understood", "hebrew", "SolidDescription",
           "build_solid", "solid"]


class DescribeError(AssertionError):
    """A sentence outside the grammar, or a description that cannot be one
    figure. An AssertionError, so every `raises(...)` harness in the suite
    and euclid's refusal contract catch it the same way."""


# ------------------------------------------------------------------ text ---
_BIDI = re.compile(r"[‎‏‪-‮⁦-⁩]")


def _clean(s):
    """The author's typing, normalised without changing what it says."""
    s = unicodedata.normalize("NFC", str(s))
    s = _BIDI.sub("", s)
    for a, b in (("׳", "'"), ("״", '"'), ("–", "-"), ("—", "-"),
                 ("−", "-"), ("‐", "-"), ("‑", "-"), (" ", " "),
                 # U+05BE MAQAF is the Hebrew hyphen, and it is how the
                 # grammar above, this module's docstring and the briefs all
                 # spell the compound shape names. It was the ONE dash not
                 # normalised, so every correctly typed
                 # 'משולש שווה־שוקיים',
                 # 'משולש שווה־צלעות',
                 # 'משולש ישר־זווית',
                 # 'טרפז שווה־שוקיים' and
                 # 'טרפז ישר־זווית' was refused with
                 # "המשפט הראשון חייב להכריז על הצורה" -- a refusal
                 # of standard Hebrew orthography, which pushes an author to
                 # mis-spell the shape to get a figure.
                 ("־", "-"),
                 ("＝", "="), ("：", ":")):
        s = s.replace(a, b)
    # a maqaf between two Hebrew words is a space: שווה־שוקיים
    s = re.sub(r"(?<=[֐-׿])-(?=[֐-׿])", " ", s)
    # ...and after a Hebrew word before a Latin letter: מקביל ל־CD
    s = re.sub(r"(?<=[֐-׿])-(?=[A-Z])", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def _sentences(text):
    out = []
    for part in re.split(r"[;\n]+", _clean(text)):
        part = part.strip(" .·")
        if part:
            out.append(part)
    return out


# --------------------------------------------------------------- grammar ---
L = "([A-Z])"
NUM = r"(-?\d+(?:\.\d+)?)"
_UNIT = r'(?:\s*(?:ס"מ|סמ|מ"מ|cm))?'
_HIDE = r'(?:\s*\((?:לא בשרטוט|ללא סימון)\))?'

# (role, regex, example, gloss). The order is the order tried; the message a
# refusal prints is built from this table, so the table IS the documentation.
GRAMMAR = [
    ("angle3", re.compile(r"^(?:∠|(?:ה)?זווית)\s*%s\s*%s\s*%s\s*=\s*%s\s*°?%s$"
                          % (L, L, L, NUM, _HIDE)),
     "∠ABC = 37°", "זווית בקודקוד האמצעי"),
    ("angle1", re.compile(r"^(?:∠|(?:ה)?זווית)\s*%s\s*=\s*%s\s*°?%s$"
                          % (L, NUM, _HIDE)),
     "∠A = 60°", "הזווית של הצורה בקודקוד"),
    ("ratio", re.compile(r"^%s%s\s*:\s*%s%s\s*=\s*%s\s*:\s*%s$"
                         % (L, L, L, L, NUM, NUM)),
     "AG : GD = 2 : 3", "יחס לאורך קטע"),
    ("equal", re.compile(r"^%s%s\s*=\s*%s%s$" % (L, L, L, L)),
     "AB = CD", "שני קטעים שווים"),
    ("length", re.compile(r"^%s%s\s*=\s*%s%s%s$" % (L, L, NUM, _UNIT, _HIDE)),
     "AB = 15", "אורך קטע"),
    ("height", re.compile(r"^(?:ה)?גובה\s*=\s*%s%s%s$" % (NUM, _UNIT, _HIDE)),
     "גובה = 6", "גובה הטרפז"),
    ("on", re.compile(r"^%s\s+על\s+%s%s$" % (L, L, L)),
     "G על AD", "נקודה על קטע"),
    ("midpoint", re.compile(r"^%s\s+אמצע\s+%s%s$" % (L, L, L)),
     "M אמצע AB", "אמצע קטע"),
    ("parallel", re.compile(r"^%s%s\s*(?:∥|\|\||מקביל(?:ה)?\s*ל)\s*%s%s$"
                            % (L, L, L, L)),
     "AB ∥ CD", "קטעים מקבילים"),
    ("perp", re.compile(r"^%s%s\s*(?:⊥|מאונך(?:ת)?\s*ל)\s*%s%s$"
                        % (L, L, L, L)),
     "BD ⊥ AB", "קטעים מאונכים"),
    ("meet", re.compile(r"^%s\s+מפגש\s+(?:ה)?אלכסונים$" % L),
     "M מפגש האלכסונים", "מפגש האלכסונים"),
    ("diagonals", re.compile(r"^(?:ה)?אלכסונים$"),
     "אלכסונים", "שני האלכסונים"),
    ("diagonal", re.compile(r"^(?:ה)?אלכסון\s+%s%s$" % (L, L)),
     "אלכסון AC", "אלכסון אחד"),
    ("bisector", re.compile(r"^%s%s\s+חוצה\s+(?:את\s+)?(?:ה)?זווית\s+%s$"
                            % (L, L, L)),
     "AE חוצה זווית A", "חוצה זווית"),
    ("median", re.compile(r"^%s%s\s+תיכון\s+(?:אל|ל)\s*%s%s$" % (L, L, L, L)),
     "CM תיכון אל AB", "תיכון"),
    ("altitude", re.compile(r"^%s%s\s+גובה\s+(?:אל|ל)\s*%s%s$" % (L, L, L, L)),
     "CH גובה אל AB", "גובה במשולש"),
    ("foot", re.compile(r"^%s\s+היטל\s+%s\s+על\s+%s%s$" % (L, L, L, L)),
     "H היטל C על AB", "רגל האנך"),
    ("incircle", re.compile(r"^מעגל\s+חסום$"), "מעגל חסום", "מעגל חסום"),
    ("circumcircle", re.compile(r"^מעגל\s+חוסם$"), "מעגל חוסם", "מעגל חוסם"),
]

_SHAPE_WORDS = [
    ("מצולע משוכלל", "polygon", None),
    ("משולש ישר זווית", "triangle", "right"),
    ("משולש שווה שוקיים", "triangle", "iso"),
    ("משולש שווה צלעות", "triangle", "equilateral"),
    ("משולש", "triangle", None),
    ("טרפז שווה שוקיים", "trapezoid", "iso"),
    ("טרפז ישר זווית", "trapezoid", "right"),
    ("טרפז", "trapezoid", "scalene"),
    ("מקבילית", "parallelogram", None),
    ("מלבן", "rectangle", None),
    ("ריבוע", "square", None),
    ("מעוין", "rhombus", None),
    ("דלתון", "kite", None),
    ("מעגל", "circle", None),
]

def hebrew(kind, variant=None):
    """The Hebrew word for a shape kind — so a refusal from `generate`
    speaks the language the description is written in (conventions: English
    identifiers, Hebrew user-facing strings)."""
    for word, k, var in _SHAPE_WORDS:
        if k == kind and var == variant:
            return word
    for word, k, _var in _SHAPE_WORDS:
        if k == kind:
            return word
    return str(kind)


_NVERT = {"square": 4, "rectangle": 4, "parallelogram": 4, "rhombus": 4,
          "kite": 4, "trapezoid": 4, "triangle": 3, "circle": 1}


# v6.6 S: the solids. (word, kind, default letters, base size n)
_SOLID_WORDS = [
    ("פירמידה ריבועית", "pyramid.square", "SABCD", 4),
    ("פירמידה משולשת", "pyramid.triangle", "SABC", 3),
    ("מנסרה משולשת", "prism.triangle", "ABCDEF", 3),
    ("קובייה", "cube", "ABCDEFGH", 4),
    ("קוביה", "cube", "ABCDEFGH", 4),
    ("תיבה", "box", "ABCDEFGH", 4),
    ("גליל", "cylinder", "", 0),
    ("חרוט", "cone", "", 0),
]
_R_RX = re.compile(r'^(?:r|R|(?:ה)?רדיוס(?:\s+(?:ה)?בסיס)?)\s*=\s*%s%s%s$'
                   % (NUM, _UNIT, _HIDE))
_H_RX = re.compile(r'^(?:h|H|(?:ה)?גובה)\s*=\s*%s%s%s$' % (NUM, _UNIT, _HIDE))
_E_RX = re.compile(r'^%s%s\s*=\s*%s%s%s$' % (L, L, NUM, _UNIT, _HIDE))


def understood(what="הכול"):
    """The whole grammar as the refusal prints it. A refusal that only says
    'not understood' sends the author away; this one hands him the list."""
    rows = ["  צורה (משפט ראשון):"]
    for word, kind, var in _SHAPE_WORDS:
        rows.append("    %-26s %s%s" % (word + " ABCD", kind,
                                        "" if var is None else " (%s)" % var))
    rows.append("  גוף (משפט ראשון):")
    for word, kind, lets, _n in _SOLID_WORDS:
        rows.append("    %-26s %s" % ((word + " " + lets) if lets else
                                      (word + " r=2 h=5"), kind))
    rows.append("  נתון על גוף: AB = 4 (מקצוע), r = 2, h = 5 / גובה = 5, "
                "SA = 10 (מקצוע צדדי)")
    rows.append("  נתון (כל משפט = נתון אחד):")
    for _role, _rx, ex, gloss in GRAMMAR:
        rows.append("    %-26s %s" % (ex, gloss))
    rows.append("    %-26s %s" % ("AB = 15 (לא בשרטוט)",
                                  "נתון שמגביל ואינו מודפס"))
    return "describe מבין רק את אלה (%s):\n%s" % (what, "\n".join(rows))


def _refuse(sentence, why):
    raise DescribeError("describe: %r — %s\n%s"
                        % (sentence, why, understood()))


# ------------------------------------------------------------------ data ---
Datum = namedtuple("Datum", "role args value drawn text")
Datum.__doc__ = """One sentence of a description.
  role  — the grammar row it matched ('angle3', 'on', ...)
  args  — the point letters it names, in the order the sentence gave them
  value — the number it fixes (None where the role carries no number)
  drawn — False when the sentence ended in (לא בשרטוט)
  text  — the sentence itself, as the author wrote it (a key for violate())"""


class Description(object):
    """A parsed description: one shape and its data. Pure — it solves
    nothing and draws nothing (that is `generate.Generator`)."""

    def __init__(self, kind, variant, letters, data, text):
        self.kind = kind
        self.variant = variant
        self.letters = letters
        self.data = list(data)
        self.text = text

    # every letter the description mentions, base vertices first
    def points(self):
        out = list(self.letters)
        for d in self.data:
            for a in d.args:
                if a not in out:
                    out.append(a)
        return out

    def of(self, role):
        return [d for d in self.data if d.role == role]

    def __repr__(self):
        return "Description(%s%s %s, %d data)" % (
            self.kind, "" if not self.variant else "." + self.variant,
            self.letters, len(self.data))


def _mk(role, m, sentence):
    g = list(m.groups())
    letters = [x for x in g if x and re.match(r"^[A-Z]$", x)]
    nums = [float(x) for x in g if x and re.match(r"^-?\d", x)]
    drawn = "(לא בשרטוט)" not in sentence and "(ללא סימון)" not in sentence
    val = None
    if role == "ratio":
        val = (nums[0], nums[1])
    elif nums:
        val = nums[0]
    return Datum(role, tuple(letters), val, drawn, sentence)


def _parse_one(sentence, letters):
    for role, rx, _ex, _gloss in GRAMMAR:
        m = rx.match(sentence)
        if m:
            return _mk(role, m, sentence)
    # a helpful nudge before the full list, for the near misses that matter
    if re.search(r"[֐-׿]", sentence) and "=" in sentence:
        _refuse(sentence, "משפט אחד = נתון אחד; אם יש כאן שני נתונים הפרידו "
                          "ביניהם בנקודה-פסיק")
    if re.search(r"\(\s*-?\d+\s*,", sentence):
        _refuse(sentence, "קואורדינטות אינן חלק משכבת התיאור (הן שייכות "
                          "ל-plane/figkit_plus)")
    _refuse(sentence, "המשפט אינו מתאים לאף תבנית")
    return None                                            # unreachable


def parse(text):
    """Text -> `Description`. Refuses on the first sentence it cannot read."""
    sents = _sentences(text)
    if not sents:
        raise DescribeError("describe: התיאור ריק — %s" % understood("צורה"))
    head = sents[0]
    sol = _parse_solid(sents)
    if sol is not None:
        return sol
    kind = variant = None
    letters = ""
    for word, k, var in _SHAPE_WORDS:
        m = re.match(r"^(?:ה)?%s\s+([A-Z]+)$" % re.escape(word), head)
        if m:
            kind, variant, letters = k, var, m.group(1)
            break
    if kind is None:
        _refuse(head, "המשפט הראשון חייב להכריז על הצורה")
    want = _NVERT.get(kind, len(letters))
    if kind == "polygon":
        if not 3 <= len(letters) <= 12:
            _refuse(head, "למצולע משוכלל 3 עד 12 קודקודים, אות לכל קודקוד")
    elif len(letters) != want:
        _refuse(head, "ל-%s יש %d קודקודים, וכאן ניתנו %d אותיות (%s)"
                % (kind, want, len(letters), letters))
    if len(set(letters)) != len(letters):
        _refuse(head, "כל קודקוד באות משלו")

    data = []
    for s in sents[1:]:
        try:
            data.append(_parse_one(s, letters))
        except DescribeError:
            # one retry: a sentence the author separated with a comma
            bits = [b.strip() for b in s.split(",") if b.strip()]
            if len(bits) < 2:
                raise
            for b in bits:
                data.append(_parse_one(b, letters))
    # two passes, so the order of the sentences never matters: every point a
    # datum DECLARES is collected first, and only then is every datum checked
    # against the full cast. ('AE חוצה זווית A' may stand before 'E על BC'.)
    seen = set(letters)
    for d in data:
        new = _NEW.get(d.role)
        if new is None:
            continue
        a = d.args[new]
        if a in seen:
            _refuse(d.text, "האות %s כבר מציינת נקודה בשרטוט" % a)
        seen.add(a)
    for d in data:
        i = _MAY_NEW.get(d.role)
        if i is not None:
            seen.add(d.args[i])
    for d in data:
        _check_letters(d, seen, d.text, kind, letters)
    return Description(kind, variant, letters, data, _clean(text))


# which letter of a datum is the point the datum INTRODUCES (the rest must
# already exist). A sentence may name at most one new point.
_NEW = {"on": 0, "midpoint": 0, "meet": 0, "foot": 0,
        "median": 1, "altitude": 1}

# r1 (S2-5-bisector-advertised-but-refused): a datum whose point the sentence
# introduces IF no other sentence already declares it. 'CM תיכון אל AB' and
# 'CH גובה אל AB' bring their own point; the bisector — advertised beside
# them in the same list — did not, so the everyday 'AE חוצה זווית A' was
# refused for a point the sentence itself names, and the refusal's suggested
# fix named a side the bisector cannot meet. It builds its own E now (the
# internal bisector of a convex shape always leaves it through a side), and
# an E some other sentence pins still wins.
_MAY_NEW = {"bisector": 1}


def _check_letters(d, seen, sentence, kind, letters):
    """Every letter a datum names has to be a point the description defines:
    a vertex of the shape, or a point some sentence declares.

    r1 (S2-5): the side the refusal SUGGESTS is the one the datum can
    actually put the point on. The old template always wrote the first and
    the last letter of the shape ('E על AC' for a triangle ABC), which for
    every datum that hangs off a vertex is a side THROUGH that vertex — a
    suggestion whose only outcome is a second refusal."""
    for a in d.args:
        if a not in seen:
            _refuse(sentence,
                    "הנקודה %s אינה מוגדרת: %s הוא %s, ונקודה חדשה נכנסת רק "
                    "במשפט שמגדיר אותה (למשל '%s על %s')"
                    % (a, letters, kind, a, _away_from(d, letters)))


def _away_from(d, letters):
    """A side of the shape that does NOT pass through the vertex this datum
    hangs off — where a point it introduces can actually stand."""
    vertex = None
    if d.role == "bisector":
        vertex = d.args[2]
    elif d.role in ("median", "altitude"):
        vertex = d.args[0]
    n = len(letters)
    for i in range(n):
        side = letters[i] + letters[(i + 1) % n]
        if vertex is None or vertex not in side:
            return side
    return letters[0] + letters[-1]


# ----------------------------------------------------------------- build ---
def build(text, seed=0, rotate=0.0, fam=None, cap=30.0, size=None):
    """A description -> one finished SVG.

    The figure is SOLVED (`generate.Generator`), drawn by `shapekit` and
    checked by the engine on the way out. `seed` fixes the choice among the
    configurations the data leaves open — the same (text, seed) always gives
    the same figure. `cap` is a wall-clock SAFETY NET in seconds (v6.7):
    passing it raises generate.GenerateMachineError, never a refusal.

    The import is local so `describe` stays the pure grammar layer and
    `generate` may import it without a cycle."""
    sol = _parse_solid(_sentences(text))
    if sol is not None:
        return build_solid(sol, fam=fam)
    from generate import Generator
    return Generator(text, seed=seed, cap=cap).figure(
        rotate=rotate, fam=fam, size=size).svg



# ---------------------------------------------------------------- solids ---
class SolidDescription(object):
    """A parsed solid: its kind, its letters, and its data (Datum rows with
    role 'edge', 'r', 'h'). Pure, like Description."""

    def __init__(self, kind, letters, data, text):
        self.kind, self.letters = kind, letters
        self.data, self.text = list(data), text
        self.variant = None

    def of(self, role):
        return [d for d in self.data if d.role == role]

    def __repr__(self):
        return "SolidDescription(%s %s, %d data)" % (
            self.kind, self.letters, len(self.data))


def _parse_solid(sents):
    """The head sentence of a solid, or None when it is not one (then the
    plane grammar takes it, and refuses it with the whole list)."""
    if not sents:
        return None
    head = sents[0]
    for word, kind, dflt, nb in _SOLID_WORDS:
        m = re.match(r"^(?:ה)?%s(?:\s+([A-Z]+))?((?:\s*,?\s*[rhRH]\s*=\s*"
                     r"-?\d+(?:\.\d+)?%s)*)$" % (re.escape(word), _HEAD_HIDE),
                     head)
        if m:
            break
    else:
        return None
    letters = m.group(1) or dflt
    if kind in ("cylinder", "cone"):
        if m.group(1):
            _refuse(head, "לגליל ולחרוט אין אותיות קודקודים כאן; כתבו "
                          "למשל '%s r=2 h=5'" % word)
    elif len(letters) != len(dflt) or len(set(letters)) != len(letters):
        _refuse(head, "ל-%s יש %d קודקודים, אות לכל קודקוד (למשל %s)"
                % (word, len(dflt), dflt))
    elif kind in ("box", "cube") and letters != dflt:
        _refuse(head, "solidkit מסמן תיבה וקובייה ABCDEFGH (ABCD הבסיס, E "
                      "מעל A); כתבו '%s ABCDEFGH'" % word)
    data, where = [], []
    # r1: a datum in the HEAD sentence ('חרוט r=10 h=1') is its own token,
    # and '(לא בשרטוט)' may follow it there ('חרוט r=10 h=1 (לא בשרטוט)'),
    # so the route a refusal names for it is text this grammar reads.
    for tm in re.finditer(r"([rhRH])\s*=\s*(-?\d+(?:\.\d+)?)(%s)"
                          % _HEAD_HIDE, m.group(2) or ""):
        if kind not in ("cylinder", "cone"):
            _refuse(head, "r= ו-h= בשורת הכותרת הם של גליל ושל חרוט; "
                          "כתבו את הנתון במשפט משלו")
        tok = "%s=%s" % (tm.group(1), tm.group(2))
        data.append(Datum(tm.group(1).lower(), (), float(tm.group(2)),
                          not tm.group(3).strip(), tok))
        where.append((0, tm.group(0).strip(" ,")))
    for k, s in enumerate(sents[1:], 1):
        for bit in ([s] + ([b.strip() for b in s.split(",") if b.strip()]
                           if "," in s else [])):
            d = _solid_datum(bit, kind, letters)
            if d is not None:
                data.append(d)
                where.append((k, None))
                break
        else:
            _refuse(s, "נתון על גוף הוא מקצוע (AB = 4), רדיוס (r = 2) או "
                       "גובה (h = 5)")
    sd = SolidDescription(kind, letters, data, _clean("; ".join(sents)))
    sd.sents, sd.where = list(sents), where
    return sd


_HEAD_HIDE = r"(?:\s*\((?:לא בשרטוט|ללא סימון)\))?"


def _hidden_text(sd, idxs):
    """The description with data `idxs` marked '(לא בשרטוט)' -- the exact
    text a refusal hands the author (and parses back to that data)."""
    sents = list(sd.sents)
    for i in idxs:
        k, tok = sd.where[i]
        if tok is None:
            sents[k] = sents[k] + " (לא בשרטוט)"
        else:
            sents[k] = sents[k].replace(tok, tok + " (לא בשרטוט)", 1)
    return "; ".join(sents)


def _solid_datum(s, kind, letters):
    drawn = "(לא בשרטוט)" not in s and "(ללא סימון)" not in s
    m = _R_RX.match(s)
    if m:
        if kind not in ("cylinder", "cone"):
            _refuse(s, "רדיוס שייך לגליל או לחרוט")
        return Datum("r", (), float(m.group(1)), drawn, s)
    m = _H_RX.match(s)
    if m:
        if kind in ("box", "cube", "prism.triangle"):
            _refuse(s, "הגובה של %s הוא מקצוע: כתבו אותו כמקצוע, למשל "
                       "'%s%s = 5'" % (kind, letters[0],
                                       letters[4 if kind in ("box", "cube")
                                               else 3]))
        return Datum("h", (), float(m.group(1)), drawn, s)
    m = _E_RX.match(s)
    if m:
        a, b = m.group(1), m.group(2)
        if kind in ("cylinder", "cone"):
            _refuse(s, "לגליל ולחרוט אין מקצועות: r = ... ו-h = ...")
        for x in (a, b):
            if x not in letters:
                _refuse(s, "הנקודה %s אינה קודקוד של %s" % (x, letters))
        return Datum("edge", (a, b), float(m.group(3)), drawn, s)
    return None


def _edge_class(kind, letters, a, b):
    """Which defining length an edge carries, or None if a-b is no edge.
    box/cube: 'a' (AB), 'b' (BC), 'c' (AE); prism: 'c'=AB, 'a'=BC, 'b'=CA
    (and the same on the top), 'L' the lateral edges; pyramid: 'base<i>'
    for base edge i, 'lat' for an edge to the apex."""
    i, j = letters.index(a), letters.index(b)
    if kind in ("box", "cube"):
        import solidkit as SK
        V = SK._box_V(1.0, 2.0, 3.0)
        P, Q = V[a], V[b]
        diff = [k for k in range(3) if abs(P[k] - Q[k]) > 1e-9]
        if len(diff) != 1:
            return None
        return {0: "a", 2: "b", 1: "c"}[diff[0]]
    if kind == "prism.triangle":
        lo, up = sorted((i, j))
        if up - lo == 3:
            return "L"
        if (lo < 3) != (up < 3):
            return None
        pair = frozenset((lo % 3, up % 3))
        return {frozenset((0, 1)): "c", frozenset((1, 2)): "a",
                frozenset((0, 2)): "b"}[pair]
    # a pyramid: letters[0] is the apex
    if 0 in (i, j):
        return "lat"
    n = len(letters) - 1
    lo, up = sorted((i - 1, j - 1))
    if up - lo == 1 or (lo == 0 and up == n - 1):
        return "base%d" % (lo if up - lo == 1 else up)
    return None


def build_solid(sd, fam=None):
    """A SolidDescription -> the finished SVG (see _draw_solid).

    Doctrine 4 (grow before dropping): when the figure cannot print every
    datum readably at tier 'side', it is drawn BIGGER (tier 'block') and --
    a triangular prism -- LAID DOWN with its base facing the reader, before
    any datum is taken out of the drawing. Only when none of those renders
    does the refusal name a datum to mark '(לא בשרטוט)', and it names it as
    the WHOLE description to write, found by drawing that very variant.

    v6.7 (DETERMINISM): no clock decides anything here. Each attempt is one
    draw of one variant, and a failing fit stops after _FAIL_DRAWS failed
    draws (a COUNT, Scene._fail_fast); the variants are a fixed, finite
    list (every tier/pose, then every way of hiding one or two data) capped
    at _SOLID_ATTEMPTS. The same text renders, or is refused with the same
    message, on an idle machine, a loaded one, and in a cold process."""
    return _solid_routes(sd, fam, tries_of=_tries_of)[0]


_FAIL_DRAWS = 2          # failed draws after which one variant's fit gives up
_SOLID_ATTEMPTS = 96     # variants drawn at most, per description


def _tries_of(sd, data):
    """The fixed order of ways to draw `data`: tier 'side', tier 'block',
    and -- a triangular prism -- laid down on each lateral face."""
    out = [("side", None), ("block", None)]
    if sd.kind == "prism.triangle" and any(d.drawn for d in data):
        lt = sd.letters
        for i in range(3):
            j = (i + 1) % 3
            face = lt[i] + lt[j] + lt[j + 3] + lt[i + 3]
            for yaw in (90, -90):
                out.append(("side", (face, yaw)))
    return out


class _no_export(object):
    """A probe draw is not a figure: whatever it registers with the export
    is forgotten on the way out (solidkit's own route probe does the same)."""

    def __enter__(self):
        import export as _xp
        self.saved = (dict(_xp._FIGS), list(_xp._ORDER))

    def __exit__(self, *a):
        import export as _xp
        _xp._FIGS.clear()
        _xp._FIGS.update(self.saved[0])
        _xp._ORDER[:] = self.saved[1]
        return False


def _solid_routes(sd, fam, tries_of=None, finish=True):
    """Draw `sd` by the first variant that renders -> (result, tier, pose).
    Refuses (DescribeError) naming a whole description that renders, or --
    none does -- solidkit's own whole message and route."""
    tries_of = tries_of or _tries_of
    first = [None]
    count = [0]

    def attempt(data, tier, pose, fin):
        if count[0] >= _SOLID_ATTEMPTS:
            return None
        count[0] += 1
        try:
            return _draw_solid(sd, fam, data, tier=tier, pose=pose,
                               fail_fast=_FAIL_DRAWS, finish=fin)
        except DescribeError:
            raise
        except AssertionError as e:
            # v6.7 r1 (V67F-flat-cone-refusal-slow): DATA no variant can
            # draw (solidkit.SolidUndrawable) ends the search at once --
            # every other tier, pose and hidden datum is the same geometry
            if type(e).__name__ == "SolidUndrawable":
                raise DescribeError("describe: %r — %s" % (sd.text, e))
            if first[0] is None:
                first[0] = str(e)
            return None

    for tier, pose in tries_of(sd, sd.data):
        if finish:
            got = attempt(sd.data, tier, pose, True)
        else:
            # describe.solid(): the page adds add-ons and finishes itself,
            # so the variant is chosen by a FINISHED probe draw (which is
            # not a figure of the sheet: the export forgets it) and handed
            # back unfinished, at that tier and pose
            with _no_export():
                got = attempt(sd.data, tier, pose, True)
            if got is not None:
                got = _draw_solid(sd, fam, sd.data, finish=False, tier=tier,
                                  pose=pose)
        if got is not None:
            return got, tier, pose
    import itertools
    shown = [i for i, d in enumerate(sd.data) if d.drawn]
    lying = (u" וגם כשהגוף שוכב" if sd.kind == "prism.triangle" else "")
    for k in (1, 2):
        for idxs in itertools.combinations(shown, k):
            if k == len(shown):
                continue
            alt = list(sd.data)
            for i in idxs:
                alt[i] = alt[i]._replace(drawn=False)
            for tier, pose in tries_of(sd, alt):
                if attempt(alt, tier, pose, True) is not None:
                    route = _hidden_text(sd, idxs)
                    _refuse(sd.data[idxs[0]].text,
                            "השרטוט אינו יכול להדפיס את כל %d המספרים כך "
                            "שכל אחד ייקרא ליד המקצוע שלו, גם בגודל "
                            "'block'%s. כתבו: «%s» (נבדק: כך הוא משורטט). "
                            "solidkit: %s" % (len(shown), lying, route,
                                              first[0].split(" || ")[0]))
    # v6.7: nothing describe can write renders. The refusal is solidkit's
    # WHOLE message for the biggest drawing (tier 'block', every datum),
    # with the routes solidkit tried and found to render -- it used to be
    # cut at ' || ', which left only figkit's "enlarge the figure", a knob
    # describe does not have.
    whole = first[0]
    try:
        _draw_solid(sd, fam, sd.data, tier="block")
    except DescribeError:
        raise
    except AssertionError as e:
        whole = str(e)
    # v6.7 r1 (V67F-abstract-routes): solidkit's route is about the DATA
    # ("a bigger number"); the route that keeps the question's numbers is
    # named concretely -- the same text, printed with no figure
    raise DescribeError(
        "describe: %r — %s || route that keeps every number: print the "
        "question's text «%s» with no fig= (the solid in words, no drawing)"
        % (sd.text, whole, sd.text))


def _draw_solid(sd, fam, data, finish=True, tier="side", pose=None,
                fail_fast=None):
    """A SolidDescription -> the finished SVG, drawn by solidkit.

    The data become the solid's own parameters (so its volume, its surface
    and its metrics are the question's), and every datum that is drawn is
    printed on the edge the sentence named, where solidkit checks it
    against the edge's drawn length."""
    import solidkit as SK
    kind, lt = sd.kind, sd.letters
    fam = fam or "describe.%s" % kind
    vals, show = {}, []
    for d in data:
        if d.role == "edge":
            key = _edge_class(kind, lt, d.args[0], d.args[1])
            if key is None:
                _refuse(d.text, "%s%s אינו מקצוע של %s %s"
                        % (d.args[0], d.args[1], hebrew_solid(kind), lt))
        else:
            key = d.role
        if key in vals and abs(vals[key][0] - d.value) > 1e-9:
            _refuse(d.text, "סותר את '%s': אותו אורך (%s) קיבל שני ערכים"
                    % (vals[key][1], key))
        vals.setdefault(key, (d.value, d.text))
        if d.drawn:
            show.append(d)
        if d.value <= 0:
            _refuse(d.text, "אורך חייב להיות חיובי")
    v = dict((k, x[0]) for k, x in vals.items())
    need = {"box": ["a", "b", "c"], "cube": [], "cylinder": ["r", "h"],
            "cone": ["r", "h"], "prism.triangle": ["a", "b", "c", "L"],
            "pyramid.square": [], "pyramid.triangle": []}[kind]
    if kind == "cube":
        es = set(round(x, 9) for x in v.values())
        if len(es) > 1:
            _refuse(sd.text, "בקובייה כל המקצועות שווים, וכאן ניתנו %s"
                    % ", ".join(sorted("%g" % x for x in es)))
    miss = [k for k in need if k not in v]
    if v and miss:
        names = {"r": "r", "h": "h"}
        if kind == "box":
            names.update(a=lt[:2], b=lt[1:3], c=lt[0] + lt[4])
        if kind == "prism.triangle":
            names.update(a=lt[1:3], b=lt[2] + lt[0], c=lt[:2],
                         L=lt[0] + lt[3])
        _refuse(sd.text, "חסרים נתונים: %s — גוף צריך את כל האורכים שמגדירים "
                "אותו, או אף אחד (ואז הוא משורטט בלי מספרים)"
                % ", ".join("%s = ..." % names.get(k, k) for k in miss))
    labelled = bool(v)
    if kind == "box":
        a, b, c = (v["a"], v["b"], v["c"]) if labelled else (6.0, 3.0, 4.0)
        sc, s = SK.box(a, b, c, labels=False, fam=fam, tier=tier)
    elif kind == "cube":
        e = list(v.values())[0] if labelled else 4.0
        sc, s = SK.cube(e, label=False, fam=fam, tier=tier)
    elif kind in ("cylinder", "cone"):
        r, h = (v["r"], v["h"]) if labelled else (3.0, 7.0)
        lab = {"r": None, "h": None}
        for d in show:
            lab[d.role] = True
        mk = SK.cylinder if kind == "cylinder" else SK.cone
        sc, s = mk(r, h, labels=lab if labelled else False, fam=fam,
                   tier=tier)
        sc.kindname = "solidkit.%s" % kind
        if fail_fast is not None:
            sc._fail_fast, sc._probing = fail_fast, True
        return SK.finish(sc, fam) if finish else (sc, s)
    elif kind == "prism.triangle":
        if labelled:
            a, b, c, L = v["a"], v["b"], v["c"], v["L"]
        else:
            a, b, c, L = 6.0, 5.0, 4.0, 9.0
        sc, s = SK.prism("triangle", L=L, names=(lt[:3], lt[3:]),
                         labels=False, fam=fam, variant="sss", a=a, b=b, c=c,
                         tier=tier, pose=pose)
    else:
        base = kind.split(".")[1]
        apex, bl = lt[0], lt[1:]
        edges = [v[k] for k in v if k.startswith("base")]
        if len(set(round(x, 9) for x in edges)) > 1 and base == "square":
            _refuse(sd.text, "לבסיס ריבועי כל הצלעות שוות")
        if base == "square":
            data = dict(a=edges[0] if edges else (6.0 if not v else None))
        else:
            ks = ["base0", "base1", "base2"]
            if v and any(k not in v for k in ks):
                _refuse(sd.text, "חסרים נתונים: כל שלוש צלעות הבסיס %s"
                        % ", ".join(bl[i] + bl[(i + 1) % 3] + " = ..."
                                    for i in range(3) if ks[i] not in v))
            data = (dict(variant="sss", c=v["base0"], a=v["base1"],
                         b=v["base2"]) if v else
                    dict(variant="sss", a=6.0, b=5.0, c=5.5))
        if v and data.get("a") is None:
            _refuse(sd.text, "חסר נתון: צלע הבסיס (%s = ...)" % bl[:2])
        pts2, _ex = SK._base_polygon("describe", base, data)
        cx = sum(p[0] for p in pts2) / len(pts2)
        cz = sum(p[1] for p in pts2) / len(pts2)
        # the height: given, or from a lateral edge (h^2 = SX^2 - |XO|^2)
        hs = []
        if "h" in v:
            hs.append((v["h"], vals["h"][1]))
        for d in sd.data:
            if d.role == "edge" and _edge_class(kind, lt, *d.args) == "lat":
                X = d.args[1] if d.args[0] == apex else d.args[0]
                p = pts2[bl.index(X)]
                r2 = (p[0] - cx) ** 2 + (p[1] - cz) ** 2
                if d.value ** 2 <= r2:
                    _refuse(d.text, "מקצוע צדדי קצר מדי: הוא חייב להיות "
                            "ארוך מ-%s" % round(math.sqrt(r2), 3))
                hs.append((math.sqrt(d.value ** 2 - r2), d.text))
        if v and not hs:
            _refuse(sd.text, "חסר נתון: הגובה (h = ...) או מקצוע צדדי "
                    "(%s%s = ...)" % (apex, bl[0]))
        for hv, t in hs[1:]:
            if abs(hv - hs[0][0]) > 1e-6 * max(hv, 1.0):
                _refuse(t, "סותר את '%s': הגובה יוצא %s ולא %s"
                        % (hs[0][1], round(hv, 4), round(hs[0][0], 4)))
        h = hs[0][0] if hs else 7.0
        sc, s = SK.pyramid(base, h=h, names=bl, apex=apex, labels=False,
                           fam=fam, tier=tier, **data)
    for d in show:
        if d.role == "edge":
            s.edge_label(d.args[0] + d.args[1], given=d.value)
        elif d.role == "h":
            _pyramid_height(SK, sc, s, d.value)
    sc.kindname = "solidkit.%s" % kind
    if fail_fast is not None:
        sc._fail_fast, sc._probing = fail_fast, True
    return SK.finish(sc, fam) if finish else (sc, s)


def solid(text, fam=None):
    """A solid description -> `(scene, solid)`, NOT finished: the page adds
    solidkit add-ons (a diagonal, a section) and reads `solid.metrics` (V,
    S, ...) for its answer key -- the same numbers the figure was built
    from -- then calls `solidkit.finish(scene, fam)`."""
    sd = _parse_solid(_sentences(text))
    if sd is None:
        raise DescribeError("describe.solid: %r is not a solid — %s"
                            % (text, understood("גוף")))
    # v6.7: it GROWS like build() -- side, block, a prism laid down -- so a
    # text build() renders is not refused when a page takes this route
    # (the variant is picked by a finished probe; the page's add-ons then
    # draw on the scene at that tier and pose)
    return _solid_routes(sd, fam or "describe.%s" % sd.kind, finish=False)[0]


def _pyramid_height(SK, sc, s, h):
    """A pyramid's height, drawn: the altitude from the apex to the base's
    centre O (dashed -- it runs through the body), its right angle, and the
    number on a dimension line outside the drawing."""
    bl, apex = s.base_names, s.apex
    O = tuple(sum(s.p3(k)[i] for k in bl) / len(bl) for i in range(3))
    free = [c for c in "OHPQK" if c not in s.V][0]
    s._add_point(free, O)
    sc.line(s.p2(apex), s.p2(free), 1.2, SK.AUX)
    s.right_mark(free, apex, bl[0])
    S2, O2 = s.p2(apex), s.p2(free)
    sc.dim(O2, S2, off="out", text=SK._n(h))
    sc.check("h", O2, S2, h, s._shrink(SK.sub3(s.p3(apex), O)))


def hebrew_solid(kind):
    for word, k, _l, _n in _SOLID_WORDS:
        if k == kind:
            return word
    return kind


# v6.5 X2 r1 (MUST-3, spec rule 6): the author's call into this module
# is recorded as source, so figures/<id>.py can re-draw the figure.
import export as _export_rec  # noqa: E402
build = _export_rec.entry(build)

if __name__ == "__main__":                                  # a 2-line smoke
    d = parse("ריבוע ABCD; G על AD; ∠GBA = 37°")
    print(d, [x.role for x in d.data])
