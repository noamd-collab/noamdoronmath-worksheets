# -*- coding: utf-8 -*-
"""build_plus — v7.1.1-noam. The stock build, with G76, G77, item figures,
G82 FIG_REF, G83 FIG_DENSITY (gate_figref), and G84 CHRONOLOGY.

`build.py` is not edited and not copied. This file installs the wrappers
into `emit_html` and then runs `build.py` itself, so a package built this way
gets G74, G75, G76, G77, G82, G83, G84 and 4-tuple item figures, and a package
built the old way still works exactly as before.

    cd <package folder>          # holds content.py
    DYLD_FALLBACK_LIBRARY_PATH=/opt/homebrew/lib python3 /path/to/build_plus.py

Everything build.py documents still applies: LEVELS, figure_sheet, TITLE, ORIG,
SOURCE, COLON_DIVISION_OK.
"""
import re
import runpy
import sys
from pathlib import Path

V = Path(__file__).resolve().parent
sys.path.insert(0, str(V))

import didactic as DD                                  # noqa: E402
import emit_plus                                       # noqa: E402
import gate_variety                                    # noqa: E402
import gate_figref                                     # noqa: E402

# ---------------------------------------------------------------------------
# G84 CHRONOLOGY (v7.1.1-noam): forbid concepts/terms not yet taught at the
# worksheet's point in curriculum_tashpaz.json / curriculum_tools.json.
# Each entry maps a tool_id in `not_yet_allowed` to:
#   (compiled_regex, concept_label_he, replacement_guidance_he)
# ---------------------------------------------------------------------------
_CHRONOLOGY_TOOL_RULES = [
    ("thm.pythagoras",
     re.compile(
         r"(?<![א-ת])(?:"
         r"פיתגורס"
         r"|(?:היתר|ליתר|מהיתר|ביתר)"
         r"|(?<!בין\s)יתר(?!\s+(?:על|הצלעות|הזוויות|הנקודות|הקודקודים|הסעיפים|המספרים|החלקים))"
         r"|(?:הניצב|לניצב|מהניצב|ניצבים|הניצבים|לניצבים|מהניצבים|ניצביו|ניצבי)"
         r")(?![א-ת])"
     ),
     "משפט פיתגורס / יתר / ניצבים (נלמדים רק החל מפרק משפט פיתגורס בסוף כיתה ז׳)",
     "כתבו את שם הצלע המפורש (למשל 'הצלע DF') או 'שתי הצלעות המאונכות זו לזו' / 'הצלעות של הזווית הישרה' — ללא המילים 'יתר' או 'ניצבים'"),
    ("thm.exterior_angle",
     re.compile(r"(?<![א-ת])ו?[בהלמ]?זוויו?ת\s+ה?חיצוניו?ת(?![א-ת])"),
     "זווית חיצונית למשולש (נלמדת רק בכיתה ח׳)",
     "השתמשו בזוויות צמודות על ישר (סכומן 180°) ובסכום זוויות במשולש ללא המונח 'זווית חיצונית'"),
    ("thm.isosceles_base_angles",
     re.compile(r"(?<![א-ת])ו?[בהלמ]?זוויות\s+הבסיס(?![א-ת])"),
     "זוויות הבסיס במשולש שווה־שוקיים (המונח והמשפט נלמדים בכיתה ח׳)",
     "ציינו את שמות הזוויות בשלוש אותיות (למשל ∡ABC ו־∡ACB) או כתבו 'שתי הזוויות השוות'"),
    ("thm.isosceles_special_lines",
     re.compile(r"(?<![א-ת])(?:"
                r"חוצה\s+זווית\s+הראש"
                r"|(?:התיכון|לתיכון|מהתיכון|תיכונים|התיכונים)"
                r"|תיכון\s+ל[בצ]"
                r")(?![א-ת])"),
     "תיכון במשולש / התלכדות חוצה זווית הראש, תיכון וגובה במשולש שווה־שוקיים (נלמד בכיתה ח׳)",
     "לפני כיתה ח׳ תארו נקודת אמצע באופן מפורש ('הנקודה M היא אמצע הצלע BC', BM = MC) ללא המונח 'תיכון'"),
    ("thm.congruence_sas",
     re.compile(r"(?<![א-ת])(?:"
                r"משולשים\s+חופפים|חפיפת\s+משולשים|משפטי?\s+ה?חפיפה"
                r"|צ\.ז\.צ|ז\.צ\.ז|צ\.צ\.צ|צ\.צ\.ז"
                r")(?![א-ת])|\\cong"),
     "חפיפת משולשים ומשפטי החפיפה (נלמדים בכיתה ח׳)",
     "הימנעו ממונחי חפיפה וסימן ≅ לפני פרק חפיפת משולשים בכיתה ח׳"),
    ("thm.similarity_aa",
     re.compile(r"(?<![א-ת])(?:"
                r"משולשים\s+דומים|דמיון\s+משולשים|יחס\s+ה?דמיון|מקדם\s+ה?דמיון"
                r")(?![א-ת])"),
     "דמיון משולשים ויחס דמיון (נלמדים בכיתה ח׳)",
     "הימנעו ממונחי דמיון משולשים ויחס דמיון לפני פרק הדמיון בכיתה ח׳"),
    ("thm.similar_area_ratio",
     re.compile(r"(?<![א-ת])ריבוע\s+יחס\s+הדמיון(?![א-ת])"),
     "יחס השטחים במשולשים דומים (נלמד בכיתה ט׳)",
     "חשבו את השטחים עצמם או את היחס ביניהם ישירות מתוך אורכי הצלעות והגבהים"),
    ("thm.midsegment",
     re.compile(r"(?<![א-ת])ו?[בהלמ]?קטעי?\s+ה?אמצעים(?![א-ת])"),
     "קטע אמצעים במשולש או בטרפז (נלמד בכיתה ט׳)",
     "לפני פרק קטע האמצעים תארו 'הנקודות D ו־E הן אמצעי הצלעות...' ללא המונח 'קטע אמצעים'"),
    ("thm.median_to_hypotenuse",
     re.compile(r"(?<![א-ת])ו?[בהלמ]?תיכון\s+ליתר(?![א-ת])"),
     "משפט התיכון ליתר (נלמד בכיתה ט׳)",
     "הימנעו מהמונח והמשפט 'תיכון ליתר' לפני פרק משפט התיכון ליתר בכיתה ט׳"),
    ("thm.30_60_90",
     re.compile(r"(?<![א-ת])משולש\s+(?:זהב|30\s*[-–]\s*60\s*[-–]\s*90)(?![א-ת])"),
     "משולש 30°-60°-90° (נלמד בכיתה ט׳)",
     "הימנעו ממשפט משולש 30°-60°-90° לפני הוראתו בכיתה ט׳"),
    ("thm.kite_main_diagonal",
     re.compile(r"(?<![א-ת])האלכסון\s+ה(?:ראשי|משני)(?![א-ת])"),
     "האלכסון הראשי והאלכסון המשני בדלתון (נלמדים בכיתה ט׳)",
     "בכיתות ז׳–ח׳ נקבו בשמות האלכסונים המפורשים (למשל 'האלכסונים AC ו־BD') ללא המונחים 'האלכסון הראשי/המשני'"),
    ("thm.isosceles_trapezoid",
     re.compile(r"(?<![א-ת])טרפז\s+שווה[\s־-]שוקיים(?![א-ת])"),
     "טרפז שווה־שוקיים ומשפטיו (נלמדים בכיתה ט׳)",
     "לפני פרק הטרפז בכיתה ט׳ כתבו 'טרפז ABCD שבו השוקיים שוות באורכן (AB = CD)' במקום המונח 'טרפז שווה־שוקיים'"),
    ("alg.slope",
     re.compile(r"(?<![א-ת])(?:"
                r"שיפוע\s+ה?ישר|השיפוע|פונקציה\s+קווית|הפונקציה\s+הקווית|משוואת\s+ה?ישר"
                r")(?![א-ת])"),
     "שיפוע ופונקציה קווית y = mx + b (נלמדים בכיתה ח׳)",
     "בכיתה ז׳ השתמשו בטבלת ערכים, קצב השתנות או ישרים המקבילים לצירים ללא מושגי השיפוע ומשוואת ישר"),
    ("alg.linear_inequality",
     re.compile(r"(?<![א-ת])אי[\s־-]שוויו(?:ן|נות)(?!\s+המשולש)(?![א-ת])"),
     "אי־שוויונות קוויים (נלמדים בכיתה ח׳)",
     "בכיתה ז׳ השוו מספרים או ביטויים באמצעות סימני <, >, = ללא המושג האלגברי 'אי־שוויון'"),
    ("alg.linear_system_sub",
     re.compile(r"(?<![א-ת])(?:מערכת\s+משוואות|שיטת\s+ההצבה|השוואת\s+מקדמים)(?![א-ת])"),
     "מערכת משוואות לינאריות בשני נעלמים (נלמדת בכיתה ח׳)",
     "בכיתה ז׳ בטאו את הגדלים באמצעות משתנה יחיד x ובנו משוואה בנעלם אחד"),
    ("alg.short_mult_diff_sq",
     re.compile(r"(?<![א-ת])(?:ה?כפל\s+ה?מקוצר|נוסחאות\s+הכפל|הפרש\s+ריבועים)(?![א-ת])"),
     "נוסחאות הכפל המקוצר (נלמדות בכיתה ט׳)",
     "לפני כיתה ט׳ פתחו סוגריים באמצעות חוק הפילוג בלבד ללא מונחי הכפל המקוצר"),
    ("alg.trinomial",
     re.compile(r"(?<![א-ת])טרינום(?![א-ת])"),
     "פירוק טרינום ריבועי (נלמד בכיתה ט׳)",
     "הימנעו מהמונח 'טרינום' לפני פרק פירוק לגורמים בכיתה ט׳"),
    ("alg.parabola_vertex",
     re.compile(r"(?<![א-ת])ו?[בהלמ]?פרבולה(?![א-ת])"),
     "הפונקציה הריבועית והפרבולה (נלמדות בכיתה ט׳)",
     "הימנעו ממושגי הפרבולה והפונקציה הריבועית לפני הוראתם בכיתה ט׳"),
    ("alg.quadratic_formula",
     re.compile(r"(?<![א-ת])(?:נוסחת\s+השורשים|משוואה\s+ריבועית|דיסקרימיננטה)(?![א-ת])"),
     "משוואה ריבועית ונוסחת השורשים (נלמדות בכיתה ט׳)",
     "הימנעו ממושגי המשוואה הריבועית ונוסחת השורשים לפני הוראתם בכיתה ט׳"),
]

_HIGH_SCHOOL_ONLY_RE = re.compile(
    r"(?<![א-ת])(?:"
    r"טריגונומטרי[הת]|סינוס|קוסינוס|טנגנס|חוק\s+הסינוסים|חוק\s+הקוסינוסים"
    r"|משפט\s+תא?לס|לוגריתם|נגזרת|אינטגרל"
    r")(?![א-ת])"
)


def _flat_str(val):
    if val is None:
        return ""
    if isinstance(val, str):
        return val
    if isinstance(val, (list, tuple)):
        return " ".join(_flat_str(x) for x in val)
    if isinstance(val, dict):
        return " ".join(_flat_str(val.get(k)) for k in ("intro", "text", "answer", "approved_hint"))
    return str(val)


def assert_chronology(L, package=None, verbose=True):
    """G84-chronology: refuse any concept/term in intro, text, items, answers,
    final_answers, or approved_hint that belongs to a curriculum unit in
    `not_yet_allowed` (or high-school-only material)."""
    pkg = L.get("package") or package or gate_figref.package_of(Path.cwd() / "content.py")
    cur_spec = L.get("curriculum")
    if not cur_spec:
        return
    grade = L.get("grade") or (
        str(pkg)[1] if isinstance(pkg, str) and len(str(pkg)) >= 2 and str(pkg)[0] == "G" and str(pkg)[1].isdigit()
        else None
    )
    reg = DD.load_tools()
    try:
        cur = DD.curriculum_block(cur_spec, grade, reg)
    except Exception:
        return
    not_yet = set(t["id"] for t in cur.get("not_yet_allowed") or [])
    if pkg == "G9-T47":
        not_yet.discard("thm.midsegment")
    exceptions = L.get("chronology_exceptions") or {}
    active_rules = [
        (tid, rx, label_he, fix_he)
        for tid, rx, label_he, fix_he in _CHRONOLOGY_TOOL_RULES
        if tid in not_yet
    ]

    violations = []

    def _scan_text(loc, text, q_num=None):
        if q_num is not None and q_num in exceptions:
            return
        s = _flat_str(text)
        if not s:
            return
        m_hs = _HIGH_SCHOOL_ONLY_RE.search(s)
        if m_hs:
            violations.append(
                f"{loc}: מופיע המונח העל־חטיבתי '{m_hs.group(0)}' (אינו בחומר הלימוד של כיתות ז׳–ט׳)"
            )
        for tid, rx, label_he, fix_he in active_rules:
            m = rx.search(s)
            if m:
                violations.append(
                    f"{loc}: מופיע המונח '{m.group(0)}' השייך ל־[{tid}: {label_he}] שטרם נלמד בנקודה זו ברצף הלימודים ({cur.get('track')} / {cur.get('topic')}). תיקון: {fix_he}."
                )

    for q in L.get("questions") or []:
        qn = q.get("n")
        qloc = f"q{qn}"
        _scan_text(f"{qloc}.intro", q.get("intro"), qn)
        _scan_text(f"{qloc}.text", q.get("text"), qn)
        _scan_text(f"{qloc}.answer", q.get("answer"), qn)
        _scan_text(f"{qloc}.approved_hint", q.get("approved_hint"), qn)
        for idx, it in enumerate(q.get("items") or []):
            if isinstance(it, dict):
                ilab = it.get("label") or str(idx + 1)
                _scan_text(f"{qloc}.{ilab}.text", it.get("text"), qn)
                _scan_text(f"{qloc}.{ilab}.answer", it.get("answer"), qn)
                _scan_text(f"{qloc}.{ilab}.approved_hint", it.get("approved_hint"), qn)
            elif isinstance(it, (list, tuple)) and len(it) >= 2:
                ilab = it[0]
                _scan_text(f"{qloc}.{ilab}.text", it[1], qn)

    for field in ("answers", "final_answers"):
        ans_block = L.get(field)
        if isinstance(ans_block, dict):
            for k, v in ans_block.items():
                _scan_text(f"{field}[{k}]", v)
        elif isinstance(ans_block, (list, tuple)):
            for idx, v in enumerate(ans_block, 1):
                _scan_text(f"{field}[{idx}]", v)

    lvl_name = L.get("key") or L.get("level") or "?"
    if violations:
        msg = (
            f"G84-chronology FAIL on level '{lvl_name}' "
            f"(package={pkg}, track={cur.get('track')}, topic={cur.get('topic')}):\n  - "
            + "\n  - ".join(violations)
        )
        raise AssertionError(msg)
    if verbose:
        print(
            f"G84-chronology {lvl_name:<4} PASS (track={cur.get('track')}, "
            f"topic={cur.get('topic')}, 0 premature terms)"
        )


def _install_chronology(package=None):
    import emit_html as E
    if getattr(E.assert_figure_variety, "_g84_installed", False):
        return E.assert_figure_variety
    inner = E.assert_figure_variety

    def wrapped(L):
        r = inner(L)
        assert_chronology(L, package=package, verbose=True)
        return r

    wrapped._g84_installed = True
    wrapped._inner = inner
    for k in ("_g76_installed", "_g82_installed"):
        if getattr(inner, k, False):
            setattr(wrapped, k, True)
    wrapped.__doc__ = (inner.__doc__ or "") + "\n\nWrapped by build_plus (G84 CHRONOLOGY)."
    E.assert_figure_variety = wrapped
    return wrapped


emit_plus.install()          # 4-tuple items: a figure inside a sub-item
gate_variety.install()       # G76 variety + G77 visual density
# (v6.16 fix r1, W-FIGURE-DENSITY) G82 FIG_REF + G83 FIG_DENSITY, after G78;
# the figure-topic status reads the package id of THIS build's content.py
_PKG = gate_figref.package_of(Path.cwd() / "content.py")
gate_figref.install(package=_PKG)
_install_chronology(package=_PKG)
runpy.run_path(str(V / "build.py"), run_name="__main__")
