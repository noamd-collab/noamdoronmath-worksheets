# -*- coding: utf-8 -*-
r"""numberline — v6 stage 1 (C4). The number-line builder.

WHY THIS FILE EXISTS
--------------------
Number lines were drawn by package-local helpers (z01 `nline`, `dline`,
`dbars`, `_decorate`, `_fit`, ...) on top of the generic label solver. The
author found, on one sheet: tick numbers slid off their ticks that verify()
passed (28ב), a −0.5 dot printed on the 0 tick (3ג), −120 and −75 merged into
one blob (36), jump heads buried in the landing dot or the next jump (8ב,
22ב), an open circle touching the arrowhead (q20), lines numbered every fifth
tick (28ב, 34ב, 2ב), a bracket from 0 to −5 beside "find the distance of −5"
(1ג/34ב), and a reversed range that drew nothing and said nothing.

This builder draws a number line FROM ITS NUMBERS. Every value is a
`fractions.Fraction`; ticks are anchored at multiples of `tick` counted from
0; tick numbers are pinned (never solved); every mark is checked against the
line's range and ticks when it is added; and every render is read back from
the finished SVG by `svgcheck` (struck labels, minus signs, font floor, tick
alignment, arrowheads, dots on other ticks, markers, reading merges) and by
this module's own `sweep()`, which parses the SVG through `svgcheck.model`
and reads nothing from the builder's records: printed tick spacing, three
tick lengths, label spacing, arc heights, head boxes, rims against axis ends,
and the set a bar-and-circle drawing shows against its inequality.

QUICK API
---------
    import numberline as N
    N.new_sheet(arrows="right")                  # once per sheet
    nl = N.NL(-2, 2, tick=F(1, 4))               # labels −2..2, 3 tick lengths
    nl.point(F(3, 4), "A").jump(-2, 1, "+3")
    svg = nl.svg()

    NL(lo, hi, tick=1, label_every="auto", label_fmt="auto"|"int"|"dec"|
       "frac"|"mixed", plus_sign=False, zero_emph=False, tier="side",
       width=None, unit=None, sparse=False, label_at=None, sketch=False,
       blank=False, arrows=None, answer_values=(), answer_hidden=(),
       tick_pt=None, fam=None)
    .point(v, name=None, style="filled"|"open"|"cross"|"tri"|"square",
           value_label=False|True|"3.2", between=False)  # True: drawn like a
                                                   # tick number (stacked 1/3)
    .span(a, b, label=None, kind="bracket"|"arrow2")
    .symmetric(a, label=True, kind="arrow2", between=False)   # −a..0, 0..a
    .double_arrow(center, d, label=None, between=False)       # ±d from centre
    .midpoint(a, b, name="M")
    .jump(a, b, label=None) / .chain([v0, v1, ...], labels=[...])
    .repeat(start, step, n, label=None)
    .from_inequality("2x+3 <= 7", closed=None, domain=None, between=False)
    .interval(a, b, closed_a, closed_b, source=None, between=False) -> Set
    .ray(a, "left"|"right", closed=True, source=None, between=False) -> Set
                                     # ONE set per line; boundaries on ticks
    .union(A, B, source=None) / .intersect(A, B, source=None) -> Set
    .all_reals(source=) / .empty(source=)                     -> Set
    .integers_in(S, domain=None, between=False)               -> [values]
    .test_markers([(v, "x"|"tri")])
    .svg() / .render()

    solve(src) -> Set; interval(...), ray(...), union(...), intersect(...)
    sweep(svg, member=None) -> [problems]  (independent; see its docstring)

C5 -- more than one line, and lines that are not horizontal:

    NL(..., orientation="v", height=230)          # a vertical scale
    .reference(v, kind="level"|"mirror"|"sea", both_sides=True, label=None)
    .bars_from_zero(values, order="given"|"asc", row_ids=None, min_len_pt=3)
    .zoom(a, b, subdiv=10)                        -> Stack (.parent, .child)
    stack(rows, scale="shared"|"own", captions=[...], connect=[values])
                                                  -> Stack (.svg(), .html())
    double(scale_a, scale_b, parts, hide_a=(), hide_b=(), pairs=(),
           ratio=True, captions=(over, under))    -> Double
    sign_chart(roots, signs, closed=True, poly=None, touch=(),
               student_drawing=False, asks=None)  -> NL
    NL(..., student_drawing=True, asks=["find_error"],
       wrong_scale=[(v, "2.5")])                  # a wrong line to criticise
    sweep_v(svg, dots=[values]) / stack_sweep / double_sweep / sign_sweep
    critique_guard(question)                      # emit_html calls it

C5 r2 -- three rules the first round left open:

  * double() refuses scale_b ends that are not multiples of its step: the
    axis ticks stand at multiples of the step from 0, so the line would print
    other numbers than the parts it declares. The refusal names the swap that
    works (double((32, 212), (0, 100), 10, ratio=False)) and, where one
    exists, a parts= whose step divides both ends.
  * sweep_v(dots=[...]) runs the dot-on-its-value check in the turned frame;
    render() feeds it, so an upright line is no weaker than a flat one.
  * sign_chart(..., student_drawing=True, asks=["find_error"]) draws the
    chart WRONG on purpose. It needs poly=: the disagreements with the
    polynomial are kept instead of refused, and a chart that is in fact right
    is refused (the giveaway rule).

C5 r3 -- the rules that were written and never reached:

  * critique_guard(q) reads EVERY figure of the question -- q["fig"] and the
    figure of each 4-tuple sub-item -- and emit_plus calls it for every
    question, so a wrong drawing can no longer ship through the item route.
  * a critique LINE must be drawn wrong: a wrong_scale number, a set that
    disagrees with its inequality, or an error the drawing cannot show by
    itself, named in words -- student_drawing="the point stands at 3, the
    answer is 2". The flag alone is refused (the giveaway rule, as for a
    sign chart).
  * render() runs sign_sweep on a sign chart (with its polynomial, unless it
    is a critique chart) and passes ratio= to double_sweep.
  * reference(v) is held to answer_hidden like every other mark; double()
    refuses both halves of one pair hidden, by name; a zoom's printed-floor
    refusal names subdiv=, the parameter the author passed.

Every layout is computed in one SCALE FRAME (x along the scale, y across it,
decorations above, numbers below). A horizontal line prints the frame as it
is; a vertical line prints it turned, (x, y) -> (-y, -x), with the text left
upright, so one jump / span / letter layout serves both. Captions are HTML
beside the figure, never text inside it (G49).

Jumps are grounded at their ticks (other side, then a taller arc, then a
lower arc nested under an overlap; labels slid along the arc); see
NL._layout_jumps. Refusals found while laying out are raised after the
printed floors.

Text on the line is Latin (a Hebrew name or label is refused: it prints
reversed inside SVG). `answer_hidden` values are positions: a jump label is
a displacement and is not compared with them. C4 r3: jump and span labels
are read back from the SVG by `sweep` (owner, middle, value).

"""
import hashlib
import math
import re
from fractions import Fraction as F

import export
import svgcheck

PX_TO_PT = 0.75
INK = "#111"
FACE = "David Libre,serif"
MINUS = u"−"

# -- placement tiers: the widest px a line may print at; the tick numbers
# print at ONE size on every tier (the unit is fitted, the font never shrinks)
TIERS = {"item": 150.0, "side": 205.0, "block": 420.0, "strip": 600.0}

# -- ONE HOUSE LOOK (stage review, the author 2026-09-18) --------------------
# v6.1 gave plane()/wide() a house look in pt (figkit_plus.HOUSE) and left
# numberline on its own numbers: a sheet with a plane above a number line
# printed 7.95pt numbers over 7.50pt ones, 4.5pt ticks over 6.8pt ones, and
# a 0.82pt axis over a 1.05pt one -- two looks side by side on z08_a page 1,
# with G78 reporting only the planes.  figkit_plus.new_sheet(number_pt=...)
# did not reach a number line at all.  The Typst reference the author
# compared us against prints ONE look on both kinds; so do we now.  Every
# printed size below is HOUSE, converted to px where the emitter wants px.
_HOUSE = None


def _house():
    """figkit_plus.HOUSE, or None when numberline is used on its own.
    Imported here (not at the top) only so that a broken figkit_plus never
    stops a number line from drawing."""
    global _HOUSE
    if _HOUSE is None:
        try:
            import figkit_plus as _FP
            _HOUSE = _FP.HOUSE
        except Exception:                                   # pragma: no cover
            _HOUSE = {}
    return _HOUSE


def _hpt(key, fallback):
    """A printed pt from HOUSE."""
    return float(_house().get(key, fallback))


def _hpx(key, fallback):
    """A HOUSE printed pt as the px the emitter draws in."""
    return _hpt(key, fallback) / PX_TO_PT


TICK_PT = _hpt("number_pt", 8.0)      # printed tick-number size (every tier)
LETTER_PT = _hpt("letter_pt", 9.5)    # point letters
AXIS_W = _hpx("axis_pt", 0.8)         # 0.80pt printed, as a plane's axes
BAR_W = 2.5 * AXIS_W     # a set's thick bar
TICK_W = _hpx("tick_pt", 0.6)         # 0.60pt printed, as a plane's ticks
# full length, printed px. A plane's tick is 2 x tick_half_pt across its
# axis; a number line keeps its 9:6:4 major/half/minor ladder underneath.
TICK_LEN = dict((k, 2.0 * _hpx("tick_half_pt", 2.2) * v / 9.0)
                for k, v in (("major", 9.0), ("half", 6.0), ("minor", 4.0)))
ZERO_EXTRA = 3.0         # zero_emph: the 0 tick this much longer
MINOR_GAP_PT = 6.0       # printed floor between two ticks
LABEL_SPACING = 1.6      # numbered ticks >= this x the widest number apart
TICK_TOL = 0.15          # a tick number's centre, x tick spacing
# v6 P2: 3.5pt printed as a blob beside the numbers (the author, against the
# Typst line: a 2.3pt dot with a 0.8pt rim); the stage review then found 2.7
# standing beside a plane's 2.04pt dots.  ONE radius serves every marker
# style here (filled, open, tri, square, cross), so it is the plane's OPEN
# marker size -- HOUSE["open_pt"] -- which is also svgcheck's readability
# floor for a ring (MARKER_R_PT = 2.4).
# ONE radius serves every style here (filled, open, tri, square, cross) and
# P2-L2-r2-01 keeps them one family, so it is the plane's OPEN marker size --
# HOUSE["open_pt"] -- which is also svgcheck's readability floor for a ring
# (MARKER_R_PT = 2.4). A plane's FILLED dot is 2.0pt; a number line's is this,
# 0.36pt larger, because the same circle has to read as an open ring too.
MARK_R_PT = _hpt("open_pt", 2.4)      # every marker, half its extent, printed
POINT_GAP_PT = 1.5       # two points on different values: >= 2r + this
ARROW_GAP_PT = 1.5       # a head's tip from a dot's rim / the next shaft
RIM_CLEAR_PT = 3.0       # an end circle's rim from the axis end / arrowhead
# axis/jump arrowhead: length, half-width (px), from the plane's filled
# axis head (head_pt long, head_deg half-angle)
HEAD = (_hpx("head_pt", 5.0),
        _hpx("head_pt", 5.0) * math.tan(math.radians(_hpt("head_deg", 20.0))))
RAY_HEAD = (HEAD[0] * 8.5 / 7.0, HEAD[1] * 4.2 / 3.2)
# The band of stroke weights an independent sweep reads as "an axis" -- kept
# relative to AXIS_W so that a change of house look never quietly stops the
# sweeps finding the axis (it did: at 1.067 the literal 1.2 floor made
# sweep_v report "no vertical axis" and stack_sweep "the drawing shows 0").
LEGACY_TAG = "<!--legacy-numberline-->"   # the figkit.number_line shim's own
                                         # size=/font=, read by G78
AXIS_W_LO = AXIS_W * 6.0 / 7.0
AXIS_W_HI = AXIS_W * 1.7 / 1.4
ZERO_W = TICK_W * 2.0      # zero_emph: the 0 tick's stroke
TICK_W_HI = ZERO_W * 1.1   # the widest stroke a sweep reads as a TICK. Tied
                           # to the tick pen, not the axis pen: at the house
                           # look the emphasised 0 tick (1.6) stood above the
                           # axis band and the sweeps lost the 0 tick, so '0'
                           # snapped to the -1 tick and read as a stacked
                           # number '-1/0'. Stays well under BAR_W.
ARC_MIN = 5.0            # a jump's height, px: at least (or 0.5 x span if less)
ARC_MAX = 18.0
ARC_PREF = 0.34          # height / span before clamping
ARC_RATIO = 0.5          # never taller than this x its span
LEVEL_GAP = 3.0
MARGIN = 4.0
PAD = 7.0                # axis overhang past the last tick
SAMPLES = 400
# -- C5: extended features -----------------------------------------------------
V_HEIGHT = 240.0         # orientation="v": the printed px length of lo..hi
LABEL_V_SPACING = 1.3    # vertical: numbered ticks >= this x one line apart
REF_LEN = 22.0           # a reference line, px past the axis (a tick is 4.5)
REF_BELOW = 10.0         # ... and past the row of numbers on the other side
REF_MIN_PT = 10.0        # printed: a dashed line shorter reads as a tick
REF_DASH = {"mirror": "5,2.5", "level": "2.5,2", "sea": "7,2,1.5,2"}
BAR_ROW = 12.0           # bars_from_zero: row pitch, bar height (px)
BAR_H = 5.0
BAR_MIN_PT = 3.0
SHADE_FILL = svgcheck.SHADE_FILL   # lighter than svgcheck.LIGHT: paper, not ink
BAR_FILL = "#e2e2e2"
ZOOM_BAND = 6.0          # a zoomed segment's band, px each side of the axis
CONNECT_DASH = "2.5,2.5"  # stack / zoom connectors
# C5 r2: every refusal that says a drawing contradicts its numbers also names
# the one case where a wrong drawing is the point of the item
CRITIQUE_FIX = (" — or, if the item asks the reader to FIND this error, draw "
                "it on purpose: student_drawing=True, asks=['find_error'] (the "
                "question needs asks=['find_error'] too)")
ROW_GAP = 14.0           # clear paper between two stacked rows (px)
ROW_CLEAR_PT = 4.0       # printed floor the stack sweep reads

# -- one sheet, one convention -----------------------------------------------
_SHEET = {"arrows": "right", "tick_pt": TICK_PT, "lines": 0}


def new_sheet(arrows="right", tick_pt=TICK_PT):
    """Start a sheet: every number line after this uses `arrows` and prints
    its tick numbers at `tick_pt`. Call once at the top of a level.

    Stage review: the size reaches the sheet's PLANES too (figkit_plus.SHEET),
    so one call cannot leave a sheet with two looks whichever builder starts
    it."""
    _check_arrows(arrows)
    _SHEET.update(arrows=arrows, tick_pt=float(tick_pt), lines=0)
    _to_planes(float(tick_pt))


def _to_planes(tick_pt):
    """Give figkit_plus the same printed number size, without resetting its
    house fallback records (only figkit_plus.new_sheet does that)."""
    try:
        import figkit_plus as _FP
    except Exception:                                       # pragma: no cover
        return
    _FP.SHEET["number_pt"] = None if abs(tick_pt - _FP.HOUSE["number_pt"]) < 1e-9 \
        else float(tick_pt)


def style(arrows=None, tick_pt=None):
    """Set the sheet's arrow convention ('right' | 'both' | 'none') and tick
    number size once. Changing either after a line was drawn is refused: a
    sheet whose lines disagree reads as two conventions."""
    if _SHEET["lines"] and ((arrows is not None and arrows != _SHEET["arrows"]) or
                            (tick_pt is not None and
                             float(tick_pt) != _SHEET["tick_pt"])):
        raise AssertionError(
            "numberline.style: %d line(s) of this sheet already use arrows=%r, "
            "tick_pt=%g — set the convention once, before the first line "
            "(numberline.new_sheet(arrows=...) at the top of the level)"
            % (_SHEET["lines"], _SHEET["arrows"], _SHEET["tick_pt"]))
    if arrows is not None:
        _check_arrows(arrows)
        _SHEET["arrows"] = arrows
    if tick_pt is not None:
        _SHEET["tick_pt"] = float(tick_pt)
        _to_planes(float(tick_pt))


def _check_arrows(a):
    if a not in ("right", "both", "none"):
        raise AssertionError("numberline: arrows=%r — 'right', 'both' or 'none'"
                             % (a,))


# -- values ------------------------------------------------------------------
def _F(v, what="value"):
    if isinstance(v, bool):
        raise AssertionError("numberline: %s %r is not a number" % (what, v))
    if isinstance(v, F):
        return v
    if isinstance(v, int):
        return F(v)
    if isinstance(v, float):
        f = F(v).limit_denominator(10 ** 6)
        if abs(float(f) - v) > 1e-9:
            raise AssertionError(
                "numberline: %s %r is not an exact value — pass a Fraction, or "
                "between=True for an estimate such as √10" % (what, v))
        return f
    if isinstance(v, str):
        try:
            return F(v.replace(MINUS, "-").strip())
        except ValueError:
            pass
    raise AssertionError("numberline: %s %r is not a number" % (what, v))


def _num(v):
    """A plain decimal / integer string with U+2212."""
    v = F(v)
    if v.denominator == 1:
        s = str(v.numerator)
    elif _finite_dec(v):
        s = ("%.6f" % float(v)).rstrip("0").rstrip(".")
    else:
        # v6 open issues (C4r3v-01): a value with no finite decimal printed
        # rounded -- 'the 1.333333 tick' -- and a reader who typed it back got
        # a different number. It prints as the fraction it is.
        s = "%d/%d" % (v.numerator, v.denominator)
    return s.replace("-", MINUS)


def _finite_dec(v):
    d = F(v).denominator
    for p in (2, 5):
        while d % p == 0:
            d //= p
    return d == 1


_SIGNED = re.compile(u"^\\s*([+\\-−]?)\\s*(\\d+(?:[.,]\\d+)?)\\s*$")


# a label that is a number: sign, then an integer / decimal, a fraction
# 'a/b' or a mixed number 'w a/b', then an optional unit of Latin letters
# ('4 cm'). C4 r2: only integers and decimals were read, so '+7/2' on a 5/2
# jump and '4 cm' on a 5-unit span were never compared with the drawing
_LABEL_NUM = re.compile(
    u"^\\s*([+\\-−]?)\\s*(\\d+(?:[.,]\\d+)?)"
    u"(?:\\s+(\\d+)\\s*/\\s*(\\d+)|\\s*/\\s*(\\d+))?"
    u"\\s*([A-Za-z]{1,3})?\\s*$")


def _parse_label(text):
    """(value, signed, decimals) for a numeric label ('+5', '−2', '2.5',
    '+7/2', '−1 1/2', '4 cm'); None for a label with no digit ('?', 'd').
    A label with digits that is none of these is refused: the check that a
    label equals the drawing's own number cannot read it."""
    if text is None:
        return None
    t = str(text)
    if not re.search(r"\d", t):
        return None
    m = _LABEL_NUM.match(t)
    if not m:
        raise AssertionError(
            u"numberline: label %r mixes a number with other text, so it cannot "
            u"be checked against the drawing — print the number alone ('+3', "
            u"'−1/2', '2.5', a unit such as '4 cm' is fine) or a letter / '?', "
            u"and put the rest in the HTML" % (t,))
    whole = m.group(2).replace(",", ".")
    v = F(whole)
    dec = len(whole.split(".")[1]) if "." in whole else 0
    if m.group(3):
        if "." in whole or int(m.group(4)) == 0:
            raise AssertionError(u"numberline: label %r is not a mixed number" % t)
        v += F(int(m.group(3)), int(m.group(4)))
        dec = None
    elif m.group(5):
        if int(m.group(5)) == 0:
            raise AssertionError(u"numberline: label %r divides by 0" % t)
        v = v / int(m.group(5))
        dec = None
    if m.group(1) in ("-", MINUS):
        v = -v
    return v, bool(m.group(1)), dec


def _latin(text, what):
    """Doctrine 7 / G49: a figure's text is Latin letters, digits, signs and
    °. C4 r3: a Hebrew point name, span label or jump label went straight
    into <text> and printed reversed ('קפיצה' as 'הציפק'); figkit.Figure
    refused it, the number line did not."""
    if text is None or text is True or text is False:
        return text
    t = str(text)
    if any(svgcheck._rtl(c) for c in t):
        raise AssertionError(
            u"numberline: the %s %r is Hebrew — inside an SVG it prints "
            u"reversed (G49). Draw a Latin letter, a number or '?' on the line "
            u"(name='A', label='+5') and put the Hebrew word in the HTML "
            u"beside the figure (e.g. 'A — הקפיצה')" % (what, t))
    return text


def _adv(text, px):
    w = 0.0
    for c in text:
        w += 0.50 if (c.isdigit() or c in u"+−") else \
            0.36 if c in ".," else 0.58
    return w * px


# -- sets ------------------------------------------------------------------------
INF = None


class Set(object):
    """A union of intervals (a, b, closed_a, closed_b); a or b None is −∞/+∞.
    `kind`: 'empty', 'all_reals', 'ray', 'interval', 'union', 'points'."""

    def __init__(self, parts=(), kind=None, points=None):
        self.parts = _merge([(a, b, bool(ca), bool(cb)) for a, b, ca, cb in parts])
        self.points = sorted(set(points)) if points is not None else None
        self.kind = kind or self._kind()
        self.caption = None
        # v6.2: the line this set was DRAWN on (NL._set fills it in). A set is
        # the one decoration that does not hand the line back, so
        # `NL(...).interval(...)` could not be finished in one expression and
        # levels grew a local wrapper to do it -- which is how package-local
        # figure kits start. `.line`, `.svg()` and `.render()` close that.
        self.line = None
        if self.kind == "empty":
            # Hebrew and set symbols stay in HTML (doctrine 7)
            self.caption = u'<span class="set-empty">∅</span>'

    def _kind(self):
        if self.points is not None:
            return "points"
        if not self.parts:
            return "empty"
        if len(self.parts) > 1:
            return "union"
        a, b, _, _ = self.parts[0]
        if a is None and b is None:
            return "all_reals"
        if a is None or b is None:
            return "ray"
        return "interval"

    def contains(self, x):
        if self.points is not None:
            return any(x == p for p in self.points)
        for a, b, ca, cb in self.parts:
            lo_ok = a is None or x > a or (ca and x == a)
            hi_ok = b is None or x < b or (cb and x == b)
            if lo_ok and hi_ok:
                return True
        return False

    def ends(self):
        out = []
        for a, b, ca, cb in self.parts:
            if a is not None:
                out.append(a)
            if b is not None:
                out.append(b)
        return out + list(self.points or [])

    def on(self):
        """The NL this set was drawn on."""
        if self.line is None:
            raise AssertionError(
                "numberline: this set was built by numberline.%s(...), which "
                "computes a set and draws nothing — draw it on a line first "
                "(NL(lo, hi).interval(...) / .ray(...) / .union(A, B)) and "
                "finish that line" % (self.kind if self.kind in
                                      ("interval", "ray", "union") else "interval"))
        return self.line

    def svg(self, width=None):
        """Finish the line this set was drawn on (see `on`)."""
        return self.on().svg(width)

    def render(self, width=None):
        return self.on().render(width)

    def __repr__(self):
        return "Set(%s, %r)" % (self.kind, self.parts if self.points is None
                                else self.points)


def _merge(parts):
    def key(p):
        return (-math.inf if p[0] is None else p[0])
    parts = sorted([p for p in parts if not _empty_part(p)], key=key)
    out = []
    for p in parts:
        if out:
            a, b, ca, cb = out[-1]
            if b is None or p[0] is None or p[0] < b or \
                    (p[0] == b and (cb or p[2])):
                nb, ncb = (b, cb)
                if b is not None and (p[1] is None or p[1] > b):
                    nb, ncb = p[1], p[3]
                elif b is not None and p[1] == b:
                    ncb = cb or p[3]
                out[-1] = (a, nb, ca, ncb)
                continue
        out.append(p)
    return out


def _empty_part(p):
    a, b, ca, cb = p
    if a is None or b is None:
        return False
    return a > b or (a == b and not (ca and cb))


def interval(a, b, closed_a=True, closed_b=True):
    a, b = _F(a), _F(b)
    if a > b:
        raise AssertionError("numberline.interval: a=%s > b=%s — pass the "
                             "smaller end first" % (_num(a), _num(b)))
    return Set([(a, b, closed_a, closed_b)])


def ray(a, direction, closed=True):
    a = _F(a)
    if direction not in ("left", "right"):
        raise AssertionError("numberline.ray: direction %r — 'left' or 'right'"
                             % (direction,))
    if direction == "right":
        return Set([(a, None, closed, False)])
    return Set([(None, a, False, closed)])


def union(*sets):
    return Set([p for s in sets for p in s.parts])


def intersect(*sets):
    cur = [(None, None, False, False)]
    for s in sets:
        nxt = []
        for a1, b1, ca1, cb1 in cur:
            for a2, b2, ca2, cb2 in s.parts:
                if a1 is None:
                    a, ca = a2, ca2
                elif a2 is None or a1 > a2:
                    a, ca = a1, ca1
                elif a2 > a1:
                    a, ca = a2, ca2
                else:
                    a, ca = a1, ca1 and ca2
                if b1 is None:
                    b, cb = b2, cb2
                elif b2 is None or b1 < b2:
                    b, cb = b1, cb1
                elif b2 < b1:
                    b, cb = b2, cb2
                else:
                    b, cb = b1, cb1 and cb2
                nxt.append((a, b, ca, cb))
        cur = nxt
    return Set(cur)


def all_reals():
    return Set([(None, None, False, False)])


def empty():
    return Set([])


def _set_text(S):
    if S.kind == "empty":
        return "the empty set"
    out = []
    for a, b, ca, cb in S.parts:
        out.append("%s%s, %s%s" % ("[" if ca else "(", "-inf" if a is None else
                                   _num(a), "inf" if b is None else _num(b),
                                   "]" if cb else ")"))
    return " U ".join(out)


# -- a linear inequality in x ---------------------------------------------------
_OPS = u"<=|>=|≤|≥|<|>"
_TOKS = re.compile(u"\\s*(?:(\\d+(?:[.,]\\d+)?)|(x)|([-+*/()−·]))",
                   re.I)


def _linear(src):
    """Parse a linear expression in x -> (a, b) meaning a*x + b."""
    s = src.replace(MINUS, "-").replace(u"·", "*")
    toks, pos = [], 0
    while pos < len(s):
        if s[pos].isspace():
            pos += 1
            continue
        m = _TOKS.match(s, pos)
        if not m or m.end() == pos:
            raise AssertionError("numberline: cannot read %r at %r" % (src, s[pos:]))
        if m.group(1):
            toks.append(("n", F(m.group(1).replace(",", "."))))
        elif m.group(2):
            toks.append(("x", None))
        else:
            toks.append((m.group(3), None))
        pos = m.end()
    i = [0]

    def peek():
        return toks[i[0]][0] if i[0] < len(toks) else None

    def take():
        i[0] += 1
        return toks[i[0] - 1]

    def expr():
        a, b = term()
        while peek() in ("+", "-"):
            op = take()[0]
            c, d = term()
            a, b = (a + c, b + d) if op == "+" else (a - c, b - d)
        return a, b

    def term():
        a, b = factor()
        while peek() in ("*", "/", "n", "x", "("):
            op = take()[0] if peek() in ("*", "/") else "*"
            c, d = factor()
            if op == "*":
                if a and c:
                    raise AssertionError("numberline: %r is not linear in x" % src)
                a, b = a * d + c * b, b * d
            else:
                if c:
                    raise AssertionError("numberline: %r divides by x" % src)
                if d == 0:
                    raise AssertionError("numberline: %r divides by 0" % src)
                a, b = a / d, b / d
        return a, b

    def factor():
        t = peek()
        if t in ("+", "-"):
            take()
            a, b = factor()
            return (a, b) if t == "+" else (-a, -b)
        if t == "n":
            return F(0), take()[1]
        if t == "x":
            take()
            return F(1), F(0)
        if t == "(":
            take()
            v = expr()
            if peek() != ")":
                raise AssertionError("numberline: unbalanced brackets in %r" % src)
            take()
            return v
        raise AssertionError("numberline: cannot read %r" % src)

    v = expr()
    if i[0] != len(toks):
        raise AssertionError("numberline: cannot read %r" % src)
    return v


class Inequality(object):
    """A parsed chain `L op R [op S]`; `holds(x)` evaluates the source
    itself, exactly, with Fractions -- the reference the drawn set is sampled
    against (it never goes through `solve`)."""

    def __init__(self, src):
        if isinstance(src, tuple):
            op, v = src
            src = "x %s %s" % (op, _num(_F(v)).replace(MINUS, "-"))
        self.src = src
        parts = re.split(u"(%s)" % _OPS, src)
        if len(parts) not in (3, 5):
            raise AssertionError(
                "numberline: %r is not an inequality in x (one or two of "
                "< <= > >= ≤ ≥)" % (src,))
        self.exprs = [_linear(p) for p in parts[0::2]]
        self.ops = [{u"≤": "<=", u"≥": ">="}.get(o, o)
                    for o in parts[1::2]]
        has_x = [bool(re.search("x", p, re.I)) for p in parts[0::2]]
        if not any(has_x):
            raise AssertionError(
                "numberline: %r has no x — an inequality in x, e.g. 2x+3 <= 7"
                % (src,))
        if len(self.ops) == 2:
            # C4 r2: '1 < x > 3' and 'x < 2 < 5' were read and silently
            # intersected. A chain reads one way, with x in the middle
            ups = [o in ("<", "<=") for o in self.ops]
            if ups[0] != ups[1]:
                raise AssertionError(
                    "numberline: %r is not a chain — a chain reads one way "
                    "(a < x <= b, or b > x >= a); for two conditions draw one "
                    "set: nl.intersect(solve('...'), solve('...')) for 'and', "
                    "nl.union(...) for 'or'" % (src,))
            if not has_x[1] or has_x[0] or has_x[2]:
                raise AssertionError(
                    "numberline: %r — in a chain x stands in the middle and the "
                    "ends are numbers (−1 < x <= 4, 1 < 2x+1 < 7)" % (src,))

    def holds(self, x):
        vals = [a * x + b for a, b in self.exprs]
        for (l, r), op in zip(zip(vals, vals[1:]), self.ops):
            if not {"<": l < r, "<=": l <= r, ">": l > r, ">=": l >= r}[op]:
                return False
        return True


def solve(src):
    """The solution set of a linear inequality (or a chain of two) in x. An
    identity gives all_reals(), a contradiction empty() -- decided from the
    inequality, never by the author."""
    q = src if isinstance(src, Inequality) else Inequality(src)
    sets = []
    for (l, r), op in zip(zip(q.exprs, q.exprs[1:]), q.ops):
        a, b = l[0] - r[0], l[1] - r[1]        # a x + b  op  0
        if a == 0:
            ok = {"<": b < 0, "<=": b <= 0, ">": b > 0, ">=": b >= 0}[op]
            sets.append(all_reals() if ok else empty())
            continue
        x0 = -b / a
        if a < 0:
            op = {"<": ">", "<=": ">=", ">": "<", ">=": "<="}[op]
        closed = op in ("<=", ">=")
        sets.append(ray(x0, "left" if op in ("<", "<=") else "right", closed))
    return intersect(*sets) if len(sets) > 1 else sets[0]


# -- the builder -------------------------------------------------------------------
class NL(object):
    """A number line drawn from its numbers. See the module docstring."""

    def __init__(self, lo, hi, tick=1, label_every="auto", label_fmt="auto",
                 plus_sign=False, zero_emph=False, tier="side", width=None,
                 unit=None, sparse=False, label_at=None, sketch=False,
                 blank=False, arrows=None, answer_values=(), answer_hidden=(),
                 tick_pt=None, fam=None, orientation="h", height=None,
                 student_drawing=False, asks=None, wrong_scale=None,
                 register=True, _legacy=None):
        # O3-03: the call itself, so a refusal can TRY the tick it names
        self._ctor = dict(lo=lo, hi=hi, label_fmt=label_fmt,
                          plus_sign=plus_sign, zero_emph=zero_emph, tier=tier,
                          width=width, unit=unit, arrows=arrows,
                          tick_pt=tick_pt, orientation=orientation,
                          height=height)
        # v6 P2 r1 (LP2-01): the WHOLE call, and (below) every decoration
        # call made on the line, so the N.stack a refusal names keeps the
        # line's tick=, width=, points and sets -- it was rebuilt from lo, hi
        # and the jumps only, dropping a point P and trying tick=2 as tick=1
        self._ctor_all = dict(lo=lo, hi=hi, tick=tick, label_every=label_every,
                              label_fmt=label_fmt, plus_sign=plus_sign,
                              zero_emph=zero_emph, tier=tier, width=width,
                              unit=unit, sparse=sparse, label_at=label_at,
                              sketch=sketch, blank=blank, arrows=arrows,
                              answer_values=answer_values,
                              answer_hidden=answer_hidden, tick_pt=tick_pt,
                              fam=fam, orientation=orientation, height=height,
                              student_drawing=student_drawing, asks=asks,
                              wrong_scale=wrong_scale)
        self._calls = []
        self.lo, self.hi = _F(lo, "lo"), _F(hi, "hi")
        if not self.lo < self.hi:
            raise AssertionError(
                "numberline: lo=%s is not below hi=%s — a number line runs from "
                "the smaller value to the larger (NL(%s, %s))"
                % (_num(self.lo), _num(self.hi), _num(min(self.lo, self.hi)),
                   _num(max(self.lo, self.hi))))
        self.tick = _F(tick, "tick")
        # v6 open issues (C4r3v-01): a tick typed as a ROUNDED decimal --
        # 0.666667 copied out of a message -- was taken as 666667/1000000 and
        # drew ticks every 0.666667 with the label 666667/250000. A decimal
        # within a millionth of a simple fraction it is not is refused, naming
        # the fraction.
        if isinstance(tick, (float, str)) and not isinstance(tick, bool):
            near = self.tick.limit_denominator(12)
            if near != self.tick and abs(near - self.tick) <= F(1, 10 ** 5):
                raise AssertionError(
                    "numberline: tick=%r is %s rounded — ticks every %s would "
                    "miss the whole numbers. Pass the exact value: "
                    "tick='%d/%d' (or tick=Fraction(%d, %d))"
                    % (tick, _num(near), tick, near.numerator,
                       near.denominator, near.numerator, near.denominator))
        if self.tick <= 0:
            raise AssertionError("numberline: tick=%s must be positive" % tick)
        if label_fmt not in ("auto", "int", "dec", "frac", "mixed"):
            raise AssertionError("numberline: label_fmt=%r — int, dec, frac, "
                                 "mixed or auto" % (label_fmt,))
        if tier not in TIERS:
            raise AssertionError("numberline: tier=%r — one of %s"
                                 % (tier, sorted(TIERS)))
        if sum(bool(x) for x in (sparse, sketch, blank)) > 1 and not \
                (blank and not sparse and not sketch):
            raise AssertionError("numberline: sparse, sketch and blank are "
                                 "separate modes — pass one")
        self.legacy = _legacy
        self.register = register and _legacy is None
        arrows = arrows if arrows is not None else \
            ("none" if _legacy else _SHEET["arrows"])
        _check_arrows(arrows)
        if self.register and arrows != _SHEET["arrows"]:
            raise AssertionError(
                "numberline: this line asks arrows=%r but the sheet uses %r — "
                "the arrow convention is set once per sheet with "
                "numberline.style(arrows=...)" % (arrows, _SHEET["arrows"]))
        self.arrows = arrows
        self.tick_pt = float(tick_pt) if tick_pt is not None else _SHEET["tick_pt"]
        if self.register and self.tick_pt != _SHEET["tick_pt"]:
            raise AssertionError(
                "numberline: tick_pt=%g but this sheet prints tick numbers at "
                "%gpt — the same printed size on every number line of a sheet "
                "(numberline.style(tick_pt=...) once, or leave tick_pt out)"
                % (self.tick_pt, _SHEET["tick_pt"]))
        self.plus_sign, self.zero_emph = plus_sign, zero_emph
        self.tier, self.width, self.unit = tier, width, unit
        self.sparse, self.sketch, self.blank = sparse, sketch, blank
        self.fam = fam
        # -- C5 ------------------------------------------------------------
        if orientation not in ("h", "v"):
            raise AssertionError("numberline: orientation=%r — 'h' or 'v'"
                                 % (orientation,))
        self.orientation = orientation
        if height is not None and orientation != "v":
            raise AssertionError("numberline: height= is the length of a "
                                 "vertical line's scale — pass orientation='v', "
                                 "or width=/tier= for a horizontal line")
        self.height = float(height) if height is not None else V_HEIGHT
        # P3 leftovers r2 (P3r2-ASKS-TRUE-RAW-TYPEERROR): asks=True is the
        # natural wrong spelling of the parameter the student_drawing
        # refusal itself points at ("declare it: NL(..., student_drawing=
        # True, asks=[...])"), and it used to raise a bare TypeError
        # ("'bool' object is not iterable") with no message at all.
        if isinstance(asks, bool) or isinstance(asks, str):
            raise AssertionError(
                "numberline.NL: asks=%r is not a list of questions. asks= "
                "names WHAT the item asks about this drawing, one string per "
                "question -- asks=['find_error'] for a wrong drawing the "
                "student has to correct, asks=['read_value'] for one to read "
                "off. Write the list: NL(..., student_drawing=True, "
                "asks=['find_error'])." % (asks,))
        self.asks = [str(a) for a in (asks or [])]
        # Stage review (L3-Stage-06): wrong_scale= is the parameter the
        # student_drawing refusal itself names in the same breath as asks=,
        # and its three natural mis-spellings raised bare Python exceptions
        # (TypeError: 'bool' object is not iterable; ValueError: not enough
        # values to unpack) instead of a refusal naming the list form -- an
        # opaque traceback immediately after following the refusal's own
        # instruction.
        _bad_ws = None
        if isinstance(wrong_scale, (bool, str)):
            _bad_ws = wrong_scale
        elif wrong_scale is not None:
            try:
                for _p in wrong_scale:
                    if isinstance(_p, str) or len(_p) != 2:
                        _bad_ws = wrong_scale
                        break
            except TypeError:
                _bad_ws = wrong_scale
        if _bad_ws is not None:
            raise AssertionError(
                "numberline.NL: wrong_scale=%r is not a list of (tick, text) "
                "pairs. wrong_scale= draws the STUDENT'S wrong number at a "
                "tick of this line, so each entry says WHICH tick and WHAT "
                "the student wrote there: wrong_scale=[(2, '2.5')] prints "
                "'2.5' at the tick of 2. Write the pairs: NL(..., "
                "wrong_scale=[(2, '2.5')], asks=['find_error'])."
                % (_bad_ws,))
        self.wrong_scale = []
        self.critique = False
        # C5 r3: WHAT is wrong on this line, as the builder can see it (a
        # number written on the wrong tick, a set that disagrees with its
        # inequality) or as the author names it in words. A critique line with
        # nothing wrong on it is the CORRECT drawing standing beside an
        # error-finding item, and is refused at render — the giveaway rule
        # sign_chart already enforced for sign charts.
        self._crit_why = []
        if isinstance(student_drawing, str) and student_drawing.strip():
            self._crit_why.append("the author names the error: %s"
                                  % student_drawing.strip())
        if student_drawing or wrong_scale:
            self._allow_critique("student_drawing=True" if student_drawing
                                 else "wrong_scale=")
        self._zooms, self._top, self._refs, self._bars, self._signs = \
            [], [], [], [], []
        self.marks = []
        self.sets = []           # (Set, Inequality or None, domain)
        self.hidden = [_F(v, "answer_hidden") for v in answer_hidden]
        self.answer_values = [_F(v, "answer_values") for v in answer_values]
        if sketch and self.answer_values and not all(
                v in [_F(r) for r in (label_at or [])] for v in self.answer_values):
            # stage-1 fix r1: a sketch has no ticks -- the answer the student
            # must mark had nowhere to be marked
            raise AssertionError(
                "numberline: answer_values on a sketch line -- a sketch has no "
                "ticks, so the student has nowhere to mark %s; draw the line "
                "numbered (sketch off) with the answer on a tick"
                % ", ".join(_num(v) for v in self.answer_values))
        for v in self.answer_values:
            if not sketch and (v / self.tick).denominator != 1:
                # C4 r2: 1/2 on a tick-1 line was accepted -- the student
                # marks an answer on a tick, and there was none to mark
                raise AssertionError(
                    "numberline: answer value %s is not on a tick of %s — the "
                    "student marks the answer on a tick; use tick=%s"
                    % (_num(v), _num(self.tick),
                       str(self.tick / (v / self.tick).denominator)))
            if not (self.lo + self.tick <= v <= self.hi - self.tick):
                raise AssertionError(
                    "numberline: answer value %s is not inside [%s, %s] with a "
                    "tick of margin — the student must be able to mark it; "
                    "widen the line (e.g. NL(%s, %s))"
                    % (_num(v), _num(self.lo + self.tick),
                       _num(self.hi - self.tick),
                       _num(min(self.lo, v - 2 * self.tick)),
                       _num(max(self.hi, v + 2 * self.tick))))
        # ticks, anchored at 0
        k0 = math.ceil(self.lo / self.tick)
        k1 = math.floor(self.hi / self.tick)
        self.ks = list(range(k0, k1 + 1))
        if sketch:
            self.ks = []
        self.fmt = label_fmt
        self._choose_labels(label_every, label_at)
        if orientation == "v" and self.fmt in ("frac", "mixed"):
            raise AssertionError(
                "numberline: a vertical line prints its numbers in one line "
                "beside the axis — label_fmt=%r stacks them; use "
                "label_fmt='dec' (a tick that is a finite decimal) or a "
                "horizontal line for fractions" % self.fmt)
        for v, text in (wrong_scale or []):
            v = _F(v, "wrong_scale value")
            if v not in self.labelled:
                raise AssertionError(
                    "numberline: wrong_scale value %s is not a numbered tick of "
                    "this line (%s) — the student's number replaces a number "
                    "the line prints" % (_num(v), ", ".join(_num(x) for x in
                                                            self.labelled)))
            t = svgcheck.true_minus(str(_latin(text, "wrong_scale text")))
            if not re.match(u"^[\\d+\u2212.,]+$", t):
                raise AssertionError("numberline: wrong_scale text %r — a number "
                                     "as the student wrote it" % (text,))
            # C5 r4 — the student's number must actually DIFFER from the one the
            # line prints there. wrong_scale=[(2, '2')] used to record a reason
            # without checking it, so a critique line could be byte-identical to
            # the correct drawing and still claim an error (the giveaway rule
            # with the door left open beside it). '2', '2.0' and '2,0' are the
            # same number as the tick 2, so all three are refused.
            try:
                same = _parse_label(t)
            except AssertionError:
                same = None
            if same is not None and same[0] == v:
                raise AssertionError(
                    "numberline: wrong_scale=[(%s, %r)] writes the number the "
                    "tick already prints, so the drawing is the CORRECT one and "
                    "would give the answer away (the giveaway rule). The "
                    "student's number has to be a DIFFERENT number: "
                    "wrong_scale=[(%s, %r)] (the tick of %s numbered %s), or "
                    "put the error somewhere else — from_inequality('x<%s', "
                    "closed=True) for the wrong boundary circle, or name an "
                    "error the drawing cannot show by itself in words, "
                    "student_drawing='the point stands at ...'"
                    % (_pyn(v), text, _pyn(v), _num(v + F(1, 2)), _num(v),
                       _num(v + F(1, 2)), _num(v)))
            self.wrong_scale.append((v, t))
            self._crit_why.append("the number %s written at the tick of %s"
                                  % (t, _num(v)))
            self._key("wrong_scale", v, t)

    # -- numbering ------------------------------------------------------------
    def _fmt_ok(self, vals, fmt):
        if fmt == "int":
            return all(v.denominator == 1 for v in vals)
        if fmt == "dec":
            return all(_finite_dec(v) for v in vals)
        return True

    def _auto_fmt(self, vals):
        if all(v.denominator == 1 for v in vals):
            return "int"
        if all(_finite_dec(v) and len(_num(abs(v))) <= 5 for v in vals):
            return "dec"
        return "frac"

    def _choose_labels(self, label_every, label_at):
        t = self.tick
        # a MAJOR tick: the first multiple of `tick` that is a whole number
        self.major = t * t.denominator
        if label_at is not None and not (self.sparse or self.sketch):
            label_at = [_F(v, "label_at") for v in label_at]
            # numbered only where asked: judged by the density rule below
        if self.sketch:
            refs = [_F(v) for v in (label_at if label_at is not None else
                                    ([0] if self.lo <= 0 <= self.hi else []))]
            for v in refs:
                self._in_range(v, "label_at")
            self.labelled = sorted(set(refs))
            self.ref_ticks = self.labelled
            self.k = None
            self.fmt = self.fmt if self.fmt != "auto" else \
                self._auto_fmt(self.labelled or [F(0)])
            self._check_fmt(self.labelled)
            return
        if self.sparse:
            if not label_at or len(label_at) < 2:
                raise AssertionError(
                    "numberline: sparse=True needs label_at=[two or more values] "
                    "— the numbers the student reads the scale from")
            vals = [_F(v, "label_at") for v in label_at]
            for v in vals:
                self._in_range(v, "label_at")
                if (v / t).denominator != 1:
                    raise AssertionError(
                        "numberline: label_at value %s is not on a tick of %s"
                        % (_num(v), _num(t)))
            self.labelled = sorted(set(vals))
            self.k = None
            self.fmt = self.fmt if self.fmt != "auto" else self._auto_fmt(self.labelled)
            self._check_fmt(self.labelled)
            return
        if label_at is not None:
            self.labelled = sorted(set(label_at))
            self.k = None
        else:
            if label_every == "auto":
                base = 1 if self.fmt in ("dec", "frac", "mixed") else t.denominator
                if sum(1 for kk in self.ks if kk % base == 0) < 2:
                    # a short stretch between two whole numbers (0.1..0.5):
                    # number the ticks themselves, as decimals or fractions
                    base = 1
                den = t.denominator
                cands = set(base * m for m in (1, 2, 4, 5, 10))
                if base == 1 and den > 1:
                    # C4 r3: counted from 0 over 1, 2, 4, 5, 10 a thirds line
                    # numbered -2/3, 0, 2/3 and left the whole numbers and
                    # both ends bare. Every candidate numbers every whole
                    # number (k divides the denominator) or only whole
                    # numbers (k is a multiple of it)
                    cands |= set(den * m for m in (1, 2, 4, 5, 10))
                    cands = set(k for k in cands if den % k == 0 or k % den == 0)
                cands = sorted(cands)
                cands = [k for k in cands if self._density_bad(
                    [kk * t for kk in self.ks if kk % k == 0]) is None] or [base]
                self._cands = cands
                self.k = cands[0]
            else:
                if not isinstance(label_every, int) or label_every < 1:
                    raise AssertionError("numberline: label_every=%r — a whole "
                                         "number of ticks, or 'auto'" % (label_every,))
                self.k = label_every
                self._cands = [label_every]
            self.labelled = [k * t for k in self.ks if k % self.k == 0]
        if self.fmt == "auto":
            self.fmt = self._auto_fmt(self.labelled or [F(0)])
        self._check_fmt(self.labelled)
        self._check_density()

    def _check_fmt(self, vals):
        if not self._fmt_ok(vals, self.fmt):
            bad = [v for v in vals if not self._fmt_ok([v], self.fmt)][0]
            raise AssertionError(
                "numberline: label_fmt=%r cannot print the tick %s exactly — use "
                "label_fmt='frac' (or 'mixed'), or number fewer ticks "
                "(label_every=)" % (self.fmt, str(bad).replace("-", MINUS)))

    def _density_bad(self, labelled):
        """The first whole-step tick that follows another unnumbered one, or
        None. A MAJOR tick is a multiple of the first whole multiple of
        `tick` (1 for quarters, 50 for a tick of 50): at least every 2nd major
        tick carries a number."""
        lab = set(labelled)
        run = 0
        for k in self.ks:
            v = k * self.tick
            if (v / self.major).denominator != 1:
                continue
            run = 0 if v in lab else run + 1
            if run >= 2:
                return v
        return None

    def _check_density(self):
        if self.sparse or self.sketch:
            return
        M = self.major
        v = self._density_bad(self.labelled)
        if v is not None:
            # C4 r2: name only fixes that exist for THIS line -- 'tick=5' on a
            # -3..3 line leaves one tick, and label_at= wants sparse=True
            fixes = []
            if self.k is None:
                fixes.append("for a 'find the scale' item declare sparse=True "
                             "with these label_at=[...] (every tick one length), "
                             "or drop label_at to number the ticks")
            else:
                fixes.append("number every 1st or 2nd one (label_every=%d)"
                             % max(1, int(2 * M / self.tick)))
            for c in (M * 2, M * 5, M * 10):
                if c > self.tick and (self.hi - self.lo) / c >= 4:
                    fixes.append("use a coarser tick (tick=%s)" % _pyn(c))
                    break
            if self.k is not None:
                fixes.append("or, for a 'find the scale' item, declare "
                             "sparse=True with label_at=[...]")
            raise AssertionError(
                "numberline: tick %s and the whole-step tick before it both carry "
                "no number — at least every 2nd whole-step tick is numbered (the "
                "z01 lines numbered every 5th tick were unreadable). Fix: %s"
                % (_num(v), "; ".join(fixes)))
        if len(self.labelled) < 2 and not self.blank:
            raise AssertionError(
                "numberline: fewer than two numbers on %s..%s — a reader cannot "
                "find the scale; widen the range or number more ticks"
                % (_num(self.lo), _num(self.hi)))

    def _level(self, v):
        """'major' (numbered), 'half', 'minor'."""
        if self.sparse or self.sketch:
            return "major"
        if v in self._labset:
            return "major"
        if self.k and self.k % 2 == 0:
            k = int(v / self.tick)
            if k % (self.k // 2) == 0:
                return "half"
        elif self.k is None:
            if (v / self.major).denominator == 1:
                return "half"
        return "minor"

    # -- guards -----------------------------------------------------------------
    def _in_range(self, v, what):
        if not (self.lo <= v <= self.hi):
            raise AssertionError(
                "numberline: %s %s is outside the line %s..%s — widen the line "
                "or fix the value (it was drawn off the line silently before)"
                % (what, _num(v) if isinstance(v, F) else "%g" % v,
                   _num(self.lo), _num(self.hi)))

    def _val(self, v, what, between=False, hidden=True):
        if between and isinstance(v, float):
            fv = v
        else:
            fv = _F(v, what)
        if between:
            # Stage review: between= was the one hatch with NO didactic
            # guard -- sparse got _sparse_is_didactic, data_ticks got
            # _data_ticks_is_didactic, sketch and student_drawing got theirs,
            # and the off-tick refusal offered between= as a co-equal
            # alternative to a finer tick, which is strictly cheaper under
            # deadline. Taken on a value the reader COULD have read off a
            # tick, it turns that value into an unmarked dot.
            self.__dict__.setdefault("_btw", []).append((what, fv))
        self._in_range(fv, what)
        if self._bars and what != "bar end":
            raise AssertionError(
                "numberline: this line shows bars_from_zero — a %s would stand "
                "among the bars; draw it on a line of its own" % what)
        if self._top:
            raise AssertionError(
                "numberline: this line carries a second scale over its axis "
                "(double) — a %s would stand among its numbers; draw it on a "
                "line of its own, or hide the value the item asks for "
                "(double(..., hide_a=[...], hide_b=[...]))" % what)
        if self.blank:
            raise AssertionError(
                "numberline: blank=True is a line for the student to draw on — "
                "it takes no %s; drop blank=True to draw one" % what)
        if not between and not self.sketch and isinstance(fv, F) and \
                (fv / self.tick).denominator != 1:
            # refused at render, AFTER the magnitude check: "-0.5 prints on
            # the 0 tick" says more than "-0.5 is not on a tick of 100"
            # C4 r3: every call that reaches here with between=False takes
            # between= (symmetric and double_arrow did not), except test
            # markers, which stand on ticks by definition
            self.__dict__.setdefault("_otf", []).append(
                self.tick / (fv / self.tick).denominator)
            self._offtick.append(
                "numberline: %s %s is not on a tick of %s — use a finer tick "
                "(tick=%s)%s"
                % (what, _num(fv), _num(self.tick),
                   str(self.tick / (fv / self.tick).denominator),
                   "" if what == "test marker" else
                   ", or declare between=True for an estimate item"))
        if hidden and isinstance(fv, F) and fv in self.hidden:
            raise AssertionError(
                "numberline: %s lands on %s, a hidden answer (answer_hidden) — "
                "the figure would give the answer away; draw the question's "
                "data only" % (what, _num(fv)))
        return fv

    def _key(self, kind, *vals):
        self.marks.append((kind,) + tuple(
            str(v) if isinstance(v, F) else ("%.6g" % v if isinstance(v, float)
                                             else v) for v in vals))

    # -- marks ------------------------------------------------------------------
    def point(self, v, name=None, style="filled", value_label=False,
              between=False):
        if style not in ("filled", "open", "cross", "tri", "square"):
            raise AssertionError("numberline.point: style %r — filled, open, "
                                 "cross, tri or square" % (style,))
        _latin(name, "point name")
        _latin(value_label, "value label")
        v = self._val(v, "point", between)
        if value_label is not False and value_label is not None:
            value_label = self._value_label(v, value_label)
        self._points.append(dict(v=v, name=name, style=style,
                                 value_label=value_label, between=between,
                                 kind="point"))
        self._key("point", v, style, bool(value_label))
        return self

    def _value_label(self, v, value_label):
        """What a point's value label prints: (value, fmt) drawn like a tick
        number (a stacked fraction on a frac/mixed line, or wherever a decimal
        cannot print the value exactly), or a checked text for an estimate.
        C4 r2: it printed _num(v) -- '0.333333' beside the tick '1/3',
        '1.5' beside '1½', and '3.16228' for √10."""
        if value_label is True:
            if not isinstance(v, F):
                raise AssertionError(
                    "numberline.point: value_label=True on an estimate "
                    "(between=True, %g) would print a rounded decimal as if it "
                    "were the value — pass the printed value yourself, "
                    "value_label='%s' (checked to its last digit), or name the "
                    "point and give its value in the text" % (v, "%.1f" % v))
            fmt = self.fmt if self._fmt_ok([v], self.fmt) and \
                self.fmt in ("int", "dec", "frac", "mixed") else "frac"
            if fmt == "dec" and len(_num(abs(v))) > 6:
                fmt = "frac"
            return ("value", v, fmt)
        p = _parse_label(value_label)
        if p is None or p[0] is None:
            raise AssertionError(
                "numberline.point: value_label=%r is not a number — True prints "
                "the value; a letter goes in name=" % (value_label,))
        val, _, dec = p
        text = str(value_label).strip()
        if isinstance(v, F):
            if val != v:
                raise AssertionError(
                    u"numberline.point: value_label %s ≠ the point's value %s"
                    % (svgcheck.true_minus(text), _num(v)))
            if "/" not in text:
                return ("text", svgcheck.true_minus(text))
            fmt = "frac" if "/" in text and " " not in text else \
                "mixed" if "/" in text else ("int" if v.denominator == 1 else "dec")
            return ("value", v, fmt)
        if dec is None or abs(float(val) - v) > 0.5 * 10 ** (-dec) + 1e-9:
            raise AssertionError(
                u"numberline.point: value_label %s does not round %g — print the "
                u"estimate to the digits you mean (e.g. '%.1f')"
                % (svgcheck.true_minus(text), v, v))
        return ("text", svgcheck.true_minus(text))

    def points(self, vals, **kw):
        for v in vals:
            if isinstance(v, (tuple, list)):
                self.point(v[0], *v[1:], **kw)
            else:
                self.point(v, **kw)
        return self

    def test_markers(self, marks):
        for v, st in marks:
            if st not in ("x", "tri"):
                raise AssertionError("numberline.test_markers: %r — 'x' or 'tri'"
                                     % (st,))
            v = self._val(v, "test marker")
            self._points.append(dict(v=v, name=None, style="cross" if st == "x"
                                     else "tri", value_label=False,
                                     between=False, kind="test"))
            self._key("test", v, st)
        return self

    def _numeric_label(self, label, want, what, signed):
        """A numeric label on a jump or span must BE the drawing's number:
        b − a for a jump ('+5', '−2', or '5' for +5), |b − a| for a span."""
        p = _parse_label(label)
        if p is None or want is None:
            return
        val, has_sign, _ = p
        if val != want:
            raise AssertionError(
                u"numberline: %s label %s \u2260 %s = %s — a label on the "
                u"drawing must be the drawing's own number"
                % (what, str(label).replace("-", MINUS),
                   u"b\u2212a" if signed else u"|b\u2212a|", _num(want)))
        if what != "jump" and val in self.hidden:
            # C4 r3: a jump's label is a displacement, not a position -- '+3'
            # on 1 -> 4 was refused beside a hidden answer at the POSITION 3.
            # A jump that LANDS on a hidden value is refused by _val
            raise AssertionError(
                "numberline: %s label %s prints a hidden answer (answer_hidden)"
                " — the figure would give the answer away" % (what, label))

    def span(self, a, b, label=None, kind="bracket", between=False, _key=True):
        if kind not in ("bracket", "arrow2"):
            raise AssertionError("numberline.span: kind %r — 'bracket' or "
                                 "'arrow2' (spans are never dashed)" % (kind,))
        _latin(label, "span label")
        a = self._val(a, "span end", between)
        b = self._val(b, "span end", between)
        if a == b:
            raise AssertionError("numberline.span: a == b")
        if label is not None and isinstance(a, F) and isinstance(b, F):
            self._numeric_label(label, abs(b - a), "span", False)
        self._decos.append(dict(kind=kind, a=min(a, b), b=max(a, b), label=label,
                                between=between))
        if _key:
            self._key("span", min(a, b), max(a, b), kind)
        return self

    def symmetric(self, a, label=True, kind="arrow2", between=False):
        """−a..0 and 0..a. `between=True` for ends between ticks (C4 r3: the
        off-tick refusal named between=True, which this call did not take)."""
        _latin(label, "span label")
        if between and isinstance(a, float):
            a = abs(a)
            if label is True:
                raise AssertionError(
                    "numberline.symmetric: label=True on an estimate (%g) would "
                    "print a rounded decimal as the value — pass the printed "
                    "value, label='%.1f', or label=None" % (a, a))
        else:
            a = abs(_F(a))
        # a value a decimal cannot print exactly is printed as a fraction
        lab = (_num(a) if _finite_dec(a) else "%d/%d" % (a.numerator, a.denominator)) \
            if label is True else label
        self.span(-a, 0, lab, kind, between=between, _key=False)
        self.span(0, a, lab, kind, between=between, _key=False)
        self._key("symmetric", a, kind)
        return self

    def double_arrow(self, center, d, label=None, between=False):
        """±d from `center`; `between=True` for ends between ticks."""
        _latin(label, "double_arrow label")
        c = self._val(center, "double_arrow centre", between, hidden=False)
        d = d if (between and isinstance(d, float)) else _F(d, "double_arrow d")
        if d <= 0:
            raise AssertionError("numberline.double_arrow: d must be positive")
        self._val(c - d, "double_arrow end", between)
        self._val(c + d, "double_arrow end", between)
        if label is not None and isinstance(d, F):
            self._numeric_label(label, d, "double_arrow", False)
        self._decos.append(dict(kind="double", c=c, d=d, label=label,
                                between=between))
        self._key("double", c, d)
        return self

    def midpoint(self, a, b, name="M", between=False):
        a, b = _F(a), _F(b)
        m = (a + b) / 2
        self.point(m, name, "filled", between=between)
        return self

    def jump(self, a, b, label=None, between=False, _key=True):
        _latin(label, "jump label")
        a = self._val(a, "jump start", between, hidden=False)
        b = self._val(b, "jump end", between)
        if a == b:
            raise AssertionError("numberline.jump: a jump from %s to itself"
                                 % _num(a))
        if label is not None and isinstance(a, F) and isinstance(b, F):
            self._numeric_label(label, b - a, "jump", True)
        self._decos.append(dict(kind="jump", a=a, b=b, label=label,
                                between=between))
        if _key:
            self._key("jump", a, b)
        return self

    def chain(self, values, labels=None):
        if len(values) < 2:
            raise AssertionError("numberline.chain: two or more values")
        labels = list(labels) if labels is not None else [None] * (len(values) - 1)
        if len(labels) != len(values) - 1:
            raise AssertionError("numberline.chain: %d values need %d labels"
                                 % (len(values), len(values) - 1))
        for a, b, lab in zip(values, values[1:], labels):
            self.jump(a, b, lab)
        return self

    def repeat(self, start, step, n, label=None):
        start, step = _F(start), _F(step)
        if n < 1:
            raise AssertionError("numberline.repeat: n >= 1")
        vals = [start + step * i for i in range(n + 1)]
        return self.chain(vals, [label] * n if label is not None else None)

    # -- sets -------------------------------------------------------------------
    def _one_set(self, what):
        """C4 r2: two sets on one line were accepted at the call and refused
        at render as 'disagrees ... draw it with from_inequality(<the call
        already made>)'. One line shows one set; say how to draw two."""
        if not self.sets:
            return
        st = self.sets[0]
        have = st["q"].src if st.get("q") is not None else \
            ("the integers of a set" if "src" in st else _set_text(st["S"]))
        raise AssertionError(
            "numberline: this line already shows %s; a second set (%s) on the "
            "same line reads as one drawing — draw both as ONE set: "
            "nl.union(N.solve('...'), N.solve('...')) for 'or', "
            "nl.intersect(...) for 'and' (source= is optional), or draw the "
            "second set on its own line" % (have, what))

    def _set(self, S, source=None, domain=None, closed=None, what="set",
             between=False):
        if self.blank:
            raise AssertionError("numberline: blank=True takes no set")
        q = None
        if source is not None:
            q = source if isinstance(source, Inequality) else Inequality(source)
        self._one_set(q.src if q is not None else _set_text(S))
        if domain is not None:
            dlo, dhi = _F(domain[0]), _F(domain[1])
            S = intersect(S, interval(dlo, dhi))
        if closed is not None:
            S = Set([(a, b, (closed if a is not None else ca),
                      (closed if b is not None else cb))
                     for a, b, ca, cb in S.parts])
        for e in S.ends():
            # C4 r2: a boundary is data like any point -- x>=3.5 on a tick-1
            # line drew an unmarked boundary between two ticks
            self._val(e, "set end", between=between)
        if q is not None and not self.critique:
            # at the call: the set about to be drawn against the source, on
            # the same samples the render-time sweep reads off the SVG
            dom = (_F(domain[0]), _F(domain[1])) if domain is not None else None
            lo_, hi_ = self.lo, self.hi
            xs = [lo_ + (hi_ - lo_) * i / (SAMPLES - 1) for i in range(SAMPLES)]
            for e in S.ends() + [p[0] for p in solve(q).parts if p[0] is not None] + \
                    [p[1] for p in solve(q).parts if p[1] is not None]:
                xs += [e, e - (hi_ - lo_) / 500, e + (hi_ - lo_) / 500]
            for x in sorted(set(x for x in xs if lo_ <= x <= hi_)):
                want = q.holds(x) and (dom is None or dom[0] <= x <= dom[1])
                if S.contains(x) != want:
                    raise AssertionError(
                        "numberline: drawn set disagrees with the inequality at "
                        "x=%s (%s: %s, the set drawn: %s) — draw it with "
                        "from_inequality(%r), which derives the circles and rays"
                        % (_num(x), q.src, "in" if want else "out",
                           "out" if want else "in", q.src))
            ref = solve(q) if dom is None else intersect(solve(q), interval(*dom))
            if ref.parts != S.parts:
                raise AssertionError(
                    "numberline: drawn set disagrees with the inequality past the "
                    "end of the line: %s solves to %s, the drawing says %s (a "
                    "ray's arrow or an end circle is a claim about values beyond "
                    "the line) — draw it with from_inequality(%r)"
                    % (q.src, _set_text(ref), _set_text(S), q.src))
        elif q is not None:
            # C5 r3: on a critique line a disagreement IS the drawing — it is
            # kept, and remembered, so a critique line that turns out to be the
            # correct drawing can be refused (the giveaway rule)
            dom = (_F(domain[0]), _F(domain[1])) if domain is not None else None
            ref = solve(q) if dom is None else intersect(solve(q), interval(*dom))
            if _set_text(ref) != _set_text(S):
                self._crit_why.append(
                    "the set drawn is %s, and %s solves to %s"
                    % (_set_text(S), q.src, _set_text(ref)))
        self.sets.append(dict(S=S, q=q, domain=domain, between=between))
        self._key("set", S.kind, repr(S.parts))
        S.line = self                      # v6.2: .interval(...).svg() works
        return S

    def from_inequality(self, src, closed=None, domain=None, between=False):
        """Draw the solution set of `src` ('x<=2.5', '2x+3<2x+5', '-1<x<=4',
        or ('<=', 2.5)); `domain=(0, bound)` restricts it for a context
        problem. The drawing is sampled at 400 points against `src` at render.
        `closed=` overrides the boundary circles -- for a FAIL fixture; a
        wrong override is refused as a disagreement. A boundary must stand on
        a tick unless `between=True`."""
        q = Inequality(src)
        S = solve(q)
        return self._set(S, q, domain, closed, between=between)

    def interval(self, a, b, closed_a=True, closed_b=True, source=None,
                 between=False):
        return self._set(interval(a, b, closed_a, closed_b), source,
                         between=between)

    def ray(self, a, direction, closed=True, source=None, between=False):
        return self._set(ray(a, direction, closed), source, between=between)

    def union(self, *sets, **kw):
        return self._set(union(*sets), kw.get("source"),
                         between=kw.get("between", False))

    def intersect(self, *sets, **kw):
        return self._set(intersect(*sets), kw.get("source"),
                         between=kw.get("between", False))

    def all_reals(self, source=None):
        return self._identity(all_reals(), "all_reals", source)

    def empty(self, source=None):
        return self._identity(empty(), "empty", source)

    def _identity(self, S, name, source):
        if source is None:
            raise AssertionError(
                "numberline.%s: pass source='...' — all reals and the empty set "
                "come from an identity check on the inequality, never from the "
                "author's choice (use from_inequality)" % name)
        q = Inequality(source)
        if solve(q).kind != S.kind:
            raise AssertionError(
                "numberline.%s: %r is not %s — its solution set is %s"
                % (name, q.src, name, solve(q)))
        return self._set(S, q)

    def integers_in(self, S, domain=None, between=False):
        """Discrete dots at the integers of S (inside `domain`, default the
        line). Returns the values drawn."""
        self._one_set("the integers of a set")
        dlo, dhi = (_F(domain[0]), _F(domain[1])) if domain else (self.lo, self.hi)
        vals = [F(k) for k in range(math.ceil(max(dlo, self.lo)),
                                    math.floor(min(dhi, self.hi)) + 1)
                if S.contains(F(k))]
        P = Set(points=vals)
        for v in vals:
            self._val(v, "integer", between=between)
        self.sets.append(dict(S=P, q=None, domain=(dlo, dhi), src=S,
                              between=between))
        self._key("integers", repr(vals))
        return vals

    # -- C5: critique, reference lines, distance bars, zoom ---------------------
    def _allow_critique(self, what):
        """A deliberately wrong drawing (an error-finding item) is declared on
        the line AND the item: without asks=['find_error'] it is refused, so a
        wrong set can never reach a sheet as if it were the answer."""
        if "find_error" not in self.asks:
            raise AssertionError(
                "numberline: %s draws a deliberately WRONG line (a student's "
                "drawing for an error-finding item) — declare it: NL(..., "
                "student_drawing=True, asks=['find_error']), and give the "
                "question asks=['find_error'] too. A correct line needs neither"
                % what)
        self.critique = True

    def _crit_giveaway(self):
        """C5 r3 — the giveaway rule for a number LINE. A critique line is
        allowed BECAUSE something on it is wrong; a line that declares
        student_drawing=True and draws everything right is the correct answer
        standing beside an error-finding item. The flag alone used to be
        enough (sign_chart already refused the correct chart; a line did not).
        `student_drawing='...'` names an error the builder cannot see (a point
        at the wrong value, an arrow left off) and counts as the declaration."""
        if not self.critique or self._crit_why:
            return
        raise AssertionError(
            "numberline: this line declares student_drawing=True (a student's "
            "drawing, for an item that asks the reader to find the error) but "
            "nothing on it is drawn wrong — it IS the correct drawing, and it "
            "would give the answer away (the giveaway rule). Draw the error: "
            "wrong_scale=[(2, '2.5')] (a number written on the wrong tick) or "
            "from_inequality('x<2', closed=True) (the wrong boundary circle); "
            "if the error is one the drawing cannot show by itself (a point at "
            "the wrong value, a missing arrow), name it in words — "
            "student_drawing='the point stands at 3, the answer is 2'; or drop "
            "student_drawing= and draw the line correctly")

    def reference(self, v, kind="level", both_sides=True, label=None,
                  between=False):
        """A dashed reference line across the axis at `v` (a mirror line, a
        water level, sea level): past the ticks on the decorations' side
        (REF_LEN px) and, with `both_sides`, past the row of numbers on the
        other. Dashed, so it is not a tick or a span; `label` is Latin (a
        Hebrew word goes in the HTML). C5: the z01 q1 gauge's one-sided dash
        of tick length read as a stray tick. Stage-1 fix r1: on a VERTICAL
        line `both_sides` draws the decorations' side only -- the piece past
        a number stood on its middle line and printed as its minus sign."""
        if kind not in REF_DASH:
            raise AssertionError("numberline.reference: kind=%r — %s"
                                 % (kind, ", ".join(sorted(REF_DASH))))
        _latin(label, "reference label")
        # C5 r3: a dashed line across the axis at the hidden answer, with its
        # own label over it, marks the answer's position as plainly as a bar
        # or a point does — it is held to answer_hidden like every other mark
        v = self._val(v, "reference line", between)
        if any(float(r["v"]) == float(v) for r in self._refs):
            raise AssertionError("numberline.reference: a second reference at "
                                 "%s" % _lab(v))
        self._refs.append(dict(v=v, kind=kind, both=bool(both_sides),
                               label=label))
        self._key("reference", v, kind, bool(both_sides), bool(label))
        return self

    def bars_from_zero(self, values, order="given", row_ids=None,
                       min_len_pt=BAR_MIN_PT, between=True):
        """One bar per value, from 0 to the value, in rows above the axis --
        the z01 distance-bars device (1ב, 3ב, 11ב, 34ב, 36ב). `order`:
        'given' (top row first, the item's order) or 'asc'. `row_ids`: Latin
        letters drawn left of each row and keyed in the item text (default A,
        B, C ...). A bar that prints shorter than `min_len_pt` is refused by
        name, naming zoom() or a separate line (z01 3ב: the empty row was the
        answer). Bar ends need not stand on ticks (`between=True`)."""
        if self._bars:
            raise AssertionError("numberline.bars_from_zero: this line already "
                                 "has its bars")
        if self._decos or self._points or self.sets or self._refs:
            raise AssertionError(
                "numberline.bars_from_zero: a bars line carries its bars only "
                "(the row letters name them) — draw points, jumps and sets on "
                "a line of their own")
        if self.orientation == "v":
            raise AssertionError("numberline.bars_from_zero: a vertical line "
                                 "has no rows beside it — use a horizontal line")
        if order not in ("given", "asc"):
            raise AssertionError("numberline.bars_from_zero: order=%r — "
                                 "'given' or 'asc'" % (order,))
        if not (self.lo <= 0 <= self.hi):
            raise AssertionError("numberline.bars_from_zero: 0 is not on the "
                                 "line %s..%s — bars start at 0"
                                 % (_num(self.lo), _num(self.hi)))
        vals = list(values)
        if not vals:
            raise AssertionError("numberline.bars_from_zero: no values")
        ids = list(row_ids) if row_ids is not None else \
            [chr(ord("A") + i) for i in range(len(vals))]
        if len(ids) != len(vals):
            raise AssertionError(
                "numberline.bars_from_zero: %d values but %d row_ids — one "
                "letter per bar" % (len(vals), len(ids)))
        for t in ids:
            _latin(t, "row id")
            if not re.match(r"^[A-Za-z][A-Za-z0-9']{0,2}$", str(t)):
                raise AssertionError("numberline.bars_from_zero: row id %r — a "
                                     "Latin letter keyed in the item text" % (t,))
        if len(set(ids)) != len(ids):
            raise AssertionError("numberline.bars_from_zero: row ids repeat")
        rows = []
        for v, t in zip(vals, ids):
            fv = self._val(v, "bar end", between)
            if float(fv) == 0:
                raise AssertionError(
                    "numberline.bars_from_zero: the value 0 has no bar — say it "
                    "in the item, or compare it on a line with point(0)")
            rows.append((fv, str(t)))
        if order == "asc":
            rows.sort(key=lambda r: float(r[0]))
        self._bars = rows
        self._bar_min = float(min_len_pt)
        self._key("bars", order, tuple(float(v) for v, _ in rows))
        return self

    def _layout_bars(self, E, X, k_s, px, e0, half, x_left):
        # the row letters print at the sheet's LETTER size, so the pitch is
        # whatever keeps two of them clear of each other
        lpx = px * LETTER_PT / TICK_PT
        pitch, bh = max(BAR_ROW * k_s, lpx * 1.15), BAR_H * k_s
        base = e0 + 1.0 * k_s
        x0 = X(F(0))
        n = len(self._bars)
        for i, (v, t) in enumerate(self._bars):
            yc = -(base + pitch * (n - 1 - i) + pitch / 2.0)
            xv = X(v)
            L = abs(xv - x0) * PX_TO_PT / k_s
            if L < self._bar_min - 1e-9:
                self._errs.append(
                    "numberline.bars_from_zero: the bar for %s is %.2fpt, floor "
                    "%gpt — at this unit it cannot be seen. %s; never drop the "
                    "row or round the value" % (_lab(v), L, self._bar_min,
                                                self._small_fix(v)))
            E.bar(min(x0, xv), yc - bh / 2.0, max(x0, xv), yc + bh / 2.0)
            # stage review: a row's NAME is a letter and prints at the
            # sheet's letter size, like a point's letter -- it printed at the
            # tick-number size, so a sheet's A/B/C stood 1.5pt under the
            # letters of every other figure on it
            fw, fh = E.dims(t, lpx)
            xr = x_left - 3.0 * k_s
            E.text_box((xr - fw, yc - fh / 2.0, xr, yc + fh / 2.0), t, lpx)
        E.line((x0, -half["major"]), (x0, -(base + pitch * n + 1.0 * k_s)), 0.8)

    def _wider(self, prefix="", suffix=""):
        """v6 open issues (C4r3v-03): 'a wider placement' names only the tiers
        wider than this line's -- none on a strip line, on a vertical line, or
        on a line whose unit= the author fixed. '' or prefix+phrase+suffix."""
        if self.orientation == "v" or self.unit is not None:
            return ""
        wider = [t for t in ("block", "strip")
                 if TIERS[t] > max(TIERS.get(self.tier, 0.0),
                                   float(self.width or 0)) + 1e-6]
        if not wider:
            return ""
        return "%sa wider placement (%s)%s" % (
            prefix, " or ".join("tier='%s'" % t for t in wider), suffix)

    def _horizontal_tried(self):
        """v6 P2 r2 (P2R2-04): a vertical line's refusal offered 'draw it on
        a horizontal line' without trying it -- in 5 of 36 sampled vertical
        refusals the horizontal line at the same range is refused too, and
        the author was sent one step sideways. Offered only when it
        renders."""
        import copy
        if getattr(self, "_trial", False) or _SPLITTING:
            return ""
        memo = self.__dict__.setdefault("_split_memo", {})
        key = ("horiz", len(self._decos), len(self._calls), self.tier)
        if key not in memo:
            memo[key] = ""
            _SPLITTING.append(1)
            try:
                for t in [self.tier] + [w for w in ("side", "block", "strip")
                                        if w != self.tier]:
                    trial = copy.deepcopy(self)
                    trial._trial, trial.register = True, False
                    trial.orientation, trial.tier = "h", t
                    try:
                        trial.render()
                    except AssertionError:
                        continue
                    memo[key] = " draw it on a horizontal line (%s), or" % \
                        self._whole_call_src(t, orientation="h")
                    break
            finally:
                _SPLITTING.pop()
        return memo[key]

    def _finer_tick_tried(self):
        """v6 P2 r2 (P2R2-01): a line with a value OFF ITS TICKS and a layout
        fault refused with the layout symptom and no fix at all -- every
        trial the advice machinery renders (a split, a shorter range, a wider
        tier) is refused for the off-tick value, so each came back empty,
        while the one-keystroke fix (a finer tick) was already in
        self._offtick. Name it here, and only after it RENDERS: the finer
        tick alone, then with each wider placement (tick=1 on its own is
        usually refused for crowded numbers, which would have sent the
        author one step sideways)."""
        import copy
        fines = [f for f in self.__dict__.get("_otf", []) if f > 0]
        if not fines or getattr(self, "_trial", False) or _SPLITTING:
            return ""
        fine = min(fines)
        if fine == self.tick:
            return ""
        memo = self.__dict__.setdefault("_split_memo", {})
        key = ("finer", len(self._decos), len(self._calls), self.tier)
        if key in memo:
            return memo[key]
        memo[key] = ""
        _SPLITTING.append(1)
        try:
            for t in [self.tier] + [w for w in ("side", "block", "strip")
                                    if w != self.tier]:
                trial = copy.deepcopy(self)
                trial._trial, trial.register = True, False
                trial.tick, trial.tier = fine, t
                trial.__dict__["_ot"] = []
                trial.__dict__["_otf"] = []
                try:
                    trial.render()
                except AssertionError:
                    continue
                memo[key] = (" — the line also has a value off its ticks, and "
                             "no wider line, shorter range or split can draw "
                             "that: %s renders" % self._whole_call_src(
                                 t, tick=fine))
                break
        finally:
            _SPLITTING.pop()
        return memo[key]

    def _between_is_didactic(self):
        """between=True declares a value the reader CANNOT read off a tick.
        A value that sits on a tick of this line, or on a tick of a finer
        numbering that draws the same line, is not an estimate -- it is a
        value the item gave away by leaving it unmarked."""
        if getattr(self, "_trial", False) or _SPLITTING or self.sketch:
            return []
        out = []
        for what, fv in self.__dict__.get("_btw", []):
            if what != "point":
                # between= is also passed inside the builder (a bar's end, a
                # span's end); the DECLARATION this guards is a point's
                continue
            if not isinstance(fv, F):
                # a float typed for an estimate is still exact when a short
                # fraction hits it: 7.0, 0.5 and 2.25 are not estimates
                fr = F(fv).limit_denominator(1000)
                if abs(float(fr) - float(fv)) > 1e-9:
                    continue
                fv = fr
            d = (fv / self.tick).denominator
            if d == 1:
                out.append(
                    "numberline: %s %s is declared between=True, but it sits "
                    "ON the tick %s of this line -- between= is for a value "
                    "no tick shows. Drop between=True and draw the point on "
                    "its tick; never leave a value the reader could read off "
                    "the line as an unmarked dot"
                    % (what, _num(fv), _num(fv)))
                continue
            # Only the plain case: a WHOLE-number tick whose half shows the
            # value. On a line already ticked in tenths or thirds, halving
            # again is not the reader's fix, so between= stays the honest
            # declaration there.
            if d != 2 or self.tick != 1:
                continue
            fine = self.tick / d
            call = self._finer_renders(fine)
            if call:
                out.append(
                    "numberline: %s %s is declared between=True, but a finer "
                    "numbering shows it exactly and draws this same line: %s "
                    "renders. between= is for a value no tick can show -- "
                    "taken here it turns a value the reader could read off a "
                    "tick into an unmarked dot" % (what, _num(fv), call))
        return out

    def _finer_renders(self, fine):
        """The call for this line at `fine` ticks, quoted only when it
        RENDERS (the same trial machinery _finer_tick_tried uses)."""
        import copy
        if fine == self.tick or getattr(self, "_trial", False) or _SPLITTING:
            return ""
        memo = self.__dict__.setdefault("_split_memo", {})
        key = ("btwfine", str(fine), len(self._decos), len(self._calls),
               self.tier)
        if key in memo:
            return memo[key]
        memo[key] = ""
        _SPLITTING.append(1)
        try:
            # built from the CONSTRUCTOR, not deep-copied: a copy keeps the
            # tick list and the label set the old tick made, so the trial
            # drew the old numbering on the new ticks and always failed
            kw = dict(self.__dict__.get("_ctor_all", {}), tick=fine,
                      register=False)
            try:
                trial = NL(**kw)
                trial._trial = True
                for name, a_, k_ in self._calls:
                    kk = dict(k_)
                    if name in ("point", "points", "span", "symmetric",
                                "double_arrow", "midpoint", "test_markers"):
                        kk.pop("between", None)
                    getattr(trial, name)(*a_, **kk)
                trial.render()
                memo[key] = self._whole_call_src(
                    self.tier, tick=fine).replace(", between=True", "")
            except (AssertionError, TypeError, ValueError):
                pass
        finally:
            _SPLITTING.pop()
        return memo[key]

    def _tier_and_tick(self, cands):
        """P3 (g): the floor refusal used to name 'a wider placement
        (tier='block' or tier='strip')' when no coarser tick rendered HERE.
        Both tiers then refused the line as called -- NL(0, 100,
        tier='side').point(35, 'A') sent the author through three refusals
        before tick=5 at a wider tier rendered. The pair is tried here, and
        the refusal names the call that renders, or nothing."""
        if getattr(self, "_trial", False) or _SPLITTING or \
                not hasattr(self, "_ctor_all"):
            return ""
        memo = self.__dict__.setdefault("_split_memo", {})
        key = ("tiertick", len(self._decos), len(self._calls), self.tier)
        if key in memo:
            return memo[key]
        memo[key] = ""
        # a wider line has a bigger unit, so ticks this tier cannot print may
        # clear the floor there: every nicer tick is a candidate, not only the
        # ones that clear the floor HERE
        try:
            more = self._coarser_ticks(0.0, min_tick=self.tick)[0]
        except Exception:               # noqa: BLE001 - a hint, never a stop
            more = []
        cands = list(cands) + [c for c in more if c not in cands]
        _SPLITTING.append(1)
        try:
            for t in ("side", "block", "strip"):
                if TIERS.get(t, 0.0) <= max(TIERS.get(self.tier, 0.0),
                                            float(self.width or 0)) + 1e-6:
                    continue
                for c in sorted(cands)[:6]:
                    try:
                        kw = dict(self._ctor_all, tick=c, tier=t,
                                  register=False)
                        trial = NL(**kw)
                        trial._trial = True
                        for name, a, k in self._calls:
                            getattr(trial, name)(*a, **k)
                        trial.svg()
                    except (AssertionError, TypeError):
                        continue
                    memo[key] = (" — a coarser tick at a wider placement "
                                 "draws it: %s renders"
                                 % self._whole_call_src(t, tick=c))
                    return memo[key]
        finally:
            _SPLITTING.pop()
        return memo[key]

    def _wider_tried(self, prefix="", suffix=""):
        """C7P-04: _wider, keeping only the tiers on which this line RENDERS.
        The walk chain([-2, 6, -5, 5]) was sent from 'block' to 'strip', and
        drawn there with two arcs crossing almost along each other."""
        if getattr(self, "_trial", False) or _SPLITTING:
            return ""
        memo = self.__dict__.setdefault("_split_memo", {})
        key = ("wider", len(self._decos), len(self._calls), self.tier,
               prefix, suffix)
        if key not in memo:
            _SPLITTING.append(1)
            try:
                memo[key] = self._wider_tried_now(prefix, suffix)
            finally:
                _SPLITTING.pop()
        return memo[key]

    def _wider_tried_now(self, prefix, suffix):
        import copy
        ok = []
        for t in ("side", "block", "strip"):
            # v6 P2 r1 (P2-L1-01): an item line's next placement is 'side'
            if t not in self._wider() and not (
                    t == "side" and self.tier == "item" and self.unit is None
                    and self.orientation != "v" and not self.width):
                continue
            trial = copy.deepcopy(self)
            trial._trial, trial.tier, trial.register = True, t, False
            try:
                trial.render()
                ok.append(t)
            except AssertionError:
                pass
        if not ok:
            return ""
        return "%sa wider placement (%s)%s" % (
            prefix, " or ".join("tier='%s'" % t for t in ok), suffix)

    def _shorter_range(self):
        """v6 P2 r1 (P2-L1-01): 'a shorter range' as the call that renders --
        the line cut to the whole ticks around every value it shows -- or ''
        when that range is this one or does not render."""
        if _SPLITTING or getattr(self, "_trial", False) or \
                not hasattr(self, "_ctor_all"):
            return ""
        vals = [float(j[k]) for j in self._decos if j["kind"] == "jump"
                for k in ("a", "b")] + [float(p["v"]) for p in self._points]
        if not vals or self.sets or self.unit is not None:
            # (a row of a stack is fitted to the stack's shared unit)
            return ""
        t = self.tick
        lo = t * math.floor(F(min(vals)).limit_denominator(10 ** 6) / t)
        hi = t * math.ceil(F(max(vals)).limit_denominator(10 ** 6) / t)
        if hi - lo < 2 * t or (lo, hi) == (self.lo, self.hi):
            return ""
        memo = self.__dict__.setdefault("_split_memo", {})
        key = ("range", len(self._decos), len(self._calls), self.tier)
        if key not in memo:
            memo[key] = ""
            _SPLITTING.append(1)
            try:
                kw = dict(self._ctor_all, lo=lo, hi=hi, register=False)
                trial = NL(**kw)
                trial._trial = True
                for name, a, k in self._calls:
                    getattr(trial, name)(*a, **k)
                trial.svg()
                src = self._row_src(self.tier, False, "")
                src = re.sub(r"^N\.NL\([^,]+, [^,)]+", "N.NL(%s, %s" % (
                    _pyn(lo), _pyn(hi)), src)
                memo[key] = "a shorter range (%s, with the same calls)" % src
            except AssertionError:
                pass
            finally:
                _SPLITTING.pop()
        return memo[key]

    def _later(self, fn):
        """A token standing for fn() in an error text, resolved at raise."""
        lazy = self.__dict__.setdefault("_lazy", {})
        k = len(lazy)
        lazy[k] = fn
        return "\x00lazy%d\x00" % k

    def _split_advice(self, d):
        return self._later(lambda: self._split_advice_now(d))

    def _split_advice_now(self, d):
        """v6 P2 r1 (LP2-04, P2-L2-06, LP2-02): how to split, said as the
        call that renders does it -- the prose and the call used to disagree
        ('up to 4 ... from 4 on' over a call that split elsewhere, 'two
        number lines' over three rows, N.stack for a vertical line)."""
        call = self._split_call(d)
        if self.orientation == "v":
            return call or (" (one figure each, side by side: N.stack takes "
                            "horizontal lines only)")
        if call:
            return ", one under the other with the same range" + call
        return (", one under the other with the same range: two number lines "
                "with the walk split at %s (N.stack([first, second]))"
                % _lab(d["a"]))

    def _split_call(self, d, wider_only=False):
        """Stage-1 fix r1 (nl-dropping-jump-labels): the walk split at the
        jump `d` that has no place, as the call that draws it on two (or
        three) lines -- quoted only when it RENDERS. The refusal said 'draw
        these jumps on two number lines' with no call and no split point, and
        the easy way out was deleting the labels.

        v6 P2 r1: the text names the number of lines the call really has
        (LP2-04: 'two' over a three-row stack), keeps the line's own call
        (tick=, width=, points, sets: LP2-01), tries the wider tiers when no
        split renders at this one (P2-L1-01: a hop too short at item width
        is split at side width), and on a vertical line -- which N.stack
        does not take -- names the vertical lines side by side (LP2-02).
        Computed once per jump per render: every solver pass asked again,
        and each answer rendered stacks (a refused item walk took 12s)."""
        if _SPLITTING or getattr(self, "_trial", False) or \
                not hasattr(self, "_ctor_all"):
            return ""
        key = (id(d), len(self._decos), len(self._calls), self.tier,
               self.width, wider_only)
        memo = self.__dict__.setdefault("_split_memo", {})
        if key not in memo:
            _SPLITTING.append(1)
            try:
                memo[key] = self._split_find(d, wider_only)
            finally:
                _SPLITTING.pop()
        return memo[key]

    def _split_find(self, d, wider_only=False):
        js = [j for j in self._decos if j["kind"] == "jump"]
        order = self._chain_order(js)
        if d not in order or len(order) < 2:
            return ""
        tiers = [self.tier]
        if self.orientation != "v" and self.unit is None and not self.width:
            tiers += [t for t in ("side", "block", "strip")
                      if TIERS[t] > TIERS.get(self.tier, 0.0) + 1e-6]
        if wider_only:
            # a hop too short at this width is as short on any row of it
            tiers = tiers[1:]
        walk = [order[0]["a"]] + [j["b"] for j in order]
        chained = all(float(a["b"]) == float(b["a"])
                      for a, b in zip(order, order[1:]))
        for tier in tiers:
            if not chained:
                got = self._split_jumps(d, order, tier)
            else:
                got = ""
                i0 = max(order.index(d), 1)
                # v6 P2: the split at this jump first, then at the nearest
                # other hops, then three lines
                for i in sorted(range(1, len(order)),
                                key=lambda k: (abs(k - i0), k)):
                    got = self._split_at(walk, order, [i], tier)
                    if got:
                        break
                if not got:
                    for i in range(1, len(order) - 1):
                        for k in range(i + 1, len(order)):
                            got = self._split_at(walk, order, [i, k], tier)
                            if got:
                                break
                        if got:
                            break
            if got:
                return got
        return ""

    def _split_row(self, tier, first, add):
        """One trial row of a split: this line's own call at `tier`, the
        line's other decorations on the FIRST row, then `add(row)`."""
        kw = dict(self._ctor_all, tier=tier, register=False)
        t = NL(**kw)
        t._trial = True
        if first:
            for name, a, k in self._calls:
                if name not in _JUMP_CALLS:
                    getattr(t, name)(*a, **k)
        add(t)
        return t

    def _whole_call_src(self, tier, **over):
        """This whole line as source -- its constructor (with `over` applied),
        its decorations AND its jumps -- for a refusal that names a call the
        author can paste (v6 P2 r2, P2R2-01)."""
        keep = self.__dict__.get("_ctor_all", {})
        self.__dict__["_ctor_all"] = dict(keep, **over)
        try:
            out = self._row_src(tier, True, "")
        finally:
            self.__dict__["_ctor_all"] = keep
        for name, a, k in self._calls:
            if name not in _JUMP_CALLS:
                continue
            parts = [_src(x) or "..." for x in a] + \
                ["%s=%s" % (kk, _src(vv) or "...") for kk, vv in k.items()]
            out += ".%s(%s)" % (name, ", ".join(parts))
        return out

    def _replay_lines(self, var):
        """This line as statements that rebuild it (v6.5 X2 r1, spec rule 6):
        its constructor with every non-default value, then every call made
        on it, in order. None when a value has no source (a Set object)."""
        ctor = dict(self.__dict__.get("_ctor_all") or {})
        if not ctor or getattr(self, "legacy", None):
            return None
        dflt = _NL_DEFAULTS
        kw = {}
        for k, v in ctor.items():
            if k in ("lo", "hi"):
                continue
            if k in dflt and _same(v, dflt[k]):
                continue
            kw[k] = v
        head = export.call_src("numberline", "NL", (ctor["lo"], ctor["hi"]), kw)
        if head is None:
            return None
        lines = ["%s = %s" % (var, head)]
        for name, a, k in self._calls:
            src = export.call_src(var, name, a, k)
            if src is None:
                return None
            lines.append(src)
        return lines

    def _row_src(self, tier, first, tail):
        dflt = _NL_DEFAULTS
        args = [_pyn(self._ctor_all["lo"]), _pyn(self._ctor_all["hi"])]
        for k, v in self._ctor_all.items():
            if k in ("lo", "hi"):
                continue
            if k == "tier":
                v = tier
                if self.orientation == "v" and v == dflt.get("tier"):
                    continue        # a vertical line is sized by height=
            elif k in dflt and _same(v, dflt[k]):
                continue
            src = _src(v)
            args.append("%s=%s" % (k, src if src is not None else "..."))
        out = "N.NL(%s)" % ", ".join(args)
        if first:
            for name, a, k in self._calls:
                if name in _JUMP_CALLS:
                    continue
                parts = [_src(x) or "..." for x in a] + \
                    ["%s=%s" % (kk, _src(vv) or "...")
                     for kk, vv in k.items()]
                out += ".%s(%s)" % (name, ", ".join(parts))
        return out + tail

    def _rows_text(self, rows, srcs):
        """The finished split, or '' when it does not render."""
        n = {2: "two", 3: "three"}.get(len(srcs), str(len(srcs)))
        if self.orientation == "v":
            # LP2-02: N.stack refuses vertical rows -- each line is its own
            # figure, printed side by side
            try:
                for r in rows:
                    r.svg()
            except AssertionError:
                return ""
            return (" -- %s vertical number lines side by side render it, "
                    "one figure each (N.stack takes horizontal lines only): "
                    "%s" % (n, "; ".join(srcs)))
        try:
            stack(rows).svg()
        except AssertionError:
            return ""
        return " -- on %s number lines it renders as N.stack([%s])" % (
            n, ", ".join(srcs))

    def _split_at(self, walk, order, cuts, tier=None):
        tier = tier or self.tier
        b = [0] + list(cuts) + [len(order)]
        parts = [(walk[b[q]:b[q + 1] + 1], order[b[q]:b[q + 1]])
                 for q in range(len(b) - 1)]
        srcs, rows = [], []
        for q, (vals, jj) in enumerate(parts):
            labs = [j["label"] for j in jj]
            lab = labs if any(labs) else None
            try:
                rows.append(self._split_row(tier, q == 0,
                                      lambda t: t.chain(vals, lab)))
            except AssertionError:
                return ""
            srcs.append(self._row_src(tier, q == 0, ".chain([%s]%s)" % (
                ", ".join(_pyn(v) for v in vals),
                ", [%s]" % ", ".join(repr(str(l)) for l in labs)
                if lab else "")))
        return self._rows_text(rows, srcs)

    def _split_jumps(self, d, order, tier=None):
        """v6 P2: jumps that are no walk (0 -> 5, 2 -> 7, 4 -> 9: three spans
        that interleave, so two arcs must cross on any one side) -- the jump
        `d` moved to a second line, with every other jump that cannot share
        the first line's sides with the rest, as the call that renders; ''
        when it does not."""
        tier = tier or self.tier
        if self.orientation == "v":
            # one side only: rows in which no two jumps interleave or land
            # on one value (at most three)
            groups = []
            for j in [d] + [o for o in order if o is not d]:
                for g in groups:
                    if not any(_side_conflict(o, j) for o in g):
                        g.append(j)
                        break
                else:
                    groups.append([j])
            if len(groups) > 3:
                return ""
            return self._jump_rows(groups, tier)
        first, second = [], []
        for j in order:
            if j is d:
                second.append(j)
                continue
            clash = [o for o in first if _interleave(o, j)]
            if len(clash) >= 1 and any(_interleave(a, b) for a in clash
                                       for b in clash + [j] if a is not b and
                                       b is not j) or len(clash) >= 2:
                second.append(j)
            else:
                first.append(j)
        if not first or not second:
            return ""
        return self._jump_rows([first, second], tier)

    def _jump_rows(self, groups, tier):
        srcs, rows = [], []
        for q, jj in enumerate(groups):
            if not jj:
                return ""

            def add(t, jj=jj):
                for j in jj:
                    t.jump(j["a"], j["b"], j["label"])
            try:
                rows.append(self._split_row(tier, q == 0, add))
            except AssertionError:
                return ""
            srcs.append(self._row_src(tier, q == 0, "".join(
                ".jump(%s, %s%s)" % (_pyn(j["a"]), _pyn(j["b"]),
                                     ", %r" % str(j["label"]) if j["label"]
                                     else "") for j in jj)))
        return self._rows_text(rows, srcs)

    def _small_fix(self, v):
        """The fixes for a value too small for this line's unit, in order:
        a zoom of the tick cell holding it (when one x10 zoom shows it), a
        separate line at its own scale."""
        fixes = []
        if isinstance(v, F) or isinstance(v, float):
            fv = F(v).limit_denominator(10 ** 6) if isinstance(v, float) else v
            t = self.tick
            a = t * math.floor(fv / t)
            if a == fv and fv > self.lo:
                a -= t
            b = a + t
            if a >= self.lo and b <= self.hi:
                for sub in (10, 5, 4, 2):
                    ct = t / sub
                    if (fv / ct).denominator == 1 and fv not in (a, b):
                        fixes.append("show it in a zoom: nl.zoom(%s, %s, subdiv=%d)"
                                     % (_pyn(a), _pyn(b), sub))
                        break
            if abs(fv) > 0 and not fixes:
                # a line of this value's own magnitude, on which it is a TICK
                # (the -0.5 and -395 case). A value that would stand between
                # ticks there as well is no better off, so nothing is named
                e = F(10) ** int(math.floor(math.log10(abs(float(fv)))))
                if (fv / e).denominator == 1:
                    lo_ = e * 10 * math.floor(min(fv, 0) / (e * 10))
                    hi_ = e * 10 * math.ceil(max(fv, 0) / (e * 10))
                    if lo_ == hi_:
                        hi_ += e * 10
                    fixes.append(
                        "draw it on a separate line at its own scale "
                        "(N.NL(%s, %s, tick=%s)) beside this one — a split "
                        "scale, N.stack([...], scale='own')"
                        % (_pyn(lo_), _pyn(hi_), _pyn(e)))
        return "; ".join(fixes) or "draw it on a separate line"

    def zoom(self, a, b, subdiv=10, tier=None, captions=None, connect=True):
        """A magnified row under this line: the segment a..b is shaded here
        and redrawn below with `subdiv` intervals, joined by dashed
        connectors from a and b. Returns a `Stack`; mark the detail on
        `.child` (and this line as usual) before `.svg()` / `.html()`."""
        if self.orientation == "v":
            raise AssertionError("numberline.zoom: zoom a horizontal line")
        a, b = _F(a, "zoom start"), _F(b, "zoom end")
        if not a < b:
            raise AssertionError("numberline.zoom: a=%s is not below b=%s"
                                 % (_num(a), _num(b)))
        self._in_range(a, "zoom start")
        self._in_range(b, "zoom end")
        for e in (a, b):
            if (e / self.tick).denominator != 1:
                raise AssertionError(
                    "numberline.zoom: %s is not a tick of %s — a zoom magnifies "
                    "the stretch between two ticks the reader can find (e.g. "
                    "zoom(%s, %s))" % (_num(e), _num(self.tick),
                                       _pyn(self.tick * math.floor(a / self.tick)),
                                       _pyn(self.tick * math.ceil(b / self.tick))))
        if not isinstance(subdiv, int) or subdiv < 2:
            raise AssertionError("numberline.zoom: subdiv=%r — a whole number "
                                 ">= 2 of intervals" % (subdiv,))
        if (a, b) == (self.lo, self.hi):
            raise AssertionError("numberline.zoom: the whole line — draw the "
                                 "finer line itself")
        self._zooms.append((a, b))
        self._key("zoom", a, b, subdiv)
        ct = (b - a) / subdiv
        # the magnified row numbers its own ticks: with label_fmt left to
        # 'auto' a tenths line numbers only the whole numbers, and a zoom
        # that prints 2 and 3 magnifies nothing the reader can read
        child = NL(a, b, tick=ct, tier=tier or self.tier,
                   label_fmt="dec" if _finite_dec(ct) else "frac",
                   register=self.register)
        # C5 r3: the row knows it is a zoom, so a printed-size refusal names
        # subdiv= — the parameter the author actually passed
        child._zoom_of = (a, b, subdiv)
        return Stack([self, child], scale="own", captions=captions,
                     _zoom=(a, b, subdiv, connect))

    # lazily created lists (keeps __init__ readable)
    @property
    def _points(self):
        if not hasattr(self, "_pts"):
            self._pts = []
        return self._pts

    @property
    def _offtick(self):
        if not hasattr(self, "_ot"):
            self._ot = []
        return self._ot

    @property
    def _decos(self):
        if not hasattr(self, "_dec"):
            self._dec = []
        return self._dec

    # -- fam ------------------------------------------------------------------------
    def fam_key(self):
        kind = "blank" if self.blank else "sketch" if self.sketch else \
            "sparse" if self.sparse else "regular"
        if self.orientation == "v":
            kind += "+v"
        if self.critique:
            # recorded as critique: a wrong drawing is another object than
            # the correct one, and a gate can read which it is
            kind += "+critique"
        h = hashlib.sha1(repr(sorted(self.marks)).encode("utf-8")).hexdigest()[:10]
        return "numberline[%s,%s,%s,%s]{%s}" % (self.lo, self.hi, self.tick, kind, h)

    # -- render ---------------------------------------------------------------------
    def svg(self, width=None):
        return self.render(width)

    def _points_vs_sets(self):
        """A circle point on a line that carries a set is read as part of the
        set. Allowed where it agrees with the drawing (a filled point inside
        the set, a point on an end drawn in the end's own style); otherwise
        refused, naming the call that works. C4 r2: a point ON a set end was
        told 'use tri', and the tri was then refused as 'one marker per
        value' -- a loop with no way out. A set end is named with the end's
        own circle: point(v, name, <its style>)."""
        for p in self._points:
            if not self.sets:
                return
            v = p["v"]
            for st in self.sets:
                S = st["S"]
                ends = {}
                for a, b, ca, cb in S.parts:
                    if a is not None:
                        ends[a] = "filled" if ca else "open"
                    if b is not None:
                        ends[b] = "filled" if cb else "open"
                for q in (S.points or []):
                    ends[q] = "filled"
                if isinstance(v, F) and v in ends:
                    if ends[v] == p["style"] and p["kind"] != "test":
                        continue
                    inside = S.contains(v)
                    if p["kind"] == "test":
                        # C4 r3: the fix named swapped the test marker for an
                        # open point, dropping the 'check this value' marker
                        raise AssertionError(
                            "numberline: the test marker at %s stands on the "
                            "set's %s end circle — one would hide the other. "
                            "Keep both: draw the test values on a line of their "
                            "own under this one, N.NL(%s, %s).test_markers([(%s, "
                            "%r)]), with the same range" % (
                                _lab(v), ends[v], _pyn(self.lo), _pyn(self.hi),
                                _pyv(v), "x" if p["style"] == "cross" else "tri"))
                    raise AssertionError(
                        "numberline: a %s marker at %s stands on the set's %s "
                        "end circle (%s is %s the set) — the later marker hides "
                        "the end. To name that end, give the point the end's own "
                        "circle: point(%s, %r, %r); to show a different value, "
                        "draw it on its own line"
                        % (p["style"], _lab(v), ends[v], _lab(v),
                           "in" if inside else "not in", _pyv(v),
                           p["name"], ends[v]))
                if p["style"] not in ("filled", "open"):
                    continue
                x = v if isinstance(v, F) else F(v).limit_denominator(10 ** 6)
                ok = p["style"] == "filled" and S.points is None and S.contains(x)
                if not ok:
                    raise AssertionError(
                        "numberline: a %s point at %s on a line that shows a set "
                        "reads as part of the set (or a hole in it) — mark it with "
                        "style='tri' or 'cross', use test_markers(), or draw it on "
                        "its own line" % (p["style"], _lab(v)))

    def render(self, width=None):
        self._crit_giveaway()
        self._points_vs_sets()
        self._labset = set(self.labelled)
        s = 1.0
        lg = self.legacy
        if lg:
            # v5.8 number_line: X = v * size -- `size` figure units per UNIT,
            # whatever the step (C4 r2: the shim used size per step, and
            # number_line(-3, 5, step=2, size=20) shrank from 206 to 117px)
            unit = float(lg["size"])
            for _ in range(4):
                body, vb = self._layout(unit, s)
                if lg.get("width"):
                    s = float(lg["width"]) / vb[2]
            disp = float(lg["width"]) if lg.get("width") else vb[2]
        else:
            W = float(width or self.width or TIERS[self.tier])
            if self.unit is not None:
                unit = float(self.unit)
                body, vb = self._layout(unit, s)
            elif self.orientation == "v":
                # C5: `height` is the printed length of lo..hi; the figure
                # adds its overhang, arrowheads and margins
                unit = self.height / float(self.hi - self.lo)
                self._pick_k(unit)
                body, vb = self._layout(unit, s)
            else:
                span = float(self.hi - self.lo)
                unit = max((W - 60.0) / span, 1e-3)
                self._pick_k(unit)
                for _ in range(6):
                    body, vb = self._layout(unit, s)
                    if abs(vb[2] - W) < 0.25 and vb[2] <= W + 1e-6:
                        break
                    unit = max(unit + (W - 0.2 - vb[2]) / span, 1e-3)
                    self._pick_k(unit)
                body, vb = self._layout(unit, s)
            disp = vb[2]
        self._floors(unit, disp / vb[2])
        if self._errs:
            # v6 P2 r1 PERF: the fixes a refusal names render trial lines
            # and stacks, so they are worked out for the refusal RAISED only
            # (every solver pass used to build them for every error)
            msg = self._errs[0]
            lazy = self.__dict__.get("_lazy", {})
            while True:
                m = re.search("\x00lazy(\\d+)\x00", msg)
                if not m:
                    break
                msg = msg.replace(m.group(0), lazy[int(m.group(1))]())
            msg = msg.replace(
                _WIDER_TRIED, self._wider_tried(prefix=", or ")).replace(
                _WIDER_USE, self._wider_tried(prefix=" — use "))
            # v6 P2 r2 (P2R2-01): a refusal that names NOTHING that renders,
            # on a line that also has a value off its ticks -- the off-tick
            # message holds the fix the trials could never reach.
            # stage review: the test for "names nothing that RENDERS" read
            # the literal 'N.stack(' -- which the prose fallback 'two number
            # lines ... (N.stack([first, second]))' also contains, so a
            # message naming no runnable call lost its off-tick fix. Every
            # runnable call quoted here holds an 'N.NL(' (a stack's rows do
            # too); the prose does not.
            if "N.NL(" not in msg and "tier='" not in msg:
                msg += self._finer_tick_tried()
            raise AssertionError(msg)
        out = ['<svg xmlns="http://www.w3.org/2000/svg" width="%.2f" height="%.2f" '
               'viewBox="0 0 %.2f %.2f">' % (disp, vb[3] * disp / vb[2], vb[2], vb[3])]
        out += body
        out.append("</svg>")
        svg = "".join(out)
        if self.legacy:
            # stage review: the figkit.number_line shim keeps its caller's
            # own size=/font= (backward compatibility), so such a line prints
            # a look of its own. It SAYS so, and G78 names the call that puts
            # it back in the sheet's look.
            svg = svg.replace(">", ">" + LEGACY_TAG, 1)
        # v6.5 (DELIVERABLE_SPEC 1-2): what this line drew, with `svg_xy` in
        # the file's own frame, and the refusal if the two disagree
        Ec = getattr(self, "_canvas", None)
        if Ec is not None and getattr(Ec, "at", None) is not None:
            # the numbers the FILE states (its header is written at two
            # decimals), so unit_px is the scale a renderer really applies
            _wf = float("%.2f" % disp)
            _vwf, _vhf = float("%.2f" % vb[2]), float("%.2f" % vb[3])
            # v6.8 final (G6): a number printed under the line names the
            # tick (else the point) it stands for, by id
            _own = {}
            for _it in Ec.ex.items:
                if _it.kind in ("ticks", "point") and _it.name is not None:
                    if _it.kind == "ticks" or str(_it.name) not in _own:
                        _own[str(_it.name)] = export.make_id(_it.kind,
                                                             _it.name)
            # v6.7-noam r1 (BC2-NL-LETTERS): a point keeps its value name
            # (pt-1), and carries the letter printed over it (letter "A"),
            # so a claim naming A finds the point as well as its label
            _let = dict((v_, k_) for k_, v_ in
                        getattr(Ec, "letter_for", {}).items())
            for _it in Ec.ex.items:
                if _it.kind == "point" and str(_it.name) in _let:
                    if _it.meta is None:
                        _it.meta = {}
                    _it.meta["letter"] = _let[str(_it.name)]
            for _it in Ec.ex.items:
                _lf = getattr(Ec, "letter_for", {}).get(str(_it.name))
                if (_it.kind == "label" and not (_it.meta or {}).get("for")
                        and _lf is not None):
                    _it.meta["for"] = export.make_id("point", _lf)
                    continue
                _wrf = getattr(Ec, "wrong_for", {}).get(str(_it.name))
                if (_it.kind == "label" and not (_it.meta or {}).get("for")
                        and _wrf is not None and _wrf in _own):
                    # v6.12 fix_r2 (N2): the student's wrong number stands
                    # for the tick it is printed under
                    if _it.meta is None:
                        _it.meta = {}
                    _it.meta["for"] = _own[_wrf]
                    continue
                if (_it.kind == "label" and not (_it.meta or {}).get("for")
                        and str(_it.name) in _own):
                    if _it.meta is None:
                        _it.meta = {}
                    _it.meta["for"] = _own[str(_it.name)]
            # v6.12 fix_r1 (M1-readoff): no id may name a value the student
            # reads off. A tick is named by its INDEX from the low end
            # (tick-k0, tick-k1, ...), a lettered point by its LETTER (pt-A),
            # so the served SVG no longer says id="pt-m2d5" beside lbl-A. A
            # printed number keeps its value name (lbl-m1: it is printed).
            svg = _neutral_ids(svg, Ec)
            Ec.ex.finish(Ec.at, {"width_px": _wf,
                                 "height_px": float("%.2f" % (vb[3] * disp
                                                              / vb[2])),
                                 "unit_px": round(_wf / _vwf, 6),
                                 "viewbox": [_vwf, _vhf],
                                 "rotate": 90 if self.orientation == "v" else 0},
                         rotate=90 if self.orientation == "v" else 0)
            anch = Ec.ex.anchors(set(Ec.oids.values()))
            if anch:
                svg = svg.replace("</svg>", anch + "</svg>", 1)
            export.verify(svg, Ec.ex, "numberline.NL.render")
            # v6.5 X2: what a number line KNOWS -- every marked point lies on
            # the axis, a span's midpoint is its midpoint -- re-measured on
            # the file, then the figure is filed under the key written into
            # it so packaging finds this build and never re-runs it.
            Ec.ex.kindname = "numberline"
            Ec.ex.critique = "find_error" if self.critique else None
            export.recheck(svg, Ec.ex, "numberline.NL.render")
            _rl = self._replay_lines("n")
            with export.replay(
                    "import numberline\n%s\nsvg = n.svg(%s)"
                    % ("\n".join(_rl), export.lit(width))
                    if _rl and export.lit(width) is not None else None):
                svg = export.stamp(svg, Ec.ex, export.callsite())
            self.objects = Ec.ex
        E_ = (getattr(self, "_geo", None) or {}).get("canvas")
        if E_ is not None and getattr(E_, "geometry", None):
            # C6 r6: the file draws every stroke the layout emitted -- a hole
            # in a reference, an arc or the axis is refused off the file
            svgcheck.assert_draws(svg, E_.geometry, "numberline.NL(%s, %s)"
                                  % (_num(self.lo), _num(self.hi)))
        irregular = self.fmt in ("frac", "mixed") or self.sparse or self.sketch \
            or self.critique
        dots = [float(p["v"]) for p in self._points
                if p["style"] == "filled"]
        for st in self.sets:
            S = st["S"]
            dots += [float(e) for a, b, ca, cb in S.parts
                     for e, c in ((a, ca), (b, cb)) if e is not None and c]
            dots += [float(p) for p in (S.points or [])]
        svgcheck.assert_clean(
            svg, "numberline.NL(%s, %s)" % (_num(self.lo), _num(self.hi)),
            # a critique line's numbers are wrong on purpose: distance only
            # a double line's two rows are read by double_sweep, each on its
            # own: svgcheck judges both against one lattice and refuses the
            # second scale's numbers as sitting on the first's ticks
            ticks=(False if self._top else True if self.critique else
                   "values" if irregular else True),
            irregular=irregular,
            # a mixed number's whole part stands beside its fraction, off the
            # tick; svgcheck's merge sweep reads it as a stray label in the
            # row. sweep() groups it with its tick and reads its value instead,
            # and still refuses any other text in the row
            merges=self.fmt != "mixed",
            # a sketch line's two or three reference ticks are no axis to
            # svgcheck, and it read them as equality ticks on the pieces the
            # points cut (C4 r2) -- a number line carries no geometry marks
            marks=not self.sketch,
            # C5 r2: on a VERTICAL line svgcheck reads the numbers against a
            # horizontal lattice, so the dot rule is run by sweep_v in the
            # turned frame instead -- never dropped
            dot_values=(dots or None) if not irregular and
            self.orientation == "h" else None)
        bad = self._sweep(svg, (dots or None) if not irregular else None)
        if bad:
            raise AssertionError("numberline.sweep: NL(%s, %s) — %s"
                                 % (_num(self.lo), _num(self.hi), "; ".join(bad)))
        if self.register:
            _SHEET["lines"] += 1
        if self.fam:
            import figkit
            svg = figkit.tag(svg, self.fam)
        else:
            svg = svg.replace(">", "><!--fam:%s-->" % self.fam_key(), 1)
        if self.critique:
            svg = svg.replace("-->", "--><!--critique:find_error-->", 1)
        return svg

    def _sweep(self, svg, dots=None):
        """The independent sweeps for this kind of line (C5: vertical lines,
        bars, sign charts, a second scale and critique lines each read the
        SVG with their own additions)."""
        kw = dict(member=None if self.critique else self._member(),
                  lo=float(self.lo), hi=float(self.hi),
                  label_spacing=not self.legacy,
                  lengths=not (self.sparse or self.sketch),
                  vote=not self.critique, bars=self._bars or None,
                  signs=bool(self._signs))
        if self._top:
            # C5 r3: the ratio rule ('0 pairs with 0') was written but never
            # reached a shipped figure — double_sweep was called without it
            return double_sweep(svg, ratio=getattr(self, "_ratio", False), **kw)
        if self.orientation == "v":
            return sweep_v(svg, dots=dots, **kw)
        bad = sweep(svg, **kw)
        if self._signs:
            # C5 r3: sign_sweep is the independent reader of a sign chart, and
            # render() never called it — sweep(signs=True) marks the '+'/'−'
            # texts as owned and says nothing more about them, so a sign in the
            # wrong interval, two signs in one interval or a sign missing
            # altogether shipped unseen. A critique chart is read WITHOUT its
            # polynomial: its disagreement with p(x) is the point of the figure
            # (sign_sweep's structural rules still run).
            bad += sign_sweep(svg, poly=None if self.critique
                              else getattr(self, "_poly", None))
        return bad

    def _member(self):
        """What the sampling check compares the drawing with: the SOURCE
        inequality of each set drawn from one (and its domain)."""
        refs = []
        for st in self.sets:
            q, dom = st["q"], st["domain"]
            if q is None and "src" not in st:
                continue
            if "src" in st:
                S, (dlo, dhi) = st["src"], st["domain"]
                refs.append(("points", lambda x, S=S, dlo=dlo, dhi=dhi:
                             x.denominator == 1 and dlo <= x <= dhi and S.contains(x),
                             st["S"]))
                continue

            def ref(x, q=q, dom=dom):
                if dom is not None and not (_F(dom[0]) <= x <= _F(dom[1])):
                    return False
                return q.holds(x)
            refs.append(("set", ref, st["S"], q.src))
        return refs or None

    def _pick_k(self, unit):
        """label_every='auto': the densest candidate whose numbers stand
        LABEL_SPACING x the widest number apart at this unit."""
        if self.k is None or len(getattr(self, "_cands", [])) < 2:
            return
        for k in self._cands:
            lab = [kk * self.tick for kk in self.ks if kk % k == 0]
            fmt = self.fmt
            wmax = max([self._along(v, fmt) for v in lab] or [0])
            if k * self.tick * unit * PX_TO_PT >= self._lab_factor() * wmax * \
                    PX_TO_PT - 1e-9:
                break
        if k != self.k:
            self.k = k
            self.labelled = lab
            self._labset = set(lab)

    def _floors(self, unit, sc):
        """Printed spacing floors, from the numbers (the sweep re-reads them
        from the SVG). Refused with the fix named."""
        if self.sketch:
            # stage-1 fix r1 (doctrine 4, as plane() sketches are): a sketch
            # that CARRIES data -- lettered points, jumps, spans, sets -- is
            # held to the floor of the numbered line it sketches. sketch=True
            # was a one-kwarg way past 'minor ticks 4.5pt apart': the same
            # points printed on a line numbered only '0'. A sign chart (its
            # roots are its references) is a sketch by nature.
            if self._signs or not (self._points or self._decos or self.sets):
                return
            gap = float(self.tick) * unit * sc * PX_TO_PT
            if gap < MINOR_GAP_PT - 1e-6:
                k = int(math.ceil(MINOR_GAP_PT / gap - 1e-9))
                raise AssertionError(
                    "numberline: this sketch line carries data, and the line "
                    "it sketches (tick=%s) would print its ticks %.1fpt apart, "
                    "floor %gpt -- sketch=True is not a way past the floor. "
                    "Draw it numbered with a tick of at least %s x this one "
                    "(on which the values still sit), %sa shorter range"
                    % (_pyn(self.tick), gap, MINOR_GAP_PT, k,
                       self._wider_tried(suffix=", or ")))
            return
        if self.legacy:
            self._legacy_floors(unit, sc)
        ppt = unit * sc * PX_TO_PT
        gap = float(self.tick) * ppt
        if gap < MINOR_GAP_PT - 1e-6:
            # C5 r3: the magnified row of a zoom has no tick= of its own — the
            # author wrote subdiv=, and being told to pass tick=0.04 names a
            # call that does not exist on this figure
            z = getattr(self, "_zoom_of", None)
            if z is not None:
                raise AssertionError(
                    "numberline.zoom: the magnified row cuts %s..%s into %d "
                    "intervals, %.1fpt apart, floor %gpt — %s, or a wider "
                    "placement (tier='block' or 'strip')"
                    % (_num(z[0]), _num(z[1]), z[2], gap, MINOR_GAP_PT,
                       self._zoom_subdiv(z, gap / MINOR_GAP_PT)))
            # C7N-04: 'tick x 2' was named without being tried -- 1/7 was
            # sent to 2/7, 4/7, 8/7 (no whole number a tick) and 0..100 to
            # 2, 4, 8 (numbered 0, 16, ..., 96). The tick named is the nicer
            # tick _coarser_tick picks (unit fractions, then x2, x5/2, x5, x10)
            # that clears this floor and keeps every exact value on a tick.
            cands, stranded = self._coarser_ticks(0.0, min_tick=self.tick * F(
                int(math.ceil(MINOR_GAP_PT / gap * 1000)), 1000))
            # O3-03: the tick named is one on which this line RENDERS (the
            # numbers' density rule included), ends numbered where one does
            c = self._tick_that_renders(cands) if cands else None
            if c is not None:
                ct = "coarser tick (tick=%s)" % _pyn(c)
            elif stranded:
                ct = ("coarser tick= — but the nearest tick that clears the "
                      "floor (tick=%s) leaves %s off its ticks%s"
                      % (_pyn(stranded[0]),
                         ", ".join(_num(v) for v in stranded[1][:4])
                         .replace("-", MINUS),
                         self._tier_and_tick(cands)))
            elif cands:
                ct = ("coarser tick= — but no tick that clears the floor "
                      "(tick=%s ...) numbers this line within the density "
                      "rule%s" % (_pyn(cands[0]), self._tier_and_tick(cands)))
            else:
                ct = ("coarser tick= — but a tick clears the floor only from "
                      "%d x this one, which leaves fewer than 4 ticks on this "
                      "range" % int(math.ceil(MINOR_GAP_PT / gap - 1e-9)))
                if self.width and self.orientation != "v":
                    ct += " — so a wider line (width=%d)" % int(
                        math.ceil(float(self.width) * MINOR_GAP_PT / gap))
            if self.orientation == "v":
                raise AssertionError(
                    "numberline: minor ticks %.1fpt apart, floor %gpt — use a "
                    "%s or a taller line (height=%d), or a "
                    "shorter range; never a smaller font"
                    % (gap, MINOR_GAP_PT, ct,
                       int(math.ceil(self.height * MINOR_GAP_PT / gap))))
            raise AssertionError(
                # P3 (g): the tiers named are the ones this line RENDERS at,
                # not every tier wider than this one -- NL(0, 100,
                # tier='side').point(35, 'A') named block and strip, and both
                # refused the line as called
                "numberline: minor ticks %.1fpt apart, floor %gpt — use a "
                "%s, %sa shorter range; never a smaller font"
                % (gap, MINOR_GAP_PT, ct, self._wider_tried(suffix=", or ")))
        labs = sorted(self.labelled)
        # the figkit.number_line shim keeps its callers' own font and size
        # (z08 2ב: '10' at 15.8 units on 20-unit steps); new lines are held
        # to the spacing rule
        if len(labs) >= 2 and not self.legacy:
            wmax = max(self._along(v, self.fmt) for v in labs) * sc * PX_TO_PT
            d = min(float(b - a) for a, b in zip(labs, labs[1:])) * ppt
            fac = self._lab_factor()
            if d < fac * wmax - 1e-6:
                # C7P2-07 / O3-03: name the coarser tick that renders, as the
                # floor refusal does (label_every= alone cannot part them)
                cands = self._coarser_ticks(0.0, min_tick=self.tick * F(
                    1001, 1000))[0]
                c = self._tick_that_renders(cands) if cands and not \
                    getattr(self, "_trial", False) else None
                raise AssertionError(
                    "numberline: numbered ticks %.1fpt apart, need %.1f x the "
                    "%s (%.1fpt) = %.1fpt — %suse a coarser tick%s, %s"
                    "or a shorter range"
                    % (d, fac, "height of a number" if self.orientation == "v"
                       else "widest number", wmax, fac * wmax,
                       # v6 open issues (C4r3v-09): label_every= is named
                       # only when numbering every 2nd whole step -- the
                       # sparsest the density rule allows -- has the room
                       "number fewer ticks within the density rule "
                       "(label_every=), " if 2 * float(self.major) * ppt >=
                       fac * wmax - 1e-6 else "",
                       " (tick=%s)" % _pyn(c) if c is not None else "",
                       "a taller line (height=) " if self.orientation == "v" else
                       self._wider_tried(suffix=" "))
                    # stage review (L3-Stage-03): the tier list used to come
                    # from _wider, which names every WIDER tier without
                    # drawing the line there -- 14 of 258 refusals in a
                    # 600-walk probe named only tiers that are themselves
                    # refused, so the builder's first named exit dead-ended.
                    # _wider_tried names only tiers that render; when none
                    # does, the tick-and-tier pair is tried, so the message
                    # still carries a call that draws.
                    + (self._tier_and_tick(cands)
                       if not self._wider_tried() else "")
                    + self._zoom_tail(d / (fac * wmax)))

    def _zoom_subdiv(self, z, room):
        """The subdiv that fits, given the fraction of the needed room this
        one has (`room` < 1). C5 r3."""
        k = int(math.floor(z[2] * room))
        if k >= 2:
            return "use fewer intervals (subdiv=%d)" % k
        return ("a zoom of %s..%s does not fit here at any subdiv — magnify a "
                "shorter stretch" % (_num(z[0]), _num(z[1])))

    def _zoom_tail(self, room):
        """The same fix, as a tail on a refusal that is not the zoom's own."""
        z = getattr(self, "_zoom_of", None)
        if z is None:
            return ""
        return (" — this row is the magnified row of zoom(%s, %s, subdiv=%d): "
                "%s" % (_pyn(z[0]), _pyn(z[1]), z[2],
                        self._zoom_subdiv(z, room)))

    def _legacy_floors(self, unit, sc):
        """figkit.number_line callers: numbers that strike each other or print
        under the 7pt floor are refused naming the shim's own knobs. C4 r3:
        number_line(0, 1, step=0.1, width=300) was refused as a bare 'struck
        label' that named no fix."""
        lg = self.legacy
        font, size = float(lg["font"]), float(lg["size"])
        labs = sorted(self.labelled)
        step = self.tick
        s_min = 0.0
        if len(labs) >= 2:
            wmax = max(self._label_w(v, self.fmt) for v in labs)
            g = min(float(b - a) for a, b in zip(labs, labs[1:]))
            d = g * unit
            s_min = (wmax + 0.15 * font) / g
            if d < wmax + 0.15 * font - 1e-6:
                need = int(math.ceil((wmax + 0.5 * font) / g))
                coarse = [c for c in (step * 2, step * 5, step * 10)
                          if (self.hi - self.lo) / c >= 2 and
                          float(c) * unit >= wmax + 0.5 * font]
                # v6 open issues (C4r3v-07): the size named must render --
                # a bigger size widens the drawing, and shown at the same
                # width= its numbers can drop under the 7pt floor. The width
                # that keeps them at the floor is named with it.
                shown = ""
                if lg.get("width"):
                    disp = float(lg["width"])
                    pads = disp / sc - float(self.hi - self.lo) * unit
                    full2 = pads + float(self.hi - self.lo) * need
                    if font * disp / full2 * PX_TO_PT < svgcheck.MIN_PT - 1e-6:
                        shown = " with width=%d" % (int(math.ceil(
                            full2 * svgcheck.MIN_PT / (font * PX_TO_PT))) + 1)
                raise AssertionError(
                    "figkit.number_line: numbers %.1f units wide stand %.1f units "
                    "apart (step=%s x size=%g) — they strike each other. Use "
                    "size=%d (figure units per unit)%s%s; never a smaller font"
                    % (wmax, d, _pyn(step), size, need, shown,
                       (", or a coarser step (step=%s)" % _pyn(coarse[0]))
                       if coarse else ""))
        pt = font * sc * PX_TO_PT
        if pt < svgcheck.MIN_PT - 1e-6:
            disp = float(lg["width"])
            full = disp / sc
            pads = full - float(self.hi - self.lo) * unit
            # the largest size whose drawing, shown `width` wide, still prints
            # the font at the floor -- offered only if the numbers still clear
            s_max = (disp * font * PX_TO_PT / svgcheck.MIN_PT - pads) / \
                float(self.hi - self.lo)
            alt = (" or a smaller size=%d" % int(math.floor(s_max))) \
                if int(math.floor(s_max)) >= max(s_min, 1.0) else ""
            raise AssertionError(
                "figkit.number_line: the numbers print at %.1fpt, under %gpt — "
                "the %.0f-unit drawing is shown %gpx wide. Show it wider "
                "(width=%d)%s; never a smaller font"
                % (pt, svgcheck.MIN_PT, full, disp,
                   int(math.ceil(disp * svgcheck.MIN_PT / pt)) + 1, alt))

    # -- geometry ---------------------------------------------------------------------
    def _px(self):
        """Label size in figure units."""
        if self.legacy:
            return float(self.legacy["font"])
        return self.tick_pt / PX_TO_PT

    def _letter_px(self):
        """v6.2 Q1b (the verifier's V2): a point's LETTER in figure units.

        The shim used to print its caller's own font for the letter as well,
        so a legacy number_line on a v6 sheet printed its numbers AND its
        letters at one size of its own -- 7.5pt where the sheet printed 8.0
        and 9.5 -- and G78 refused the whole level (z08_a q2). Doctrine 5:
        the shim must keep existing levels working. In `house` mode (the
        shim's default now) the legacy px is the one the caller's drawing is
        SHOWN at, tuned by figkit.number_line until the numbers print at the
        sheet's number_pt, and the letter keeps the house ratio to it."""
        if not self.legacy:
            return LETTER_PT / PX_TO_PT
        f = float(self.legacy["font"])
        return f * LETTER_PT / TICK_PT if self.legacy.get("house") else f

    def _label_runs(self, v, fmt):
        """[(text, dx, dy_baseline, px)], [vinculum (x0, x1, y)], width, depth
        -- relative to the tick's x and the top of the label row."""
        px = self._px()
        asc = 0.72 * px
        v = F(v)
        sign = MINUS if v < 0 else ("+" if self.plus_sign and v > 0 else "")
        av = abs(v)
        if fmt in ("int", "dec") or av.denominator == 1:
            t = sign + _num(av)
            return [(t, 0.0, asc, px)], [], _adv(t, px), asc + 0.1 * px
        whole = av.numerator // av.denominator if fmt == "mixed" else 0
        fr = av - whole
        nt, dt = str(fr.numerator), str(fr.denominator)
        wf = max(_adv(nt, px), _adv(dt, px)) + 2.0
        yn = asc
        yv = yn + 0.09 * px + 1.4
        yd = yv + 1.4 + 0.72 * px
        head = sign + (str(whole) if whole else "")
        wh = _adv(head, px) + (1.0 if head else 0.0)
        runs, vin = [], []
        if head in (MINUS, "+"):
            # a lone sign before a stacked fraction: the FRACTION stays centred
            # on its tick and the sign hangs to its left, drawn as a stroke at
            # the bar's height (a '+' as two). As a text run '−' it stood alone
            # in the row of numbers and read as one of them, and a fraction
            # pushed right by its sign was read as a number off its tick
            W = wf + 2.0 * wh
            left = -wf / 2.0 - wh
            vin.append((left + 0.3, left + wh - 1.2, yv, "sign"))
            if head == "+":
                c = left + 0.3 + (wh - 1.5) / 2.0
                vin.append((c, c, yv, "sign", (wh - 1.5) / 2.0))
            cx = 0.0
        else:
            W = wh + wf
            left = -W / 2.0
            if head:
                runs.append((head, left + wh / 2.0 - 0.5, yv + 0.33 * px, px))
            cx = left + wh + wf / 2.0
        runs.append((nt, cx, yn, px))
        runs.append((dt, cx, yd, px))
        vin.append((cx - wf / 2.0 + 0.6, cx + wf / 2.0 - 0.6, yv))
        return runs, vin, W, yd + 0.1 * px

    def _label_w(self, v, fmt):
        return self._label_runs(v, fmt)[2]

    def _along(self, v, fmt):
        """A tick number's extent along the scale: its width on a horizontal
        line, one line (1.02 em) on a vertical one."""
        if self.orientation == "v":
            return 1.02 * self._px()
        return self._label_w(v, fmt)

    def _lab_factor(self):
        return LABEL_V_SPACING if self.orientation == "v" else LABEL_SPACING

    def _layout(self, unit, s):
        """Every element in figure units, then translated. Returns (body, vb)."""
        E = _Canvas(vertical=self.orientation == "v")
        self._dims, self._canvas = E.dims, E
        # refusals found while laying out are raised by render() AFTER the
        # printed floors: C4 r2 blamed a point 'within r of the -130 tick' on
        # a line whose ticks broke the 6pt floor, the real fault
        self._errs = []
        lo, hi = self.lo, self.hi
        X = lambda v: float(F(v) - lo) * unit if isinstance(v, F) else \
            (v - float(lo)) * unit
        # v6.5 r1 (X1-06): the DATA frame of a number line is its VALUE axis.
        # `xy` used to be the canvas position (the point at 2 exported
        # [109.75, 0]), which is not what the question talks about. The map
        # is the inverse of X; across the axis it reads in the same units, so
        # a decoration above the line has a positive second coordinate. Every
        # object here is named by its value, so no id moves.
        E.ex.set_data(lambda q, _u=(float(unit) or 1.0), _lo=float(lo):
                      (q[0] / _u + _lo, -q[1] / _u))
        px = self._px()
        k_s = 1.0 / s                       # printed floors at display scale
        r = MARK_R_PT / PX_TO_PT * k_s
        if self.legacy:
            r = max(r, 3.0)
        hl, hw = HEAD[0] * k_s, HEAD[1] * k_s
        rhl, rhw = RAY_HEAD[0] * k_s, RAY_HEAD[1] * k_s
        half = dict((k, v / 2.0 * k_s) for k, v in TICK_LEN.items())
        rim = RIM_CLEAR_PT / PX_TO_PT * k_s
        # -- which ends carry an arrow, a ray, an end circle
        left_arrow = self.arrows == "both"
        right_arrow = self.arrows in ("both", "right")
        ray_l = any(p[0] is None for st in self.sets for p in st["S"].parts)
        ray_r = any(p[1] is None for st in self.sets for p in st["S"].parts)
        end_vals = [p["v"] for p in self._points] + \
            [e for st in self.sets for e in st["S"].ends()]
        pad = PAD * k_s if not self.legacy else 14.0
        pl = pr = pad
        if any(float(e) == float(lo) for e in end_vals):
            pl = max(pl, r + rim + 1.0)
        if any(float(e) == float(hi) for e in end_vals):
            pr = max(pr, r + rim + 1.0)
        xL, xR = X(lo) - pl, X(hi) + pr
        # C5: a zoom's segment, a light band behind everything (not ink)
        for za, zb in self._zooms:
            E.shade(X(za), -ZOOM_BAND * k_s, X(zb), ZOOM_BAND * k_s)
        # the axis runs from xL to xR; a head's BASE sits on the end, its tip
        # beyond it. A ray's head replaces the axis head on its side.
        E.line((xL, 0.0), (xR, 0.0), AXIS_W, cap="butt", ex=("segment", "axis"))
        a0 = xL - (rhl if ray_l else hl if left_arrow else 0.0)
        a1 = xR + (rhl if ray_r else hl if right_arrow else 0.0)
        if left_arrow and not ray_l:
            E.head((a0, 0.0), (-1.0, 0.0), hl, hw)
        if right_arrow and not ray_r:
            E.head((a1, 0.0), (1.0, 0.0), hl, hw)
        self._ends = (a0, a1)
        # -- ticks
        ticks = [k * self.tick for k in self.ks] if not self.sketch else \
            list(self.ref_ticks)
        top_row = 0.0
        for v in ticks:
            lev = self._level(v)
            h = half[lev]
            w = TICK_W
            if self.zero_emph and v == 0:
                h, w = half["major"] + ZERO_EXTRA / 2.0 * k_s, ZERO_W
            E.line((X(v), -h), (X(v), h), w, ex=("ticks", _idname(v)))
            top_row = max(top_row, h)
        # -- tick numbers, pinned
        row_top = half["major"] + 2.0 * k_s + \
            (ZERO_EXTRA / 2.0 * k_s if self.zero_emph else 0.0)
        # stage review: at the house look the major tick is shorter than the
        # markers are wide, so the row of numbers came up under them and a
        # tick number printed inside the dot standing on its value ('2' under
        # the marker at 2). The row clears whatever is drawn ON the line.
        if self._points or self.sets:
            row_top = max(row_top, r + 1.6 * k_s)
        row_bot = row_top
        wrong = dict(self.wrong_scale)
        for v in sorted(self._labset):
            runs, vin, W, depth = self._label_runs(v, self.fmt)
            lname = _idname(v)
            if v in wrong:
                # C5 critique: the student's number printed at this tick
                runs = [(wrong[v], 0.0, 0.72 * px, px)]
                vin, depth = [], 0.82 * px
                # v6.12 fix_r2 (N2): the label is named by what it PRINTS
                # (the student's '2.5' -> lbl-2d5), never by the tick's true
                # value, which is what a find_error item asks for
                lname = _wrong_name(wrong[v], {_idname(u) for u in self._labset
                                               if u not in wrong})
                if not hasattr(E, "wrong_for"):
                    E.wrong_for = {}
                E.wrong_for[lname] = _idname(v)     # its tick, by value
            x = self._tick_label_x(X(v), runs, px)
            if E.vertical:
                t = runs[0][0]
                fw, fh = E.dims(t, px)
                E.text_box((x - fw / 2.0, row_top, x + fw / 2.0, row_top + fh),
                           t, px, ex=("label", lname))
                depth = fh
            else:
                _emit_group(E, x, row_top, runs, vin,
                            ex=("label", lname))
            row_bot = max(row_bot, row_top + depth)
        self._row = (row_top, row_bot)
        # C5 double(): the second scale's numbers over the same ticks
        for v, ent in self._top:
            if ent[0] == "text":
                runs, vin, depth = [(ent[1], 0.0, 0.72 * px, px)], [], 0.82 * px
            else:
                runs, vin, W, depth = self._label_runs(ent[1], ent[2])
            _emit_group(E, X(v), -(row_top + depth), runs, vin)
        # C5 reference lines: dashed, across the axis, past the ticks. The
        # ink is reserved now (a letter is placed clear of it) and drawn at
        # the end, CUT around every label it would run through
        self._ref_spans = []
        for rf in self._refs:
            x = X(rf["v"])
            spans = [(-REF_LEN * k_s, -(half["major"] + 1.5 * k_s))]
            if rf["both"] and not E.vertical:
                # stage-1 fix r1 (PR1): not on a VERTICAL line -- there the
                # piece past the number lies on the number's own middle line
                # and prints as its minus sign ('2' read '−2'); the line runs
                # on the decorations' side only (dash_as_sign refuses it)
                # past the number standing at this value (not past the whole
                # row: on a vertical line the widest number is far away, and
                # the piece read as a stray dash in the margin)
                hit = [b for b in E.boxes if b[0] - 1.5 < x < b[2] + 1.5 and b[1] > 0]
                y0 = (max(b[3] for b in hit) if hit else half["major"]) + 1.5 * k_s
                spans.append((y0, y0 + REF_BELOW * k_s))
            for y0, y1 in spans:
                E.reserve((x, y0), (x, y1), 1.0)
            self._ref_spans.append((x, spans, REF_DASH[rf["kind"]]))
        # -- sets: bars, rays, knock-outs (markers come last)
        ends = []
        for st in self.sets:
            S = st["S"]
            for a, b, ca, cb in S.parts:
                xa = X(a) if a is not None else xL
                xb = X(b) if b is not None else xR
                E.line((xa, 0), (xb, 0), BAR_W * k_s, cap="butt")
                if a is None:
                    E.head((a0, 0.0), (-1.0, 0.0), rhl, rhw)
                if b is None:
                    E.head((a1, 0.0), (1.0, 0.0), rhl, rhw)
                for v in ticks:
                    xv = X(v)
                    if xa + r + 0.5 < xv < xb - r - 0.5:
                        E.knock((xv, -BAR_W * k_s / 2.0 - 0.2),
                                (xv, BAR_W * k_s / 2.0 + 0.2), 0.9)
                if a is not None:
                    ends.append((a, "filled" if ca else "open"))
                if b is not None:
                    ends.append((b, "filled" if cb else "open"))
            for p in (S.points or []):
                ends.append((p, "filled"))
        # -- decorations above / below
        e0 = r + (ARROW_GAP_PT + 0.9) / PX_TO_PT * k_s
        below0 = row_bot + 3.0 * k_s
        if self._bars:
            self._layout_bars(E, X, k_s, px, e0, half, min(a0, xL))
        # v6 P2 r1 (P2-L2-04): with no marker on the line the jumps start a
        # marker's radius above their ticks, floating over the tick top (two
        # arcs of a fan met in a sharp V there). Where nothing is marked they
        # start just over the tick, as Typst does.
        e0j = e0 if (self._points or self.sets or ends) else max(
            half["major"] + 0.8 / PX_TO_PT * k_s,
            (ARROW_GAP_PT + 0.9) / PX_TO_PT * k_s)
        placed = self._layout_jumps(E, X, k_s, px, hl, hw, e0j, below0)
        if any(d["kind"] in ("bracket", "arrow2") for d in self._decos) and \
                not E.vertical:
            # stage-1 fix r1 (PR9): a span stands ABOVE the letters of the
            # points under it. Placed first, a span's bracket ran between A
            # and its dot and its '0.7' printed on A's row: 'A   0.7', A
            # being 0.3. The letter's room over its marker is reserved here
            lpx0 = self._letter_px()
            for p in self._points:
                if not p["name"]:
                    continue
                w_, h_ = self._dims(svgcheck.true_minus(str(p["name"])), lpx0)
                xp = X(p["v"])
                top_ = self._letter_floor(p["style"], r, k_s) + h_ + 1.0
                placed[1].append((xp - w_ / 2.0, xp + w_ / 2.0, top_))
        self._layout_spans(E, X, k_s, px, hl, hw, e0, placed)
        # -- markers last, above every stroke
        marks = [(p["v"], p["style"]) for p in self._points] + ends
        seen = set()
        for v, st in marks:
            key = (float(v), st)
            if key in seen:
                continue
            seen.add(key)
            if st in ("cross", "tri"):
                # stage-1 fix r1 (PR7): the tick under a cross or a triangle
                # is knocked out (the axis is not): through the X it printed
                # a six-armed asterisk, and it stuck out under a triangle's
                # base. The tick stays in the file; only paper covers it.
                hh = half["major"] + ZERO_EXTRA / 2.0 * k_s + 0.6
                aw = AXIS_W / 2.0 + 0.05
                E.knock((X(v), -hh), (X(v), -aw), TICK_W * k_s + 0.9)
                E.knock((X(v), aw), (X(v), hh), TICK_W * k_s + 0.9)
            E.marker((X(v), 0.0), st, r, ex=("point", _idname(v)))
        self._separation(marks, X, r, ticks, k_s)
        self._errs += self._offtick[:1]
        self._errs += self._between_is_didactic()
        # C5 sign_chart(): one sign over each interval, clear of the circles
        for xs_, t in self._signs:
            E.text_over(X(xs_), -(e0 + 2.0 * k_s), t, LETTER_PT / PX_TO_PT)
        # -- letters and value labels, clear of everything, over their point
        lpx = self._letter_px()
        for p in self._points:
            y_min = self._letter_floor(p["style"], r, k_s)
            if p["name"]:
                t = svgcheck.true_minus(str(p["name"]))
                # v6.8 final (B-NUM-3): the letter is an exported label
                # (lbl-A) tied by `for` to its point, so Noam AI finds A
                _lx = None
                if not hasattr(E, "letter_for"):
                    E.letter_for = {}
                if t not in E.letter_for and re.match(
                        u"^[A-Za-z\u05d0-\u05ea][A-Za-z0-9'\u2032]*$", t):
                    E.letter_for[t] = _idname(p["v"])
                    _lx = ("label", t)
                y_min = E.place_label(X(p["v"]), t, lpx, y_min,
                                      ex=_lx) + 1.0
            vl = p["value_label"]
            if vl and vl is not True:
                if vl[0] == "text" or E.vertical:
                    t = vl[1] if vl[0] == "text" else \
                        self._label_runs(vl[1], vl[2])[0][0][0]
                    y_min = E.place_label(X(p["v"]), t, px, y_min) + 1.0
                else:
                    runs, vin, W, depth = self._label_runs(vl[1], vl[2])
                    y_min = E.place_group(X(p["v"]), runs, vin, W, depth, px,
                                          y_min) + 1.0
        # a reference line runs past everything standing in its column (a
        # span's label, a jump's arc): cut short by one it would read as that
        # decoration's own mark
        spans2 = []
        for i, (x, spans, dash) in enumerate(self._ref_spans):
            col = [e[4] for e in E.els if e[4][0] - 1.0 < x < e[4][2] + 1.0
                   and e[4][1] < 0]
            top = max([-b[1] + 7.0 * k_s for b in col] + [REF_LEN * k_s])
            spans = [(-(top + 3.0 * k_s), spans[0][1])] + list(spans[1:])
            spans2.append((x, spans, dash))
            rf = self._refs[i]
            if rf["label"]:
                E.place_label(x, svgcheck.true_minus(str(rf["label"])), px,
                              top + 4.5 * k_s)
        for x, spans, dash in spans2:
            for y0, y1 in spans:
                for a, b in _cut_span(y0, y1, [bx for bx in E.boxes
                                               if bx[0] - 1.0 < x < bx[2] + 1.0],
                                      at=0.0):
                    E.line((x, a), (x, b), 1.0, cap="butt", dash=dash)
        body, vb = E.emit(MARGIN)
        self._geo = dict(unit=unit, lo=lo, ox=E.ox, oy=E.oy, vb=vb, canvas=E,
                         row=self._row)
        return body, vb

    # -- jumps ------------------------------------------------------------------
    @staticmethod
    def _chain_order(jumps):
        """Jumps that share an end, in walking order: jump(-4,-1) then
        jump(-7,-4) is the chain -7 -> -4 -> -1 (C4 r2: called out of order,
        the second head ran into the first's start)."""
        rem, out = list(jumps), []
        while rem:
            cur = [rem.pop(0)]
            # forward first, so a back-and-forth walk keeps its own order
            # (0->3 then 3->0 is not the walk 3->0->3)
            for fwd in (True, False):
                grown = True
                while grown:
                    grown = False
                    for j in rem:
                        if fwd and float(j["a"]) == float(cur[-1]["b"]):
                            cur.append(j)
                        elif not fwd and float(j["b"]) == float(cur[0]["a"]):
                            cur.insert(0, j)
                        else:
                            continue
                        rem.remove(j)
                        grown = True
                        break
            out += cur
        return out

    def _layout_jumps(self, E, X, k_s, px, hl, hw, e0, below0):
        """Every jump is GROUNDED: its arc leaves its start tick and its head
        lands on its end tick, just clear of the axis (above) or of the row
        of numbers (below). A jump that overlaps another takes the other side,
        then a taller arc, the first whose head stands the arrow gap clear of
        every placed arc and head. Labels are placed after all arcs, at the
        apex or slid along the arc, clear of every arc, head and label.
        C4 r2: overlapping jumps were stacked on levels that floated above
        the axis with no connection to their ticks, and a '?' label was placed
        where another arc ran through it. None clear -> refused, naming why."""
        gap = ARROW_GAP_PT / PX_TO_PT * k_s + 0.3 * k_s
        self._X = X
        # stage-1 fix r1: a departure's step along the line is bounded by
        # TICK_TOL of a tick spacing, so the arc still starts AT its tick
        self._tick_px = abs(X(self.lo + self.tick) - X(self.lo))
        jl = []
        prev = None
        order = self._chain_order([d for d in self._decos
                                   if d["kind"] == "jump"])

        def _nest(d):
            """v6 stage 1b, ported from the tool comparison (Typst figlib):
            the LONGER jump is the OUTER arc. A jump's level is the number of
            jumps that lie strictly inside it, so a hop drawn over another
            arches over it instead of crossing it. Ours searched heights from
            the bottom up and, with the ARC_MAX clamp giving every long hop
            the same height, drew 1 -> 9 and 3 -> 7 as two crossing arcs."""
            lo, hi = sorted((float(d["a"]), float(d["b"])))
            n = 0
            for o in order:
                if o is d:
                    continue
                a, b = sorted((float(o["a"]), float(o["b"])))
                if a >= lo - 1e-9 and b <= hi + 1e-9 and \
                        (b - a) < (hi - lo) - 1e-9:
                    n += 1
            return n

        def _inside(j, x0, x1):
            """Is the placed jump `j` the arc this one nests under?"""
            return j["x0"] <= x0 + 0.5 and x1 <= j["x1"] + 0.5 and \
                (j["x1"] - j["x0"]) > (x1 - x0) + 0.5
        def solve(avoid):
            """C6 r6: one pass over the jumps. With `avoid`, each jump first
            looks for a place where its arc crosses no placed arc; the layout
            is kept only if every jump found one, else the layout of the
            older passes is used whole (a forced crossing stays as it was,
            rather than one jump being pushed onto a tall arc by the others'
            new places)."""
            jl, errs, crossed = [], [], [False]
            prev = None
            for d in order:
                d.pop("_side", None)
                xa, xb = X(d["a"]), X(d["b"])
                span = abs(xb - xa)
                pref, walk = 1, False
                if prev is not None and float(prev["b"]) == float(d["a"]) and \
                        self.orientation != "v":
                    same = (float(prev["b"]) - float(prev["a"])) * \
                        (float(d["b"]) - float(d["a"])) > 0
                    pref = prev["_side"] if same else -prev["_side"]
                    # stage review: a WALK -- hop after hop the same way --
                    # keeps ONE side for its whole length. The side was only
                    # a preference, tried at each height before the height
                    # grew, so chain([2, 3, 4, 5]) drew hop 1 above, hop 2
                    # BELOW the row of numbers and hop 3 above: a detached
                    # comma under the digits, and the walk could no longer be
                    # read left to right. The other side is still reachable,
                    # but only after every height on this one.
                    walk = same
                h0 = min(max(ARC_PREF * span, ARC_MIN * k_s), ARC_MAX * k_s,
                         ARC_RATIO * span)
                step = (LEVEL_GAP + 5.0) * k_s
                x0, x1 = min(xa, xb), max(xa, xb)
                hl_j, hw_j = hl, hw
                if span < SHORT_HOP * hl - 1e-6:
                    # v6 P2 r1 (LP2-03): the smaller head the nested layout
                    # draws a short hop with, here too. The refusal said a
                    # hop 'prints 8.2pt, under the 10.5pt an arc and its
                    # arrowhead need' and then named a stack drawing that
                    # same 8.2pt hop at the same width.
                    hl_j = max(JUMP_HEAD_MIN_PT / PX_TO_PT * k_s,
                               min(hl, span / SHORT_HOP, 0.5 * span - 0.3 * k_s))
                    hw_j = hw * hl_j / hl
                    # r2 (P2-L2-r2-02): the cap, then read the head the
                    # geometry actually draws (an arrival lift and a
                    # departure shift bend the end more than the plain
                    # quadratic) and lower it until the head is straight
                    h0 = min(h0, _turn_cap(span, k_s))
                    aim = 0.85 * TURN_TARGET_DEG
                    for _ in range(4):
                        t_ = max(_head_turn(*(lambda g: (g["keep"], g["tri"]))(
                            self._jump_geom(d, xa, xb, sd, h0,
                                            [j for j in jl if j["side"] == sd],
                                            e0, below0, hl_j, hw_j, k_s)), k_s)
                                 for sd in (pref, -pref))
                        if t_ <= aim or h0 <= 1.4 * k_s + 1e-9:
                            break
                        h0 = max(1.4 * k_s, h0 * math.tan(math.radians(aim)) /
                                 math.tan(math.radians(t_)))
                if span < 2.0 * hl_j - 1e-6:
                    # C4 r2: a one-tick jump at item width was all head (a 7px
                    # head on a 10px hop) and its label sat on its own head
                    # v6 P2 r1 (P2-L1-01): the fixes named are the ones that
                    # render -- 'use a shorter range' was said of a range
                    # that already fitted the walk, and nothing else
                    def _short_fix(d=d):
                        short = self._shorter_range()
                        return (" — use " + short + _WIDER_TRIED if short
                                else _WIDER_USE) + self._split_call(d, True)
                    errs.append(
                        "numberline: the jump %s -> %s prints %.1fpt long, under the "
                        "%.1fpt an arc and its smallest arrowhead need at this "
                        "width%s; never drop the jump" % (
                            _lab(d["a"]), _lab(d["b"]), span * PX_TO_PT / k_s,
                            2.0 * hl_j * PX_TO_PT / k_s,
                            self._later(_short_fix)))
                got, first, spare = None, None, None
                hs = []
                base_L = _nest(d)
                for L in list(range(base_L, 12)) + list(range(0, base_L)):
                    if L and h0 + L * step > ARC_RATIO * span + 1e-6:
                        continue
                    hs.append((L, h0 + L * step))
                # C4 r3: last, LOWER arcs nested under an overlapping jump (the
                # ARC_MAX clamp gives every long hop one height, so a hop inside
                # another could only cross it). Tried after every taller choice,
                # so a layout that had a place keeps it
                hl0 = h0 - 0.5 * step
                while hl0 >= min(ARC_MIN * k_s, ARC_RATIO * span) - 1e-6 and \
                        len(hs) < 20:
                    hs.append((-1, hl0))
                    hl0 -= 0.5 * step
                # v6 stage 1b r2: taller arcs than ARC_RATIO would allow, last of
                # all. Without them a jump that may NOT dive under a shorter one
                # (below) had nowhere left and was refused; with them it arches
                # over instead, which is what the ported rule asks for.
                for k in range(1, 7):
                    # C6 r6: only as tall as the sweep lets an arc stand
                    # (ARC_RATIO of its span, head included). Taller rungs were
                    # always refused off the file ('a teardrop reads as a
                    # loop'), so a labelled chain the engine could have
                    # refused with a fix was refused with none instead
                    if h0 + k * step > ARC_RATIO * (span + hl) + 0.3:
                        continue
                    if all(abs(h - (h0 + k * step)) > 1e-6 for _, h in hs):
                        hs.append((k, h0 + k * step))
                # v6 stage 1b r2: the outer/inner rule is a PREFERENCE, not a ban.
                # The first pass refuses to nest this jump under a SHORTER one
                # (the longer jump is the outer arc, for a partial overlap too --
                # sent under, it was drawn inside the shorter arc and crossed it
                # twice). The second pass lifts that, so a walk where every choice
                # collides still draws, as it did before, instead of being lost.
                # C6 r6: a first pass that also keeps arcs from CROSSING; the
                # two older passes follow unchanged, so a walk whose jumps
                # overlap on both sides (a crossing no height avoids) still
                # draws as it did
                # C7P-04: when a crossing is forced, a STEEP one first -- the
                # +10 of chain([-2, 6, -5, 5]) ran along +8 almost tangent at
                # both peaks, and the eye could not tell which curve went on
                # to which head
                sh = CROSS_MIN_DEG
                # C7P2-03: the fallback layout (avoid=False) first keeps a
                # jump from crossing the arc it lies inside ("nest"): the '-2'
                # of 2 -> 0 under 3 -> -4 took a steep crossing there, and the
                # sweep refused the layout the engine had chosen
                # stage-1 fix r1 (PR6): the same passes once more WITHOUT
                # the room reserved over each apex for a label. A labelled
                # walk was refused where the same walk without labels drew
                # (11 of 47 random block walks), so the easy way out was
                # deleting the displacements the item is about; the labels
                # are then placed along their arcs as always, and refused
                # there by name if none has a clear place
                base_passes = (((True, True), (True, sh), (False, sh),
                                (True, False), (False, False)) if avoid
                               else ((True, "nest"), (True, sh), (False, sh),
                                     (True, False), (False, False)))
                # (the passes that let a fan cross come after both)
                safe = [p_ for p_ in base_passes if p_[1] is not False]
                loose = [p_ for p_ in base_passes if p_[1] is False]
                passes = ([p_ + (True,) for p_ in safe] +
                          [p_ + (False,) for p_ in safe] +
                          [p_ + (True,) for p_ in loose] +
                          [p_ + (False,) for p_ in loose])
                # a vertical line has one side for decorations: its numbers
                # stand on the other. A WALK tries EVERY pass on its own side
                # before it looks at the other one (see `walk` above): the
                # side is the thing the reader follows, so it outranks how
                # strictly the arcs are kept apart.
                if self.orientation == "v":
                    groups = [(1,)]
                elif walk:
                    groups = [(pref,)]      # never the other side
                else:
                    groups = [(pref, -pref)]
                for sides_now, (strict, nocross, use_res) in \
                        [(g_, p_) for g_ in groups for p_ in passes]:
                    fans = nocross is not False     # O3-05, all but the last
                    nest_only = nocross == "nest"
                    if nest_only:
                        nocross = False
                    combos = [(L, h, sd) for L, h in hs for sd in sides_now]
                    for L, hgt, side in combos:
                        if True:
                            mine = [j for j in jl if j["side"] == side]
                            if L == 0 and any(j["x0"] < x1 - 0.5
                                              and x0 < j["x1"] - 0.5
                                              and not _inside(j, x0, x1)
                                              for j in mine):
                                continue
                            over = [j for j in mine if j["x0"] < x1 - 0.5
                                    and x0 < j["x1"] - 0.5]
                            if L < 0 and not over:
                                continue
                            if L < 0 and strict and \
                                    any((j["x1"] - j["x0"]) < (x1 - x0) - 0.5
                                        for j in over):
                                continue
                            g = self._jump_geom(d, xa, xb, side, hgt, mine, e0,
                                                below0, hl_j, hw_j, k_s, px)
                            g["hl"], g["hw"] = hl_j, hw_j
                            first = first or g
                            # C6 r6: in the strict pass an arc may not CROSS a
                            # placed arc either. The nesting rule only raised the
                            # longer arc's peak; 10 -> 8 under 11 -> -5 crossed
                            # near 11 (the long arc is low there), and three jumps
                            # crossed with the whole side below the line free.
                            if nocross is True and _arcs_cross(g, jl, gap):
                                continue
                            # C7P2-03: in the fallback layout a jump that LIES
                            # INSIDE a placed arc still may not cross it: the
                            # sweep refuses that ('the shorter jump nests under
                            # the longer'), and a steep crossing of the arc it
                            # nests in was the engine's own choice
                            if fans and _fan_cross(g, jl, gap):
                                continue
                            if nest_only and _arcs_cross(
                                    g, [j for j in jl if _inside(j, x0, x1)],
                                    gap):
                                continue
                            if nocross not in (True, False) and \
                                    _arcs_cross(g, jl, gap, shallow=nocross):
                                continue
                            if _jump_clear(g, jl, gap, use_res) and \
                                    _starts_clear(g, jl, 2 * gap):
                                # v6 P2 r2 (P2-L2-r2-02): a short hop raised
                                # to a level is tall again and its head turns
                                # off its shaft. Such a place is kept only as
                                # a spare -- taken when no clear place draws a
                                # straight arrow, never dropping the jump.
                                if hl_j != hl and not _arc_ok(g, hl_j, k_s):
                                    if spare is None and _head_turn(
                                            g["keep"], g["tri"],
                                            k_s) <= HEAD_TURN_DEG - 3.0:
                                        spare = g   # never worse than sweep
                                    continue
                                got = g
                                break
                        if got:
                            break
                    if got:
                        break
                got = got or spare
                if got is None and walk:
                    got = first or self._jump_geom(d, xa, xb, pref, h0, [], e0,
                                                   below0, hl_j, hw_j, k_s, px)
                    got["hl"], got["hw"] = hl_j, hw_j
                    errs.append(
                        "numberline: the hop %s -> %s carries the walk on and "
                        "cannot be drawn above the line beside the hop before "
                        "it, at any height. A walk keeps ONE side for its whole "
                        "length — flipped to the other side it prints under the "
                        "row of numbers, a detached arc the reader cannot follow "
                        "left to right. Split the walk%s%s; never drop the "
                        "jump and never drop its label"
                        % (_lab(d["a"]), _lab(d["b"]), self._split_advice(d),
                           _WIDER_TRIED))
                elif got is None:
                    got = first or self._jump_geom(d, xa, xb, pref, h0, [], e0,
                                                   below0, hl_j, hw_j, k_s, px)
                    got["hl"], got["hw"] = hl_j, hw_j
                    errs.append(
                        "numberline: the jump %s -> %s has no clear place — on both "
                        "sides and at every height its head meets another jump's arc "
                        "or head (jumps that land on one value from one side hide "
                        "each other). %s"
                        % (_lab(d["a"]), _lab(d["b"]),
                           ("A vertical line places its jumps on ONE side only (its "
                            "numbers own the other), so a walk that turns back has "
                            "no second side here:%s draw these jumps on vertical "
                            "number lines side by side"
                            % self._later(self._horizontal_tried)
                            if self.orientation == "v" else "Draw these jumps on "
                            "more than one number line")
                           + self._split_advice(d) + _WIDER_TRIED
                           # v6 P2 r2 (P2R2-02): the only jump refusal with no
                           # never-drop clause -- and the cheapest way out of
                           # it WORKS (the same walk renders once its +1/-2
                           # labels are deleted), which is the escape doctrine
                           # 4 forbids.
                           + "; never drop the jump, and never drop its label "
                             "— the displacements are what the item teaches"))
                got["d"] = d
                d["_side"] = got["side"]
                if avoid and _arcs_cross(got, jl, gap):
                    crossed[0] = True
                jl.append(got)
                prev = d
            return jl, errs, crossed[0]
        self._tick_px = abs(X(self.lo + self.tick) - X(self.lo))
        nested = self._nest_layout(order, k_s, px, hl, hw, e0, below0, gap)
        if nested is not None:
            jl, errs = nested, []
        else:
            jl, errs, crossed = solve(True)
            if crossed or errs:
                jl, errs, _ = solve(False)
        if errs:
            # the departure step bounded to a tick's tolerance left no place:
            # the old fixed step (3.3px, just past the incoming head) is tried
            # before the walk is refused
            self._shift_free = True
            try:
                jl2, errs2, crossed2 = solve(True)
                if crossed2 or errs2:
                    jl2, errs2, _ = solve(False)
            finally:
                self._shift_free = False
            if not errs2:
                jl, errs = jl2, errs2
        if not errs:
            # C7P-04: a crossing no side or height avoids is kept only when it
            # is steep. Two arcs running along each other (the +10 and +8 of
            # chain([-2, 6, -5, 5]) on a strip, near tangent at both peaks)
            # do not show which curve goes on to which head.
            for i, g in enumerate(jl):
                # v6 P2: ANY crossing (the sweep refuses them all now)
                if _arcs_meet(g, jl[:i], k_s):
                    d = g["d"]
                    errs.append(
                        "numberline: the jump %s -> %s crosses or runs along "
                        "another jump's arc — an arc drawn through another cannot "
                        "be followed to its head, and no side or "
                        "height of this layout avoids it. Draw the walk on "
                        "more than one number line%s; never drop a jump%s"
                        % (_lab(d["a"]), _lab(d["b"]), self._split_advice(d),
                           _WIDER_TRIED))
                    break
        if not errs:
            # O3-05: a fan whose shorter arc runs over the longer one
            for i, g in enumerate(jl):
                if _fan_cross(g, jl[:i], gap):
                    d = g["d"]
                    errs.append(
                        "numberline: the jump %s -> %s leaves %s the same way "
                        "as a longer jump and crosses it -- the longer jump is "
                        "the outer arc, and no height of this layout keeps the "
                        "shorter under it. Draw the walk on more than one "
                        "number line%s; never drop a jump"
                        % (_lab(d["a"]), _lab(d["b"]), _lab(d["a"]),
                           self._split_advice(d)))
                    break
        self._errs.extend(errs)
        # labels, after every arc is known
        boxes = []
        for g in jl:
            d = g["d"]
            if not d["label"]:
                continue
            t = svgcheck.true_minus(str(d["label"]))
            box = _jump_label(g, t, px, jl, boxes, k_s, e0, below0, self._dims)
            if box is None:
                self._errs.append(
                    "numberline: no clear place for the label %s of the jump "
                    "%s -> %s — along its arc every position meets another "
                    "jump's arc, head or label. Draw the crossing jumps on "
                    "more than one number line%s; never drop the jump, and "
                    "never drop its label%s" % (t, _lab(d["a"]), _lab(d["b"]),
                                 self._split_advice(d), _WIDER_TRIED))
                box = _grow(_bbox(g["keep"]), 0.0)
                box = (box[0], box[1] - 1.02 * px, box[0] + len(t) * 0.58 * px, box[1])
            g["box"] = box
            boxes.append(box)
        placed = {1: [], -1: []}
        for g in jl:
            E.arc(g["P0"], g["C"], g["P2"], g.get("hl", hl), g.get("hw", hw))
            top = g["top"]
            # the jump's full ink, head included, and an arrow gap: a span
            # beside a jump's head must not stand at the head's height
            ink = _bbox(g["keep"] + g["tri"])
            g["x0"], g["x1"] = ink[0] - 2 * gap, ink[2] + 2 * gap
            if g["box"] is not None:
                b = g["box"]
                t = svgcheck.true_minus(str(g["d"]["label"]))
                E.text_box(b, t, px)
                top = max(top, abs(b[1]), abs(b[3]))
            placed[g["side"]].append((g["x0"], g["x1"], top))
        return placed

    def _nest_geom(self, d, side, hgt, arrives, e0, below0, hl, hw, k_s, px,
                   res=True, departs=False):
        """v6 P2: one jump's arc for the nested layout (see _nest_layout)."""
        X = self._X
        xa, xb = X(d["a"]), X(d["b"])
        dirn = 1.0 if xb > xa else -1.0
        base = e0 if side == 1 else below0
        sg = -side
        if arrives:
            # another jump's head stands on this start: leave a little along
            # and low, under that head (Typst figlib: 3pt along, 1.5pt up)
            s = min((ARROW_GAP_PT + 1.0) / PX_TO_PT * k_s,
                    (TICK_TOL - 0.02) * self._tick_px)
            r = MARK_R_PT / PX_TO_PT * k_s
            h = max(0.45 * e0, math.sqrt(max(0.0, (r + 1.2 * k_s) ** 2 - s * s)))
            P0 = (xa + dirn * s, sg * (h if side == 1 else base))
        else:
            P0 = (xa, sg * base)
        # another jump leaves the point this one lands on: the tip stops a
        # little farther out, so that departure passes under the head (Typst
        # lands every tip at 6pt and leaves at 1.5-3pt). Under the line the
        # departure cannot drop into the numbers, so only the tip moves.
        lift = 0.0
        if departs:
            lift = (ARRIVE_LIFT_PT if side == 1 else ARRIVE_LIFT_BELOW_PT) \
                / PX_TO_PT * k_s
        P2 = (xb, sg * (base + lift))
        C = ((P0[0] + P2[0]) / 2.0, sg * (base + 2 * hgt))
        keep, tri = _arc_geom(P0, C, P2, hl, hw)
        far = max(abs(p[1]) for p in keep + tri)
        g = dict(side=side, a=d["a"], b=d["b"], P0=P0, C=C, P2=P2, keep=keep,
                 tri=tri, box=None, x0=min(xa, xb), x1=max(xa, xb), top=far,
                 base=base, res=None)
        if d["label"] and px and res:
            w, h_ = self._dims(svgcheck.true_minus(str(d["label"])), px)
            x = (P0[0] + P2[0]) / 2.0
            d0 = far + 2.0 * k_s
            g["res"] = (x - w / 2.0, -(d0 + h_), x + w / 2.0, -d0) if sg < 0 \
                else (x - w / 2.0, d0, x + w / 2.0, d0 + h_)
        return g

    def _nest_layout(self, order, k_s, px, hl, hw, e0, below0, gap):
        """v6 P2: every jump ABOVE the line when the walk fits there, nested.

        Side assignments are tried with as few jumps below as possible (none
        first). On each side the jumps are placed shortest first, each at the
        lowest height -- from its natural one up to what the sweep lets an arc
        stand (ARC_RATIO of its span) -- whose arc, head and label room keep
        clear of every jump already on that side (_nest_clear): so a longer
        jump arches OVER the shorter ones inside it, a return hop passes
        under the head it leaves from, and a fan opens out. None -> the older
        solver. Before, a walk that turned back was sent below by rule
        (pref = -prev side), into the row of numbers: '+5' over the line and
        its '-2' under it, where Typst drew both above."""
        n = len(order)
        if n == 0 or n > 10:
            return None
        sides = (1,) if self.orientation == "v" else (1, -1)
        import itertools
        combos = []
        idx = list(range(n))
        for k in range(0, n + 1 if len(sides) > 1 else 1):
            for below in itertools.combinations(reversed(idx), k):
                combos.append(set(below))
        # stage review: hop after hop the same way is a WALK, and a walk
        # keeps one side for its whole length. Split across the line, hop 2
        # printed under the row of numbers as a detached comma and the walk
        # could no longer be read left to right (chain([2, 3, 4, 5]) at item
        # width drew above / below / above). Side assignments that break a
        # walk are not tried at all; when none of the rest draws, the older
        # solver refuses by name instead.
        links = [(i, i + 1) for i in range(n - 1)
                 if float(order[i]["b"]) == float(order[i + 1]["a"]) and
                 (float(order[i]["b"]) - float(order[i]["a"])) *
                 (float(order[i + 1]["b"]) - float(order[i + 1]["a"])) > 0]
        if links and len(sides) > 1:
            walkers = set(i for ln in links for i in ln)
            combos = [c for c in combos if not (c & walkers)]
        step = (LEVEL_GAP + 5.0) * k_s
        labelled = any(d["label"] for d in order)
        # first with room reserved over each apex for its label; then (a
        # labelled walk only) without, the labels slid along their arcs as
        # always -- kept only if every label finds its place
        for res in ((True, False) if labelled else (True,)):
            tried = 0
            for below in combos:
                side_of = [(-1 if i in below else 1) for i in idx]
                if any(side_of[i] == side_of[j] and
                       _side_conflict(order[i], order[j])
                       for i in idx for j in idx if i < j):
                    continue
                tried += 1
                if tried > NEST_MAX_LAYOUTS:
                    break
                for flat in (1.0, 0.7, 0.5):
                    jl = self._nest_try(order, side_of, flat, step, k_s, px, hl,
                                        hw, e0, below0, gap, res)
                    if jl is None:
                        continue
                    if res or self._labels_fit(jl, px, k_s, e0, below0):
                        return jl
        return None

    def _labels_fit(self, jl, px, k_s, e0, below0):
        boxes = []
        for g in jl:
            if not g["d"]["label"]:
                continue
            t = svgcheck.true_minus(str(g["d"]["label"]))
            box = _jump_label(g, t, px, jl, boxes, k_s, e0, below0, self._dims)
            if box is None:
                return False
            boxes.append(box)
        return True

    def _nest_try(self, order, side_of, flat, step, k_s, px, hl, hw, e0,
                  below0, gap, res=True):
        X = self._X
        placed = []
        seq = sorted(range(len(order)),
                     key=lambda i: (abs(X(order[i]["b"]) - X(order[i]["a"])), i))
        out = [None] * len(order)
        for i in seq:
            d, side = order[i], side_of[i]
            arrives = any(side_of[j] == side and j != i and
                          float(order[j]["b"]) == float(d["a"])
                          for j in range(len(order)))
            departs = any(side_of[j] == side and j != i and
                          float(order[j]["a"]) == float(d["b"])
                          for j in range(len(order)))
            span = abs(X(d["b"]) - X(d["a"]))
            hl_j, hw_j = hl, hw
            if span < SHORT_HOP * hl - 1e-6:
                # a one-tick hop at item width: a smaller head (never under
                # JUMP_HEAD_MIN_PT, over svgcheck's 3.5pt arrowhead floor)
                # rather than no jump -- the refusal 'prints 10pt, under the
                # 10.5pt an arc and its head need' was most item walks
                # v6 P2 r1 (P2-L2-03): and on any hop under SHORT_HOP heads,
                # where a full head covered half the arc and read as a hook
                hl_j = max(JUMP_HEAD_MIN_PT / PX_TO_PT * k_s,
                           min(hl, span / SHORT_HOP, 0.5 * span - 0.3 * k_s))
                hw_j = hw * hl_j / hl
                if span < 2.0 * hl_j - 1e-6:
                    return None
            h0 = min(max(ARC_PREF * span, ARC_MIN * k_s), ARC_MAX * k_s,
                     ARC_RATIO * span)
            h0 = max(min(ARC_MIN * k_s, ARC_RATIO * span), flat * h0)
            if hl_j != hl:                           # r2: P2-L2-r2-02
                h0 = min(h0, _turn_cap(span, k_s))
            got = None
            mine = [g for g in placed if g["side"] == side]

            spare = [None]

            def at(h):
                g = self._nest_geom(d, side, h, arrives, e0, below0, hl_j,
                                    hw_j, k_s, px, res, departs)
                g["hl"], g["hw"] = hl_j, hw_j
                if not _arc_ok(g, hl_j):
                    return False                      # too tall: stop climbing
                clear = all(_nest_clear(g, j, gap) for j in mine)
                if not _arc_ok(g, hl_j, k_s):
                    # v6 P2 r2 (P2-L2-r2-02): the head turns off its shaft --
                    # a preference, not a wall. Keep climbing for a straight
                    # arrow and keep this one as a spare, so a short hop that
                    # can be drawn ONLY with a turned head is still drawn
                    # (never refuse a jump the engine can place).
                    if clear and spare[0] is None and _head_turn(
                            g["keep"], g["tri"], k_s) <= HEAD_TURN_DEG - 3.0:
                        spare[0] = g
                    return None
                return g if clear else None
            # the lowest clear height: coarse rungs first, then the quarter
            # rungs under the first clear one (the layout runs thousands of
            # these; a quarter-rung search alone made a refusal take seconds)
            hgt, prev = h0, None
            while True:
                r = at(hgt)
                if r is False:
                    break
                if r is not None:
                    got = r
                    if prev is not None:
                        h = prev + 0.25 * step
                        while h < hgt - 1e-6:
                            r2 = at(h)
                            if r2:
                                got = r2
                                break
                            h += 0.25 * step
                    break
                prev = hgt
                hgt += step
            if got is None and prev is not None:
                # the rung past the last coarse one may still stand
                h = prev + 0.25 * step
                while True:
                    r = at(h)
                    if r is False:
                        break
                    if r:
                        got = r
                        break
                    h += 0.25 * step
            got = got or spare[0]
            if got is None:
                return None
            got["d"] = d
            placed.append(got)
            out[i] = got
        for d, g in zip(order, out):
            d["_side"] = g["side"]
        return out

    def _jump_geom(self, d, xa, xb, side, hgt, mine, e0, below0, hl, hw, k_s,
                   px=None):
        dirn = 1.0 if xb > xa else -1.0
        base = e0 if side == 1 else below0
        shift = 0.0
        for j in mine:
            if float(j["b"]) == float(d["a"]):
                cap = 1e9 if getattr(self, "_shift_free", False) else \
                    (TICK_TOL - 0.02) * getattr(self, "_tick_px", 1e9)
                shift = dirn * min((ARROW_GAP_PT + 1.0) / PX_TO_PT * k_s, cap)
        sg = -side                          # svg y: above is negative
        P0 = (xa + shift, sg * base)
        P2 = (xb, sg * base)
        C = ((P0[0] + P2[0]) / 2.0, sg * (base + 2 * hgt))
        keep, tri = _arc_geom(P0, C, P2, hl, hw)
        # the arc's own ink, head included, farthest from the axis
        far = max(abs(p[1]) for p in keep + tri)
        g = dict(side=side, a=d["a"], b=d["b"], P0=P0, C=C, P2=P2, keep=keep,
                 tri=tri, box=None, x0=min(xa, xb), x1=max(xa, xb), top=far,
                 base=base, res=None)
        if d["label"] and px:
            # room for the label over the apex, reserved while arcs are chosen
            w, h = self._dims(svgcheck.true_minus(str(d["label"])), px)
            x = (P0[0] + P2[0]) / 2.0
            d0 = far + 2.0 * k_s
            g["res"] = (x - w / 2.0, -(d0 + h), x + w / 2.0, -d0) if sg < 0 else \
                (x - w / 2.0, d0, x + w / 2.0, d0 + h)
        return g

    def _layout_spans(self, E, X, k_s, px, hl, hw, e0, placed):
        gap = ARROW_GAP_PT / PX_TO_PT * k_s
        # arrow2 / double heads that meet at one value (symmetric(a): -a..0
        # and 0..a) stop short of it, half the arrow gap each. C4 r2: their
        # tips met exactly at 0, a bow-tie of touching heads
        headed = {}
        for d in self._decos:
            if d["kind"] == "arrow2":
                for e in (d["a"], d["b"]):
                    headed[float(e)] = headed.get(float(e), 0) + 1
            elif d["kind"] == "double":
                for e in (d["c"] - d["d"], d["c"] + d["d"]):
                    headed[float(e)] = headed.get(float(e), 0) + 1
        ins = lambda v: (gap / 2.0 + 0.4 * k_s) if headed.get(float(v), 0) > 1 else 0.0
        H, W2 = hl * 0.9, hw * 0.9
        need = 2 * H + gap + 2.0 * k_s
        for d in self._decos:
            if d["kind"] in ("bracket", "arrow2"):
                xa, xb = X(d["a"]), X(d["b"])
                lab_h = self._dims(str(d["label"]), px)[1] + 2.0 if d["label"] else 0.0
                # a span stands from base - 3 (a bracket's legs) to base + its
                # head's half-width (+ its label). C4 r2: stacked 3px apart,
                # the heads of two arrow2 spans over one stretch touched
                reach = W2 if d["kind"] == "arrow2" else 0.6
                start = e0 + 2.0
                if d["label"]:
                    lw = self._dims(svgcheck.true_minus(str(d["label"])), px)[0]
                    xm = (xa + xb) / 2.0
                    start = max(start, self._under_labels(X,
                        [(xm - lw / 2.0, xm + lw / 2.0)], k_s, px))
                base = self._base(placed[1], xa + 0.5, xb - 0.5, start, 3.0 * k_s)
                placed[1].append((xa + 0.5, xb - 0.5, base + reach + lab_h))
                y = -base
                if d["kind"] == "bracket":
                    E.line((xa, y + 3.0), (xa, y), 1.1)
                    E.line((xb, y + 3.0), (xb, y), 1.1)
                    E.line((xa, y), (xb, y), 1.1)
                else:
                    ta, tb = xa + ins(d["a"]), xb - ins(d["b"])
                    if tb - ta < need - 1e-6:
                        # C4 r2: two heads on a short span overlapped
                        self._errs.append(
                            "numberline.span %s..%s (kind='arrow2') prints "
                            "%.1fpt long, under the %.1fpt its two arrowheads "
                            "need — draw it with kind='bracket' (for symmetric: "
                            "symmetric(a, kind='bracket')), %sa shorter range"
                            % (_lab(d["a"]), _lab(d["b"]), (tb - ta) * PX_TO_PT / k_s,
                               need * PX_TO_PT / k_s, self._wider_tried(suffix=", or ")))
                        continue
                    E.line((ta + H, y), (tb - H, y), 1.1)
                    E.head((ta, y), (-1.0, 0.0), H, W2)
                    E.head((tb, y), (1.0, 0.0), H, W2)
                if d["label"]:
                    E.text_over((xa + xb) / 2.0, y - reach - 1.5 * k_s,
                                svgcheck.true_minus(str(d["label"])), px)
            elif d["kind"] == "double":
                xc = X(d["c"])
                xa, xb = X(d["c"] - d["d"]), X(d["c"] + d["d"])
                lab_h = self._dims(str(d["label"]), px)[1] + 2.0 if d["label"] else 0.0
                start = e0 + 2.0
                if d["label"]:
                    lw = self._dims(svgcheck.true_minus(str(d["label"])), px)[0]
                    start = max(start, self._under_labels(X,
                        [(xm - lw / 2.0, xm + lw / 2.0)
                         for xm in ((xa + xc) / 2.0, (xc + xb) / 2.0)], k_s, px))
                base = self._base(placed[1], xa, xb, start, 3.0 * k_s)
                placed[1].append((xa, xb, base + W2 + lab_h))
                y = -base
                if (xc - xa) - ins(d["c"] - d["d"]) < H + 2.0 * k_s:
                    self._errs.append(
                        "numberline.double_arrow(%s, %s) prints each half "
                        "%.1fpt long, too short for its arrowhead — a wider "
                        "placement (tier=) or a shorter range"
                        % (_lab(d["c"]), _lab(d["d"]), (xc - xa) * PX_TO_PT / k_s))
                    continue
                # no stop at the centre: with it, the two heads' bases and the
                # stop read as an axis of three ticks and '150' as its numbers
                # v6 open issues (C4r3v-02): ... so a centre BETWEEN ticks had
                # nothing on it -- two collinear halves read as one arrow from
                # c-d to c+d with its label printed twice. Such a centre is
                # marked by a point, which the author names.
                cv = d["c"]
                on_tick = isinstance(cv, F) and (cv / self.tick).denominator == 1
                if not on_tick and not any(
                        abs(float(pp["v"]) - float(cv)) < 1e-9 for pp in self._points):
                    self._errs.append(
                        "numberline.double_arrow(%s, %s): its centre %s is not a "
                        "tick and nothing marks it — the two halves read as one "
                        "arrow from %s to %s. Mark the centre with a point: "
                        ".point(%s, 'M'%s) (any letter); never drop the arrow"
                        % (_lab(cv), _lab(d["d"]), _lab(cv), _lab(cv - d["d"]),
                           _lab(cv + d["d"]), _pyv(cv),
                           ", between=True" if d.get("between") else ""))
                    continue
                for xe, dx, v in ((xa, -1.0, d["c"] - d["d"]), (xb, 1.0, d["c"] + d["d"])):
                    xt = xe - dx * ins(v)
                    E.line((xc, y), (xt - dx * H, y), 1.1)
                    E.head((xt, y), (dx, 0.0), H, W2)
                if d["label"]:
                    lw = self._dims(svgcheck.true_minus(str(d["label"])), px)[0]
                    if (xb - xa) / 2.0 - lw < 0.6 * px - 1e-6:
                        # C4 r3: the two half labels met ('0.5' '0.5' read as
                        # one word) and svgcheck refused it naming no fix
                        self._errs.append(
                            "numberline.double_arrow(%s, %s): its two labels "
                            "print %.1fpt apart, under 0.6 em — they read as one "
                            "word. Use %sa shorter range; never drop the label"
                            % (_lab(d["c"]), _lab(d["d"]),
                               max(0.0, (xb - xa) / 2.0 - lw) * PX_TO_PT / k_s,
                               self._wider_tried(suffix=" or ")))
                    for xm in ((xa + xc) / 2.0, (xc + xb) / 2.0):
                        E.text_over(xm, y - W2 - 1.5 * k_s,
                                    svgcheck.true_minus(str(d["label"])), px)

    @staticmethod
    def _letter_floor(style, r, k_s):
        """P2-02: how high over the line a point's letter box starts. A
        triangle's apex stands r / cos 30 over the line, not r, and an
        outlined marker (open, tri, square) has half its 1.2-unit rim outside
        r: from r + 1.5 its letter printed 0.68-0.89pt from the outline
        (svgcheck.marker_clearance wants MARKER_CLEAR_PT). A filled dot keeps
        r + 1.5."""
        top = r / math.cos(math.radians(30.0)) if style == "tri" else r
        return top + (2.2 if style in ("open", "tri", "square") else 1.5) * k_s

    def _under_labels(self, X, cols, k_s, px):
        """C7P-03: the height a carrier must stand at so the letters and value
        labels of the points under its label's columns `cols` ([(x0, x1)])
        print BELOW it. Stacked over the label instead ('M' over the '6' of
        span(0, 6) with its midpoint, 'A' over the '4' of symmetric(4)), the
        pair read as one: M = 6. 0.0 when no point stands in a column."""
        lpx = self._letter_px()
        r = MARK_R_PT / PX_TO_PT * k_s
        if self.legacy:
            r = max(r, 3.0)
        need = 0.0
        for p in self._points:
            items = []
            if p["name"]:
                items.append(self._dims(svgcheck.true_minus(str(p["name"])), lpx))
            vl = p["value_label"]
            if vl and vl is not True:
                if vl[0] == "text" or self.orientation == "v":
                    t = vl[1] if vl[0] == "text" else \
                        self._label_runs(vl[1], vl[2])[0][0][0]
                    items.append(self._dims(t, px))
                else:
                    runs, vin, W, depth = self._label_runs(vl[1], vl[2])
                    items.append((W, depth + 0.1 * px))
            if not items:
                continue
            x = X(p["v"])
            w = max(it[0] for it in items)

            if not any(x + w / 2.0 > a - 1.0 and x - w / 2.0 < b + 1.0
                       for a, b in cols):
                continue
            need = max(need, self._letter_floor(p["style"], r, k_s)
                       + sum(it[1] + 1.0 for it in items)
                       + 3.5 * k_s)
        return need

    def _tick_label_x(self, x, runs, px):
        """Where a tick number is centred: ON its tick. (A test monkeypatches
        this to prove the sweep catches a slide.)"""
        return x

    @staticmethod
    def _base(placed, x0, x1, start, below=0.0):
        """The lowest base clear of every placed item over [x0, x1]; `below`
        is how far the new item reaches under its base."""
        base = start
        for a, b, top in placed:
            if a < x1 - 0.5 and x0 < b - 0.5:
                base = max(base, top + LEVEL_GAP + below)
        return base

    def _separation(self, marks, X, r, ticks, k_s):
        err = self._errs.append
        styles = {}
        for v, st in marks:
            styles.setdefault(float(v), set()).add(st)
        for fv, sts in styles.items():
            if len(sts) > 1:
                err("numberline: %s at %s — one marker per value (the later one "
                    "hides the first); keep the one the item means, or draw the "
                    "other on its own line" % (" and ".join(sorted(sts)),
                                               ("%g" % fv).replace("-", MINUS)))
        vals = sorted(set((float(v), v) for v, st in marks), key=lambda t: t[0])
        need = 2 * r + POINT_GAP_PT / PX_TO_PT * k_s
        for (fa, a), (fb, b) in zip(vals, vals[1:]):
            if X(b) - X(a) < need - 1e-6 and fa != fb:
                err("numberline: the points at %s and %s print %.1fpt apart, "
                    "under 2r + %.1fpt = %.1fpt — they read as one blob. Draw the "
                    "line wider (tier='block'/'strip'), use a shorter range or a "
                    "finer tick; never move or drop a point"
                    % (_lab(a), _lab(b), (X(b) - X(a)) * PX_TO_PT / k_s,
                       POINT_GAP_PT, need * PX_TO_PT / k_s))
        clear = r + 0.5 / PX_TO_PT * k_s
        # C4 r3: the fix that works for real data -- a coarser tick, computed
        # here -- is named first, so the easy escape is not rounding -395 to
        # -400. Every tick counts, numbered or not: svgcheck's independent
        # dot sweep (E29) refuses a disc half over ANY tick (-7.8 over the
        # unnumbered -7.5 of a tick-2.5 line), and its message names no tick
        for fv, v in vals:
            for t in ticks:
                if float(t) != fv and abs(X(v) - X(t)) < clear:
                    unit = X(F(1)) - X(F(0))
                    c = self._coarser_tick(clear / unit)
                    # v6 open issues: 'a shorter range' is named only when a
                    # range of at least two ticks prints the value clear of
                    # the tick (the unit grows as the range shrinks)
                    dist = abs(fv - float(t))
                    room = dist * unit * float(self.hi - self.lo) / clear
                    # the strip clears every value from every other tick?
                    u_s = 0.95 * (TIERS["strip"] - 60.0) / float(self.hi - self.lo)
                    strip = self.tier != "strip" and self.unit is None and \
                        (self.width or 0) < TIERS["strip"] and all(
                            abs(X(w) - X(tt)) / unit * u_s >= clear
                            for _, w in vals for tt in ticks if float(tt) != float(w))
                    fixes = (["use a coarser tick (tick=%s), which no value stands "
                              "near" % _pyn(c)] if c is not None else []) + \
                        (["a wider placement (tier='strip')"] if strip else []) + \
                        (["a shorter range around the values (at most %g long)"
                          % (math.floor(room * 10) / 10.0)]
                         if room >= 2 * self.tick else
                         ["no shorter range helps: at this placement %s stands "
                          "too close to the tick of %s (%s away) on every range "
                          "of at least two ticks" % (_lab(v), _num(t),
                                                     _read(dist, self.tick))]) + \
                        [self._small_fix(v)]
                    err("numberline: the point at %s prints within r of the %s "
                        "tick%s — at this unit it reads as %s. Fix: %s; never "
                        "round the value or draw it silently"
                        % (_lab(v), _num(t), "" if t in self._labset else
                           " (unnumbered)", _num(t), "; ".join(fixes)))
                    return

    def _coarser_tick(self, clear_v, min_tick=0):
        """The smallest nicer tick (x2, x2.5, x5, x10 ... of this one) on
        which every exact value still stands on a tick and every estimate
        stands `clear_v` (value units) from every tick, with >= 4 ticks on
        the line; None when there is none."""
        got = self._coarser_ticks(clear_v, min_tick)[0]
        return got[0] if got else None

    def _tick_that_renders(self, cands):
        """O3-03: of the candidate ticks (smallest first), the one on which
        this line, as called, RENDERS -- preferring one whose numbering
        reaches both ends. The floor refusal named the tick _coarser_tick
        picked, which cleared the minor-tick floor and was then refused by
        the numbers' density rule at side/strip/block; at item it numbered
        0..30 as 0, 4, ..., 28. None when no candidate renders."""
        if getattr(self, "_trial", False) or not hasattr(self, "_ctor"):
            return cands[0] if cands else None
        first = None
        for c in cands[:8]:
            try:
                trial = NL(**dict(self._ctor, tick=c, register=False))
                trial._trial = True
                trial.render()
            except AssertionError:
                continue
            lab = set(getattr(trial, "labelled", ()))
            if self.lo in lab and self.hi in lab:
                return c
            first = first if first is not None else c
        return first

    def _coarser_ticks(self, clear_v, min_tick=0):
        """(ticks, stranded): every nicer tick _coarser_tick would accept,
        smallest first, and -- when some tick clears `min_tick` and keeps 4
        ticks but strands an exact value -- those values (C7P2-06: the floor
        refusal then said 'fewer than 4 ticks' when 5 was simply off a tick
        of 2)."""
        exact, est = [], []
        for p in self._points:
            (est if p["between"] else exact).append(p["v"])
        for d in self._decos:
            vs = [d["a"], d["b"]] if "a" in d else [d["c"] - d["d"], d["c"] + d["d"], d["c"]]
            (est if d.get("between") else exact).extend(vs)
        for st in self.sets:
            (est if st.get("between") else exact).extend(st["S"].ends())
        mults = [2, F(5, 2), 5, 10, 20, 25, 50, 100]
        whole = (1 / self.tick).denominator == 1 and self.tick < 1
        if whole:
            # v6 open issues (C4r3v-01): on a tick of 1/n every whole number is
            # a tick, and x5/2 of 1/3 or 1/6 offered 5/6 or 5/12, on which they
            # are not. A tick of 1/n grows through the unit fractions that
            # divide it (1/6 -> 1/3, 1/2), then whole ticks.
            n = (1 / self.tick).numerator
            mults = [F(n, d) for d in range(n - 1, 0, -1) if n % d == 0] + \
                [F(n) * k for k in (2, 5, 10, 20, 25, 50, 100)]
        found, stranded = [], []
        for m in mults:
            c = self.tick * m
            if whole and (1 / c).denominator != 1 and c.denominator != 1:
                continue
            if c < min_tick:
                continue
            if (self.hi - self.lo) / c < 4 or \
                    (self.fmt == "int" and c.denominator != 1):
                continue
            off = [v for v in exact if isinstance(v, F) and
                   (v / c).denominator != 1]
            if off:
                stranded.append((c, sorted(set(off))))
                continue
            ok = True
            for v in est:
                fv = float(v)
                k = math.floor(fv / float(c))
                if min(abs(fv - k * float(c)), abs(fv - (k + 1) * float(c))) < clear_v:
                    ok = False
                    break
            if ok:
                found.append(c)
        return found, (stranded[0] if stranded and not found else None)


def _cut_span(y0, y1, boxes, keep=0.0, at=None):
    """The ONE stretch of y0..y1 a reference line is drawn as: from where it
    starts, out to the first label standing in its column on either side.

    v6 stage 1b r2 (the author's rule 1, ported to number lines). This used to
    cut the line behind EVERY box in the column and throw away any piece
    shorter than 2 units: one reference came out as three dashed stubs with
    the middle one gone, and nothing could see it -- svgcheck.lost_ink skips
    dashed strokes by design, and numberline emits the pieces rather than
    cutting them out of a whole, so there was no length to compare. A stroke
    is never cut or broken; a guide that ENDS at the letter it points to loses
    nothing, so the line is one piece and the labels sit at its ends.

    `at` is where the line belongs (its point, y = 0 in the scale frame); the
    piece kept is the one holding it, else the longest."""
    gaps = sorted((b[1] - 1.0, b[3] + 1.0) for b in boxes
                  if b[3] + 1.0 > y0 and b[1] - 1.0 < y1)
    out, cur = [], y0
    for a, b in gaps:
        if a > cur + keep:
            out.append((cur, a))
        cur = max(cur, b)
    if y1 > cur + keep:
        out.append((cur, y1))
    if len(out) <= 1:
        return out
    if at is not None:
        own = [p for p in out if p[0] - 1e-9 <= at <= p[1] + 1e-9]
        if own:
            return own[:1]
    return [max(out, key=lambda p: p[1] - p[0])]


def _lab(v):
    return _num(v) if isinstance(v, F) else ("%g" % v).replace("-", MINUS)


def _read(v, step):
    """A value READ BACK off a drawing, printed without float noise: rounded
    to a thousandth of the step it was measured in. C5 r2: a '0' misprinted on
    another line's tick was reported as standing 'on the tick of −1.77636e−15',
    where the reader had to see 0."""
    try:
        if step and step > 0:
            q = 10.0 ** max(0, 3 - int(math.floor(math.log10(abs(step)))))
            v = round(v * q) / q
    except (ValueError, OverflowError):
        pass
    if v == 0:
        v = 0.0
    return ("%g" % v).replace("-", MINUS)


_SPLITTING = []           # v6 P2 r1: a split call is being looked for
_JUMP_CALLS = ("jump", "chain", "repeat")
_RECORDED = ("point", "points", "test_markers", "span", "symmetric",
             "double_arrow", "midpoint", "jump", "chain", "repeat",
             "from_inequality", "interval", "ray", "union", "intersect",
             "all_reals", "empty", "integers_in", "reference",
             "bars_from_zero")


def _recorded(name, fn):
    """v6 P2 r1 (LP2-01): remember each decoration call made on a line (the
    outermost only: chain() calls jump()), so a split names the whole line."""
    def w(self, *a, **k):
        top = not self.__dict__.get("_rec_busy")
        self.__dict__["_rec_busy"] = True
        try:
            out = fn(self, *a, **k)
        finally:
            if top:
                self.__dict__["_rec_busy"] = False
        if top and "_calls" in self.__dict__:
            self._calls.append((name, a, k))
        return out
    w.__name__, w.__doc__ = fn.__name__, fn.__doc__
    return w


for _n in _RECORDED:
    setattr(NL, _n, _recorded(_n, getattr(NL, _n)))


def _nl_defaults():
    import inspect
    return dict((k, v.default) for k, v in
                inspect.signature(NL.__init__).parameters.items()
                if v.default is not inspect.Parameter.empty)


_NL_DEFAULTS = _nl_defaults()


def _same(a, b):
    try:
        return type(a) is type(b) and a == b or \
            (isinstance(a, (tuple, list)) and isinstance(b, (tuple, list))
             and list(a) == list(b))
    except Exception:
        return False


def _src(v):
    """A call argument as Python source; None when it has none."""
    if v is None or isinstance(v, bool):
        return repr(v)
    if isinstance(v, (int, F)):
        return _pyn(v)
    if isinstance(v, float):
        return repr(v)
    if isinstance(v, str):
        return repr(v)
    if isinstance(v, (list, tuple)):
        inner = [_src(x) for x in v]
        if any(x is None for x in inner):
            return None
        if isinstance(v, list):
            return "[%s]" % ", ".join(inner)
        return "(%s)" % (inner[0] + "," if len(inner) == 1 else ", ".join(inner))
    return None


def _pyv(v):
    """_pyn for a value that may be a float estimate (quoted as typed)."""
    if isinstance(v, float):
        return repr(v)
    return _pyn(v)


def _pyn(v):
    """A value as Python source a message can quote for pasting: ASCII
    minus, a decimal when it is exact, F(n, d) otherwise (C4r3v-01/08: a
    rounded '0.666667' and a U+2212 in a quoted call both broke the call)."""
    v = F(v)
    if v.denominator == 1:
        return str(v.numerator)
    if _finite_dec(v):
        return ("%.6f" % float(v)).rstrip("0").rstrip(".")
    return "F(%d, %d)" % (v.numerator, v.denominator)


class _Canvas(object):
    """Elements in figure units, with the ink boxes letters must avoid.

    C5: every layout is computed in the SCALE FRAME -- x along the scale, y
    across it, decorations at y < 0 and the row of numbers at y > 0. A
    horizontal line prints the frame as it is. A vertical line (`vertical`)
    prints it turned: (x, y) -> (-y, -x), so the scale runs up, decorations
    stand right of the axis and numbers left of it. Text stays upright, so in
    the frame a text box of a vertical line is 1.02 em along the scale and
    its advance across it (`dims`)."""

    def __init__(self, vertical=False):
        # v6.5 (DELIVERABLE_SPEC 1-2): this canvas writes its own SVG, so it
        # feeds export.Objects itself -- with the SAME coordinates it draws
        # from, which is what makes `svg_xy` true to the pixel. A number line
        # names its objects by the VALUE they sit on (`pt-3`, `tick-m1d5`,
        # `lbl-2`), the only name a number line has.
        self.ex = export.Objects()
        self.oids = {}           # element index -> id
        self.els = []            # (z, svg-format, points, box)
        self.segs = []           # (a, b, half width)
        self.boxes = []          # text boxes (x0, y0, x1, y1)
        self.vertical = vertical
        self.ox = self.oy = 0.0

    def dims(self, t, px):
        """(along the scale, across it) of a text box, in the frame."""
        w, h = len(t) * 0.58 * px, 1.02 * px
        return (h, w) if self.vertical else (w, h)

    def text_box(self, box, t, px, ex=None):
        """A text filling the frame box `box` (as `dims` sized it)."""
        cx = (box[0] + box[2]) / 2.0
        if not self.vertical:
            self.text(cx, box[3] - 0.24 * px, t, px, ex=ex)
            return
        cy = (box[1] + box[3]) / 2.0
        fw, fh = self.dims(t, px)
        b = (cx - fw / 2.0, cy - fh / 2.0, cx + fw / 2.0, cy + fh / 2.0)
        self.boxes.append(b)
        self._add(3, ('<text x="%.2f" y="%.2f" font-family="' + FACE +
                      '" font-size="%.2f" text-anchor="middle" fill="' + INK +
                      '">%s</text>', [(cx, cy)], (px, t, "v")),
                  [(b[0], b[1]), (b[2], b[3])],
                  # an upright text on a turned frame is moved 0.27 em DOWN
                  # in the emitted frame (see emit); the export claims where
                  # the glyph really lands, so the id and the claim agree
                  oid=self._ex(ex, [(cx - 0.27 * px, cy)], text=t))

    def text_over(self, cx, bottom, t, px):
        """A text centred on `cx` whose frame box ends at `bottom` (y < 0:
        the side of the decorations). Returns its box."""
        fw, fh = self.dims(t, px)
        box = (cx - fw / 2.0, bottom - fh, cx + fw / 2.0, bottom)
        self.text_box(box, t, px)
        return box

    def shade(self, x0, y0, x1, y1, fill=SHADE_FILL):
        """A light band behind the strokes (a zoom's segment): not ink."""
        P = [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]
        d = "M" + " L".join("%.2f,%.2f" % p for p in P) + " Z"
        self._add(0, ('<path d="%s" fill="' + fill + '" stroke="none"/>', None,
                      (d,)), P)

    def bar(self, x0, y0, x1, y1):
        """A distance bar: a light fill with a dark outline (ink)."""
        P = [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]
        d = "M" + " L".join("%.2f,%.2f" % p for p in P) + " Z"
        self._add(1, ('<path d="%s" fill="' + BAR_FILL + '" stroke="' + INK +
                      '" stroke-width="0.90"/>', None, (d,)), P, 0.45)
        for a, b in zip(P, P[1:] + P[:1]):
            self.segs.append((a, b, 0.45))

    def _ex(self, spec, pts, role=None, text=None):
        """Register what is being drawn and return the id it will carry.
        v6.7-noam r1 (NL-LABEL-NO-TEXT): a label carries the `text` it
        prints, as every other builder's label does."""
        if not spec:
            return None
        kind, name = spec
        meta = {"text": text} if kind == "label" and text is not None \
            else None
        self.ex.add(kind, pts, name=name, role=role, meta=meta)
        return export.make_id(kind, name)

    def _add(self, z, fmt, pts, extra=0.0, oid=None):
        if oid:
            self.oids[len(self.els)] = oid
        xs = [p[0] for p in pts]
        ys = [p[1] for p in pts]
        self.els.append((z, len(self.els), fmt, pts,
                         (min(xs) - extra, min(ys) - extra,
                          max(xs) + extra, max(ys) + extra)))

    def line(self, a, b, w, cap="round", kind=None, dash=None, ex=None):
        self._add(1, ('<line x1="%.2f" y1="%.2f" x2="%.2f" y2="%.2f" stroke="'
                      + INK + '" stroke-width="%.2f" stroke-linecap="' + cap +
                      '"' + (' stroke-dasharray="%s"' % dash if dash else "") +
                      '/>', [a, b], (w,)), [a, b], w / 2.0,
                  oid=self._ex(ex, [a, b]))
        self.segs.append((a, b, w / 2.0))

    def reserve(self, a, b, w):
        """Ink a label must avoid, drawn later (a reference line is cut
        around the labels, so its pieces are only known at the end)."""
        self.segs.append((a, b, w / 2.0))

    def knock(self, a, b, w):
        self._add(2, ('<line x1="%.2f" y1="%.2f" x2="%.2f" y2="%.2f" '
                      'stroke="#fff" stroke-width="%.2f"/>', [a, b], (w,)),
                  [a, b])

    def head(self, tip, u, hl, hw):
        bx, by = tip[0] - u[0] * hl, tip[1] - u[1] * hl
        n = (-u[1], u[0])
        P = [tip, (bx + n[0] * hw, by + n[1] * hw), (bx - n[0] * hw, by - n[1] * hw)]
        self._add(2, ('<path d="M%.2f,%.2f L%.2f,%.2f L%.2f,%.2f Z" fill="' + INK +
                      '" stroke="none"/>', P, ()), P)
        for a, b in zip(P, P[1:] + P[:1]):
            self.segs.append((a, b, 0.3))

    def arc(self, P0, C, P2, hl, hw):
        keep, tri = _arc_geom(P0, C, P2, hl, hw)
        d = "M" + " L".join("%.2f,%.2f" % p for p in keep)
        self._add(1, ('<path d="%s" fill="none" stroke="' + INK +
                      '" stroke-width="1.20" stroke-linecap="round"/>', None,
                      (d,)), keep, 0.6)
        for a, b in zip(keep, keep[1:]):
            self.segs.append((a, b, 0.6))
        tip = tri[0]
        u = ((tip[0] - keep[-1][0]) / hl, (tip[1] - keep[-1][1]) / hl)
        self.head(tip, u, hl, hw)

    def text(self, x, y, t, px, ex=None):
        w = len(t) * 0.58 * px
        box = (x - w / 2.0, y - 0.78 * px, x + w / 2.0, y + 0.24 * px)
        self.boxes.append(box)
        self._add(3, ('<text x="%.2f" y="%.2f" font-family="' + FACE +
                      '" font-size="%.2f" text-anchor="middle" fill="' + INK +
                      '">%s</text>', [(x, y)], (px, t)),
                  [(box[0], box[1]), (box[2], box[3])],
                  oid=self._ex(ex, [(x, y)], text=t))

    def marker(self, c, style, r, ex=None):
        x, y = c
        oid = self._ex(ex, [c], role="marker")
        if style == "cross" and oid:
            # the two arms are drawn, the POINT is the centre: the id goes on
            # an anchor rather than on an arm whose ends are not the point
            oid = None
        if style == "filled":
            fmt = '<circle cx="%.2f" cy="%.2f" r="%.2f" fill="' + INK + \
                  '" stroke="none"/>'
            self._add(4, (fmt, [c], (r,)), [(x - r, y - r), (x + r, y + r)],
                      oid=oid)
        elif style == "open":
            fmt = '<circle cx="%.2f" cy="%.2f" r="%.2f" fill="#fff" stroke="' + \
                  INK + '" stroke-width="1.20"/>'
            # the ring's OUTER half-extent is exactly MARK_R_PT -- the plane's
            # open-marker size, and svgcheck's readability floor (2.4pt). It
            # used to be 0.95 x r, which at the house radius printed 2.28pt
            # and was refused.
            self._add(4, (fmt, [c], (r,)), [(x - r, y - r), (x + r, y + r)],
                      oid=oid)
        elif style in ("tri", "square"):
            if style == "tri":
                # centroid on the value (figure_family keys a marker by its
                # vertices' mean), as figkit.Figure.marker draws it
                R = r / math.cos(math.radians(30.0))
                P = [(x + R * math.cos(math.radians(t)),
                      y + R * math.sin(math.radians(t))) for t in (-90.0, 30.0, 150.0)]
            else:
                P = [(x - r, y - r), (x + r, y - r), (x + r, y + r), (x - r, y + r)]
            d = "M" + " L".join("%.2f,%.2f" % p for p in P) + " Z"
            self._add(4, ('<path d="%s" fill="#fff" stroke="' + INK +
                          '" stroke-width="1.20" stroke-linejoin="round"/>',
                          None, (d,)), P, oid=oid)
        elif style == "cross":
            # v6 P2 r2 (P2-L2-r2-01): one family. The cross used to keep a
            # 3.5pt half-extent and a 1.5px stroke -- 7.08pt across and 25%
            # heavier than every other marker, so a line mixing styles printed
            # two weights (the r1 reason for keeping it, that a dot-sized cross
            # was read as ticks by figure_family, was a bug in the family key,
            # now fixed: a tick meets an arm at 45 degrees, not square). It is
            # now the square's box exactly: half-extent r, stroke 1.20px.
            q = r
            for i_, (a, b) in enumerate((((x - q, y - q), (x + q, y + q)),
                                         ((x - q, y + q), (x + q, y - q)))):
                self._add(4, ('<line x1="%.2f" y1="%.2f" x2="%.2f" y2="%.2f" '
                              'stroke="' + INK + '" stroke-width="%.2f" '
                              'stroke-linecap="round"/>', [a, b], (1.20,)),
                          [a, b], oid=oid if i_ == 0 else None)
        self.boxes.append((x - r - 0.6, y - r - 0.6, x + r + 0.6, y + r + 0.6))

    def place_label(self, x, t, px, y_min, ex=None):
        """A letter over its point: the nearest height above whose box meets
        no ink and stands 0.6 em clear of every other label on its band.
        (C4 r2: the 'below the row of numbers' fallback could never be
        reached -- a clear height above always exists -- and is gone; the
        sweep refuses any label in the row.) Returns the box's height above
        the axis."""
        w, h = self.dims(t, px)
        for step in range(0, 200):
            d = y_min + step * 1.0
            y1 = -d
            y0 = y1 - h
            if self._clear((x - w / 2.0, y0, x + w / 2.0, y1), px):
                self.text_box((x - w / 2.0, y0, x + w / 2.0, y1), t, px,
                              ex=ex)
                return d + h
        raise AssertionError("numberline: no room for the label %r" % t)

    def place_group(self, x, runs, vin, W, depth, px, y_min):
        """A number drawn like a tick number (a stacked fraction with its bar
        and sign strokes) over its point, placed like a letter."""
        for step in range(0, 200):
            d = y_min + step * 1.0
            top = -d - depth
            box = (x - W / 2.0, top - 0.1 * px, x + W / 2.0, -d)
            if self._clear(box, px):
                _emit_group(self, x, top, runs, vin)
                return d + depth + 0.1 * px
        raise AssertionError("numberline: no room for a value label")

    def _clear(self, box, px):
        pad = 1.0
        for a, b, hw in self.segs:
            if _seg_box(a, b, (box[0] - pad - hw, box[1] - pad - hw,
                               box[2] + pad + hw, box[3] + pad + hw)):
                return False
        for b in self.boxes:
            if self.vertical:
                # printed side by side = frame boxes sharing an x band
                hov = min(box[2], b[2]) - max(box[0], b[0])
                m = 0.6 * px if hov > 0 else pad
                if box[0] < b[2] + pad and b[0] < box[2] + pad and \
                        box[1] < b[3] + m and b[1] < box[3] + m:
                    return False
                continue
            vov = min(box[3], b[3]) - max(box[1], b[1])
            m = 0.6 * px if vov > 0 else pad
            if box[0] < b[2] + m and b[0] < box[2] + m and \
                    box[1] < b[3] + pad and b[1] < box[3] + pad:
                return False
        return True

    def emit(self, margin):
        T = (lambda p: (-p[1], -p[0])) if self.vertical else (lambda p: p)
        bx = [e[4] for e in self.els]
        if self.vertical:
            bx = [(-b[3], -b[2], -b[1], -b[0]) for b in bx]
        xs0 = min(b[0] for b in bx)
        ys0 = min(b[1] for b in bx)
        xs1 = max(b[2] for b in bx)
        ys1 = max(b[3] for b in bx)
        ox, oy = margin - xs0, margin - ys0
        self.ox, self.oy = ox, oy

        def at(p):
            q = T(p)
            return q[0] + ox, q[1] + oy
        self.at = at            # v6.5: the frame the export converts with
        out = []

        def with_id(el, i):
            oid = self.oids.get(i)
            if not oid:
                return el
            cut = el.rfind("/>")
            if cut < 0:
                cut = el.find(">")
                return el[:cut] + ' id="%s"' % oid + el[cut:]
            return el[:cut] + ' id="%s"' % oid + el[cut:]

        # C6 r6: the dark strokes this canvas was given, in the emitted frame,
        # for svgcheck.assert_draws (the lost-ink gate's clause (b))
        self.geometry = []
        for z, i, (fmt, pts, extra), P, box in sorted(self.els, key=lambda e: (e[0], e[1])):
            if fmt.startswith("<line") and 'stroke="' + INK in fmt and pts:
                self.geometry.append((at(pts[0]), at(pts[1])))
            elif pts is None and 'fill="none" stroke="' + INK in fmt and P:
                q = [at(p) for p in P]
                self.geometry += list(zip(q, q[1:]))
            if pts is None:
                d = extra[0]
                d = re.sub(r"(-?\d+\.\d+),(-?\d+\.\d+)",
                           lambda m: "%.2f,%.2f" % at((float(m.group(1)),
                                                       float(m.group(2)))), d)
                out.append(with_id(fmt % d, i))
            elif fmt.startswith("<line"):
                (a, b), (w,) = pts, extra
                out.append(with_id(fmt % (at(a) + at(b) + (w,)), i))
            elif fmt.startswith("<circle"):
                out.append(with_id(fmt % (at(pts[0]) + (extra[0],)), i))
            elif fmt.startswith("<text"):
                c = at(pts[0])
                if len(extra) > 2:           # an upright text on a turned frame
                    c = (c[0], c[1] + 0.27 * extra[0])
                out.append(with_id(fmt % (c[0], c[1], extra[0], extra[1]), i))
            else:
                flat = []
                for p in pts:
                    flat += list(at(p))
                out.append(with_id(fmt % tuple(flat), i))
        return out, (0.0, 0.0, xs1 - xs0 + 2 * margin, ys1 - ys0 + 2 * margin)


def _idvalue(name):
    """the value an _idname() stands for ('m1d5' -> -1.5, '2s3' -> 2/3), or
    None when the name is not one."""
    t = str(name).replace("m", "-").replace("d", ".")
    try:
        if "s" in t:
            a, b = t.split("s", 1)
            return F(a) / F(b)
        return F(t)
    except (ValueError, ZeroDivisionError):
        return None


def _neutral_ids(svg, Ec):
    """v6.12 fix_r1 (M1-readoff): rename a finished line's value-named
    objects -- ticks by their index along the line, lettered points by their
    letter -- in the SVG text, the canvas id table and the export items (and
    every `for` that points at them). Deterministic: two builds of the same
    line name everything the same way."""
    items = list(Ec.ex.items)
    ticks = [it for it in items if it.kind == "ticks" and it.name is not None
             and _idvalue(it.name) is not None]
    order = sorted({_idvalue(it.name) for it in ticks})
    newname = {}
    for it in ticks:
        newname[("ticks", str(it.name))] = "k%d" % order.index(
            _idvalue(it.name))
    let = dict((v_, k_) for k_, v_ in getattr(Ec, "letter_for", {}).items())
    used = set()
    for it in items:
        if it.kind == "point" and str(it.name) in let and \
                let[str(it.name)] not in used:
            newname[("point", str(it.name))] = let[str(it.name)]
            used.add(let[str(it.name)])
    idmap = {}
    for (kind, old), new in newname.items():
        idmap[export.make_id(kind, old)] = export.make_id(kind, new)
    if not idmap:
        return svg
    for it in items:
        k = (it.kind, str(it.name))
        if k in newname:
            it.name = newname[k]
        fr = (it.meta or {}).get("for")
        if fr in idmap:
            it.meta["for"] = idmap[fr]
    for i, oid in list(Ec.oids.items()):
        if oid in idmap:
            Ec.oids[i] = idmap[oid]
    if hasattr(Ec, "letter_for"):
        for k_, v_ in list(Ec.letter_for.items()):
            if ("point", str(v_)) in newname:
                Ec.letter_for[k_] = newname[("point", str(v_))]
    return re.sub(r' id="([^"]+)"',
                  lambda m: ' id="%s"' % idmap.get(m.group(1), m.group(1)),
                  svg)


def _idname(v):
    """v6.5: a number line's objects are named by the VALUE they sit on --
    '3', '-1.5' -> 'm1d5', '2/3' -> '2s3'. Two builds of the same line name
    the same value the same way, and an unrelated point added elsewhere
    changes nobody's name."""
    t = _num(v) if not isinstance(v, str) else v
    return t.replace(u"\u2212", "m").replace("-", "m").replace("/", "s")


def _wrong_name(text, taken=()):
    """v6.12 fix_r2 (N2): the export name of a wrong_scale label -- its
    PRINTED text, written as _idname writes a value ('2.5' -> '2.5', id
    lbl-2d5; '−1' -> 'm1'; '2/3' -> '2s3'; any other sign -> 'q'). If a true
    label of the same line already prints that number, the name gets a 'w'
    in front."""
    t = str(text).replace(u"\u2212", "m").replace("-", "m").replace("/", "s")
    t = "".join(c if (c.isalnum() or c == ".") else "q" for c in t)
    return "w" + t if t in taken else t


def _emit_group(E, x, top, runs, vin, ex=None):
    """A tick number (or a value label drawn like one): its text runs and its
    fraction bar / sign strokes, relative to (x, top)."""
    for j_, (t, dx, dy, size) in enumerate(runs):
        E.text(x + dx, top + dy, t, size, ex=ex if j_ == 0 else None)
    for vv in vin:
        x0, x1, y = vv[:3]
        if len(vv) > 4:              # the upright of a '+'
            E.line((x + x0, top + y - vv[4]), (x + x0, top + y + vv[4]), 0.75)
            continue
        E.line((x + x0, top + y), (x + x1, top + y), 0.75 if len(vv) > 3 else 0.8)


def _arc_geom(P0, C, P2, hl, hw):
    """A jump's quadratic arc as (shaft polyline ending at the head's base,
    head triangle [tip, corner, corner])."""
    pts = []
    n = 40
    for i in range(n + 1):
        u = i / float(n)
        pts.append(((1 - u) ** 2 * P0[0] + 2 * u * (1 - u) * C[0] + u * u * P2[0],
                    (1 - u) ** 2 * P0[1] + 2 * u * (1 - u) * C[1] + u * u * P2[1]))
    tip = pts[-1]
    # v6 P2 r1 (P2-L2-03): the head lies along the CHORD from where the
    # shaft is cut (the curve point hl from the tip) to the tip, and the
    # shaft ends exactly at that point, the head's base. The head used to
    # point along the end tangent while the shaft was cut hl from the tip:
    # on a tight short hop the two parted by 50-96 degrees and the shaft
    # poked out beside the head -- a hook or a blob, not an arrow.
    i = len(pts) - 2
    while i > 0 and math.hypot(pts[i][0] - tip[0], pts[i][1] - tip[1]) <= hl:
        i -= 1
    a, b = pts[i], pts[i + 1]
    da = math.hypot(a[0] - tip[0], a[1] - tip[1])
    db = math.hypot(b[0] - tip[0], b[1] - tip[1])
    if da > hl >= db and da - db > 1e-9:
        f = (da - hl) / (da - db)
        base = (a[0] + f * (b[0] - a[0]), a[1] + f * (b[1] - a[1]))
    else:
        tx, ty = P2[0] - C[0], P2[1] - C[1]
        L0 = math.hypot(tx, ty) or 1.0
        base = (tip[0] - tx / L0 * hl, tip[1] - ty / L0 * hl)
    tx, ty = tip[0] - base[0], tip[1] - base[1]
    L = math.hypot(tx, ty) or 1.0
    u = (tx / L, ty / L)
    keep = pts[:i + 1] if da > hl else pts[:1]
    keep.append(base)
    nx, ny = -u[1], u[0]
    tri = [tip, (base[0] + nx * hw, base[1] + ny * hw),
           (base[0] - nx * hw, base[1] - ny * hw)]
    return keep, tri


def _grow(b, m):
    return (b[0] - m, b[1] - m, b[2] + m, b[3] + m)


def _meet(a, b):
    return a[0] < b[2] and b[0] < a[2] and a[1] < b[3] and b[1] < a[3]


def _jump_clear(g, placed, gap, res=True):
    """Is jump geometry `g` clear of every placed jump: its head the arrow gap
    from any other arc or head, and no other head that close to its arc?
    `res=False` ignores the room reserved for labels over the apexes (the
    labels are placed afterwards, slid along their arcs when the apex is
    taken; see _layout_jumps, C7P2-03)."""
    tb = _bbox(g["tri"])
    mine = list(zip(g["keep"], g["keep"][1:]))
    for j in placed:
        jt = _bbox(j["tri"])
        if _meet(_grow(tb, gap), jt):
            return False
        segs = list(zip(j["keep"], j["keep"][1:]))
        if not res:
            pass
        elif j.get("res") and (any(_seg_box(a, b, _grow(j["res"], 1.0)) for a, b in mine)
                             or _meet(_grow(j["res"], 1.0), tb)):
            return False
        if res and g.get("res"):
            r = _grow(g["res"], 1.0)
            if any(_seg_box(a, b, r) for a, b in segs) or _meet(r, jt) or \
                    (j.get("res") and _meet(_grow(g["res"], 4.0), j["res"])):
                return False
        if any(_seg_box(a, b, _grow(tb, gap)) for a, b in zip(j["keep"], j["keep"][1:])):
            return False
        if any(_seg_box(a, b, _grow(jt, gap)) for a, b in mine):
            return False
    return True


_WIDER_TRIED = "\x00wider-tried\x00"
_WIDER_USE = "\x00wider-use\x00"   # v6 P2 r1: ' — use a wider placement'
CROSS_MIN_DEG = 12.0      # C7P-04: two arcs that must cross do so at least this steeply


def _cross_deg(a, b, c, d):
    """The angle (0..90 degrees) between segments a-b and c-d."""
    ux, uy = b[0] - a[0], b[1] - a[1]
    vx, vy = d[0] - c[0], d[1] - c[1]
    n = math.hypot(ux, uy) * math.hypot(vx, vy)
    if n <= 0:
        return 90.0
    return math.degrees(math.acos(min(1.0, abs(ux * vx + uy * vy) / n)))


def _arcs_cross(g, placed, gap, shallow=None):
    """C6 r6: does jump `g`'s arc cross the arc of a placed jump on its side?
    Two jumps that share a tick (a chain's hop, a fan leaving one tick) meet
    there by construction, so only a crossing away from that shared point is
    counted; a short hop fanned out ABOVE a long one from the same tick still
    crosses it and is read."""
    mine = list(zip(g["keep"], g["keep"][1:]))
    for j in placed:
        if j["side"] != g["side"]:
            continue
        if abs(j["P0"][0] - g["P0"][0]) < 4 * gap and \
                (j["P2"][0] - j["P0"][0]) * (g["P2"][0] - g["P0"][0]) > 0:
            # a FAN: two jumps leaving one tick the same way. Sent to the
            # other side instead, the two arcs leave the tick up and down
            # and read as ONE stroke through its number (lost_ink refuses
            # that file); a fan is left to _starts_clear
            continue
        shared = [e for e in (g["P0"], g["P2"]) for f in (j["P0"], j["P2"])
                  if math.hypot(e[0] - f[0], e[1] - f[1]) < 4 * gap]
        segs = list(zip(j["keep"], j["keep"][1:]))
        for a, b in mine:
            for c, d in segs:
                if not _cross(a, b, c, d):
                    continue
                if any(min(math.hypot(q[0] - e[0], q[1] - e[1])
                           for q in (a, b, c, d)) < 4 * gap for e in shared):
                    continue
                if shallow is not None and _cross_deg(a, b, c, d) >= shallow:
                    continue
                return True
    return False


FAN_START = 0.3           # O3-05: a fan's shared start zone, x the shorter chord


def _fan_cross(g, placed, gap):
    """O3-05: two jumps leaving one tick the same way (a FAN) cross away
    from that tick? The longer is the outer arc (stage 1b) -- with both
    clamped to ARC_MAX they rose to one apex height and the shorter ran over
    the longer at 2.5-8 degrees, so neither could be followed to its head.
    A fan is exempt from _arcs_cross (sent to the other side, the pair read
    as one stroke through the number); this is its own rule: past the shared
    start (4 x gap), the two arcs do not meet at all."""
    mine = list(zip(g["keep"], g["keep"][1:]))
    for j in placed:
        if j["side"] != g["side"]:
            continue
        if not (abs(j["P0"][0] - g["P0"][0]) < 4 * gap and
                (j["P2"][0] - j["P0"][0]) * (g["P2"][0] - g["P0"][0]) > 0):
            continue
        s0 = ((j["P0"][0] + g["P0"][0]) / 2.0, (j["P0"][1] + g["P0"][1]) / 2.0)
        # near the start the two arcs leave together (a short hop may graze
        # the long one there and still reads); the rule is about the rest
        zone = max(4 * gap, FAN_START * min(abs(g["P2"][0] - g["P0"][0]),
                                            abs(j["P2"][0] - j["P0"][0])))
        for a, b in mine:
            if min(math.hypot(q[0] - s0[0], q[1] - s0[1]) for q in (a, b)) < \
                    zone:
                continue
            for c, d in zip(j["keep"], j["keep"][1:]):
                if _cross(a, b, c, d):
                    return True
    return False


def _starts_clear(g, placed, gap):
    """An arc passes no other arc's START (and no other arc passes its start)
    closer than `gap`: an arc drawn over another's first point hides which
    tick that jump leaves (C4 r3; the sweep reads the same rule). Two jumps
    leaving one tick share a start and fan out."""
    mine = list(zip(g["keep"], g["keep"][1:]))
    for j in placed:
        if math.hypot(j["P0"][0] - g["P0"][0], j["P0"][1] - g["P0"][1]) < gap:
            continue                          # one tick, two jumps: they fan
        segs = list(zip(j["keep"], j["keep"][1:]))
        if any(svgcheck._pt_seg(j["P0"], a, b) < gap for a, b in mine) or \
                any(svgcheck._pt_seg(g["P0"], a, b) < gap for a, b in segs):
            return False
    return True


def _jump_label(g, t, px, jl, boxes, k_s, e0, below0, dims=None):
    """A jump label's box: over the apex, else slid along the arc (a label
    stands just beyond the arc at that point, on the arc's side), clear of
    every arc and head by 1px, of every other label by 0.6 em, and never
    nearer the axis than the arc's base."""
    w, h = dims(t, px) if dims else (len(t) * 0.58 * px, 1.02 * px)
    sg = -g["side"]
    P0, C, P2 = g["P0"], g["C"], g["P2"]
    for u in (0.5, 0.4, 0.6, 0.3, 0.7, 0.2, 0.8):
        x = (1 - u) ** 2 * P0[0] + 2 * u * (1 - u) * C[0] + u * u * P2[0]
        for lift in (0.0, 0.5 * h, h):
            # the arc's farthest ink under the label's width
            near = [abs(p[1]) for p in g["keep"] + g["tri"]
                    if x - w / 2.0 - 1.0 <= p[0] <= x + w / 2.0 + 1.0]
            y_arc = max(near) if near else abs(C[1])
            d0 = y_arc + 2.0 * k_s + lift
            box = (x - w / 2.0, -(d0 + h), x + w / 2.0, -d0) if sg < 0 else \
                (x - w / 2.0, d0, x + w / 2.0, d0 + h)
            ok = True
            # nothing between the label and its own arc: a label over ANOTHER
            # arc reads as that arc's (C4 r2: a '?' lifted over a long jump)
            lo_y, hi_y = sorted((sg * y_arc, box[3] if sg < 0 else box[1]))
            col = (x - w / 2.0, lo_y, x + w / 2.0, hi_y)
            for j in jl:
                segs = list(zip(j["keep"], j["keep"][1:]))
                if j is not g and (any(_seg_box(a, b, col) for a, b in segs) or
                                   _meet(col, _bbox(j["tri"]))):
                    ok = False
                    break
                if any(_seg_box(a, b, _grow(box, 1.0)) for a, b in segs) or \
                        _meet(_grow(box, 1.0), _bbox(j["tri"])):
                    ok = False
                    break
            if ok:
                for b in boxes:
                    m = 0.6 * px
                    if box[0] < b[2] + m and b[0] < box[2] + m and \
                            box[1] < b[3] + 1.0 and b[1] < box[3] + 1.0:
                        ok = False
                        break
            if ok:
                return box
    return None


def _seg_box(a, b, box):
    """Does segment a-b meet the box?"""
    x0, y0, x1, y1 = box
    if max(a[0], b[0]) < x0 or min(a[0], b[0]) > x1 or \
            max(a[1], b[1]) < y0 or min(a[1], b[1]) > y1:
        return False
    if x0 <= a[0] <= x1 and y0 <= a[1] <= y1:
        return True
    if x0 <= b[0] <= x1 and y0 <= b[1] <= y1:
        return True
    corners = [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]
    for c, d in zip(corners, corners[1:] + corners[:1]):
        if _cross(a, b, c, d):
            return True
    return False


def _cross(p, q, r, s):
    # boxes apart: no crossing (P2: most pairs the layout asks about)
    if (p[0] if p[0] > q[0] else q[0]) < (r[0] if r[0] < s[0] else s[0]) or \
            (r[0] if r[0] > s[0] else s[0]) < (p[0] if p[0] < q[0] else q[0]) or \
            (p[1] if p[1] > q[1] else q[1]) < (r[1] if r[1] < s[1] else s[1]) or \
            (r[1] if r[1] > s[1] else s[1]) < (p[1] if p[1] < q[1] else q[1]):
        return False

    def o(a, b, c):
        v = (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])
        return 0 if abs(v) < 1e-12 else (1 if v > 0 else -1)
    return o(p, q, r) != o(p, q, s) and o(r, s, p) != o(r, s, q)


# ================================================== P2: nested jump arcs ===
# v6 P2 (the author, against the Typst drawing of the same walk): jumps stay
# ABOVE the line whenever they fit there. A walk that turns back nests -- the
# longer jump is the outer arc, an arrival tip stops just above its point and
# a departure from that point starts a little along and low, so it passes
# under the incoming head. Several jumps leaving one tick fan out at clearly
# different angles (the longer one steeper, outside) and never meet again.
# Going under the line, into the row of numbers, is the last resort: only
# jumps that cannot share the upper side with the others (two arcs whose spans
# interleave must cross; two heads on one point hide each other) go below.
FAN_DEG = 18.0            # two arcs leaving one point: their start directions
ARRIVE_LIFT_PT = 1.2      # a tip over a point another jump leaves, above
ARRIVE_LIFT_BELOW_PT = 3.0  # ... and under the line
HEAD_TURN_DEG = 40.0      # sweep: a head's axis off the last HEAD_BACK_PT of its shaft
HEAD_BACK_PT = 1.5
# v6 P2 r2 (P2-L2-r2-02): the LAYOUT's own ceiling. r1 measured the worst head
# the engine drew at 36.5 degrees and set the sweep at 45 -- but seeded walks
# reach 44.7 (NL(-8,8,tier='side').chain([3,5,6,-2])), so the guard had 0.3
# degrees of headroom and the engine's own worst output still printed as a
# comma. A short hop's arc is now capped so its head keeps under this.
TURN_TARGET_DEG = 30.0
SHORT_HOP = 2.6           # v6 P2 r1: a hop under this many heads long gets a smaller head
JUMP_HEAD_MIN_PT = 4.0    # a short hop's head, tip to base, printed (HEAD is 5.25)
ARC_TOUCH_PT = 2.6        # sweep: arcs may meet only this near a shared point
ARC_ZONE_PT = 6.0         # sweep: ... and come closer than ARC_APART_PT this near
ARC_SHARE_PT = 5.0        # sweep: two arc ends this close are one shared point
ARC_APART_PT = 1.0        # sweep: paper between two arcs, away from shared points
NEST_ZONE = 3.0           # x gap: the shared point's zone, where arcs may meet
NEST_APART = 2.5          # x gap: two arcs apart, away from a shared point
NEST_MAX_LAYOUTS = 96     # side assignments tried before the older solver


def _seg_d(a, b, c, d):
    """Distance between segments a-b and c-d."""
    if _cross(a, b, c, d):
        return 0.0
    P = svgcheck._pt_seg
    return min(P(a, c, d), P(b, c, d), P(c, a, b), P(d, a, b))


def _in_tri(p, T):
    def s(a, b, c):
        return (a[0] - c[0]) * (b[1] - c[1]) - (b[0] - c[0]) * (a[1] - c[1])
    d1, d2, d3 = s(p, T[0], T[1]), s(p, T[1], T[2]), s(p, T[2], T[0])
    neg = d1 < 0 or d2 < 0 or d3 < 0
    pos = d1 > 0 or d2 > 0 or d3 > 0
    return not (neg and pos)


def _poly_d(A, B, lim, skip=None):
    """The least distance between polylines A and B, stopping early once under
    `lim`; segments of A with an end inside a `skip` (centre, radius) zone
    are left out, and so are B's. (Segments are compared only when their
    boxes, grown by `lim`, meet -- the layout calls this thousands of times.)"""
    def out(a, b):
        return skip is None or all(
            math.hypot(a[0] - c[0], a[1] - c[1]) > r and
            math.hypot(b[0] - c[0], b[1] - c[1]) > r for c, r in [skip])
    sb = []
    for c, d in zip(B, B[1:]):
        if out(c, d):
            sb.append((min(c[0], d[0]) - lim, max(c[0], d[0]) + lim,
                       min(c[1], d[1]) - lim, max(c[1], d[1]) + lim, c, d))
    if not sb:
        return 1e9
    X0 = min(t[0] for t in sb)
    X1 = max(t[1] for t in sb)
    Y0 = min(t[2] for t in sb)
    Y1 = max(t[3] for t in sb)
    best = 1e9
    for a, b in zip(A, A[1:]):
        ax0, ax1 = (a[0], b[0]) if a[0] < b[0] else (b[0], a[0])
        ay0, ay1 = (a[1], b[1]) if a[1] < b[1] else (b[1], a[1])
        if ax1 < X0 or ax0 > X1 or ay1 < Y0 or ay0 > Y1 or not out(a, b):
            continue
        for x0, x1, y0, y1, c, d in sb:
            if ax1 < x0 or ax0 > x1 or ay1 < y0 or ay0 > y1:
                continue
            best = min(best, _seg_d(a, b, c, d))
            if best < lim:
                return best
    return best


def _tri_segs(T):
    return [T[0], T[1], T[2], T[0]]


def _nest_clear(g, j, gap):
    """Is the jump geometry `g` clear of the placed jump `j` on its side?
    Exact distances (the older _jump_clear grew boxes, and a departure passing
    under an incoming head always met the head's box): no crossing and at
    least `gap` of paper between the two arcs away from a point they share,
    each head `gap` from the other arc and head, each label's room free of
    the other's ink, and two arcs leaving one point at FAN_DEG apart."""
    A, B = g["keep"], j["keep"]
    TA, TB = _tri_segs(g["tri"]), _tri_segs(j["tri"])
    zone = None
    for e in (g["P0"], g["tri"][0]):
        for f in (j["P0"], j["tri"][0]):
            if math.hypot(e[0] - f[0], e[1] - f[1]) < 5.0 * gap:
                zone = (((e[0] + f[0]) / 2.0, (e[1] + f[1]) / 2.0),
                        NEST_ZONE * gap)
    if math.hypot(g["P0"][0] - j["P0"][0], g["P0"][1] - j["P0"][1]) < 1.0:
        # a fan: the two start directions must differ clearly
        u = (g["C"][0] - g["P0"][0], g["C"][1] - g["P0"][1])
        v = (j["C"][0] - j["P0"][0], j["C"][1] - j["P0"][1])
        if _cross_deg((0, 0), u, (0, 0), v) < FAN_DEG and \
                u[0] * v[0] + u[1] * v[1] > 0:
            return False
    # the arcs: nowhere crossing (inside the zone too -- only the first
    # stretch of two arcs leaving one point may touch), gap apart outside it
    fan0 = None
    if math.hypot(g["P0"][0] - j["P0"][0], g["P0"][1] - j["P0"][1]) < 1.0:
        fan0 = (g["P0"], 1.5 * gap)
    if _poly_d(A, B, 1e-9, skip=fan0) <= 1e-9:
        return False
    # two nested arcs keep NEST_APART x gap of paper along their length (at
    # one gap, -7 over +6 ran as a double line with its label squeezed
    # between); only near a shared point may they come to one gap
    if _poly_d(A, B, gap, skip=zone) < gap:
        return False
    if _poly_d(A, B, NEST_APART * gap, skip=(zone[0], 2.5 * zone[1]) if zone
               else None) < NEST_APART * gap:
        return False
    # heads: clear of the other arc and head everywhere
    if _poly_d(TA, B, gap) < gap or _poly_d(TB, A, gap) < gap or \
            _poly_d(TA, TB, gap) < gap:
        return False
    # the sweep reads two heads by their boxes (1pt apart); keep them apart
    # the same way, or a layout this accepts is refused with no fix named
    if _meet(_grow(_bbox(g["tri"]), gap), _bbox(j["tri"])):
        return False
    if any(_in_tri(p, g["tri"]) for p in B) or \
            any(_in_tri(p, j["tri"]) for p in A):
        return False
    # starts: an arc passing close over another jump's first point hides
    # which tick that jump leaves (the sweep's rule, 2 x gap)
    if math.hypot(g["P0"][0] - j["P0"][0], g["P0"][1] - j["P0"][1]) >= 1.0:
        P = svgcheck._pt_seg
        if any(P(j["P0"], a, b) < 2 * gap for a, b in zip(A, A[1:])) or \
                any(P(g["P0"], a, b) < 2 * gap for a, b in zip(B, B[1:])):
            return False
    # label room over each apex
    for m, o in ((g, j), (j, g)):
        if m.get("res"):
            # a label keeps a gap of paper from ANOTHER jump's arc (at 1px
            # the +6 under -7 read as squeezed between two strokes)
            r = _grow(m["res"], gap)
            if any(_seg_box(a, b, r) for a, b in zip(o["keep"], o["keep"][1:])) \
                    or _meet(r, _bbox(o["tri"])) or \
                    (o.get("res") and _meet(_grow(m["res"], 4.0), o["res"])):
                return False
    return True


def _head_turn(keep, tri, k_s):
    """The angle (degrees) between an arrowhead's axis and the last
    HEAD_BACK_PT of the shaft it ends -- exactly what sweep measures on the
    finished SVG, measured here on the geometry before it is written."""
    q = keep[-1]
    back = next((z for z in reversed(keep[:-1]) if math.hypot(
        z[0] - q[0], z[1] - q[1]) * PX_TO_PT / (k_s or 1.0) >= HEAD_BACK_PT),
        keep[0])
    ux, uy = q[0] - back[0], q[1] - back[1]
    vx, vy = tri[0][0] - q[0], tri[0][1] - q[1]
    nn = math.hypot(ux, uy) * math.hypot(vx, vy)
    if nn <= 0:
        return 0.0
    return math.degrees(math.acos(max(-1.0, min(1.0,
                                                (ux * vx + uy * vy) / nn))))


def _turn_cap(span, k_s):
    """The tallest arc (apex over the axis, px) whose head still points the
    way its shaft arrives.

    v6 P2 r2 (P2-L2-r2-02): on a one-tick hop the shaft ended AT the apex and
    the head carried the whole descent -- shaft flat, head 42 degrees down,
    an arrow with a kink in it. For a quadratic of apex height h over a span
    S the head's chord leaves the apex at atan(2h/S), so the apex is capped
    at half a TURN_TARGET_DEG tangent of the span. ARC_MIN (5px, absolute)
    was what made short hops relatively tall: the cap is near ARC_PREF's own
    proportion, so it only bites where the head eats the arc."""
    return max(0.5 * math.tan(math.radians(TURN_TARGET_DEG)) * span,
               1.4 * k_s)


def _arc_ok(g, hl, k_s=None):
    """Is the arc within what the sweep lets an arc stand -- its height off
    the chord at most ARC_RATIO x (chord + head), and its head within
    TURN_TARGET_DEG of the shaft it ends? (sweep's own measures)

    v6 P2 r1 (P2-L1-04): capping the height against the start-to-TIP chord
    too (0.5 instead of the 0.53 a verifier measured there) pushed the
    return hop of a turning walk BELOW the line, against the author's rule
    of the Typst comparison, and doubled the layout search. The reading is
    left as the sweep's; see SKILL.md.
    """
    p, q = g["keep"][0], g["keep"][-1]
    L = math.hypot(q[0] - p[0], q[1] - p[1])
    if L <= 0:
        return False
    h = max(abs((q[0] - p[0]) * (p[1] - m[1]) - (p[0] - m[0]) * (q[1] - p[1])) / L
            for m in g["keep"])
    if h > ARC_RATIO * (L + hl) - 0.2:
        return False
    return k_s is None or _head_turn(g["keep"], g["tri"], k_s) <= TURN_TARGET_DEG


def _arcs_meet(g, placed, k_s):
    """v6 P2: the sweep's arc rule in layout units -- does `g` cross, or run
    together with, a placed arc on its side away from a point they share?"""
    u = k_s / PX_TO_PT                    # figure units per printed pt
    A = g["keep"]
    for j in placed:
        if j["side"] != g["side"]:
            continue
        B = j["keep"]
        shared = [((e[0] + f[0]) / 2.0, (e[1] + f[1]) / 2.0)
                  for e in (A[0], g["tri"][0]) for f in (B[0], j["tri"][0])
                  if math.hypot(e[0] - f[0], e[1] - f[1]) < ARC_SHARE_PT * u]

        def far(p, q, r_):
            return all(math.hypot(z[0] - c[0], z[1] - c[1]) > r_
                       for z in (p, q) for c in shared)
        for p, q in zip(A, A[1:]):
            for r_, t_ in zip(B, B[1:]):
                if far(p, q, ARC_TOUCH_PT * u) and far(r_, t_, ARC_TOUCH_PT * u) \
                        and _cross(p, q, r_, t_):
                    return True
                if far(p, q, ARC_ZONE_PT * u) and far(r_, t_, ARC_ZONE_PT * u) \
                        and _seg_d(p, q, r_, t_) < ARC_APART_PT * u:
                    return True
    return False


def _interleave(p, q):
    """Two spans that overlap without one lying inside the other: on one
    side of the line their arcs must cross."""
    a0, a1 = sorted((float(p["a"]), float(p["b"])))
    b0, b1 = sorted((float(q["a"]), float(q["b"])))
    return (a0 < b0 < a1 < b1) or (b0 < a0 < b1 < a1)


def _side_conflict(p, q):
    """Cheap reasons two jumps cannot share a side."""
    if _interleave(p, q):
        return True
    if float(p["b"]) == float(q["b"]):
        return True                       # two heads on one point
    return False


# a value stated in a point's label: 'A(4)', 'P(-2.5)', 'x = 4', 'M=1/2'
_CLAIM = re.compile(u"^\\s*[A-Za-z][A-Za-z0-9_']{0,2}\\s*"
                    u"(?:\\(\\s*([-+\u2212]?\\d+(?:[.,]\\d+)?)\\s*\\)"
                    u"|=\\s*([-+\u2212]?\\d+(?:[.,]\\d+)?))\\s*$")


def _value_claim(text):
    """The value a point's label STATES, or None."""
    m = _CLAIM.match(svgcheck.true_minus(str(text)).replace(u"\u2212", "-"))
    if not m:
        return None
    try:
        return float((m.group(1) or m.group(2)).replace(",", "."))
    except (TypeError, ValueError):
        return None


def _point_value_labels(M, ay, scale, sp):
    """Every 'A(4)' / 'x=4' printed over a dot, against the dot's own value
    read off the axis's numbers."""
    xa, va, k = scale
    tol = 0.05 * abs(k) * sp
    out = []
    row = set(id(t) for t in _row_texts(M, ay))
    for cx, cy, r, _ in M.dots:
        if abs(cy - ay) > max(r, 2.0):
            continue
        v = va + k * (cx - xa)
        for T in M.texts:
            if id(T) in row or not T.box or T.centre()[1] > ay:
                continue                     # the numbers' row is below
            c = T.centre()
            if abs(c[0] - cx) > 1.2 * T.size + r or (ay - c[1]) > 4.0 * T.size:
                continue
            claim = _value_claim(T.text)
            if claim is None or abs(claim - v) <= tol:
                continue
            out.append("the label %r says this point is %s, but its dot "
                       "stands at %s -- a number printed at a point IS that "
                       "point's value; draw the dot at the value the label "
                       "prints, or print the value the dot has"
                       % (T.text, _read(claim, abs(k) * sp),
                          _read(v, abs(k) * sp)))
            break
    return out


# ============================================================ the sweep ===
def sweep(svg, member=None, lo=None, hi=None, label_spacing=True,
          lengths=True, vote=True, merges=True, bars=None, signs=False):
    """Independent checks of a finished number-line SVG, read through
    `svgcheck.model` (no builder records):

      * minor ticks >= 6pt apart, printed (the width attribute included);
      * numbered ticks >= 1.6 x the widest number apart;
      * every number (a stacked fraction's runs included) centred within
        0.15 x the tick spacing of the tick below which it stands;
      * a jump arc no taller than 0.5 x its chord (the z02 teardrop at 1.8x);
      * no two arrowhead triangles' boxes meet (z01 8ב/22ב '→→');
      * an open circle's rim >= 3pt from the axis end and its arrowhead
        (z01 q20);
      * `member`: for each set drawn from an inequality, 400 samples over
        [lo, hi] plus every boundary, membership read from the bars, the
        filled/open circles and the ray heads, against the source;
      * C4 r3: filled circles at the axis ends too; no arc over another
        jump's start; jump and span labels owned, centred and equal to the
        drawing (_carried_labels).
      * C5: dashed reference lines run past the ticks and own their label
        (_reference_lines); distance bars start at 0, end at their values,
        print >= 3pt and carry one row letter each (_bar_rows; `bars` is
        the [(value, letter)] the item declares, top row first).

    `svg` may be a string or an `svgcheck.Model` (a row cut from a stack, a
    vertical line turned into the frame). `vote=False` skips the value vote
    (a critique line's numbers are wrong on purpose); `merges=False` skips
    the one-band merge rule (a vertical line runs its own); `signs=True`
    leaves lone '+'/'−' over the axis to sign_sweep.
    """
    M = svg if isinstance(svg, svgcheck.Model) else svgcheck.model(svg)
    ppu = M.pt_per_unit
    out = []
    horiz = [s for s in M.strokes if s.tag == "line" and not s.dash and
             abs(s.pts[0][1] - s.pts[1][1]) < 0.01]
    if not horiz:
        return ["no axis"]
    axis = max(horiz, key=lambda s: abs(s.pts[1][0] - s.pts[0][0]))
    ay = axis.pts[0][1]
    ax0, ax1 = sorted((axis.pts[0][0], axis.pts[1][0]))
    ticks = []
    for s in M.strokes:
        if s.tag != "line" or s.width > TICK_W_HI or s.dash:
            continue
        (x1, y1), (x2, y2) = s.pts
        if abs(x1 - x2) < 0.01 and min(y1, y2) < ay - 0.5 < ay + 0.5 < max(y1, y2) \
                and abs(y2 - y1) <= 16.0 / max(ppu / PX_TO_PT, 1e-6) + 0.1:
            ticks.append((x1, abs(y2 - y1)))
    ticks.sort()
    xs = [t[0] for t in ticks]
    gaps = [b - a for a, b in zip(xs, xs[1:])]
    sp = min(gaps) if gaps else None
    if sp is not None and sp * ppu < MINOR_GAP_PT - 0.02:
        out.append("minor ticks %.1fpt apart, floor %gpt" % (sp * ppu, MINOR_GAP_PT))
    # numbers below the axis, grouped per tick (a stacked fraction is its
    # runs, its bar and its sign strokes), each read back to a VALUE
    groups = _row_groups(M, ay, xs)
    wmax = 0.0
    tol = TICK_TOL * sp + 0.02 if sp else 0.0
    for j, g in groups.items():
        wmax = max(wmax, g["w"])
        if sp and abs(g["centre"] - xs[j]) > tol:
            out.append("%s %r centred %.2f off its tick (tolerance 0.15 x "
                       "spacing = %.2f)" % ("number" if len(g["texts"]) == 1 else
                                            "stacked number", g["label"],
                                            abs(g["centre"] - xs[j]), TICK_TOL * sp))
    # every number on its OWN tick: the values must lie on one line against
    # the tick positions (a vote, so a swapped or misprinted number is the
    # odd one out, as in svgcheck.tick_alignment, fractions included)
    vals = [(xs[j], g["value"], g["label"]) for j, g in groups.items()
            if g["value"] is not None]
    if vote and len(vals) >= 3 and sp:
        best = None
        for a in range(len(vals)):
            for b in range(a + 1, len(vals)):
                (xa, va, _), (xb, vb, _) = vals[a], vals[b]
                if va == vb or abs(xb - xa) < 1e-6:
                    continue
                k = float(vb - va) / (xb - xa)
                inl = [n for n, (x, v, _) in enumerate(vals)
                       if abs(float(va) + k * (x - xa) - float(v)) <= 0.05 * abs(k) * sp]
                if best is None or len(inl) > len(best[0]):
                    best = (inl, xa, va, k)
        if best and len(best[0]) * 2 > len(vals) and len(best[0]) >= 2:
            inl, xa, va, k = best
            for n, (x, v, lab) in enumerate(vals):
                if n not in inl:
                    at = float(va) + k * (x - xa)
                    out.append("number %r stands on the tick of %s" %
                               (lab, _read(at, abs(k) * sp)))
    if groups:
        texts = _row_texts(M, ay)
        band = (min(t.box[1] for t in texts), max(t.box[3] for t in texts))
        for t in M.texts:
            if t in texts or not t.box or not t.text.strip():
                continue
            if t.box[1] < band[1] - 0.5 and band[0] + 0.5 < t.box[3] and \
                    t.box[1] > ay:
                out.append("label %r stands in the row of numbers — it reads as "
                           "one of them" % t.text)
        for j, g in groups.items():
            if g["value"] is None:
                out.append("the number %r at tick %.1f cannot be read as a value"
                           % (g["label"], xs[j]))
    # numbers stand on the LONG ticks, and every long tick carries one: a '1'
    # moved onto a minor tick of a quarters line reads as a thirds line, which
    # no value vote with two numbers can see (off for sparse/sketch lines,
    # whose ticks are all one length by design)
    if lengths and groups and len(ticks) >= 3:
        lens = [round(l, 1) for _, l in ticks]
        numbered = [lens[j] for j in groups]
        # stage review: on a TIE (two numbers, one moved onto a minor tick)
        # this fell back to the iteration order of a set of floats, so the
        # rule's answer changed when the tick lengths changed. The longer
        # tick wins a tie -- numbers stand on the LONG ticks.
        top = max(set(numbered), key=lambda l: (numbered.count(l), l))
        for j, g in groups.items():
            if lens[j] < top - 0.3:
                out.append("number %r stands on a shorter tick than the other "
                           "numbers" % g["label"])
        for j, l in enumerate(lens):
            if j not in groups and abs(l - top) <= 0.3:
                out.append("the long tick at %.1f carries no number (numbered "
                           "ticks are the long ones)" % xs[j])
    # Stage review: a NUMBER printed at a POINT is a claim about that
    # point's value. The rule SKILL.md records ("a dot at 3 labelled 5") only
    # ever fired because a BARE numeral reads as a tick number landing on the
    # wrong tick -- wrap the same wrong value in what an author actually
    # writes, 'A(4)' or 'x=4', and nothing measured it.
    if vote and len(vals) >= 2 and sp:
        scale = None
        best = locals().get("best")
        if best and len(best[0]) >= 2:
            _, xa_, va_, k_ = best
            scale = (xa_, float(va_), k_)
        else:
            for a in range(len(vals)):
                for b in range(a + 1, len(vals)):
                    (xa_, va_, _), (xb_, vb_, _) = vals[a], vals[b]
                    if va_ != vb_ and abs(xb_ - xa_) > 1e-6:
                        scale = (xa_, float(va_),
                                 float(vb_ - va_) / (xb_ - xa_))
                        break
                if scale:
                    break
        if scale:
            out += _point_value_labels(M, ay, scale, sp)
    lab_x = sorted(xs[j] for j in groups)
    if len(lab_x) >= 2 and label_spacing:
        d = min(b - a for a, b in zip(lab_x, lab_x[1:]))
        if d * ppu < LABEL_SPACING * wmax * ppu - 0.05:
            out.append("numbered ticks %.1fpt apart, under %.1f x the widest "
                       "number (%.1fpt)" % (d * ppu, LABEL_SPACING, wmax * ppu))
    # labels off the row: two on one band stand >= 0.5 em apart (ink), or
    # they read as one ('A B' -> 'AB', '+3 A'). Numeric runs of one number
    # (a stacked value label, a whole part beside its fraction) are exempt
    row = set(id(t) for t in _row_texts(M, ay))
    if merges:
        out += _free_merges(M, row)
    # C5: reference lines and distance bars, and the texts they own
    got, owned = _reference_lines(M, ay)
    out += got
    got, own2 = _bar_rows(M, ay, bars)
    out += got
    owned |= own2
    if signs:
        owned |= set(id(t) for t in M.texts if t.box and t.box[3] < ay and
                     t.text.strip() in ("+", MINUS))
    out += _sweep_rest(M, ay, xs, ax0, ax1, sp, owned, member, lo, hi)
    return out


def _free_merges(M, row):
    """Labels off the row on one printed band stand >= 0.5 em apart (ink)."""
    out = []
    ppu = M.pt_per_unit
    free = [t for t in M.texts if t.box and t.text.strip() and id(t) not in row]
    isnum = lambda t: re.match(u"^[\\d+\u2212.,]+$", t.text.strip())
    for i in range(len(free)):
        for j in range(i + 1, len(free)):
            a, b = free[i], free[j]
            if isnum(a) and isnum(b):
                continue
            if min(a.box[3], b.box[3]) - max(a.box[1], b.box[1]) <= 0.5:
                continue
            ca, cb = a.centre()[0], b.centre()[0]
            g = abs(ca - cb) - (_ink_w(a) + _ink_w(b)) / 2.0
            em = min(a.size, b.size)
            if g < 0.5 * em - 0.05:
                out.append("labels %r and %r stand %.1fpt apart on one line "
                           "(at least 0.5 em) — they read as one"
                           % (a.text, b.text, max(g, 0.0) * ppu))
    return out


def _sweep_rest(M, ay, xs, ax0, ax1, sp, owned, member, lo, hi):
    out = []
    ppu = M.pt_per_unit
    # a set's bar hides the ticks it crosses unless each is knocked out in
    # white (the reader counts ticks along a bar to read its ends)
    bars = [tuple(sorted((k.pts[0][0], k.pts[1][0]))) for k in M.strokes
            if k.tag == "line" and k.width >= 2.0 * AXIS_W and
            abs(k.pts[0][1] - ay) < 0.01 and abs(k.pts[1][1] - ay) < 0.01]
    rr = MARK_R_PT / ppu
    for x0, x1 in bars:
        for x in xs:
            if x0 + rr + 1.0 < x < x1 - rr - 1.0 and not any(
                    abs(a[0] - x) < 0.3 and abs(b[0] - x) < 0.3 and
                    min(a[1], b[1]) < ay - 0.5 and max(a[1], b[1]) > ay + 0.5
                    for a, b in M.light):
                out.append("the tick at %.1f crosses a set's bar with no white "
                           "knock-out — the bar hides it" % x)
                break
    # arrowhead triangles: boxes at least 1pt apart (C4 r2: symmetric()'s two
    # tips met exactly at 0 and boxes that share an edge passed)
    tris = _tris(M)
    hg = 1.0 / ppu
    for i in range(len(tris)):
        for j in range(i + 1, len(tris)):
            a, b = _bbox(tris[i]), _bbox(tris[j])
            if a[0] < b[2] + hg and b[0] < a[2] + hg and a[1] < b[3] + hg and \
                    b[1] < a[3] + hg:
                out.append("two arrowheads overlap or touch near (%.1f, %.1f)"
                           % ((a[0] + a[2]) / 2.0, (a[1] + a[3]) / 2.0))
    # v6 P2: two jump arcs on one side of the line NEVER cross and never run
    # together, whatever lies inside what. Only where they share a point (a
    # fan's tick, a hop leaving the head another lands with) may they come
    # close, and two arcs leaving one point leave it at clearly different
    # angles. Read off the file: arcs are the open many-point paths, their
    # arrival point the tip of the head at their end. Before, a crossing was
    # refused only with one span strictly inside the other or at under 12
    # degrees, and a fan's arcs could run as one stroke for 30% of the shorter
    # chord (L2C7r3-03: 2->6 and 2->8 fused for 12mm; L2C7r3-06: -7 and -6
    # crossing mid-air; shared-start pairs crossing unrefused).
    arcs = []
    for k in M.strokes:
        if k.tag != "path" or k.closed or len(k.pts) < 6:
            continue
        up = sum(p[1] for p in k.pts) / len(k.pts) < ay
        q = k.pts[-1]
        tip = q
        for t in tris:
            if math.hypot((t[1][0] + t[2][0]) / 2.0 - q[0],
                          (t[1][1] + t[2][1]) / 2.0 - q[1]) < 1.0:
                tip = t[0]
        arcs.append((up, k.pts, tip))
    near_r = ARC_TOUCH_PT / ppu
    zone_r = ARC_ZONE_PT / ppu
    for i in range(len(arcs)):
        for j in range(i + 1, len(arcs)):
            ua, A, ta = arcs[i]
            ub, B, tb = arcs[j]
            if ua != ub:
                continue
            shared = [((e[0] + f[0]) / 2.0, (e[1] + f[1]) / 2.0)
                      for e in (A[0], ta) for f in (B[0], tb)
                      if math.hypot(e[0] - f[0], e[1] - f[1]) < ARC_SHARE_PT / ppu]

            def far(p, q, r_):
                return all(math.hypot(z[0] - c[0], z[1] - c[1]) > r_
                           for z in (p, q) for c in shared)
            SA = list(zip(A, A[1:]))
            SB = list(zip(B, B[1:]))
            hit = next((p[0] for p, q in SA if far(p, q, near_r)
                        for r_, t_ in SB if far(r_, t_, near_r)
                        and _cross(p, q, r_, t_)), None)
            if hit is not None:
                out.append("two jump arcs on one side of the line cross near x "
                           "%.1f — an arc drawn through another cannot be "
                           "followed to its head; the longer jump is the outer "
                           "arc, and a jump that overlaps another without lying "
                           "inside it goes to the other side of the line" % hit)
                continue
            close = None
            for p, q in SA:
                if not far(p, q, zone_r):
                    continue
                for r_, t_ in SB:
                    if far(r_, t_, zone_r) and \
                            _seg_d(p, q, r_, t_) * ppu < ARC_APART_PT:
                        close = p[0]
                        break
                if close is not None:
                    break
            if close is not None:
                out.append("two jump arcs run together near x %.1f (under "
                           "%gpt apart) — they print as one stroke; the longer "
                           "jump is the outer arc, clear of the shorter"
                           % (close, ARC_APART_PT))
                continue
            if math.hypot(A[0][0] - B[0][0], A[0][1] - B[0][1]) * ppu < 1.0:
                # a fan: two arcs leaving one point, the same way
                def dirn(P):
                    k_ = next((z for z in P if math.hypot(z[0] - P[0][0],
                                                          z[1] - P[0][1]) > zone_r),
                              P[-1])
                    return (k_[0] - P[0][0], k_[1] - P[0][1])
                u, v = dirn(A), dirn(B)
                if u[0] * v[0] + u[1] * v[1] > 0 and \
                        _cross_deg((0, 0), u, (0, 0), v) < FAN_DEG - 6.0:
                    out.append("two jump arcs leave x %.1f at %d degrees apart "
                               "— a fan whose arcs leave together reads as one "
                               "stroke; the longer jump leaves steeper, outside"
                               % (A[0][0], round(_cross_deg((0, 0), u, (0, 0), v))))
    # jump arcs (open paths of many points)
    for s in M.strokes:
        if s.tag != "path" or s.closed or len(s.pts) < 6:
            continue
        p, q = s.pts[0], s.pts[-1]
        L = math.hypot(q[0] - p[0], q[1] - p[1])
        if L <= 0:
            continue
        # the head's length is part of the jump's span
        hl = _head_len(q, tris)
        h = max(abs((q[0] - p[0]) * (p[1] - m[1]) - (p[0] - m[0]) * (q[1] - p[1])) / L
                for m in s.pts)
        if h > ARC_RATIO * (L + hl) + 0.3:
            out.append("a jump arc stands %.2f x its span (at most %.1f) — a "
                       "teardrop reads as a loop" % (h / (L + hl), ARC_RATIO))
        # v6 P2 r1 (P2-L2-03): the head points the way its shaft arrives.
        # A head laid along the end tangent while the shaft was cut a head
        # length back parted from it by 50-96 degrees on short hops: a hook.
        tri = next((t for t in tris if math.hypot(
            (t[1][0] + t[2][0]) / 2.0 - q[0],
            (t[1][1] + t[2][1]) / 2.0 - q[1]) < 1.0), None)
        if tri is not None:
            back = next((z for z in reversed(s.pts[:-1]) if math.hypot(
                z[0] - q[0], z[1] - q[1]) * ppu >= HEAD_BACK_PT), s.pts[0])
            ux, uy = q[0] - back[0], q[1] - back[1]
            vx, vy = tri[0][0] - q[0], tri[0][1] - q[1]
            nn = math.hypot(ux, uy) * math.hypot(vx, vy)
            if nn > 0:
                turn = math.degrees(math.acos(max(-1.0, min(1.0, (
                    ux * vx + uy * vy) / nn))))
                if turn > HEAD_TURN_DEG:
                    out.append("the arrowhead at x %.1f turns %d degrees off "
                               "its arc (at most %g) — it prints as a hook, "
                               "not an arrow" % (tri[0][0], round(turn),
                                                 HEAD_TURN_DEG))
        # grounded: an arc leaves from beside the axis (above it) or beside
        # the row of numbers (below), so the reader sees which tick it leaves
        # and lands on (C4 r2: overlapping jumps floated on stacked levels)
        rt = _row_texts(M, ay)
        row_b = max([t.box[3] for t in rt] or [ay])
        tip = None
        for t in tris:
            if min(math.hypot(v[0] - q[0], v[1] - q[1]) for v in t) < 1.5 or \
                    math.hypot((t[1][0] + t[2][0]) / 2.0 - q[0],
                               (t[1][1] + t[2][1]) / 2.0 - q[1]) < 1.0:
                tip = min(t, key=lambda v: abs(v[1] - ay))
        for pt_, what in ((p, "starts"), (tip, "lands")):
            if pt_ is None:
                continue
            dy = pt_[1] - ay
            # (3.5: the marker size this floor was set with; v6 P2 shrank
            # the markers, not the room a tip may stand off its point)
            lim = (3.5 + ARROW_GAP_PT + 1.5) / ppu
            if (dy < 0 and -dy > lim) or (dy > 0 and dy > row_b - ay + 5.0 / ppu):
                out.append("a jump arc %s %.1fpt from the axis — floating, it "
                           "does not show which tick it %s" %
                           (what, abs(dy) * ppu, "leaves" if what == "starts"
                            else "lands on"))
    # C4 r3: an arc passing over ANOTHER jump's first point hides which tick
    # that jump leaves (two jumps leaving one tick share a start, and fan)
    arcs = [k.pts for k in M.strokes if k.tag == "path" and not k.closed and
            len(k.pts) >= 6]
    lim = 2 * (ARROW_GAP_PT + 0.3 * PX_TO_PT) / ppu
    for a_ in arcs:
        for b_ in arcs:
            if a_ is b_ or math.hypot(a_[0][0] - b_[0][0], a_[0][1] - b_[0][1]) < lim:
                continue
            dmin = min(svgcheck._pt_seg(b_[0], u, v) for u, v in zip(a_, a_[1:]))
            if dmin < lim - 0.05:
                out.append("a jump arc passes %.1fpt from another jump's start "
                           "— it hides which tick that jump leaves"
                           % (dmin * ppu))
                break
    # circles on the axis against its ends: open (a white-filled ring) and,
    # C4 r3, filled -- a dot touching the arrowhead hides it just the same
    rims = []
    for s in M.strokes:
        if s.tag != "circle" or (s.fill or "").lower() not in ("#fff", "#ffffff",
                                                               "white"):
            continue
        xs_ = [p[0] for p in s.pts]
        if abs(s.pts[0][1] - ay) > (max(xs_) - min(xs_)) / 2.0 + 0.5 and \
                abs(sum(p[1] for p in s.pts) / len(s.pts) - ay) > 0.5:
            continue
        rims.append(((max(xs_) + min(xs_)) / 2.0, (max(xs_) - min(xs_)) / 2.0,
                     s.width, "an open circle"))
    rims += [(cx, r_, 0.0, "a filled circle") for cx, cy, r_, _ in M.dots
             if abs(cy - ay) < 0.5]
    for c, rr, sw, what in rims:
        ends = [ax0, ax1]
        for t in tris:
            ty = sum(p[1] for p in t) / 3.0
            if abs(ty - ay) < 0.5:
                ends += [min(p[0] for p in t), max(p[0] for p in t)]
        for e in ends:
            gap = abs(e - c) - rr - sw / 2.0
            if gap * ppu < RIM_CLEAR_PT - 0.05 and not (min(ends) < c < max(ends)
                                                       and abs(e - c) > rr * 3):
                if abs(e - c) < rr + RIM_CLEAR_PT / ppu + 0.01:
                    out.append("%s's rim stands %.2fpt from the axis "
                               "end or its arrowhead (floor %gpt)"
                               % (what, max(gap * ppu, 0), RIM_CLEAR_PT))
    out += _carried_labels(M, ay, sp, tris, owned)
    if member:
        out += _sample_sets(M, member, ay, ax0, ax1, tris, lo, hi)
    return out


def _markers_x(M, ay):
    """x of every marker standing on the axis: dots, white circles, tri and
    square outlines, crosses."""
    xs = [cx for cx, cy, r_, _ in M.dots if abs(cy - ay) < 1.0]
    for k in M.strokes:
        P = k.pts
        if not P:
            continue
        b = _bbox(P)
        cy = (b[1] + b[3]) / 2.0
        if k.tag == "circle" and abs(cy - ay) < 1.0:
            xs.append((b[0] + b[2]) / 2.0)
        elif k.tag == "path" and k.closed and b[2] - b[0] < 16 and \
                abs(sum(p[1] for p in P) / len(P) - ay) < 2.5:
            xs.append(sum(p[0] for p in P) / len(P))
        elif k.tag == "line" and abs(P[0][0] - P[-1][0]) > 0.5 and \
                abs(P[0][1] - P[-1][1]) > 0.5 and abs(cy - ay) < 1.0:
            xs.append((b[0] + b[2]) / 2.0)
    return xs


def _carriers(M, ay, tris):
    """What a label off the row can belong to, read from the SVG: jump arcs
    (an open many-point path and its head) and spans (a thin horizontal line
    off the axis whose ends carry a head, a leg, or meet another half)."""
    out = []
    for k in M.strokes:
        if k.tag != "path" or k.closed or len(k.pts) < 6:
            continue
        q = k.pts[-1]
        head, tip = [], None
        for t in tris:
            bm = ((t[1][0] + t[2][0]) / 2.0, (t[1][1] + t[2][1]) / 2.0)
            if min(math.hypot(v[0] - q[0], v[1] - q[1]) for v in t) < 1.5 or \
                    math.hypot(bm[0] - q[0], bm[1] - q[1]) < 1.0:
                head = t
                tip = max(t, key=lambda v: math.hypot(v[0] - q[0], v[1] - q[1]))
        if tip is None:
            continue
        out.append(dict(kind="jump", ink=list(k.pts), tri=head, x0=k.pts[0][0],
                        x1=tip[0], side=-1 if k.pts[0][1] < ay else 1))
    thin = [k for k in M.strokes if k.tag == "line" and 0.9 <= k.width <= 1.3 and
            abs(k.pts[0][1] - k.pts[-1][1]) < 0.01 and k.pts[0][1] < ay - 1.0 and
            abs(k.pts[0][0] - k.pts[-1][0]) > 1.0]
    legs = [k for k in M.strokes if k.tag == "line" and 0.9 <= k.width <= 1.3 and
            abs(k.pts[0][0] - k.pts[-1][0]) < 0.01 and
            abs(k.pts[0][1] - k.pts[-1][1]) > 1.0]
    for k in thin:
        y = k.pts[0][1]
        ends = sorted((k.pts[0][0], k.pts[-1][0]))
        got, ink = [], [(ends[0], y), (ends[1], y)]
        for e, dirn in ((ends[0], -1.0), (ends[1], 1.0)):
            x = None
            for t in tris:
                bm = ((t[1][0] + t[2][0]) / 2.0, (t[1][1] + t[2][1]) / 2.0)
                tp = max(t, key=lambda v: abs(v[0] - bm[0]))
                if abs(bm[0] - e) < 1.0 and abs(bm[1] - y) < 0.5 and \
                        (tp[0] - bm[0]) * dirn > 0:
                    x = tp[0]
                    ink += list(t)
            if x is None:
                for g in legs:
                    if abs(g.pts[0][0] - e) < 0.3 and \
                            min(abs(g.pts[0][1] - y), abs(g.pts[-1][1] - y)) < 0.3:
                        x = e
                        ink += list(g.pts)
            got.append(x if x is not None else e)
        out.append(dict(kind="span", ink=ink, tri=[], x0=got[0], x1=got[1],
                        side=-1, y=y))
    return out


def _carried_labels(M, ay, sp, tris, owned=()):
    """C4 r3 (doctrine 3): jump and span labels read from the finished SVG.
    Only the builder checked them, so a label moved over a junction or onto
    another arc, and '+5' edited to '+6' on a 5-jump, passed every sweep.

    A label off the row that does not stand centred over a marker belongs to
    the first arc or span straight under it (toward the axis) -- the builder
    keeps every other arc out of that column. Then:
      * it stands over the middle of its arc (20-80 % of the hop, where the
        builder slides it) or of its span, not over a junction;
      * it stands within 2px + one line of its arc (1.5px + the head of a
        span): farther, it floats;
      * a number equals what the drawing shows: tip - start for a jump
        (the start sits up to 2.5pt past a chained tick), the length between
        the ends for a span, within 0.45 x the minor tick spacing."""
    out = []
    rows = set(id(t) for t in _row_texts(M, ay))
    marks = _markers_x(M, ay)
    cars = _carriers(M, ay, tris)
    X = _scale(M, ay)
    upx = (X(1) - X(0)) if X else None
    for t in M.texts:
        if id(t) in rows or not t.box or not t.text.strip() or id(t) in owned:
            continue
        cx, cy = t.centre()
        # a text centred over a marker is a point's letter or value -- unless
        # an arc or span runs between it and the line. Skipped outright, the
        # label of a span with its midpoint, of symmetric(a) with points at
        # +-a/2, or of a jump over a point could be edited to any number and
        # pass (stage-1 open issue C4r3v-04)
        on_mark = any(abs(cx - m) < 0.6 for m in marks)
        own = False
        if on_mark:
            try:
                pl = _parse_label(t.text)
            except AssertionError:
                continue
            if pl is None:
                continue                     # a point's letter
            # C7P-01: a number that IS the value of the marker under it is
            # that point's value label (point(v, value_label=True) at a jump's
            # start or tip, over a span's end or a chain junction). Read as
            # the carrier's label, every such correct drawing was refused.
            own = X is not None and any(abs(cx - m) < 0.6 for m in marks
                                        if abs(X(pl[0]) - m) <
                                        max(0.6, 0.25 * (sp or 0.0)))
        above = cy < ay
        best = None
        for c in cars:
            if (c["side"] < 0) != above:
                continue
            lo_x, hi_x = sorted((c["x0"], c["x1"]))
            if not lo_x - 0.5 <= cx <= hi_x + 0.5:
                continue
            ys = []
            segs = list(zip(c["ink"], c["ink"][1:])) + \
                list(zip(c["tri"], c["tri"][1:] + c["tri"][:1])) \
                if c["kind"] == "jump" else [((c["x0"], c["y"]), (c["x1"], c["y"]))]
            for a, b in segs:
                if min(a[0], b[0]) - 1e-6 <= cx <= max(a[0], b[0]) + 1e-6:
                    u = 0.0 if abs(b[0] - a[0]) < 1e-9 else (cx - a[0]) / (b[0] - a[0])
                    ys.append(a[1] + u * (b[1] - a[1]))
            if above:
                ys = [y for y in ys if t.box[3] - 0.5 < y < ay]
            else:
                ys = [y for y in ys if ay < y < t.box[1] + 0.5]
            if not ys:
                continue
            gap = min(abs(y - (t.box[3] if above else t.box[1])) for y in ys)
            if best is None or gap < best[0]:
                best = (gap, c)
        if on_mark and best is not None and own:
            # O3-04: ... but only where it cannot be the carrier's own label:
            # over a span's end or a jump's start, tip or junction. At the
            # label's place (the middle of a span, 18-82 % of a hop) a number
            # equal to the point under it is the CARRIER's label edited to
            # that value -- the builder prints a point's value under the
            # carrier there (C7P-03) -- and is judged as one
            c = best[1]
            ch = c["x1"] - c["x0"]
            f = (cx - c["x0"]) / ch if abs(ch) > 1e-6 else 0.5
            if (c["kind"] == "jump" and not 0.18 <= f <= 0.82) or \
                    (c["kind"] != "jump" and abs(f - 0.5) > 0.05):
                continue
            # a carrier with no label of its own does not lift, and the
            # point's value stands over it there: the number is the point's
            # unless the point's value is ALREADY printed nearer the line
            if not any(u is not t and u.box and u.text.strip() == t.text.strip()
                       and id(u) not in rows and abs(u.centre()[0] - cx) < 0.6
                       and (u.centre()[1] < ay) == above and
                       abs(u.centre()[1] - ay) < abs(cy - ay)
                       for u in M.texts):
                continue
        if best is None and on_mark:
            def _bar_between(u):
                y0, y1 = sorted((cy, u.centre()[1]))
                return any(abs(a[1] - b[1]) < 0.3 and y0 < a[1] < y1 and
                           min(a[0], b[0]) - 0.5 <= cx <= max(a[0], b[0]) + 0.5
                           and abs(b[0] - a[0]) < 2.5 * t.size
                           for a, b, _ in M.dark_segs())
            stacked = [u for u in M.texts if u is not t and u.box and
                       u.text.strip() and abs(u.centre()[0] - cx) < 0.6 * t.size
                       and abs(u.centre()[1] - cy) < 1.6 * t.size and
                       id(u) not in rows and _bar_between(u)]
            if not own and X is not None and not stacked:
                # (a stacked fraction's numerator and denominator are two
                # texts in one column: left to the builder's own reading)
                # O3-04: a number printed straight over a point, with nothing
                # between it and the line, is that point's value label -- a
                # dot at 3 labelled 5 passed every sweep
                m = min(marks, key=lambda m: abs(cx - m))
                v = _num(F(round((m - X(0)) / (X(1) - X(0)), 6)).limit_denominator(24))
                out.append("label %r stands straight over the point at %s — a "
                           "number over a point is that point's value label, "
                           "and the drawing puts the point at %s; print its own "
                           "value (or a letter), never another number"
                           % (t.text, v.replace("-", MINUS),
                              v.replace("-", MINUS)))
            continue                         # a point's letter or value
        if best is None:
            if cars:
                out.append("label %r stands over no jump, span or point — it "
                           "belongs to nothing on the line" % t.text)
            continue
        c = best[1]
        # C7P-03: a point's letter (or value) printed straight on top of this
        # label, in its column, reads with it as one: 'M' over the '6' of a
        # span reads M = 6. The builder puts such a letter UNDER the carrier.
        for u in M.texts:
            if u is t or not u.box or not u.text.strip() or id(u) in rows:
                continue
            ux = u.centre()[0]
            if not any(abs(ux - m) < 0.6 for m in marks):
                continue
            if u.box[0] > t.box[2] + 0.5 or u.box[2] < t.box[0] - 0.5:
                continue
            g = (t.box[1] - u.box[3]) if above else (u.box[1] - t.box[3])
            if -0.5 * t.size < g < 0.8 * t.size:
                out.append("the point's %r stands on the label %r of its %s, in "
                           "one column — they read as one (%s = %s); the point's "
                           "letter goes under the %s, the label over it"
                           % (u.text, t.text, c["kind"], u.text, t.text,
                              "arc" if c["kind"] == "jump" else "span"))
        chord = c["x1"] - c["x0"]
        f = (cx - c["x0"]) / chord if abs(chord) > 1e-6 else 0.5
        d = min(_box_seg_d(t.box, a, b) for a, b in
                list(zip(c["ink"], c["ink"][1:])) + list(zip(c["tri"], c["tri"][1:] + c["tri"][:1])))
        if c["kind"] == "jump":
            if not 0.18 <= f <= 0.82:
                out.append("label %r stands at %d%% of its jump, over the "
                           "junction with the next — a jump label stands over "
                           "the middle of its own arc" % (t.text, round(100 * f)))
            if d > 2.0 + 1.02 * t.size + 1.0:
                out.append("label %r floats %.1fpt from its jump arc" %
                           (t.text, d * M.pt_per_unit))
        else:
            if abs(f - 0.5) > 0.05:
                out.append("label %r stands off the middle of its span (%d%%)"
                           % (t.text, round(100 * f)))
            if d > 1.5 + 4.2 + 1.0:
                out.append("label %r floats %.1fpt over its span" %
                           (t.text, d * M.pt_per_unit))
        try:
            p = _parse_label(t.text)
        except AssertionError:
            p = None
        if p is None or not upx or not sp:
            continue
        val, signed, _ = p
        drawn = chord if c["kind"] == "jump" else abs(chord)
        want = float(val) * upx if c["kind"] == "jump" else abs(float(val) * upx)
        if abs(drawn - want) > 0.45 * sp + 0.02:
            # the drawing read to its ticks: whole tick spacings x the tick
            raw = sp / abs(upx)
            tv = F(raw).limit_denominator(12)
            if abs(float(tv) - raw) > 0.01 * raw:
                tv = F("%.3g" % raw)
            n_t = int(round(drawn / sp))
            shown = ("+" if c["kind"] == "jump" and n_t > 0 else "") + _num(n_t * tv)
            out.append("label %r on a %s that the drawing shows as %s — a label "
                       "on the drawing is the drawing's own number"
                       % (t.text, c["kind"], shown.replace("-", MINUS)))
    return out


def _box_seg_d(box, a, b):
    return svgcheck._box_seg_dist(box, a, b)


def _tris(M):
    """Dark filled triangles (arrowheads), closing vertex dropped."""
    out = []
    for pts, closed, el in M.fills:
        P = list(pts)
        if len(P) > 1 and math.hypot(P[0][0] - P[-1][0], P[0][1] - P[-1][1]) < 0.01:
            P = P[:-1]
        if len(P) == 3:
            out.append(P)
    return out


def _row_texts(M, ay):
    """The ROW of tick numbers: numeric runs below the axis, from the highest
    one down 1.6 em (a stacked fraction's denominator is 1.1 em down; a jump
    label under the row is farther)."""
    nums = [t for t in M.texts if t.box and t.box[1] > ay and
            re.match(u"^[\\d+\u2212.,]+$", t.text.strip())]
    if not nums:
        return []
    top = min(t.box[1] for t in nums)
    return [t for t in nums if t.box[1] <= top + 1.6 * t.size]


def _ink_w(t):
    return sum(0.5 if c.isdigit() or c in u"+\u2212" else
               0.36 if c in ".," else 0.58 for c in t.text) * t.size


def _row_groups(M, ay, xs):
    """{tick index: group} for the row of numbers. A group holds the texts
    nearest that tick, the short thin strokes among them (a fraction bar, a
    sign drawn as a stroke), its ink centre, width, printed label and value
    (None when it cannot be read)."""
    texts = _row_texts(M, ay)
    if not texts or not xs:
        return {}
    y0 = min(t.box[1] for t in texts) - 1.0
    y1 = max(t.box[3] for t in texts) + 1.0
    size = max(t.size for t in texts)
    strokes = []
    for k in M.strokes:
        if k.tag != "line" or k.width > 1.0:
            continue
        (xa, ya), (xb, yb) = k.pts[0], k.pts[-1]
        if y0 <= min(ya, yb) and max(ya, yb) <= y1 and \
                max(abs(xb - xa), abs(yb - ya)) < 2.0 * size:
            strokes.append(((xa + xb) / 2.0, (ya + yb) / 2.0, k))
    out = {}
    near = lambda x: min(range(len(xs)), key=lambda i: abs(xs[i] - x))
    # C4 r2: runs were given to their nearest tick one by one, so on a tenths
    # line the whole part of '−1 3/5' went to the previous tick and both
    # halves were refused as off their ticks. Numbers are assembled first --
    # a stacked pair (one centre, one above the other) with a whole part
    # standing beside it at mid height -- and the NUMBER goes to its tick
    pairs, used = [], set()
    for a in sorted(texts, key=lambda t: t.box[1]):
        if id(a) in used:
            continue
        for b in texts:
            if b is not a and id(b) not in used and b.box[1] > a.box[3] - 0.5 and \
                    b.box[1] < a.box[3] + 0.8 * size and \
                    abs(a.centre()[0] - b.centre()[0]) < 1.0:
                pairs.append([a, b])
                used |= {id(a), id(b)}
                break
    clusters = []
    for num, den in pairs:
        fl = min(num.centre()[0] - _ink_w(num) / 2.0, den.centre()[0] - _ink_w(den) / 2.0)
        best = None
        for t in texts:
            if id(t) in used:
                continue
            cy = t.centre()[1]
            right = t.centre()[0] + _ink_w(t) / 2.0
            if num.box[1] < cy < den.box[3] and -0.5 <= fl - right < 0.6 * size:
                if best is None or right > best[0]:
                    best = (right, t)
        c = [num, den]
        if best:
            used.add(id(best[1]))
            c.append(best[1])
        clusters.append(c)
    clusters += [[t] for t in texts if id(t) not in used]
    for c in clusters:
        if len(c) == 1:
            cx = c[0].centre()[0]
        elif len(c) == 2:
            cx = c[0].centre()[0]
        else:
            cx = (min(t.centre()[0] - _ink_w(t) / 2.0 for t in c) +
                  max(t.centre()[0] + _ink_w(t) / 2.0 for t in c)) / 2.0
        out.setdefault(near(cx), dict(texts=[], strokes=[]))["texts"].extend(c)
    for cx, cy, k in strokes:
        # a stroke joins the number whose runs it stands nearest (a sign
        # hangs left of its fraction, often nearer the previous tick)
        def gap(j):
            T = out[j]["texts"]
            x0, x1 = min(t.box[0] for t in T), max(t.box[2] for t in T)
            return max(x0 - cx, cx - x1, 0.0)
        j = min(out, key=gap)
        if gap(j) < 0.6 * size:
            out[j]["strokes"].append(k)
    for j, g in out.items():
        T = g["texts"]
        if len(T) == 1:
            t = T[0]
            g["centre"], g["w"], g["label"] = t.centre()[0], _ink_w(t), t.text
            m = _SIGNED.match(t.text)
            g["value"] = None
            if m:
                v = F(m.group(2).replace(",", "."))
                g["value"] = -v if m.group(1) in ("-", MINUS) else v
            continue
        # stacked: numerator over denominator share a centre; a head run (a
        # whole part) and sign strokes stand to the left
        T = sorted(T, key=lambda t: t.box[1])
        fr = None
        for a in T:
            for b in T:
                if b.box[1] > a.box[3] - 0.5 and abs(a.centre()[0] - b.centre()[0]) < 1.0:
                    fr = (a, b)
                    break
            if fr:
                break
        # ink extents (digits advance 0.5 em), not the 0.58 em text boxes:
        # a whole part's box is wider than its ink on one side only
        xs_ = [t.centre()[0] - _ink_w(t) / 2.0 for t in T] + \
            [min(k.pts[0][0], k.pts[-1][0]) for k in g["strokes"]]
        xe_ = [t.centre()[0] + _ink_w(t) / 2.0 for t in T] + \
            [max(k.pts[0][0], k.pts[-1][0]) for k in g["strokes"]]
        g["w"] = max(xe_) - min(xs_)
        g["value"], g["label"] = None, "/".join(t.text for t in T)
        if not fr:
            g["centre"] = (min(xs_) + max(xe_)) / 2.0
            continue
        num, den = fr
        fx = num.centre()[0]
        head = [t for t in T if t not in fr]
        signs = [k for k in g["strokes"] if max(k.pts[0][0], k.pts[-1][0]) <
                 min(num.box[0], den.box[0]) - 0.2]
        try:
            v = F(int(num.text), int(den.text))
        except ValueError:
            g["centre"] = fx
            continue
        neg = False
        if head:
            m = _SIGNED.match(head[0].text)
            if m:
                v += F(m.group(2))
                neg = m.group(1) in ("-", MINUS)
            g["centre"] = (min(xs_) + max(xe_)) / 2.0
        else:
            horiz = [k for k in signs if abs(k.pts[0][1] - k.pts[-1][1]) < 0.01]
            vert = [k for k in signs if abs(k.pts[0][0] - k.pts[-1][0]) < 0.01]
            neg = bool(horiz) and not vert
            g["centre"] = fx                 # the fraction itself on its tick
        g["value"] = -v if neg else v
        g["label"] = ("%s%s%s/%s" % (MINUS if neg and not head else "",
                                     (head[0].text + " ") if head else "",
                                     num.text, den.text))
    return out


def _bbox(P):
    return (min(p[0] for p in P), min(p[1] for p in P),
            max(p[0] for p in P), max(p[1] for p in P))


def _head_len(q, tris):
    best = 0.0
    for t in tris:
        for p in t:
            d = math.hypot(p[0] - q[0], p[1] - q[1])
            if d < 1.5:
                tip = max(t, key=lambda z: math.hypot(z[0] - q[0], z[1] - q[1]))
                best = max(best, math.hypot(tip[0] - q[0], tip[1] - q[1]))
    if best == 0.0:
        for t in tris:
            b = ((t[1][0] + t[2][0]) / 2.0, (t[1][1] + t[2][1]) / 2.0)
            if math.hypot(b[0] - q[0], b[1] - q[1]) < 1.0:
                best = math.hypot(t[0][0] - b[0], t[0][1] - b[1])
    return best


def _scale(M, ay):
    """value -> x, from the row of numbers read back per tick (fractions
    included): the two extreme readable numbers name their ticks."""
    Md = M
    hz = [k for k in Md.strokes if k.tag == "line" and abs(k.pts[0][1] - k.pts[-1][1]) < .01]
    xs = sorted(k.pts[0][0] for k in Md.strokes if k.tag == "line" and
                abs(k.pts[0][0] - k.pts[-1][0]) < .01 and
                min(k.pts[0][1], k.pts[-1][1]) < ay < max(k.pts[0][1], k.pts[-1][1]))
    items = {}
    for j, g in _row_groups(M, ay, xs).items():
        if g["value"] is not None:
            items.setdefault(g["value"], xs[j])
    items = sorted(items.items())
    if len(items) < 2:
        return None
    (v0, x0), (v1, x1) = items[0], items[-1]
    return lambda v: x0 + float(F(v) - v0 if isinstance(v, F) else v - float(v0)) * \
        (x1 - x0) / float(v1 - v0)


def _sample_sets(M, member, ay, ax0, ax1, tris, lo, hi):
    """Membership read off the drawing, against each source. C4 r2: only 400
    fixed samples were read, so a deleted end circle, a deleted ray head and a
    boundary circle moved off its boundary all passed. Now: every bar end
    carries a circle or a ray head; every circle on the axis is read at its
    OWN value (filled = in, open = out); samples just past every bar end;
    and a ray head is a claim about the values past the line's end."""
    X = _scale(M, ay)
    if X is None:
        return ["cannot read the line's scale to sample its sets"]
    x_0, x_1 = X(0), X(1)
    upx = x_1 - x_0

    def value(x):
        f = (x - x_0) / upx
        g = F(f).limit_denominator(100)
        return g if abs(float(g) - f) * abs(upx) < 0.08 else F(f)
    out = []
    bars = [s for s in M.strokes if s.tag == "line" and s.width >= 2.0 * AXIS_W
            and abs(s.pts[0][1] - ay) < 0.01 and abs(s.pts[1][1] - ay) < 0.01]
    bars = [tuple(sorted((s.pts[0][0], s.pts[1][0]))) for s in bars]
    rays = []
    for x0, x1 in bars:
        for t in tris:
            if abs(sum(p[1] for p in t) / 3.0 - ay) > 0.5:
                continue
            tx = [p[0] for p in t]
            if abs(max(tx) - x0) < 1.0 and min(tx) < x0:
                rays.append((x0, x1, "left"))
            if abs(min(tx) - x1) < 1.0 and max(tx) > x1:
                rays.append((x0, x1, "right"))
    circles = [(cx, r, True) for cx, cy, r, _ in M.dots if abs(cy - ay) < 0.5]
    for s in M.strokes:
        if s.tag == "circle" and (s.fill or "").lower() in ("#fff", "#ffffff", "white"):
            xs = [p[0] for p in s.pts]
            ys = [p[1] for p in s.pts]
            if abs((max(ys) + min(ys)) / 2.0 - ay) < 0.5:
                circles.append(((max(xs) + min(xs)) / 2.0, (max(xs) - min(xs)) / 2.0,
                                False))
    for x0, x1 in bars:
        for xe, side in ((x0, "left"), (x1, "right")):
            if any(abs(c - xe) < 0.6 for c, _, _ in circles) or \
                    any(d == side and (a if side == "left" else b) == xe
                        for a, b, d in rays):
                continue
            out.append("a set's bar ends at %s with no circle and no ray arrow "
                       "— the boundary cannot be read (is it in the set?)"
                       % _num(value(xe)))

    def on_bar(x):
        return any(x0 - 0.02 <= x <= x1 + 0.02 for x0, x1 in bars)

    lo_, hi_ = F(lo).limit_denominator(10 ** 6), F(hi).limit_denominator(10 ** 6)
    for ent in member:
        kind, ref = ent[0], ent[1]
        src = ent[3] if len(ent) > 3 else "the integer set"
        bad = []
        if kind == "points":
            for k in range(math.ceil(lo_), math.floor(hi_) + 1):
                x = X(F(k))
                got = any(abs(c - x) < 0.6 and f for c, _, f in circles)
                if got != ref(F(k)):
                    bad.append((F(k), ref(F(k))))
            for c, _, f in circles:
                v = value(c)
                if f and not ref(v):
                    bad.append((v, False))
        else:
            dv = F(1.2 / abs(upx)).limit_denominator(10 ** 6)
            samples = [lo_ + (hi_ - lo_) * i / (SAMPLES - 1) for i in range(SAMPLES)]
            for x0, x1 in bars:
                for xe in (x0, x1):
                    samples += [value(xe) - dv, value(xe) + dv]
            cs = [(value(c), r, f) for c, r, f in circles]
            for x in sorted(set(v for v in samples if lo_ <= v <= hi_)):
                if any(abs(X(x) - X(v)) <= r + 0.6 for v, r, _ in cs):
                    continue                  # under a circle: read at its value
                if on_bar(X(x)) != ref(x):
                    bad.append((x, ref(x)))
                    break
            for v, r, f in cs:
                if f != ref(v):
                    bad.append((v, ref(v)))
            for side, beyond in (("right", hi_ + (hi_ - lo_)), ("left", lo_ - (hi_ - lo_))):
                has = any(d == side for _, _, d in rays)
                if has != bool(ref(beyond)):
                    out.append("drawn set disagrees with the inequality past the "
                               "%s end of the line (%s: %s there, the drawing: %s "
                               "— %s ray arrow) — draw it with from_inequality(%r)"
                               % (side, src, "in" if ref(beyond) else "out",
                                  "in" if has else "out",
                                  "a" if has else "no", src))
        for x, want in bad[:1]:
            out.append("drawn set disagrees with the inequality at x=%s "
                       "(%s: %s, the drawing: %s) — draw it with "
                       "from_inequality(%r), which derives the circles and "
                       "rays" % (_num(x), src, "in" if want else "out",
                                 "in" if not want else "out", src))
    return out


# ======================================================= C5: more sweeps ===
_NUMTXT = re.compile(u"^[\\d+−.,]+$")


def _dashed_perp(M):
    """Dashed strokes across a horizontal axis (not connectors): (x, y0, y1)."""
    out = []
    for k in M.strokes:
        if k.tag != "line" or not k.dash or k.dash == CONNECT_DASH:
            continue
        (x1, y1), (x2, y2) = k.pts[0], k.pts[-1]
        if abs(x1 - x2) < 0.01 and abs(y1 - y2) > 0.5:
            out.append((x1, min(y1, y2), max(y1, y2)))
    return out


def _reference_lines(M, ay):
    """C5 (critic: reference). A dashed line across the axis runs at least
    REF_MIN_PT past it on one side -- a dash as short as a tick reads as a
    stray tick (the z01 q1 gauge). Its label stands centred over its far
    end, within 1.5 lines. Returns (problems, ids of the labels it owns)."""
    ppu = M.pt_per_unit
    out, owned = [], set()
    groups = []
    for x, y0, y1 in _dashed_perp(M):
        for g in groups:
            if abs(g[0] - x) < 0.6:
                g[1].append((y0, y1))
                break
        else:
            groups.append([x, [(y0, y1)]])
    band = TICK_LEN["major"] / 2.0 + 2.5
    for x, parts in groups:
        above = max([ay - y0 for y0, y1 in parts if y0 < ay - 0.1] or [0.0])
        below = max([y1 - ay for y0, y1 in parts if y1 > ay + 0.1] or [0.0])
        # a dashed piece that starts where a tick ends must run well past the
        # ticks; one that starts past the row of numbers is no tick to begin
        # with. The line itself must reach REF_MIN_PT on one side or it is
        # not a reference line at all (the z01 q1 one-sided dash)
        near = [(min(abs(y0 - ay), abs(y1 - ay)), max(abs(y0 - ay), abs(y1 - ay)),
                 1 if y0 + y1 < 2 * ay else -1) for y0, y1 in parts]
        # a piece with another piece of the same line beyond it is one span
        # CUT behind a label, not a short mark
        short = [f for n, f, sd in near if n <= band and
                 f * ppu < REF_MIN_PT - 0.05 and
                 not any(sd2 == sd and f2 > f + 0.5 for _, f2, sd2 in near)]
        if short or max(above, below) * ppu < REF_MIN_PT - 0.05:
            out.append("a dashed mark at %.1f runs %.1fpt from the axis — as "
                       "short as a tick it reads as a stray tick; a reference "
                       "line runs past the ticks (reference(v, both_sides=True))"
                       % (x, (max(short) if short else max(above, below)) * ppu))
        if above <= 0:
            continue
        top = ay - above
        cand = [t for t in M.texts if t.box and t.text.strip() and
                abs(t.centre()[0] - x) < 0.6 and t.box[3] <= top + 0.5]
        if cand:
            t = max(cand, key=lambda t: t.box[3])
            gap = top - t.box[3]
            if gap > 2.0 + 1.02 * t.size + 1.0:
                # v6.1: every other refusal in this file names the way out,
                # and this one did not. The line is too short to reach its
                # label at this size; the fixes that WORK are more room (the
                # thermometer passes at height=205 / tier='side') and a line
                # that runs both sides of the axis. Dropping the label is not
                # offered: that is the escape the author complained about.
                out.append("label %r floats %.1fpt over its reference line — "
                           "the line stops short of it at this size: give the "
                           "figure more room (a taller line, height= or a "
                           "wider tier=), or run the line past the axis "
                           "(reference(v, both_sides=True)). Keep the label"
                           % (t.text, gap * ppu))
            owned.add(id(t))
    return out, owned


def _bar_rects(M, ay):
    out = []
    for k in M.strokes:
        if not k.closed or k.tag not in ("path", "rect", "polygon") or \
                not svgcheck._light_fill(k.fill):
            continue
        P = k.pts
        if len(set((round(p[0], 2), round(p[1], 2)) for p in P)) != 4:
            continue
        xs, ys = [p[0] for p in P], [p[1] for p in P]
        if max(ys) > ay - 0.5 or max(ys) - min(ys) > 14.0:
            continue
        if any(min(abs(p[0] - min(xs)), abs(p[0] - max(xs))) > 0.01 or
               min(abs(p[1] - min(ys)), abs(p[1] - max(ys))) > 0.01 for p in P):
            continue
        out.append((min(xs), min(ys), max(xs), max(ys)))
    return sorted(out, key=lambda b: b[1])


def _bar_rows(M, ay, bars=None):
    """C5 (critic: bars_from_zero). Read from the SVG: every distance bar
    (a light rectangle with a dark outline over the axis) starts at 0, ends
    at its value (`bars`: [(value, letter)], top row first), prints at least
    BAR_MIN_PT long, and carries exactly one row letter left of the line,
    level with it. Returns (problems, ids of the row letters)."""
    rects = _bar_rects(M, ay)
    out, owned = [], set()
    if not rects and not bars:
        return out, owned
    ppu = M.pt_per_unit
    if bars is not None and len(bars) != len(rects):
        out.append("the drawing shows %d distance bar(s), the item declares %d"
                   % (len(rects), len(bars)))
    X = _scale(M, ay)
    x0 = X(0) if X else None
    horiz = [k for k in M.strokes if k.tag == "line" and not k.dash and
             abs(k.pts[0][1] - ay) < 0.01 and abs(k.pts[-1][1] - ay) < 0.01]
    left = min([min(p[0] for p in k.pts) for k in horiz] + [r[0] for r in rects])
    letters = [t for t in M.texts if t.box and t.text.strip() and
               t.box[2] < left + 0.5 and t.box[3] < ay]
    for i, b in enumerate(rects):
        L = (b[2] - b[0]) * ppu
        if L < BAR_MIN_PT - 0.02:
            out.append("a distance bar prints %.2fpt long, floor %gpt — it "
                       "cannot be seen" % (L, BAR_MIN_PT))
        cy = (b[1] + b[3]) / 2.0
        mine = [t for t in letters if abs(t.centre()[1] - cy) < 1.0]
        if len(mine) != 1:
            out.append("the bar row at y=%.1f carries %d row letters (one, "
                       "left of the line, keyed in the item)" % (cy, len(mine)))
        else:
            owned.add(id(mine[0]))
            if bars and i < len(bars) and mine[0].text.strip() != bars[i][1]:
                out.append("row letter %r stands where the item keys %r"
                           % (mine[0].text, bars[i][1]))
        if x0 is None:
            continue
        if min(abs(b[0] - x0), abs(b[2] - x0)) > 0.6:
            out.append("the bar at y=%.1f does not start at 0" % cy)
            continue
        far = b[2] if abs(b[0] - x0) <= abs(b[2] - x0) else b[0]
        if bars and i < len(bars):
            v = bars[i][0]
            if abs(X(v) - far) > 0.6:
                got = (far - x0) / (X(1) - x0)
                out.append("the bar of row %s ends at %s, not at its value %s"
                           % (bars[i][1], ("%.3g" % got).replace("-", MINUS),
                              _lab(v)))
    for t in letters:
        if id(t) not in owned and any(b[1] - 1 <= t.centre()[1] <= b[3] + 1
                                      for b in rects):
            owned.add(id(t))            # a second letter: refused above
    return out, owned


def _turn(M, fn=None, fbox=None, keep=None):
    """A copy of a model, every point through `fn` and every text box through
    `fbox` (text stays upright: a box is turned as a box); `keep(kind, item)`
    filters. Used to read a vertical line in its frame and to cut one row
    (or one scale) out of a figure."""
    fn = fn or (lambda p: p)
    fbox = fbox or (lambda b: b)
    keep = keep or (lambda kind, it: True)
    N = svgcheck.Model()
    N.pt_per_unit, N.view = M.pt_per_unit, M.view
    for k in M.strokes:
        if keep("stroke", k):
            N.strokes.append(svgcheck.Stroke([fn(p) for p in k.pts], k.closed,
                                             k.el, k.tag, k.width, k.fill, k.dash))
    for pts, closed, el in M.fills:
        if keep("fill", pts):
            N.fills.append(([fn(p) for p in pts], closed, el))
    for cx, cy, r, el in M.dots:
        if keep("dot", (cx, cy, r, el)):
            c = fn((cx, cy))
            N.dots.append((c[0], c[1], r, el))
    N.light = [(fn(a), fn(b)) for a, b in M.light if keep("light", (a, b))]
    N.shades = [[fn(p) for p in P] for P in M.shades if keep("shade", P)]
    for t in M.texts:
        if keep("text", t):
            N.texts.append(svgcheck.Text(t.text, [
                svgcheck.Run(r.text, r.size, fbox(r.box) if r.box else None,
                             fbox(r.ink) if r.ink else None) for r in t.runs],
                t.size, t.el))
    return N


_TURN = (lambda p: (-p[1], -p[0]))
_TURN_BOX = (lambda b: (-b[3], -b[2], -b[1], -b[0]))


def _axis_of(M):
    horiz = [s for s in M.strokes if s.tag == "line" and not s.dash and
             abs(s.pts[0][1] - s.pts[-1][1]) < 0.01]
    if not horiz:
        return None, []
    axis = max(horiz, key=lambda s: abs(s.pts[-1][0] - s.pts[0][0]))
    ay = axis.pts[0][1]
    ppu = M.pt_per_unit
    xs = sorted(s.pts[0][0] for s in M.strokes
                if s.tag == "line" and s.width <= 1.7 and not s.dash and
                abs(s.pts[0][0] - s.pts[-1][0]) < 0.01 and
                min(s.pts[0][1], s.pts[-1][1]) < ay - 0.5 < ay + 0.5 <
                max(s.pts[0][1], s.pts[-1][1]) and
                abs(s.pts[-1][1] - s.pts[0][1]) <= 16.0 / max(ppu / PX_TO_PT, 1e-6) + 0.1)
    return ay, xs


def dash_as_sign(svg, em=1.0):
    """Stage-1 fix r1 (PR1): a horizontal dark stroke that ENDS just before a
    number, on the number's own middle band, prints as a sign: reference(2) on
    a vertical line drew its number-side dash 1.9 units left of the '2', as
    long and heavy as the U+2212 of the '−2' further down, and the page read
    '−2' (and '−0', and '−−200'). Read on the finished SVG: any such stroke
    whose right end stands within `em` of a number's left edge is refused."""
    M = svg if isinstance(svg, svgcheck.Model) else svgcheck.model(svg)
    out = []
    nums = [t for t in M.texts if t.box and re.match(
        u"^[%s+]?[0-9]" % MINUS, t.text.strip())]
    for k in M.strokes:
        for a, b in k.segs():
            if abs(a[1] - b[1]) > 0.3 or abs(a[0] - b[0]) < 1.0:
                continue
            xr, y = max(a[0], b[0]), 0.5 * (a[1] + b[1])
            for t in nums:
                x0, y0, x1, y1 = t.box
                h = y1 - y0
                if (x0 - em * t.size <= xr <= x0 + 0.3 and
                        y0 + 0.25 * h <= y <= y1 - 0.15 * h):
                    out.append("a dash ends %.1fpt before the number %r on its "
                               "middle line — it prints as a sign in front of "
                               "it" % (max(0.0, x0 - xr) * M.pt_per_unit, t.text))
    return out


def sweep_v(svg, member=None, lo=None, hi=None, label_spacing=True,
            lengths=True, vote=True, merges=True, bars=None, signs=False,
            dots=None):
    """C5: a VERTICAL number line read from its SVG. The drawing is turned
    into its frame -- (x, y) -> (-y, -x), text boxes turned as boxes, text
    upright -- and read by `sweep` (ticks, numbers on their ticks, the value
    vote, tick lengths, arcs, heads, rims, carried labels, sets). Two rules
    are the vertical line's own: numbered ticks stand LABEL_V_SPACING lines
    apart (a number's height, not its width, is along the scale), and labels
    printed side by side stand 0.5 em apart, read on the drawing as printed.

    `dots` (the values the filled dots of this line stand for) runs
    svgcheck.dot_on_other_tick in the turned frame: C5 r2 switched the
    dot-on-its-value check off for a vertical line and put nothing in its
    place, so a point drawn a whole tick off passed every check -- the z01
    28-ב defect, upright."""
    M = svg if isinstance(svg, svgcheck.Model) else svgcheck.model(svg)
    if not any(k.tag == "line" and not k.dash and
               abs(k.pts[0][0] - k.pts[-1][0]) < 0.01 and k.width >= AXIS_W_LO
               for k in M.strokes):
        return ["no vertical axis"]
    Mr = _turn(M, _TURN, _TURN_BOX)
    out = sweep(Mr, member, lo, hi, label_spacing=False, lengths=lengths,
                vote=vote, merges=False, bars=None, signs=signs)
    out += dash_as_sign(M)
    if dots:
        out += svgcheck.dot_on_other_tick(Mr, list(dots))
    ay, xs = _axis_of(Mr)
    if ay is None:
        return out
    groups = _row_groups(Mr, ay, xs)
    ppu = M.pt_per_unit
    if label_spacing and len(groups) >= 2:
        pos = sorted(xs[j] for j in groups)
        size = max(t.size for g in groups.values() for t in g["texts"])
        d = min(b - a for a, b in zip(pos, pos[1:]))
        need = LABEL_V_SPACING * 1.02 * size
        if d * ppu < need * ppu - 0.05:
            out.append("numbered ticks %.1fpt apart, under %.1f lines (%.1fpt)"
                       % (d * ppu, LABEL_V_SPACING, need * ppu))
    if merges:
        els = set(t.el for g in groups.values() for t in g["texts"])
        out += _free_merges(M, set(id(t) for t in M.texts if t.el in els))
    return out


def double_sweep(svg, member=None, lo=None, hi=None, label_spacing=True,
                 lengths=True, vote=True, merges=True, bars=None, signs=False,
                 ratio=False):
    """C5: a DOUBLE number line read from its SVG -- one axis, one row of
    numbers under it and one over it. Each scale is cut out and read by
    `sweep` on its own (the upper row moved under the axis, its order kept,
    so a stacked fraction still reads numerator over denominator). Then:
    every tick carries exactly one entry above and one below (a number or a
    '?'), a '?' stands on a tick, and with `ratio` the tick that carries 0
    below carries 0 above."""
    M = svg if isinstance(svg, svgcheck.Model) else svgcheck.model(svg)
    ay, xs = _axis_of(M)
    if ay is None:
        return ["no axis"]
    top = [t for t in M.texts if t.box and t.box[3] < ay and
           (t.text.strip() == "?" or _NUMTXT.match(t.text.strip()))]
    qb = [t for t in M.texts if t.box and t.box[1] > ay and t.text.strip() == "?"]
    tops = set(id(t) for t in top) | set(id(t) for t in qb)

    def top_stroke(k):
        return k.tag == "line" and k.width <= 1.0 and not k.dash and \
            max(p[1] for p in k.pts) < ay - 0.5
    Mb = _turn(M, keep=lambda kind, it: not (kind == "text" and id(it) in tops)
               and not (kind == "stroke" and top_stroke(it)))
    out = sweep(Mb, member, lo, hi, label_spacing=label_spacing, lengths=False,
                vote=vote, merges=merges, bars=bars, signs=signs)
    if not top:
        return out + ["no second scale over the axis — a double number line "
                      "prints one row of numbers on each side"]
    nums = [t for t in top if t.text.strip() != "?"]
    qt = [t for t in top if t.text.strip() == "?"]
    sp = min([b - a for a, b in zip(xs, xs[1:])] or [0.0])
    gt = {}
    if nums:
        gap = ay - max(t.box[3] for t in nums)
        dy = ay + gap - min(t.box[1] for t in nums)
        mv = lambda p: (p[0], p[1] + dy)
        ids = set(id(t) for t in nums)

        def keep_t(kind, it):
            if kind == "text":
                return id(it) in ids
            if kind == "stroke":
                return top_stroke(it) or (it.tag == "line" and not it.dash and (
                    abs(it.pts[0][1] - it.pts[-1][1]) < 0.01 and
                    abs(it.pts[0][1] - ay) < 0.01 or
                    abs(it.pts[0][0] - it.pts[-1][0]) < 0.01 and
                    min(p[1] for p in it.pts) < ay < max(p[1] for p in it.pts)))
            return False
        Mt = _turn(M, keep=keep_t)
        # move the upper row (texts and its bars) under the axis
        for k in Mt.strokes:
            if max(p[1] for p in k.pts) < ay - 0.5:
                k.pts = [mv(p) for p in k.pts]
        Mt.texts = [svgcheck.Text(t.text, [svgcheck.Run(
            r.text, r.size, (r.box[0], r.box[1] + dy, r.box[2], r.box[3] + dy),
            (r.ink[0], r.ink[1] + dy, r.ink[2], r.ink[3] + dy) if r.ink else None)
            for r in t.runs], t.size, t.el) for t in Mt.texts]
        out += ["second scale: " + p for p in
                sweep(Mt, lengths=False, label_spacing=label_spacing, vote=vote)]
        gt = _row_groups(Mt, ay, xs)
    gb = _row_groups(Mb, ay, xs)
    tol = TICK_TOL * sp + 0.02
    on = lambda t, x: abs(t.centre()[0] - x) <= tol
    for t in qt + qb:
        if not any(on(t, x) for x in xs):
            out.append("'?' stands off every tick — it hides a number of a tick")
    for j, x in enumerate(xs):
        n_t = (1 if j in gt else 0) + sum(1 for t in qt if on(t, x))
        n_b = (1 if j in gb else 0) + sum(1 for t in qb if on(t, x))
        if n_t != 1 or n_b != 1:
            out.append("the tick at %.1f carries %d entr%s over the axis and %d "
                       "under it — a double number line pairs one number (or "
                       "'?') above with one below every tick"
                       % (x, n_t, "y" if n_t == 1 else "ies", n_b))
    if ratio:
        for j, g in gb.items():
            if g["value"] == 0 and j in gt and gt[j]["value"] != 0:
                out.append("a ratio line pairs 0 with 0, this one pairs 0 with "
                           "%s" % gt[j]["label"])
    return out


def _poly_at(cs, x):
    v = F(0)
    for c in cs:
        v = v * x + c
    return v


def sign_sweep(svg, poly=None):
    """C5: a sign chart read from its SVG. Every root circle has its number
    under it; every interval between two circles (and beyond the outer ones)
    carries exactly one sign, '+' or U+2212, clear of the circles; with
    `poly` (coefficients, highest power first) each sign is the polynomial's
    sign on its interval, at values read back from the numbers."""
    M = svg if isinstance(svg, svgcheck.Model) else svgcheck.model(svg)
    ay, xs = _axis_of(M)
    if ay is None:
        return ["no axis"]
    ppu = M.pt_per_unit
    out = []
    marks = sorted(set(round(m, 2) for m in _markers_x(M, ay)))
    if not marks:
        return ["a sign chart with no root circles"]
    horiz = [k for k in M.strokes if k.tag == "line" and not k.dash and
             abs(k.pts[0][1] - ay) < 0.01 and abs(k.pts[-1][1] - ay) < 0.01]
    ax0 = min(min(p[0] for p in k.pts) for k in horiz)
    ax1 = max(max(p[0] for p in k.pts) for k in horiz)
    signs = [t for t in M.texts if t.box and t.box[3] < ay and
             t.text.strip() in ("+", MINUS, "-")]
    for t in signs:
        if t.text.strip() == "-":
            out.append("sign '-' is the ASCII hyphen — print U+2212")
    groups = _row_groups(M, ay, xs)
    vals = []
    for m in marks:
        j = min(range(len(xs)), key=lambda i: abs(xs[i] - m)) if xs else None
        if j is None or abs(xs[j] - m) > 0.6 or j not in groups or \
                groups[j]["value"] is None:
            out.append("the root circle at %.1f has no number under it" % m)
            vals.append(None)
        else:
            vals.append(groups[j]["value"])
    rr = MARK_R_PT / ppu
    bounds = [ax0] + marks + [ax1]
    for i in range(len(bounds) - 1):
        a, b = bounds[i], bounds[i + 1]
        inside = [t for t in signs if a < t.centre()[0] < b]
        where = "%s..%s" % ("" if i == 0 else _lab(vals[i - 1]) if vals[i - 1] is not None else "?",
                            "" if i == len(bounds) - 2 else
                            _lab(vals[i]) if vals[i] is not None else "?")
        if len(inside) != 1:
            out.append("the interval %s carries %d signs — a sign chart prints "
                       "one sign over each interval between roots"
                       % (where, len(inside)))
            continue
        t = inside[0]
        if (i > 0 and t.box[0] < a + rr + 0.5) or \
                (i < len(bounds) - 2 and t.box[2] > b - rr - 0.5):
            out.append("sign %r over %s touches a root circle — it reads as that "
                       "root's" % (t.text, where))
        if poly is None:
            continue
        lv = vals[i - 1] if i > 0 else None
        rv = vals[i] if i < len(vals) else None
        if (i > 0 and lv is None) or (i < len(vals) and rv is None):
            continue
        x = (lv + rv) / 2 if i > 0 and i < len(vals) else \
            (rv - 1 if i == 0 else lv + 1)
        p = _poly_at([F(c) for c in poly], x)
        want = "+" if p > 0 else MINUS
        if p != 0 and t.text.strip().replace("-", MINUS) != want:
            out.append("sign %r over %s, where the polynomial is %s"
                       % (t.text, where, want))
    return out


def _axes_list(M):
    """Every number-line axis in a figure: a horizontal line of axis weight
    crossed by at least one tick. [(y, x0, x1)] top to bottom."""
    ppu = M.pt_per_unit
    ticks = [k for k in M.strokes if k.tag == "line" and not k.dash and
             k.width <= TICK_W_HI and abs(k.pts[0][0] - k.pts[-1][0]) < 0.01 and
             abs(k.pts[-1][1] - k.pts[0][1]) <= 16.0 / max(ppu / PX_TO_PT, 1e-6) + 0.1]
    got = {}
    for k in M.strokes:
        if k.tag != "line" or k.dash or not AXIS_W_LO <= k.width <= AXIS_W_HI or \
                abs(k.pts[0][1] - k.pts[-1][1]) > 0.01:
            continue
        y = k.pts[0][1]
        x0, x1 = sorted((k.pts[0][0], k.pts[-1][0]))
        if not any(min(t.pts[0][1], t.pts[-1][1]) < y - 0.5 and
                   max(t.pts[0][1], t.pts[-1][1]) > y + 0.5 and
                   x0 - 0.5 <= t.pts[0][0] <= x1 + 0.5 for t in ticks):
            continue
        key = round(y, 1)
        if key not in got or x1 - x0 > got[key][2] - got[key][1]:
            got[key] = (y, x0, x1)
    return sorted(got.values())


def _extent(kind, it):
    if kind == "stroke":
        ys = [p[1] for p in it.pts]
        return min(ys), max(ys)
    if kind == "text":
        return it.box[1], it.box[3]
    if kind == "dot":
        return it[1] - it[2], it[1] + it[2]
    ys = [p[1] for p in it]
    return min(ys), max(ys)


def stack_sweep(svg, shared=False, zoom=False, rows=None, connectors=True):
    """C5: a stack of number lines (stack(), zoom()) read from its SVG.

      * the rows are found as axes (a line of axis weight crossed by ticks),
        and cut apart at the widest clear band between two axes; less than
        ROW_CLEAR_PT of clear paper is refused (the rows touch);
      * each row is read by `sweep` on its own (`rows`: per-row keywords);
      * `shared`: every row maps a value to the same x as the first row,
        within 0.15 x the finer tick spacing;
      * every connector (a line dashed CONNECT_DASH) joins two adjacent rows,
        touches each (3pt), and the value it leaves on the upper row is the
        value it lands on in the lower one;
      * `zoom`: the upper row's shaded band covers exactly the lower row's
        numbered range, and two connectors leave the band's two ends --
        or, with `connectors=False` (zoom(..., connect=False)), none does."""
    M = svg if isinstance(svg, svgcheck.Model) else svgcheck.model(svg)
    ppu = M.pt_per_unit
    axes = _axes_list(M)
    if len(axes) < 2:
        return ["a stack needs two or more number lines; the drawing shows %d"
                % len(axes)]
    conns = [k for k in M.strokes if k.tag == "line" and k.dash == CONNECT_DASH]
    cid = set(id(k) for k in conns)
    items = [("stroke", k) for k in M.strokes if id(k) not in cid] + \
        [("text", t) for t in M.texts if t.box] + [("dot", d) for d in M.dots] + \
        [("fill", f[0]) for f in M.fills] + [("shade", P) for P in M.shades]
    ext = [(_extent(kd, it), kd, it) for kd, it in items]
    out, cuts = [], []
    for i in range(len(axes) - 1):
        a, b = axes[i][0], axes[i + 1][0]
        iv = sorted((max(y0, a), min(y1, b)) for (y0, y1), _, _ in ext
                    if y1 > a and y0 < b)
        cur, best = a, (0.0, (a + b) / 2.0)
        for y0, y1 in iv:
            if y0 > cur and y0 - cur > best[0]:
                best = (y0 - cur, (cur + y0) / 2.0)
            cur = max(cur, y1)
        if best[0] * ppu < ROW_CLEAR_PT - 0.05:
            out.append("rows %d and %d touch: %.1fpt of clear paper between "
                       "them (floor %gpt) — a decoration of one row reads as the "
                       "other's" % (i + 1, i + 2, best[0] * ppu, ROW_CLEAR_PT))
        cuts.append(best[1])
    bands = list(zip([-1e9] + cuts, cuts + [1e9]))
    band_of = lambda y: next(i for i, (p, q) in enumerate(bands) if p <= y < q)
    subs, lows, highs = [], [], []
    for i, (p, q) in enumerate(bands):
        def keep(kind, it, p=p, q=q):
            if kind == "stroke" and id(it) in cid:
                return False
            if kind == "light":
                y = (it[0][1] + it[1][1]) / 2.0
            else:
                y0, y1 = _extent(kind, it)
                y = (y0 + y1) / 2.0
            return p <= y < q
        subs.append(_turn(M, keep=keep))
        e = [y for (y0, y1), kd, it in ext for y in (y0, y1)
             if p <= (y0 + y1) / 2.0 < q]
        lows.append(max(e))
        highs.append(min(e))
    scales, sps = [], []
    for i, sub in enumerate(subs):
        kw = dict((rows[i] if rows and i < len(rows) else {}))
        out += ["row %d: %s" % (i + 1, p) for p in sweep(sub, **kw)]
        scales.append(_scale(sub, axes[i][0]))
        ay, xs = _axis_of(sub)
        sps.append(min([b - a for a, b in zip(xs, xs[1:])] or [1.0]))
    tol = TICK_TOL * min(sps) + 0.05
    if shared and scales[0]:
        for i in range(1, len(scales)):
            X0, Xi = scales[0], scales[i]
            if Xi is None:
                continue
            sub = subs[i]
            ay, xs = _axis_of(sub)
            vs = [g["value"] for g in _row_groups(sub, ay, xs).values()
                  if g["value"] is not None]
            for v in (min(vs), max(vs)):
                if abs(X0(v) - Xi(v)) > tol:
                    out.append("row %d is not on the shared scale: %s prints "
                               "%.1fpt from where row 1 puts it"
                               % (i + 1, _lab(v), abs(X0(v) - Xi(v)) * ppu))
                    break
    inv = lambda X, x: F(x - X(0)) / F(X(1) - X(0))
    ends = []
    for k in conns:
        (xa, ya), (xb, yb) = sorted((k.pts[0], k.pts[-1]), key=lambda p: p[1])
        i, j = band_of(ya), band_of(yb)
        if j != i + 1:
            out.append("a connector at x=%.1f does not join two adjacent rows"
                       % xa)
            continue
        if ya - lows[i] > 3.0 / ppu + 0.05 and not _touches(subs[i], xa, ya, 3.0 / ppu):
            out.append("a connector leaves row %d %.1fpt below its ink — it "
                       "floats" % (i + 1, (ya - lows[i]) * ppu))
        if highs[j] - yb > 3.0 / ppu + 0.05 and not _touches(subs[j], xb, yb, 3.0 / ppu):
            out.append("a connector stops %.1fpt short of row %d — it floats"
                       % ((highs[j] - yb) * ppu, j + 1))
        ends.append((xa, xb, i, j))
        if scales[i] and scales[j]:
            vi = inv(scales[i], xa)
            if abs(scales[j](float(vi)) - xb) > tol:
                vj = inv(scales[j], xb)
                out.append("a connector joins %s on row %d to %s on row %d — it "
                           "claims they are one value"
                           % (("%.4g" % float(vi)).replace("-", MINUS), i + 1,
                              ("%.4g" % float(vj)).replace("-", MINUS), j + 1))
    if zoom:
        sh = [P for P in M.shades if band_of(sum(p[1] for p in P) / len(P)) == 0]
        if len(sh) != 1:
            out.append("a zoom shades %d segments of the upper line (one)" % len(sh))
        elif scales[0] and len(subs) > 1:
            s0, s1 = min(p[0] for p in sh[0]), max(p[0] for p in sh[0])
            ay, xs = _axis_of(subs[1])
            vs = [g["value"] for g in _row_groups(subs[1], ay, xs).values()
                  if g["value"] is not None]
            if vs and (abs(scales[0](min(vs)) - s0) > tol or
                       abs(scales[0](max(vs)) - s1) > tol):
                out.append("the shaded band covers %s..%s of the upper line but "
                           "the lower line runs %s..%s — a zoom magnifies exactly "
                           "its band" % (("%.4g" % float(inv(scales[0], s0))).replace("-", MINUS),
                                         ("%.4g" % float(inv(scales[0], s1))).replace("-", MINUS),
                                         _lab(min(vs)), _lab(max(vs))))
            tops = sorted(e[0] for e in ends if e[2] == 0)
            # v6 open issues (C5r3-V2): zoom(connect=False) drew no connectors
            # and this rule, demanding two, refused the builder's own drawing
            if not connectors:
                if tops:
                    out.append("a zoom declared without connectors (connect="
                               "False) carries %d" % len(tops))
            elif len(tops) != 2 or abs(tops[0] - s0) > tol or abs(tops[1] - s1) > tol:
                out.append("a zoom's two connectors leave the ends of its shaded "
                           "band (found %d)" % len(tops))
    return out


def _touches(M, x, y, lim):
    """Is there ink of this row within `lim` of (x, y)?"""
    for k in M.strokes:
        for a, b in zip(k.pts, k.pts[1:]):
            if svgcheck._pt_seg((x, y), a, b) <= lim:
                return True
    for t in M.texts:
        if t.box and svgcheck._box_seg_dist(t.box, (x, y), (x, y)) <= lim:
            return True
    for cx, cy, r, _ in M.dots:
        if math.hypot(cx - x, cy - y) <= r + lim:
            return True
    return False


# ===================================================== C5: rows of lines ===
_SVG_OPEN = re.compile(r"^\s*<svg\b[^>]*>")
_COMMENT = re.compile(r"<!--[^>]*-->")


def _body_of(svg):
    """One rendered line's body, its <svg> wrapper and comments dropped."""
    s = _SVG_OPEN.sub("", svg)
    s = s[:s.rindex("</svg>")]
    return _COMMENT.sub("", s)


def _attr(svg, name):
    return float(re.search(r'<svg[^>]*\b%s="([\d.]+)"' % name, svg).group(1))


class Stack(object):
    """Number lines under one another: `stack(rows, ...)` and `NL.zoom(...)`.

    The rows are drawn and checked one by one, then composed into ONE figure
    so the alignment can be drawn (and read back). `scale='shared'` fits every
    row to one unit and puts a value at the same x on every row;
    `scale='own'` fits each row to the width. `connect=[values]` draws dashed
    connectors between adjacent rows at those values (a shared scale only).
    `captions` come back as an HTML column from `html()`, so Hebrew stays out
    of the SVG."""

    def __init__(self, rows, scale=None, captions=None, connect=(), tier=None,
                 width=None, fam=None, _zoom=None):
        rows = list(rows)
        if len(rows) < 2:
            raise AssertionError("numberline.stack: two or more rows")
        for r in rows:
            if not isinstance(r, NL):
                raise AssertionError("numberline.stack: a row is %r, not an NL"
                                     % type(r).__name__)
            if r.orientation == "v":
                raise AssertionError("numberline.stack: rows are horizontal "
                                     "lines (a vertical line stands alone)")
        if scale is None:
            if len(set((r.lo, r.hi) for r in rows)) == 1:
                scale = "shared"
            else:
                raise AssertionError(
                    "numberline.stack: the rows do not share a scale (%s) — "
                    "pass scale='own' (each row fitted to the width, read on "
                    "its own numbers) or scale='shared' (one unit, every row "
                    "aligned by value)"
                    % "; ".join("%s..%s" % (_num(r.lo), _num(r.hi)) for r in rows))
        if scale not in ("shared", "own"):
            raise AssertionError("numberline.stack: scale=%r — 'shared' or "
                                 "'own'" % (scale,))
        self.rows, self.scale, self.fam = rows, scale, fam
        self.zoom = _zoom
        self.connect = [_F(v, "connect value") for v in (connect or ())]
        if self.connect and scale != "shared":
            raise AssertionError(
                "numberline.stack: connectors join EQUAL values, which stand "
                "at one x only on a shared scale — pass scale='shared', or "
                "zoom() for a magnified row with its own scale")
        for v in self.connect:
            if not any(r.lo <= v <= r.hi and q.lo <= v <= q.hi
                       for r, q in zip(rows, rows[1:])):
                raise AssertionError(
                    "numberline.stack: the connector value %s is not on two "
                    "rows that stand next to each other — a connector joins "
                    "one row to the next" % _num(v))
        if captions is not None and len(list(captions)) != len(rows):
            raise AssertionError("numberline.stack: %d rows but %d captions — "
                                 "one caption per row (None for no caption)"
                                 % (len(rows), len(list(captions))))
        self.captions = list(captions) if captions is not None else None
        self.tier = tier or max(rows, key=lambda r: TIERS[r.tier]).tier
        self.width = width
        self._svg = None
        self._caps_y = []

    # -- geometry ------------------------------------------------------------
    def _measure(self, unit, vmin):
        offs, vbs = [], []
        for r in self.rows:
            r._labset = set(r.labelled)
            r._pick_k(unit)
            body, vb = r._layout(unit, 1.0)
            offs.append(r._geo["ox"] - float(r.lo - vmin) * unit)
            vbs.append(vb)
        base = max(offs)
        ts = [base - o for o in offs]
        return max(t + vb[2] for t, vb in zip(ts, vbs)), ts

    def _build(self):
        """v6 P2 r1 (P2-L1-01): a stack refused at its width is told the
        wider tier at which the same rows render (a row of an item stack
        was told 'use a shorter range' of its own, which a shared scale
        cannot take). Tried only for the refusal raised, never inside a
        trial."""
        try:
            return self._build_now()
        except AssertionError as e:
            if _SPLITTING or getattr(self, "_trial", False) or self.width \
                    or self.zoom:
                raise
            import copy
            for t in ("side", "block", "strip"):
                if TIERS[t] <= TIERS.get(self.tier, 0.0) + 1e-6:
                    continue
                _SPLITTING.append(1)
                try:
                    rows = []
                    for r in self.rows:
                        c = copy.deepcopy(r)
                        c.unit = r._ctor_all.get("unit") if hasattr(
                            r, "_ctor_all") else None
                        c._trial = True
                        rows.append(c)
                    trial = Stack(rows, scale=self.scale, connect=self.connect,
                                  tier=t, fam=self.fam)
                    trial._trial = True
                    trial._build_now()
                except AssertionError:
                    continue
                finally:
                    _SPLITTING.pop()
                raise AssertionError(
                    "%s -- the same rows render as a wider stack: "
                    "N.stack([...], tier=%r)" % (e, t))
            split = self._row_split_tried()
            if split:
                raise AssertionError(
                    "%s -- inside a stack a row's own width is fixed, so the "
                    "row has to carry fewer jumps: %s renders" % (e, split))
            raise

    def _row_split_tried(self):
        """v6 P2 r2 (P2R2-03): inside a Stack the row advice is switched off
        (the stack fixes the row's unit) and the wider-stack suffix is only
        added when a wider tier renders -- so a stack whose ROW still needs
        splitting refused with a bare symptom and no fix, the dead end an
        author reaches by following the engine's own advice to stack and then
        editing the rows. Split one row's walk in two and name the whole
        stack, once it renders."""
        import copy
        if _SPLITTING or getattr(self, "_trial", False) or self.zoom:
            return ""
        _SPLITTING.append(1)
        try:
            for idx, r in enumerate(self.rows):
                js = [j for j in r._decos if j["kind"] == "jump"]
                if len(js) < 2 or not hasattr(r, "_ctor_all"):
                    continue
                order = r._chain_order(js)
                if not all(float(a_["b"]) == float(b_["a"])
                           for a_, b_ in zip(order, order[1:])):
                    continue
                walk = [order[0]["a"]] + [j["b"] for j in order]
                mid = len(order) // 2
                for t in [self.tier] + [w for w in ("side", "block", "strip")
                                        if TIERS[w] > TIERS.get(self.tier, 0.0)
                                        + 1e-6]:
                    for cut in sorted(range(1, len(order)),
                                      key=lambda k: (abs(k - mid), k)):
                        got = self._row_split_at(idx, r, walk, order, cut, t)
                        if got:
                            return got
        finally:
            _SPLITTING.pop()
        return ""

    def _row_split_at(self, idx, r, walk, order, cut, tier=None):
        import copy
        tier = tier or self.tier
        bs = [0, cut, len(order)]
        rows, srcs = [], []
        for q in (0, 1):
            vals = walk[bs[q]:bs[q + 1] + 1]
            jj = order[bs[q]:bs[q + 1]]
            labs = [j["label"] for j in jj]
            lab = labs if any(labs) else None
            try:
                rows.append(r._split_row(
                    r.tier, q == 0, lambda t, v=vals, l=lab: t.chain(v, l)))
            except AssertionError:
                return ""
            srcs.append(r._row_src(r.tier, q == 0, ".chain([%s]%s)" % (
                ", ".join(_pyn(v) for v in vals),
                ", [%s]" % ", ".join(repr(str(l)) for l in labs)
                if lab else "")))
        others, osrc = [], []
        for x in self.rows:
            c = copy.deepcopy(x)
            c._trial, c.unit = True, None
            others.append(c)
            osrc.append(x._whole_call_src(x.tier)
                        if hasattr(x, "_ctor_all") else "...")
        try:
            trial = Stack(others[:idx] + rows + others[idx + 1:],
                          scale=self.scale, connect=self.connect,
                          tier=tier, fam=self.fam)
            trial._trial = True
            trial._build_now()
        except AssertionError:
            return ""
        return "N.stack([%s]%s)" % (
            ", ".join(osrc[:idx] + srcs + osrc[idx + 1:]),
            "" if tier == self.tier else ", tier=%r" % tier)

    def _build_now(self):
        W = float(self.width or TIERS[self.tier])
        svgs, ts = [], []
        if self.scale == "shared":
            vmin = min(r.lo for r in self.rows)
            span = float(max(r.hi for r in self.rows) - vmin)
            unit = max((W - 60.0) / span, 1e-3)
            for _ in range(6):
                wide, ts = self._measure(unit, vmin)
                if abs(wide - W) < 0.25 and wide <= W + 1e-6:
                    break
                unit = max(unit + (W - 0.2 - wide) / span, 1e-3)
            wide, ts = self._measure(unit, vmin)
            for r in self.rows:
                r.unit = unit
                svgs.append(r.render())
        else:
            for r in self.rows:
                svgs.append(r.render(width=W))
            ts = [0.0] * len(self.rows)
            wide = max(_attr(s, "width") for s in svgs)
        gap = ROW_GAP + (6.0 if self.zoom else 0.0)
        ys, y = [], 0.0
        for s in svgs:
            ys.append(y)
            y += _attr(s, "height") + gap
        H = y - gap
        self._caps_y = [ys[i] + self.rows[i]._geo["oy"]
                        for i in range(len(self.rows))]
        parts = []
        for k, (r, s, t, yy) in enumerate(zip(self.rows, svgs, ts, ys)):
            # v6.5 X2 r1 (MUST-4): every row draws `tick-0`, `seg-axis` ...;
            # in ONE file each id gets its row's prefix, the same prefix
            # export.compose() gives the row's objects
            body = re.sub(r'\bid="([^"]+)"',
                          lambda m, k=k: 'id="r%d-%s"' % (k + 1, m.group(1)),
                          _body_of(s))
            parts.append('<g transform="translate(%.2f,%.2f)">%s</g>'
                         % (t, yy, body))
        parts += self._connectors(ts, ys)
        svg = ('<svg xmlns="http://www.w3.org/2000/svg" width="%.2f" '
               'height="%.2f" viewBox="0 0 %.2f %.2f">%s</svg>'
               % (wide, H, wide, H, "".join(parts)))
        if self.fam:
            import figkit
            svg = figkit.tag(svg, self.fam)
        else:
            svg = svg.replace(">", "><!--fam:%s-->" % self.fam_key(), 1)
        if any(r.critique for r in self.rows):
            svg = svg.replace("-->", "--><!--critique:find_error-->", 1)
        # v6.5 X2 r1 (MUST-4): the stack is ONE figure of the deliverable,
        # stamped BEFORE the sweeps so they read the very file that ships,
        # recorded like every other: its rows' objects and constraints in
        # the composed file's frame, verified against it, re-measured on it
        obs = [getattr(r, "objects", None) for r in self.rows]
        if all(o is not None for o in obs):
            ex = export.compose(
                [(o, "r%d-" % (k + 1), (t, yy))
                 for k, (o, t, yy) in enumerate(zip(obs, ts, ys))],
                kindname="numberline.zoom" if self.zoom else "numberline.stack",
                view={"width_px": float("%.2f" % wide),
                      "height_px": float("%.2f" % H), "unit_px": 1.0,
                      "viewbox": [float("%.2f" % wide), float("%.2f" % H)],
                      "rotate": 0},
                fam=self.fam or self.fam_key())
            export.verify(svg, ex, "numberline.stack")
            export.recheck(svg, ex, "numberline.stack",
                           lenient=bool(ex.critique))
            with export.replay(self._replay_src()):
                svg = export.stamp(svg, ex, export.callsite())
            self.objects = ex
        svgcheck.assert_clean(svg, "numberline.stack", ticks=False, dots=False,
                              marks=False, minus=True, irregular=True)
        rows_kw = [dict(lengths=not (r.sparse or r.sketch), vote=not r.critique,
                        bars=r._bars or None, signs=bool(r._signs))
                   for r in self.rows]
        bad = stack_sweep(svg, shared=self.scale == "shared",
                          zoom=bool(self.zoom), rows=rows_kw,
                          connectors=not self.zoom or bool(self.zoom[3]))
        if bad:
            raise AssertionError("numberline.stack_sweep: %s" % "; ".join(bad))
        self._svg = svg

    def _column(self, r, t, yy, v, below):
        """Where a connector meets a row at value `v`: just past the ink of
        its column. Everything in that column must stand centred on `v` (a
        tick, its number, a marker, a letter): a connector that stopped at a
        jump arc crossing the column would point at the arc."""
        g = r._geo
        xf = (float(v) - float(g["lo"])) * g["unit"]
        E = g["canvas"]
        edges, joined = [], False
        for z, i, (fmt, pts, extra), P, box in E.els:
            # a white knock-out stroke is no ink; a white-filled marker is
            if z == 0 or 'stroke="#fff"' in fmt:
                continue
            if box[2] < xf - 1.5 or box[0] > xf + 1.5:
                continue
            if box[1] <= 0.0 <= box[3]:
                joined = joined or (abs((box[0] + box[2]) / 2.0 - xf) < 0.6) or \
                    (box[0] < xf < box[2] and fmt.startswith("<line") and
                     abs(box[2] - box[0]) < 2.0)
                # v6.0 deliverables: a marker ON the axis at v (a set's end
                # circle, a point) is part of the column too. The connector
                # used to stop 2px from the axis, inside the ring, and
                # assert_clean refused the stack ("a stroke is painted over the
                # marker") -- so a compound-set stack joined at its boundaries
                # could not be drawn at all. It now stops at the rim.
                if abs((box[0] + box[2]) / 2.0 - xf) < 0.6 and \
                        box[2] - box[0] >= 2.0:
                    edges.append(box[3] if below else box[1])
                continue
            if (box[1] > 0) != below:
                continue
            centred = abs((box[0] + box[2]) / 2.0 - xf) < 0.6 or \
                (fmt.startswith("<line") and abs(box[3] - box[1]) < 1.5 and
                 box[3] <= r._row[1] + 1.0)
            if not centred:
                raise AssertionError(
                    "numberline.stack: the connector at %s would run into a "
                    "decoration of the row %s..%s that does not stand on %s — "
                    "connect a value whose column is clear (the rows stay "
                    "aligned without a connector), or draw that decoration on "
                    "another row" % (_num(v), _num(r.lo), _num(r.hi), _num(v)))
            edges.append(box[3] if below else box[1])
        if not joined:
            raise AssertionError(
                "numberline.stack: the connector at %s joins nothing on the row "
                "%s..%s — it has no tick and no point there (its ticks are "
                "every %s). Connect a value both rows draw, or mark %s on that "
                "row (point(%s))" % (_num(v), _num(r.lo), _num(r.hi),
                                     _num(r.tick), _num(v), _pyn(v)))
        edge = (max(edges) if below else min(edges)) if edges else 0.0
        y = edge + (2.0 if below else -2.0)
        return t + g["ox"] + xf, yy + g["oy"] + y

    def _connectors(self, ts, ys):
        out = []
        if self.zoom:
            a, b, _, on = self.zoom
            if not on:
                return out
            p, c = self.rows[0], self.rows[1]
            for v in (a, b):
                x0 = ts[0] + p._geo["ox"] + (float(v) - float(p.lo)) * p._geo["unit"]
                x1 = ts[1] + c._geo["ox"] + (float(v) - float(c.lo)) * c._geo["unit"]
                out.append(self._dash((x0, ys[0] + p._geo["vb"][3] - MARGIN + 2.0),
                                      (x1, ys[1] + MARGIN - 2.0)))
            return out
        for v in self.connect:
            for i in range(len(self.rows) - 1):
                r, q = self.rows[i], self.rows[i + 1]
                if not (r.lo <= v <= r.hi and q.lo <= v <= q.hi):
                    continue
                p0 = self._column(r, ts[i], ys[i], v, True)
                p1 = self._column(q, ts[i + 1], ys[i + 1], v, False)
                out.append(self._dash(p0, p1))
        return out

    @staticmethod
    def _dash(p0, p1):
        return ('<line x1="%.2f" y1="%.2f" x2="%.2f" y2="%.2f" stroke="%s" '
                'stroke-width="0.90" stroke-dasharray="%s"/>'
                % (p0[0], p0[1], p1[0], p1[1], INK, CONNECT_DASH))

    def _replay_src(self):
        """The stack as source (spec rule 6), or None (a zoom, or a row whose
        values have no source)."""
        if self.zoom:
            return None
        lines = ["import numberline"]
        for k, r in enumerate(self.rows):
            rl = r._replay_lines("r%d" % (k + 1))
            if rl is None:
                return None
            lines += rl
        kw = {"scale": self.scale, "captions": self.captions,
              "connect": list(self.connect), "tier": self.tier,
              "width": self.width, "fam": self.fam}
        kw = dict((k, v) for k, v in kw.items() if v is not None)
        src = export.call_src("numberline", "stack", (), kw)
        if src is None:
            return None
        rows = "[%s]" % ", ".join("r%d" % (k + 1)
                                  for k in range(len(self.rows)))
        src = src.replace("numberline.stack(", "numberline.stack(%s%s"
                          % (rows, ", " if kw else ""), 1)
        return "\n".join(lines + ["svg = %s.svg()" % src])

    # -- output --------------------------------------------------------------
    def fam_key(self):
        h = hashlib.sha1(repr([r.fam_key() for r in self.rows] +
                              [str(v) for v in self.connect] +
                              [repr(self.zoom)]).encode("utf-8")).hexdigest()[:10]
        return "numberline.%s[%d,%s]{%s}" % ("zoom" if self.zoom else "stack",
                                             len(self.rows), self.scale, h)

    def svg(self, width=None):
        if width is not None:
            self.width, self._svg = width, None
        if self._svg is None:
            self._build()
        return self._svg

    def html(self):
        """The figure with its captions as an HTML column beside it (Hebrew
        belongs in the HTML, never in the SVG: G49)."""
        return _caption_html(self.svg(), self._caps_y, self.captions)

    @property
    def child(self):
        return self.rows[-1]

    @property
    def parent(self):
        return self.rows[0]


def stack(rows, scale=None, captions=None, connect=(), tier=None, width=None,
          fam=None):
    """Number lines under one another, aligned. See `Stack`."""
    return Stack(rows, scale=scale, captions=captions, connect=connect,
                 tier=tier, width=width, fam=fam)


def _caption_html(svg, ys, captions):
    if not captions:
        return svg
    H = _attr(svg, "height")
    cells, prev = [], 0.0
    for y, c in zip(ys, captions):
        if not c:
            continue
        top = max(prev, y - 7.0)
        cells.append('<div style="height:14px;line-height:14px;margin-top:%.1fpx;'
                     'white-space:nowrap">%s</div>' % (top - prev, c))
        prev = top + 14.0
    return ('<table class="nlstack" style="border-collapse:collapse;'
            'margin:0 auto"><tr>'
            '<td style="padding:0 0 0 6pt;vertical-align:top;font-size:9pt">'
            '<div style="height:%.1fpx">%s</div></td>'
            '<td style="padding:0;vertical-align:top">%s</td></tr></table>'
            % (H, "".join(cells), svg))


# ================================================== C5: the double line ===
class Double(object):
    """A double number line: one axis, `scale_b` numbered under it and
    `scale_a` over it, `parts` equal steps on both. Ratio, percent and unit
    conversion items read one scale off the other."""

    def __init__(self, nl, captions=None, call=None):
        self.nl, self.captions = nl, list(captions) if captions else None
        self._call = call
        if self.captions is not None and len(self.captions) != 2:
            raise AssertionError("numberline.double: captions=(over the axis, "
                                 "under it)")

    def svg(self, width=None):
        try:
            return self.nl.svg(width)
        except AssertionError as e:
            msg = str(e)
            if self._call is None or not msg.startswith("numberline: ") or \
                    " apart" not in msg.split(" — ")[0]:
                raise
            raise AssertionError(self._floor_fix(msg, width))

    def _floor_fix(self, msg, width):
        """v6.0 deliverables: the floor refusal of the inner line named
        label_every= and tick=, which double() does not take -- the author
        could not type the fix back. Name the double() knobs instead, and only
        the calls that render: a wider tier, then fewer parts (keeping every
        hidden value and every stated pair on the scale)."""
        call = dict(self._call)
        tries = []
        order = ["item", "side", "block", "strip"]
        if width is None and call.get("width") is None:
            for t in order[order.index(call["tier"]) + 1:]:
                tries.append(("tier=%r" % t, dict(call, tier=t)))
        parts = call["parts"]
        for p in range(parts - 1, 1, -1):
            if parts % p:
                continue
            tries.append(("parts=%d" % p, dict(call, parts=p)))
        works = []
        for text, kw in tries:
            try:
                d = double(**kw)
                d._call = None
                d.svg(width)
            except AssertionError:
                continue
            works.append(text)
            if len(works) == 2:
                break
        head = msg.split(" — ")[0].replace("numberline:", "numberline.double:", 1)
        if works:
            fix = " or ".join(works) + " (each renders)"
        else:
            fix = "shorter scales (neither a wider tier nor fewer parts renders)"
        return "%s — %s; never a smaller font" % (head, fix)

    def html(self, width=None):
        s = self.svg(width)
        g = self.nl._geo
        row = self.nl._row
        return _caption_html(s, [g["oy"] - row[0] - 5.0, g["oy"] + row[1] - 5.0],
                             self.captions)


def _double_parts(lb, hb, parts, lim=20):
    """A number of equal parts, near `parts` and at most `lim`, whose step
    divides both ends of scale_b (so every part IS a tick of the axis), or
    None. C5 r2: named in the refusal below."""
    ok = [p for p in range(2, lim + 1)
          if (lb * p / (hb - lb)).denominator == 1 and
          (hb * p / (hb - lb)).denominator == 1]
    return min(ok, key=lambda p: (abs(p - parts), p)) if ok else None


def double(scale_a, scale_b, parts, hide_a=(), hide_b=(), pairs=(), ratio=True,
           tier="block", width=None, captions=None, fam=None, label_fmt="auto"):
    """A double number line for ratio, percent and unit problems.

        double((0, 80), (0, 100), 10, hide_a=[24], captions=("ק\"מ", "%"))

    `scale_a` prints over the axis, `scale_b` under it, both in `parts` equal
    steps. `hide_a` / `hide_b` print '?' instead of a value (what the item
    asks). `pairs` are the pairs the item states: each must be a pair this
    line actually draws. `ratio=True` (the default) demands 0 against 0."""
    (la, ha), (lb, hb) = (_F(scale_a[0]), _F(scale_a[1])), \
        (_F(scale_b[0]), _F(scale_b[1]))
    if not isinstance(parts, int) or parts < 2:
        raise AssertionError("numberline.double: parts=%r — a whole number >= 2 "
                             "of equal steps" % (parts,))
    for lo, hi, who in ((la, ha, "scale_a"), (lb, hb, "scale_b")):
        if not lo < hi:
            raise AssertionError("numberline.double: %s runs %s..%s — from the "
                                 "smaller value to the larger"
                                 % (who, _num(lo), _num(hi)))
    if ratio and (la != 0 or lb != 0):
        raise AssertionError(
            "numberline.double: a ratio or percent line pairs 0 with 0, and "
            "this one starts at %s over %s — start both scales at 0, or pass "
            "ratio=False for two scales that are linear but not proportional "
            "(°C and °F)" % (_num(la), _num(lb)))
    ta, tb = (ha - la) / parts, (hb - lb) / parts
    # the axis is numbered from scale_b, and a line's ticks stand at multiples
    # of its step from 0 (E13). C5 r2: with ends that are not multiples of the
    # step the line drew OTHER numbers than the parts asked for -- 36, 54, ...
    # for a 32..212 scale in 10 parts -- and only the generic second-scale
    # sweep complained, twelve times and without a fix
    if (lb / tb).denominator != 1 or (hb / tb).denominator != 1:
        off = lb if (lb / tb).denominator != 1 else hb
        first = math.ceil(lb / tb) * tb
        fixes = []
        if (la / ta).denominator == 1 and (ha / ta).denominator == 1:
            fixes.append(
                "swap the scales — double((%s, %s), (%s, %s), %d%s) numbers the "
                "axis from the scale that does fall on ticks and prints this "
                "one over it (hide_a/hide_b, pairs= and captions= swap with "
                "them)" % (_num(lb), _num(hb), _num(la), _num(ha), parts,
                           "" if ratio else ", ratio=False"))
        p2 = _double_parts(lb, hb, parts)
        if p2:
            fixes.append("parts=%d (a step of %s, which divides both ends)"
                         % (p2, _num((hb - lb) / p2)))
        fixes.append("or move scale_b's ends to multiples of its step")
        raise AssertionError(
            "numberline.double: the axis is numbered from scale_b, whose ticks "
            "stand at multiples of the step from 0 — %s..%s in %d parts steps "
            "by %s, and %s is not a multiple of it, so the line would print "
            "%s, %s, ... instead of %s, %s, ... — %s"
            % (_num(lb), _num(hb), parts, _num(tb), _num(off), _num(first),
               _num(first + tb), _num(lb), _num(lb + tb), "; ".join(fixes)))
    for va, vb in pairs:
        va, vb = _F(va, "pair"), _F(vb, "pair")
        ka, kb = (va - la) / ta, (vb - lb) / tb
        if ka != kb or ka.denominator != 1 or not 0 <= ka <= parts:
            says = None
            if ka.denominator == 1 and 0 <= ka <= parts:
                says = "%s pairs with %s" % (_num(va), _num(lb + tb * ka))
            elif kb.denominator == 1 and 0 <= kb <= parts:
                says = "%s pairs with %s" % (_num(vb), _num(la + ta * kb))
            raise AssertionError(
                "numberline.double: the pair (%s, %s) is not a pair this line "
                "draws — %s; change the scales, or parts="
                % (_num(va), _num(vb), says if says else
                   "neither value stands on one of its %d steps" % parts))
    nl = NL(lb, hb, tick=tb, label_every=1, tier=tier, width=width, fam=fam,
            label_fmt=label_fmt)
    vals_a = [la + ta * i for i in range(parts + 1)]
    fmt_a = nl._auto_fmt(vals_a) if label_fmt == "auto" else label_fmt
    hid_a = [_F(v, "hide_a") for v in hide_a]
    hid_b = [_F(v, "hide_b") for v in hide_b]
    for v in hid_a:
        if v not in vals_a:
            raise AssertionError("numberline.double: hide_a=%s is not a number "
                                 "of scale_a (%s)"
                                 % (_num(v), ", ".join(_num(x) for x in vals_a)))
    for v in hid_b:
        if v not in nl.labelled:
            raise AssertionError("numberline.double: hide_b=%s is not a number "
                                 "of scale_b" % _num(v))
    # C5 r3: both halves of one pair hidden leaves a tick with '?' over the
    # axis and '?' under it — a pair with nothing to read it from. svgcheck
    # refused it, but as a stray '?' in the row of numbers, naming a fix
    # (move the label) that belongs to this builder and not to its caller
    for i in range(parts + 1):
        vb = lb + tb * i
        if vals_a[i] in hid_a and vb in hid_b:
            raise AssertionError(
                "numberline.double: the pair (%s, %s) is hidden on BOTH scales "
                "(hide_a=%s and hide_b=%s) — that tick carries '?' over the "
                "axis and '?' under it, and nothing is left to read the pair "
                "from. Hide one side of a pair: hide_a=[%s] (the item asks for "
                "the value over the axis) or hide_b=[%s] (it asks for the value "
                "under it)" % (_num(vals_a[i]), _num(vb), _num(vals_a[i]),
                               _num(vb), _num(vals_a[i]), _num(vb)))
    nl._top = [(lb + tb * i, ("text", "?") if vals_a[i] in hid_a
                else ("value", vals_a[i], fmt_a)) for i in range(parts + 1)]
    nl._hide_b = hid_b
    nl.wrong_scale += [(v, "?") for v in hid_b]
    nl._ratio = ratio
    nl._key("double", la, ha, parts, tuple(_num(v) for v in hid_a),
            tuple(_num(v) for v in hid_b))
    return Double(nl, captions, call=dict(
        scale_a=scale_a, scale_b=scale_b, parts=parts, hide_a=hide_a,
        hide_b=hide_b, pairs=pairs, ratio=ratio, tier=tier, width=width,
        captions=captions, fam=fam, label_fmt=label_fmt))


# ================================================== C5: the sign chart ===
def sign_chart(roots, signs, closed=True, poly=None, touch=(), tier="side",
               width=None, fam=None, student_drawing=False, asks=None):
    """The sign chart of a polynomial: its roots as circles on a sketch line
    (filled where the inequality is weak), a '+' or U+2212 over each interval.

        sign_chart([-2, 3], ["+", "−", "+"], closed=False, poly=[1, -1, -6])

    `poly` (coefficients, highest power first) is checked: every root is a
    root, no root is missing, and every sign is the polynomial's own sign on
    its interval. Without it the signs must alternate, except at a root
    listed in `touch` (a double root).

    `student_drawing=True` with `asks=['find_error']` draws the chart WRONG on
    purpose, for an item that asks the reader to find the error (C5 r2: the
    sign rules refused such a chart, so it could not be drawn at all). It
    needs `poly=` -- the engine reads the chart against the polynomial, keeps
    every disagreement instead of refusing it, and refuses a chart that turns
    out to be RIGHT (the giveaway rule, L7)."""
    rs = [_F(r, "root") for r in roots]
    if not rs:
        raise AssertionError("numberline.sign_chart: no roots — a polynomial "
                             "with no real root keeps one sign; say that in the "
                             "item instead of drawing an empty chart")
    if sorted(rs) != rs or len(set(rs)) != len(rs):
        raise AssertionError("numberline.sign_chart: roots %s — in increasing "
                             "order, each once"
                             % ", ".join(_num(r) for r in rs))
    sg = []
    for s in signs:
        t = str(s).strip().replace("-", MINUS)
        if t not in ("+", MINUS):
            raise AssertionError("numberline.sign_chart: sign %r — '+' or '−'"
                                 % (s,))
        sg.append(t)
    if len(sg) != len(rs) + 1:
        raise AssertionError("numberline.sign_chart: %d roots cut the line into "
                             "%d intervals, %d signs given"
                             % (len(rs), len(rs) + 1, len(sg)))
    cl = list(closed) if isinstance(closed, (list, tuple)) else [closed] * len(rs)
    if len(cl) != len(rs):
        raise AssertionError("numberline.sign_chart: closed= is one flag, or "
                             "one per root")
    tch = [_F(t, "touch") for t in touch]
    # C5 r2: a chart drawn wrong on purpose keeps its disagreements with the
    # polynomial instead of being refused by them -- and must have at least one
    critique = bool(student_drawing)
    wrong = []

    def _refuse(msg):
        if critique:
            wrong.append(msg)
        else:
            raise AssertionError(msg + CRITIQUE_FIX)
    if critique and "find_error" not in [str(a) for a in (asks or [])]:
        raise AssertionError(
            "numberline.sign_chart: student_drawing=True draws a deliberately "
            "WRONG chart — declare it: sign_chart(..., poly=[...], "
            "student_drawing=True, asks=['find_error']), and give the question "
            "asks=['find_error'] too. A correct chart needs neither")
    if critique and poly is None:
        raise AssertionError(
            "numberline.sign_chart: student_drawing=True draws the chart wrong "
            "on purpose, and a wrong chart is only wrong against the "
            "polynomial it should have been read off — pass poly=[coefficients] "
            "(the engine then keeps the error instead of refusing it, and "
            "refuses a chart that is in fact right)")
    if poly is not None:
        cs = [_F(c, "coefficient") for c in poly]
        if len(cs) < 2 or cs[0] == 0:
            raise AssertionError("numberline.sign_chart: poly= is the "
                                 "coefficients, highest power first, the first "
                                 "not 0")
        for r in rs:
            v = _poly_at(cs, r)
            if v != 0:
                _refuse(
                    "numberline.sign_chart: p(%s) = %s, not 0 — %s is not a "
                    "root of this polynomial; list the roots it has"
                    % (_num(r), _num(v), _num(r)))
        # every real root lies inside the Cauchy bound, so a root left off
        # the chart is found wherever it is (not only near the listed ones)
        R = 1 + max(abs(c) for c in cs[1:]) / abs(cs[0])
        bounds = [min(rs[0], -R) - 1] + rs + [max(rs[-1], R) + 1]
        for i in range(len(bounds) - 1):
            a, b = bounds[i], bounds[i + 1]
            xs = [a + (b - a) * F(k, 64) for k in range(1, 64)]
            vs = [_poly_at(cs, x) for x in xs]
            if any(v == 0 for v in vs) or \
                    any((u > 0) != (v > 0) for u, v in zip(vs, vs[1:])):
                _refuse(
                    "numberline.sign_chart: the polynomial changes sign between "
                    "%s and %s — a root there is not listed; list every root"
                    % (_num(a), _num(b)))
            want = "+" if vs[0] > 0 else MINUS
            if want != sg[i]:
                _refuse(
                    "numberline.sign_chart: the polynomial is %s between %s and "
                    "%s, the chart says %s — the chart is read off the "
                    "polynomial" % (want, _num(a), _num(b), sg[i]))
    else:
        for i, r in enumerate(rs):
            flips = r not in tch
            if (sg[i] != sg[i + 1]) != flips:
                raise AssertionError(
                    "numberline.sign_chart: the sign %s at %s — a simple root "
                    "flips the sign and a double root does not. Pass poly=[...] "
                    "to have the chart read off the polynomial, or list %s in "
                    "touch=[...] if it is a double root"
                    % ("does not change" if flips else "changes", _num(r),
                       _num(r)) + CRITIQUE_FIX)
    if critique and not wrong:
        raise AssertionError(
            "numberline.sign_chart: this chart declares student_drawing=True "
            "but it is the CORRECT chart of p(x) — an item that asks the reader "
            "to find the error may not show the right answer (the giveaway "
            "rule). Draw the error the item is about (a sign not flipped at a "
            "root, a root left out, a value that is not a root), or drop "
            "student_drawing=")
    span = rs[-1] - rs[0]
    pad = max(span / 2, F(1))
    lo, hi = rs[0] - pad, rs[-1] + pad
    nl = NL(lo, hi, sketch=True, label_at=rs, tier=tier, width=width, fam=fam,
            student_drawing=student_drawing, asks=asks)
    for r, c in zip(rs, cl):
        nl.point(r, style="filled" if c else "open")
    mids = [(lo + rs[0]) / 2] + [(a + b) / 2 for a, b in zip(rs, rs[1:])] + \
        [(rs[-1] + hi) / 2]
    nl._signs = list(zip(mids, sg))
    # C5 r3: what is wrong with this chart, for the line's own giveaway rule
    nl._crit_why += list(wrong)
    nl._poly = [F(c) for c in poly] if poly is not None else None
    nl._key("signs", tuple(sg), tuple(_num(r) for r in rs), tuple(cl))
    return nl


# ============================================ C5: the critique contract ===
def critique_guard(q):
    """A figure drawn WRONG on purpose (student_drawing / wrong_scale) may
    stand only beside an item that asks the reader to find the error, and an
    item that asks for the error may not show the correct drawing beside it
    (the giveaway rule, L7).

    EVERY figure of the question is read: the question's own `fig` and the
    figure of each 4-tuple sub-item (`("א", text, space, fig)`). C5 r3: the
    guard ran on `q['fig']` only, so a wrong line shipped unguarded through
    the item-figure route — a route real levels use. `emit_html` calls this
    for a question that has a `fig`; `emit_plus` calls it for every question,
    before the 4-tuples are rewritten away."""
    figs = []
    if q.get("fig"):
        figs.append(("", str(q["fig"])))
    for it in (q.get("items") or []):
        if len(it) >= 4 and it[3]:
            figs.append((" item %s" % (it[0],), str(it[3])))
    asks = [str(a) for a in (q.get("asks") or [])]
    n = q.get("n", "?")
    for where, fig in figs:
        if "<!--critique:" in fig and "find_error" not in asks:
            raise AssertionError(
                "question %s%s shows a deliberately wrong number line "
                "(student_drawing / wrong_scale) but does not declare "
                "asks=['find_error'] — a wrong drawing beside an ordinary item "
                "reads as the answer. Add asks=['find_error'] to the question, "
                "or draw the line correctly" % (n, where))
    lines = [(w, f) for w, f in figs if "fam:numberline" in f]
    if "find_error" in asks and lines and \
            not any("<!--critique:" in f for _, f in lines):
        raise AssertionError(
            "question %s asks the reader to find the error but its number line "
            "is the correct drawing%s — draw the student's line "
            "(student_drawing=True / wrong_scale=[(v, '...')]), or drop "
            "asks=['find_error']"
            % (n, "" if len(lines) == 1 else
               " (none of its %d number lines is drawn wrong)" % len(lines)))


# ============================================================= selftest ===
def _selftest_cases():
    """(name, build) that must render clean, and (name, build, needle) that
    must be refused with the named fix."""
    Q, H = F(1, 4), F(1, 2)

    def sets(nl, fn):
        fn(nl)
        return nl.svg()

    def sets_nl(nl, src):
        nl.from_inequality(src)
        return nl

    good = [
        ("quarters -2..2", lambda: NL(-2, 2, tick=Q).svg()),
        ("points and letters", lambda: NL(0, 6).point(2, "A").point(3, "B")
         .point(4, "C", "open").svg()),
        ("x>=3.5", lambda: sets(NL(-1, 6, tick=H), lambda n: n.from_inequality("x>=3.5"))),
        ("2x+1<5", lambda: sets(NL(-3, 4), lambda n: n.from_inequality("2x+1<5"))),
        ("all reals", lambda: sets(NL(-3, 3), lambda n: n.from_inequality("2x+3<2x+5"))),
        ("open at lo", lambda: sets(NL(-1, 3), lambda n: n.interval(-1, 2, False))),
        ("chain -8,-3,-5", lambda: NL(-9, 1).chain([-8, -3, -5], ["+5", "-2"]).svg()),
        ("repeat 4x3", lambda: NL(0, 12).repeat(0, 3, 4, "+3").svg()),
        ("thirds frac", lambda: NL(0, 1, tick=F(1, 3), label_fmt="frac").svg()),
        ("halves mixed", lambda: NL(0, 3, tick=H, label_fmt="mixed", tier="block").svg()),
        ("-120 and -75", lambda: NL(-150, 150, tick=10, tier="strip").point(-120, "A")
         .point(-75, "B", between=True).svg()),
        ("symmetric 3", lambda: NL(-5, 5).symmetric(3).svg()),
        ("double arrow", lambda: NL(-200, 200, tick=50, tier="block")
         .double_arrow(0, 150, "150").svg()),
        ("bracket", lambda: NL(-6, 2).span(-5, 0, "5").point(-5, "P").svg()),
        ("sparse", lambda: NL(-3, 3, sparse=True, label_at=[-2, 1]).svg()),
        ("blank", lambda: NL(-6, 6, blank=True, tier="block").svg()),
        ("test markers", lambda: NL(0, 6).test_markers([(2, "x"), (4, "tri")]).svg()),
        ("union", lambda: sets(NL(-5, 5), lambda n: n.union(ray(-2, "left", False),
                                                           ray(3, "right")))),
        ("integers", lambda: sets(NL(-4, 4), lambda n: n.integers_in(solve("-2<x<=3")))),
        ("zero_emph plus_sign", lambda: NL(-4, 4, zero_emph=True, plus_sign=True)
         .point(-2, "A", value_label=True).svg()),
        ("decimals", lambda: NL(-1, 1, tick=F(1, 10), label_fmt="dec", tier="block")
         .point(F(-3, 4), "Q", between=True).svg()),
        ("domain", lambda: sets(NL(0, 12, tier="block"),
                                lambda n: n.from_inequality("3x<=24", domain=(0, 12)))),
        # C4 r2
        ("value label 1/3 stacked", lambda: NL(0, 1, tick=F(1, 3), label_fmt="frac",
                                               tier="block").point(F(1, 3), "A", value_label=True).svg()),
        ("jumps out of order", lambda: NL(-8, 1).jump(-4, -1, "+3").jump(-7, -4, "+3").svg()),
        ("overlapping jumps grounded", lambda: NL(0, 10, tier="block").jump(0, 5)
         .jump(4, 9).svg()),
        ("walk 0,5,2,6", lambda: NL(-1, 8, tier="block").chain([0, 5, 2, 6],
                                                          ["+5", "-3", "+4"]).svg()),
        ("square on thirds", lambda: NL(F(-4, 3), F(1, 3), tick=F(1, 3)).point(-1, "Q", "square").svg()),
        ("mixed tenths side", lambda: NL(F(-8, 5), F(1, 10), tick=F(1, 10), label_fmt="mixed").svg()),
        ("set end named open", lambda: sets(NL(-3, 3), lambda n: (n.from_inequality("x<2"),
                                                                 n.point(2, "P", "open")))),
        ("union of two sources", lambda: sets(NL(-3, 3), lambda n: n.union(solve("x<-1"),
                                                                          solve("x>2")))),
        # C4 r3
        ("thirds auto numbers -1, 0, 1", lambda: NL(-1, 1, tick=F(1, 3), label_fmt="frac").svg()),
        ("symmetric between ticks", lambda: NL(-3, 3).symmetric(H * 5, between=True).svg()),
        ("estimates on tick 5", lambda: NL(-15, 25, tick=5, tier="block")
         .point(F("-7.8"), between=True).point(F("4.2"), between=True).svg()),
        ("jump label beside a hidden 3", lambda: NL(-1, 8, answer_hidden=[3]).jump(1, 4, "+3").svg()),
        ("nested lower arc", lambda: NL(-9, 9, tier="block").chain([-2, 6, -5, 5]).svg()),
        ("open end at hi", lambda: sets(NL(0, 5), lambda n: n.interval(2, 5, closed_b=False))),
        # C5
        ("vertical thermometer", lambda: NL(-150, 150, tick=10, orientation="v",
                                            height=240).point(50, "A")
         .point(-30, "B").svg(), _ck_v),
        ("vertical jump", lambda: NL(-10, 30, tick=5, orientation="v", height=200)
         .point(-5, "A").jump(-5, 20, "+25").svg(), _ck_v),
        ("vertical set", lambda: sets(NL(-10, 10, tick=2, orientation="v",
                                         height=200),
                                      lambda n: n.from_inequality("x>=-4")), _ck_v),
        ("reference mirror", lambda: NL(-5, 5).reference(0, "mirror", label="m")
         .point(3, "A").svg()),
        ("reference sea level", lambda: NL(-40, 60, tick=10, orientation="v",
                                           height=220).reference(0, "sea", label="S")
         .point(30, "A").svg(), _ck_v),
        ("bars from zero", lambda: NL(-500, 1000, tick=100, tier="strip")
         .bars_from_zero([-395, 812, 250]).svg(), _ck_bars),
        ("bars ascending", lambda: NL(-10, 10, tier="block")
         .bars_from_zero([7, -4, 9], order="asc", row_ids=["P", "Q", "R"]).svg(),
         _ck_bars),
        ("stack shared", lambda: stack(
            [NL(-1, 2, tick=F(1, 4), label_fmt="dec", tier="block"),
             NL(-1, 2, tick=F(1, 4), label_fmt="frac", tier="block")],
            connect=[F(-3, 4)], captions=["a", "b"]).svg(), _ck_stack),
        ("stack own", lambda: stack([NL(0, 10, tier="block"),
                                     NL(-100, 100, tick=20, tier="block")],
                                    scale="own").svg(), _ck_stack),
        ("stack sets", lambda: stack(
            [sets_nl(NL(-5, 5, tier="block"), "x<=2"),
             sets_nl(NL(-5, 5, tier="block"), "x>-3")],
            captions=["A", "B"]).svg(), _ck_stack),
        ("zoom 2..3", lambda: NL(0, 10, tier="block").zoom(2, 3, 10).svg(),
         _ck_zoom),
        ("double km / percent", lambda: double((0, 80), (0, 100), 10,
                                               hide_a=[24]).svg(), _ck_double),
        ("double not from zero", lambda: double((32, 212), (0, 100), 10,
                                                ratio=False).svg(), _ck_double0),
        ("sign chart", lambda: sign_chart([-2, 3], ["+", MINUS, "+"],
                                          closed=False, poly=[1, -1, -6]).svg(),
         _ck_sign([1, -1, -6])),
        ("sign chart double root", lambda: sign_chart(
            [1], ["+", "+"], poly=[1, -2, 1]).svg(), _ck_sign([1, -2, 1])),
        ("critique wrong scale", lambda: NL(-2, 3, student_drawing=True,
                                            asks=["find_error"],
                                            wrong_scale=[(2, "2.5")]).svg(),
         _ck_crit),
        ("critique wrong set", lambda: sets(
            NL(-3, 3, student_drawing=True, asks=["find_error"]),
            lambda n: n.from_inequality("x<2", closed=True)), _ck_crit),
        # C5 r2
        ("vertical dots on their values", lambda: NL(
            -150, 150, tick=10, orientation="v", height=240).point(120, "A")
         .point(-120, "B").svg(), _ck_v_dots([120.0, -120.0])),
        ("double 5..35 in 6 parts", lambda: double((0, 60), (5, 35), 6,
                                                   ratio=False,
                                                   tier="block").svg(),
         _ck_double0),
        ("critique sign chart", lambda: sign_chart(
            [-2, 3], [MINUS, "+", MINUS], poly=[1, -1, -6],
            student_drawing=True, asks=["find_error"]).svg(), _ck_crit_sign),
        ("critique sign chart, root left out", lambda: sign_chart(
            [-2], ["+", MINUS], poly=[1, -1, -6], student_drawing=True,
            asks=["find_error"]).svg(), _ck_crit_sign),
        # C5 r3
        ("critique error named in words", lambda: NL(
            -4, 4, asks=["find_error"],
            student_drawing="the point stands at 3, the answer is 2")
         .point(3, "A").svg(), _ck_crit),
        ("zoom at the subdiv that fits", lambda: NL(0, 10, tick=1)
         .zoom(3, 4, subdiv=21).svg(), _ck_zoom),
        ("reference clear of the hidden answer", lambda: NL(
            -10, 10, tick=1, tier="block", answer_hidden=[3])
         .reference(0, "sea", label="S").svg(), _ck_ref),
        ("double hiding one side of a pair", lambda: double(
            (0, 80), (0, 100), 10, hide_b=[30], tier="block").svg(), _ck_double),
    ]
    bad = [
        ("6pt floor", lambda: NL(-2, 2, tick=Q, width=60).svg(), "minor ticks"),
        ("closed=False", lambda: NL(-1, 6, tick=H).from_inequality("x>=3.5", closed=False),
         "drawn set disagrees with the inequality at x=3.5"),
        ("chosen ray", lambda: NL(-2, 8).ray(5, "left", source="2x+3<2x+5"), "disagrees"),
        ("jump label", lambda: NL(-9, 1).jump(-8, -3, "+6"), u"label +6 ≠"),
        ("-0.5 on 0", lambda: NL(-500, 1000, tick=100, tier="strip").point(-H).svg(),
         "within r of the 0 tick"),
        ("blank + point", lambda: NL(-6, 6, blank=True).point(2), "blank=True"),
        ("reversed", lambda: NL(5, 0), "not below"),
        ("off the line", lambda: NL(0, 5).point(9), "outside the line"),
        ("dec thirds", lambda: NL(0, 1, tick=F(1, 3), label_fmt="dec"), "cannot print"),
        ("every 5th", lambda: NL(-10, 10, label_every=5, tier="block"), "every 2nd"),
        ("label_at w/o sparse", lambda: NL(-3, 3, label_at=[-2, 1]), "sparse=True"),
        ("answer value", lambda: NL(-6, 6, answer_values=[8]), "answer value 8"),
        ("hidden bracket", lambda: NL(-6, 6, answer_hidden=[-5]).span(0, -5), "hidden"),
        # C4 r2
        ("estimate value label", lambda: NL(0, 5).point(10 ** 0.5, between=True,
                                                         value_label=True), "value_label='3.2'"),
        ("second set", lambda: sets(NL(-3, 3), lambda n: (n.from_inequality("x<-1"),
                                                         n.from_inequality("x>2"))), "union"),
        ("tri on a set end", lambda: sets(NL(-3, 3), lambda n: (n.from_inequality("x<2"),
                                                               n.point(2, "P", "tri"))),
         "point(2, 'P', 'open')"),
        ("short arrow2", lambda: NL(0, 10, tier="item").span(3, 4, kind="arrow2").svg(),
         "kind='bracket'"),
        ("floors first", lambda: NL(-150, 150, tick=10).point(-120).svg(), "minor ticks"),
        ("fraction label", lambda: NL(0, 3, tick=H, label_fmt="frac", tier="block")
         .jump(0, F(5, 2), "+7/2"), u"≠"),
        ("boundary off tick", lambda: sets(NL(-1, 6), lambda n: n.from_inequality("x>=3.5")),
         "not on a tick"),
        ("chain both ways", lambda: solve("1 < x > 3"), "not a chain"),
        ("same value same side", lambda: NL(-5, 5).chain([0, 3, 0, 3]).svg(), "two number lines"),
        # C5
        ("vertical too short", lambda: NL(-150, 150, tick=10, orientation="v",
                                          height=120).svg(), "coarser tick"),
        ("vertical fractions", lambda: NL(0, 2, tick=F(1, 3), label_fmt="frac",
                                          orientation="v"), "label_fmt='dec'"),
        ("stack no shared scale", lambda: stack([NL(0, 10), NL(-5, 5)]),
         "scale='own'"),
        ("stack own with connectors", lambda: stack(
            [NL(0, 10, tier="block"), NL(-5, 5, tier="block")], scale="own",
            connect=[5]), "shared"),
        ("connector on no tick", lambda: stack(
            [NL(-1, 2, tick=F(1, 4), tier="block"),
             NL(-1, 2, tick=F(1, 3), label_fmt="frac", tier="block")],
            connect=[F(-3, 4)]).svg(), "point(-0.75)"),
        ("bars and a point", lambda: NL(-10, 10).bars_from_zero([4]).point(2, "A"),
         "line of its own"),
        ("bar for 0", lambda: NL(-10, 10).bars_from_zero([4, 0]), "value 0 has no bar"),
        ("bar too short", lambda: NL(-500, 1000, tick=100, tier="strip")
         .bars_from_zero([-395, F(-1, 2)]).svg(), "floor 3pt"),
        ("bars ids repeat", lambda: NL(-10, 10).bars_from_zero([4, 5], row_ids=["A", "A"]),
         "row ids repeat"),
        ("zoom off the ticks", lambda: NL(0, 10, tier="block").zoom(F(1, 2), 3),
         "is not a tick of 1"),
        ("zoom the whole line", lambda: NL(0, 10, tier="block").zoom(0, 10),
         "the whole line"),
        ("double pair", lambda: double((0, 80), (0, 100), 10, pairs=[(32, 30)]),
         "32 pairs with 40"),
        ("double not a ratio", lambda: double((32, 212), (0, 100), 10),
         "ratio=False"),
        ("double hide value", lambda: double((0, 80), (0, 100), 10, hide_a=[25]),
         "is not a number of scale_a"),
        ("sign chart wrong sign", lambda: sign_chart([-2, 3], ["+", "+", "+"],
                                                     poly=[1, -1, -6]),
         "the chart says"),
        ("sign chart not a root", lambda: sign_chart([-2, 4], ["+", MINUS, "+"],
                                                     poly=[1, -1, -6]),
         "is not a root"),
        ("sign chart missing root", lambda: sign_chart([-2], ["+", MINUS],
                                                       poly=[1, -1, -6]),
         "a root there is not listed"),
        ("sign chart alternation", lambda: sign_chart([-2, 3], ["+", MINUS, MINUS]),
         "touch=[...]"),
        ("critique without asks", lambda: NL(-2, 3, student_drawing=True),
         "asks=['find_error']"),
        ("a point on a double line", lambda: double((0, 80), (0, 100), 10).nl
         .point(50, "A"), "second scale"),
        # C5 r2
        ("double ends off its own ticks", lambda: double(
            (0, 100), (32, 212), 10, ratio=False, tier="block").svg(),
         "is not a multiple"),
        ("double 5..35 in 4 parts", lambda: double(
            (0, 60), (5, 35), 4, ratio=False, tier="block").svg(), "parts=6"),
        ("critique sign chart that is right", lambda: sign_chart(
            [-2, 3], ["+", MINUS, "+"], poly=[1, -1, -6], student_drawing=True,
            asks=["find_error"]), "it is the CORRECT chart"),
        ("critique sign chart without poly", lambda: sign_chart(
            [-2, 3], [MINUS, "+", MINUS], student_drawing=True,
            asks=["find_error"]), "pass poly=[coefficients]"),
        ("critique sign chart without asks", lambda: sign_chart(
            [-2, 3], [MINUS, "+", MINUS], poly=[1, -1, -6],
            student_drawing=True), "asks=['find_error']"),
        ("wrong_scale off the numbers", lambda: NL(-2, 3, student_drawing=True,
                                                   asks=["find_error"],
                                                   wrong_scale=[(F(1, 2), "0.7")]),
         "is not a numbered tick"),
        # C4 r3
        ("Hebrew jump label", lambda: NL(0, 8).jump(1, 6, u"קפיצה"), "Hebrew"),
        # v6 P2: three spans that interleave cannot all be drawn without two
        # arcs crossing; the refusal names the two-line call that renders
        # (this was the 'overlapping jumps grounded' fixture, drawn with a
        # crossing the sweep now refuses)
        ("three interleaved jumps name a stack", lambda: NL(0, 10, tier="block")
         .jump(0, 5).jump(2, 7).jump(4, 9).svg(), "renders as N.stack(["),
        ("estimate names tick=5", lambda: NL(-15, 25, tick=H * 5, tier="block")
         .point(F("-7.8"), between=True).svg(), "tick=5"),
        ("test marker on a set end", lambda: sets(NL(-2, 6), lambda n: (
            n.from_inequality("x>3"), n.test_markers([(3, "x")]))), "test_markers([(3, 'x')])"),
        ("double_arrow labels meet", lambda: NL(F(-7, 2), F(3, 2), tick=H, tier="side")
         .double_arrow(-2, H, "0.5").svg(), "tier="),
        # C5 r3
        ("critique line with nothing wrong", lambda: NL(
            -4, 4, student_drawing=True, asks=["find_error"]).svg(),
         "nothing on it is drawn wrong"),
        ("critique line drawing the right set", lambda: sets(
            NL(-4, 4, student_drawing=True, asks=["find_error"]),
            lambda n: n.from_inequality("x<2", closed=False)),
         "it IS the correct drawing"),
        ("both halves of a pair hidden", lambda: double(
            (0, 80), (0, 100), 10, hide_a=[24], hide_b=[30],
            tier="block").svg(), "hidden on BOTH scales"),
        ("reference on the hidden answer", lambda: NL(
            -10, 10, tick=1, tier="block", answer_hidden=[3]).reference(3),
         "a hidden answer"),
        ("zoom too fine names subdiv", lambda: NL(0, 10, tick=1)
         .zoom(3, 4, subdiv=50).svg(), "subdiv=21"),
    ]
    return good, bad


def _ck_v(s):
    return svgcheck.problems(s, irregular=True) + sweep_v(s)


def _ck_v_dots(dots):
    def run(s):
        return svgcheck.problems(s, irregular=True) + sweep_v(s, dots=dots)
    return run


def _ck_crit_sign(s):
    return svgcheck.problems(s, irregular=True, marks=False) + \
        sweep(s, lengths=False, signs=True, vote=False)


def _ck_bars(s):
    return svgcheck.problems(s, irregular=True) + sweep(s)


def _ck_stack(s):
    return svgcheck.problems(s, ticks=False, dots=False, marks=False,
                             irregular=True) + stack_sweep(s)


def _ck_zoom(s):
    return svgcheck.problems(s, ticks=False, dots=False, marks=False,
                             irregular=True) + stack_sweep(s, zoom=True)


def _ck_double(s):
    return svgcheck.problems(s, ticks=False, irregular=True) + \
        double_sweep(s, ratio=True)


def _ck_double0(s):
    return svgcheck.problems(s, ticks=False, irregular=True) + double_sweep(s)


def _ck_sign(poly):
    def run(s):
        return svgcheck.problems(s, irregular=True, marks=False) + \
            sweep(s, lengths=False, signs=True) + sign_sweep(s, poly=poly)
    return run


def _ck_crit(s):
    return svgcheck.problems(s, irregular=True) + sweep(s, vote=False)


def _ck_ref(s):
    return svgcheck.problems(s, irregular=True) + sweep(s)


def selftest():
    good, bad = _selftest_cases()
    fails = 0
    new_sheet()
    for case in good:
        name, fn = case[0], case[1]
        try:
            s = fn()
            probs = case[2](s) if len(case) > 2 else \
                svgcheck.problems(s, irregular=True) + \
                sweep(s, lengths="sparse" not in name)
            ok = not probs and "fam:" in s
            detail = "; ".join(probs)[:120]
        except AssertionError as e:
            ok, detail = False, str(e)[:160]
        fails += not ok
        print("  %-40s %s %s" % (name, "PASS" if ok else "FAIL", "" if ok else detail))
    for name, fn, needle in bad:
        try:
            fn()
            ok, detail = False, "was not refused"
        except AssertionError as e:
            ok, detail = needle in str(e), str(e)[:160]
        fails += not ok
        print("  %-40s %s %s" % ("refused: " + name, "PASS" if ok else "FAIL",
                                 "" if ok else detail))
    # the builder's own slide put back: the independent sweeps must see it
    old = NL._tick_label_x
    try:
        NL._tick_label_x = lambda self, x, runs, px: x + 0.6 * px
        try:
            NL(0, 5).svg()
            ok = False
        except AssertionError as e:
            ok = "0.15" in str(e)
    finally:
        NL._tick_label_x = old
    fails += not ok
    print("  %-40s %s" % ("refused: a 0.6 em slide", "PASS" if ok else "FAIL"))
    new_sheet()
    print("\nNUMBERLINE SELFTEST %s (%d cases)" % ("PASS" if not fails else "FAIL",
                                                  len(good) + len(bad) + 1))
    return fails == 0


if __name__ == "__main__":
    import sys
    sys.exit(0 if selftest() else 1)
