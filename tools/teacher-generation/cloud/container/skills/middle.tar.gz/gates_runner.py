#!/usr/bin/env python3
"""Single entry point for the OUTPUT gates. build.py MUST call this.

Why this file exists: G42's render half and G43-F2 were both defined, both
correct, and both shipped broken packages — because nothing asserted they had
actually RUN. A gate that silently skips (missing extractor, HTML stem != PDF
stem, a sweep scoped to question text so the answers page is never read) is
indistinguishable from a gate that passed. So every check here reports one of
PASS / FAIL / SKIPPED, and **SKIPPED is a build failure**, not a warning.

    from gates_runner import run_output_gates
    run_output_gates(pdf_paths, src_pdfs=None, strict=True)   # raises on FAIL

CLI:  python3 gates_runner.py out/*.pdf
      python3 gates_runner.py --selftest
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

PASS, FAIL, SKIPPED = "PASS", "FAIL", "SKIPPED"
# U+2236 RATIO is no longer banned outright: it is the one glyph the
# emitter may use for a RATIO, and only in ratio shape (digits, colon,
# digits, no spaces). Everything else about it still fails, and the
# other lookalikes stay banned. Without a legal ratio notation the
# emitter forced "1:50000" to print as a built fraction, which is not
# how a scale is written on a worksheet -- a gate cannot be allowed to
# dictate the notation of the subject being taught.
import re

DIVISION_GLYPHS = ("\u00f7", "\ua789", "\uff1a")
RATIO_COLON = "\u2236"
RATIO_OK = re.compile(r"(?<!\d)\d+(?:\.\d+)?(?:\u2236\d+(?:\.\d+)?)+(?!\d)")


def _text(pdf):
    """Full text of EVERY page — answers included. Returns None if no
    extractor is available, which is a SKIPPED, never a quiet pass."""
    try:
        import pymupdf
        return "".join(p.get_text("text") for p in pymupdf.open(str(pdf)))
    except Exception:
        pass
    try:
        import subprocess
        return subprocess.run(["pdftotext", "-enc", "UTF-8", str(pdf), "-"],
                              capture_output=True, text=True, check=True).stdout
    except Exception:
        return None


def g42_render_half(pdf, colon_division_ok=False):
    """`÷`, the colon lookalikes AND the plain ASCII colon, swept over ALL
    pages.  The three `÷` that shipped in the זוויות package were every one
    of them on the answers page.

    Aug 2026 — the ASCII half was MISSING.  DIVISION_GLYPHS listed U+00F7,
    U+2236, U+A789 and U+FF1A but not U+003A, so a sheet with 62 division
    colons returned PASS.  Half of this gate had never executed.  Pass
    `colon_division_ok=True` only for a sheet whose TOPIC is operator
    precedence (`24:6·2` vs `24:(6·2)` is the question; a fraction bar
    carries implicit grouping and destroys it)."""
    t = _text(pdf)
    if t is None:
        return SKIPPED, "no PDF text extractor available"
    if len(t.strip()) < 20:
        return SKIPPED, "extracted text is empty — sweep saw nothing"
    hits = [g for g in DIVISION_GLYPHS if g in t]
    stray = len(re.findall(RATIO_COLON, t)) - sum(
        len(re.findall(RATIO_COLON, m.group(0))) for m in RATIO_OK.finditer(t))
    if stray > 0:
        return FAIL, ("%d ratio colon(s) not in ratio shape -- U+2236 is for "
                      "`3\u22364`, never for a division or beside a space" % stray)
    if hits:
        return FAIL, "division glyph(s) %s in rendered text" % hits
    # NOTE: no local `import re` here. `re` is imported at module scope; a
    # function-local import made every use of `re` in this function local,
    # so the ratio-colon sweep above raised UnboundLocalError and g42 could
    # never run at all.
    if not colon_division_ok:
        # `\s` matches a newline, so the original pattern joined the last
        # digit of one line to the first of the next and reported a division
        # that is not on the page: a band reading "1-20" followed by a line
        # starting ":3-4-5" tripped it. A real colon division is on ONE line.
        n = len(re.findall(r"\d[ \t\u00a0]*:[ \t\u00a0]*\d", t))
        # `\b` between a Hebrew letter and a digit is not a word boundary the
        # way this text comes out of the extractor, so "בשעה 6:00" was NOT
        # exempted and an author had to delete the clock times from the
        # sheet to pass. Anchor on the digits alone: a time is 1-2 digits,
        # a colon, and exactly two minute digits. `81:3` and the ratio
        # `1:2:3` still fail, which is the point of the gate.
        clock = len(re.findall(r"(?<!\d)[012]?\d:[0-5]\d(?!\d)", t))
        if n - clock > 0:
            return FAIL, ("%d ASCII colon division(s) — use a stacked "
                          "fraction, or declare the precedence exception"
                          % (n - clock))
    slash = len(re.findall(r"[\d)a-zA-Z][ \t\u00a0]*/[ \t\u00a0]*[\d(a-zA-Z]", t))
    if slash:
        return FAIL, ("%d inline slash division(s) — a division is a stacked "
                      "fraction, never `a/b`" % slash)
    return PASS, "%d chars swept" % len(t)


def g43_f2_roots(pdf):
    """Roots ship as SVG paths, so ANY root codepoint in the text layer is a
    leaked vinculum-less glyph."""
    t = _text(pdf)
    if t is None:
        return SKIPPED, "no PDF text extractor available"
    n = sum(t.count(c) for c in "\u221a\u221b\u221c")
    if n:
        return FAIL, "%d bare root codepoint(s) in the text layer" % n
    return PASS, "no bare roots"


def g45_g46(pdf, src=None):
    try:
        from check_render_integrity import check
    except Exception as e:
        return SKIPPED, "check_render_integrity unavailable: %r" % e
    problems = check(pdf, src)
    return (FAIL, "; ".join(problems)) if problems else (PASS, "body font + figures ok")


def g67_markup_leak(pdf):
    """G67 — MARKUP LEAK (HOUSE RULE, Noam, Sep 2026; טרפז package).

    Three levels shipped with `\\sqrt{100 - 36}` and `\\angle{A}` printed as
    literal ink, scrambled by the RTL run into `{63 - 001}trqs\\`. Every gate
    in this runner returned PASS on those files, because not one of them
    looked for a backslash. Presence of authoring markup in the OUTPUT is a
    defect no reader can misdiagnose, and it costs one regex to catch.

    The emitter now refuses an unknown macro at source; this is the belt over
    that brace, and it also catches markup that never went through the
    emitter at all (a hand-edited HTML, a figure label, a pasted answer).
    Deliberate scope: backslash and TeX braces only — `$` is the island
    delimiter and is stripped by construction, `^` is legitimate prose."""
    t = _text(pdf)
    if t is None:
        return SKIPPED, "no PDF text extractor available"
    if len(t.strip()) < 20:
        return SKIPPED, "extracted text is empty — sweep saw nothing"
    import re
    hits = re.findall(r"\\[a-zA-Z]+|\\(?![a-zA-Z])", t)
    if hits:
        return FAIL, ("%d authoring macro(s) printed as text: %s"
                      % (len(hits), sorted(set(hits))[:6]))
    braces = len(re.findall(r"\{[^{}]{0,30}\}", t))
    if braces:
        return FAIL, "%d TeX-style brace group(s) in the text layer" % braces
    return PASS, "no markup leak"




# =====================================================================
#  v5 GATES — added Sep 2026 after the full-corpus audit of 447 sheets.
#  Each one below is tied to a defect class that was COUNTED in shipped
#  PDFs, ordered by how many files it touched.  The existing gates all
#  read the text layer; these read GEOMETRY and FONTS, because the
#  top defect classes are invisible to text extraction: a label crossed
#  by a rule extracts perfectly and prints unreadable.
# =====================================================================

def _spans(pdf):
    try:
        import pymupdf
    except Exception:
        return None
    out = []
    for pno, page in enumerate(pymupdf.open(str(pdf)), 1):
        for b in page.get_text("dict")["blocks"]:
            if b.get("type") != 0:
                continue
            for l in b["lines"]:
                for sp in l["spans"]:
                    if sp["text"].strip():
                        out.append((pno, sp))
    return out


def g70_font_load(pdf):
    """G70 — THE SILENT FONT FALLBACK  (root cause of the minus defect).

    v4.3 pointed @font-face at `~/.fonts`, which does not exist. All three
    faces failed, David Libre never loaded, and every sheet rendered in
    whatever serif the OS offered — the audit found DejaVu, FreeSerif,
    NimbusRoman and Noto across the corpus. Nothing failed; the PDF just
    came out in the wrong font, and DejaVu's U+2212 against David Libre's
    digits is the `-5 prints as a struck-through 5` bug.

    A sheet whose body is not David Libre is not the house product."""
    sp = _spans(pdf)
    if sp is None:
        return SKIPPED, "pymupdf unavailable"
    fonts = {s["font"] for _, s in sp}
    body = [f for f in fonts if "David" in f or "DL" in f]
    if not body:
        return FAIL, "David Libre absent from the output; fonts=%s" % sorted(fonts)
    stray = {f for f in fonts
             if not any(k in f for k in ("David", "DL", "HouseSym"))}
    if stray:
        return FAIL, ("unpinned fallback font(s) %s — pin the glyph or ship "
                      "the face with the skill" % sorted(stray))
    return PASS, "body is %s" % sorted(body)[0]


def g72_label_struck(pdf):
    """G72 — A LABEL WITH A LINE THROUGH IT.  The single largest defect
    class in the audit: 120 of 447 sheets. A vertex letter, an axis number
    or a length label with a stroke crossing its glyph box. Extraction is
    perfect, the print is ambiguous, and `60` on a diagonal reads as `-60`.

    Sweeps every stroked path against every glyph box, shrunk to the ink so
    that a label legitimately resting against an edge does not trip it."""
    try:
        import pymupdf
    except Exception:
        return SKIPPED, "pymupdf unavailable"

    def hit(p, q, r):
        x0, y0, x1, y1 = r
        dx, dy = q.x - p.x, q.y - p.y
        t0, t1 = 0.0, 1.0
        for pk, qk in ((-dx, p.x - x0), (dx, x1 - p.x),
                       (-dy, p.y - y0), (dy, y1 - p.y)):
            if abs(pk) < 1e-9:
                if qk < 0:
                    return False
            else:
                t = qk / pk
                if pk < 0:
                    if t > t1: return False
                    if t > t0: t0 = t
                else:
                    if t < t0: return False
                    if t < t1: t1 = t
        return t0 < t1

    bad, n = [], 0
    for pno, page in enumerate(pymupdf.open(str(pdf)), 1):
        segs = []
        for d in page.get_drawings():
            if d.get("type") == "f" or not (d.get("width") or 0) > 0:
                continue
            col = d.get("color")
            if col and min(col) > 0.85:
                continue                       # invisible on white
            # P1: the coordinate grid (svgcheck.GRID_GREY, a neutral light
            # grey hairline) is background, recognised by colour and width
            if col and max(col) - min(col) < 0.01 and \
                    abs(min(col) - 200 / 255.0) < 0.01 and \
                    (d.get("width") or 0) <= 0.6:
                continue
            for it in d["items"]:
                if it[0] == "l":
                    segs.append((it[1], it[2]))
                elif it[0] == "re":
                    r = it[1]
                    c = [pymupdf.Point(r.x0, r.y0), pymupdf.Point(r.x1, r.y0),
                         pymupdf.Point(r.x1, r.y1), pymupdf.Point(r.x0, r.y1)]
                    segs += list(zip(c, c[1:] + c[:1]))
                elif it[0] == "c":
                    # CURVES WERE INVISIBLE TO THIS GATE. It collected only
                    # straight segments and rectangles, so an arc, a circle, a
                    # parabola or a pie slice could run straight through a
                    # label and the page reported "no stroked figure on any
                    # page". This is the gate SKILL.md calls the one that
                    # matters most, and the corpus it backstops is full of
                    # curves. Flatten the cubic and check it like any edge.
                    p0, p1, p2, p3 = it[1], it[2], it[3], it[4]
                    prev, N = p0, 12
                    for k in range(1, N + 1):
                        t = k / float(N)
                        u = 1.0 - t
                        x = (u * u * u * p0.x + 3 * u * u * t * p1.x
                             + 3 * u * t * t * p2.x + t * t * t * p3.x)
                        y = (u * u * u * p0.y + 3 * u * u * t * p1.y
                             + 3 * u * t * t * p2.y + t * t * t * p3.y)
                        cur = pymupdf.Point(x, y)
                        segs.append((prev, cur))
                        prev = cur
                elif it[0] == "qu":
                    q = it[1]
                    c = [q.ul, q.ur, q.lr, q.ll]
                    segs += list(zip(c, c[1:] + c[:1]))
        if not segs:
            continue
        for b in page.get_text("rawdict")["blocks"]:
            if b.get("type") != 0:
                continue
            for l in b["lines"]:
                for s in l["spans"]:
                    for ch in s["chars"]:
                        c = ch["c"]
                        if c.isspace() or 0x0591 <= ord(c) <= 0x05C7:
                            continue
                        x0, y0, x1, y1 = ch["bbox"]
                        w, h = x1 - x0, y1 - y0
                        if w <= .2 or h <= .2:
                            continue
                        core = (x0 + w * .22, y0 + h * .30,
                                x1 - w * .22, y1 - h * .18)
                        n += 1
                        for a, bb in segs:
                            if hit(a, bb, core):
                                bad.append("p%d %r at (%.0f,%.0f)"
                                           % (pno, c, x0, y0))
                                break
    if bad:
        return FAIL, "%d struck glyph(s): %s" % (len(bad), "; ".join(bad[:5]))
    if n == 0:
        return PASS, "no stroked figure on any page — nothing to strike"
    return PASS, "%d glyph(s) clear of every stroke" % n


def g73_page_counter(pdf):
    """G73 — «עמוד 5 מתוך 6» on a five-page file. Found on every
    `ללא_תשובות` variant in ז/50 and ח/64: the answer pages were stripped
    after the build, so the printed total outlived the document."""
    try:
        import pymupdf
        doc = pymupdf.open(str(pdf))
    except Exception:
        return SKIPPED, "pymupdf unavailable"
    import re
    real = len(doc)
    # The footer is bidi text: extraction may hand back "2 \u05de\u05ea\u05d5\u05da 1"
    # or "1 \u05de\u05ea\u05d5\u05da 2" depending on the run. Read the digits on
    # BOTH sides and require the true total to be among them.
    pat = re.compile(r"(\d+)?\s*\u05de\u05ea\u05d5\u05da\s*(\d+)?")
    seen = set()
    for page in doc:
        for m in pat.finditer(page.get_text("text")):
            for grp in m.groups():
                if grp:
                    seen.add(int(grp))
    if seen and real not in seen:
        return FAIL, ("footer never states the real total; document has %d "
                      "page(s), footer shows %s" % (real, sorted(seen)))
    return PASS, "%d page(s), footer agrees" % real


CHECKS = [("G42-render", g42_render_half),
          ("G43-F2", g43_f2_roots),
          ("G67-leak", g67_markup_leak),
          ("G45/G46", g45_g46),
          ("G70-font", g70_font_load),
          ("G72-struck", g72_label_struck),
          ("G73-pages", g73_page_counter)]


def run_output_gates(pdfs, src_pdfs=None, strict=True, verbose=True,
                     colon_division_ok=False):
    """colon_division_ok — set True ONLY for a sheet whose topic is operator
    precedence (סדר פעולות), where `24:6·2` vs `24:(6·c)` IS the question and
    a fraction bar would answer it by construction."""
    pdfs = [Path(p) for p in pdfs]
    if not pdfs:
        raise SystemExit("gates_runner: no PDFs given — a delivery gate must "
                         "run, not vanish")
    src_pdfs = src_pdfs or {}
    bad = []
    for pdf in pdfs:
        for name, fn in CHECKS:
            if name == "G45/G46":
                status, msg = fn(pdf, src_pdfs.get(pdf.name))
            elif name == "G42-render":
                status, msg = fn(pdf, colon_division_ok)
            else:
                status, msg = fn(pdf)
            if verbose:
                print("%-10s %-42s %-7s %s" % (name, pdf.name[:42], status, msg))
            if status in (FAIL, SKIPPED):
                bad.append((pdf.name, name, status, msg))
    if bad and strict:
        lines = "\n".join("  %s :: %s :: %s :: %s" % b for b in bad)
        raise SystemExit("BUILD BLOCKED — output gates did not all pass:\n" + lines)
    return bad


def _selftest():
    ok = True
    if g42_render_half.__doc__ is None:
        ok = False
    # SKIPPED must be treated exactly like FAIL
    fake = [("x.pdf", "G43-F2", SKIPPED, "no extractor")]
    if not fake:
        ok = False
    for st in (FAIL, SKIPPED):
        if st not in (FAIL, SKIPPED):
            ok = False
    # a text sweep must see the answers page: assert we concatenate all pages
    src = Path(__file__).read_text(encoding="utf-8")
    if "for p in pymupdf.open" not in src:
        print("SELFTEST FAIL: sweep is not over all pages"); ok = False
    if "SKIPPED is a build failure" not in src:
        print("SELFTEST FAIL: skip-is-failure doctrine missing"); ok = False
    print("SELFTEST PASS" if ok else "SELFTEST FAILED")
    return 0 if ok else 1


if __name__ == "__main__":
    if "--selftest" in sys.argv:
        sys.exit(_selftest())
    ok = "--colon-division-ok" in sys.argv
    try:
        run_output_gates([a for a in sys.argv[1:] if not a.startswith("-")],
                         colon_division_ok=ok)
    except SystemExit as e:
        print(e)
        sys.exit(1)
    print("ALL OUTPUT GATES PASS")
