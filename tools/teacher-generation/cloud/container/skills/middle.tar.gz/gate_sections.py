# -*- coding: utf-8 -*-
u"""gate_sections — v7.2.0 post-build gates of a sectioned sheet.

    G85 section-volume        G86 terms               G87 subtopic-chronology
    G88 level-parity          G89 catalog (dispatch)  G92 section-structure

    python3 gate_sections.py --pkg DIR [--out DIR] [--json OUT]   exit 1 on any FAIL
    python3 gate_sections.py --selftest                            offline, < 30 s

WHY POST-BUILD, AND WHY THE PRINTED FILES
-----------------------------------------
build.py stops at the first failing level, so nothing inside it can compare
a, b and c (G88) or read the Word file and the catalog (G86, G89). These gates
therefore run after build_plus, emit_docx and catalog_build (build_v72.py
step 5), and they read what was PRINTED: out/deliver/<k>/sheet.json,
sheet.html, noam-ai.json, out/docx/<k>/sheet.docx and out/catalog/<id>/*.json.
The package source (pkgload: levels, IR, SHEET) is read too, because the
section manifest (SHEET) lives only there and the IR is the very object the
PDF was printed from. A defect that exists only in one output (a term that
only the Word file carries, a band the HTML lost) is caught where it is.

A legacy package (no sheet_meta.py and no SHEET) gets SKIP from every gate,
never PASS: these gates know nothing about a sheet without sections, and a
PASS would claim they did. A package that ships sheet_meta.py but exposes no
usable SHEET (None, {} or not a dict) gets FAIL from every gate: build_v72
treats an all-SKIP step as non-failing, so a SKIP would ship it unchecked.
A missing printed file is never a silent PASS either: FAIL when the gate
cannot work without it (sheet.json, sheet.html, the catalog for G89), REVIEW
("not scanned") when it only narrows what was scanned (the DOCX, in G86,
G87 and G92 alike).

SHEET is the declared intent, so G88 also holds its identity (grade, track,
topic_id, sheet_id) against what the package itself says: every level's
curriculum dict and printed grade line, the curriculum block of every
level's noam-ai.json (grade, topic, and track: a level with its own SHEET
entry, SHEET.track_by_level[k] or SHEET.track[k], may name only that track;
otherwise SHEET.track or the house mapping of ST.track_for; the file itself
is required), and the
registry track of every section's subtopic. G86 and G87 choose their rules
from SHEET; a manifest copied from another sheet must not switch those rules
off unnoticed.

A part band is the title of the section it opens, not navigation. G92 and
G88 require its printed title to EQUAL the SHEET section title (after NFC,
niqqud, invisible-mark and whitespace folding): a band that merely contains
it can name a later section's subtopic. G92 also holds the bands printed in
sheet.html and in the DOCX to the IR bands. G87 checks a band's terms at the
position of its own section, later-section rule included. Only the title
and the rule box ("מה בדף") announce the whole sheet and are checked at its
last section.

One house-spelling hit is REVIEW, not FAIL, in G86: the locked engine's
default aux-figure label (didactic.AUX_LABEL), exactly, at the aux label
paths of sheet.json / noam-ai.json. The engine writes it for every aux dict
without a label, so the author never wrote it; the message names the cure
(label=u"סרטוט עזר" on the aux dict). The same string anywhere else stays FAIL,
and so does this one when a string literal of the package source equals it
(the author wrote label=u"שרטוט עזר"; the printed output cannot tell).

Result record (dev-contract):
    {"gate": "G85-section-volume", "level": "a" | None,
     "status": "PASS" | "FAIL" | "REVIEW" | "SKIP", "messages": [...]}
"""
import argparse
import ast
import html as _html
import json
import re
import sys
import zipfile
from html.parser import HTMLParser
from pathlib import Path
from xml.etree import ElementTree as ET

# The skill folder must stay free of __pycache__ (it is copied and hashed as
# a unit), and `python3 -I` ignores PYTHONDONTWRITEBYTECODE: so the gates never
# write bytecode for the modules they import, whoever runs them and how.
sys.dont_write_bytecode = True

SK = Path(__file__).resolve().parent
if str(SK) not in sys.path:
    sys.path.insert(0, str(SK))

import subtopics as ST  # noqa: E402  (stdlib-only API over registry + glossary)

LEVEL_KEYS = ("a", "b", "c")
G85, G86, G87, G88, G89, G92 = ("G85-section-volume", "G86-terms", "G87-subtopic-chronology",
                                "G88-level-parity", "G89-catalog", "G92-section-structure")
GATES = (G85, G86, G87, G88, G89, G92)
LEGACY_MSG = "legacy package (no SHEET)"
MAX_MESSAGES = 80
_RANK = {"PASS": 0, "SKIP": 0, "REVIEW": 1, "FAIL": 2}

# G86 exclusions: JSON paths (prefixes, list indices removed) that the gate
# does NOT scan, each with the reason. Only blocks that list words ON PURPOSE
# as engine metadata, never content a student or teacher reads.
G86_EXCLUDE = {
    # deliver writes the curriculum tools the AI tutor must NOT use yet
    # (names copied from curriculum_tools.json for every later topic). It is a
    # deny-list, not sheet text: a later term listed there is the point of the
    # list, and the fixtures review saw term hits only there.
    "/curriculum/not_yet_allowed": "AI deny-list of later tools (curriculum_tools names), "
                                   "not printed sheet text",
}

_W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
_M = "{http://schemas.openxmlformats.org/officeDocument/2006/math}"
_A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
_QID = re.compile(r"^(?:ans_)?q(\d+)([a-z]*)$")
_BIND_QID = re.compile(r"(?:^|:)q(\d+)([a-z]*)(?::|$)")

_ORDINAL = (u"ראשון|ראשונה|שני|שנייה|שניה|שלישי|שלישית|רביעי|רביעית|חמישי|חמישית|שישי|שישית|"
            u"שביעי|שמיני|תשיעי|עשירי|אחרון|אחרונה")
_ROMAN = u"(?:I{1,3}|IV|VI{0,3}|IX|X)(?![A-Za-z])"
BAD_TITLE = [
    # "חלק 2", "חלק א׳", "חלק שני", "החלק השני", "(חלק II)" -- but not the word
    # "חלקי" ("חלקי הזווית"): the ordinal may carry the article (review
    # 2026-11-09: "— החלק השני" passed), Roman numerals count as numbers.
    (re.compile(u"(?<![א-ת])[ובלה]?חלק(?:[\\s־-]*\\d+|[\\s־-]*" + _ROMAN +
                u"|[\\s־-]+(?:[א-י][׳']?|ה?(?:" + _ORDINAL + u")))(?![א-ת0-9])"),
     u"a 'חלק N' title (no part-1/part-2 sheets)"),
    (re.compile(u"(?i)(?<![a-z])part[\\s-]*(?:\\d+|" + _ROMAN + u"|one|two|three)(?![a-z0-9])"),
     u"a 'part N' title (no part-1/part-2 sheets)"),
    # "זוויות — המשך" / "(המשך)": a part-2 sheet under another name. Only a
    # trailing one: "המשך הצלע" (the extension of a side) is a geometry term.
    (re.compile(u"(?:^|[\\s—–:,(־-])[וה]?המשך\\s*\\)?\\s*[.!]?$"),
     u"a '— המשך' (continued) title (no part-1/part-2 sheets)"),
    (re.compile(u"(?<![א-ת])[והבל]?(?:מבוא|הקדמה)(?![א-ת])(?![\\s־-]*ל[א-ת])"),
     u"a bare 'מבוא/הקדמה' title (name the subtopics)"),
    (re.compile(u"יחסים[\\s־-]+ו?פעולות"), u"the generic title 'יחסים ופעולות'"),
]


# ================================================================ records ===
class Rec(object):
    """One gate result being built: the worst status wins."""

    def __init__(self, gate, level):
        self.gate, self.level, self.status, self.messages = gate, level, "PASS", []

    def add(self, status, msg):
        if _RANK[status] > _RANK[self.status]:
            self.status = status
        if status != "PASS" or len(self.messages) < MAX_MESSAGES:
            self.messages.append(u"%s: %s" % (status, msg))

    def note(self, msg):
        self.messages.append(u"info: %s" % msg)

    def out(self):
        msgs = list(dict.fromkeys(self.messages))
        if len(msgs) > MAX_MESSAGES:
            extra = len(msgs) - MAX_MESSAGES
            msgs = msgs[:MAX_MESSAGES] + [u"... and %d more message(s)" % extra]
        return {"gate": self.gate, "level": self.level, "status": self.status, "messages": msgs}


def _record(gate, level, status, messages):
    return {"gate": gate, "level": level, "status": status, "messages": list(messages)}


# ========================================================== printed files ===
def _rel(path, root=None):
    """A path as the messages print it: relative to the build output folder
    when it lies inside it (absolute scratch paths drown the finding)."""
    try:
        return str(Path(path).relative_to(root)) if root else str(path)
    except ValueError:
        return str(path)


def _load_json(path, root=None):
    try:
        with open(str(path), encoding="utf-8") as f:
            return json.load(f), None
    except FileNotFoundError:
        return None, "%s is missing" % _rel(path, root)
    except Exception as e:  # unreadable output is a finding, not a crash
        return None, "%s is unreadable: %r" % (_rel(path, root), e)


def walk_strings(obj, path="", qid=None):
    """Yield (path, string, question id) for every string in a JSON value.

    The question id is the nearest enclosing dict whose "id" is q<n>[x] (a
    question or item row), or the "question" of a figure entry."""
    if isinstance(obj, dict):
        q = obj.get("id")
        if isinstance(q, str) and _QID.match(q):
            qid = q
        elif isinstance(obj.get("question"), str) and _QID.match(obj["question"]):
            qid = obj["question"]
        for k, v in obj.items():
            for x in walk_strings(v, "%s/%s" % (path, k), qid):
                yield x
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            for x in walk_strings(v, "%s[%d]" % (path, i), qid):
                yield x
    elif isinstance(obj, str):
        yield path, obj, qid


def _plain_path(path):
    return re.sub(r"\[\d+\]", "", path)


def _excluded(path):
    p = _plain_path(path)
    for pre in G86_EXCLUDE:
        if p == pre or p.startswith(pre + "/"):
            return True
    return False


class HtmlDoc(object):
    """sheet.html as the gates need it: visible text blocks with their
    context (q<n> or a navigation role), the bands, h1, rule and the printed
    question numbers."""

    def __init__(self, raw):
        self.raw = raw
        p = _HtmlText()
        p.feed(raw)
        p.close()
        p.flush()
        self.blocks = p.blocks                    # [(ctx, text)]
        self.h1 = u" ".join(t for c, t in self.blocks if c == "nav:h1").strip()
        self.rule = u" ".join(t for c, t in self.blocks if c == "nav:rule").strip()
        main = raw.split('class="ansband"')[0]
        self.qnums = [int(x) for x in re.findall(r'<span class="qnum">\((\d+)\)</span>', main)]
        self.bands = []                           # [(title, range or None, next qnum or None)]
        for m in re.finditer(r'<div class="band(?: brk)?"><b>(.*?)</b>(?:\s*(?:שאלות|שאלה)\s*'
                             r'<span class="num">(.*?)</span>)?\s*</div>', main, re.S):
            nxt = re.search(r'<span class="qnum">\((\d+)\)</span>', main[m.end():])
            self.bands.append((_strip_tags(m.group(1)),
                               _html.unescape(m.group(2)) if m.group(2) is not None else None,
                               int(nxt.group(1)) if nxt else None))


def _strip_tags(s):
    s = re.sub(r"(?s)<svg.*?</svg>", "", s)
    return re.sub(r"\s+", " ", _html.unescape(re.sub(r"<[^>]+>", "", s))).strip()


class _HtmlText(HTMLParser):
    VOID = {"br", "hr", "img", "meta", "link", "input", "wbr", "area", "base", "col",
            "embed", "source", "track", "param"}
    BLOCK = {"div", "p", "h1", "h2", "h3", "h4", "h5", "h6", "li", "tr", "td", "th",
             "table", "br", "section", "header", "footer", "ul", "ol", "text"}
    SKIP = {"style", "script", "head", "title", "desc", "defs", "metadata"}
    NAV = {"band": "nav:band", "rule": "nav:rule", "lvl": "nav:lvl", "sub": "nav:sub",
           "ansband": "nav:ansband", "ansnote": "nav:ansnote", "good": "nav:good",
           "idline": "nav:idline"}

    def __init__(self):
        HTMLParser.__init__(self, convert_charrefs=True)
        self.stack = []          # [tag, ctx, skip, is_q]
        self.blocks = []
        self.buf, self.buf_ctx = [], None
        self._qnum_pending = False

    def _ctx(self):
        return self.stack[-1][1] if self.stack else "nav:page"

    def _skip(self):
        return bool(self.stack) and self.stack[-1][2]

    def flush(self):
        t = re.sub(r"\s+", " ", u"".join(self.buf)).strip()
        if t:
            self.blocks.append((self.buf_ctx, t))
        self.buf, self.buf_ctx = [], None

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag in self.BLOCK:
            self.flush()
        if tag in self.VOID:
            return
        ctx = self._ctx()
        skip = self._skip() or tag in self.SKIP
        is_q = False
        cls = (a.get("class") or "").split()
        bind = a.get("data-bind")
        if bind:
            m = _BIND_QID.search(bind)
            if m:
                ctx = "q%s" % m.group(1)
        elif tag == "h1":
            ctx = "nav:h1"
        elif "q" in cls and tag == "div":
            ctx, is_q = "q?", True
        else:
            for c in cls:
                if c in self.NAV:
                    ctx = self.NAV[c]
                    break
        if "qnum" in cls:
            self._qnum_pending = True
        self.stack.append([tag, ctx, skip, is_q])

    def handle_startendtag(self, tag, attrs):
        if tag in self.BLOCK:
            self.flush()

    def handle_endtag(self, tag):
        if tag in self.BLOCK:
            self.flush()
        for i in range(len(self.stack) - 1, -1, -1):
            if self.stack[i][0] == tag:
                del self.stack[i:]
                break

    def handle_data(self, data):
        if self._skip():
            return
        if self._qnum_pending:
            m = re.match(r"\s*\((\d+)\)", data)
            if m:
                q = "q%s" % m.group(1)
                for fr in self.stack:
                    if fr[1] == "q?":
                        fr[1] = q
            self._qnum_pending = False
        ctx = self._ctx()
        if self.buf and self.buf_ctx != ctx:
            self.flush()
        self.buf_ctx = ctx
        self.buf.append(data)


class DocxDoc(object):
    """The text of a .docx (stdlib): paragraphs with their part and their
    innermost q-bookmark, and the text of every bookmark.

    `bands` maps a paragraph index to the question number it opens: an
    unbookmarked heading-2 paragraph of the body (emit_docx writes the part
    band as style Heading2, outside every q-bookmark) that is followed by a
    q<n> paragraph before any other heading-2. G87 checks a band at the
    position of the section it opens, and G92 holds it to the IR band of
    that question, so both need to know which q it heads; a heading it
    cannot tie to a question stays navigation text (and is missing from
    G92's band list)."""

    PARTS = re.compile(r"^word/(document|header\d*|footer\d*|footnotes|endnotes|comments)\.xml$")
    BAND_STYLE = "Heading2"

    def __init__(self, path):
        self.paragraphs = []       # [(part, bookmark or None, text)]
        self.styles = []           # paragraph style id (or None), parallel to paragraphs
        self.bookmarks = {}        # {name: text}
        self.bands = {}            # {paragraph index: question number it opens}
        with zipfile.ZipFile(str(path)) as z:
            for name in z.namelist():
                if self.PARTS.match(name):
                    self._part(name, ET.fromstring(z.read(name)))
        self._find_bands()

    def _find_bands(self):
        pending = None
        for i, (part, bm, _t) in enumerate(self.paragraphs):
            if part != "word/document.xml":
                continue
            if bm is None and self.styles[i] == self.BAND_STYLE:
                pending = i
                continue
            m = re.match(r"^q(\d+)[a-z]*$", bm or "")
            if pending is not None and m:
                self.bands[pending] = int(m.group(1))
                pending = None

    def _part(self, part, root):
        open_bm, names, acc = {}, {}, {}
        stack = []                 # paragraph buffers: [list of (text, bookmark)]

        def emit(s):
            for i in open_bm:
                acc[names[i]].append(s)
            if stack:
                stack[-1].append((s, _innermost([names[i] for i in open_bm])))

        def walk(el):
            tag = el.tag
            if tag == _W + "bookmarkStart":
                i = el.get(_W + "id")
                names[i] = el.get(_W + "name") or ""
                acc.setdefault(names[i], [])
                open_bm[i] = True
                return
            if tag == _W + "bookmarkEnd":
                open_bm.pop(el.get(_W + "id"), None)
                return
            if tag in (_W + "t", _M + "t", _A + "t"):
                emit(el.text or u"")
                return
            if tag in (_W + "tab", _W + "br", _W + "cr"):
                emit(u" ")
                return
            is_p = tag in (_W + "p", _A + "p")
            style = None
            if is_p:
                stack.append([])
                if tag == _W + "p":
                    ps = el.find(_W + "pPr/" + _W + "pStyle")
                    style = ps.get(_W + "val") if ps is not None else None
            for ch in el:
                walk(ch)
            if is_p:
                toks = stack.pop()
                txt = re.sub(r"\s+", " ", u"".join(t for t, _b in toks)).strip()
                if txt:
                    bms = [b for _t, b in toks if b]
                    self.paragraphs.append((part, bms[0] if bms else None, txt))
                    self.styles.append(style)
                emit(u" ")
            elif tag == _W + "tc":
                emit(u" ")
        walk(root)
        for k, v in acc.items():
            t = re.sub(r"\s+", " ", u"".join(v)).strip()
            if k in self.bookmarks:
                t = self.bookmarks[k] + u" " + t
            self.bookmarks[k] = t


def _innermost(names):
    """The most specific q-bookmark among the open ones (q3b over q3)."""
    qs = [n for n in names if _QID.match(n or "")]
    if not qs:
        return None
    return sorted(qs, key=lambda n: (len(_QID.match(n).group(2)), n.startswith("ans_")))[-1]


class Printed(object):
    """The printed outputs of one level, loaded lazily, errors kept."""

    def __init__(self, deliver, docx_root, k, root=None):
        self.k = k
        self.dir = Path(deliver) / k
        self.docx_path = Path(docx_root) / k / "sheet.docx"
        self.errors = []
        self.sheet, e1 = _load_json(self.dir / "sheet.json", root)
        self.noam, e2 = _load_json(self.dir / "noam-ai.json", root)
        for e in (e1, e2):
            if e:
                self.errors.append(e)
        self.html = None
        hp = self.dir / "sheet.html"
        try:
            self.html = HtmlDoc(hp.read_text(encoding="utf-8"))
        except FileNotFoundError:
            self.errors.append("%s is missing" % _rel(hp, root))
        except Exception as e:
            self.errors.append("%s is unreadable: %r" % (_rel(hp, root), e))
        self.docx, self.docx_error = None, None
        if self.docx_path.is_file():
            try:
                self.docx = DocxDoc(self.docx_path)
            except Exception as e:
                self.docx_error = "%s is unreadable: %r" % (_rel(self.docx_path, root), e)
        else:
            self.docx_error = "%s is missing" % _rel(self.docx_path, root)


# ================================================================ context ===
class Ctx(object):
    """Everything the gates read about one package build."""

    def __init__(self, pkg_dir, out_dir, sheet, package, levels, deliver=None):
        self.pkg_dir = Path(pkg_dir)
        self.out_dir = Path(out_dir)
        self.sheet = sheet
        self.package = package
        self.levels = levels                       # {k: IR level dict}
        self.deliver = Path(deliver) if deliver else self.out_dir / "deliver"
        self._printed = {}
        self._src_strings = None                   # _source_strings cache (G86)
        # A sectioned package is one that ships sheet_meta.py (dev-contract
        # "Package format"); its SHEET may still fail to reach content.py.
        self.sheet_meta = (self.pkg_dir / "sheet_meta.py").is_file()

    @classmethod
    def from_package(cls, pkg_dir, out_dir=None):
        import pkgload
        P = pkgload.load(pkg_dir)
        out = Path(out_dir) if out_dir else Path(pkg_dir) / "out"
        deliver = out / "deliver"
        if not deliver.is_dir():
            try:
                deliver = pkgload.deliver_dir(pkg_dir)
            except Exception:
                pass
        return cls(pkg_dir, out, P.sheet, P.package, P.ir, deliver)

    @property
    def keys(self):
        return [k for k in LEVEL_KEYS if k in self.levels]

    @property
    def grade(self):
        return str(self.sheet.get("grade"))

    @property
    def sections(self):
        return list(self.sheet.get("sections") or [])

    def printed(self, k):
        if k not in self._printed:
            self._printed[k] = Printed(self.deliver, self.out_dir / "docx", k, self.out_dir)
        return self._printed[k]

    def section_qs(self, sec, k):
        q = (sec.get("questions") or {}).get(k)
        return [int(x) for x in q] if isinstance(q, (list, tuple)) else []

    def questions(self, k):
        return [q for q in (self.levels.get(k) or {}).get("questions", []) if q.get("n") is not None]

    def qmap(self, k):
        return dict((int(q["n"]), q) for q in self.questions(k))


def _items(q):
    out = []
    for it in q.get("items") or []:
        if isinstance(it, dict):
            out.append((it.get("label") or it.get("id"), it.get("text"), it.get("fig")))
        else:
            out.append((it[0], it[1], it[3] if len(it) > 3 else None))
    return out


def _example(q):
    ex = q.get("example")
    if not ex:
        return None, []
    if isinstance(ex, dict):
        return ex.get("title"), list(ex.get("lines") or [])
    title = ex[0] if len(ex) > 0 else None
    lines = ex[1] if len(ex) > 1 else []
    if isinstance(lines, str):
        lines = [lines]
    return title, list(lines or [])


def _n(s):
    return re.sub(r"\s+", " ", ST.normalize(s or u"")).strip()


def parse_range(rng):
    """'1-4' | '1–4' | '3, 5' | '5'  ->  sorted list of ints, or None."""
    if rng is None:
        return None
    s = ST.normalize(u"%s" % rng).strip()
    out = []
    for part in re.split(u"\\s*[,،]\\s*", s):
        m = re.fullmatch(u"(\\d+)\\s*(?:[-–—־]\\s*(\\d+))?", part.strip())
        if not m:
            return None
        a = int(m.group(1))
        b = int(m.group(2)) if m.group(2) else a
        if b < a:
            return None
        out.extend(range(a, b + 1))
    return sorted(set(out)) if out else None


def _justification(sec):
    j = sec.get("justification")
    return j.strip() if isinstance(j, str) and j.strip() else None


def _sec_label(sec):
    return u"%s (%s)" % (sec.get("id"), sec.get("title"))


# =================================================================== G85 ===
def gate_g85(ctx):
    """Volume per section (sectioned) or per level (broad), from the
    curriculum's volume_policy / volume_rule, never from numbers of our own."""
    vr = ST.volume_rule()
    vp = ST.volume_policy()
    scope = ctx.sheet.get("scope")
    lo_sub, hi_sub = int(vr["min_subitems_per_question"]), int(vr["max_subitems_per_question"])
    mean_min = float(vr["mean_subitems_per_question"])
    out = []
    secs = ctx.sections
    # The volume range belongs to a SUBTOPIC (its registry size_class), so the
    # count is per distinct subtopic id over every non-combo section that
    # carries it: one S subtopic split into "זוויות" 1-5 and "זוויות — תרגול
    # נוסף" 6-9 is 9 questions of one S subtopic, not 5 + 4 (review
    # 2026-11-09). G92 reports the split itself.
    groups, gi = [], {}
    for s in secs:
        if s.get("kind") == "combo":
            continue
        key = s.get("subtopic") or ("<no subtopic>", s.get("id"))
        if key not in gi:
            gi[key] = len(groups)
            groups.append((s.get("subtopic"), []))
        groups[gi[key]][1].append(s)
    single_s = False
    if len(groups) == 1 and groups[0][0]:
        e = ST.get(groups[0][0])
        single_s = bool(e and e.get("size_class") == "S")
    for k in ctx.keys:
        R = Rec(G85, k)
        qmap = ctx.qmap(k)
        if scope == "broad":
            _g85_broad(R, ctx, k, vr)
            out.append(R.out())
            continue
        if scope not in (vp.get("applies_to_scope") or ["sectioned"]):
            R.add("FAIL", "SHEET.scope %r is neither 'sectioned' nor 'broad'" % (scope,))
            out.append(R.out())
            continue
        units = []        # (label, question numbers, (lo, hi), why, justification, all optional)
        for sid, ss in groups:
            label = u" + ".join(_sec_label(s) for s in ss)
            if len(ss) > 1:
                label = u"subtopic %s, split over %s" % (sid, label)
            e = ST.get(sid) if sid else None
            if e is None:
                R.add("FAIL", "%s: subtopic %r is not in the registry, so its size class "
                              "is unknown" % (label, sid))
                continue
            size = e.get("size_class")
            if single_s:
                rng, why = ST.volume_range("single_S_sheet"), "single_S_sheet (the sheet's only "\
                    "subtopic is one S subtopic)"
            else:
                rng, why = ST.volume_range(size), "size %s" % size
            qs = sorted(set(n for s in ss for n in ctx.section_qs(s, k)))
            jus = u"; ".join(j for j in (_justification(s) for s in ss) if j) or None
            units.append((label, qs, rng, why, jus, all(s.get("optional") for s in ss)))
        for s in secs:
            if s.get("kind") == "combo":
                units.append((_sec_label(s), ctx.section_qs(s, k), ST.volume_range("combo"), "combo",
                              _justification(s), bool(s.get("optional"))))
        for label, qs, rng, why, jus, optional in units:
            if not qs and optional:
                R.note("%s is optional and empty in level %s" % (label, k))
                continue
            n = len(qs)
            if rng[0] <= n <= rng[1]:
                R.note("%s: %d main question(s), range %d-%d (%s)" % (label, n, rng[0], rng[1], why))
            elif jus:
                R.add("REVIEW", "%s: %d main question(s), outside %d-%d (%s); justification: %s"
                      % (label, n, rng[0], rng[1], why, jus))
            else:
                R.add("FAIL", "%s: %d main question(s) in level %s, outside %d-%d (%s), and the "
                              "section has no justification" % (label, n, k, rng[0], rng[1], why))
        for s in secs:
            qs = ctx.section_qs(s, k)
            jus = _justification(s)
            for qn in qs:
                q = qmap.get(qn)
                if q is None:
                    R.note("%s lists q%d, which level %s does not print (G92 reports it); its "
                           "sub-items were not counted" % (_sec_label(s), qn, k))
                    continue
                m = len(_items(q))
                if not (lo_sub <= m <= hi_sub):
                    msg = "%s q%d has %d sub-item(s), volume_rule wants %d-%d" % (
                        _sec_label(s), qn, m, lo_sub, hi_sub)
                    if jus:
                        R.add("REVIEW", msg + "; justification: " + jus)
                    else:
                        R.add("FAIL", msg)
        qs_all = ctx.questions(k)
        if qs_all:
            mean = sum(len(_items(q)) for q in qs_all) / float(len(qs_all))
            if mean + 1e-9 < mean_min:
                R.add("FAIL", "level %s: mean %.2f sub-items per question < %g (volume_rule)"
                      % (k, mean, mean_min))
            else:
                R.note("level %s: %d questions, mean %.2f sub-items (>= %g)" % (k, len(qs_all), mean, mean_min))
        else:
            R.add("FAIL", "level %s prints no question" % k)
        _g85_draw_from_words(R, ctx, k, vp)
        out.append(R.out())
    return out


def _g85_broad(R, ctx, k, vr):
    qs = ctx.questions(k)
    n = len(qs)
    if not n:
        R.add("FAIL", "level %s prints no question" % k)
        return
    drawn = sum(1 for q in qs if q.get("fig") or any(f for _l, _t, f in _items(q)))
    geo = drawn / float(n) >= 0.60
    min_q = int(vr["min_main_questions_geometry_sheet"] if geo else vr["min_main_questions_general"])
    min_t = int(vr["min_total_subitems_geometry"] if geo else vr["min_total_subitems_general"])
    subs = [len(_items(q)) for q in qs]
    kind = "geometry (%d%% drawn)" % round(100.0 * drawn / n) if geo else \
        "general (%d%% drawn)" % round(100.0 * drawn / n)
    if n < min_q:
        R.add("FAIL", "scope=broad, %s sheet: %d main questions < %d (volume_rule)" % (kind, n, min_q))
    if sum(subs) < min_t:
        R.add("FAIL", "scope=broad, %s sheet: %d sub-items < %d (volume_rule)" % (kind, sum(subs), min_t))
    lo, hi = int(vr["min_subitems_per_question"]), int(vr["max_subitems_per_question"])
    bad = [q["n"] for q, s in zip(qs, subs) if not (lo <= s <= hi)]
    if bad:
        R.add("FAIL", "scope=broad: q%s outside %d-%d sub-items" % (", q".join(map(str, bad)), lo, hi))
    mean = sum(subs) / float(n)
    if mean + 1e-9 < float(vr["mean_subitems_per_question"]):
        R.add("FAIL", "scope=broad: mean %.2f sub-items < %s" % (mean, vr["mean_subitems_per_question"]))
    R.note("scope=broad, %s: %d questions, %d sub-items, mean %.2f" % (kind, n, sum(subs), mean))


def _exempt(sheet, k, name="draw_from_words"):
    ex = sheet.get("small_sheet_exemptions") or {}
    v = None
    if isinstance(ex, dict):
        v = ex.get(name) or ex.get(name + "_min_per_level")
        if isinstance(v, dict):
            v = v.get(k)
    elif isinstance(ex, (list, tuple)) and name in ex:
        v = "named in small_sheet_exemptions (no reason given)"
    return v.strip() if isinstance(v, str) and v.strip() else None


def _g85_draw_from_words(R, ctx, k, vp):
    """small_sheet_absolute_minimums: >= 1 drawing-from-words question per
    level from N main questions. The signal is the one G83 uses: the level's
    words_share declaration (gate_figref.words_share), on a figure topic
    (gate_figref.topic_status). If either cannot be read: REVIEW, never PASS."""
    sm = vp.get("small_sheet_absolute_minimums") or {}
    need = int(sm.get("draw_from_words_min_per_level", 1))
    from_n = int(sm.get("draw_from_words_applies_when_main_questions_at_least", 4))
    L = ctx.levels.get(k) or {}
    n = len(ctx.questions(k))
    if n < from_n:
        R.note("level %s: %d main questions < %d, draw-from-words minimum not owed" % (k, n, from_n))
        return
    try:
        import gate_figref as GF
        st = GF.topic_status(L, ctx.package)
        ws = GF.words_share(L)
    except Exception as e:
        R.add("REVIEW", "level %s: the drawing-from-words signal (gate_figref.words_share / "
                        "topic_status) could not be read: %r" % (k, e))
        return
    if st.get("figure") is not True:
        R.note("level %s: not a figure topic (%s), draw-from-words minimum not applicable"
               % (k, st.get("source")))
        return
    if st.get("deferred"):
        R.add("REVIEW", "level %s: figure-topic status deferred (%s); draw-from-words not "
                        "verified" % (k, st.get("deferred")))
        return
    nums = set(int(q["n"]) for q in ctx.questions(k))
    have = sorted(int(x) for x in (ws or {}) if int(x) in nums)
    if len(have) >= need:
        R.note("level %s: drawing-from-words q%s (>= %d)" % (k, ", q".join(map(str, have)), need))
        return
    ex = _exempt(ctx.sheet, k)
    if ex:
        R.add("REVIEW", "level %s: %d drawing-from-words question(s) < %d, exempt by "
                        "SHEET.small_sheet_exemptions: %s" % (k, len(have), need, ex))
    else:
        R.add("FAIL", "level %s has %d main questions and %d drawing-from-words question(s); "
                      "small_sheet_absolute_minimums wants >= %d (or a reason in "
                      "SHEET.small_sheet_exemptions)" % (k, n, len(have), need))


# =================================================================== G86 ===
def _term_grades(ctx):
    """The grades whose forbidden lists G86 applies: SHEET.grade plus every
    grade a level's own curriculum dict claims. They agree on a sound package
    (G88 FAILs when they do not); when they disagree, scanning with all of them
    keeps a mislabelled SHEET.grade from switching off a grade-only rule such
    as mashlimot_term_g7 (review 2026-11-09)."""
    gs = [ctx.grade]
    for k in ctx.keys:
        cur = (ctx.levels.get(k) or {}).get("curriculum")
        if isinstance(cur, dict) and cur.get("grade") is not None:
            gs.append(str(cur.get("grade")))
    return sorted(set(gs))


def _g86_scan(R, grade, house, label, text, house_review=None, house_note=None):
    """house_review: when set, a house-spelling hit is REVIEW with this
    advice instead of FAIL (only the engine's own default aux label, see
    _aux_default_label_at); forbidden terms are FAIL whatever it says.
    house_note: appended to a house-spelling FAIL (why it is not softened)."""
    seen = set()
    for g in (grade if isinstance(grade, (list, tuple)) else [grade]):
        for h in ST.forbidden_hits(text, g):
            if (h["id"], h["span"]) in seen:
                continue
            seen.add((h["id"], h["span"]))
            R.add("FAIL", u"%s: forbidden '%s' [%s]; use instead: %s"
                  % (label, h["match"], h["id"], h.get("use_instead")))
    if house:
        for h in ST.house_spelling_hits(text):
            if house_review:
                R.add("REVIEW", u"%s: house spelling '%s' (write %s); %s"
                      % (label, h["match"], h["preferred"], house_review))
            else:
                R.add("FAIL", u"%s: house spelling '%s'; write %s%s" % (label, h["match"], h["preferred"],
                                                                     (u" " + house_note) if house_note else u""))


_AUX_LABEL_PATHS = (re.compile(r"^/figures\[(\d+)\]/visual_model/aux\[\d+\]/label$"),
                    re.compile(r"^/figures\[(\d+)\]/label$"))
_AUX_FIX = (u"it is the locked engine's default aux-figure label (didactic.AUX_LABEL), written because "
            u"the aux dict names no label (no string literal of the package source is this label); add "
            u"label=u\"סרטוט עזר\" to the aux dict (aux=[dict(fig=..., step=..., label=u\"סרטוט עזר\")])")
_AUX_AUTHOR = (u"(the engine's default aux label, but the package source writes this string itself -- "
               u"e.g. label=u\"שרטוט עזר\" -- so it is the author's text: write label=u\"סרטוט עזר\")")


def _source_strings(ctx):
    """Every string literal of the package's own Python sources -- the
    package folder's *.py and the copies deliver keeps in
    deliver/<k>/source/*.py -- normalized with _n, as (literals, raw): the
    files are parsed with ast, never imported; a file that does not parse
    adds its whole normalized text to raw, so a literal cannot hide in it.
    Cached on ctx."""
    cached = getattr(ctx, "_src_strings", None)
    if cached is not None:
        return cached
    lits, raw = set(), []
    files = sorted(Path(ctx.pkg_dir).glob("*.py")) + sorted(Path(ctx.deliver).glob("*/source/*.py"))
    for f in files:
        try:
            text = f.read_text(encoding="utf-8")
        except Exception:
            continue
        try:
            tree = ast.parse(text)
        except Exception:
            raw.append(_n(text))
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Constant) and isinstance(node.value, str):
                lits.add(_n(node.value))
    ctx._src_strings = (lits, raw)
    return ctx._src_strings


def _source_writes(ctx, s):
    """True when the package source itself has the string s (a literal equal
    to it after _n, or the text of a file that does not parse contains it)."""
    lits, raw = _source_strings(ctx)
    t = _n(s)
    return bool(t) and (t in lits or any(t in r for r in raw))


def _aux_default_label():
    """didactic.AUX_LABEL, read from the locked module (never copied here, so
    an engine change of the default is followed), or None if it cannot be
    imported -- then no hit is softened."""
    try:
        import didactic
        lab = getattr(didactic, "AUX_LABEL", None)
        return lab if isinstance(lab, str) and lab.strip() else None
    except Exception:
        return None


def _aux_default_label_at(obj, path, s, default):
    """True when string s at JSON path is the engine's default label of an
    aux figure: s is exactly didactic.AUX_LABEL, and it sits where deliver /
    visual_model write that label -- /figures[i]/visual_model/aux[j]/label,
    or /figures[i]/label of a figure deliver marked aux.

    WHY REVIEW, NOT FAIL: the locked engine writes AUX_LABEL ('שרטוט עזר')
    into sheet.json and noam-ai.json for every aux=[dict(fig=..., step=...)]
    without a label, so a FAIL blamed the author for a string the author
    never wrote; the cure (label=u"סרטוט עזר" on the aux dict) is named in the
    message. The same string anywhere else, or any other spelling at these
    paths, is the author's text and stays FAIL; so does this one when the
    package source itself writes it (gate_g86, _source_writes): the printed
    output cannot tell label=u"שרטוט עזר" from no label, the source can
    (review round 3, VB1)."""
    if not default or s != default or not isinstance(obj, dict):
        return False
    for rx in _AUX_LABEL_PATHS:
        m = rx.match(path)
        if not m:
            continue
        figs = obj.get("figures")
        i = int(m.group(1))
        if not isinstance(figs, list) or i >= len(figs) or not isinstance(figs[i], dict):
            return False
        if rx is _AUX_LABEL_PATHS[1]:
            return figs[i].get("aux") is True
        return True
    return False


def _g86_json(R, grade, house, fname, obj, aux_default=None, author_wrote=False):
    """author_wrote: the package source itself writes aux_default, so a hit
    at an aux label path is the author's text (FAIL with _AUX_AUTHOR)."""
    for path, s, qid in walk_strings(obj):
        if _excluded(path):
            continue
        soft = note = None
        if _aux_default_label_at(obj, path, s, aux_default):
            if author_wrote:
                note = _AUX_AUTHOR
            else:
                soft = _AUX_FIX
        _g86_scan(R, grade, house, u"%s %s%s" % (fname, path, (" (%s)" % qid) if qid else ""), s,
                  house_review=soft, house_note=note)


def gate_g86(ctx):
    """Forbidden terms and house spelling in everything printed."""
    grade = _term_grades(ctx)
    house = ST.house_spelling_applies(ctx.sheet.get("scope"))
    aux_default = _aux_default_label() if house else None
    author_wrote = bool(aux_default) and _source_writes(ctx, aux_default)
    out = []
    for k in ctx.keys:
        R = Rec(G86, k)
        P = ctx.printed(k)
        for e in P.errors:
            R.add("FAIL", "printed output not available, terms not verified: %s" % e)
        if P.html is not None:
            for c, t in P.html.blocks:
                _g86_scan(R, grade, house, u"sheet.html [%s]" % c, t)
        if P.sheet is not None:
            _g86_json(R, grade, house, "sheet.json", P.sheet, aux_default, author_wrote)
        if P.noam is not None:
            _g86_json(R, grade, house, "noam-ai.json", P.noam, aux_default, author_wrote)
        if P.docx is not None:
            for part, bm, t in P.docx.paragraphs:
                _g86_scan(R, grade, house, u"sheet.docx %s [%s]" % (part, bm or "-"), t)
        else:
            R.add("REVIEW", "DOCX not scanned: %s" % P.docx_error)
        R.note("scanned: forbidden (grade %s)%s; excluded %s" % (
            "+".join(grade), ", house spelling (scope=%s)" % ctx.sheet.get("scope") if house else
            ", house spelling not applicable (scope=%s)" % ctx.sheet.get("scope"),
            ", ".join(sorted(G86_EXCLUDE))))
        out.append(R.out())
    R = Rec(G86, None)
    _g86_scan(R, grade, house, u"SHEET.title", ctx.sheet.get("title") or u"")
    for s in ctx.sections:
        _g86_scan(R, grade, house, u"SHEET section %s title" % s.get("id"), s.get("title") or u"")
    cdir = ctx.out_dir / "catalog" / str(ctx.sheet.get("sheet_id"))
    for fname in ("catalog-entry.json", "landing.json"):
        obj, err = _load_json(cdir / fname, ctx.out_dir)
        if err:
            R.add("REVIEW", "not scanned: %s (G89 reports a missing catalog)" % err)
            continue
        _g86_json(R, grade, house, "catalog/%s" % fname, obj)
    out.append(R.out())
    return out


# =================================================================== G87 ===
def _q_texts(ctx, k, P):
    """Every printed string of a level, from the IR and from each printed
    output, as three groups:
      qt    {n: [(source, text)]}  the strings of question n;
      bands {n: [(source, text)]}  the part band printed on / before q n;
      nav   [(source, text)]       title, rule box, headers: navigation.

    WHY BANDS ARE NOT NAVIGATION: a band is the title of the section it
    opens, printed at that point of the sheet. Checked as navigation (at the
    sheet's last section) a band 'זוויות צמודות וזוויות קודקודיות' over the
    adjacent section passed although it names the later subtopic (review
    S-F1); G87 checks it at its own section's position. The rule box and the
    title announce the whole sheet and stay navigation. A band text that
    cannot be tied to a question (an HTML band block the band parser did not
    read, a DOCX heading not followed by a q<n> paragraph) stays navigation,
    so nothing is checked less strictly than before."""
    L = ctx.levels.get(k) or {}
    qt, bands = {}, {}

    def add(n, src, t):
        if isinstance(t, str) and t.strip():
            qt.setdefault(int(n), []).append((src, t))

    def band(n, src, t):
        if isinstance(t, str) and t.strip():
            bands.setdefault(int(n), []).append((src, t))

    nav = []
    for key in ("title", "subtitle", "rule", "level", "grade", "ansnote"):
        if isinstance(L.get(key), str):
            nav.append(("IR %s" % key, L[key]))
    for q in ctx.questions(k):
        n = int(q["n"])
        if q.get("part"):
            band(n, "IR band q%d" % n, u"%s" % q["part"][0])
        add(n, "IR stem", q.get("intro"))
        add(n, "IR stem", q.get("text"))
        for lab, t, _f in _items(q):
            add(n, "IR item %s" % lab, t)
        title, lines = _example(q)
        add(n, "IR example title", title)
        for ln in lines:
            add(n, "IR example", ln)
        if q.get("table") is not None:
            for _p, s, _q in walk_strings(q.get("table")):
                add(n, "IR table", s)
    for n, ans in L.get("answers") or []:
        for row in ans or []:
            if isinstance(row, (list, tuple)):
                for t in row[1:]:
                    add(n, "IR answer", t)
            else:
                add(n, "IR answer", row)

    def from_json(obj, fname):
        if not obj:
            return
        for q in obj.get("questions") or []:
            m = _QID.match(u"%s" % q.get("id"))
            if not m:
                continue
            for path, s, _qid in walk_strings(q):
                add(int(m.group(1)), "%s %s%s" % (fname, q.get("id"), path), s)
        for f in obj.get("figures") or []:
            m = _QID.match(u"%s" % f.get("question"))
            if m:
                for path, s, _qid in walk_strings(f):
                    add(int(m.group(1)), "%s figure %s" % (fname, f.get("id")), s)
        for key in ("title", "subtitle", "grade"):
            if isinstance(obj.get(key), str):
                nav.append(("%s %s" % (fname, key), obj[key]))

    from_json(P.sheet, "sheet.json")
    from_json(P.noam, "noam-ai.json")
    if P.html is not None:
        # the band blocks in document order, tied to HtmlDoc.bands (title,
        # range, next question number) by order and by their title
        hb = [b for b in P.html.bands]
        j = 0
        for c, t in P.html.blocks:
            m = re.match(r"^q(\d+)$", c or "")
            if m:
                add(int(m.group(1)), "sheet.html", t)
            elif (c == "nav:band" and j < len(hb) and hb[j][2] is not None
                  and _n(t).startswith(_n(hb[j][0]))):
                band(hb[j][2], "sheet.html band", t)
                j += 1
            else:
                nav.append(("sheet.html [%s]" % c, t))
    if P.docx is not None:
        for name, t in P.docx.bookmarks.items():
            m = _QID.match(name)
            if m:
                add(int(m.group(1)), "sheet.docx bookmark %s" % name, t)
        for i, (part, bm, t) in enumerate(P.docx.paragraphs):
            if bm:
                continue
            if i in P.docx.bands:
                band(P.docx.bands[i], "sheet.docx band", t)
            else:
                nav.append(("sheet.docx %s" % part, t))
    return qt, nav, bands


_END = 10 ** 6


def _place_elsewhere(ctx, s, track, reg_track, reg_topic, R):
    """The position of a section whose subtopic is registered under another
    track (grade-9 level b of a ט_רגילה sheet) and whose topic id is not in
    sequences[track].

    WHY NOT A PLAIN FAIL: 16 of the 22 ט_רגילה topic ids do not exist in
    ט_מצומצמת, although several are taught there under other ids
    (parallels_trapezoid ~ parallels_and_parallelogram, kite ~
    kite_and_isosceles). "Not in the sequence" therefore proves nothing. The
    contract fails level b only for what the track does not teach, so:
      1. the curriculum's not-in-track lists cover the subtopic -> FAIL;
      2. an explicit equivalence places it (registry equivalent_by_track, or
         allowed_from_by_track of the terms it introduces) -> that position;
      3. otherwise -> REVIEW, and the section's terms are checked against
         the end of the grade in that track: any term the track never teaches
         (a ט_רגילה-only allowed_from, a not-in-track keyword) still FAILs,
         only the order inside the year goes unchecked."""
    grade = ctx.grade
    sub = s["subtopic"]
    why = ST.not_in_track_reasons(track, sub)
    if why:
        R.add("FAIL", "%s: this level is checked against track %s, and %s (subtopic %s, registered under "
                      "%s); nothing of this section may be printed at this level"
              % (_sec_label(s), track, "; ".join(why), sub, reg_track))
        return None
    eq, ewhy = ST.equivalent_position(grade, track, sub)
    if eq is not None:
        R.note("%s: subtopic %s (topic %s of %s) placed in %s by %s"
               % (_sec_label(s), sub, reg_topic, reg_track, track, ewhy))
        return eq
    R.add("REVIEW", "%s: topic %s (subtopic %s, registered under %s) has no place in sequences[%s] and no "
                    "declared equivalent there (registry equivalent_by_track, or allowed_from_by_track of "
                    "a term it introduces), and the not-in-track lists of %s do not name it; its order "
                    "inside the %s year cannot be checked, so its terms were checked against the end of "
                    "grade %s in %s (a term %s never teaches still FAILs)"
          % (_sec_label(s), reg_topic, sub, reg_track, track, track, track, grade, track, track))
    return (int(grade), _END, _END)


def _section_positions(ctx, track, R):
    """[(section, position or None)] for a level's track, with FAILs for an
    unknown subtopic or what the track does not teach (see _place_elsewhere)."""
    grade = ctx.grade
    res, by_id = [], {}
    topic = ctx.sheet.get("topic_id")
    for s in ctx.sections:
        pos = None
        if s.get("kind") == "combo":
            ids = s.get("combines") or [x.get("id") for x in ctx.sections
                                        if x.get("kind") != "combo" and x is not s]
            ps = [by_id.get(i) for i in ids if by_id.get(i) is not None]
            missing = [i for i in ids if i not in by_id]
            if missing:
                R.add("FAIL", "combo %s combines %s, which no earlier section defines"
                      % (s.get("id"), ", ".join(map(str, missing))))
            pos = max(ps) if ps else None
        elif s.get("subtopic"):
            loc = ST.locate(s["subtopic"])
            if loc is None:
                R.add("FAIL", "%s: subtopic %r is not in the registry" % (_sec_label(s), s.get("subtopic")))
            else:
                reg_track, reg_topic, entry = loc
                if topic and reg_topic != topic:
                    R.add("FAIL", "%s: subtopic %s belongs to topic %s, SHEET.topic_id is %s"
                          % (_sec_label(s), s["subtopic"], reg_topic, topic))
                pos = ST.position(grade, track, reg_topic, s["subtopic"])
                if pos is None and reg_track == track:
                    # the registry and curriculum_tools disagree: a data defect
                    R.add("FAIL", "%s: topic %s is registered under track %s but is missing from "
                                  "sequences[%s] (curriculum_tools.json), so the section's place in "
                                  "the teaching order cannot be computed"
                          % (_sec_label(s), reg_topic, track, track))
                elif pos is None:
                    pos = _place_elsewhere(ctx, s, track, reg_track, reg_topic, R)
                elif reg_track != track:
                    R.note("%s: subtopic registered under %s, checked at its topic's place in %s"
                           % (_sec_label(s), reg_track, track))
        else:
            ti = ST.topic_index(track, topic) if topic else None
            pos = (int(grade), ti, 10 ** 6) if ti is not None else None
            if pos is None:
                R.add("FAIL", "%s: no subtopic, and SHEET.topic_id %r is not in sequences[%s]"
                      % (_sec_label(s), topic, track))
        by_id[s.get("id")] = pos
        res.append((s, pos))
    return res


def gate_g87(ctx):
    """Subtopic chronology of every printed term (glossary allowed_from)."""
    grade = ctx.grade
    out = []
    cache = {}

    def terms(t):
        key = ST.normalize(t)
        if key not in cache:
            cache[key] = ST.find_terms(key)
        return cache[key]

    for k in ctx.keys:
        R = Rec(G87, k)
        track = ST.track_for(grade, k, ctx.sheet)
        P = ctx.printed(k)
        for e in P.errors:
            R.add("FAIL", "printed output not available (%s); the IR was still checked" % e)
        if P.docx is None:
            # as in G86: a term only the Word file carries would go unseen, so a
            # missing DOCX narrows the check and is never a silent PASS
            R.add("REVIEW", "DOCX not scanned: %s (the IR, sheet.json, noam-ai.json and sheet.html "
                            "were)" % P.docx_error)
        secs = _section_positions(ctx, track, R)
        positions = [p for _s, p in secs if p is not None]
        sheet_pos = max(positions) if positions else None
        qt, nav, bands = _q_texts(ctx, k, P)
        # terms introduced by LATER subtopic sections of this sheet
        later = []
        for i, (s, _p) in enumerate(secs):
            own = set()
            for s2, _p2 in secs[:i + 1]:
                if s2.get("subtopic"):
                    own |= ST.terms_introduced_by(s2["subtopic"])
            lt = {}
            for s2, _p2 in secs[i + 1:]:
                if s2.get("subtopic") and s2.get("kind") != "combo":
                    for tk in ST.terms_introduced_by(s2["subtopic"]) - own:
                        lt.setdefault(tk, s2)
            later.append(lt)
        found = {}

        def check(where, n, texts, pos, lt):
            for src, t in texts:
                for tk, mt, _sp in terms(t):
                    ok, why = ST.term_allowed(tk, grade, track, pos)
                    reasons = []
                    if not ok:
                        reasons.append(why)
                    if lt and tk in lt:
                        reasons.append("introduced by the later section %s" % _sec_label(lt[tk]))
                    if reasons:
                        key = (where, n, tk, mt)
                        found.setdefault(key, [set(), reasons])[0].add(src)

        covered = set()
        for i, (s, pos) in enumerate(secs):
            for n in ctx.section_qs(s, k):
                covered.add(n)
                check(_sec_label(s), n, qt.get(n, []), pos, later[i])
                # the band on q n is a title of this section: same position,
                # same later-section terms (a section whose position is
                # unknown -- already a FAIL -- checks it at the sheet's end)
                check(u"%s band" % _sec_label(s), n, bands.get(n, []),
                      pos if pos is not None else sheet_pos, later[i])
        for n in sorted(set(qt) - covered):
            check("no section (G92 reports it)", n, qt[n], sheet_pos, None)
        for n in sorted(set(bands) - covered):
            check("band on a question of no section (G92 reports it)", n, bands[n], sheet_pos, None)
        check("navigation text (title/rule box), checked at the sheet's last section",
              None, nav, sheet_pos, None)
        for (where, n, tk, mt), (srcs, reasons) in sorted(found.items(), key=lambda x: (str(x[0][1]), x[0][2])):
            R.add("FAIL", u"level %s, %s%s: term %s '%s' -- %s [seen in: %s]"
                  % (k, where, (", q%d" % n) if n else "", tk, mt, "; ".join(dict.fromkeys(reasons)),
                     ", ".join(sorted(srcs))))
        # what the level's track does not teach (grade 9 level b: ט_מצומצמת)
        allt = [(("q%d" % n), src, t) for n, lst in qt.items() for src, t in lst] + \
               [(("band q%d" % n), src, t) for n, lst in bands.items() for src, t in lst] + \
               [("nav", src, t) for src, t in nav]
        hits = {}
        for qid, src, t in allt:
            for h in ST.not_in_track_hits(t, track):
                hits.setdefault((qid, h["topic"], h["match"]), set()).add(src)
        for (qid, topic, mt), srcs in sorted(hits.items()):
            R.add("FAIL", u"level %s (track %s), %s: '%s' belongs to '%s', which track %s does "
                          u"not teach [seen in: %s]" % (k, track, qid, mt, topic, track, ", ".join(sorted(srcs))))
        R.note("level %s checked against track %s; %d question(s), sheet position %s"
               % (k, track, len(qt), sheet_pos))
        out.append(R.out())
    return out


# =================================================================== G88 ===
GRADE_LETTER = {"7": u"ז", "8": u"ח", "9": u"ט"}


def _declared_tracks(sheet, k=None):
    """The track(s) SHEET declares: SHEET.track (str, or a per-level dict) and
    SHEET.track_by_level -- for one level when k is given, else all of them."""
    out = []
    for v in (sheet.get("track"), sheet.get("track_by_level")):
        if isinstance(v, str) and v:
            out.append(v)
        elif isinstance(v, dict):
            out.extend(t for kk, t in v.items() if isinstance(t, str) and t and (k is None or kk == k))
    return out


def _g88_meta(ctx, R0):
    """SHEET.grade / track / sheet_id against each other and the registry.

    WHY: G86 picks its forbidden list and G87 its chronology from SHEET.grade
    and track. A manifest copied from another sheet (grade 8 on a grade-7
    sheet) would switch rules off silently (review 2026-11-09), so the
    manifest is held against what the package itself says: the levels'
    curriculum dicts and printed grade (per level, below) and the registry
    track of every section's subtopic (here)."""
    g = ctx.grade
    if g not in GRADE_LETTER:
        R0.add("FAIL", "SHEET.grade %r is not 7, 8 or 9" % (ctx.sheet.get("grade"),))
        return
    ok_tracks = ST.tracks_for_grade(g)
    declared = _declared_tracks(ctx.sheet)
    if not declared:
        R0.add("FAIL", "SHEET.track is missing (grade %s expects %s)" % (g, " or ".join(ok_tracks)))
    for t in declared:
        if t not in ok_tracks:
            R0.add("FAIL", "SHEET.track %r does not fit SHEET.grade %s (expected %s)"
                   % (t, g, " or ".join(ok_tracks)))
    sid = u"%s" % ctx.sheet.get("sheet_id")
    m = re.match(r"^G(\d+)-", sid)
    if not m or m.group(1) != g:
        R0.add("FAIL", "SHEET.sheet_id %r does not start with 'G%s-' (catalog id grammar "
                       "G<grade>-<TOPIC3>-<NN>, SHEET.grade %s)" % (sid, g, g))
    for s in ctx.sections:
        if not s.get("subtopic"):
            continue
        loc = ST.locate(s["subtopic"])
        if loc is None:
            continue                       # G85/G87 report an unknown subtopic
        rg = ST.grade_of_track(loc[0])
        if rg != g:
            R0.add("FAIL", "%s: subtopic %s is registered under track %s (grade %s), SHEET.grade is %s"
                   % (_sec_label(s), s["subtopic"], loc[0], rg, g))


def _per_level_tracks(sheet, k):
    """SHEET's own entries for level k: SHEET.track[k] (when SHEET.track is a
    per-level dict) and SHEET.track_by_level[k], in that order."""
    out = []
    for v in (sheet.get("track"), sheet.get("track_by_level")):
        if isinstance(v, dict) and isinstance(v.get(k), str) and v.get(k):
            out.append(v[k])
    return out


def _level_tracks(sheet, g, k, R=None):
    """The track(s) level k's curriculum dict and noam-ai.json may name.

    A per-level entry (SHEET.track_by_level[k], or SHEET.track[k] when
    SHEET.track is a dict) IS the level's track: it alone is accepted, and
    it must be the track ST.track_for gives the level (the one G87 checks
    the level against); R, when given, gets a FAIL when SHEET's entries
    disagree with each other or with track_for.
    WHY: the sheet-wide SHEET.track string used to be accepted next to the
    per-level entry, so a level SHEET moves to ט_מצומצמת could still tell the
    AI tutor ט_רגילה and pass (review D-F6, round 3).
    Without a per-level entry the level may name the sheet-wide SHEET.track
    string or its house mapping (ST.track_for): a grade-9 ט_רגילה sheet's
    level b may say ט_רגילה or ט_מצומצמת (by design, E88-8)."""
    tf = ST.track_for(g, k, sheet)
    per = _per_level_tracks(sheet, k)
    if per:
        if R is not None and len(set(per)) > 1:
            R.add("FAIL", "level %s: SHEET.track[%r] %r != SHEET.track_by_level[%r] %r (one track per level)"
                  % (k, k, per[0], k, per[1]))
        elif R is not None and per[0] != tf:
            R.add("FAIL", "level %s: SHEET.track_by_level[%r] is %r, but SHEET.track is a per-level dict "
                          "without %r, so ST.track_for (and G87) use %r; declare the level's track in one "
                          "place" % (k, k, per[0], k, tf))
        return {tf}
    want = {tf}
    tr = sheet.get("track")
    if isinstance(tr, str) and tr:
        want.add(tr)
    return want


def _g88_level_meta(ctx, k, R, P):
    """One level's own curriculum dict and printed grade against SHEET."""
    g, topic = ctx.grade, ctx.sheet.get("topic_id")
    L = ctx.levels.get(k) or {}
    cur = L.get("curriculum")
    want_tracks = _level_tracks(ctx.sheet, g, k, R)
    if not isinstance(cur, dict):
        R.add("REVIEW", "level %s has no curriculum dict, so SHEET.grade/track/topic_id could not be "
                        "held against it" % k)
    else:
        if str(cur.get("grade")) != g:
            R.add("FAIL", "level %s curriculum grade %r != SHEET.grade %r" % (k, cur.get("grade"), g))
        if cur.get("topic") != topic:
            R.add("FAIL", "level %s curriculum topic %r != SHEET.topic_id %r" % (k, cur.get("topic"), topic))
        if cur.get("track") not in want_tracks:
            R.add("FAIL", "level %s curriculum track %r, SHEET declares %s for it"
                  % (k, cur.get("track"), " or ".join(sorted(want_tracks))))
    letter = GRADE_LETTER.get(g)
    for label, t in (("IR grade line", L.get("grade")),
                     ("printed sheet.json grade", (P.sheet or {}).get("grade") if P.sheet else None)):
        if not isinstance(t, str):
            continue
        m = re.search(u"כיתה\\s+([א-ת])", _n(t))
        if m and letter and m.group(1) != letter:
            R.add("FAIL", "level %s %s %r does not name grade %s (כיתה %s׳)" % (k, label, t, g, letter))
    # noam-ai.json is what the AI tutor reads to choose the tools it may use:
    # its curriculum grade, track and topic must be the ones SHEET declares for
    # this level (track: _level_tracks -- the level's own SHEET entry when it
    # has one, else SHEET.track or the house mapping of ST.track_for; the same
    # set the IR dict is held to). A missing file is a
    # FAIL in gate_g88 (P.errors), a missing block or key is a FAIL here:
    # deliver writes all three whenever the level has a curriculum dict, so
    # nothing may be skipped silently (review D-F6).
    if P.noam is None:
        return
    pc = P.noam.get("curriculum") if isinstance(P.noam, dict) else None
    if not isinstance(pc, dict):
        if isinstance(cur, dict):
            R.add("FAIL", "level %s noam-ai.json has no curriculum block although the level declares one, "
                          "so the AI tutor's grade/track/topic could not be held against SHEET" % k)
        else:
            R.add("REVIEW", "level %s noam-ai.json has no curriculum block (the level declares none either)" % k)
        return
    if str(pc.get("grade")) != g:
        R.add("FAIL", "level %s noam-ai.json curriculum grade %r != SHEET.grade %r" % (k, pc.get("grade"), g))
    if pc.get("topic") != topic:
        R.add("FAIL", "level %s noam-ai.json curriculum topic %r != SHEET.topic_id %r"
              % (k, pc.get("topic"), topic))
    if pc.get("track") not in want_tracks:
        R.add("FAIL", "level %s noam-ai.json curriculum track %r, SHEET declares %s for it"
              % (k, pc.get("track"), " or ".join(sorted(want_tracks))))
    elif isinstance(cur, dict) and cur.get("track") and pc.get("track") != cur.get("track"):
        R.add("FAIL", "level %s noam-ai.json curriculum track %r != the level's curriculum track %r "
                      "(deliver prints the level's own track)" % (k, pc.get("track"), cur.get("track")))


def gate_g88(ctx):
    """The same sections in a, b and c; SHEET's identity agrees with the package."""
    out = []
    R0 = Rec(G88, None)
    missing = [k for k in LEVEL_KEYS if k not in ctx.levels]
    if missing:
        R0.add("FAIL", "the package builds levels %s; a sectioned sheet needs a, b and c (missing %s)"
               % (",".join(ctx.keys) or "-", ",".join(missing)))
    if ctx.sheet.get("package") != ctx.package:
        R0.add("FAIL", "SHEET.package %r != content.PACKAGE %r" % (ctx.sheet.get("package"), ctx.package))
    _g88_meta(ctx, R0)
    for s in ctx.sections:
        qd = s.get("questions") or {}
        counts = dict((k, len(ctx.section_qs(s, k))) for k in LEVEL_KEYS)
        if len(set(counts.values())) > 1:
            msg = "%s: question counts differ across levels (%s)" % (
                _sec_label(s), ", ".join("%s=%d" % kv for kv in sorted(counts.items())))
            if _justification(s):
                R0.add("REVIEW", msg + "; justification: " + _justification(s))
            else:
                R0.add("FAIL", msg + " and the section has no justification")
        for k in LEVEL_KEYS:
            if k not in qd:
                R0.add("FAIL", "%s: SHEET.questions has no key %r" % (_sec_label(s), k))
    out.append(R0.out())
    ref_titles = None
    for k in ctx.keys:
        R = Rec(G88, k)
        for s in ctx.sections:
            if not ctx.section_qs(s, k) and not s.get("optional"):
                R.add("FAIL", "%s has no question in level %s (every %s section must be present "
                              "in a, b and c unless optional)" % (_sec_label(s), k, s.get("kind") or "subtopic"))
        L = ctx.levels.get(k) or {}
        if L.get("title") != ctx.sheet.get("title"):
            R.add("FAIL", "level %s title %r != SHEET.title %r" % (k, L.get("title"), ctx.sheet.get("title")))
        P = ctx.printed(k)
        for e in P.errors:
            # as in G86/G87/G92: the printed identity (title, grade line,
            # noam-ai.json curriculum) cannot be verified, never a silent PASS
            R.add("FAIL", "printed output not available, level %s not verified against it: %s" % (k, e))
        if P.sheet is not None and P.sheet.get("title") != ctx.sheet.get("title"):
            R.add("FAIL", "printed sheet.json title %r != SHEET.title" % (P.sheet.get("title"),))
        _g88_level_meta(ctx, k, R, P)
        bands = [_n(q["part"][0]) for q in ctx.questions(k) if q.get("part")]
        if ref_titles is None:
            ref_titles = (k, bands)
        elif bands != ref_titles[1]:
            R.add("FAIL", "level %s prints the bands %s, level %s prints %s (same sections, same "
                          "order, same titles in every level)" % (k, bands, ref_titles[0], ref_titles[1]))
        # a band IS its section's title (normalized equality, as G92): a band
        # that only contains it ('זוויות צמודות וזוויות קודקודיות' over the
        # adjacent section) names more than its section (review S-F1)
        want = [_n(s.get("title")) for s in ctx.sections if ctx.section_qs(s, k)]
        if len(bands) != len(want) or any(w != b for w, b in zip(want, bands)):
            R.add("FAIL", "level %s band titles %s do not follow the SHEET sections %s (one band per "
                          "section, in order, each equal to its section title)" % (k, bands, want))
        if R.status == "PASS":
            R.note("level %s: %d section(s) present, bands %s" % (k, len(want), bands))
        out.append(R.out())
    return out


# =================================================================== G89 ===
def gate_g89(ctx):
    """Dispatch to selfcheck_catalog.check (written by the catalog builder).
    A missing checker or entry is a FAIL for a sectioned sheet, never SKIP:
    the catalog is a deliverable of every SHEET build."""
    R = Rec(G89, None)
    entry = ctx.out_dir / "catalog" / str(ctx.sheet.get("sheet_id")) / "catalog-entry.json"
    try:
        import importlib
        mod = importlib.import_module("selfcheck_catalog")
    except ImportError as e:
        R.add("FAIL", "selfcheck_catalog.py is missing or does not import (%r): G89 cannot run" % e)
        return [R.out()]
    if not entry.is_file():
        R.add("FAIL", "catalog entry %s is missing (catalog_build did not run or failed)"
              % _rel(entry, ctx.out_dir))
        return [R.out()]
    fn = getattr(mod, "check", None)
    if not callable(fn):
        R.add("FAIL", "selfcheck_catalog has no check(entry_path, deliver_root)")
        return [R.out()]
    try:
        # Hand G89 the SHEET pkgload already read from the package, so a
        # sheet_meta.py that imports a constant is accepted here exactly as
        # pkgload and catalog_build accept it (catalog fix, 2026-11-09).
        # A checker without the keyword still gets the two-argument call.
        try:
            res = fn(str(entry), str(ctx.deliver), sheet=ctx.sheet)
        except TypeError:
            res = fn(str(entry), str(ctx.deliver))
    except Exception as e:
        R.add("FAIL", "selfcheck_catalog.check raised %r" % e)
        return [R.out()]
    st = (res or {}).get("status")
    msgs = [u"%s" % m for m in ((res or {}).get("messages") or [])]
    if st not in ("PASS", "FAIL", "REVIEW"):
        # SKIP included: a sheet with a SHEET must never skip its catalog check
        R.add("FAIL", "selfcheck_catalog.check returned status %r for a sectioned sheet: %s"
              % (st, "; ".join(msgs) or "(no message)"))
    elif st != "PASS":
        R.add(st, "selfcheck_catalog: %s" % ("; ".join(msgs) or "(no message)"))
    for m in msgs if st == "PASS" else []:
        R.note(m)
    R.note("checked %s against %s" % (_rel(entry, ctx.out_dir), _rel(ctx.deliver, ctx.out_dir)))
    return [R.out()]


# =================================================================== G92 ===
def _title_problems(title):
    t = _n(title)
    return [why for rx, why in BAD_TITLE if rx.search(t)]


def _in_order(text, titles):
    """Every title occurs in text, in this order (normalized substring)."""
    pos, t = 0, _n(text)
    for ti in titles:
        i = t.find(_n(ti), pos)
        if i < 0:
            return False, ti
        pos = i + len(_n(ti))
    return True, None


_DOCX_BAND_WORDS = (u"שאלות", u"שאלה")


def _g92_docx_bands(R, k, qs, P):
    """The Word file's bands against the IR bands, as sheet.html's are.

    emit_docx prints a part band as an unbookmarked heading-2 paragraph
    '<title> שאלות <range>' ('שאלה' for one number) right before q<n>
    (DocxDoc.bands ties it to n). Each IR band must be there, before the
    same question, with the same title and range after _n (NFC, niqqud,
    invisible marks such as the range's LRMs, whitespace), and no other band.
    WHY: G92 held only sheet.html to the IR, so a DOCX band 'זוויות צמודות —
    תרגול' (an emit_docx bug or a post-build edit of the teachers' editable
    page) passed every gate (review round 3, VA5). A missing DOCX is REVIEW,
    as in G86/G87: the check could not run, never a silent PASS."""
    if P.docx is None:
        R.add("REVIEW", "DOCX bands not checked: %s" % P.docx_error)
        return
    want = [(int(q["n"]), _n(q["part"][0]),
             _n(q["part"][1]) if len(q["part"]) > 1 and q["part"][1] else None) for q in qs if q.get("part")]
    got = [(n, _n(P.docx.paragraphs[i][2])) for i, n in sorted(P.docx.bands.items())]
    if [w[0] for w in want] != [g[0] for g in got]:
        R.add("FAIL", "level %s sheet.docx prints bands before q%s, the IR before q%s (sheet.docx: %s)"
              % (k, [g[0] for g in got], [w[0] for w in want], [g[1] for g in got]))
        return
    for (n, title, rng), (_m, text) in zip(want, got):
        ok = [title] if rng is None else [u"%s %s %s" % (title, w, rng) for w in _DOCX_BAND_WORDS]
        if text not in ok:
            R.add("FAIL", "level %s sheet.docx band before q%d reads %r, the IR band is %r (title %r, "
                          "range %r)" % (k, n, text, ok[0], title, rng))


def gate_g92(ctx):
    """Bands, numbering, title, rule box, reminders: the structure a reader
    navigates by, checked on the IR and on the printed HTML/JSON/DOCX."""
    out = []
    R0 = Rec(G92, None)
    secs = ctx.sections
    if ctx.sheet.get("schema") != "noam-sheet-sections/v1":
        R0.add("FAIL", "SHEET.schema %r != 'noam-sheet-sections/v1'" % (ctx.sheet.get("schema"),))
    if not secs:
        R0.add("FAIL", "SHEET has no sections")
    ids = [s.get("id") for s in secs]
    if len(set(ids)) != len(ids):
        R0.add("FAIL", "duplicate section ids %s" % ids)
    for s in secs:
        if s.get("kind") not in ("subtopic", "combo"):
            R0.add("FAIL", "%s: kind %r is neither 'subtopic' nor 'combo'" % (_sec_label(s), s.get("kind")))
        if s.get("kind") == "subtopic" and not s.get("subtopic"):
            R0.add("FAIL", "%s: a subtopic section without a subtopic id" % _sec_label(s))
        if not (s.get("title") or u"").strip():
            R0.add("FAIL", "%s: empty title" % s.get("id"))
    kinds = [s.get("kind") for s in secs]
    if "combo" in kinds and any(k2 != "combo" for k2 in kinds[kinds.index("combo"):]):
        R0.add("FAIL", "a combo section is not last: section kinds in order are %s" % kinds)
    for why in _title_problems(ctx.sheet.get("title")):
        R0.add("FAIL", "SHEET.title %r is %s" % (ctx.sheet.get("title"), why))
    # one subtopic = one section: a split ("זוויות" + "זוויות — תרגול נוסף")
    # dodges the per-section reading of the volume range and is a part-2
    # section in disguise (review 2026-11-09). G85 counts the split together.
    by_sub = {}
    for s in secs:
        if s.get("kind") != "combo" and s.get("subtopic"):
            by_sub.setdefault(s["subtopic"], []).append(s)
    for sub, ss in by_sub.items():
        if len(ss) < 2:
            continue
        msg = "subtopic %s is split over sections %s (one subtopic, one section)" % (
            sub, ", ".join(_sec_label(s) for s in ss))
        jus = [_justification(s) for s in ss]
        if all(jus):
            R0.add("REVIEW", msg + "; justification: " + "; ".join(dict.fromkeys(jus)))
        else:
            R0.add("FAIL", msg + ", and not every one of them has a justification")
    titles = [_n(s.get("title")) for s in secs if (s.get("title") or u"").strip()]
    dup = sorted(set(t for t in titles if titles.count(t) > 1))
    if dup:
        R0.add("FAIL", "two sections share the title %s: a band could not tell them apart" % dup)
    for s in secs:
        for why in _title_problems(s.get("title")):
            R0.add("FAIL", "%s: the section title is %s" % (_sec_label(s), why))
    out.append(R0.out())

    for k in ctx.keys:
        R = Rec(G92, k)
        P = ctx.printed(k)
        L = ctx.levels.get(k) or {}
        qs = ctx.questions(k)
        nums = [int(q["n"]) for q in qs]
        qmap = ctx.qmap(k)
        # numbering 1..N, and the printed outputs agree with the IR
        if nums != list(range(1, len(nums) + 1)):
            R.add("FAIL", "level %s question numbers %s are not 1..%d in order" % (k, nums, len(nums)))
        if P.sheet is not None:
            sj = [int(q.get("n")) for q in P.sheet.get("questions") or [] if q.get("n") is not None]
            if sj != nums:
                R.add("FAIL", "sheet.json numbers %s != IR %s" % (sj, nums))
        if P.html is not None and P.html.qnums != nums:
            R.add("FAIL", "sheet.html prints question numbers %s, IR has %s" % (P.html.qnums, nums))
        for e in P.errors:
            R.add("FAIL", "printed output not available: %s" % e)
        # every question in exactly one section, every listed question printed
        owner = {}
        for s in secs:
            for n in ctx.section_qs(s, k):
                owner.setdefault(n, []).append(s.get("id"))
        for n in nums:
            if n not in owner:
                R.add("FAIL", "q%d (level %s) belongs to no SHEET section" % (n, k))
            elif len(owner[n]) > 1:
                R.add("FAIL", "q%d (level %s) is in more than one section: %s" % (n, k, owner[n]))
        for n in sorted(owner):
            if n not in qmap:
                R.add("FAIL", "SHEET lists q%d in %s for level %s, but the level prints no q%d"
                      % (n, ", ".join(owner[n]), k, n))
        # each section is ONE consecutive block, and the blocks follow SHEET
        # order: a band '1-3, 5' / '4, 6-8' prints q5 under the wrong band
        # (review 2026-11-09). Combo-last is the special case of this order.
        prev = None
        for s in secs:
            lst = sorted(set(ctx.section_qs(s, k)))
            if not lst:
                continue
            if lst != list(range(lst[0], lst[-1] + 1)):
                R.add("FAIL", "%s: its questions %s in level %s are not one consecutive block (sections "
                              "may not interleave)" % (_sec_label(s), lst, k))
            if prev is not None and lst[0] <= prev[1]:
                R.add("FAIL", "%s starts at q%d in level %s, but %s (earlier in SHEET) ends at q%d: "
                              "sections must follow SHEET order, one block after the other"
                      % (_sec_label(s), lst[0], k, _sec_label(prev[0]), prev[1]))
            if prev is None or lst[-1] > prev[1]:
                prev = (s, lst[-1])
        # bands
        firsts = {}
        for s in secs:
            lst = ctx.section_qs(s, k)
            if not lst:
                continue
            first = min(lst)
            firsts[first] = s
            q = qmap.get(first)
            if q is None:
                continue
            part = q.get("part")
            if not part:
                R.add("FAIL", "%s: its first question q%d (level %s) has no part band" % (_sec_label(s), first, k))
                continue
            title = part[0] if len(part) > 0 else u""
            rng = part[1] if len(part) > 1 else None
            # equality, not containment: a band that contains the section
            # title may also name a later section's subtopic (the SHEET title
            # 'זוויות צמודות וזוויות קודקודיות' over the adjacent section
            # passed, review S-F1). _n folds NFC, niqqud, invisible marks and
            # whitespace, so only a real difference of words fails.
            if _n(s.get("title")) != _n(title):
                R.add("FAIL", "%s: band title %r on q%d is not the section title %r (the band names "
                              "exactly its section)" % (_sec_label(s), title, first, s.get("title")))
            got = parse_range(rng)
            if got is None:
                R.add("FAIL", "%s: band range %r on q%d is missing or unreadable" % (_sec_label(s), rng, first))
            elif got != sorted(lst):
                R.add("FAIL", "%s: band range %r on q%d covers %s, the section is %s (level %s)"
                      % (_sec_label(s), rng, first, got, sorted(lst), k))
        for q in qs:
            if q.get("part") and int(q["n"]) not in firsts:
                R.add("FAIL", "q%s (level %s) prints a band %r but does not open a section"
                      % (q["n"], k, q["part"][0]))
        if P.html is not None:
            ir_b = [(_n(q["part"][0]), _n(q["part"][1]) if len(q["part"]) > 1 and q["part"][1] else None,
                     int(q["n"])) for q in qs if q.get("part")]
            html_b = [(_n(t), _n(r) if r else None, n) for t, r, n in P.html.bands]
            if ir_b != html_b:
                R.add("FAIL", "sheet.html bands %s != IR bands %s" % (html_b, ir_b))
        _g92_docx_bands(R, k, qs, P)
        # combo questions come last
        sub_n = [n for s in secs if s.get("kind") != "combo" for n in ctx.section_qs(s, k)]
        com_n = [n for s in secs if s.get("kind") == "combo" for n in ctx.section_qs(s, k)]
        if sub_n and com_n and min(com_n) < max(sub_n):
            R.add("FAIL", "level %s: combo questions %s are not after the subtopic questions" % (k, com_n))
        # title
        for label, t in (("IR title", L.get("title")),
                         ("sheet.json title", (P.sheet or {}).get("title") if P.sheet else None),
                         ("sheet.html h1", P.html.h1 if P.html else None)):
            if t is None:
                continue
            if _n(t) != _n(ctx.sheet.get("title")):
                R.add("FAIL", "level %s %s %r != SHEET.title %r" % (k, label, t, ctx.sheet.get("title")))
            for why in _title_problems(t):
                R.add("FAIL", "level %s %s %r is %s" % (k, label, t, why))
        # rule box ("מה בדף") lists the section titles in order
        want = [s.get("title") for s in secs if ctx.section_qs(s, k)]
        for label, rule in (("IR rule", L.get("rule")), ("sheet.html rule box", P.html.rule if P.html else None)):
            if rule is None and label.startswith("sheet.html"):
                continue
            if not rule or u"מה בדף" not in _n(rule):
                R.add("FAIL", "level %s %s has no 'מה בדף' list: %r" % (k, label, rule))
                continue
            ok, miss = _in_order(rule.split(u"מה בדף", 1)[-1] if u"מה בדף" in rule else rule, want)
            if not ok:
                R.add("FAIL", "level %s %s does not list the section titles %s in order (missing or "
                              "out of order: %r)" % (k, label, want, miss))
        # reminder in every subtopic section; worked example in the guided level
        pj = dict((int(q.get("n")), q) for q in (P.sheet or {}).get("questions") or [] if q.get("n") is not None)
        for s in secs:
            lst = ctx.section_qs(s, k)
            if not lst or s.get("kind") == "combo":
                continue
            first = min(lst)
            q = qmap.get(first)
            if q is None:
                continue
            title, _lines = _example(q)
            if not title or u"תזכורת" not in _n(title):
                R.add("FAIL", "%s: its first question q%d (level %s) has no reminder "
                              "(example=('תזכורת', [...]))" % (_sec_label(s), first, k))
            elif P.sheet is not None:
                ex = (pj.get(first) or {}).get("example") or {}
                if u"תזכורת" not in _n(ex.get("title") if isinstance(ex, dict) else u""):
                    R.add("FAIL", "%s: the reminder of q%d is not in the printed sheet.json" % (_sec_label(s), first))
            if k == "a":
                has = [n for n in lst if qmap.get(n) and u"דוגמה" in _n(_example(qmap[n])[0] or u"")]
                if not has:
                    R.add("REVIEW", "%s: level a (the guided level) has no worked example "
                                    "('דוגמה פתורה') in this section; subtopics-he.md §4.5 makes it the "
                                    "default, an open decision for Noam" % _sec_label(s))
                else:
                    R.note("%s: worked example in q%s" % (_sec_label(s), ", q".join(map(str, has))))
        if R.status == "PASS":
            R.note("level %s: %d questions, %d band(s), numbering and sections agree"
                   % (k, len(nums), len(firsts)))
        out.append(R.out())
    return out


# ==================================================================== run ===
def _legacy():
    return [_record(g, None, "SKIP", [LEGACY_MSG]) for g in GATES]


def _unusable_sheet(ctx):
    """None when SHEET is a usable manifest, else why not.

    Legacy means exactly: no sheet_meta.py AND no SHEET. Anything else that
    is not a non-empty dict is a broken sectioned package, and it must FAIL:
    build_v72 counts an all-SKIP gate step as non-failing, so a SKIP here would
    ship a sectioned sheet with none of G85-G92 run (review 2026-11-09:
    `del SHEET` in content.py, or SHEET = {})."""
    s = ctx.sheet
    if isinstance(s, dict) and s:
        return None
    if s is None:
        return ("the package ships sheet_meta.py but content.py does not expose SHEET "
                "(add `from sheet_meta import SHEET`)")
    return "SHEET is %s, not a non-empty dict" % ("empty" if isinstance(s, dict) else type(s).__name__)


def run_ctx(ctx):
    """All gates on a prepared context; a gate that crashes is a FAIL."""
    if ctx.sheet is None and not ctx.sheet_meta:
        return _legacy()
    why = _unusable_sheet(ctx)
    if why:
        return [_record(g, None, "FAIL", ["FAIL: sectioned package without a usable SHEET: %s; "
                                          "no section gate could run" % why]) for g in GATES]
    res = []
    for gate, fn in ((G85, gate_g85), (G86, gate_g86), (G87, gate_g87),
                     (G88, gate_g88), (G89, gate_g89), (G92, gate_g92)):
        try:
            res.extend(fn(ctx))
        except Exception as e:
            import traceback
            res.append(_record(gate, None, "FAIL", ["FAIL: internal error %r" % e,
                                                    traceback.format_exc()[-1500:]]))
    return res


def run(pkg_dir, out_dir=None):
    """gate_sections.run(pkg_dir, out_dir) -> [result records] (dev-contract)."""
    try:
        ctx = Ctx.from_package(pkg_dir, out_dir)
    except Exception as e:
        return [_record(g, None, "FAIL", ["FAIL: the package could not be loaded: %r" % e]) for g in GATES]
    return run_ctx(ctx)


def summary(results):
    lines = []
    for r in results:
        lines.append(u"%-26s %-4s %-6s %s" % (r["gate"], r["level"] or "-", r["status"],
                                             (r["messages"][0] if r["messages"] else "")[:150]))
        for m in r["messages"][1:]:
            if not m.startswith("info:"):
                lines.append(u"%38s %s" % ("", m[:220]))
    return u"\n".join(lines)


def main(argv=None):
    ap = argparse.ArgumentParser(description="v7.2.0 section gates G85-G89, G92")
    ap.add_argument("--pkg", help="package folder")
    ap.add_argument("--out", help="build output folder (default: <pkg>/out)")
    ap.add_argument("--json", help="write the result records here")
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args(argv)
    if a.selftest:
        return 0 if selftest() else 1
    if not a.pkg:
        ap.error("--pkg is required")
    res = run(a.pkg, a.out)
    print(summary(res))
    if a.json:
        Path(a.json).parent.mkdir(parents=True, exist_ok=True)
        Path(a.json).write_text(json.dumps(res, ensure_ascii=False, indent=1), encoding="utf-8")
    bad = [r for r in res if r["status"] == "FAIL"]
    print("gate_sections: %d result(s), %d FAIL, %d REVIEW, %d SKIP"
          % (len(res), len(bad), sum(r["status"] == "REVIEW" for r in res),
             sum(r["status"] == "SKIP" for r in res)))
    return 1 if bad else 0


# =============================================================== selftest ===
def _st_level(k, title, rule, qs, words=None, curriculum=None):
    cur = dict(curriculum or {"topic": "angles", "track": u"ז", "grade": "7"})
    return {"key": k, "level": {"a": u"רמה א׳", "b": u"רמה ב׳", "c": u"מצוינות"}[k],
            "grade": u"כיתה %s׳" % GRADE_LETTER.get(str(cur["grade"]), u"ז"),
            "title": title, "rule": rule, "questions": qs, "figure_topic": True,
            "words_share": words or {}, "curriculum": cur,
            "answers": [(q["n"], [(it[0], u"$%d°$" % (10 * q["n"])) for it in q["items"]]) for q in qs]}


def _st_q(n, intro, part=None, example=None, fig=True, items=3):
    q = {"n": n, "intro": intro, "items": [(u"אבגדהו"[i], u"חשבו את הזווית.", 30) for i in range(items)]}
    if part:
        q["part"] = part
    if example:
        q["example"] = example
    if fig:
        q["fig"] = "<svg/>"
    return q


def _st_write(root, k, L):
    d = Path(root) / "deliver" / k
    d.mkdir(parents=True, exist_ok=True)
    qrows, body = [], []
    body.append(u'<div class="lvl">%s</div><h1>%s</h1><div class="rule">%s</div>'
                % (L["level"], _html.escape(L["title"]), _html.escape(L["rule"])))
    for q in L["questions"]:
        n = q["n"]
        if q.get("part"):
            body.append(u'<div class="band"><b>%s</b> שאלות <span class="num">%s</span></div>'
                        % (_html.escape(q["part"][0]), _html.escape(q["part"][1])))
        body.append(u'<div class="q"><div class="qmarkabs"><span class="qnum">(%d)</span></div>' % n)
        row = {"id": "q%d" % n, "n": n, "text": q["intro"], "items": []}
        if q.get("example"):
            row["example"] = {"title": q["example"][0], "lines": q["example"][1]}
            body.append(u'<div class="ex" data-bind="example:q%d"><div class="exh">%s</div>'
                        u'<div class="exl">%s</div></div>' % (n, q["example"][0], u" ".join(q["example"][1])))
        body.append(u'<div class="qintro" data-bind="stem:q%d:0">%s</div>' % (n, _html.escape(q["intro"])))
        for it in q["items"]:
            iid = "q%d%s" % (n, "abcdef"[u"אבגדהו".index(it[0])])
            row["items"].append({"id": iid, "label": it[0], "text": it[1], "answer": u"$%d°$" % (10 * n)})
            body.append(u'<div class="it" data-bind="item:%s">%s. %s</div>' % (iid, it[0], it[1]))
        body.append(u"</div>")
        qrows.append(row)
    html_doc = u"<html><head><style>.q{}</style></head><body>%s</body></html>" % u"".join(body)
    (d / "sheet.html").write_text(html_doc, encoding="utf-8")
    cur = dict(L.get("curriculum") or {})
    cur["not_yet_allowed"] = [{"id": "x", "name": u"זוויות נשלמות"}]
    sj = {"package": "ST-1", "level": k, "grade": L.get("grade"), "title": L["title"], "questions": qrows,
          "curriculum": cur}
    (d / "sheet.json").write_text(json.dumps(sj, ensure_ascii=False), encoding="utf-8")
    (d / "noam-ai.json").write_text(json.dumps({"questions": qrows, "curriculum": sj["curriculum"]},
                                               ensure_ascii=False), encoding="utf-8")
    dd = Path(root) / "docx" / k
    dd.mkdir(parents=True, exist_ok=True)
    paras = []
    bid = 0
    for q in L["questions"]:
        bid += 1
        if q.get("part"):
            # the band as emit_docx writes it: unbookmarked heading 2, '<title> שאלות <LRM>range<LRM>'
            paras.append(u'<w:p><w:pPr><w:pStyle w:val="Heading2"/></w:pPr><w:r><w:t>%s</w:t></w:r>'
                         u'<w:r><w:t xml:space="preserve"> שאלות </w:t></w:r><w:r><w:t>\u200e%s\u200e</w:t></w:r>'
                         u'</w:p>' % (_html.escape(q["part"][0]), _html.escape(q["part"][1])))
        paras.append(u'<w:p><w:bookmarkStart w:id="%d" w:name="q%d"/><w:r><w:t>%s</w:t></w:r>'
                     u'<w:bookmarkEnd w:id="%d"/></w:p>' % (bid, q["n"], _html.escape(q["intro"]), bid))
    doc = (u'<?xml version="1.0" encoding="UTF-8"?><w:document xmlns:w="%s"><w:body>%s</w:body></w:document>'
           % (_W[1:-1], u"".join(paras)))
    with zipfile.ZipFile(str(dd / "sheet.docx"), "w") as z:
        z.writestr("word/document.xml", doc.encode("utf-8"))


def selftest():
    """Offline: synthetic package (IR dicts + small printed files in a temp
    folder), good sheet -> PASS, each defect -> the right gate FAILs."""
    import copy
    import shutil
    import tempfile
    import types
    fails = []

    def ok(cond, msg):
        if not cond:
            fails.append(msg)

    title = u"זוויות צמודות וזוויות קודקודיות"
    rule = u"מה בדף: זוויות צמודות, זוויות קודקודיות ושילוב."
    REM_A = (u"תזכורת", [u"סכום זוויות צמודות הוא $180°$."])
    REM_V = (u"תזכורת", [u"זוויות קודקודיות שוות זו לזו."])
    WORK = (u"דוגמה פתורה", [u"הזוויות צמודות, ולכן סכומן $180°$."])

    def levels(curriculum=None):
        out = {}
        for k in LEVEL_KEYS:
            qs = [_st_q(1, u"בסרטוט שלפניכם הזוויות צמודות.", (u"זוויות צמודות", u"1-4"), REM_A),
                  _st_q(2, u"חשבו את הזווית הצמודה.", example=WORK if k == "a" else None),
                  _st_q(3, u"סרטטו שתי זוויות צמודות.", fig=False),
                  _st_q(4, u"חשבו את סכום הזוויות הצמודות."),
                  _st_q(5, u"הישרים נחתכים. זוויות קודקודיות.", (u"זוויות קודקודיות", u"5-8"), REM_V),
                  _st_q(6, u"מצאו זווית קודקודית.", example=WORK if k == "a" else None),
                  _st_q(7, u"חשבו את הזוויות הקודקודיות."),
                  _st_q(8, u"סרטטו שני ישרים נחתכים.", fig=False),
                  _st_q(9, u"שילוב של צמודות וקודקודיות.", (u"שילוב", u"9-10")),
                  _st_q(10, u"חשבו את כל הזוויות.")]
            out[k] = _st_level(k, title, rule, qs, words={3: u"סקיצה", 8: u"סקיצה"}, curriculum=curriculum)
        return out

    sheet = {"schema": "noam-sheet-sections/v1", "sheet_id": "G7-ANG-01", "package": "ST-1",
             "grade": "7", "track": u"ז", "topic_id": "angles", "scope": "sectioned", "title": title,
             "sections": [
                 {"id": "s1", "subtopic": "st.g7.angles.adjacent", "kind": "subtopic",
                  "title": u"זוויות צמודות", "questions": dict((k, [1, 2, 3, 4]) for k in LEVEL_KEYS)},
                 {"id": "s2", "subtopic": "st.g7.angles.vertical", "kind": "subtopic",
                  "title": u"זוויות קודקודיות", "questions": dict((k, [5, 6, 7, 8]) for k in LEVEL_KEYS)},
                 {"id": "s3", "kind": "combo", "title": u"שילוב", "combines": ["s1", "s2"],
                  "questions": dict((k, [9, 10]) for k in LEVEL_KEYS)}]}

    tmp = Path(tempfile.mkdtemp(prefix="gate_sections_st_"))
    fake = types.ModuleType("selfcheck_catalog")
    fake.check = lambda entry, deliver: {"status": "PASS", "messages": ["fake ok"]}
    saved = sys.modules.get("selfcheck_catalog")

    def build(name, sheet_, levels_, tweak=None, catalog=True):
        root = tmp / name / "out"
        for k, L in levels_.items():
            _st_write(root, k, L)
        if catalog:
            c = root / "catalog" / sheet_["sheet_id"]
            c.mkdir(parents=True, exist_ok=True)
            (c / "catalog-entry.json").write_text(json.dumps({"title": sheet_["title"]}, ensure_ascii=False),
                                                  encoding="utf-8")
            (c / "landing.json").write_text(json.dumps({"h1": sheet_["title"]}, ensure_ascii=False),
                                            encoding="utf-8")
        if tweak:
            tweak(root)
        return Ctx(tmp / name, root, sheet_, "ST-1", levels_)

    def status(res, gate, level="*"):
        rs = [r for r in res if r["gate"] == gate and (level == "*" or r["level"] == level)]
        order = ["PASS", "SKIP", "REVIEW", "FAIL"]
        return max((r["status"] for r in rs), key=order.index) if rs else None

    try:
        sys.modules["selfcheck_catalog"] = fake
        good = run_ctx(build("good", sheet, levels()))
        for g in GATES:
            ok(status(good, g) == "PASS", "good sheet: %s is %s %s" % (
                g, status(good, g), [r["messages"][:3] for r in good if r["gate"] == g and r["status"] != "PASS"]))
        # legacy
        ok(all(r["status"] == "SKIP" and r["messages"] == [LEGACY_MSG]
               for r in run_ctx(Ctx(tmp, tmp, None, "X", {}))), "legacy must SKIP")
        # G85: 6 questions in an S section (two-section sheet), no justification
        L = levels()
        sh = copy.deepcopy(sheet)
        sh["sections"][0]["questions"]["b"] = [1, 2, 3, 4, 5, 6]
        sh["sections"][1]["questions"]["b"] = [7, 8]
        r = run_ctx(build("g85", sh, L))
        ok(status(r, G85, "b") == "FAIL", "G85 S section with 6 questions")
        sh["sections"][0]["justification"] = u"מקרה מיוחד"
        sh["sections"][1]["justification"] = u"מקרה מיוחד"
        r = run_ctx(build("g85j", sh, L))
        ok(status(r, G85, "b") == "REVIEW", "G85 out of range with justification -> REVIEW")
        # G85: sub-items
        L = levels()
        L["c"]["questions"][3]["items"] = L["c"]["questions"][3]["items"][:1]
        ok(status(run_ctx(build("g85s", sheet, L)), G85, "c") == "FAIL", "G85 one sub-item")
        # G85: draw from words missing
        L = levels()
        L["a"]["words_share"] = {}
        ok(status(run_ctx(build("g85w", sheet, L)), G85, "a") == "FAIL", "G85 draw-from-words 0")
        sh = copy.deepcopy(sheet)
        sh["small_sheet_exemptions"] = {"draw_from_words": u"דף הקנייה ללא סרטוט"}
        ok(status(run_ctx(build("g85we", sh, L)), G85, "a") == "REVIEW", "G85 exemption -> REVIEW")
        # G86: forbidden in an answer (sheet.json only) / only in the DOCX / house spelling
        L = levels()

        def t_answer(root):
            p = root / "deliver" / "b" / "sheet.json"
            d = json.loads(p.read_text(encoding="utf-8"))
            d["questions"][1]["items"][0]["answer"] = u"הזוויות נשלמות"
            p.write_text(json.dumps(d, ensure_ascii=False), encoding="utf-8")
        r = run_ctx(build("g86a", sheet, L, t_answer))
        ok(status(r, G86, "b") == "FAIL" and status(r, G86, "a") == "PASS", "G86 term only in an answer")

        def t_docx(root):
            p = root / "docx" / "c" / "sheet.docx"
            with zipfile.ZipFile(str(p)) as z:
                doc = z.read("word/document.xml").decode("utf-8")
            doc = doc.replace(u"חשבו את הזווית הצמודה.", u"חשבו את הזווית הנשלמ‍ת.")
            with zipfile.ZipFile(str(p), "w") as z:
                z.writestr("word/document.xml", doc.encode("utf-8"))
        r = run_ctx(build("g86d", sheet, L, t_docx))
        ok(status(r, G86, "c") == "FAIL" and status(r, G86, "b") == "PASS", "G86 term only in the DOCX")
        L = levels()
        L["a"]["questions"][2]["intro"] = u"שרטטו שתי זוויות צמודות."
        r = run_ctx(build("g86h", sheet, L))
        ok(status(r, G86, "a") == "FAIL", "G86 house spelling")
        sh = copy.deepcopy(sheet)
        sh["scope"] = "broad"
        ok(status(run_ctx(build("g86hb", sh, L)), G86, "a") == "PASS", "house spelling off for broad")
        ok(status(good, G86, "a") == "PASS", "not_yet_allowed exclusion")
        # G87: later-subtopic term in an earlier section; grade-8 term; out-of-order sheet
        L = levels()
        L["b"]["questions"][1]["intro"] = u"האם הזוויות קודקודיות?"
        r = run_ctx(build("g87", sheet, L))
        ok(status(r, G87, "b") == "FAIL" and status(r, G87, "a") == "PASS", "G87 vertical term in adjacent section")
        L = levels()
        L["a"]["questions"][6]["intro"] = u"חשבו את הזווית החיצונית."
        ok(status(run_ctx(build("g87e", sheet, L)), G87, "a") == "FAIL", "G87 grade-8 term")
        L = levels()
        L["c"]["rule"] = u"מה בדף: זוויות צמודות, זוויות קודקודיות ושילוב. בהמשך: חוצה זווית וסכום הזוויות במשולש."
        ok(status(run_ctx(build("g87n", sheet, L)), G87, "c") == "FAIL", "G87 nav text beyond the sheet")
        L = levels()
        L["c"]["rule"] = u"מה בדף: זוויות צמודות, זוויות קודקודיות ושילוב של זוויות קודקודיות."
        ok(status(run_ctx(build("g87m", sheet, L)), G87, "c") == "PASS", "G87 nav may name later sections")
        # G88: missing section in c; count difference; package mismatch
        L = levels()
        sh = copy.deepcopy(sheet)
        sh["sections"][1]["questions"]["c"] = []
        r = run_ctx(build("g88", sh, L))
        ok(status(r, G88, "c") == "FAIL", "G88 missing section in c")
        sh = copy.deepcopy(sheet)
        sh["package"] = "OTHER"
        ok(status(run_ctx(build("g88p", sh, levels())), G88, None) == "FAIL", "G88 package mismatch")
        # G89: missing module / missing entry
        sys.modules.pop("selfcheck_catalog", None)
        sys.modules["selfcheck_catalog"] = None   # import now raises ImportError
        ok(status(run_ctx(build("g89", sheet, levels())), G89) == "FAIL", "G89 missing checker")
        sys.modules["selfcheck_catalog"] = fake
        ok(status(run_ctx(build("g89e", sheet, levels(), catalog=False)), G89) == "FAIL", "G89 missing entry")
        # G92: off-by-one band, band skipping a number, title 'חלק 2', combo first, no reminder
        L = levels()
        L["a"]["questions"][4]["part"] = (u"זוויות קודקודיות", u"5-7")
        ok(status(run_ctx(build("g92", sheet, L)), G92, "a") == "FAIL", "G92 off-by-one band")
        L = levels()
        L["b"]["questions"][0]["part"] = (u"זוויות צמודות", u"1-2, 4")
        ok(status(run_ctx(build("g92s", sheet, L)), G92, "b") == "FAIL", "G92 band skips a number")
        L = levels()
        sh = copy.deepcopy(sheet)
        sh["title"] = u"זוויות חלק 2"
        for k in LEVEL_KEYS:
            L[k]["title"] = sh["title"]
        r = run_ctx(build("g92t", sh, L))
        ok(status(r, G92, None) == "FAIL" and status(r, G92, "a") == "FAIL", "G92 title 'חלק 2'")
        L = levels()
        del L["c"]["questions"][4]["example"]
        ok(status(run_ctx(build("g92r", sheet, L)), G92, "c") == "FAIL", "G92 no reminder")
        L = levels()
        L["a"]["questions"][1].pop("example")
        ok(status(run_ctx(build("g92w", sheet, L)), G92, "a") == "REVIEW", "G92 no worked example -> REVIEW")
        ok(parse_range(u"1–4") == [1, 2, 3, 4] and parse_range(u"3, 5") == [3, 5] and
           parse_range("x") is None and parse_range(u"7") == [7], "parse_range")
        ok(_title_problems(u"מבוא לפונקציות") == [] and _title_problems(u"זוויות — מבוא") and
           _title_problems(u"חלק א׳: זוויות") and _title_problems(u"יחסים ופעולות") and
           _title_problems(u"זוויות חלק 2") and _title_problems(u"זוויות, חלק שני") and
           _title_problems(u"הקדמה") and _title_problems(u"חלקי הזווית") == [] and
           _title_problems(u"זוויות צמודות וזוויות קודקודיות") == [], "title rules")

        # ---- review 2026-11-09: every probe that passed or failed wrongly ----
        # titles: the article on the ordinal, Roman numerals, 'part N', '— המשך'
        for t in (u"זוויות קודקודיות — החלק השני", u"זוויות קודקודיות, החלק הראשון", u"זוויות (חלק II)",
                  u"זוויות, חלק ב׳", u"זוויות חלק-3", u"Angles, part 2", u"זוויות קודקודיות — המשך",
                  u"זוויות קודקודיות (המשך)"):
            ok(_title_problems(t), "title %r must be flagged" % t)
        for t in (u"המשך הצלע והזווית החיצונית", u"חלקי הזווית", u"זוויות קודקודיות", u"מבוא לפונקציות"):
            ok(not _title_problems(t), "title %r must pass" % t)
        L = levels()
        sh = copy.deepcopy(sheet)
        sh["title"] = u"זוויות צמודות וזוויות קודקודיות — החלק השני"
        for k in LEVEL_KEYS:
            L[k]["title"] = sh["title"]
        ok(status(run_ctx(build("r_title", sh, L)), G92, None) == "FAIL", "G92 'החלק השני'")

        # one S subtopic split over two sections (9 questions): G85 counts it as one
        REM = (u"תזכורת", [u"זוויות קודקודיות שוות זו לזו."])

        def split_levels(rule_):
            d = {}
            for k in LEVEL_KEYS:
                qs = [_st_q(1, u"חשבו.", (u"זוויות", u"1-5"), REM)]
                qs += [_st_q(n, u"חשבו.", example=WORK if (k == "a" and n in (2, 7)) else None)
                       for n in (2, 3, 4, 5)]
                qs += [_st_q(6, u"חשבו.", (u"זוויות — תרגול נוסף", u"6-9"), REM)]
                qs += [_st_q(n, u"חשבו.", example=WORK if (k == "a" and n == 7) else None) for n in (7, 8, 9)]
                d[k] = _st_level(k, u"זוויות", rule_, qs, words={3: u"סקיצה"})
            return d
        sh_split = {"schema": "noam-sheet-sections/v1", "sheet_id": "G7-ANG-02", "package": "ST-1",
                    "grade": "7", "track": u"ז", "topic_id": "angles", "scope": "sectioned", "title": u"זוויות",
                    "sections": [
                        {"id": "s1", "subtopic": "st.g7.angles.vertical", "kind": "subtopic",
                         "title": u"זוויות", "questions": dict((k, [1, 2, 3, 4, 5]) for k in LEVEL_KEYS)},
                        {"id": "s2", "subtopic": "st.g7.angles.vertical", "kind": "subtopic",
                         "title": u"זוויות — תרגול נוסף", "questions": dict((k, [6, 7, 8, 9]) for k in LEVEL_KEYS)}]}
        r = run_ctx(build("r_split", sh_split, split_levels(u"מה בדף: זוויות, זוויות — תרגול נוסף.")))
        ok(all(status(r, G85, k) == "FAIL" for k in LEVEL_KEYS), "G85 split S subtopic (9 > 8) %s"
           % [m for x in r if x["gate"] == G85 for m in x["messages"]][:3])
        ok(status(r, G92, None) == "FAIL", "G92 split subtopic")
        sh_j = copy.deepcopy(sh_split)
        for s in sh_j["sections"]:
            s["justification"] = u"בדיקה: דף תרגול מורחב"
        r = run_ctx(build("r_split_j", sh_j, split_levels(u"מה בדף: זוויות, זוויות — תרגול נוסף.")))
        ok(status(r, G85, "a") == "REVIEW" and status(r, G92, None) == "REVIEW", "split + justification -> REVIEW")

        # interleaved sections: s1 = 1,2,3,5 and s2 = 4,6,7,8 with matching bands
        L = levels()
        for k in LEVEL_KEYS:
            qs = L[k]["questions"][:8]
            qs[0]["part"] = (u"זוויות צמודות", u"1-3, 5")
            qs[4].pop("part")
            qs[4].pop("example")
            qs[3]["part"] = (u"זוויות קודקודיות", u"4, 6-8")
            qs[3]["example"] = REM_V
            L[k]["questions"] = qs
            L[k]["answers"] = L[k]["answers"][:8]
            L[k]["rule"] = u"מה בדף: זוויות צמודות, זוויות קודקודיות."
        sh = copy.deepcopy(sheet)
        sh["sections"] = sh["sections"][:2]
        for k in LEVEL_KEYS:
            sh["sections"][0]["questions"][k] = [1, 2, 3, 5]
            sh["sections"][1]["questions"][k] = [4, 6, 7, 8]
        r = run_ctx(build("r_interleave", sh, L))
        ok(all(status(r, G92, k) == "FAIL" for k in LEVEL_KEYS), "G92 interleaved sections")

        # SHEET unusable: {} / a sheet_meta.py whose SHEET content.py does not expose
        r = run_ctx(Ctx(tmp, tmp, {}, "X", levels()))
        ok(len(r) == len(GATES) and all(x["status"] == "FAIL" for x in r), "SHEET = {} must FAIL")
        (tmp / "pkgmeta").mkdir()
        (tmp / "pkgmeta" / "sheet_meta.py").write_text(u"SHEET = {}\n", encoding="utf-8")
        r = run_ctx(Ctx(tmp / "pkgmeta", tmp, None, "X", levels()))
        ok(all(x["status"] == "FAIL" and "sheet_meta.py" in x["messages"][0] for x in r),
           "sheet_meta.py present but SHEET not exposed must FAIL")

        # G88: SHEET relabelled grade 8 / ח while the levels say grade 7; G86 keeps grade-7 rules
        L = levels()
        L["c"]["questions"][1]["intro"] = u"האם הזוויות משלימות?"
        sh = copy.deepcopy(sheet)
        sh.update(grade="8", track=u"ח", sheet_id="G8-ANG-01")
        r = run_ctx(build("r_mislabel", sh, L))
        ok(status(r, G88, None) == "FAIL" and all(status(r, G88, k) == "FAIL" for k in LEVEL_KEYS),
           "G88 SHEET.grade vs curriculum/registry")
        ok(status(r, G86, "c") == "FAIL" and status(r, G86, "a") == "PASS", "G86 grade-7 rule kept")
        sh = copy.deepcopy(sheet)
        sh["sheet_id"] = "G8-ANG-01"
        ok(status(run_ctx(build("r_sid", sh, levels())), G88, None) == "FAIL", "G88 sheet_id grade prefix")
        L = levels()
        L["b"]["grade"] = u"כיתה ח׳"
        ok(status(run_ctx(build("r_gline", sheet, L)), G88, "b") == "FAIL", "G88 printed grade line")

        # G87 grade 9, ט_רגילה parallels sheet: level b (ט_מצומצמת) is REVIEW, not FAIL
        c9 = {"topic": "parallels_trapezoid", "track": u"ט_רגילה", "grade": "9"}
        sh9 = copy.deepcopy(sheet)
        sh9.update(grade="9", track=u"ט_רגילה", topic_id="parallels_trapezoid", sheet_id="G9-PAR-01")
        sh9["sections"][0]["subtopic"] = "st.g9r.parallels_trapezoid.properties"
        sh9["sections"][1]["subtopic"] = "st.g9r.parallels_trapezoid.alternate_corresponding"
        r = run_ctx(build("r_g9", sh9, levels(c9)))
        ok(status(r, G87, "a") == "PASS" and status(r, G87, "c") == "PASS" and status(r, G87, "b") == "REVIEW",
           "G87 grade-9 parallels: a/c PASS, b REVIEW %s" % [x["messages"][:2] for x in r if x["gate"] == G87])
        ok(not any("not_in_track" in m for x in r for m in x["messages"]), "no false 'not_in_track' label")
        for g in (G85, G86, G88, G89, G92):
            ok(status(r, g) == "PASS", "grade-9 parallels sheet: %s %s" % (g, status(r, g)))
        sh9c = copy.deepcopy(sh9)
        sh9c["sections"][1]["subtopic"] = "st.g9r.parallels_trapezoid.converse"
        r = run_ctx(build("r_g9c", sh9c, levels(c9)))
        ok(status(r, G87, "b") == "FAIL" and status(r, G87, "a") == "PASS", "G87 9b converse not in track")
        sh9p = copy.deepcopy(sh9)
        sh9p.update(topic_id="powers", sheet_id="G9-POW-01")
        sh9p["sections"][0]["subtopic"] = "st.g9r.powers.natural_review"
        sh9p["sections"][1]["subtopic"] = "st.g9r.powers.quotient_same_base"
        r = run_ctx(build("r_g9p", sh9p, levels(dict(c9, topic="powers"))))
        ok(status(r, G87, "b") == "FAIL" and status(r, G87, "a") == "PASS", "G87 9b quotient law via requires")

        # G87 without the DOCX: REVIEW, as G86
        def t_nodocx(root):
            shutil.rmtree(str(root / "docx" / "b"))
        r = run_ctx(build("r_nodocx", sheet, levels(), t_nodocx))
        ok(status(r, G87, "b") == "REVIEW" and status(r, G86, "b") == "REVIEW" and
           status(r, G87, "a") == "PASS", "missing DOCX -> REVIEW in G86 and G87")
        # round 3 (VA5): G92 reads the DOCX bands, so a missing DOCX is REVIEW there too
        ok(status(r, G92, "b") == "REVIEW" and status(r, G92, "a") == "PASS" and
           any(m.startswith("REVIEW: DOCX bands not checked") for x in r if x["gate"] == G92 and x["level"] == "b"
               for m in x["messages"]), "missing DOCX -> G92 REVIEW 'DOCX bands not checked'")

        # ---- fix round 2 (S-F1, S-F2, D-F6): each case failed on the old code ----
        def msgs(res, gate, level):
            return [m for x in res if x["gate"] == gate and x["level"] == level for m in x["messages"]]

        def edit_json(root, k, fname, fn):
            p = root / "deliver" / k / fname
            d = json.loads(p.read_text(encoding="utf-8"))
            fn(d)
            p.write_text(json.dumps(d, ensure_ascii=False), encoding="utf-8")

        def docx_before(root, k, n, para):
            p = root / "docx" / k / "sheet.docx"
            with zipfile.ZipFile(str(p)) as z:
                doc = z.read("word/document.xml").decode("utf-8")
            anchor = u'<w:p><w:bookmarkStart w:id="%d" w:name="q%d"/>' % (n, n)
            assert doc.count(anchor) == 1, anchor
            doc = doc.replace(anchor, para + anchor)
            with zipfile.ZipFile(str(p), "w") as z:
                z.writestr("word/document.xml", doc.encode("utf-8"))

        def h2(text, style="Heading2"):
            ppr = u'<w:pPr><w:pStyle w:val="%s"/></w:pPr>' % style if style else u""
            return u"<w:p>%s<w:r><w:t>%s</w:t></w:r></w:p>" % (ppr, _html.escape(text))

        # S-F1: the first band names the sheet title (both subtopics) in every
        # level. It CONTAINS the section title, so the old G88/G92 passed, and
        # G87 read it as navigation at the sheet's last section.
        L = levels()
        for k in LEVEL_KEYS:
            L[k]["questions"][0]["part"] = (title, u"1-4")
        r = run_ctx(build("f_band_names_later", sheet, L))
        for k in LEVEL_KEYS:
            ok(status(r, G92, k) == "FAIL" and any("is not the section title" in m for m in msgs(r, G92, k)),
               "S-F1 G92 %s: band containing the section title must FAIL %s" % (k, msgs(r, G92, k)[:3]))
            ok(status(r, G88, k) == "FAIL" and any("equal to its section title" in m for m in msgs(r, G88, k)),
               "S-F1 G88 %s: band containing the section title must FAIL" % k)
            ok(status(r, G87, k) == "FAIL" and any("band, q1: term vertical_angles" in m and
                                                   "introduced by the later section" in m
                                                   for m in msgs(r, G87, k)),
               "S-F1 G87 %s: later-section term in the band of s1 %s" % (k, msgs(r, G87, k)[:3]))
        ok(status(r, G86) == "PASS" and status(r, G85) == "PASS", "S-F1 touches only G87/G88/G92")
        # normalization only: niqqud, an invisible mark and doubled spaces are the same title
        L = levels()
        for k in LEVEL_KEYS:
            L[k]["questions"][0]["part"] = (u"ז\u05b8וויות\u200d  צמודות", u"1-4")
        r = run_ctx(build("f_band_norm", sheet, L))
        ok(status(r, G92) == "PASS" and status(r, G88) == "PASS" and status(r, G87) == "PASS",
           "S-F1 a band equal after normalization passes %s" % [(x["gate"], x["level"], x["messages"][:2])
                                                               for x in r if x["status"] != "PASS"][:3])
        # a band printed only in the DOCX (heading 2 before q1): G87 checks it at
        # s1; since round 3 G92 also holds the DOCX bands to the IR, so it FAILs too
        r = run_ctx(build("f_docx_band", sheet, levels(),
                          lambda root: docx_before(root, "c", 1, h2(title + u" שאלות 1-4"))))
        ok(status(r, G87, "c") == "FAIL" and any("sheet.docx band" in m for m in msgs(r, G87, "c"))
           and status(r, G87, "b") == "PASS", "S-F1 G87: a later term in a DOCX band FAILs %s" % msgs(r, G87, "c")[:2])
        ok(status(r, G92, "c") == "FAIL" and status(r, G92, "b") == "PASS",
           "round 3 G92: a DOCX band that names the later section FAILs %s" % msgs(r, G92, "c")[:2])

        # ---- round 3 (VA5): the DOCX bands against the IR bands in G92 ----
        def docx_sub(k, old, new):
            def t(root):
                p = root / "docx" / k / "sheet.docx"
                with zipfile.ZipFile(str(p)) as z:
                    doc = z.read("word/document.xml").decode("utf-8")
                assert doc.count(old) == 1, old
                with zipfile.ZipFile(str(p), "w") as z:
                    z.writestr("word/document.xml", doc.replace(old, new).encode("utf-8"))
            return t
        band1 = u'<w:r><w:t>זוויות צמודות</w:t></w:r>'
        # extra words in the DOCX band only (no glossary term, so G87 cannot see it)
        r = run_ctx(build("f_docx_band_words", sheet, levels(),
                          docx_sub("c", band1, u'<w:r><w:t>זוויות צמודות — תרגול</w:t></w:r>')))
        ok(status(r, G92, "c") == "FAIL" and any("sheet.docx band before q1" in m for m in msgs(r, G92, "c")) and
           status(r, G92, "b") == "PASS" and status(r, G87) == "PASS" and status(r, G88) == "PASS",
           "round 3 G92: extra words in a DOCX band FAIL %s" % msgs(r, G92, "c")[:2])
        # the DOCX range differs from the IR range
        r = run_ctx(build("f_docx_band_range", sheet, levels(),
                          docx_sub("a", u"<w:t>\u200e5-8\u200e</w:t>", u"<w:t>\u200e5-7\u200e</w:t>")))
        ok(status(r, G92, "a") == "FAIL" and any("before q5" in m for m in msgs(r, G92, "a")),
           "round 3 G92: a DOCX band range differs from the IR %s" % msgs(r, G92, "a")[:2])
        # a band missing from the DOCX (its heading-2 paragraph is no band any more)
        r = run_ctx(build("f_docx_band_gone", sheet, levels(),
                          docx_sub("b", u'<w:p><w:pPr><w:pStyle w:val="Heading2"/></w:pPr><w:r><w:t>שילוב',
                                   u'<w:p><w:r><w:t>שילוב')))
        ok(status(r, G92, "b") == "FAIL" and any("prints bands before q[1, 5]" in m for m in msgs(r, G92, "b")),
           "round 3 G92: a band missing from the DOCX FAILs %s" % msgs(r, G92, "b")[:2])
        # normalization only (niqqud, an invisible mark, doubled spaces, 'שאלה'): PASS
        r = run_ctx(build("f_docx_band_norm", sheet, levels(),
                          docx_sub("c", band1 + u'<w:r><w:t xml:space="preserve"> שאלות </w:t></w:r>',
                                   u'<w:r><w:t>ז\u05b8וויות\u200d  צמודות</w:t></w:r>'
                                   u'<w:r><w:t xml:space="preserve">  שאלה </w:t></w:r>')))
        ok(status(r, G92) == "PASS", "round 3 G92: a DOCX band equal after normalization passes %s"
           % msgs(r, G92, "c")[:2])
        # the same words in an unstyled DOCX paragraph are navigation (like the
        # rule box, which may announce every section of the sheet): PASS
        r = run_ctx(build("f_docx_nav", sheet, levels(),
                          lambda root: docx_before(root, "c", 1, h2(u"מה בדף: " + title, style=None))))
        ok(status(r, G87, "c") == "PASS", "S-F1 G87: rule-box words stay navigation %s" % msgs(r, G87, "c")[:2])
        # the band of the HTML only (the IR keeps the right band): G92 (HTML !=
        # IR) and G87 (sheet.html band at s1) both FAIL
        def t_html_band(root):
            p = root / "deliver" / "b" / "sheet.html"
            t = p.read_text(encoding="utf-8")
            old = u"<b>%s</b>" % u"זוויות צמודות"
            assert t.count(old) == 1
            p.write_text(t.replace(old, u"<b>%s</b>" % title), encoding="utf-8")
        r = run_ctx(build("f_html_band", sheet, levels(), t_html_band))
        ok(status(r, G87, "b") == "FAIL" and any("sheet.html band" in m for m in msgs(r, G87, "b")) and
           status(r, G92, "b") == "FAIL", "S-F1 G87/G92: later term in the HTML band")

        # S-F2: the engine's default aux label (didactic.AUX_LABEL) at the aux
        # label paths -> REVIEW naming the fix; any other spelling, or the same
        # string elsewhere, stays FAIL
        aux_lab = _aux_default_label()
        ok(aux_lab == u"שרטוט עזר", "didactic.AUX_LABEL readable: %r" % (aux_lab,))

        def aux_tweak(label, where="paths", aux_flag=True):
            def t(root):
                for fname in ("sheet.json", "noam-ai.json"):
                    def fn(d):
                        if where == "paths":
                            d["figures"] = [
                                {"id": "q2_head", "question": "q2",
                                 "visual_model": {"aux": [{"id": "q2c_aux1", "label": label,
                                                           "reveal": "on_request", "step": u"צעד."}]}},
                                {"id": "q2c_aux1", "question": "q2", "item": "q2c", "aux": aux_flag,
                                 "reveal": "on_request", "label": label}]
                        else:
                            d["questions"][1]["text"] = d["questions"][1]["text"] + u" " + label
                    edit_json(root, "a", fname, fn)
            return t
        r = run_ctx(build("f_aux_default", sheet, levels(), aux_tweak(aux_lab)))
        ok(status(r, G86, "a") == "REVIEW" and status(r, G86, "b") == "PASS" and
           sum(u'label=u"סרטוט עזר"' in m for m in msgs(r, G86, "a")) == 4,
           "S-F2 default aux label -> REVIEW with the fix, 4 paths %s" % msgs(r, G86, "a")[:3])
        r = run_ctx(build("f_aux_house", sheet, levels(), aux_tweak(u"סרטוט עזר")))
        ok(status(r, G86, "a") == "PASS", "S-F2 label override -> PASS")
        r = run_ctx(build("f_aux_other", sheet, levels(), aux_tweak(u"שרטוט")))
        ok(status(r, G86, "a") == "FAIL", "S-F2 a non-default label at the aux paths stays FAIL")
        r = run_ctx(build("f_aux_text", sheet, levels(), aux_tweak(aux_lab, where="text")))
        ok(status(r, G86, "a") == "FAIL", "S-F2 the default label inside question text stays FAIL")
        r = run_ctx(build("f_aux_notaux", sheet, levels(), aux_tweak(aux_lab, aux_flag=False)))
        ok(status(r, G86, "a") == "FAIL" and any("/figures[1]/label" in m and m.startswith("FAIL")
                                                 for m in msgs(r, G86, "a")),
           "S-F2 /figures[i]/label of a figure not marked aux stays FAIL")
        ok(_aux_default_label_at({"figures": [{"aux": True, "label": aux_lab}]}, "/figures[0]/label",
                                 aux_lab + u" ", aux_lab) is False, "S-F2 exact string only")
        # round 3 (VB1): the author wrote label=u"שרטוט עזר" (= the engine default);
        # the printed output is the same as with no label, the package source is not
        def with_src(tweak, rel, text):
            def t(root):
                tweak(root)
                f = root.parent / rel
                f.parent.mkdir(parents=True, exist_ok=True)
                f.write_text(text, encoding="utf-8")
            return t
        src_label = u'q = dict(fig=None, step=u"צעד.", label=u"%s")\n' % aux_lab
        r = run_ctx(build("f_aux_author", sheet, levels(), with_src(aux_tweak(aux_lab), "level_a.py", src_label)))
        ok(status(r, G86, "a") == "FAIL" and sum("package source writes this string" in m and m.startswith("FAIL")
                                                 for m in msgs(r, G86, "a")) == 4 and
           not any(m.startswith("REVIEW") for m in msgs(r, G86, "a")),
           "round 3 G86: label=u'שרטוט עזר' in the package source -> FAIL, never REVIEW %s" % msgs(r, G86, "a")[:2])
        # only deliver's copy of the source carries it
        r = run_ctx(build("f_aux_author_deliver", sheet, levels(),
                          with_src(aux_tweak(aux_lab), "out/deliver/a/source/level_a.py", src_label)))
        ok(status(r, G86, "a") == "FAIL", "round 3 G86: the label in deliver/<k>/source -> FAIL")
        # a source file that does not parse still counts (its text is searched)
        r = run_ctx(build("f_aux_author_broken", sheet, levels(),
                          with_src(aux_tweak(aux_lab), "level_a.py", u"def (:\n" + src_label)))
        ok(status(r, G86, "a") == "FAIL", "round 3 G86: the label in an unparsable source -> FAIL")
        # the string only in a comment, or only inside a longer literal, is no label -> REVIEW stays
        r = run_ctx(build("f_aux_comment", sheet, levels(),
                          with_src(aux_tweak(aux_lab), "level_a.py",
                                   u"# %s\nq = dict(step=u\"ראו %s בעמוד.\")\n" % (aux_lab, aux_lab))))
        ok(status(r, G86, "a") == "REVIEW", "round 3 G86: a comment / longer literal keeps the REVIEW %s"
           % msgs(r, G86, "a")[:2])

        # D-F6: noam-ai.json curriculum track and a missing noam-ai.json
        r = run_ctx(build("f_noam_track", sheet, levels(),
                          lambda root: edit_json(root, "b", "noam-ai.json",
                                                 lambda d: d["curriculum"].update(track=u"ח"))))
        ok(status(r, G88, "b") == "FAIL" and any("noam-ai.json curriculum track" in m for m in msgs(r, G88, "b"))
           and status(r, G88, "a") == "PASS", "D-F6 noam-ai.json track differs -> FAIL")
        r = run_ctx(build("f_noam_notrack", sheet, levels(),
                          lambda root: edit_json(root, "a", "noam-ai.json",
                                                 lambda d: d["curriculum"].pop("track"))))
        ok(status(r, G88, "a") == "FAIL", "D-F6 noam-ai.json without a track -> FAIL")
        r = run_ctx(build("f_noam_nocur", sheet, levels(),
                          lambda root: edit_json(root, "a", "noam-ai.json", lambda d: d.pop("curriculum"))))
        ok(status(r, G88, "a") == "FAIL", "D-F6 noam-ai.json without a curriculum block -> FAIL")
        r = run_ctx(build("f_noam_missing", sheet, levels(),
                          lambda root: (root / "deliver" / "c" / "noam-ai.json").unlink()))
        ok(status(r, G88, "c") == "FAIL" and any("noam-ai.json is missing" in m for m in msgs(r, G88, "c"))
           and status(r, G88, "b") == "PASS", "D-F6 missing noam-ai.json -> G88 FAIL")
        # grade 9: the house mapping lets level b print ט_מצומצמת, level a may not
        L = levels(c9)
        L["b"]["curriculum"] = dict(c9, track=u"ט_מצומצמת")
        L["a"]["curriculum"] = dict(c9)
        r = run_ctx(build("f_noam_g9", sh9, L,
                          lambda root: edit_json(root, "a", "noam-ai.json",
                                                 lambda d: d["curriculum"].update(track=u"ט_מצומצמת"))))
        ok(status(r, G88, "b") == "PASS", "D-F6 grade 9 level b ט_מצומצמת allowed by track_for %s"
           % msgs(r, G88, "b")[:2])
        ok(status(r, G88, "a") == "FAIL" and any("noam-ai.json curriculum track" in m for m in msgs(r, G88, "a")),
           "D-F6 grade 9 level a ט_מצומצמת not declared for a")
        # SHEET.track_by_level respected: level a declared ט_מצומצמת
        sh9t = copy.deepcopy(sh9)
        sh9t["track_by_level"] = {"a": u"ט_מצומצמת"}
        L = levels(c9)
        L["a"]["curriculum"] = dict(c9, track=u"ט_מצומצמת")
        r = run_ctx(build("f_noam_g9_tbl", sh9t, L))
        ok(not any("noam-ai.json curriculum track" in m for m in msgs(r, G88, "a")),
           "D-F6 track_by_level a=ט_מצומצמת accepts that track in noam-ai.json %s" % msgs(r, G88, "a")[:2])
        # round 3 (VC7): the per-level entry is the ONLY track the level may
        # name; the sheet-wide SHEET.track 'ט_רגילה' printed by level a (IR
        # curriculum and noam-ai.json alike) contradicts track_by_level a
        r = run_ctx(build("f_noam_g9_tbl_other", sh9t, levels(c9)))
        ok(status(r, G88, "a") == "FAIL" and
           any(u"noam-ai.json curriculum track 'ט_רגילה', SHEET declares ט_מצומצמת" in m for m in msgs(r, G88, "a")) and
           any(u"level a curriculum track 'ט_רגילה', SHEET declares ט_מצומצמת" in m for m in msgs(r, G88, "a")) and
           status(r, G88, "c") == "PASS",
           "round 3 G88: track_by_level a=ט_מצומצמת rejects the sheet-wide ט_רגילה %s" % msgs(r, G88, "a")[:3])
        # level b, no per-level entry: the sheet-wide track or the house mapping (E88-8, by design)
        ok(status(r, G88, "b") == "PASS", "round 3 G88: level b without an entry keeps SHEET.track %s"
           % msgs(r, G88, "b")[:2])
        # SHEET.track as a per-level dict: the same rule
        sh9d = copy.deepcopy(sh9)
        sh9d["track"] = {"a": u"ט_מצומצמת", "b": u"ט_מצומצמת", "c": u"ט_רגילה"}
        L = levels(c9)
        L["b"]["curriculum"] = dict(c9, track=u"ט_מצומצמת")
        r = run_ctx(build("f_track_dict", sh9d, L))
        ok(status(r, G88, "a") == "FAIL" and status(r, G88, "b") == "PASS" and status(r, G88, "c") == "PASS",
           "round 3 G88: SHEET.track dict a=ט_מצומצמת rejects ט_רגילה in level a %s"
           % [msgs(r, G88, k)[:2] for k in "abc"])
        # SHEET.track[k] and track_by_level[k] disagree -> FAIL (one track per level)
        sh9x = copy.deepcopy(sh9d)
        sh9x["track_by_level"] = {"c": u"ט_מצומצמת"}
        r = run_ctx(build("f_track_clash", sh9x, L))
        ok(status(r, G88, "c") == "FAIL" and any("one track per level" in m for m in msgs(r, G88, "c")),
           "round 3 G88: SHEET.track[c] != track_by_level[c] FAILs %s" % msgs(r, G88, "c")[:2])
        # track_by_level[k] hidden by a SHEET.track dict without k -> FAIL
        sh9h = copy.deepcopy(sh9)
        sh9h["track"] = {"a": u"ט_רגילה", "c": u"ט_רגילה"}
        sh9h["track_by_level"] = {"b": u"ט_רגילה"}
        r = run_ctx(build("f_track_hidden", sh9h, levels(c9)))
        ok(status(r, G88, "b") == "FAIL" and any("in one place" in m for m in msgs(r, G88, "b")) and
           status(r, G88, "a") == "PASS",
           "round 3 G88: track_by_level[b] ignored by track_for FAILs %s" % msgs(r, G88, "b")[:2])
    finally:
        if saved is not None:
            sys.modules["selfcheck_catalog"] = saved
        else:
            sys.modules.pop("selfcheck_catalog", None)
        shutil.rmtree(str(tmp), ignore_errors=True)
    for f in fails:
        print("FAIL", f)
    print("gate_sections selftest: %s (%d failure(s))" % ("PASS" if not fails else "FAIL", len(fails)))
    return not fails


if __name__ == "__main__":
    sys.exit(main())
