# -*- coding: utf-8 -*-
r"""wspec_build -- v6.9: a worksheet level whose figures (and the maths core
of its question text) are declared as a WSPEC SPEC, built by the vendored
engine (wspec/, the wspec-engine-v1 of 2026-09-23).

A question of a level may carry `spec=` instead of builder figures:

    import wspec_build as WB
    LS = WB.LevelSpec("g9t18a.wspec.json")     # {"spec": ..., "display": ...}
    Q = [LS.question("q1", space=40, didactic={"q1a": DID(...)}),
         dict(n=2, intro=..., fig=shapekit..., items=[...])]   # old path

For such a question the build
  (a) validates the spec (wspec.schema.validate, templates approved by hash),
  (b) builds the PUBLIC model (wspec.project.public_model) -- the only thing
      the renderer reads -- and the private one (answers) beside it,
  (c) renders every figure with the engine (wspec.render.render) and inlines
      its SVG in the sheet EXACTLY: the file's bytes from `<svg` on, no
      re-drawing, no font pinning, no rescaling (the page prints it at the
      placement the engine returns: 1 SVG px = 0.75 pt),
  (d) prints the question / item texts the approved templates generate
      (wspec.templates.render_spec; the level's approved prose joins them
      through the spec's own `prose` segments),
  (e) writes the answer key from the PRIVATE part (answer facts).
A question without `spec` is untouched: `expand_level(L)` returns the very
same level object when no question carries a spec, so the builder path is
byte-for-byte what it was.

What this module hands the rest of the skill
  expand_level(L)        the level with every spec question as an ordinary
                         question dict (intro, fig, items with given /
                         to_prove / to_construct as claim dicts, answers),
                         plus L["_wspec_figs"] {fid: FigRec}
  is_spec_svg(svg)       the inline SVG string is an engine figure
  fig_key(svg)           a stable key for sheet_unique_ids ("wspec:" + sha1)
  figure_entry(rec, ..)  the sheet.json entry of one engine figure: objects
                         (points, segments, labels, arcs, marks ... with the
                         engine's element ids as svg_id), constraints from
                         the spec's facts, view from the placement
  vm_engine_layer(vm, rec)  the visual_model gets the engine's objects
                         (object id -> parts: svg ids + span)
  figure_script(rec)     figures/<id>.py: re-renders from the stored public
                         spec and prints the SVG byte for byte
"""
import copy
import hashlib
import json
import math
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

from wspec import schema as WS          # noqa: E402
from wspec import templates as WT       # noqa: E402
from wspec import project as WP         # noqa: E402
from wspec import render as WR          # noqa: E402
from wspec import canon as WC           # noqa: E402
from wspec.errors import SpecError as _WSpecError   # noqa: E402
import givens614 as G614                  # noqa: E402  (v6.14 F2 / F3)
import wspec_fam616 as F616               # noqa: E402  (v6.16 integrate)

HOUSE_FONT = "David Libre,serif"
ITEM_FIG_MAX = 150.0            # emit_plus: an item figure is <= 150 px wide
PUBLIC_SPEC_REL = "wspec/public_spec.json"   # in a deliver level folder
DEFAULT_SPACE = 40
_TSET = []


def tset():
    if not _TSET:
        _TSET.append(WT.load_templates())
    return _TSET[0]


class SpecBuildError(AssertionError):
    """A spec level the build cannot make true."""


def _bad(said, fix):
    raise SpecBuildError("wspec_build: %s -- %s" % (said, fix))


def _issues_text(issues, n=6):
    out = []
    for i in list(issues)[:n]:
        out.append("%s %s %s" % (getattr(i, "code", ""),
                                 getattr(i, "where", ""),
                                 getattr(i, "detail", "")))
    more = len(issues) - n
    return "; ".join(out) + (" (+%d more)" % more if more > 0 else "")


# ------------------------------------------- v6.9 fix r1: the text layer --
def apply_text_layer(spec, layer, name="spec"):
    """The level file's "text" layer: {scope id: [segments]} -- another
    composition of the SAME maths core of a question / item text (which
    approved templates, which connectors), like "display" is another
    layout of the same figure. Refused unless, for every scope:
      * the scope is a question or item of the spec;
      * the new segments use approved templates / connectors only, and no
        prose the scope's own text does not already use (prose needs a
        human approval of its exact text);
      * they print EXACTLY the facts the spec's own text prints (same fact
        ids, same count): nothing dropped, nothing added, no answer, no
        target value (the template checks refuse those anyway).
    Returns a copy of the spec with those texts replaced -- used ONLY to
    print the sheet's texts (LevelSpec.rendered / text_segs); LevelSpec.spec,
    the public model and its hash stay the spec's own."""
    if not isinstance(layer, dict):
        _bad("the text layer of %s is not {scope: [segments]}" % name,
             "give text={\"q1\": [{\"tpl\": ...}, {\"join\": \". \"}]}")
    new = copy.deepcopy(spec)
    ix = WS.Index(spec)
    scopes = {}
    for q in new.get("questions") or []:
        scopes[q.get("id")] = q
        for it in q.get("items") or []:
            scopes[it.get("id")] = it
    for sid in sorted(layer):
        segs = layer[sid]
        holder = scopes.get(sid)
        if holder is None:
            _bad("the text layer of %s names %r, which is no question / "
                 "item of the spec" % (name, sid),
                 "scopes: %s" % ", ".join(sorted(scopes)))
        old = holder.get("text") or []
        old_prose = set(s.get("prose") for s in old
                        if isinstance(s, dict) and "prose" in s)
        for s in segs if isinstance(segs, list) else []:
            if isinstance(s, dict) and "prose" in s and \
                    s.get("prose") not in old_prose:
                _bad("the text layer of %s gives %s prose %r that its own "
                     "text does not use" % (name, sid, s.get("prose")),
                     "prose joins a text only with the author's approval "
                     "(approved_by / approved_hash in the spec)")
        try:
            _t0, f_old = WT.render_text(tset(), old, ix, sid, mode="sheet")
            _t1, f_new = WT.render_text(tset(), segs, ix, sid, mode="sheet")
        except _WSpecError as e:
            _bad("the text layer of %s: %s cannot be generated: %s"
                 % (name, sid, _issues_text(e.issues)),
                 "template calls with the scope's own facts, approved "
                 "connectors (wspec/templates_he.json)")
        if sorted(f_old) != sorted(f_new):
            _bad("the text layer of %s: %s prints %s, the spec's own text "
                 "prints %s" % (name, sid, sorted(f_new), sorted(f_old)),
                 "the text layer recomposes the same facts: every fact the "
                 "spec's text prints, once, and nothing else")
        holder["text"] = copy.deepcopy(segs)
    return new


# ------------------------------------------------------------- loading ----
def load(path):
    """A spec file: {"spec": <wspec spec>, "display": {fid: settings}} or a
    bare wspec spec (display then given to LevelSpec)."""
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def sub_spec(spec, qids):
    """The level spec cut to some questions (tests, pilots): their facts,
    figures, releases and the entities these name. The result validates on
    its own when the questions do not lean on the others."""
    qids = list(qids)
    ix = WS.Index(spec)
    keep_q = [q for q in spec.get("questions") or [] if q.get("id") in qids]
    if len(keep_q) != len(qids):
        _bad("sub_spec: no question(s) %s in the spec"
             % sorted(set(qids) - set(q["id"] for q in keep_q)),
             "name questions of the spec (q1, q2 ...)")
    scopes = set()
    for q in keep_q:
        scopes.add(q["id"])
        for it in q.get("items") or []:
            scopes.add(it["id"])
    facts = [f for f in spec.get("facts") or [] if f.get("item") in scopes]
    fids = set(f["id"] for f in facts)
    figs = [g for g in spec.get("figures") or [] if g.get("scope") in scopes]
    rel = [r for r in spec.get("releases") or [] if r.get("fact") in fids]
    prose = [p for p in spec.get("prose") or [] if p.get("scope") in scopes]
    ents = set()
    for f in facts:
        for a in f.get("args") or []:
            ents |= set(WS.entity_closure(a, ix))
    for g in figs:
        for e in g.get("entities") or []:
            ents |= set(WS.entity_closure(e, ix))
    out = {}
    for k, v in spec.items():
        if k == "entities":
            out[k] = [e for e in v if e.get("id") in ents]
        elif k == "facts":
            out[k] = facts
        elif k == "figures":
            out[k] = figs
        elif k == "questions":
            out[k] = keep_q
        elif k == "releases":
            out[k] = rel
        elif k == "prose":
            out[k] = prose
        else:
            out[k] = copy.deepcopy(v)
    return copy.deepcopy(out)


# ------------------------------------------------------------ registry ----
_REG = {}             # inline svg -> [FigRec]


def _register(rec):
    _REG.setdefault(rec["svg"], [])
    if not any(r is rec for r in _REG[rec["svg"]]):
        _REG[rec["svg"]].append(rec)


# v6.12 fix_r1: the two engine FAMILIES (their own renderers and dialects);
# (v6.16 integrate) + the graph and pie engines (wspec_fam616.ENGINES)
FAMILY_ENGINES = ("wspec-coord/1.0.0", "wspec-render-nl/1.0.0",
                  F616.GRAPH_ENGINE, F616.PIE_ENGINE)


def is_family_rec(rec):
    """a figure drawn by a family engine (coordinate plane / number line):
    no inner lines, no polygon vertex dots -- the geometry look settings
    (inner_stroke, vertex_dots) do not exist there."""
    return ((rec or {}).get("object_map") or {}).get("engine") in \
        FAMILY_ENGINES


def family_of_rec(rec):
    """v6.13 fix_r1 (C1/C2): the visual_model kind of an engine figure drawn
    by a family engine -- 'coordinate_plane' / 'number_line' -- else None
    (a geometry engine figure is classified as before)."""
    eng = ((rec or {}).get("object_map") or {}).get("engine")
    if eng == FAMILY_ENGINES[0]:
        return "coordinate_plane"
    if eng == FAMILY_ENGINES[1]:
        return "number_line"
    # (v6.16 integrate) 'function_graph' / 'pie_chart'
    return F616.family_of_engine(eng)


# v6.13 integ (t01_b): a number line's display role "tick" is a tick of its
# AXIS (wspec-nl-svg/1), not the geometry engine's equal-length tick mark;
# the coordinate plane names its axis ticks "axis_tick", so no role clashes
def _mark_roles(rec):
    """the display roles that are geometry MARKS (each states a fact the
    export must carry) in this figure's engine."""
    eng = ((rec or {}).get("object_map") or {}).get("engine")
    if eng == FAMILY_ENGINES[1]:
        return ("angle_arc", "right_mark", "parallel_arrow")
    if F616.family_of_engine(eng):
        # (v6.16 integrate) a graph's "tick" is an axis tick; a pie has no
        # geometry mark
        return ()
    return ("angle_arc", "right_mark", "tick", "parallel_arrow")


def is_spec_svg(svg):
    return isinstance(svg, str) and svg in _REG


def fig_key(svg):
    """sheet_unique_ids' key of an engine figure (it has no data-fig)."""
    return "wspec:" + hashlib.sha1(svg.encode("utf-8")).hexdigest()[:16]


def inline_of(svg_file):
    """The inline form of an engine SVG file: from `<svg` on (the XML
    declaration cannot stand inside HTML). Nothing else changes."""
    k = svg_file.find("<svg")
    if k < 0:
        _bad("an engine figure has no <svg> element", "re-render it")
    return svg_file[k:].rstrip("\n")


def three_letter_angles(spec):
    """v6.11 fix r1 (author decision W-ANGLE-3-LETTERS, wspec/approvals/
    APPROVALS_NOAM.json: "always an angle with three letters"): every fact
    display that names an ANGLE by its vertex alone ("B" for ang:ABC) is
    dropped, in place, so the engine prints the angle entity's own three
    letters (∠ABC) -- the angle the fact is about, never a guess. A display
    of any other kind, or a three-letter one (the order v6.7.3 printed,
    "MCB"), stays. Returns [(fact id, arg, dropped display)]. A package
    that still prints a one-letter angle is refused by gate G81
    (anglenames.py) at the build and in verify_export."""
    ents = dict((e.get("id"), e) for e in spec.get("entities") or [])
    out = []
    for f in spec.get("facts") or []:
        d = f.get("display")
        if not isinstance(d, list):
            continue
        new = list(d)
        for k, (a, x) in enumerate(zip(f.get("args") or [], d)):
            e = ents.get(a) or {}
            if e.get("kind") == "angle" and x == e.get("vertex"):
                new[k] = None
                out.append((f.get("id"), a, x))
        if new != d:
            if all(x is None for x in new):
                f.pop("display")
            else:
                f["display"] = new
    return out


def spec_without(spec, qids, display=None, text=None):
    """(v6.10 fix r1, s1) the level spec WITHOUT the questions a level still
    prints through the builder: their facts, figures, releases and prose
    go with them. The package's public spec then holds only what the
    sheet prints from the spec -- a builder question's own text is the
    builder dict's, and a public model that restated the spec's other
    wording of it would disagree with the PDF. Returns (spec, display,
    text) -- copies; display / text lose the dropped scopes too."""
    qids = set(qids or ())
    sp = copy.deepcopy(spec)
    gone = set()
    for q in sp.get("questions") or []:
        if q.get("id") in qids:
            gone.add(q["id"])
            gone.update(it.get("id") for it in q.get("items") or [])
    miss = qids - gone
    if miss:
        _bad("spec_without: no question %s in the spec" % sorted(miss),
             "name questions of the spec (q<n>)")
    sp["questions"] = [q for q in sp.get("questions") or []
                       if q.get("id") not in qids]
    dropped = set(f["id"] for f in sp.get("facts") or []
                  if f.get("item") in gone)
    sp["facts"] = [f for f in sp.get("facts") or []
                   if f["id"] not in dropped]
    for f in sp["facts"]:
        src = f.get("source") or {}
        if set(src.get("from") or []) & dropped:
            _bad("spec_without: %s derives from a fact of a dropped "
                 "question" % f["id"], "keep that question on the spec")
    figs = set(g.get("id") for g in sp.get("figures") or []
               if g.get("scope") in gone)
    sp["figures"] = [g for g in sp.get("figures") or []
                     if g.get("id") not in figs]
    if "releases" in sp:
        sp["releases"] = [r for r in sp["releases"]
                          if r.get("fact") not in dropped]
    if "prose" in sp:
        sp["prose"] = [x for x in sp["prose"] if x.get("scope") not in gone]
    if isinstance(sp.get("didactic"), dict):
        sp["didactic"] = dict((k, v) for k, v in sp["didactic"].items()
                              if k not in gone)
    disp = None if display is None else dict(
        (k, v) for k, v in display.items() if k not in figs)
    txt = None if text is None else dict(
        (k, v) for k, v in text.items() if k not in gone)
    return sp, disp, txt


# -------------------------------------------------------------- level -----
class LevelSpec(object):
    """One level's wspec spec: validated, projected, its texts generated."""

    def __init__(self, spec, display=None, name=None, text=None):
        if isinstance(spec, str):
            name = name or os.path.basename(spec)
            spec = load(spec)
        if isinstance(spec, dict) and "spec" in spec and \
                "questions" not in spec:
            display = display if display is not None else spec.get(
                "display")
            text = text if text is not None else spec.get("text")
            spec = spec["spec"]
        self.name = name or spec.get("sheet") or "spec"
        self.text_layer = sorted((text or {}).keys())
        # the text layer changes what the SHEET prints, never the facts
        # (apply_text_layer: the same fact ids, approved templates only).
        # (v6.10 fix r1, s1) the PUBLIC model is the printed one: the
        # delivered wspec/public_spec.json says what the sheet prints (a
        # public file that disagrees with the PDF is a defect), and
        # source/level_spec.json ships this printed spec -- the spec the
        # build used, from which that public model is re-derived
        printed = apply_text_layer(spec, text, self.name) if text else spec
        self.spec = spec
        self.printed = printed
        self.display = dict(display or {})
        issues = WS.validate(spec, tset())
        if issues:
            _bad("the spec %s does not validate: %s"
                 % (self.name, _issues_text(issues)),
                 "fix the spec (wspec.schema); a level is built only from a "
                 "spec that validates with 0 issues")
        try:
            self.pub = WP.public_model(printed, tset(), mode="sheet")
            self.prv = WP.private_model(printed, tset())
        except _WSpecError as e:
            _bad("the spec %s has no public model: %s"
                 % (self.name, _issues_text(e.issues)),
                 "fix the spec")
        self.ix = WS.Index(spec)
        out = []
        # 'sheet': the worksheet form (one math island per datum; fix r1)
        self.rendered = WT.render_spec(printed, tset(), self.ix, out,
                                       mode="sheet")
        self.text_segs = {}          # scope -> the segments the sheet prints
        for q in printed.get("questions") or []:
            self.text_segs[q.get("id")] = q.get("text")
            for it in q.get("items") or []:
                self.text_segs[it.get("id")] = it.get("text")
        if out:
            _bad("the texts of %s cannot be generated: %s"
                 % (self.name, _issues_text(out)),
                 "every question / item text is template calls, joins and "
                 "approved prose (wspec/templates_he.json)")
        self.answers = {}
        for f in spec.get("facts") or []:
            if f.get("role") == "answer":
                self.answers[f["id"][:-1] + "t"] = f
        self._figs = {}

    # -- figures ----------------------------------------------------------
    def settings(self, fid):
        st = self.display.get(fid)
        if F616.is_graph_fid(self, fid) or F616.is_pie_fid(self, fid):
            # (v6.16 integrate) a graph / pie figure: the author's display
            # settings are optional (square, fonts, radius); a graph's
            # hidden numbers come from its spec (wspec_fam616.settings)
            try:
                st = F616.settings(self, fid, st)
            except ValueError as ex:
                _bad(str(ex), "drop 'curves' / 'marks' from the display "
                     "settings: the build lays them out from the spec")
        if st is None:
            _bad("figure %s of %s has no display settings" % (fid, self.name),
                 "give display={%r: {'layout': [...], 'width': ...}} (the "
                 "engine's layout program, wspec/render/FORMAT.txt)" % fid)
        st = dict(st)
        source_fig = F616.spec_figure(self, fid) or {}
        if source_fig.get("data") is not None:
            from wspec import sheet_data as SD
            if "data_layout" in st:
                _bad("figure %s authors private data_layout" % fid,
                     "observation positions are derived from the source spec")
            st["data_layout"] = SD.display_layout(source_fig)
        st.setdefault("figure", fid)
        st.setdefault("font_family", HOUSE_FONT)
        if st["figure"] != fid:
            _bad("display settings of %s name figure %s" % (fid,
                                                            st["figure"]),
                 "one settings entry per figure id")
        return st

    def figure(self, fid, question, item):
        if fid in self._figs:
            return self._figs[fid]
        st = self.settings(fid)
        try:
            out = WR.render(self.pub, st, WR.ENGINE_VERSION)
        except WR.RenderRefused as e:
            _bad("the engine refuses figure %s: %s" % (fid, e),
                 "fix its display settings / layout (wspec/render/"
                 "FORMAT.txt)")
        val = out["validation"]
        if val.get("status") != "PASS":
            _bad("figure %s: the renderer's own validation says %s (%s)"
                 % (fid, val.get("status"), "; ".join(
                     "%s %s" % (i.get("code"), i.get("detail", ""))
                     for i in (val.get("issues") or [])[:4])),
                 "fix the layout so the drawing states the spec (a FAIL is "
                 "never printed)")
        from wspec import rules617 as R617
        private_issues = R617.private_figure_issues(self.ix, out["svg"], fid)
        if private_issues:
            _bad("figure %s: private proof configuration failed: %s" %
                 (fid, "; ".join("%s %s" % (i.code, i.detail) for i in private_issues[:4])),
                 "make the finished SVG agree with the private steps; never publish the private step to bypass this check")
        rec = {"fid": fid, "svg_file": out["svg"],
               "svg": inline_of(out["svg"]),
               "object_map": out["object_map"],
               "placements": out["placements"], "validation": val,
               "settings": st, "question": question, "item": item,
               "level": self}
        self._figs[fid] = rec
        _register(rec)
        return rec

    # -- questions --------------------------------------------------------
    def question(self, qid, **kw):
        """The content-side question: {'n': .., 'spec': ..} + the author's
        own keys (space / spaces / didactic / star / part ...)."""
        q = self.ix.questions.get(qid)
        if q is None:
            _bad("%s has no question %s" % (self.name, qid),
                 "questions: %s" % ", ".join(sorted(self.ix.questions)))
        if kw.get("printed_claims") is not None:
            # The source spec, not an in-memory public patch, owns every
            # retained description. Register before any figure receives
            # the public hash; a late declaration would stale its map.
            declaration = {"scopes": copy.deepcopy(kw["printed_claims"]),
                           "unsupported": bool(kw.get("spec_unsupported"))}
            current = next(x for x in self.printed["questions"] if x["id"] == qid)
            if current.get("printed_claims") != declaration:
                if self._figs:
                    _bad("%s claims declared after rendering" % qid,
                         "declare all question metadata before rendering figures")
                candidate = copy.deepcopy(self.printed)
                next(x for x in candidate["questions"] if x["id"] == qid)["printed_claims"] = declaration
                try:
                    pub = WP.public_model(candidate, tset(), mode="sheet")
                except _WSpecError as ex:
                    _bad("%s claims do not validate: %s" % (qid, _issues_text(ex.issues)),
                         "use source excerpts bound to existing targets, without values")
                self.printed, self.pub = candidate, pub
        d = dict(kw)
        d["n"] = q.get("n")
        d["spec"] = QuestionRef(self, qid)
        return d


class QuestionRef(object):
    def __init__(self, level, qid):
        self.level, self.qid = level, qid

    def __repr__(self):
        return "<wspec question %s of %s>" % (self.qid, self.level.name)


def has_spec(L):
    return any(isinstance(q, dict) and q.get("spec") is not None
               for q in L.get("questions") or [])


# ---------------------------------------------------------- facts -> claims
_SHAPES = ("rectangle", "square", "parallelogram", "rhombus", "equilateral",
           "isosceles")
# (v6.10) relations carried by their text only (no content-schema claim)
_TEXT_ONLY_RELS = ("linear", "greater", "not_parallel", "inside",
                   "acute_triangle", "classify",
                   # (v6.17-noam V1)
                   "obtuse_triangle")
# (v6.14 F2) axis_parallel is no longer a text-only line: 'AB ∥ ציר x' is a
# typed parallel claim {'of': ['AB', 'axis-x']} linked to its fact
# (givens614.axis_parallel_claim) -- the figure model names its objects and
# marks it (givens614.engine_given_marks)
# (v6.10) the new shape classes a typed-shape claim can carry (deliver's C3
# block reads 'trapezoid' and 'right_triangle'; an isosceles trapezoid is
# a trapezoid whose text says שווה־שוקיים)
_SHAPE_VALUE = {"trapezoid": "trapezoid", "isosceles_trapezoid":
                "trapezoid", "right_triangle": "right_triangle"}
_QTY = {"angle_measure": "angle", "length": "length", "perimeter":
        "perimeter", "area": "area", "var_value": "variable",
        "ratio": "ratio"}


def _ent(ix, eid):
    return ix.entities.get(eid) or {}


def _seg_name(ix, eid, override=None):
    if override:
        return override
    e = _ent(ix, eid)
    if e.get("kind") == "segment":
        return "".join(e["ends"])
    if e.get("kind") == "line":
        return e.get("name") or "".join(e["through"])
    if e.get("kind") == "ray":
        return e["from"] + e["through"]
    return WT.entity_name(eid, ix)


def _poly_name(ix, eid):
    """a polygon's printed name: its vertex letters; (v6.16 gaps, G5) a
    polygon declared by coordinates only has none -- its vertex places,
    as the sheet declares them (templates.entity_name)."""
    e = _ent(ix, eid)
    if e.get("tag") is not None:
        return WT.entity_name(eid, ix)
    return "".join(e["vertices"])


def _tagged(ix, eid):
    """(v6.16 gaps r2, G5) a polygon declared by coordinates only: no
    letters -- its find targets say what they ask in words ('שטח המצולע',
    quantity 'value', as the v6.7.3 builder rows), never of='<letters>'."""
    e = _ent(ix, eid)
    return e.get("kind") == "polygon" and e.get("tag") is not None


def _unit_words(f):
    """(v6.16 gaps r2) a grid unit in words ('יחידות ריבועיות'), as the
    builder's find rows carry it; None when the fact has no unit."""
    try:
        u = WC.canon_unit((f or {}).get("unit"))
    except _WSpecError:
        return None
    if not u:
        return None
    return (WC.UNIT_DISPLAY.get(u) or "").strip() or None


def _disp(f, k):
    d = f.get("display")
    return d[k] if isinstance(d, list) and k < len(d) else None


def _angle(ix, eid, override=None):
    e = _ent(ix, eid)
    if override and len(override) == 3:
        return {"at": override[1], "rays": [override[0], override[2]]}
    return {"at": e["vertex"], "rays": list(e["arms"])}


def _num(v):
    """A canonical value as the claim dicts carry it: int / float, or the
    surd string ('8√3', v6.10: a sum '16 + 16√3')."""
    if WC.is_sum(v):
        return WC.number_display(WC.canon_number(v))
    c, r = WC.parse_number(v)
    if r != 1:
        return WC.number_display(WC.canon_number(v))
    if c.denominator == 1:
        return int(c.numerator)
    return float(c)


def _unit_he(f):
    u = WC.canon_unit(f.get("unit"))
    return {"cm": u'ס"מ', "mm": u'מ"מ', "m": u"מ'", "cm2": u'סמ"ר',
            "mm2": u'ממ"ר', "m2": u'מ"ר',
            # (v6.17, V5)
            "min": u"דקות", "h": u"שעות", "L": u"ליטר", "km": u'ק"מ'}.get(u)


def claim_of(LS, f):
    """One spec fact as the claim dict of the content schema (given /
    to_prove / to_construct); a target becomes a find target whose value
    is the answer from the private part (sheet.json only).
    (v6.14 fix_r1, W-META-LINES-3) a claim whose line is one of the three
    approved unprinted wordings ('המספר שמייצגת הנקודה A', 'ההפרש בין
    הערכים של שני קווי רשת סמוכים על ציר x', 'AB ∥ ציר x') links the fact
    it restates (facts), so the author's condition is checked: at build
    (given_source_faults / target_source_faults), in deliver and in
    selfcheck_noam_package K25 (givens614.meta_line_faults)."""
    c = _claim_core(LS, f)
    if G614.is_meta_line(c.get("text")) and "facts" not in c:
        c["facts"] = [f["id"]]
    return c


def _claim_core(LS, f, technical=False):
    ix = LS.ix
    rel, args, role = f["rel"], list(f.get("args") or []), f.get("role")
    from wspec import base_height as BH
    description = None if technical else BH.description(f, ix)
    if description:
        if role == "target":
            kind, _ = BH.role_of(f, ix)
            if kind in ("base", "height"):
                # Reading a printed datum uses the established native
                # read-off claim projection, not an undisclosed-value find.
                # Both typed length targets and answers remain in WSPEC.
                return {"text": description, "facts": [f["id"]], "readoff": True}
            c = {}
            if kind == "area":
                c = {"type": "find", "quantity": "area", "of": _poly_name(ix, args[0]), "text": description}
            answer = LS.answers.get(f["id"]) or {}
            if answer.get("value") is not None:
                c["value"] = _num(answer["value"])
            return c
        return {"text": description, "facts": [f["id"]]}
    text = WT.fact_line(tset(), f, ix)
    from wspec import point_transform as PT
    # The existing claim projection takes its source from LS.ix. Ordinary
    # claims need no new LS.spec attribute; C1 uses that same index's full
    # source only for the coordinate target kind it actually handles.
    if role == "target" and rel == "coordinate" and PT.target_row(ix.spec, f) is not None:
        c = {"type": "find", "quantity": "value", "what": PT.find_what(ix.spec, f), "text": text}
        a = LS.answers.get(f["id"])
        if a is not None:
            c["value"] = _num(a["value"])
        return c
    if rel == "classify" and role == "target":
        # (v6.10 fix r2, N1) "which special quadrilateral is ABCD?" is a
        # find target, as v6.7.3 wrote it: {quantity 'value', of 'ABCD',
        # what 'סוג המרובע', value 'מלבן'}; the value (the class noun) is
        # private -- sheet.json only, never noam-ai.json
        c = {"type": "find", "quantity": "value",
             "of": _disp(f, 0) or WT.entity_name(args[0], ix),
             "what": WT.classify_what(tset(), f, ix), "text": text}
        a = LS.answers.get(f["id"])
        if a is not None and a.get("value") is not None:
            c["value"] = tset().class_nouns[a["value"]]
        return c
    if rel == "axis_parallel" and role in ("given", "to_prove"):
        qid = ix.scope_question.get(f.get("item"))
        has_figure = any(ix.scope_question.get(g.get("scope")) == qid
                         for g in ix.figures.values())
        if not has_figure:
            # A figureless Cartesian fact has no visual axis-x/y operand.
            # Keep its typed geometry in the public spec and expose only its
            # exact printed clause plus fact link in Noam's claim projection.
            # K6 continues to reject any invented visual object references.
            noun = {"segment": u"הקטע", "line": u"הישר", "ray": u"הקרן"}.get(
                ix.kind(args[0])) if args else None
            name = _seg_name(ix, args[0], _disp(f, 0)) if args else ""
            axis = WT.entity_name(args[1], ix) if len(args) == 2 else ""
            source = _claim_excerpt(LS.rendered.texts.get(f.get("item"), ""))
            clause = u"%s %s מקביל לציר %s" % (noun, name, axis)
            match = re.search(r"(?:^|[.;]\s*)(%s)(?=$|[\s,.;])" %
                              re.escape(clause), source) if noun else None
            if match is None:
                _bad("figureless axis_parallel %s has no exact printed clause"
                     % f["id"], "keep its original segment/line/ray parallel "
                     "statement in this scope; never invent a visual axis")
            return {"text": match.group(1), "facts": [f["id"]]}
        return G614.axis_parallel_claim(
            f, _seg_name(ix, args[0], _disp(f, 0)) if args else "", text)
    if rel in _TEXT_ONLY_RELS or rel == "axis_parallel":
        # (v6.10) a relation the content schema has no claim type for is
        # carried as its generated line (like the builder's text claims)
        return {"text": text}
    if role == "target":
        q = _QTY.get(rel)
        if q is None:
            if rel in WS.FAMILY_RELS:
                # v6.13 fix_r1 (C1): a coordinate-plane / number-line
                # target (read off, interval value ...) is a text row as
                # before, marked for deliver.readoff_questions -- its
                # figure's data frame is withheld from noam-ai.json (the
                # key 'readoff' is never exported: _NOAM_CLAIM_KEYS)
                return {"text": text, "readoff": True}
            return {"text": text}
        c = {"type": "find", "quantity": q}
        if rel == "angle_measure":
            c.update(_angle(ix, args[0], _disp(f, 0)))
        elif rel == "length":
            c["of"] = _seg_name(ix, args[0], _disp(f, 0))
        elif rel in ("perimeter", "area") and not _disp(f, 0) and \
                _tagged(ix, args[0]):
            # (v6.16 gaps r2, K4 of t08_c) an unnamed (G5) polygon has no
            # letters for of=: the builder's form {quantity 'value', what
            # 'שטח המצולע'} (check_didactic D12 / noam K15 pass it)
            c["quantity"] = "value"
            c["what"] = (u"היקף " if rel == "perimeter" else u"שטח ") + \
                _poly_name(ix, args[0])
        elif rel in ("perimeter", "area"):
            c["of"] = _disp(f, 0) or _poly_name(ix, args[0])
        elif rel == "var_value":
            c["of"] = _ent(ix, args[0]).get("name")
        elif rel == "ratio":
            c["of"] = [_seg_name(ix, a, _disp(f, k))
                       for k, a in enumerate(args)]
        a = LS.answers.get(f["id"])
        if a is not None and a.get("value") is not None:
            c["value"] = _num(a["value"])
        u = _unit_he(a or f) if rel in ("length", "perimeter", "area") \
            else None
        if not u and rel in ("length", "perimeter", "area"):
            # Coordinate units belong to named objects too (AB / ABCD),
            # not only an unnamed polygon's what= description.
            u = _unit_words(a or f)
        if u:
            c["unit"] = u
        c["text"] = text
        return c
    c = None
    if rel == "angle_measure" and f.get("value") is not None:
        c = {"type": "angle", "value": _num(f["value"])}
        c.update(_angle(ix, args[0], _disp(f, 0)))
    elif rel == "length" and f.get("value") is not None:
        c = {"type": "length", "of": _seg_name(ix, args[0], _disp(f, 0)),
             "value": _num(f["value"])}
        if _unit_he(f):
            c["unit"] = _unit_he(f)
    elif rel in _SHAPES or rel in _SHAPE_VALUE:
        c = {"type": "shape", "points": list(_ent(ix, args[0])["vertices"]),
             "value": _SHAPE_VALUE.get(rel, rel)}
    elif rel in ("on_segment", "midpoint"):
        e = _ent(ix, args[1])
        c = {"type": rel, "point": args[0], "of": list(e["ends"])}
    elif rel == "equal_length":
        c = {"type": "equal_length", "of": [_seg_name(ix, a, _disp(f, k))
                                            for k, a in enumerate(args)]}
    elif rel == "equal_angle":
        # the content schema names the angles 'DAE' (the vertex between);
        # the figure's constraint takes {at, rays} (_constraints)
        c = {"type": "equal_angle", "of": [
            (lambda g: g["rays"][0] + g["at"] + g["rays"][1])(
                _angle(ix, a, _disp(f, k))) for k, a in enumerate(args)]}
    elif rel in ("parallel", "perpendicular"):
        c = {"type": rel, "of": [_seg_name(ix, a, _disp(f, k))
                                 for k, a in enumerate(args)]}
    elif rel == "ratio" and f.get("value") is not None:
        c = {"type": "ratio", "of": [_seg_name(ix, a, _disp(f, k))
                                     for k, a in enumerate(args)],
             "value": _num(f["value"])}
    elif rel == "plot" and role == "to_plot" and args and \
            ix.kind(args[0]) == "point":
        # (v6.13 fix_r2) a point the student plots is the row's typed
        # to_construct point, as the builder writes it (new_pt: {'type':
        # 'point', 'point': 'A'}): a later find target may name it (15ג
        # "the length of AB" after 15א "plot A, B, C")
        c = {"type": "point",
             "point": _ent(ix, args[0]).get("name") or args[0]}
    elif role == "to_construct":
        res = _ent(ix, args[0]) if args else {}
        k = res.get("kind")
        if k == "segment":
            c = {"type": "segment", "of": _seg_name(ix, args[0], _disp(f, 0))}
        elif k in ("line", "ray"):
            c = {"type": k, "of": _seg_name(ix, args[0], _disp(f, 0))}
        elif k == "point":
            c = {"type": "point", "point": args[0]}
        elif k == "polygon":
            c = {"type": "polygon"}
            if not res.get("tag"):
                c["points"] = list(res["vertices"])
    if c is None:
        return {"text": text}
    c["text"] = text
    return c


_CLINE_WORD = {"parallel": u"המקביל", "perpendicular": u"המאונך"}


def cline_constructs(LS, iid, it, have=()):
    """(v6.10 integrate) the to_construct claims of the clines an item's
    text mentions (a cline is public by its id; the sheet gives it no
    name): {'type': 'line', 'of': [P], 'parallel_to' | 'perpendicular_to':
    'AD', 'text': 'ישר דרך P המקביל ל־AD'}. One per cline, in text order,
    none twice (nor one a to_construct target already declares)."""
    ix = LS.ix
    seen = set(c.get("text") for c in have if isinstance(c, dict))
    out = []
    for sg in (LS.text_segs.get(iid) or it.get("text") or []):
        if not isinstance(sg, dict):
            continue
        for eid in sg.get("entities") or []:
            e = _ent(ix, eid)
            if e.get("kind") != "cline" or e.get("op") not in _CLINE_WORD:
                continue
            # the name the mention template prints ({e0.base})
            base = WT.entity_display(e["base"], ix, "plain")
            c = {"type": "line", "of": [e["through"]],
                 "%s_to" % e["op"]: base,
                 "text": u"ישר דרך %s %s ל־%s" % (
                     e["through"], _CLINE_WORD[e["op"]], base)}
            if c["text"] not in seen:
                seen.add(c["text"])
                out.append(c)
    return out


def _carried_given(ix, f, fi):
    """f restates the stated GIVEN of the earlier item fi (L1)"""
    return any((ix.facts.get(x) or {}).get("role") == "given" and
               (ix.facts.get(x) or {}).get("item") == fi
               for x in (f.get("source") or {}).get("from") or [])


def _released_from(LS, f):
    for r in LS.spec.get("releases") or []:
        if r.get("fact") == f["id"] and r.get("from_item"):
            return r["from_item"]
    return None


def _num_tex(v, approx=None, sheet=None):
    """(v6.17, V3) a key value in the ONE printed form (canon.surd_tex):
    '$8\\sqrt{3}$', '$16 + 16\\sqrt{3}$', '$\\f{3\\sqrt{5}}{2}$' (a
    surd's coefficient is never a decimal; v6.10 printed '1.5\\sqrt{5}' and
    nested an island for 3/7); a rational as number_display prints it. An
    irrational value with approx (D6) prints its rounding after it:
    '$2\\sqrt{22} \\approx 9.4$'."""
    if not WC.is_irrational(v):
        return WC.number_display(WC.canon_number(v))
    t = WC.answer_surd_tex(WC.canon_number(v), sheet)
    if approx in WC.APPROX_DECIMALS:
        t += " \\approx " + WC.approx_text(v, approx)
    return "$%s$" % t


def _plot_key(ix, plots):
    """the key line of an item's plot targets (v6.13 integ): numbers on a
    number line are named, in the order the item's text prints them (as
    wspec.project.answer_key orders a key); a point on a plane is shown by
    the key figure."""
    nums = [(ix.entities.get((f.get("args") or [None])[0]) or {})
            for f in plots]
    if nums and all(e.get("kind") == "number" and e.get("value")
                    is not None for e in nums):
        return u"סימון של " + u", ".join(
            u"$%s$" % _nl_val(e["value"], e.get("form")) for e in nums)
    return u"סימון בשרטוט"


def _is_nl_axis(ix, aid):
    """is aid the axis of a NUMBER LINE (a figure frame of family
    number_line names it)? A plane's axes (axis:x / axis:y) are not."""
    for g in (ix.spec.get("figures") if hasattr(ix, "spec") else None) \
            or []:
        fr = g.get("frame") or {}
        if fr.get("family") == "number_line" and fr.get("axis") == aid:
            return True
    return aid == "axis:n"


def _nl_val(v, form=None):
    """a number-line value in the answer key (v6.13 integ, D6): its printed
    form (fraction / mixed / decimal, as the sheet prints it), SIGNED -- the
    house key of the number line writes 'C = +1', 'Q = +0.5' (G7-T01 a/b/c
    originals) -- and an ASCII '-' inside the math island, as the builder's
    keys ('$A = -5$'); bare maths, the caller adds the $...$."""
    try:
        t = WC.family_display(v, "tex", form, signed=True)
    except _WSpecError:
        t = _num_tex(str(v)).strip("$")
        if not t.startswith("-") and t not in ("0",):
            t = "+" + t
    return t.replace(WC.MINUS, "-")


def answer_text(LS, it):
    """The item's line of the answer key, from the private part."""
    ix = LS.ix
    from wspec import point_transform as PT
    parts = PT.answer_pairs(LS.spec, it, ix)
    tpls = [sg.get("tpl") for sg in (LS.text_segs.get(it.get("id")) or
                                     it.get("text") or [])
            if isinstance(sg, dict)]
    # (v6.10 fix r1, K) key_also: a known value the key restates after the
    # item's own answers (the fact is both its "target" and its "answer")
    also = [(x, ix.facts[x], ix.facts[x]) for x in it.get("key_also") or []]
    # v6.12 fix_r1 (t08_b D6): a point's coordinate targets print as ONE
    # house key entry -- "$A(1,4)$" on a plane (both axes), "$P = -2.5$" on a
    # number line -- not as bare numbers that no longer say which point
    coords = {}
    for t in it.get("targets") or []:
        f_, a_ = ix.facts.get(t) or {}, LS.answers.get(t)
        if PT.target_row(LS.spec, f_) is not None:
            continue
        if f_.get("rel") == "coordinate" and len(f_.get("args") or []) == 2 \
                and a_ is not None and a_.get("value") is not None:
            coords.setdefault(f_["args"][0], {})[f_["args"][1]] = \
                _nl_val(a_["value"], a_.get("form") or f_.get("form")) \
                if _is_nl_axis(ix, f_["args"][1]) else \
                _num_tex(a_["value"], sheet=LS.spec.get("sheet")).strip("$")
    done_pts = set()
    # v6.13 integ (t01_b D1): the student PLOTS these -- the key says so, as
    # the house keys do: a number line "סימון של $-2$, $+1$" (the numbers
    # the item names), a plane "סימון בשרטוט" (the key figure shows where)
    printed = list(getattr(LS.rendered, "printed", None) or [])
    plots = [ix.facts[t] for t in sorted(
        it.get("targets") or [], key=lambda t: (
            (0, printed.index(t)) if t in printed else (1, 0), t))
        if (ix.facts.get(t) or {}).get("role") == "to_plot"]
    plot_done = False
    for tid, f, a in [(t, ix.facts.get(t) or {}, LS.answers.get(t))
                      for t in it.get("targets") or []] + also:
        if PT.target_row(LS.spec, f) is not None:
            continue
        if f.get("role") == "to_plot":
            if not plot_done:
                plot_done = True
                parts.append(_plot_key(ix, plots))
            continue
        if f.get("rel") == "coordinate" and \
                (f.get("args") or [None])[0] in coords:
            p = f["args"][0]
            if p in done_pts:
                continue
            done_pts.add(p)
            cv = coords[p]
            nm = _ent(ix, p).get("name") or str(p).split(":", 1)[-1]
            if ix.kind(p) == "origin":
                nm = ""          # (v6.16 gaps, G2) the sheet names no letter
            if "axis:x" in cv and "axis:y" in cv:
                parts.append(u"$%s(%s,%s)$" % (nm, cv["axis:x"], cv["axis:y"]))
            else:
                for ax_, v_ in sorted(cv.items()):
                    parts.append(
                        u"$%s = %s$" % (nm, v_) if ax_ == "axis:n" else
                        u"שיעור ה־$%s$ של $%s$ הוא $%s$" % (
                            ax_.split(":", 1)[-1], nm, v_))
            continue
        if f.get("role") == "to_construct":
            said = any(tid in (sg.get("facts") or []) for sg in (
                LS.text_segs.get(it.get("id")) or it.get("text") or [])
                if isinstance(sg, dict))
            if said or not WS.claim_presupposes_join(f, ix):
                # (v6.10 fix r1, L2) a construction the item's claim only
                # presupposes is no answer of its own: the key says what
                # the item asks (הוכחה), as v6.7.3's did
                parts.append(u"בנייה")
            continue
        if f.get("rel") == "classify" and a is not None and \
                a.get("value") is not None:
            # (v6.10) the class, as the house key says it: "המרובע $ABCD$
            # הוא מלבן" (the class's tex phrase, the name as a math island)
            nm = _disp(f, 0) or WT.entity_name(f["args"][0], ix)
            parts.append(WT._phrase(tset(), dict(a, rel=a["value"],
                                                 display=["$%s$" % nm]),
                                    ix, "tex", "answer key"))
            continue
        if f.get("role") == "to_prove" and a is not f and \
                _deduce_only(LS.text_segs.get(it.get("id")) or
                             it.get("text") or [], it, ix):
            # (v6.10 fix r1, m1) "הסיקו כי AE = BF": the key states the
            # conclusion, as the v6.7.3 house key does ("AE = BF")
            parts.append(WT._phrase(tset(), f, ix, "sheet", "answer key"))
            continue
        if (f.get("role") == "to_prove" and a is not f) or a is None or \
                a.get("value") is None:
            parts.append(u"נימוק" if any(t in _JUSTIFY_TPLS for t in tpls)
                         else u"הוכחה")
            continue
        rel, args = f["rel"], f.get("args") or []
        v = _num_tex(a["value"], a.get("approx"), LS.spec.get("sheet"))
        u = WT._unit_text(a)
        if rel == "angle_measure":
            ang = _angle(ix, args[0], _disp(f, 0))
            # (v6.10 fix r1) a one-letter display ('∠B', as the item text
            # prints it) is the key's name too
            nm = _disp(f, 0) if _disp(f, 0) and len(_disp(f, 0)) == 1 \
                else ang["rays"][0] + ang["at"] + ang["rays"][1]
            parts.append(u"$\\angle{%s} = %s°$" % (nm, v.strip("$")))
        elif rel == "length":
            parts.append(_eq_tex(_seg_name(ix, args[0], _disp(f, 0)), v, u))
        elif rel in ("perimeter", "area"):
            word = u"היקף" if rel == "perimeter" else u"שטח"
            nm = _disp(f, 0) or _poly_name(ix, args[0])
            if not _disp(f, 0) and _tagged(ix, args[0]):
                # (v6.16 gaps r2, G5) a noun, not a maths name: 'שטח
                # המצולע הוא $30$ יחידות ריבועיות' (no \tri, no island)
                parts.append(u"%s %s הוא $%s$%s"
                             % (word, nm, v.strip("$"), u))
            elif len(_ent(ix, args[0]).get("vertices") or []) == 3:
                # (v6.10 fix r2, m2) a triangle's row as the v6.7.3 house
                # key prints it: 'שטח $\tri BOC$ הוא $12$ סמ״ר' (PENDING
                # Noam, like every key wording of the spec path)
                parts.append(u"%s $\\tri %s$ הוא $%s$%s"
                             % (word, nm, v.strip("$"), u))
            else:
                parts.append(word + u" " + _eq_tex(nm, v, u))
        elif rel == "var_value":
            # (v6.17, V5) with its unit when it has one ('$x = 10$ דקות');
            # no v6.16 var_value answer carries a unit
            parts.append(_eq_tex(_ent(ix, args[0]).get("name"), v, u))
        elif rel == "jump_value":
            # (v6.13, author decision W-NL-JUMP-DIRECTION) the key states a
            # positive size and a direction: "$5$ יחידות שמאלה"
            parts.append(WT.jump_words(tset(), a["value"], a.get("form") or
                                       f.get("form"), "tex"))
        elif rel == "interval_value" and args and \
                not _is_nl_axis(ix, args[0]):
            # v6.13 fix_r1: a PLANE axis's interval value says which axis,
            # as the v6.7.3 house key of G7-T08 does ('ציר $x$ – $10$, ציר
            # $y$ – $2$'); a number line keeps its bare value
            parts.append(u"ציר $%s$ – $%s$" % (
                _ent(ix, args[0]).get("name") or args[0].split(":")[-1],
                v.strip("$")))
        else:
            parts.append(u"%s%s" % (v, u))
    seen = []
    for p in parts:
        if p not in seen or p not in (u"הוכחה", u"בנייה"):
            seen.append(p)
    out = u", ".join(seen)
    # (v6.9 fix r1, N3/P5) an item that says נמקו keeps its "· נימוק" in the
    # key, as the house answer rows of v6.7.3 do (a proof is its own reason)
    txt = LS.rendered.texts.get(it.get("id"), u"")
    if (u"נמקו" in txt or u"הסבירו" in txt) and seen and any(
            p not in (u"הוכחה", u"בנייה", u"נימוק") for p in seen):
        # v6.13 fix_r1 (m2): a coordinate-plane / number-line key writes
        # "0.5, נימוק", as the G7-T01 / G7-T08 originals do; the geometry
        # house key (v6.7.3, G9-T18) keeps " · נימוק"
        from wspec import schema as _S
        fam = any((ix.facts.get(t) or {}).get("rel") in _S.FAMILY_RELS
                  for t in it.get("targets") or [])
        out += u", נימוק" if fam else u" · נימוק"
    return out


# (v6.10) templates whose item asks for a reason: its key line says "נימוק"
_JUSTIFY_TPLS = ("justify_why", "explain_why", "justify_one_sentence")
# (v6.10 fix r1, m1) templates whose key line states the claim itself
_DEDUCE_TPLS = ("deduce_that",)


def _deduce_only(segs, it, ix):
    """a 'הסיקו כי ...' item: every to_prove of the item is printed by a
    deduce_that segment (a mixed 'הוכיחו ... הסיקו ...' item keeps
    'הוכחה', as the v6.7.3 house key does)"""
    ded = set(fid for sg in segs if isinstance(sg, dict) and
              sg.get("tpl") in _DEDUCE_TPLS for fid in sg.get("facts") or [])
    tps = [t for t in it.get("targets") or []
           if (ix.facts.get(t) or {}).get("role") == "to_prove"]
    return bool(tps) and set(tps) <= ded


def _eq_tex(name, v, u):
    """'$DE = 4$ ס״מ' -- the equation as ONE math island (the house key
    form; v6.9 fix r1, P5), the unit outside it."""
    # (v6.10 fix r1, M-2) a root too: ONE island -- '$BC$ = $8\\sqrt{3}$'
    # (two islands) printed right-to-left as '8√3 = BC'
    return u"$%s = %s$%s" % (name, v.strip("$"), u)


# ------------------------------------------------------------ expansion ---
_AUTHOR_KEYS = ("space", "spaces", "didactic", "star", "part", "fig_side",
                "space_q", "dashed", "no_target_reason", "spec_unsupported",
                "aux",
                # v6.13 fix_r1: the author's key line of an item the spec
                # has NO target for (explain / yes-no / which points ...)
                "keys",
                # (v6.16 fix r1, verify S-P6) keep the question on one page
                # (emit_html: an inline break-inside:avoid)
                "keep", "printed_claims", "builder_figures")
_SPEC_OWNS = ("intro", "text", "fig", "items", "given", "to_prove",
              "to_construct", "table", "example")


def _builder_figures_of(value, sq, LS, mark):
    """Preserve an explicitly unsupported item's original builder figure.

    This never replaces an engine figure and never registers the retained
    drawing as a spec figure. Acceptance must still classify its pipeline
    independently. Text and mathematical claims remain owned by the spec.
    """
    if value is None:
        return {}
    if not isinstance(value, dict) or not value or not mark:
        _bad("builder_figures requires a nonempty item mapping and spec_unsupported",
             "retain only original builder figures of explicitly unsupported items")
    items = {it["id"]: it for it in sq.get("items") or []}
    engine_scopes = {f.get("scope") for f in LS.spec.get("figures") or []}
    for iid, svg in value.items():
        if iid not in items or items[iid].get("figure") is not None or iid in engine_scopes:
            _bad("builder figure %r would replace or shadow a spec figure" % iid,
                 "the retained item's source must declare no engine figure")
        if not isinstance(svg, str) or not svg.lstrip().startswith("<svg") or "</svg>" not in svg:
            _bad("builder figure %r is not an SVG" % iid,
                 "pass the original registered builder drawing unchanged")
    return dict(value)


# ------------------------------------------- v6.9 (Codex F4): TEXT_ONLY ----
# A spec question must carry every datum and target ESSENTIAL to it in the
# PUBLIC spec (a typed fact / target Noam AI can read), or the whole
# question is marked spec_unsupported=<reason> by the author (noam-ai.json
# then says so) -- never silently dropped. spec_gaps() names what the sheet
# states / asks that the public spec lacks:
#   NO_TARGET     an item that asks (its task) but has no spec target
#                 (e.g. "which quadrilateral is it": no quadrilateral-type
#                 target exists)
#   EMPTY_TEXT    an item whose generated text is empty
#   VAR_UNDEFINED a variable's value is asked, but no given the item may use
#                 involves the variable (its defining expression, e.g.
#                 AC = 4x + 6, is not in the public spec)
#   PROSE_DATUM   approved prose states a property word (acute, trapezoid,
#                 isosceles ...) that no fact of the scope carries and no
#                 template text of the question prints
#   PROSE_TARGET  approved prose asks (type of / which / compute / prove ...)
#                 for something the item's spec targets do not carry
_GAP_ASK = (u"חשבו", u"מצאו", u"קבעו", u"הוכיחו", u"הראו", u"בנו",
            u"שרטטו", u"האם", u"מהו", u"מהי", u"כמה", u"בדקו", u"הסבירו",
            u"נמקו", u"השלימו", u"סמנו", u"הביעו")
_GAP_TYPE_ASK = (u"סוג", u"איזה", u"איזו")
_GAP_TYPE_RELS = ("rectangle", "square", "parallelogram", "rhombus",
                  "equilateral", "isosceles", "congruent", "classify",
                  "trapezoid", "isosceles_trapezoid", "right_triangle",
                  "acute_triangle", "obtuse_triangle")
# property word (maqaf / hyphen read as a space) -> relations that carry it
_GAP_DATUM = [(u"שווה צלעות", ("equilateral",)),
              (u"שווה שוקיים", ("isosceles",)),
              (u"שווי שוקיים", ("isosceles",)),
              (u"ישר זווית", ("right_triangle",)),
              (u"ישרת זווית", ("right_triangle",)),
              (u"ישרי זווית", ("right_triangle",)),
              (u"חד זוויות", ("acute_triangle",)),
              # (v6.17-noam V1) the sources print "קהה־זוויות" (G7-T14)
              (u"קהה זוויות", ("obtuse_triangle",)),
              (u"קהה זווית", ("obtuse_triangle",)),
              (u"קהת זווית", ("obtuse_triangle",)),
              (u"מלבן", ("rectangle",)), (u"ריבוע", ("square",)),
              (u"מקבילית", ("parallelogram",)), (u"מעוין", ("rhombus",)),
              (u"טרפז", ("trapezoid", "isosceles_trapezoid")),
              (u"דלתון", ()), (u"אמצע", ("midpoint",)),
              (u"מקביל", ("parallel",)), (u"מאונך", ("perpendicular",)),
              (u"חופפ", ("congruent",)), (u"חוצה", ("equal_angle",
                                                     "midpoint")),
              (u"תיכון", ("midpoint",)), (u"גובה", ("perpendicular",)),
              (u"בתוך", ("inside",)), (u"מחוץ", ()),
              (u"גדול", ("greater", "linear")), (u"קטן", ("greater",))]


def _gap_norm(s):
    import unicodedata
    s = u"".join(ch for ch in unicodedata.normalize("NFKD", s or u"")
                 if not (unicodedata.category(ch) == "Mn" and
                         u"\u0591" <= ch <= u"\u05c7"))
    return u" " + re.sub(u"[\u05be\\-\u2010-\u2014]", u" ", s) + u" "


def _vars_of(ix, fact):
    out = set()
    for a in fact.get("args") or []:
        for e in WS.entity_closure(a, ix):
            if (ix.entities.get(e) or {}).get("kind") == "variable":
                out.add(e)
    return out


def spec_gaps(LS, qid):
    """[(scope, code, detail)] -- what question qid's sheet states or asks
    that its PUBLIC spec lacks (see the note above); [] when complete."""
    ix = LS.ix
    sq = ix.questions[qid]
    out = []
    facts = list(ix.facts.values())
    prose_of = {}
    for p in LS.spec.get("prose") or []:
        prose_of.setdefault(p.get("scope"), []).append(p)

    def scope_facts(s):
        return [f for f in facts if f.get("item") == s]

    def tpl_text(s, segs):
        txt = LS.rendered.texts.get(s, u"")
        for seg in segs or []:
            if isinstance(seg, dict) and "prose" in seg:
                p = ix.prose.get(seg["prose"]) or {}
                txt = txt.replace(p.get("text") or u"\x00", u" ", 1)
        return txt
    q_tpl = _gap_norm(tpl_text(qid, sq.get("text")))
    q_rels = set(f.get("rel") for f in scope_facts(qid))
    scopes = [(qid, sq.get("text"), None)] + [
        (it["id"], it.get("text"), it) for it in sq.get("items") or []]
    for sid, segs, it in scopes:
        rels = q_rels | set(f.get("rel") for f in scope_facts(sid))
        tpl = q_tpl + _gap_norm(tpl_text(sid, segs))
        tgt = [ix.facts[t] for t in (it or {}).get("targets") or []
               if t in ix.facts]
        if it is not None:
            from wspec import schema_bound as _SB
            if not LS.rendered.texts.get(sid, u"").strip() and \
                    not (_SB.stem_item(sq) == sid and
                         LS.rendered.texts.get(qid, u"").strip()):
                # (v6.13 fix_r2) a STEM ITEM's task is the stem's sentence
                out.append((sid, "EMPTY_TEXT", "the item's generated text "
                            "is empty: what the sheet asks here is not in "
                            "the public spec"))
            if not tgt and not F616.graph_finds(LS, sid):
                # (v6.16 integrate) a graph find is the item's target (the
                # public graph model carries it, answer-free)
                out.append((sid, "NO_TARGET", "the item (task %s) has no "
                            "target in the public spec: what it asks is not "
                            "a supported target" % it.get("task_type")))
            usable = set()
            for fid in list(it.get("uses") or []) + [
                    f["id"] for f in scope_facts(qid) + scope_facts(sid)]:
                f = ix.facts.get(fid) or {}
                if f.get("role") not in ("target", "answer", "to_prove",
                                         "to_construct"):
                    usable |= _vars_of(ix, f)
            for f in tgt:
                if f.get("rel") == "var_value":
                    for v in _vars_of(ix, f) - usable:
                        out.append((sid, "VAR_UNDEFINED", "the value of %s is "
                                    "asked, but no given of the public spec "
                                    "involves %s (its defining expression "
                                    "is missing)" % ((ix.entities.get(v) or
                                                      {}).get("name", v), v)))
        for p in prose_of.get(sid) or []:
            pt = _gap_norm(p.get("text"))
            for w, rs in _GAP_DATUM:
                if w in pt and w not in tpl and not (set(rs) & rels):
                    out.append((sid, "PROSE_DATUM", u"prose %s states '%s', "
                                "which no fact of the public spec carries"
                                % (p.get("id"), w)))
            if it is None:
                continue
            if any(w in pt for w in _GAP_TYPE_ASK) and not any(
                    f.get("rel") in _GAP_TYPE_RELS for f in tgt):
                out.append((sid, "PROSE_TARGET", u"prose %s asks for a type "
                            "(%s); the public spec has no such target"
                            % (p.get("id"), p.get("text"))))
            elif not tgt and any(u" %s" % w in pt for w in _GAP_ASK):
                out.append((sid, "PROSE_TARGET", u"prose %s asks (%s) with "
                            "no target in the public spec" % (
                                p.get("id"), p.get("text"))))
    seen, uniq = set(), []
    for g in out:
        if g not in seen:
            seen.add(g)
            uniq.append(g)
    return uniq


def _item_id(n, label):
    import deliver as _D
    return _D.item_id(n, label)


def _aux_of(aux, sq, n, qid):
    """(v6.10) the author's aux figures of a spec question: {item id:
    [dict(fig=<a recorded builder figure>, step=u'<the one step>',
    completes=False)]}. The spec has no aux figure of its own (an aux shows
    an object the question does not name), so the aux figure is drawn by a
    recording builder (shapekit / figkit / euclid) exactly as on the
    builder path; an engine SVG is refused (the engine draws only the
    spec)."""
    if aux is None:
        return {}
    iids = [it["id"] for it in sq.get("items") or []]
    if not isinstance(aux, dict):
        _bad("question %s (spec %s): aux=%r" % (n, qid, type(aux).__name__),
             "give aux={'%s': [dict(fig=..., step=u'...')]} -- keyed by the "
             "item the aux figure helps" % (iids[0] if iids else qid + "a"))
    out = {}
    for iid, lst in sorted(aux.items()):
        if iid not in iids:
            _bad("question %s (spec %s): aux names %r, no item of it"
                 % (n, qid, iid), "items: %s" % ", ".join(iids))
        if not isinstance(lst, list) or not lst:
            _bad("question %s: aux[%r] is not a list of aux figures"
                 % (n, iid), "aux={%r: [dict(fig=..., step=...)]}" % iid)
        for a in lst:
            if not isinstance(a, dict) or a.get("fig") is None or \
                    not str(a.get("step") or "").strip():
                _bad("question %s: an aux figure of %s without fig / step"
                     % (n, iid), "dict(fig=<builder figure>, step=u'<the "
                     "one step it shows>', completes=False)")
            figs_ = a.get("fig") if isinstance(a.get("fig"), (list, tuple)) \
                else [a.get("fig")]
            if any(is_spec_svg(x) for x in figs_):
                _bad("question %s: the aux figure of %s is an engine figure"
                     % (n, iid), "the spec has no aux figure; draw the aux "
                     "step with a recording builder (as the builder path "
                     "does)")
            extra = sorted(set(a) - set(["fig", "step", "completes",
                                         "label"]))
            if extra:
                _bad("question %s: aux of %s carries %s" % (n, iid, extra),
                     "an aux figure is dict(fig, step, completes, label)")
        out[iid] = lst
    return out


def _keys_of(keys, sq, n, qid, mark, LS=None):
    """(v6.13 fix_r1) keys={item id: u'<key line>'}: the author's answer-key
    line of an item the public spec has NO target for -- the original
    sheet's own line ('לא, נימוק', '$E$ ו־$G$', 'נימוק'), as the builder
    path writes every key. Only for a target-less item, and only in a
    question marked spec_unsupported (its NO_TARGET gap is then listed in
    noam-ai.json).
    (v6.13 fix_r2, K) An item WITH targets may also key the original line
    when the spec's own row words it differently ('$5$ יחידות' for an
    interval value asked of both axes; '$5$ יחידות, $6 - 1 = 5$' for a
    length and its subtraction): only when EVERY target has a private value
    (an answer value, or the number a plot target marks) and every one of
    those values is a number the line prints -- the original key restates
    the spec's answers, it never replaces them."""
    if keys is None:
        return {}
    if not isinstance(keys, dict) or not keys:
        _bad("question %s (spec %s): keys=%r" % (n, qid, keys),
             "keys={'<item id>': u'<the original key line>'}")
    its = dict((it["id"], it) for it in sq.get("items") or [])
    targetless = False
    for iid, txt in sorted(keys.items()):
        if iid not in its:
            _bad("question %s (spec %s): keys names %r, no item of it"
                 % (n, qid, iid), "items: %s" % ", ".join(sorted(its)))
        if not isinstance(txt, str) or not txt.strip():
            _bad("question %s: keys[%r] is empty" % (n, iid),
                 "write the original key line")
        if LS is not None and not its[iid].get("targets"):
            # Original root keys must be recomputed even when the source
            # item has no typed target and declares spec_unsupported.
            from wspec import equation618 as EQ618
            root_issues = EQ618.key_issues(LS.printed, WS.Index(LS.printed), iid, txt)
            if root_issues:
                _bad("question %s: keys[%r] -- %s" %
                     (n, iid, _issues_text(root_issues)),
                     "bind an exact original root key to its printed equation; unsupported roots cannot bypass verification")
        if its[iid].get("targets"):
            _key_restates(LS, its[iid], txt, n, iid)
        elif LS is not None and F616.graph_finds(LS, iid):
            # (v6.16 integrate) an item whose targets are GRAPH finds: its
            # original key line restates every find's exact answer
            bad = F616.key_problems(LS, its[iid], txt)
            if bad:
                _bad("question %s: keys[%r] -- %s" % (n, iid, "; ".join(
                    bad[:3])), "the original key line of a graph item "
                     "must state every answer of its finds (it never "
                     "replaces one)")
        else:
            targetless = True
    if targetless and mark is None:
        _bad("question %s (spec %s): keys= without spec_unsupported"
             % (n, qid), "an item with no spec target is a NO_TARGET gap: "
             "mark the question spec_unsupported=u'<why>' (noam-ai.json "
             "says so)")
    return dict(keys)


def _key_values(LS, tid):
    """(v6.13 fix_r2) the private value a key line must restate for target
    tid: its answer's value, or the value of the number a plot marks; None
    when the target has none (a construction, a plotted point)."""
    ix = LS.ix
    a = LS.answers.get(tid) or {}
    if a.get("value") is not None:
        return a["value"]
    f = ix.facts.get(tid) or {}
    if f.get("rel") == "plot" and f.get("args"):
        e = ix.entities.get(f["args"][0]) or {}
        if e.get("kind") == "number":
            return e.get("value")
    return None


def _plot_point_key_ok(LS, tf, txt, qid, iid):
    """A point-plot key must restate its named, ordered GIVEN pair.

    This route does not turn a plot into a private coordinate target.
    Both givens must be printed in this item or its own question stem;
    no earlier/later item, layout placement or private answer is read.
    """
    from wspec import schema_bound as _SB
    if tf.get("rel") != "plot" or not tf.get("args"):
        return False
    p = tf["args"][0]
    if LS.ix.kind(p) != "point":
        return False
    printed = set()
    for sid in (qid, iid):
        printed.update(G614.printed_facts(LS.text_segs.get(sid)))
    xy = {}
    for f in LS.ix.facts.values():
        if (f.get("role") == "given" and f.get("rel") == "coordinate"
                and f.get("item") in (qid, iid) and f.get("id") in printed
                and (f.get("args") or [None])[0] == p):
            axis = f["args"][1]
            val = _SB.value_of(f.get("value"))
            if axis in xy and xy[axis] != val:
                return False
            xy[axis] = val
    if set(xy) != {"axis:x", "axis:y"}:
        return False
    at = _SB.atoms(txt)
    name = _ent(LS.ix, p).get("name") or p
    # This narrow extension accepts just the named pair, not a correct
    # option mixed with a contradictory pair or a negation of it.
    plain = _SB.atoms_plain(txt)[0]
    pairs = _SB.coord_pairs(txt)
    if len(pairs) != 1 or len(at) != 3:
        return False
    for xi, yi, ni in _SB.coord_pairs(txt):
        if ni is None or at[ni][1] != name:
            continue
        compact = re.sub(r"\s+", "", plain).rstrip(".;")
        if compact != "%s(%s,%s)" % (name, at[xi][1], at[yi][1]):
            return False
        try:
            pair = (_SB.atom_value(*at[xi]), _SB.atom_value(*at[yi]))
        except Exception:                         # noqa: BLE001
            continue
        if pair == (xy["axis:x"], xy["axis:y"]):
            return True
    return False


def _transform_key_ok(LS, it, txt):
    """C1 overrides are a closed list of ordered pairs, never a number bag.

    Retain the declared result order and point names (anonymous results
    stay anonymous). Only separators may surround the pairs; explanatory
    prose belongs in the source task, not this narrow override grammar.
    """
    from wspec import point_transform as PT, schema_bound as SB

    def pairs(text):
        plain, spans = SB.atoms_plain(text)
        atoms = SB.atoms(text)
        got, ranges = [], []
        for xi, yi, ni in SB.coord_pairs(text):
            if atoms[xi][0] != "number" or atoms[yi][0] != "number":
                return None
            try:
                xy = (SB.atom_value(*atoms[xi]), SB.atom_value(*atoms[yi]))
            except (ValueError, TypeError, ZeroDivisionError):
                return None
            name = atoms[ni][1] if ni is not None else None
            got.append((name, xy))
            start = spans[ni][2] if ni is not None else len(plain[:spans[xi][2]].rstrip())-1
            end = spans[yi][3]
            end += len(plain[end:])-len(plain[end:].lstrip())+1  # closing ')'
            ranges.append((start, end))
        rest = plain
        for start, end in reversed(ranges):
            rest = rest[:start] + rest[end:]
        if not got or not re.fullmatch(r"[\s,;:.·ו־]*", rest):
            return None
        return got

    want = pairs(", ".join(PT.answer_pairs(LS.spec, it, LS.ix)))
    return want is not None and pairs(txt) == want


def _key_restates(LS, it, txt, n, iid):
    from wspec import schema_bound as _SB
    if LS is None:
        _bad("question %s: keys[%r] -- the item has spec targets" % (n, iid),
             "an item with a target keys from the spec's private part")
    if it.get("transforms") and not _transform_key_ok(LS, it, txt):
        _bad("question %s: keys[%r] -- TRANSFORM_KEY_PAIR_MISMATCH" % (n, iid),
             "restate the exact ordered coordinate pairs in source result order; "
             "keep named points named and anonymous results unnamed, with no extra pair")
    got = []
    spellings = {}
    for k, tok in _SB.atoms(txt):
        if k == "number":
            try:
                value = _SB.atom_value(k, tok)
                got.append(value)
                spellings.setdefault(value, []).append(tok)
            except Exception:                         # noqa: BLE001
                pass
    for tid in it.get("targets") or []:
        v = _key_values(LS, tid)
        if v is None and ((LS.ix.facts.get(tid) or {}).get("rel") ==
                          "construct_pie"):
            # (v6.16 fix r1, D-BUILD) a build-a-pie construction has NO
            # value (pie.PIE_VALUE_FORBIDDEN): there is nothing the line
            # could restate or replace, and the source's key line holds the
            # construction data ("the angles live in the key only",
            # BRIEF_V616) -- it keys the item as written
            continue
        tf = LS.ix.facts.get(tid) or {}
        if v is None and tf.get("role") == "to_prove":
            # A proof has no private numeric answer to replace. Other
            # numerical targets in the same item are still checked below.
            continue
        if v is None and tf.get("rel") == "construct" and tf.get("role") == "to_construct":
            from wspec import printed_claims as PC
            declaration = next((q.get("printed_claims") for q in LS.printed.get("questions", [])
                                if q.get("id") == "q%s" % n), None) or {}
            target_entity = (tf.get("args") or [None])[0]
            if declaration.get("unsupported") and any(PC.selects(c, target_entity, LS.ix.entities.get(target_entity, {}))
                    for c in (declaration.get("scopes", {}).get(iid) or {}).get("to_construct") or []):
                # An open construction has no unique coordinate answer.
                # Preserve the original private example/key only when its
                # public target is explicitly source-backed and unsupported.
                continue
        if v is None and _plot_point_key_ok(LS, tf, txt, "q%s" % n, iid):
            continue
        if v is None and tf.get("rel") == "plot" and \
                LS.ix.kind((tf.get("args") or [None])[0]) == "polygon":
            # (v6.16 gaps r2, K3 of t08_c) "סרטטו את המצולע" (the G5
            # to_plot of a polygon) has NO value: the line restates nothing
            # and replaces nothing but the house word 'סימון בשרטוט' -- the
            # source's own key line ('שרטוט') keys the item as written
            continue
        if v is None:
            _bad("question %s: keys[%r] -- target %s has no private value "
                 "the line could restate" % (n, iid, tid),
                 "an item whose target has no value keys from the spec's "
                 "private part (wspec_build.answer_text)")
        want = _SB.value_of(v)
        if want not in got:
            _bad("question %s: keys[%r] = %r does not state the answer %s "
                 "of %s" % (n, iid, txt, v, tid),
                 "the original key line of an item with a target must "
                 "restate every answer of the spec (it never replaces one)")
        if WC.is_irrational(v):
            # V617-Q6: a source key cannot bypass the grade's answer form.
            # Compare the exact-value atom, never rewrite surrounding prose.
            form = WC.answer_surd_plain(v, LS.spec.get("sheet"))
            norm = lambda t: t.replace(" ", "").replace("-", u"−").lstrip("+")
            if any(norm(t) != norm(form) for t in spellings.get(want, [])):
                _bad("question %s: keys[%r] -- ANSWER_SURD_FORM: expected %s"
                     % (n, iid, form), "use the author-approved root form "
                     "for this grade, while keeping the exact value")
            a = LS.answers.get(tid) or {}
            if a.get("approx") in WC.APPROX_DECIMALS and _SB.value_of(
                    WC.approx_text(v, a["approx"])) not in got:
                _bad("question %s: keys[%r] -- ANSWER_APPROX_MISSING" % (n, iid),
                     "the original key must include the exact value and "
                     "the question's required rounding")


def _printed_givens(LS, scope, segs, have):
    """(v6.14 F3) the scope's printed scale (a context fact the stem prints)
    and quoted calculations as structured givens (givens614); then every
    given that links facts is checked to restate only what the scope
    prints (never a target: W-META-LINES-3) -- a fault refuses the build."""
    try:
        new = G614.scale_givens(LS.ix, segs, scope, _num, WC.canon_unit) + \
            G614.calc_givens(segs)
    except G614.GivenError as e:
        _bad("%s: %s" % (scope, e), "state the scale with its unit (a "
             "scale fact value=..., unit='m') so Noam AI reads it")
    have_t = set(c.get("text") for c in have if isinstance(c, dict))
    new = [c for c in new if c.get("text") not in have_t]
    bad = G614.given_source_faults(LS.ix, scope, segs, list(have) + new)
    if bad:
        _bad("; ".join(bad[:4]), "a given restates a given / context fact "
             "the question PRINTS; a target or a conclusion is never a "
             "given")
    return new


def _claim_excerpt(text):
    """Only harmless display normalization; never parse/rewrite meaning."""
    if not isinstance(text, str):
        return ""
    return " ".join(text.replace("$", "").split()).strip()


def _apply_printed_claims(out, authored, LS, qid, keys=None):
    """Keep explicit public descriptions when a spec migration is partial.

    printed_claims={scope: {'given': [{'text': <printed excerpt>}],
      'to_construct': [{'point': 'B', 'text': <excerpt>,
                        'printed_in': <own question or item>}]}}

    Text may be a list of excerpts, joined by a semicolon. Every excerpt
    must already appear in that scope's rendered text. Givens append only
    text rows. Construction descriptions replace the text of an existing
    typed point or polygon target. Unnamed plot groups require actual
    undrawn observations in the item's figure or its inherited head figure.
    A targetless, spec_unsupported item's to_prove may also preserve a
    numeric find: {'what': <printed excerpt>, 'unit': <printed word>}.
    Its private value comes only from keys=: the unique numeric atom by
    default, a declared numeric atom index, or the original complete key
    for an open/text answer. Public declarations accept no answer value.
    The regular leak checks still run.
    These ordinary content claims still pass all deliver/Noam validators.
    This deliberately does not claim to add typed WSPEC relations.
    """
    if authored is None:
        return
    declared = next(x for x in LS.printed["questions"] if x["id"] == qid).get("printed_claims")
    if not declared or declared.get("scopes") != authored:
        _bad("%s claims differ from the serialized source" % qid,
             "declare metadata through LevelSpec.question before building")
    if not isinstance(authored, dict) or not authored:
        _bad("%s printed_claims is not a nonempty mapping" % qid,
             "declare only exact excerpts from this question's text")
    sq = LS.ix.questions[qid]
    its = sq.get("items") or []
    scopes = {qid: out}
    scopes.update((it["id"], d) for it, d in zip(its, out.get("items") or []))
    if any(it.get("label") == "" for it in its):
        _bad("%s printed_claims on a stem-only item" % qid,
             "keep the ordinary spec claims for a stem-only item")
    for scope, groups in authored.items():
        if scope not in scopes or not isinstance(groups, dict) or not groups:
            _bad("%s printed_claims names invalid scope %r" % (qid, scope),
                 "use this question id or one of its item ids")
        for role, claims in groups.items():
            if role not in ("given", "to_construct", "to_prove") or not isinstance(claims, list):
                _bad("%s printed_claims role %r is unsupported" % (scope, role),
                     "given excerpts or existing point construction descriptions only")
            if role == "to_prove" and scopes[scope].get("to_prove") and not all(c.get("supplemental") is True for c in claims):
                _bad("%s already has typed proof/find claims" % scope,
                     "retain the native spec query instead of adding an unsupported one")
            for claim in claims:
                allowed = ({"text", "axis_start"} if role == "given" else
                           {"what", "unit", "quantity", "of", "key_text", "key_number", "key_pair", "supplemental"} if role == "to_prove" else
                           {"point", "points", "polygon_entity", "data_points", "text", "printed_in"})
                if not isinstance(claim, dict) or set(claim) - allowed:
                    _bad("%s printed_claims has non-description fields" % scope,
                         "no values, answers, relations or drawing overrides")
                source = claim.get("printed_in", scope)
                if source not in ({scope} if role == "given" else {qid, scope}):
                    _bad("%s printed_claims reads another scope %r" % (scope, source),
                         "a description uses only its item or owning question")
                excerpts = claim.get("what") if role == "to_prove" else claim.get("text")
                excerpts = excerpts if isinstance(excerpts, list) else [excerpts]
                excerpts = [_claim_excerpt(t) for t in excerpts]
                shown = _claim_excerpt(LS.rendered.texts.get(source, ""))
                from wspec import printed_claims as PC
                derived_axis = role == "given" and "axis_start" in claim and excerpts == [PC.axis_start_text(claim, LS.printed.get("figures", []), scope)]
                if not derived_axis and (not excerpts or any(not t or t not in shown for t in excerpts)):
                    _bad("%s printed_claims contains text absent from %s" % (scope, source),
                         "copy exact printed excerpts; private answers cannot be inserted")
                text = "; ".join(excerpts)
                row = scopes[scope]
                if role == "to_prove":
                    # A single original numeric key is the only private
                    # source here. No answer value can be authored in the
                    # overlay; the typed spec still honestly reports its gap.
                    from wspec import schema_bound as _SB
                    sit = next((i for i in its if i["id"] == scope), {})
                    key = (keys or {}).get(scope)
                    typed = [LS.ix.facts[t] for t in sit.get("targets") or []]
                    if (not sit or (any(t.get("role") != "to_construct" for t in typed) and claim.get("supplemental") is not True) or not out.get("spec_unsupported")
                            or not isinstance(key, str)):
                        _bad("%s printed find is not a targetless keyed item" % scope,
                             "use typed spec targets whenever they exist")
                    nums = [tok for kind, tok in _SB.atoms(key) if kind == "number"]
                    if "key_number" in claim and claim["key_number"] >= len(nums):
                        _bad("%s query selects a missing private numeric atom" % scope,
                             "key_number must refer to the unchanged original key")
                    if not claim.get("key_text") and "key_number" not in claim and "key_pair" not in claim and (len(nums) != 1 or _SB.coord_pairs(key)):
                        _bad("%s printed find has no unique numeric key" % scope,
                             "the preserved original key must contain one numeric answer")
                    unit = claim.get("unit")
                    if unit is not None and not PC.query_unit_allowed(unit, shown, LS.rendered.texts.get(qid, ""), LS.printed.get("figures", []), scopes):
                        _bad("%s printed find unit is absent from its query" % scope,
                             "use the unit word printed by the item")
                    from wspec import printed_claims as PC
                    if "key_pair" in claim:
                        pairs, atoms = _SB.coord_pairs(key), _SB.atoms(key)
                        if claim["key_pair"] >= len(pairs):
                            _bad("%s query selects a missing private pair" % scope, "use a pair in the unchanged original key")
                        xi, yi, ni = pairs[claim["key_pair"]]
                        if ni is not None and claim.get("of") != atoms[ni][1]:
                            _bad("%s query selects another point's private pair" % scope, "match the query's point to its keyed pair")
                        value = "(%g, %g)" % tuple(float(_SB.atom_value(*atoms[k])) for k in (xi, yi))
                    else:
                        value = key if claim.get("key_text") else _num(_SB.atom_value("number", nums[claim.get("key_number", 0)]))
                    target = PC.query_claim(claim)
                    target["value"] = value
                    row.setdefault("to_prove", []).append(target)
                elif role == "given":
                    if not any(isinstance(c, dict) and c.get("text") == text
                               for c in row.get("given") or []):
                        row.setdefault("given", []).append({"text": text})
                else:
                    from wspec import printed_claims as PC
                    if "data_points" in claim:
                        row.setdefault("to_construct", []).append(PC.construction_claim(claim))
                        continue
                    if "points" in claim or "polygon_entity" in claim:
                        matches = [c for c in row.get("to_construct") or []
                                   if isinstance(c, dict) and c.get("type") == "polygon"
                                   and (c.get("points") == claim["points"] if "points" in claim else not c.get("points"))]
                        if len(matches) != 1:
                            _bad("%s has no unique declared polygon construction" % scope,
                                 "first declare the item's polygon construction target")
                        matches[0]["text"] = text
                        continue
                    point = claim.get("point")
                    from wspec import schema_bound as _SB
                    named = PC.names(text)
                    if point not in named:
                        _bad("%s construction description does not name %r" % (scope, point),
                             "preserve the printed clause that names the target point")
                    matches = [c for c in row.get("to_construct") or []
                               if isinstance(c, dict) and c.get("type") == "point"
                               and c.get("point") == point]
                    if not isinstance(point, str) or len(matches) != 1:
                        _bad("%s has no unique point construction %r" % (scope, point),
                             "first declare the item's typed coordinate or plot target")
                    matches[0]["text"] = text


def expand_question(q):
    """(the question as an ordinary content dict, {fid: FigRec}, answer
    row)."""
    ref = q["spec"]
    if not isinstance(ref, QuestionRef):
        _bad("question %s: spec=%r is not a LevelSpec question"
             % (q.get("n"), ref),
             "write spec questions as LS.question('q1', ...) of a "
             "wspec_build.LevelSpec")
    LS, qid = ref.level, ref.qid
    ix = LS.ix
    sq = ix.questions[qid]
    n = sq.get("n")
    # (v6.17 FIX, S2) a question put on the SHEET never prints an area /
    # perimeter target without its word ("חשבו את $\tri ABC$." for "חשבו את
    # שטח המשולש"; the approved 'compute' line does that). Read here, where a
    # question is printed, not when a level spec loads: older test fixtures
    # carry such a question they never print (fixtures/wspec_g9t18a_
    # q1q4q9.json q4ד)
    qw = [i for i in WT.quantity_word_issues(LS.printed, tset())
          if str(i.where).split(" ")[-1] in [qid] + [
              it.get("id") for it in sq.get("items") or []]]
    if qw:
        _bad("question %s (spec %s) prints an area / perimeter question "
             "without its word: %s" % (n, qid, _issues_text(qw)),
             "print the original wording as bound prose (\"חשבו את שטח "
             "המשולש.\") or a template that says שטח / היקף (the approved "
             "'compute' line does not; PENDING_V617 item 7)")
    if q.get("n") not in (None, n):
        _bad("question n=%s names spec question %s (n=%s)"
             % (q.get("n"), qid, n), "leave n to the spec")
    own = [k for k in _SPEC_OWNS if q.get(k) is not None]
    if own:
        _bad("question %s (spec %s) also writes %s" % (n, qid, own),
             "a spec question takes its text, figures, items, givens and "
             "targets from the spec; only %s are the author's"
             % ", ".join(_AUTHOR_KEYS))
    unknown = [k for k in q if k not in _AUTHOR_KEYS + ("n", "spec")]
    if unknown:
        _bad("question %s (spec %s) carries %s" % (n, qid, unknown),
             "a spec question takes only %s beside spec=" %
             ", ".join(_AUTHOR_KEYS))
    gaps = spec_gaps(LS, qid)
    mark = q.get("spec_unsupported")
    if mark is not None and not str(mark).strip():
        _bad("question %s (spec %s): spec_unsupported is empty" % (n, qid),
             "say in words why the public spec cannot carry the question "
             "(Noam AI reads it), or drop the mark")
    if gaps and mark is None:
        _bad("question %s (spec %s): the sheet states / asks what the public "
             "spec lacks (TEXT_ONLY) -- %s" % (n, qid, "; ".join(
                 "%s %s: %s" % g for g in gaps[:6])),
             "put every essential datum / target in the spec as a typed "
             "fact / target, or mark the WHOLE question: LS.question(%r, "
             "spec_unsupported=u'<why>') -- noam-ai.json then marks it "
             "spec-unsupported with that reason (never silently dropped)"
             % qid)
    aux = _aux_of(q.get("aux"), sq, n, qid)
    keys = _keys_of(q.get("keys"), sq, n, qid, mark, LS)
    builder_figures = _builder_figures_of(q.get("builder_figures"), sq, LS, mark)
    space = q.get("space", DEFAULT_SPACE)
    spaces = dict(q.get("spaces") or {})
    didactic = dict(q.get("didactic") or {})
    out = dict((k, q[k]) for k in ("star", "part", "fig_side", "dashed",
                                   "keep",
                                   "no_target_reason") if k in q)
    out["n"] = n
    if mark is not None:
        out["spec_unsupported"] = {"reason": str(mark).strip(),
                                   "missing": ["%s %s: %s" % g
                                               for g in gaps]}
    out["intro"] = LS.rendered.texts.get(qid, u"")
    if u"\n" in out["intro"]:
        # (v6.13 fix_r2) the connector "\n" breaks the stem into lines, as
        # the builder's intro list prints them (one paragraph per line)
        out["intro"] = [ln for ln in out["intro"].split(u"\n")]
    # (v6.13, W-BOUND-PROSE) the spec question's table (cells: bound blocks
    # or blanks) and worked example (bound prose) print on the sheet in the
    # emitter's form; both come from the spec only (_SPEC_OWNS)
    if qid in LS.rendered.tables:
        out["table"] = LS.rendered.tables[qid]
    if qid in LS.rendered.examples:
        out["example"] = LS.rendered.examples[qid]
    figs = {}
    head = sq.get("figure")
    if head is not None:
        if head != "q%s_head" % n:
            _bad("question %s: its figure is %r" % (qid, head),
                 "the head figure of question n is named q<n>_head "
                 "(deliver names figures by position: q%s_head)" % n)
        rec = LS.figure(head, qid, None)
        out["fig"] = rec["svg"]
        figs[head] = rec
    if didactic.get(qid):
        out["didactic"] = didactic[qid]
    facts = sorted(ix.facts.values(), key=lambda f: f["id"])

    def in_text_order(scope, segs):
        """the scope's facts in the order its text prints them, then the
        rest by id"""
        first = {}
        for seg in segs or []:
            for fid in (seg.get("facts") or []) if isinstance(seg, dict) \
                    else []:
                first.setdefault(fid, len(first))
        mine = [f for f in facts if f.get("item") == scope]
        return sorted(mine, key=lambda f: (first.get(f["id"], 10 ** 6),
                                           f["id"]))
    out["given"] = [claim_of(LS, f) for f in in_text_order(
        qid, LS.text_segs.get(qid, sq.get("text")))
                    if f.get("role") == "given"]
    # (v6.14 F3) the printed scale of the stem / a quoted calculation:
    # structured givens linked to their facts, checked against the text
    out["given"] += _printed_givens(LS, qid, LS.text_segs.get(
        qid, sq.get("text")), out["given"])
    out["to_prove"] = []
    items, arow = [], []
    from wspec import schema_bound as _SB
    stem_iid = _SB.stem_item(sq)
    for it in sq.get("items") or []:
        iid, lab = it["id"], it["label"]
        if _item_id(n, lab) != iid:
            _bad("item %s of question %s has label %r" % (iid, n, lab),
                 "an item id is q<n> + the latin letter of its label "
                 "(%s)" % _item_id(n, lab))
        d = {"label": lab, "text": LS.rendered.texts.get(iid, u""),
             "space": spaces.get(iid, space)}
        fid = it.get("figure")
        if fid is not None and fid != head:
            if fid != iid:
                _bad("item %s shows figure %r" % (iid, fid),
                     "an item shows its question's head figure or its own "
                     "figure, named by the item id (%s)" % iid)
            rec = LS.figure(fid, qid, iid)
            w = rec["placements"]["canvas_px"][0]
            if w > ITEM_FIG_MAX:
                _bad("item figure %s is %.0f px wide (grown: %s)"
                     % (fid, w, rec["placements"].get("grown")),
                     "an item figure is at most %.0f px (emit_plus): the "
                     "engine grows a figure whose labels have no room -- "
                     "give it margin=16 (the display settings' smallest) "
                     "or another width, and check canvas_px" % ITEM_FIG_MAX)
            d["fig"] = rec["svg"]
            figs[fid] = rec
        if iid in builder_figures:
            d["fig"] = builder_figures[iid]
        given = []
        for f in in_text_order(iid, LS.text_segs.get(iid, it.get("text"))):
            if f.get("role") != "given":
                continue
            c = claim_of(LS, f)
            fi = _released_from(LS, f)
            if fi and _carried_given(ix, f, fi):
                # (v6.10 fix r1, L1) a given an earlier item STATED and this
                # item uses again without printing it (author.
                # carried_given): Noam AI reads where it was given, as the
                # v6.7.3 builder did ("∡OAB = 20° (נתון בסעיף ג)"); no
                # from_item (that marks a PROVED claim carried on)
                c["text"] = u"%s (נתון בסעיף %s)" % (
                    c.get("text") or u"", ix.items[fi].get("label"))
            elif fi:
                c["from_item"] = fi
            given.append(c)
        given += _printed_givens(LS, iid, LS.text_segs.get(
            iid, it.get("text")), given)
        d["given"] = given
        tp, tc, var = [], [], []
        for tid in it.get("targets") or []:
            f = ix.facts[tid]
            c = claim_of(LS, f)
            # v6.13 integ (t01_b): a point / number the student PLOTS is a
            # construction of the row, as the builder writes it (G7-T08
            # 'סמנו את הנקודה' -> to_construct), never a claim to prove
            if f.get("role") in ("to_construct", "to_plot"):
                tc.append(c)
            else:
                tp.append(c)
            if f.get("rel") == "var_value":
                var.append(_ent(ix, f["args"][0]).get("name"))
        # (v6.16 fix r1, K1 = T08B-D10; the t08_b skillfix, proven there:
        # v616/work_t08_b/skillfix_wspec_build.diff) a POINT whose
        # coordinates the item asks and that no figure of the question
        # shows (the G1 partial polygon's missing vertex, b q10 D; c q4 M,
        # c q5 C / D) is what the student FINDS: the row declares it
        # to_construct, as the builder form did (new_pt) -- so deliver s8,
        # check_didactic D8 and selfcheck_noam_package K6 read the text's
        # name of it as made by the task, not as undrawn
        _shown = set()
        for _g in LS.spec.get("figures") or []:
            if _g.get("scope") == qid or str(_g.get("scope") or "") in set(
                    x["id"] for x in sq.get("items") or []):
                _shown.update(_g.get("entities") or [])
        _made = set(c.get("point") for c in tc if isinstance(c, dict))
        for tid in it.get("targets") or []:
            f = ix.facts[tid]
            _p = (f.get("args") or [None])[0]
            if (f.get("rel") == "coordinate" and
                    ix.kind(_p) == "point" and _p not in _shown):
                _nm = _ent(ix, _p).get("name") or _p
                if _nm not in _made:
                    _made.add(_nm)
                    tc.append({"type": "point", "point": _nm,
                               "text": u"הנקודה %s" % _nm})
        # (v6.16 integrate) the item's GRAPH finds are its targets too: a
        # metadata row each (wspec_fam616.find_claims); their key line is
        # the source's (keys=), checked to restate every exact answer
        gfinds = F616.graph_finds(LS, iid)
        if gfinds:
            tp = tp + F616.find_claims(LS, iid)
            if iid not in keys:
                _bad("item %s asks graph finds %s but has no key line"
                     % (iid, [r.get("id") for _g, r, _t in gfinds]),
                     "write the source's key line: keys={%r: u'...'} (the "
                     "build checks it states every find's answer)" % iid)
        d["to_prove"] = tp
        # (v6.14 fix_r1, W-META-LINES-3) a target line that links its fact
        # restates the target THIS item's text asks -- never a given, an
        # answer or another item's target
        bad = G614.target_source_faults(ix, iid, LS.text_segs.get(
            iid, it.get("text")), tp)
        if bad:
            _bad("; ".join(bad[:4]), "a W-META-LINES-3 target line restates "
                 "the target its own item prints, linked to that fact")
        # (v6.10 integrate) an unnamed construction (cline) the item's text
        # mentions ("הדרכה: העבירו דרך P ישר מקביל ל־AD") is what the
        # student draws: the item declares it to_construct, as the builder
        # form did ({'type': 'line', 'of': ['P'], 'parallel_to': 'AD'})
        tc += cline_constructs(LS, iid, it, tc)
        if tc:
            d["to_construct"] = tc
        if var:
            d["variables"] = var
        if didactic.get(iid):
            d["didactic"] = didactic[iid]
        if aux.get(iid):
            # (v6.10) an aux figure (שרטוט עזר) of a spec item: shown on
            # request, one step -- the same {fig, step, completes} the
            # builder items carry; deliver makes it a visual_model aux
            # patch on the item's engine figure
            d["aux"] = [dict(a) for a in aux[iid]]
        if iid in keys and not it.get("targets") and not gfinds:
            # (v6.13 fix_r1) the item states why it has no find target:
            # the question's spec_unsupported reason (noam-ai.json row)
            d["no_target_reason"] = str(mark).strip()
        if iid == stem_iid:
            # (v6.13 fix_r2, NOITEM) the STEM ITEM: no row of its own -- the
            # question's sentence states its task (as the builder's items=[]
            # question): its claims, didactic data and writing space are the
            # question's, its key row has no label
            if "fig" in d:
                _bad("question %s: its stem item %s has a figure of its own"
                     % (n, iid), "a stem item shows the question's head "
                     "figure only (or none)")
            for k in ("given", "to_prove", "to_construct"):
                if d.get(k):
                    out[k] = list(out.get(k) or []) + list(d[k])
            for k in ("didactic", "no_target_reason", "variables"):
                if d.get(k):
                    out[k] = d[k]
            out["space"] = d["space"]
            arow.append(("", keys[iid] if iid in keys else
                         answer_text(LS, it)))
            continue
        items.append(d)
        arow.append((lab, keys[iid] if iid in keys else
                     answer_text(LS, it)))
    out["items"] = items
    _apply_printed_claims(out, q.get("printed_claims"), LS, qid, keys)
    out["_wspec"] = {"qid": qid, "level": LS}
    # (v6.10 fix r2, N2) a challenge question keeps its ★ in the answer key
    # too ('(14) ★'), as the builder rows and v6.7.3 print it
    return out, figs, ((n, arow, True) if q.get("star") else (n, arow))


def expand_level(L):
    """The level with every spec question expanded; the SAME object when no
    question carries a spec (the builder path is untouched)."""
    if not has_spec(L) or L.get("_wspec_expanded"):
        return L
    # the house gates ride along with figkit_plus (G76-G78 install on its
    # import); a spec level may import no builder, so it is imported HERE,
    # before any emitter runs -- installing it inside build_html (whose G77
    # reads the author's level through a temporary patch) would wrap the
    # patch instead of the gate
    import figkit_plus                     # noqa: F401
    L2 = dict(L)
    qs, figs, rows = [], {}, []
    own = dict((str(r[0]), r) for r in L.get("answers") or []
               if isinstance(r, (list, tuple)) and r)
    order = []
    for q in L.get("questions") or []:
        if isinstance(q, dict) and q.get("spec") is not None:
            eq, qf, arow = expand_question(q)
            if str(eq["n"]) in own:
                _bad("answers= of the level writes question %s, a spec "
                     "question" % eq["n"],
                     "the answer key of a spec question is written from the "
                     "spec's private part; drop its row from answers=")
            dup = set(qf) & set(figs)
            if dup:
                _bad("figure(s) %s appear twice" % sorted(dup),
                     "one figure id per figure")
            qs.append(eq)
            figs.update(qf)
            rows.append(arow)
            order.append(str(eq["n"]))
        else:
            qs.append(q)
            if isinstance(q, dict):
                order.append(str(q.get("n")))
    ans = []
    have = dict((str(r[0]), r) for r in rows)
    for k in order:
        if k in have:
            ans.append(have[k])
        elif k in own:
            ans.append(own[k])
    for k, r in own.items():
        if k not in order:
            ans.append(r)
    L2["questions"] = qs
    L2["answers"] = ans
    L2["_wspec_expanded"] = True
    L2["_wspec_figs"] = figs
    return L2


def spec_figs(L):
    return (L or {}).get("_wspec_figs") or {}


# ------------------------------------------------ the sheet.json entry ----
_NUMR = re.compile(r"-?\d*\.?\d+(?:[eE][-+]?\d+)?")
_EL = re.compile(r"<(line|circle|path|polyline|polygon|text)\b([^>]*?)/?>"
                 r"(?:([^<]*)</text>)?", re.S)
_ATTR = re.compile(r'([\w:-]+)="([^"]*)"')


def svg_elements(svg):
    """{element id: (tag, attrs, text)} of an engine SVG; a label's text in
    LOGICAL order (wspec-svg/5 stores a Hebrew label in visual order under
    the bidi override)."""
    from wspec import bidi as BIDI
    out = {}
    for m in _EL.finditer(svg):
        a = dict(_ATTR.findall(m.group(2)))
        if a.get("id"):
            t = (m.group(3) or "").strip()
            if BIDI.is_override(a):
                t = BIDI.logical(t)
            out[a["id"]] = (m.group(1), a, t)
    return out


def _pts_of(tag, a):
    f = lambda k: float(a.get(k, 0))                       # noqa: E731
    if tag == "line":
        return [(f("x1"), f("y1")), (f("x2"), f("y2"))]
    if tag == "circle":
        return [(f("cx"), f("cy"))]
    if tag in ("polyline", "polygon"):
        v = [float(x) for x in _NUMR.findall(a.get("points", ""))]
        return list(zip(v[0::2], v[1::2]))
    if tag == "path":
        v = [float(x) for x in _NUMR.findall(a.get("d", ""))]
        return list(zip(v[0::2], v[1::2]))
    if tag == "text":
        return [(f("x"), f("y"))]
    return []


def _r2(p):
    return [round(float(p[0]), 2), round(float(p[1]), 2)]


class _Frame(object):
    def __init__(self, rec):
        pl = rec["placements"]
        m = pl["model_to_svg"]["matrix"]
        self.a, self.d, self.e, self.f = float(m[0]), float(m[3]), \
            float(m[4]), float(m[5])
        self.px = dict((k, tuple(v)) for k, v in pl["points_px"].items())
        self.W, self.H = pl["canvas_px"]
        ix = rec["level"].ix
        self.named_lines = {ix.entities[eid]["name"]: ix.entities[eid]["through"]
                            for eid in rec["object_map"].get("objects", {})
                            if ix.kind(eid) == "line" and ix.entities[eid].get("name")}

    def xy(self, p):
        return [round((p[0] - self.e) / self.a, 6),
                round((p[1] - self.f) / self.d, 6)]

    def view(self):
        return {"width_px": float(self.W), "height_px": float(self.H),
                "unit_px": 1.0, "viewbox": [float(self.W), float(self.H)],
                "rotate": 0.0,
                "data_to_svg": [self.a, 0.0, 0.0, self.d, self.e, self.f],
                "data_unit_px": [abs(self.a), abs(self.d)]}


def _near(p, q, tol=0.6):
    return math.hypot(p[0] - q[0], p[1] - q[1]) <= tol


def _item_by_el(omap):
    by = {}
    for it in omap.get("display_items") or []:
        for el in it.get("elements") or []:
            by[el] = it
    return by


def figure_entry(rec, rows=None):
    """The sheet.json entry of one engine figure, in the schema every
    checker of the skill reads: objects by bucket (svg_id = the engine's
    element id), constraints from the spec's facts (source given /
    to_prove / derived, marked with the marks the engine drew for them),
    view from the placement. rows: {row id: {'given': [...], 'to_prove':
    [...]}} of the question / items the figure serves (their claims)."""
    if F616.family_of_rec(rec):
        # (v6.16 integrate) a graph / pie figure (wspec_fam616)
        return F616.figure_entry(rec)
    LS = rec["level"]
    ix = LS.ix
    om = rec["object_map"]
    fr = _Frame(rec)
    els = svg_elements(rec["svg"])
    items = om.get("display_items") or []
    objs = om.get("objects") or {}
    fig = [g for g in LS.spec.get("figures") or []
           if g.get("id") == rec["fid"]][0]
    from wspec import sheet_locus as SL
    locus_objects = SL.objects(LS.pub, rec["fid"])
    polys = [ix.entities[e]["vertices"] for e in objs
             if (ix.entities.get(e) or {}).get("kind") == "polygon"]
    vertices = set(v for p in polys for v in p)
    sides = set()
    for p in polys:
        for i in range(len(p)):
            sides.add(frozenset((p[i], p[(i + 1) % len(p)])))
    out = {"points": [], "segments": [], "lines": [], "rays": [],
           "polygons": [], "arcs": [], "marks": [], "labels": []}
    # points and their names
    for eid, o in sorted(objs.items()):
        if o["kind"] == "data_point":
            from wspec import sheet_data as SD
            record = SD.objects(LS.pub, rec["fid"])[eid]
            series = next(s for s in fig["data"]["series"] if s["id"] == record["series"])
            if o.get("parts") and eid in fr.px:
                out["points"].append({"svg_id": o["parts"][0]["element"],
                    "kind": "point", "role": "data", "series": record["series"],
                    "marker": series["marker"], "xy": fr.xy(fr.px[eid]),
                    "svg_xy": _r2(fr.px[eid])})
            continue
        if o["kind"] != "point":
            continue
        dot = [p["element"] for p in o["parts"]
               if els.get(p["element"], ("",))[0] == "circle"]
        if not dot or eid not in fr.px:
            continue
        name = ix.entities[eid].get("name", eid)
        sxy = list(fr.px[eid])
        out["points"].append({
            "svg_id": dot[0], "kind": "point",
            "role": "vertex" if eid in vertices else "point", "name": name,
            "xy": fr.xy(sxy), "svg_xy": _r2(sxy)})
        example = next((r for r in locus_objects.values() if r["point"] == eid and r["example"]), None)
        if example:
            variable = ix.entities[example["variable"]]["name"]
            out["points"][-1]["legend"] = "מיקום לדוגמה של %s (%s אינו נתון)" % (name, variable)
    # segments / lines / rays / polygons with an element of their own
    seg_names = {}
    for eid, o in sorted(objs.items()):
        k = o["kind"]
        e = ix.entities.get(eid) or locus_objects.get(eid)
        if e is None or k not in ("segment", "line", "ray", "polygon"):
            # v6.13 integ (D3): a family engine's map also holds objects
            # that are no entity -- a coordinate plane's reading guide
            # (keyed by its fact), a number line's span / jump -- which
            # have no segment / line / polygon export here
            continue
        lines = [p for p in o["parts"]
                 if els.get(p["element"], ("",))[0] in ("line", "polygon")]
        if k == "segment":
            if len(lines) != 1 or lines[0]["span"] != "whole":
                continue
            a, b = e["ends"]
            if a not in fr.px or b not in fr.px:
                continue
            el = els[lines[0]["element"]]
            pts = _pts_of(el[0], el[1])
            A, B = fr.px[a], fr.px[b]
            if not ((_near(pts[0], A) and _near(pts[-1], B)) or
                    (_near(pts[0], B) and _near(pts[-1], A))):
                continue          # a longer element: not this segment alone
            nm = a + b
            seg_names[eid] = (nm, lines[0]["element"])
            out["segments"].append({
                "svg_id": lines[0]["element"], "kind": "segment",
                "role": "edge" if frozenset((a, b)) in sides else "data",
                "name": nm, "xy": [fr.xy(A), fr.xy(B)],
                "svg_xy": [_r2(A), _r2(B)]})
        elif k in ("line", "ray") and lines:
            el = els[lines[0]["element"]]
            pts = _pts_of(el[0], el[1])
            nm = eid.split(":", 1)[1] if e.get("locus") else (e.get("name") or "".join(e["through"])) if k == "line" else \
                e["from"] + e["through"]
            out[k + "s"].append({
                "svg_id": lines[0]["element"], "kind": k, "role": "data",
                "name": nm, "xy": [fr.xy(p) for p in pts],
                "svg_xy": [_r2(p) for p in pts]})
        elif k == "polygon":
            poly = [p for p in o["parts"]
                    if els.get(p["element"], ("",))[0] == "polygon"]
            if len(poly) == 1:
                vs = e["vertices"]
                out["polygons"].append({
                    "svg_id": poly[0]["element"], "kind": "polygon",
                    "role": "data", "name": "".join(vs),
                    "xy": [fr.xy(fr.px[v]) for v in vs],
                    "svg_xy": [_r2(fr.px[v]) for v in vs]})
    # marks, arcs and labels, from the display items
    mark_of_fact = {}
    arc_n = {}
    mroles = _mark_roles(rec)
    for it in items:
        role = it["role"]
        if role == "tick" and "tick" not in mroles:
            continue          # v6.13 integ: an axis tick of a number line
        src = it.get("source") or {}
        ent = src.get("entity")
        fct = src.get("fact")
        for el in it.get("elements") or []:
            tag, a, text = els.get(el, (None, {}, ""))
            if tag is None:
                continue
            pts = _pts_of(tag, a)
            if role == "angle_arc":
                ang = ix.entities[ent]
                mid = pts[len(pts) // 2]
                cls = (a.get("data-mark") or "arc").split(" ")[0]
                n_ = int(cls[3:] or 1) if cls.startswith("arc") else 1
                arc_n[el] = n_
                out["arcs"].append({
                    "svg_id": el, "kind": "arc", "role": "mark",
                    "name": ang["vertex"], "xy": fr.xy(mid),
                    "svg_xy": _r2(mid), "ink_xy": _r2(mid), "n": n_})
            elif role == "right_mark":
                ang = ix.entities[ent]
                V = fr.px[ang["vertex"]]
                corner = pts[1] if len(pts) == 3 else pts[0]
                out["marks"].append({
                    "svg_id": el, "kind": "right_angle", "role": "mark",
                    "name": ang["vertex"], "xy": fr.xy(V),
                    "svg_xy": _r2(V), "ink_xy": _r2(corner)})
            elif role in ("tick", "parallel_arrow"):
                mid = pts[len(pts) // 2] if role == "parallel_arrow" else \
                    ((pts[0][0] + pts[-1][0]) / 2.0,
                     (pts[0][1] + pts[-1][1]) / 2.0)
                nm = _seg_name(ix, ent) if ent else None
                out["marks"].append({
                    "svg_id": el,
                    "kind": "ticks" if role == "tick" else "parallel",
                    "role": "mark", "name": nm,
                    "xy": [fr.xy(p) for p in pts],
                    "svg_xy": [_r2(p) for p in pts], "ink_xy": _r2(mid)})
            elif role in ("point_name", "line_name", "angle_caption", "segment_caption"):
                P = pts[0]
                lab = {"svg_id": el, "kind": "label", "text": text,
                       "xy": fr.xy(P), "svg_xy": _r2(P)}
                if role == "point_name":
                    lab.update(role="vertex" if ent in vertices else "point",
                               name=ent, **{"for": ent})
                elif role == "line_name":
                    lab.update(role="data", name=ix.entities[ent]["name"],
                               **{"for": ix.entities[ent]["name"]})
                elif role == "angle_caption":
                    # `for` names the angle's vertex, a point object of the
                    # figure (the builder's convention for a value at a
                    # vertex); the caption's own angle is its name
                    ang = ix.entities[ent]
                    lab.update(role="value", name=ang["arms"][0] +
                               ang["vertex"] + ang["arms"][1],
                               **{"for": ang["vertex"]})
                else:
                    nm = seg_names.get(ent, (None,))[0] or \
                        _seg_name(ix, ent)
                    lab.update(role="value", name=nm,
                               **{"for": seg_names.get(ent, (nm,))[0]})
                out["labels"].append(lab)
            if fct and role in ("angle_arc", "right_mark", "tick",
                                "parallel_arrow", "angle_caption",
                                "segment_caption"):
                mark_of_fact.setdefault(fct, []).append(el)
    out = dict((k, v) for k, v in out.items() if v)
    from wspec import base_height as BH
    hidden = BH.unnamed(ix, rec["fid"])
    if hidden:
        native_refs = {o.get("name"): o.get("svg_id") for o in out["segments"] if o.get("name")}
        for label in out["labels"]:
            if hidden.intersection(_split(label.get("for", ""))):
                label["for"] = native_refs[label["for"]]
    cons = _constraints(rec, fr, mark_of_fact, seg_names, fig, rows)
    return {"kind": "wspec", "fam": "wspec", "view": fr.view(),
            "objects": out, "constraints": cons}


def _measure_ok(c, fr, LS):
    """Is the constraint true on the drawn points (1 px / 0.6 deg)?"""
    P = fr.px

    def pt(n):
        return P[n]

    def seg(s):
        if isinstance(s, str):
            # Printed names identify actual geometric lines; their public
            # metadata keeps a/b, while measurement uses declared anchors.
            s = fr.named_lines.get(s) or _split(s)
        return pt(s[0]), pt(s[1])

    def ang3(v, a, b):
        d1 = math.atan2(a[1] - v[1], a[0] - v[0])
        d2 = math.atan2(b[1] - v[1], b[0] - v[0])
        x = abs(math.degrees(d1 - d2)) % 360.0
        return 360.0 - x if x > 180.0 else x

    def dirang(s1, s2):
        (a, b), (c_, d) = s1, s2
        u = (b[0] - a[0], b[1] - a[1])
        w = (d[0] - c_[0], d[1] - c_[1])
        cs = (u[0] * w[0] + u[1] * w[1]) / (math.hypot(*u) * math.hypot(*w))
        return math.degrees(math.acos(max(-1.0, min(1.0, cs))))
    t = c["type"]
    try:
        if t == "angle":
            return abs(ang3(pt(c["at"]), pt(c["rays"][0]),
                            pt(c["rays"][1])) - float(c["value"])) <= 0.5
        if t == "length":
            a, b = seg(c["of"])
            L = math.hypot(a[0] - b[0], a[1] - b[1]) / abs(fr.a)
            v = float(c["value"])
            return abs(L - v) <= max(0.005 * v, 0.02)
        if t == "on_segment":
            a, b = seg(c["of"])
            p = pt(c["point"])
            vx, vy = b[0] - a[0], b[1] - a[1]
            L2 = vx * vx + vy * vy
            tt = ((p[0] - a[0]) * vx + (p[1] - a[1]) * vy) / L2
            d = math.hypot(p[0] - a[0] - tt * vx, p[1] - a[1] - tt * vy)
            return -1e-6 <= tt <= 1 + 1e-6 and d <= 0.6
        if t == "midpoint":
            a, b = seg(c["of"])
            p = pt(c["point"])
            return _near(p, ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2))
        if t == "equal_length":
            L = [math.hypot(*(lambda s: (s[1][0] - s[0][0],
                                         s[1][1] - s[0][1]))(seg(x)))
                 for x in c["of"]]
            return max(L) - min(L) <= max(0.005 * max(L), 0.5)
        if t == "equal_angle":
            xs = [x if isinstance(x, dict) else
                  {"at": _split(x)[1], "rays": [_split(x)[0], _split(x)[2]]}
                  for x in c["of"]]
            v = [ang3(pt(x["at"]), pt(x["rays"][0]), pt(x["rays"][1]))
                 for x in xs]
            return max(v) - min(v) <= 0.5
        if t == "parallel":
            a = dirang(seg(c["of"][0]), seg(c["of"][1]))
            return min(a, 180 - a) <= 0.5
        if t == "perpendicular":
            return abs(dirang(seg(c["of"][0]), seg(c["of"][1])) - 90) <= 0.5
        if t == "ratio":
            s = [seg(x) for x in c["of"]]
            L = [math.hypot(q[1][0] - q[0][0], q[1][1] - q[0][1]) for q in s]
            return abs(L[0] / L[1] - float(c["value"])) <= 0.01 * max(
                1.0, abs(float(c["value"])))
    except (KeyError, TypeError, ValueError, ZeroDivisionError, IndexError):
        return False
    return False


def _split(s):
    t = re.findall(u"[A-Z][′″']*[0-9]?", str(s))
    return t


_EXPORT_TYPES = ("angle", "length", "on_segment", "midpoint", "equal_length",
                 "equal_angle", "parallel", "perpendicular", "ratio")


def _fields(c):
    return dict((k, v) for k, v in c.items()
                if k in ("of", "point", "points", "at", "rays", "value",
                         "unit"))


def _constraints(rec, fr, mark_of_fact, seg_names, fig, rows):
    """The figure's constraints from the spec: every fact the figure draws
    (marked, with the marks the engine drew for it), every given of its
    question / items it shows (measured true on the drawing), every
    to_prove relation that is measurable on it (unmarked), and the right
    angles the engine marks for a rectangle / square (derived, marked)."""
    LS = rec["level"]
    ix = LS.ix
    qid = rec["question"]
    scopes = [qid] + [it["id"] for it in (ix.questions[qid].get("items")
                                          or [])]
    if rec.get("item"):
        scopes = scopes[:scopes.index(rec["item"]) + 1]
    out, seen = [], {}
    draws = list(fig.get("draws") or [])

    def add(c, source, item, marks=None, fact=None):
        if c.get("type") not in _EXPORT_TYPES:
            return
        if any(p not in fr.px for p in _names_in(c)):
            return
        if not _measure_ok(c, fr, LS):
            return
        d = {"type": c["type"]}
        d.update(_fields(c))
        if d["type"] == "equal_angle":
            d["of"] = [x if isinstance(x, dict) else
                       {"at": _split(x)[1], "rays": [_split(x)[0],
                                                    _split(x)[2]]}
                       for x in d["of"]]
        if d["type"] == "angle":
            d["unit"] = "deg"
            d["value"] = float(d["value"])
        from wspec import base_height as BH
        source_text = BH.description(fact, ix) if fact is not None else None
        if source_text:
            d["text"] = source_text  # private geometry stays typed and remeasurable
        key = json.dumps(dict((k, v) for k, v in d.items()
                              if k not in ("unit",)), sort_keys=True,
                         ensure_ascii=False)
        if key in seen:
            prev = seen[key]
            if marks and not prev.get("marked"):
                prev["marked"] = True
                prev["mark_id"] = marks[0]
                prev["mark_ids"] = list(marks)
            return
        d["source"] = source
        d["item"] = item
        if marks:
            d["marked"] = True
            d["mark_id"] = marks[0]
            d["mark_ids"] = list(marks)
        seen[key] = d
        out.append(d)
    facts = sorted(ix.facts.values(), key=lambda f: f["id"])
    for fid in draws:
        f = ix.facts.get(fid) or {}
        if f.get("role") != "given":
            continue
        c = _claim_core(LS, f, technical=True)
        marks = [m for m in mark_of_fact.get(fid, [])]
        item = f.get("item") if f.get("item") != qid else None
        add(c, "given", item, marks or None, fact=f)
    # the right angles a shape fact marks (rectangle / square corners)
    for fid in draws:
        f = ix.facts.get(fid) or {}
        if f.get("rel") not in ("rectangle", "square"):
            continue
        for el in mark_of_fact.get(fid, []):
            it = _item_by_el(rec["object_map"]).get(el) or {}
            ent = (it.get("source") or {}).get("entity")
            e = ix.entities.get(ent) or {}
            if e.get("kind") != "angle":
                continue
            c = {"type": "angle", "at": e["vertex"], "rays": list(e["arms"]),
                 "value": 90}
            add(c, "derived", None, [el])
    # the parallel arrows a shape fact draws (parallelogram / rhombus): one
    # arrow class per pair of opposite sides -> a parallel, derived from
    # the given shape, marked with the arrows of both sides
    els = svg_elements(rec["svg"])
    for fid in draws:
        f = ix.facts.get(fid) or {}
        if f.get("rel") not in ("parallelogram", "rhombus"):
            continue
        cls = {}
        for it in rec["object_map"].get("display_items") or []:
            src = it.get("source") or {}
            if it["role"] != "parallel_arrow" or src.get("fact") != fid:
                continue
            for el in it["elements"]:
                mk = (els.get(el, (None, {}, ""))[1].get("data-mark") or
                      "par").split(" ")[0]
                cls.setdefault(mk, {}).setdefault(src.get("entity"),
                                                  []).append(el)
        for mk, by_seg in sorted(cls.items()):
            if len(by_seg) != 2:
                continue
            sids = sorted(by_seg)
            c = {"type": "parallel", "of": [_seg_name(ix, x) for x in sids]}
            add(c, "derived", None, [e for x in sids for e in by_seg[x]])
    for f in facts:
        if f.get("item") not in scopes or f.get("role") != "given":
            continue
        c = _claim_core(LS, f, technical=True)
        item = f.get("item") if f.get("item") != qid else None
        add(c, "given", item, fact=f)
    if fig.get("figure_accuracy") == "accurate":
        for f in facts:
            if f.get("item") not in scopes or f.get("role") != "to_prove":
                continue
            c = claim_of(LS, f)
            add(c, "to_prove", f.get("item"))
    # a mark the engine drew for a fact that no constraint names: refuse
    named = set(m for c in out for m in (c.get("mark_ids") or []))
    for it in rec["object_map"].get("display_items") or []:
        if it["role"] not in _mark_roles(rec):
            continue
        for el in it["elements"]:
            if el not in named:
                _bad("figure %s: the engine drew a %s (%s, for %s) that no "
                     "exported constraint names" % (
                         rec["fid"], it["role"], el,
                         (it.get("source") or {}).get("fact")),
                     "a mark states a given fact the export can carry "
                     "(angle, length, equal_length, equal_angle, parallel, "
                     "perpendicular, midpoint); report this figure")
    return out


def _names_in(c):
    out = []
    for k in ("point", "at"):
        if c.get(k):
            out.append(c[k])
    for r in c.get("rays") or []:
        out.append(r)
    of = c.get("of")
    for x in (of if isinstance(of, list) else [of] if of else []):
        if isinstance(x, dict):
            out += [x["at"]] + list(x["rays"])
        else:
            out += _split(x)
    for p in c.get("points") or []:
        out.append(p)
    return out


# ------------------------------------------------ the visual model layer --
def entity_parts(rec):
    """{entity id: [{'svg_id', 'span'}]} of the engine's object map."""
    out = {}
    for eid, o in (rec["object_map"].get("objects") or {}).items():
        out[eid] = [dict({"svg_id": p["element"]},
                         **({"span": list(p["span"])}
                            if p.get("span") not in (None, "whole") else {}))
                    for p in o["parts"]]
    return out


def vm_engine_layer(vm, rec, entry):
    """The visual_model of an engine figure speaks the engine's ids: an
    object the export carries on the element that draws an entity (a
    point's dot, a segment's own line, a polygon outline) takes the entity
    id (A, seg:AB, poly:ABCD) and its parts; every other entity the figure
    shows (an angle, a polygon drawn by its sides, a segment that is a
    piece of a longer line) is added with svg_id null and its parts. The
    relations name objects by these ids."""
    if F616.family_of_rec(rec):
        # (v6.16 integrate) a graph / pie figure: the engine's objects
        return F616.vm_layer(vm, rec, entry)
    ix = rec["level"].ix
    parts = entity_parts(rec)
    fr = _Frame(rec)
    principal = {}
    # (v6.16 gaps) the element that DRAWS the entity: a point's dot, a
    # segment's / line's / ray's own line, a polygon's outline -- by its
    # tag, so that a polygon drawn by its sides, or a partial polygon (G1)
    # whose first part is a vertex's dot, never takes over the element of
    # a point / segment (it is added below with svg_id null)
    own_tag = {"point": "circle", "segment": "line", "line": "line",
               "ray": "line", "polygon": "polygon"}
    tags = svg_elements(rec["svg"])
    from wspec import sheet_data as SD
    data_objects = SD.objects(rec["level"].pub, rec["fid"])
    from wspec import sheet_locus as SL
    locus_objects = SL.objects(rec["level"].pub, rec["fid"])
    for eid, ps in parts.items():
        k = (ix.entities.get(eid) or locus_objects.get(eid) or {}).get("kind")
        if eid in data_objects and data_objects[eid]["kind"] == "data_point" and ps:
            principal[ps[0]["svg_id"]] = eid
        if k in own_tag and ps and "span" not in ps[0] and \
                (tags.get(ps[0]["svg_id"]) or ("",))[0] == own_tag[k]:
            principal[ps[0]["svg_id"]] = eid
    rename = {}
    have = set()
    for o in vm.get("objects") or []:
        sid = o.get("svg_id")
        eid = principal.get(sid)
        if eid is None or o.get("display") != "initial":
            continue
        if o.get("type") == "label":
            continue
        want_kind = "point" if (data_objects.get(eid) or {}).get("kind") == "data_point" else (ix.entities.get(eid) or locus_objects.get(eid) or {}).get("kind")
        if o.get("type") != want_kind:
            continue
        rename[o["id"]] = eid
        o["id"] = eid
        o["parts"] = parts[eid]
        have.add(eid)
    segs, angs, polys, named_lines = {}, {}, {}, {}
    for eid in parts:
        e = ix.entities.get(eid) or {}
        if e.get("kind") == "line" and e.get("name"):
            named_lines[e["name"]] = eid
        if e.get("kind") == "segment":
            segs[frozenset(e["ends"])] = eid
        elif e.get("kind") == "angle":
            angs[(e["vertex"], frozenset(e["arms"]))] = eid
        elif e.get("kind") == "polygon":
            polys[frozenset(e["vertices"])] = eid

    def ents_of(r):
        """the engine objects a relation is ABOUT (its angle, its segments,
        its polygon), before the points it names"""
        out = []
        t = r.get("type")
        of = r.get("of")
        lst = of if isinstance(of, list) else ([of] if of else [])
        if t == "angle" and r.get("at"):
            out.append(angs.get((r["at"], frozenset(r.get("rays") or []))))
        for x in lst:
            if isinstance(x, dict):
                out.append(angs.get((x.get("at"),
                                     frozenset(x.get("rays") or []))))
            elif isinstance(x, str) and x in named_lines:
                out.append(named_lines[x])
            elif t == "equal_angle" and len(_split(x)) == 3:
                a, v, b = _split(x)
                out.append(angs.get((v, frozenset((a, b)))))
            elif len(_split(x)) == 2:
                out.append(segs.get(frozenset(_split(x))))
        if t == "shape" and r.get("points"):
            out.append(polys.get(frozenset(r["points"])))
        return [x for x in out if x]
    # (v6.10 integrate) an aux patch built on this model (visual_model.
    # aux_patch -> engine_aux_match) shows model objects by their ids: the
    # same rename
    for a in vm.get("aux") or []:
        for op in a.get("ops") or []:
            if op.get("op") == "show":
                op["ids"] = [rename.get(x, x) for x in op.get("ids") or []]
    for r in vm.get("relations") or []:
        if r.get("objects") or r.get("type"):
            obs = [rename.get(x, x) for x in r.get("objects") or []]
            r["objects"] = [x for x in ents_of(r) if x not in obs] + obs
    gids = set(x for r in vm.get("relations") or []
               if r.get("role") == "given" for x in r.get("objects") or [])
    used = set(x for r in vm.get("relations") or []
               for x in r.get("objects") or [])
    for eid in sorted(parts):
        if eid in have:
            continue
        if eid in locus_objects:
            # Its exact dashed stroke was exported above as a line object.
            # Refuse an unbound line rather than creating a metadata anchor.
            _bad("locus %s has no principal exported stroke" % eid,
                 "a source-bound locus must export its actual native line")
        if eid in data_objects:
            record = data_objects[eid]
            d = {"id": eid, "svg_id": None, "type": record["kind"],
                 "parts": parts[eid], "role": "context", "display": "initial"}
            if record.get("label"):
                d["text"] = record["label"]
            if record["kind"] == "data_series":
                d.update(series=record["series"], marker=record["marker"])
            vm["objects"].append(d)
            continue
        e = ix.entities.get(eid) or {}
        k = e.get("kind")
        if k == "angle" and eid not in used and _zero_angle(e, fr):
            # (v6.9 fix r1, C4) a 0-degree angle (both arms one ray: H on
            # CA makes ACH = ACA) highlights one line and no sector -- not
            # offered to Noam AI unless a relation names it
            continue
        d = {"id": eid, "svg_id": None, "type": k,
             "name": WT.entity_name(eid, ix), "parts": parts[eid],
             "role": "given" if eid in gids else "context",
             "display": "initial"}
        if k == "segment" and all(p in fr.px for p in e["ends"]):
            d["name"] = "".join(e["ends"])
            d["xy"] = [fr.xy(fr.px[p]) for p in e["ends"]]
            d["svg_xy"] = [_r2(fr.px[p]) for p in e["ends"]]
        elif k == "polygon":
            # (v6.16 gaps r2, G5) a tagged polygon's name is its noun, never
            # its vertex ids joined
            d["name"] = WT.entity_name(eid, ix) if e.get("tag") is not None \
                else "".join(e["vertices"])
            # (v6.16 gaps, corpus-v2 G1) a PARTIAL polygon: the figure shows
            # only these vertices (the others are an answer / not drawn);
            # its highlight paints exactly that part (C1r2 _u_partial)
            if any(v not in fr.px for v in e["vertices"]):
                d["shown"] = [v for v in e["vertices"] if v in fr.px]
        elif k == "angle":
            d["name"] = e["arms"][0] + e["vertex"] + e["arms"][1]
        if k == "point":
            continue          # every drawn point has its dot object
        vm["objects"].append(d)
    from wspec import base_height as BH
    hidden = BH.unnamed(ix, rec["fid"])
    safe_lines = {BH.description(f, ix) for f in ix.facts.values() if f.get("role") == "given" and BH.description(f, ix)} if hidden else set()
    for relation in vm.get("relations") or []:
        if relation.get("text") in safe_lines:
            for key in ("of", "point", "points", "at", "rays", "value", "unit"):
                relation.pop(key, None)
            relation["type"] = "statement"
    for obj in vm.get("objects") or []:
        if hidden.intersection(_split(obj.get("name", ""))):
            obj.pop("name", None)
        if obj.get("id") in hidden:
            obj["part"] = "anchor"

    return vm


def _zero_angle(e, fr):
    v, arms = e.get("vertex"), e.get("arms") or []
    if len(arms) != 2 or not all(p in fr.px for p in [v] + list(arms)):
        return False
    V = fr.px[v]
    a, b = fr.px[arms[0]], fr.px[arms[1]]
    ua = (a[0] - V[0], a[1] - V[1])
    ub = (b[0] - V[0], b[1] - V[1])
    na, nb = math.hypot(*ua), math.hypot(*ub)
    if na < 1e-9 or nb < 1e-9:
        return True
    c = (ua[0] * ub[0] + ua[1] * ub[1]) / (na * nb)
    # (v6.10 fix r1, S2) a STRAIGHT angle (180 deg: A-M-B collinear, the
    # entity ang:AMB of another question of the same level spec) has no
    # sector either -- one line, no focus arc; not offered unless a
    # relation of this figure names it
    return abs(c) > math.cos(math.radians(0.5))


# ---------------------------------------------------------- the files -----
LEVEL_SPEC_REL = "source/level_spec.json"     # (v6.10 fix r1) the built spec


def level_spec_bytes(LS):
    """The spec the build used (text layer applied: what the sheet prints),
    with its display settings -- private (answers), like the rest of
    source/. wspec.project.public_model of its "spec" is byte-for-byte
    the delivered wspec/public_spec.json (verify_export W1)."""
    return (json.dumps({"name": LS.name, "spec": LS.printed,
                        "display": LS.display,
                        "public_model": {"mode": "sheet"}},
                       ensure_ascii=False,
                       indent=1, sort_keys=True) + "\n")


def public_spec_bytes(LS):
    return (json.dumps(LS.pub, ensure_ascii=False, indent=1,
                       sort_keys=True) + "\n")


_SCRIPT = u'''# -*- coding: utf-8 -*-
# %(fid)s -- the code that drew this figure (wspec engine %(engine)s).
# Written by deliver.py from the build itself (skill %(skill)s).
# kind: wspec.render   figure: %(fid)s   public spec: ../%(spec)s
# RUNNABLE: running this file re-draws figures/%(fid)s.svg byte for byte
# (checked when the package was written): `python3 %(fid)s.py > %(fid)s.svg`.
# It reads the PUBLIC spec only; the renderer refuses a private model.
import json
import os
import sys
_HERE = os.path.dirname(os.path.abspath(globals().get("__file__", ".")))
SKILL = os.environ.get("WORKSHEET_SKILL_DIR") or next((p for p in (
    os.path.join(_HERE, "..", "skill"), os.path.join(_HERE, "..", "..",
                                                      "skill"),
    os.path.expanduser("~/.claude/skills/hebrew-math-worksheet-v5"))
    if os.path.isdir(os.path.join(p, "wspec"))), None)
if not SKILL:
    raise SystemExit("set WORKSHEET_SKILL_DIR to the folder of the "
                     "hebrew-math-worksheet skill")
sys.path.insert(0, SKILL)
from wspec import render as R
SETTINGS = json.loads(%(settings)r)
with open(os.path.join(_HERE, "..", %(spec)r), encoding="utf-8") as fh:
    PUBLIC = json.load(fh)
out = R.render(PUBLIC, SETTINGS, %(engine)r)
sys.stdout.buffer.write(out["svg"].encode("utf-8"))
'''


def figure_script(rec, skill_version):
    return _SCRIPT % {"fid": rec["fid"], "engine": WR.ENGINE_VERSION,
                      "skill": skill_version, "spec": PUBLIC_SPEC_REL,
                      "settings": json.dumps(rec["settings"],
                                             ensure_ascii=False,
                                             sort_keys=True)}


def map_bytes(rec):
    return WR.dumps(rec["object_map"])


def script_redraws(py_path, svg_file):
    """Run figures/<id>.py in a FRESH process (the skill on
    WORKSHEET_SKILL_DIR) and compare its output with the SVG bytes."""
    import subprocess
    env = dict(os.environ, WORKSHEET_SKILL_DIR=HERE)
    try:
        r = subprocess.run([sys.executable, py_path],
                           cwd=os.path.dirname(py_path), env=env,
                           capture_output=True, timeout=300)
    except subprocess.TimeoutExpired:
        return False
    return r.returncode == 0 and r.stdout == svg_file.encode("utf-8")
