# -*- coding: utf-8 -*-
u"""catalog_build — v7.2.0. Write out/catalog/<sheet_id>/catalog-entry.json: the public index card of one sheet.

    import catalog_build
    catalog_build.build(pkg_dir, out_dir)          # -> Path of catalog-entry.json
    python3 catalog_build.py --pkg DIR [--out DIR] [--deliver DIR]
    python3 catalog_build.py --synthetic G7-ANG-01 --out DIR   # a planned sheet, from the registry (tests)
    python3 catalog_build.py --selftest

WHY
---
The website finds sheets by topic title only, inside one grade, and has no slot
for subtopics, aliases or per-question ids (website.md §1, §5a). A v7.2 sheet is
cut into sections, one per curriculum subtopic, so the useful unit for a teacher
is "section s4 of G7-ANG-02", not "the angles sheet". This file is that unit,
written once per build, from three sources only:

  SHEET       the package's sections manifest (sheet_meta.SHEET, via pkgload)
  registry    curriculum_tashpaz.json "subtopics" (titles, aliases) and
              glossary_he.json (search_variants of the terms a subtopic introduces)
  deliver     out/deliver/<k>/noam-ai.json (question and item ids — the
              whitelist-built public file, never sheet.json answers) and
              build.json (page count only)

Section question numbers come from SHEET, level question/item ids from what was
printed. They are NOT reconciled here on purpose: when the manifest lies about
the printed sheet (fixtures NEGATIVE.md N7, N8) the entry must carry the lie so
that G89 (selfcheck_catalog) can catch it. The entry holds no answers, hints,
solutions, file paths, hashes, timestamps or e-mails (G89 scans for them).

SCHEMA "noam-catalog-entry/v1" (whitelist; the authoritative copy is
selfcheck_catalog.ENTRY_REQUIRED / LEVEL_FIELDS / SECTION_REQUIRED, imported here)
  schema            "noam-catalog-entry/v1"
  sheet_id          SHEET.sheet_id, e.g. "G7-ANG-02"
  package           SHEET.package (engine PACKAGE, e.g. "G7-T12")
  grade, track, topic_id, scope     as in SHEET ("7", "ז", "angles", "sectioned")
  title             == SHEET.title
  title_search      catalog_search.search_key(title): niqqud, final letters, maqaf folded
  levels            {a|b|c: {name: "רמה א׳"|"רמה ב׳"|"מצוינות",
                             question_ids: ["q1", ...], item_ids: ["q1a", ...], pages: int}}
  sections          [{id, subtopic (null for combo), kind "subtopic"|"combo", title,
                      anchor (stable slug from the subtopic id: st.g7.angles.vertical →
                              "angles-vertical"; the same subtopic in a second section →
                              "angles-vertical-2"; combo → "<topic>-combo", then "-2" …),
                      aliases (registry aliases + glossary search_variants of the terms
                               the subtopic introduces), search_variants (generated:
                               ktiv male/haser, with/without ה־, singular/plural, 3/שלוש,
                               maqaf/space — never repeating an alias). Both come from
                               catalog_search.aliases_for / search_variants_for, and G89
                               recomputes them: they must be exactly the registry's.
                      question_ids {a|b|c: ["q<n>", ...]}, combines (combo only)}]
  subtopic_ids      the section subtopics, in order
  replaces          SHEET.replaces (legacy site topics this sheet supersedes)
  landing_slug      SHEET.landing.slug
  skill_version, engine_version
  synthetic         (optional, true) a planned sheet generated from the registry; G89
                    fails it unless explicitly allowed — tests only

MAPPING TO THE SITE LATER (website.md §1, §5b; nothing on the site is touched now)
  grade                  → teacher-catalog grades[].grade (int(grade)); catalog.v1 grade
  title                  → topics[].title (the only string teacher search sees);
                           SheetEntry.title = "<title> · <levelLabel>"
  levels.<k>.name        → SheetEntry.levelLabel (site legacy rows say "רמת מצוינות",
                           edition rows "מצוינות"; AGENTS.md: never "רמה ג׳")
  levels.<k>             → SheetEntry.level a/b/c; manifest levelCode A/B/E (site_level_code)
  item_ids "q4b"         → teacher key ex:<pdfId>:"4ב" (site_item_key); manifest id
                           "<prefix>-<A|B|E>-Q04ב" (site_manifest_id)
  sections[].anchor      → landing page "#<anchor>"
  aliases/search_variants→ catalog searchTerms (student search); the teacher search
                           needs a code change to read them (website.md §1c)
  subtopic_ids           → no slot today (catalog `parent` children, or new fields)
  replaces               → which legacy topic (noamTopicId / prefix) to retire or redirect
  landing_slug           → src/data/topic-pages/<slug>.json + TopicPage slug
  pdf ids / hashes       → NOT here: they exist only after the Wix upload (two-phase).

REGISTRY ACCESS. SK/subtopics.py (written in parallel) is used when importable and
its get()/entries()/load_glossary() answer sanely; otherwise a tiny private
fallback reads curriculum_tashpaz.json["subtopics"] and glossary_he.json directly.
`Registry().source` says which one was used.
"""
import argparse
import json
import re
import sys
import time
from pathlib import Path

SK = Path(__file__).resolve().parent
if str(SK) not in sys.path:
    sys.path.insert(0, str(SK))

import catalog_search as CS  # noqa: E402
import selfcheck_catalog as G89  # noqa: E402

SCHEMA = G89.SCHEMA
LEVEL_KEYS = ("a", "b", "c")
LEVEL_NAMES = dict(G89.LEVEL_NAMES)
SKILL_VERSION = "7.2.0-noam"
ENGINE_VERSION = "6.18-noam"
try:  # keep one source of truth when the driver is importable
    from build_v72 import SKILL_VERSION, ENGINE_VERSION  # noqa: E402,F401
except Exception:
    pass

_HEB = u"אבגדהוזחטיכלמנסעפצקרשת"   # deliver.item_id's tables
_LAT = "abcdefghijklmnopqrstuvwx"
SITE_LEVEL_CODE = {"a": "A", "b": "B", "c": "E"}


class LegacyPackageError(ValueError):
    """Raised for a package without SHEET: catalog/landing exist only for sectioned sheets."""


# ---------------------------------------------------------------- registry ----
class Registry(object):
    """Subtopic registry + glossary. Prefers subtopics.py; falls back to the JSON files.

    The fallback is deliberately tiny (read two JSON files, index by id) so that it
    cannot grow into a second implementation of subtopics.py.
    """

    def __init__(self, skill_dir=None):
        self.skill = Path(skill_dir) if skill_dir else SK
        self.source = "fallback-json"
        self._mod = None
        self._json = None
        self._gloss = None
        try:
            import subtopics as S  # lazily; another module owns it
            if callable(getattr(S, "get", None)) and callable(getattr(S, "load_glossary", None)):
                self._mod = S
                self.source = "subtopics.py"
        except Exception:
            self._mod = None

    def _reg(self):
        if self._json is None:
            with open(self.skill / "curriculum_tashpaz.json", encoding="utf-8") as fh:
                self._json = json.load(fh).get("subtopics", {})
        return self._json

    def located(self):
        """[(track, topic_id, entry)] in file order — enumeration always reads the JSON."""
        out = []
        for track, topics in self._reg().get("by_track", {}).items():
            for topic, ents in topics.items():
                for e in ents:
                    out.append((track, topic, e))
        return out

    def get(self, sid):
        if self._mod is not None:
            try:
                e = self._mod.get(sid)
                if isinstance(e, dict) and e.get("id") == sid:
                    return e
            except Exception:
                pass
            self.source = "fallback-json"
            self._mod = None
        for _t, _p, e in self.located():
            if e.get("id") == sid:
                return e
        return None

    def glossary(self):
        if self._gloss is None:
            g = None
            if self._mod is not None:
                try:
                    g = self._mod.load_glossary()
                except Exception:
                    g = None
            if not (isinstance(g, dict) and "terms" in g):
                with open(self.skill / "glossary_he.json", encoding="utf-8") as fh:
                    g = json.load(fh)
            self._gloss = g
        return self._gloss


# ---------------------------------------------------------------- helpers -----
# The anchor rules live in selfcheck_catalog (G89 verifies them) and the vocabulary
# (aliases, spelling variants) in catalog_search (G89 recomputes it under -I);
# these names are kept so that callers of catalog_build see one API.
anchor_for = G89.anchor_for
combo_anchor = G89.combo_anchor
subtopic_anchor = G89.subtopic_anchor
aliases_for = CS.aliases_for
search_variants_for = CS.search_variants_for
_dedupe = CS.dedupe
_article = CS._article
_number = CS._number


def site_item_key(item_id):
    """q4b → "4ב" (the site's teacher key part; deliver.item_id read backwards)."""
    m = re.match(r"^q(\d+)([a-x]?)$", item_id)
    if not m:
        raise ValueError(item_id)
    return m.group(1) + (_HEB[_LAT.index(m.group(2))] if m.group(2) else u"")


def site_manifest_id(prefix, level, item_id):
    """("G7-T12", "c", "q4b") → "G7-T12-E-Q04ב" (noam-ai manifests on the site)."""
    k = site_item_key(item_id)
    n = re.match(r"\d+", k).group(0)
    return u"%s-%s-Q%02d%s" % (prefix, SITE_LEVEL_CODE[level], int(n), k[len(n):])


# ---------------------------------------------------------------- the entry ---
def levels_from_deliver(deliver_root, keys):
    """{k: {name, question_ids, item_ids, pages}} from noam-ai.json and build.json of each level."""
    out = {}
    for k in keys:
        d = Path(deliver_root) / k
        na = d / "noam-ai.json"
        if not na.is_file():
            raise FileNotFoundError("no out/deliver/%s/noam-ai.json — build the package first" % k)
        with open(na, encoding="utf-8") as fh:
            j = json.load(fh)
        qids, iids = [], []

        def items(node):
            for it in node.get("items") or []:
                if isinstance(it, dict) and it.get("id"):
                    iids.append(it["id"])
                    items(it)
        for q in j.get("questions") or []:
            qids.append(q.get("id"))
            items(q)
        pages = None
        bj = d / "build.json"
        if bj.is_file():
            with open(bj, encoding="utf-8") as fh:
                pages = json.load(fh).get("pages")
        out[k] = {"name": LEVEL_NAMES[k], "question_ids": qids, "item_ids": iids, "pages": pages}
    return out


def entry_from(sheet, levels, registry=None, synthetic=False):
    """The catalog entry for a SHEET and its levels info. Pure: reads only the registry."""
    if not sheet:
        raise LegacyPackageError("legacy package (no SHEET): there is no catalog entry for it")
    reg = registry or Registry()
    gl = reg.glossary()
    sections, used = [], set()
    for sec in sheet.get("sections") or []:
        kind = sec.get("kind", "subtopic")
        qd = {k: ["q%d" % int(n) for n in (sec.get("questions") or {}).get(k) or []] for k in levels}
        if kind == "combo":
            anchor = combo_anchor(sheet.get("topic_id"), used)
            s = {"id": sec.get("id"), "subtopic": None, "kind": "combo", "title": sec.get("title"),
                 "anchor": anchor, "aliases": [], "search_variants": [], "question_ids": qd,
                 "combines": list(sec.get("combines") or [])}
        else:
            sid = sec.get("subtopic")
            ent = reg.get(sid) if sid else None
            if ent is None:
                raise KeyError("section %s: subtopic %r is not in the registry "
                               "(curriculum_tashpaz.json subtopics)" % (sec.get("id"), sid))
            anchor = subtopic_anchor(sid, used)   # a repeated subtopic gets "-2", "-3", ...
            al = aliases_for(ent, gl)
            s = {"id": sec.get("id"), "subtopic": sid, "kind": "subtopic", "title": sec.get("title"),
                 "anchor": anchor, "aliases": al,
                 "search_variants": search_variants_for(sec.get("title") or u"", al),
                 "question_ids": qd}
        used.add(anchor)
        sections.append(s)
    subs = []
    for s in sections:
        if s["subtopic"] and s["subtopic"] not in subs:
            subs.append(s["subtopic"])
    title = sheet.get("title")
    e = {"schema": SCHEMA, "sheet_id": sheet.get("sheet_id"), "package": sheet.get("package"),
         "grade": sheet.get("grade"), "track": sheet.get("track"), "topic_id": sheet.get("topic_id"),
         "scope": sheet.get("scope"), "title": title, "title_search": CS.search_key(title or u""),
         "levels": levels, "sections": sections, "subtopic_ids": subs,
         "replaces": list(sheet.get("replaces") or []),
         "landing_slug": (sheet.get("landing") or {}).get("slug"),
         "skill_version": SKILL_VERSION, "engine_version": ENGINE_VERSION}
    if synthetic:
        e["synthetic"] = True
    allowed = set(G89.ENTRY_REQUIRED) | set(G89.ENTRY_OPTIONAL)
    assert set(e) <= allowed, sorted(set(e) - allowed)
    return e


def resolve_deliver(pkg_dir, out_dir, deliver_root=None):
    """deliver_root if given, else <out_dir>/deliver if it exists, else where the build writes it."""
    if deliver_root:
        return Path(deliver_root)
    cand = Path(out_dir) / "deliver"
    if cand.is_dir():
        return cand
    import pkgload
    return pkgload.deliver_dir(pkg_dir)


def load_sheet(pkg_dir):
    """(SHEET, level keys) of a package; LegacyPackageError when it has no SHEET."""
    import pkgload
    P = pkgload.load(pkg_dir, with_ir=False)
    if not P.sheet:
        raise LegacyPackageError("legacy package (no SHEET): %s — catalog-entry.json and landing.json "
                                 "are built only for sectioned sheets" % Path(pkg_dir).name)
    return P.sheet, P.keys


def compute(pkg_dir, out_dir, deliver_root=None, registry=None):
    """(SHEET, entry, deliver_root) without writing anything (landing_build uses it too)."""
    sheet, keys = load_sheet(pkg_dir)
    droot = resolve_deliver(pkg_dir, out_dir, deliver_root)
    present = [k for k in keys if (droot / k / "noam-ai.json").is_file()]
    missing = [k for k in keys if k not in present]
    if missing:
        raise FileNotFoundError("deliver output missing for level(s) %s under %s — build first"
                                % (",".join(missing), droot))
    return sheet, entry_from(sheet, levels_from_deliver(droot, present), registry), droot


def write_json(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    return path


def build(pkg_dir, out_dir, deliver_root=None):
    """out/catalog/<sheet_id>/catalog-entry.json for a sectioned package; returns its Path."""
    sheet, entry, _ = compute(pkg_dir, out_dir, deliver_root)
    return write_json(Path(out_dir) / "catalog" / sheet["sheet_id"] / "catalog-entry.json", entry)


# ---------------------------------------------------------------- synthetic ---
SYNTH_COUNTS = {"S": 4, "M": 6, "L": 9, "combo": 2}


def _join_he(titles):
    titles = list(titles)
    if len(titles) <= 1:
        return u"".join(titles)
    return u", ".join(titles[:-1]) + u" ו" + titles[-1]


def synthetic_sheet(sheet_id, registry=None, overrides=None):
    """A SHEET-shaped dict for a PLANNED sheet: the registry entries whose `sheet` is sheet_id.

    Question counts are mid-range per size class (S 4, M 6, L 9, combo 2) — only so
    that question ids exist; nothing here was built. Used to test catalog search
    before the real sheets exist.
    """
    reg = registry or Registry()
    rows = [(t, p, e) for t, p, e in reg.located() if e.get("sheet") == sheet_id]
    if not rows:
        raise KeyError("no registry subtopic has sheet %r" % sheet_id)
    track, topic = rows[0][0], rows[0][1]
    rows.sort(key=lambda r: r[2].get("order", 0))
    grade = re.match(r"st\.g(\d+)", rows[0][2]["id"]).group(1)
    secs, n = [], 1
    for i, (_t, _p, e) in enumerate(rows, 1):
        c = SYNTH_COUNTS.get(e.get("size_class"), 4)
        nums = list(range(n, n + c))
        n += c
        secs.append({"id": "%s.s%d" % (sheet_id, i), "subtopic": e["id"], "kind": "subtopic",
                     "title": e["title"], "questions": {k: nums for k in LEVEL_KEYS},
                     "justification": None, "optional": bool(e.get("optional"))})
    if len(secs) >= 2:
        nums = list(range(n, n + SYNTH_COUNTS["combo"]))
        secs.append({"id": "%s.s%d" % (sheet_id, len(secs) + 1), "kind": "combo", "title": u"שילוב",
                     "combines": [s["id"] for s in secs], "questions": {k: nums for k in LEVEL_KEYS},
                     "justification": None, "optional": False})
    sheet = {"schema": "noam-sheet-sections/v1", "sheet_id": sheet_id, "package": None,
             "grade": grade, "track": track, "topic_id": topic, "scope": "sectioned",
             "title": _join_he(e["title"] for _t, _p, e in rows), "sections": secs,
             "landing": {"slug": "%s-synthetic" % sheet_id.lower(), "animation_id": "synthetic-placeholder"},
             "replaces": []}
    for k, v in (overrides or {}).items():
        sheet[k] = v
    return sheet


def synthetic_levels(sheet):
    out = {}
    for k in LEVEL_KEYS:
        nums = sorted({int(x) for s in sheet["sections"] for x in (s.get("questions") or {}).get(k) or []})
        out[k] = {"name": LEVEL_NAMES[k], "question_ids": ["q%d" % x for x in nums], "item_ids": [],
                  "pages": None}
    return out


def build_synthetic(sheet_id, out_dir, registry=None, overrides=None):
    """Write catalog-entry.json (+ landing.json) of a planned sheet, marked synthetic. Returns the entry path."""
    import landing_build
    reg = registry or Registry()
    sheet = synthetic_sheet(sheet_id, reg, overrides)
    entry = entry_from(sheet, synthetic_levels(sheet), reg, synthetic=True)
    d = Path(out_dir) / "catalog" / sheet_id
    p = write_json(d / "catalog-entry.json", entry)
    write_json(d / "landing.json", landing_build.landing_from(sheet, entry, reg))
    return p


# ---------------------------------------------------------------- lint ---------
def glossary_lint(strings, grade, scope, glossary):
    """[(rule, match, text)] for glossary `forbidden` and house spelling — what G86 will look for.

    Not a gate (G86 in gate_sections is); landing_build and the selftests use it to
    keep generated text clean before the gate sees it.
    """
    try:  # the very functions G86 uses, when subtopics.py is there
        import subtopics as S
        out = []
        for s in strings:
            for h in S.forbidden_hits(s, grade):
                out.append((h.get("id"), h.get("match"), s))
            if S.house_spelling_applies(scope):
                for h in S.house_spelling_hits(s):
                    out.append(("house_spelling", h.get("match"), s))
        return out
    except Exception:  # missing module or a changed API: the lint must never break a build
        pass
    m = glossary.get("matching") or {}
    tmpl = m.get("compile") or u"(?<![א-ת])(?:[ובכלמשה]{0,3})(?:<pattern>)(?![א-ת])"
    rules = []
    for f in glossary.get("forbidden") or []:
        if str(grade) in ((f.get("scope") or {}).get("grades") or []):
            rules.append((f.get("id"), f.get("pattern")))
    hs = glossary.get("house_spelling") or {}
    if scope in (hs.get("applies_to_scope") or []):
        for i, pat in enumerate(hs.get("forbidden_patterns") or []):
            rules.append(("house_spelling.%d" % i, pat))
    comp = [(rid, re.compile(tmpl.replace(u"<pattern>", pat))) for rid, pat in rules if pat]
    out = []
    for s in strings:
        t = CS.normalize(s)
        for rid, rx in comp:
            mm = rx.search(t)
            if mm:
                out.append((rid, mm.group(0), s))
    return out


def all_strings(obj):
    if isinstance(obj, dict):
        for v in obj.values():
            for s in all_strings(v):
                yield s
    elif isinstance(obj, list):
        for v in obj:
            for s in all_strings(v):
                yield s
    elif isinstance(obj, str):
        yield obj


# ---------------------------------------------------------------- CLI ---------
def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--pkg", help="package folder")
    ap.add_argument("--out", help="output root (default: <pkg>/out)")
    ap.add_argument("--deliver", help="deliver root (default: <out>/deliver or the package's DELIVER_DIR)")
    ap.add_argument("--synthetic", nargs="+", help="planned sheet ids to generate from the registry")
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args(argv)
    if a.selftest:
        return selftest()
    if a.synthetic:
        if not a.out:
            ap.error("--synthetic needs --out")
        for sid in a.synthetic:
            print(build_synthetic(sid, a.out))
        return 0
    if not a.pkg:
        ap.error("--pkg is required")
    out = a.out or str(Path(a.pkg) / "out")
    try:
        print(build(a.pkg, out, a.deliver))
    except LegacyPackageError as e:
        print("catalog_build: %s" % e, file=sys.stderr)
        return 2
    return 0


def selftest():
    t0 = time.time()
    fails = []

    def eq(got, want, what):
        if got != want:
            fails.append(u"%s: got %r, want %r" % (what, got, want))

    eq(anchor_for("st.g7.angles.vertical"), "angles-vertical", "anchor")
    eq(anchor_for("st.g9r.powers.product_same_base"), "powers-product-same-base", "anchor g9r")
    eq(combo_anchor("angles", set()), "angles-combo", "combo anchor")
    eq(combo_anchor("angles", {"angles-combo"}), "angles-combo-2", "second combo anchor")
    eq(subtopic_anchor("st.g7.angles.vertical", {"angles-vertical"}), "angles-vertical-2",
       "repeated subtopic gets -2 (review: the old branch returned the same anchor)")
    eq(subtopic_anchor("st.g7.angles.vertical", {"angles-vertical", "angles-vertical-2"}),
       "angles-vertical-3", "and -3 after that")
    eq(site_item_key("q4b"), u"4ב", "site item key")
    eq(site_manifest_id("G7-T12", "c", "q4b"), u"G7-T12-E-Q04ב", "site manifest id")
    v = search_variants_for(u"זוויות קודקודיות", [u"קודקודיות", u"זווית קודקודית"])
    for want in (u"זוויות קדקודיות", u"הזוויות הקודקודיות", u"זויות קודקודיות", u"קדקודיות", u"קודקודית"):
        if want not in v:
            fails.append(u"variant %s missing from %s" % (want, v))
    if u"קודקודיות" in v:
        fails.append("variants repeat an alias")
    v = search_variants_for(u"סימון זוויות", [u"3 אותיות", u"בשלוש אותיות"])
    for want in (u"שלוש אותיות", u"ב־3 אותיות"):
        if want not in v:
            fails.append(u"variant %s missing from %s" % (want, v))
    eq(_article([u"סכום", u"זוויות"]), [u"סכום הזוויות"], "construct article")
    eq(_article([u"זווית", u"צמודה"]), [u"הזווית הצמודה"], "noun-adjective article")
    eq(_article([u"הזווית", u"הצמודה"]), [u"זווית צמודה"], "strip article")
    eq(_article([u"אות", u"יוונית"]), [u"האות היוונית"], "אות is singular (noun + adjective)")
    eq(_number([u"זוויות", u"צמודות"]), [u"זווית צמודה"], "plural → singular")
    eq(_number([u"סכום", u"זוויות"]), [], "no number swap through a construct head")
    # registry-backed: one subtopic entry + a synthetic sheet (no package needed)
    reg = Registry()
    ent = reg.get("st.g7.angles.vertical")
    eq(bool(ent), True, "registry has st.g7.angles.vertical (%s)" % reg.source)
    if ent:
        al = aliases_for(ent, reg.glossary())
        for want in (u"קודקודיות", u"קדקודיות", u"קודקדיות"):
            if want not in al:
                fails.append(u"alias %s missing (registry + glossary)" % want)
    try:
        sh = synthetic_sheet("G7-ANG-02", reg)
        e = entry_from(sh, synthetic_levels(sh), reg, synthetic=True)
        eq([s["anchor"] for s in e["sections"]],
           ["angles-bisector", "angles-sum-diff", "angles-adjacent", "angles-vertical", "angles-combo"],
           "G7-ANG-02 anchors")
        eq(e["title"], u"חוצה זווית, סכום והפרש זוויות, זוויות צמודות וזוויות קודקודיות", "synthetic title")
        bad = glossary_lint(list(all_strings(e)), "7", "sectioned", reg.glossary())
        eq(bad, [], "generated entry passes the glossary")
        bad = [x for x in G89.scan_public(e, "entry")]
        eq(bad, [], "generated entry passes the G89 value scan")
    except Exception as ex:  # a broken registry must show, not crash the selftest
        fails.append("synthetic G7-ANG-02: %r" % ex)
    try:  # the same subtopic in two sections: distinct anchors, and G89 accepts the entry
        sh2 = {"sheet_id": "T7-ANG-77", "package": "G7-T77", "grade": "7", "track": u"ז",
               "topic_id": "angles", "scope": "sectioned", "title": u"זוויות קודקודיות",
               "sections": [{"id": "T7-ANG-77.s1", "subtopic": "st.g7.angles.vertical", "kind": "subtopic",
                             "title": u"זוויות קודקודיות", "questions": {"a": [1, 2, 3]}},
                            {"id": "T7-ANG-77.s2", "subtopic": "st.g7.angles.vertical", "kind": "subtopic",
                             "title": u"זוויות קודקודיות – המשך", "questions": {"a": [4, 5, 6]}}],
               "landing": {"slug": "t7-ang-77", "animation_id": "x"}, "replaces": []}
        lv2 = {"a": {"name": LEVEL_NAMES["a"], "question_ids": ["q%d" % n for n in range(1, 7)],
                     "item_ids": [], "pages": 2}}
        e2 = entry_from(sh2, lv2, reg)
        eq([s["anchor"] for s in e2["sections"]], ["angles-vertical", "angles-vertical-2"], "dup subtopic anchors")
        msgs2, _n = G89.check_entry(e2, None, sh2)
        eq([m for m in msgs2 if "anchor" in m], [], "G89 accepts the de-duplicated anchors")
    except Exception as ex:
        fails.append("same subtopic twice: %r" % ex)
    try:
        entry_from(None, {})
        fails.append("legacy did not raise")
    except LegacyPackageError as ex:
        eq(str(ex).startswith("legacy package (no SHEET)"), True, "legacy message")
    dt = time.time() - t0
    for f in fails:
        print(u"FAIL " + f)
    print("catalog_build selftest: %d checks failed, %.2f s (registry: %s)" % (len(fails), dt, reg.source))
    return 1 if fails or dt > 30 else 0


if __name__ == "__main__":
    sys.exit(main())
