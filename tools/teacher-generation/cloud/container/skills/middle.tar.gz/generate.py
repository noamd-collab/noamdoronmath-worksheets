# -*- coding: utf-8 -*-
"""generate — v6.3 section 4: configurations from a description.

    from generate import Generator
    G = Generator("ריבוע ABCD; G על AD; ∠GBA = 37°", seed=3)
    fig  = G.figure()              # one valid configuration (fig.svg)
    more = G.alternatives(3)       # other configurations of the SAME data
    print(G.report())              # what the data does and does not fix
    bad  = G.violate("∠GBA = 37°") # one datum broken, for "find the mistake"

WHAT THIS IS FOR
----------------
`describe` says what the question claims; this file turns the claim into
DRAWINGS. Four things make it worth the code:

  * it SOLVES. `G על AD` plus `∠GBA = 37°` is one equation in one unknown
    (how far along AD the point stands), and it is solved — exactly with
    sympy where the equation has a closed form (a ratio, a length along a
    segment, a wedge angle), and with a bounded root finder over [0, 1]
    otherwise. Nothing is placed by eye, so the number the figure PRINTS is
    the number the figure MEASURES.
  * it REFUSES. A configuration that is degenerate (a point that lands on a
    vertex, two letters on one spot, a wedge too thin to arc) or that
    contradicts its own description is refused with a message naming the
    fix, including the band of values that WOULD work.
  * it gives SEVERAL. `alternatives(n)` returns different configurations of
    the same data — the variety a sheet and its three levels need — and, by
    doing so, reports data that does not determine the figure at all: an
    under-specified question, which is the author's own bug to fix.
  * it can LIE ON PURPOSE. `violate(datum)` breaks exactly one datum and
    tags the SVG `<!--critique:find_error-->`, the tag `numberline.
    critique_guard` already reads, so a deliberately wrong figure can only
    stand beside an item that asks for the mistake (the giveaway rule).

HOW A FIGURE IS BUILT
---------------------
    1. bind    every length/angle datum that IS a parameter of the base
               shape goes straight into it (AB = 15 on a rectangle is w).
    2. sample  a parameter no datum fixes is drawn from a readable band by
               the seeded RNG — and RECORDED as free, which is what makes
               `alternatives` and the under-specified report possible.
    3. solve   the remaining data become equations; each unknown (a free
               parameter, or the position t of a point on a segment) is
               solved against one of them, then a few Gauss-Seidel sweeps
               settle any coupling. Everything is under one deadline.
    4. draw    `shapekit` and nothing else: the base shape, then the add-ons
               each datum asks for, then the marks it claims.
    5. read    the FINISHED SVG is parsed again by `_read_back` — the
               polygon and the dots, not this module's bookkeeping — and
               every datum is re-measured on what was actually drawn. A
               figure whose drawing does not match its description is
               refused even if every step above thought it had succeeded.

DETERMINISM
-----------
`(description, seed)` fixes everything: the RNG is seeded from a SHA-256 of
the cleaned description text and the seed (never Python's salted `hash`), and
no step consults the clock. Every loop is bounded by a COUNT (Newton rounds,
configurations tried, sympy only on closed forms), so the same text gives the
same figure -- or the same refusal -- on an idle machine, a loaded one, and in
a cold process (v6.7).

THE TIME CAP
------------
`cap=` seconds (30 by default) is a SAFETY NET, not a verdict: hitting it
raises GenerateMachineError, which is not an AssertionError and says the
machine is the problem. It names `cap=` so a slow machine can allow more.
"""
import hashlib
import math
import random
import re
import time

import describe as _D
import shapekit as S
from describe import Description, DescribeError, parse

__all__ = ["Generator", "Figure", "GenerateError", "GenerateMachineError",
           "build_figure",
           "alternatives", "violate"]


class GenerateMachineError(RuntimeError):
    """v6.7: the safety-net clock ran out -- a MACHINE problem (overloaded or
    stalled), never a refusal of the description. Not an AssertionError, so
    no caller routes around it as if the figure were at fault."""


class GenerateError(AssertionError):
    """A description that cannot be drawn: degenerate, self-contradictory,
    under a time cap it cannot meet, or outside what the generator solves."""


def _bad(said, fix):
    raise GenerateError("generate: %s — %s" % (said, fix))


# ---------------------------------------------------------------- bounds ---
_SCALE = 10.0            # the default data length, when no datum gives one
MIN_T, MAX_T = 0.10, 0.90        # a point on a segment, away from both ends
MIN_GAP = 0.20                   # figure units between two named points
MIN_WEDGE = 4.0                  # degrees: under this no arc reads at all
CALLOUT_WEDGE = 14.0             # ... and under THIS the number is called out
MIN_VERTEX = 15.0                # degrees, the base shape's own corners
TOL_DEG = 0.05
TOL_REL = 3e-4

_BANDS = {
    "square":        {"a": (1.0, 1.0)},
    "rectangle":     {"w": (1.0, 1.0), "h": (0.40, 0.72)},
    # b runs BOTH sides of a: 'the bisector of A meets BC' is only true when
    # AB is the shorter side, and a band that always made b the shorter one
    # could never draw the author's own question
    "parallelogram": {"a": (1.0, 1.0), "b": (0.45, 1.80),
                      "angle": (52.0, 74.0)},
    "rhombus":       {"a": (1.0, 1.0), "angle": (48.0, 74.0)},
    "kite":          {"a": (0.50, 0.66), "b": (1.0, 1.0), "q": (0.55, 0.85)},
    "trapezoid":     {"a": (1.0, 1.0), "b": (0.40, 0.62), "h": (0.45, 0.72)},
    # three sides a reader can tell apart: bands that overlap produced a
    # free triangle that came out looking isosceles more often than not, and
    # a sheet's figure may not suggest a datum the question never gave
    # Three sides a reader can tell apart, on a triangle that is still
    # ACUTE: bands that overlapped drew a free triangle that read as
    # isosceles more often than not (a sheet's figure may not suggest a datum
    # the question never gave), and bands wider than these drew an obtuse one
    # nearly every time, where the foot of the altitude from C falls outside
    # AB and `CH גובה אל AB` cannot be drawn at all.
    "triangle":      {"c": (1.0, 1.0), "a": (0.74, 0.88), "b": (1.08, 1.22)},
    "polygon":       {"a": (1.0, 1.0)},
    "circle":        {"r": (1.0, 1.0)},
}
_ANGLE_PARAMS = {"angle"}

_SIDES = {
    "square":        {(0, 1): "a", (1, 2): "a", (2, 3): "a", (3, 0): "a"},
    "rectangle":     {(0, 1): "w", (2, 3): "w", (1, 2): "h", (3, 0): "h"},
    "parallelogram": {(0, 1): "a", (2, 3): "a", (1, 2): "b", (3, 0): "b"},
    "rhombus":       {(0, 1): "a", (1, 2): "a", (2, 3): "a", (3, 0): "a"},
    "kite":          {(0, 1): "a", (3, 0): "a", (1, 2): "b", (2, 3): "b"},
    "trapezoid":     {(0, 1): "a", (2, 3): "b"},
    "triangle":      {(1, 2): "a", (0, 2): "b", (0, 1): "c"},
}
_DIAGS = {"rhombus": {(0, 2): "d1", (1, 3): "d2"}, "kite": {(1, 3): "q"}}
# the angle at vertex i is  s * params['angle'] + k
_ANG_AT = {"parallelogram": {0: (1, 0), 2: (1, 0), 1: (-1, 180), 3: (-1, 180)},
           "rhombus":       {0: (1, 0), 2: (1, 0), 1: (-1, 180), 3: (-1, 180)}}

# What `violate` knows how to break, and — for each — whether the lie lands
# in a MARK the engine measures. A mark that contradicts the drawing has to
# be declared to svgcheck (`<!--critique:find_error:marks-->`), which then
# requires the error to be there; a wrong NUMBER beside a side is not a mark,
# so it carries the plain tag.
_VIOLABLE = {"angle3": "marks", "angle1": "marks", "equal": "marks",
             "midpoint": "marks", "length": ""}


# ------------------------------------------------------------- geometry ---
def _d(p, q):
    return math.hypot(p[0] - q[0], p[1] - q[1])


def _ang(p, v, q):
    """The unsigned angle p-v-q in degrees (similarity- and reflection-
    invariant, which is why the read-back can use it)."""
    u = (p[0] - v[0], p[1] - v[1])
    w = (q[0] - v[0], q[1] - v[1])
    n = math.hypot(*u) * math.hypot(*w)
    if n <= 1e-12:
        return 0.0
    c = max(-1.0, min(1.0, (u[0] * w[0] + u[1] * w[1]) / n))
    return math.degrees(math.acos(c))


def _lerp(p, q, t):
    return (p[0] + t * (q[0] - p[0]), p[1] + t * (q[1] - p[1]))


def _sin_between(p, q, r, s):
    """Signed, and zero exactly when the two lines are PARALLEL. The
    unsigned angle between two lines only TOUCHES zero there, so a bounded
    scan could never bracket it — a root finder needs a sign change, not a
    tangency."""
    u = (q[0] - p[0], q[1] - p[1])
    w = (s[0] - r[0], s[1] - r[1])
    n = math.hypot(*u) * math.hypot(*w)
    if n <= 1e-12:
        return 0.0
    return math.degrees(math.asin(max(-1.0, min(1.0,
                                                (u[0] * w[1] - u[1] * w[0]) / n))))


def _cos_between(p, q, r, s):
    """Signed, and zero exactly when the two lines are PERPENDICULAR."""
    u = (q[0] - p[0], q[1] - p[1])
    w = (s[0] - r[0], s[1] - r[1])
    n = math.hypot(*u) * math.hypot(*w)
    if n <= 1e-12:
        return 0.0
    return math.degrees(math.asin(max(-1.0, min(1.0,
                                                (u[0] * w[0] + u[1] * w[1]) / n))))


def _foot(p, a, b):
    ux, uy = b[0] - a[0], b[1] - a[1]
    L2 = ux * ux + uy * uy
    if L2 <= 1e-12:
        return a
    t = ((p[0] - a[0]) * ux + (p[1] - a[1]) * uy) / L2
    return (a[0] + t * ux, a[1] + t * uy)


def _cross_point(a, b, c, d):
    x1, y1 = a
    x2, y2 = b
    x3, y3 = c
    x4, y4 = d
    den = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
    if abs(den) < 1e-12:
        return None
    px = ((x1 * y2 - y1 * x2) * (x3 - x4) - (x1 - x2) * (x3 * y4 - y3 * x4)) / den
    py = ((x1 * y2 - y1 * x2) * (y3 - y4) - (y1 - y2) * (x3 * y4 - y3 * x4)) / den
    return (px, py)


def _root(f, lo, hi, n=64):
    """A bounded root: scan for a sign change, then bisect. None when the
    band holds no root — the caller turns that into a refusal that names the
    band, never into a guess."""
    xs = [lo + (hi - lo) * i / float(n) for i in range(n + 1)]
    vs = []
    for x in xs:
        try:
            vs.append(f(x))
        except (GenerateError, S.ShapeError, ZeroDivisionError, ValueError):
            vs.append(None)
    best = None
    for i in range(n):
        u, v = vs[i], vs[i + 1]
        if u is None or v is None:
            continue
        if u == 0.0:
            return xs[i]
        if u * v < 0:
            a, b, fa = xs[i], xs[i + 1], u
            for _ in range(70):
                m = 0.5 * (a + b)
                fm = f(m)
                if fm == 0.0:
                    return m
                if fa * fm < 0:
                    b = m
                else:
                    a, fa = m, fm
            return 0.5 * (a + b)
        k = abs(u)
        if best is None or k < best[0]:
            best = (k, xs[i])
    return None


# ------------------------------------------------------------ the frame ---
def _frame(kind, variant, params):
    """The base shape's vertices in the pre-rotation frame, straight from
    `shapekit`'s own geometry table — the very numbers `shapekit.shape` will
    draw, so the solver and the drawing can never disagree. Returns
    (points in order, the extra dict, units-per-data-length)."""
    data = dict(params)
    if variant:
        data["variant"] = variant
    raw, extra = S._GEOM[kind](data)
    if kind == "circle":
        return [], extra, (S._SPAN / 2.0) / extra["r"]
    pts, k, _ctr = S._norm(S._ccw(list(raw)))
    return pts, extra, k


def _base_points(desc, params):
    pts, extra, U = _frame(desc.kind, _shape_variant(desc), params)
    P = {}
    for name, p in zip(desc.letters, pts):
        P[name] = p
    return P, extra, U


def _shape_variant(desc):
    """The variant `shapekit.shape` is called with. A triangle is ALWAYS
    built from its three sides: the declared kind (right / isosceles /
    equilateral) becomes an equation the solver has to satisfy and a mark the
    drawing has to carry, which is stricter than asking the builder for it —
    `svgcheck` then re-measures the mark against the drawing."""
    if desc.kind == "triangle":
        return "sss"
    if desc.kind == "trapezoid":
        return desc.variant or "scalene"
    return None


# ----------------------------------------------------------- the binding ---
def _pairs(desc):
    """letter -> index, and the index pair of a segment, when both ends are
    vertices of the base shape."""
    idx = dict((c, i) for i, c in enumerate(desc.letters))
    return idx


def _side_param(desc, i, j):
    n = len(desc.letters)
    if desc.kind == "polygon":
        return "a" if (j - i) % n in (1, n - 1) else None
    tab = _SIDES.get(desc.kind, {})
    for (u, v), name in tab.items():
        if (u, v) == (i, j) or (v, u) == (i, j):
            return name
    for (u, v), name in _DIAGS.get(desc.kind, {}).items():
        if (u, v) == (i, j) or (v, u) == (i, j):
            return name
    return None


def _neighbours(desc, i):
    n = len(desc.letters)
    return (i - 1) % n, (i + 1) % n


def _bind(desc, rng, override=None):
    """Data -> base parameters. Returns (params, free names, the data that
    did not become a parameter and must be solved or checked).

    `override` (violate) has to reach HERE as well: a length that the shape
    is built from is not an equation to be solved later, it IS the parameter,
    so a violated `AB = 9` that only changed the equation would fight a
    parameter still holding 9 and be refused as a contradiction."""
    kind = desc.kind
    override = override or {}
    idx = _pairs(desc)
    want = dict(_BANDS[kind])
    params, fixed, rest = {}, set(), []
    if kind == "rhombus":
        # the two ways a sheet gives a rhombus. The diagonals win when they
        # are named, because then they are the question's own numbers.
        diag = [d for d in desc.data if d.role == "length"
                and set(d.args) <= set(desc.letters)
                and _side_param(desc, idx[d.args[0]], idx[d.args[1]])
                in ("d1", "d2")]
        want = {"d1": (1.0, 1.0), "d2": (0.55, 0.85)} if diag \
            else {"a": (1.0, 1.0), "angle": (48.0, 74.0)}

    for dat in desc.data:
        if dat.role == "height" and kind == "trapezoid":
            params["h"] = override.get(dat.text, dat.value)
            fixed.add("h")
            continue
        if dat.role == "length" and set(dat.args) <= set(desc.letters):
            p = _side_param(desc, idx[dat.args[0]], idx[dat.args[1]])
            if p in want and p not in params:
                params[p] = override.get(dat.text, dat.value)
                fixed.add(p)
                continue
        if dat.role in ("angle1", "angle3"):
            v = _vertex_of(desc, dat)
            if v is not None and kind in _ANG_AT and v in _ANG_AT[kind]:
                s, k = _ANG_AT[kind][v]
                if "angle" in want and "angle" not in params:
                    params["angle"] = (override.get(dat.text, dat.value)
                                       - k) / float(s)
                    fixed.add("angle")
                    continue
        rest.append(dat)

    ref = None
    for p in ("a", "w", "c", "b", "d1", "r"):
        if p in params:
            ref = params[p]
            break
    if ref is None:
        ref = _SCALE
    free = []
    for p, (lo, hi) in sorted(want.items()):
        if p in params:
            continue
        free.append(p)
        if p in _ANGLE_PARAMS:
            params[p] = round(rng.uniform(lo, hi), 1)
        else:
            params[p] = round(ref * rng.uniform(lo, hi), 2)
    if kind == "triangle" and "a" in free and "b" in free and \
            rng.random() < 0.5:
        # which of the two free sides is the long one is itself a choice: a
        # band that always made CA the longest put the foot of the altitude
        # from C outside AB nearly every time, and left alternatives() with
        # half the figures it could have
        params["a"], params["b"] = params["b"], params["a"]
    if kind == "polygon":
        params["n"] = len(desc.letters)
    if kind == "kite" and params.get("q", 0) >= 2 * min(params["a"],
                                                        params["b"]):
        params["q"] = round(1.2 * min(params["a"], params["b"]), 2)
    return params, free, rest


def _vertex_of(desc, dat):
    """The index of the base vertex whose OWN angle this datum gives, or
    None (an angle between a side and something else is an equation)."""
    idx = _pairs(desc)
    if dat.role == "angle1":
        return idx.get(dat.args[0])
    x, y, z = dat.args
    if not set(dat.args) <= set(desc.letters):
        return None
    i = idx[y]
    return i if set(_neighbours(desc, i)) == set([idx[x], idx[z]]) else None


# --------------------------------------------------------- construction ---
_BUILDS = ("on", "midpoint", "meet", "foot", "median", "altitude")


def _declared(desc):
    """Every point some OTHER sentence pins (a vertex, or a point a
    `_BUILDS` datum declares)."""
    out = set(desc.letters)
    for dat in desc.data:
        if dat.role in _BUILDS:
            out.add(dat.args[_D._NEW.get(dat.role, 0)])
    return out


def _builds_bisector(desc, dat):
    """r1 (S2-5): 'AE חוצה זווית A' brings its own E — unless another
    sentence already says where E is, in which case that sentence wins and
    the bisector is an equation about it, exactly as before."""
    return dat.role == "bisector" and dat.args[1] not in _declared(desc)


def _derived(desc):
    """The points the description builds, in declaration order, as
    (letter, role, datum)."""
    out = []
    for dat in desc.data:
        if dat.role in _BUILDS:
            out.append((dat.args[_D._NEW.get(dat.role, 0)], dat.role, dat))
        elif _builds_bisector(desc, dat):
            out.append((dat.args[1], "bisector", dat))
    return out


def _bisector_side(desc, dat, P):
    """Where the internal bisector from V leaves the shape: (A, B, t) on the
    side it meets. A convex shape always has one — which is why the datum
    can build its own point."""
    V = dat.args[2]
    i = _pairs(desc)[V]
    u, w = _neighbours(desc, i)
    v = P[V]
    (u1x, u1y) = _unitv(v, P[desc.letters[u]])
    (u2x, u2y) = _unitv(v, P[desc.letters[w]])
    dx, dy = u1x + u2x, u1y + u2y
    if math.hypot(dx, dy) < 1e-9:
        return None
    far = (v[0] + dx * 1e4, v[1] + dy * 1e4)
    n = len(desc.letters)
    best = None
    for j in range(n):
        a, b = desc.letters[j], desc.letters[(j + 1) % n]
        if V in (a, b):
            continue
        X = _cross_point(v, far, P[a], P[b])
        if X is None:
            continue
        L = _d(P[a], P[b])
        t = _d(P[a], X) / L if L else 0.0
        if not (-1e-9 <= t <= 1 + 1e-9):
            continue
        if (X[0] - v[0]) * dx + (X[1] - v[1]) * dy <= 0:
            continue
        r = _d(v, X)
        if best is None or r < best[0]:
            best = (r, a, b, min(1.0, max(0.0, t)))
    return None if best is None else (best[1], best[2], best[3])


def _unitv(p, q):
    L = _d(p, q) or 1.0
    return ((q[0] - p[0]) / L, (q[1] - p[1]) / L)


def _construct(desc, P0, tvals):
    """base points + the solved t's -> every point the figure names."""
    P = dict(P0)
    for name, role, dat in _derived(desc):
        if role == "on":
            a, b = dat.args[1], dat.args[2]
            P[name] = _lerp(P[a], P[b], tvals[name])
        elif role == "midpoint":
            P[name] = _lerp(P[dat.args[1]], P[dat.args[2]],
                            tvals.get(name, 0.5))
        elif role == "median":
            P[name] = _lerp(P[dat.args[2]], P[dat.args[3]], 0.5)
        elif role in ("altitude", "foot"):
            apex = dat.args[0] if role == "altitude" else dat.args[1]
            a, b = dat.args[2], dat.args[3]
            P[name] = _foot(P[apex], P[a], P[b])
        elif role == "bisector":
            side = _bisector_side(desc, dat, P)
            if side is None:
                _bad("חוצה הזווית %s אינו פוגש אף צלע של %s"
                     % (dat.text, _D.hebrew(desc.kind, desc.variant)),
                     "הכריזו על הנקודה בעצמכם ('%s על %s')"
                     % (dat.args[1], _D._away_from(dat, desc.letters)))
            a, b, t = side
            P[name] = _lerp(P[a], P[b], t)
        elif role == "meet":
            n = len(desc.letters)
            if n != 4:
                _bad("מפגש האלכסונים על %s בעל %d קודקודים" % (desc.kind, n),
                     "מפגש אלכסונים מוגדר כאן למרובע; במשולש בקשו תיכון "
                     "('CM תיכון אל AB') או גובה")
            A, B, C, Dd = [P[c] for c in desc.letters]
            X = _cross_point(A, C, B, Dd)
            if X is None:
                _bad("האלכסונים אינם נחתכים", "בדקו את נתוני הצורה")
            P[name] = X
    return P


# ------------------------------------------------------------- equations ---
def _resid(desc, dat, P, U, override=None):
    """(residual, kind) for one datum. kind is 'deg' or 'rel', so a
    tolerance can mean the same thing for an angle and for a length."""
    v = dat.value if override is None else override
    a = dat.args
    if dat.role == "angle3":
        return _ang(P[a[0]], P[a[1]], P[a[2]]) - v, "deg"
    if dat.role == "angle1":
        i = _pairs(desc)[a[0]]
        u, w = _neighbours(desc, i)
        return _ang(P[desc.letters[u]], P[a[0]], P[desc.letters[w]]) - v, "deg"
    if dat.role == "length":
        return (_d(P[a[0]], P[a[1]]) - v * U) / S._SPAN, "rel"
    if dat.role == "equal":
        # v is a FACTOR here (1 = the equality the sentence claims); only
        # violate() ever passes anything else
        f = 1.0 if v is None else float(v)
        return (_d(P[a[0]], P[a[1]]) - f * _d(P[a[2]], P[a[3]])) / S._SPAN, "rel"
    if dat.role == "ratio":
        p, q = v if isinstance(v, tuple) else (v, 1.0)
        return (_d(P[a[0]], P[a[1]]) * q - _d(P[a[2]], P[a[3]]) * p) / S._SPAN, "rel"
    if dat.role == "parallel":
        return _sin_between(P[a[0]], P[a[1]], P[a[2]], P[a[3]]), "deg"
    if dat.role == "perp":
        return _cos_between(P[a[0]], P[a[1]], P[a[2]], P[a[3]]), "deg"
    if dat.role == "bisector":
        V, E = a[2], a[1]
        i = _pairs(desc)[V]
        u, w = _neighbours(desc, i)
        return (_ang(P[desc.letters[u]], P[V], P[E])
                - _ang(P[E], P[V], P[desc.letters[w]])), "deg"
    return None, None


def _variant_eqs(desc):
    """The declared kind, as equations the solve has to satisfy (and the
    drawing has to carry as marks)."""
    out = []
    if desc.kind == "triangle":
        if desc.variant == "iso":
            out.append(("iso", lambda P, U: (_d(P[desc.letters[2]], P[desc.letters[0]])
                                             - _d(P[desc.letters[2]], P[desc.letters[1]])) / S._SPAN, "rel"))
        elif desc.variant == "equilateral":
            out.append(("equilateral", lambda P, U: (_d(P[desc.letters[0]], P[desc.letters[1]])
                                                     - _d(P[desc.letters[1]], P[desc.letters[2]])) / S._SPAN, "rel"))
            out.append(("equilateral2", lambda P, U: (_d(P[desc.letters[1]], P[desc.letters[2]])
                                                      - _d(P[desc.letters[2]], P[desc.letters[0]])) / S._SPAN, "rel"))
        elif desc.variant == "right":
            out.append(("right", lambda P, U: _ang(P[desc.letters[1]], P[desc.letters[0]],
                                                   P[desc.letters[2]]) - 90.0, "deg"))
    return out


def _tolerance(kindn):
    return TOL_DEG if kindn == "deg" else TOL_REL


# ================================================================ solving ===
class _Solved(object):
    """What the solver found: the base parameters, the position of every
    point that had one, and WHICH of them no datum fixed."""

    def __init__(self, params, tvals, free, P, U, extra):
        self.params, self.tvals, self.free = params, tvals, list(free)
        self.P, self.U, self.extra = P, U, extra

    def signature(self):
        return (tuple(sorted((k, round(float(v), 3))
                             for k, v in self.params.items())),
                tuple(sorted((k, round(float(v), 4))
                             for k, v in self.tvals.items())))


def _param_band(name, params, ref):
    if name in _ANGLE_PARAMS:
        return 15.0, 165.0
    return 0.20 * ref, 3.0 * ref


def _solve(desc, rng, deadline, override=None):
    """The whole solve. `override` replaces one datum's value — that is how
    `violate` works: the broken value is solved for exactly, so the figure is
    wrong in one named way and right in every other."""
    override = override or {}
    params, free_params, _rest = _bind(desc, rng, override)
    ref = max([v for k, v in params.items()
               if k not in _ANGLE_PARAMS and k != "n"] or [_SCALE])

    derived = _derived(desc)
    tnames = [n for n, role, _ in derived if role == "on"]
    tvals = dict((n, 0.5) for n in tnames)
    for n, role, dat in derived:
        if role == "midpoint":
            tvals[n] = override.get(("t", dat.text), 0.5)

    # ---- the equations: every datum that is a claim about the drawing
    eqs = []
    for dat in desc.data:
        val = override.get(dat.text, dat.value)
        probe = _resid_probe(desc, dat)
        if probe is None:
            continue
        eqs.append(_Eq(dat.text, dat.args, probe, val, dat))
    for name, fn, kindn in _variant_eqs(desc):
        eqs.append(_Eq(name, tuple(desc.letters), (fn, kindn), None, None))

    def ev(params_, tvals_):
        P0, extra, U = _base_points(desc, params_)
        return _construct(desc, P0, tvals_), U, extra

    def resid(e, params_, tvals_):
        P, U, _x = ev(params_, tvals_)
        return e.value_at(desc, P, U)

    # ---- assignment: one equation per unknown, in the order they appear
    base_letters = set(desc.letters)
    unassigned = list(eqs)
    plan = []                                   # (kind, name, equation|None)

    def affects(e, kindp, name):
        """Does this unknown MOVE this equation? A datum already bound into
        the base shape (AB = 4 IS the parameter c) does not depend on any
        other unknown, and handing it to one used to 'solve' it at the first
        sample it tried — a right triangle came out with a leg of 0.8."""
        try:
            base = _resid_at(desc, e, params, tvals, ev)
        except Exception:
            return False
        if base is None:
            return False
        h = 1e-4 if kindp == "t" else 1e-3 * max(1.0, abs(params.get(name, 1.0)))
        q, r = dict(params), dict(tvals)
        if kindp == "t":
            r[name] = min(0.999, max(0.001, r.get(name, 0.5) + h))
        else:
            q[name] = q[name] + h
        try:
            moved = _resid_at(desc, e, q, r, ev)
        except Exception:
            return False
        return moved is not None and abs(moved - base) > 1e-7

    for p in free_params:
        pick = None
        for e in unassigned:
            if set(e.args) <= base_letters and affects(e, "param", p):
                pick = e
                break
        if pick is not None:
            unassigned.remove(pick)
        plan.append(("param", p, pick))
    for n in tnames:
        pick = None
        for e in unassigned:
            if n in e.args and affects(e, "t", n):
                pick = e
                break
        if pick is not None:
            unassigned.remove(pick)
        plan.append(("t", n, pick))

    free = [name for kindp, name, e in plan if e is None]

    # ---- solve, unknown by unknown
    for kindp, name, e in plan:
        _tick(deadline, desc)
        if e is None:
            if kindp == "t":
                tvals[name] = round(rng.uniform(0.28, 0.72), 3)
            continue
        if kindp == "param":
            lo, hi = _param_band(name, params, ref)

            def f(x, _n=name):
                q = dict(params)
                q[_n] = x
                try:
                    return resid(e, q, tvals)
                except (S.ShapeError, GenerateError):
                    raise
            x = _guarded_root(f, lo, hi)
            if x is None:
                def q(v, _n=name):
                    P, U, _x = ev(dict(params, **{_n: v}), tvals)
                    return _quantity(desc, e.datum, P, U)
                _contradiction(desc, e, "הפרמטר %s" % name, lo, hi, q)
            params[name] = x
        else:
            x = _solve_t(desc, e, name, params, tvals, ev, deadline)
            tvals[name] = x

    # ---- the unknowns that COUPLE, solved together
    # Gauss-Seidel alone oscillates on a genuinely coupled pair (a
    # parallelogram given both angles a diagonal makes with its sides moves
    # both when either is solved), so the square system gets a damped Newton
    # over finite differences first, and the sweeps stay as the fallback.
    square = [(kindp, name, e) for kindp, name, e in plan if e is not None]
    if len(square) > 1:
        _newton(desc, square, params, tvals, ev, ref, deadline)

    for _ in range(6):
        _tick(deadline, desc)
        worst = _worst(desc, eqs, ev, params, tvals)
        if worst is None or worst[0] <= 1.0:
            break
        for kindp, name, e in plan:
            if e is None:
                continue
            if kindp == "t":
                try:
                    tvals[name] = _solve_t(desc, e, name, params, tvals, ev,
                                           deadline)
                except GenerateError:
                    pass
            else:
                lo, hi = _param_band(name, params, ref)
                x = _guarded_root(lambda v, _n=name: resid(
                    e, dict(params, **{_n: v}), tvals), lo, hi)
                if x is not None:
                    params[name] = x

    # ---- everything, checked
    P, U, extra = ev(params, tvals)
    worst = _worst(desc, eqs, ev, params, tvals)
    if worst is not None and worst[0] > 1.0:
        e = worst[1]
        _contradiction(desc, e, None, None, None, None)
    return _Solved(params, tvals, free, P, U, extra)


def _gauss(A, b):
    n = len(b)
    M = [row[:] + [b[i]] for i, row in enumerate(A)]
    for i in range(n):
        p = max(range(i, n), key=lambda r: abs(M[r][i]))
        if abs(M[p][i]) < 1e-12:
            return None
        M[i], M[p] = M[p], M[i]
        for r in range(n):
            if r == i:
                continue
            f = M[r][i] / M[i][i]
            for c in range(i, n + 1):
                M[r][c] -= f * M[i][c]
    return [M[i][n] / M[i][i] for i in range(n)]


def _newton(desc, square, params, tvals, ev, ref, deadline, rounds=30):
    """A damped Newton on the unknowns that have an equation each. Finite
    differences, a line search that only accepts a step that reduces the
    worst residual, and every unknown clamped to its own band — so it can
    fail to converge but can never wander into a figure nobody asked for."""
    names = [(kindp, name) for kindp, name, _e in square]
    eqs = [e for _k, _n, e in square]
    bands = [(0.0005, 0.9995) if k == "t" else _param_band(n, params, ref)
             for k, n in names]

    def put(x):
        for (kindp, name), v in zip(names, x):
            if kindp == "t":
                tvals[name] = v
            else:
                params[name] = v

    def F(x):
        put(x)
        try:
            P, U, _x = ev(params, tvals)
        except (S.ShapeError, GenerateError):
            return None
        out = []
        for e in eqs:
            try:
                out.append(e.value_at(desc, P, U))
            except Exception:
                return None
        return out

    x = [tvals[n] if k == "t" else params[n] for k, n in names]
    f0 = F(x)
    if f0 is None:
        return
    for _ in range(rounds):
        _tick(deadline, desc)          # v6.7: the safety net, never a break
        worst = max(abs(v) for v in f0)
        if worst <= 1.0:
            break
        J = []
        ok = True
        for j in range(len(x)):
            h = 1e-5 * max(1.0, abs(x[j]))
            y = list(x)
            y[j] = min(bands[j][1], max(bands[j][0], x[j] + h))
            fj = F(y)
            if fj is None or y[j] == x[j]:
                ok = False
                break
            J.append([(fj[i] - f0[i]) / (y[j] - x[j]) for i in range(len(f0))])
        put(x)
        if not ok:
            return
        A = [[J[j][i] for j in range(len(x))] for i in range(len(f0))]
        step = _gauss(A, [-v for v in f0])
        if step is None:
            return
        moved = False
        for damp in (1.0, 0.5, 0.25, 0.1, 0.03):
            y = [min(bands[j][1], max(bands[j][0], x[j] + damp * step[j]))
                 for j in range(len(x))]
            fy = F(y)
            if fy is not None and max(abs(v) for v in fy) < worst:
                x, f0, moved = y, fy, True
                break
        put(x)
        if not moved:
            return


def _resid_at(desc, e, params, tvals, ev):
    P, U, _x = ev(params, tvals)
    return e.value_at(desc, P, U)


class _Eq(object):
    def __init__(self, text, args, probe, value, datum):
        self.text, self.args, self.value, self.datum = text, args, value, datum
        self.probe = probe

    def value_at(self, desc, P, U):
        fn, kindn = self.probe
        if self.datum is None:
            return fn(P, U) / _tolerance(kindn)
        r, kindn2 = fn(P, U, self.value)
        return r / _tolerance(kindn2)


def _resid_probe(desc, dat):
    """(callable(P, U, value) -> (residual, kind)) for a datum that makes a
    claim, or None for one that only builds (a midpoint, a foot, a median)."""
    if dat.role not in ("angle3", "angle1", "length", "equal", "ratio",
                        "parallel", "perp", "bisector"):
        return None

    def fn(P, U, value):
        return _resid(desc, dat, P, U, override=value)
    return (fn, "deg")


def _worst(desc, eqs, ev, params, tvals):
    try:
        P, U, _x = ev(params, tvals)
    except (S.ShapeError, GenerateError):
        return None
    out = None
    for e in eqs:
        try:
            r = abs(e.value_at(desc, P, U))
        except Exception:
            continue
        if out is None or r > out[0]:
            out = (r, e)
    return out


def _guarded_root(f, lo, hi):
    def g(x):
        try:
            return f(x)
        except (S.ShapeError, GenerateError, ValueError, ZeroDivisionError):
            return None
    xs = [lo + (hi - lo) * i / 96.0 for i in range(97)]
    vs = [g(x) for x in xs]
    for i in range(96):
        u, v = vs[i], vs[i + 1]
        if u is None or v is None:
            continue
        if u == 0:
            return xs[i]
        if u * v < 0:
            a, b, fa = xs[i], xs[i + 1], u
            for _ in range(70):
                m = 0.5 * (a + b)
                fm = g(m)
                if fm is None:
                    break
                if fa * fm < 0:
                    b = m
                else:
                    a, fa = m, fm
            return 0.5 * (a + b)
    return None


def _solve_t(desc, e, name, params, tvals, ev, deadline):
    """Where the point `name` stands on its segment. sympy first (the three
    closed forms), the bounded scan second, and a refusal that names the
    band of values that WOULD land inside the segment third."""
    _tick(deadline, desc)

    def f(t):
        q = dict(tvals)
        q[name] = t
        P, U, _x = ev(params, q)
        return e.value_at(desc, P, U)

    t = _exact_t(desc, e, name, params, tvals, ev, deadline, f)
    if t is None:
        t = _root(f, 0.0, 1.0)
    if t is None:
        def q(x):
            p = dict(tvals)
            p[name] = x
            P, U, _x = ev(params, p)
            return _quantity(desc, e.datum, P, U)
        _contradiction(desc, e, "הנקודה %s" % name, 0.0, 1.0, q)
    if not MIN_T <= t <= MAX_T:
        _off_segment(desc, e, name, t, ev, params, tvals)
    return t


def _exact_t(desc, e, name, params, tvals, ev, deadline, f):
    """The closed forms, through sympy: a ratio along the segment, a length
    from one of its ends, and the wedge angle at a vertex. A root that comes
    out of algebra cannot drift, so it is tried first; anything else (or a
    sympy that will not close in the time left) falls through to `_root`."""
    dat = e.datum
    if dat is None:
        return None
    on = None
    for n, role, dd in _derived(desc):
        if n == name and role == "on":
            on = dd
            break
    if on is None:
        return None
    A, B = on.args[1], on.args[2]
    P, U, _x = ev(params, dict(tvals, **{name: 0.5}))
    try:
        import sympy
    except Exception:
        return None
    _tick(deadline, desc)              # v6.7: no "not enough time left" path
    t = sympy.Symbol("t", real=True)
    pa, pb = P[A], P[B]
    Gx = sympy.Float(pa[0]) + t * sympy.Float(pb[0] - pa[0])
    Gy = sympy.Float(pa[1]) + t * sympy.Float(pb[1] - pa[1])
    expr = None
    val = e.value if e.value is not None else dat.value
    try:
        if dat.role == "ratio" and set(dat.args) == set([A, B, name]):
            p, q = val
            if dat.args[0] == A and dat.args[1] == name:
                return float(sympy.Rational(int(p), int(p) + int(q)))
            if dat.args[0] == name and dat.args[1] == B:
                return float(sympy.Rational(int(q), int(p) + int(q)))
        if dat.role == "length" and set(dat.args) == set([A, name]):
            L = _d(pa, pb)
            return float(sympy.Float(val * U) / sympy.Float(L))
        if dat.role == "length" and set(dat.args) == set([B, name]):
            L = _d(pa, pb)
            return float(1 - sympy.Float(val * U) / sympy.Float(L))
        if dat.role == "angle3" and name in dat.args:
            x, v, z = dat.args
            if v == name:
                return None
            other = z if x == name else x
            if other == name or v not in P or other not in P:
                return None
            V = P[v]
            ux, uy = sympy.Float(P[other][0] - V[0]), sympy.Float(P[other][1] - V[1])
            wx, wy = Gx - sympy.Float(V[0]), Gy - sympy.Float(V[1])
            dot = ux * wx + uy * wy
            expr = dot - sympy.cos(sympy.rad(sympy.Float(val))) * \
                sympy.sqrt(ux ** 2 + uy ** 2) * sympy.sqrt(wx ** 2 + wy ** 2)
        if expr is None:
            return None
        sols = sympy.solve(sympy.Eq(expr, 0), t)
    except Exception:
        return None
    best = None
    for s in sols:
        try:
            v = complex(sympy.N(s))
        except Exception:
            continue
        if abs(v.imag) > 1e-9 or not -0.001 <= v.real <= 1.001:
            continue
        r = abs(f(min(1.0, max(0.0, v.real))))
        if r < 1.0 and (best is None or r < best[0]):
            best = (r, min(1.0, max(0.0, v.real)))
    return None if best is None else best[1]


# ------------------------------------------------------------- refusals ---
def _tick(deadline, desc):
    """v6.7: the wall clock is a SAFETY NET. Every step is bounded by a
    count, so passing the deadline means the machine is overloaded or
    stalled -- it raises GenerateMachineError (not a refusal), naming cap=."""
    if time.monotonic() > deadline:
        raise GenerateMachineError(
            "generate: MACHINE PROBLEM, not a refusal -- %r ran over the "
            "safety-net cap of the wall clock (the solver's work is bounded "
            "by counts, so this is the machine: overloaded or stalled). Run "
            "it again, or give a bigger cap= (seconds)" % desc.text[:60])


def _quantity(desc, dat, P, U):
    """The datum's OWN quantity on a configuration, as (value, kind).

    r1 (S2-6-nonsense-band-in-refusal): the band a refusal prints used to be
    built from the solver's NORMALISED residual — value_at() divides by the
    datum's tolerance — and then multiplied by the DEGREE tolerance and
    added to the datum's value whatever its kind. For an angle that happens
    to be the right arithmetic; for a length, a ratio or a perpendicularity
    it mixes three units, and the refusal named "the values you can draw
    here" with a negative length or with degrees for a datum that has no
    value at all. A refusal that pushes the author somewhere (doctrine 4)
    has to push him at a number he can use, so the quantity is measured
    DIRECTLY here, in the unit the sentence is written in."""
    if dat is None:
        return None
    a, r = dat.args, dat.role
    try:
        if r == "angle3":
            return (_ang(P[a[0]], P[a[1]], P[a[2]]), "deg")
        if r == "angle1":
            i = _pairs(desc)[a[0]]
            u, w = _neighbours(desc, i)
            return (_ang(P[desc.letters[u]], P[a[0]], P[desc.letters[w]]),
                    "deg")
        if r == "length":
            if not U:
                return None
            return (_d(P[a[0]], P[a[1]]) / U, "len")
        if r in ("equal", "ratio"):
            den = _d(P[a[2]], P[a[3]])
            if den <= 1e-9:
                return None
            return (_d(P[a[0]], P[a[1]]) / den, "ratio")
        if r in ("parallel", "perp"):
            return (_between(P[a[0]], P[a[1]], P[a[2]], P[a[3]]), "between")
        if r == "bisector":
            V, E = a[2], a[1]
            i = _pairs(desc)[V]
            u, w = _neighbours(desc, i)
            return (_ang(P[desc.letters[u]], P[V], P[E])
                    - _ang(P[E], P[V], P[desc.letters[w]]), "gap")
    except (KeyError, ZeroDivisionError, ValueError):
        return None
    return None


def _between(p, q, r, s):
    """The angle between two segments, 0 to 90 degrees."""
    a = math.degrees(math.atan2(q[1] - p[1], q[0] - p[0]))
    b = math.degrees(math.atan2(s[1] - r[1], s[0] - r[0]))
    dd = abs(a - b) % 180.0
    return min(dd, 180.0 - dd)


_BAND_SAY = {
    "deg": "הזוויות שאפשר לשרטט כאן: %.3g° עד %.3g°",
    "len": "האורכים שאפשר לשרטט כאן: %.3g עד %.3g",
    "ratio": "היחס בין שני הקטעים יוצא בין %.3g ל-%.3g",
    "between": "הזווית בין שני הקטעים יוצאת בין %.3g° ל-%.3g°",
    "gap": "ההפרש בין שתי חצאי הזוויות יוצא בין %.3g° ל-%.3g°",
}


def _band_of(desc, dat, q, lo, hi):
    """What the drawing CAN give: the datum's own quantity at the two ends
    of the band and in the middle, so a refusal can say "between 6.3 and 45"
    instead of "no" — and in the datum's own unit."""
    out, kind = [], None
    for x in (lo + 1e-6, 0.5 * (lo + hi), hi - 1e-6):
        try:
            v = q(x)
        except Exception:
            v = None
        if not v or v[0] is None:
            continue
        out.append(float(v[0]))
        kind = v[1]
    if len(out) < 2 or kind is None:
        return None
    return (min(out), max(out), kind)


def _band_text(band):
    if not band:
        return ""
    lo, hi, kind = band
    say = _BAND_SAY.get(kind)
    if say is None:
        return ""
    return " (%s)" % (say % (lo, hi))


def _contradiction(desc, e, who, lo, hi, q):
    band = ""
    if q is not None and lo is not None:
        band = _band_text(_band_of(desc, e.datum, q, lo, hi))
    _bad("הנתון %r אינו מתיישב עם שאר התיאור%s" % (e.text, band),
         "שנו את הערך, ותרו על נתון אחר שסותר אותו, או הוסיפו דרגת חופש "
         "(אל תקבעו את כל הצלעות והזוויות יחד)")


def _off_segment(desc, e, name, t, ev, params, tvals):
    def q(x):
        p = dict(tvals)
        p[name] = x
        P, U, _x = ev(params, p)
        return _quantity(desc, e.datum, P, U)
    say = _band_text(_band_of(desc, e.datum, q, MIN_T, MAX_T))
    if say:
        say = " הערכים ש-%s נופלת בהם בתוך הקטע —%s." % (name, say)
    _bad("הנקודה %s יוצאת ב-%.3f לאורך הקטע — כמעט על הקודקוד"
         % (name, t),
         "נקודה שנוגעת בקודקוד אינה נקראת בדפוס ואינה מה שהשאלה מתארת.%s"
         % say)


# ================================================================ drawing ===
def _num(v):
    return "%g" % float(v)


def _shape_kwargs(desc, params):
    kw = dict(params)
    kw.pop("n", None)
    if desc.kind == "polygon":
        kw["n"] = len(desc.letters)
    if desc.kind == "triangle":
        kw["variant"] = "sss"
    elif desc.kind == "trapezoid":
        kw["variant"] = desc.variant or "scalene"
    return kw


def _shared(seg1, seg2):
    for c in seg1:
        if c in seg2:
            return c
    return None


def _on_segment(P, p, q, x, tol=1e-6):
    """Is x on the drawn piece p..q?"""
    ux, uy = q[0] - p[0], q[1] - p[1]
    L2 = ux * ux + uy * uy
    if L2 <= 1e-12:
        return False
    t = ((x[0] - p[0]) * ux + (x[1] - p[1]) * uy) / L2
    if not -1e-6 <= t <= 1 + 1e-6:
        return False
    fx, fy = p[0] + t * ux, p[1] + t * uy
    return math.hypot(x[0] - fx, x[1] - fy) <= 1e-4


def _ensure_rays(desc, sol, g, d, drawn):
    """An angle is a claim about two RAYS. `∠GBA` on a square names the
    segment BG, and a sheet always draws it — without it the reader sees an
    arc leaning on nothing, and `svgcheck._arcs`, which measures a wedge from
    the strokes it stands on, cannot check the number either. So a ray the
    figure does not already contain is DRAWN, not assumed."""
    P = sol.P
    for dat in desc.data:
        if dat.role not in ("angle3", "bisector") or not dat.drawn:
            continue
        if dat.role == "bisector":
            continue
        X, V, Z = dat.args[0], dat.args[1], dat.args[2]
        for other in (X, Z):
            if any(_on_segment(P, P[p], P[q], P[V]) and
                   _on_segment(P, P[p], P[q], P[other]) for p, q in drawn):
                continue
            g.line(S._H(g, d, V), S._H(g, d, other), w=1.4)
            drawn.append((V, other))


def _drawn_pairs(desc):
    """The segments the base shape itself draws."""
    n = len(desc.letters)
    if desc.kind == "circle" or n < 3:
        return []
    return [(desc.letters[i], desc.letters[(i + 1) % n]) for i in range(n)]


def _arc_n(reg, value):
    """The stroke count for an angle of this size. On the page the NUMBER OF
    STROKES is the claim 'equal to the other angles marked the same way'
    (svgcheck.arc_equality), so one value gets one count, and two different
    values can never share one."""
    for v, n in reg.items():
        if abs(v - value) <= max(0.6, 0.03 * max(v, value)):
            return n
    n = len(reg) + 1
    if n > 3:
        _bad("השרטוט מסמן %d גדלים שונים של זוויות" % n,
             "יותר משלושה סוגי קשתות אינם נקראים בדפוס: סמנו פחות זוויות "
             "בשרטוט אחד ('(לא בשרטוט)' על נתון שאינו חייב להופיע), או "
             "פצלו את השאלה לשני שרטוטים")
    reg[value] = n
    return n


def _draw(desc, sol, rotate, fam, size, override=None):
    """The configuration -> shapekit calls, in the one order that works:
    the base shape, the points it builds, the segments that join them, and
    only then the marks that make a claim about all of it."""
    override = override or {}
    bis = []
    kw = _shape_kwargs(desc, sol.params)
    _eq, _rt = _given(desc)
    g, d = S.shape(desc.kind, rotate=rotate, fam=fam,
                   names=desc.letters, size=size,
                   given={"equal": _eq, "right": sorted(_rt)}, **kw)

    for name, role, dat in _derived(desc):
        if role == "on":
            S.point_at(g, d, dat.args[1], dat.args[2], sol.tvals[name], name)
        elif role == "midpoint":
            t = sol.tvals.get(name, 0.5)
            if abs(t - 0.5) < 1e-9:
                S.midpoint(g, d, dat.args[1], dat.args[2], name)
            else:
                # a midpoint that is not the middle: the drawing must still
                # CLAIM it is (that is the mistake the reader has to find),
                # so the point is placed and the two ticks are put on by hand
                S.point_at(g, d, dat.args[1], dat.args[2], t, name)
                _ticks_unchecked(g, d, [(dat.args[1], name),
                                        (name, dat.args[2])])
        elif role == "median":
            S.median(g, d, dat.args[0], dat.args[2], dat.args[3], name=name)
        elif role == "altitude":
            S.altitude(g, d, dat.args[0], dat.args[2], dat.args[3], name=name)
        elif role == "bisector":
            a, b, t = _bisector_side(desc, dat, sol.P)
            S.point_at(g, d, a, b, t, name)
        elif role == "foot":
            S.perp_foot(g, d, dat.args[1], dat.args[2], dat.args[3],
                        name=name, draw=False)
        elif role == "meet":
            S.diagonals(g, d, label=name)

    drawn = _drawn_pairs(desc)
    for dat in desc.data:
        if dat.role == "diagonals":
            S.diagonals(g, d, label=None, dot=False)
            if len(desc.letters) == 4:
                drawn += [(desc.letters[0], desc.letters[2]),
                          (desc.letters[1], desc.letters[3])]
        elif dat.role == "diagonal":
            g.line(d[dat.args[0]], d[dat.args[1]], dash="4,3", w=1.2)
            drawn.append((dat.args[0], dat.args[1]))
        elif dat.role == "bisector":
            V, E = dat.args[2], dat.args[1]
            if dat.args[0] != V:
                _bad("%r מתחיל ב-%s ואינו יוצא מהקודקוד %s"
                     % (dat.text, dat.args[0], V),
                     "חוצה זווית יוצא מהקודקוד עצמו: כתבו '%s%s חוצה זווית %s'"
                     % (V, E, V))
            if E not in d:
                _bad("הנקודה %s של חוצה הזווית אינה מוגדרת" % E,
                     "הוסיפו משפט שמגדיר אותה, למשל '%s על %s'"
                     % (E, _D._away_from(dat, desc.letters)))
            g.line(d[V], d[E], dash="4,3", w=1.2)
            drawn.append((V, E))
            bis.append((V, E))
        elif dat.role == "incircle":
            S.incircle(g, d)
        elif dat.role == "circumcircle":
            S.circumcircle(g, d)

    for name, role, dat in _derived(desc):
        if role == "meet":
            drawn += [(desc.letters[0], desc.letters[2]),
                      (desc.letters[1], desc.letters[3])]
        elif role in ("median", "altitude"):
            drawn.append((dat.args[0], name))
    _variant_marks(desc, g, d)
    _ensure_rays(desc, sol, g, d, drawn)

    reg = {}
    for V, E in bis:
        i = _pairs(desc)[V]
        u, w = _neighbours(desc, i)
        half = _ang(sol.P[desc.letters[u]], sol.P[V], sol.P[E])
        n = _arc_n(reg, half)
        S.angle_arc(g, d, V, desc.letters[u], E, n=n)
        S.angle_arc(g, d, V, E, desc.letters[w], n=n)

    for dat in desc.data:
        if not dat.drawn:
            continue
        a = dat.args
        if dat.role in ("angle3", "angle1"):
            v = dat.value
            if dat.role == "angle1":
                i = _pairs(desc)[a[0]]
                u, w = _neighbours(desc, i)
                V, X, Z = a[0], desc.letters[u], desc.letters[w]
            else:
                V, X, Z = a[1], a[0], a[2]
            wedge = _ang(sol.P[X], sol.P[V], sol.P[Z])
            if wedge < MIN_WEDGE:
                # r1 (S2-3): the refusal no longer offers "drop the mark".
                # Everything above MIN_WEDGE is DRAWN — narrow wedges with
                # the number called out beside the arc — so what is left
                # here really is unreadable at any size, and the fix is a
                # value, a bigger figure or a second drawing, never less
                # information.
                _bad("הזווית %s%s%s יוצאת %.1f° — צרה מכדי לשאת קשת בכלל"
                     % (X, V, Z, wedge),
                     "מתחת ל-%g° שתי השוקיים מודפסות כקו אחד: שנו את הנתון "
                     "כך שהזווית תהיה מעל %g° (מעל %g° היא מסומנת בקריאה "
                     "החוצה), או שרטטו את הזווית הזו בהגדלה נפרדת לצד "
                     "השרטוט" % (MIN_WEDGE, MIN_WEDGE, CALLOUT_WEDGE))
            S.angle_arc(g, d, V, X, Z, text=_num(v) + "°",
                        n=_arc_n(reg, wedge),
                        lead=wedge < CALLOUT_WEDGE)
        elif dat.role == "length":
            S.side_label(g, d, a[0], a[1], _num(dat.value))
        elif dat.role == "equal":
            _claim_mark(g, d, "ticks", (a[0], a[1]), (a[2], a[3]))
        elif dat.role == "parallel":
            _claim_mark(g, d, "parallel", (a[0], a[1]), (a[2], a[3]))
        elif dat.role == "perp":
            V = _shared(a[:2], a[2:])
            if V is None:
                _bad("%r — הקטעים אינם נפגשים בנקודה שיש לה שם" % dat.text,
                     "סמנו את נקודת החיתוך ('M מפגש האלכסונים', או "
                     "'H היטל C על AB') וכתבו את האנך דרכה")
            X = a[0] if a[1] == V else a[1]
            Z = a[2] if a[3] == V else a[3]
            S.right_angle(g, d, V, X, Z)
    return g, d


def _free_arrow_n(g):
    used = set(kw["n"] for kind, kw in g.ops if kind == "parallel")
    for n in (1, 2, 3):
        if n not in used:
            return n
    return 1


def _mark_n(g, kind, a, b):
    """The count a mark of this kind already gives the segment a-b, or None.
    Handles, not letters, and unordered: the house marks of a trapezoid draw
    the chevrons on AB and on DC, and `AB \u2225 CD` names the same two sides."""
    seg = frozenset((a, b))
    for k, kw in g.ops:
        if k == kind and frozenset((kw["a"], kw["b"])) == seg:
            return kw["n"]
    return None


def _claim_mark(g, d, kind, s1, s2):
    """Draw the datum's claim about two segments — ONCE.

    r1 (S2-1-duplicate-marks): a datum that restates a mark the SHAPE
    already carries was drawn a second time with a count nobody had used
    yet, so one claim stood twice in two counts. On a square 'AB = CD' that
    printed n=1 on all four sides AND n=2 on AB and CD: a reader reads two
    lengths on a figure that has one. On a trapezoid 'AB \u2225 CD' the house
    chevrons (AB, DC) and the datum's (AB, CD) met on DC pointing at each
    other. A count IS the claim, so the datum joins the group that already
    states it instead of opening a rival one:

      * both segments already carry the same count -> the figure says it;
      * one of them carries a count -> the other joins THAT group (they are
        equal/parallel, so everything in the group is too);
      * neither -> a free count, as before."""
    a1, b1 = S._H(g, d, s1[0]), S._H(g, d, s1[1])
    a2, b2 = S._H(g, d, s2[0]), S._H(g, d, s2[1])
    n1, n2 = _mark_n(g, kind, a1, b1), _mark_n(g, kind, a2, b2)
    if n1 is not None and n1 == n2:
        return None
    if n1 is not None and n2 is not None:
        # the drawing already gives these two segments DIFFERENT counts —
        # it already says they are not the same. (_static_checks refuses the
        # ordinary way in; this is the net under it, so no figure can ever
        # leave here claiming both.)
        _bad("%r נוגד סימון שכבר בשרטוט: %s%s ו-%s%s נושאים מספר סימנים שונה"
             % (" ".join(s1) + " / " + " ".join(s2), s1[0], s1[1],
                s2[0], s2[1]),
             "מחקו את הנתון, או הכריזו על צורה שבה השוויון הזה נכון")
    draw = S.equal_ticks if kind == "ticks" else S.parallel_marks
    if n1 is not None:
        return draw(g, d, [s2], n=n1)
    if n2 is not None:
        return draw(g, d, [s1], n=n2)
    n = (S._free_tick_n(g, 1) or 1) if kind == "ticks" else _free_arrow_n(g)
    return draw(g, d, [s1, s2], n=n)


def _ticks_unchecked(g, d, pairs):
    """Equality ticks on pieces that are NOT equal. Only `violate` reaches
    this: the ticks are the lie the reader has to catch, and the figure that
    carries them is tagged `<!--critique:find_error-->`, so the giveaway
    guard will not let it stand beside an ordinary item."""
    n = S._free_tick_n(g, 1) or 1
    for P, Q in pairs:
        g.ticks(S._H(g, d, P), S._H(g, d, Q), n)


def _variant_marks(desc, g, d):
    """What the declared kind CLAIMS, drawn as marks — and therefore
    re-measured by svgcheck against the drawing. A triangle is built from
    three solved sides, so this is the only place its 'isosceles' is stated,
    and the engine checks it."""
    if desc.kind != "triangle":
        return
    A, B, C = desc.letters
    if desc.variant == "iso":
        n = S._free_tick_n(g, 1) or 1
        S.equal_ticks(g, d, [(C, A), (C, B)], n=n)
    elif desc.variant == "equilateral":
        n = S._free_tick_n(g, 1) or 1
        S.equal_ticks(g, d, [(A, B), (B, C), (C, A)], n=n)
    elif desc.variant == "right":
        S.right_angle(g, d, A, B, C)


# =========================================================== the read-back ===
_POLY = re.compile(r'<polygon[^>]*points="([^"]+)"')
_CIRC = re.compile(r'<circle[^>]*cx="(-?[\d.]+)"[^>]*cy="(-?[\d.]+)"'
                   r'[^>]*r="(-?[\d.]+)"')
_TEXT = re.compile(r"<text[^>]*>(.*?)</text>", re.S)
_TAGS = re.compile(r"<[^>]+>")


def _svg_points(svg):
    m = _POLY.search(svg)
    pts = []
    if m:
        for tok in m.group(1).split():
            x, y = tok.split(",")
            pts.append((float(x), float(y)))
    dots = [(float(a), float(b)) for a, b, r in _CIRC.findall(svg)
            if float(r) <= 4.0]
    texts = [_TAGS.sub("", t).strip() for t in _TEXT.findall(svg)]
    return pts, dots, texts


def _affine(src, dst):
    """The least-squares affine map src -> dst. Used ONLY to say which dot in
    the finished SVG is which point; every number the read-back reports is
    measured on the SVG's own coordinates."""
    n = len(src)
    if n < 3:
        return None
    Sxx = sum(p[0] * p[0] for p in src)
    Sxy = sum(p[0] * p[1] for p in src)
    Syy = sum(p[1] * p[1] for p in src)
    Sx = sum(p[0] for p in src)
    Sy = sum(p[1] for p in src)
    A = [[Sxx, Sxy, Sx], [Sxy, Syy, Sy], [Sx, Sy, float(n)]]
    out = []
    for k in (0, 1):
        b = [sum(s[0] * t[k] for s, t in zip(src, dst)),
             sum(s[1] * t[k] for s, t in zip(src, dst)),
             sum(t[k] for t in dst)]
        sol = _lin3(A, b)
        if sol is None:
            return None
        out.append(sol)
    return out


def _lin3(A, b):
    M = [row[:] + [b[i]] for i, row in enumerate(A)]
    for i in range(3):
        p = max(range(i, 3), key=lambda r: abs(M[r][i]))
        if abs(M[p][i]) < 1e-12:
            return None
        M[i], M[p] = M[p], M[i]
        for r in range(3):
            if r == i:
                continue
            f = M[r][i] / M[i][i]
            for c in range(i, 4):
                M[r][c] -= f * M[i][c]
    return [M[i][3] / M[i][i] for i in range(3)]


_MEASURED = ("angle3", "angle1", "length", "equal", "ratio", "parallel",
             "perp", "bisector")


def _read_back(svg, desc, sol, override=None, violated=None):
    """Read the FINISHED figure, re-measure every datum on it, and RETURN
    how many data were re-measured.

    Doctrine 3: a check that proves a figure means what it says may not use
    the numbers that built it. The base vertices come from the emitted
    `<polygon>`, the built points from the emitted dots, and every angle and
    every ratio is computed from THOSE coordinates. Lengths have no absolute
    scale in a drawing, so the first length datum sets the scale and the
    others are checked against it."""
    override = override or {}
    pts, dots, texts = _svg_points(svg)
    if desc.kind == "circle":
        # r1 (S2-8-read-back-silent-skips): a circle used to return here,
        # having read nothing, and the caller could not tell "verified" from
        # "not looked at". It reads what a circle HAS instead, and says how
        # many data it re-measured.
        if "<circle" not in svg:
            _bad("השרטוט הסופי אינו מכיל מעגל",
                 "הצורה לא שורטטה כפי שהתיאור מכריז — דווחו על כך, זו תקלה "
                 "במנוע ולא בנתונים")
        return 0
    if len(pts) != len(desc.letters):
        _bad("השרטוט הסופי מכיל %d קודקודים במקום %d"
             % (len(pts), len(desc.letters)),
             "הצורה לא שורטטה כפי שהתיאור מכריז — דווחו על כך, זו תקלה "
             "במנוע ולא בנתונים")
    M = dict(zip(desc.letters, pts))
    frame = [sol.P[c] for c in desc.letters]
    T = _affine(frame, pts)
    if T is None and _derived(desc):
        # r1 (S2-8): this used to `break` out of the loop, leaving the built
        # points out of M — and the datum loop below then SKIPPED every
        # datum that names one, so a figure nobody could read back counted
        # as read back. A fit that will not close on the emitted polygon is
        # an engine fault, and it is reported as one.
        _bad("אי אפשר לזהות את הנקודות הבנויות בשרטוט הסופי",
             "הקודקודים שיצאו אינם מתאימים לצורה שנפתרה — דווחו על כך, זו "
             "תקלה במנוע ולא בנתונים")
    for name, role, _dat in _derived(desc):
        want = sol.P[name]
        x = T[0][0] * want[0] + T[0][1] * want[1] + T[0][2]
        y = T[1][0] * want[0] + T[1][1] * want[1] + T[1][2]
        near = sorted(dots, key=lambda p: _d(p, (x, y)))
        if not near or _d(near[0], (x, y)) > 6.0:
            _bad("הנקודה %s אינה מופיעה בשרטוט הסופי" % name,
                 "כל נקודה שהתיאור בונה חייבת להיות מסומנת — דווחו על כך, "
                 "זו תקלה במנוע ולא בנתונים")
        M[name] = near[0]

    U = None
    for dat in desc.data:
        if dat.role == "length" and dat.args[0] in M and dat.args[1] in M:
            U = _d(M[dat.args[0]], M[dat.args[1]]) / \
                float(override.get(dat.text, dat.value))
            break
    checked = 0
    for dat in desc.data:
        if dat.role not in _MEASURED:
            continue
        if not set(dat.args) <= set(M):
            # r1 (S2-8): a datum whose points the reader could not find is
            # an ENGINE fault, not a datum to pass over in silence.
            _bad("הנתון %r מדבר על נקודה שאינה מסומנת בשרטוט הסופי (%s)"
                 % (dat.text, ", ".join(sorted(set(dat.args) - set(M)))),
                 "כל נקודה שנתון מדבר עליה חייבת להיות מסומנת — דווחו על "
                 "כך, זו תקלה במנוע ולא בנתונים")
        if dat.role == "length" and U is None:
            continue
        checked += 1
        # a violated datum is re-measured against the value the drawing was
        # SOLVED for: the figure is deliberately wrong, and the read-back
        # proves it is wrong in exactly the one way that was asked for
        val = override.get(dat.text, dat.value)
        r, kindn = _resid(desc, dat, M, U or 1.0, override=val)
        tol = 0.25 if kindn == "deg" else 0.01
        if abs(r) > tol:
            _bad("השרטוט הסופי אינו מקיים את %r (סטייה %.3g)" % (dat.text, r),
                 "הנתונים סותרים זה את זה, או שהצורה שהוכרזה אינה יכולה "
                 "לשאת אותם — שנו ערך אחד ונסו שוב")
        if dat.drawn and dat.role in ("angle3", "angle1") \
                and dat.text != violated:
            want = _num(dat.value) + "°"
            if want not in texts:
                _bad("המספר %s אינו מודפס בשרטוט" % want,
                     "נתון שאינו מסומן אינו נתון: הוסיפו '(לא בשרטוט)' אם "
                     "הוא אינו אמור להופיע")
    return checked


# ======================================================= static refusals ===
def _house_groups(desc, kind="ticks"):
    """What the DECLARED shape's own marks already say: the groups of sides
    its house marks put the same count on, as sets of frozenset(letters).

    Read off a probe of the shape itself rather than written out here, so it
    cannot drift from what shapekit draws."""
    try:
        params, _free, _rest = _bind(desc, random.Random(0))
        g, d = S.shape(desc.kind, rotate=0.0, fam="probe",
                       names=desc.letters, **_shape_kwargs(desc, params))
    except (S.ShapeError, GenerateError, AssertionError, KeyError):
        return []
    by_n = {}
    where = dict((d[c], c) for c in desc.letters if c in d)
    for k, kw in g.ops:
        if k != kind:
            continue
        a, b = where.get(kw["a"]), where.get(kw["b"])
        if a and b:
            by_n.setdefault(kw["n"], set()).add(frozenset((a, b)))
    return [v for _k, v in sorted(by_n.items()) if len(v) > 1]


def _say_groups(groups):
    return "; ".join(" = ".join("".join(sorted(pair)) for pair in
                                sorted(gr, key=lambda p: "".join(sorted(p))))
                     for gr in groups)


def _static_checks(desc):
    """Refusals a reader of the SENTENCES alone can make — before any solve,
    so the message is about the description and not about a shapekit
    parameter the author never wrote."""
    for dat in desc.data:
        if dat.role != "bisector":
            continue
        V = dat.args[2]
        if V not in desc.letters:
            continue
        for other in desc.data:
            # r1 (S2-5): 'E על AC' + 'AE חוצה זווית A' — the bisector from A
            # leaves A, so on a side THROUGH A its only point is A itself.
            if other.role == "on" and other.args[0] == dat.args[1] \
                    and V in other.args[1:]:
                _bad("%r מציב את %s על צלע שעוברת דרך %s, ו-%r יוצא מ-%s "
                     "עצמו" % (other.text, dat.args[1], V, dat.text, V),
                     "חוצה הזווית פוגש צלע שאינה עוברת דרך %s: כתבו "
                     "'%s על %s', או מחקו את המשפט הזה ותנו ל-%s להיבנות "
                     "לבד" % (V, dat.args[1],
                              _D._away_from(dat, desc.letters), dat.args[1]))
    groups = None
    for dat in desc.data:
        if dat.role != "equal" or not set(dat.args) <= set(desc.letters):
            continue
        if groups is None:
            groups = _house_groups(desc)
        if not groups:
            continue
        s1, s2 = frozenset(dat.args[:2]), frozenset(dat.args[2:])
        g1 = [i for i, gr in enumerate(groups) if s1 in gr]
        g2 = [i for i, gr in enumerate(groups) if s2 in gr]
        # r1 (S2-7-kite-equal-pair-unstated): the shape's own marks say
        # these two sides are NOT the same length. The old path let the
        # equation squeeze the base parameters together until shapekit
        # refused in English about a rhombus.
        if g1 and g2 and g1 != g2:
            _bad("הנתון %r סותר את הצורה שהוכרזה (%s): הסימונים שלה כבר "
                 "אומרים ש-%s%s ו-%s%s אינן שוות"
                 % (dat.text, _D.hebrew(desc.kind, desc.variant),
                    dat.args[0], dat.args[1], dat.args[2], dat.args[3]),
                 "ב-%s %s שוות: %s. כתבו אחד מאלה, או הכריזו על צורה "
                 "אחרת שבה השוויון שביקשתם נכון (מעוין, ריבוע)"
                 % (_D.hebrew(desc.kind, desc.variant), desc.letters,
                    _say_groups(groups)))


# ============================================================= readable ===
def _readable(desc, sol):
    """A configuration a reader can actually read. Each refusal names the
    fix, because the cheap way out of a refusal must never be deleting
    information (doctrine 4)."""
    P = sol.P
    names = [c for c in desc.points() if c in P]
    for i, x in enumerate(names):
        for y in names[i + 1:]:
            if _d(P[x], P[y]) < MIN_GAP:
                # r1 (S2-3): no "give up one of them" — doctrine 4. The
                # letters are the question's; only their POSITIONS may move.
                _bad("הנקודות %s ו-%s יוצאות במרחק %.2f יחידות זו מזו"
                     % (x, y, _d(P[x], P[y])),
                     "שתי אותיות קרובות כל כך נקראות כאחת: שנו את הנתון "
                     "שקובע את מקומן (זווית אחרת, יחס אחר) כך שיתרחקו "
                     "מעל %g יחידות, או הגדילו את השרטוט (size=) — אל "
                     "תוותרו על אף נקודה" % MIN_GAP)
    n = len(desc.letters)
    if desc.kind not in ("circle",) and n >= 3:
        for i in range(n):
            a = desc.letters[(i - 1) % n]
            v = desc.letters[i]
            b = desc.letters[(i + 1) % n]
            ang = _ang(P[a], P[v], P[b])
            if ang < MIN_VERTEX:
                _bad("הזווית בקודקוד %s יוצאת %.1f°" % (v, ang),
                     "מתחת ל-%g° הצורה מודפסת כרסיס והאותיות מתנגשות: "
                     "שנו את הנתונים לצורה עגולה יותר" % MIN_VERTEX)


# v6.4 T2-9 r1: ONE reader's rule means ONE pair of numbers. These were
# retyped here as literals, so tuning shapekit's would have left this layer
# judging by the old value and no test could see the two disagree -- the
# description layer would accept a figure shapekit refuses, or the reverse.
# They are shapekit's, by reference.
ACC_LEN = S.ACC_LEN      # two sides this close read as "equal" to a reader
ACC_DEG = S.ACC_DEG      # ... and an angle this close to 90 reads as right


def _given(desc):
    """(equal side groups, right-angle vertices) this DESCRIPTION gives --
    its shape word, its variant and its data. v6.4 T2-9: the sweep below
    and the `given=` shapekit gets both read it, so the two layers agree on
    what the question said; describe builds every triangle through
    variant='sss', and 'משולש שווה שוקיים' is a datum all the same."""
    n = len(desc.letters)
    if desc.kind == "circle" or n < 3:
        return [], set()
    groups, right = S.declared(desc.kind, {"variant": desc.variant}, n)
    groups = [list(g) for g in groups]
    right = set(right)
    idx = dict((frozenset((desc.letters[i], desc.letters[(i + 1) % n])), i)
               for i in range(n))
    for dat in desc.data:
        if dat.role != "equal":
            continue
        k1 = idx.get(frozenset((dat.args[0], dat.args[1])))
        k2 = idx.get(frozenset((dat.args[2], dat.args[3])))
        if k1 is None or k2 is None:
            continue
        g1 = [g for g in groups if k1 in g]
        g2 = [g for g in groups if k2 in g]
        merged = sorted(set((g1[0] if g1 else [k1]) + (g2[0] if g2 else [k2])))
        groups = [g for g in groups if g not in g1 and g not in g2]
        groups.append(merged)
    if any(dd.role == "perp" for dd in desc.data) or desc.variant == "right" \
            or any(dd.role in ("angle3", "angle1")
                   and abs(dd.value - 90.0) < 1e-6 for dd in desc.data):
        right = set(range(n))
    return groups, right


def _accidents(desc, sol):
    """A drawing may not let the reader infer a datum the question never
    gave. The author's own sheets say it at the top of every page:
    "השרטוטים להמחשה בלבד - אין להסיק מהם נתונים שלא נכתבו או סומנו".

    A free configuration that comes out looking isosceles, or with a corner
    that reads as a right angle, is therefore rejected — the seeded retry
    simply draws another one. When the DATA itself makes the figure look
    that way the refusal names the fix, because then it is the question that
    misleads, and only the author can decide."""
    P = sol.P
    n = len(desc.letters)
    if desc.kind == "circle" or n < 3:
        return
    # v6.4 T2-9 (pgram-reads-as-rhombus): EVERY shape is swept, not only
    # triangles. A parallelogram whose adjacent sides landed within 5% of
    # each other was drawn as a visual rhombus while its own house ticks
    # (n=1 on AB/DC, n=2 on AD/BC) claimed two different lengths on two
    # sides the reader measures as the same -- 34 of ~360 figures in the
    # verifier's sweep, with svgcheck.problems() == [] on every one. The
    # reader's rule is one rule, so it lives in shapekit.accidents and both
    # layers ask it; only the message is this layer's, in Hebrew.
    groups, right = _given(desc)
    pts = [P[c] for c in desc.letters]
    for row in S.accidents(pts, groups, right, S.ACC_LEN, S.ACC_DEG):
        if row[0] == "right":
            _, i, ang = row
            _bad("הזווית בקודקוד %s יוצאת %.1f° — נקראת כזווית ישרה"
                 % (desc.letters[i], ang),
                 "השרטוט יגרום לתלמיד להסיק זווית ישרה שלא ניתנה: שנו "
                 "את הנתונים, או כתבו את הזווית הישרה במפורש "
                 "('∠%s = 90°' או 'XY ⊥ YZ')" % desc.letters[i])
        _, i, j, L1, L2 = row
        if desc.kind == "triangle":
            _bad("שתי צלעות יוצאות באורך כמעט שווה (%.2f ו-%.2f)" % (L1, L2),
                 "שרטוט כזה נקרא כמשולש שווה-שוקיים, והתלמיד יסיק נתון שלא "
                 "ניתן: תנו אורכים שנבדלים ביותר מ-%g%%, או הכריזו 'משולש "
                 "שווה שוקיים'" % (100 * ACC_LEN))
        _bad("הצלעות %s%s ו-%s%s יוצאות כמעט שוות (%.2f ו-%.2f)"
             % (desc.letters[i], desc.letters[(i + 1) % n], desc.letters[j],
                desc.letters[(j + 1) % n], L1, L2),
             "השרטוט נקרא כצורה אחרת — מקבילית כזו נקראת מעוין — "
             "והסימונים שעליו טוענים שני אורכים שונים על צלעות שהעין מודדת "
             "כשוות: תנו אורכים שנבדלים ביותר מ-%g%%, או הכריזו על הצורה "
             "שבהגדרתה הן שוות (מעוין, ריבוע, משולש שווה-שוקיים)"
             % (100 * ACC_LEN))

# =============================================================== results ===
def _shape_key(desc, sol):
    """What the figure IS, with the scale divided out: the angle at every
    vertex and the position of every built point. Two configurations with
    the same key are the same drawing printed at two sizes — which is why a
    square whose side no datum gives is NOT an under-specified question, and
    a parallelogram whose angle no datum gives IS one."""
    P, n = sol.P, len(desc.letters)
    if desc.kind == "circle" or n < 3:
        return ("circle",) + tuple(round(float(sol.tvals[k]), 3)
                                   for k in sorted(sol.tvals))
    angs = tuple(round(_ang(P[desc.letters[(i - 1) % n]], P[desc.letters[i]],
                            P[desc.letters[(i + 1) % n]]), 1) for i in range(n))
    sides = [_d(P[desc.letters[i]], P[desc.letters[(i + 1) % n]])
             for i in range(n)]
    ref = max(sides) or 1.0
    return angs + tuple(round(x / ref, 3) for x in sides) + \
        tuple(round(float(sol.tvals[k]), 3) for k in sorted(sol.tvals))


class Figure(object):
    """One finished configuration: `.svg` is the figure, and everything else
    says how it came to be — so a level can record the seed, and a report
    can say which of the author's data did the work."""

    def __init__(self, svg, fam, seed, sol, desc, tag=None, violated=None,
                 measured=0):
        self.svg = svg
        self.sol = sol
        # r1 (S2-8): how many data the read-back re-measured ON THE FINISHED
        # SVG. A figure that says 0 while its description makes claims is a
        # read-back that did nothing, and a test can see that.
        self.measured = int(measured)
        self.shape_key = _shape_key(desc, sol)
        self.fam = fam
        self.seed = seed
        self.params = dict(sol.params)
        self.tvals = dict(sol.tvals)
        self.free = list(sol.free)
        self.description = desc
        self.tag = tag
        self.violated = violated

    @property
    def under_determined(self):
        return bool(self.free)

    def signature(self):
        return (tuple(sorted((k, round(float(v), 2))
                             for k, v in self.params.items())),
                tuple(sorted((k, round(float(v), 3))
                             for k, v in self.tvals.items())))

    def __str__(self):
        return self.svg

    def __repr__(self):
        return "Figure(%s, seed=%s%s)" % (
            self.fam, self.seed, ", violated=%r" % self.violated
            if self.violated else "")


def _has_freedom(desc):
    """Is there anything left for the RNG to choose? (A shape every datum
    pins, with every point fixed by an equation, is drawn once or not at
    all — retrying it would only burn the clock.)"""
    params, free, _rest = _bind(desc, random.Random(0))
    return bool(free) or any(role == "on" for _n, role, _d in _derived(desc))


def _fam_for(desc, sol, extra=""):
    roles = sorted(set(d.role for d in desc.data))
    key = hashlib.sha256(
        repr(sol.signature()).encode("utf-8")).hexdigest()[:6]
    name = "describe.%s%s" % (desc.kind,
                              "." + desc.variant if desc.variant else "")
    return "%s%s%s-%s" % (name, "".join("+" + r for r in roles), extra, key)


class Generator(object):
    """A description, and every figure it can become."""

    def __init__(self, text, seed=0, cap=30.0):
        self.description = text if isinstance(text, Description) else parse(text)
        self.seed = int(seed)
        self.cap = float(cap)
        self._first = None
        self._under = None

    # ------------------------------------------------------------- inside
    def _rng(self, seed):
        key = "%s|%d" % (self.description.text, int(seed))
        h = hashlib.sha256(key.encode("utf-8")).digest()[:8]
        return random.Random(int.from_bytes(h, "big"))

    def _one(self, seed, rotate=0.0, fam=None, size=None, override=None,
             tag=None, violated=None, extra=""):
        """One figure, end to end, under one deadline.

        A description that leaves something free gets a few ATTEMPTS: the
        same seeded RNG draws another configuration and the whole build runs
        again. That is not a retry loop hiding a bug — a bisector from A
        meets BC only when AB is the shorter side, and 'מקבילית ABCD; E על
        BC; AE חוצה זווית A' says nothing about which is shorter, so the
        first draw can be a parallelogram in which the sentence cannot be
        true. Determinism is untouched: one RNG, drawn in one order."""
        deadline = time.monotonic() + self.cap
        desc = self.description
        rng = self._rng(seed)
        _tick(deadline, desc)
        _static_checks(desc)
        tries = 8 if _has_freedom(desc) else 1
        last = None
        for attempt in range(tries):
            try:
                sol = _solve(desc, rng, deadline, override=override)
                _readable(desc, sol)
                _accidents(desc, sol)
                _tick(deadline, desc)
                use = fam or _fam_for(desc, sol, extra)
                g, _d_ = _draw(desc, sol, rotate, use, size,
                               override=override)
                if tag:
                    # the declaration reaches the ENGINE, not just the
                    # finished string: figkit and svgcheck both read it, and
                    # both then require the declared error to be there
                    g.critique = tag.split("critique:", 1)[-1]
                _tick(deadline, desc)
                svg = S.finish(g, use)
                if tag and "<!--critique:" not in svg:
                    svg = svg.replace("-->", "--><!--%s-->" % tag, 1)
                got = _read_back(svg, desc, sol, override=override,
                                 violated=violated)
                _tick(deadline, desc)
                return Figure(svg, use, seed, sol, desc, tag=tag,
                              violated=violated, measured=got)
            except (GenerateError, S.ShapeError, AssertionError) as e:
                last = e
                _tick(deadline, desc)
        raise type(last)("%s [אחרי %d תצורות שנוסו]" % (last, tries))

    # -------------------------------------------------------------- public
    def figure(self, rotate=0.0, fam=None, size=None):
        """The configuration this (description, seed) names. Deterministic."""
        f = self._one(self.seed, rotate=rotate, fam=fam, size=size)
        if self._first is None:
            self._first = f
        return f

    def alternatives(self, n=3, rotate=0.0, fam=None, size=None, tries=None):
        """Other configurations of the SAME data.

        A question whose data fixes the figure has exactly one, and the list
        comes back with one figure in it — that is the honest answer, not a
        failure. A question that comes back with several is under-specified
        in the author's own sheet: the reader could draw any of them, and
        `report()` says which datum is missing."""
        n = max(1, int(n))
        tries = tries or (6 * n + 12)
        out, seen = [], set()
        last = None
        for k in range(tries):
            try:
                f = self._one(self.seed + k, rotate=rotate, fam=fam, size=size)
            except (GenerateError, S.ShapeError, DescribeError) as e:
                last = e
                continue
            s = f.shape_key
            if s in seen:
                continue
            seen.add(s)
            out.append(f)
            if len(out) >= n:
                break
        if not out:
            raise GenerateError(
                "generate: אף תצורה לא עברה את הבדיקות — %s" % (last or ""))
        return out

    @property
    def free(self):
        if self._first is None:
            self.figure()
        return list(self._first.free)

    @property
    def under_determined(self):
        """Not 'a parameter was sampled' — that would call every square
        under-specified, since its side only sets the scale — but 'ANOTHER
        drawing satisfies the same sentences'. Measured, by drawing it."""
        if self._under is None:
            keys = set()
            for k in range(4):
                try:
                    keys.add(self._one(self.seed + k).shape_key)
                except (GenerateError, S.ShapeError):
                    continue
            self._under = len(keys) > 1
        return self._under

    def report(self):
        """What the data fixes and what it leaves open, in words — the
        author's own check that a question is not under-specified."""
        d = self.description
        head = "תיאור: %s\nצורה: %s%s, נתונים: %d" % (
            d.text, d.kind, "." + d.variant if d.variant else "", len(d.data))
        if not self.under_determined:
            return (head + "\nהנתונים קובעים את השרטוט (עד כדי קנה מידה "
                    "וסיבוב): תצורה אחת בלבד.")
        return (head + "\nהנתונים אינם קובעים את השרטוט: %s נקבע%s על ידי "
                "ה-seed, ותצורות שונות מקיימות את אותם משפטים.\nייתכן "
                "שהשאלה חסרה נתון — alternatives() מראה אותן."
                % (", ".join(self.free) or "מיקום חופשי",
                   "ים" if len(self.free) > 1 else ""))

    def violate(self, constraint, rotate=0.0, fam=None, size=None):
        """One datum broken on purpose, for a 'find the mistake' item.

        The drawing obeys every OTHER datum exactly and prints the original
        number beside the wrong drawing — which is what the reader has to
        catch. The SVG is tagged `<!--critique:find_error-->`, the tag
        `numberline.critique_guard` already reads, so it cannot stand beside
        an ordinary item."""
        dat = self._find(constraint)
        if dat.role not in _VIOLABLE:
            _bad("אי אפשר לשבור את %r (סוג הנתון: %s)" % (dat.text, dat.role),
                 "אפשר לשבור נתון מסוג %s — נתון שהשרטוט מראה אותו"
                 % ", ".join(sorted(_VIOLABLE)))
        if dat.role == "length" and len([d for d in self.description.data
                                         if d.role == "length" and d.drawn]) < 2:
            _bad("%r הוא האורך היחיד שמודפס בשרטוט" % dat.text,
                 "אורך יחיד ששונה רק מקטין או מגדיל את כל השרטוט ואין מה "
                 "להשוות אליו: הוסיפו אורך שני, או שברו זווית או סימון שוויון")
        tagkind = _VIOLABLE[dat.role]
        tag = "critique:find_error" + (":" + tagkind if tagkind else "")
        last = None
        for new in self._breaks(dat):
            key = ("t", dat.text) if dat.role == "midpoint" else dat.text
            try:
                return self._one(self.seed, rotate=rotate, fam=fam, size=size,
                                 override={key: new}, tag=tag,
                                 violated=dat.text, extra="+violated")
            except (GenerateError, S.ShapeError) as e:
                last = e
                continue
        if not _has_freedom(self.description):
            lens = [d.text for d in self.description.data
                    if d.role in ("length", "angle3", "angle1")]
            _bad("הנתונים קובעים את השרטוט לגמרי, ולכן %r אינו יכול להיות "
                 "שקר בפני עצמו" % dat.text,
                 "הטעות חייבת לשבת בנתון שהשרטוט נבנה ממנו: שברו אחד מאלה "
                 "— %s" % ("; ".join(lens) or "אין נתון כזה בתיאור"))
        _bad("אף שינוי של %r לא נתן שרטוט קריא" % dat.text,
             "שברו נתון אחר, או הגדילו את מרחב התצורות (פחות נתונים "
             "קבועים). הסיבה האחרונה: %s" % last)

    def _find(self, constraint):
        want = _D._clean(constraint)
        for d in self.description.data:
            if d.text == want or want in d.text:
                return d
        _bad("אין בתיאור נתון בשם %r" % constraint,
             "הנתונים הם: %s" % "; ".join(d.text
                                          for d in self.description.data))

    def _breaks(self, dat):
        """The deliberate errors, in a fixed order (determinism again)."""
        if dat.role in ("angle3", "angle1"):
            for k in (12.0, -12.0, 18.0, -18.0, 8.0, -8.0, 25.0, -25.0):
                v = dat.value + k
                if 5.0 < v < 175.0:
                    yield v
        elif dat.role == "length":
            for k in (1.35, 0.7, 1.6, 0.55):
                yield dat.value * k
        elif dat.role == "equal":
            for k in (1.3, 0.75, 1.5):
                yield k
        elif dat.role == "ratio":
            p, q = dat.value
            for k in (1.6, 0.6, 2.2):
                yield (p * k, q)
        elif dat.role == "midpoint":
            for t in (0.32, 0.68, 0.27):
                yield t


# ------------------------------------------------------ module shortcuts ---
def build_figure(text, seed=0, rotate=0.0, fam=None, cap=30.0, size=None):
    return Generator(text, seed=seed, cap=cap).figure(rotate=rotate, fam=fam,
                                                      size=size)


def alternatives(text, n=3, seed=0, cap=30.0, rotate=0.0):
    return Generator(text, seed=seed, cap=cap).alternatives(n, rotate=rotate)


def violate(text, constraint, seed=0, cap=30.0, rotate=0.0):
    return Generator(text, seed=seed, cap=cap).violate(constraint,
                                                       rotate=rotate)


if __name__ == "__main__":
    G = Generator("ריבוע ABCD; G על AD; ∠GBA = 37°", seed=1)
    f = G.figure()
    print(f, len(f.svg))
    print(G.report())
