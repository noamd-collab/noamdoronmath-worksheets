# -*- coding: utf-8 -*-
u"""emit_docx — v7.2.0-noam. The Word (.docx) twin of sheet.pdf, from the SAME IR.

WHY THIS FILE EXISTS
--------------------
Teachers buy an editable sheet. Every earlier DOCX exporter in this family
scraped the finished HTML, and each one shipped a defect that only Word shows
(docx.md §3-§4, verified with Microsoft Word 16.114 for Mac):

  * `w:jc="right"` under `w:bidi` renders LEFT-aligned        -> never jc right/end
  * a Hebrew run without bCs/iCs/szCs loses bold and size     -> cs pairs always
  * a table style's bidiVisual is not inherited                -> direct bidiVisual
  * two `m:oMath` separated by an LTR run reorder              -> ONE oMath per $..$
  * `−5 + 3` or `(2, −3)` inside an RTL run is mirrored        -> math only in OMML
  * PyMuPDF's direct SVG renderer drops strokes                -> WeasyPrint, no fallback

So this writer never reads HTML. It consumes exactly the object build.py hands
to emit_html.build_html:  Ln = deliver.normalize(wspec_build.expand_level(L))
(pkgload.load(pkg).ir[k]), and prints the same blocks in the same order:

    level line · h1 title · subtitle · id line · rule box
    per question: part band, marker (n) [★], example box, intro lines,
                  figure (beside the text when narrow / fig_side, else centred),
                  table, items with their writing space (+ 4-tuple item figures)
    בהצלחה!  ·  final-answers page (band, note, rows)

THE INLINE LAYER
----------------
`$…$` islands are parsed by a Python port of the website's mathXml DSL parser,
extended to the full house DSL of emit_html.m_body/seg/_plain (\\f \\d \\g ^ _
\\sqrt \\angle \\tri \\para \\npara \\perp \\cong \\sim \\pi \\leq \\geq \\neq
\\approx \\cdot \\times \\pm \\mp \\deg \\infty \\rat \\text ___ \\% \\$ \\& \\# \\_,
ASCII '-' -> U+2212, **bold** spanning islands). Anything the PDF parser would
refuse is refused here too (fail closed): an unknown macro never becomes ink.

BOOKMARKS (invisible; the binding to sheet.json)
    q<n>          around every question (first to last paragraph)
    q<n><latin>   around every item, ids from deliver.item_id (q7b)
    ans_q<n>      around every final-answer row
linearize(Ln) gives the normalized text each of them must hold, and
extract_bookmark_text()/parity_report() read it back from the written file.
An id that is not unambiguous — a duplicate, or an item id that does not read
q<n><letters> (numeric labels: question 3 item "1" -> q31, the shape of a
question id) — stops the build: Word keeps only one of two equal names, and
G90/G91 would bind the wrong question. deliver.item_id is locked, so numeric
item labels wait for a contract decision on their id.

NOTES FOR TEXT CHECKERS (G86 / G90 / G91)
  * Prose that touches the island after it (`ו־$x$`) ends with U+200D ZERO
    WIDTH JOINER — Word's "no-width non break" — so Word does not end a line
    with `ו־` and start the next with the formula. Strip U+200D (with the
    LRM/RLM marks) before matching text; _norm() does.
  * Two islands separated only by neutrals (`$42°$, $78°$`, or `(2)` between
    two answer segments) are two m:oMath with an RTL run between them, and
    that run starts with U+200F RLM (guard_zones). Word keeps the order even
    without it (docx.md §4-D P5), but check_docx_rtl R9 — the G90 gate —
    demands a strong RTL character there, and other renderers need it.
  * The band's question range ("1-4", "3, 5") is an LRM-bounded rtl=0 run.

ISLANDS AND LINE ENDS
    An island sits in an unbreakable m:box (the PDF prints it nowrap) only
    while its estimated width in Word (Cambria Math advances + Word's operator
    spacing, island_width_pt) fits BOX_FIT of the line it is set in. A wider
    island may break before its top-level relations (= < ≤ …), each piece
    between them still unbreakable; a piece wider than the line is left
    breakable. Word sets math ~1.3x wider than the PDF, so a box that fits the
    PDF can run off the page in Word. Such islands are listed in the stats
    (wide_islands).

FIGURES
    Rendered by WeasyPrint (the PDF's own engine) in a subprocess with
    DYLD_FALLBACK_LIBRARY_PATH, rasterised by PyMuPDF at 300 dpi, cropped to
    their ink and embedded as PNG at the PDF's physical scale (1 CSS px =
    0.75 pt). There is no fallback renderer: a figure that cannot be rendered
    stops the build.

USE
    import pkgload, emit_docx
    P = pkgload.load(pkg_dir)
    emit_docx.build_docx(P.ir["a"], "out/docx/a/sheet.docx", meta={...})

    python3 emit_docx.py --pkg DIR [--out DIR] [--levels a,b,c]
        -> DIR/out/docx/<k>/sheet.docx (default out = DIR/out)
    python3 emit_docx.py --selftest

This module does not import emit_html: emit_html resolves its fonts through
a file URI and fails in any folder whose path has a space. The constants and
the three small functions mirrored from it are compared with the original in
--selftest by reading emit_html.py's source (ast), so the check runs in the
real skill folder too; a missing or changed original fails the selftest
(EMIT_DOCX_SKIP_MIRROR=1 skips it, loudly).
"""
from __future__ import print_function

import argparse
import ast
import datetime
import hashlib
import json
import os
import re
import struct
import subprocess
import sys
import tempfile
import unicodedata
import zipfile
import zlib
from pathlib import Path
from xml.etree import ElementTree as ET

SKILL = Path(__file__).resolve().parent
if str(SKILL) not in sys.path:
    sys.path.insert(0, str(SKILL))

VERSION = "7.2.0-noam"

# ----------------------------------------------- mirrored from emit_html ---
# (compared with emit_html in selftest whenever emit_html can be imported)
BRAND = u"מתמטיקה · נועם דורון"
BSD = u"בס״ד"
MINUS = u"−"
COPYRIGHT = (u"© כל הזכויות שמורות לנועם דורון · אין להעתיק, לצלם או "
             u"להפיץ ללא אישור בכתב")
ANSNOTE = (u"התשובות הסופיות בלבד. בשאלות שבהן נדרש נימוק, הסבר או הוכחה — "
           u"הכתיבה המלאה היא חלק מן הפתרון שלכם.")
SIDE_MAX = float(os.environ.get("HMW_SIDE_MAX", 210.0))
HEB_LABEL = re.compile(u"^[א-ת]{1,3}[׳'′״\"]?$")
MARKER_RE = re.compile(r"^\(\d+\)$")
_MATH_PUNCT_GAP = re.compile(r"\$[ \u00a0]+([.,;:!?])")
_TEX_OK = re.compile(u"^[0-9A-Za-z+\\-− .,()°^_{}]*$")
_GENERIC_FACE = re.compile(r'font-family="(serif|sans-serif|monospace)"')
_TEXT_NO_FACE = re.compile(r'<text(?![^>]*font-family=)')
_SVG_TEXT = re.compile(r"(<text\b[^>]*>)(.*?)(</text>)", re.S)
_HYPHEN_REF = re.compile(r"&#(?:0*45|[xX]0*2[dD]);")
_SVG_W = re.compile(r'<svg[^>]*\bwidth="([\d.]+)')
_SVG_H = re.compile(r'<svg[^>]*\bheight="([\d.]+)')
ITEM_FIG_MAX = 150.0            # emit_plus.ITEM_FIG_MAX
_PX_TO_PT = 0.75

# Symbols the house face lacks; the PDF pins them to a symbol face (.sym).
SYM = set(u"★□")
SYM_FONT = "Segoe UI Symbol"
FONT = "David"                  # bundled with Word (DFonts); David Libre is not
MATH_FONT = "Cambria Math"

# How a line that is exactly one $…$ island is placed. The PDF's `.mline` is
# `direction:ltr; text-align:right; margin-right:14pt` — at the start (right)
# edge, 14pt inside the text column. Word turns a paragraph that holds only an
# oMath into display math and centres it, so the line is written as an
# m:oMathPara with m:jc="right" (verified in Word: microprobe M1 — it lands at
# the indented right edge, in display style like the PDF's fractions there).
# "center" would centre it instead.
DISPLAY_ALIGN = "start"

LRM, RLM = u"\u200e", u"\u200f"

# --------------------------------------------------------------- units ---
TW_PER_PT = 20
EMU_PER_PT = 12700


def _mm_tw(mm):
    return int(round(mm / 25.4 * 1440))


PAGE_W, PAGE_H = 11906, 16838                    # A4
MARGIN = dict(top=_mm_tw(16), right=_mm_tw(15), bottom=_mm_tw(14),
              left=_mm_tw(15), header=_mm_tw(7), footer=_mm_tw(6))
TEXT_W = PAGE_W - MARGIN["left"] - MARGIN["right"]       # 10206 twips
Q_GUTTER = 44 * TW_PER_PT       # .q{padding-right:44pt}
I_GUTTER = 28 * TW_PER_PT       # .it{padding-right:28pt}
MLINE_IN = 14 * TW_PER_PT       # .mline{margin-right:14pt}

# font sizes in points, from emit_html.CSS
SZ = dict(body=11.6, lvl=10.5, h1=19.0, sub=11.0, idline=11.0, rule=10.2,
          band=11.0, ex=10.8, td=10.8, th=10.4, good=13.0, ansband=11.5,
          ansnote=9.8, abody=9.9, amark=10.4, anote=10.2, head=9.0,
          foot=8.5, copy=6.4)
LINE = dict(body=1.62, rule=1.55, ex=1.62, abody=1.72)


def _hp(pt):
    """points -> OOXML half-points (w:sz)."""
    return int(round(pt * 2))


class DocxError(ValueError):
    """Content the PDF emitter would also refuse, or a broken invariant."""


# ======================================================== inline layer ===
_B_OPEN, _B_CLOSE = u"\x01", u"\x02"
_BARE = {
    "para": u"∥", "npara": u"∦", "perp": u"⊥",
    "cong": u"≅", "sim": u"∼", "tri": u"△",
    "pi": u"π", "leq": u"≤", "geq": u"≥", "neq": u"≠",
    "approx": u"≈", "cdot": u"·", "times": u"×",
    "pm": u"±", "mp": u"∓", "deg": u"°", "infty": u"∞",
}
ANGLE_SIGN = u"∡"           # ∡, the PDF's \measuredangle
RATIO_COLON = u"∶"          # ∶, the PDF's \rat colon
BLANK_TEXT = u"______"           # ≈ 34pt, the PDF's .blank


def _brace(s, i):
    """s[i] == '{' ; (inner, index after the matching '}') — emit_html._brace."""
    if i >= len(s) or s[i] != "{":
        raise DocxError("expected '{' in %r" % s)
    d, j = 0, i
    while j < len(s):
        if s[j] == "{":
            d += 1
        elif s[j] == "}":
            d -= 1
            if d == 0:
                return s[i + 1:j], j + 1
        j += 1
    raise DocxError("unbalanced brace in %r" % s)


def _vector_guard(dsl):
    """emit_html._to_tex as a pure syntax guard: \\sqrt{} and \\angle{} take
    only what the PDF's vector path accepts, so the two outputs refuse the
    same content."""
    out, i = [], 0
    while i < len(dsl):
        if dsl.startswith("\\f{", i) or dsl.startswith("\\d{", i):
            num, j = _brace(dsl, i + 2)
            den, j = _brace(dsl, j)
            out.append(u"\\frac{%s}{%s}" % (_vector_guard(num), _vector_guard(den)))
            i = j
        elif dsl.startswith("\\g{", i):
            inner, j = _brace(dsl, i + 2)
            out.append(u"\\left(%s\\right)" % _vector_guard(inner))
            i = j
        elif dsl.startswith("\\sqrt{", i):
            inner, j = _brace(dsl, i + 5)
            out.append(u"\\sqrt{%s}" % _vector_guard(inner))
            i = j
        elif dsl[i] in "^_":
            if i + 1 >= len(dsl):
                raise DocxError("dangling %r in %r" % (dsl[i], dsl))
            if dsl[i + 1] == "{":
                inner, j = _brace(dsl, i + 1)
            else:
                inner, j = dsl[i + 1], i + 2
            out.append(u"%s{%s}" % (dsl[i], _vector_guard(inner)))
            i = j
        elif dsl[i] == "\\":
            raise DocxError("unsupported macro inside vector math: %r" % dsl)
        else:
            out.append(dsl[i])
            i += 1
    tex = u"".join(out).replace(MINUS, "-").replace(u"·", u"\\cdot ")
    if "\\" not in tex and not _TEX_OK.match(tex):
        raise DocxError("unsafe characters in vector math: %r" % dsl)
    return tex


def _plain(t):
    """emit_html._plain without the HTML: '-' and U+2212 are one sign."""
    return t.replace("-", MINUS)


def _attach(out, kind, script):
    """`^`/`_` follow their base in the DSL; OMML needs the base inside.
    The base is the node before the script: a structure, a number, or one
    character (a letter, ')' or '°')."""
    while out and out[-1][0] == "t" and not out[-1][1].strip(u" \u00a0"):
        out.pop()                            # spaces only: look further back
    base = []
    if out and out[-1][0] == "t":
        s = out[-1][1].rstrip(u" \u00a0")
        m = re.search(r"[0-9.]+$", s) if s[-1:].isdigit() else None
        tok = m.group(0) if m else s[-1]
        rest = s[:-len(tok)]
        out.pop()
        if rest:
            out.append(("t", rest))
        base = [("t", tok)]
    elif out and out[-1][0] == "sub" and kind == "sup":
        _, b, s = out.pop()
        out.append(("subsup", b, s, script))
        return
    elif out and out[-1][0] == "sup" and kind == "sub":
        _, b, s = out.pop()
        out.append(("subsup", b, script, s))
        return
    elif out:
        base = [out.pop()]
    out.append((kind, base, script))


def parse_math(e):
    """The inside of one $…$ island -> nodes (emit_html.m_body, as a tree).

    ("t", text) ("frac", num, den, display) ("grp", inner)
    ("sup"|"sub", base, script) ("subsup", base, sub, sup) ("sqrt", inner)
    ("angle", letters) ("rat", a, b) ("txt", word) ("blank",) ("sym", ch)"""
    out, buf, i = [], [], 0

    def flush():
        if buf:
            out.append(("t", _plain(u"".join(buf))))
            del buf[:]

    while i < len(e):
        if e.startswith("\\f{", i) or e.startswith("\\d{", i):
            num, j = _brace(e, i + 2)
            den, j = _brace(e, j)
            flush()
            out.append(("frac", parse_math(num), parse_math(den), e[i + 1] == "d"))
            i = j
        elif e.startswith("\\g{", i):
            inner, j = _brace(e, i + 2)
            flush()
            out.append(("grp", parse_math(inner)))
            i = j
        elif e[i] == "^":
            flush()
            if i + 1 >= len(e):
                raise DocxError("dangling '^' in %r" % e)
            if e[i + 1] == "{":
                inner, j = _brace(e, i + 1)
            else:
                inner, j = e[i + 1], i + 2
            _attach(out, "sup", parse_math(inner))
            i = j
        elif e.startswith("\\rat{", i):
            a, j = _brace(e, i + 4)
            b, k = _brace(e, j)
            flush()
            out.append(("rat", parse_math(a), parse_math(b)))
            i = k
        elif e[i] == "_" and not e.startswith("___", i):
            flush()
            if i + 1 >= len(e):
                raise DocxError("dangling '_' in %r" % e)
            if e[i + 1] == "{":
                inner, j = _brace(e, i + 1)
            else:
                inner, j = e[i + 1], i + 2
            _attach(out, "sub", parse_math(inner))
            i = j
        elif e.startswith("___", i):
            flush()
            out.append(("blank",))
            i += 3
        elif e[i] == "\\":
            if i + 1 < len(e) and e[i + 1] in "%$&#_":
                flush()
                out.append(("t", e[i + 1]))
                i += 2
                continue
            if e.startswith("\\text{", i):
                inner, j = _brace(e, i + 5)
                flush()
                out.append(("txt", inner))
                i = j
                continue
            name = re.match(r"\\([a-zA-Z]+)", e[i:])
            if not name:
                raise DocxError("stray backslash in math island: %r" % e)
            nm, j = name.group(1), i + name.end()
            flush()
            if nm in ("sqrt", "angle"):
                if j >= len(e) or e[j] != "{":
                    raise DocxError("\\%s needs {...} in %r" % (nm, e))
                inner, j = _brace(e, j)
                _vector_guard(inner)
                out.append((nm, parse_math(inner)))
            elif nm == "tri":
                out.append(("sym", _BARE[nm]))
                while j < len(e) and e[j] == " ":
                    j += 1
            elif nm in _BARE:
                out.append(("sym", _BARE[nm]))
            else:
                # G67 at source, as in the PDF: never fall through to text.
                raise DocxError("unknown math macro \\%s in %r" % (nm, e))
            i = j
        else:
            buf.append(e[i])
            i += 1
    flush()
    return out


def nodes_text(nodes):
    """What a text extractor reads back from the OMML (m:t in order)."""
    out = []
    for nd in nodes:
        k = nd[0]
        if k in ("t", "sym"):
            out.append(nd[1])
        elif k == "txt":
            out.append(nd[1])
        elif k == "blank":
            out.append(BLANK_TEXT)
        elif k == "frac":
            out.append(nodes_text(nd[1]) + nodes_text(nd[2]))
        elif k in ("grp", "sqrt"):
            out.append(nodes_text(nd[1]))
        elif k == "angle":
            out.append(ANGLE_SIGN + nodes_text(nd[1]))
        elif k == "rat":
            out.append(nodes_text(nd[1]) + RATIO_COLON + nodes_text(nd[2]))
        elif k in ("sup", "sub"):
            out.append(nodes_text(nd[1]) + nodes_text(nd[2]))
        elif k == "subsup":
            out.append(nodes_text(nd[1]) + nodes_text(nd[2]) + nodes_text(nd[3]))
    return u"".join(out)


def _mark_bold(text):
    """emit_html._mark_bold: ** pairs matched across the whole string."""
    out, i, depth = [], 0, 0
    while True:
        j = text.find("**", i)
        if j < 0:
            out.append(text[i:])
            break
        out.append(text[i:j])
        out.append(_B_CLOSE if depth else _B_OPEN)
        depth ^= 1
        i = j + 2
    if depth:
        raise DocxError("unbalanced **bold** in %r" % text)
    return u"".join(out)


def parse_seg(text):
    """Hebrew prose with $…$ islands -> [("p", text, bold) | ("m", nodes, bold)].
    The same refusals as emit_html.seg: odd '$', a backslash in prose, a stray
    '*'."""
    text = _MATH_PUNCT_GAP.sub(r"$\1", u"%s" % text)
    text = _mark_bold(text)
    parts = text.split("$")
    if len(parts) % 2 == 0:
        raise DocxError("odd number of $ delimiters in %r" % text)
    out, bold = [], False
    for k, p in enumerate(parts):
        if k % 2 == 0:
            if "\\" in p:
                raise DocxError("backslash in Hebrew prose (macro outside "
                                "$...$?): %r" % text)
            if "*" in p:
                raise DocxError("stray '*' in prose (unbalanced **bold**?): %r" % p)
            buf = []
            for ch in p:
                if ch in (_B_OPEN, _B_CLOSE):
                    if buf:
                        out.append(("p", u"".join(buf), bold))
                        buf = []
                    bold = ch == _B_OPEN
                else:
                    buf.append(ch)
            if buf:
                out.append(("p", u"".join(buf), bold))
        else:
            inner = p.replace(_B_OPEN, u"").replace(_B_CLOSE, u"")
            mbold = bold or (_B_OPEN in p or _B_CLOSE in p)
            out.append(("m", parse_math(inner), mbold))
            for ch in p:
                if ch == _B_OPEN:
                    bold = True
                elif ch == _B_CLOSE:
                    bold = False
    return out


_WS = re.compile(u"[ \t\r\n\f]+")


def _collapse(s):
    """HTML white-space collapsing (no-break spaces survive, as in the PDF)."""
    return _WS.sub(u" ", s)


def seg_text(text):
    """The plain text one inline string prints (prose collapsed, islands as
    their OMML text). Shared by the emitter's own bookkeeping and linearize."""
    out = []
    for part in parse_seg(text):
        if part[0] == "p":
            out.append(_collapse(part[1]))
        else:
            out.append(nodes_text(part[1]))
    return u"".join(out)


def is_display(text):
    """emit_html.is_display: a line that is exactly one island."""
    t = (u"%s" % text).strip()
    return t.startswith("$") and t.endswith("$") and t.count("$") == 2


def item_label_text(lab):
    """emit_html.item_label: Hebrew letters keep `א.`; anything else is the
    mirrored-pair form `(1)`, which cannot flip to `.1`."""
    lab = u"%s" % lab
    return (u"%s." % lab) if HEB_LABEL.match(lab) else (u"(%s)" % lab)


def marker_text(n):
    txt = u"(%s)" % n
    if not MARKER_RE.match(txt):
        raise DocxError("marker %r is not (\\d+) — house rule" % txt)
    return txt


# ============================================================ XML bits ===
def _esc(s):
    s = u"%s" % s
    s = re.sub(u"[\x00-\x08\x0b\x0c\x0e-\x1f]", u"", s)
    return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            .replace('"', "&quot;"))


NS = {
    "w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
    "m": "http://schemas.openxmlformats.org/officeDocument/2006/math",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    "wp": "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
    "pic": "http://schemas.openxmlformats.org/drawingml/2006/picture",
}
NSDECL = " ".join('xmlns:%s="%s"' % kv for kv in NS.items())
XML_HEAD = u'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'


def _rpr(size, bold=False, color=None, rtl=True, font=FONT, lang=True):
    """Run properties in schema order. Every Hebrew run carries the cs twins
    (bCs, szCs): Word draws an RTL run from them (docx.md §4-B)."""
    hp = _hp(size)
    x = ['<w:rFonts w:ascii="%s" w:hAnsi="%s" w:eastAsia="%s" w:cs="%s"/>'
         % (font, font, font, font)]
    if bold:
        x.append("<w:b/><w:bCs/>")
    if color:
        x.append('<w:color w:val="%s"/>' % color)
    x.append('<w:sz w:val="%d"/><w:szCs w:val="%d"/>' % (hp, hp))
    x.append("<w:rtl/>" if rtl else '<w:rtl w:val="0"/>')
    if lang:
        x.append('<w:lang w:val="he-IL" w:bidi="he-IL"/>')
    return "<w:rPr>%s</w:rPr>" % "".join(x)


def _t(text):
    """Text with tabs as <w:tab/>."""
    out = []
    for k, piece in enumerate(text.split("\t")):
        if k:
            out.append("<w:tab/>")
        if piece:
            out.append('<w:t xml:space="preserve">%s</w:t>' % _esc(piece))
    return "".join(out)


def run(text, size, bold=False, color=None, rtl=True, font=FONT):
    if not text:
        return ""
    return "<w:r>%s%s</w:r>" % (_rpr(size, bold, color, rtl, font), _t(text))


def _prose_runs(text, size, bold, color):
    """One prose chunk -> RTL runs; ★ □ get the symbol face, as `.sym` does."""
    out, buf = [], []

    def flush():
        if buf:
            out.append(run(u"".join(buf), size, bold, color))
            del buf[:]
    for ch in text:
        if ch in SYM:
            flush()
            out.append(run(ch, size, bold, color, font=SYM_FONT))
        else:
            buf.append(ch)
    flush()
    return "".join(out)


# Word draws the numerator and denominator of an INLINE fraction at about 70%
# of the line (8.0pt on 11.5pt, measured in Word: microprobe2); the PDF prints
# them at .94em (.frac .fnu/.fde). Their runs are therefore set 1.35x larger,
# which lands at ~10.8pt like the PDF. Display lines (m:oMathPara) are drawn
# full size by Word and are not scaled; nor is a fraction inside a fraction.
FRAC_SCALE = 1.35


class _Ctx(object):
    def __init__(self, size, bold=False, color=None, display=False, nested=False):
        self.size, self.bold, self.color = size, bold, color
        self.display, self.nested = display, nested

    def frac_parts(self):
        if self.display or self.nested:
            return _Ctx(self.size, self.bold, self.color, self.display, True)
        return _Ctx(self.size * FRAC_SCALE, self.bold, self.color, False, True)


def _m_wrpr(ctx, heb=False):
    hp = _hp(ctx.size)
    if heb:
        return ('<w:rPr><w:rFonts w:ascii="%s" w:hAnsi="%s" w:cs="%s"/>%s%s'
                '<w:sz w:val="%d"/><w:szCs w:val="%d"/><w:rtl/>'
                '<w:lang w:val="he-IL" w:bidi="he-IL"/></w:rPr>'
                % (FONT, FONT, FONT, "<w:b/><w:bCs/>" if ctx.bold else "",
                   '<w:color w:val="%s"/>' % ctx.color if ctx.color else "",
                   hp, hp))
    return ('<w:rPr><w:rFonts w:ascii="%s" w:hAnsi="%s" w:cs="%s"/>%s%s'
            '<w:sz w:val="%d"/><w:szCs w:val="%d"/><w:rtl w:val="0"/></w:rPr>'
            % (MATH_FONT, MATH_FONT, MATH_FONT,
               "<w:b/><w:bCs/>" if ctx.bold else "",
               '<w:color w:val="%s"/>' % ctx.color if ctx.color else "", hp, hp))


_HEB_CHAR = re.compile(u"[֐-׿]")


def _mr(text, ctx, nor=False):
    """One math run. Letters upright (m:sty p) like the PDF's David Libre;
    bold islands m:sty b. A \\text{} run is normal text (m:nor), and when it
    holds Hebrew it is an RTL David run inside the zone (docx.md §4-D P1)."""
    if not text:
        return ""
    heb = bool(_HEB_CHAR.search(text))
    if nor:
        mrpr = "<m:rPr><m:nor/></m:rPr>"
    else:
        mrpr = '<m:rPr><m:sty m:val="%s"/></m:rPr>' % ("b" if ctx.bold else "p")
    return ('<m:r>%s%s<m:t xml:space="preserve">%s</m:t></m:r>'
            % (mrpr, _m_wrpr(ctx, heb=heb and nor), _esc(text)))


def _ctrl(ctx):
    return "<m:ctrlPr>%s</m:ctrlPr>" % _m_wrpr(ctx)


def omml(nodes, ctx):
    out = []
    for nd in nodes:
        k = nd[0]
        if k in ("t", "sym"):
            if _HEB_CHAR.search(nd[1]):
                raise DocxError("Hebrew inside a math island needs \\text{}: %r"
                                % nd[1])
            out.append(_mr(nd[1], ctx))
        elif k == "txt":
            out.append(_mr(nd[1], ctx, nor=True))
        elif k == "blank":
            out.append(_mr(BLANK_TEXT, ctx))
        elif k == "frac":
            fc = ctx.frac_parts()
            out.append("<m:f><m:fPr>%s</m:fPr><m:num>%s</m:num><m:den>%s</m:den></m:f>"
                       % (_ctrl(ctx), omml(nd[1], fc), omml(nd[2], fc)))
        elif k == "grp":
            out.append('<m:d><m:dPr><m:begChr m:val="("/><m:endChr m:val=")"/>%s'
                       '</m:dPr><m:e>%s</m:e></m:d>' % (_ctrl(ctx), omml(nd[1], ctx)))
        elif k == "sqrt":
            out.append('<m:rad><m:radPr><m:degHide m:val="1"/>%s</m:radPr><m:deg/>'
                       '<m:e>%s</m:e></m:rad>' % (_ctrl(ctx), omml(nd[1], ctx)))
        elif k == "angle":
            out.append(_mr(ANGLE_SIGN, ctx) + omml(nd[1], ctx))
        elif k == "rat":
            out.append(omml(nd[1], ctx) + _mr(RATIO_COLON, ctx) + omml(nd[2], ctx))
        elif k == "sup":
            out.append("<m:sSup><m:sSupPr>%s</m:sSupPr><m:e>%s</m:e><m:sup>%s</m:sup></m:sSup>"
                       % (_ctrl(ctx), omml(nd[1], ctx), omml(nd[2], ctx)))
        elif k == "sub":
            out.append("<m:sSub><m:sSubPr>%s</m:sSubPr><m:e>%s</m:e><m:sub>%s</m:sub></m:sSub>"
                       % (_ctrl(ctx), omml(nd[1], ctx), omml(nd[2], ctx)))
        elif k == "subsup":
            out.append("<m:sSubSup><m:sSubSupPr>%s</m:sSubSupPr><m:e>%s</m:e>"
                       "<m:sub>%s</m:sub><m:sup>%s</m:sup></m:sSubSup>"
                       % (_ctrl(ctx), omml(nd[1], ctx), omml(nd[2], ctx),
                          omml(nd[3], ctx)))
        else:                                        # pragma: no cover
            raise DocxError("unknown node %r" % (k,))
    return "".join(out)


def _has_dfrac(nodes):
    for nd in nodes:
        if nd[0] == "frac" and nd[3]:
            return True
        for sub in nd[1:]:
            if isinstance(sub, list) and _has_dfrac(sub):
                return True
    return False


# ------------------------------------------------- island width in Word ---
# Word sets an island in Cambria Math and adds its own operator spacing, so the
# same island is ~1.3x wider in Word than in the PDF's David Libre. Inside an
# unbreakable box that difference ran an item off the page (v7.2.0 review:
# `360°−48°−4·60°=72°, …` fits the PDF's 438pt item column, not Word's). The
# writer has to decide without Word whether a box is safe, so it estimates the
# Word width from Cambria Math's own advance widths (units of 1/2048 em, read
# once with fontTools from Word 16.114's DFonts/Cambria.ttc; listed here so
# the build never depends on Word being installed) and Word's spacing rules:
# a relation (and ⊥ ∥) gets a thick space (5/18 em) on each side, a binary
# operator a medium space (4/18 em) — none when it is a sign, and none inside
# an inline fraction or a script; a comma or semicolon is followed by Word's
# own ~0.15 em, which replaces a typed space there. Other literal spaces in
# m:t are printed as Cambria spaces. Calibrated against Word's own PDF on 90
# islands (G7-T13 + synthetic, tests/docx/calib/calib_report_refined.txt):
# estimate / Word = 0.98 … 1.10, median 1.01 — it errs wide, by fraction bars
# and edge spaces.
_CM_UPEM = 2048.0
_CM_ADV = {}
for _w, _chs in (
        (420, u",."), (485, u"'"), (529, u"′"), (540, u":;"), (545, u"j"),
        (556, u"l"), (569, u"i"), (578, u"·"), (585, u"!"), (620, u"f"),
        (624, u"∶"), (628, u"J"), (648, u"|"), (664, u"I"), (680, u"-"),
        (693, u"t"), (717, u"[]"), (759, u"_"), (769, u"°"), (793, u"{}"),
        (805, u'"'), (847, u"r"), (850, u"()"), (865, u"?"), (875, u"*"),
        (880, u"s"), (881, u"″"), (903, u"c"), (931, u"z"), (950, u"∥"),
        (990, u"x"), (999, u"e"), (1000, u"a"), (1004, u"/\\"), (1012, u"g"),
        (1016, u"S"), (1032, u"vy"), (1074, u"k"), (1087, u"o"), (1099, u"FL"),
        (1101, u"Z"), (1114, u"∦"), (1120, u"q"), (1121, u"b"), (1130, u"h"),
        (1131, u"u"), (1134, u"0123456789^"), (1136, u"d"), (1139, u"p"),
        (1143, u"n"), (1152, u"C"), (1163, u"P"), (1168, u"Y"), (1170, u"X"),
        (1178, u"E"), (1214, u"T"), (1233, u"π"), (1236, u"V"), (1251, u"G"),
        (1252, u"B"), (1268, u"#"), (1272, u"R"), (1276, u"A"), (1289, u"K"),
        (1327, u"U"), (1338, u"OQ"), (1348, u"∡"), (1355, u"D"), (1358, u"⊥"),
        (1394, u"N"), (1406, u"H"), (1408, u"&"), (1459, u"~∼"), (1463, u"×"),
        (1482, u"△"), (1507, u"≈"), (1530, u"+=−≠≅±∓"),
        (1534, u"<>≤≥"), (1586, u"w"), (1670, u"M"), (1704, u"m"),
        (1742, u"∞"), (1822, u"%"), (1887, u"W"), (451, u" \u00a0")):
    for _c in _chs:
        _CM_ADV[_c] = _w
_CM_DEFAULT = 1150                 # an unlisted glyph: about a digit
_REL_CH = set(u"=<>≤≥≠≈≅∼")   # break points, thick space
_REL_SPACED = _REL_CH | set(u"⊥∥∦")            # thick space, not cut
_BIN_CH = set(u"+−×·±∓")         # binary operators, medium space
_PUNCT_CH = set(u",;")
_REL_SP, _BIN_SP, _PUNCT_SP = 5.0 / 18, 4.0 / 18, 0.15
SCRIPT_SCALE = 0.7                 # Word's sup/sub size, and inline fraction parts
# A box may hold an island up to this share of its line: with the estimate
# at most 2% under Word, a boxed island fills at most ~87% of its line, and a
# borderline one breaks at a relation instead of running off the page.
BOX_FIT = 0.85


def _text_width_em(s, prev_operand, tight=False):
    """(width in em, prev_operand) of one math text run; `tight` = inside an
    inline fraction or a script, where Word adds no operator spacing."""
    w, after_punct = 0.0, False
    for ch in s:
        if ch.isspace() and after_punct:
            continue                        # Word's punctuation space replaces it
        w += _CM_ADV.get(ch, _CM_DEFAULT) / _CM_UPEM
        after_punct = False
        if ch in _REL_SPACED:
            w += 0 if tight else 2 * _REL_SP
            prev_operand = False
        elif ch in _BIN_CH:
            if prev_operand and not tight:  # a sign after `=`, `(` or at the start: none
                w += 2 * _BIN_SP
            prev_operand = False
        elif ch in _PUNCT_CH:
            w += _PUNCT_SP
            after_punct, prev_operand = True, False
        elif ch == u"(":
            prev_operand = False
        elif not ch.isspace():
            prev_operand = True
    return w, prev_operand


def island_width_pt(nodes, size, display=False):
    """Estimated width in Word of one island's nodes at `size` pt."""
    def walk(nodes, sz, prev, tight=False):
        w = 0.0
        for nd in nodes:
            k = nd[0]
            if k in ("t", "sym"):
                e, prev = _text_width_em(nd[1], prev, tight)
                w += e * sz
                continue
            if k == "txt":
                w += _advance_pt(nd[1], sz)          # David, as written
            elif k == "blank":
                w += _CM_ADV["_"] / _CM_UPEM * sz * len(BLANK_TEXT)
            elif k == "frac":
                # inline parts are drawn at SCRIPT_SCALE of runs set FRAC_SCALE
                # larger, tight; display fractions keep the full size
                if display:
                    fs, ft = sz, tight
                else:
                    fs, ft = sz * FRAC_SCALE * SCRIPT_SCALE, True
                w += max(walk(nd[1], fs, False, ft), walk(nd[2], fs, False, ft)) + 0.1 * sz
            elif k == "grp":
                w += walk(nd[1], sz, False, tight) + 2 * _CM_ADV["("] / _CM_UPEM * sz
            elif k == "sqrt":
                w += walk(nd[1], sz, False, tight) + 0.9 * sz
            elif k == "angle":
                w += _CM_ADV[ANGLE_SIGN] / _CM_UPEM * sz + walk(nd[1], sz, False, tight)
            elif k == "rat":
                w += (walk(nd[1], sz, False, tight) + walk(nd[2], sz, False, tight)
                      + (_CM_ADV[RATIO_COLON] / _CM_UPEM + 2 * _REL_SP) * sz)
            elif k in ("sup", "sub"):
                w += (walk(nd[1], sz, prev, tight)
                      + walk(nd[2], sz * SCRIPT_SCALE, False, True))
            elif k == "subsup":
                w += walk(nd[1], sz, prev, tight) + max(
                    walk(nd[2], sz * SCRIPT_SCALE, False, True),
                    walk(nd[3], sz * SCRIPT_SCALE, False, True))
            prev = True
        return w
    return walk(nodes, float(size), False)


def _split_at_relations(nodes):
    """Top-level relation signs cut an island into pieces:
    [(None, piece0), (rel, piece1), ...]. Only text and symbol nodes at the
    top level are cut; structures (fractions, roots, scripts) stay whole."""
    out, cur, rel = [], [], None
    for nd in nodes:
        if nd[0] in ("t", "sym") and any(c in _REL_CH for c in nd[1]):
            buf = []
            for ch in nd[1]:
                if ch in _REL_CH:
                    if buf:
                        cur.append((nd[0], u"".join(buf)))
                        buf = []
                    out.append((rel, cur))
                    cur, rel = [], ch
                else:
                    buf.append(ch)
            if buf:
                cur.append((nd[0], u"".join(buf)))
        else:
            cur.append(nd)
    out.append((rel, cur))
    return out


def _box(inner, ctx):
    return ("<m:box><m:boxPr><m:noBreak/>%s</m:boxPr><m:e>%s</m:e></m:box>"
            % (_ctrl(ctx), inner))


def island_xml(nodes, ctx, avail_pt=None, report=None):
    """One $…$ island = ONE m:oMath.

    Its content sits in an unbreakable box: the PDF prints an island
    `white-space:nowrap`, and Word otherwise breaks inline math at a relation,
    which in an RTL line strands `∠CPD =` at the end of one line and `144°` at
    the start of the next (seen in Word, q8 of G7-T13). But a box wider than
    its line runs off the page, so an island whose Word width (estimated)
    exceeds BOX_FIT of `avail_pt` gets one box per piece between its top-level
    relations, the relations themselves left free to break before
    (m:brkBin before); a piece that alone is too wide stays unboxed. An island
    with a display fraction (\\d) may wrap anywhere, as `.m.dm` does in the
    PDF. Wide islands are appended to `report`."""
    if _has_dfrac(nodes):
        return "<m:oMath>%s</m:oMath>" % omml(nodes, ctx)
    est = island_width_pt(nodes, ctx.size, ctx.display)
    if avail_pt is None or est <= BOX_FIT * avail_pt:
        return "<m:oMath>%s</m:oMath>" % _box(omml(nodes, ctx), ctx)
    out, loose = [], 0
    for rel, piece in _split_at_relations(nodes):
        if rel:
            out.append(_mr(rel, ctx))
        if not piece:
            continue
        x = omml(piece, ctx)
        if island_width_pt(piece, ctx.size, ctx.display) <= BOX_FIT * avail_pt:
            x = _box(x, ctx)
        else:
            loose += 1
        out.append(x)
    if report is not None:
        report.append(dict(text=nodes_text(nodes), est_pt=round(est, 1),
                           line_pt=round(avail_pt, 1), loose_pieces=loose))
    return "<m:oMath>%s</m:oMath>" % "".join(out)


ZWJ = u"\u200d"


def inline(text, size, bold=False, color=None, strip=True, display=False,
           avail_pt=None, report=None):
    """One inline string (prose + islands) -> (runs xml, plain text, n_islands).
    Each island is exactly ONE m:oMath (docx.md §4-D).

    Prose that touches the island that follows it (`ו־$x$`, `ב$P$`) gets a
    ZERO WIDTH JOINER at its end: Word honours U+200D as "no-width non break"
    and otherwise ends a line with `ו־` and starts the next with the formula
    (verified in Word: microprobe M2; U+2060 does not work there). The PDF
    never breaks at that point. The joiner is invisible and bidi-neutral (BN).

    `display`: the string is exactly one island on its own line (is_display);
    it becomes an m:oMathPara justified like the PDF's `.mline` (DISPLAY_ALIGN).
    `avail_pt`: width of the line the string is set in (island_xml's box
    decision); None keeps every island in one box.
    Separators between two islands get their RLM later, per paragraph
    (guard_zones), because a label or a tab run can sit between them too."""
    text = u"%s" % text
    if strip:
        text = text.strip(u" \t\r\n\f")
    parts = parse_seg(text)
    xs, ts, nmath = [], [], 0
    for k, part in enumerate(parts):
        if part[0] == "p":
            s = _collapse(part[1])
            glue = (k + 1 < len(parts) and parts[k + 1][0] == "m" and s
                    and not s[-1].isspace())
            xs.append(_prose_runs(s + (ZWJ if glue else u""), size,
                                  bold or part[2], color))
            ts.append(s)
        else:
            disp = bool(display and len(parts) == 1)
            ctx = _Ctx(size, bold or part[2], color, display=disp)
            om = island_xml(part[1], ctx, avail_pt, report)
            if disp:
                jc = "center" if DISPLAY_ALIGN == "center" else "right"
                om = ('<m:oMathPara><m:oMathParaPr><m:jc m:val="%s"/></m:oMathParaPr>'
                      '%s</m:oMathPara>' % (jc, om))
            xs.append(om)
            ts.append(nodes_text(part[1]))
            nmath += 1
    return "".join(xs), u"".join(ts), nmath


# ------------------------------------------------- zone separators (R9) ---
_TOP_TOK = re.compile(r"<m:oMathPara>.*?</m:oMathPara>|<m:oMath>.*?</m:oMath>"
                      r"|<w:r>.*?</w:r>|<w:fldSimple\b.*?</w:fldSimple>"
                      r"|<w:[A-Za-z]+\b[^>]*/>", re.S)
_WT_RE = re.compile(r'(<w:t(?: [^>]*)?>)(.*?)</w:t>', re.S)


def _unesc(s):
    return (s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", '"')
            .replace("&amp;", "&"))


def strong_rtl(s):
    """True when `s` holds a strong right-to-left character (R/AL, RLM)."""
    return any(unicodedata.bidirectional(c) in ("R", "AL") for c in s)


def guard_zones(runs, size):
    """check_docx_rtl R9 (G90): two m:oMath zones in one paragraph must be
    separated by a run holding a strong RTL character. Word keeps
    `oMath(A) + rtl ", " + oMath(B)` in order without it (docx.md §4-D P5)
    and with it (P3/P4 for LRM islands; G7-T13 here) — so a separator of
    neutrals only (", ", " ", "(2) ", "   ") gets U+200F at the start of its
    first RTL run, and two zones with no RTL run between them get an RLM run
    of their own. The RLM is invisible and strips out of every text check."""
    if runs.count("<m:oMath>") < 2:
        return runs
    toks, pos = [], 0
    for m in _TOP_TOK.finditer(runs):
        if m.start() != pos:
            raise DocxError("guard_zones: unparsed paragraph content %r"
                            % runs[pos:m.start()][:60])
        toks.append(m.group(0))
        pos = m.end()
    if pos != len(runs):
        raise DocxError("guard_zones: unparsed paragraph tail %r" % runs[pos:][:60])
    out, last_zone, between = [], False, []
    for tok in toks:
        if tok.startswith("<m:oMath"):
            if last_zone:
                sep = u"".join(_unesc(t) for k in between
                               for _o, t in _WT_RE.findall(out[k]))
                if not strong_rtl(sep):
                    for k in between:
                        if "<w:rtl/>" in out[k] and _WT_RE.search(out[k]):
                            out[k] = _WT_RE.sub(lambda m: m.group(1) + RLM + m.group(2)
                                                + "</w:t>", out[k], count=1)
                            break
                    else:
                        out.append(run(RLM, size))
            last_zone, between = True, []
        elif last_zone and tok.startswith("<w:r>"):
            between.append(len(out))
        out.append(tok)
    return "".join(out)


# ====================================================== block objects ===
class P(object):
    """One paragraph. Properties are written in ECMA-376 pPr order; every
    paragraph carries a direct <w:bidi/>, and jc is only ever center (or
    absent = start = right under bidi)."""

    def __init__(self, runs="", text=u"", size=SZ["body"], center=False,
                 ind_start=0, hanging=0, ind_end=0, before=0, after=0,
                 line=None, line_rule="atLeast", keep_next=False,
                 keep_lines=False, page_break=False, border=None, shd=None,
                 tabs=(), style=None):
        self.runs, self.text, self.size = runs, text, size
        self.center = center
        self.ind_start, self.hanging, self.ind_end = ind_start, hanging, ind_end
        self.before, self.after = before, after
        self.line, self.line_rule = line, line_rule
        self.keep_next, self.keep_lines = keep_next, keep_lines
        self.page_break, self.border, self.shd = page_break, border, shd
        self.tabs, self.style = tabs, style
        self.bm_start, self.bm_end = [], []
        # `prefix` runs print before `bm_inner` starts: an item paragraph that
        # also carries its question's marker keeps the marker inside q<n> and
        # outside q<n><x>.
        self.prefix, self.bm_inner = "", []

    def xml(self):
        x = []
        if self.style:
            x.append('<w:pStyle w:val="%s"/>' % self.style)
        if self.keep_next:
            x.append("<w:keepNext/>")
        if self.keep_lines:
            x.append("<w:keepLines/>")
        if self.page_break:
            x.append("<w:pageBreakBefore/>")
        if self.border:
            x.append("<w:pBdr>%s</w:pBdr>" % "".join(
                '<w:%s w:val="%s" w:sz="%d" w:space="%d" w:color="%s"/>'
                % (side, val, sz, space, color)
                for side, val, sz, space, color in self.border))
        if self.shd:
            x.append('<w:shd w:val="clear" w:color="auto" w:fill="%s"/>' % self.shd)
        if self.tabs:
            x.append("<w:tabs>%s</w:tabs>" % "".join(
                '<w:tab w:val="left" w:pos="%d"/>' % pos for pos in self.tabs))
        x.append("<w:bidi/>")
        sp = '<w:spacing w:before="%d" w:after="%d"' % (self.before, self.after)
        if self.line:
            sp += ' w:line="%d" w:lineRule="%s"' % (self.line, self.line_rule)
        x.append(sp + "/>")
        if self.ind_start or self.hanging or self.ind_end:
            ind = '<w:ind w:left="%d" w:right="%d"' % (self.ind_start, self.ind_end)
            if self.hanging:
                ind += ' w:hanging="%d"' % self.hanging
            x.append(ind + "/>")
        if self.center:
            x.append('<w:jc w:val="center"/>')
        hp = _hp(self.size)
        x.append('<w:rPr><w:sz w:val="%d"/><w:szCs w:val="%d"/><w:rtl/></w:rPr>'
                 % (hp, hp))
        def starts(lst):
            return "".join('<w:bookmarkStart w:id="%d" w:name="%s"/>' % (i, _esc(n))
                           for i, n in lst)
        bme = "".join('<w:bookmarkEnd w:id="%d"/>' % i for i, _n in self.bm_end)
        # the marker prefix never holds an island, so the zones are all in runs
        return "<w:p><w:pPr>%s</w:pPr>%s%s%s%s%s</w:p>" % (
            "".join(x), starts(self.bm_start), self.prefix, starts(self.bm_inner),
            guard_zones(self.runs, self.size), bme)

    def all_text(self):
        return self.text


class Cell(object):
    def __init__(self, blocks, width, shd=None, borders=None, valign=None,
                 margins=None):
        if not blocks or not isinstance(blocks[-1], P):
            blocks = list(blocks) + [P(size=2, line=20, line_rule="exact")]
        self.blocks, self.width = blocks, width
        self.shd, self.borders, self.valign, self.margins = shd, borders, valign, margins

    def xml(self):
        x = ['<w:tcW w:w="%d" w:type="dxa"/>' % self.width]
        if self.borders:
            x.append("<w:tcBorders>%s</w:tcBorders>" % _borders(self.borders))
        if self.shd:
            x.append('<w:shd w:val="clear" w:color="auto" w:fill="%s"/>' % self.shd)
        if self.margins:
            x.append("<w:tcMar>%s</w:tcMar>" % _cell_mar(self.margins))
        if self.valign:
            x.append('<w:vAlign w:val="%s"/>' % self.valign)
        return "<w:tc><w:tcPr>%s</w:tcPr>%s</w:tc>" % (
            "".join(x), "".join(b.xml() for b in self.blocks))


_SIDES = ("top", "left", "bottom", "right", "insideH", "insideV")


def _borders(spec):
    """spec: {side: (val, sz, color)} in schema order."""
    out = []
    for side in _SIDES:
        if side in spec:
            val, sz, color = spec[side]
            out.append('<w:%s w:val="%s" w:sz="%d" w:space="0" w:color="%s"/>'
                       % (side, val, sz, color))
    return "".join(out)


def _cell_mar(m):
    return "".join('<w:%s w:w="%d" w:type="dxa"/>' % (side, m[side])
                   for side in ("top", "left", "bottom", "right") if side in m)


class T(object):
    """A table. bidiVisual is written DIRECTLY on every table (docx.md §4-C):
    a style-level flag is not honoured by Word."""

    def __init__(self, rows, widths, ind=0, borders=None, cell_mar=None,
                 shd=None, header_row=False, cant_split=True, row_height=None,
                 rtl=True):
        self.rows, self.widths, self.ind = rows, widths, ind
        self.borders, self.cell_mar, self.shd = borders, cell_mar, shd
        self.header_row, self.cant_split = header_row, cant_split
        self.row_height, self.rtl = row_height, rtl

    def xml(self):
        x = ['<w:bidiVisual/>' if self.rtl else '<w:bidiVisual w:val="0"/>',
             '<w:tblW w:w="%d" w:type="dxa"/>' % sum(self.widths)]
        if self.ind:
            x.append('<w:tblInd w:w="%d" w:type="dxa"/>' % self.ind)
        b = self.borders or {s: ("nil", 0, "auto") for s in _SIDES}
        x.append("<w:tblBorders>%s</w:tblBorders>" % _borders(b))
        if self.shd:
            x.append('<w:shd w:val="clear" w:color="auto" w:fill="%s"/>' % self.shd)
        x.append('<w:tblLayout w:type="fixed"/>')
        cm = self.cell_mar or dict(top=0, left=0, bottom=0, right=0)
        x.append("<w:tblCellMar>%s</w:tblCellMar>" % _cell_mar(cm))
        x.append('<w:tblLook w:val="0000" w:firstRow="0" w:lastRow="0" '
                 'w:firstColumn="0" w:lastColumn="0" w:noHBand="1" w:noVBand="1"/>')
        grid = "".join('<w:gridCol w:w="%d"/>' % w for w in self.widths)
        rows = []
        for k, row in enumerate(self.rows):
            trpr = []
            if self.cant_split:
                trpr.append("<w:cantSplit/>")
            if self.row_height:
                trpr.append('<w:trHeight w:val="%d" w:hRule="atLeast"/>'
                            % self.row_height)
            if self.header_row and k == 0:
                trpr.append("<w:tblHeader/>")
            rows.append("<w:tr>%s%s</w:tr>" % (
                "<w:trPr>%s</w:trPr>" % "".join(trpr) if trpr else "",
                "".join(c.xml() for c in row)))
        return "<w:tbl><w:tblPr>%s</w:tblPr><w:tblGrid>%s</w:tblGrid>%s</w:tbl>" % (
            "".join(x), grid, "".join(rows))


def first_para(blocks):
    for b in blocks:
        if isinstance(b, P):
            return b
        if isinstance(b, T):
            for row in b.rows:
                for c in row:
                    p = first_para(c.blocks)
                    if p is not None:
                        return p
    return None


def last_para(blocks):
    for b in reversed(blocks):
        if isinstance(b, P):
            return b
        if isinstance(b, T):
            for row in reversed(b.rows):
                for c in reversed(row):
                    p = last_para(c.blocks)
                    if p is not None:
                        return p
    return None


def spacer(pt, keep_next=False):
    """An empty paragraph exactly `pt` high: the PDF's block margins around a
    table (Word tables have no spacing of their own), and the guard that keeps
    two tables from fusing into one."""
    tw = max(20, int(round(pt * TW_PER_PT)))
    return P(size=1, line=tw, line_rule="exact", keep_next=keep_next)


def _lines(pt_size, factor):
    return int(round(pt_size * factor * TW_PER_PT))


# ============================================================= figures ===
def _pin_svg_fonts(svg):
    """emit_html._pin_svg_fonts (mirrored; compared in selftest)."""
    svg = _GENERIC_FACE.sub('font-family="David Libre,serif"', svg)
    return _TEXT_NO_FACE.sub('<text font-family="David Libre,serif"', svg)


def true_minus_svg(svg):
    """emit_html.true_minus_svg (mirrored; compared in selftest)."""
    def body(m):
        parts = re.split(r"(<!\[CDATA\[.*?\]\]>|<[^>]+>)", m.group(2), flags=re.S)
        parts = [("<![CDATA[" + p[9:-3].replace("-", MINUS) + "]]>")
                 if p.startswith("<![CDATA[") else
                 p if p.startswith("<") else
                 _HYPHEN_REF.sub(MINUS, p).replace("-", MINUS)
                 for p in parts]
        return m.group(1) + "".join(parts) + m.group(3)
    return _SVG_TEXT.sub(body, u"%s" % svg)


def _is_spec_svg(svg):
    try:
        import wspec_build as _WB
    except Exception:                                  # pragma: no cover
        return False
    return _WB.is_spec_svg(svg)


def head_fig_blob(svg):
    """The figure exactly as fig_html inlines it in the PDF."""
    svg = u"%s" % svg
    return svg if _is_spec_svg(svg) else true_minus_svg(_pin_svg_fonts(svg))


def item_fig_blob(svg):
    """The item figure exactly as emit_plus._prepare stores it."""
    svg = u"%s" % svg
    return svg if _is_spec_svg(svg) else true_minus_svg(svg)


def fig_is_side(blob, side_ok):
    """emit_html.fig_html's side decision, on the same string."""
    if side_ok is True:
        return True
    if side_ok == "auto":
        m = _SVG_W.search(blob)
        return bool(m) and float(m.group(1)) <= SIDE_MAX
    return False


class FigImage(object):
    """A rendered figure: PNG bytes at `dpi`, and its size on the page in pt."""

    def __init__(self, png, width_pt, height_pt, dpi=300):
        self.png, self.width_pt, self.height_pt, self.dpi = png, width_pt, height_pt, dpi


_CHILD_CSS = u"""
@font-face{font-family:"David Libre";src:url("%(A)s/DavidLibre-Regular.ttf");font-weight:400}
@font-face{font-family:"David Libre";src:url("%(A)s/DavidLibre-Bold.ttf");font-weight:700}
@font-face{font-family:"David Libre";src:url("%(A)s/DavidLibre-Medium.ttf");font-weight:500}
@font-face{font-family:"HouseSym";src:url("%(A)s/DejaVuSans.ttf")}
@page{size:180mm 600mm; margin:0}
*{box-sizing:border-box}
html,body{margin:0;padding:0}
body{font-family:"David Libre","DejaVu Serif",serif; direction:rtl;
     font-size:11.6pt; line-height:1.62; color:#111}
.sym{font-family:"HouseSym","DejaVu Sans",sans-serif}
.fig{text-align:center; padding:6pt}
.fig svg{direction:ltr}
.figrow{direction:ltr; margin:0 auto; border-collapse:separate; border-spacing:20pt 0}
.figrow td{text-align:center; vertical-align:bottom}
.figbox{margin-bottom:3pt}
.figcap{direction:rtl; font-size:10pt; color:#222}
.it{padding:6pt; text-align:center}
.it > .ifig{display:inline-block; line-height:0}
.it > .ifig svg{direction:ltr}
.it > .ifig table.figrow{direction:ltr; margin:0 auto}
.it > .ifig table.figrow td{padding:0 7pt}
"""


def _child_render(job_path):
    """Subprocess body: WeasyPrint (the PDF's engine) -> PDF -> PyMuPDF PNG at
    `dpi`, cropped to the drawn ink. Imports nothing from the skill."""
    import weasyprint
    import pymupdf
    job = json.loads(Path(job_path).read_text(encoding="utf-8"))
    css = _CHILD_CSS % dict(A=Path(job["assets"]).as_uri())
    dpi = int(job["dpi"])
    res = []
    for k, it in enumerate(job["items"]):
        if it["kind"] == "item":
            body = u'<div class="it"><span class="ifig">%s</span></div>' % it["blob"]
        else:
            body = u'<div class="fig">%s</div>' % it["blob"]
        doc = (u'<!DOCTYPE html><html lang="he" dir="rtl"><head><meta charset="utf-8">'
               u"<style>%s</style></head><body>%s</body></html>" % (css, body))
        pdf = weasyprint.HTML(string=doc, base_url=job["assets"]).write_pdf()
        d = pymupdf.open(stream=pdf, filetype="pdf")
        if len(d) != 1:
            raise RuntimeError("figure %d spans %d pages" % (k, len(d)))
        page = d[0]
        box = None
        for kind, rect in page.get_bboxlog():
            if not (kind.startswith("fill") or kind.startswith("stroke")):
                continue
            r = pymupdf.Rect(rect)
            if r.is_empty or r.width <= 0 or r.height <= 0:
                continue
            box = r if box is None else box | r
        if box is None:
            raise RuntimeError("figure %d renders no ink" % k)
        pad = 2.0
        box = pymupdf.Rect(box.x0 - pad, box.y0 - pad, box.x1 + pad, box.y1 + pad)
        box = box & page.rect
        pix = page.get_pixmap(dpi=dpi, clip=box, alpha=False)
        out = Path(job["out"]) / ("fig%03d.png" % k)
        pix.save(str(out))
        res.append(dict(png=str(out), width_pt=box.width, height_pt=box.height))
    Path(job["out"], "result.json").write_text(json.dumps(res), encoding="utf-8")


class WeasyFigureRenderer(object):
    """Figures through the same engine as sheet.pdf, in a subprocess (so the
    DYLD path WeasyPrint needs is set for it alone). Results are cached by
    content, so a drawing shared by levels a/b/c is rendered once. There is no
    fallback: a failure raises."""

    def __init__(self, assets=None, dpi=300, python=None, timeout=600):
        self.assets = Path(assets or (SKILL / "assets"))
        self.dpi, self.timeout = dpi, timeout
        self.python = python or sys.executable
        self.cache = {}
        if not (self.assets / "DavidLibre-Regular.ttf").is_file():
            raise RuntimeError("emit_docx: DavidLibre-Regular.ttf not found in %s"
                               % self.assets)

    @staticmethod
    def key(kind, blob):
        return hashlib.sha256((kind + "\x00" + blob).encode("utf-8")).hexdigest()

    def render_many(self, jobs):
        """jobs: [(kind, blob)] -> [FigImage] in the same order."""
        todo = []
        for kind, blob in jobs:
            k = self.key(kind, blob)
            if k not in self.cache and k not in [t[0] for t in todo]:
                todo.append((k, kind, blob))
        if todo:
            tmp = tempfile.mkdtemp(prefix="emit_docx_fig_")
            try:
                job = dict(assets=str(self.assets), dpi=self.dpi, out=tmp,
                           items=[dict(kind=kind, blob=blob) for _k, kind, blob in todo])
                jp = Path(tmp) / "job.json"
                jp.write_text(json.dumps(job), encoding="utf-8")
                env = dict(os.environ)
                dy = env.get("DYLD_FALLBACK_LIBRARY_PATH", "")
                if "/opt/homebrew/lib" not in dy.split(":"):
                    env["DYLD_FALLBACK_LIBRARY_PATH"] = ":".join(
                        [p for p in (dy, "/opt/homebrew/lib") if p])
                env["PYTHONDONTWRITEBYTECODE"] = "1"
                cp = subprocess.run([self.python, str(Path(__file__).resolve()),
                                     "--render-figures", str(jp)],
                                    env=env, capture_output=True, text=True,
                                    timeout=self.timeout)
                if cp.returncode != 0:
                    raise RuntimeError("emit_docx: figure renderer failed (exit %d):\n%s"
                                       % (cp.returncode, cp.stderr[-3000:]))
                res = json.loads((Path(tmp) / "result.json").read_text(encoding="utf-8"))
                for (k, _kind, _blob), r in zip(todo, res):
                    self.cache[k] = FigImage(Path(r["png"]).read_bytes(),
                                             r["width_pt"], r["height_pt"], self.dpi)
            finally:
                for f in Path(tmp).glob("*"):
                    try:
                        f.unlink()
                    except OSError:
                        pass
                try:
                    os.rmdir(tmp)
                except OSError:
                    pass
        return [self.cache[self.key(kind, blob)] for kind, blob in jobs]


def _png_size(png):
    if png[:8] != b"\x89PNG\r\n\x1a\n":
        raise DocxError("figure is not a PNG")
    w, h = struct.unpack(">II", png[16:24])
    return w, h


def _render_all(renderer, jobs):
    if not jobs:
        return []
    if hasattr(renderer, "render_many"):
        got = renderer.render_many(jobs)
    else:
        got = [renderer(kind, blob) for kind, blob in jobs]
    out = []
    for g in got:
        if isinstance(g, FigImage):
            out.append(g)
        else:
            png, w, h = g
            out.append(FigImage(png, w, h))
    return out


# ======================================================== text widths ===
_FONT_CACHE = {}


def _advance_pt(text, size, bold=False):
    """Width of `text` in David Libre (close to Word's David), for table
    column weights. A missing glyph counts half an em."""
    face = "DavidLibre-Bold.ttf" if bold else "DavidLibre-Regular.ttf"
    f = _FONT_CACHE.get(face)
    if f is None:
        try:
            from fontTools.ttLib import TTFont
            tt = TTFont(str(SKILL / "assets" / face))
            f = (tt.getBestCmap(), tt["hmtx"], tt["head"].unitsPerEm)
        except Exception:
            f = (None, None, 1000)
        _FONT_CACHE[face] = f
    cmap, hmtx, upem = f
    w = 0
    for ch in text:
        gn = cmap.get(ord(ch)) if cmap else None
        w += hmtx[gn][0] if gn else upem * 0.5
    return w * size / upem


# ============================================================ document ===
class _Doc(object):
    def __init__(self, renderer):
        self.renderer = renderer
        self.images = []          # (rid, name, png)
        self.bm_next = 0
        self.bookmarks = []
        self.docpr = 0
        self.fig_index = {}       # blob key -> FigImage
        self.nmath = 0
        self.wide = []            # islands too wide for one unbreakable line

    def bookmark(self, name):
        self.bm_next += 1
        self.bookmarks.append(name)
        return (self.bm_next, name)

    def image_run(self, fig, descr, max_w_pt=None):
        w, h = fig.width_pt, fig.height_pt
        if max_w_pt and w > max_w_pt:
            h = h * max_w_pt / w
            w = max_w_pt
        cx, cy = int(round(w * EMU_PER_PT)), int(round(h * EMU_PER_PT))
        self.docpr += 1
        rid = "rIdImg%d" % self.docpr
        name = "image%d.png" % self.docpr
        self.images.append((rid, name, fig.png))
        did = self.docpr
        return ('<w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0">'
                '<wp:extent cx="%d" cy="%d"/><wp:effectExtent l="0" t="0" r="0" b="0"/>'
                '<wp:docPr id="%d" name="Figure %d" descr="%s"/>'
                '<wp:cNvGraphicFramePr><a:graphicFrameLocks noChangeAspect="1"/>'
                '</wp:cNvGraphicFramePr><a:graphic><a:graphicData '
                'uri="http://schemas.openxmlformats.org/drawingml/2006/picture">'
                '<pic:pic><pic:nvPicPr><pic:cNvPr id="%d" name="%s"/><pic:cNvPicPr/>'
                '</pic:nvPicPr><pic:blipFill><a:blip r:embed="%s"/><a:stretch>'
                '<a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm>'
                '<a:off x="0" y="0"/><a:ext cx="%d" cy="%d"/></a:xfrm>'
                '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic>'
                '</a:graphicData></a:graphic></wp:inline></w:drawing></w:r>'
                % (cx, cy, did, did, _esc(descr), did, name, rid, cx, cy)), w, h


def _fig_ids_for_question(q):
    """deliver's figure ids for this question (q7_head, q7_head_2, q7b)."""
    import deliver as D
    n = q.get("n")
    head = ["q%s_head%s" % (n, "" if k == 0 else "_%d" % (k + 1))
            for k in range(len(D.svgs_in(q.get("fig"))))]
    return head


def _item_parts(it):
    it = tuple(it)
    lab = it[0] if len(it) > 0 else u""
    txt = it[1] if len(it) > 1 else u""
    sp = it[2] if len(it) > 2 else 0
    fig = it[3] if len(it) > 3 and it[3] else None
    return lab, txt, sp, fig


def _item_id(n, lab):
    import deliver as D
    return D.item_id(n, lab)


class _Builder(object):
    def __init__(self, Ln, doc, scale, breaks):
        self.L, self.doc, self.scale, self.breaks = Ln, doc, scale, set(breaks or ())
        self.body_line = _lines(SZ["body"], LINE["body"])
        # width of the column being filled: the text column, or the text cell
        # beside a side figure (examples, tables and item figures fit into it)
        self.col = TEXT_W

    # ---- small paragraph helpers --------------------------------------
    def inl(self, text, size, bold=False, color=None, display=False, avail_tw=None):
        """inline() for a line `avail_tw` twips wide (default: the column)."""
        w = self.col if avail_tw is None else avail_tw
        runs, t, nm = inline(text, size, bold, color, display=display,
                             avail_pt=w / float(TW_PER_PT), report=self.doc.wide)
        self.doc.nmath += nm
        return runs, t, nm

    def para(self, text, size, bold=False, color=None, display=False, avail_tw=None,
             **kw):
        runs, t, nm = self.inl(text, size, bold, color, display, avail_tw)
        kw.setdefault("line", _lines(size, LINE["body"]))
        return P(runs, t, size=size, **kw)

    def marker_runs(self, n, star, size=SZ["body"]):
        r = run(marker_text(n), size, bold=True)
        t = marker_text(n)
        if star:
            r += run(u"★", size * 9.4 / 11.6, bold=False, font=SYM_FONT)
            t += u"★"
        return r, t

    # ---- head -----------------------------------------------------------
    def head(self):
        L = self.L
        out = []
        lvl_runs, lvl_t, _n1 = self.inl(L["level"], SZ["lvl"], True, "222222")
        g_runs, g_t, _n2 = self.inl(L.get("grade", u"כיתה ט׳"), SZ["lvl"], True, "222222")
        out.append(P(lvl_runs + run(u" · ", SZ["lvl"], True, "222222") + g_runs,
                     lvl_t + u" · " + g_t, size=SZ["lvl"], after=9 * TW_PER_PT,
                     line=_lines(SZ["lvl"], 1.3),
                     border=[("bottom", "single", 12, 3, "111111")]))
        out.append(self.para(L["title"], SZ["h1"], True, center=True,
                             after=2 * TW_PER_PT, line=_lines(SZ["h1"], 1.25),
                             style="Heading1"))
        out.append(self.para(self.sub_line(), SZ["sub"], False, "333333",
                             center=True, after=9 * TW_PER_PT))
        # emit_html: "שם: ___&nbsp;&nbsp;&nbsp;\nכיתה: ..." (the newline is a space)
        idl = (u"שם: " + u"_" * 25 + u"\u00a0\u00a0\u00a0 כיתה: " + u"_" * 8
               + u"\u00a0\u00a0\u00a0תאריך: " + u"_" * 12)
        out.append(P(run(idl, SZ["idline"]), idl, size=SZ["idline"], center=True,
                     after=10 * TW_PER_PT, line=_lines(SZ["idline"], LINE["body"])))
        rule = L.get("rule")
        if rule:
            p = self.para(rule, SZ["rule"], line=_lines(SZ["rule"], LINE["rule"]),
                          avail_tw=TEXT_W - 400)
            # shading on the CELL: Word paints no table-level shd (microprobe M3)
            out.append(T([[Cell([p], TEXT_W, shd="F2F2F0")]], [TEXT_W],
                         borders={s: ("single", 6, "D8D8D4")
                                  for s in ("top", "left", "bottom", "right")},
                         cell_mar=dict(top=140, left=200, bottom=140, right=200)))
            out.append(spacer(12))
        return out

    def sub_line(self):
        """emit_html._sub_line: unbreakable pieces, last two glued."""
        L = self.L
        parts = ([L.get("grade", u"כיתה ט׳")]
                 + (u"%s" % L.get("subtitle", u"דף עבודה")).split(u" · ")
                 + [L["level"]])
        parts = [p if "$" in p else p.strip().replace(u" ", u"\u00a0") for p in parts]
        tail = u"\u00a0\u00b7\u00a0".join(parts[-2:])
        return u" · ".join(parts[:-2] + [tail])

    # ---- band -------------------------------------------------------------
    def band(self, part, brk):
        name, rng = part[0], (part[1] if len(part) > 1 else None)
        runs, t, _nm = self.inl(name, SZ["band"], True, avail_tw=TEXT_W - 360 - 400)
        if rng:
            word = u"שאלה" if re.fullmatch(r"\s*\d+\s*", rng or "") else u"שאלות"
            runs += run(u" %s " % word, SZ["band"])
            runs += run(LRM + rng + LRM, SZ["band"], rtl=False)
            t += u" %s %s" % (word, rng)
        return P(runs, t, size=SZ["band"], before=13 * TW_PER_PT,
                 after=9 * TW_PER_PT, keep_next=True, keep_lines=True,
                 page_break=brk, shd="E9E9E6", ind_start=180, ind_end=180,
                 line=_lines(SZ["band"], 1.4), style="Heading2",
                 border=[(s, "single", 8, sp, "111111") for s, sp in
                         (("top", 3), ("left", 9), ("bottom", 3), ("right", 9))])

    # ---- question pieces ---------------------------------------------------
    def intro_paras(self, intro, marker=None):
        lines = intro if isinstance(intro, list) else [intro]
        out = []
        for k, ln in enumerate(lines):
            disp = is_display(ln)
            with_marker = bool(k == 0 and marker)
            start = Q_GUTTER + (MLINE_IN if disp and DISPLAY_ALIGN == "start" else 0)
            runs, t, _nm = self.inl(ln, SZ["body"], display=disp and not with_marker,
                                    avail_tw=self.col - start)
            kw = dict(size=SZ["body"], ind_start=start, keep_next=True,
                      after=2 * TW_PER_PT, line=self.body_line)
            if disp:
                kw["line"] = _lines(SZ["body"], 2.0)
            if with_marker:
                mr, mt = marker
                runs = mr + run(u"\t", SZ["body"]) + runs
                t = mt + u" " + t
                kw["hanging"] = start
            out.append(P(runs, t, **kw))
        return out

    def marker_para(self, marker):
        mr, mt = marker
        return P(mr, mt, size=SZ["body"], keep_next=True, line=self.body_line)

    def example_table(self, example, marker=None):
        """The worked example (.ex): a shaded box with a 3px rule on its START
        (right) edge, 44pt in from the margin. When it opens the question the
        marker sits in a gutter cell beside it, where .qmarkabs puts it.
        In a bidiVisual table w:left IS the start edge (microprobe M3)."""
        title, lines = example
        w = self.col - Q_GUTTER
        inner = w - 400                                   # cell margins 200 + 200
        blocks = [self.para(title, SZ["ex"], True, after=2 * TW_PER_PT,
                            keep_next=True, line=_lines(SZ["ex"], LINE["ex"]),
                            avail_tw=inner)]
        for ln in lines:
            disp = is_display(ln)
            kw = dict(before=TW_PER_PT, after=TW_PER_PT, keep_next=True,
                      line=_lines(SZ["ex"], 2.0 if disp else LINE["ex"]),
                      display=disp, avail_tw=inner)
            if disp and DISPLAY_ALIGN == "start":
                kw["ind_start"] = MLINE_IN
                kw["avail_tw"] = inner - MLINE_IN
            blocks.append(self.para(ln, SZ["ex"], **kw))
        box = Cell(blocks, w, shd="F6F6F4",
                   borders={"left": ("single", 18, "999999")},
                   margins=dict(top=120, left=200, bottom=140, right=200))
        mk = [self.marker_para(marker)] if marker else [P(size=SZ["body"], line=None)]
        gutter = Cell(mk, Q_GUTTER, margins=dict(top=0, left=0, bottom=0, right=0))
        return T([[gutter, box]], [Q_GUTTER, w])

    def q_table(self, t):
        head = t.get("head") or []
        rows = ([[(c, True) for c in head]] if head else []) + [
            [(c, bool(t.get("hcol")) and k == 0) for k, c in enumerate(r)]
            for r in t.get("rows") or []]
        if not rows:
            return None
        ncol = max(len(r) for r in rows)
        weights = [56.0 + 18.0] * ncol      # min-width 56pt + 2 x 9pt padding
        for r in rows:
            for k, (c, th) in enumerate(r):
                wpt = _advance_pt(seg_text(c), SZ["th"] if th else SZ["td"], th) + 18
                weights[k] = max(weights[k], wpt)
        wide = "wide" in (t.get("cls") or "").split()
        ind = Q_GUTTER + (0 if wide else MLINE_IN)
        avail = (self.col - ind) / float(TW_PER_PT)
        total = sum(weights)
        if total > avail:
            weights = [w * avail / total for w in weights]
        widths = [int(round(w * TW_PER_PT)) for w in weights]
        trs = []
        for r in rows:
            cells = []
            for k in range(ncol):
                c, th = r[k] if k < len(r) else (u"", False)
                p = self.para(c, SZ["th"] if th else SZ["td"], th, center=True,
                              keep_next=True, line=_lines(SZ["td"], 1.3),
                              avail_tw=widths[k] - 360)
                cells.append(Cell([p], widths[k], shd="EFEFEC" if th else None,
                                  valign="center"))
            trs.append(cells)
        return T(trs, widths, ind=ind,
                 borders={s: ("single", 6, "444444") for s in _SIDES},
                 cell_mar=dict(top=64, left=180, bottom=64, right=180),
                 header_row=bool(head), row_height=19 * TW_PER_PT)

    def fig_para(self, fig, descr, center_in_q=True):
        r, _w, _h = self.doc.image_run(fig, descr, max_w_pt=(self.col - Q_GUTTER) / 20.0)
        return P(r, u"", center=True, ind_start=Q_GUTTER if center_in_q else 0,
                 before=6 * TW_PER_PT, after=8 * TW_PER_PT, keep_next=True,
                 line=None)

    def item_blocks(self, q, it, marker, last, keep):
        """One sub-item: label + text, its writing room, and its dashed rule.
        Returns (blocks, item_para)."""
        lab, txt, sp, fig = _item_parts(it)
        start = Q_GUTTER + I_GUTTER
        img = figw = None
        if fig is not None:
            img = self.doc.fig_index[WeasyFigureRenderer.key("item", item_fig_blob(fig))]
            figw = int(round((img.width_pt + 12) * TW_PER_PT))
        line_w = (self.col if figw is None else self.col - figw) - start
        runs, t, _nm = self.inl(txt, SZ["body"], avail_tw=line_w)
        lt = item_label_text(lab)
        label = run(lt, SZ["body"], bold=True)
        # keep_next: the item, its writing room and its rule are one unit, as
        # `.it{break-inside:avoid}` makes them in the PDF — otherwise Word
        # carries the dashed rule alone to the top of the next page.
        kw = dict(size=SZ["body"], ind_start=start, hanging=I_GUTTER,
                  before=TW_PER_PT, keep_lines=True, line=self.body_line,
                  keep_next=True)
        text = lt + u" " + t
        runs = label + run(u"\t", SZ["body"]) + runs
        prefix = ""
        if marker:
            mr, mt = marker
            prefix = mr + run(u"\t", SZ["body"])
            text = mt + u" " + text
            kw["hanging"] = start
            kw["tabs"] = (Q_GUTTER,)
        after_rule = (2 + 7) if last else 6
        if fig is None:
            kw["after"] = int(round(float(sp) * self.scale * TW_PER_PT))
            p = P(runs, text, **kw)
            p.prefix = prefix
            blocks = [p, self.rule_para(0, after_rule, keep)]
            return blocks, p
        # a figure inside the sub-item: text on the right, drawing on the left
        iid = _item_id(q.get("n"), lab)
        r, _w, _h = self.doc.image_run(img, iid)
        txtw = self.col - figw
        p = P(runs, text, **kw)
        p.prefix = prefix
        fp = P(r, u"", center=True, line=None, keep_next=True)
        tbl = T([[Cell([p], txtw, valign="top"), Cell([fp], figw, valign="top")]],
                [txtw, figw])
        m = re.search(r'<svg[^>]*\bheight="([\d.]+)', u"%s" % fig)
        ifs = float(sp) if not m else max(6.0, float(sp) + 6.0 - float(m.group(1)) * _PX_TO_PT)
        return [tbl, self.rule_para(ifs * self.scale, after_rule, keep)], p

    def rule_para(self, before_pt, after_pt, keep):
        """The item's dashed writing rule (.it border-bottom), as the top
        border of an empty 1pt paragraph, so it sits under the writing room."""
        return P(size=1, ind_start=Q_GUTTER, line=20, line_rule="exact",
                 before=int(round(before_pt * TW_PER_PT)),
                 after=int(round(after_pt * TW_PER_PT)), keep_next=keep,
                 border=[("top", "dashed", 4, 0, "BCBCBC")])

    # ---- one question -------------------------------------------------------
    def question(self, q):
        n = q.get("n")
        qid = u"q%s" % n
        keep = bool(q.get("keep") or self.L.get("keep_questions"))
        pre = []
        if q.get("part"):
            pre.append(self.band(q["part"], n in self.breaks))
        marker = self.marker_runs(n, q.get("star"))

        fig_blob = head_fig_blob(q["fig"]) if q.get("fig") else None
        side = bool(fig_blob) and fig_is_side(fig_blob, q.get("fig_side", "auto"))
        items = list(q.get("items") or [])
        has_intro = bool(q.get("intro"))
        # who carries the marker: the first paragraph the PDF prints at the top
        first = ("example" if q.get("example") else "intro" if has_intro else
                 "fig" if (fig_blob and not side) else
                 "table" if q.get("table") else "item" if items else "empty")
        marker_used = [False]

        def take_marker(kind):
            if kind == first and not marker_used[0]:
                marker_used[0] = True
                return marker
            return None

        fig_img = fig_descr = None
        figw = 0
        if fig_blob:
            fig_img = self.doc.fig_index[WeasyFigureRenderer.key("head", fig_blob)]
            fig_descr = u" ".join(_fig_ids_for_question(q)) or u"%s_head" % qid
            if side:
                # .qtop.split: the drawing keeps its own width (capped at half
                # the question column) plus the 12pt gap; the text takes the rest
                figw = int(round((min(fig_img.width_pt, (TEXT_W - Q_GUTTER) / 40.0) + 12)
                                 * TW_PER_PT))
                self.col = TEXT_W - figw

        head = []
        if q.get("example"):
            head.append(spacer(4, keep_next=True))
            head.append(self.example_table(q["example"], take_marker("example")))
            head.append(spacer(9, keep_next=True))
        if has_intro:
            head.extend(self.intro_paras(q["intro"], take_marker("intro")))
        if fig_blob and not side:
            if first == "fig":
                head.append(self.marker_para(take_marker("fig")))
            head.append(self.fig_para(fig_img, fig_descr))
        if q.get("table"):
            tb = self.q_table(q["table"])
            if tb is not None:
                if first == "table":
                    head.append(self.marker_para(take_marker("table")))
                head.append(spacer(5, keep_next=True))
                head.append(tb)
                head.append(spacer(8, keep_next=True))

        item_blocks = []
        for k, it in enumerate(items):
            mk = take_marker("item") if k == 0 else None
            blocks, ip = self.item_blocks(q, it, mk, k == len(items) - 1,
                                          keep and k < len(items) - 1)
            lab = _item_parts(it)[0]
            b = self.doc.bookmark(_item_id(n, lab))
            ip.bm_inner.append(b)
            ip.bm_end.append(b)
            item_blocks.append(blocks)
            self.col = TEXT_W               # only items[0] sits beside the figure
        if not items:
            sp = float(q.get("space", 30)) * self.scale
            mk = take_marker("empty")
            runs, t = (mk if mk else ("", u""))
            after = max(0, int(round(sp * TW_PER_PT)) - self.body_line)
            item_blocks.append([P(runs, t, size=SZ["body"], line=self.body_line,
                                  after=after, keep_next=True),
                                self.rule_para(0, 9, keep)])
        self.col = TEXT_W
        if not marker_used[0]:                     # pragma: no cover
            raise DocxError("question %s: the marker found no paragraph" % n)

        if side:
            txtw = TEXT_W - figw
            r, _w, _h = self.doc.image_run(fig_img, fig_descr, max_w_pt=figw / 20.0 - 12)
            left = [P(r, u"", center=True, before=2 * TW_PER_PT,
                      after=6 * TW_PER_PT, line=None)]
            right = head + (item_blocks[0] if item_blocks else [])
            blocks = [T([[Cell(right, txtw, valign="top"),
                          Cell(left, figw, valign="top")]], [txtw, figw])]
            for ib in item_blocks[1:]:
                blocks.extend(ib)
        else:
            blocks = list(head)
            for ib in item_blocks:
                blocks.extend(ib)

        fp, lp = first_para(blocks), last_para(blocks)
        b = self.doc.bookmark(qid)
        fp.bm_start.insert(0, b)
        lp.bm_end.append(b)
        return pre + blocks

    # ---- answers ------------------------------------------------------------
    def answers(self):
        ans = self.L.get("answers") or []
        if not ans:
            return []
        out = [P(run(u"תשובות סופיות", SZ["ansband"], True), u"תשובות סופיות",
                 size=SZ["ansband"], page_break=True, after=7 * TW_PER_PT,
                 shd="E9E9E6", ind_start=180, ind_end=180, keep_next=True,
                 line=_lines(SZ["ansband"], 1.4), style="Heading2",
                 border=[(s, "single", 8, sp, "111111") for s, sp in
                         (("top", 4), ("left", 9), ("bottom", 4), ("right", 9))])]
        out.append(self.para(self.L.get("ansnote") or ANSNOTE, SZ["ansnote"],
                             False, "444444", after=6 * TW_PER_PT, keep_next=True))
        mw = 36 * TW_PER_PT
        bw = TEXT_W - mw
        rows = []
        for a in ans:
            n, segs = a[0], a[1]
            star = len(a) > 2 and a[2]
            mr, mt = self.marker_runs(n, star, SZ["amark"])
            mp = P(mr, mt, size=SZ["amark"], line=_lines(SZ["abody"], LINE["abody"]))
            body, pieces, texts = [], [], []
            for lab, txt in segs:
                if not lab:
                    if pieces:
                        body.append(P("".join(pieces), u"  ".join(texts),
                                      size=SZ["abody"],
                                      line=_lines(SZ["abody"], LINE["abody"])))
                        pieces, texts = [], []
                    body.append(self.para(txt, SZ["anote"], False, "444444",
                                          line=_lines(SZ["abody"], LINE["abody"]),
                                          avail_tw=bw))
                    continue
                lt = item_label_text(lab)
                runs, t, _nm = self.inl(txt, SZ["abody"], avail_tw=bw - 20 * TW_PER_PT)
                if pieces:
                    pieces.append(run(u"   ", SZ["abody"]))
                # No-break space: Word otherwise breaks the line right after the
                # label when the answer opens with a math zone that does not fit,
                # leaving "ג." alone at the end of a line (G7-T92 level c, q5,
                # integration 2026-11-09). The PDF keeps the label with its answer.
                pieces.append(run(lt, SZ["abody"], True) + run(u"\u00a0", SZ["abody"]) + runs)
                texts.append(lt + u" " + t)
            if pieces:
                body.append(P("".join(pieces), u"  ".join(texts), size=SZ["abody"],
                              line=_lines(SZ["abody"], LINE["abody"])))
            if not body:
                body.append(P(size=SZ["abody"]))
            b = self.doc.bookmark(u"ans_q%s" % n)
            mp.bm_start.append(b)
            body[-1].bm_end.append(b)
            bd = {"bottom": ("single", 4, "D6D6D2")}
            rows.append([Cell([mp], mw, borders=bd, valign="top",
                              margins=dict(top=27, bottom=27, left=160, right=0)),
                         Cell(body, bw, borders=bd, valign="top",
                              margins=dict(top=27, bottom=27, left=0, right=0))])
        out.append(T(rows, [mw, bw]))
        out.append(spacer(1))
        return out

    # ---- whole sheet ----------------------------------------------------------
    def body(self):
        blocks = self.head()
        for q in self.L["questions"]:
            blocks.extend(self.question(q))
        blocks.append(self.para(u"בהצלחה!", SZ["good"], True, center=True,
                                before=14 * TW_PER_PT))
        blocks.extend(self.answers())
        if not isinstance(blocks[-1], P):
            blocks.append(spacer(1))
        # two tables in a row would fuse in Word: keep a paragraph between
        fixed = []
        for b in blocks:
            if fixed and isinstance(b, T) and isinstance(fixed[-1], T):
                fixed.append(spacer(1))
            fixed.append(b)
        return fixed


# -------------------------------------------------------------- parts ---
def _sect_pr():
    return ('<w:sectPr><w:headerReference w:type="default" r:id="rIdHdr1"/>'
            '<w:footerReference w:type="default" r:id="rIdFtr1"/>'
            '<w:pgSz w:w="%d" w:h="%d"/>'
            '<w:pgMar w:top="%d" w:right="%d" w:bottom="%d" w:left="%d" '
            'w:header="%d" w:footer="%d" w:gutter="0"/>'
            '<w:cols w:space="708"/><w:bidi/><w:docGrid w:linePitch="360"/></w:sectPr>'
            % (PAGE_W, PAGE_H, MARGIN["top"], MARGIN["right"], MARGIN["bottom"],
               MARGIN["left"], MARGIN["header"], MARGIN["footer"]))


def _header_xml():
    w3 = [int(TEXT_W * 0.25), TEXT_W - 2 * int(TEXT_W * 0.25), int(TEXT_W * 0.25)]
    sz = SZ["head"]
    cells = [Cell([P(run(BSD, sz, color="666666"), size=sz, line=None)], w3[0]),
             Cell([P(run(BRAND, sz, color="666666"), size=sz, center=True, line=None)], w3[1]),
             Cell([P(size=sz, line=None)], w3[2])]
    tbl = T([cells], w3, cant_split=False)
    return (XML_HEAD + u"<w:hdr %s>%s%s</w:hdr>"
            % (NSDECL, tbl.xml(), P(size=1, line=20, line_rule="exact").xml()))


def _field(instr, sz, color):
    return ('<w:fldSimple w:instr=" %s \\* MERGEFORMAT ">%s</w:fldSimple>'
            % (instr, run(u"1", sz, color=color)))


def _footer_xml():
    w3 = [_mm_tw(40), _mm_tw(48), TEXT_W - _mm_tw(40) - _mm_tw(48)]
    fs, cs = SZ["foot"], SZ["copy"]
    page = (run(u"עמוד ", fs, color="555555") + _field("PAGE", fs, "555555")
            + run(u" מתוך ", fs, color="555555") + _field("NUMPAGES", fs, "555555"))
    cells = [Cell([P(run(BRAND, fs, color="666666"), size=fs, line=None)], w3[0]),
             Cell([P(page, size=fs, center=True, line=None)], w3[1]),
             Cell([P(run(COPYRIGHT, cs, color="8A8A8A"), size=cs, line=None)], w3[2],
                  valign="center")]
    tbl = T([cells], w3, cant_split=False)
    return (XML_HEAD + u"<w:ftr %s>%s%s</w:ftr>"
            % (NSDECL, tbl.xml(), P(size=1, line=20, line_rule="exact").xml()))


def _styles_xml():
    hp = _hp(SZ["body"])
    rf = ('<w:rFonts w:ascii="%s" w:hAnsi="%s" w:eastAsia="%s" w:cs="%s"/>'
          % (FONT, FONT, FONT, FONT))
    lang = '<w:lang w:val="he-IL" w:eastAsia="en-US" w:bidi="he-IL"/>'
    return (XML_HEAD + u'<w:styles %s><w:docDefaults><w:rPrDefault><w:rPr>%s'
            '<w:sz w:val="%d"/><w:szCs w:val="%d"/>%s</w:rPr></w:rPrDefault>'
            '<w:pPrDefault><w:pPr><w:bidi/><w:spacing w:after="0" w:line="240" '
            'w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults>'
            '<w:style w:type="paragraph" w:default="1" w:styleId="Normal">'
            '<w:name w:val="Normal"/><w:qFormat/><w:pPr><w:widowControl/><w:bidi/>'
            '<w:spacing w:after="0" w:line="%d" w:lineRule="atLeast"/></w:pPr>'
            '<w:rPr>%s<w:sz w:val="%d"/><w:szCs w:val="%d"/>%s</w:rPr></w:style>'
            '<w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/>'
            '<w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/>'
            '<w:pPr><w:keepNext/><w:keepLines/><w:bidi/><w:outlineLvl w:val="0"/></w:pPr>'
            '<w:rPr><w:b/><w:bCs/></w:rPr></w:style>'
            '<w:style w:type="paragraph" w:styleId="Heading2"><w:name w:val="heading 2"/>'
            '<w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/>'
            '<w:pPr><w:keepNext/><w:keepLines/><w:bidi/><w:outlineLvl w:val="1"/></w:pPr>'
            '</w:style>'
            '<w:style w:type="character" w:default="1" w:styleId="DefaultParagraphFont">'
            '<w:name w:val="Default Paragraph Font"/><w:uiPriority w:val="1"/>'
            '<w:semiHidden/><w:unhideWhenUsed/></w:style>'
            '<w:style w:type="table" w:default="1" w:styleId="TableNormal">'
            '<w:name w:val="Normal Table"/><w:uiPriority w:val="99"/><w:semiHidden/>'
            '<w:unhideWhenUsed/><w:tblPr><w:bidiVisual/><w:tblInd w:w="0" w:type="dxa"/>'
            '<w:tblCellMar><w:top w:w="0" w:type="dxa"/><w:left w:w="108" w:type="dxa"/>'
            '<w:bottom w:w="0" w:type="dxa"/><w:right w:w="108" w:type="dxa"/>'
            '</w:tblCellMar></w:tblPr></w:style>'
            '<w:style w:type="numbering" w:default="1" w:styleId="NoList">'
            '<w:name w:val="No List"/><w:uiPriority w:val="99"/><w:semiHidden/>'
            '<w:unhideWhenUsed/></w:style></w:styles>'
            % (NSDECL, rf, hp, hp, lang, _lines(SZ["body"], LINE["body"]), rf, hp,
               hp, lang))


def _settings_xml():
    return (XML_HEAD + u'<w:settings %s><w:zoom w:percent="100"/>'
            '<w:defaultTabStop w:val="720"/><w:characterSpacingControl '
            'w:val="doNotCompress"/><w:compat><w:compatSetting w:name="compatibilityMode" '
            'w:uri="http://schemas.microsoft.com/office/word" w:val="15"/>'
            '<w:compatSetting w:name="overrideTableStyleFontSizeAndJustification" '
            'w:uri="http://schemas.microsoft.com/office/word" w:val="1"/>'
            '<w:compatSetting w:name="enableOpenTypeFeatures" '
            'w:uri="http://schemas.microsoft.com/office/word" w:val="1"/>'
            '<w:compatSetting w:name="doNotFlipMirrorIndents" '
            'w:uri="http://schemas.microsoft.com/office/word" w:val="1"/></w:compat>'
            '<m:mathPr><m:mathFont m:val="Cambria Math"/><m:brkBin m:val="before"/>'
            '<m:brkBinSub m:val="--"/><m:smallFrac m:val="0"/><m:dispDef/>'
            '<m:lMargin m:val="0"/><m:rMargin m:val="0"/><m:defJc m:val="centerGroup"/>'
            '<m:wrapIndent m:val="1440"/><m:intLim m:val="subSup"/>'
            '<m:naryLim m:val="undOvr"/></m:mathPr>'
            '<w:themeFontLang w:val="en-US" w:bidi="he-IL"/>'
            '<w:doNotAutoCompressPictures/>'
            '<w:decimalSymbol w:val="."/><w:listSeparator w:val=","/></w:settings>'
            % NSDECL)


def _font_table_xml():
    return (XML_HEAD + u'<w:fonts %s>'
            '<w:font w:name="%s"><w:charset w:val="B1"/><w:family w:val="swiss"/>'
            '<w:pitch w:val="variable"/></w:font>'
            '<w:font w:name="%s"><w:charset w:val="00"/><w:family w:val="roman"/>'
            '<w:pitch w:val="variable"/></w:font>'
            '<w:font w:name="%s"><w:charset w:val="00"/><w:family w:val="swiss"/>'
            '<w:pitch w:val="variable"/></w:font></w:fonts>'
            % (NSDECL, FONT, MATH_FONT, SYM_FONT))


def _core_xml(meta):
    def tag(t, v):
        return u"<%s>%s</%s>" % (t, _esc(v), t) if v else u""
    stamp = meta.get("created") or _now_iso()
    return (XML_HEAD + u'<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/'
            u'package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/'
            u'elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" '
            u'xmlns:dcmitype="http://purl.org/dc/dcmitype/" '
            u'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
            + tag("dc:title", meta.get("title")) + tag("dc:subject", meta.get("subject"))
            + tag("dc:creator", BRAND) + tag("cp:keywords", meta.get("keywords"))
            + tag("dc:description", meta.get("description"))
            + tag("cp:lastModifiedBy", BRAND) + tag("dc:language", "he-IL")
            + u'<dcterms:created xsi:type="dcterms:W3CDTF">%s</dcterms:created>'
              u'<dcterms:modified xsi:type="dcterms:W3CDTF">%s</dcterms:modified>'
              u'</cp:coreProperties>' % (stamp, stamp))


def _now_iso():
    sde = os.environ.get("SOURCE_DATE_EPOCH")
    t = (datetime.datetime.fromtimestamp(int(sde), datetime.timezone.utc) if sde
         else datetime.datetime.now(datetime.timezone.utc))
    return t.replace(microsecond=0).strftime("%Y-%m-%dT%H:%M:%SZ")


def _app_xml():
    return (XML_HEAD + u'<Properties xmlns="http://schemas.openxmlformats.org/'
            u'officeDocument/2006/extended-properties"><Application>emit_docx %s'
            u'</Application><DocSecurity>0</DocSecurity><Company>%s</Company>'
            u'</Properties>' % (VERSION, _esc(BRAND)))


_CT = (u'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
       u'<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
       u'<Default Extension="xml" ContentType="application/xml"/>'
       u'<Default Extension="png" ContentType="image/png"/>'
       u'<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
       u'<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>'
       u'<Override PartName="/word/settings.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml"/>'
       u'<Override PartName="/word/fontTable.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.fontTable+xml"/>'
       u'<Override PartName="/word/header1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml"/>'
       u'<Override PartName="/word/footer1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/>'
       u'<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'
       u'<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>'
       u'</Types>')

_RELS = (u'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
         u'<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
         u'<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>'
         u'<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>'
         u'</Relationships>')


def _doc_rels(images):
    base = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/"
    x = [u'<Relationship Id="rIdStyles" Type="%sstyles" Target="styles.xml"/>' % base,
         u'<Relationship Id="rIdSettings" Type="%ssettings" Target="settings.xml"/>' % base,
         u'<Relationship Id="rIdFonts" Type="%sfontTable" Target="fontTable.xml"/>' % base,
         u'<Relationship Id="rIdHdr1" Type="%sheader" Target="header1.xml"/>' % base,
         u'<Relationship Id="rIdFtr1" Type="%sfooter" Target="footer1.xml"/>' % base]
    for rid, name, _png in images:
        x.append(u'<Relationship Id="%s" Type="%simage" Target="media/%s"/>'
                 % (rid, base, name))
    return (XML_HEAD + u'<Relationships xmlns="http://schemas.openxmlformats.org/'
            u'package/2006/relationships">%s</Relationships>' % "".join(x))


def _write_zip(path, parts):
    """Deterministic package: fixed member order and timestamps."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    with zipfile.ZipFile(str(tmp), "w", zipfile.ZIP_DEFLATED) as z:
        for name, data in parts:
            zi = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            zi.compress_type = zipfile.ZIP_DEFLATED
            zi.external_attr = 0o644 << 16
            z.writestr(zi, data if isinstance(data, bytes) else data.encode("utf-8"))
    os.replace(str(tmp), str(path))


# ================================================================ API ===
def _collect_figs(Ln):
    jobs = []
    for q in Ln.get("questions", []):
        if q.get("fig"):
            jobs.append(("head", head_fig_blob(q["fig"])))
        for it in q.get("items") or []:
            fig = _item_parts(it)[3]
            if fig:
                jobs.append(("item", item_fig_blob(fig)))
    seen, out = set(), []
    for j in jobs:
        if j not in seen:
            seen.add(j)
            out.append(j)
    return out


def write_package(out_path, body, images=(), meta=None):
    """Wrap body XML (block-level WordprocessingML) into a complete .docx:
    styles, settings, header/footer, core props. Every XML part is parsed
    before it is written. Returns the document.xml text."""
    meta = dict(meta or {})
    document = (XML_HEAD + u"<w:document %s><w:body>%s%s</w:body></w:document>"
                % (NSDECL, body, _sect_pr()))
    parts = [("[Content_Types].xml", XML_HEAD + _CT), ("_rels/.rels", XML_HEAD + _RELS),
             ("word/document.xml", document), ("word/styles.xml", _styles_xml()),
             ("word/settings.xml", _settings_xml()),
             ("word/fontTable.xml", _font_table_xml()),
             ("word/header1.xml", _header_xml()), ("word/footer1.xml", _footer_xml()),
             ("word/_rels/document.xml.rels", _doc_rels(images)),
             ("docProps/core.xml", _core_xml(meta)), ("docProps/app.xml", _app_xml())]
    for _rid, name, png in images:
        parts.append(("word/media/%s" % name, png))
    for name, data in parts:                     # every XML part must parse
        if name.endswith(".xml") or name.endswith(".rels"):
            try:
                ET.fromstring(data.encode("utf-8") if not isinstance(data, bytes) else data)
            except ET.ParseError as e:
                raise DocxError("emit_docx produced malformed %s: %s" % (name, e))
    _write_zip(out_path, parts)
    return document


_QID_RE = re.compile(r"^q\d+$")


def check_ids(Ln):
    """Every bookmark name must be unique and say what it binds, or the
    binding to sheet.json breaks silently: Word keeps only one of two equal
    bookmark names, and G90 (R11/R16) reads `q<digits>` as a whole question.
    deliver.item_id maps a Hebrew label to a letter (q3b) but keeps any other
    label as written, so question 3 item "1" becomes q31 — question 31's id —
    and "י"/"יא" share q3j. Such a sheet is refused with the reason; the
    remedy is Hebrew letter labels, or a contract change of the item id in
    deliver.item_id (locked) and the checker together. Returns the ids."""
    from collections import Counter
    names, bad = Counter(), []
    for q in Ln.get("questions", []):
        n = q.get("n")
        qid = u"q%s" % n
        if not _QID_RE.match(qid):
            bad.append(u"question number %r gives bookmark %r (expected q<digits>)" % (n, qid))
        names[qid] += 1
        for it in q.get("items") or []:
            lab = _item_parts(it)[0]
            iid = _item_id(n, lab)
            if not re.match(u"^%s[^\\W\\d_]+$" % re.escape(qid), iid):
                bad.append(u"question %s, item label %r -> id %r: not q<n><letters>, so "
                           u"G90/G91 read it as another question" % (n, lab, iid))
            names[iid] += 1
    for a in Ln.get("answers") or []:
        names[u"ans_q%s" % a[0]] += 1
    dup = sorted(k for k, v in names.items() if v > 1)
    if dup:
        bad.append(u"duplicate bookmark names %s (Word keeps one of each)" % u", ".join(dup))
    if bad:
        raise DocxError(u"emit_docx: ambiguous ids — " + u"; ".join(bad)
                        + u". Use Hebrew item labels (א, ב, …); numeric labels need a "
                          u"contract decision on the item id (deliver.item_id is locked).")
    return sorted(names)


def build_docx(Ln, out_path, *, figure_renderer=None, meta=None, breaks=(), scale=None):
    """Write one level as sheet.docx. `Ln` is the normalized level the PDF
    printed (pkgload.load(pkg).ir[k]).

    figure_renderer  object with render_many([(kind, blob)]) -> [FigImage], or a
                     callable (kind, blob) -> FigImage | (png, w_pt, h_pt);
                     default WeasyFigureRenderer() (only built when the level
                     has figures). kind is "head" or "item".
    meta             core properties: title, subject, keywords, description,
                     created (W3CDTF; else SOURCE_DATE_EPOCH; else, when
                     out_path sits in the contract layout out/docx/<k>/, the
                     engine's out/deliver/<k>/build.json built_at — so a
                     rebuild gives the same bytes; else now)
    breaks           question numbers whose part band starts a new page — the
                     same argument as emit_html.build_html (build.py passes none)
    scale            writing-space scale; default = build_html's
                     max(space_scale, 0.75)
    Returns stats: path, sha256, bytes, questions, items, answers, omath,
    images, figures_rendered, bookmarks, paragraphs, tables, wide_islands
    (islands whose estimated Word width exceeds BOX_FIT of their line: they
    may break before a relation; loose_pieces > 0 = a piece wider than the
    line, breakable anywhere — worth a look in the Word render).
    Raises DocxError for content the PDF would refuse and for ambiguous ids
    (check_ids)."""
    meta = dict(meta or {})
    check_ids(Ln)
    if not meta.get("created") and not os.environ.get("SOURCE_DATE_EPOCH"):
        op = Path(out_path)
        t = _built_at(op.parent.parent.parent / "deliver" / op.parent.name / "build.json")
        if t:
            meta["created"] = t
    if scale is None:
        scale = max(float(Ln.get("space_scale", 1.0)), 0.75)    # build_html's floor
    jobs = _collect_figs(Ln)
    if jobs and figure_renderer is None:
        figure_renderer = WeasyFigureRenderer()
    doc = _Doc(figure_renderer)
    for (kind, blob), img in zip(jobs, _render_all(figure_renderer, jobs)):
        doc.fig_index[WeasyFigureRenderer.key(kind, blob)] = img
    B = _Builder(Ln, doc, scale, breaks)
    blocks = B.body()
    body = u"".join(b.xml() for b in blocks)
    qids = [u"q%s" % q.get("n") for q in Ln.get("questions", [])]
    meta.setdefault("title", u"%s · %s" % (Ln.get("title", u""), Ln.get("level", u"")))
    meta.setdefault("subject", Ln.get("package") or u"")
    meta.setdefault("keywords", u"; ".join(
        [u"level:%s" % Ln.get("key", u"")] + ([u" ".join(qids)] if qids else [])))
    document = write_package(out_path, body, doc.images, meta)
    data = Path(out_path).read_bytes()
    return dict(path=str(out_path), sha256=hashlib.sha256(data).hexdigest(),
                bytes=len(data), questions=len(qids),
                items=sum(len(q.get("items") or []) for q in Ln.get("questions", [])),
                answers=len(Ln.get("answers") or []), omath=doc.nmath,
                images=len(doc.images), figures_rendered=len(jobs),
                bookmarks=list(doc.bookmarks), paragraphs=document.count("<w:p>"),
                tables=document.count("<w:tbl>"), wide_islands=list(doc.wide))


# ============================================================ linearize ===
def _norm(s):
    s = unicodedata.normalize("NFC", u"%s" % s)
    s = s.replace(u"\u00a0", u" ").replace(u"-", MINUS)
    s = re.sub(u"[\u200d\u200e\u200f\u2060\u202a-\u202e\u2066-\u2069]", u"", s)
    return re.sub(r"\s+", u" ", s).strip()


def plain_text(dsl):
    """Normalized printed text of one DSL string — the same text the DOCX
    carries for it (islands as their OMML m:t, fractions num+den)."""
    return _norm(seg_text(dsl))


def linearize(Ln):
    """Per-question normalized text, in the DOCX's print order, for the parity
    gate: {"questions": {q<n>: text}, "items": {q<n><x>: text},
    "answers": {q<n>: text}}. A question's text covers its marker, example,
    intro, table and items; an item's its label and text."""
    qs, items, ans = {}, {}, {}
    for q in Ln.get("questions", []):
        n = q.get("n")
        parts = [marker_text(n) + (u"★" if q.get("star") else u"")]
        if q.get("example"):
            title, lines = q["example"]
            parts.append(seg_text(title))
            parts.extend(seg_text(l) for l in lines)
        if q.get("intro"):
            lines = q["intro"] if isinstance(q["intro"], list) else [q["intro"]]
            parts.extend(seg_text(l) for l in lines)
        t = q.get("table")
        if t:
            for c in t.get("head") or []:
                parts.append(seg_text(c))
            for r in t.get("rows") or []:
                parts.extend(seg_text(c) for c in r)
        for it in q.get("items") or []:
            lab, txt = _item_parts(it)[:2]
            s = item_label_text(lab) + u" " + seg_text(txt)
            items[_item_id(n, lab)] = _norm(s)
            parts.append(s)
        qs[u"q%s" % n] = _norm(u" ".join(parts))
    for a in Ln.get("answers") or []:
        n, segs = a[0], a[1]
        parts = [marker_text(n) + (u"★" if len(a) > 2 and a[2] else u"")]
        for lab, txt in segs:
            parts.append((item_label_text(lab) + u" " if lab else u"") + seg_text(txt))
        ans[u"q%s" % n] = _norm(u" ".join(parts))
    return {"questions": qs, "items": items, "answers": ans}


# ===================================================== DOCX read-back ===
_W = "{%s}" % NS["w"]
_M = "{%s}" % NS["m"]


def extract_bookmark_text(docx_path):
    """{bookmark name: normalized text between its start and end} from the
    DOCX itself (stdlib only), so a build can prove it printed what linearize
    says it should."""
    with zipfile.ZipFile(str(docx_path)) as z:
        root = ET.fromstring(z.read("word/document.xml"))
    open_ids, names, acc = {}, {}, {}

    def emit(s):
        for i in open_ids:
            acc[names[i]].append(s)

    def walk(el):
        tag = el.tag
        if tag == _W + "bookmarkStart":
            i = el.get(_W + "id")
            names[i] = el.get(_W + "name")
            acc.setdefault(names[i], [])
            open_ids[i] = True
            return
        if tag == _W + "bookmarkEnd":
            open_ids.pop(el.get(_W + "id"), None)
            return
        if tag in (_W + "t", _M + "t"):
            emit(el.text or u"")
            return
        if tag == _W + "tab":
            emit(u" ")
            return
        for ch in el:
            walk(ch)
        if tag in (_W + "p", _W + "tc"):
            emit(u" ")
    walk(root)
    return {k: _norm(u"".join(v)) for k, v in acc.items()}


def parity_report(docx_path, Ln):
    """Compare the DOCX read-back with linearize(Ln). Returns a list of
    problems (empty = parity)."""
    got = extract_bookmark_text(docx_path)
    want = linearize(Ln)
    bad = []
    for qid, t in want["questions"].items():
        if qid not in got:
            bad.append("missing bookmark %s" % qid)
        elif got[qid] != t:
            bad.append("text of %s differs:\n  docx: %s\n  want: %s" % (qid, got[qid], t))
    for iid, t in want["items"].items():
        if iid not in got:
            bad.append("missing bookmark %s" % iid)
        elif got[iid] != t:
            bad.append("text of %s differs:\n  docx: %s\n  want: %s" % (iid, got[iid], t))
    for qid, t in want["answers"].items():
        k = u"ans_" + qid
        if k not in got:
            bad.append("missing bookmark %s" % k)
        elif got[k] != t:
            bad.append("text of %s differs:\n  docx: %s\n  want: %s" % (k, got[k], t))
    return bad


# ========================================================== invariants ===
_INLINE_CONTAINERS = None


def _inline_children(p):
    """A paragraph's runs and math zones in order: through w:hyperlink,
    w:fldSimple, w:smartTag, w:ins and w:sdtContent, never into a nested
    paragraph (text boxes) — the token stream check_docx_rtl reads."""
    global _INLINE_CONTAINERS
    if _INLINE_CONTAINERS is None:
        _INLINE_CONTAINERS = set(_W + t for t in ("hyperlink", "fldSimple", "smartTag",
                                                  "ins", "sdt", "sdtContent",
                                                  "customXml"))
    for ch in p:
        if ch.tag in (_W + "r", _M + "oMath", _M + "oMathPara"):
            yield ch
        elif ch.tag in _INLINE_CONTAINERS:
            for x in _inline_children(ch):
                yield x


def rtl_invariants(docx_path):
    """The docx.md §4 rules this writer guarantees, checked on the package
    (a subset of check_docx_rtl R1–R17: R1 R3 R4 R5 R6 R7 R9 R10 R13).
    Returns a list of violations."""
    bad = []
    with zipfile.ZipFile(str(docx_path)) as z:
        names = z.namelist()
        if "docProps/thumbnail.jpeg" in names:
            bad.append("R13 thumbnail present")
        settings = z.read("word/settings.xml").decode("utf-8")
        if 'w:name="compatibilityMode"' not in settings or 'w:val="15"' not in settings:
            bad.append("R13 compatibilityMode != 15")
        core = z.read("docProps/core.xml").decode("utf-8")
        if "python-docx" in core:
            bad.append("R13 creator python-docx")
        stories = [n for n in names if re.match(r"word/(document|header\d*|footer\d*)\.xml$", n)]
        for part in stories:
            root = ET.fromstring(z.read(part))
            for sp in root.iter(_W + "sectPr"):
                if sp.find(_W + "bidi") is None:
                    bad.append("R1 %s sectPr without bidi" % part)
            for k, p in enumerate(root.iter(_W + "p")):
                ppr = p.find(_W + "pPr")
                if ppr is None or ppr.find(_W + "bidi") is None:
                    bad.append("R3 %s paragraph %d without bidi" % (part, k))
                if ppr is not None:
                    jc = ppr.find(_W + "jc")
                    if jc is not None and jc.get(_W + "val") in ("right", "end"):
                        bad.append("R4 %s paragraph %d jc=%s" % (part, k, jc.get(_W + "val")))
                # R9 as check_docx_rtl applies it (G90): between two math zones
                # the runs must hold a strong RTL character (Hebrew or RLM)
                last_zone, sep = False, []
                for el in _inline_children(p):
                    if el.tag in (_M + "oMath", _M + "oMathPara"):
                        if last_zone and not strong_rtl(u"".join(sep)):
                            bad.append("R9 %s paragraph %d: two OMML zones separated by %r "
                                       "(no strong RTL character / RLM)"
                                       % (part, k, u"".join(sep)))
                        last_zone, sep = True, []
                    elif el.tag == _W + "r":
                        sep.append(u"".join(t.text or u"" for t in el.iter(_W + "t")))
            for k, tbl in enumerate(root.iter(_W + "tbl")):
                tp = tbl.find(_W + "tblPr")
                if tp is None or tp.find(_W + "bidiVisual") is None:
                    bad.append("R5 %s table %d without direct bidiVisual" % (part, k))
            for k, r in enumerate(root.iter(_W + "r")):
                rpr = r.find(_W + "rPr")
                txt = u"".join(t.text or u"" for t in r.iter(_W + "t"))
                rtl = rpr is not None and rpr.find(_W + "rtl") is not None and \
                    rpr.find(_W + "rtl").get(_W + "val") not in ("0", "false", "off")
                if not (rtl or _HEB_CHAR.search(txt)):
                    continue
                if rpr is None:
                    bad.append("R6 %s run %d without rPr" % (part, k))
                    continue
                for a, b in (("b", "bCs"), ("i", "iCs"), ("sz", "szCs")):
                    ea, eb = rpr.find(_W + a), rpr.find(_W + b)
                    va = None if ea is None else ea.get(_W + "val", "1")
                    vb = None if eb is None else eb.get(_W + "val", "1")
                    if va != vb:
                        bad.append("R6 %s run %d %s/%s differ: %r" % (part, k, a, b, txt[:30]))
                rf = rpr.find(_W + "rFonts")
                if rf is None or not rf.get(_W + "cs"):
                    bad.append("R6 %s run %d without rFonts@cs" % (part, k))
                if rtl and re.search(r"[0-9A-Za-z)]\s*[+\-−×·*/=<>≤≥≠≈^∶]\s*[0-9A-Za-z(]", txt):
                    bad.append("R7 %s run %d math in RTL run: %r" % (part, k, txt[:40]))
            for t in list(root.iter(_W + "t")) + list(root.iter(_M + "t")):
                if t.text and re.search(r"[$\\{}]", t.text):
                    bad.append("R10 %s DSL leak %r" % (part, t.text[:40]))
            for mr in root.iter(_M + "r"):
                mt = u"".join(x.text or u"" for x in mr.iter(_M + "t"))
                if _HEB_CHAR.search(mt):
                    mrpr = mr.find(_M + "rPr")
                    wrpr = mr.find(_W + "rPr")
                    if mrpr is None or mrpr.find(_M + "nor") is None or \
                            wrpr is None or wrpr.find(_W + "rtl") is None:
                        bad.append("R10 %s Hebrew in math run without nor+rtl" % part)
    return bad


# ============================================================ selftest ===
def _tiny_png(w=40, h=20):
    raw = b"".join(b"\x00" + b"\xff\x00\x00" * w for _ in range(h))

    def chunk(t, d):
        c = struct.pack(">I", len(d)) + t + d
        return c + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b""))


def _fake_renderer(kind, blob):
    m = _SVG_W.search(blob)
    w = float(m.group(1)) if m else 100.0
    h = float(_SVG_H.search(blob).group(1)) if _SVG_H.search(blob) else 60.0
    return FigImage(_tiny_png(), w * _PX_TO_PT, h * _PX_TO_PT)


def _selftest_math():
    cases = [
        (u"\\f{1}{2}", ["<m:f>", "<m:num>", ">1<", ">2<"]),
        (u"x^{2}+1", ["<m:sSup>", ">x<", ">2<", u">+1<"]),
        (u"10^3", ["<m:sSup>", ">10<", ">3<"]),
        (u"x_1^2", ["<m:sSubSup>"]),
        (u"\\angle{ABC} = 40°", [u">∡<", u">ABC<", u"> = 40°<"]),
        (u"-5+3", [u">−5+3<"]),
        (u"\\sqrt{x_{1}}", ["<m:rad>", '<m:degHide m:val="1"/>', "<m:sSub>"]),
        (u"\\rat{3}{4}", [u">∶<"]),
        (u"S=\\text{בסיס}\\cdot\\text{גובה}", ["<m:nor/>", "<w:rtl/>", u">בסיס<", u">·<"]),
        (u"x=___", [u">______<"]),
        (u"\\g{a+b}", ['<m:begChr m:val="("/>', "<m:d>"]),
        (u"\\tri ABC", [u">△<", u">ABC<"]),
        (u"5\\%", [u">%<"]),
        (u"AB\\perp CD,\\ AB\\para EF", None),          # '\ ' is a stray backslash
        (u"\\d{a}{b}", ["<m:f>"]),
    ]
    for dsl, want in cases:
        if want is None:
            try:
                parse_math(dsl)
            except DocxError:
                continue
            raise AssertionError("expected a refusal for %r" % dsl)
        x = omml(parse_math(dsl), _Ctx(11.6))
        for w in want:
            if w not in x:
                raise AssertionError("%r: %r not in %s" % (dsl, w, x))
    for nm, ch in _BARE.items():
        x = omml(parse_math(u"\\%s" % nm), _Ctx(11.6))
        assert ch in x, (nm, x)
    for bad in (u"\\foo{1}", u"\\sqrt{\\pi}", u"\\sqrt 2", u"\\", u"\\f{1}", u"x^"):
        try:
            parse_math(bad)
        except DocxError:
            continue
        raise AssertionError("expected a refusal for %r" % bad)
    for bad in (u"טקסט $x", u"טקסט \\angle{ABC}", u"טקסט *x", u"**פתוח"):
        try:
            parse_seg(bad)
        except DocxError:
            continue
        raise AssertionError("expected a refusal for %r" % bad)
    # bold across an island
    parts = parse_seg(u"**סכום הזוויות הוא $180°$** בדיוק")
    assert parts[0] == ("p", u"סכום הזוויות הוא ", True), parts
    assert parts[1][0] == "m" and parts[1][2] is True, parts
    assert parts[2] == ("p", u" בדיוק", False), parts
    x = inline(u"**$x$**", 11.6)[0]
    assert '<m:sty m:val="b"/>' in x, x
    # the $ . gap is stripped, as emit_html.seg does
    assert seg_text(u"הפתרון $x=5$ .") == u"הפתרון x=5.", seg_text(u"הפתרון $x=5$ .")
    # one oMath per island, never split
    runs, _t, nm = inline(u"השוו $\\f{1}{2} < \\f{3}{4}$ וגם $x$.", 11.6)
    assert nm == 2 and runs.count("<m:oMath>") == 2, runs
    assert item_label_text(u"א") == u"א." and item_label_text(u"1") == u"(1)"
    assert item_label_text(u"יא") == u"יא."
    # Word-verified behaviours (docx-dev microprobes M1, M2, microprobe2)
    x = inline(u"הקרניים ו־$\\angle{APB}=36°$ ו־ $x$", 11.6)[0]
    assert (u"ו־" + ZWJ + u"</w:t>") in x, "ZWJ glue before a touching island"
    assert x.count(ZWJ) == 1, "no glue after a space"
    assert "<m:box><m:boxPr><m:noBreak/>" in x, "islands are unbreakable"
    x = inline(u"$\\f{2}{3}+\\f{1}{6}=___$", 11.6, display=True)[0]
    assert '<m:oMathPara><m:oMathParaPr><m:jc m:val="right"/>' in x, x[:120]
    assert '<w:sz w:val="%d"/>' % _hp(11.6 * FRAC_SCALE) not in x, "display: no scaling"
    x = inline(u"$\\f{1}{2}$", 11.6)[0]
    assert '<w:sz w:val="%d"/>' % _hp(11.6 * FRAC_SCALE) in x, "inline fraction scaled"
    x = inline(u"$\\d{a}{b}+1$", 11.6)[0]
    assert "<m:box>" not in x, "a display-fraction island may wrap (.m.dm)"
    # R9: neutral separators between zones get an RLM (G90), Hebrew ones do not
    x = guard_zones(inline(u"הזוויות $42°$, $78°$ ו־$60°$", 11.6)[0], 11.6)
    assert x.count(RLM) == 1 and (u'">' + RLM + u", </w:t>") in x, x
    x = guard_zones(inline(u"$1$$2$", 11.6)[0], 11.6)
    assert x.count(RLM) == 1 and x.index(RLM) > x.index("</m:oMath>"), "adjacent zones"
    assert guard_zones(inline(u"$a$ וגם $b$", 11.6)[0], 11.6).count(RLM) == 0
    # a box that would not fit its line in Word is split before relations
    long_isl = (u"$360° − 48° − 4 \\cdot 60° = 72°, 360° − 4 \\cdot 60° = 120°, "
                u"360° − 2 \\cdot 60° − 48° − 60° − 60° = 72°$")
    w = island_width_pt(parse_seg(long_isl)[0][1], 11.6)
    assert 450 < w < 650, w                  # Word: ~1.3x the PDF's 392pt
    rep = []
    x = inline(u"א " + long_isl, 11.6, avail_pt=438.0, report=rep)[0]
    assert x.count("<m:oMath>") == 1 and x.count("<m:box>") == 4, x.count("<m:box>")
    assert len(rep) == 1 and rep[0]["loose_pieces"] == 0, rep
    assert inline(u"א " + long_isl, 11.6)[0].count("<m:box>") == 1, "no width: one box"
    assert _split_at_relations(parse_math(u"=5"))[0] == (None, [])
    s_ = inline(u"$\\angle{CPD} = 144°$", 11.6, avail_pt=438.0)[0]
    assert s_.count("<m:box>") == 1, "a short island stays one box"
    return len(cases)


def _tiny_level():
    svg = (u'<svg xmlns="http://www.w3.org/2000/svg" width="120" height="80">'
           u'<line x1="0" y1="0" x2="100" y2="60" stroke="#000"/>'
           u'<text x="5" y="70">-3</text></svg>')
    wide = svg.replace(u'width="120"', u'width="340"')
    return dict(
        key="a", level=u"רמה א׳", grade=u"כיתה ז׳", title=u"זוויות — בדיקה",
        subtitle=u"בדיקה פנימית", rule=u"**שימו לב:** סכום הזוויות הוא $180°$.",
        questions=[
            dict(n=1, part=(u"חלק א׳ — חישוב", u"1-2"), intro=u"נתון $∠APB=36°$.",
                 fig=svg, items=[(u"א", u"חשבו את $\\angle{BPC}$.", 30),
                                 (u"ב", u"מצאו $x$ אם $3x-6=12$.", 30)]),
            dict(n=2, star=True, example=(u"דוגמה", [u"$\\f{1}{2}+\\f{1}{4}=\\f{3}{4}$", u"שלב 1"]),
                 fig=wide, fig_side="wide",
                 table=dict(head=[u"זמן", u"0", u"2"], rows=[[u"זווית", u"0°", u"36°"]]),
                 items=[(u"א", u"השלימו את הטבלה.", 30, svg)]),
            dict(n=3, items=[(u"א", u"חשבו $-5+3$ ואת $4-7$, $2-9$.", 20)]),
            dict(n=4, items=[], space=40),
        ],
        answers=[(1, [(u"א", u"$62°$"), (u"ב", u"$x=6$")]),
                 (2, [(u"א", u"$72°$"), (u"", u"הערה")], True),
                 (3, [(u"א", u"$−2$, $−4$, $−7$")]), (4, [(u"", u"פתוח")])])


def selftest(verbose=True):
    """Offline (< 30 s): DSL->OMML cases, then a tiny sheet built with a fake
    figure renderer and checked for the RTL invariants and bookmark parity."""
    n = _selftest_math()
    L = _tiny_level()
    tmp = tempfile.mkdtemp(prefix="emit_docx_selftest_")
    out = Path(tmp) / "sheet.docx"
    try:
        st = build_docx(L, out, figure_renderer=_fake_renderer,
                        meta=dict(created="2026-11-08T00:00:00Z"))
        bad = rtl_invariants(out)
        if bad:
            raise AssertionError("RTL invariants: " + "; ".join(bad[:8]))
        par = parity_report(out, L)
        if par:
            raise AssertionError("parity: " + "; ".join(par[:4]))
        with zipfile.ZipFile(str(out)) as z:
            doc = z.read("word/document.xml").decode("utf-8")
        n_islands = doc.count("<m:oMath>")
        assert n_islands == st["omath"], (n_islands, st["omath"])
        want = [u"q1", u"q1a", u"q1b", u"q2", u"q2a", u"q3", u"q3a", u"q4",
                u"ans_q1", u"ans_q2", u"ans_q3", u"ans_q4"]
        assert len(set(st["bookmarks"])) == len(st["bookmarks"]), "unique bookmarks"
        assert RLM in doc, "R9 separators carry an RLM"
        for w in want:
            assert w in st["bookmarks"], (w, st["bookmarks"])
        assert '<w:jc w:val="right"/>' not in doc and '<w:jc w:val="end"/>' not in doc
        assert doc.count("<w:tbl>") == doc.count("<w:bidiVisual/>"), "bidiVisual"
        # the example box: start-edge rule is w:left in a bidiVisual table, and
        # shading sits on cells (Word paints no table-level shd) — microprobe M3
        assert '<w:left w:val="single" w:sz="18" w:space="0" w:color="999999"/>' in doc
        assert 'w:fill="F6F6F4"' in doc and 'w:fill="F2F2F0"' in doc
        assert "<w:tblPr><w:shd" not in doc and "</w:tblBorders><w:shd" not in doc
        assert u"−3" not in doc                     # figure text never in the body
        # deterministic bytes for a fixed timestamp
        st2 = build_docx(L, Path(tmp) / "again.docx", figure_renderer=_fake_renderer,
                         meta=dict(created="2026-11-08T00:00:00Z"))
        assert st2["sha256"] == st["sha256"], "output is not deterministic"
        # R9 is really checked: the same sheet without the RLM guard must fail
        global guard_zones
        keep = guard_zones
        guard_zones = lambda runs, size: runs                    # noqa: E731
        try:
            build_docx(L, Path(tmp) / "noguard.docx", figure_renderer=_fake_renderer)
            r9 = [b for b in rtl_invariants(Path(tmp) / "noguard.docx")
                  if b.startswith("R9")]
        finally:
            guard_zones = keep
        assert len(r9) >= 2, "rtl_invariants must report R9 without the guard: %r" % r9
        # ambiguous ids are refused before anything is written
        for qs in ([dict(n=3, items=[(u"1", u"א", 10)])],                    # q31
                   [dict(n=1, items=[(u"י", u"א", 10), (u"יא", u"ב", 10)])],  # q1j twice
                   [dict(n=2, items=[]), dict(n=2, items=[])]):              # q2 twice
            try:
                build_docx(dict(L, questions=qs, answers=[]), Path(tmp) / "amb.docx",
                           figure_renderer=_fake_renderer)
            except DocxError as e:
                assert "ambiguous ids" in u"%s" % e
                continue
            raise AssertionError("ambiguous ids accepted: %r" % (qs,))
        assert not (Path(tmp) / "amb.docx").exists()
        # the constants, regexes and SVG transforms mirrored from emit_html
        parity_note = _mirror_check()
    finally:
        for f in Path(tmp).glob("*"):
            f.unlink()
        os.rmdir(tmp)
    if verbose:
        print("emit_docx selftest: %d DSL cases, tiny sheet %d paragraphs / %d tables / "
              "%d oMath / %d bookmarks — RTL invariants + parity OK; %s"
              % (n, st["paragraphs"], st["tables"], st["omath"], len(st["bookmarks"]),
                 parity_note))
    return True


_MIRROR = {
    "emit_html.py": (("BRAND", "BSD", "MINUS", "ANSNOTE", "SIDE_MAX", "HEB_LABEL",
                      "MARKER_RE", "_MATH_PUNCT_GAP", "_GENERIC_FACE", "_TEXT_NO_FACE",
                      "_SVG_TEXT", "_HYPHEN_REF", "CSS"),
                     ("_pin_svg_fonts", "true_minus_svg", "is_display")),
    "emit_plus.py": (("ITEM_FIG_MAX",), ()),
}


def _mirror_source(path, names, funcs):
    """The named module-level assignments and functions of a skill file, run
    from its SOURCE (ast) in a bare namespace — never by importing it, so the
    check works where emit_html cannot be imported (a space in the path)."""
    tree = ast.parse(Path(path).read_text(encoding="utf-8"), filename=str(path))
    keep, found = [], set()
    for node in tree.body:
        if (isinstance(node, ast.Assign) and len(node.targets) == 1
                and isinstance(node.targets[0], ast.Name)
                and node.targets[0].id in names):
            keep.append(node)
            found.add(node.targets[0].id)
        elif isinstance(node, ast.FunctionDef) and node.name in funcs:
            keep.append(node)
            found.add(node.name)
    missing = sorted((set(names) | set(funcs)) - found)
    if missing:
        raise AssertionError("mirror check: %s no longer defines %s — update emit_docx's "
                             "mirror" % (Path(path).name, ", ".join(missing)))
    ns = {"re": re, "os": os, "_os": os}
    exec(compile(ast.Module(body=keep, type_ignores=[]), str(path), "exec"), ns)
    return ns


def _mirror_check():
    """Constants, regexes and SVG transforms mirrored from emit_html (and
    emit_plus) must equal the originals, read from their source. A missing
    original fails; EMIT_DOCX_SKIP_MIRROR=1 skips the check and says so."""
    if os.environ.get("EMIT_DOCX_SKIP_MIRROR") == "1":
        return "mirror check SKIPPED (EMIT_DOCX_SKIP_MIRROR=1)"
    for fn in _MIRROR:
        if not (SKILL / fn).is_file():
            raise AssertionError("mirror check: %s not found next to emit_docx (%s); set "
                                 "EMIT_DOCX_SKIP_MIRROR=1 to skip" % (fn, SKILL))
    E = _mirror_source(SKILL / "emit_html.py", *_MIRROR["emit_html.py"])
    Pl = _mirror_source(SKILL / "emit_plus.py", *_MIRROR["emit_plus.py"])
    pairs = [("BRAND", BRAND), ("BSD", BSD), ("MINUS", MINUS), ("ANSNOTE", ANSNOTE),
             ("SIDE_MAX", SIDE_MAX)]
    for nm, mine in pairs:
        assert E[nm] == mine, "mirror check: %s differs from emit_html" % nm
    for nm, mine in (("HEB_LABEL", HEB_LABEL), ("MARKER_RE", MARKER_RE),
                     ("_MATH_PUNCT_GAP", _MATH_PUNCT_GAP), ("_GENERIC_FACE", _GENERIC_FACE),
                     ("_TEXT_NO_FACE", _TEXT_NO_FACE), ("_SVG_TEXT", _SVG_TEXT),
                     ("_HYPHEN_REF", _HYPHEN_REF)):
        assert (E[nm].pattern, E[nm].flags) == (mine.pattern, mine.flags), \
            "mirror check: regex %s differs from emit_html" % nm
    assert Pl["ITEM_FIG_MAX"] == ITEM_FIG_MAX, "mirror check: ITEM_FIG_MAX differs"
    css = E["CSS"]
    assert COPYRIGHT in css, "mirror check: COPYRIGHT is not the PDF's footer text"
    # the layout constants come from these rules (gutters, display-line inset)
    for rule in (".q{position:relative; padding-right:44pt",
                 ".it{position:relative; padding-right:28pt",
                 ".mline{direction:ltr; text-align:right; line-height:2.0; margin-right:14pt"):
        assert rule in css, "mirror check: emit_html CSS changed: %r" % rule
    samples = [u'<svg width="10"><text font-family="serif">-3</text><text>a-b&#45;</text></svg>',
               u'<svg><text x="1"><![CDATA[-2]]></text><text>&#x2D;1</text></svg>',
               u'<svg><text font-family="monospace" x="2">−4-5</text></svg>']
    for smp in samples:
        assert E["true_minus_svg"](E["_pin_svg_fonts"](smp)) == \
            true_minus_svg(_pin_svg_fonts(smp)), "mirror check: SVG transform differs"
        assert E["true_minus_svg"](smp) == true_minus_svg(smp)
    for smp in (u"$x$ .", u"**א $1$ ב**", u"$\\f{1}{2}$", u"  $a=b$ ", u"$a$ $b$"):
        assert E["is_display"](smp) == is_display(smp), "mirror check: is_display differs"
    for lab in (u"א", u"יא", u"ב׳", u"1", u"a", u"אבגד"):
        assert bool(E["HEB_LABEL"].match(lab)) == bool(HEB_LABEL.match(lab))
    return "emit_html/emit_plus mirror check OK (from source)"


# ================================================================= CLI ===
_W3C = "%Y-%m-%dT%H:%M:%SZ"


def _built_at(build_json):
    """The engine build's `built_at` (build.json) as W3CDTF UTC, or None."""
    try:
        t = json.loads(Path(build_json).read_text(encoding="utf-8")).get("built_at")
        if not t:
            return None
        dt = datetime.datetime.fromisoformat(str(t))
        if dt.tzinfo is None:
            dt = dt.astimezone()                     # naive = the build machine's local time
        return dt.astimezone(datetime.timezone.utc).replace(microsecond=0).strftime(_W3C)
    except (OSError, ValueError, TypeError, AttributeError):
        return None


def stable_created(pkg, out, key):
    """docProps/core.xml's created/modified stamp for a package build, chosen
    so that rebuilding the same package gives the same bytes (v72-report.json
    records every output's sha256): SOURCE_DATE_EPOCH when set (None here:
    _now_iso honours it), else the engine build's own `built_at` from
    out/deliver/<key>/build.json (local time of that build), else the newest
    mtime of the package's .py sources."""
    if os.environ.get("SOURCE_DATE_EPOCH"):
        return None
    t = _built_at(Path(out) / "deliver" / key / "build.json")
    if t:
        return t
    srcs = sorted(Path(pkg).glob("*.py"))
    if srcs:
        m = max(p.stat().st_mtime for p in srcs)
        return datetime.datetime.fromtimestamp(int(m), datetime.timezone.utc).strftime(_W3C)
    return "2000-01-01T00:00:00Z"


def run_g90(docx_path, sheet_json=None, timeout=120):
    """The G90 gate as the contract calls it: check_docx_rtl.py under
    `python3 -I -B` with --source sheet.json and --glossary glossary_he.json.
    Returns {exit, errors, warnings, rules, first} or None when the checker is
    not in the skill folder. emit_docx's own rtl_invariants are a subset of
    it; running both is how the writer and the gate are kept in agreement."""
    chk = SKILL / "check_docx_rtl.py"
    if not chk.is_file():
        return None
    tmp = tempfile.mkdtemp(prefix="emit_docx_g90_")
    rep = Path(tmp) / "g90.json"
    cmd = [sys.executable, "-I", "-B", str(chk), str(docx_path)]
    if sheet_json and Path(sheet_json).is_file():
        cmd += ["--source", str(sheet_json)]
    if (SKILL / "glossary_he.json").is_file():
        cmd += ["--glossary", str(SKILL / "glossary_he.json")]
    cmd += ["--json", str(rep)]
    try:
        cp = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        try:
            d = json.loads(rep.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return dict(exit=cp.returncode, errors=-1, warnings=-1, rules={},
                        first=[(cp.stderr or cp.stdout)[-400:]])
        return dict(exit=cp.returncode, errors=len(d.get("errors") or []),
                    warnings=len(d.get("warnings") or []),
                    rules=(d.get("stats") or {}).get("rules", {}),
                    first=["%s %s" % (e.get("id"), e.get("msg", ""))[:200]
                           for e in (d.get("errors") or [])[:4]])
    finally:
        for f in Path(tmp).glob("*"):
            f.unlink()
        os.rmdir(tmp)


def build_package(pkg, out=None, levels=None, renderer=None, verbose=True, g90=True):
    """Build sheet.docx for each level of a package (pkgload), then prove
    bookmark parity, the RTL invariants and (when check_docx_rtl.py is in the
    skill) the G90 gate on the written file."""
    import pkgload
    P = pkgload.load(pkg)
    out = Path(out) if out else Path(pkg) / "out"
    keys = [k for k in (levels or P.keys) if k in P.ir]
    renderer = renderer or WeasyFigureRenderer()
    res = {}
    for k in keys:
        Ln = P.ir[k]
        dst = out / "docx" / k / "sheet.docx"
        meta = dict(subject=(P.sheet or {}).get("sheet_id") or P.package or u"",
                    description=u"%s · %s" % (P.package or u"", Ln.get("level", u"")))
        created = stable_created(pkg, out, k)
        if created:
            meta["created"] = created
        st = build_docx(Ln, dst, figure_renderer=renderer, meta=meta)
        st["rtl_invariants"] = rtl_invariants(dst)
        st["parity"] = parity_report(dst, Ln)
        st["g90"] = run_g90(dst, out / "deliver" / k / "sheet.json") if g90 else None
        res[k] = st
        if verbose:
            g = st["g90"]
            gtxt = ("G90 n/a" if g is None else
                    "G90 OK" if g["errors"] == 0 else "G90 %s error(s)" % g["errors"])
            print("emit_docx %-2s %s  %d q · %d items · %d answers · %d oMath · %d images"
                  " · %s · parity %s · RTL %s · %s · %d wide island(s)"
                  % (k, dst, st["questions"], st["items"], st["answers"], st["omath"],
                     st["images"], st["sha256"][:12],
                     "OK" if not st["parity"] else "%d problem(s)" % len(st["parity"]),
                     "OK" if not st["rtl_invariants"] else
                     "%d problem(s)" % len(st["rtl_invariants"]), gtxt,
                     len(st["wide_islands"])))
            for p in (st["parity"] + st["rtl_invariants"] + (g["first"] if g else []))[:6]:
                print("   ", p)
            for w in st["wide_islands"]:
                print("    wide island %.0fpt on a %.0fpt line%s: %s"
                      % (w["est_pt"], w["line_pt"],
                         " (%d piece(s) still too wide)" % w["loose_pieces"]
                         if w["loose_pieces"] else "", w["text"][:70]))
    return res


def _failed(st):
    g = st.get("g90")
    return bool(st["parity"] or st["rtl_invariants"] or (g and g["errors"]))


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv[:1] == ["--render-figures"]:
        _child_render(argv[1])
        return 0
    ap = argparse.ArgumentParser(description="Word (.docx) twin of sheet.pdf")
    ap.add_argument("--pkg", help="package folder (holds content.py)")
    ap.add_argument("--out", help="output root (default: PKG/out)")
    ap.add_argument("--levels", help="comma list, e.g. a,b,c")
    ap.add_argument("--json", help="write the stats here")
    ap.add_argument("--no-g90", action="store_true",
                    help="do not run check_docx_rtl.py (G90) on the result")
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args(argv)
    if a.selftest:
        selftest()
        return 0
    if not a.pkg:
        ap.error("--pkg is required")
    levels = [x.strip() for x in a.levels.split(",")] if a.levels else None
    res = build_package(a.pkg, a.out, levels, g90=not a.no_g90)
    if a.json:
        Path(a.json).write_text(json.dumps(res, ensure_ascii=False, indent=1),
                                encoding="utf-8")
    return 1 if any(_failed(st) for st in res.values()) else 0


if __name__ == "__main__":
    sys.exit(main())
