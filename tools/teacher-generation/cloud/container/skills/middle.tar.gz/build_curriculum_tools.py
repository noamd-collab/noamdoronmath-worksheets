# -*- coding: utf-8 -*-
"""build_curriculum_tools.py -- v6.7.1-noam (BRIEF_V671 §7): the teaching-
order registry. Writes curriculum_tools.json beside this file from

  * curriculum_tashpaz.json  -- the official פריסת הוראה תשפ"ז (ז / ח / ט in
                                two tracks): topics, months, details,
                                keywords, excluded topics;
  * THEOREMS below           -- the named theorems / formulas / methods of
                                the middle-school geometry and algebra
                                (names and prior knowledge from
                                kb/concepts.md parts 8-12), each placed in
                                the official topic where it is first taught.

    python3 build_curriculum_tools.py          # rewrite curriculum_tools.json
    python3 build_curriculum_tools.py --check  # exit 1 if the file is stale

The file lists every tool with an id, a Hebrew name, the grade, the unit
(topic id + name) and its ORDER in each official sequence (ז topics, then
ח, then the ט track). didactic.curriculum_block() reads it: a package at
position p may use every tool whose first position is <= p; the rest are
`not_yet_allowed` (and a topic the track excludes is never allowed).
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "curriculum_tashpaz.json")
OUT = os.path.join(HERE, "curriculum_tools.json")

MONTHS = [u"ספטמבר", u"אוקטובר", u"נובמבר", u"דצמבר", u"ינואר", u"פברואר",
          u"מרץ", u"אפריל", u"מאי", u"יוני"]
GRADE_OF = {u"ז": "7", u"ח": "8", u"ט_רגילה": "9", u"ט_מצומצמת": "9"}
TRACK_ID = {u"ז": "g7", u"ח": "g8", u"ט_רגילה": "g9", u"ט_מצומצמת": "g9m"}
# the official sequences: a grade builds on the grades before it
SEQUENCES = {u"ז": [u"ז"], u"ח": [u"ז", u"ח"],
             u"ט_רגילה": [u"ז", u"ח", u"ט_רגילה"],
             u"ט_מצומצמת": [u"ז", u"ח", u"ט_מצומצמת"]}

# (id, Hebrew name, kind, [(track, topic id), ...] where it is taught,
#  keywords a text uses when it invokes it). Names follow kb/concepts.md.
THEOREMS = [
    # -- angles (ז) ---------------------------------------------------------
    ("thm.adjacent_angles", u"זוויות צמודות (סכומן 180°)", "theorem",
     [(u"ז", "angles")], [u"צמודות"]),
    ("thm.vertical_angles", u"זוויות קודקודיות שוות", "theorem",
     [(u"ז", "angles")], [u"קודקודיות"]),
    ("thm.angle_bisector", u"חוצה זווית", "definition",
     [(u"ז", "angles")], [u"חוצה זווית", u"חוצה את הזווית"]),
    ("thm.alternate_angles", u"זוויות מתחלפות בין ישרים מקבילים", "theorem",
     [(u"ז", "angles"), (u"ט_רגילה", "parallels_trapezoid"),
      (u"ט_מצומצמת", "parallels_and_parallelogram")], [u"מתחלפות"]),
    ("thm.corresponding_angles", u"זוויות מתאימות בין ישרים מקבילים",
     "theorem", [(u"ז", "angles"), (u"ט_רגילה", "parallels_trapezoid"),
                 (u"ט_מצומצמת", "parallels_and_parallelogram")],
     [u"מתאימות"]),
    ("thm.co_interior_angles", u"זוויות חד-צדדיות בין ישרים מקבילים",
     "theorem", [(u"ט_רגילה", "parallels_trapezoid")],
     [u"חד-צדדיות", u"חד צדדיות"]),
    ("thm.triangle_angle_sum", u"סכום הזוויות במשולש 180°", "theorem",
     [(u"ז", "angles"), (u"ט_מצומצמת", "computational_triangle")],
     [u"סכום הזוויות במשולש", u"סכום זוויות במשולש"]),
    ("thm.quad_angle_sum", u"סכום הזוויות במרובע 360°", "theorem",
     [(u"ז", "angles")], [u"סכום הזוויות במרובע"]),
    # -- areas, solids (ז) ---------------------------------------------------
    ("frm.area_rectangle", u"שטח מלבן = אורך × רוחב", "formula",
     [(u"ז", "areas")], [u"שטח מלבן", u"שטח המלבן"]),
    ("frm.area_triangle", u"שטח משולש = צלע × גובה : 2", "formula",
     [(u"ז", "areas")], [u"שטח משולש", u"שטח המשולש"]),
    ("frm.area_parallelogram", u"שטח מקבילית = צלע × גובה", "formula",
     [(u"ז", "areas")], [u"שטח מקבילית", u"שטח המקבילית"]),
    ("frm.area_trapezoid", u"שטח טרפז = (סכום בסיסים) × גובה : 2",
     "formula", [(u"ז", "areas"), (u"ט_רגילה", "parallels_trapezoid"),
                 (u"ט_מצומצמת", "trapezoid")], [u"שטח טרפז", u"שטח הטרפז"]),
    ("frm.perimeter", u"היקף מצולע", "formula", [(u"ז", "areas")],
     [u"היקף"]),
    ("frm.box_volume", u"נפח תיבה", "formula", [(u"ז", "solids")],
     [u"נפח תיבה", u"נפח התיבה"]),
    ("frm.box_surface", u"שטח פנים של תיבה", "formula", [(u"ז", "solids")],
     [u"שטח פנים"]),
    # -- pythagoras (ז updated plan, ח) -------------------------------------
    ("thm.pythagoras", u"משפט פיתגורס", "theorem",
     [(u"ז", "pythagoras"), (u"ח", "pythagoras"),
      (u"ט_מצומצמת", "pythagoras")],
     [u"פיתגורס", u"היתר", u"ליתר", u"אורך היתר", u"הניצב",
      u"ניצבים", u"הניצבים", u"ניצביו"]),
    ("thm.pythagoras_converse", u"המשפט ההפוך למשפט פיתגורס", "theorem",
     [(u"ח", "pythagoras")], [u"ההפוך לפיתגורס", u"הפוך למשפט פיתגורס"]),
    ("thm.pythagoras_3d", u"משפט פיתגורס במרחב", "theorem",
     [(u"ח", "pythagoras_3d")], [u"פיתגורס במרחב"]),
    # -- congruence, triangle (ח) --------------------------------------------
    ("thm.congruence_sas", u"משפט חפיפה צ.ז.צ", "theorem",
     [(u"ח", "congruence")], [u"צ.ז.צ", u"צ\"ז\"צ", u"צז\"צ"]),
    ("thm.congruence_asa", u"משפט חפיפה ז.צ.ז", "theorem",
     [(u"ח", "congruence")], [u"ז.צ.ז", u"ז\"צ\"ז", u"זצ\"ז"]),
    ("thm.congruence_sss", u"משפט חפיפה צ.צ.צ", "theorem",
     [(u"ח", "congruence")], [u"צ.צ.צ", u"צצ\"צ"]),
    ("thm.congruence_ssa", u"משפט חפיפה צ.צ.ז", "theorem",
     [(u"ח", "congruence")], [u"צ.צ.ז", u"צצ\"ז"]),
    ("thm.congruent_parts", u"במשולשים חופפים צלעות וזוויות מתאימות שוות",
     "theorem", [(u"ח", "congruence")],
     [u"משולשים חופפים", u"מתאימים במשולשים חופפים"]),
    ("thm.exterior_angle", u"זווית חיצונית למשולש", "theorem",
     [(u"ח", "triangle_parts")], [u"זווית חיצונית"]),
    ("thm.isosceles_base_angles", u"במשולש שווה שוקיים זוויות הבסיס שוות",
     "theorem", [(u"ח", "triangle_parts"),
                 (u"ט_מצומצמת", "kite_and_isosceles")],
     [u"זוויות הבסיס", u"שווה שוקיים"]),
    ("thm.isosceles_special_lines",
     u"במשולש שווה שוקיים חוצה זווית הראש, התיכון והגובה לבסיס מתלכדים",
     "theorem", [(u"ח", "triangle_parts"),
                 (u"ט_מצומצמת", "kite_and_isosceles")],
     [u"מתלכדים", u"חוצה זווית הראש"]),
    ("thm.isosceles_converse", u"משפטים הפוכים: הוכחה שמשולש שווה שוקיים",
     "theorem", [(u"ט_רגילה", "isosceles_converse"),
                 (u"ט_מצומצמת", "kite_and_isosceles")],
     [u"משפט הפוך"]),
    ("thm.triangle_inequality", u"אי-שוויון המשולש", "theorem",
     [(u"ח", "triangle_parts")], [u"אי-שוויון המשולש", u"אי שוויון המשולש"]),
    ("thm.side_angle_order", u"מול הצלע הגדולה הזווית הגדולה (וההפך)",
     "theorem", [(u"ט_רגילה", "side_angle_relations")],
     [u"מול הצלע הגדולה", u"מול הזווית הגדולה"]),
    # -- similarity (ח, ט) ---------------------------------------------------
    ("thm.similarity_aa", u"משפט דמיון ז.ז", "theorem",
     [(u"ח", "similarity"), (u"ט_מצומצמת", "similarity")],
     [u"ז.ז", u"דמיון"]),
    ("thm.similarity_sas", u"משפט דמיון צ.ז.צ", "theorem",
     [(u"ח", "similarity")], [u"דמיון צ.ז.צ"]),
    ("thm.similarity_sss", u"משפט דמיון צ.צ.צ", "theorem",
     [(u"ח", "similarity")], [u"דמיון צ.צ.צ"]),
    ("thm.similar_area_ratio", u"יחס השטחים הוא ריבוע יחס הדמיון",
     "theorem", [(u"ט_רגילה", "similarity")], [u"יחס השטחים", u"יחס שטחים"]),
    # -- ט: deductive geometry ----------------------------------------------
    ("thm.kite_main_diagonal",
     u"בדלתון האלכסון הראשי חוצה את המשני, מאונך לו וחוצה את זוויות הראש",
     "theorem", [(u"ט_רגילה", "kite"), (u"ט_מצומצמת", "kite_and_isosceles")],
     [u"אלכסון ראשי", u"האלכסון הראשי"]),
    ("thm.30_60_90", u"במשולש ישר זווית הניצב מול 30° שווה למחצית היתר",
     "theorem", [(u"ט_רגילה", "right_triangle_30_60_90")],
     [u"מחצית היתר", u"מול זווית של 30", u"מול 30"]),
    ("thm.parallel_converse", u"משפטים הפוכים לישרים מקבילים", "theorem",
     [(u"ט_רגילה", "parallels_trapezoid")],
     [u"הפוך לישרים מקבילים"]),
    ("thm.isosceles_trapezoid", u"טרפז שווה שוקיים: זוויות בסיס ואלכסונים",
     "theorem", [(u"ט_רגילה", "parallels_trapezoid"),
                 (u"ט_מצומצמת", "trapezoid")], [u"טרפז שווה שוקיים"]),
    ("thm.parallelogram_props",
     u"במקבילית צלעות נגדיות שוות, זוויות נגדיות שוות, האלכסונים חוצים זה "
     u"את זה", "theorem", [(u"ט_רגילה", "parallelogram"),
                           (u"ט_מצומצמת", "parallels_and_parallelogram")],
     [u"מקבילית", u"חוצים זה את זה"]),
    ("thm.parallelogram_converse", u"משפטים הפוכים: הוכחה שמרובע מקבילית",
     "theorem", [(u"ט_רגילה", "parallelogram"),
                 (u"ט_מצומצמת", "parallels_and_parallelogram")],
     [u"הוא מקבילית"]),
    ("thm.rectangle_props", u"במלבן כל הזוויות ישרות והאלכסונים שווים",
     "theorem", [(u"ט_רגילה", "rectangle"), (u"ט_מצומצמת", "rectangle")],
     [u"מלבן", u"האלכסונים שווים", u"אלכסוני המלבן"]),
    ("thm.rectangle_converse",
     u"משפטים הפוכים: מקבילית עם זווית ישרה או עם אלכסונים שווים היא מלבן",
     "theorem", [(u"ט_רגילה", "rectangle")], [u"הוא מלבן"]),
    ("thm.rhombus_props",
     u"במעוין כל הצלעות שוות, האלכסונים מאונכים וחוצי זוויות", "theorem",
     [(u"ט_רגילה", "rhombus"), (u"ט_מצומצמת", "rhombus")],
     [u"מעוין", u"אלכסוני המעוין"]),
    ("thm.rhombus_converse", u"משפטים הפוכים: הוכחה שמרובע מעוין",
     "theorem", [(u"ט_רגילה", "rhombus")], [u"הוא מעוין"]),
    ("thm.square_props", u"ריבוע: מלבן שהוא גם מעוין", "theorem",
     [(u"ט_רגילה", "square"), (u"ט_מצומצמת", "square")], [u"ריבוע"]),
    ("thm.right_triangle_median", u"התיכון ליתר שווה למחצית היתר",
     "theorem", [(u"ט_רגילה", "right_triangle_median")],
     [u"תיכון ליתר", u"התיכון ליתר"]),
    ("frm.area_rhombus_diagonals", u"שטח מעוין / דלתון = מכפלת האלכסונים : 2",
     "formula", [(u"ט_רגילה", "rhombus"), (u"ט_רגילה", "kite"),
                 (u"ט_מצומצמת", "rhombus"),
                 (u"ט_מצומצמת", "kite_and_isosceles")],
     [u"מכפלת האלכסונים"]),
    ("thm.midsegment", u"קטע אמצעים במשולש ובטרפז", "theorem",
     [], [u"קטע אמצעים", u"קטע האמצעים"]),
    # -- algebra -------------------------------------------------------------
    ("mth.distributive", u"חוק הפילוג", "method",
     [(u"ז", "algebraic_expressions")], [u"חוק הפילוג"]),
    ("mth.first_degree_eq", u"פתרון משוואה ממעלה ראשונה", "method",
     [(u"ז", "equations")], [u"משוואה"]),
    ("frm.short_multiplication", u"נוסחאות הכפל המקוצר", "formula",
     [(u"ט_רגילה", "alg_technique")], [u"כפל מקוצר"]),
    ("mth.factoring", u"פירוק לגורמים", "method",
     [(u"ט_רגילה", "alg_technique")], [u"פירוק לגורמים"]),
    ("frm.quadratic_formula", u"נוסחת השורשים", "formula",
     [(u"ט_רגילה", "quad_func_and_eq")], [u"נוסחת השורשים"]),
]


def _topic_order(track, data):
    """[(topic id, name, domain, first month index, list index)] in the
    order the track teaches them."""
    tps = data["tracks"][track].get("topics") or []
    rows = []
    for k, tp in enumerate(tps):
        ms = [MONTHS.index(m) for m in tp.get("months") or [] if m in MONTHS]
        rows.append((min(ms) if ms else 99, k, tp))
    rows.sort(key=lambda r: (r[0], r[1]))
    return [r[2] for r in rows]


def _parts(name):
    """A topic name without details ('זוויות — סימון, מדידה, ...') split
    into the methods it lists."""
    head, _, tail = name.partition(u"—")
    src = tail if tail.strip() else head
    out = []
    for p in src.replace(u" ו-", u", ").split(u","):
        p = p.strip()
        if p and p not in out:
            out.append(p)
    return out or [name.strip()]


def build():
    with open(SRC, encoding="utf-8") as fh:
        data = json.load(fh)
    tools, index = [], {}

    def add(tid, name, kind, grade, units, kws):
        index[tid] = len(tools)
        tools.append({"id": tid, "name_he": name, "kind": kind,
                      "grade": grade, "units": units, "keywords": kws})

    units_of = {}
    for track in (u"ז", u"ח", u"ט_רגילה", u"ט_מצומצמת"):
        for pos, tp in enumerate(_topic_order(track, data)):
            units_of[(track, tp["id"])] = {
                "track": track, "topic": tp["id"], "unit": tp["name"],
                "domain": tp.get("domain"), "order": pos}
    # 1) the official details (ט) or the methods a topic name lists (ז, ח)
    for track in (u"ז", u"ח", u"ט_רגילה", u"ט_מצומצמת"):
        for tp in _topic_order(track, data):
            det = tp.get("details") or _parts(tp["name"])
            for k, d in enumerate(det):
                tid = "%s.%s.%d" % (TRACK_ID[track], tp["id"], k + 1)
                add(tid, d, "method" if tp.get("domain") != u"גיאומטרי"
                    else "topic_item", GRADE_OF[track],
                    [units_of[(track, tp["id"])]], [])
    # 2) the named theorems / formulas / methods
    for tid, name, kind, where, kws in THEOREMS:
        units = [units_of[w] for w in where if w in units_of]
        grades = sorted(set(GRADE_OF[w[0]] for w in where)) or ["9"]
        add(tid, name, kind, grades[0], units, list(kws))
    # 3) what a track does not teach this year (explicit exclusions)
    excluded = {}
    for track, t in data["tracks"].items():
        for ex in t.get("excluded") or []:
            kws = ex.get("keywords") or []
            hits = [x["id"] for x in tools
                    if any(k in x["name_he"] or k in x["keywords"]
                           for k in kws)]
            # This exclusion names quadrilateral converses, not every
            # theorem whose name contains the generic word "converse".
            if ex.get("topic") == u"משפטים הפוכים למרובעים":
                quadrilateral_topics = {
                    "parallelogram", "parallels_and_parallelogram",
                    "rectangle", "rhombus", "square", "trapezoid", "kite"}
                hits = [tid for tid in hits if any(
                    unit["topic"] in quadrilateral_topics
                    for unit in tools[index[tid]]["units"])]
            excluded.setdefault(track, []).append(
                {"topic": ex.get("topic"), "basis": ex.get("basis"),
                 "keywords": kws, "tools": sorted(set(hits))})
    seqs = {}
    for track, chain in SEQUENCES.items():
        seq = []
        for tr in chain:
            for tp in _topic_order(tr, data):
                seq.append({"track": tr, "topic": tp["id"],
                            "unit": tp["name"], "grade": GRADE_OF[tr]})
        seqs[track] = seq
    return {"schema": "curriculum-tools/v1",
            "source": "curriculum_tashpaz.json (פריסת הוראה תשפ\"ז) + "
                      "kb/concepts.md (names, prior knowledge)",
            "sequences": seqs, "excluded": excluded, "tools": tools}


def dump(reg):
    return json.dumps(reg, ensure_ascii=False, indent=1, sort_keys=False) + "\n"


if __name__ == "__main__":
    body = dump(build())
    if "--check" in sys.argv:
        cur = open(OUT, encoding="utf-8").read() if os.path.isfile(OUT) else ""
        print("curriculum_tools.json %s" % ("up to date" if cur == body
                                            else "STALE"))
        sys.exit(0 if cur == body else 1)
    with open(OUT, "w", encoding="utf-8") as fh:
        fh.write(body)
    reg = json.loads(body)
    print("curriculum_tools.json: %d tools, sequences %s"
          % (len(reg["tools"]), ", ".join("%s=%d" % (k, len(v)) for k, v in
                                          reg["sequences"].items())))
