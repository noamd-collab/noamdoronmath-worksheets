# -*- coding: utf-8 -*-
r"""gate_variety — v5.4. G76: variety that SCALES WITH THE SHEET.

WHY THIS FILE EXISTS
--------------------
v5.2 added G75 after an author opened three rebuilt analytic-geometry sheets and
saw the same rhombus on five questions. G75 counts three things — how many
questions carry a drawing, how many DISTINCT SVGs there are, and how many
OBJECTS — and it fixed the loudest half of the problem. The other half survived,
and the author said so again in Sep 2026 after a second set of sheets:

    REUSE caps the same SVG at two questions. It does NOT cap the same SHAPE.
    A rhombus drawn plain, then with its diagonals, then with an altitude, then
    with a midpoint, then with a right-angle mark is five DIFFERENT SVGs and ONE
    object, and G75 passes it — which is exactly the sheet that was complained
    about.

    FIG_FAMILIES_MIN is the number 3, flat. Three objects is a reasonable floor
    for an eight-question sheet and an absurd one for a twenty-question sheet,
    where it permits a twenty-question drill on three shapes.

So G76 measures the two things G75 does not: how many objects a sheet of THIS
SIZE owes, and how much of the sheet one object may carry. It does not replace
G75 — both run, and G75's REUSE, COVER and OBJECTS checks are untouched.

THE THREE CHECKS
----------------
| check | rule | the case it was written for |
|---|---|---|
| SCALE | distinct objects >= ceil(drawn / 3), capped at 8 | 17 drawn questions on 4 shapes |
| DOMINANCE | the busiest object serves <= max(2, ceil(drawn / 5)) questions | the same rhombus on questions 1, 2, 10, 11, 15 |
| PART | a part with 3+ drawn questions shows 2+ objects | a whole חלק that is one shape, five ways |

`drawn` is the number of questions that carry a figure — not the number of
questions — so a sheet is never asked to invent shapes for its text items.

An "object" is `figkit.figure_family(svg)`, the same key G75 uses: a rhombus and
the same rhombus with a diagonal added are ONE object; a rhombus and a trapezoid
are two. That is the whole point — the gate is blind to decoration and sees only
the shape.

SCOPE, AND WHAT THE OVERRIDE DOES
---------------------------------
SCALE and PART run on a figure sheet (`emit_html.is_figure_sheet`), and
`figure_sheet=False` on the level switches them off, exactly as it does for
G75's COVER and OBJECTS.

DOMINANCE runs ALWAYS and the override never lifts it, on the same principle
that keeps REUSE unconditional: an algebra sheet has no more right to run half
its questions on one parabola than a geometry sheet has to run them on one
rhombus.

HOW IT RUNS
-----------
`build_plus.py` installs it and then runs the stock `build.py`, so the gate fires
inside `build_html` next to G74 and G75 and cannot be skipped:

    DYLD_FALLBACK_LIBRARY_PATH=/opt/homebrew/lib python3 /path/to/build_plus.py

Nothing in `emit_html.py`, `build.py` or `gates_runner.py` is edited. `install()`
wraps `emit_html.assert_figure_variety` at import time and is idempotent.

WHAT THE AUTHOR DOES WITH A FAILURE
-----------------------------------
The same thing G75 asks for, one level up. G75 says: a question that returns to a
shape already drawn draws what IT adds. G76 says: across the sheet, CHANGE THE
SHAPE. A different point set per part, a shape on the axes and a shape off them,
one with a negative coordinate, a concave one, a small one and a large one, a
circle among the polygons. Twenty questions on one rhombus is a drill; a
synthesis sheet is supposed to be a synthesis.
"""
import math
import re
import sys
from collections import Counter

__all__ = ["variety_report", "assert_variety_scales", "density_report",
           "assert_visual_density", "figure_family_plus", "install",
           "VAR_OBJECTS_PER", "VAR_OBJECTS_CAP", "VAR_DOMINANCE_PER",
           "VAR_PART_MIN_DRAWN", "VAR_PART_MIN_OBJECTS",
           "DEN_Q_COVER", "DEN_ITEM_COVER", "DEN_PLACEMENTS_FROM"]

VAR_OBJECTS_PER = 3         # one distinct object per three drawn questions
VAR_OBJECTS_CAP = 8         # ...but never demand more than this
VAR_DOMINANCE_PER = 5       # busiest object: one question per five drawn
VAR_DOMINANCE_FLOOR = 2     # ...with this floor, so a tiny sheet stays legal
VAR_PART_MIN_DRAWN = 3      # a part with this many drawn questions...
VAR_PART_MIN_OBJECTS = 2    # ...shows at least this many objects

# G77 (v5.6) — VISUAL DENSITY. The author measured three finished packages:
# 94% of QUESTIONS carried a drawing and 23-27% of SUB-ITEMS did, because the
# emitter draws once per question and the reader reads per sub-item. A page of
# four questions showed four drawings and fifteen empty ruled bands. Both G75
# and G76 count questions, so neither could see it.
DEN_Q_COVER = 0.98          # of questions, on a geometry sheet
DEN_ITEM_COVER = 0.90       # of sub-items — the number the reader actually sees
DEN_PLACEMENTS_FROM = 8     # from this many questions, a sheet needs 2 placements
ITEM_FIG_MAX = 150.0        # px — wider belongs at the question head


_FAM_RE = re.compile(r"<!--\s*fam:([^>]+?)\s*-->")


def figure_family_plus(svg):
    """The object a figure draws — configuration first, geometry second.

    `figkit.figure_family` keys a figure on its polygon coordinates. On a
    COORDINATE sheet that is right. On a EUCLIDEAN sheet it is wrong in both
    directions, and the author verified both: a triangle drawn larger, or
    rotated, gets a different key (so a sheet of one configuration in twelve
    sizes passes G76), while a circle with no polygon falls to the
    `("none", whole svg)` branch, where a changed label invents a new object
    (so six near-identical circle figures also pass).

    So a Euclidean builder DECLARES what it drew, as an SVG comment
    `<!--fam:triangle.right+altitude-->`, and this key reads the declaration
    when it is there. Rotation and scale collapse into one object, which is the
    truth for a reader; a right triangle with an altitude and an isosceles
    triangle with a median stay two."""
    # v6 C4: an SVG that draws nothing is not an object (an empty
    # number-line call once counted as one of a sheet's figure families)
    if not re.search(r"<(line|path|polyline|polygon|rect|circle|ellipse|text)\b",
                     _FAM_RE.sub("", str(svg))):
        raise AssertionError(
            "figure_family_plus: this figure draws nothing (no line, path, "
            "shape or text) -- it is not an object; build the figure, or leave "
            "fig= out")
    m = _FAM_RE.search(str(svg))
    if m:
        return ("cfg", m.group(1).strip())
    from figkit import figure_family
    return figure_family(svg)


def chart_reprints(L):
    """(v6.16 fix r1, D-G76) {question n: original n} -- the DATA CHARTS a
    level declares as REPRINTS: L["chart_reprints"] = {n: (original n,
    reason)}. The source prints the same pie chart beside every question
    about its data ("באותו תרשים", G8-T30 b q1-q3); the frozen pie corpus
    requires each question to own its copy (SCORING_pie 4.2), and a copy is
    not a new object. A reprint is counted ONCE, at its original, by
    DOMINANCE / SCALE / PART. Refused (AssertionError, named): a reprint of a
    question the level lacks or that comes later, a figure that is not a
    pie-chart family figure (data-pie), a copy whose object differs from the
    original's, a missing reason, a chain (a reprint of a reprint)."""
    rp = L.get("chart_reprints") or {}
    if not isinstance(rp, dict):
        raise AssertionError("G76: chart_reprints is {question n: (original "
                             "n, reason)}, not %r" % (rp,))
    qs = dict((q.get("n"), q) for q in L.get("questions", []))
    out = {}
    for n, v in rp.items():
        if not (isinstance(v, (tuple, list)) and len(v) == 2):
            raise AssertionError("G76: chart_reprints[%s] is (original n, "
                                 "reason), not %r" % (n, v))
        m, why = v
        q, o = qs.get(n), qs.get(m)
        if q is None or o is None or not m < n:
            raise AssertionError("G76: chart_reprints %s -> %s: both must be "
                                 "questions of level %s, the original first"
                                 % (n, m, L.get("key")))
        if not str(why or "").strip():
            raise AssertionError("G76: chart_reprints %s gives no reason" % n)
        if m in rp:
            raise AssertionError("G76: chart_reprints %s -> %s: %s is itself "
                                 "a reprint (name the original)" % (n, m, m))
        for k in (n, m):
            f = qs[k].get("fig")
            if not f or "data-pie=" not in str(f):
                raise AssertionError("G76: chart_reprints %s -> %s: question "
                                     "%s carries no pie chart (a reprint is "
                                     "a data chart only)" % (n, m, k))
        if figure_family_plus(q["fig"]) != figure_family_plus(o["fig"]):
            raise AssertionError("G76: chart_reprints %s -> %s: the copy is "
                                 "not the same chart as the original" % (n, m))
        out[n] = m
    return out


_PIE_HOOK = re.compile(r'data-pie="([a-z]+)"')


def is_build_workspace(svg):
    """(v6.16 fix r1, D-G76) a pie-family figure that is ONLY an empty build
    circle (data-pie "bcirc", optionally its centre dot "bdot"): the
    workspace a build-a-pie question gives the student to draw in, like the
    empty ruled band of a written answer -- not an object a question is
    'about'. G76 does not count it (each build question has its own data;
    the circle is the same by design). G77 still counts it as a drawing.
    (v6.16 integrate r2, pie IR3) an empty disc's caption (hook "bcap",
    wspec-pie/1.1) is part of that workspace: a row of EMPTY discs with
    their captions is one too."""
    hooks = set(_PIE_HOOK.findall(str(svg or "")))
    return bool(hooks) and hooks <= {"bcirc", "bdot", "bcap"}


def _families(L):
    """{question number: object key} for every question that carries a figure
    (a declared chart reprint is counted once, at its original; an empty
    build-a-pie circle is a workspace, not an object)."""
    rp = chart_reprints(L)
    out = {}
    for q in L["questions"]:
        if q.get("fig") and q.get("n") not in rp and \
                not is_build_workspace(q["fig"]):
            out[q["n"]] = figure_family_plus(q["fig"])
    return out


def _item_figs(q):
    """The figures carried by a question's sub-items (4-tuple items, v5.6)."""
    return [it[3] for it in q.get("items", []) if len(it) >= 4 and it[3]]


def _placement(svg):
    """Where the emitter will put a figure: a row of small figures, a block
    across the page, or a column beside the text."""
    t = str(svg)
    if "figrow" in t:
        return "row"
    m = re.search(r'<svg[^>]*\bwidth="([\d.]+)', t)
    w = float(m.group(1)) if m else 0.0
    return "block" if w > 210.0 else "side"


def density_report(L):
    """What a reader sees, counted the way a reader sees it."""
    import emit_html as E
    # (v6.14 F4) a figure_exempt question (named, with its reason, drawing
    # nothing) is outside the floors; every other question counts
    ex = E.figure_exemptions(L)
    qs = [q for q in L.get("questions", []) if q.get("n") not in ex]
    items = drawn_items = drawn_qs = 0
    placements, wide_item = set(), []
    for q in qs:
        ifigs = _item_figs(q)
        head = q.get("fig")
        if head or ifigs:
            drawn_qs += 1
        if head:
            placements.add(_placement(head))
        if ifigs:
            placements.add("item")
        its = q.get("items", [])
        items += len(its)
        for i, it in enumerate(its):
            own = len(it) >= 4 and it[3]
            if own:
                m = re.search(r'<svg[^>]*\bwidth="([\d.]+)', str(it[3]))
                if m and float(m.group(1)) > ITEM_FIG_MAX:
                    wide_item.append((q["n"], it[0], float(m.group(1))))
            # the head figure sits beside the FIRST item, so that item is drawn
            if own or (i == 0 and head):
                drawn_items += 1
    return dict(n=len(qs), items=items, drawn_qs=drawn_qs,
                drawn_items=drawn_items,
                q_cover=(drawn_qs / float(len(qs))) if qs else 1.0,
                item_cover=(drawn_items / float(items)) if items else 1.0,
                placements=sorted(placements), wide_item=wide_item,
                figure_sheet=E.is_figure_sheet(L))


def assert_visual_density(L, verbose=True):
    """G77 — raises with the numbers that decided it."""
    r = density_report(L)
    if not r["figure_sheet"]:
        return r
    bad = []
    # (v6.16 fix r1, W-FIGURE-DENSITY) on a level G83 governs (a figure
    # topic, gate_figref) the author's rule decides the density: every
    # question but the drawing-from-words share has a figure, and a sub-item
    # gets its OWN figure when its situation differs -- not on a 90% quota.
    # G77's QUESTIONS / SUB-ITEMS floors give way to G83 there; PLACEMENT
    # and ITEM FIGURE TOO WIDE still run.
    import gate_figref as _GF
    r["g83"] = _GF.governs(L)
    if r["g83"]:
        pass
    elif r["n"] and r["q_cover"] < DEN_Q_COVER:
        bad.append("QUESTIONS: %d of %d carry a drawing (%.0f%%), floor %.0f%%"
                   % (r["drawn_qs"], r["n"], 100 * r["q_cover"],
                      100 * DEN_Q_COVER))
    if not r["g83"] and r["items"] and r["item_cover"] < DEN_ITEM_COVER:
        bad.append(
            "SUB-ITEMS: %d of %d carry a drawing (%.0f%%), floor %.0f%%. This "
            "is the number the reader sees: one figure per question means one "
            "drawing and three empty ruled bands. Give the sub-items their own "
            "small figures (4-tuple items, emit_plus)"
            % (r["drawn_items"], r["items"], 100 * r["item_cover"],
               100 * DEN_ITEM_COVER))
    if r["n"] >= DEN_PLACEMENTS_FROM and len(r["placements"]) < 2:
        bad.append(
            "PLACEMENT: every figure is placed the same way (%s). A sheet whose "
            "drawings all sit in one column at one size reads as copy-paste "
            "however varied the shapes are — use wide() or row() or item "
            "figures for some of them" % (r["placements"] or ["none"])[0])
    if r["wide_item"]:
        bad.append("ITEM FIGURE TOO WIDE: %s — over %.0fpx belongs at the "
                   "question head"
                   % (", ".join("q%s%s %.0fpx" % w for w in r["wide_item"]),
                      ITEM_FIG_MAX))
    if bad:
        raise AssertionError("G77 (visual density, level %s): %s"
                             % (L.get("key", "?"), " | ".join(bad)))
    if verbose:
        print("G77 %-4s questions %.0f%% · sub-items %.0f%% (%d/%d) · "
              "placements %s" % (L.get("key", "?"), 100 * r["q_cover"],
                                 100 * r["item_cover"], r["drawn_items"],
                                 r["items"], "+".join(r["placements"])))
    return r


def _parts(L):
    """[(part name, [question numbers])] — a band is declared on the first
    question of its part, so it has to be carried forward."""
    parts, cur = [], None
    for q in L["questions"]:
        if q.get("part") or cur is None:
            name = str(q["part"][0]) if q.get("part") else "(no part band)"
            cur = (name, [])
            parts.append(cur)
        cur[1].append(q["n"])
    return parts


def need_objects(drawn):
    return min(VAR_OBJECTS_CAP, max(1, math.ceil(drawn / float(VAR_OBJECTS_PER))))


def allowed_dominance(drawn):
    return max(VAR_DOMINANCE_FLOOR,
               math.ceil(drawn / float(VAR_DOMINANCE_PER)))


def variety_report(L):
    """Everything G76 reads, as numbers — printable, testable, arguable."""
    import emit_html as E
    fam = _families(L)
    drawn = len(fam)
    counts = Counter(fam.values())
    busiest = counts.most_common(1)[0] if counts else (None, 0)
    part_rows = []
    for name, qns in _parts(L):
        objs = {fam[n] for n in qns if n in fam}
        part_rows.append((name, sum(1 for n in qns if n in fam), len(objs)))
    return dict(
        n=len(L["questions"]), drawn=drawn, objects=len(counts),
        need=need_objects(drawn), busiest_n=busiest[1],
        busiest_qs=sorted(n for n, k in fam.items() if k == busiest[0]),
        allowed=allowed_dominance(drawn), parts=part_rows,
        figure_sheet=E.is_figure_sheet(L), override=("figure_sheet" in L))


def assert_variety_scales(L, verbose=True):
    """G76 — raises AssertionError with every number that decided it."""
    r = variety_report(L)
    bad = []

    if r["drawn"] and r["busiest_n"] > r["allowed"]:
        bad.append(
            "DOMINANCE: one shape carries %d of the %d drawn questions "
            "(%s) — the cap at this size is %d. Those questions may each add "
            "their own diagonal or altitude and still be the same object; "
            "change the SHAPE, not the decoration"
            % (r["busiest_n"], r["drawn"],
               ", ".join(str(q) for q in r["busiest_qs"]), r["allowed"]))

    if r["figure_sheet"]:
        if r["objects"] < r["need"]:
            bad.append(
                "SCALE: %d drawn question(s) on %d object(s) — a sheet this "
                "size owes %d (one per %d drawn, capped at %d). A flat floor of "
                "3 objects is a floor for an 8-question sheet, not for this one"
                % (r["drawn"], r["objects"], r["need"], VAR_OBJECTS_PER,
                   VAR_OBJECTS_CAP))
        thin = ["%s (%d drawn, %d object)" % (nm, nd, no)
                for nm, nd, no in r["parts"]
                if nd >= VAR_PART_MIN_DRAWN and no < VAR_PART_MIN_OBJECTS]
        if thin:
            bad.append(
                "PART: %s — a part that walks one shape through every question "
                "is a drill. Give the part a second point set" % "; ".join(thin))

    if bad:
        raise AssertionError("G76 (variety scales, level %s): %s"
                             % (L.get("key", "?"), " | ".join(bad)))

    if verbose:
        print("G76 %-4s objects %d/%d · busiest %d/%d · parts %d%s"
              % (L.get("key", "?"), r["objects"], r["need"], r["busiest_n"],
                 r["allowed"], len(r["parts"]),
                 "   (figure_sheet=False: SCALE/PART off, DOMINANCE still on)"
                 if r["override"] and not r["figure_sheet"] else ""))
    return r


# ---------------------------------------------------------------- G78 ------
# P1 r1 (the author, 2026-09-17): ONE printed look for every coordinate plane
# on a sheet. figkit_plus.plane prints the house look (8pt numbers, axis
# arrowheads) whatever the width, but a narrow item figure with no room fell
# back to ~7.2pt or to v6.0's look, and nothing read it: z08_a built 'GATES:
# all pass' with 7.2pt planes under 8pt ones on pages 1, 3 and 9. G78 reads
# the FINISHED figures of the level (doctrine 3), not the builder's list.
G78_SPREAD_PT = 0.4


def _level_svgs(L):
    """(where, svg) for every figure of the level: question figures and
    sub-item figures, a figure row split into its SVGs."""
    out = []
    for q in L.get("questions", []):
        figs = [("q%s" % q.get("n"), q.get("fig"))]
        # P1 r2: an item figure is named by its item's LABEL ('q16 item ג'),
        # not by its place among the items that carry a figure -- 'q16 item
        # 1' was item ג and sent the builder to the wrong one
        figs += [("q%s item %s" % (q.get("n"), it[0]), it[3])
                 for it in q.get("items", []) if len(it) >= 4 and it[3]]
        for where, f in figs:
            if not f:
                continue
            for k, sv in enumerate(re.findall(r"<svg\b.*?</svg>", str(f), re.S)):
                out.append((where if k == 0 else "%s/%d" % (where, k + 1), sv))
    return out


def plane_look_report(L):
    """Everything G78 reads: per FIGURE, its printed number size, its printed
    letter size, arrowheads (planes only), and a fallback tag.

    Stage review (the author, 2026-09-18): this used to drop every figure
    svgcheck.is_coordinate_plane rejected, so a number line, a triangle or a
    pair of parallels printed whatever size it liked and nothing could fail.
    The skill's own gallery page 6 shipped one question whose two figures
    printed their angle numbers at 7.2 and 8.9pt. Every figure is read now;
    `plane` says which are coordinate planes, since the arrowhead rule is
    theirs alone."""
    import svgcheck as C
    import figkit_plus as FP
    rows = []
    for where, sv in _level_svgs(L):
        plane = C.is_coordinate_plane(sv)
        num, let = FP.printed_number_pt(sv), FP.printed_letter_pt(sv)
        if num is None and let is None and not plane:
            continue                      # a drawing with no text to judge
        fb = re.search(r"<!--house-fallback:([^>]*?)-->", sv)
        heads = None
        if plane:
            # P1 r2: arrowheads read by svgcheck.axis_heads, which finds the
            # axes of an unnumbered sketch too (house_look needs tick marks)
            hd = C.axis_heads(sv)
            heads = bool(hd) if hd is not None else not any(
                "has no arrowhead" in p for p in C.house_look(sv))
        # stage review: an explicit item width taken up to 150px is a real
        # change to what the author asked for (width=124 draws at 140), and
        # the only signal was a comment inside the SVG. G78 SAYS it.
        wd = re.search(r"<!--house-widened:from=([\d.]+),to=([\d.]+)-->", sv)
        # v6.2 Q1 r1 (L3-04, letter-band-reaches-nobody): the READING
        # distance of a point's letter. problems() refuses it only from
        # LETTER_REFUSE_EM and only where a nearer spot is free (doctrine 4),
        # and the band below that -- about 70% of the pilot's origin letters
        # -- was reported to nobody: svgcheck.letter_side(curable=False) had
        # no caller outside the test file. G78 prints it on every build now.
        rows.append(dict(where=where, pt=num, letter_pt=let, plane=plane,
                         heads=heads, far_letters=C.letter_side(sv,
                                                                reading=True),
                         legacy="<!--legacy-numberline-->" in sv,
                         widened=(wd.group(1), wd.group(2)) if wd else None,
                         fallback=fb.group(1) if fb else None,
                         width=(re.search(r'<svg[^>]*\bwidth="([\d.]+)', sv)
                                or [0, "?"])[1]))
    return rows


def _engine_look(L):
    """v6.9 fix r1 (P4): a level that prints engine (wspec) figures BESIDE
    builder figures prints one line look: the builder draws inner lines
    (diagonals, cevians, midsegments) thin under a normal outline, so every
    engine figure of such a level must be rendered with the display setting
    inner_stroke='thin' (else its diagonals print heavy beside thin ones).
    v6.9 fix r2 (P4): and with vertex_dots='corner' -- the builder puts no
    dot on a polygon's vertex; the engine's corner dot (r 0.75) hides in the
    join, so the vertex prints as its corner while the figure keeps a dot
    for every point (G79's anchors). A point on a line or where lines cross
    keeps its visible dot, as in the builder."""
    WB = sys.modules.get("wspec_build")
    if WB is None:
        return []
    svgs = [sv for _w, sv in _level_svgs(L)]
    eng = [sv for sv in svgs if WB.is_spec_svg(sv)]
    if not eng or len(eng) == len(svgs):
        return []
    heavy, dotted = [], []
    for sv in eng:
        for rec in WB._REG.get(sv) or []:
            # v6.12 fix_r1 (t08_b D2): a family figure (coordinate plane /
            # number line) draws no inner lines and no polygon vertex dots;
            # its renderer refuses both settings -- the look rule is not
            # about it (G78 still checks its axis heads and text sizes)
            if getattr(WB, "is_family_rec", lambda r: False)(rec):
                continue
            st = rec.get("settings") or {}
            if st.get("inner_stroke") != "thin":
                heavy.append(rec.get("fid"))
            if st.get("vertex_dots") != "corner":
                dotted.append(rec.get("fid"))
    out = []
    if heavy:
        out.append("LOOK: engine figure(s) %s print inner lines at the "
                   "normal width beside builder figures that draw them thin "
                   "-- give them display inner_stroke='thin' in the level's "
                   ".wspec.json (the outline stays normal)"
                   % ", ".join(sorted(set(heavy))))
    if dotted:
        out.append("LOOK: engine figure(s) %s print a dot on every vertex "
                   "beside builder figures that print none -- give them "
                   "display vertex_dots='corner' in the level's .wspec.json "
                   "(a vertex prints as its corner; points on lines keep "
                   "their dot)" % ", ".join(sorted(set(dotted))))
    return out


# the report is no longer about planes alone; the old name stays for callers
sheet_look_report = plane_look_report


def assert_one_plane_look(L, verbose=True):
    """G78 -- every coordinate plane of a level prints ONE look: its axis
    numbers within G78_SPREAD_PT of each other, no figure drawn as a narrow
    fallback, arrowheads on all or none.

    P1 r2: never off. new_sheet(house=False) returned [] here, silently, and
    one line brought back the mixed 7.2-7.7pt sheet G78 exists to catch; a
    v6.0-look sheet is judged for SIZE and ARROWS like any other."""
    import figkit_plus as FP
    rows = plane_look_report(L)
    bad = []
    fbs = [r for r in rows if r["fallback"]]
    if fbs:
        def fix(r):
            m = re.search(r"renders_at=([\w.]+)", r["fallback"])
            at = m.group(1) if m else "none"
            if at != "none" and "item" in r["where"] and float(at) > 150:
                return ("%s (width=%s): renders in the house look only at "
                        "width=%s, wider than an item figure's 150px -- move "
                        "it to the question head (q['fig']) at width=%s, or "
                        "number every 2 squares (step=2), never fewer numbers"
                        % (r["where"], r["width"], at, at))
            if at != "none":
                return ("%s (width=%s, %s): width=%s renders it in the house "
                        "look" % (r["where"], r["width"], r["fallback"]
                                  .split(",renders_at")[0], at))
            return ("%s (width=%s, %s): no width up to %dpx renders it -- "
                    "move it to the question head (q['fig'], width up to "
                    "210px) or number every 2 squares (step=2), never fewer "
                    "numbers" % (r["where"], r["width"], r["fallback"]
                                 .split(",renders_at")[0], FP.HOUSE["narrow_px"]))
        bad.append("NARROW: printed under the sheet's look, the width leaves "
                   "no room for the house numbers and arrowheads: "
                   + "; ".join(fix(r) for r in fbs))
    # Stage review: numbers are judged against numbers and letters against
    # letters, over EVERY figure kind -- a triangle carrying only A, B, C is
    # judged on its letters, a number line on both.
    for key, what, house_key in (("pt", "numbers", "number_pt"),
                                 ("letter_pt", "letters", "letter_pt")):
        pts = [r for r in rows if r.get(key)]
        # the spread is judged in proportion: letters print 19% larger than
        # numbers, so the same relative drift is a larger number of points
        spread = G78_SPREAD_PT * FP.HOUSE[house_key] / FP.HOUSE["number_pt"]
        if not pts or max(r[key] for r in pts) - min(r[key] for r in pts) \
                <= spread:
            continue
        common = sorted(pts, key=lambda r: r[key])[len(pts) // 2][key]
        # P1 r2: the sheet's own size is the common one when any figure
        # prints it -- with two figures the median was the odd one
        tgt = FP.house_text_pt(house_key) if FP.SHEET.get("house") else None
        if tgt and any(abs(r[key] - tgt) <= spread / 2 for r in pts):
            common = float(tgt)
        odd = [r for r in pts if abs(r[key] - common) > spread / 2]
        lg = [r["where"] for r in odd if r.get("legacy")]
        bad.append(
            "SIZE: the sheet's figures print their %s at %.1fpt but %s -- "
            "one sheet prints them at one size (within %.1fpt)%s"
            % (what, common, ", ".join("%s at %.1fpt" % (r["where"], r[key])
                                       for r in odd), spread,
               "" if FP.SHEET.get("house") else
               "; new_sheet(house=False) prints each figure in proportion to "
               "its width -- drop house=False for the house look, whose "
               "numbers print at %gpt at any width" % FP.HOUSE["number_pt"])
            + ("; %s came from the figkit.number_line SHIM, which keeps its "
               "caller's own size=/font= -- draw it with the builder instead "
               "and it prints the sheet's look: "
               "numberline.NL(lo, hi, tier='item').point(v, 'H')"
               % ", ".join(lg) if lg else ""))
    if len(set(r["heads"] for r in rows if r["plane"])) > 1:
        bad.append(
            "ARROWS: %s carry axis arrowheads and %s do not (axis_arrows= is "
            "one setting for the sheet: new_sheet(axis_arrows=...))"
            % (", ".join(r["where"] for r in rows if r["plane"] and r["heads"]),
               ", ".join(r["where"] for r in rows
                         if r["plane"] and not r["heads"])))
    bad += _engine_look(L)
    if bad:
        raise AssertionError("G78 (one figure look, level %s): %s"
                             % (L.get("key", "?"), " | ".join(bad)))
    if verbose and rows:
        # v6.2 Q1 r1 (L3-04): a NOTE, not a refusal -- the band where a fix
        # that renders cannot be named (see svgcheck.letter_side). Silent, it
        # reached no author at all.
        far = [(r["where"], m) for r in rows for m in r.get("far_letters") or []]
        if far:
            print("G78 %-4s NOTE %d letter(s) stand far from the point they "
                  "name (not refused -- no width cures the origin's own "
                  "square): %s"
                  % (L.get("key", "?"), len(far),
                     "; ".join("%s: %s" % (w, m) for w, m in far[:4])
                     + (" (+%d more)" % (len(far) - 4) if len(far) > 4 else "")))
        sizes = sorted(set("%.1f" % r["pt"] for r in rows if r["pt"])) or ["-"]
        lets = sorted(set("%.1f" % r["letter_pt"] for r in rows
                          if r["letter_pt"])) or ["-"]
        wide = [r for r in rows if r.get("widened")]
        print("G78 %-4s %d figure(s), %d plane(s): numbers %spt, letters %spt%s%s"
              % (L.get("key", "?"), len(rows),
                 sum(1 for r in rows if r["plane"]), "/".join(sizes),
                 "/".join(lets),
                 "" if FP.SHEET.get("house") else " (house=False)",
                 ("; WIDENED to hold the house look: "
                  + ", ".join("%s width=%s drawn at %spx"
                              % (r["where"], r["widened"][0], r["widened"][1])
                              for r in wide)) if wide else ""))
    return rows


def install(verbose=True):
    """Wrap `emit_html.assert_figure_variety` so G76 runs wherever G75 runs —
    inside `build_html`, on every level, with no edit to emit_html.py and no
    way for a content file to opt out. Idempotent."""
    import emit_html as E
    if getattr(E.assert_figure_variety, "_g76_installed", False):
        return E.assert_figure_variety
    inner = E.assert_figure_variety

    def wrapped(L):
        r = inner(L)                      # G75 first: it is the coarser net
        assert_variety_scales(L, verbose=verbose)
        assert_visual_density(L, verbose=verbose)
        assert_one_plane_look(L, verbose=verbose)     # P1 r1: G78
        return r

    wrapped._g76_installed = True
    wrapped._inner = inner         # P1 r1: a G75-only test can reach it
    wrapped.__doc__ = (inner.__doc__ or "") + "\n\nWrapped by gate_variety.G76."
    E.assert_figure_variety = wrapped
    return wrapped
