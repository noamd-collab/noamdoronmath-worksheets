#!/usr/bin/env python3
"""Real vector math -> inline SVG paths with exact baseline.

Radicals are true surds: the vinculum is part of the glyph/rule and is drawn
CONNECTED to the sign, scaling with the radicand (fractions, nested roots).
Output is pure <path> data: no font dependency at print time, bidi-atomic.
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib as mpl
import matplotlib.font_manager as fm
from matplotlib.textpath import TextPath
from matplotlib.font_manager import FontProperties
from pathlib import Path

# The bundled faces sit NEXT TO this file. The path used to climb three
# directories out of the package, so from a delivered skill it resolved
# outside it and every addfont() was skipped in silence -- the same shape
# as the font-path bug this whole version exists to fix.
_FDIR = Path(__file__).resolve().parent / "assets"
for _f in ("DavidLibre-Regular.ttf", "DavidLibre-Bold.ttf", "DavidLibre-Medium.ttf"):
    p = _FDIR / _f
    if p.exists():
        fm.fontManager.addfont(str(p))

# STIX: Times-like serif with a full math repertoire (true surds, fraction
# rules, italic variables). Pairs with David Libre's Times-like Latin.
mpl.rcParams["mathtext.fontset"] = "stix"

_cache = {}


def math_svg(tex: str, size: float = 13.0, cls: str = "m") -> str:
    key = (tex, round(size, 3), cls)
    if key in _cache:
        return _cache[key]
    tp = TextPath((0, 0), f"${tex}$", prop=FontProperties(size=size), usetex=False)
    verts = tp.vertices
    if len(verts) == 0:
        return ""
    x0, y0 = verts.min(axis=0)
    x1, y1 = verts.max(axis=0)
    pad = size * 0.03
    x0 -= pad; x1 += pad; y0 -= pad; y1 += pad
    w, h = x1 - x0, y1 - y0
    d = []
    for pts, code in tp.iter_segments():
        if code == 1:
            d.append("M%.2f,%.2f" % (pts[0] - x0, y1 - pts[1]))
        elif code == 2:
            d.append("L%.2f,%.2f" % (pts[0] - x0, y1 - pts[1]))
        elif code == 3:
            d.append("Q%.2f,%.2f %.2f,%.2f" % (pts[0]-x0, y1-pts[1], pts[2]-x0, y1-pts[3]))
        elif code == 4:
            d.append("C%.2f,%.2f %.2f,%.2f %.2f,%.2f" % (
                pts[0]-x0, y1-pts[1], pts[2]-x0, y1-pts[3], pts[4]-x0, y1-pts[5]))
        elif code == 79:
            d.append("Z")
    descent = -y0
    svg = ('<svg class="%s" xmlns="http://www.w3.org/2000/svg" width="%.2fpt" '
           'height="%.2fpt" viewBox="0 0 %.2f %.2f" style="vertical-align:%.2fpt">'
           '<path d="%s" fill="currentColor" fill-rule="nonzero"/></svg>'
           % (cls, w, h, w, h, -descent, "".join(d)))
    _cache[key] = svg
    return svg


if __name__ == "__main__":
    import sys
    print(math_svg(sys.argv[1], float(sys.argv[2]) if len(sys.argv) > 2 else 13.0))
