# -*- coding: utf-8 -*-
u"""landing_build — v7.2.0. Write out/catalog/<sheet_id>/landing.json: the content of the sheet's landing page.

    import landing_build
    landing_build.build(pkg_dir, out_dir)          # -> Path of landing.json
    python3 landing_build.py --pkg DIR [--out DIR] [--deliver DIR]
    python3 landing_build.py --selftest

WHY
---
Every site topic has a hand-written landing page, src/data/topic-pages/<slug>.json
(website.md §5c). Today the angle pages describe the old sheets, and they are
where the forbidden "נשלמות" actually lives (website.md §7.5). A v7.2 sheet knows
its sections, their official definitions and explanations (registry definition_he
/ explain_he) and which questions illustrate each one, so it can hand the site a
page skeleton whose text came from the same checked sources as the sheet, with one
anchor per section to deep-link from the catalog search ("#angles-vertical").
Nothing on the site is touched; this file is an input for a later, reviewed PR.

All text is taken from SHEET, the registry or short fixed Hebrew frames
(selfcheck_catalog.H1_FRAME, DESCRIPTION_FRAME, ALT_FRAME, COMBO_EXPLAIN,
CTA_LABEL — shared with G89, which recomputes every derived string and compares),
so the glossary gate G86 can scan it like the sheet itself; landing_build prints a
warning if glossary_lint finds a forbidden form, but G86 is the gate.

SCHEMA "noam-landing/v1" (whitelist: selfcheck_catalog.LANDING_REQUIRED et al.)
  schema, sheet_id
  slug              SHEET.landing.slug                     site: slug
  path              "/" + slug                             site: path
  grade             int                                    site: grade
  title             == SHEET.title                         site: title is "<h1> | …" (SEO);
                                                           set at publish
  h1                "<title> לכיתה ז׳"                     site: h1
  description       one fixed sentence + title             site: description
  intro             first explain_he sentence of every     site: intro (≥ 40 chars, ≠ h1)
                    subtopic section
  anchors           one per section, in order:             site: sections[] —
                    {anchor, kind, subtopic, title,          title → sections[].heading,
                     definition_he (registry, may hold       definition_plain + explain_he →
                     $…$ math), definition_plain (the        blocks[{type:"paragraph",
                     same with ∡/β…, or null),               text, links: []}],
                     explain_he [2 sentences],               anchor → the section's id
                     example_question_ids [1-2, level a],    attribute (#anchor)
                     combines (combo: the anchors)}
  animation         ONE {id: SHEET.landing.animation_id,   site: COMPONENT_LANDING_LOOPS /
                     anchor: where it appears, alt_he}       landingLoops.ts marker
  downloads         {a|b|c: {label, pdf, docx}} bare        site: catalogCtas + Wix pdfId
                    placeholder names "<sheet_id>_<k>.pdf"   (filled at publish)
  relatedTopics     [{label, subtopic, relation              site: relatedTopics[{path,
                      "requires"|"next", sheet, anchor,        label}] — path resolved at
                      path (null until published)}]            publish
  catalogCta        {label, href null, catalogTopicId null,  site: catalogCta (topic id is
                     catalogTopicTitle}                        assigned at publish)
  synthetic         (optional) as in the catalog entry

The animation sits at SHEET.landing.animation_anchor when given, else at the first
subtopic section whose slug words all appear in the animation id
("two-lines-vertical-angles" → angles-vertical), else at the first section.
Its alt text is SHEET.landing.animation_alt_he when given, else a fixed frame
with that section's title.
"""
import argparse
import re
import sys
import time
from pathlib import Path

SK = Path(__file__).resolve().parent
if str(SK) not in sys.path:
    sys.path.insert(0, str(SK))

import catalog_build as CB  # noqa: E402
import selfcheck_catalog as G89  # noqa: E402

SCHEMA = G89.LANDING_SCHEMA
# The fixed Hebrew frames and the math-to-plain converter live in selfcheck_catalog:
# G89 recomputes every one of these strings and compares, so builder and checker
# must share a single copy.
GRADE_HE = G89.GRADE_HE
CTA_LABEL = G89.CTA_LABEL
COMBO_EXPLAIN = G89.COMBO_EXPLAIN
plain_math = G89.plain_math


def _animation_anchor(sheet, anchors):
    land = sheet.get("landing") or {}
    names = [a["anchor"] for a in anchors]
    if land.get("animation_anchor") in names:
        return land["animation_anchor"]
    words = set(re.split(r"[-_]+", (land.get("animation_id") or u"").lower()))
    topic = (sheet.get("topic_id") or u"").replace("_", "-")
    for a in anchors:
        if a["kind"] != "subtopic":
            continue
        slug = a["anchor"][len(topic) + 1:] if a["anchor"].startswith(topic + "-") else a["anchor"]
        sw = [w for w in slug.split("-") if w]
        if sw and all(w in words for w in sw):
            return a["anchor"]
    return names[0] if names else None


def _related(sheet, entry, reg):
    own = set(entry.get("subtopic_ids") or [])
    req, nxt = [], []
    for sid in entry.get("subtopic_ids") or []:
        e = reg.get(sid) or {}
        for r in e.get("requires") or []:
            if r not in own and r not in req:
                req.append(r)
    for track, topic, e in reg.located():
        if track != sheet.get("track") or topic != sheet.get("topic_id"):
            continue
        # A subtopic that one section requires and that itself requires
        # another section is listed once, as "requires"; G89 rejects a
        # subtopic listed twice (seen on a grade-9 parallels sheet, 2026-11-09).
        if e.get("id") in own or e.get("id") in nxt or e.get("id") in req:
            continue
        if own & set(e.get("requires") or []):
            nxt.append(e["id"])
    out = []
    for rel, ids in (("requires", req), ("next", nxt)):
        for sid in ids:
            e = reg.get(sid) or {}
            out.append({"label": e.get("title") or sid, "subtopic": sid, "relation": rel,
                        "sheet": e.get("sheet"), "anchor": CB.anchor_for(sid), "path": None})
    return out


def landing_from(sheet, entry, registry=None):
    """The landing dict for a SHEET and its catalog entry. Pure: reads only the registry."""
    if not sheet:
        raise CB.LegacyPackageError("legacy package (no SHEET): there is no landing page for it")
    reg = registry or CB.Registry()
    grade = str(sheet.get("grade"))
    ghe = GRADE_HE.get(grade, grade)
    title = sheet.get("title")
    by_id = {s["id"]: s for s in entry["sections"]}
    anchors, intro = [], []
    for s in entry["sections"]:
        ex = list((s.get("question_ids") or {}).get("a") or [])[: (1 if s["kind"] == "combo" else 2)]
        if s["kind"] == "combo":
            names = [by_id[c]["title"] for c in s.get("combines") or [] if c in by_id]
            anchors.append({"anchor": s["anchor"], "kind": "combo", "subtopic": None, "title": s["title"],
                            "definition_he": None, "definition_plain": None,
                            "explain_he": [COMBO_EXPLAIN[0] % u", ".join(names), COMBO_EXPLAIN[1]],
                            "example_question_ids": ex,
                            "combines": [by_id[c]["anchor"] for c in s.get("combines") or [] if c in by_id]})
            continue
        e = reg.get(s["subtopic"]) or {}
        expl = G89._explain(e)
        if expl:
            intro.append(expl[0])
        anchors.append({"anchor": s["anchor"], "kind": "subtopic", "subtopic": s["subtopic"],
                        "title": s["title"], "definition_he": e.get("definition_he"),
                        "definition_plain": plain_math(e.get("definition_he")),
                        "explain_he": expl, "example_question_ids": ex})
    land = sheet.get("landing") or {}
    at = _animation_anchor(sheet, anchors)
    at_title = next((a["title"] for a in anchors if a["anchor"] == at), title)
    out = {"schema": SCHEMA, "sheet_id": sheet.get("sheet_id"), "slug": land.get("slug"),
           "path": "/" + str(land.get("slug")), "grade": int(grade) if grade.isdigit() else grade,
           "title": title, "h1": G89.H1_FRAME % (title, ghe),
           "description": G89.DESCRIPTION_FRAME % (ghe, title),
           "intro": u" ".join(intro) or title,
           "anchors": anchors,
           "animation": {"id": land.get("animation_id"), "anchor": at,
                         "alt_he": land.get("animation_alt_he") or G89.ALT_FRAME % at_title},
           "downloads": {k: {"label": entry["levels"][k]["name"],
                             "pdf": "%s_%s.pdf" % (sheet.get("sheet_id"), k),
                             "docx": "%s_%s.docx" % (sheet.get("sheet_id"), k)} for k in entry["levels"]},
           "relatedTopics": _related(sheet, entry, reg),
           "catalogCta": {"label": CTA_LABEL, "href": None, "catalogTopicId": None, "catalogTopicTitle": title}}
    if entry.get("synthetic"):
        out["synthetic"] = True
    allowed = set(G89.LANDING_REQUIRED) | set(G89.LANDING_OPTIONAL)
    assert set(out) <= allowed, sorted(set(out) - allowed)
    return out


def to_topic_page(landing):
    """A TopicPageContent-shaped skeleton (website.md §5c) — returned, never written.

    Shows how the fields map; faq, jsonLd, author and the real catalogCta href are
    deliberately absent: they are written by hand (or by the site's build) in the
    reviewed site PR, not by the skill.
    """
    secs = []
    for a in landing["anchors"]:
        text = u" ".join(x for x in [a.get("definition_plain")] + list(a.get("explain_he") or []) if x)
        secs.append({"heading": a["title"], "id": a["anchor"],
                     "blocks": [{"type": "paragraph", "text": text, "links": []}]})
    return {"slug": landing["slug"], "path": landing["path"], "grade": landing["grade"],
            "verifiedVia": "authored", "title": landing["title"], "description": landing["description"],
            "h1": landing["h1"], "intro": landing["intro"], "sections": secs,
            "updatedLine": None, "updatedLinePlacement": "absent",
            "relatedTopics": [{"path": r["path"], "label": r["label"]} for r in landing["relatedTopics"]],
            "catalogCta": dict(landing["catalogCta"])}


def build(pkg_dir, out_dir, deliver_root=None):
    """out/catalog/<sheet_id>/landing.json for a sectioned package; returns its Path."""
    reg = CB.Registry()
    sheet, entry, _ = CB.compute(pkg_dir, out_dir, deliver_root, reg)
    land = landing_from(sheet, entry, reg)
    bad = CB.glossary_lint(list(CB.all_strings(land)), sheet.get("grade"), sheet.get("scope"), reg.glossary())
    for rid, m, s in bad:
        print(u"landing_build: WARNING glossary %s matches %r in %r (G86 will fail it)" % (rid, m, s[:80]),
              file=sys.stderr)
    return CB.write_json(Path(out_dir) / "catalog" / sheet["sheet_id"] / "landing.json", land)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--pkg")
    ap.add_argument("--out")
    ap.add_argument("--deliver")
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args(argv)
    if a.selftest:
        return selftest()
    if not a.pkg:
        ap.error("--pkg is required")
    try:
        print(build(a.pkg, a.out or str(Path(a.pkg) / "out"), a.deliver))
    except CB.LegacyPackageError as e:
        print("landing_build: %s" % e, file=sys.stderr)
        return 2
    return 0


def selftest():
    t0 = time.time()
    fails = []

    def eq(got, want, what):
        if got != want:
            fails.append(u"%s: got %r, want %r" % (what, got, want))

    eq(plain_math(u"למשל $\\angle{ABC}$, או $\\beta$."), u"למשל ∡ABC, או β.", "plain_math angle/greek")
    eq(plain_math(u"$a^{n}\\cdot a^{k}=a^{n+k}$"), u"aⁿ·aᵏ=aⁿ⁺ᵏ", "plain_math powers")
    eq(plain_math(u"$\\int x$"), None, "plain_math unknown → None")
    eq(plain_math(u"$\\left(\\frac{a}{b}\\right)^n=\\frac{a^n}{b^n}$, כאשר $b\\neq0$."),
       u"(a/b)ⁿ=aⁿ/bⁿ, כאשר b≠0.", "plain_math quotient law")
    eq(plain_math(u"$\\sqrt{a\\cdot b}=\\sqrt{a}\\cdot\\sqrt{b}$ כאשר $a\\ge0$; $\\sqrt{\\frac{a}{b}}=\\frac{\\sqrt{a}}{\\sqrt{b}}$"),
       u"√(a·b)=√a·√b כאשר a≥0; √(a/b)=√a/√b", "plain_math root laws")
    eq(plain_math(u"$\\frac{a^n}{a^k}=a^{n−k}$"), u"aⁿ/aᵏ=aⁿ⁻ᵏ", "plain_math quotient, U+2212 exponent")
    eq(plain_math(u"$a\\cdot a\\cdot\\ldots\\cdot a=a^n$"), u"a·a·…·a=aⁿ", "plain_math ldots")
    eq(plain_math(u"בלי מתמטיקה"), u"בלי מתמטיקה", "plain text unchanged")
    reg = CB.Registry()
    sheet = {"sheet_id": "T7-ANG-92", "package": "G7-T92", "grade": "7", "track": u"ז", "topic_id": "angles",
             "scope": "sectioned", "title": u"זוויות צמודות וזוויות קודקודיות",
             "sections": [
                 {"id": "T7-ANG-92.s1", "subtopic": "st.g7.angles.adjacent", "kind": "subtopic",
                  "title": u"זוויות צמודות", "questions": {"a": [1, 2, 3, 4], "b": [1, 2, 3, 4]}},
                 {"id": "T7-ANG-92.s2", "subtopic": "st.g7.angles.vertical", "kind": "subtopic",
                  "title": u"זוויות קודקודיות", "questions": {"a": [5, 6, 7, 8], "b": [5, 6, 7, 8]}},
                 {"id": "T7-ANG-92.s3", "kind": "combo", "title": u"שילוב",
                  "combines": ["T7-ANG-92.s1", "T7-ANG-92.s2"], "questions": {"a": [9, 10], "b": [9, 10]}}],
             "landing": {"slug": "t7-ang-92", "animation_id": "two-lines-vertical-angles"}, "replaces": []}
    levels = {k: {"name": CB.LEVEL_NAMES[k], "question_ids": ["q%d" % n for n in range(1, 11)],
                  "item_ids": ["q%da" % n for n in range(1, 11)], "pages": 4} for k in ("a", "b")}
    try:
        entry = CB.entry_from(sheet, levels, reg)
        land = landing_from(sheet, entry, reg)
        eq([a["anchor"] for a in land["anchors"]], ["angles-adjacent", "angles-vertical", "angles-combo"], "anchors")
        eq(land["animation"]["anchor"], "angles-vertical", "animation anchor from the id words")
        eq(land["anchors"][0]["example_question_ids"], ["q1", "q2"], "examples from level a")
        eq(land["anchors"][2]["combines"], ["angles-adjacent", "angles-vertical"], "combo anchors")
        eq(sorted(land["downloads"]), ["a", "b"], "downloads per level")
        eq([r["subtopic"] for r in land["relatedTopics"] if r["relation"] == "requires"],
           ["st.g7.angles.sum_diff"], "requires")
        eq(bool([r for r in land["relatedTopics"] if r["relation"] == "next"]), True, "next subtopics exist")
        eq(CB.glossary_lint(list(CB.all_strings(land)), "7", "sectioned", reg.glossary()), [], "glossary-clean")
        eq(G89.check_landing(land, entry, sheet), [], "G89 landing rules")
        eq(G89.scan_public(land, "landing"), [], "G89 value scan")
        tp = to_topic_page(land)
        eq(len(tp["sections"]), 3, "topic page sections")
        eq(len(tp["intro"]) >= 40 and tp["intro"] != tp["h1"], True, "site intro rule (≥ 40, ≠ h1)")
        sheet["landing"]["animation_anchor"] = "angles-adjacent"
        eq(landing_from(sheet, entry, reg)["animation"]["anchor"], "angles-adjacent", "animation_anchor override")
        # every registry definition either has no math or converts cleanly
        for _t, _p, e in reg.located():
            d = e.get("definition_he")
            if d and u"$" in d and plain_math(d) is None:
                fails.append(u"definition_plain is None for %s: %s" % (e["id"], d[:60]))
            bad = CB.glossary_lint([d or u""] + list(e.get("explain_he") or []) + [e.get("title") or u""],
                                   re.match(r"st\.g(\d+)", e["id"]).group(1), "sectioned", reg.glossary())
            if bad:
                fails.append(u"registry text of %s fails the glossary: %s" % (e["id"], bad[0][:2]))
    except Exception as ex:
        fails.append("landing from a registry-backed sheet: %r" % ex)
    try:
        landing_from(None, {})
        fails.append("legacy did not raise")
    except CB.LegacyPackageError:
        pass
    dt = time.time() - t0
    for f in fails:
        print(u"FAIL " + f)
    print("landing_build selftest: %d checks failed, %.2f s (registry: %s)" % (len(fails), dt, reg.source))
    return 1 if fails or dt > 30 else 0


if __name__ == "__main__":
    sys.exit(main())
