# -*- coding: utf-8 -*-
r"""shapekit — v6.3. rectkit's pattern, generalised: every base shape a
ז׳–ט׳ sheet needs, built FROM ITS DATA, plus one set of add-ons that works on
all of them.

WHY THIS FILE EXISTS
--------------------
`euclid.quad`, `euclid.triangle_with` and `euclid.circle_fig` each draw ONE
fixed vertex list per kind (see euclid.py's `V` dicts) because each of them
verifies its whole family from that one list. A sheet does not work that way:
question 3 wants a 15x6 rectangle, question 7 a 16x12 one, question 11 a
trapezoid whose bases are 9 and 4 with height 6, question 14 a 5-12-13
triangle. `rectkit.py` proved the way out for one shape — a PARAMETRIC figure
on `euclid._Fig` plus computed add-ons (`point_on`, `foot_to_line`,
`angle_mark`), one line per figure, its own selfcheck green. This file is that
pattern for every shape, so no sheet ever needs a package-local helper again.

    from shapekit import shape, diagonals, altitude, angle_arc, finish

    g, d = shape("trapezoid", variant="iso", a=9, b=4, h=6, rotate=0,
                 fam="quad.trapezoid.iso+altitude")
    altitude(g, d, "D", "A", "B", name="H")
    print(finish(g, "quad.trapezoid.iso+altitude"))

WHAT IT DOES NOT DO
-------------------
It does not touch `euclid.py`'s builders or `rectkit.py`. `euclid.quad(...)`,
`euclid.triangle_with(...)` and `rectkit.rect_base(...)` keep their exact
signatures and their exact output; `shape("rectangle", ...)` DELEGATES to
`rectkit.rect_base` rather than growing a second rectangle.

RULES (rectkit's own list, which came from euclid.py's doctrine)
---------------------------------------------------------------
1. The data fixes the drawing. `shape("triangle", kind="sss", a=3, b=4, c=5)`
   prints a 3:4:5 triangle, and selfcheck_v63 re-measures it from the finished
   SVG. Data that cannot be a figure is REFUSED with a message naming data
   that would work — never quietly repaired.
2. `rotate=` on every call; `fam=` required on every call (G76 keys on `fam`,
   so a rotated copy is ONE object, not two).
3. Every computed point is worked out in the PRE-ROTATION frame (`g.pts`), so
   the figure and its add-ons turn as one rigid body.
4. Latin letters and digits in the SVG; the Hebrew stays in the question text.
5. The house look and every existing check apply unchanged. Nothing here
   weakens a rule; the one engine change of v6.3 (the tick-vs-point solver in
   `euclid._Fig._tick_t`) makes a refused figure CORRECT instead.

A NOTE ON SOLIDS (v6.4)
-----------------------
Each add-on below takes point HANDLES, never "the shape", precisely so a
face of a solid — four handles in the same `_Fig` — can use the same
`diagonals`, `midpoint`, `altitude`, `angle_arc` calls later.
"""
import math
import re

import euclid
import rectkit
from euclid import _Fig
from rectkit import point_on, foot_to_line

__all__ = [
    # base shapes
    "shape", "finish", "SHAPES",
    # add-ons
    "diagonals", "midpoint", "point_at", "perp_foot", "altitude", "median",
    "bisector", "parallel_through", "extend", "incircle", "circumcircle",
    "angle_arc", "equal_ticks", "parallel_marks", "right_angle", "side_label",
    "segment", "point",
    # re-exported from rectkit so one import serves a whole page
    "point_on", "foot_to_line",
]

_LETTERS = "ABCDEFGHIJKL"
_SPAN = 2.4            # the long side of a base shape, in figure units
# how far a centre's letter is anchored from its own dot. A fraction of the
# RADIUS put the 'O' of a big circumcircle half a centimetre from the dot it
# names; a fixed figure-unit offset reads the same on every circle.
_CLABEL = 0.17


class ShapeError(AssertionError):
    """Data that cannot be the shape it claims. An AssertionError, so every
    existing `raises(...)` harness and euclid's own refusal contract still
    catch it."""


def _bad(where, said, fix):
    raise ShapeError("shapekit.%s: %s — %s" % (where, said, fix))


def _f(where, name, v, lo=0.0):
    try:
        x = float(v)
    except (TypeError, ValueError):
        _bad(where, "%s=%r is not a number" % (name, v),
             "give it as a number, e.g. %s=6" % name)
    if not x > lo:
        _bad(where, "%s=%s" % (name, _n(x)),
             "every length must be greater than %s" % _n(lo))
    return x


def _as_deg(text):
    """The number a mark's text states, or None when it states an unknown
    (x, 2x, a+3). The degree sign and a true minus are part of the number."""
    if text is None:
        return None
    t = str(text).strip().replace(u"\u2212", "-").replace(u"\u00b0", "")
    t = t.replace(" ", "").replace("cm", "").replace("mm", "")
    if not t:
        return None
    try:
        return float(t)
    except ValueError:
        return None


_LEN_UNITS = re.compile(r"(?:cm|mm|km|m)$")


def _as_length(text, g, d, a, b):
    """The length a side label STATES, or None when it states an unknown.

    v6.5 X2 r1 (SHOULD-10): `_as_deg` read only a bare number, so a wrong
    side label wrapped in anything ('BC=8', '(8)', '~8', "8'") on a side of
    7 exported no constraint and nothing refused it. The forms a sheet
    prints around a length are read here: the side's own name and '=', one
    pair of brackets, '~' / '≈', a unit, a trailing prime. A label that is
    algebra (x, 2a+3) states no number and is left alone; a label with a
    number this cannot read is REFUSED, so a wrong length can never pass by
    being decorated."""
    if text is None:
        return None
    raw = str(text)
    t = raw.strip().replace(u"\u2212", "-").replace(" ", "")
    if not re.search(r"\d", t):
        return None
    names = [k for k, v in d.items() if isinstance(k, str) and v in (a, b)
             and not k.startswith("_")] if isinstance(d, dict) else []
    m = re.match(r"^([A-Z][′']?)([A-Z][′']?)=(.*)$", t)
    if m:
        side = {m.group(1), m.group(2)}
        if names and not side <= set(names):
            _bad("side_label", "the label %r on side %s names side %s%s"
                 % (raw, "".join(sorted(names)), m.group(1), m.group(2)),
                 "a side label states ITS OWN side's length: label that "
                 "side, or write the number alone")
        t = m.group(3)
    t = t.replace(u"\u2248", "").replace("~", "")
    if t.startswith("(") and t.endswith(")"):
        t = t[1:-1]
    t = t.rstrip(u"'′\"″")
    t = _LEN_UNITS.sub("", t)
    t = t.replace(u"\u00b0", "")
    try:
        return float(t.replace(",", "."))
    except ValueError:
        pass
    if re.search(r"[a-z]", t):
        return None                   # algebra: 2x, a+3 -- no number stated
    _bad("side_label", "the label %r carries a number this cannot read as "
         "the side's length" % raw,
         "print the length alone ('8', '8 cm', 'BC=8', '(8)'), or an "
         "expression with its unknown ('2x+1'); a length the drawing cannot "
         "be checked against is not printed on a side")


def _n(x):
    """A number the way an author wrote it (6, not 6.0)."""
    x = float(x)
    return "%g" % x


def _need(where, data, keys, alts=()):
    miss = [k for k in keys if data.get(k) is None]
    if miss:
        alt = (" or " + " + ".join(alts)) if alts else ""
        _bad(where, "missing %s" % ", ".join(miss),
             "this shape is built from %s%s" % (" + ".join(keys), alt))


def _norm(pts):
    """Scale the vertex list so its longest dimension is _SPAN figure units
    and its centre is the origin. Uniform, so every proportion the data fixed
    survives; it only stops a 3-4-5 and a 300-400-500 triangle from being two
    different figures for the label solver."""
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    w, h = max(xs) - min(xs), max(ys) - min(ys)
    k = _SPAN / max(w, h, 1e-9)
    cx, cy = (max(xs) + min(xs)) / 2.0, (max(ys) + min(ys)) / 2.0
    return [((x - cx) * k, (y - cy) * k) for x, y in pts], k, (cx, cy)


def _ccw(pts):
    """Vertices anticlockwise in maths coordinates, so `A, B, C, D` always
    runs the same way round and an add-on that says 'the angle at B' means the
    interior one."""
    s = sum((pts[i][0] * pts[(i + 1) % len(pts)][1]
             - pts[(i + 1) % len(pts)][0] * pts[i][1])
            for i in range(len(pts)))
    return list(pts) if s >= 0 else list(reversed(pts))


def _d2(p, q):
    return (p[0] - q[0]) ** 2 + (p[1] - q[1]) ** 2


def _dist(p, q):
    return math.sqrt(_d2(p, q))


def _ang(p, v, q):
    """The angle p-v-q in degrees."""
    u1 = (p[0] - v[0], p[1] - v[1])
    u2 = (q[0] - v[0], q[1] - v[1])
    n = math.hypot(*u1) * math.hypot(*u2)
    if n <= 0:
        return 0.0
    c = max(-1.0, min(1.0, (u1[0] * u2[0] + u1[1] * u2[1]) / n))
    return math.degrees(math.acos(c))


# ===================================================== the base geometries ===
# Each returns (vertices, extra). Vertices are in ANY units and any position:
# _norm and _ccw put them on the page. Each verifies its own data first and
# refuses with a message that names data which WOULD work.

def _g_rectangle(D):
    w = _f("rectangle", "w", D.get("w", D.get("a")))
    h = _f("rectangle", "h", D.get("h", D.get("b")))
    return [(0, 0), (w, 0), (w, h), (0, h)], dict(w=w, h=h)


def _g_square(D):
    a = _f("square", "a", D.get("a", D.get("side", D.get("w"))))
    return [(0, 0), (a, 0), (a, a), (0, a)], dict(a=a)


def _g_parallelogram(D):
    _need("parallelogram", D, ["a", "b", "angle"])
    a = _f("parallelogram", "a", D["a"])
    b = _f("parallelogram", "b", D["b"])
    t = float(D["angle"])
    if not 1.0 < t < 179.0:
        _bad("parallelogram", "angle=%s" % _n(t),
             "the angle at A must be between 1 and 179; 60 or 115 read well")
    if abs(t - 90.0) < 0.5:
        _bad("parallelogram", "angle=%s makes four right angles" % _n(t),
             "that is a rectangle: call shape('rectangle', w=%s, h=%s), or "
             "move the angle off 90 (65, 110)" % (_n(a), _n(b)))
    if abs(a - b) < 1e-9:
        _bad("parallelogram", "a=b=%s makes four equal sides" % _n(a),
             "that is a rhombus: call shape('rhombus', a=%s, angle=%s)"
             % (_n(a), _n(t)))
    r = math.radians(t)
    D0 = (b * math.cos(r), b * math.sin(r))
    return [(0, 0), (a, 0), (a + D0[0], D0[1]), D0], dict(a=a, b=b, angle=t)


def _g_rhombus(D):
    if D.get("d1") is not None or D.get("d2") is not None:
        _need("rhombus", D, ["d1", "d2"], alts=("a", "angle"))
        d1 = _f("rhombus", "d1", D["d1"])
        d2 = _f("rhombus", "d2", D["d2"])
        if abs(d1 - d2) < 1e-9:
            _bad("rhombus", "d1=d2=%s makes four right angles" % _n(d1),
                 "that is a square: call shape('square', a=%s), or make the "
                 "diagonals differ (d1=%s, d2=%s)"
                 % (_n(d1 / math.sqrt(2)), _n(d1), _n(d1 * 0.6)))
        p, q = d1 / 2.0, d2 / 2.0
        a = math.hypot(p, q)
        ang = 2.0 * math.degrees(math.atan2(q, p))
    else:
        _need("rhombus", D, ["a", "angle"], alts=("d1", "d2"))
        a = _f("rhombus", "a", D["a"])
        ang = float(D["angle"])
        if not 1.0 < ang < 179.0:
            _bad("rhombus", "angle=%s" % _n(ang),
                 "the angle at A must be between 1 and 179; 60 or 110 read well")
        if abs(ang - 90.0) < 0.5:
            _bad("rhombus", "angle=%s makes four right angles" % _n(ang),
                 "that is a square: call shape('square', a=%s)" % _n(a))
        p = a * math.cos(math.radians(ang / 2.0))
        q = a * math.sin(math.radians(ang / 2.0))
        d1, d2 = 2 * p, 2 * q
    return [(-p, 0), (0, -q), (p, 0), (0, q)], dict(a=a, angle=ang, d1=d1, d2=d2)


def _g_trapezoid(D):
    var = D.get("variant", "iso")
    if var not in ("iso", "right", "scalene"):
        _bad("trapezoid", "variant=%r" % var,
             "variant is 'iso', 'right' or 'scalene'")
    _need("trapezoid.%s" % var, D, ["a", "b", "h"])
    a = _f("trapezoid", "a", D["a"])
    b = _f("trapezoid", "b", D["b"])
    h = _f("trapezoid", "h", D["h"])
    if abs(a - b) < 1e-9:
        _bad("trapezoid", "a=b=%s makes both pairs of sides parallel" % _n(a),
             "that is a parallelogram, and a sheet asking the student to "
             "prove AB is not equal to DC would be answered by the picture: "
             "make the bases differ (a=%s, b=%s)" % (_n(a), _n(a * 0.55)))
    # r1 (scalene-dx-suggestion-unsound, the related note): a=10, b=9 passed
    # the test above and PRINTED as a parallelogram -- the same defect the
    # a==b refusal exists to stop, one percent away from it. The bases have
    # to differ by enough for a reader to SEE which is which.
    if abs(a - b) < _BASE_SEP * max(a, b):
        _bad("trapezoid", "a=%s and b=%s differ by %.0f%% of the longer base"
             % (_n(a), _n(b), 100.0 * abs(a - b) / max(a, b)),
             "under %.0f%% the two bases print as one length and the figure "
             "reads as a parallelogram: try a=%s, b=%s"
             % (100.0 * _BASE_SEP, _n(max(a, b)), _n(round(0.6 * max(a, b), 2))))
    if var == "iso":
        dx = (a - b) / 2.0
    elif var == "right":
        dx = 0.0
    else:
        dx = D.get("dx")
        # half-way between the right trapezoid (dx=0) and the isosceles one
        # (dx=(a-b)/2): at 0.34*a the default came out within 4% of the
        # isosceles offset and the "scalene" figure printed as an isosceles
        # one, which is the class of defect this skill exists to stop.
        dx = ((a - b) / 4.0 if dx is None else float(dx))
        _scalene_ok(a, b, h, dx)
    if var == "iso" and b > a:
        # `a` is the LONGER base by convention, so AB is the one drawn along
        # the bottom whichever way round the author gave them
        a, b = b, a
        dx = (a - b) / 2.0
    return ([(0, 0), (a, 0), (dx + b, h), (dx, h)],
            dict(a=a, b=b, h=h, dx=dx, variant=var))


_BASE_SEP = 0.15        # the bases of a trapezoid differ by this much of the longer
_LEG_SEP = 0.05         # a scalene trapezoid's legs differ by this much
_RIGHT_SEP = 3.0        # ... and its base angles stand this far off 90 degrees


def _trap_legs(a, b, h, dx):
    """(leg AD, leg BC, angle at A, angle at B) for the trapezoid the data
    draws. Measured from the FIGURE, not from the parameter: what the reader
    sees is the two legs and the two base angles, so that is what the rule
    is written on."""
    ad = math.hypot(dx, h)
    bc = math.hypot(a - (dx + b), h)
    angA = math.degrees(math.atan2(h, dx)) if dx else 90.0
    angB = math.degrees(math.atan2(h, a - (dx + b))) if (a - (dx + b)) else 90.0
    return ad, bc, angA, angB


def _scalene_ok(a, b, h, dx):
    """r1 (scalene-dx-suggestion-unsound). The old rule tested the PARAMETER
    for exact equality with 0 or (a-b)/2 and then suggested dx=0.34*a -- a
    number that is not between them at all (for a=10, b=9 it suggested 3.4
    where the band is 0..0.5) and that, for a=12, b=4, came out 2% from the
    isosceles offset: the figure was accepted and its legs printed 1.55%
    apart, i.e. as an isosceles trapezoid. The rule is now written on what
    the figure SHOWS -- legs that differ, base angles that are not right --
    and the suggestion is a dx that passes it, found by search, so a message
    never sends the author back into the defect."""
    ad, bc, angA, angB = _trap_legs(a, b, h, dx)
    why = None
    if abs(ad - bc) < _LEG_SEP * max(ad, bc):
        why = ("its legs come out %s and %s (%.1f%% apart), which prints as "
               "the ISOSCELES one"
               % (_n(round(ad, 2)), _n(round(bc, 2)),
                  100.0 * abs(ad - bc) / max(ad, bc)))
    elif abs(angA - 90.0) < _RIGHT_SEP or abs(angB - 90.0) < _RIGHT_SEP:
        why = ("a base angle comes out %.1f°, which prints as the RIGHT one"
               % (angA if abs(angA - 90.0) < _RIGHT_SEP else angB))
    if why is None:
        return
    lo, hi = 0.0, (a - b) / 2.0
    if hi < lo:
        lo, hi = hi, lo
    best = None
    for k in range(1, 200):                      # the band, swept in 200ths
        t = lo + (hi - lo) * k / 200.0
        cand = round(t, 2)
        ad2, bc2, aA, aB = _trap_legs(a, b, h, cand)
        if abs(ad2 - bc2) >= _LEG_SEP * max(ad2, bc2) and \
                abs(aA - 90.0) >= _RIGHT_SEP and abs(aB - 90.0) >= _RIGHT_SEP:
            score = abs(cand - (lo + hi) / 2.0)
            if best is None or score < best[0]:
                best = (score, cand)
    fix = ("try dx=%s" % _n(best[1])) if best else (
        "no dx draws a scalene trapezoid on these bases — raise the height "
        "(h=%s) or widen the bases" % _n(round(0.9 * (a - b), 2)))
    _bad("trapezoid.scalene", "dx=%s" % _n(dx),
         "%s: pass variant='iso' or variant='right' if that is the figure "
         "you want, or a dx that draws a scalene one (%s)" % (why, fix))


def _g_kite(D):
    var = D.get("variant")
    if var not in (None, "right"):
        _bad("kite", "variant=%r" % var,
             "a kite takes no variant, or variant='right' (right angles at "
             "B and D, where the two pairs of sides meet)")
    if var == "right":
        # v6.6 S: the route the right-angle refusal names, implemented. A
        # kite with right angles at B and D is two right triangles on the
        # axis AC: the cross diagonal is twice the altitude to the
        # hypotenuse, q = 2ab / sqrt(a^2 + b^2) -- computed, never guessed.
        _need("kite.right", D, ["a", "b"])
        a = _f("kite", "a", D["a"])
        b = _f("kite", "b", D["b"])
        qr = 2.0 * a * b / math.hypot(a, b)
        if D.get("q") is not None and \
                abs(float(D["q"]) - qr) > 1e-6 * max(qr, 1.0):
            _bad("kite.right", "q=%s with a=%s, b=%s" % (_n(D["q"]), _n(a),
                                                         _n(b)),
                 "a right kite's cross diagonal is fixed by its sides: leave "
                 "q out (it is %s), or drop variant='right'"
                 % _n(round(qr, 4)))
        D = dict(D, q=qr)
    _need("kite", D, ["a", "b", "q"])
    a = _f("kite", "a", D["a"])
    b = _f("kite", "b", D["b"])
    q = _f("kite", "q", D["q"])
    if abs(a - b) < 1e-9:
        _bad("kite", "a=b=%s makes four equal sides" % _n(a),
             "that is a rhombus: call shape('rhombus', a=%s, angle=...), or "
             "make the pairs differ (a=%s, b=%s)" % (_n(a), _n(a), _n(a * 1.7)))
    if q >= 2 * min(a, b):
        _bad("kite", "q=%s with sides %s and %s" % (_n(q), _n(a), _n(b)),
             "the cross diagonal must be shorter than twice the SHORTER pair "
             "(under %s): try q=%s" % (_n(2 * min(a, b)), _n(1.2 * min(a, b))))
    m = math.sqrt(max(a * a - q * q / 4.0, 0.0))
    n = math.sqrt(max(b * b - q * q / 4.0, 0.0))
    ex = dict(a=a, b=b, q=q, p=m + n)
    if var == "right":
        ex["variant"] = "right"
    return ([(0, 0), (q / 2.0, m), (0, m + n), (-q / 2.0, m)], ex)


def _tri_sss(D):
    _need("triangle.sss", D, ["a", "b", "c"])
    a = _f("triangle.sss", "a", D["a"])      # BC
    b = _f("triangle.sss", "b", D["b"])      # CA
    c = _f("triangle.sss", "c", D["c"])      # AB
    s = sorted([a, b, c])
    if s[0] + s[1] <= s[2] * (1 + 1e-12):
        _bad("triangle.sss", "sides %s, %s, %s" % (_n(a), _n(b), _n(c)),
             "the two shorter sides must add to MORE than the longest "
             "(%s + %s = %s, which is not more than %s): try %s, %s, %s"
             % (_n(s[0]), _n(s[1]), _n(s[0] + s[1]), _n(s[2]),
                _n(s[0]), _n(s[1]), _n(0.9 * (s[0] + s[1]))))
    cosA = (b * b + c * c - a * a) / (2.0 * b * c)
    cosA = max(-1.0, min(1.0, cosA))
    A = math.acos(cosA)
    return [(0, 0), (c, 0), (b * math.cos(A), b * math.sin(A))], \
        dict(a=a, b=b, c=c)


def _tri_sas(D):
    _need("triangle.sas", D, ["b", "angle", "c"])
    b = _f("triangle.sas", "b", D["b"])
    c = _f("triangle.sas", "c", D["c"])
    t = float(D["angle"])
    if not 1.0 < t < 179.0:
        _bad("triangle.sas", "angle=%s" % _n(t),
             "the angle between the two given sides must be between 1 and 179")
    r = math.radians(t)
    return [(0, 0), (c, 0), (b * math.cos(r), b * math.sin(r))], \
        dict(b=b, c=c, angle=t)


def _tri_asa(D):
    _need("triangle.asa", D, ["A", "c", "B"])
    ta, tb = float(D["A"]), float(D["B"])
    c = _f("triangle.asa", "c", D["c"])
    if ta <= 0 or tb <= 0 or ta + tb >= 179.0:
        _bad("triangle.asa", "angles %s and %s" % (_n(ta), _n(tb)),
             "both must be positive and add to LESS than 180 (they add to "
             "%s): try A=%s, B=%s" % (_n(ta + tb), _n(50), _n(60)))
    ra, rb = math.radians(ta), math.radians(tb)
    # C is where the two rays meet
    x = c * math.tan(rb) / (math.tan(ra) + math.tan(rb))
    y = x * math.tan(ra)
    return [(0, 0), (c, 0), (x, y)], dict(A=ta, B=tb, c=c)


def _tri_right(D):
    """The right angle is at A. Data: two legs, or one leg + the hypotenuse,
    or one leg + an acute angle."""
    b, c, hyp = D.get("b"), D.get("c"), D.get("hyp")
    ang = D.get("angle")
    if b is not None and c is not None:
        b = _f("triangle.right", "b", b)
        c = _f("triangle.right", "c", c)
    elif hyp is not None and (b is not None or c is not None):
        hyp = _f("triangle.right", "hyp", hyp)
        leg = _f("triangle.right", "b" if b is not None else "c",
                 b if b is not None else c)
        if leg >= hyp:
            _bad("triangle.right", "leg %s with hyp=%s" % (_n(leg), _n(hyp)),
                 "the hypotenuse is the LONGEST side: give hyp greater than "
                 "%s (try hyp=%s)" % (_n(leg), _n(leg * 1.3)))
        other = math.sqrt(hyp * hyp - leg * leg)
        b, c = (leg, other) if b is not None else (other, leg)
    elif ang is not None and (b is not None or c is not None):
        t = float(ang)
        if not 1.0 < t < 89.0:
            _bad("triangle.right", "angle=%s" % _n(t),
                 "an acute angle of a right triangle is between 1 and 89 "
                 "(try 30, 37, 53)")
        leg = _f("triangle.right", "c" if c is not None else "b",
                 c if c is not None else b)
        if c is not None:
            c, b = leg, leg * math.tan(math.radians(t))
        else:
            b, c = leg, leg / math.tan(math.radians(t))
    else:
        _bad("triangle.right", "not enough data",
             "give the two legs (b=, c=), a leg and the hypotenuse "
             "(c=, hyp=), or a leg and an acute angle (c=, angle=)")
    return [(0, 0), (c, 0), (0, b)], dict(b=b, c=c, hyp=math.hypot(b, c))


def _tri_iso(D):
    """AC = BC: the apex is C. Data: leg + base, or base + the apex angle."""
    base = D.get("base", D.get("c"))
    leg = D.get("leg")
    apex = D.get("apex")
    if base is None:
        _bad("triangle.iso", "no base", "give base= plus leg= or apex=")
    base = _f("triangle.iso", "base", base)
    if leg is not None:
        leg = _f("triangle.iso", "leg", leg)
        if 2 * leg <= base * (1 + 1e-12):
            _bad("triangle.iso", "leg=%s with base=%s" % (_n(leg), _n(base)),
                 "the two legs must add to more than the base (%s is not "
                 "more than %s): try leg=%s"
                 % (_n(2 * leg), _n(base), _n(0.8 * base)))
        h = math.sqrt(leg * leg - base * base / 4.0)
    elif apex is not None:
        t = float(apex)
        if not 1.0 < t < 179.0:
            _bad("triangle.iso", "apex=%s" % _n(t),
                 "the apex angle is between 1 and 179 (try 40, 90, 120)")
        h = (base / 2.0) / math.tan(math.radians(t / 2.0))
        leg = math.hypot(base / 2.0, h)
    else:
        _bad("triangle.iso", "no leg and no apex angle",
             "give leg= (the two equal sides) or apex= (the angle at C)")
    return [(0, 0), (base, 0), (base / 2.0, h)], \
        dict(base=base, leg=leg, h=h)


def _tri_equilateral(D):
    a = _f("triangle.equilateral", "a", D.get("a", D.get("side")))
    return [(0, 0), (a, 0), (a / 2.0, a * math.sqrt(3.0) / 2.0)], dict(a=a)


_TRI = {"sss": _tri_sss, "sas": _tri_sas, "asa": _tri_asa, "right": _tri_right,
        "iso": _tri_iso, "equilateral": _tri_equilateral}


def _g_triangle(D):
    k = D.get("variant", "sss")
    if k not in _TRI:
        _bad("triangle", "variant=%r" % k,
             "variant is one of %s" % ", ".join(sorted(_TRI)))
    pts, extra = _TRI[k](D)
    a, b, c = _dist(pts[1], pts[2]), _dist(pts[0], pts[2]), _dist(pts[0], pts[1])
    angs = sorted([_ang(pts[1], pts[0], pts[2]), _ang(pts[0], pts[1], pts[2]),
                   _ang(pts[0], pts[2], pts[1])])
    if angs[0] < 6.0:
        _bad("triangle.%s" % k,
             "the smallest angle comes out %.1f°" % angs[0],
             "under 6° the triangle prints as a sliver and its vertex letters "
             "collide: move the data towards something rounder (the sides "
             "come out %s, %s, %s)" % (_n(round(a, 2)), _n(round(b, 2)),
                                       _n(round(c, 2))))
    extra.update(variant=k, sides=(a, b, c), angles=tuple(angs))
    return pts, extra


def _g_polygon(D):
    n = int(D.get("n", 5))
    if not 3 <= n <= 12:
        _bad("polygon", "n=%d" % n,
             "a regular polygon here has 3 to 12 sides (3, 5, 6 and 8 are "
             "the ones a ז׳-ט׳ sheet uses)")
    if D.get("R") is not None:
        R = _f("polygon", "R", D["R"])
        a = 2 * R * math.sin(math.pi / n)
    else:
        a = _f("polygon", "a", D.get("a", 1.0))
        R = a / (2.0 * math.sin(math.pi / n))
    # A at the bottom LEFT, B at the bottom right, and on round: the order a
    # Hebrew sheet's letters run once the figure is drawn (maths y-up turns
    # anticlockwise into the reader's clockwise). Started half a step the
    # other way, A came out at the bottom RIGHT and the letters ran backwards.
    th0 = -90.0 - 180.0 / n            # a horizontal side at the bottom
    pts = [(R * math.cos(math.radians(th0 + k * 360.0 / n)),
            R * math.sin(math.radians(th0 + k * 360.0 / n))) for k in range(n)]
    return pts, dict(n=n, a=a, R=R, r=a / (2.0 * math.tan(math.pi / n)))


def _g_circle(D):
    r = _f("circle", "r", D.get("r", D.get("R", 1.0)))
    return [], dict(r=r)


_GEOM = {"rectangle": _g_rectangle, "square": _g_square,
         "parallelogram": _g_parallelogram, "rhombus": _g_rhombus,
         "trapezoid": _g_trapezoid, "kite": _g_kite, "triangle": _g_triangle,
         "polygon": _g_polygon, "circle": _g_circle}

SHAPES = tuple(sorted(_GEOM))


# ================================================================ shape() ===
def shape(kind, rotate=0.0, fam=None, names=None, marks=True, size=None,
          width=None, given=None, **data):
    """A base shape built from its data, ready for add-ons.

    Returns `(g, d)`: `g` is the open `euclid._Fig` — call `finish(g, fam)`
    when every add-on for this question has been added. `d` carries the vertex
    handles by name (`d["A"]`), `d["V"]` (the handles in order), `d["names"]`,
    `d["kind"]`, `d["xy"]` (the pre-rotation coordinates by name) and whatever
    the geometry computed (`d["a"]`, `d["angle"]`, `d["R"]`, ...).

        shape("rectangle",     w=, h=)
        shape("square",        a=)
        shape("parallelogram", a=, b=, angle=)
        shape("rhombus",       d1=, d2=)          or (a=, angle=)
        shape("trapezoid",     variant="iso"|"right"|"scalene", a=, b=, h=[, dx=])
        shape("kite",          a=, b=, q=)
        shape("triangle",      variant="sss",  a=, b=, c=)
                               variant="sas",  b=, angle=, c=
                               variant="asa",  A=, c=, B=
                               variant="right", b=, c= | c=, hyp= | c=, angle=
                               variant="iso",  base=, leg= | base=, apex=
                               variant="equilateral", a=
        shape("polygon",       n=, a=)           or (n=, R=)
        shape("circle",        r=)

    `fam=` is REQUIRED (G76 keys on it, so a rotated copy of one configuration
    counts as ONE object). `marks=True` draws the equality ticks, parallel
    arrows and right angles the shape's own definition claims; v6.3's tick
    solver keeps them readable when a question puts its own points on a
    ticked side, so `marks=False` is a choice now, not a repair.
    """
    if kind not in _GEOM:
        _bad("shape", "kind=%r" % kind,
             "kind is one of %s" % ", ".join(SHAPES))
    if not fam:
        _bad("shape", "fam= is missing",
             "every figure declares its configuration, e.g. "
             "fam='quad.%s+diagonals' — G76 counts objects by it" % kind)
    if data.get("variant") is not None and \
            kind not in ("triangle", "trapezoid", "kite"):
        v = data.get("variant")
        route = {"parallelogram": "a parallelogram with a right angle IS a "
                                  "rectangle: shape('rectangle', w=, h=)",
                 "rhombus": "a rhombus with a right angle IS a square: "
                            "shape('square', a=)"}.get(
            kind, "leave variant= out")
        _bad("shape", "%s takes no variant= (got %r) -- it would be "
             "ignored, silently" % (kind, v), route)
    raw, extra = _GEOM[kind](data)

    # the rectangle is rectkit's, not a second one
    if kind in ("rectangle", "square"):
        w, h = (extra["w"], extra["h"]) if kind == "rectangle" \
            else (extra["a"], extra["a"])
        k = _SPAN / max(w, h)
        _du = (k, 0.0, 0.0)          # v6.5 r1 (X1-06), see below
        g, rd = rectkit.rect_base(w=w * k, h=h * k, rotate=rotate,
                                  names=(names or "ABCD"),
                                  diagonals=bool(data.get("diagonals")),
                                  width=width, marks=marks, fam=fam)
        g.data_units = _du
        if size is not None:
            g.size = size
        if kind == "square" and marks:
            # rect_base ticks opposite sides 1 and 2 (they are not equal on a
            # rectangle). On a square all four ARE equal, and four different
            # counts would be four different claims.
            g.ops = [(kd, kw) for kd, kw in g.ops if kd != "ticks"]
            V = [rd["A"], rd["B"], rd["C"], rd["D"]]
            for i in range(4):
                g.ticks(V[i], V[(i + 1) % 4], 1)
        _no_accidents(kind, extra,
                      [g.pts[rd[c]] for c in "ABCD"],
                      names or "ABCD", given)
        d = _pack(g, [rd["A"], rd["B"], rd["C"], rd["D"]],
                  names or "ABCD", kind, extra)
        d["O"] = rd["O"]
        return g, d

    g = _Fig(rotate, euclid._SIZE if size is None else size, width)
    if kind == "circle":
        r = extra["r"]
        # A CIRCLE HAS NO ORIENTATION, so `rotate=` must not change how it
        # prints -- let alone whether it prints at all. It did both: `_fit`
        # scales a figure by the bounding box of its POINTS, and the only
        # points here were the centre, ONE rim point and the letter's anchor.
        # `rotate=` swung that rim point round, so the box (and with it the
        # scale, the viewBox and the printed size) changed with the angle:
        # the viewBox ran 263.9 at 0 deg to 355.0 at 37 deg, and
        # shape("circle", r=7, width=130) was REFUSED at 17, 37, 45 and 112
        # deg ("label 'O' reaches the reader at 6.9pt") while it drew at 0,
        # 90, 180 and 270. The cure is to hand `_fit` the circle's real
        # bounding square: four corner points turned BACK by `rotate`, so
        # that after the figure turns they land on the axis-aligned square
        # every time. The letter's anchor is turned back for the same reason.
        # The corners are points, not ink -- nothing draws them.
        th = math.radians(rotate)
        co, si = math.cos(th), math.sin(th)

        def _back(x, y):
            return (x * co + y * si, -x * si + y * co)

        O = g.P((0.0, 0.0))
        rim = g.P((_SPAN / 2.0, 0.0))
        R = _SPAN / 2.0
        for sx, sy in ((1, 1), (1, -1), (-1, 1), (-1, -1)):
            g.P(_back(sx * R, sy * R))
        g.circle(O, rim)
        g.dot(O)
        g.mark(g.P(_back(-0.11 * _SPAN, -0.07 * _SPAN)), (names or "O")[0],
               prefer=(-co - si, si - co))
        d = dict(extra)
        d["data"] = dict(extra)
        g.data_units = ((_SPAN / 2.0) / r, 0.0, 0.0)
        d.update(V=[], names=(names or "O")[0], kind=kind, xy={}, O=O,
                 rim=rim, unit=(_SPAN / 2.0) / r)
        return g, d

    pts, k, ctr = _norm(_ccw(raw))
    # v6.5 r1 (X1-06): _norm is a similarity, and without its inverse the
    # export's `xy` was a scaled copy of the data whose scale appeared
    # nowhere -- |AB| read 2.042 for a triangle the sheet calls 5. The figure
    # hands the way back, so `xy` is the frame the QUESTION talks about and a
    # length constraint re-measured on it equals the printed number.
    g.data_units = (k, ctr[0], ctr[1])
    nm = names or _LETTERS[:len(pts)]
    if len(nm) < len(pts):
        _bad("shape", "names=%r is too short for %d vertices" % (nm, len(pts)),
             "give one letter per vertex, e.g. names=%r" % _LETTERS[:len(pts)])
    V = list(g.P(*pts))
    _no_accidents(kind, extra, [g.pts[i] for i in V], nm, given)
    g.poly(V)
    for i, name in zip(V, nm):
        g.name(i, name, poly=V)
    if marks:
        _house_marks(g, V, kind, extra)
    d = _pack(g, V, nm, kind, extra)
    d["unit"] = k
    return g, d


def _no_accidents(kind, extra, pts, nm, given=None):
    """Refuse a figure that hands the reader a datum it was never given.

    v6.4 T2-7/T2-9: the sweep used to live in `generate` and to run on
    TRIANGLES only, so `shape('triangle', variant='sss', a=13, b=12, c=5)`
    drew a 90.0 degree corner and said nothing (the student reads a right
    angle the data never gave -- the description layer REFUSES exactly that
    figure), and a parallelogram whose adjacent sides came out 0.4% apart
    was drawn as a visual rhombus while its own ticks claimed two different
    lengths. Every shape is swept now, on its own definition."""
    if kind == "circle":
        return
    eq, right = declared(kind, extra, len(pts))
    # `given=` is what the QUESTION declares in words but the base shape's
    # own kwargs cannot say -- the description layer builds every triangle
    # through variant='sss' and writes "משולש שווה שוקיים" in the sentence,
    # so the equality is given even though this call's data does not carry
    # it. {"equal": [[side, side], ...], "right": [vertex, ...]}.
    if given:
        eq = [list(g) for g in eq] + [list(g) for g in given.get("equal", ())]
        right = set(right) | set(given.get("right", ()))
    for row in accidents(pts, eq, right):
        if row[0] == "equal":
            _, i, j, li, lj = row
            _bad("shape", "sides %s%s and %s%s come out %.2f and %.2f -- "
                 "%.1f%% apart, which a reader measures as EQUAL"
                 % (nm[i], nm[(i + 1) % len(nm)], nm[j],
                    nm[(j + 1) % len(nm)], li, lj,
                    100.0 * abs(li - lj) / max(li, lj, 1e-9)),
                 "the drawing would give a datum the question never gave "
                 "(and the marks on it claim two different lengths): give "
                 "the two sides lengths more than %g%% apart, or build the "
                 "shape whose definition says they are equal (a rhombus, a "
                 "square, an isosceles or an equilateral triangle)"
                 % (100 * ACC_LEN))
        else:
            _, i, ang = row
            _bad("shape", "the angle at %s comes out %.1f deg, which a "
                 "reader reads as a RIGHT angle" % (nm[i], ang),
                 "an unmarked right angle is a datum the question never "
                 "gave: %s, or change the data so the corner is more than "
                 "%g deg off 90" % (_right_route(kind, extra, i, nm),
                                    ACC_DEG))


def _right_route(kind, extra, i, nm):
    """v6.6 S: the way to DECLARE a right angle that this shape really
    has. The shared message used to offer variant='right' on every shape;
    on a parallelogram or a rhombus the keyword was accepted and ignored and
    the same refusal came straight back (doctrine 4: a dead route)."""
    e = extra or {}
    if kind == "parallelogram":
        return ("a parallelogram with a right angle IS a rectangle: call "
                "shape('rectangle', w=%s, h=%s) if that is the figure"
                % (_n(e.get("a", 1)), _n(e.get("b", 1))))
    if kind == "rhombus":
        return ("a rhombus with a right angle IS a square: call "
                "shape('square', a=%s) if that is the figure"
                % _n(round(e.get("a", 1), 4)))
    if kind == "kite":
        if i in (1, 3):
            return ("declare it with shape('kite', variant='right', a=%s, "
                    "b=%s) -- right angles at %s and %s, q computed"
                    % (_n(e.get("a", 1)), _n(e.get("b", 1)), nm[1], nm[3]))
        return ("a kite's angle at %s is not a variant (variant='right' "
                "puts the right angles at %s and %s)" % (nm[i], nm[1], nm[3]))
    if kind == "trapezoid":
        return ("declare it with variant='right' (right angles at %s and "
                "%s) so the figure MARKS it" % (nm[0], nm[3]))
    if kind == "triangle":
        return ("declare it (variant='right' puts the right angle at %s; "
                "or a perpendicular in the description) so the figure "
                "MARKS it" % nm[0])
    return "declare it (a perpendicular in the description) so it is MARKED"


def _pack(g, V, nm, kind, extra):
    _kindname(g, kind)
    """`d`: the HANDLES first, the geometry's own values under them.

    r1 fix (asa-handles-clobbered): `extra` used to be merged LAST, so a
    geometry whose own key is a vertex letter overwrote the handle with a
    number -- variant="asa" is given A= and B= (the two angles), and every
    add-on that named A or B then died inside euclid with
    `TypeError: list indices must be integers or slices, not float`. A crash
    is not a refusal. The handle now wins, the value stays reachable under
    `d["data"]`, and `d["sides"]` is the list of handle pairs the API
    documents on EVERY shape (the triangle's side LENGTHS, which used to take
    that key, are `d["side_lengths"]` and `d["data"]["sides"]`)."""
    d = dict(extra)
    d["data"] = dict(extra)
    if "sides" in extra:
        d.setdefault("side_lengths", extra["sides"])
    d.update(V=list(V), names=str(nm[:len(V)]), kind=kind,
             xy=dict((n, g.pts[i]) for n, i in zip(nm, V)))
    d["sides"] = [(V[i], V[(i + 1) % len(V)]) for i in range(len(V))]
    for n, i in zip(nm, V):
        d[n] = i
    return d


ACC_LEN = 0.05           # two sides this close read as "equal" to a reader
ACC_DEG = 4.0            # ... and a corner this close to 90 reads as right


def declared(kind, extra, n):
    """What a shape's own DEFINITION gives the reader: (groups of side
    indices the definition makes equal, vertices whose right angle it
    gives). Side i runs from vertex i to vertex i+1. It is the definition,
    not the drawn marks: `marks=False` says the question will put it in
    words, and a datum said in words is still a datum given."""
    k = (extra or {}).get("variant")
    if kind in ("rectangle",):
        return [[0, 2], [1, 3]], set(range(4))
    if kind == "square":
        return [[0, 1, 2, 3]], set(range(4))
    if kind == "parallelogram":
        return [[0, 2], [1, 3]], set()
    if kind == "rhombus":
        return [[0, 1, 2, 3]], set()
    if kind == "kite":
        return [[0, 3], [1, 2]], (set([1, 3]) if k == "right" else set())
    if kind == "trapezoid":
        if k == "iso":
            return [[1, 3]], set()
        if k == "right":
            return [], set([0, 3])
        return [], set()
    if kind == "triangle":
        if k == "equilateral":
            return [[0, 1, 2]], set()
        if k == "iso":
            return [[1, 2]], set()
        if k == "right":
            return [], set([0])
        return [], set()
    if kind == "polygon":
        return [list(range(n))], (set(range(4)) if n == 4 else set())
    return [], set()


def accidents(pts, equal=(), right=(), close_len=ACC_LEN, close_deg=ACC_DEG):
    """What a reader would take from this drawing that its data never gave.

    `pts` are the vertices in order; `equal` the groups of side indices the
    data makes equal; `right` the vertices whose right angle it gives.
    Returns [("equal", i, j, Li, Lj), ...] for two sides that come out
    within `close_len` of each other without being declared equal, and
    [("right", i, angle), ...] for a corner that measures 90 without being
    declared. The reader is the same one for every shape -- v6.3's sweep ran
    on triangles only, so a parallelogram whose adjacent sides landed 0.4%
    apart was DRAWN as a rhombus and carried n=1 and n=2 ticks claiming two
    different lengths on two sides a reader measures as the same (S2-1), and
    a 13-12-5 'sss' triangle drew an unmarked right angle (D5)."""
    n = len(pts)
    if n < 3:
        return []
    grp = {}
    for k, g in enumerate(equal or ()):
        for i in g:
            grp[i] = k
    L = [_dist(pts[i], pts[(i + 1) % n]) for i in range(n)]
    out = []
    for i in range(n):
        for j in range(i + 1, n):
            if i in grp and grp.get(j) == grp[i]:
                continue                 # the data says they are equal
            if (i in grp) != (j in grp):
                # one side is marked and the other carries no claim at all:
                # the marks contradict nothing, and the reader is told
                # nothing false (an isosceles trapezoid whose top base comes
                # out as long as its legs is the everyday 12/6/5 trapezoid).
                continue
            if abs(L[i] - L[j]) <= close_len * max(L[i], L[j], 1e-9):
                out.append(("equal", i, j, L[i], L[j]))
    # ... except that the exemption above has one hole, and it is the loud
    # one (v6.4 T2 r1). When EVERY side comes out the same length, the
    # figure reads as a shape with a NAME -- equilateral, rhombus -- and a
    # half-declared pair no longer saves it: an isosceles triangle whose
    # base lands 2% from its legs is drawn equilateral from data that never
    # said so, which is exactly the reading error this sweep exists to stop.
    # The everyday 12/6/5 isosceles trapezoid is untouched, because its
    # sides are not all equal; the shapes that ARE all-equal by definition
    # (square, rhombus, regular polygon, equilateral triangle) declare the
    # whole group and never reach here.
    if not any(len(set(g)) >= n for g in (equal or ())):
        lo = min(range(n), key=lambda i: L[i])
        hi = max(range(n), key=lambda i: L[i])
        if hi == lo:
            hi = (lo + 1) % n      # every side the SAME length to the bit:
            #                        min and max land on one index, and the
            #                        pair a message names must be two sides
        if L[hi] - L[lo] <= close_len * max(L[hi], 1e-9) \
                and not any(r[0] == "equal" and set(r[1:3]) == {lo, hi}
                            for r in out):
            out.append(("equal", lo, hi, L[lo], L[hi]))
    for i in range(n):
        if i in set(right or ()):
            continue
        a, v, b = pts[(i - 1) % n], pts[i], pts[(i + 1) % n]
        ang = _angle_at(a, v, b)
        if abs(ang - 90.0) <= close_deg:
            out.append(("right", i, ang))
    return out


def _angle_at(a, v, b):
    ux, uy = a[0] - v[0], a[1] - v[1]
    wx, wy = b[0] - v[0], b[1] - v[1]
    nu = math.hypot(ux, uy) or 1.0
    nw = math.hypot(wx, wy) or 1.0
    c = max(-1.0, min(1.0, (ux * wx + uy * wy) / (nu * nw)))
    return math.degrees(math.acos(c))


def _house_marks(g, V, kind, extra):
    """The marks the shape's own DEFINITION claims — never a decoration. One
    tick count means one length, so a pair that is equal gets its own count
    and a pair that is not gets another."""
    n = len(V)
    if kind == "rhombus":
        for i in range(4):
            g.ticks(V[i], V[(i + 1) % 4], 1)
    elif kind == "parallelogram":
        g.ticks(V[0], V[1], 1)
        g.ticks(V[2], V[3], 1)
        g.ticks(V[1], V[2], 2)
        g.ticks(V[3], V[0], 2)
    elif kind == "kite":
        g.ticks(V[0], V[1], 1)
        g.ticks(V[3], V[0], 1)
        g.ticks(V[1], V[2], 2)
        g.ticks(V[2], V[3], 2)
        if extra.get("variant") == "right":
            g.right(V[1], V[0], V[2])
            g.right(V[3], V[2], V[0])
    elif kind == "trapezoid":
        # AB is parallel to DC and nothing else is: that is the definition,
        # and the chevrons are how the drawing says it.
        g.parallel(V[0], V[1], 1)
        g.parallel(V[3], V[2], 1)
        if extra.get("variant") == "iso":
            g.ticks(V[1], V[2], 1)
            g.ticks(V[3], V[0], 1)
        elif extra.get("variant") == "right":
            g.right(V[0], V[1], V[3])
            g.right(V[3], V[0], V[2])
    elif kind == "triangle":
        k = extra.get("variant")
        if k == "equilateral":
            for i in range(3):
                g.ticks(V[i], V[(i + 1) % 3], 1)
        elif k == "iso":
            g.ticks(V[0], V[2], 1)
            g.ticks(V[1], V[2], 1)
        elif k == "right":
            g.right(V[0], V[1], V[2])
    elif kind == "polygon":
        for i in range(n):
            g.ticks(V[i], V[(i + 1) % n], 1)


def finish(g, fam):
    """Render. Kept as a named call so a page reads `finish(g, fam)` and the
    `fam` a figure declares is impossible to forget."""
    return g.render(fam)


def _kindname(g, kind):
    """v6.5 X2: the figure's `kind` in the deliverable JSON, so a reader of
    sheet.json knows a triangle was built by shapekit and not guessed. The
    _Fig carries it until render, which is where the export is born."""
    g.kindname = "shapekit.%s" % kind


# ================================================================ add-ons ===
# Every one takes HANDLES (or vertex names), computes in the pre-rotation
# frame, and works on any shape — including, later, one face of a solid.

def _H(g, d, x):
    """A point handle from a handle, a vertex name, or a coordinate pair."""
    if isinstance(x, int):
        return x
    if isinstance(x, str):
        if x not in d:
            _bad("add-on", "no point named %r in this figure" % x,
                 "this figure has %s" % ", ".join(sorted(
                     k for k in d if isinstance(k, str) and len(k) == 1)))
        return d[x]
    return g.P((float(x[0]), float(x[1])))


def _xy(g, d, x):
    return g.pts[_H(g, d, x)]


def _unit(g, a, b):
    p, q = g.pts[a], g.pts[b]
    L = _dist(p, q)
    return ((q[0] - p[0]) / L, (q[1] - p[1]) / L), L


def _named_points(g, d):
    """Every point this figure has already NAMED, as (handle, text). The
    vertices carry their letter, an add-on's mark carries its own."""
    out = [(d[n], n) for n in d.get("names", "") if n in d]
    for kind, kw in g.ops:
        if kind == "mark" and kw.get("text"):
            out.append((kw["a"], kw["text"]))
    return out


def _free_name(g, d, name, who):
    """One letter, one point. r1 (found by LOOKING at the gallery): a decagon
    runs A..J, so `incircle(g, d, label="I")` put a second I in the figure --
    the centre and the vertex I -- and nothing caught it. A letter already in
    use is refused, naming the letters that are free."""
    if not name:
        return
    used = set(t for _h, t in _named_points(g, d))
    if str(name) in used:
        free = [c for c in "MNOPQRSTUVWXYZ" if c not in used][:4]
        _bad(who, "the letter %r already names a point in this figure"
             % str(name),
             "two points with one letter cannot be told apart: give this one "
             "another letter (%s %s free)"
             % (", ".join(free) or "no single letter is",
                "are" if free else ""))


def _free_tick_n(g, want):
    """r1 (midpoint-clashes-with-house-marks): a tick COUNT is a length, and
    the count a shape's own marks already use is that shape's side. midpoint()
    asked for two ticks on each half -- the very count rect_base and
    _house_marks put on a rectangle's, a parallelogram's and a kite's second
    pair of sides -- so the most basic add-on on the most basic shapes was
    always refused, by figkit's generic message. The halves get a count of
    their own instead, and only a figure that has used them all is refused."""
    used = set(kw["n"] for kind, kw in g.ops if kind == "ticks")
    if want not in used:
        return want
    for n in (1, 2, 3, 4):
        if n not in used:
            return n
    return None


def _parallel_dir(g, a, b):
    (ux, uy), _L = _unit(g, a, b)
    return (ux, uy) if (ux > 0 or (ux == 0 and uy > 0)) else (-ux, -uy)


def _free_parallel_n(g, a, b, want=None):
    """The CHEVRON count for a new parallel claim: (n, mark_the_reference).

    r1 (parallel-through-hardcodes-chevron-count-1): `parallel_through` drew
    one chevron always, and a trapezoid's house marks already use one for
    AB || DC -- so a parallel drawn through a point in any other direction
    was refused at every rotation ('parallel arrows n=1 say two segments are
    parallel, but they differ by 59.0 degrees'), and the only one-call way
    out deleted the claim. A count is a DIRECTION here exactly as a tick
    count is a length: a direction already marked keeps its own count (and
    the reference is not marked twice), a new direction takes a free one."""
    used = {}
    for kind, kw in g.ops:
        if kind == "parallel":
            used.setdefault(int(kw["n"]), []).append((kw["a"], kw["b"]))
    want_dir = _parallel_dir(g, a, b)
    if want is not None:
        # an explicit n= is the author's claim, honoured as written: if it
        # is the count another direction already uses, svgcheck refuses the
        # figure, which is the whole point of one count meaning one thing.
        marked = any(kind == "parallel" and {kw["a"], kw["b"]} == {a, b}
                     for kind, kw in g.ops)
        return int(want), not marked
    for n, rows in sorted(used.items()):
        same = all(abs(_parallel_dir(g, x, y)[0] - want_dir[0]) < 0.01 and
                   abs(_parallel_dir(g, x, y)[1] - want_dir[1]) < 0.01
                   for x, y in rows)
        if same:
            return n, False
    for n in (1, 2, 3, 4):
        if n not in used:
            return n, True
    return None, True


AUTO = "auto"            # "give this point any free letter"
_AUTO_ORDER = "DPQRSTUVWXYZMNO"


def _auto_name(g, d, name, who, first=None):
    """The letter a point gets. `name=AUTO` (the default of every add-on
    that names a point the question never names) takes the first FREE
    letter, the way `_free_tick_n` takes the first free tick count; an
    explicit letter is still refused when it is taken, because the author
    asked for that one.

    r1 (bisector-default-name-D-clashes-on-every-quad): the default was the
    fixed letter 'D', which is a VERTEX on every quadrilateral and on every
    polygon from n=4 up, so the documented one-liner
    `bisector(g, d, 'A', 'B', 'C')` was refused on 11 of the 16 shapes."""
    if name is not AUTO:
        _free_name(g, d, name, who)
        return name
    used = set(t for _h, t in _named_points(g, d))
    for c in ((first or "") + _AUTO_ORDER):
        if c not in used:
            d.setdefault("auto_names", []).append(c)
            return c
    _bad(who, "every letter is already a point in this figure",
         "name this one yourself with name='...' (two letters are fine, e.g. "
         "name='D1'), or drop a point the figure does not need")


def _drawn_between(g, d, a, b):
    """Is the segment a-b INK in this figure? A side of the shape, a
    diagonal that was asked for, or any line already drawn between the two
    handles. (A point placed on a segment nobody drew floats in mid-air.)"""
    for x, y in d.get("sides", ()):
        if (x, y) == (a, b) or (y, x) == (a, b):
            return True
    for kind, kw in g.ops:
        if kind == "line" and {kw.get("a"), kw.get("b")} == {a, b}:
            return True
        if kind == "poly":
            idx = list(kw.get("idx") or ())
            n = len(idx)
            for i in range(n):
                if {idx[i], idx[(i + 1) % n]} == {a, b}:
                    return True
    return False


def _ray_hits_outline(g, d, v, dx, dy):
    """(handle_a, handle_b, t, point) where the ray from handle `v` along
    (dx, dy) first leaves the shape's outline, or None. generate's
    `_bisector_side` does the same sum for the description layer; this is
    the same computation over the figure's own handles."""
    V = list(d.get("V") or ())
    n = len(V)
    if n < 3:
        return None
    vx, vy = g.pts[v]
    best = None
    for i in range(n):
        a, b = V[i], V[(i + 1) % n]
        if v in (a, b):
            continue
        ax, ay = g.pts[a]
        bx, by = g.pts[b]
        sx, sy = bx - ax, by - ay
        den = dx * sy - dy * sx
        if abs(den) < 1e-12:
            continue
        t = ((ax - vx) * sy - (ay - vy) * sx) / den        # along the ray
        u = ((ax - vx) * dy - (ay - vy) * dx) / den        # along the side
        if t <= 1e-9 or not -1e-9 <= u <= 1 + 1e-9:
            continue
        if best is None or t < best[0]:
            best = (t, a, b, u, (vx + dx * t, vy + dy * t))
    if best is None:
        return None
    return (best[1], best[2], best[3], best[4])


def _centre_point(g, d, I, label, dot, who, other):
    """The centre of a circle, as ONE dot carrying ONE letter.

    r1 (two-centres-one-dot): on a regular polygon the incircle and the
    circumcircle share a centre. Each call dropped its own dot at the same
    place and anchored its own letter off it with the same fixed offset, so
    two letters named one dot, 1.35 em apart -- and G78's reading-distance
    rule only NOTEs, so nothing caught it."""
    _free_name(g, d, label, who)
    C = None
    for kind, kw in g.ops:
        if kind == "dot" and _dist(g.pts[kw["a"]], I) < 1e-6:
            C = kw["a"]
            break
    if C is None:
        C = g.P(I)
        if dot:
            g.dot(C)
    elif label:
        # a second circle on the same centre is fine -- it is a second LETTER
        # on it that a reader cannot resolve
        for h, text in _named_points(g, d):
            if _dist(g.pts[h], I) < 0.35:
                _bad(who, "the centre is the point already called %r" % text,
                     "the %s and the %s of this %s share their centre: one "
                     "dot cannot carry two letters — label it once (%s(g, d, "
                     "label='%s') and %s(g, d) with no label), or draw the "
                     "second circle on a figure of its own"
                     % (who, other, d["kind"], other, text, who))
    if label:
        g.mark(g.P((I[0] - _CLABEL, I[1] - _CLABEL)), label, prefer=(-1, -1))
        d[label] = C
    return C


def diagonals(g, d, label="O", dash="4,3", w=1.2, dot=True):
    """The diagonals and, for a quadrilateral, their intersection.

    A quadrilateral gets AC and BD plus `O`; a regular polygon gets every
    diagonal and no labelled crossing (there are many). A triangle has none —
    refused, naming `median`, `altitude` and `bisector`."""
    V = d["V"]
    if d["kind"] == "circle":
        _bad("diagonals", "a circle has no vertices to join",
             "for the lines inside a circle use shape('circle', ...) with "
             "euclid.circle_fig's parts (radius, diameter, chord, tangent)")
    if len(V) < 4:
        _bad("diagonals", "a %s has no diagonals" % d["kind"],
             "the line inside a triangle is a cevian: use median(), "
             "altitude() or bisector()")
    if len(V) == 4:
        g.line(V[0], V[2], dash=dash, w=w)
        g.line(V[1], V[3], dash=dash, w=w)
        p, q = g.pts[V[0]], g.pts[V[2]]
        r, s = g.pts[V[1]], g.pts[V[3]]
        X = _seg_cross(p, q, r, s)
        if X is None:
            _bad("diagonals", "the diagonals of this %s do not cross inside it"
                 % d["kind"], "the vertex order must go round the shape — "
                 "shape() puts it anticlockwise; a custom point list has to "
                 "as well")
        O = g.P(X)
        if dot:
            g.dot(O)
        if label:
            g.mark(O, label, prefer=(0.45, -0.5))
            d[label] = O
        d["O"] = O
        return O
    n = len(V)
    for i in range(n):
        for j in range(i + 2, n):
            if (i, j) == (0, n - 1):
                continue
            g.line(V[i], V[j], dash=dash, w=w)
    return None


def _seg_cross(p, q, r, s):
    d1 = (q[0] - p[0], q[1] - p[1])
    d2 = (s[0] - r[0], s[1] - r[1])
    den = d1[0] * d2[1] - d1[1] * d2[0]
    if abs(den) < 1e-12:
        return None
    t = ((r[0] - p[0]) * d2[1] - (r[1] - p[1]) * d2[0]) / den
    u = ((r[0] - p[0]) * d1[1] - (r[1] - p[1]) * d1[0]) / den
    if not (-1e-9 <= t <= 1 + 1e-9 and -1e-9 <= u <= 1 + 1e-9):
        return None
    return (p[0] + t * d1[0], p[1] + t * d1[1])


def point_at(g, d, P, Q, t, name, prefer=None):
    """A point at ratio `t` along P->Q (rectkit.point_on, by name)."""
    if not 0.0 <= float(t) <= 1.0:
        _bad("point_at", "t=%s" % _n(t),
             "t runs 0 (at P) to 1 (at Q); 0.5 is the midpoint. To go BEYOND "
             "the segment use extend()")
    _free_name(g, d, name, "point_at")
    R = point_on(g, _H(g, d, P), _H(g, d, Q), float(t), name, prefer=prefer)
    d[name] = R
    return R


def midpoint(g, d, P, Q, name="M", ticks=True, prefer=None, n=None):
    """The midpoint, with the two ticks that SAY it is the midpoint.

    The tick COUNT is chosen so it is not one the shape's own marks already
    use (r1: two ticks are what a rectangle, a parallelogram and a kite put
    on their second pair of sides, so `midpoint(g, d, 'A', 'B', 'M')` on all
    three was always refused). Pass `n=` to fix it yourself, or `ticks=False`
    for a midpoint the question states in words."""
    a, b = _H(g, d, P), _H(g, d, Q)
    _free_name(g, d, name, "midpoint")
    M = point_on(g, a, b, 0.5, name, prefer=prefer)
    if ticks:
        k = int(n) if n else _free_tick_n(g, 2)
        if k is None:
            _bad("midpoint", "every tick count 1-4 is already in use here",
                 "the two halves need a count of their own (one count, one "
                 "length): give this one n=5, or say the midpoint in the "
                 "question and pass ticks=False")
        g.ticks(a, M, k)
        g.ticks(M, b, k)
    # v6.8 G7: the builder KNOWS M is the midpoint -- exported (and
    # re-measured) whether or not the ticks say it on paper
    g.constrain("midpoint", point=M, of=[a, b])
    d[name] = M
    return M


def perp_foot(g, d, P, A, B, name="H", draw=True):
    """The TRUE perpendicular foot of P on line AB (rectkit.foot_to_line),
    named. `draw=False` computes it without the segment and the right angle —
    for an intersection point a question needs but does not show."""
    a, b, p = _H(g, d, A), _H(g, d, B), _H(g, d, P)
    _free_name(g, d, name, "perp_foot")
    _foot_ok(g, d, "perp_foot", p, a, b, A, B)
    if draw:
        F = foot_to_line(g, p, a, b)
    else:
        (ux, uy), L = _unit(g, a, b)
        px, py = g.pts[p]
        ax, ay = g.pts[a]
        t = (px - ax) * ux + (py - ay) * uy
        F = g.P((ax + ux * t, ay + uy * t))
        g.dot(F)
    # v6.8 G7: the foot is on line AB, in this order along it
    g.constrain("collinear", points=[a, F, b] if 0.0 <= _t_on(g, F, a, b)
                <= 1.0 else ([F, a, b] if _t_on(g, F, a, b) < 0 else
                             [a, b, F]))
    if draw:
        g.constrain("perpendicular", of=[[p, F], [a, b]])
    if name:
        g.mark(F, name)
        d[name] = F
    return F


def _t_on(g, F, a, b):
    """Where F stands along a->b (0 at a, 1 at b)."""
    (ux, uy), L = _unit(g, a, b)
    return ((g.pts[F][0] - g.pts[a][0]) * ux +
            (g.pts[F][1] - g.pts[a][1]) * uy) / L


def _foot_escape(g, d, a, b, A, B):
    """A point whose perpendicular foot on AB really lands clear, found by
    TRYING them -- never a guess.

    r1 (perp-foot-refusal-names-an-escape-that-is-refused-again): the old
    message sent the author to "a point at a ratio along another side". On
    a rectangle or a square two of the three other sides are perpendicular
    to AB, so every point on them projects onto the same vertex and the
    escape was refused again, word for word (doctrine 4)."""
    names = d.get("names", "")
    V = list(d.get("V") or ())
    (ux, uy), L = _unit(g, a, b)
    ax, ay = g.pts[a]
    fixed = [g.pts[h] for h, _t in _named_points(g, d)]
    for i in range(len(V)):
        X, Y = V[i], V[(i + 1) % len(V)]
        if {X, Y} == {a, b}:
            continue
        for t in (0.4, 0.3, 0.6, 0.5):
            px = g.pts[X][0] + t * (g.pts[Y][0] - g.pts[X][0])
            py = g.pts[X][1] + t * (g.pts[Y][1] - g.pts[X][1])
            s_ = ((px - ax) * ux + (py - ay) * uy) / L
            F = (ax + ux * s_ * L, ay + uy * s_ * L)
            if not -0.25 < s_ < 1.25:
                continue
            if any(_dist(q, F) < 0.08 * L for q in fixed):
                continue
            used = set(tx for _h, tx in _named_points(g, d))
            free = ([c for c in _AUTO_ORDER if c not in used] or ["P1"])[0]
            return ("drop it from a point whose foot lands clear of the "
                    "corners -- point_at(g, d, %r, %r, %s, %r) then "
                    "perp_foot(g, d, %r, %r, %r) renders on this figure"
                    % (names[i % len(names)],
                       names[(i + 1) % len(names)], _n(t), free,
                       free, A, B))
    return ("on this shape every other side runs square to %s%s, so every "
            "point of it projects onto the same corner: put the point "
            "INSIDE the shape (point_at along a diagonal) or drop the "
            "perpendicular onto another side" % (A, B))


def _foot_ok(g, d, who, p, a, b, A, B):
    """r1 (perp-foot-no-degenerate-guard): altitude() refuses a foot at or
    outside a vertex; perp_foot() had no guard at all, so it dropped a named
    point exactly ON an existing one -- H on B, two letters 18px apart naming
    one place, with a right-angle mark on a zero-width wedge -- and whether
    that shipped depended on the rotation (refused at 0 and 90 by an
    unrelated rule, drawn at 17, 37 and 143)."""
    (ux, uy), L = _unit(g, a, b)
    ax, ay = g.pts[a]
    px, py = g.pts[p]
    t = ((px - ax) * ux + (py - ay) * uy) / L
    F = (ax + ux * t * L, ay + uy * t * L)
    for h, text in _named_points(g, d):
        if _dist(g.pts[h], F) < 0.06 * L:
            _bad(who, "the foot lands on %s, which is already the point %r"
                 % (text, text),
                 "two letters on one point, and the right angle would sit "
                 "on a wedge of no width: name the point you already have "
                 "instead of a new one, or %s"
                 % _foot_escape(g, d, a, b, A, B))
    if not -0.25 < t < 1.25:
        _bad(who, "the foot falls at %.2f of %s%s" % (t, A, B),
             "that far past the end of %s%s the perpendicular is drawn to "
             "nothing: extend the side first with extend(), or pick a point "
             "whose foot lands on it" % (A, B))


def altitude(g, d, apex, A, B, name="H", dash="4,3"):
    """The altitude from `apex` to side AB: the true foot, the right angle,
    and a refusal when the foot lands outside the side (where the drawing
    would contradict the word)."""
    a, b, p = _H(g, d, A), _H(g, d, B), _H(g, d, apex)
    _free_name(g, d, name, "altitude")
    (ux, uy), L = _unit(g, a, b)
    ax, ay = g.pts[a]
    px, py = g.pts[p]
    t = ((px - ax) * ux + (py - ay) * uy) / L
    if not 0.03 < t < 0.97:
        _bad("altitude", "the foot falls at %.2f of %s%s" % (t, A, B),
             "at or outside a vertex the drawing contradicts the word "
             "'altitude': drop it onto the side OPPOSITE the widest angle "
             "(on an obtuse triangle that is the longest side), or extend "
             "the side first with extend()")
    F = g.P((ax + ux * t * L, ay + uy * t * L))
    g.dot(F)
    g.line(p, F, dash=dash, w=1.2)
    g.right(F, a, p)
    # v6.8 G7: the foot lies on the side, between its ends
    g.constrain("on_segment", point=F, of=[a, b])
    g.constrain("perpendicular", of=[[p, F], [a, b]])
    if name:
        g.mark(F, name)
        d[name] = F
    return F


def median(g, d, apex, A, B, name="M", dash="4,3", ticks=True):
    """The median from `apex` to AB: it really lands on the midpoint, and the
    two ticks say so."""
    a, b, p = _H(g, d, A), _H(g, d, B), _H(g, d, apex)
    _free_name(g, d, name, "median")
    ax, ay = g.pts[a]
    bx, by = g.pts[b]
    M = g.P(((ax + bx) / 2.0, (ay + by) / 2.0))
    g.dot(M)
    g.line(p, M, dash=dash, w=1.2)
    # v6.8 G7: a median lands on the midpoint, ticks or not
    g.constrain("midpoint", point=M, of=[a, b])
    if ticks:
        k = _free_tick_n(g, 2)
        if k is None:
            _bad("median", "every tick count 1-4 is already in use here",
                 "the two halves of the side need a count of their own: pass "
                 "ticks=False and say in the question that AM = MB")
        g.ticks(a, M, k)
        g.ticks(M, b, k)
    if name:
        g.mark(M, name)
        d[name] = M
    return M


def _bisector_landing(g, d, v, a, b, named=True):
    """Where the bisector of a-v-b leaves the outline: a point, or a STRING
    saying what is wrong with it (so the caller can try another vertex
    before it writes a refusal -- doctrine 4: the way out a message names
    has to be a way out).

    `named=False` (the caller is not putting a letter there) accepts a
    landing ON a vertex and returns that vertex exactly: with no second
    letter to read, the bisector of a rhombus's angle is simply its
    diagonal, which is the escape the refusal below names."""
    (u1x, u1y), _ = _unit(g, v, a)
    (u2x, u2y), _ = _unit(g, v, b)
    dx, dy = u1x + u2x, u1y + u2y
    hit = None if abs(dx) + abs(dy) < 1e-9 else \
        _ray_hits_outline(g, d, v, dx, dy)
    if hit is None:
        return "it meets no side at all (the angle opens outwards)"
    ha, hb, u, D0 = hit
    if min(u, 1.0 - u) * _dist(g.pts[ha], g.pts[hb]) < 0.06 * \
            _dist(g.pts[v], D0):
        if not named:
            return g.pts[ha] if u < 0.5 else g.pts[hb]
        return "it lands on a VERTEX, where a second letter cannot be read"
    return D0


def _bisector_escape(g, d, V):
    """A route that renders, found by trying the others -- never a guess."""
    names = d.get("names", "")
    ok = []
    for i, n in enumerate(names):
        if n == V or n not in d:
            continue
        p = d[names[(i - 1) % len(names)]]
        q = d[names[(i + 1) % len(names)]]
        if not isinstance(_bisector_landing(g, d, d[n], p, q), str):
            ok.append("bisector(g, d, %r, %r, %r)"
                      % (n, names[(i - 1) % len(names)],
                         names[(i + 1) % len(names)]))
    if ok:
        return ("bisect an angle whose bisector crosses a side away from "
                "its ends -- %s renders on this figure. Or pass name=None "
                "to draw the bisector without a new letter (on a rhombus "
                "or a square it IS the diagonal)." % ok[0])
    return ("no vertex of this shape has a bisector that lands clear of a "
            "vertex: pass name=None to draw it without a new letter (on a "
            "rhombus or a square the bisector IS the diagonal), or draw "
            "the segment it should meet with a line of its own")


def bisector(g, d, V, A, B, name=AUTO, dash="4,3", arcs=True):
    """The bisector of the angle A-V-B, to where it really lands.

    On a TRIANGLE that is the side AB, at the ratio VA:VB the bisector
    theorem fixes, not by eye. On any other shape the two rays of a vertex
    end at its two NEIGHBOURS, so A-B is a DIAGONAL and it is not drawn:
    r1 (the rhombus on page 12 of the v6.3 showcase) shipped a named dot
    floating in mid-air inside the figure, on no stroke at all. When A-B is
    not ink, the bisector is carried on to the outline it really meets --
    the same landing `generate._bisector_side` computes for the description
    layer -- so the named point always stands on a line the reader can see.

    `name=` defaults to the first FREE letter (v6.3's default 'D' is a
    vertex on every quadrilateral, so the one-liner was refused on 11 of
    the 16 shapes); the letter used is returned in `d["auto_names"][-1]`."""
    v, a, b = _H(g, d, V), _H(g, d, A), _H(g, d, B)
    name = _auto_name(g, d, name, "bisector", first="D")
    va, vb = _dist(g.pts[v], g.pts[a]), _dist(g.pts[v], g.pts[b])
    t = va / (va + vb)
    ax, ay = g.pts[a]
    bx, by = g.pts[b]
    D0 = (ax + t * (bx - ax), ay + t * (by - ay))
    if not _drawn_between(g, d, a, b):
        land = _bisector_landing(g, d, v, a, b, named=bool(name))
        if isinstance(land, str):
            _bad("bisector", "%s%s is not drawn in this figure, so the "
                 "bisector of %s%s%s can only be carried on to the outline "
                 "-- and there %s" % (A, B, A, V, B, land),
                 _bisector_escape(g, d, V))
        D0 = land
    P = g.P(D0)
    g.dot(P)
    g.line(v, P, dash=dash, w=1.2)
    if arcs:
        g.arc(v, a, P, n=1)
        g.arc(v, P, b, n=1)
        # v6.6 E (V2-M1): the two equal arcs STATE the bisection, so the
        # JSON carries it as a marked equal_angle (a to_prove of it is
        # refused, exactly as for ticks); arcs=False draws no claim.
        g.constrain("equal_angle", of=[[v, a, P], [v, P, b]], marked=True)
    else:
        # v6.8 G7: an unmarked bisector is still a bisector -- exported,
        # not marked (it may be what the student proves)
        g.constrain("equal_angle", of=[[v, a, P], [v, P, b]])
    if name:
        g.mark(P, name)
        d[name] = P
    return P


def parallel_through(g, d, P, A, B, span=None, names=None, marks=True,
                     w=1.4, n=None):
    """A segment through `P` parallel to AB, marked with the chevrons that
    say so. Returns the two end handles.

    The chevron COUNT is free-chosen the way a tick count is (`n=` fixes it
    yourself): one count is one direction, so a shape whose own marks
    already use single chevrons -- every trapezoid -- gets double ones for
    the new direction, and a line drawn parallel to a direction the figure
    ALREADY marks joins that group instead of starting a second one."""
    p = _H(g, d, P)
    a, b = _H(g, d, A), _H(g, d, B)
    (ux, uy), L = _unit(g, a, b)
    half = (span if span is not None else L) / 2.0
    px, py = g.pts[p]
    E = g.P((px - ux * half, py - uy * half))
    F = g.P((px + ux * half, py + uy * half))
    g.line(E, F, w=w)
    # v6.8 r1 (G7-lines-not-exported): the drawn parallel is a LINE through
    # P (ln-), an object of its own; the parallel relation names it
    g.export_obj("line", [E, F],
                 name=("%s%s" % (names[0], names[1])) if names else None)
    if marks:
        k, mark_ref = _free_parallel_n(g, a, b, n)
        if k is None:
            _bad("parallel_through", "every chevron count 1-4 already marks "
                 "a direction in this figure",
                 "one count is one direction: give this pair a count of its "
                 "own with n=5, or pass marks=False and say in the question "
                 "that the segment is parallel to %s%s" % (A, B))
        g.parallel(E, F, k)
        if mark_ref:
            g.parallel(a, b, k)
    else:
        # v6.8 G7: drawn parallel, exported parallel (unmarked)
        g.constrain("parallel", of=[[E, F], [a, b]])
    if names:
        g.mark(E, names[0])
        g.mark(F, names[1])
        d[names[0]], d[names[1]] = E, F
    return E, F


def extend(g, d, A, B, by=0.35, name=None, dash=None, w=1.2):
    """Carry side A->B on past B by `by` (a fraction of AB). The extension a
    question needs when it drops an altitude onto an obtuse triangle's side,
    or names an exterior angle."""
    a, b = _H(g, d, A), _H(g, d, B)
    _free_name(g, d, name, "extend")
    (ux, uy), L = _unit(g, a, b)
    bx, by_ = g.pts[b]
    E = g.P((bx + ux * L * float(by), by_ + uy * L * float(by)))
    g.line(b, E, dash=dash, w=w)
    # v6.8 G7: the side and its extension are the RAY from A through B
    # (ray-AB), an object of its own, from A through B to where it is drawn
    if not dash:
        g.export_obj("ray", [a, E], name="%s%s" % (A, B))
    if name:
        g.mark(E, name, prefer=(ux, uy))
        d[name] = E
    return E


def _circle_at(g, C, r, dash=None, w=1.4):
    cx, cy = g.pts[C]
    rim = g.P((cx + r, cy))
    g.circle(C, rim, dash=dash, w=w)
    return rim


RING_GAP_PT = 2.5        # a circle and the outline it is drawn with must
#                          stand this many PRINTED pt apart at their widest
#                          (the vertex gap R - r). Two 1.1pt strokes this far
#                          apart leave white between them; under it they print
#                          as one thick wobbly ring.


def _ring_reads(g, d, who, R, r):
    """Refuse a circle that runs within a hair of the outline it is drawn
    with -- MEASURED IN PRINTED pt, once the figure has a printed size.

    r1 (D2_octagon_incircle_double_ring) read this as a RATIO: a regular
    polygon's inscribed circle stands r/R = cos(pi/n) of the way out, 0.92 at
    n=8, so every n >= 7 was refused at every size. That was wrong twice over.
    Doctrine 6: printed sizes are what matter, and the ratio is fixed while
    the printed gap is not -- the octagon's vertex gap is 4.6pt on the
    default 194px figure and 10.3pt at width=430, and both read plainly as a
    polygon with its inscribed circle. The codebase had already learnt this
    once: svgcheck.coincident_arcs_in's v6.2 fix replaced a figure-unit ring
    test with a printed one (ARC_SAME_R_PT). Doctrine 4: the cheapest escape
    the ratio message named ("draw the circle by itself") DELETED the polygon
    from the drawing, and a regular polygon inscribed in a circle is an
    everyday school figure.

    So: measure R - r in pt, refuse only under RING_GAP_PT, and name the
    route that keeps every line in the picture -- draw it BIGGER, at the
    width this very figure needs."""
    if R <= 0 or d.get("kind") != "polygon" or not hasattr(g, "defer"):
        return
    n = len(d["V"])
    gap = abs(R - r)

    def late(ptu, disp):
        got = gap * ptu
        if got >= RING_GAP_PT - 1e-9:
            return
        need = int(math.ceil(disp * RING_GAP_PT / max(got, 1e-9) / 5.0) * 5)
        _bad(who, "on a regular %d-gon this circle and the outline come "
             "within %.1fpt of each other at their widest (the vertex gap), "
             "under the %.1fpt floor" % (n, got, RING_GAP_PT),
             "two curves that close together print as one thick wobbly ring. "
             "The gap grows with the figure, so draw it bigger: this one "
             "renders at width=%d (it is %.0fpx now). Keep both lines — a "
             "regular polygon with its circle is the point of the question"
             % (need, disp))

    g.defer(late, who)


def incircle(g, d, label=None, dot=True, dash=None):
    """The inscribed circle — defined for a triangle and for a regular
    polygon, and for a rhombus or a square. Anything else is refused, naming
    the shapes that have one."""
    V = d["V"]
    kind = d["kind"]
    if kind == "triangle":
        A, B, C = [g.pts[i] for i in V]
        a, b, c = _dist(B, C), _dist(A, C), _dist(A, B)
        s = a + b + c
        I = ((a * A[0] + b * B[0] + c * C[0]) / s,
             (a * A[1] + b * B[1] + c * C[1]) / s)
        p = s / 2.0
        area = abs((B[0] - A[0]) * (C[1] - A[1]) - (C[0] - A[0]) * (B[1] - A[1])) / 2.0
        r = area / p
    elif kind in ("polygon", "rhombus", "square"):
        P = [g.pts[i] for i in V]
        I = (sum(x for x, _ in P) / len(P), sum(y for _, y in P) / len(P))
        r = min(_pt_line(I, P[i], P[(i + 1) % len(P)]) for i in range(len(P)))
    else:
        _bad("incircle", "a %s has no inscribed circle touching every side"
             % kind,
             "an inscribed circle is defined for a triangle, a regular "
             "polygon, a rhombus and a square — for a circle inside another "
             "shape, place it yourself with shape('circle', ...)")
    if d.get("kind") == "polygon":
        P = [g.pts[i] for i in V]
        _ring_reads(g, d, "incircle",
                    max(_dist(I, q) for q in P), r)
    C = _centre_point(g, d, I, label, dot, "incircle", "circumcircle")
    _circle_at(g, C, r, dash=dash)
    # v6.5 X2: an inscribed circle TOUCHES every side -- the fact a question
    # about it turns on, exported from the same centre and radius that drew
    # it and re-measured on the file.
    for i in range(len(V)):
        g.constrain("tangent", circle=C, to=[V[i], V[(i + 1) % len(V)]])
    d["incircle"] = (C, r)
    return C, r


def circumcircle(g, d, label=None, dot=True, dash=None):
    """The circle through every vertex — a triangle, a regular polygon, a
    rectangle or a square. Refused elsewhere (a general parallelogram, a
    scalene trapezoid and a kite have no such circle), naming what does."""
    V = d["V"]
    kind = d["kind"]
    P = [g.pts[i] for i in V]
    if kind == "triangle":
        (x1, y1), (x2, y2), (x3, y3) = P
        dd = 2.0 * (x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2))
        if abs(dd) < 1e-12:
            _bad("circumcircle", "the three points are in a straight line",
                 "a triangle with a positive area has one circumcircle")
        ux = ((x1 ** 2 + y1 ** 2) * (y2 - y3) + (x2 ** 2 + y2 ** 2) * (y3 - y1)
              + (x3 ** 2 + y3 ** 2) * (y1 - y2)) / dd
        uy = ((x1 ** 2 + y1 ** 2) * (x3 - x2) + (x2 ** 2 + y2 ** 2) * (x1 - x3)
              + (x3 ** 2 + y3 ** 2) * (x2 - x1)) / dd
        O = (ux, uy)
    elif kind in ("polygon", "rectangle", "square"):
        O = (sum(x for x, _ in P) / len(P), sum(y for _, y in P) / len(P))
    else:
        _bad("circumcircle", "a %s has no circle through all four vertices"
             % kind,
             "a circumcircle is defined for a triangle, a regular polygon, a "
             "rectangle and a square — a parallelogram, a rhombus, a kite and "
             "a scalene trapezoid are not cyclic")
    r = sum(_dist(O, p) for p in P) / len(P)
    if max(abs(_dist(O, p) - r) for p in P) > 1e-6 * max(r, 1.0):
        _bad("circumcircle", "the vertices of this %s are not all the same "
             "distance from one point" % kind,
             "only a cyclic figure has a circumcircle — try circumcircle on a "
             "triangle, a regular polygon, a rectangle or a square")
    if d.get("kind") == "polygon":
        _ring_reads(g, d, "circumcircle", r,
                    min(_pt_line(O, P[i], P[(i + 1) % len(P)])
                        for i in range(len(P))))
    C = _centre_point(g, d, O, label, dot, "circumcircle", "incircle")
    _circle_at(g, C, r, dash=dash)
    d["circumcircle"] = (C, r)
    return C, r


def _pt_line(p, a, b):
    L = _dist(a, b)
    return abs((p[0] - a[0]) * (b[1] - a[1]) - (p[1] - a[1]) * (b[0] - a[0])) / L


LEAD_SPAN = 14.0         # degrees: under this the number is CALLED OUT


def angle_arc(g, d, V, A, B, text=None, n=1, r=17, out=0.30, lead=None):
    """Arc the wedge A-V-B and, optionally, print its value.

    The number stands a little way INTO the wedge, on its own bisector — not
    on the vertex, where it would fight the vertex's letter. `text=None` arcs
    the wedge and says nothing (the 'x' a question asks for).

    v6.3 r1 (S2-3-doctrine4-escape-drops-information): a wedge too narrow to
    hold a number INSIDE it used to be refused, and the refusal's cheapest
    escape was '(לא בשרטוט)' — which deletes the arc AND the number, exactly
    the "easy escape is dropping information" doctrine 4 forbids. A narrow
    wedge is now CALLED OUT instead: the arc is drawn as always, and the
    number stands just OUTSIDE the wedge, beside the arc, with a short
    leader line tying it to the arc's outer edge. Nothing is dropped, and
    the number stays inside svgcheck's reach, so `_arcs` still measures the
    wedge it names (a wrong number is still refused). `lead=True/False`
    forces the choice; `None` calls out anything under `LEAD_SPAN`."""
    v, a, b = _H(g, d, V), _H(g, d, A), _H(g, d, B)
    g.arc(v, a, b, n=n)
    # v6.5 X2: an arc with a NUMBER on it states that angle, and the sheet's
    # JSON says so from the same data the wedge was drawn from. A text that
    # is not a number (x, 2x) is the unknown the question asks for and stays
    # unknown -- the rule v6.3 gave the angle-text check.
    _deg = _as_deg(text)
    if _deg is not None:
        g.constrain("angle", at=v, rays=[a, b], value=_deg, unit="deg",
                    marked=True)
    if text is None:
        return None
    vx, vy = g.pts[v]
    u1, _ = _unit(g, v, a)
    u2, _ = _unit(g, v, b)
    bx, by = u1[0] + u2[0], u1[1] + u2[1]
    nb = math.hypot(bx, by)
    if nb < 1e-9:
        bx, by, nb = -u1[1], u1[0], 1.0
    bx, by = bx / nb, by / nb
    span = _ang(g.pts[a], g.pts[v], g.pts[b])
    callout = (span < LEAD_SPAN) if lead is None else bool(lead)
    if not callout:
        rr = out * max(1.0, 0.9 / max(
            math.sin(math.radians(max(span, 8.0) / 2.0)), 0.12))
        T = g.P((vx + rr * bx, vy + rr * by))
        g.mark(T, text, prefer=(bx, by))
        return T
    # the callout: outside the wedge, on the side that faces away from the
    # rest of the figure, at the arc's own radius so the sweep still owns it
    ang = math.atan2(by, bx)
    step = math.radians(span / 2.0 + LEAD_OUT_DEG)
    cx, cy = _centroid(g, d)
    best = None
    for sgn in (1.0, -1.0):
        dx = math.cos(ang + sgn * step)
        dy = math.sin(ang + sgn * step)
        score = (vx + dx - cx) ** 2 + (vy + dy - cy) ** 2
        if best is None or score > best[0]:
            best = (score, dx, dy)
    _s, dx, dy = best
    rr = out * 1.30
    T = g.P((vx + rr * dx, vy + rr * dy))
    g.line(g.P((vx + rr * 0.62 * bx, vy + rr * 0.62 * by)), T, w=0.7)
    g.mark(T, text, prefer=(dx, dy))
    return T


LEAD_OUT_DEG = 20.0      # how far outside the wedge the callout stands


def _centroid(g, d):
    V = d.get("V") or []
    pts = [g.pts[h] for h in V] or g.pts[:1]
    return (sum(p[0] for p in pts) / len(pts),
            sum(p[1] for p in pts) / len(pts))


def equal_ticks(g, d, pairs, n=1):
    """Say "these segments are equal". `pairs` is a list of (P, Q). One count
    means one length: svgcheck re-measures every group of the same count from
    the finished SVG and refuses the figure if they differ."""
    out = []
    for P, Q in pairs:
        a, b = _H(g, d, P), _H(g, d, Q)
        g.ticks(a, b, n)
        out.append((a, b))
    return out


def parallel_marks(g, d, pairs, n=1):
    """Say "these segments are parallel", with chevrons. `pairs` is a list of
    (P, Q); svgcheck checks that every stroke of one count really is parallel
    to the others."""
    out = []
    for P, Q in pairs:
        a, b = _H(g, d, P), _H(g, d, Q)
        g.parallel(a, b, n)
        out.append((a, b))
    return out


def right_angle(g, d, V, A, B):
    """A right-angle mark at V. `figkit.Figure.right_angle` measures the angle
    itself and refuses anything off 90 by more than 0.5 degrees — so this
    never ships a square corner on a 53-degree vertex."""
    g.right(_H(g, d, V), _H(g, d, A), _H(g, d, B))


def side_label(g, d, A, B, text, out=0.22, t=0.5):
    """A length written beside side AB, outside the shape. Anchored off the
    side (never on it), so the label solver has somewhere to go and
    svgcheck's label_ownership reads it as this side's."""
    a, b = _H(g, d, A), _H(g, d, B)
    (ux, uy), L = _unit(g, a, b)
    ax, ay = g.pts[a]
    mx, my = ax + ux * L * t, ay + uy * L * t
    V = d.get("V") or []
    if V:
        P = [g.pts[i] for i in V]
        cx = sum(p[0] for p in P) / len(P)
        cy = sum(p[1] for p in P) / len(P)
    else:
        cx, cy = 0.0, 0.0
    nx, ny = -uy, ux
    if (mx - cx) * nx + (my - cy) * ny < 0:
        nx, ny = -nx, -ny
    T = g.P((mx + nx * out, my + ny * out))
    # v6.5 X2: the number beside a side IS that side's length. It is written
    # against the figure's own units (the shape was built from them), so the
    # re-measure on the finished SVG catches a label that names a length the
    # drawing does not have.
    _v = _as_length(text, g, d, a, b)
    if _v is not None:
        g.constrain("length", of=[a, b], value=_v, marked=True)
    g.mark(T, text, prefer=(nx, ny), owner=(a, b))
    return T


def segment(g, d, P, Q, w=1.2):
    """v6.7.1-noam (VE-R1): a plain segment between two points, by name.

    A bare `g.line()` in a level file draws the same stroke, but the
    sequence logger does not record it, so figures/<id>.py cannot re-draw
    the figure and verify_export refuses it (R1). This is that stroke,
    recorded. Solid only: a dashed helper line is not question data."""
    a, b = _H(g, d, P), _H(g, d, Q)
    g.line(a, b, w=w)
    return None


def point(g, d, name, xy, prefer=None):
    """v6.7.1-noam (VE-R1): a named point at figure coordinates `xy` (a
    point the question places by its own data, e.g. P inside a rectangle
    from two given angles), recorded like every other shapekit call."""
    _free_name(g, d, name, "point")
    R = g.P((float(xy[0]), float(xy[1])))
    g.dot(R)
    g.mark(R, name, prefer=prefer)
    d[name] = R
    return R


# v6.5 X2 r1 (MUST-3, spec rule 6): the author's call into this module
# is recorded as source, so figures/<id>.py can re-draw the figure.
import export as _export_rec  # noqa: E402
shape = _export_rec.seq(shape, start=True)
finish = _export_rec.seq(finish)
diagonals = _export_rec.seq(diagonals)
point_at = _export_rec.seq(point_at)
midpoint = _export_rec.seq(midpoint)
perp_foot = _export_rec.seq(perp_foot)
altitude = _export_rec.seq(altitude)
median = _export_rec.seq(median)
bisector = _export_rec.seq(bisector)
parallel_through = _export_rec.seq(parallel_through)
extend = _export_rec.seq(extend)
incircle = _export_rec.seq(incircle)
circumcircle = _export_rec.seq(circumcircle)
angle_arc = _export_rec.seq(angle_arc)
equal_ticks = _export_rec.seq(equal_ticks)
parallel_marks = _export_rec.seq(parallel_marks)
right_angle = _export_rec.seq(right_angle)
side_label = _export_rec.seq(side_label)
segment = _export_rec.seq(segment)
point = _export_rec.seq(point)
