# -*- coding: utf-8 -*-
r"""visual_model.py -- v6.7.1-noam (BRIEF_V671 §9): ONE general visual layer
for Noam AI.

Every drawing, graph, table, tree or diagram of a sheet gets a semantic
`visual_model` (schema "visual-model/v1") built HERE, at build time, from
what the engine recorded -- never from an LLM. Noam AI (or any model) may
only CHOOSE: show(component), highlight(ids of highlight_given), show_aux(aux
id). It never produces SVG, code or a free drawing; every state it can show
is pre-rendered by the engine from this model.

    kind            from REGISTRY (a new kind = a new REGISTRY row + its
                    validator in check_didactic.vm_faults)
    visual_support  "full"        engine SVG, every object addressable by id
                    "partial"     exact model, rendered, some parts not
                                  addressable (a curve with no id, a table
                                  drawn by the page)
                    "unsupported" NO figure, no approximate SVG: Noam AI
                                  explains in words or asks a sharper question
    objects         id, svg_id, type, maths (xy / xyz / value / cell / p ...),
                    svg_xy / bbox, role (given | to_prove | to_construct |
                    context | aux_step), display (initial | given_highlight |
                    aux_only)
    relations       typed (every export constraint + on_graph, row_sum,
                    col_sum, branch_sum, leaf_product, region_count,
                    bar_height, sector_angle ...), role, item, objects
    highlight_given relation ids the givens overlay may mark (role given)
    aux             approved aux figures as PATCHES: ops add / show /
                    highlight on this model, one step, reveal on_request
    actions         the closed list: show, highlight, show_aux

The validator is check_didactic.vm_faults (independent, stdlib only); deliver
calls it and refuses a model that fails.
"""
import math
import re

import didactic as DD

SCHEMA = "visual-model/v1"
SUPPORT = ("full", "partial", "unsupported")
ROLES = ("given", "to_prove", "to_construct", "context", "aux_step")
DISPLAY = ("initial", "given_highlight", "aux_only")
OPS = ("add", "show", "highlight")
ACTIONS = ("show", "highlight", "show_aux")

# kind -> (the best support the skill can give, what renders it)
REGISTRY = {
    "plane_geometry":   ("full", "figkit / shapekit / euclid"),
    "construction":     ("full", "figkit / shapekit / euclid + aux patches"),
    "coordinate_plane": ("full", "figkit_plus.plane"),
    "function_graph":   ("partial", "figkit_plus.plane(curves=) -- the curve "
                         "is one uncut path with no id"),
    "number_line":      ("full", "numberline"),
    "table":            ("partial", "the page's question table (cells, no "
                         "SVG ids)"),
    "solid_3d":         ("full", "solidkit"),
    # the front / top / side views of a solid (היטלים): no renderer yet --
    # solidkit draws the solid in cabinet projection, which is solid_3d
    "projection_2d":    ("unsupported", None),
    "net_2d":           ("full", "solidkit.net"),
    # schema + validator only: the skill has no exact renderer yet
    "probability_tree": ("unsupported", None),
    "sample_space":     ("unsupported", None),
    "outcome_table":    ("unsupported", None),
    "frequency_table":  ("unsupported", None),
    "venn":             ("unsupported", None),
    "bar_chart":        ("unsupported", None),
    "pie_chart":        ("unsupported", None),
    "line_chart":       ("unsupported", None),
}
# the maths each declared (content `visual=`) object of a kind carries
KIND_FIELDS = {
    "probability_tree": ("node: parent (id | null), label, p (branch "
                         "probability, '1/3' ok); a leaf may carry leaf_p"),
    "sample_space": "outcome: value; data: size, stages (optional)",
    "outcome_table": "cell: row, col, value; data: rows, cols",
    "frequency_table": "category: label, frequency, relative (optional); "
                       "data: total",
    "venn": "set: label, total; region: in (set ids), count; data: universe",
    "bar_chart": "bar: label, value, height_px; data: scale (px per unit)",
    "pie_chart": "sector: label, value, angle",
    "line_chart": "point: xy, svg_xy; view: data_to_svg",
    "table": "cell: row, col, value; relations row_sum / col_sum",
    "projection_2d": ("view: name (front | top | side), cells [[a, b], ...] "
                      "(unit squares seen) or points {name: [a, b]}; data: "
                      "cubes [[x, y, z], ...] or vertices {name: [x, y, z]}"
                      " -- front = (x, z), top = (x, y), side = (y, z)"),
    "function_graph": "curve: expr (x only, + - * / ** ( )); point: xy; "
                      "relation on_graph {point, curve}",
}
_OBJ_KEEP = ("name", "letter", "text", "xy", "xyz", "svg_xy", "r", "n",
             "for", "series", "legend", "marker", "row")
_REL_KEEP = ("points", "point", "of", "t", "at", "rays", "value", "unit",
             "circle", "to", "space", "text", "from_item",
             # v6.7.2-noam: a find target (its value never reaches here)
             "quantity", "what", "curve", "x")


class VMError(ValueError):
    """A model the engine cannot state exactly: deliver refuses it."""


# v6.13 fix_r1 (C1/C2): an engine (wspec) figure of a FAMILY engine -- the
# coordinate-plane or number-line renderer -- is that family, whatever its
# entry kind ('wspec') says. deliver passes the spec frame's family; without
# it a spec plane was published as 'construction' / 'plane_geometry', so the
# read-off data frame was never withheld (noam-ai.json gave the answers).
ENGINE_FAMILIES = ("coordinate_plane", "number_line",
                   # (v6.16 integrate) the graph and pie engines: every
                   # object drawn with ids (wspec_fam616.vm_layer: "full")
                   "function_graph", "pie_chart")


def classify(entry, svg="", has_construct=False, family=None):
    """The registry kind of one recorded figure entry (None = no model)."""
    if family in ENGINE_FAMILIES:
        return family
    k = str(entry.get("kind") or "")
    if k == "unrecorded" or not entry.get("objects") and \
            not entry.get("constraints") and k in ("", "unrecorded"):
        return None
    if k.startswith("numberline"):
        return "number_line"
    if k == "plane":
        if re.search(r'<path(?![^>]*\sid=)[^>]*\sd="M[^"]*C[^"]*"', svg or ""):
            return "function_graph"
        return "coordinate_plane"
    if k.startswith("solidkit.net"):
        return "net_2d"
    if k.startswith("solidkit"):
        return "solid_3d"
    return "construction" if has_construct else "plane_geometry"


# (v6.16 integrate, fix round 2) a relation id of a v6.16 family figure
# carries NO digit: the house slug keeps the digits of a statement's text
# ('הגזרה A: 40%' -> r-statement-A40) and numbers a repeat (-2, -3), and a
# number in any public string of noam-ai.json may be an answer of the sheet
# (pie pilot G8-T30 b q2: the count of C is 40). Letters only, and a repeat
# takes a letter suffix (-b, -c, ...). House figures keep their ids.
DIGITLESS_ID_KINDS = ("function_graph", "pie_chart")


def _slug(c, kind=None):
    t = c.get("type") or "statement"
    parts = DD.names_in(c) if isinstance(c, dict) else []
    v = c.get("value") if isinstance(c, dict) else None
    if kind in DIGITLESS_ID_KINDS:
        v = None
    s = "-".join([t] + parts + ([str(v)] if v is not None else []))
    if t == "statement" or not parts:
        s += "-" + re.sub(r"[^A-Za-z0-9]+", "", str(c.get("text") or ""))[:12]
    s = re.sub(r"[^A-Za-z0-9_\-]+", "_", s)
    if kind in DIGITLESS_ID_KINDS:
        s = re.sub(r"[0-9]+", "", s)
        s = re.sub(r"[_\-]{2,}", "-", s)
    return "r-" + s.strip("_-")


def _repeat_suffix(n, kind=None):
    """the id suffix of the n-th repeat (n >= 2) of one slug"""
    if kind not in DIGITLESS_ID_KINDS:
        return "-%d" % n
    out, k = "", n - 1
    while True:
        out = chr(ord("a") + k % 26) + out
        k = k // 26 - 1
        if k < 0:
            return "-" + out


def _obj(o, bucket, display, kind):
    sid = o.get("svg_id")
    d = {"id": sid, "svg_id": sid, "type": o.get("kind") or bucket[:-1],
         "part": o.get("role")}
    for k in _OBJ_KEEP:
        if o.get(k) is not None:
            d[k] = o[k]
    if o.get("ink_box"):
        d["bbox"] = o["ink_box"]
    if kind == "number_line" and d["type"] == "point" and \
            isinstance(o.get("xy"), list) and o["xy"]:
        d["value"] = o["xy"][0]
    d["display"] = display
    return d


def _resolve(entry, c):
    """object ids a claim dict names in this figure (points, segments)."""
    by_id, by_name, _p = DD._obj_index(entry)
    out = []
    for p in DD.names_in(c):
        o = by_name.get(("points", p))
        if o and o.get("svg_id"):
            out.append(o["svg_id"])
    of = c.get("of")
    segs = of if isinstance(of, list) else ([of] if of else [])
    for s in segs:
        if len(DD.toks(s)) == 2:
            o = DD.seg_obj(entry, s)
            if o and o.get("svg_id"):
                out.append(o["svg_id"])
    seen = set()
    return [x for x in out if not (x in seen or seen.add(x))]


def _rel(c, role, item, entry):
    r = {"type": c.get("type") or "statement", "role": role}
    if DD.is_find(c):
        c = DD.find_public(c)
    for k in _REL_KEEP:
        if c.get(k) is not None:
            r[k] = c[k]
    if r["type"] == "equal_angle" and isinstance(r.get("of"), list):
        # (v6.10 fix r1, S3) the model names an angle 'DAP' (the vertex
        # between, as every claim row does); a figure constraint in the
        # engine's {at, rays} form (wspec_build._constraints) that no claim
        # row of this figure matches -- an earlier item's to_prove measured
        # on a later item's figure -- is written the same way, never as a
        # dict whose letters V1 would read as points A', D', ...
        r["of"] = [(x["rays"][0] + x["at"] + x["rays"][1])
                   if isinstance(x, dict) and len(x.get("rays") or []) == 2
                   and x.get("at") else x for x in r["of"]]
    if item:
        r["item"] = item
    if entry is not None:
        r["objects"] = _resolve(entry, c)
    return r


def _role_of_marks(entry, rels):
    """svg id of a mark -> the role of the relation it marks."""
    out = {}
    for r in rels:
        for m in [r.get("mark_id")] + list(r.get("mark_ids") or []):
            if m:
                out[m] = r["role"]
    return out


def from_figure(entry, svg, rows, aux=(), has_construct=False,
                family=None):
    """The visual_model of one starting figure.

    entry  the sheet figure entry (objects, constraints, view, kind)
    rows   [(row id, is_item, {'given': [...], 'to_prove': [...],
            'to_construct': [...]})] -- the question row and the item rows
           this figure serves (claim dicts)
    aux    [(aux entry, aux spec)] -- aux figures of this figure's rows
    """
    kind = classify(entry, svg, has_construct, family)
    fid = entry["id"]
    if kind is None:
        return unsupported(fid, entry.get("question"), entry.get("item"),
                           "plane_geometry", "an unrecorded figure: the "
                           "engine holds no model of it")
    view = dict((k, v) for k, v in (entry.get("view") or {}).items()
                if k in ("viewbox", "data_to_svg", "data_unit_px", "frame",
                         "sketch", "rotate"))
    # relations: every declared claim, then every recorded constraint
    rels, by_key = [], {}
    for rid, is_item, cl in rows:
        for role in ("given", "to_prove", "to_construct"):
            for c in cl.get(role) or []:
                if not isinstance(c, dict):
                    c = {"text": str(c)}
                r = _rel(c, role, rid if is_item else None, entry)
                k = (DD.canon(c), role)
                if k in by_key:
                    continue
                by_key[k] = r
                rels.append(r)
    for fc in entry.get("constraints") or []:
        k0 = DD.canon(fc)
        hit = None
        for role in ("given", "to_prove", "to_construct"):
            hit = hit or by_key.get((k0, role))
        if hit is None:
            src = fc.get("source")
            role = src if src in ("given", "to_prove") else "context"
            hit = _rel(fc, role, fc.get("item"), entry)
            by_key[(k0, role)] = hit
            rels.append(hit)
        hit["measured"] = True
        if fc.get("marked"):
            hit["marked"] = True
        for k in ("mark_id", "mark_ids", "violated"):
            if fc.get(k):
                hit[k] = fc[k]
    used, taken = {}, set()
    for r in rels:
        base = _slug(r, kind)
        n = used.get(base, 0)
        rid = base if n == 0 else base + _repeat_suffix(n + 1, kind)
        while kind in DIGITLESS_ID_KINDS and rid in taken:
            n += 1
            rid = base + _repeat_suffix(n + 1, kind)
        used[base] = n + 1
        taken.add(rid)
        r["id"] = rid
    # objects
    mrole = _role_of_marks(entry, rels)
    gids = set(x for r in rels if r["role"] == "given"
               for x in r.get("objects") or [])
    objs = []
    for b, lst in (entry.get("objects") or {}).items():
        for o in lst or []:
            if not o.get("svg_id"):
                continue
            d = _obj(o, b, "initial", kind)
            sid = d["id"]
            if sid in mrole:
                d["role"] = mrole[sid]
            elif sid in gids:
                d["role"] = "given"
            else:
                d["role"] = "context"
            objs.append(d)
    # the givens overlay (§4): drawn by the page on the SVG, never printed
    hl = []
    gm_rows = [(c, rid if is_item else None) for rid, is_item, cl in rows
               for c in cl.get("given") or [] if isinstance(c, dict) and
               not c.get("from_item") and not c.get("no_overlay")]   # a carried result is no datum of
    # the figure: the overlay serves every item, the earlier one included
    hl_ids = set()
    for gm in DD.given_marks(entry, gm_rows):
        k = (DD.canon(gm["claim"]), "given")
        r = by_key.get(k)
        if r is None:
            continue
        oid = "hl-" + r["id"][2:]
        if oid in hl_ids:
            # (v6.10 fix r1) one given stated by an item and CARRIED into
            # later items (author.carried_given) is one relation: its mark
            # is one overlay, not one per row
            continue
        hl_ids.add(oid)
        ov = {"id": oid, "svg_id": None, "type": "overlay_mark",
              "mark": gm["mark"], "on": list(gm["svg_ids"]), "for": r["id"],
              "role": "given", "display": "given_highlight"}
        for k2 in ("n", "value"):
            if gm.get(k2) is not None:
                ov[k2] = gm[k2]
        objs.append(ov)
        r["highlight"] = oid
        hl.append(r["id"])
    vm = {"schema_version": SCHEMA, "id": fid, "kind": kind,
          "visual_support": REGISTRY[kind][0], "question":
          entry.get("question"), "svg": entry.get("svg"), "view": view,
          "objects": objs, "relations": rels, "highlight_given": hl,
          "aux": []}
    if entry.get("item"):
        vm["item"] = entry["item"]
    for a_entry, spec in aux or ():
        vm["aux"].append(aux_patch(vm, a_entry, spec, rows))
    vm["actions"] = actions(vm)
    return vm


def actions(vm):
    if vm.get("visual_support") == "unsupported":
        return {"allowed": list(ACTIONS), "show": [], "highlight": [],
                "show_aux": []}
    return {"allowed": list(ACTIONS), "show": [vm["id"]],
            "highlight": list(vm.get("highlight_given") or []),
            "show_aux": [a["id"] for a in vm.get("aux") or []]}


def _close(p, q, tol=1e-3):
    if not isinstance(p, list) or not isinstance(q, list) or \
            len(p) != len(q):
        return True
    if p and isinstance(p[0], list):
        return all(_close(a, b, tol) for a, b in zip(p, q))
    try:
        return all(abs(float(a) - float(b)) <= tol * max(1.0, abs(float(a)))
                   for a, b in zip(p, q))
    except (TypeError, ValueError):
        return True


_ENGINE_SID = re.compile(r"^e\d{4}$")


def _pts2(v):
    """[(x, y), ...] of an svg_xy ([x, y] or [[x, y], ...])."""
    if not isinstance(v, list) or not v:
        return []
    if isinstance(v[0], list):
        return [(float(p[0]), float(p[1])) for p in v
                if isinstance(p, list) and len(p) >= 2]
    return [(float(v[0]), float(v[1]))] if len(v) >= 2 else []


def _obj_key(o):
    """(type, name key) of a drawn object, or None: a point / an arc / a
    right-angle mark / a label by its name, a segment by its two ends."""
    t, nm = o.get("type"), o.get("name")
    if not nm:
        return None
    if t == "segment":
        tk = DD.toks(nm)
        return (t, frozenset(tk)) if len(tk) == 2 else None
    if t in ("point", "arc", "right_angle", "label", "ticks"):
        return (t, str(nm))
    return None


def engine_aux_match(vm, a_entry, tol_frac=0.03):
    """(v6.10 integrate) {aux svg id: model object id} when `vm` is an ENGINE
    figure (wspec element ids e0001...) and the aux figure is a recording
    builder's (its own ids: pt-A, seg-AB ...). The two frames differ, so an
    object of the aux is the model's own when it has its type and name (or,
    unnamed, its type and place) and sits where the model's does after the
    similarity that carries the aux's named points onto the model's (a
    mark or a label: its type and name alone, one of them in the model). The
    aux must BE the starting figure plus its step: if its named points do
    not fit the model's (3% of the figure's size), VMError. {} for a
    builder base (ids shared) or fewer than two named points in common."""
    sids = [o.get("svg_id") for o in vm["objects"] if o.get("svg_id")]
    if not sids or not all(_ENGINE_SID.match(str(x)) for x in sids):
        return {}
    aux = [(b, o) for b, lst in (a_entry.get("objects") or {}).items()
           for o in lst or [] if o.get("svg_id")]
    if any(o["svg_id"] in sids for _b, o in aux):
        return {}

    def typ(b, o):
        return o.get("kind") or b[:-1]
    bpt = dict((o.get("name"), _pts2(o.get("svg_xy"))[0]) for o in
               vm["objects"] if o.get("type") == "point" and o.get("name")
               and _pts2(o.get("svg_xy")))
    apt = dict((o.get("name"), _pts2(o.get("svg_xy"))[0]) for b, o in aux
               if typ(b, o) == "point" and o.get("name") and
               _pts2(o.get("svg_xy")))
    common = sorted(set(bpt) & set(apt))
    if len(common) < 2:
        return {}
    # least-squares similarity z_base = a * z_aux + c (complex a, c)
    za = [complex(*apt[n]) for n in common]
    zb = [complex(*bpt[n]) for n in common]
    ma, mb = sum(za) / len(za), sum(zb) / len(zb)
    den = sum(abs(z - ma) ** 2 for z in za)
    if den <= 0:
        return {}
    a = sum((w - mb) * (z - ma).conjugate() for z, w in zip(za, zb)) / den
    c = mb - a * ma

    def to_base(p):
        z = a * complex(*p) + c
        return (z.real, z.imag)
    xs = [p[0] for p in bpt.values()]
    ys = [p[1] for p in bpt.values()]
    tol = max(2.0, tol_frac * max(max(xs) - min(xs), max(ys) - min(ys)))
    worst = max(abs(a * z + c - w) for z, w in zip(za, zb))
    if worst > tol:
        raise VMError(
            "aux figure %s is not the starting figure %s plus its step: "
            "its points %s sit %.1f px off the model's after the best "
            "similarity (tolerance %.1f px)" % (a_entry.get("id"), vm["id"],
                                                 "".join(common), worst, tol))

    def near(ps, qs):
        if len(ps) != len(qs) or not ps:
            return False
        return all(min(math.hypot(p[0] - q[0], p[1] - q[1]) for q in qs)
                   <= tol for p in ps)
    by_key = {}
    for o in vm["objects"]:
        k = _obj_key(o)
        if k is not None:
            by_key.setdefault(k, []).append(o)
    out = {}
    for b, o in aux:
        t = typ(b, o)
        ps = [to_base(p) for p in _pts2(o.get("svg_xy"))]
        k = _obj_key(dict(o, type=t))
        cand = by_key.get(k, []) if k is not None else [
            m for m in vm["objects"] if m.get("type") == t and
            not m.get("name")]
        if k is not None and t in ("arc", "right_angle", "label", "ticks") \
                and len(cand) == 1:
            # a mark / a label: each renderer places its own (an arc's
            # svg_xy is its vertex in one, a point of the arc in the other)
            # -- the same kind named for the same thing is the same object
            out[o["svg_id"]] = cand[0]["id"]
            continue
        for m in cand:
            if near(ps, _pts2(m.get("svg_xy"))):
                out[o["svg_id"]] = m["id"]
                break
    return out


def aux_patch(vm, a_entry, spec, rows):
    """One aux figure (שרטוט עזר) as a small patch on `vm`: every object it
    shows is either an object of the model (same id, same place) or an
    addition the engine recorded and re-measured in the aux SVG itself.
    (v6.10 integrate) On an ENGINE starting figure the aux's own ids differ:
    an aux object is the model's when engine_aux_match places it there."""
    base = dict((o["id"], o) for o in vm["objects"])
    same = engine_aux_match(vm, a_entry)
    tcons = [c for _r, _i, cl in rows for c in cl.get("to_construct") or []
             if isinstance(c, dict)]
    adds, shows = [], []
    for b, lst in (a_entry.get("objects") or {}).items():
        for o in lst or []:
            sid = o.get("svg_id")
            if not sid:
                continue
            if sid in same:
                if same[sid] not in shows:
                    shows.append(same[sid])
                continue
            if sid in base:
                if not _close(base[sid].get("xy"), o.get("xy")) or \
                        not _close(base[sid].get("xyz"), o.get("xyz")):
                    raise VMError(
                        "aux figure %s draws %s elsewhere than the starting "
                        "figure %s (%s vs %s)" % (a_entry["id"], sid, vm["id"],
                                                  o.get("xy"),
                                                  base[sid].get("xy")))
                shows.append(sid)
                continue
            d = _obj(o, b, "aux_only", vm["kind"])
            d["svg_id"] = sid
            d["role"] = "context"
            for c in tcons:
                if sid in DD._drawn(a_entry, c):
                    d["role"] = "to_construct"
            adds.append(d)
    by_key = dict((DD.canon(r), r) for r in vm["relations"])
    hl, add_rel = [], []
    for fc in a_entry.get("constraints") or []:
        if not fc.get("marked"):
            continue
        r = by_key.get(DD.canon(fc))
        if r is not None:
            if r["role"] in ("to_prove", "to_construct"):
                raise VMError("aux figure %s marks %s, a %s relation"
                              % (a_entry["id"], r["id"], r["role"]))
            hl.append(r["id"])
            continue
        nr = _rel(fc, "aux_step", fc.get("item"), a_entry)
        nr["id"] = "aux-" + _slug(fc)[2:]
        nr["marked"] = True
        add_rel.append(nr)
        hl.append(nr["id"])
    ops = []
    if adds or add_rel:
        op = {"op": "add"}
        if adds:
            op["objects"] = adds
        if add_rel:
            op["relations"] = add_rel
        ops.append(op)
    if shows:
        ops.append({"op": "show", "ids": shows})
    if hl:
        ops.append({"op": "highlight", "ids": hl})
    p = {"id": a_entry["id"], "svg": a_entry.get("svg"),
         "label": spec.get("label") or DD.AUX_LABEL, "reveal": "on_request",
         "step": spec.get("step"), "ops": ops}
    if a_entry.get("item"):
        p["item"] = a_entry["item"]
    if spec.get("completes"):
        p["completes"] = True
    return p


def unsupported(vid, question, item, kind, why):
    """A visual the skill cannot render exactly: the model says so, ships no
    SVG, and Noam AI does not guess."""
    vm = {"schema_version": SCHEMA, "id": vid, "kind": kind,
          "visual_support": "unsupported", "question": question,
          "svg": None, "reason": why, "objects": [], "relations": [],
          "highlight_given": [], "aux": []}
    if item:
        vm["item"] = item
    vm["actions"] = actions(vm)
    return vm


def declared(vid, question, item, spec):
    """A content-declared visual (question / item `visual=dict(kind=...,
    objects=[...], relations=[...], data={...})`): tables, trees, Venn,
    charts. The model is exact data; a kind with no renderer is shipped
    'unsupported' (no SVG)."""
    if not isinstance(spec, dict) or spec.get("kind") not in REGISTRY:
        raise VMError("visual=%r: kind must be one of %s" % (
            (spec or {}).get("kind") if isinstance(spec, dict) else spec,
            ", ".join(sorted(REGISTRY))))
    kind = spec["kind"]
    ceiling = REGISTRY[kind][0]
    objs = []
    for o in spec.get("objects") or []:
        d = dict(o)
        d.setdefault("svg_id", None)
        d.setdefault("role", "given")
        d.setdefault("display", "initial")
        objs.append(d)
    rels = []
    for r in spec.get("relations") or []:
        d = dict(r)
        d.setdefault("role", "given")
        rels.append(d)
    vm = {"schema_version": SCHEMA, "id": vid, "kind": kind,
          "visual_support": ceiling if ceiling != "full" else "partial",
          "question": question, "svg": None, "objects": objs,
          "relations": rels, "highlight_given": [], "aux": []}
    if ceiling == "unsupported":
        vm["reason"] = ("no exact renderer for %s yet: Noam AI explains in "
                        "words or asks a sharper question" % kind)
    if spec.get("data") is not None:
        vm["data"] = spec["data"]
    if spec.get("view") is not None:
        vm["view"] = spec["view"]
    if item:
        vm["item"] = item
    vm["actions"] = actions(vm)
    return vm


def from_table(vid, question, table):
    """A question table (the page draws it from its cells): kind table,
    partial -- exact cells, no SVG ids."""
    rows = []
    if isinstance(table, dict):
        head = table.get("head") or table.get("header")
        if head:
            rows.append(list(head))
        rows += [list(r) for r in table.get("rows") or []
                 if isinstance(r, (list, tuple))]
    objs = []
    for i, r in enumerate(rows):
        for j, v in enumerate(r):
            objs.append({"id": "%s-r%dc%d" % (vid, i + 1, j + 1),
                         "svg_id": None, "type": "cell", "row": i + 1,
                         "col": j + 1, "value": v if isinstance(
                             v, (int, float)) else str(v),
                         "role": "given", "display": "initial"})
    vm = {"schema_version": SCHEMA, "id": vid, "kind": "table",
          "visual_support": "partial", "question": question, "svg": None,
          "objects": objs, "relations": [], "highlight_given": [],
          "aux": []}
    vm["actions"] = {"allowed": list(ACTIONS), "show": [vid],
                     "highlight": [], "show_aux": []}
    return vm
