# -*- coding: utf-8 -*-
"""gallery — v5.5. Renders EVERY shape and every transformation the skill can
draw, one per question, into a single PDF.

Two reasons it ships with the skill and is not a throwaway script:

1. An author who cannot see the shapes will not use them, and G76 asks for
   variety. This is the catalogue: twenty objects, each with the one line of
   code that produced it printed underneath.
2. It is a smoke test with a picture. Every builder in `shapelib` and every
   drawing primitive in `figkit_plus.plane` runs here, through the real
   emitter, against the real gates. If a change breaks a shape, the gallery
   stops building.

    cd <any folder>
    DYLD_FALLBACK_LIBRARY_PATH=/opt/homebrew/lib python3 /path/to/gallery.py
    -> out/gallery.pdf
"""
import sys
from pathlib import Path

V = Path(__file__).resolve().parent
sys.path.insert(0, str(V))

from fractions import Fraction as F                    # noqa: E402

import emit_html as E                                  # noqa: E402
import shapelib as S                                   # noqa: E402
import euclid as U                                     # noqa: E402
import numberline as N                                 # noqa: E402
from figkit_plus import plane, row, wide                # noqa: E402

N.new_sheet(arrows="right")

R = dict(width=200)


def q(n, title, code, fig, part=None):
    d = dict(n=n, intro=[title, "$\\text{%s}$" % code] if False else title,
             fig=fig, items=[], space=4)
    if part:
        d["part"] = part
    d["example"] = None
    d.pop("example")
    d["intro"] = [title]
    return d


# --- ישר המספרים (v6 C5): every builder of numberline.py, once -------------
def _nl_walk():
    n = N.NL(-9, 9, tier="block")
    n.chain([-6, 2, -3], ["+8", u"−5"]).point(-6, "A").point(-3, "B")
    return n.svg()


def _nl_set():
    n = N.NL(-5, 5, tier="block")
    n.from_inequality("2x + 3 <= 7")
    return n.svg()


def _nl_bars():
    return N.NL(-500, 1000, tick=100, tier="strip") \
        .bars_from_zero([-395, 812, 250]).svg()


def _nl_ref():
    n = N.NL(-6, 6, tier="block").reference(0, "mirror", label="m")
    n.point(-4, "A").point(4, "B").span(0, 4, "4")
    return n.svg()


def _nl_stack():
    return N.stack([N.NL(-1, 2, tick=F(1, 4), label_fmt="dec", tier="block"),
                    N.NL(-1, 2, tick=F(1, 4), label_fmt="frac", tier="block")],
                   connect=[F(-3, 4)],
                   captions=["עשרוני", "שברים"]).html()


def _nl_double():
    return N.double((0, 80), (0, 100), 10, hide_a=[24],
                    captions=['ק"מ', "אחוזים"]).html()


def _nl_zoom():
    z = N.NL(0, 10, tier="block").zoom(2, 3, 10)
    z.child.point(F(23, 10), "P")
    z.captions = ["הישר", "הגדלה"]
    return z.html()


def _nl_vertical():
    v = N.NL(-40, 60, tick=10, orientation="v", height=230)
    v.reference(0, "sea", label="S").point(30, "A").point(-20, "B")
    v.jump(-20, 30, "+50")
    return v.svg()


def _nl_sign():
    return N.sign_chart([-2, 3], ["+", u"−", "+"], closed=False,
                        poly=[1, -1, -6], tier="block").svg()


def _nl_sign_critique():
    # C5 r2: a sign chart drawn WRONG on purpose -- the signs are not the
    # polynomial's; the engine keeps the error only for an error-finding item
    return N.sign_chart([-2, 3], [u"−", "+", u"−"], poly=[1, -1, -6],
                        tier="block", student_drawing=True,
                        asks=["find_error"]).svg()


def _nl_critique():
    return N.NL(-2, 3, tier="block", student_drawing=True,
                asks=["find_error"], wrong_scale=[(2, "2.5")]).svg()


def _nl_item_critique_line():
    # C5 r3: the SUB-ITEM route (emit_plus 4-tuples). The critique contract is
    # read here too. Stage-1 open issue C5r3-V6: the error is one the builder
    # MODELS -- the inequality solved against the set drawn -- so the wrong
    # drawing is verified to be wrong, not merely declared wrong in words
    # (an interval drawn [-1, 2] with a sentence saying so was a correct
    # closed interval that nothing checked)
    n = N.NL(-1, 4, tier="item", student_drawing=True, asks=["find_error"])
    n.from_inequality("-1 <= x < 2", closed=True)
    return n


def _nl_item_critique():
    return _nl_item_critique_line().svg()


SQ = S.square(1, 1, 4)
RECT = S.rect(0, 0, 6, 3)
PAR = S.parallelogram((-3, -1), (2, -2), (0, 3))
RHO = S.rhombus_from_diagonals((4, 3), 8, 6)
KITE = S.kite(3, 0, 3, 8, 3)
DART = S.dart(4, 1, 3, 9, 4)
TRAP = S.iso_trapezoid(0, 4, 5, 2, 5)
RTRAP = S.right_trapezoid(0, 0, 7, 3, 4)
RTRI = S.right_triangle((0, 0), 6, 8)
ITRI = S.iso_triangle(-3, 3, 0, 5)
LSH = S.l_shape(0, 0, 6, 5, 3, 3)
STAIR = S.staircase(0, 0, 3, 2, 2)
CROSS = S.cross(4, 4, 4, 2)
HOUSE = S.house(1, 0, 4, 3, 2)
ARROW = S.arrow(0, 4, 5, 2, 3, 4)
CHEV = S.chevron(0, 5, 6, 3, 2)
HEX = S.regular_polygon((4, 4), 3.2, 6)
STAR = S.star((4, 4), 3.2, 1.4)

QS = [
    q(1, "מלבן וריבוע — rect, square",
      "", plane((-1, 8), (-1, 6), polys=[RECT], dpolys=[SQ], **R),
      ("חלק א׳ · מרובעים", "1-5")),
    q(2, "מקבילית מוגדרת בשלוש נקודות — parallelogram",
      "", plane((-4, 6), (-3, 4), polys=[PAR],
                dashed=[(PAR[0], PAR[2]), (PAR[1], PAR[3])], **R)),
    q(3, "מעוין מן האלכסונים — rhombus_from_diagonals",
      "", plane((-1, 9), (-1, 7), polys=[RHO],
                dashed=[(RHO[0], RHO[2]), (RHO[1], RHO[3])],
                tickmarks=[((RHO[0], RHO[1]), 1), ((RHO[1], RHO[2]), 1),
                           ((RHO[2], RHO[3]), 1), ((RHO[3], RHO[0]), 1)], **R)),
    q(4, "דלתון וחץ־שקע — kite, dart",
      "", plane((-2, 10), (-1, 10), polys=[KITE], dpolys=[DART], **R)),
    q(5, "טרפז שווה־שוקיים וטרפז ישר־זווית — iso_trapezoid, right_trapezoid",
      "", plane((-1, 11), (-1, 6), polys=[TRAP], dpolys=[RTRAP],
                right=[(RTRAP[0], RTRAP[1], RTRAP[3])], **R)),
    q(6, "משולש ישר־זווית וגובה ליתר — right_triangle",
      "", plane((-1, 8), (-1, 9), polys=[RTRI],
                right=[((0, 0), (6, 0), (0, 8))],
                dashed=[((0, 0), (2.88, 3.84))],
                points=[((2.88, 3.84), "N")], **R),
      ("חלק ב׳ · משולשים", "6-8")),
    q(7, "משולש שווה־שוקיים, זוויות הבסיס וסימוני שוויון — iso_triangle",
      "", plane((-4, 5), (-1, 6), polys=[ITRI], shaded=[ITRI],
                arcs=[(ITRI[0], ITRI[1], ITRI[2]), (ITRI[1], ITRI[2], ITRI[0])],
                tickmarks=[((ITRI[0], ITRI[2]), 1), ((ITRI[2], ITRI[1]), 1)],
                **R)),
    # P3 leftovers r2 (number-leaves-its-row-into-the-drawing): one of the
    # medians crosses the x-axis within a digit's width of the tick at x = 2.
    # The '2' used to take the other side of the axis and print inside the
    # triangle beside that median; it now stays in its row's side, a little
    # further out and a little along.
    q(8, "משולש כללי, תיכון וחציית צלע ביחס — divide",
      "", plane((-3, 8), (-4, 6), polys=[[(-2, -2), (7, 4), (3, -3)]],
                dashed=[((7, 4), S.divide((-2, -2), (3, -3), 1, 1)),
                        ((-2, -2), S.divide((7, 4), (3, -3), 1, 2))],
                points=[(S.divide((-2, -2), (3, -3), 1, 1), "M"),
                        (S.divide((7, 4), (3, -3), 1, 2), "T")], **R)),
    q(9, "צורת L — l_shape", "",
      plane((-1, 8), (-1, 7), polys=[LSH], shaded=[LSH], **R),
      ("חלק ג׳ · מצולעים מורכבים", "9-13")),
    q(10, "מדרגות — staircase", "",
      plane((-1, 8), (-1, 8), polys=[STAIR], **R)),
    q(11, "צלב — cross", "",
      plane((-1, 9), (-1, 9), polys=[CROSS], shaded=[CROSS], **R)),
    q(12, "בית — house", "",
      plane((-1, 7), (-1, 7), polys=[HOUSE], **R)),
    q(13, "חץ ושברון — arrow, chevron", "",
      plane((-1, 10), (-1, 8), polys=[ARROW], dpolys=[CHEV], **R)),
    q(14, "מצולע משוכלל ומצולע כוכב — regular_polygon, star", "",
      plane((-1, 9), (-1, 9), polys=[HEX], dpolys=[STAR], **R),
      ("חלק ד׳ · מעגל וסימטריה", "14-15")),
    q(15, "מעגל, רדיוס ומיתר — circles", "",
      plane((-6, 6), (-6, 6), circles=[((0, 0), 5, "4,3")],
            solid=[((0, 0), (3, 4)), ((-4, 3), (4, -3))],
            points=[((0, 0), "O"), ((3, 4), "A"), ((-4, 3), "B"),
                    ((4, -3), "C")], **R)),
    q(16, "הזזה ווקטור ההזזה — translate, arrows", "",
      plane((-1, 11), (-1, 9), polys=[RECT],
            dpolys=[S.translate(RECT, 4, 4)],
            arrows=[((3, 1.5), (7, 5.5))], **R),
      ("חלק ה׳ · טרנספורמציות מחושבות", "16-20")),
    q(17, "שיקוף בציר ובישר אנכי — reflect_x, reflect_line_x", "",
      plane((-4, 16), (-5, 5), polys=[ITRI],
            dpolys=[S.reflect_x(ITRI), S.reflect_line_x(ITRI, 6)],
            dashed=[((6, -4), (6, 5))],
            labels=[((6, 5.2), "x = 6", (1, 0))],
            # C6 r6: the window holds the whole figure (the original
            # triangle reaches x = -3 and its mirror x = 15; on (-1, 13) a
            # third of each printed off the grid), so it prints wider
            **dict(R, width=260))),
    q(18, "שיקוף בישר y = x — reflect_yx", "",
      plane((-1, 9), (-1, 9), polys=[[(1, 2), (5, 3), (2, 6)]],
            dpolys=[S.reflect_yx([(1, 2), (5, 3), (2, 6)])],
            dashed=[((-0.5, -0.5), (8.5, 8.5))],
            labels=[((7.4, 8.2), "y = x", (0, -1))], **R)),
    q(19, "סיבוב ברבע וחצי סיבוב — rotate", "",
      # C6 r6: (-8, 8), since the triangle's leg of 8 and its rotations
      # reach 8 -- on (-7, 7) three corners printed off the grid
      plane((-8, 8), (-8, 8), polys=[RTRI],
            dpolys=[S.rotate(RTRI, (0, 0), 1), S.rotate(RTRI, (0, 0), 2)],
            # v6.2 Q1b: the centre of the rotation is named O, so the axes
            # do not ALSO print a '0' on it -- with both, the '0' sat on the
            # dot and 'O' was pushed 1.7 em out, naming nothing (the defect
            # this round was chartered to fix; svgcheck.letter_side refuses
            # it now, and origin=False is the fix it names).
            points=[((0, 0), "O")], origin=False, **R)),
    q(20, "הגדלה ממרכז דמיון — scale_from", "",
      plane((-1, 10), (-1, 10), polys=[[(0, 0), (2, 1), (1, 3)]],
            dpolys=[S.scale_from([(0, 0), (2, 1), (1, 3)], (0, 0), 3)],
            points=[((0, 0), "O")], origin=False, **R)),   # v6.2 Q1b, as q19

    # --- גיאומטריה אוקלידית (v5.6): בלי מערכת צירים, והכול מסתובב ---
    q(21, "מקבילים ונחתך — parallels", "",
      row([U.parallels(58, mark=(1, 5), width=150),
           U.parallels(38, mark=(3, 7), rotate=24, width=150)],
          caps=["58°", "38° מסובב"]),
      ("חלק ו׳ · גיאומטריה אוקלידית", "21-26")),
    q(22, "זוויות סביב נקודה ועל ישר — angles_at_point", "",
      row([U.angles_at_point((0, 55, 130, 215), arcs=(0, 2), width=140),
           U.angles_at_point((0, 40, 180, 220), straight=True, rotate=18,
                             arcs=(0, 2), width=140)],
          caps=["סביב נקודה", "קודקודיות"])),
    q(23, "קטעים במשולש — triangle_with", "",
      row([U.triangle_with("right", "altitude", width=125),
           U.triangle_with("iso", "median", rotate=-14, width=125),
           U.triangle_with("scalene", "bisector", rotate=22, width=125),
           U.triangle_with("equilateral", "midsegment", width=125)],
          caps=["גובה", "תיכון", "חוצה זווית", "קטע אמצעים"])),
    q(24, "משולשים חופפים — congruent_pair", "",
      U.congruent_pair("sas", rotate=9, width=330)),
    q(25, "מעגל — circle_fig", "",
      row([U.circle_fig(("centre", "radius", "chord"), width=130),
           U.circle_fig(("centre", "tangent"), rotate=25, width=130),
           U.circle_fig(("centre", "two-tangents"), rotate=-15, width=130),
           U.circle_fig(("centre", "central", "inscribed"), width=130)],
          caps=["רדיוס ומיתר", "משיק", "שני משיקים", "מרכזית והיקפית"])),
    q(26, "משפחת המרובעים — quad", "",
      row([U.quad("parallelogram", diagonals=True, rotate=8, width=118),
           U.quad("rhombus", diagonals=True, rotate=-12, width=118),
           U.quad("trapezoid", rotate=15, width=118),
           U.quad("kite", diagonals=True, width=118)],
          caps=["מקבילית", "מעוין", "טרפז", "דלתון"])),

    # --- ישר המספרים (v6): numberline.py, כל היכולות ---
    q(27, "נקודות, אותיות ושרשרת קפיצות — NL.point, NL.chain", "",
      _nl_walk(), ("חלק ז׳ · ישר המספרים", "27-38")),
    q(28, "קבוצת פתרון מאי־שוויון — NL.from_inequality", "", _nl_set()),
    q(29, "עמודות מרחק מאפס — NL.bars_from_zero", "", _nl_bars()),
    q(30, "ישר ייחוס מקווקו וקטע עם תווית — NL.reference, NL.span", "",
      _nl_ref()),
    q(31, "שתי שורות על אותו סרגל עם מקשר — numberline.stack", "", _nl_stack()),
    q(32, "ישר מספרים כפול ליחס ולאחוזים — numberline.double", "",
      _nl_double()),
    q(33, "הגדלה של קטע — NL.zoom", "", _nl_zoom()),
    q(34, "סקאלה אנכית: גובה, ייחוס וקפיצה — orientation='v'", "",
      _nl_vertical()),
    q(35, "טבלת סימנים של פולינום — numberline.sign_chart", "", _nl_sign()),
    dict(q(36, "שרטוט שגוי לזיהוי טעות — student_drawing · wrong_scale", "",
           _nl_critique()), asks=["find_error"]),
    dict(q(37, "טבלת סימנים שגויה לזיהוי טעות — sign_chart · student_drawing",
           "", _nl_sign_critique()), asks=["find_error"]),
    # C5 r3: a wrong drawing inside a SUB-ITEM (emit_plus), the route the
    # question-level guard never saw, with an error the builder checks
    dict(n=38, intro=["שרטוט תלמיד בתוך תת־סעיף — student_drawing=True, from_inequality(closed=True)"],
         items=[("א", "מצאו את הטעות בשרטוט של דני", 30, _nl_item_critique())],
         space=4, asks=["find_error"]),
]

LEVEL = dict(
    level="קטלוג צורות", key="gallery", grade="הסקיל",
    subtitle="figkit_plus · shapelib · euclid · numberline · v6",
    title="כל הצורות שהסקיל יודע לצייר",
    rule="כל שרטוט בדף הזה נבנה בקריאה אחת ל-shapelib ומצויר ב-plane. הצורות "
         "המקווקוות הן תמונות מחושבות, לא קואורדינטות שהוקלדו ביד.",
    questions=QS, answers=[], figure_sheet=True, space_scale=0.75,
)

if __name__ == "__main__":
    import weasyprint
    import pymupdf
    import gate_variety, emit_plus
    gate_variety.install()
    emit_plus.install()
    out = Path.cwd() / "out"
    out.mkdir(exist_ok=True)
    f = out / "gallery.pdf"
    weasyprint.HTML(string=E.build_html(LEVEL), base_url=str(V)).write_pdf(str(f))
    import gates_runner as G
    bad = G.run_output_gates([str(f)], strict=False)
    print("\ngallery: %d page(s), %d shapes, gates %s"
          % (len(pymupdf.open(str(f))), len(QS),
             "all pass" if not bad else "%d FAILURE(S)" % len(bad)))
    sys.exit(1 if bad else 0)
