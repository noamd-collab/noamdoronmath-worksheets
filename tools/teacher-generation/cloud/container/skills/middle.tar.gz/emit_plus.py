# -*- coding: utf-8 -*-
r"""emit_plus — v5.6. A DRAWING INSIDE THE SUB-ITEM.

WHY THIS FILE EXISTS
--------------------
The author measured three finished packages and found the number the gates were
not looking at:

    per QUESTION   94% of questions carried a drawing
    per SUB-ITEM   23-27%

`emit_html` renders one figure per question (`q["fig"]`) and places it beside
`items[0]`. Every other sub-item is a bare ruled band. So a page with four
questions shows four drawings and fifteen empty lines, and reads — correctly —
as "most of this sheet has no picture". G75 and G76 both count questions, so
neither could see it.

`items` is a fixed 3-tuple (`for lab, txt, sp in q["items"]`), and item text is
escaped by `seg()`, so a figure cannot be smuggled through either. The renderer
has to learn a fourth slot.

HOW, WITHOUT EDITING THE RENDERER
---------------------------------
The same doctrine `gate_variety.install()` already uses: wrap, do not edit. But
`question_html` is 60 lines of hard-won layout, and re-implementing it to add
one slot would fork the very code the audits hardened. So this module does not
re-implement anything:

    1. it rewrites the LEVEL — a 4-tuple item `("א", txt, space, fig)` becomes
       a 3-tuple whose text starts with a plain-text token, and whose space is
       raised to fit the figure;
    2. the ORIGINAL `question_html` renders it, byte for byte as before;
    3. the token is swapped for the figure in the finished HTML;
    4. one `<style>` block is appended for the two new classes.

A 3-tuple item takes the original path untouched, and a sheet with no 4-tuple
anywhere produces output identical to the unwrapped emitter — which
`selfcheck_plus` asserts by comparing the two strings.

USE
---
    import emit_plus; emit_plus.install()          # build_plus.py does this

    items=[("א", "חשבו את השטח", 34, plane(..., width=120)),
           ("ב", "הסבירו במשפט אחד", 26)]          # 3-tuple: unchanged

    fig=row([f1, f2, f3], caps=["א", "ב", "ג"])    # figkit_plus, a figure row
    fig=wide(svg)                                   # a full-width block figure

LAYOUT
------
An item figure floats to the left of its writing band and the ruled line runs
beside it, which is where the corpus puts a small figure. The item's `space` is
raised to the figure's height so the next item cannot climb into it — the
defect the audit called "a dashed rule crossing a figure", arriving from a new
direction.

Item figures should be 90-140px wide. Wider belongs to the question head, where
`q["fig"]` already puts it.
"""
import copy
import html as _html
import re

__all__ = ["install", "uninstall", "ITEM_FIG_MAX", "item_fig_space"]

ITEM_FIG_MAX = 150.0          # px; wider than this belongs at the question head
_PX_TO_PT = 0.75
_TOKEN = "@@HMWFIG%d@@"
_TOKEN_RE = re.compile(r"@@HMWFIG(\d+)@@")

_CSS = """
/* emit_plus v5.6 — a figure inside a sub-item. Floated so the writing band
   runs beside it; the band's height is raised by the caller so nothing
   overlaps. `direction:ltr` on the svg matches .fig svg in the house sheet. */
.it > .ifig{float:left; margin:0 12pt 2pt 0; line-height:0}
.it > .ifig svg{direction:ltr}
.it{overflow:hidden}
/* a row of small figures with captions INSIDE an item. v6 C5 r3: these two
   rules were unscoped, and this block is appended after the house sheet — so
   one item figure anywhere on a page added 14pt of padding to every cell of
   every question-level figrow too, widening the rows and squeezing the title
   column beside them until a title wrapped into the figures (the gallery's
   'triangle_with' struck by a triangle's side). A question-level row keeps
   the house's own border-spacing; only a row inside an item is spaced here. */
.it > .ifig table.figrow{direction:ltr; margin:0 auto}
.it > .ifig table.figrow td{padding:0 7pt}
"""


def item_fig_space(svg, space, pad=6.0):
    """Writing room left under an item once a figure floats inside it. `.it` is
    overflow:hidden, so the float already sets the band's height; adding the
    figure's height again doubled every drawn item. Returns points."""
    m = re.search(r'<svg[^>]*\bheight="([\d.]+)', str(svg))
    if not m:
        return space
    return max(pad, float(space) + pad - float(m.group(1)) * _PX_TO_PT)


def _prepare(L, store):
    """Rewrite 4-tuple items into 3-tuples carrying a token. Returns a copy;
    the caller's level is never mutated."""
    out = copy.copy(L)
    qs = []
    import numberline as _N
    for q in L.get("questions", []):
        # v6 C5 r3: the critique contract, on the ITEM figures too. emit_html
        # calls critique_guard for a question that carries q["fig"]; an item
        # figure never reaches that call (this function rewrites the 4-tuples
        # away first), so a number line drawn WRONG on purpose used to ship
        # beside an ordinary item with nothing to stop it. `q` here is the
        # author's own question dict, so `asks` is still in reach.
        _N.critique_guard(q)
        q2 = copy.copy(q)
        items = []
        for it in q.get("items", []):
            if len(it) >= 4 and it[3]:
                lab, txt, sp, fig = it[0], it[1], it[2], it[3]
                svg = str(fig)
                w = re.search(r'<svg[^>]*\bwidth="([\d.]+)', svg)
                if w and float(w.group(1)) > ITEM_FIG_MAX:
                    raise AssertionError(
                        "emit_plus: item figure is %.0fpx wide, over the %.0f "
                        "limit — a figure that big belongs at the question "
                        "head (q['fig']), where the layout gives it a column"
                        % (float(w.group(1)), ITEM_FIG_MAX))
                if _TOKEN_RE.search(txt):
                    raise AssertionError(
                        "emit_plus: item text already contains the figure "
                        "token; rename it")
                k = len(store)
                import emit_html as _E           # v6 (E7): U+2212 in text
                import wspec_build as _WB        # v6.9: engine SVG exact
                store.append(svg if _WB.is_spec_svg(svg)
                             else _E.true_minus_svg(svg))
                items.append((lab, (_TOKEN % k) + txt,
                              item_fig_space(svg, sp)))
            else:
                items.append(tuple(it[:3]))
        q2["items"] = items
        qs.append(q2)
    out["questions"] = qs
    return out


def _restore(doc, store):
    def sub(m):
        return '<span class="ifig">%s</span>' % store[int(m.group(1))]
    # the token may have been escaped on its way through seg(); it is plain
    # ASCII, so it survives unchanged, but unescape defensively first
    doc = _TOKEN_RE.sub(sub, doc)
    doc = _TOKEN_RE.sub(sub, _html.unescape(doc)) if _TOKEN_RE.search(doc) else doc
    if _TOKEN_RE.search(doc):
        raise AssertionError("emit_plus: a figure token survived into the "
                             "output — the item text was transformed")
    return doc


def install(verbose=False):
    """Wrap `emit_html.build_html`. Idempotent; a sheet with no 4-tuple item
    renders exactly as before."""
    import emit_html as E
    if getattr(E.build_html, "_emit_plus", False):
        return E.build_html
    inner = E.build_html

    def wrapped(L, *a, **kw):
        store = []
        # The gates inside build_html must read the author's level: the
        # prepared copy has no 4-tuples left, so G77 counted every item
        # figure as missing.
        gate = E.assert_figure_variety
        E.assert_figure_variety = lambda _prepared: gate(L)
        was = E._SHEET_IDS[0]
        E._SHEET_IDS[0] = False
        try:
            doc = inner(_prepare(L, store), *a, **kw)
        finally:
            E.assert_figure_variety = gate
            E._SHEET_IDS[0] = was
        if store:
            doc = _restore(doc, store)
            doc = doc.replace("</style>", _CSS + "</style>", 1)
            if _CSS not in doc:                       # no <style> to extend
                doc = doc.replace("<body", "<style>%s</style><body" % _CSS, 1)
        # v6.6 E r1: ids unique per sheet, item figures included -- prefixed
        # once, on the finished document, from the author's own level (the
        # prepared copy has no item figures left to name).
        if was:
            import deliver as _deliver
            doc = _deliver.sheet_unique_ids(doc, L)
        return doc

    wrapped._emit_plus = True
    wrapped.__doc__ = (inner.__doc__ or "") + "\n\nWrapped by emit_plus (v5.6)."
    wrapped._inner = inner
    E.build_html = wrapped
    if verbose:
        print("emit_plus: item figures enabled")
    return wrapped


def uninstall():
    """Restore the stock emitter — used by the selfcheck to compare paths."""
    import emit_html as E
    if getattr(E.build_html, "_emit_plus", False):
        E.build_html = E.build_html._inner
    return E.build_html
