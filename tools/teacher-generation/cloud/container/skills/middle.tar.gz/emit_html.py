# -*- coding: utf-8 -*-
r"""Path A emitter (PDF): a level dict -> HTML -> WeasyPrint.

CONTENT SCHEMA (one dict per level; `LEVELS = [...]` in the sheet's
content.py).  Everything the emitter needs, nothing it does not:

    dict(
      level="רמה א׳", key="a", title="…",
      rule="the grey instruction box, one paragraph",
      questions=[ dict(
          n=1,
          part=("חלק א׳ — הצבה ישירה", "1-4"),   # only on the first Q of a part
          star=True,                              # challenge item (optional)
          intro="…"  |  ["line", "$display island$", …],
          example=("דוגמה מודרכת", ["$expr$", "שלב 1 …", "שלב 2 …"]),
          fig=<raw SVG or HTML>,                  # figlib.* — never Hebrew in SVG
          table=dict(head=[…], rows=[[…]], hcol=True, cls="wide"),
          items=[("א", "text with $math$", 30), …],   # 30 = pt of writing space
      ), … ],
      answers=[ (n, [("א","…"), …], star_bool_optional), … ],
    )

MATH MARKUP, inside `$…$` only:
    \f{a}{b}   inline stacked fraction        \d{a}{b}   display fraction
    \g{...}    parentheses stretched to the content height
    ^{...} / ^2  superscript                    ___        answer blank
ASCII `-` is converted to U+2212 MINUS SIGN; a binary +/- gets breathing
room, a unary minus stays glued to its operand.  `□ ★` are pinned to an
explicit family (G45) — David Libre has neither.
"""
import html, re, os
from pathlib import Path

# Absolute, so the CSS resolves no matter what cwd or base_url the caller
# uses.  A relative "assets/…" silently 404s, David Libre never loads, and
# the WHOLE BODY falls back to FreeSerif — the exact G45 failure that shipped
# four packages.  Caught here by the gate, fixed here by construction.
def _assets_uri():
    """FIX 1 (v5) — THE SILENT FONT FALLBACK.

    v4.3 pointed this at `~/.fonts`, a directory that does not exist on the
    author's machine.  All three @font-face rules therefore failed, David
    Libre never loaded, and EVERY sheet this skill produced fell back to
    DejaVu/FreeSerif/NimbusRoman.  The audit of Sep 2026 found exactly that
    fallback chain in the shipped PDFs, and it is the root cause of the
    minus-sign defect below: DejaVu's U+2212 sits low and short against
    David Libre's digit metrics, so `-5` printed as a struck-through 5.

    The fonts now ship INSIDE the skill, next to this file.  If they are
    missing the build DIES here: a silent fallback is how four packages
    shipped wrong, and a loud failure costs one rebuild."""
    here = Path(__file__).resolve().parent
    for cand in (here / "assets", here.parent / "assets", Path.home() / ".fonts"):
        if (cand / "DavidLibre-Regular.ttf").is_file():
            return cand.as_uri()
    raise RuntimeError(
        "G45: DavidLibre-*.ttf not found next to emit_html.py (assets/). "
        "Without them the whole body silently falls back to DejaVu and every "
        "minus sign misprints. Ship the fonts with the skill.")


ASSETS = _assets_uri()

BRAND = "מתמטיקה · נועם דורון"          # U+00B7, one space each side (G41)
BSD = "בס״ד"
MINUS = "\u2212"
def _body_cmap():
    """FIX 10 (v5) — STOP ENUMERATING THE GLYPHS THE BODY FONT LACKS.

    v4.3 hard-coded `SYM = {★, □}`, so the day an author typed `✓` it fell
    to the generic `serif` and WeasyPrint substituted Hiragino Mincho, a
    Japanese face — found by G70 in ט/35's answer key. The same trap waits
    for →, ≠, ≈, α, ∡ and every other symbol nobody listed in advance.

    So the emitter now ASKS the font. Any character David Libre cannot draw
    is wrapped in the shipped symbol face automatically, and the list can
    never fall behind the content again."""
    from fontTools.ttLib import TTFont
    path = Path(ASSETS.replace("file://", "")) / "DavidLibre-Regular.ttf"
    return set(TTFont(str(path)).getBestCmap())


_BODY_CMAP = _body_cmap()


def needs_pin(ch):
    """True when the body font cannot draw `ch` and it must be pinned."""
    o = ord(ch)
    if ch.isspace() or o < 0x20:
        return False
    return o not in _BODY_CMAP


SYM = set("★□")                          # kept: always pinned, even if present

# ------------------------------------------------------------------ math ----
def _brace(s, i):
    """s[i] == '{' ; return (inner, index_after_closing_brace)"""
    assert s[i] == "{"
    d, j = 0, i
    while j < len(s):
        if s[j] == "{":
            d += 1
        elif s[j] == "}":
            d -= 1
            if d == 0:
                return s[i + 1:j], j + 1
        j += 1
    raise ValueError("unbalanced brace in " + s)


_BLANK = "\x00blank"          # prev marker: the last thing emitted was ___
OPERAND_END = set("0123456789.)]}"
                 "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")
REL = set("=\u2264\u2265\u2260<>")


def _plain(t, prev=None, after=" "):
    """prev = last significant char emitted before this run (for unary vs
    binary minus).  Binary +/- and every relation get real breathing room;
    a unary minus stays glued to its operand. `after` = the character that
    follows this run in the island (a macro's backslash, '^', ...): a sign
    that ends the run decides glued-or-binary by it."""
    out = []
    for idx, ch in enumerate(t):
        if ch in REL:
            out.append('<span class="op2">%s</span>' % html.escape(ch))
        elif ch in "+-\u2212":
            # v6 (E7): U+2212 is the same sign as '-'. mathkit.n() and the
            # figure layer now emit it, and a typed U+2212 used to skip the
            # binary/unary spacing decision entirely.
            g = "+" if ch == "+" else MINUS
            if prev == _BLANK:
                # v6 (E21): after an answer blank the sign decides by its
                # neighbour. `___ -3` is a comparison item whose right side is
                # the number -3 (glued); `___ - 3` is a binary minus. It used
                # to be binary either way, so z01 typed U+2212 to dodge it.
                # The last character of a run looks past it: `___ -\f{4}{3}`
                # (mathkit.fr's own form) is the number -4/3, glued, although
                # the run was flushed before the fraction macro.
                nxt = t[idx + 1] if idx + 1 < len(t) else (after or " ")
                if nxt.isspace():
                    out.append('<span class="op1">%s</span>' % g)
                else:
                    out.append(g)
            elif prev in OPERAND_END:
                out.append('<span class="op1">%s</span>' % g)
            else:
                out.append(g)
        elif ch in SYM or needs_pin(ch):
            out.append('<span class="sym">%s</span>' % html.escape(ch))
        else:
            out.append(html.escape(ch))
        if not ch.isspace():
            prev = ch
    return "".join(out)


# ------------------------------------------------- VECTOR MACROS (G67) ---
# THE PERMANENT FIX for the "\sqrt{20} printed as literal text" defect
# (טרפז package, Sep 2026).  Before this table the parser knew \f \d \g ^ ___
# and NOTHING ELSE, so `\sqrt{...}` and `\angle{A}` fell through to _plain(),
# shipped as prose, and the RTL algorithm scrambled them into `{02}trqs\`.
# Every gate passed, because no gate looked for a backslash.
#
# These symbols render as SVG PATHS via mathsvg (STIX): font-independent,
# bidi-atomic, and invisible to the text layer — which is exactly what
# G43-F2 requires (a `√` CODEPOINT in the extracted text is a defect; a
# vector surd is not).  `∡` needs no G45 font pin for the same reason.
# E-1: the letters following an angle symbol are normal body-font text;
# only its sign is a vector, scaled in em to the surrounding font size.
_ARG_MACROS = {"sqrt": r"\sqrt{%s}", "angle": r"\measuredangle %s"}
_BARE_MACROS = {
    "para": r"\parallel", "npara": r"\nparallel", "perp": r"\perp",
    "cong": r"\cong", "sim": r"\sim", "tri": r"\triangle",
    # FIX 7 (v5) — these are used across the shipped corpus and were simply
    # ABSENT from v4.3's table, so `\pi` fell through to _plain() and printed
    # as the four letters `\pi` on every circle sheet in ח/63 and ח/64, and
    # `\leq` destroyed the given in ט/39 ("AC\leq AB"). An emitter that
    # refuses an unknown macro is only safe if the macros authors need exist.
    "pi": r"\pi", "leq": r"\leq", "geq": r"\geq", "neq": r"\neq",
    "approx": r"\approx", "cdot": r"\cdot", "times": r"\times", "pm": r"\pm", "mp": r"\mp",
    "deg": r"^\circ", "infty": r"\infty",
}
# `^` and braces are produced by _to_tex itself when it lifts a power, so a
# guard that forbids them rejects its own output: `\sqrt{150^2-75^2}` raised
# "unsafe characters" although every character came from this parser.
_TEX_OK = re.compile(r"^[0-9A-Za-z+\-\u2212 .,()°^_{}]*$")


def _to_tex(dsl):
    """House DSL -> mathtext TeX, for the inside of a vector macro.
    Deliberately narrow: anything it cannot prove safe RAISES, so a typo
    becomes a build failure instead of literal ink on a sellable sheet."""
    out, i = [], 0
    while i < len(dsl):
        if dsl.startswith("\\f{", i) or dsl.startswith("\\d{", i):
            num, j = _brace(dsl, i + 2)
            den, j = _brace(dsl, j)
            out.append(r"\frac{%s}{%s}" % (_to_tex(num), _to_tex(den)))
            i = j
        elif dsl.startswith("\\g{", i):
            inner, j = _brace(dsl, i + 2)
            out.append(r"\left(%s\right)" % _to_tex(inner))
            i = j
        elif dsl.startswith("\\sqrt{", i):
            inner, j = _brace(dsl, i + 5)
            out.append(r"\sqrt{%s}" % _to_tex(inner))
            i = j
        elif dsl[i] == "^":
            if i + 1 < len(dsl) and dsl[i + 1] == "{":
                inner, j = _brace(dsl, i + 1)
            else:
                inner, j = dsl[i + 1], i + 2
            out.append("^{%s}" % _to_tex(inner))
            i = j
        elif dsl[i] == "_":
            # A subscript inside a root was rejected outright, so `\sqrt{x_1}`
            # could not be written and an author had to rephrase the answer.
            # The HTML side already renders subscripts; the vector side has to
            # agree, or the same expression is legal in one place and illegal
            # three characters away.
            if i + 1 < len(dsl) and dsl[i + 1] == "{":
                inner, j = _brace(dsl, i + 1)
            else:
                inner, j = dsl[i + 1], i + 2
            out.append("_{%s}" % _to_tex(inner))
            i = j
        elif dsl[i] == "\\":
            raise ValueError("unsupported macro inside vector math: %r" % dsl)
        else:
            out.append("\u2212" if dsl[i] == "\u2212" else dsl[i])
            i += 1
    tex = "".join(out).replace("\u2212", "-").replace("\u00b7", r"\cdot ")
    if "\\" not in tex and not _TEX_OK.match(tex):
        raise ValueError("unsafe characters in vector math: %r" % dsl)
    return tex


# v6.12 fix_r2 (m1): size of the \\tri glyph -- its ink is the cap height of
# the 13pt body (David Libre capitals ~8.6pt), not a 12pt-tall symbol.
TRI_PT = 9.2


def _vector(tex):
    from mathsvg import math_svg
    return math_svg(tex, 13.0, cls="rad")


def _angle_name(inner):
    """A geometric name uses the surrounding text face and em size.

    Only the measured-angle sign stays vector (David Libre lacks it).
    Unlike a mathematical variable, ABC must not become STIX italic paths;
    absolute 13pt paths also enlarged names in the smaller answer key.
    """
    _to_tex(inner)  # preserve the existing vector-argument syntax guard
    from mathsvg import math_svg
    sign = math_svg(r"\measuredangle", 13.0, cls="angle-symbol")
    sign = re.sub(r'(width|height)="([0-9.]+)pt"',
                  lambda m: '%s="%.6fem"' % (m[1], float(m[2]) / 13.0), sign)
    sign = re.sub(r'vertical-align:([0-9.\-]+)pt',
                  lambda m: 'vertical-align:%.6fem' % (float(m[1]) / 13.0), sign)
    return '<span class="angle-name">%s<span class="angle-letters">%s</span></span>' % (sign, m_body(inner))


def m_body(e, prev=None):
    """Render the inside of a $...$ island."""
    out, i, buf = [], 0, []
    state = {"prev": prev}

    def flush():
        if buf:
            txt = "".join(buf)
            out.append(_plain(txt, state["prev"],
                              e[i] if i < len(e) else " "))
            for c in reversed(txt):
                if not c.isspace():
                    state["prev"] = c
                    break
            buf.clear()

    while i < len(e):
        if e.startswith("\\f{", i) or e.startswith("\\d{", i):
            kind = "frac" if e[i + 1] == "f" else "dfrac"
            num, j = _brace(e, i + 2)
            den, j = _brace(e, j)
            flush()
            out.append('<span class="%s"><span class="fnu">%s</span>'
                       '<span class="fbar"></span>'
                       '<span class="fde">%s</span></span>'
                       % (kind, m_body(num), m_body(den)))
            state["prev"] = ")"
            i = j
        elif e.startswith("\\g{", i):
            inner, j = _brace(e, i + 2)
            flush()
            out.append('<span class="grp"><span class="par">(</span>%s'
                       '<span class="par">)</span></span>' % m_body(inner))
            state["prev"] = ")"
            i = j
        elif e[i] == "^":
            flush()
            if i + 1 < len(e) and e[i + 1] == "{":
                inner, j = _brace(e, i + 1)
            else:
                inner, j = e[i + 1], i + 2
            out.append("<sup>%s</sup>" % m_body(inner))
            state["prev"] = "9"
            i = j
        elif e.startswith("\\rat{", i):
            # `\rat{3}{4}` prints 3∶4 with U+2236, the one colon the division
            # gate accepts in ratio shape. A ratio and a scale are written with
            # a colon on a worksheet; before this they had to be faked as a
            # built fraction or spelled out in words.
            # THE COLON MUST BE PINNED. David Libre has no U+2236, and this
            # branch emitted it raw inside `.m`, whose stack ends in the
            # generic `serif` -- so the one glyph the macro exists to print
            # came out of Songti-SC, a Chinese system face, and G70 failed
            # for every sheet that used a ratio. `.sym` is the shipped
            # symbol face (DejaVu Sans), which does have the glyph.
            a, j = _brace(e, i + 4)
            b, k = _brace(e, j)
            flush()
            out.append('<span class="m">%s<span class="sym">\u2236</span>'
                       '%s</span>' % (m_body(a), m_body(b)))
            state["prev"] = "9"
            i = k
        elif e[i] == "_" and not e.startswith("___", i):
            # SUBSCRIPTS PRINTED AS INK. `x_{1}` came out of the emitter as
            # the literal characters `x_{1}`, exactly the markup-leak class
            # the audit found for `\sqrt` and `**bold**` -- and G67 never
            # caught it because an underscore is also the answer-blank
            # character. A package hit this and wrote `BP_min` out in words
            # rather than print the leak. The writing blank is `___`, three
            # or more, so a single `_` is unambiguously a subscript.
            flush()
            if i + 1 < len(e) and e[i + 1] == "{":
                inner, j = _brace(e, i + 1)
            else:
                inner, j = e[i + 1], i + 2
            # v6.12 fix_r2 (mF): a subscript right before a closing bracket
            # left the side bearings of both glyphs as a visible gap
            # ("A(x₁,y₁ )"); the bracket is pulled in a little.
            tight = e[j:j + 1] in (")", "]")
            out.append("<sub%s>%s</sub>" % (' class="tight"' if tight else "",
                                           m_body(inner)))
            state["prev"] = "9"
            i = j
        elif e.startswith("___", i):
            flush()
            out.append('<span class="blank"></span>')
            state["prev"] = _BLANK
            i += 3
        elif e[i] == "\\":
            # FIX 9 (v5) — two forms the corpus uses that v4.3 could not read.
            # `\%` is an escaped literal (ח/64 writes `20\%`), and `\text{…}`
            # carries a Hebrew word inside a formula (ט/34's area formula).
            # Hebrew inside a math run is bidi-scrambled, which is exactly
            # what shipped: `\text{\·}בסיסtext{}גובה`. Rendered here as its
            # own RTL-embedded span, it reads correctly.
            if i + 1 < len(e) and e[i + 1] in "%$&#_":
                flush()
                out.append(html.escape(e[i + 1]))
                state["prev"] = e[i + 1]
                i += 2
                continue
            if e.startswith("\\text{", i):
                inner, j = _brace(e, i + 5)
                flush()
                out.append('<span class="txt">%s</span>' % html.escape(inner))
                state["prev"] = ")"
                i = j
                continue
            name = re.match(r"\\([a-zA-Z]+)", e[i:])
            if not name:
                raise ValueError("stray backslash in math island: %r" % e)
            nm, j = name.group(1), i + name.end()
            flush()
            if nm in _ARG_MACROS:
                if j >= len(e) or e[j] != "{":
                    raise ValueError("\\%s needs {...} in %r" % (nm, e))
                inner, j = _brace(e, j)
                out.append(_angle_name(inner) if nm == "angle" else
                           _vector(_ARG_MACROS[nm] % _to_tex(inner)))
            elif nm == "tri":
                # v6.12 fix_r2 (m1): the STIX triangle at body size stood
                # taller than the capitals, and the TeX delimiter space
                # printed a gap before the name ("△ ABC ."). The triangle is
                # drawn at cap height and joined to the name that follows.
                from mathsvg import math_svg
                out.append(math_svg(_BARE_MACROS[nm], TRI_PT, cls="rad tri"))
                while j < len(e) and e[j] == " ":
                    j += 1
            elif nm in _BARE_MACROS:
                out.append(_vector(_BARE_MACROS[nm]))
            else:
                # G67 AT SOURCE. Never fall through to _plain(): that is
                # precisely how \sqrt{} reached a customer as literal ink.
                raise ValueError("unknown math macro \\%s in %r" % (nm, e))
            state["prev"] = ")"
            i = j
        else:
            buf.append(e[i])
            i += 1
    flush()
    return "".join(out)


_B_OPEN, _B_CLOSE = "\x01", "\x02"


def _mark_bold(text):
    """FIX 8 (v5) — BOLD THAT SPANS A MATH ISLAND.

    v4.3 split on `$` first and only then looked for `**...**`, so a phrase
    like `**סכום שלוש הזוויות הוא $180°$**` put the opening marker in one
    prose part and the closing marker in another. Each part then saw a lone
    `*`, and the build died on content that is perfectly reasonable — the
    rule box of ט/34 says exactly that sentence. Pairs are matched across
    the whole string first, so an island may sit inside bold."""
    out, i, depth = [], 0, 0
    while True:
        j = text.find("**", i)
        if j < 0:
            out.append(text[i:])
            break
        out.append(text[i:j])
        out.append(_B_CLOSE if depth else _B_OPEN)
        depth ^= 1
        i = j + 2
    if depth:
        raise ValueError("unbalanced **bold** in %r" % text)
    return "".join(out)


# Authors keep writing `$x = 5$ .` -- a space wedged between a math island and
# the sentence-final period, inserted by hand to stop the period from drifting
# in the bidi run. It never needed to: a period after an LTR island takes the
# paragraph direction and lands at the left edge, which IS the end of a Hebrew
# sentence. The space does nothing but print a gap before the period. Strip it
# here rather than in every content.py, since the next author will write it too.
_MATH_PUNCT_GAP = re.compile(r"\$[ \u00a0]+([.,;:!?])")


def seg(text):
    """Hebrew prose with $...$ math islands."""
    text = _MATH_PUNCT_GAP.sub(r"$\1", text)
    text = _mark_bold(text)
    parts = text.split("$")
    if len(parts) % 2 == 0:
        raise ValueError("odd number of $ delimiters in %r" % text)
    out = []
    for k, p in enumerate(parts):
        if k % 2 == 0:
            # G67 AT SOURCE, prose half. `\angle{A}` written OUTSIDE a math
            # island is the same defect one step earlier — and the RTL run
            # scrambles it far worse than it scrambles it inside one.
            if "\\" in p:
                raise ValueError("backslash in Hebrew prose (macro outside "
                                 "$...$?): %r" % text)
            esc = "".join('<span class="sym">%s</span>' % html.escape(c)
                          if (c in SYM or needs_pin(c)) else html.escape(c)
                          for c in p)
            # `**bold**` was never processed — the asterisks shipped as ink and
            # print as `''` beside Hebrew, in the rule box of every sheet this
            # skill has ever produced. Convert here, then refuse any asterisk
            # that survives, so an unbalanced pair fails the build instead of
            # decorating a term in the definition box.
            if "*" in esc:
                raise ValueError("stray '*' in prose (unbalanced **bold**?): "
                                 "%r" % p)
            esc = esc.replace(_B_OPEN, "<b>").replace(_B_CLOSE, "</b>")
            out.append(esc)
        else:
            cls = "m dm" if ("\\d{" in p) else "m"
            body = m_body(p.replace(_B_OPEN, "").replace(_B_CLOSE, ""))
            if _B_OPEN in p or _B_CLOSE in p:
                body = "<b>%s</b>" % body      # bold opened outside the island
            out.append('<span class="%s">%s</span>' % (cls, body))
    return "".join(out)


def _sub_line(L):
    """v6.12 fix_r2 (mG): the subtitle line "grade · subtitle · level".
    It wrapped wherever the last word fell, so a long subtitle left
    "מצוינות" alone on line 2. Each " · " piece is now unbreakable (its
    spaces are no-break) and the last two pieces are one unit, so a wrap
    comes only at a separator and never strands the level name."""
    parts = ([L.get('grade', 'כיתה ט׳')]
             + str(L.get('subtitle', 'דף עבודה')).split(" · ")
             + [L['level']])
    parts = [p if "$" in p else p.strip().replace(" ", "\u00a0")
             for p in parts]
    tail = "\u00a0·\u00a0".join(parts[-2:])
    return seg(" · ".join(parts[:-2] + [tail]))


def is_display(text):
    """A line that is exactly one math island becomes a display line."""
    t = text.strip()
    return t.startswith("$") and t.endswith("$") and t.count("$") == 2


# ------------------------------------------------------------------- CSS ----
CSS = r"""
@font-face{font-family:"David Libre";src:url("%(ASSETS)s/DavidLibre-Regular.ttf");font-weight:400}
@font-face{font-family:"David Libre";src:url("%(ASSETS)s/DavidLibre-Bold.ttf");font-weight:700}
@font-face{font-family:"David Libre";src:url("%(ASSETS)s/DavidLibre-Medium.ttf");font-weight:500}
/* FIX 2 (v5) — ★ and □ came out of Hiragino Mincho, a Japanese system font.
   `.sym` asked for "DejaVu Serif", which is NOT installed on the author's
   Mac, so the generic `serif` fallback picked whatever the OS offered. The
   glyphs now ship with the skill, so the sheet renders the same everywhere. */
@font-face{font-family:"HouseSym";src:url("%(ASSETS)s/DejaVuSans.ttf")}

@page{
  size:A4; margin:16mm 15mm 14mm 15mm;
  @top-right   {content:"%(BSD)s";  font-family:"David Libre"; font-size:9pt; color:#666;}
  @top-center  {content:"%(BRAND)s";font-family:"David Libre"; font-size:9pt; color:#666;}
  @bottom-center{content:"עמוד " counter(page) " מתוך " counter(pages);
                 font-family:"David Libre"; font-size:8.5pt; color:#555;}
/* FIX 4 (v5) — two @bottom-right rules were declared; the second won and
     the copyright line (S-26) never printed on a single sheet. The notice
     now lives bottom-left, where nothing competes with it. */
  /* FIX 12b — the shipped sheets carry the full notice, not a short form.
     Using the author's own wording keeps a rebuild from quietly dropping it. */
  @bottom-left{content:"© כל הזכויות שמורות לנועם דורון · אין להעתיק, לצלם או להפיץ ללא אישור בכתב";
                 font-family:"David Libre"; font-size:6.4pt; color:#8a8a8a;}
  @bottom-right{content:"%(BRAND)s";font-family:"David Libre"; font-size:8.5pt; color:#666;}
}

*{box-sizing:border-box}
html,body{margin:0;padding:0}
body{font-family:"David Libre","DejaVu Serif",serif; direction:rtl;
     font-size:11.6pt; line-height:1.62; color:#111;}

.sym{font-family:"HouseSym","DejaVu Sans",sans-serif}
/* a Hebrew word inside a formula: its own RTL run, never part of the LTR
   math flow that would scramble it. */
.txt{direction:rtl; unicode-bidi:embed; font-family:"David Libre",serif}

/* --- math islands ------------------------------------------------------ */
.m{direction:ltr; unicode-bidi:embed; white-space:nowrap;
   font-family:"David Libre","DejaVu Serif",serif;}
.m .op1{margin:0 .13em}
.m .op2{margin:0 .22em}
.m.dm{white-space:normal}
/* vector macros (\sqrt, ∥, ⊥ …): SVG paths, no font, no codepoint —
   mathsvg sets vertical-align inline to the exact descent. */
.rad{display:inline-block; margin:0 .06em}
.rad.tri{margin:0 .03em 0 -.05em}
.angle-name{font-family:inherit; font-size:inherit; font-style:normal;
            white-space:nowrap}
.angle-letters{font:inherit}
.angle-symbol{display:inline-block; margin:0 .03em 0 0}

.frac{display:inline-block; vertical-align:middle; text-align:center;
      margin:0 .16em; line-height:1.06; position:relative; top:-0.06em}
.frac .fnu,.frac .fde{display:block; padding:0 .22em; font-size:.94em}
.frac .fbar{display:block; height:1.25px; background:currentColor;
            font-size:0; line-height:0}

.dfrac{display:inline-block; vertical-align:middle; text-align:center;
       margin:0 .18em; line-height:1.18; position:relative; top:-0.06em}
.dfrac .fnu,.dfrac .fde{display:block; padding:0 .40em}
.dfrac .fbar{display:block; height:1.35px; background:currentColor;
             font-size:0; line-height:0}

.grp{display:inline-block; vertical-align:middle; position:relative;
     top:-0.06em}
.grp>.par{font-size:2.05em; line-height:.46; vertical-align:middle;
          font-weight:400; margin:0 .01em; position:relative; top:.015em}

.blank{display:inline-block; width:34pt; border-bottom:1px solid #333;
       height:.85em; margin:0 3pt}

/* --- head -------------------------------------------------------------- */
.lvl{font-weight:700; font-size:10.5pt; text-align:right; color:#222;
     border-bottom:1.6px solid #111; padding-bottom:3pt; margin-bottom:9pt}
h1{font-size:19pt; font-weight:700; text-align:center; margin:0 0 2pt}
.sub{text-align:center; font-size:11pt; color:#333; margin-bottom:9pt}
.idline{text-align:center; font-size:11pt; margin-bottom:10pt; color:#111}
.rule{background:#f2f2f0; border:1px solid #d8d8d4; border-radius:2px;
      padding:7pt 10pt; font-size:10.2pt; line-height:1.55; margin-bottom:12pt}

/* --- bands ------------------------------------------------------------- */
.band{background:#e9e9e6; border:1.2px solid #111; padding:3.5pt 9pt;
      margin:13pt 0 9pt; font-size:11pt; break-after:avoid; break-inside:avoid}
.band b{font-weight:700}
/* Marker number is its OWN LTR unit (Gdot-fix): bidi-override removes
   neutral-resolution entirely, so a trailing period can NEVER flip to ".1".
   The wrapper only positions; the star is a SIBLING, never inside the run. */
.qnum,.anum,.band .num{display:inline-block; direction:ltr;
       unicode-bidi:bidi-override; white-space:nowrap}
.band.brk{break-before:page}

/* --- questions --------------------------------------------------------- */
/* FIX 3 (v5) — THE ★ THAT TOUCHED THE FIRST LETTER.
   `.qmarkabs` is absolutely positioned in a 30pt gutter, but a two-digit
   marker `(12)` measures 20.2pt and the star adds 10pt more: 30.2pt, so the
   star landed exactly on the first Hebrew letter of the question. Measured
   in the shipped PDFs of ז/25, ז/27 and ט/02 — every starred question whose
   number reached two digits. The gutter is now sized for the widest real
   marker (a three-digit starred number) with a deliberate 4pt air gap. */
.q{position:relative; padding-right:44pt; margin-bottom:7pt}
.qtop{break-inside:avoid}
.qtop::after{content:""; display:block; clear:both}
.qmarkabs{position:absolute; right:0; top:0; direction:rtl;
          font-weight:700; font-size:11.6pt; white-space:nowrap;
          width:40pt; text-align:right; padding-left:4pt}
.qmarkabs .st{font-family:"HouseSym","DejaVu Sans",sans-serif; font-size:9.4pt}
.qintro{margin-bottom:2pt; break-after:avoid}
.mline{direction:ltr; text-align:right; line-height:2.0; margin-right:14pt;
       margin-bottom:1pt; white-space:nowrap}

.ex{background:#f6f6f4; border-right:3px solid #999; padding:6pt 10pt 7pt;
    margin:4pt 0 9pt; font-size:10.8pt; break-inside:avoid}
.ex .exh{font-weight:700; margin-bottom:2pt}
.ex .exl{margin:1pt 0}

/* FIX 6b — `(10)` measures ~22pt bold; the 19pt gutter let it print on the
   first letter, the same failure as the star in FIX 3. Sized for `(99)`. */
.it{position:relative; padding-right:28pt; padding-top:1pt;
    border-bottom:1px dashed #bcbcbc; margin-bottom:6pt;
    break-inside:avoid}
.it:last-child{margin-bottom:2pt}
.it.noitem{padding-right:0}
.imark{position:absolute; right:0; top:1pt; font-weight:700}
/* FIX 6 — a parenthesised label is a closed LTR unit, like .qnum. */
.lmark{display:inline-block; direction:ltr; unicode-bidi:bidi-override;
       white-space:nowrap}

.fig{text-align:center; margin:6pt 0 8pt; break-inside:avoid}
/* FIX 11 (v5) — PAGE ECONOMY. A figure emitted as a full-width block pushed
   the text below it and inflated the rebuilt sheets by 38%% (132 pages became
   182 across the first six packages). The originals set a narrow figure
   BESIDE the text. `float:left` in an RTL flow puts the drawing on the left
   and lets the Hebrew wrap to its right, which is the house layout and costs
   no pages. Applied only to figures narrow enough to leave a readable
   column; a wide one still gets its own block. */
/* A figure floated beside the text got cut in half by the item's dashed
   writing rule: the rule is a full-width border and a float does not
   shorten it. That is the audit's own 'dashed rule crossing a figure'
   defect (45 files), reproduced by the rebuild -- verified by
   rendering. Painting an opaque ground on the float does not cover it
   either. So a side figure is no longer a float: the question head
   becomes two columns, and the rule lives in the text column where it
   belongs. */
.fig.side{margin:2pt 0 6pt 0; text-align:center}
.qtop.split{display:flex; align-items:flex-start; gap:12pt}
.qtop.split .qbody{flex:1 1 auto; min-width:0}
.qtop.split .fig.side{flex:0 0 auto; order:2}
.q::after{content:""; display:block; clear:both}
.figrow{direction:ltr; margin:0 auto; border-collapse:separate;
        border-spacing:20pt 0}
.figrow td{text-align:center; vertical-align:bottom}
.figbox{margin-bottom:3pt}
.figcap{direction:rtl; font-size:10pt; color:#222}
.fig svg{direction:ltr}
sup{font-size:.66em; line-height:0; vertical-align:.52em}
.m sub.tight{margin-right:-.14em}
table.g{border-collapse:collapse; margin:5pt 14pt 8pt 0; font-size:10.8pt}
table.g.wide{margin-right:0; width:auto}
table.g th,table.g td{border:1px solid #444; padding:3.2pt 9pt;
                      text-align:center; min-width:56pt; height:19pt}
table.g th{background:#efefec; font-weight:700; font-size:10.4pt}

.good{text-align:center; font-weight:700; font-size:13pt; margin-top:14pt}

/* --- answers ----------------------------------------------------------- */
.ansband{background:#e9e9e6; border:1.2px solid #111; padding:4pt 9pt;
         margin:0 0 7pt; font-weight:700; font-size:11.5pt}
.ansnote{font-size:9.8pt; color:#444; margin-bottom:6pt}
.arow{display:table; width:100%%; border-bottom:0.6px solid #d6d6d2;
      padding:1.35pt 0; break-inside:avoid}
.amark{display:table-cell; width:28pt; direction:rtl;
       font-weight:700; vertical-align:top; padding-left:8pt;
       white-space:nowrap; font-size:10.4pt}
.amark .st{font-family:"HouseSym","DejaVu Sans",sans-serif; font-size:8.6pt}
/* FIX 5 (v5, preventive) — an answer segment that carries a stacked
   fraction is taller than a 1.40 line box, so a wrapped row printed tight
   against the row below it. Not a proven miscount, but the audit logged
   21 sheets with answer rows reading as one block; the extra leading costs
   a few millimetres and removes the ambiguity. */
.abody{display:table-cell; vertical-align:top; font-size:__AFS__pt;
       line-height:1.72}
.aseg{display:inline-block; vertical-align:top; margin-left:11pt;
      max-width:100%%}
.aline{display:block}
.alab{font-weight:700}
.anote{color:#444; font-size:10.2pt}
"""


# ------------------------------------------------- THE MARKER INVARIANT ---
# One place emits `N.`; nowhere else may. `bidi-override` is a LOADED GUN:
# it does not resolve neutrals, it *reverses whatever it is given*. Digits
# and a period come out `12.` — correct. A Hebrew letter would come out
# reversed and no render gate that counts glyphs would see it. So the run is
# closed by construction: it accepts `\d+\.` and nothing else, and the star
# is emitted as a SIBLING, never inside.
MARKER_RE = re.compile(r"^\(\d+\)$")

# The declarations G65 depends on. `direction:ltr` alone is NOT enough:
# without an override (or at minimum `embed`) the trailing period is a bidi
# neutral, resolves to the paragraph direction (RTL) by UAX#9 rule N2, and
# renders to the LEFT of the digits — the `.12` bug.
MARKER_CSS_REQUIRED = ("direction:ltr", "unicode-bidi:bidi-override")


# A Hebrew label of ANY length, not just one letter. The single-letter form
# left `\u05d9\u05d0` and `\u05d9\u05d1` \u2014 the tenth and eleventh sub-items, ordinary on a long
# question \u2014 falling through to the parenthesised branch, whose CSS is
# `direction:ltr; unicode-bidi:bidi-override`. That override does not resolve
# neutrals, it REVERSES what it is given, so `(\u05d9\u05d0)` printed as `(\u05d0\u05d9)`. The
# file's own comment warns about exactly this; the pattern did not.
HEB_LABEL = re.compile("^[\u05d0-\u05ea]{1,3}[\u05f3'\u2032\u05f4\"]?$")


def item_label(lab, cls="imark"):
    """FIX 6 (v5) — THE `.1` DEFECT, WHERE IT ACTUALLY SURVIVED.

    v4.3 closed this for QUESTION numbers by switching them to `(N)`: a
    mirrored parenthesis pair has no dangling neutral, so nothing can flip.
    But sub-item labels were left as `%s.` and the identical bug lives on
    there whenever the label is a digit:

        `1.`  ->  digit is an LTR run, the period after it is a bidi
                  neutral, UAX#9 rule N2 gives it the paragraph direction
                  (RTL), and it lands to the LEFT of the digit: `.1`

    A Hebrew label is immune, because the letter is itself strong RTL and
    the period simply follows it. So the rule is by label type, verified by
    render, not by hope:

        א ב ג   -> `א.`   house style, renders correctly
        1 2 10  -> `(1)`  parenthesised, same cure as the question number
        A B     -> `(A)`  same reason

    Noam asked for exactly this, Sep 2026: stop defending against the flip
    and remove the neutral instead."""
    lab = str(lab)
    if HEB_LABEL.match(lab):
        return '<span class="%s">%s.</span>' % (cls, html.escape(lab))
    return '<span class="%s lmark">(%s)</span>' % (cls, html.escape(lab))


def ltr_marker(n, cls="qnum"):
    """Render one question/answer marker as a closed LTR unit."""
    txt = "(%s)" % n
    if not MARKER_RE.match(txt):
        raise AssertionError(
            "marker %r is not (\\d+) — house rule, Noam Aug 2026: a trailing "
            "period is a bidi neutral and flips left of the digits; the "
            "parenthesis pair is mirrored, so the bug is eliminated rather "
            "than defended against" % txt)
    return '<span class="%s">%s</span>' % (cls, txt)


def assert_marker_invariants(css=None):
    """G66 (source half of the `.1` fix). Called on every build: if the CSS
    that carries the invariant is edited away, the build dies HERE, with a
    message, instead of silently shipping `.12` markers."""
    css = CSS if css is None else css
    flat = re.sub(r"\s+", "", css)
    for decl in MARKER_CSS_REQUIRED:
        if decl not in flat:
            raise AssertionError(
                "G66: marker CSS lost %r — `.qnum/.anum` would render `.12` "
                "instead of `12.` (see SKILL.md invariant #1)" % decl)
    if ".qnum" not in flat or ".anum" not in flat:
        raise AssertionError("G66: `.qnum`/`.anum` rule missing from CSS")
    return True




# ------------------------------------------------- G74: GUTTER FITS ------
# The star that printed on the first Hebrew letter (ז/25, ז/27, ט/02) was a
# WIDTH bug: a 30pt gutter holding a 20.2pt marker plus a 10pt star. The
# first attempt at a gate for it read the finished PDF and tried to measure
# the gap. That cannot work: an inline answer label followed by a space is
# geometrically identical to a marker touching the text, because the space
# belongs to the neighbouring span's bounding box. Both readings are 0.00pt.
#
# So this is decided where it is decidable — at source, against the real
# advance widths in the bundled font, before a byte is rendered.
_GUTTER_PT = {"q": 44.0, "it": 28.0}     # must match .q / .it padding-right
_AIR_PT = 4.0                            # deliberate clear space


def _advance(text, size, bold=True):
    """Width of `text` in points, from the bundled David Libre."""
    from fontTools.ttLib import TTFont
    face = "DavidLibre-Bold.ttf" if bold else "DavidLibre-Regular.ttf"
    path = Path(ASSETS.replace("file://", "")) / face
    f = TTFont(str(path))
    cmap, hmtx, upem = f.getBestCmap(), f["hmtx"], f["head"].unitsPerEm
    w = 0
    for ch in text:
        gn = cmap.get(ord(ch))
        w += hmtx[gn][0] if gn else upem * 0.5
    return w * size / upem


def assert_gutter_fits(L):
    """G74 — every marker this sheet will emit must fit its gutter."""
    worst = []
    for q in L["questions"]:
        mark = "(%s)" % q["n"]
        w = _advance(mark, 11.6)
        if q.get("star"):
            w += 10.0 + 2.0                      # ★ at 9.4pt + its space
        worst.append(("q", q["n"], mark + ("\u2605" if q.get("star") else ""), w))
        for lab, _txt, _sp in q["items"]:
            lab = str(lab)
            txt = ("%s." % lab) if HEB_LABEL.match(lab) else ("(%s)" % lab)
            worst.append(("it", q["n"], txt, _advance(txt, 11.6)))
    bad = []
    for kind, n, txt, w in worst:
        room = _GUTTER_PT[kind] - _AIR_PT
        if w > room:
            bad.append("%s %r in question %s needs %.1fpt, gutter leaves %.1fpt"
                       % ("marker" if kind == "q" else "label", txt, n, w, room))
    if bad:
        raise AssertionError(
            "G74: a marker will print on the first letter of its text — "
            + "; ".join(bad[:3])
            + ". Widen .%s padding-right in CSS." % ("q/.it"))
    return True


# ------------------------------------------------- G75: FIGURE VARIETY ---
# v5.2 (Noam, Sep 2026). A rebuilt analytic-geometry package passed every
# gate in this file and still looked wrong to its author: one SVG served five
# questions on רמה א׳, one served six on רמת מצוינות, and three of twenty
# questions on each sheet had no drawing at all. Nothing measured how many
# drawings a sheet has, or whether they are the SAME drawing. The audit's
# instruments count defects in figures; they do not count figures.
#
# The rule, in three parts:
#   * REUSE   — one SVG may serve at most FIG_REUSE_MAX questions. A question
#               that goes back to an object already drawn draws the thing IT
#               adds: the diagonal, the altitude, the midpoint, the extra
#               point, the right-angle mark. Same coordinates, new drawing.
#   * COVER   — on a figure sheet, at least FIG_COVER_MIN of the questions
#               carry a drawing. That is the curriculum file's own trigger
#               for a geometry sheet (60%), applied in the other direction.
#   * OBJECTS — a figure sheet with FIG_FAMILIES_FROM or more drawn questions
#               shows at least FIG_FAMILIES_MIN different objects. Variants
#               of one rhombus are one object (figkit.figure_family).
#
# A sheet is a figure sheet when its title or its part bands name geometry,
# or (until v6.16) when FIG_SHEET_SHARE of its questions carried a drawing. The
# level may say `figure_sheet=True/False` itself; False switches off COVER
# and OBJECTS, is printed loudly by build.py, and never lifts REUSE — an
# algebra sheet has no more right to print one graph five times.
FIG_REUSE_MAX = 2
FIG_COVER_MIN = 0.60
FIG_FAMILIES_MIN = 3
FIG_FAMILIES_FROM = 8
FIG_SHEET_SHARE = 0.40
FIG_KEYWORDS = ("גאומטר", "גיאומטר", "וקטור", "מערכת צירים", "מערכת הצירים",
                "קואורדינט", "משולש", "מרובע", "טרפז", "מקבילית", "מעוין",
                "מלבן", "מעגל", "עיגול", "גליל", "חרוט", "פיתגורס", "דמיון",
                "חפיפ", "זווית", "זוויות", "תיבה", "פירמיד", "מנסרה", "שרטוט")


def _fig_key(svg):
    return re.sub(r"\s+", " ", str(svg)).strip()


def is_figure_sheet(L):
    """Explicit `figure_sheet`, else the TOPIC, else geometry words in the
    title or a band.

    (v6.16 fix r1, the author's W-FIGURE-DENSITY) "Whether a sheet counts as
    a figure sheet comes from the topic, never from measured coverage": the
    last rule used to be the share of questions that already carry a drawing
    (FIG_SHEET_SHARE), so a figure topic drawn on less than 40% of its
    questions was, by that very count, not a figure sheet and escaped every
    floor. The topic is gate_figref.topic_status: a declared figure_topic,
    the package id in figure_topics.json, or the tashpaz unit. A sheet whose
    topic is unknown is judged by the words of its title and bands only."""
    if "figure_sheet" in L:
        return bool(L["figure_sheet"])
    import gate_figref as _GF
    st = _GF.topic_status(L)
    if st["figure"] is not None:
        return bool(st["figure"])
    text = " ".join([str(L.get("title", ""))]
                    + [str(q["part"][0]) for q in L["questions"] if q.get("part")])
    return any(k in text for k in FIG_KEYWORDS)


def _item_fig(it):
    if isinstance(it, dict):
        return it.get("fig")
    return it[3] if len(it) >= 4 else None


def figure_exemptions(L):
    """(v6.14 F4) {question n: reason} -- the questions a figure sheet
    exempts BY NAME from the drawing floors (G75 COVER, G77 QUESTIONS /
    SUB-ITEMS): a question the original prints with no figure ("פתרו בלי
    שרטוט"). Each names a question of the level, gives its reason, and
    draws nothing (no head, no item figure); anything else is refused. The
    rest of the level keeps every floor -- unlike figure_sheet=False."""
    ex = L.get("figure_exempt") or {}
    if not isinstance(ex, dict):
        raise AssertionError("G75: figure_exempt is {question n: reason}, "
                             "not %r" % (ex,))
    qs = dict((q.get("n"), q) for q in L.get("questions", []))
    out = {}
    for n, why in ex.items():
        q = qs.get(n)
        if q is None:
            raise AssertionError("G75: figure_exempt names question %s, "
                                 "which level %s lacks" % (n, L.get("key")))
        if not str(why or "").strip():
            raise AssertionError("G75: figure_exempt question %s gives no "
                                 "reason" % n)
        if q.get("fig") or any(_item_fig(it) for it in q.get("items", [])):
            raise AssertionError("G75: figure_exempt question %s draws a "
                                 "figure -- an exemption is for a question "
                                 "with none" % n)
        out[n] = str(why)
    return out


def figure_report(L):
    """Counts G75 reads: questions, drawn questions, distinct SVGs, objects,
    and every SVG that serves more than one question. (v6.14 F4) n leaves
    out the figure_exempt questions."""
    from figkit import figure_family
    ex = figure_exemptions(L)
    qs = [q for q in L["questions"] if q.get("n") not in ex]
    uses = {}
    for q in qs:
        if q.get("fig"):
            uses.setdefault(_fig_key(q["fig"]), []).append(q["n"])
    fams = {figure_family(k) for k in uses}
    return dict(n=len(qs), with_fig=sum(len(v) for v in uses.values()),
                distinct=len(uses), families=len(fams),
                reuse=sorted(((len(v), v) for v in uses.values()), reverse=True),
                figure_sheet=is_figure_sheet(L),
                override=("figure_sheet" in L), exempt=sorted(ex))


def assert_figure_variety(L):
    """G75 — every level, on every build."""
    r = figure_report(L)
    bad = []
    over = [(c, qn) for c, qn in r["reuse"] if c > FIG_REUSE_MAX]
    if over:
        bad.append("the same drawing serves %s (cap is %d): draw what each of "
                   "those questions adds — a diagonal, an altitude, a midpoint, "
                   "a new point"
                   % ("; ".join("questions %s" % ", ".join(map(str, qn))
                                for _, qn in over), FIG_REUSE_MAX))
    if r["figure_sheet"] and r["n"]:
        share = r["with_fig"] / float(r["n"])
        if share < FIG_COVER_MIN - 1e-9:
            bad.append("a figure sheet with drawings on %d of %d questions "
                       "(%.0f%%, floor %.0f%%)"
                       % (r["with_fig"], r["n"], 100 * share, 100 * FIG_COVER_MIN))
        if r["with_fig"] >= FIG_FAMILIES_FROM and r["families"] < FIG_FAMILIES_MIN:
            bad.append("%d drawn questions but only %d object(s) drawn — vary the "
                       "shapes and the point sets across the parts (floor %d "
                       "objects)" % (r["with_fig"], r["families"], FIG_FAMILIES_MIN))
    if bad:
        raise AssertionError("G75 (figure variety, level %s): "
                             % L.get("key", "?") + "; ".join(bad))
    return r


# ------------------------------------------------------------------ build ---
def band_html(part, brk):
    """The part band went through `html.escape`, so a family name like
    `y = x^{2} + c` could not be printed: the superscript is absent from the
    bundled face, and writing the character raw pulls a fallback font that
    fails G70. An author hitting this drops the formula from the band, which
    is content loss caused by the emitter. Route the name through `seg` so a
    `$...$` island works here exactly as it does in a question."""
    name, rng = (part[0], part[1] if len(part) > 1 else None)
    if not rng:
        # A section heading with no question range is legitimate — a band that
        # just names the part. It used to crash with AttributeError, so the
        # author invented a range to get past the emitter.
        return ('<div class="band%s"><b>%s</b></div>'
                % (" brk" if brk else "", seg(name)))
    # The word was hard-coded plural, so a part holding ONE question printed
    # «חלק ו׳ – אתגר שאלות 22» — a band that contradicts its own contents.
    # A range is "12-14" or "3, 5"; a bare number is one question.
    word = "שאלה" if re.fullmatch(r"\s*\d+\s*", rng or "") else "שאלות"
    return ('<div class="band%s"><b>%s</b> %s '
            '<span class="num">%s</span></div>'
            % (" brk" if brk else "", seg(name), word, html.escape(rng)))


def _bind(kind, rid, part=None):
    """v6.11 (G80-text, Codex NEW-1): the id of a printed block, so the
    finished PDF can be bound, block by block, to the row of sheet.json it
    prints (textbind.py). An attribute only: no CSS reads it, the layout is
    unchanged. Written AFTER class/style, so a reader of those is unaffected."""
    if rid is None:
        return ""
    return ' data-bind="%s:%s%s"' % (kind, rid,
                                     "" if part is None else ":%d" % part)


def _with_bind(frag, attr):
    """`frag` (one element's HTML) with `attr` written into its first
    opening tag -- so a caller (or a harness that wraps fig_html /
    table_html / intro_html) keeps the signature it always had."""
    if not attr:
        return frag
    i = frag.find(">")
    return frag if i < 0 else frag[:i] + attr + frag[i:]


def intro_html(intro):
    lines = intro if isinstance(intro, list) else [intro]
    out = []
    for ln in lines:
        if is_display(ln):
            out.append('<div class="mline">%s</div>' % seg(ln))
        else:
            out.append('<div class="qintro">%s</div>' % seg(ln))
    return "".join(out)


def _intro_bound(intro, qid):
    """intro_html, each line bound as stem:<qid>:<k> (G80-text)."""
    lines = intro if isinstance(intro, list) else [intro]
    return "".join(_with_bind(intro_html([ln]), _bind("stem", qid, k))
                   for k, ln in enumerate(lines))


def table_html(t):
    out = []
    if t.get("head"):
        out.append("<tr>%s</tr>"
                   % "".join("<th>%s</th>" % seg(x) for x in t["head"]))
    hcol = t.get("hcol")
    for r in t["rows"]:
        cells = []
        for k, c in enumerate(r):
            tag = "th" if (hcol and k == 0) else "td"
            cells.append("<%s>%s</%s>" % (tag, seg(c), tag))
        out.append("<tr>%s</tr>" % "".join(cells))
    return '<table class="g %s">%s</table>' % (t.get("cls", ""), "".join(out))


import os as _os
# Overridable so a harness can measure the same package both ways without
# editing any content file.
SIDE_MAX = float(_os.environ.get("HMW_SIDE_MAX", 210.0))


_GENERIC_FACE = re.compile(r'font-family="(serif|sans-serif|monospace)"')
_TEXT_NO_FACE = re.compile(r'<text(?![^>]*font-family=)')


def _pin_svg_fonts(svg):
    """Raw SVG passed to `fig=` bypasses everything, and the corpus is full
    of it. A `<text font-family="serif">` in there resolves to whatever the
    OS offers — Times New Roman on this machine — which is the silent font
    fallback this whole version exists to end, arriving through the one
    door nobody guarded. Two assessment packages built from their own
    sources failed G70 on exactly this. Pin the generic family to the
    bundled face, and give a face to a <text> that names none."""
    svg = _GENERIC_FACE.sub('font-family="David Libre,serif"', svg)
    return _TEXT_NO_FACE.sub('<text font-family="David Libre,serif"', svg)


_SVG_TEXT = re.compile(r"(<text\b[^>]*>)(.*?)(</text>)", re.S)
_HYPHEN_REF = re.compile(r"&#(?:0*45|[xX]0*2[dD]);")


def true_minus_svg(svg):
    """v6 (E7). Every ASCII '-' inside an SVG <text> body becomes U+2212.

    A figure label has no hyphenated words — Latin, digits, ° and U+2212 is
    the whole alphabet — so the conversion is total. Raw SVG written in a
    level file reaches the page through here (and emit_plus item figures),
    which is where t17's 184 hyphen tick labels came from. Tags and
    attributes are left alone; only character data changes."""
    def body(m):
        parts = re.split(r"(<!\[CDATA\[.*?\]\]>|<[^>]+>)", m.group(2),
                         flags=re.S)
        # an escaped hyphen (&#45; / &#x2d;) is the same glyph once parsed;
        # svgcheck.ascii_minus unescapes before it looks, so convert it too.
        # CDATA is character data as well.
        parts = [("<![CDATA[" + p[9:-3].replace("-", MINUS) + "]]>")
                 if p.startswith("<![CDATA[") else
                 p if p.startswith("<") else
                 _HYPHEN_REF.sub(MINUS, p).replace("-", MINUS)
                 for p in parts]
        return m.group(1) + "".join(parts) + m.group(3)
    return _SVG_TEXT.sub(body, str(svg))


def fig_html(svg, side_ok="auto"):
    """Place a narrow figure beside the text instead of above it.

    v6.9: an engine (wspec) figure is inlined EXACTLY as the engine wrote
    it -- it names the house face itself and prints U+2212 of its own; no
    pass of this module rewrites a byte of it."""
    import wspec_build as _WB
    if not _WB.is_spec_svg(svg):
        svg = true_minus_svg(_pin_svg_fonts(svg))
    side = False
    if side_ok is True:
        side = True
    elif side_ok == "auto":
        m = re.search(r'<svg[^>]*\bwidth="([\d.]+)', svg)
        side = bool(m) and float(m.group(1)) <= SIDE_MAX
    return '<div class="fig%s">%s</div>' % (" side" if side else "", svg)


def _item_rid(q, lab):
    if q.get("n") is None:
        return None
    import deliver as _deliver
    return _deliver.item_id(q["n"], lab)


def question_html(q, scale, brk):
    out = []
    qid = "q%s" % q["n"] if q.get("n") is not None else None
    if q.get("part"):
        out.append(band_html(q["part"], brk))
    star = '<span class="st">★</span> ' if q.get("star") else ""
    # (v6.16 fix r1, verify S-P6) `keep=True` on ONE question keeps it on one
    # page (its sub-items with its figure), as the level-wide keep_questions
    # does for every question -- an inline style, so the class stays "q" (the
    # G80 text binding reads <div class="q"> by its class list)
    keep = ' style="break-inside:avoid"' if q.get("keep") else ""
    out.append('<div class="q"%s><div class="qmarkabs">%s%s</div>'
               % (keep, ltr_marker(q["n"], "qnum"), star))
    if q.get("example"):
        title, lines = q["example"]
        body = "".join('<div class="exl%s">%s</div>'
                       % (" mline" if is_display(l) else "", seg(l))
                       for l in lines)
        # The worked-example TITLE was escaped, not emitted: a heading that
        # says "כאשר המקדם $b$ הוא אפס" printed the dollar signs as ink -- the
        # markup-leak class, in the one heading nobody thought to route through
        # the maths layer. The band title had the same bug and was fixed; this
        # is its twin.
        out.append('<div class="ex"%s><div class="exh">%s</div>%s</div>'
                   % (_bind("example", qid), seg(title), body))
    # `intro` was the last hard key of the family: `rule` became optional and
    # `items` may be empty, but a question that is a figure plus sub-items still
    # raised KeyError, so the author wrote a lead sentence the source never had.
    if q.get("intro"):
        out.append(_intro_bound(q["intro"], qid))
    if q.get("fig"):
        # v6 C5: a number line drawn WRONG on purpose (an error-finding item)
        # may stand only beside an item that declares asks=['find_error'], and
        # such an item may not show the correct drawing instead (L7)
        import numberline
        numberline.critique_guard(q)
        out.append(_with_bind(fig_html(q["fig"],
                                       side_ok=q.get("fig_side", "auto")),
                              _bind("fig", qid)))
    if q.get("table"):
        out.append(_with_bind(table_html(q["table"]), _bind("table", qid)))
    # A QUESTION MAY HAVE NO LETTERED PARTS. The emitter used to crash on an
    # empty `items`, so an author facing a source question that is one plain
    # instruction had to invent a sub-item label `א.` that the page never had.
    # `space` gives the writing room for that case.
    items = ['<div class="it" style="padding-bottom:%.1fpt"%s>%s%s</div>'
             % (sp * scale, _bind("item", _item_rid(q, lab)),
                item_label(lab), seg(txt))
             for lab, txt, sp in q["items"]]
    if not items:
        items = ['<div class="it noitem" style="padding-bottom:%.1fpt"></div>'
                 % (float(q.get("space", 30)) * scale)]
    head = out[2 if q.get("part") else 1:]        # example+intro+table
    del out[2 if q.get("part") else 1:]
    side = [h for h in head if h.startswith('<div class="fig side"')]
    if side:
        body = [h for h in head if h not in side]
        out.append('<div class="qtop split"><div class="qbody">%s%s</div>%s</div>'
                   % ("".join(body), items[0], "".join(side)))
    else:
        out.append('<div class="qtop">%s%s</div>' % ("".join(head), items[0]))
    out.extend(items[1:])
    out.append("</div>")
    return "".join(out)


# FIX 12 (v5) — the answer-key note was hardcoded, and it did not match what
# the corpus actually prints. Rebuilt sheets therefore lost the author's own
# wording and the word-diff reported a dozen missing words on every package.
# The house text below is the one measured in the shipped PDFs; a level may
# override it with `ansnote`.
ANSNOTE = ("התשובות הסופיות בלבד. בשאלות שבהן נדרש נימוק, הסבר או הוכחה — "
           "הכתיבה המלאה היא חלק מן הפתרון שלכם.")


def answers_html(answers, note=None):
    out = ['<div class="ansband">תשובות סופיות</div>',
           '<div class="ansnote">%s</div>' % seg(note or ANSNOTE)]
    for a in answers:
        n, segs = a[0], a[1]
        star = len(a) > 2 and a[2]
        body = []
        for lab, txt in segs:
            if not lab:
                body.append('<span class="aline anote">%s</span>' % seg(txt))
                continue
            piece = '%s %s' % (item_label(lab, "alab"), seg(txt))
            body.append('<span class="aseg">%s</span>' % piece)
        st = '<span class="st">★</span> ' if star else ""
        out.append('<div class="arow"%s><div class="amark">%s%s</div>'
                   '<div class="abody">%s</div></div>'
                   % (_bind("answer", "q%s" % n), ltr_marker(n, "anum"), st,
                      "".join(body)))
    return "".join(out)


def build_html(L, scale=None, breaks=(), ansfs=9.9):
    """`space_scale` on the level multiplies every item's writing space.
    Rebuilt sheets run longer than their originals mostly because of that
    space, and until now the only way to compress it was to edit the number on
    every single item. The caller's explicit `scale` still wins."""
    if scale is None:
        # FLOOR. The knob exists to recover a page, not to shrink the answer
        # space to a third of what the author asked for -- and left free it
        # drifted to 0.38 in one package and 0.45 in another, purely to make
        # the page count look like the original's. A worksheet is a place to
        # write; 0.75 is as tight as that stays honest. An explicit `scale`
        # from the caller is a deliberate override and is not floored.
        scale = max(float(L.get("space_scale", 1.0)), 0.75)
    assert_marker_invariants()
    assert_gutter_fits(L)
    assert_figure_variety(L)
    q = "".join(question_html(x, scale, x["n"] in breaks)
                for x in L["questions"])
    # THE INSTRUCTION BOX IS OPTIONAL. It used to be mandatory -- `L['rule']`
    # raised KeyError without it -- so an author rebuilding a sheet that never
    # had one had to invent a paragraph in house style to make the build run.
    # A generator that forces new prose onto the page is not a repair tool.
    # `rule=None` or no `rule` key at all now emits no box.
    rule = L.get("rule")
    rule_html = '<div class="rule">%s</div>' % seg(rule) if rule else ""
    # `keep_questions=True` stops a question from splitting across a page.
    # One package needed it and had to inject the CSS through a figure string
    # to get it; that is the emitter's job, not the content file's. Off by
    # default: it changes pagination, and every existing package was laid out
    # without it.
    keep = "<style>.q{break-inside:avoid}</style>" if L.get("keep_questions") else ""
    # A sheet whose answers ship separately used to get a page break and an
    # empty "תשובות סופיות" band with the standing note under it. No answers,
    # no answer page.
    ans = L.get("answers") or []
    ans_html = ('<div style="break-before:page"></div>\n'
                + answers_html(ans, L.get("ansnote"))) if ans else ""
    # THE HEADLINE WAS ESCAPED, NOT EMITTED. The part band had this bug and was
    # fixed; the worked-example heading had it and was fixed; the <h1>, the
    # level line, the subtitle and the answer-key note are the rest of the
    # family, and they are the LARGEST text on the page. A sheet titled
    # `פתרון המשוואה $2x + 5 = 11$` printed the dollar signs. Every heading now
    # goes through the same maths layer as a question.
    doc = f"""<!DOCTYPE html><html lang="he" dir="rtl"><head>
<meta charset="utf-8"><style>{(CSS % dict(BSD=BSD, BRAND=BRAND, ASSETS=ASSETS)).replace("__AFS__", "%.2f" % ansfs)}</style>{keep}</head><body>
<div class="lvl">{seg(L['level'])} · {seg(L.get('grade','כיתה ט׳'))}</div>
<h1>{seg(L['title'])}</h1>
<div class="sub">{_sub_line(L)}</div>
<div class="idline">שם: _________________________&nbsp;&nbsp;&nbsp;
כיתה: ________&nbsp;&nbsp;&nbsp;תאריך: ____________</div>
{rule_html}
{q}
<div class="good">בהצלחה!</div>
{ans_html}
</body></html>"""
    # v6.6 E (X1R2-02): one id, one element, across the whole sheet -- each
    # inlined figure's ids carry its figure id (deliver.sheet_unique_ids)
    # emit_plus turns this off for its inner call: the item figures are put
    # back only after this returns, so it prefixes the finished sheet itself
    # from the author's level (v6.6 E r1, E-X1R2-02-emitplus).
    if not _SHEET_IDS[0]:
        return doc
    import deliver as _deliver
    return _deliver.sheet_unique_ids(doc, L)


_SHEET_IDS = [True]
