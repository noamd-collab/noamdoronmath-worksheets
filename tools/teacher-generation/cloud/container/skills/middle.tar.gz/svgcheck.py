# -*- coding: utf-8 -*-
r"""svgcheck — v6. Sweeps that read ONLY the finished SVG.

WHY THIS FILE EXISTS
--------------------
`figkit.Figure.verify()` once passed a sheet whose axis numbers had slid off
their ticks (z01 28ב): it checked the solver's own records, and the records
said every number was where the solver had put it. A check that reads the
bookkeeping of the thing it is checking proves nothing. Every sweep here takes
the SVG string a builder is about to return, parses it with its own tokenizer
(no figkit import, no solver state), and measures what a reader would see.

So a defect counts as caught only when a test feeds this module the broken
SVG and it complains. Builders call `assert_clean()` at render time; a PDF
gate can call the same functions on the SVGs it extracts.

THE SWEEPS
----------
    struck(svg)          labels (tspans included) crossed by dark ink: any
                         path command (M L H V C S Q T A Z, absolute or
                         relative), lines, polylines, polygons, rects,
                         circle and ellipse rims, and filled dots
    ascii_minus(svg)     ASCII '-' (or a look-alike dash, U+2010-2013,
                         U+FE63, U+FF0D) directly before a digit inside
                         <text>; a figure prints U+2212 (DejaVu/David hyphen
                         reads as a short dash, not a minus)
    font_floor(svg)      every text run, tspans included, at its PRINTED size
                         (size x display/viewBox x 0.75pt) against 7pt — the
                         superscript of `y = x^2` printed at 6.15pt
    tick_alignment(svg)  the ROW of axis numbers: each within 0.15 x tick
                         spacing of a tick, and on its OWN tick (z01 28ב,
                         q38); jump, length and point labels off that row
                         are not tick numbers
    arrowhead_clearance  an arrow tip stops >= 1.5pt short of another arrow's
                         tail and >= r + 1.5pt from any dot (pilot C 2ד,
                         z08 4ג '->->'); a double-headed dimension line and
                         dimensions chained head to head are not refused;
                         barbs, filled triangles, chevrons over a shaft that
                         stops at their base, and <marker> heads all count
    label_ownership      a value label bound to a stroke is nearer that
                         stroke than any other by a factor of 1.5
    dot_on_other_tick    a dot on an axis never half-covers a tick (off its
                         centre by >= 0.5pt with the rim still on it); with
                         `values=` every dot reads back as one of the values
                         and a dot whose value is not its tick's value may not
                         print on that tick (-0.5 m at 0.105 px/m on the 0)

    mark_geometry        v6 C3 (E5): right-angle marks on 90 +- 0.5 degrees,
                         equality ticks on pieces of one length (a tick at
                         least 5pt, 2.5pt apart), chevrons on parallel strokes,
                         '59°' against its arc's rays; C3 r2: a tick names the
                         piece whose middle it stands on (an arc's end is no
                         vertex), and ticks on an edge lying along an axis
                         stand clear of the axis's tick marks ('|| |')
    markers              v6 C3 (E8): white-filled markers at least 3.5pt half
                         across, never painted over; no hollow ring (a
                         <circle> or a <path>) a line shows through
    rtl_text             v6 C4 r3 (G49 / doctrine 7): Hebrew (any right-to-left
                         letter) inside <text>; WeasyPrint does not run the
                         bidi algorithm there, so 'קפיצה' prints 'הציפק'
    reading_merge        v6 C3 (E24): two labels on one baseline band closer
                         than 0.6 em, or a label standing in the row of an
                         axis's numbers ('4 Q 6')

    problems(svg, ...)   all of the above as a list of strings
    assert_clean(svg, where, ...)  raises AssertionError naming the fix

The parser follows CSS precedence (style beats a presentation attribute) and
reads font-size units (px, pt, %, em). The text box model is the one the house layout uses for David Libre: advance
0.58 em per character, ascent 0.78 em, descent 0.24 em.

A run made only of digits, U+2212, '+', '.' and ',' is also given its INK box
(C2 round 2), measured from DavidLibre-Regular with fontTools: every digit,
U+2212 and '+' advances 0.50 em, '.' and ',' 0.36 em; digit ink stands at most
0.63 em above the baseline and 0.022 em below it (a comma 0.19 em below). The
box used is 0.66 em up, 0.03 em down (0.20 with a comma), padded NUM_PAD_EM
all round. `struck` tests a number against that box: the 0.78/0.24 em text box
reaches 0.12 em above a digit and 0.21 em below it, so a curve passing clear
of the digits was read as striking them, and the figure engine had to cut a
gap a third larger than the number to satisfy it.
"""
import html
import math
import re
import unicodedata

MIN_PT = 7.0
CHAR_W = 0.58
ASC, DESC = 0.78, 0.24
PX_TO_PT = 0.75
LIGHT = 0.85          # luminance above this is background, as in G72
# P1 (house look): the coordinate grid's grey. Visible in black-and-white
# print (luminance inside GRID_BAND) and still BACKGROUND to every sweep:
# _dark() recognises it by colour. Builders never draw data in it.
GRID_GREY = "#c8c8c8"
GRID_BAND = (0.74, 0.82)       # #bdbdbd .. #d1d1d1
GRID_PT = (0.28, 0.45)         # a grid line's printed width, pt
TICK_TOL = 0.15       # fraction of tick spacing
# v6 stage 1b (the author's rule of 2026-09-16): a data stroke is never cut
# behind a number, so a number a stroke reaches MOVES instead. One such number
# may stand this far along its axis from its tick -- still well inside half a
# spacing, so its centre is nearer its own tick than any other and a reader
# cannot mistake which tick it names. A ROW that has slid is a different thing
# and is still refused at TICK_TOL: at most one number in four may be moved.
MOVED_TOL = 0.35
MOVED_SHARE = 3       # at most 1 in this many of a row may stand off its tick
MOVED_LEAST = 2       # ... but always at least this many, and never the WHOLE
#                       row: a row with no number on its tick has slid, which
#                       is the z01 28ב defect and stays refused at TICK_TOL.
_LONE_REACH = 0.45    # a lone number this near a tick is that tick's (C2 r3)
# v6 stage 1b r2: how far out of its row a number that CROSSED its axis may
# stand and still be judged as that row's (see _mirrors). It must cover the
# engine's step-out tier, figkit.PIN_DROP_EM = 0.70 em, or such a number is
# judged by nothing.
_MIRROR_EM = 1.60
# ... and how near its own value's place such a number must stand to be read
# as this axis's at all (in spacings): past MOVED_TOL it is a slid number and
# is refused, past this it is someone else's label
_MIRROR_REACH = 0.75
# a number off its tick is judged as slid when its own tick is nearer than
# this many spacings; one exactly half-way between two numbered ticks, 1.5
# spacings from its own, is a value (C3 r2: the solver asks the same)
SLID_REACH = 1.5 * (1 - 1e-3)
ARROW_GAP_PT = 1.5
ROUND_PT = 0.02       # printed pt lost to the SVG's own 0.1-unit rounding
OWN_FACTOR = 1.5
# stage-1 fix r1 (PR10): ONE shade grey for every builder on a sheet (0.86
# luminance: above the 0.85 ink line, visible on a laser printer)
SHADE_FILL = "#dcdcdc"
SLOT_SHARE = 0.25        # a letter covering this share of an axis number slot
MINUS = "−"
# the ink of a NUMBER in the shipped face (see the module docstring)
NUM_ADV = dict([(c, 0.50) for c in "0123456789+" + "\u2212"] +
               [(".", 0.36), (",", 0.36)])
NUM_TOP, NUM_BOT, NUM_BOT_COMMA = 0.66, 0.03, 0.20
NUM_PAD_EM = 0.06

__all__ = ["parse", "model", "struck", "ascii_minus", "font_floor",
           "tick_alignment", "arrowhead_clearance", "label_ownership",
           "dot_on_other_tick", "problems", "assert_clean", "true_minus",
           "blocks", "mark_geometry", "markers", "reading_merge",
           "rtl_text", "letter_side", "number_owns_its_tick", "number_on_data", "zero_owner_strict", "row_straddles",
           "arcs_join", "arc_crossings", "equal_arc_angles", "MINUS"]


def true_minus(s):
    """Every ASCII '-' in figure text becomes U+2212. In an SVG label there is
    no hyphenated word to protect — the house rule is Latin, digits, ° and
    U+2212 only — so the conversion is total and safe."""
    return _DASHES.sub(MINUS, str(s))


# ASCII hyphen-minus plus the look-alike dashes an author's editor or a
# copied number brings in (hyphen, non-breaking hyphen, figure dash, en dash,
# small and full-width hyphen-minus). Doctrine: U+2212 is the only minus.
_DASH_CLASS = "\\-\u2010\u2011\u2012\u2013\u2014\ufe58\ufe63\uff0d\u2796\u02d7"
_DASHES = re.compile("[%s]" % _DASH_CLASS)


# ------------------------------------------------------------------ parse ---
class Node(object):
    __slots__ = ("tag", "attrs", "children", "text", "tail", "parent")

    def __init__(self, tag, attrs, parent=None):
        self.tag, self.attrs, self.parent = tag, attrs, parent
        self.children, self.text, self.tail = [], "", ""


_TOK = re.compile(r"<!--.*?-->|<\?.*?\?>|<!\[CDATA\[.*?\]\]>|<![^>]*>"
                  r"|</\s*([\w:.-]+)\s*>|<([\w:.-]+)((?:\s+[^\s=/>]+\s*=\s*"
                  r"(?:\"[^\"]*\"|'[^']*'))*)\s*(/?)>", re.S)
_ATTR = re.compile(r"([^\s=/>]+)\s*=\s*(\"([^\"]*)\"|'([^']*)')")


_INK_COPY = re.compile(r'<g class="ink-copy"[^>]*>.*?</g>|'
                       r'<(?:line|circle) class="ink-copy"[^>]*/>', re.S)


def strip_copies(svg):
    """v6.8 G1: the SVG without its id-carrying overdraws (class="ink-copy").
    Every sweep reads each stroke once."""
    return _INK_COPY.sub("", str(svg)) if "ink-copy" in str(svg) else str(svg)


def parse(svg):
    """A tolerant tokenizer: well-formed XML parses exactly; a hand-written
    fragment with an unclosed tag still yields its elements."""
    root = Node("#root", {})
    cur, last = root, None
    pos = 0
    for m in _TOK.finditer(svg):
        txt = svg[pos:m.start()]
        if txt:
            txt = html.unescape(txt)
            if last is not None and last.parent is cur:
                last.tail += txt
            else:
                cur.text += txt
        pos = m.end()
        tok = m.group(0)
        if tok.startswith("<![CDATA["):                 # character data
            txt = tok[9:-3]
            if last is not None and last.parent is cur:
                last.tail += txt
            else:
                cur.text += txt
            continue
        if tok.startswith("<!") or tok.startswith("<?"):
            continue
        if m.group(1):                                  # closing tag
            name = m.group(1)
            n = cur
            while n is not root and n.tag != name:
                n = n.parent
            if n is not root:
                last, cur = n, n.parent
            continue
        attrs = {}
        for a in _ATTR.finditer(m.group(3) or ""):
            v = a.group(3) if a.group(3) is not None else a.group(4)
            attrs[a.group(1)] = html.unescape(v)
        style = attrs.get("style")
        if style:
            for decl in style.split(";"):
                if ":" in decl:
                    k, v = decl.split(":", 1)
                    # CSS: a style declaration beats the presentation
                    # attribute (stroke="#000" style="stroke:none" draws
                    # nothing; font-size="12" style="font-size:5px" is 5)
                    k, v = k.strip(), re.sub(r"\s*!\s*important\s*$", "",
                                             v.strip(), flags=re.I)
                    if k == "font":
                        # stage-1 open issue (C1 parser-root-font-size-and-
                        # shorthand): the shorthand 'font:6px serif' sets the
                        # size too; '!important' is no part of a value
                        fm = re.search(r"(?:^|\s)([\d.]+(?:px|pt|em|%)?)"
                                       r"(?:/[\d.]+\w*)?\s+\S", v)
                        if fm:
                            attrs["font-size"] = fm.group(1)
                        continue
                    attrs[k] = v
        node = Node(m.group(2), attrs, cur)
        cur.children.append(node)
        last = None
        if m.group(4) == "/":
            last = node
        else:
            cur = node
    return root


# ------------------------------------------------------------ transforms ---
def _mul(a, b):
    return (a[0] * b[0] + a[2] * b[1], a[1] * b[0] + a[3] * b[1],
            a[0] * b[2] + a[2] * b[3], a[1] * b[2] + a[3] * b[3],
            a[0] * b[4] + a[2] * b[5] + a[4], a[1] * b[4] + a[3] * b[5] + a[5])


_ID = (1.0, 0.0, 0.0, 1.0, 0.0, 0.0)


def _parse_transform(s):
    m = _ID
    for name, args in re.findall(r"(\w+)\s*\(([^)]*)\)", s or ""):
        v = [float(x) for x in _NUM.findall(args)]
        if name == "translate":
            t = (1, 0, 0, 1, v[0], v[1] if len(v) > 1 else 0.0)
        elif name == "scale":
            t = (v[0], 0, 0, v[1] if len(v) > 1 else v[0], 0, 0)
        elif name == "rotate":
            a = math.radians(v[0])
            t = (math.cos(a), math.sin(a), -math.sin(a), math.cos(a), 0, 0)
            if len(v) == 3:
                t = _mul(_mul((1, 0, 0, 1, v[1], v[2]), t),
                         (1, 0, 0, 1, -v[1], -v[2]))
        elif name == "matrix" and len(v) == 6:
            t = tuple(v)
        elif name == "skewX":
            t = (1, 0, math.tan(math.radians(v[0])), 1, 0, 0)
        elif name == "skewY":
            t = (1, math.tan(math.radians(v[0])), 0, 1, 0, 0)
        else:
            continue
        m = _mul(m, t)
    return m


def _ap(m, p):
    return (m[0] * p[0] + m[2] * p[1] + m[4], m[1] * p[0] + m[3] * p[1] + m[5])


def _msc(m):
    return math.sqrt(abs(m[0] * m[3] - m[1] * m[2])) or 1.0


# ---------------------------------------------------------------- colours ---
_NAMED = {"black": (0, 0, 0), "white": (255, 255, 255), "red": (255, 0, 0),
          "gray": (128, 128, 128), "grey": (128, 128, 128),
          "silver": (192, 192, 192), "lightgray": (211, 211, 211),
          "lightgrey": (211, 211, 211), "gainsboro": (220, 220, 220),
          "whitesmoke": (245, 245, 245), "darkgray": (169, 169, 169),
          "blue": (0, 0, 255), "green": (0, 128, 0), "navy": (0, 0, 128)}


def _dark(col):
    """True for ink, False for background or none."""
    if col is None:
        return False
    c = col.strip().lower()
    if c in ("none", "transparent", "") or c == GRID_GREY:
        return False
    if c == "currentcolor":
        return True
    if c.startswith("#"):
        h = c[1:]
        if len(h) == 3:
            h = "".join(ch * 2 for ch in h)
        try:
            rgb = [int(h[i:i + 2], 16) for i in (0, 2, 4)]
        except ValueError:
            return True
    elif c.startswith("rgb"):
        rgb = [float(x) for x in _NUM.findall(c)[:3]]
    elif c in _NAMED:
        rgb = _NAMED[c]
    else:
        return True
    # the same principle G72 and figkit use: the lightest channel decides
    return min(rgb) / 255.0 <= LIGHT


# ------------------------------------------------------------------ paths ---
_NUM = re.compile(r"[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?")
_PCMD = re.compile(r"([MmLlHhVvCcSsQqTtAaZz])|([-+]?(?:\d+\.?\d*|\.\d+)"
                   r"(?:[eE][-+]?\d+)?)")


def _bez(ctrl, n=10):
    out = []
    for k in range(1, n + 1):
        t = k / float(n)
        p = ctrl
        while len(p) > 1:
            p = [((1 - t) * a[0] + t * b[0], (1 - t) * a[1] + t * b[1])
                 for a, b in zip(p, p[1:])]
        out.append(p[0])
    return out


def _arc(p0, rx, ry, phi, large, sweep, p1, n=16):
    """SVG endpoint arc -> sampled points (spec F.6.5)."""
    if rx == 0 or ry == 0 or p0 == p1:
        return [p1]
    rx, ry = abs(rx), abs(ry)
    c, s = math.cos(math.radians(phi)), math.sin(math.radians(phi))
    dx, dy = (p0[0] - p1[0]) / 2.0, (p0[1] - p1[1]) / 2.0
    x1, y1 = c * dx + s * dy, -s * dx + c * dy
    lam = x1 * x1 / (rx * rx) + y1 * y1 / (ry * ry)
    if lam > 1:
        rx, ry = rx * math.sqrt(lam), ry * math.sqrt(lam)
    num = rx * rx * ry * ry - rx * rx * y1 * y1 - ry * ry * x1 * x1
    den = rx * rx * y1 * y1 + ry * ry * x1 * x1
    k = math.sqrt(max(0.0, num / den)) if den else 0.0
    if large == sweep:
        k = -k
    cx1, cy1 = k * rx * y1 / ry, -k * ry * x1 / rx
    cx = c * cx1 - s * cy1 + (p0[0] + p1[0]) / 2.0
    cy = s * cx1 + c * cy1 + (p0[1] + p1[1]) / 2.0

    def ang(ux, uy, vx, vy):
        a = math.atan2(ux * vy - uy * vx, ux * vx + uy * vy)
        return a
    t1 = ang(1, 0, (x1 - cx1) / rx, (y1 - cy1) / ry)
    dt = ang((x1 - cx1) / rx, (y1 - cy1) / ry, (-x1 - cx1) / rx, (-y1 - cy1) / ry)
    if not sweep and dt > 0:
        dt -= 2 * math.pi
    elif sweep and dt < 0:
        dt += 2 * math.pi
    out = []
    for i in range(1, n + 1):
        t = t1 + dt * i / float(n)
        x, y = rx * math.cos(t), ry * math.sin(t)
        out.append((c * x - s * y + cx, s * x + c * y + cy))
    return out


_ARGS = {"M": 2, "L": 2, "H": 1, "V": 1, "C": 6, "S": 4, "Q": 4, "T": 2,
         "A": 7, "Z": 0}
_NUMAT = re.compile(r"[\s,]*([-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?)")
_FLAGAT = re.compile(r"[\s,]*([01])")
_CMDAT = re.compile(r"[\s,]*([MmLlHhVvCcSsQqTtAaZz])")


def _path_tokens(d):
    """(command, [numbers]) in order. A cursor scanner rather than one regex:
    an arc's two flags are single characters and may be written with no
    separator ('a40 40 0 0060 0' is rx ry rot large=0 sweep=0 x=60 y=0), which
    a number regex reads as the one number 0060 and the arc was dropped."""
    out, pos, cmd, n = [], 0, None, len(d)
    while pos < n:
        m = _CMDAT.match(d, pos)
        if m:
            cmd = m.group(1)
            pos = m.end()
            if cmd in "Zz":
                out.append((cmd, []))
            continue
        if cmd is None or cmd in "Zz":
            m = _NUMAT.match(d, pos)
            if not m:
                break
            pos = m.end()               # stray number: skip it
            continue
        vals = []
        for k in range(_ARGS[cmd.upper()]):
            rx = _FLAGAT if cmd in "Aa" and k in (3, 4) else _NUMAT
            m = rx.match(d, pos)
            if not m:
                vals = None
                break
            vals.append(float(m.group(1)))
            pos = m.end()
        if vals is None:
            break
        out.append((cmd, vals))
        if cmd in "Mm":                  # implicit lineto after a moveto
            cmd = "l" if cmd == "m" else "L"
    return out


def path_polylines(d):
    """Every subpath of a `d` attribute as a list of points. Handles all
    commands, relative forms, implicit repetition and compact arc flags."""
    subs, pts = [], []
    cur, start = (0.0, 0.0), (0.0, 0.0)
    last_ctrl = None
    for cmd, v in _path_tokens(d or ""):
        if cmd in "Zz":
            if pts:
                pts.append(start)
                subs.append((pts, True))
            pts, cur, last_ctrl = [], start, None
            continue
        rel = cmd.islower()
        C = cmd.upper()
        ox, oy = (cur if rel else (0.0, 0.0))
        if C == "M":
            if pts and len(pts) > 1:
                subs.append((pts, False))
            cur = start = (ox + v[0], oy + v[1])
            pts = [cur]
            last_ctrl = None
            continue
        if not pts:
            pts = [cur]
        if C == "L":
            cur = (ox + v[0], oy + v[1])
            pts.append(cur)
            last_ctrl = None
        elif C == "H":
            cur = ((cur[0] if rel else 0.0) + v[0], cur[1])
            pts.append(cur)
            last_ctrl = None
        elif C == "V":
            cur = (cur[0], (cur[1] if rel else 0.0) + v[0])
            pts.append(cur)
            last_ctrl = None
        elif C in "CS":
            if C == "C":
                c1 = (ox + v[0], oy + v[1])
                c2, end = (ox + v[2], oy + v[3]), (ox + v[4], oy + v[5])
            else:
                c1 = (2 * cur[0] - last_ctrl[0], 2 * cur[1] - last_ctrl[1]) \
                    if last_ctrl else cur
                c2, end = (ox + v[0], oy + v[1]), (ox + v[2], oy + v[3])
            pts += _bez([cur, c1, c2, end])
            cur, last_ctrl = end, c2
        elif C in "QT":
            if C == "Q":
                c1, end = (ox + v[0], oy + v[1]), (ox + v[2], oy + v[3])
            else:
                c1 = (2 * cur[0] - last_ctrl[0], 2 * cur[1] - last_ctrl[1]) \
                    if last_ctrl else cur
                end = (ox + v[0], oy + v[1])
            pts += _bez([cur, c1, end])
            cur, last_ctrl = end, c1
        elif C == "A":
            end = (ox + v[5], oy + v[6])
            pts += _arc(cur, v[0], v[1], v[2], bool(v[3]), bool(v[4]), end)
            cur, last_ctrl = end, None
    if len(pts) > 1:
        subs.append((pts, False))
    return subs


# ------------------------------------------------------------------ model ---
class Stroke(object):
    """A dark stroked outline: `pts` a polyline; `el` the element index, so
    the pieces of one element can be told from another's."""
    __slots__ = ("pts", "closed", "el", "tag", "width", "fill", "dash")

    def __init__(self, pts, closed, el, tag, width, fill=None, dash=None):
        self.pts, self.closed, self.el, self.tag, self.width = \
            pts, closed, el, tag, width
        # v6 C5: the resolved stroke-dasharray ("4,2"), None when solid -- a
        # dashed alignment connector or reference line is another object
        # than a tick or a span (doctrine 8)
        self.dash = dash
        # v6 C3 (E8): the resolved fill, so a white-filled marker can be told
        # from a hollow ring with the paper (and any line) showing through
        self.fill = fill

    def segs(self):
        s = list(zip(self.pts, self.pts[1:]))
        if self.closed and len(self.pts) > 2 and self.pts[0] != self.pts[-1]:
            s.append((self.pts[-1], self.pts[0]))
        return s


class Run(object):
    __slots__ = ("text", "size", "box", "ink")

    def __init__(self, text, size, box, ink=None):
        self.text, self.size, self.box = text, size, box
        # a run of digits (a number): its ink box, padded; None otherwise
        self.ink = ink


class Text(object):
    __slots__ = ("text", "runs", "box", "size", "el")

    def __init__(self, text, runs, size, el):
        self.text, self.runs, self.size, self.el = text, runs, size, el
        bs = [r.box for r in runs if r.text.strip()]
        self.box = (min(b[0] for b in bs), min(b[1] for b in bs),
                    max(b[2] for b in bs), max(b[3] for b in bs)) if bs else None

    def centre(self):
        b = self.box
        return ((b[0] + b[2]) / 2.0, (b[1] + b[3]) / 2.0)


class Model(object):
    def __init__(self):
        self.projected = False   # v6.4: drawn in a declared projection
        self.strokes = []    # Stroke
        self.fills = []      # (pts, closed, el) dark filled regions
        self.dots = []       # (cx, cy, r, el) dark filled circles
        self.texts = []      # Text
        # C2 round 3: light straight lines (a grid), kept only so an axis with
        # fewer than three tick marks can still be measured by its grid
        self.light = []      # (a, b)
        # v6 C5: light-filled closed shapes with no dark outline (a zoom's
        # highlighted segment), kept so a sweep can read where they stand
        self.shades = []     # pts
        self.pt_per_unit = PX_TO_PT
        self.view = None
        # P3 leftovers r1 (critique-line-trips-the-sweep-it-should-pass): a
        # figure that DECLARES a deliberate error (numberline's
        # student_drawing= / wrong_scale=, emitted as <!--critique:...-->)
        # says so in the file, so a sweep run on the finished string knows
        # it without being told.
        self.critique = False

    def dark_segs(self):
        out = []
        for s in self.strokes:
            out += [(a, b, s.el) for a, b in s.segs()]
        for pts, closed, el in self.fills:
            ss = list(zip(pts, pts[1:]))
            if closed and len(pts) > 2:
                ss.append((pts[-1], pts[0]))
            out += [(a, b, el) for a, b in ss]
        return out


_INHERIT = ("stroke", "fill", "stroke-width", "font-size", "text-anchor",
            "stroke-dasharray")


def _length(v, default=None, parent=None):
    """A CSS length in user units: px or none as is, pt/mm/cm/in/pc
    converted; em and % relative to `parent` (the inherited font size) when
    given. `font-size="4pt"` is 5.33 units, not 4; `50%` of 12 is 6, not 50."""
    if v is None:
        return default
    m = _NUM.match(str(v).strip())
    if not m:
        return default
    x = float(m.group(0))
    u = str(v).strip()[m.end():].strip().lower()
    if u in ("%", "em", "rem", "ex"):
        if parent is None:
            return default
        return x * parent * {"%": 0.01, "em": 1.0, "rem": 1.0, "ex": 0.5}[u]
    return x * {"pt": 1 / PX_TO_PT, "mm": 96 / 25.4, "cm": 96 / 2.54,
                "in": 96.0, "pc": 16.0}.get(u, 1.0)


def model(svg):
    root = parse(svg)
    M = Model()
    # a figure that declares a deliberate error says so in the file
    M.critique = isinstance(svg, str) and "<!--critique:" in svg
    # v6.4: a figure drawn in a PROJECTION says so (solidkit writes
    # `<!--proj:cabinet45:right-->`). A projected drawing's 2D angles and
    # lengths are not its claims — a box's real 90° at C prints 117°, and its
    # equal edges print unequal — so the sweeps that read a 2D value as the
    # claim are delegated to the 3D reader (STAGE2_DESIGN S2.3). Everything
    # about SIZE and SPACING (tick length, tick gap, font floor, ownership,
    # struck labels) runs unchanged.
    M.projected = isinstance(svg, str) and "<!--proj:" in svg
    # v6.3: the tag may NAME what is deliberately wrong
    # (`<!--critique:find_error:marks-->`, written by generate.violate), and
    # problems() then requires that error to be there. A tag that names
    # nothing (numberline's `critique:find_error`) keeps its old meaning
    # exactly.
    _ck = re.search(r"<!--critique:([^>]*?)-->", svg) \
        if isinstance(svg, str) else None
    M.critique_kind = _ck.group(1) if _ck else ""
    svgs = [c for c in root.children if c.tag == "svg"] or \
        [n for n in _walk(root) if n.tag == "svg"]
    top = svgs[0] if svgs else root
    vb = top.attrs.get("viewBox")
    if vb:
        v = [float(x) for x in _NUM.findall(vb)]
        if len(v) == 4 and v[2] > 0:
            M.view = tuple(v)
            w = top.attrs.get("width")
            wpt = top.attrs.get("width", "")
            disp = _length(w, v[2])
            if wpt.strip().endswith("%"):
                disp = v[2]
            M.pt_per_unit = disp / v[2] * PX_TO_PT
    elif top.attrs.get("width"):
        M.pt_per_unit = PX_TO_PT
    counter = [0]
    ids = dict((n.attrs["id"], n) for n in _walk(root) if "id" in n.attrs)

    def visit(ch, mat, inh, depth):
        a = ch.attrs
        if "ink-copy" in (a.get("class") or ""):
            # v6.8 G1: an exact overdraw that carries an export id ON INK (a
            # polygon's edge, a solid's vertex). The stroke it copies is read
            # already; reading it again would count the same ink twice.
            return
        counter[0] += 1
        el = counter[0]
        st = dict(inh)
        for k in _INHERIT:
            if k in a:
                st[k] = a[k]
        if "font-size" in a:
            st["font-size"] = repr(_length(a["font-size"], _f(inh, "font-size", 16.0),
                                           _f(inh, "font-size", 16.0)))
        if "stroke-width" in a:
            st["stroke-width"] = repr(_length(a["stroke-width"], 1.0))
        m = _mul(mat, _parse_transform(a.get("transform"))) \
            if "transform" in a else mat
        tag = ch.tag.split(":")[-1]
        if tag in ("defs", "clipPath", "mask", "marker", "symbol",
                   "title", "desc", "style", "metadata"):
            return
        if tag == "use":
            # <use href="#id"> draws the referenced element here, shifted by
            # x/y. Ignored, a line defined once and reused was invisible ink.
            ref = ids.get((a.get("href") or a.get("xlink:href") or "")
                          .lstrip("#"))
            if ref is not None and depth < 8:
                m2 = _mul(m, (1, 0, 0, 1, _f(a, "x"), _f(a, "y")))
                if ref.tag.split(":")[-1] == "symbol":
                    walk(ref, m2, st, depth + 1)
                else:
                    visit(ref, m2, st, depth + 1)
            return
        if tag == "text":
            _text(M, ch, m, st, el)
            return
        _shape(M, tag, a, m, st, el)
        if depth < 8:
            _markers(ch, tag, a, m, st, depth)
        walk(ch, m, st, depth)

    def _markers(ch, tag, a, m, st, depth):
        """marker-start / marker-mid / marker-end draw their <marker> at the
        path's vertices, turned to the path (orient="auto"). An arrowhead
        written as a marker was invisible to every sweep."""
        want = [(k, (a.get(k) or "")) for k in
                ("marker-start", "marker-mid", "marker-end")]
        want = [(k, re.search(r"#([^)\s\"']+)", v)) for k, v in want]
        want = [(k, ids.get(g.group(1))) for k, g in want if g]
        want = [(k, n) for k, n in want if n is not None]
        if not want:
            return
        if tag == "line":
            lines = [[(_f(a, "x1"), _f(a, "y1")), (_f(a, "x2"), _f(a, "y2"))]]
        elif tag in ("polyline", "polygon"):
            v = [float(x) for x in _NUM.findall(a.get("points", ""))]
            lines = [list(zip(v[0::2], v[1::2]))]
        elif tag == "path":
            lines = [p for p, _ in path_polylines(a.get("d", ""))]
        else:
            return
        sw = _f(st, "stroke-width", 1.0)
        for kind, mk in want:
            ma = mk.attrs
            for pts in lines:
                if len(pts) < 2:
                    continue
                if kind == "marker-start":
                    spots = [(pts[0], pts[0], pts[1], True)]
                elif kind == "marker-end":
                    spots = [(pts[-1], pts[-2], pts[-1], False)]
                else:
                    spots = [(pts[k], pts[k - 1], pts[k], False)
                             for k in range(1, len(pts) - 1)]
                for at, p0, p1, start in spots:
                    orient = (ma.get("orient") or "0").strip()
                    if orient.startswith("auto"):
                        ang = math.degrees(math.atan2(p1[1] - p0[1],
                                                      p1[0] - p0[0]))
                        if start and orient == "auto-start-reverse":
                            ang += 180.0
                    else:
                        ang = _f(ma, "orient")
                    k = 1.0 if ma.get("markerUnits") == "userSpaceOnUse" else sw
                    vb = [float(x) for x in _NUM.findall(ma.get("viewBox", ""))]
                    sx = sy = 1.0
                    if len(vb) == 4 and vb[2] > 0 and vb[3] > 0:
                        sx = _f(ma, "markerWidth", 3.0) / vb[2]
                        sy = _f(ma, "markerHeight", 3.0) / vb[3]
                    r = math.radians(ang)
                    t = _mul((1, 0, 0, 1, at[0], at[1]),
                             (math.cos(r), math.sin(r), -math.sin(r),
                              math.cos(r), 0, 0))
                    t = _mul(t, (k * sx, 0, 0, k * sy, 0, 0))
                    t = _mul(t, (1, 0, 0, 1, -_f(ma, "refX"), -_f(ma, "refY")))
                    walk(mk, _mul(m, t), dict(_BASE_STYLE), depth + 1)

    def walk(node, mat, inh, depth=0):
        for ch in node.children:
            visit(ch, mat, inh, depth)

    base = dict(_BASE_STYLE)
    if top is not root:
        # the root <svg> passes its presentation attributes down like any
        # group: <svg font-size="6"> prints its text at 6 (stage-1 open issue)
        for k in _INHERIT:
            if k in top.attrs:
                base[k] = top.attrs[k]
        if "font-size" in top.attrs:
            base["font-size"] = repr(_length(top.attrs["font-size"], 16.0, 16.0))
    walk(top if top is not root else root, _ID, base)
    return M


_BASE_STYLE = {"fill": None, "stroke": None, "stroke-width": "1",
               "font-size": "16", "text-anchor": "start"}


def _walk(n):
    for c in n.children:
        yield c
        for x in _walk(c):
            yield x


def _f(a, k, d=0.0):
    try:
        return float(_NUM.match(a.get(k, "").strip()).group(0))
    except (AttributeError, ValueError):
        return d


def _shape(M, tag, a, m, st, el):
    # Hand-written SVG often names neither stroke nor fill. Read literally that
    # is a black FILL, but the author meant a line (`<path d="M.. C..">` for a
    # curve) and that is how every earlier sweep read it; a circle with
    # neither is the house way of writing a dot, so it stays a filled disc.
    unset = st.get("stroke") is None and st.get("fill") is None
    stroke_dark = _dark(st.get("stroke")) or (unset and tag != "circle")
    fill_dark = _dark(st.get("fill")) or (unset and tag == "circle")
    sw = _f(st, "stroke-width", 1.0) * _msc(m)
    polys = []                                     # (pts, closed)
    if tag == "line":
        polys.append(([(_f(a, "x1"), _f(a, "y1")), (_f(a, "x2"), _f(a, "y2"))],
                      False))
        fill_dark = False
    elif tag in ("polyline", "polygon"):
        v = [float(x) for x in _NUM.findall(a.get("points", ""))]
        pts = list(zip(v[0::2], v[1::2]))
        if len(pts) >= 2:
            polys.append((pts, tag == "polygon"))
        if tag == "polyline":
            fill_dark = fill_dark and False
    elif tag == "rect":
        x, y, w, h = _f(a, "x"), _f(a, "y"), _f(a, "width"), _f(a, "height")
        if w > 0 and h > 0:
            polys.append(([(x, y), (x + w, y), (x + w, y + h), (x, y + h)], True))
    elif tag == "path":
        polys += path_polylines(a.get("d", ""))
    elif tag in ("circle", "ellipse"):
        cx, cy = _f(a, "cx"), _f(a, "cy")
        rx = _f(a, "rx", _f(a, "r")) if tag == "ellipse" else _f(a, "r")
        ry = _f(a, "ry", _f(a, "r")) if tag == "ellipse" else _f(a, "r")
        if rx <= 0 or ry <= 0:
            return
        ring = [_ap(m, (cx + rx * math.cos(2 * math.pi * i / 48.0),
                        cy + ry * math.sin(2 * math.pi * i / 48.0)))
                for i in range(48)]
        if stroke_dark:
            M.strokes.append(Stroke(ring, True, el, tag, sw, st.get("fill"),
                                    _dash(st)))
        if fill_dark:
            c = _ap(m, (cx, cy))
            M.dots.append((c[0], c[1], max(rx, ry) * _msc(m), el))
        return
    else:
        return
    for pts, closed in polys:
        tp = [_ap(m, p) for p in pts]
        if not stroke_dark and tag == "line" and \
                (st.get("stroke") or "none").strip().lower() != "none":
            M.light.append((tp[0], tp[1]))
        if stroke_dark:
            M.strokes.append(Stroke(tp, closed, el, tag, sw, st.get("fill"),
                                    _dash(st)))
        if fill_dark and tag != "line" and len(tp) >= 3:
            M.fills.append((tp, True, el))
        elif not stroke_dark and tag != "line" and len(tp) >= 3 and closed and \
                _light_fill(st.get("fill")):
            M.shades.append(tp)


def _dash(st):
    d = (st.get("stroke-dasharray") or "").strip().lower()
    return None if d in ("", "none") or not _NUM.search(d) or \
        all(float(x) == 0 for x in _NUM.findall(d)) else d


def _light_fill(col):
    """A visible fill that is not ink: grey, not none / white / dark."""
    if col is None or _dark(col):
        return False
    c = col.strip().lower()
    return c not in ("none", "transparent", "", "#fff", "#ffffff", "white")


def _text(M, node, m, st, el):
    """A <text> as runs: each tspan keeps its own size and baseline shift, so
    a superscript is measured where and how big it prints."""
    x0 = _f(node.attrs, "x")
    y0 = _f(node.attrs, "y")
    anchor = st.get("text-anchor", "start")
    size0 = _f(st, "font-size", 16.0)
    chunks = [[]]                        # list of runs (text, size, dy_total)
    state = {"dy": _f(node.attrs, "dy"), "dx": _f(node.attrs, "dx"),
             "x": x0, "y": y0}

    def add(txt, size):
        if txt:
            chunks[-1].append([txt, size, state["x"], state["y"] + state["dy"],
                               state["dx"]])
            state["dx"] = 0.0

    def rec(n, size, is_root):
        if is_root:
            add(n.text, size)
        for c in n.children:
            if c.tag.split(":")[-1] != "tspan":
                continue
            sz = _length(c.attrs["font-size"], size, size) \
                if "font-size" in c.attrs else size
            if "x" in c.attrs or "y" in c.attrs:
                chunks.append([])
                state["x"] = _f(c.attrs, "x", state["x"])
                state["y"] = _f(c.attrs, "y", state["y"])
                state["dy"] = 0.0
            state["dy"] += _f(c.attrs, "dy")
            state["dx"] += _f(c.attrs, "dx")
            add(c.text, sz)
            rec(c, sz, False)
            add(c.tail, size)
    rec(node, size0, True)
    runs, full = [], []
    for ch in chunks:
        if not ch:
            continue
        widths = [len(t) * CHAR_W * s for t, s, _, _, _ in ch]
        total = sum(widths) + sum(r[4] for r in ch)
        start = ch[0][2] - (total / 2.0 if anchor == "middle"
                            else total if anchor == "end" else 0.0)
        cx = start
        for (t, s, _, base, dx), w in zip(ch, widths):
            cx += dx
            box = (cx, base - ASC * s, cx + w, base + DESC * s)

            def tbox(box):
                c = [_ap(m, (box[0], box[1])), _ap(m, (box[2], box[3])),
                     _ap(m, (box[0], box[3])), _ap(m, (box[2], box[1]))]
                return (min(p[0] for p in c), min(p[1] for p in c),
                        max(p[0] for p in c), max(p[1] for p in c))
            ink = None
            if len(ch) == 1 and t.strip() and all(k in NUM_ADV for k in t.strip()):
                # a number alone in its chunk: the advance of its own glyphs,
                # placed by the same anchor as the text box
                ts = t.strip()
                iw = sum(NUM_ADV[k] for k in ts) * s
                ix = cx + (w - iw) / 2.0 if anchor == "middle" else \
                    (cx + w - iw if anchor == "end" else cx)
                pd = NUM_PAD_EM * s
                bot = NUM_BOT_COMMA if "," in ts else NUM_BOT
                if t == ts:
                    ink = tbox((ix - pd, base - NUM_TOP * s - pd,
                                ix + iw + pd, base + bot * s + pd))
            runs.append(Run(t, s * _msc(m), tbox(box), ink))
            full.append(t)
            cx += w
    if runs and "".join(full).strip():
        M.texts.append(Text("".join(full), runs, size0 * _msc(m), el))


# --------------------------------------------------------------- geometry ---
def _seg_box(p, q, box):
    x0, y0, x1, y1 = box
    if max(p[0], q[0]) < x0 or min(p[0], q[0]) > x1:
        return False
    if max(p[1], q[1]) < y0 or min(p[1], q[1]) > y1:
        return False
    dx, dy = q[0] - p[0], q[1] - p[1]
    t0, t1 = 0.0, 1.0
    for pk, qk in ((-dx, p[0] - x0), (dx, x1 - p[0]),
                   (-dy, p[1] - y0), (dy, y1 - p[1])):
        if abs(pk) < 1e-12:
            if qk < 0:
                return False
        else:
            t = qk / pk
            if pk < 0:
                if t > t1:
                    return False
                t0 = max(t0, t)
            else:
                if t < t0:
                    return False
                t1 = min(t1, t)
    return t0 <= t1


def _disk_box(cx, cy, r, box):
    nx = min(max(cx, box[0]), box[2])
    ny = min(max(cy, box[1]), box[3])
    return math.hypot(cx - nx, cy - ny) < r


def _pt_seg(p, a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    L2 = dx * dx + dy * dy
    t = 0.0 if L2 == 0 else max(0.0, min(1.0, ((p[0] - a[0]) * dx +
                                               (p[1] - a[1]) * dy) / L2))
    return math.hypot(p[0] - a[0] - t * dx, p[1] - a[1] - t * dy)


def _box_seg_dist(box, a, b):
    if _seg_box(a, b, box):
        return 0.0
    cs = [(box[0], box[1]), (box[2], box[1]), (box[2], box[3]), (box[0], box[3])]
    d = min(_pt_seg(c, a, b) for c in cs)
    for e in zip(cs, cs[1:] + cs[:1]):
        d = min(d, _pt_seg(a, *e), _pt_seg(b, *e))
    return d


def _in_poly(pt, pts):
    x, y = pt
    inside, j = False, len(pts) - 1
    for i in range(len(pts)):
        xi, yi = pts[i]
        xj, yj = pts[j]
        if (yi > y) != (yj > y) and \
                x < xi + (y - yi) * (xj - xi) / ((yj - yi) or 1e-12):
            inside = not inside
        j = i
    return inside


def _M(svg):
    return svg if isinstance(svg, Model) else model(svg)


# ----------------------------------------------------------------- sweeps ---
def blocks(svg):
    """The top-level <svg>...</svg> blocks of a string (an HTML row holds
    several). Nested <svg> elements stay inside their parent's block."""
    out, depth, start = [], 0, None
    for m in re.finditer(r"<(/?)svg\b[^>]*?(/?)>", svg):
        if m.group(1):
            if depth > 0:
                depth -= 1
                if depth == 0:
                    out.append(svg[start:m.end()])
        elif not m.group(2):
            if depth == 0:
                start = m.start()
            depth += 1
    if depth > 0 and start is not None:          # an unclosed fragment
        out.append(svg[start:])
    return out


def _per_block(fn):
    """A sweep handed several figures (a figkit_plus.row, concatenated SVGs)
    runs once per <svg>. model() reads one figure's coordinate system, so a
    struck label in the second figure of a row used to pass unseen."""
    def run(svg, *a, **kw):
        if not isinstance(svg, Model):
            bl = blocks(svg)
            if len(bl) > 1:
                out = []
                for b in bl:
                    out += fn(b, *a, **kw)
                return out
        return fn(svg, *a, **kw)
    run.__name__, run.__doc__ = fn.__name__, fn.__doc__
    return run


@_per_block
def struck(svg):
    """Texts with dark ink through any of their runs, as their full strings.
    A stroke is as wide as it is drawn: a run is struck when the ink's EDGE
    reaches it, not only its centre line. A run that is a number is read by
    its padded ink box (Run.ink, see the module docstring), any other run by
    its 0.58 x 1.02 em text box."""
    M = _M(svg)
    segs = [(a, b, s.width / 2.0) for s in M.strokes for a, b in s.segs()]
    for pts, closed, el in M.fills:
        ss = list(zip(pts, pts[1:]))
        if closed and len(pts) > 2:
            ss.append((pts[-1], pts[0]))
        segs += [(a, b, 0.0) for a, b in ss]
    bad = []
    for T in M.texts:
        hit = False
        for r in T.runs:
            if not r.text.strip():
                continue
            b = r.ink or r.box
            if any(_seg_box(p, q, (b[0] - h, b[1] - h, b[2] + h, b[3] + h))
                   for p, q, h in segs) or \
                    any(_disk_box(cx, cy, rr, b) for cx, cy, rr, _ in M.dots) or \
                    any(_in_poly(((b[0] + b[2]) / 2, (b[1] + b[3]) / 2), pts)
                        for pts, _, _ in M.fills):
                hit = True
                break
        if hit:
            bad.append(T.text)
    return bad


def stroke_length(svg):
    """Total length of dark stroked ink, in user units, summed over every
    <svg> block (E4: figkit.Figure.check_complete compares it with what the
    figure was asked to draw, so a deleted edge cannot pass as a cut)."""
    if not isinstance(svg, Model):
        bl = blocks(svg)
        if len(bl) > 1:
            return sum(stroke_length(b) for b in bl)
    M = _M(svg)
    return sum(math.hypot(b[0] - a[0], b[1] - a[1])
               for s in M.strokes for a, b in s.segs())


# ------------------------------------------- v6 stage 1b: lost ink --------
LOST_GAP_EM = 3.2         # a gap wider than this is two objects, not one cut
LOST_MIN_PT = 0.6         # a gap narrower than this is a join, not a cut
LOST_PIECE_PT = 1.5       # both sides must be real strokes, not stubs
DRAWS = 0.995             # emitted dark ink / the geometry handed in


def _collinear_runs(M):
    """Maximal dark polylines, as (direction, offset, [(t0, t1, width)]) per
    straight line they lie on. Only STRAIGHT pieces are grouped: a curve's
    chain of short chords is collinear with nothing."""
    lines = {}
    for s in M.strokes:
        if s.dash:                     # a dashed stroke is gaps by design
            continue
        for a, b in s.segs():
            dx, dy = b[0] - a[0], b[1] - a[1]
            L = math.hypot(dx, dy)
            if L < 1e-9:
                continue
            ux, uy = dx / L, dy / L
            if ux < 0 or (abs(ux) < 1e-12 and uy < 0):
                ux, uy = -ux, -uy
            off = a[0] * (-uy) + a[1] * ux
            key = (round(ux, 3), round(uy, 3), round(off, 1))
            t0 = a[0] * ux + a[1] * uy
            t1 = b[0] * ux + b[1] * uy
            lines.setdefault(key, []).append((min(t0, t1), max(t0, t1),
                                              s.width, s.el))
    return lines


LOST_TURN = 8.0           # a piece that bends this much is a curve, not a line
LOST_LEAN = 75.0          # how far either end may lean off the chord between
#                           them (degrees) and still read as one curve's arc
LOST_LEAN_GAP = 30.0      # ... and how much the two leans may differ


def _turn(pts):
    """How much a polyline bends, end to end, in degrees."""
    if len(pts) < 3:
        return 0.0
    a = math.atan2(pts[1][1] - pts[0][1], pts[1][0] - pts[0][0])
    b = math.atan2(pts[-1][1] - pts[-2][1], pts[-1][0] - pts[-2][0])
    d = math.degrees(abs(a - b)) % 360.0
    return min(d, 360.0 - d)


def _back(pts, want):
    """Three points at the END of a polyline, spread at least `want` apart, so
    the local bend is measured over real distance and not over two samples a
    tenth of a pixel apart."""
    out = [pts[-1]]
    acc = 0.0
    for p, q in zip(reversed(pts[:-1]), reversed(pts[1:])):
        acc += math.hypot(q[0] - p[0], q[1] - p[1])
        if acc >= want * len(out):
            out.append(p)
            if len(out) == 3:
                break
    return out if len(out) == 3 else None


def _tangent(pts, d):
    """The unit direction of travel at the END of a polyline, measured over a
    baseline of about half the gap so one sub-pixel sample cannot set it."""
    got = _back(pts, max(d * 0.5, 2.0))
    if not got:
        return None
    (x2, y2), (x1, y1), _ = got
    L = math.hypot(x2 - x1, y2 - y1)
    return ((x2 - x1) / L, (y2 - y1) / L) if L > 1e-9 else None


def _turned(u, v):
    """Signed angle from u to v, in degrees."""
    return math.degrees(math.atan2(u[0] * v[1] - u[1] * v[0],
                                   u[0] * v[0] + u[1] * v[1]))


def _broken_curves(M, em, unit_pt, gap_em):
    """v6 stage 1b r2: a CURVED stroke printed in two pieces.

    lost_ink's first half only groups pieces that lie on one straight LINE, so
    the second of the two defects the chunk exists to kill -- the gap in F4's
    parabola -- was invisible to the independent gate, and only figkit's own
    length bookkeeping (Figure.check_complete) covered it. Here two bending
    pieces of the same width whose ends AIM AT EACH OTHER across a small gap
    are one curve that lost a piece. A curve that leaves the window and comes
    back is two pieces far apart; two arcs of a mark bend away from each
    other; a gap holding a dot or an arrowhead is the one a chain is drawn
    with, and is left alone."""
    out = []
    # stage-1 fix r1: a CLOSED outline (a ring marker, a circle, a closed
    # polygon) has no ends to lose a piece between -- the rims of two open
    # markers a square apart were read as one curve with a hole and a figure
    # with no curve at all was refused
    ss = [s for s in M.strokes if not s.dash and len(s.pts) >= 3 and
          not s.closed and math.hypot(s.pts[0][0] - s.pts[-1][0],
                                      s.pts[0][1] - s.pts[-1][1]) > 1e-6]
    lens = [sum(math.hypot(b[0] - a[0], b[1] - a[1]) for a, b in s.segs())
            for s in ss]
    tips = _arrows(M)[0] if len(ss) > 1 else []
    for i in range(len(ss)):
        for j in range(i + 1, len(ss)):
            A, B = ss[i], ss[j]
            if abs(A.width - B.width) > 0.05:
                continue
            # two STRAIGHT pieces on one line are the first half's business
            # (it asks for a number in the hole); at least one of these bends
            if max(_turn(A.pts), _turn(B.pts)) < LOST_TURN:
                continue
            if min(lens[i], lens[j]) * unit_pt < LOST_PIECE_PT:
                continue
            for pa, pb in ((A.pts[0], B.pts[0]), (A.pts[0], B.pts[-1]),
                           (A.pts[-1], B.pts[0]), (A.pts[-1], B.pts[-1])):
                gap = math.hypot(pb[0] - pa[0], pb[1] - pa[1])
                if gap * unit_pt < LOST_MIN_PT:
                    continue
                # v6 stage 1b r3: the gap cap is what a NUMBER's plate could
                # have taken out, and it kept a 48pt hole cut out of F4's
                # parabola off the report. Two pieces of the SAME <path> are
                # not two objects that happen to line up -- every builder
                # here emits one subpath per curve -- so for them the cap is
                # only the 0.6-of-a-piece test below.
                if gap > gap_em * em and A.el != B.el:
                    continue
                if gap > 0.6 * min(lens[i], lens[j]):
                    continue
                # The gap must read as a SECANT of one smooth curve: the two
                # ends must lean the same way off the chord and by nearly the
                # same angle, as the ends of any arc do. Two objects that
                # merely stop near each other (a parabola's end and a line's,
                # two arcs of a mark) do not: the chord runs backwards along
                # one of them, or the two leans disagree.
                pas = A.pts if pa is A.pts[-1] else list(reversed(A.pts))
                pbs = B.pts if pb is B.pts[-1] else list(reversed(B.pts))
                ua, t = _tangent(pas, gap), _tangent(pbs, gap)
                if not ua or not t:
                    continue
                ub = (-t[0], -t[1])            # travel resumes into B here
                c = ((pb[0] - pa[0]) / gap, (pb[1] - pa[1]) / gap)
                al, be = _turned(c, ua), _turned(ub, c)
                if max(abs(al), abs(be)) > LOST_LEAN or \
                        abs(al - be) > LOST_LEAN_GAP:
                    continue
                mid = (0.5 * (pa[0] + pb[0]), 0.5 * (pa[1] + pb[1]))
                # v6 stage 1b r3: a dot (or, below, an arrowhead) explains a
                # hole only while it could FILL it. The reach grew with the
                # gap, so a 2.4-unit plotted point excused a 48pt hole cut
                # out of F4's parabola around it -- the very defect this
                # chunk exists to end, standing where the cut was made.
                if any(math.hypot(cx - mid[0], cy - mid[1])
                       <= r + gap / 2.0 + 1.0 and gap <= 2.0 * r + gap_em * em
                       for cx, cy, r, _ in M.dots):
                    continue
                if any(_in_poly(mid, pts) for pts, _, _ in M.fills):
                    continue
                # An ARROWHEAD in the hole explains it: that is how a chain of
                # jumps is drawn -- one arc arrives, the head is drawn, the
                # next arc leaves -- and the two arcs lean off their chord
                # exactly as one arc would. A tick or an axis crossing the
                # hole explains nothing: a number stands at a tick, which is
                # precisely where a cut used to be made.
                if any(math.hypot(tip[0] - mid[0], tip[1] - mid[1])
                       <= gap / 2.0 + hl and gap <= 2.0 * hl + gap_em * em
                       for tip, _t, _i, hl, _w in tips):
                    continue
                # v6 P2 (C7r3-P1): two COMPLETE arrows -- each piece carries
                # a head at its far end and none at the gap -- are two jumps
                # leaving one point (a fan sent over and under its line), not
                # one curve with a hole: a cut stroke keeps at most the heads
                # the whole stroke had, one per end. Refusing them left
                # 'drop a jump' as the only way out.
                fa = A.pts[0] if pa is A.pts[-1] else A.pts[-1]
                fb = B.pts[0] if pb is B.pts[-1] else B.pts[-1]

                def headed(e):
                    return any(math.hypot(tip[0] - e[0], tip[1] - e[1]) <= hl + 1.5
                               for tip, _t, _i, hl, _w in tips)
                if headed(fa) and headed(fb) and not headed(pa) and \
                        not headed(pb):
                    continue
                out.append(
                    "a curve is printed in two pieces with a %.1fpt gap at "
                    "(%.1f, %.1f) — the two ends run into each other, so "
                    "this is one stroke that lost a piece. A line, an "
                    "edge, a curve or a rim is never cut, broken or "
                    "shortened (v6 stage 1b); move whatever the hole was "
                    "made for, or give the figure more room."
                    % (gap * unit_pt, mid[0], mid[1]))
                return out            # one is enough to refuse the file
    return out


def lost_ink(svg, gap_em=LOST_GAP_EM):
    """v6 stage 1b: a data stroke printed in PIECES, with a gap between them.

    Independent of every builder: it reads the finished file. Two dark pieces
    that lie on the SAME straight line, of the same width, with a gap between
    them no wider than `gap_em` of the figure's text, are one stroke that was
    cut -- the defect the comparison found in F5 (two sides of a triangle in
    pieces around a number) and F4 (a gap in the parabola). Since v6 stage 1b
    nothing may cut a stroke, so this is always a defect.

    A dashed stroke is skipped (its gaps are the dash), and so is a gap wider
    than `gap_em` (two separate segments of a figure, drawn on one line on
    purpose). A label standing in the gap is named, because that is what the
    cut was made for."""
    M = _M(svg)
    em = max([T.size for T in M.texts] or [10.0]) or 10.0
    unit_pt = M.pt_per_unit
    out = []
    for (ux, uy, _off), runs in sorted(_collinear_runs(M).items()):
        runs = sorted(runs)
        merged = []
        for t0, t1, w, el in runs:
            if merged and t0 <= merged[-1][1] + 1e-6 and \
                    abs(w - merged[-1][2]) < 0.05:
                merged[-1] = (merged[-1][0], max(merged[-1][1], t1),
                              merged[-1][2])
            else:
                merged.append((t0, t1, w))
        # P1: the pieces of ONE stroke are compared with each other, whatever
        # thinner ink stands between them -- at the house look a tick mark
        # (0.6pt) sits right in the hole cut in a 1pt line beside the y-axis,
        # and comparing only neighbours in order let that cut through
        pairs = []
        for w in sorted(set(round(m[2], 2) for m in merged)):
            same = [m for m in merged if abs(m[2] - w) < 0.05]
            pairs += list(zip(same, same[1:]))
        for (a0, a1, aw), (b0, b1, bw) in pairs:
            gap = b0 - a1
            if abs(aw - bw) > 0.05 or gap * unit_pt < LOST_MIN_PT:
                continue
            if gap > gap_em * em:
                continue
            if min(a1 - a0, b1 - b0) * unit_pt < LOST_PIECE_PT:
                continue
            mid = ((a1 + b0) / 2.0 * ux - _off * uy,
                   (a1 + b0) / 2.0 * uy + _off * ux)
            # what the gap was made FOR, and is allowed to hold: a plotted
            # point an arrow stops short of, or an arrowhead between two
            # shafts of a chain (figkit_plus.stop_short draws exactly that)
            if any(math.hypot(cx - mid[0], cy - mid[1]) <= r + gap / 2.0 + 1.0
                   for cx, cy, r, _ in M.dots):
                continue
            if any(_in_poly(mid, pts) or
                   min(math.hypot(q[0] - mid[0], q[1] - mid[1]) for q in pts)
                   <= gap / 2.0 + 1.0 for pts, _, _ in M.fills):
                continue
            # Two SHAPES that happen to share a line (the two triangles of a
            # congruence pair on one baseline) are not one cut stroke: a cut
            # takes a number's width out of a long stroke, so the hole is
            # small beside the pieces it left, and a label stands in it.
            if gap > 0.6 * min(a1 - a0, b1 - b0):
                continue
            ga = (a1 * ux - _off * uy, a1 * uy + _off * ux)
            gb = (b0 * ux - _off * uy, b0 * uy + _off * ux)
            # ... and the thing in the hole is a LABEL whose plate is about
            # as wide as the hole: that is what a cut behind a tick number
            # looks like, and it is the only cut the engine ever made.
            # C6 r5: any label but a lone POINT NAME. A cut made behind a
            # value label ('x+1', '5 cm') or a segment's name is the same lost
            # ink as one behind a number, and this file-level sweep is the only
            # guard that would see one come back (Label.cut is off today). A
            # single vertex letter is the one label that legitimately stands
            # in such a hole: two shapes on one baseline (euclid's congruence
            # pair) leave exactly a letter-wide gap with 'B' in it, and nothing
            # in the file tells that apart from a cut behind 'B'.
            who = None
            for T in M.texts:
                if not (T.box and T.text.strip()) or \
                        _POINT_NAME.match(T.text.strip()):
                    continue
                if not _seg_box(ga, gb, T.box):
                    continue
                span = abs(T.box[2] - T.box[0]) * abs(ux) + \
                    abs(T.box[3] - T.box[1]) * abs(uy)
                if gap <= span + 1.0 * T.size:
                    who = T.text
                    break
            if who is None:
                continue
            out.append(
                "a stroke is printed in two pieces with a %.1fpt gap at "
                "(%.1f, %.1f), behind the label %r — a line, an edge, a curve "
                "or a rim is never cut, broken or shortened by a label (v6 "
                "stage 1b). Move the number (the engine slides it, crosses "
                "its axis or steps it out), number every 2 squares, or give "
                "the figure more room; never cut the stroke and never drop "
                "the number." % (gap * unit_pt, mid[0], mid[1], who))
    return out + _broken_curves(M, em, unit_pt, gap_em)


COVER_NEAR = 1.2          # how near dark ink must pass to cover a point
_COVER_PTS = 900          # sample points one call spends on the geometry


def covers(svg, geometry, least=DRAWS, near=COVER_NEAR):
    """v6 stage 1b r3: every stretch of the geometry has ink ON it.

    The length test below compares two TOTALS, so ink the builder never
    asked for -- the axes, the ticks, an arrowhead -- pays for a piece that
    went missing: a hole cut out of the middle of F4's parabola left the sum
    of dark ink far above 99.5% of the curve's own length, and `draws` saw
    nothing. This walks the geometry instead and asks, at every step, whether
    any dark segment passes within `near`. Uncovered stretches are added up
    and named by where they start, so the message points at the hole.

    Multi-block SVGs are left to the length test: the geometry belongs to one
    figure and there is no way to tell which block it was drawn in."""
    want = sum(math.hypot(q[0] - p[0], q[1] - p[1]) for p, q in geometry)
    if want <= 0 or len(blocks(svg) if not isinstance(svg, Model) else [1]) > 1:
        return []
    M = _M(svg)
    dark = M.dark_segs()
    # C6 r6: an AXIS line is not ink that draws the data. Counted, it covered
    # every edge lying along it -- a right triangle at the origin with both
    # legs deleted printed only its hypotenuse and draws() called it whole.
    # The axis is the element that runs the found axis end to end; an edge
    # drawn along it is its own element and still covers itself.
    axis_els = set()
    for ax in _axes(M):
        k = 1 if ax["orient"] == "h" else 0
        span = ax["hi"] - ax["lo"]
        if any(abs(p[k] - ax["at"]) < 0.5 and abs(q[k] - ax["at"]) < 0.5 and
               abs(p[1 - k] - q[1 - k]) >= 0.9 * span for p, q in geometry):
            continue        # the geometry asks for this very line: it is data
        for a, b, el in dark:
            if abs(a[k] - ax["at"]) < 0.5 and abs(b[k] - ax["at"]) < 0.5 and \
                    abs(a[1 - k] - b[1 - k]) >= 0.9 * span:
                axis_els.add(el)
    segs = [(a, b) for a, b, el in dark if el not in axis_els]
    if not segs:
        return ["nothing is drawn at all, though %.1f units of line, edge or "
                "curve were given" % want]
    cell = max(2.0 * near, 8.0)
    idx = {}
    for k, (a, b) in enumerate(segs):
        xs, ys = sorted((a[0], b[0])), sorted((a[1], b[1]))
        for i in range(int(math.floor((xs[0] - near) / cell)),
                       int(math.floor((xs[1] + near) / cell)) + 1):
            for j in range(int(math.floor((ys[0] - near) / cell)),
                           int(math.floor((ys[1] + near) / cell)) + 1):
                idx.setdefault((i, j), []).append(k)

    def inked(p):
        for k in idx.get((int(math.floor(p[0] / cell)),
                          int(math.floor(p[1] / cell))), ()):
            a, b = segs[k]
            if _pt_seg(p, a, b) <= near:
                return True
        return False
    step = max(0.5, want / float(_COVER_PTS))
    lost, worst, run, at = 0.0, (0.0, None), 0.0, None
    for p, q in geometry:
        d = math.hypot(q[0] - p[0], q[1] - p[1])
        n = max(1, int(math.ceil(d / step)))
        for k in range(n):
            t = (k + 0.5) / n
            m = (p[0] + (q[0] - p[0]) * t, p[1] + (q[1] - p[1]) * t)
            if inked(m):
                run, at = 0.0, None
            else:
                lost += d / n
                run += d / n
                at = at or m
                if run > worst[0]:
                    worst = (run, at)
    if lost <= (1.0 - least) * want + 1e-9:
        return []
    where = (" — the longest stretch with no ink on it is %.1f units at "
             "(%.1f, %.1f)" % (worst[0], worst[1][0], worst[1][1])) \
        if worst[1] else ""
    return ["%.2f%% of the geometry the figure was given has no ink on it "
            "(%.1f of %.1f units)%s. A line, an edge, a curve or a rim is "
            "never cut, broken or shortened (v6 stage 1b): move the number, "
            "or give the figure more room."
            % (100.0 * lost / want, lost, want, where)]


def draws(svg, geometry, least=DRAWS):
    """v6 stage 1b: the finished file draws what the builder handed in.

    `geometry` is the input as (p, q) segments in the SAME user units as the
    SVG -- what the figure was ASKED to draw. The emitted dark stroke length
    must reach `least` of it, AND every stretch of it must carry ink
    (`covers`). Independent of the renderer's own bookkeeping: both are
    measured by this module's parser off the file.

    Returns [] or the messages naming the shortfall."""
    want = sum(math.hypot(q[0] - p[0], q[1] - p[1]) for p, q in geometry)
    if want <= 0:
        return []
    out = covers(svg, geometry, least)
    got = stroke_length(svg)
    if got < least * want - 1e-9:
        out.append(
            "the drawing is %.2f%% short of the geometry it was given "
            "(%.1f of %.1f units of stroke) — %.1f units of line, edge or "
            "curve are missing from the file. Nothing may be cut behind a "
            "number since v6 stage 1b: move the number instead."
            % (100.0 * (1 - got / want), got, want, want - got))
    return out


def assert_draws(svg, geometry, where="figure", least=DRAWS):
    bad = lost_ink(svg) + draws(svg, geometry, least)
    if bad:
        raise AssertionError("svgcheck: %s — %s" % (where, "; ".join(bad[:4])))
    return svg


_ASCII_MINUS = re.compile("[%s](?=\\s*[\\d.])" % _DASH_CLASS)


def _rtl(ch):
    return unicodedata.bidirectional(ch) in ("R", "AL") or \
        0x0590 <= ord(ch) <= 0x05FF or 0xFB1D <= ord(ch) <= 0xFB4F


@_per_block
def rtl_text(svg):
    """Texts holding a right-to-left letter (Hebrew, its gershayim '״',
    Arabic). v6 C4 r3: figkit.Figure refused Hebrew, but number lines wrote
    it straight into <text>, where it prints reversed (G49). Latin letters,
    digits, ° and U+2212 only; Hebrew goes in the HTML."""
    return [T.text for T in _M(svg).texts if any(_rtl(c) for c in T.text)]


@_per_block
def ascii_minus(svg):
    """Texts with an ASCII '-' (or a look-alike dash: U+2010-2013, U+FE63,
    U+FF0D) directly before a digit. Only U+2212 prints as a minus."""
    return [T.text for T in _M(svg).texts if _ASCII_MINUS.search(T.text)]


@_per_block
def font_floor(svg, min_pt=MIN_PT):
    """(text, run, printed pt) for every run under the floor.

    The printed size is read from numbers the SVG writes rounded (width and
    viewBox to 0.1 unit), so a run exactly at the floor can read a few
    thousandths of a point under it. ROUND_PT absorbs that and nothing a
    reader could see; figkit writes font sizes rounded UP so that its own
    rounding never lands a label under the floor."""
    M = _M(svg)
    out = []
    for T in M.texts:
        for r in T.runs:
            if r.text.strip() and r.size * M.pt_per_unit < min_pt - ROUND_PT:
                out.append((T.text, r.text, round(r.size * M.pt_per_unit, 2)))
    return out


_NUMTXT = re.compile(r"^[\-−+]?\d+(?:[.,]\d+)?$")
# C6 r5: a lone point name -- one Latin letter, primes, one index digit
_POINT_NAME = re.compile(r"^[A-Za-z][\u2032\u2033']*[0-9]?$")


def _value(t):
    return float(t.replace(MINUS, "-").replace(",", "."))


def _axes(M):
    """Axes found from the ink alone: a long horizontal or vertical dark
    stroke crossed by at least three short perpendicular strokes at a regular
    spacing. Returns dicts: orient 'h'|'v', at (y or x), lo, hi, ticks (sorted
    positions along the axis), spacing, half (tick half-length)."""
    # v6 C4 r2: the sides of a small closed marker (a white square on the
    # axis) are no tick marks -- read as two ticks 2r apart they bent the
    # lattice of a thirds line and every number was refused as 1.00 x
    # spacing off its tick
    # v6.2 Q1 r1 (L3-02): the sizes below are PRINTED sizes. As absolute
    # figure units they stopped recognising anything on a viewBox much
    # bigger than the printed width (see the tick-length band further down).
    ppu = max(M.pt_per_unit, 1e-6)
    mk = set(s.el for s in M.strokes if s.closed and s.tag in ("path", "rect",
                                                               "polygon")
             and (s.fill or "none").strip().lower() not in ("none", "transparent")
             and not _dark(s.fill) and (_extent(s.pts) <= 16.0
                                       or _extent(s.pts) * ppu <= 12.0))
    # ... nor is the base of a filled arrowhead: the heads of two touching
    # dimension arrows (numberline symmetric(), a span over another) stood
    # across their shafts like ticks, the shafts read as an axis and the
    # distances over them as its slid numbers
    for pts, closed, el in M.fills:
        P = list(pts)
        if len(P) > 1 and P[0] == P[-1]:
            P = P[:-1]
        if len(P) == 3 and (_extent(P) <= 16.0 or _extent(P) * ppu <= 12.0):
            mk.add(el)
    _rows = [(a, b, el) for a, b, el in M.dark_segs() if el not in mk]
    segs = [(a, b) for a, b, _el in _rows]
    if not segs:
        return []
    # v6.3 r1 (found while fixing S2-1-duplicate-marks): an axis is never an
    # edge of a CLOSED shape. A triangle's horizontal base carrying four
    # equality ticks was read as an axis with a tick lattice: every tick on
    # it then counted as the axis's own and the equal-lengths sweep saw
    # nothing, and a right trapezoid's two perpendicular sides were read as a
    # coordinate frame, so its side label '10' was refused as a tick number
    # "2.90 squares from the axes' crossing" on a figure with no axes
    # (the defect S2's predecessor reported and could not place). A plane's
    # axes are open strokes and are untouched.
    _closed = set(st.el for st in M.strokes if st.closed)
    # C3 r4: figkit spaces a group of equality ticks at
    # max(3.4 units, TICK_GAP_PT x upt + the mark's own stroke) -- a floor in
    # FIGURE UNITS, so on a large figure the gap is 4.4 units and stops
    # shrinking with the paper. Judged against GROUP_PT (4pt) alone, a group
    # of three on an edge along an axis stopped being a group at width >= 230:
    # its middle tick joined the lattice and the correct figure was refused
    # ('stand 0.00pt from the axis tick', and the ticks already were half-way,
    # so the message named no way out). The bound below is figkit's own
    # formula, measured off the file, with 5% for the rounding.
    _mw = [s.width for s in M.strokes for a, b in s.segs()
           if 1.0 <= _d(a, b) <= MARK_MAX_PT]
    # (figkit's marks only GROW: their first guess is 4/3 units per pt, the
    # scale of a figure printed 1:1, so a figure printed larger keeps that
    # gap in units -- 4.43 at width=400, where the paper says 3.58)
    group_u = 1.05 * max(3.4, TICK_GAP_PT * max(4.0 / 3.0,
                                                1.0 / max(M.pt_per_unit, 1e-6)) +
                         (max(_mw) if _mw else 1.0))
    xs = [p[0] for s in segs for p in s]
    ys = [p[1] for s in segs for p in s]
    extent = max(max(xs) - min(xs), max(ys) - min(ys), 1.0)
    out = []
    for orient in ("h", "v"):
        k, j = (1, 0) if orient == "h" else (0, 1)   # k: fixed coord index
        longs = {}
        for a, b, el in _rows:
            if el in _closed:
                continue
            if abs(a[k] - b[k]) < 0.3 and abs(a[j] - b[j]) >= max(30.0, 0.25 * extent):
                key = round((a[k] + b[k]) / 2.0)
                lo, hi = sorted((a[j], b[j]))
                longs.setdefault(key, []).append((lo, hi, (a[k] + b[k]) / 2.0))
        for key, spans in longs.items():
            at = sum(s[2] for s in spans) / len(spans)
            lo = min(s[0] for s in spans)
            hi = max(s[1] for s in spans)
            ticks, halves, across, tick_len = [], [], [], {}
            for a, b in segs:
                if abs(a[j] - b[j]) > 0.3:
                    continue
                L = abs(a[k] - b[k])
                # v6.2 Q1 r1 (L3-02, blind-at-big-viewbox): the CEILING is
                # a printed size (doctrine 6). It used to be 16 FIGURE UNITS
                # flat, so a figure drawn on a viewBox 2.5x bigger at the same
                # printed width -- which _GROW_PINNED reaches, and which every
                # new refusal of this round names as its cure ('bigger
                # squares, size=') -- had ticks of 18 units and _axes found no
                # axis at all. problems(), letter_side and every geometric
                # sweep that hangs off _axes then returned [] VACUOUSLY, so
                # the cheapest way out of a refusal was to climb until nothing
                # was read any more. The unit band is kept as it was, so no
                # stroke that counted as a tick stops counting: the printed
                # ceiling only ADDS the ones a big viewBox had hidden.
                if not (1.0 <= L and (L <= 16.0 or L * ppu <= 12.0)):
                    continue
                lo_k, hi_k = sorted((a[k], b[k]))
                if lo_k - 0.3 <= at <= hi_k + 0.3 and lo - 1 <= a[j] <= hi + 1:
                    ticks.append((a[j] + b[j]) / 2.0)
                    tick_len.setdefault(round((a[j] + b[j]) / 2.0, 2), []).append(L)
                    halves.append(max(hi_k - at, at - lo_k))
                    if lo_k < at - 0.5 and hi_k > at + 0.5:
                        across.append(round((a[j] + b[j]) / 2.0, 2))
            ticks = sorted(set(round(t, 2) for t in ticks))
            marks = None
            if 1 <= len(ticks) < 3 and sorted(set(across)) == ticks:
                marks = list(ticks)
                ticks = _grid_ticks(M, orient, at, lo, hi, ticks)
            if len(ticks) < 3:
                continue
            diffs = sorted(round(b - a, 1) for a, b in zip(ticks, ticks[1:])
                           if b - a > 0.5)
            if not diffs:
                continue
            s = min(diffs, key=lambda d: (-sum(1 for e in diffs
                                               if abs(e - d) <= 0.3), d))
            # The spacing above is rounded to 0.1; walked out across fifteen
            # ticks that error put the far ticks off the lattice (z01: a
            # 8.75-unit step read as 8.8 dropped every tick right of '3' and
            # the numbers there looked slid). Refit origin and step by least
            # squares on the tick INDEX, twice, before deciding membership.
            # v6 C3: the lattice is anchored on the tick most others agree
            # with, not on the first mark: a right-angle mark standing on the
            # axis left of the first tick put every real tick off the lattice
            # and the whole axis went unread (gallery 5)
            s_mode = s
            s, t0, grouped, n_iso = _best_lattice(ticks, s, tick_len,
                                                  M.pt_per_unit,
                                                  group_u=group_u)
            # C3 r3: a group of equality ticks straddling an axis tick made
            # the commonest gap under 4 units and the axis went unread; it is
            # read when three lone marks agree on a wider lattice
            if s < 4.0 or (s_mode < 4.0 and n_iso < 3):
                continue
            # the marks of a group are no ticks of the lattice when three
            # lone marks carry it (else they joined it and went unjudged)
            pool = [t for t in ticks if t not in grouped]
            if len(_on_lattice(pool, s, t0)) < 3:
                pool = ticks
            lattice = []
            for _ in range(3):
                idx = [(round((t - t0) / s), t) for t in pool
                       if abs((t - t0) / s - round((t - t0) / s)) < 0.15]
                lattice = [t for _, t in idx]
                if len(idx) < 3:
                    break
                n = float(len(idx))
                mk = sum(k for k, _ in idx) / n
                mt = sum(t for _, t in idx) / n
                kk = sum((k - mk) ** 2 for k, _ in idx)
                if kk <= 0:
                    break
                s = sum((k - mk) * (t - mt) for k, t in idx) / kk
                t0 = mt - s * mk
            if len(lattice) < 3 or s < 4.0:
                continue
            out.append(dict(orient=orient, at=at, lo=lo, hi=hi,
                            ticks=lattice, spacing=s, t0=t0,
                            half=max(halves) if halves else 3.0,
                            marks=marks))
    return out


def _extent(pts):
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    return max(max(xs) - min(xs), max(ys) - min(ys))


def _on_lattice(ticks, s, a, tol=0.15):
    return [t for t in ticks if abs((t - a) / s - round((t - a) / s)) < tol]


def _best_lattice(ticks, s_mode, lengths=None, ppu=1.0, group_u=None):
    """C3 round 3: the axis's spacing and anchor, chosen among lattices.

    The most common gap between neighbouring marks is not the axis's step
    when equality ticks stand on an edge lying along the axis: a group of two
    or three ticks 4.4 units apart, half-way between two axis ticks 32 apart,
    made 4.4 (or 13.1, tick to group) the 'spacing', the lattice ran through
    the group and one axis tick, the real ticks fell off it, and a correct
    figure was refused ('stand 2.87pt from the axis tick at 78.9', 'tick label
    2 sits 2.65 x spacing'). Every gap between a mark and its next four
    neighbours proposes a spacing; each mark anchors it. A lattice that
    leaves more than half of its own positions empty between its first and
    last member is a coincidence, not an axis; of the rest the one explaining
    the most marks wins, then the fuller, then the wider (a two- or three-mark
    group ties a three-tick axis only on count, and its spacing is the
    smaller). Returns (spacing, anchor, grouped marks, lone members)."""
    lengths = lengths or {}
    # a mark with a same-length neighbour nearer than GROUP_PT of paper is
    # one of a group of equality ticks (their gap is TICK_GAP_PT plus a
    # stroke; figkit keeps a group 2 x TICK_GAP_PT clear of an axis tick).
    # C3 r4: figkit's spacing is max(3.4 units, TICK_GAP_PT x upt + stroke),
    # so on a big figure the gap is 3.4-4.4 UNITS and stops shrinking with the
    # paper. Held to GROUP_PT alone, a correct three-tick edge along an axis
    # became three lone marks at width >= ~230 and was refused; so the gap is
    # a group when it is under GROUP_PT of paper OR under GROUP_U units, and
    # GROUP_U is the floor under which no gap is ever read as an axis anyway.
    gap_u = max(GROUP_PT / ppu, GROUP_U) if ppu > 0 else GROUP_U
    if group_u:
        gap_u = max(gap_u, group_u)

    def alike(u, t):              # lengths: position -> [stroke lengths]
        return any(abs(x - y) < 0.3 for x in lengths[u] for y in lengths[t])
    grouped = set(t for t in ticks if t in lengths and any(
        0 < abs(u - t) < gap_u and u in lengths and alike(u, t)
        for u in ticks))
    # a mark whose length fewer than three marks share is a lone equality
    # tick or a mark's side, not a tick of a lattice
    def same(t):
        return sum(1 for u in ticks if u in lengths and alike(u, t))
    known = [t for t in ticks if t in lengths]
    top = max([same(t) for t in known] or [0])
    close = set(grouped)
    lone = set(t for t in known if same(t) < 3 <= top)
    # C4: a number line prints three tick LENGTHS (numbered, half, minor); on
    # a short line only two numbered ticks share the longest. Those stand on
    # the lattice of the commonest gap through the other marks, so they are
    # the axis's ticks, not lone equality ticks (read as lone, the numbers
    # '1' and '2' of 0.25..2.25 were refused as half a spacing off)
    # A lone equality tick half-way between two axis ticks leaves a gap in
    # the finer lattice it suggests; a number line's ticks fill it end to end
    # (an arrowhead's base may stand past either end). So: two or more lone
    # marks, and every mark between the first and last lattice member on a
    # complete lattice of the smallest gap -- then the lone marks are ticks.
    allm = sorted(set(round(t, 2) for t in known if t not in close))
    free = lone - close
    gaps = [b_ - a_ for a_, b_ in zip(allm, allm[1:])]
    if len(free) >= 2 and len(gaps) >= 4:
        g0 = sorted(gaps)[len(gaps) // 2]          # the median gap
        for anchor in allm[:2]:
            if g0 < 4.0:
                break
            L = [t for t in allm
                 if abs((t - anchor) / g0 - round((t - anchor) / g0)) * g0 < 0.3]
            off = [t for t in allm if t not in L]
            n_pos = int(round((L[-1] - L[0]) / g0)) + 1
            if len(L) == n_pos >= 5 and len(off) <= 2 and \
                    all(t < L[0] or t > L[-1] for t in off) and \
                    sum(1 for t in free if round(t, 2) in L) >= 2:
                lone -= set(t for t in free if round(t, 2) in L)
                break
    grouped |= lone
    cands = set([s_mode] if s_mode >= 4.0 else [])
    for i, a in enumerate(ticks):
        for b in ticks[i + 1:i + 5]:
            if b - a >= 4.0:
                cands.add(round(b - a, 1))
    best = None
    for s in sorted(cands):
        seen = set()
        for a in ticks:
            if a in seen:
                continue
            mem = _on_lattice(ticks, s, a)
            seen.update(mem)
            if len(mem) < 2:
                continue
            ks = [round((t - a) / s) for t in mem]
            nk = len(set(ks))     # two marks on one position count once
            if nk < 2:
                continue
            fill = nk / float(max(ks) - min(ks) + 1)
            # a grouped member (see above) is one of a
            # group of equality ticks that happens to fall on the lattice
            iso = sorted(set(round((t - a) / s) for t in mem if t not in grouped))
            fill_iso = (len(iso) / float(iso[-1] - iso[0] + 1)) if iso else 0.0
            key = (fill >= 0.5, len(iso), round(fill_iso, 3), nk,
                   nk == len(ks), round(fill, 3), s)
            if best is None or key > best[0]:
                best = (key, s, a, len(iso))
    if best is None:
        return (s_mode, max(ticks, key=lambda a: len(_on_lattice(ticks, s_mode, a))),
                grouped, 0)
    return best[1], best[2], grouped, best[3]


def _grid_ticks(M, orient, at, lo, hi, ticks):
    """C2 round 3: an axis carrying one or two tick marks (xticks=[6] alone)
    was no axis to the sweep, so a number beside that tick was never judged
    and could sit 0.42 of a square off it. When every tick mark crosses the
    stroke (a guide merely ENDING on a dashed line is no tick), a regular grid
    of light lines crosses the axis and every tick sits on that grid, the grid
    lines are the axis's lattice. Otherwise the ticks come back unchanged."""
    k, j = (1, 0) if orient == "h" else (0, 1)
    pos = []
    for a, b in M.light:
        if abs(a[j] - b[j]) > 0.3:
            continue
        lo_k, hi_k = sorted((a[k], b[k]))
        if lo_k - 0.3 <= at <= hi_k + 0.3 and lo - 1 <= a[j] <= hi + 1:
            pos.append(round((a[j] + b[j]) / 2.0, 2))
    pos = sorted(set(pos))
    if len(pos) < 3:
        return ticks
    diffs = sorted(round(q - p, 1) for p, q in zip(pos, pos[1:]) if q - p > 0.5)
    if not diffs:
        return ticks
    s = min(diffs, key=lambda d: (-sum(1 for e in diffs if abs(e - d) <= 0.3), d))
    if s < 4.0 or sum(1 for d in diffs if abs(d - s) <= 0.3) * 2 < len(diffs):
        return ticks
    for t in ticks:
        if min(abs(t - p) for p in pos) > 0.05 * s:
            return ticks
    return sorted(set(pos) | set(ticks))


def _along(T, ax):
    c = T.centre()
    return c[0] if ax["orient"] == "h" else c[1]


def _perp_gap(box, ax):
    if ax["orient"] == "h":
        if box[1] > ax["at"]:
            return box[1] - ax["at"]
        if box[3] < ax["at"]:
            return ax["at"] - box[3]
        return 0.0
    if box[0] > ax["at"]:
        return box[0] - ax["at"]
    if box[2] < ax["at"]:
        return ax["at"] - box[2]
    return 0.0


def _near_tick(pos, ax):
    return min(ax["ticks"], key=lambda t: abs(t - pos))


def _fit(pairs):
    """Least squares value = a + b*pos from (pos, value) pairs."""
    if len(pairs) < 2:
        return None
    n = float(len(pairs))
    mp = sum(p for p, _ in pairs) / n
    mv = sum(v for _, v in pairs) / n
    sxx = sum((p - mp) ** 2 for p, _ in pairs)
    if sxx < 1e-9:
        return None
    b = sum((p - mp) * (v - mv) for p, v in pairs) / sxx
    if abs(b) < 1e-12:
        return None
    return (mv - b * mp, b)


def _axis_labels(M, axes):
    """Numeric labels assigned to the axis whose tick they sit nearest,
    in units of that axis's spacing.

    v6 stage 1b r3: an axis carries each value ONCE. A number that scores
    best against an axis already printing that value squarely on a tick is
    handed to the next axis that can reach it — where it is this axis's own
    number, judged like every other. Choosing by alignment alone let a number
    escape the sweep that judges it: the gallery's `divide` figure prints its
    x '2' across the axis, and slid far enough along, that '2' scored better
    against a y tick than against its own, moved into the y group, and was
    excused there as a value label ('the tick already carries it') — 0.68 of
    a spacing off its tick and every sweep called the file clean. A second
    '2' beside an axis cannot be that axis's number: it has one tick for the
    value, and something else is standing there."""
    cand = []
    for T in M.texts:
        if not T.box or not _NUMTXT.match(T.text.strip()):
            continue
        if T.text.strip().startswith("+"):
            # C6 r6: a SIGNED number is a displacement -- a jump's '+1' over
            # its arc -- and no axis prints its ticks with a '+'. Read as a
            # tick number it was refused '0.50 x spacing from its tick', and
            # the cheapest way out was dropping the label or its sign
            continue
        opts = []
        for i, ax in enumerate(axes):
            gap = _perp_gap(T.box, ax)
            if gap > ax["half"] + 1.6 * T.size:
                continue
            pos = _along(T, ax)
            # a number beyond the run of ticks belongs to something else — the
            # other axis's '2' beside the origin is not this axis's slid '20'.
            # v6 stage 1b r3: the reach is a whole spacing, not half of one.
            # At half, a number slid past the FIRST tick of the run left its
            # own axis's candidates altogether and was judged by nothing --
            # sliding far enough was an escape from the sweep that measures
            # how far it slid. A spacing out it is still nearer this axis's
            # end tick than any tick of its own axis, so the value test below
            # (an axis carries each value once) keeps the neighbours apart.
            if not ax["ticks"][0] - ax["spacing"] <= pos <= \
                    ax["ticks"][-1] + ax["spacing"] and \
                    not _past_free_end(M, ax, axes, pos):
                continue
            e = abs(pos - _near_tick(pos, ax)) / ax["spacing"]
            opts.append((e, i, pos))
        opts.sort(key=lambda o: o[0])
        if opts:
            cand.append((T, opts))
    # the values each axis already prints ON a tick: a further label of the
    # same value is not that axis's number
    owned = {}
    for T, opts in cand:
        e, i, _ = opts[0]
        if e <= TICK_TOL:
            owned.setdefault(i, set()).add(_value(T.text))
    groups = {i: [] for i in range(len(axes))}
    for T, opts in cand:
        pick = opts[0]
        if pick[0] > TICK_TOL:
            for o in opts:
                if _value(T.text) not in owned.get(o[1], ()):
                    pick = o
                    break
        groups[pick[1]].append((T, pick[2], pick[0]))
    return groups


def _free_ends(M, ax, axes):
    """(start_free, end_free): no perpendicular axis crosses `ax` within a
    spacing of that end of its run of ticks (cached on the axis dict)."""
    if "_free" not in ax:
        cs = _crossings(M, ax, axes)
        t, s = ax["ticks"], ax["spacing"]
        # any perpendicular dark stroke across the axis longer than its tick
        # marks: a y-axis with too few ticks to be found is still an axis
        h = ax["orient"] == "h"
        i, j = (0, 1) if h else (1, 0)
        for a, b, _ in M.dark_segs():
            if abs(a[i] - b[i]) < 0.3 and \
                    abs(a[j] - b[j]) > 2.5 * ax["half"] + 1.0 and \
                    min(a[j], b[j]) - 1.0 <= ax["at"] <= max(a[j], b[j]) + 1.0:
                cs.append((a[i] + b[i]) / 2.0)
        ax["_free"] = (not any(c <= t[0] + s for c in cs),
                       not any(c >= t[-1] - s for c in cs))
    return ax["_free"]


def _past_free_end(M, ax, axes, pos):
    """O3-02: is `pos` past a FREE end of the axis's ticks (see _free_ends)?
    The reach of one spacing kept the other axis's numbers beside the
    crossing out of this axis; at an end no other axis reaches, nothing but
    this axis's own numbers stands in its row -- and a number moved past the
    end (under the axis letter, off the figure) was judged by nothing."""
    t, s = ax["ticks"], ax["spacing"]
    a, b = _free_ends(M, ax, axes)
    return (a and pos < t[0] - s) or (b and pos > t[-1] + s)


def _lattice(ax, labs, tol):
    """The axis's own numbering, value = v0 + k x dv over tick INDEX k, agreed
    by the most aligned labels (every pair proposes one; inliers vote). A
    least-squares fit would bend toward a swapped or doubled number and call
    it consistent; a vote leaves it out as the odd one. Returns
    (v0, dv, inliers) or None when no majority of at least three agrees."""
    s, t0 = ax["spacing"], ax.get("t0", ax["ticks"][0])
    pts = []
    for T, pos, e in labs:
        if e <= tol:
            k = int(round((_near_tick(pos, ax) - t0) / s))
            pts.append((k, _value(T.text), T))
    best = None
    for i in range(len(pts)):
        for j in range(i + 1, len(pts)):
            (ki, vi, _), (kj, vj, _) = pts[i], pts[j]
            if ki == kj or vi == vj:
                continue
            dv = (vj - vi) / float(kj - ki)
            v0 = vi - dv * ki
            res = [abs(v0 + dv * k - v) for k, v, _ in pts]
            inl = [n for n, r in enumerate(res) if r <= 0.05 * abs(dv)]
            key = (len(inl), -sum(res[n] for n in inl))
            if best is None or key > best[0]:
                best = (key, v0, dv, set(inl))
    if best is None:
        return None
    n_in = len(best[3])
    if n_in < 3 or n_in * 2 <= len(pts):
        return None
    return best[1], best[2], best[3], pts


def _rows(ax, labs):
    """Numeric labels beside one axis, grouped into ROWS: same side of the
    axis, and the same offset from it (by the near edge, the centre or the far
    edge, whichever the text anchor keeps constant) within 0.75 em. The axis's
    own numbers form one row; a jump's '+2' over its arc, a length over a
    segment or a point's value over its dot sit in another. Rows come back
    with the most tick-aligned first."""
    info = []
    for T, pos, e in labs:
        b = T.box
        if ax["orient"] == "h":
            lo, hi = b[1] - ax["at"], b[3] - ax["at"]
        else:
            lo, hi = b[0] - ax["at"], b[2] - ax["at"]
        side = 1 if lo + hi > 0 else -1
        near, far = (lo, hi) if side > 0 else (-hi, -lo)
        info.append((side, near, (lo + hi) / 2.0 * side, far, T.size))
    parent = list(range(len(labs)))

    def root(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i
    for i in range(len(info)):
        for j in range(i + 1, len(info)):
            a, b = info[i], info[j]
            lim = 0.75 * max(a[4], b[4])
            if a[0] == b[0] and min(abs(a[1] - b[1]), abs(a[2] - b[2]),
                                    abs(a[3] - b[3])) <= lim:
                parent[root(i)] = root(j)
    groups = {}
    for i, lab in enumerate(labs):
        groups.setdefault(root(i), []).append(lab)
    rows = list(groups.values())
    rows.sort(key=lambda r: (-sum(1 for _, _, e in r if e <= TICK_TOL), -len(r)))
    return rows


def _tick_row(ax, labs):
    rows = _rows(ax, labs)
    return rows[0] if rows else []


@_per_block
def tick_alignment(svg, tol=TICK_TOL, distance=True, irregular=False):
    """Every numeric label in the axis's ROW of numbers is centred within
    tol x spacing of a tick, AND names that tick's value.

    Distance alone passed an axis with '3' and '4' swapped, and a '3' printed
    on the tick of 5: each number sat on A tick, just not its own (the z01
    28ב family). So once three aligned numbers agree on the axis's step, an
    aligned number that disagrees is refused as sitting on the wrong tick,
    and a number off every tick whose own tick is within 1.5 spacings is
    refused as slid.

    A number that is not a tick number is told apart two ways. By ROW (see
    _rows): a jump's '+2' over its arc, a length over a segment, a point's
    '3.1' over its dot sit across the axis from the numbers or a line farther
    out, and only the row holding the most aligned numbers (and any other row
    that agrees on a numbering of its own) is judged. Within that row, by
    VALUE: a number printed exactly at its own value between ticks ('2.5' at
    2.5), or whose own tick is far away, or whose tick already carries it, is
    a value label.

    C2 round 3: a LONE number (one listed value on a sparse axis; an axis
    with one or two tick marks, measured by its light grid) is judged against
    its nearest tick, and a number printed across the axis is joined to a row
    of one number by its offset alone. Both used to pass 0.4 of a square off.

    `distance=False` keeps only the wrong-tick votes (a number printed on
    another number's tick), which does not depend on how far the solver let
    a number slide. `irregular=True` is for a figure whose CONTENT is a
    wrongly numbered line (a "what is wrong with this line?" item): the vote
    is skipped and only the distance to a tick is measured."""
    M = _M(svg)
    axes = _axes(M)
    out = []
    groups = _axis_labels(M, axes)
    for i, all_labs in groups.items():
        ax = axes[i]
        # the origin's '0' in a corner of the crossing belongs to BOTH axes and
        # is judged below against both numberings, never inside a row
        labs = [l for l in all_labs
                if not (_value(l[0].text) == 0 and _zero_corner(M, ax, axes, l[0]))]
        rows = _rows(ax, labs)
        if not rows:
            continue
        main = list(rows[0])
        rest = [list(r) for r in rows[1:]]
        if not irregular and rest:
            main, rest = _mirrors(ax, main, rest, tol, M)
        judged = [main] + [r for r in rest
                           if r and not irregular and _lattice(ax, r, tol)]
        for row in judged:
            out += _judge_row(ax, row, tol, distance, irregular, axes, M)
        if distance and not irregular and \
                len(set(a["orient"] for a in axes)) == 2:
            out += _stray_across(M, ax, main, [r for r in rest
                                               if r and r not in judged])
        if distance:
            out += _scale_runs_the_right_way(ax, main)
        if distance and not irregular:
            out += _foreign_tick(ax, main, axes, tol, M)
            # P3 leftovers r2: a COORDINATE PLANE only. On a number line the
            # numbers are the axis's row and the DATA (spans, jumps, arcs,
            # their value labels) lives above it by design, so "nearer a data
            # stroke than its tick" is the normal reading there.
            out += _crossed_into_shape(M, ax)
    if distance and not irregular:
        out += _corner_zeros(M, axes, groups, tol, irregular)
        out += _zero_owner(M, axes)
    return out


def _stray_across(M, ax, main, spare, tol=TICK_TOL):
    """C7r3-P6 (P3 leftovers r1): a tick number that stepped ACROSS its axis
    and then slid along it was judged by nothing.

    _mirrors moves a crossed number back into the main row only when it
    stands at the row's own offset (within _MIRROR_EM); one further out forms
    a row of its own, which _lattice throws away for being a single member,
    and then no rule measured it at all. A sweep of one x '4' over a whole
    spacing caught only the middle band (0.56-0.75): at 0.38-0.50 and at
    0.81-1.00 -- a whole spacing along, standing at the '6' tick above the
    axis -- the file came back clean, and this sweep is meant to be the last
    word on a finished figure.

    Judged here: a number left OUT of the main row whose VALUE belongs to the
    row's own scale is that axis's number wherever it stands, so it keeps to
    its own tick within MOVED_TOL like any other."""
    sc = _scale(ax, main, tol)
    if not sc or not ax["ticks"]:
        return []
    read, dv = sc
    if not dv:
        return []
    seen = set(id(T) for T, _, _ in main)
    printed = set()
    for T, _p, _e in main:
        v = _value(T.text.strip())
        if v is not None:
            printed.add(round(v, 6))
    side = 1 if sum(_row_side(ax, T)[0] for T, _, _ in main) > 0 else -1
    s = ax["spacing"]
    out = []
    for row in spare:
        for T, pos, e in row:
            if id(T) in seen or not _NUMTXT.match(T.text.strip()):
                continue
            v = _value(T.text.strip())
            if v is None or round(v, 6) in printed:
                continue        # the axis's own number is printed elsewhere
            if _row_side(ax, T)[0] == side:
                continue        # not across the axis at all
            # where this VALUE's tick stands, read through the row's scale
            near = min(ax["ticks"], key=lambda t: abs(read(t) - v))
            if abs(read(near) - v) > 0.05 * abs(dv):
                continue            # not one of this axis's numbers
            off = abs(pos - near) / s
            if off <= MOVED_TOL + 1e-6:
                continue
            out.append(
                "the %s-axis number %r stands across its axis %.2f x spacing "
                "from its own tick -- that far along it names the tick it "
                "has reached, not its own, and the value it belongs to is "
                "left unnumbered. Keep it at its tick (it may cross the "
                "axis, but not walk along it): a step of 2 squares, a larger "
                "size= or a wider figure (width=/max_width=)"
                % ("x" if ax["orient"] == "h" else "y", T.text, off))
    return out


def _scale_runs_the_right_way(ax, row):
    """L1-REVERSED-SCALE (c7 #2, P3 leftovers r1): an axis whose numbers run
    BACKWARDS -- x decreasing to the right, or y decreasing upwards -- passed
    every sweep, because each number was measured only against the tick it
    stands on and the lattice was fitted with a signed step. A figure whose
    scale lies then reads as a clean file, and doctrine 3 says the later PDF
    gate relies on these file-level checks.

    Judged here off the finished file: the row's printed values against the
    positions they print at. x grows to the RIGHT, y grows UPWARDS (so its
    SVG coordinate falls). A single number says nothing; an irregular row is
    judged as well, since the direction is not a matter of the step."""
    vals = [(pos, _value(T.text.strip())) for T, pos, e in row
            if _NUMTXT.match(T.text.strip()) and e <= MOVED_TOL]
    vals = [(p, v) for p, v in vals if v is not None]
    if len(vals) < 2:
        return []
    vals.sort()
    up = 1 if ax["orient"] == "h" else -1      # SVG y falls upwards
    down = sum(1 for (p0, v0), (p1, v1) in zip(vals, vals[1:])
               if (v1 - v0) * up < -1e-9)
    grow = sum(1 for (p0, v0), (p1, v1) in zip(vals, vals[1:])
               if (v1 - v0) * up > 1e-9)
    if down <= grow:
        return []
    return ["the %s-axis is numbered BACKWARDS: its values run %s (%s read "
            "along the axis). %s grows %s -- a figure whose scale runs the "
            "other way is read wrong by every reader. Number the axis the "
            "usual way (the engine does it from the window), or, if the "
            "quantity really decreases, draw it as data and label it, never "
            "by reversing the scale"
            % ("x" if ax["orient"] == "h" else "y",
               "down" if grow == 0 else "mostly down",
               ", ".join(T.text.strip() for T, pos, e in
                         sorted(row, key=lambda r: r[1])
                         if _NUMTXT.match(T.text.strip())),
               "x" if ax["orient"] == "h" else "y",
               "to the right" if ax["orient"] == "h" else "upwards")]


ZERO_RATIO = 1.25    # the origin's '0': its centre no farther from the
                     # crossing than this x its distance to any other tick
ZERO_SQ = 0.85       # ... and no farther than this many GRID SQUARES from
                     # the crossing ACROSS one of the axes (P3,
                     # L1-ZERO-STEP2: at the default step of 2 the ticks are
                     # 2 squares apart, so the ratio alone let a '0' stand a
                     # whole square out along both axes -- on the grid point
                     # beside the origin -- and called it a corner)
ZERO_ALONG = 0.50    # ... unless it is pushed ALONG an axis and stays this
                     # close to it, and then no farther out than ZERO_FAR (a
                     # plane whose two diagonals fill every corner pushes
                     # its '0' a square out ALONG the x-axis, and there it
                     # still reads as the crossing's)
ZERO_FAR = 1.20
ZERO_SLIDE = 1.05    # P3 leftovers r2 (L1-P3r2-02): the bound for a '0'
                     # pushed ALONG an axis (min(dx, dy) within ZERO_ALONG of
                     # it), where the corner diagonal's slack does not apply:
                     # there rule 4 is read literally -- nearer the crossing
                     # than any other tick. ZERO_RATIO's 1.25 was measured on
                     # CORNER zeros, which stand on the diagonal between the
                     # crossing and the first tick of each axis and read
                     # right at 1.0-1.15; a '0' slid along an axis at 1.11
                     # reads as the next tick's number. The old NAME of this
                     # bound follows below.
                     # bound the origin's '0' is held to -- it is ZERO_RATIO
                     # now, and the bound is the author's rule 4 read
                     # literally: the '0' stands nearer the axes' CROSSING
                     # than any other tick, with 5% of slack for the corner
                     # diagonal. At 1.25 the slack was a whole step: on a
                     # step-2 axis the '0' printed 1.06 squares along the
                     # x-axis -- 1.12 squares from the crossing, 1.00 from
                     # the tick at x = -2, ratio 1.11, problems() == []
                     # (measured on the plain two-diagonal plane at (-6,6)
                     # and at (-5,5)). Every corner '0' of the shipped
                     # fixtures measures 0.33-0.98.


def _grid_square(M, h, v):
    """The GRID pitch in px, read off the light lines (the same lattice
    _grid_ticks uses), or None when the figure has no grid. The tick spacing
    is not the square: at step=2 it is two of them."""
    best = []
    for lines, j in ((M.light, 0), (M.light, 1)):
        pos = sorted(set(round((a[j] + b[j]) / 2.0, 2) for a, b in lines
                         if abs(a[j] - b[j]) <= 0.3 and
                         abs(a[1 - j] - b[1 - j]) > 1.0))
        d = sorted(round(q - p, 2) for p, q in zip(pos, pos[1:]) if q - p > 0.5)
        if len(d) >= 2:
            s = min(d, key=lambda e: (-sum(1 for f in d if abs(f - e) <= 0.3),
                                      e))
            if s >= 4.0:
                best.append(s)
    return min(best) if best else None


def _zero_owner(M, axes, strict=False):
    """Stage-1 open issue O3-01 / P2-01 (the author's rule 4 for the origin's
    '0'): the '0' printed once in a corner of the axes' crossing must stand
    nearer the CROSSING than any other tick of either axis.

    _zero_corner accepts a '0' whose nearest box corner is within one em plus
    the step-aside allowance of the crossing -- on a small square that is up
    to 1.6 squares away. The solver used that reach: the '0' went up-left to
    the grid point (-1, 1), inside a triangle with a vertex at the origin,
    beside the y '1' (the row read '0 1'), or stacked on the x '-1'. Its
    centre was then nearer the x tick -1 or the y tick 1 than the origin,
    and nothing refused it. Judged here on the finished file: the crossing of
    a horizontal and a vertical axis, the tick marks both axes carry, the
    centre of every '0' in a corner of that crossing.

    The margin (ZERO_RATIO 1.25, not 1.0): a '0' in its corner stands on the
    diagonal between the crossing and the first tick of each axis, so on a
    small square the conventional below-left '0', or one slid a little along
    an axis, is already 1.0-1.15 x as far from the crossing as from that
    tick and still reads as the crossing's (measured on 240 random planes).
    Every misowned '0' measured stood 1.34-2.7 x as far."""
    out = []
    H = [a for a in axes if a["orient"] == "h"]
    V = [a for a in axes if a["orient"] == "v"]
    zeros = [T for T in M.texts if T.box and _NUMTXT.match(T.text.strip())
             and _value(T.text) == 0]
    for h in H:
        for v in V:
            if not (h["lo"] - 1.0 <= v["at"] <= h["hi"] + 1.0 and
                    v["lo"] - 1.0 <= h["at"] <= v["hi"] + 1.0):
                continue
            O = (v["at"], h["at"])
            ticks = [("x", t, (t, h["at"])) for t in h["ticks"]] + \
                    [("y", t, (v["at"], t)) for t in v["ticks"]]
            ticks = [k for k in ticks
                     if math.hypot(k[2][0] - O[0], k[2][1] - O[1]) >= 0.5]
            if not ticks:
                continue
            for T in zeros:
                cc = T.centre()
                do = math.hypot(cc[0] - O[0], cc[1] - O[1])
                # a '0' in a corner of this crossing, or one slid out of the
                # corner's reach but still within 3 squares of it (outside
                # the reach it was judged by nothing: a '0' 1.9 squares
                # out passed)
                c = _zero_corner(M, h, axes, T)
                if c and abs(c[0] - v["at"]) > 1.0:
                    continue
                if not c and do > 3.0 * min(h["spacing"], v["spacing"]):
                    continue
                d, name, t, p = min((math.hypot(cc[0] - k[2][0],
                                                cc[1] - k[2][1]),) + k
                                    for k in ticks)
                # P3 (L1-ZERO-STEP2): a corner is a corner -- within ZERO_SQ
                # of the crossing in GRID SQUARES, whatever the step. At
                # step=2 the ratio alone passed a '0' on the grid point
                # (-1, -1), under the point at x=-1 or in the x-number row.
                g = _grid_square(M, h, v)
                dx = abs(cc[0] - O[0]) / g if g else 0.0
                dy = abs(cc[1] - O[1]) / g if g else 0.0
                out_sq = max(dx, dy)
                off_grid = g and not (
                    max(dx, dy) <= ZERO_SQ or
                    (min(dx, dy) <= ZERO_ALONG and max(dx, dy) <= ZERO_FAR))
                # r2: a '0' pushed ALONG an axis has no corner diagonal to
                # excuse it -- it is held to ZERO_SLIDE (see there)
                along = g and min(dx, dy) <= ZERO_ALONG
                lim = (ZERO_SLIDE if (along and strict) else ZERO_RATIO)
                if do < lim * d and not off_grid:
                    continue
                if do >= lim * d:
                    pass
                elif off_grid:
                    out.append(
                        "the origin's '0' stands %.2f square(s) from the "
                        "axes' crossing -- that is the grid point beside it, "
                        "not a corner of it, and the '0' reads as a value "
                        "there (rule 4); keep the '0' in the corner: move "
                        "the letter or stroke filling the corners (a point's "
                        "label to another side), a larger size= or a wider "
                        "figure" % out_sq)
                    continue
                sq = h["spacing"] if name == "x" else v["spacing"]
                out.append("the origin's '0' stands %.2f x spacing from the "
                           "axes' crossing but only %.2f from the %s-axis "
                           "tick at %s -- it reads as that tick's number "
                           "(rule 4); keep the '0' in a corner beside the "
                           "crossing: move the letter or stroke that fills "
                           "the corners (a point's label to another side), a "
                           "step of 2 squares, a larger size= or a wider "
                           "figure" % (do / sq, d / sq, name,
                                       _at(M, h if name == "x" else v, t)
                                       or ("the %s-axis" % name)))
    return out


STACK_EM = 0.90     # a letter this near a number's column end reads with it
OWN_RATIO = 0.90     # a number's centre: nearer its own tick than this x any other


def _foreign_tick(ax, labs, axes, tol, M=None):
    """C6 r6 (the author's rule 4, measured in the plane): a tick number's
    centre is nearer ITS OWN tick than any tick of the OTHER axis (by
    OWN_RATIO; along its own axis the slide allowance already judges it).

    Every sweep above measures a number along its own axis. A number that
    stepped out diagonally (a slide along, then a step away from the axis)
    can stay within the slide allowance along its axis and still stand
    nearer a tick of the OTHER axis: a y '-1' printed 1.23 squares from
    (0, -1) and 1.17 from the x tick (-1, 0), right under the x '-1', so
    x = -1 looked numbered twice and y = -1 not at all; an x '1' stepped a
    whole square into quadrant I, level with the y tick 1. Only a figure
    with a horizontal AND a vertical axis is judged -- a number line has no
    other axis to confuse its numbers with."""
    others = [o for o in axes if o is not ax and o["orient"] != ax["orient"]]
    if not others or len(labs) < 2:
        return []
    _, want = _numbering(ax, labs, tol, False)
    if want is None:
        return []
    h = ax["orient"] == "h"

    def pt(a, t):
        return (t, a["at"]) if a["orient"] == "h" else (a["at"], t)
    ticks = []
    for a in axes:
        ticks += [(a, t, pt(a, t)) for t in a["ticks"]]
    name = "x" if h else "y"
    out = []
    for T, pos, e in labs:
        v = _value(T.text)
        if v == 0:
            continue
        along = want(v)
        if abs(along - pos) >= SLID_REACH * ax["spacing"]:
            continue                 # a value label; judged by nothing here
        if any(U is not T and U.text == T.text
               and abs(p - along) <= tol * ax["spacing"]
               for U, p, _ in labs):
            continue                 # the tick already carries this number
        mine = pt(ax, along)
        c = T.centre()
        dm = math.hypot(c[0] - mine[0], c[1] - mine[1])
        best = None
        for a, t, p in ticks:
            # along its OWN axis a number is judged by the slide allowance
            # above; here only the other axis's ticks can claim it
            if a is ax or a["orient"] == ax["orient"]:
                continue
            if math.hypot(p[0] - mine[0], p[1] - mine[1]) < 0.5:
                continue             # the crossing is this axis's tick too
            d = math.hypot(c[0] - p[0], c[1] - p[1])
            if best is None or d < best[0]:
                best = (d, a, t)
        if best is None or dm < OWN_RATIO * best[0]:
            continue
        other = "x" if best[1]["orient"] == "h" else "y"
        out.append("tick label %r stands %.2f x spacing from its own tick at "
                   "%s but %.2f from the %s-axis tick at %s -- it "
                   "reads as %s number; a number that steps aside stays "
                   "nearest its own tick (rule 4): give it room (a step of 2 "
                   "squares, a larger size=, a wider figure) rather than a "
                   "spot beside another tick"
                   % (T.text, dm / ax["spacing"],
                      (M and _at(M, ax, along)) or ("the %s-axis" % name),
                      best[0] / ax["spacing"], other,
                      (M and _at(M, best[1], best[2]))
                      or ("the %s-axis" % other),
                      "that tick's"))
    return out


def _numbering(ax, labs, tol, irregular):
    """(lattice, want_pos): the row's own numbering. want_pos(v) is where
    value v belongs along the axis, or None when the row agrees on none."""
    s = ax["spacing"]
    t0 = ax.get("t0", ax["ticks"][0])
    lat = None if irregular else _lattice(ax, labs, tol)
    if lat:
        v0, dv = lat[0], lat[1]
        return lat, (lambda v: t0 + s * (v - v0) / dv)
    # stage-1 fix r1: fitted on the TICKS the aligned labels stand at (as the
    # lattice is), not on their centres: two numbers each slid a legal 0.13
    # spacing the same way put 0 a quarter spacing off the origin, and the
    # crossing's '0' of y = x^2 - 4 with y = 1/x was refused at every size
    good = [(_near_tick(pos, ax), _value(T.text)) for T, pos, e in labs
            if e <= tol]
    fit = _fit(good)
    if fit:
        return None, (lambda v, fit=fit: (v - fit[0]) / fit[1])
    return None, None


def _row_side(ax, T):
    b = T.box
    if ax["orient"] == "h":
        lo, hi = b[1] - ax["at"], b[3] - ax["at"]
    else:
        lo, hi = b[0] - ax["at"], b[2] - ax["at"]
    side = 1 if lo + hi > 0 else -1
    return side, (lo if side > 0 else -hi)


def _loops(segs, key=lambda p: (round(p[0], 2), round(p[1], 2))):
    """Stage-1 fix r1: the closed shapes drawn as SEPARATE segments (solid=
    edges one by one): every connected set of segments in which each end
    meets exactly one other segment, walked into a vertex list."""
    adj = {}
    for a, b in segs:
        ka, kb = key(a), key(b)
        if ka == kb:
            continue
        adj.setdefault(ka, []).append(kb)
        adj.setdefault(kb, []).append(ka)
    out, seen = [], set()
    for k0 in adj:
        if k0 in seen or len(adj[k0]) != 2:
            continue
        ring, prev, cur, ok = [k0], None, k0, True
        while True:
            seen.add(cur)
            nx = [n for n in adj[cur] if n != prev]
            if len(adj[cur]) != 2 or not nx:
                ok = False
                break
            prev, cur = cur, nx[0]
            if cur == k0:
                break
            if cur in seen:
                ok = False
                break
            ring.append(cur)
        if ok and len(ring) >= 3:
            out.append(ring)
    return out


def closed_shapes(M, least=0.0):
    """Stage-1 fix r1: every drawn CLOSED shape, solid or dashed -- a closed
    outline, a path that returns to its start (a curve through pts + pts[0])
    and a loop of separate segments. The rule against a crossed axis number
    inside a shape covered solid polygons only, and the same triangle drawn
    as solid= segments, a closed curve or dpolys= printed the number inside."""
    shapes = []
    for k in M.strokes:
        P = k.pts
        if len(P) >= 3 and (k.closed or math.hypot(P[0][0] - P[-1][0],
                                                  P[0][1] - P[-1][1]) < 1e-3):
            shapes.append(P)
    segs = [(k.pts[0], k.pts[-1]) for k in M.strokes if len(k.pts) == 2]
    shapes += _loops(segs)
    return [P for P in shapes if _extent(P) > least]


ROW_INK = 3.0        # P3 leftovers r2 (number-leaves-its-row-into-the-drawing):
ROW_NEAR_EM = 0.75   # a number that left its row, standing within ROW_NEAR_EM
ROW_OUT = 0.15       # of a DATA stroke and ROW_INK times nearer that stroke
                     # than the tick it names, reads as the stroke's label.
                     # (3 x, measured: the two reported drawings stood 6.5
                     # and 45.6 times nearer their stroke than their tick,
                     # while the crossed numbers of the shipped figures that
                     # read correctly measure 1.6-2.4.)
                     # A number is OUT of its row when it prints on the
                     # minority side of the axis (rule 4's "the other side")
                     # and stands at least ROW_OUT of a spacing clear of the
                     # axis line. A number pushed further out on its OWN
                     # side is still in the row: the shipped +-16 figure
                     # whose reflected triangle dips under the axis drops
                     # its '12' by 0.34 of a spacing and reads correctly.


def _data_segs(M, axes):
    """The DARK segments that are the drawing: the axis lines, the tick
    marks and the arrowheads on them are furniture, not data."""
    out = []
    for a, b, el in M.dark_segs():
        furniture = False
        for ax in axes:
            j = 1 if ax["orient"] == "h" else 0
            i = 1 - j
            along = abs(a[i] - b[i]) >= abs(a[j] - b[j])
            if along and abs(a[j] - ax["at"]) < 1.2 and \
                    abs(b[j] - ax["at"]) < 1.2:
                furniture = True            # the axis itself
                break
            if not along and math.hypot(a[0] - b[0], a[1] - b[1]) \
                    <= 0.45 * ax["spacing"] and \
                    min(a[j], b[j]) - 1.0 <= ax["at"] <= max(a[j], b[j]) + 1.0:
                furniture = True            # a tick mark across it
                break
        if not furniture:
            out.append((a, b))
    return out


def _box_gap(box, a, b):
    """The gap between a text's box and the segment a-b (0 when they meet)."""
    d = None
    n = max(2, int(math.hypot(a[0] - b[0], a[1] - b[1]) / 2.0) + 1)
    for k in range(n + 1):
        t = k / float(n)
        q = (a[0] + t * (b[0] - a[0]), a[1] + t * (b[1] - a[1]))
        g = math.hypot(max(box[0] - q[0], 0.0, q[0] - box[2]),
                       max(box[1] - q[1], 0.0, q[1] - box[3]))
        d = g if d is None else min(d, g)
    return d


def _number_on_data(M, ax, labs, axes):
    """P3 leftovers r2 (number-leaves-its-row-into-the-drawing, must): an
    axis number that left its row and landed ON the drawing.

    Rule 4 lets one number slide a little, then take the other side of the
    axis. Neither step hands it to another object, and every sweep was
    silent when one did: the skill's own gallery printed the x '2' of the
    `divide` figure 0.77 of a spacing above the number row, beside the
    dashed median, while -2/0/4/6/8 stayed in the row; the rebuilt pilot's
    run/rise figure printed its x '2' across the axis 6.1px from the dashed
    RISER and 13.3px from its own tick -- 2.2 x nearer the data stroke than
    the tick it names, in the one figure where a number beside the vertical
    leg reads as the rise. number_owns_its_tick (the r1 fix for this family)
    needs a NAMED point marker, so a number that lands on a dashed leg, a
    polygon edge or a median was judged by nothing.

    Measured on the finished file: the row's own offset from the axis, the
    gap from the digits to the nearest DATA stroke, the distance from the
    digits' centre to the tick the number names."""
    out = []
    if len(labs) < 2:
        return out
    j = 1 if ax["orient"] == "h" else 0
    sides = [1 if (T.centre()[j] - ax["at"]) > 0 else -1 for T, _, _ in labs]
    if len(set(sides)) == 1:
        return out                          # one row, nothing to judge
    home = 1 if sides.count(1) >= sides.count(-1) else -1
    segs = None
    for T, pos, e in labs:
        c = T.centre()
        if (1 if (c[j] - ax["at"]) > 0 else -1) == home or \
                abs(c[j] - ax["at"]) <= ROW_OUT * ax["spacing"]:
            continue                       # in its row, or barely off it
        tick = min(ax["ticks"], key=lambda t: abs(t - pos)) \
            if ax["ticks"] else None
        if tick is None:
            continue
        # ... and it really is THAT TICK'S number. A length over a base on
        # the axis, a point's value or a jump's label prints off the row by
        # design and carries a value of its own ('5' over the base from 2 to
        # 7 is nearest the tick at 4): judged as a slid tick number, such a
        # label was refused wherever it stood.
        sc = _scale_of(M, ax)
        if sc:
            at = sc[1] + (tick - sc[0]) * sc[2]
            v = _value(T.text)
            if v is None or abs(v - at) > 1e-6:
                continue
        own = (tick, ax["at"]) if ax["orient"] == "h" else (ax["at"], tick)
        dt = math.hypot(c[0] - own[0], c[1] - own[1])
        if dt <= 1e-9:
            continue
        if segs is None:
            segs = _data_segs(M, axes)
        for a, b in segs:
            g = _box_gap(T.box, a, b)
            if g <= ROW_NEAR_EM * T.size and g * ROW_INK < dt:
                out.append(
                    "tick label %r has left the row of numbers and prints "
                    "%.2f of a spacing from its own tick, %.1f x nearer a "
                    "drawn stroke than that tick -- it reads as that "
                    "stroke's label, not the axis's (rule 4 moves a number a "
                    "little; it never hands it to another object). Keep the "
                    "row together: a step of 2 squares, a larger size= or a "
                    "wider figure (max_width=)"
                    % (T.text, dt / ax["spacing"], dt / max(g, 1e-6)))
                break
    return out


def _zero_has_a_free_corner(M):
    """v6.2 Q1 (doctrine 4): is there anywhere better for the origin's '0'?

    zero_owner_strict is a MEASUREMENT that problems() did not run, and the
    reason it shipped that way is written in its own docstring: a plane whose
    every corner is filled -- both diagonals drawn through the origin -- has
    nowhere nearer at any width, so refusing it would name no fix that works.
    problems() runs the rule now, and this is the gate that keeps doctrine 4:
    the refusal fires only when one of the four corners of the crossing is
    free paper, which IS a fix (the ladder's bigger size or width puts the
    '0' there). The both-diagonals plane keeps rendering.

    Read off the finished file: the four boxes a '0' would occupy at the
    corners of the axes' crossing, against the DATA strokes."""
    axes = _axes(M)
    H = [a for a in axes if a["orient"] == "h"]
    V = [a for a in axes if a["orient"] == "v"]
    if not H or not V:
        return False
    z = [T for T in M.texts if T.text.strip() == "0" and T.box]
    if not z:
        return False
    T0 = z[0]
    w = (T0.box[2] - T0.box[0]) / 2.0
    h = (T0.box[3] - T0.box[1]) / 2.0
    o = (V[0]["at"], H[0]["at"])
    segs = _data_segs(M, axes)
    for sx in (-1, 1):
        for sy in (-1, 1):
            c = (o[0] + sx * (w + 0.6 * T0.size),
                 o[1] + sy * (h + 0.6 * T0.size))
            box = (c[0] - w, c[1] - h, c[0] + w, c[1] + h)
            if not any(_box_gap(box, p, q) <= 0.5 for p, q in segs):
                return True
    return False


def zero_owner_strict(svg):
    """P3 leftovers r2 (L1-P3r2-02): the origin's '0' read by rule 4 taken
    literally -- nearer the axes' CROSSING than any other tick when it was
    pushed ALONG an axis (a corner '0' on the diagonal keeps ZERO_RATIO's
    slack, which was measured on corner zeros).

    Public and tested, not part of problems(): a plane whose corners are all
    filled -- both diagonals through the origin -- has nowhere nearer at any
    width, so a refusal would name no fix that works. figkit solves the
    origin with this bound FIRST and falls back to the corner margin, which
    is what moves the '0' in when there is room (it printed 1.06 squares
    along the x-axis of the plain two-diagonal plane: 1.12 squares from the
    crossing, 1.00 from the tick at x = -2, problems() == [])."""
    M = _M(svg)
    return _zero_owner(M, _axes(M), strict=True)


def row_straddles(svg):
    """P3 leftovers r2 (number-row-straddles-its-axis): the axes whose row of
    numbers prints on BOTH sides, read off a finished file.

    Public and tested, not part of problems(): the builder keeps the rule it
    shipped with (a row that changes side once is still a row), because
    holding the tighter rule inside the solver re-placed rows across
    figures that had settled. Use this to audit a sheet -- level a item 4b
    of the rebuilt pilot printed '0' and '2' above the x-axis with '4' and
    '6' below it, and the same call at width >= 180 keeps all three x
    numbers on one side."""
    M = _M(svg)
    axes = _axes(M)
    if len(set(a["orient"] for a in axes)) != 2 or getattr(M, "critique",
                                                           False):
        return []
    out = []
    groups = _axis_labels(M, axes)
    for i, all_labs in groups.items():
        ax = axes[i]
        labs = [l for l in all_labs
                if not (_value(l[0].text) == 0
                        and _zero_corner(M, ax, axes, l[0]))]
        rows = _rows(ax, labs)
        if not rows:
            continue
        main = list(rows[0])
        rest = [list(r) for r in rows[1:]]
        if rest:
            main, rest = _mirrors(ax, main, rest, TICK_TOL, M)
        out += _row_straddles(ax, main)
    return out


def number_on_data(svg):
    """P3 leftovers r2 (number-leaves-its-row-into-the-drawing): the numbers
    that left their row and landed ON the drawing, read off a finished file.

    Public and tested, but NOT part of problems(): where it fires, the
    placement is often the only one there is -- the gallery's parallelogram
    keeps an edge beside the tick at x = -2 at EVERY width, so a refusal
    would name no fix that works (doctrine 4). The builder is what prevents
    it: figkit passes over a crossed spot whose stroke is _ROW_INK x nearer
    than the tick and takes it only as a last resort, which is what moved
    the two reported drawings (the gallery's `divide` and the pilot's
    run/rise figure) back into their rows. Use it to audit a sheet."""
    M = _M(svg)
    axes = _axes(M)
    if len(set(a["orient"] for a in axes)) != 2 or getattr(M, "critique",
                                                           False):
        return []
    out = []
    groups = _axis_labels(M, axes)
    for i, all_labs in groups.items():
        ax = axes[i]
        labs = [l for l in all_labs
                if not (_value(l[0].text) == 0
                        and _zero_corner(M, ax, axes, l[0]))]
        rows = _rows(ax, labs)
        if not rows:
            continue
        main = list(rows[0])
        rest = [list(r) for r in rows[1:]]
        if rest:
            main, rest = _mirrors(ax, main, rest, TICK_TOL, M)
        out += _number_on_data(M, ax, main, axes)
    return out


ROW_CROSS_SHARE = 3   # P3 leftovers r2 (number-row-straddles-its-axis): at
                      # most one number in this many (and never fewer than
                      # one) may print on the other side of the axis from
                      # the rest of its row. Rule 4 lets THE COLLIDING number
                      # take the other side; a row split in two blocks is two
                      # rows to a reader. One in three: a hyperbola that
                      # runs along the axis at BOTH ends blocks the end
                      # number at each end, and each of those crossing is
                      # rule 4 doing its work (2 of 6). The pilot's 4b row
                      # is 2 of 4, which is a second row.


def _row_straddles(ax, labs):
    """A row of axis numbers printed on BOTH sides of its axis.

    figkit._row_reads allowed any split that changed side ONCE ("two blocks,
    one change"), so a four-number row could print two above the axis and two
    below it and nothing said a word: level a item 4b of the rebuilt pilot
    printed '0' and '2' above the x-axis and '4' and '6' below it, and the
    three sister figures of the same question each straddled differently.
    Read here off the finished file, so a row assembled by any builder is
    judged the same."""
    labs = [l for l in labs if l[0].box]
    if len(labs) < 3:
        return []
    # read along the axis, so "next to each other" means what it says
    order = sorted(range(len(labs)),
                   key=lambda k: labs[k][0].centre()[0 if ax["orient"] == "h"
                                                     else 1])
    labs = [labs[k] for k in order]
    sides = [_row_side(ax, T)[0] for T, _, _ in labs]
    few = 1 if sides.count(1) <= sides.count(-1) else -1
    n = sides.count(few)
    # Stage review: the share alone let 2 of 6 cross, and the commonest
    # straddle IS 2 of 6 -- x numbers -6 and -4 below a sine curve's axis
    # with -2, 2, 4, 6 above it, two rows on paper and row_straddles() == [].
    # Rule 4 moves the ONE number a stroke blocks, so two crossers standing
    # SIDE BY SIDE are a second block whatever the share says; crossers that
    # each stand alone (a hyperbola blocking the end number at both ends)
    # are rule 4 doing its work.
    run = best = 0
    for sd in sides:
        run = run + 1 if sd == few else 0
        best = max(best, run)
    if best < 2 and n <= max(1, len(labs) // ROW_CROSS_SHARE):
        return []
    odd = [T.text for (T, _, _), sd in zip(labs, sides) if sd == few]
    return ["the %s-axis numbers print on BOTH sides of the axis (%d of %d "
            "on the other side: %s) -- that is two rows of numbers, not one "
            "with a number dodging (rule 4 moves ONLY the number a stroke "
            "blocks). Keep the row together: a step of 2 squares, a larger "
            "size= or a wider figure (max_width=)"
            % ("x" if ax["orient"] == "h" else "y", n, len(labs), odd)]


def _scale_of(M, ax):
    """(pixel, value, value per pixel) for one axis, read off its own printed
    numbers -- or None when fewer than two of them can be paired with a tick.

    P3 leftovers r2 (P3r2-PIXEL-COORDS-IN-REFUSALS): refusals named positions
    in SVG PIXELS formatted exactly like data coordinates ("its own tick at
    x 145.8", "the point marker at (180.9, 176.0)" on a window of -7..7). A
    builder cannot find the object such a refusal blames."""
    pairs = []
    for T in M.texts:
        if not T.box or not _NUMTXT.match(T.text.strip()):
            continue
        v = _value(T.text)
        if v is None:
            continue
        if _perp_gap(T.box, ax) > ax["half"] + 1.6 * T.size:
            continue
        pos = _along(T, ax)
        t = min(ax["ticks"], key=lambda q: abs(q - pos)) if ax["ticks"] \
            else None
        if t is None or abs(t - pos) > MOVED_TOL * ax["spacing"]:
            continue
        pairs.append((t, v))
    pairs = sorted(set(pairs))
    for (p0, v0), (p1, v1) in zip(pairs, pairs[1:]):
        if abs(p1 - p0) > 1e-6 and abs(v1 - v0) > 1e-9:
            return (p0, v0, (v1 - v0) / (p1 - p0))
    return None


def _at(M, ax, pos, axes=None):
    """ "x = -3" for a position ALONG an axis, or "" when the file's own
    numbers do not say what value stands there. Never an SVG pixel."""
    sc = _scale_of(M, ax)
    if not sc:
        return ""
    v = sc[1] + (pos - sc[0]) * sc[2]
    if abs(v - round(v)) < 0.02:
        v = round(v)
    return "%s = %s" % ("x" if ax["orient"] == "h" else "y",
                        ("%.6g" % v).replace("-", MINUS))


def _at_point(M, axes, c):
    """ "(2, -1)" for a point of the drawing, or "" -- the data coordinates
    a builder can look up, never the SVG pixels."""
    H = [a for a in axes if a["orient"] == "h"]
    V = [a for a in axes if a["orient"] == "v"]
    if not H or not V:
        return ""
    sx, sy = _scale_of(M, H[0]), _scale_of(M, V[0])
    if not sx or not sy:
        return ""
    x = sx[1] + (c[0] - sx[0]) * sx[2]
    y = sy[1] + (c[1] - sy[0]) * sy[2]
    out = []
    for v in (x, y):
        if abs(v - round(v)) < 0.02:
            v = round(v)
        out.append(("%.6g" % v).replace("-", MINUS))
    return "(%s, %s)" % tuple(out)


# ---- a NUMBER printed on a plane is a claim about the drawing (stage review)
# On a coordinate plane a number printed on the drawing was never measured
# against the geometry it names: a point labelled 'A(3, 1)' whose dot sits at
# (2, 1), and a length printed beside a dimension arrow that spans 6 units,
# both rendered with problems() == []. The same claim is measured everywhere
# else -- a jump label against b - a, a span label against |b - a|, an angle
# text against its arc, an equality tick against the lengths it marks, a
# number line's own point value against its dot. Rule 7 puts 'A(3, 1)' into
# the SVG verbatim, so it is exactly what an analytic-geometry sheet prints.
PAIR_TOL = 0.05          # squares: a printed coordinate against its dot
DIM_TOL = 0.05           # squares: a length printed beside a dimension arrow
_PAIR_TXT = re.compile(
    u"^\\s*([A-Za-z][A-Za-z0-9_']{0,2})?\\s*\\(\\s*([-\u2212]?[\\d.,]+)\\s*[,;]\\s*"
    u"([-\u2212]?[\\d.,]+)\\s*\\)\\s*$")


def _plane_scales(M, axes):
    """(x scale, y scale) of a coordinate plane, each (pixel, value, per px),
    or None when the file's own numbers do not fix them."""
    H = [a for a in axes if a["orient"] == "h"]
    V = [a for a in axes if a["orient"] == "v"]
    if not H or not V:
        return None
    sx, sy = _scale_of(M, H[0]), _scale_of(M, V[0])
    return (sx, sy) if sx and sy else None


def _data_xy(sx, sy, c):
    return (sx[1] + (c[0] - sx[0]) * sx[2], sy[1] + (c[1] - sy[0]) * sy[2])


def value_labels(svg):
    """v6.1 stage review: every NUMBER printed on a coordinate plane measured
    against the geometry it names.

      * a text 'A(3, 1)' (or '(3, 1)') claims the coordinates of the point it
        labels: the nearest dot or marker is read back through the axis
        numbers and must BE that pair;
      * a bare number printed beside a horizontal or vertical DIMENSION
        ARROW claims the arrow's length in squares.

    Only unambiguous cases are judged: a pair label with exactly one dot
    within reading distance, and a dimension arrow whose own number stands
    over its shaft."""
    M = _M(svg)
    axes = _axes(M)
    if len(set(a["orient"] for a in axes)) != 2 or getattr(M, "critique",
                                                           False):
        return []
    sc = _plane_scales(M, axes)
    if not sc:
        return []
    sx, sy = sc
    out = []
    dots = [(cx, cy, r) for cx, cy, r, _ in M.dots]
    for T in M.texts:
        if not T.box:
            continue
        m = _PAIR_TXT.match(T.text.strip())
        if not m:
            continue
        try:
            px_, py_ = (float(g.replace(MINUS, "-").replace(",", "."))
                        for g in m.group(2, 3))
        except ValueError:
            continue
        c = T.centre()
        reach = 3.2 * T.size
        near = sorted(((_d(c, (dx, dy)), (dx, dy)) for dx, dy, _ in dots),
                      key=lambda q: q[0])
        near = [q for q in near if q[0] <= reach]
        if len(near) != 1:
            continue                      # no point of its own, or a crowd
        gx, gy = _data_xy(sx, sy, near[0][1])
        step = abs(1.0 / sx[2]), abs(1.0 / sy[2])
        if abs(gx - px_) * abs(sx[2]) * step[0] > PAIR_TOL or \
                abs(gy - py_) * abs(sy[2]) * step[1] > PAIR_TOL:
            out.append(
                "the label %r names the point (%s, %s) but its dot stands at "
                "(%s, %s) -- a printed pair IS the point it labels. Draw the "
                "dot at the coordinates the label prints, or print the "
                "coordinates the dot has; never leave the two disagreeing"
                % (T.text, _n(px_), _n(py_), _n(gx), _n(gy)))
    out += _dimension_labels(M, sx, sy)
    return out


def _n(v):
    if abs(v - round(v)) < 0.02:
        v = round(v)
    return ("%.6g" % v).replace("-", MINUS)


def _dimension_labels(M, sx, sy):
    """A bare number standing over a horizontal or vertical arrow is that
    arrow's length in squares."""
    out = []
    heads = _arrows(M)[0]
    axes = _axes(M)
    # An axis's own tick numbers are not a dimension arrow's label. A text
    # is one when it stands in an axis's number row AND reads as the value
    # its position on that axis has -- _axis_labels alone also collects the
    # value labels printed in that band, which is what number_on_data is for.
    axis_texts = set()
    for i, g in _axis_labels(M, axes).items():
        ax = axes[i]
        sc = _scale_of(M, ax)
        if not sc:
            continue
        for T, _, _ in g:
            v = _value(T.text)
            if v is None:
                continue
            at = sc[1] + (_along(T, ax) - sc[0]) * sc[2]
            if abs(v - at) <= 0.2:
                axis_texts.add(id(T))
    for h in heads:
        (x1, y1), (x2, y2) = h[0], h[1]          # tip, shaft start
        horiz = abs(y2 - y1) < 0.6
        vert = abs(x2 - x1) < 0.6
        if not (horiz or vert):
            continue
        # an AXIS's own arrowhead is not a dimension arrow
        pos = y1 if horiz else x1
        if any((a["orient"] == "h") == horiz and abs(a["at"] - pos) < 2.0
               for a in axes):
            continue
        L = abs(x2 - x1) if horiz else abs(y2 - y1)
        if L < 4.0:
            continue
        span = L * abs(sx[2] if horiz else sy[2])
        mid = ((x1 + x2) / 2.0, (y1 + y2) / 2.0)
        L = abs(x2 - x1) if horiz else abs(y2 - y1)
        for T in M.texts:
            if not T.box or id(T) in axis_texts or \
                    not _NUMTXT.match(T.text.strip()):
                continue
            v = _value(T.text)
            if v is None or v <= 0:      # a length is positive; '0' is an
                continue                 # axis number, never an arrow's label
            c = T.centre()
            along = abs(c[0] - mid[0]) if horiz else abs(c[1] - mid[1])
            across = abs(c[1] - mid[1]) if horiz else abs(c[0] - mid[0])
            if along > L / 2.0 or across > 2.2 * T.size:
                continue
            if abs(v - span) > DIM_TOL + 0.02 * max(1.0, span):
                out.append(
                    "the length %r printed beside the arrow measures %s "
                    "squares on the drawing -- a printed length IS the arrow "
                    "it labels. Draw the arrow the length the number says, or "
                    "print the length the arrow has" % (T.text, _n(span)))
            break
    return out


def _crossed_into_shape(M, ax):
    """C7P2-04: a tick number printed ACROSS its axis (see _mirrors) whose
    centre lies inside a drawn closed shape reads as that shape's number (a
    side length), not the axis's: the y '2' of a +-7 plane stood between the
    triangle's edges AC and BC, every other y number left of the axis."""
    out = []
    polys = closed_shapes(M, 2 * ax["spacing"])
    for T, off in ax.pop("_crossed", ()):
        # only a number standing at its own tick (within the step-aside
        # allowance) is the axis's number moved across; a length printed at
        # the middle of a base on the axis ('2' at 1) is a value label
        if off > MOVED_TOL + 1e-6:
            continue
        c = T.centre()
        if any(_in_poly(c, P) for P in polys):
            out.append("tick label %r stands across its axis INSIDE a drawn "
                       "shape -- it reads as the shape's number, not the "
                       "axis's; keep it on its row: a step of 2 squares, a "
                       "larger size= or a wider figure (max_width=)" % T.text)
    return out


def _carried(M, ax, T):
    """C7P2-02: is there a dark stroke BETWEEN the text T and the axis, running
    right across T's column (along the axis within 30 degrees)? A span's
    shaft or a jump's arc stands between its length label and the line; a
    tick number printed across the axis has nothing between it and its tick."""
    h = ax["orient"] == "h"
    b = T.box
    lo, hi = (b[0], b[2]) if h else (b[1], b[3])
    near = (b[3] if b[3] <= ax["at"] else b[1]) if h else \
        (b[2] if b[2] <= ax["at"] else b[0])
    a0, a1 = sorted((near, ax["at"]))
    mid = (lo + hi) / 2.0
    for p, q, _ in M.dark_segs():
        i, j = (0, 1) if h else (1, 0)
        if abs(q[i] - p[i]) < 1e-9:
            continue
        if abs(q[j] - p[j]) > math.tan(math.radians(30.0)) * abs(q[i] - p[i]):
            continue
        if not (min(p[i], q[i]) <= mid <= max(p[i], q[i])):
            continue
        t = (mid - p[i]) / (q[i] - p[i])
        c = p[j] + t * (q[j] - p[j])
        if a0 + 0.5 < c < a1 - 0.5:
            return True
    return False


def _mirrors(ax, main, rest, tol, M=None):
    """C2 round 2: a tick number the figure engine printed ACROSS the axis
    (a plotted point sat on its usual spot) is still this axis's number.
    Moved into the main row -- and so judged on distance and value -- when
    it sits on the other side at the main row's offset (within _MIRROR_EM of
    it, by its near edge) and its value belongs within 1.5 spacings of where
    it is. Unjudged, a number could be printed a third of a square off its
    tick there and pass.

    v6 stage 1b r2: the allowance was 0.35 em, while the engine may step a
    crossed number PIN_DROP_EM (0.70 em) further out. A number that took that
    step landed in a row of its own, which _lattice throws out for being one
    member long, and was then judged by nothing at all -- the gallery's
    `divide` figure could have its crossed '2' printed 0.68 of a spacing from
    its tick and every sweep still called the file clean. The allowance now
    covers the step-out."""
    if not main:
        return main, rest
    lat, want = _numbering(ax, main, tol, False) if len(main) >= 2 else (None, None)
    sides = [_row_side(ax, T) for T, _, _ in main]
    side = 1 if sum(sd for sd, _ in sides) > 0 else -1
    nears = sorted(n for sd, n in sides if sd == side)
    med = nears[len(nears) // 2]
    out = []
    for r in rest:
        keep = []
        for lab in r:
            T, pos, e = lab
            sd, n = _row_side(ax, T)
            # with no numbering to ask (one number in the row, or a row whose
            # numbers do not agree: C2 round 3), a number on a tick's side of
            # the half-way line between two ticks is taken as that tick's
            off = abs(n - med)
            near = off <= 0.35 * T.size
            if want is not None:
                d = abs(want(_value(T.text)) - pos) / ax["spacing"]
                # at the row's own offset a number is this axis's while its
                # value belongs anywhere near (SLID_REACH); a number that has
                # also stepped OUT (v6 stage 1b r2, up to figkit's PIN_DROP_EM)
                # is one only while it stands about where its own value goes --
                # otherwise a jump's '+2' over its arc, or a length above the
                # axis, would be read as this axis's slid number
                mine = d < (SLID_REACH if near else _MIRROR_REACH)
            else:
                mine = e <= (_LONE_REACH if near else _MIRROR_REACH)
            if sd != side and off <= _MIRROR_EM * T.size and mine and \
                    not (M is not None and _carried(M, ax, T)):
                # a far mirror is judged on DISTANCE only: it never joins the
                # lattice vote, where a point's value printed on a tick
                # ('3.1' over the dot at 3) would read as a wrong number
                main.append(lab if near else (T, pos, max(e, tol + 1e-6)))
                if M is not None:
                    off_tick = d if want is not None else e
                    v = _value(T.text)
                    # a value the row's numbering prints at all (5 is no
                    # number of an axis numbered 2, 4, 6: a base's length)
                    if lat and v is not None and lat[1]:
                        q = (v - lat[0]) / lat[1]
                        if abs(q - round(q)) > 1e-6:
                            off_tick = 99.0
                    ax.setdefault("_crossed", []).append((T, off_tick))
            else:
                keep.append(lab)
        out.append(keep)
    return main, out


def _crossings(M, ax, axes):
    """Where a perpendicular axis (a found one, or a long perpendicular dark
    stroke) crosses `ax`, as positions along `ax`."""
    h = ax["orient"] == "h"
    cross = [o["at"] for o in axes or () if o["orient"] != ax["orient"]
             and o["lo"] - 1.0 <= ax["at"] <= o["hi"] + 1.0]
    for a, b, _ in M.dark_segs():
        i, j = (0, 1) if h else (1, 0)        # i: along ax, j: across it
        if abs(a[i] - b[i]) < 0.3 and abs(a[j] - b[j]) >= 2 * ax["spacing"] \
                and min(a[j], b[j]) - 1.0 <= ax["at"] <= max(a[j], b[j]) + 1.0:
            cross.append((a[i] + b[i]) / 2.0)
    return cross


def _nice_scale(r):
    """r is a step a person numbers an axis by: 1, 2, 2.5 or 5 x 10^k."""
    if not r > 0:
        return False
    k = math.floor(math.log10(r) + 1e-9)
    m = r / 10.0 ** k
    return any(abs(m - n) <= 1e-3 * n for n in (1.0, 2.0, 2.5, 5.0, 10.0))


def _fits_nice(v, n, tol, at_value=0.0):
    """Is there a step r a person numbers by (_nice_scale) on which the value
    v is a TICK (v / r whole) within tol squares of n squares from the 0 --
    or, a value printed at its own place between ticks, within at_value?"""
    if abs(n) < 0.5:
        return False
    r0 = v / n
    if r0 <= 0:
        return False
    k0 = int(math.floor(math.log10(r0)))
    for k in range(k0 - 1, k0 + 2):
        for m in (1.0, 2.0, 2.5, 5.0):
            r = m * 10.0 ** k
            q = v / r
            if abs(q - n) <= at_value + 1e-9 or \
                    (abs(q - round(q)) < 1e-6 and abs(q - n) <= tol + 1e-9):
                return True
    return False


def _mark_owns(M, ax, axes, T, mark):
    """Stage-1 open issue (C2 svgcheck-lone-far-shift-unjudged): on an axis
    measured by its grid (one or two tick marks), a lone number more than one
    square from its mark was never judged -- a '6' printed 1.2 squares right
    of its tick reads as 7.2 and passed. The number is that mark's when the
    axes' crossing (the 0) and the mark give its value a step a person
    numbers by (the mark 6 squares from 0 carries '6', '12', '3', '60'...);
    then it is judged against the mark however far it went. A value label
    whose number does not fit the mark ('4' as a base length, mark at 6) is
    left to label_ownership."""
    v = _value(T.text)
    if v is None or v == 0:
        return False
    for c in _crossings(M, ax, axes):
        n = (mark - c) if ax["orient"] == "h" else (c - mark)
        n /= ax["spacing"]
        if abs(n) >= 0.5 and _nice_scale(v / n):
            return True
    return False


def _zero_corner(M, ax, axes, T):
    """Where a perpendicular axis (a found one, or a long perpendicular dark
    stroke) crosses `ax`, if the text T lies wholly inside one quadrant of
    that crossing with its nearest corner within one em of it; else None."""
    h = ax["orient"] == "h"
    bx = T.box
    for c in _crossings(M, ax, axes):
        if not (ax["lo"] - 1.0 <= c <= ax["hi"] + 1.0):
            continue
        cx, cy = (c, ax["at"]) if h else (ax["at"], c)
        if bx[0] < cx < bx[2] or bx[1] < cy < bx[3]:
            continue
        dx = min(abs(bx[0] - cx), abs(bx[2] - cx))
        dy = min(abs(bx[1] - cy), abs(bx[3] - cy))
        # one em of the crossing, plus the step aside every number may take to
        # keep a stroke whole (v6 stage 1b): a '0' pushed out of its corner by
        # a line through the origin is still that crossing's zero
        if max(dx, dy) <= T.size + MOVED_TOL * ax["spacing"]:
            return (c,)
    return None


def _origin_slot(M, ax, axes, T, want0, tol):
    """A '0' printed ONCE for both axes, in a corner of their crossing (E6),
    where this axis's own numbering puts 0 (within tol x spacing)."""
    if want0 is None:
        return False
    c = _zero_corner(M, ax, axes, T)
    return bool(c) and abs(want0 - c[0]) <= tol * ax["spacing"]


def _corner_zeros(M, axes, groups, tol, irregular):
    """C2 round 2: every '0' in a corner of a crossing is judged against the
    numbering of EACH axis it sits beside. It used to be judged inside one
    row, where it was skipped as 'a value label' when 0 belonged more than
    1.5 spacings away, or as 'the tick already carries this number' when a
    shifted numbering printed another '0' on a tick -- so a plane whose
    numbers all read one too high passed with the '0' contradicting them."""
    out = []
    zeros = [T for T in M.texts if T.box and _NUMTXT.match(T.text.strip())
             and _value(T.text) == 0]
    for i, ax in enumerate(axes):
        rows = _rows(ax, [l for l in groups.get(i, ())
                          if _value(l[0].text) != 0])
        if not rows:
            continue
        _, want = _numbering(ax, rows[0], tol, irregular)
        if want is None:
            continue
        name = "x" if ax["orient"] == "h" else "y"
        for T in zeros:
            c = _zero_corner(M, ax, axes, T)
            if not c:
                continue
            off = abs(want(0.0) - c[0]) / ax["spacing"]
            if off > tol:
                out.append("tick label '0' sits in the corner of the axes' "
                           "crossing, but the %s-axis numbering puts 0 %.2f x "
                           "spacing from it, at %s %.1f -- the numbers or the "
                           "'0' are wrong" % (name, off, name, want(0.0)))
    return out


def _judge_row(ax, labs, tol, distance, irregular, axes=None, M=None):
    out = []
    s = ax["spacing"]
    t0 = ax.get("t0", ax["ticks"][0])
    name = "x" if ax["orient"] == "h" else "y"
    lat, want_pos = _numbering(ax, labs, tol, irregular)
    texts_at = {}
    for T, pos, e in labs:
        if e <= tol:
            texts_at.setdefault(T.text, []).append(pos)
    if lat:
        v0, dv, inl, pts = lat
        for n, (k, v, T) in enumerate(pts):
            if n in inl:
                continue
            right = v0 + dv * k
            out.append("tick label %r sits on the tick of %s at %s %.1f — "
                       "print each number on its own tick (if it is not "
                       "this axis's number but a jump, a length or a "
                       "point's value, print it off the row of axis "
                       "numbers: across the axis or a line farther out; "
                       "never drop it)"
                       % (T.text, ("%.6g" % right).replace("-", MINUS),
                          name, t0 + s * k))
    numbered = len(labs) >= 2
    moved = []
    cross0 = None
    if not want_pos and not ax.get("marks") and distance and not irregular \
            and M is not None:
        cs = _crossings(M, ax, axes)
        cross0 = cs[0] if cs else None

    def misread(T, pos):
        """C7N-03: on an axis with a tick at every square (sparse=True, a row
        of one or two listed numbers) a number moved a whole square lands ON
        another tick, 0.00 from "a tick", and nothing asked what it says.
        With no row to vote, a number the distance rules accept is judged by
        the axes' crossing (the 0): some step a person numbers by must put
        its value on a tick within the slide allowance of where it stands."""
        v = _value(T.text)
        if cross0 is None or not v:
            return False
        n = ((pos - cross0) if ax["orient"] == "h" else (cross0 - pos)) / s
        if _fits_nice(v, n, MOVED_TOL, tol):
            return False
        out.append("tick label %r stands %.2f squares from the axes' crossing "
                   "(the 0), where no regular numbering puts %s — it reads as "
                   "another tick's number; print it on its own tick"
                   % (T.text, n, T.text))
        return True

    def past(pos):
        if M is None or not distance or irregular:
            return False
        t = ax["ticks"]
        a, b = _free_ends(M, ax, axes)
        return (a and pos < t[0] - MOVED_TOL * s) or \
            (b and pos > t[-1] + MOVED_TOL * s)

    def past_msg(T, pos):
        t = ax["ticks"]
        d = (t[0] - pos if pos < t[0] else pos - t[-1]) / s
        return ("tick label %r stands %.2f x spacing past the end of the "
                "%s-axis ticks, where the axis has no tick to carry it (the "
                "axis letter and the figure's edge are there) — print it on "
                "its own tick; if it cannot fit, give it room (a larger "
                "size=, a wider figure or a longer window), never drop it"
                % (T.text, d, name))

    for T, pos, e in labs:
        if not numbered and not want_pos and ax.get("marks") and distance:
            # judged against its MARK, not the nearest grid line: a lone '6'
            # slid a whole square onto the unmarked grid line of 7 stood 0.00
            # from "a tick" and passed (stage-1 open issue C2)
            e = min(abs(pos - t) for t in ax["marks"]) / s
        if e <= tol or not distance:
            if distance:
                misread(T, pos)
            continue
        at = _near_tick(pos, ax)
        # v6 stage 1b: the step-aside concession (MOVED_TOL) belongs to a
        # number that stands ON A TICK and was driven off it by a stroke. A
        # value printed BETWEEN ticks ('2.5' at 2.5) has no tick to be driven
        # off, so it stays judged at `tol`.
        on_tick = True
        if want_pos and M is not None and _value(T.text) == 0 and \
                _origin_slot(M, ax, axes, T, want_pos(0.0), tol):
            continue                # the origin's '0', in a corner of it
        if want_pos:
            want = want_pos(_value(T.text))
            if abs(want - pos) >= SLID_REACH * s:
                if past(pos):
                    out.append(past_msg(T, pos))
                continue            # a value label, not this axis's number
            if abs(want - pos) <= tol * s:
                continue            # printed at its own value between ticks
            if any(abs(p - want) <= tol * s for p in texts_at.get(T.text, [])):
                continue            # the tick already carries this number
            k = (want - t0) / s
            on_tick = abs(k - round(k)) < 0.05
            e, at = abs(pos - want) / s, want
        elif not numbered:
            # C2 round 3: a lone number (sparse=True with one listed value, or
            # xticks=[6]) has no row to vote with, and was never judged. It is
            # judged against its nearest tick; one half-way between two ticks
            # ('2.5' at 2.5) is a value, not a slid number.
            # On an axis measured by its grid (one or two tick marks), the
            # number belongs to the nearest MARK within one square.
            if ax.get("marks"):
                at = min(ax["marks"], key=lambda t: abs(t - pos))
                e = abs(pos - at) / s
                if e <= tol or (e > 1.0 and not (
                        M is not None and _mark_owns(M, ax, axes, T, at))):
                    continue
            elif e > _LONE_REACH:
                # O3-02: halfway between two ticks is a value ('2.5' at 2.5)
                # only if that IS its value; a '5' at 5.5 squares, or past
                # the end of the ticks, is a slid number
                if past(pos):
                    out.append(past_msg(T, pos))
                else:
                    misread(T, pos)
                continue
        if e <= MOVED_TOL and on_tick:
            # v6 stage 1b: a number a stroke drove aside. Legal on its own --
            # it is still nearer its own tick than any other -- and refused
            # below when the whole ROW has drifted.
            if misread(T, pos):
                continue
            moved.append((T, e, at))
            continue
        out.append("tick label %r sits %.2f x spacing from its tick at "
                   "%s %.1f (tolerance %.2f; a number a stroke drives aside "
                   "may stand up to %.2f from its tick, no further) — pin it "
                   "to the tick"
                   % (T.text, e, name, at, tol, MOVED_TOL))
    if moved and (len(moved) > max(MOVED_LEAST, len(labs) // MOVED_SHARE)
                  or (len(moved) == len(labs) and len(labs) >= 2)):
        for T, e, at in moved:
            out.append("tick label %r sits %.2f x spacing from its tick at "
                       "%s %.1f — the ROW of numbers has slid off its ticks "
                       "(tolerance %.2f; only one number in %d may be moved "
                       "aside to keep a stroke whole, never the whole row, "
                       "and never past %.2f) — pin the numbers to their ticks"
                       % (T.text, e, name, at, tol, MOVED_SHARE, MOVED_TOL))
    return out


def _key(p):
    return (round(p[0], 1), round(p[1], 1))


def _shaft(p, idx, segs, ends):
    """Follow a stroke from `p` along segment `idx` for as long as it runs on
    as ONE line: through every joint where exactly one other segment
    continues without turning a corner. A straight shaft is one segment; a
    jump arc written as a Q path, or sampled into an M L L ... polyline the
    way figkit emits curves, is many short ones. Returns the points walked."""
    pts = [p]
    a, b, _ = segs[idx]
    q = b if _key(a) == _key(p) else a
    seen = {idx}
    cur = idx
    while True:
        pts.append(q)
        nxt = [e for e in ends.get(_key(q), ()) if e[2] != cur]
        if len(nxt) != 1 or nxt[0][2] in seen:
            break
        q0, q1, i2 = nxt[0]
        d1 = (q[0] - pts[-2][0], q[1] - pts[-2][1])
        d2 = (q1[0] - q0[0], q1[1] - q0[1])
        n1, n2 = math.hypot(*d1), math.hypot(*d2)
        if n1 == 0 or n2 == 0 or \
                (d1[0] * d2[0] + d1[1] * d2[1]) / (n1 * n2) < math.cos(math.radians(50)):
            break                           # a corner: a polygon, not a shaft
        seen.add(i2)
        cur, q = i2, q1
    return pts


def _dir(a, b):
    L = math.hypot(b[0] - a[0], b[1] - a[1])
    return ((b[0] - a[0]) / L, (b[1] - a[1]) / L) if L > 1e-9 else None


def _walked(pts, dist):
    """The point `dist` along a polyline (its end if shorter), and the total."""
    run = 0.0
    total = sum(math.hypot(b[0] - a[0], b[1] - a[1]) for a, b in zip(pts, pts[1:]))
    for a, b in zip(pts, pts[1:]):
        L = math.hypot(b[0] - a[0], b[1] - a[1])
        if run + L >= dist and L > 0:
            t = (dist - run) / L
            return (a[0] + t * (b[0] - a[0]), a[1] + t * (b[1] - a[1])), total
        run += L
    return pts[-1], total


def _one_head(L, used, ends, segs, ppu):
    for x in range(len(L)):
        for y in range(x + 1, len(L)):
            if x in used or y in used:
                continue
            l1, p, q1, i1 = L[x]
            l2, _, q2, i2 = L[y]
            if l1 <= 0 or abs(l1 - l2) > 0.15 * max(l1, l2):
                continue
            # a barb is short on paper and ends in free air; two polygon
            # edges meeting a diagonal at a vertex are neither
            if max(l1, l2) * ppu > 16.0 or \
                    len(ends.get(_key(q1), ())) > 1 or \
                    len(ends.get(_key(q2), ())) > 1:
                continue
            u1 = ((q1[0] - p[0]) / l1, (q1[1] - p[1]) / l1)
            u2 = ((q2[0] - p[0]) / l2, (q2[1] - p[1]) / l2)
            ang = math.degrees(math.acos(max(-1, min(1, u1[0] * u2[0] +
                                                     u1[1] * u2[1]))))
            if not 20.0 <= ang <= 150.0:
                continue
            bis = (u1[0] + u2[0], u1[1] + u2[1])
            nb = math.hypot(*bis) or 1.0
            bis = (bis[0] / nb, bis[1] / nb)
            hl = max(l1, l2)
            for z in range(len(L)):
                if z in (x, y) or z in used:
                    continue
                l3, _, q3, i3 = L[z]
                # The shaft is the whole line the head sits on, not its last
                # segment: a curve's last sampled piece is shorter than a barb,
                # and requiring one segment of twice the barb made every
                # curved jump arrow invisible to this sweep.
                walk = _shaft(p, i3, segs, ends)
                probe, total = _walked(walk, hl)
                if total < 2.0 * l1:
                    continue
                d = (probe[0] - p[0], probe[1] - p[1])
                nd = math.hypot(*d) or 1.0
                curved = len(walk) > 2
                lim = math.cos(math.radians(22 if curved else 12))
                if (d[0] * bis[0] + d[1] * bis[1]) / nd > lim:
                    return x, y, z, (p, walk[-1], {i1, i2, i3}, hl, walk)
    return None


def _base_head(tip, b1, b2, hl, segs, ends, skip, need_shaft=False,
               reach=0.0):
    """A head drawn as a triangle (filled, or an open chevron) with tip `tip`
    and base b1-b2: find the shaft that runs into its base (or a little under
    it). Its far end, not the base midpoint, is where the arrow starts. With
    `need_shaft`, no shaft -> None (a lone V is not an arrow). `reach`: how
    far back from the tip (x the head's height) the shaft's end may stop."""
    base = ((b1[0] + b2[0]) / 2.0, (b1[1] + b2[1]) / 2.0)
    width = math.hypot(b2[0] - b1[0], b2[1] - b1[1])
    hgt = math.hypot(tip[0] - base[0], tip[1] - base[1]) or 1.0
    ax_ = ((base[0] - tip[0]) / hgt, (base[1] - tip[1]) / hgt)
    tail, ids, best = base, set(), None
    for idx, (a, b, el) in enumerate(segs):
        if idx in skip:
            continue
        for e, o in ((a, b), (b, a)):
            along = (e[0] - tip[0]) * ax_[0] + (e[1] - tip[1]) * ax_[1]
            across = abs((e[0] - tip[0]) * ax_[1] - (e[1] - tip[1]) * ax_[0])
            if not (reach * hgt <= along <= hgt + 1.0 and
                    across <= max(0.6, 0.25 * min(width, hl))):
                continue
            oa = (o[0] - tip[0]) * ax_[0] + (o[1] - tip[1]) * ax_[1]
            if oa <= along:
                continue                    # heads toward the tip, not away
            if best is None or along < best[0]:
                best = (along, idx, e)
    if best is None:
        return None if need_shaft else (tip, tail, ids, hl, [tip])
    walk = _shaft(best[2], best[1], segs, ends)
    total = sum(math.hypot(q[0] - p[0], q[1] - p[1])
                for p, q in zip(walk, walk[1:]))
    if need_shaft and total < 2.0 * hl:
        return None
    return (tip, walk[-1], {best[1]}, hl, [tip] + walk)


def _arrows(M):
    """Arrowheads from the ink: two short barbs and a shaft (straight or
    curved) meeting at a tip, or a small dark filled triangle with a shaft
    running into its base. Returns (tip, tail, seg-ids, head length), where
    tail is where the SHAFT starts — the point a hop chain's previous tip
    lands on."""
    segs = []
    for s in M.strokes:
        for a, b in s.segs():
            segs.append((a, b, s.el))
    ends = {}
    for idx, (a, b, el) in enumerate(segs):
        for p, q in ((a, b), (b, a)):
            ends.setdefault(_key(p), []).append((p, q, idx))
    heads = []
    for key, lst in ends.items():
        if len(lst) < 3:
            continue
        L = [(math.hypot(q[0] - p[0], q[1] - p[1]), p, q, idx) for p, q, idx in lst]
        L.sort(key=lambda t: t[0])
        # several heads can share one point (two dimension arrows meeting
        # tip to tip), so keep looking once a head is found
        used = set()
        while True:
            found = _one_head(L, used, ends, segs, M.pt_per_unit)
            if not found:
                break
            x, y, z, head = found
            used.update((x, y, z))
            heads.append(head)
    for pts, closed, el in M.fills:
        if len(pts) not in (3, 4) or (len(pts) == 4 and pts[0] != pts[-1]):
            continue
        tri = pts[:3]
        edges = [math.hypot(tri[(i + 1) % 3][0] - tri[i][0],
                            tri[(i + 1) % 3][1] - tri[i][1]) for i in range(3)]
        if max(edges) > 20.0:
            continue
        k = edges.index(min(edges))          # shortest edge is the base
        tip = tri[(k + 2) % 3]
        heads.append(_base_head(tip, tri[k], tri[(k + 1) % 3], max(edges),
                                segs, ends, set()))
    # An open chevron whose shaft stops at the head's BASE instead of running
    # to its tip: the two barbs meet at the tip with no third stroke there,
    # so the barb search above never sees it. Read it as a triangle.
    for key, lst in ends.items():
        if len(lst) != 2:
            continue
        (p, q1, i1), (_, q2, i2) = lst
        l1 = math.hypot(q1[0] - p[0], q1[1] - p[1])
        l2 = math.hypot(q2[0] - p[0], q2[1] - p[1])
        if l1 <= 0 or l2 <= 0 or abs(l1 - l2) > 0.15 * max(l1, l2) or \
                max(l1, l2) * M.pt_per_unit > 16.0 or \
                len(ends.get(_key(q1), ())) > 1 or len(ends.get(_key(q2), ())) > 1:
            continue
        cosang = ((q1[0] - p[0]) * (q2[0] - p[0]) +
                  (q1[1] - p[1]) * (q2[1] - p[1])) / (l1 * l2)
        if not 20.0 <= math.degrees(math.acos(max(-1, min(1, cosang)))) <= 150.0:
            continue
        h = _base_head(p, q1, q2, max(l1, l2), segs, ends, {i1, i2},
                       need_shaft=True, reach=0.3)
        if h:
            heads.append(h)
    return heads, segs


@_per_block
def arrowhead_clearance(svg, gap_pt=ARROW_GAP_PT):
    M = _M(svg)
    heads, segs = _arrows(M)
    if not heads:
        return []
    g = gap_pt / M.pt_per_unit
    out = []
    for n, (tip, tail, ids, hl, walk) in enumerate(heads):
        for cx, cy, r, _ in M.dots:
            d = math.hypot(tip[0] - cx, tip[1] - cy)
            if d < r + g - 1e-6 and d > 1e-6:
                out.append("arrowhead at (%.1f, %.1f) stops %.2fpt from a dot "
                           "rim (needs %.1fpt) — end the shaft or arc %.1fpt "
                           "sooner (figkit_plus.stop_short gives the point)"
                           % (tip[0], tip[1], max(d - r, 0) * M.pt_per_unit,
                              gap_pt, (r + g - d) * M.pt_per_unit))
            elif d <= 1e-6:
                out.append("arrowhead at (%.1f, %.1f) is drawn ON a dot — end "
                           "the shaft or arc %.1fpt before the dot's centre "
                           "(figkit_plus.stop_short gives the point)"
                           % (tip[0], tip[1], (r + g) * M.pt_per_unit))
        for m_, (t2, tail2, ids2, hl2, walk2) in enumerate(heads):
            if m_ == n:
                continue
            # a double-headed arrow is two heads on one shaft: each tip is
            # the other's tail by construction (a dimension line, z47 'h')
            if math.hypot(tail[0] - t2[0], tail[1] - t2[1]) < 0.5 and \
                    math.hypot(tip[0] - tail2[0], tip[1] - tail2[1]) < 0.5:
                continue
            # chained dimensions meet head to head ('<-b->|<-b->', z47): the
            # next shaft starts under a head of its own, nothing is hidden.
            # A hop chain ('->->', z08 4ג) has no head there and is refused.
            if any(k != n and math.hypot(h[0][0] - tip[0], h[0][1] - tip[1]) < 0.5
                   and math.hypot(h[1][0] - tail2[0], h[1][1] - tail2[1]) > 0.5
                   for k, h in enumerate(heads)):
                continue
            d = math.hypot(tip[0] - tail2[0], tip[1] - tail2[1])
            if d >= g - 1e-6:
                continue
            # a ray drawn ON its axis: both shafts leave the meeting point the
            # same way, one on top of the other — nothing starts there. In a
            # hop chain the next shaft leaves away from this one.
            u = _dir(walk[0], walk[1]) if len(walk) > 1 else None
            v = _dir(walk2[-1], walk2[-2]) if len(walk2) > 1 else None
            if u and v and u[0] * v[0] + u[1] * v[1] > math.cos(math.radians(20)):
                continue
            out.append("arrowhead at (%.1f, %.1f) runs into the next "
                       "arrow's start (%.2fpt, needs %.1fpt) — end every hop "
                       "of the chain %.1fpt short of where the next begins "
                       "(figkit_plus.stop_short; plane(arrows=) does it)"
                       % (tip[0], tip[1], d * M.pt_per_unit, gap_pt, gap_pt))
    return out


def _along_owner(a, b, p, q):
    """A stroke lying along the owner p-q: on its line and overlapping it (a
    piece of the same edge, or an axis the edge lies on)."""
    ex, ey = q[0] - p[0], q[1] - p[1]
    L = math.hypot(ex, ey)
    if L <= 0:
        return False
    for e in (a, b):
        if abs((e[0] - p[0]) * ey - (e[1] - p[1]) * ex) / L > 0.3:
            return False
    ta = ((a[0] - p[0]) * ex + (a[1] - p[1]) * ey) / (L * L)
    tb = ((b[0] - p[0]) * ex + (b[1] - p[1]) * ey) / (L * L)
    return max(ta, tb) > 1e-6 and min(ta, tb) < 1 - 1e-6


def _on_owner(a, b, p, q):
    """A short stroke that belongs to the owner p-q: it crosses it through
    (an equality tick), or one of its ends stands on the owner's interior
    (a chevron's arm, a right-angle mark's side) -- not a stroke that merely
    meets the owner at one of the owner's ends (an adjacent edge)."""
    def o(u, v, w):
        return (v[0] - u[0]) * (w[1] - u[1]) - (v[1] - u[1]) * (w[0] - u[0])
    if o(p, q, a) * o(p, q, b) < -1e-9 and o(a, b, p) * o(a, b, q) < -1e-9:
        return True
    for e in (a, b):
        if _pt_seg(e, p, q) < 0.3 and min(math.hypot(e[0] - p[0], e[1] - p[1]),
                                          math.hypot(e[0] - q[0], e[1] - q[1])) > 1.0:
            return True
    return False


def _beyond_joint(box, a, b, p, q):
    """v6 C3: a stroke that MEETS the owner p-q (an adjacent edge sharing a
    vertex) and whose nearest point to the label is that very joint does not
    compete for it: the label stands beside its own edge, past the end of the
    other one. Measured naively, a length beside the short side of a sliver
    triangle was 'nearer' the two long sides that start at its ends."""
    c = ((box[0] + box[2]) / 2.0, (box[1] + box[3]) / 2.0)
    dx, dy = b[0] - a[0], b[1] - a[1]
    L2 = dx * dx + dy * dy
    if L2 <= 0:
        return False
    t = ((c[0] - a[0]) * dx + (c[1] - a[1]) * dy) / L2
    if 0.0 < t < 1.0:
        return False
    e = a if t <= 0.0 else b
    if _pt_seg(e, p, q) > 0.8:
        return False
    # and the label itself stands beside the owner's interior
    ex, ey = q[0] - p[0], q[1] - p[1]
    E2 = ex * ex + ey * ey
    u = ((c[0] - p[0]) * ex + (c[1] - p[1]) * ey) / E2 if E2 > 0 else -1.0
    return 0.0 < u < 1.0


def _shielded(box, a, b, p, q):
    """C3 r3: the owner p-q stands BETWEEN the label and the stroke a-b: the
    whole label box on one side of the owner's line, the whole stroke on the
    other (or on the line), and the label beside the owner's interior. Such
    a stroke cannot take the label -- a reader's eye meets the owner first.
    trapz_kit's '3' above the short top base of a flat trapezoid was refused
    as nearer a diagonal lying below that base."""
    ex, ey = q[0] - p[0], q[1] - p[1]
    L = math.hypot(ex, ey)
    if L <= 0:
        return False

    def side(e):
        return ((e[0] - p[0]) * ey - (e[1] - p[1]) * ex) / L
    corners = [(box[0], box[1]), (box[2], box[1]), (box[0], box[3]), (box[2], box[3])]
    sb = [side(c) for c in corners]
    if min(sb) > 0.3:
        sg = 1.0
    elif max(sb) < -0.3:
        sg = -1.0
    else:
        return False
    if any(side(e) * sg > 0.3 for e in (a, b)):
        return False
    us = [((c[0] - p[0]) * ex + (c[1] - p[1]) * ey) / (L * L) for c in corners]
    return min(us) > 0.0 and max(us) < 1.0


def _across_the_row(M, T, p, q):
    """v6 open issues: a value label with the ROW of an axis's numbers between
    it and its own stroke. A base lying on the x-axis had its length printed
    below the row of x numbers, level with the next grid line: nearer its own
    base than any other stroke (the axis runs along the owner, so ownership
    x1.5 passed), outside the row band (so no merge), and read by every
    reader as one more axis number under the row. Returns a message or ''."""
    axes = getattr(M, "_o1_axes", None)
    if axes is None:
        axes = _axes(M)
        groups = _axis_labels(M, axes) if axes else {}
        rows = []
        for i, ax in enumerate(axes):
            row = _tick_row(ax, groups.get(i, []))
            if len([1 for _, _, e in row if e <= TICK_TOL]) >= 2:
                rows.append((ax, row))
        M._o1_axes = axes
        M._o1_rows = rows
    for ax, row in M._o1_rows:
        if any(R is T for R, _, _ in row):
            continue
        h = ax["orient"] == "h"
        i, k = (0, 1) if h else (1, 0)          # i: along, k: across
        boxes = [R.box for R, _, _ in row]
        rlo = min(b[k] for b in boxes)
        rhi = max(b[k + 2] for b in boxes)
        alo = min(b[i] for b in boxes) - ax["spacing"] / 2.0
        ahi = max(b[i + 2] for b in boxes) + ax["spacing"] / 2.0
        c = T.centre()
        if not alo <= c[i] <= ahi:
            continue
        # the owner's point nearest the label, across the axis
        ex, ey = q[0] - p[0], q[1] - p[1]
        L2 = ex * ex + ey * ey
        u = 0.0 if L2 <= 0 else max(0.0, min(1.0, ((c[0] - p[0]) * ex +
                                                   (c[1] - p[1]) * ey) / L2))
        o = (p[0] + ex * u, p[1] + ey * u)
        tlo, thi = T.box[k], T.box[k + 2]
        if (thi <= rlo + 0.3 and o[k] >= rhi - 0.3) or \
                (tlo >= rhi - 0.3 and o[k] <= rlo + 0.3):
            return ("label %r stands beyond the row of %s-axis numbers, with "
                    "that row between it and its own stroke — it reads as a "
                    "stray axis number; write it on the side of its stroke "
                    "away from the axis numbers (inside the shape), or move the "
                    "shape off the axis; never drop the label"
                    % (T.text, "x" if h else "y"))
    return ""


def _short_ends(segs):
    """Every SHORT stroke, filed under each of its ends (rounded to the
    nearest unit). Built once per figure so the arrowhead test below costs
    nothing per comparison: built inside it, over every stroke, it turned
    `label_ownership` quadratic and the v6 selfcheck stopped finishing."""
    out = {}
    for a, b, _el in segs:
        L = math.hypot(b[0] - a[0], b[1] - a[1])
        if L <= 0 or L > 14.0:
            continue
        for e in (a, b):
            out.setdefault((round(e[0]), round(e[1])), []).append((a, b, L))
    return out


def _is_head_of(a, b, p, q, ends):
    """A barb of an ARROWHEAD standing at one END of the owner p-q.

    v6.4. `_on_owner` lets a short stroke off the ownership contest when it
    crosses the owner or stands on its INTERIOR (an equality tick, a
    chevron's arm). An arrowhead's barbs meet the owner at its very END, so
    they were competitors — and a short dimension line (a liquid level, a
    box's depth measured from outside) could not be nearer its own number
    than its own two barbs, whatever the figure did. A head is not a stroke
    a reader could read the number against: it is part of the object the
    number names. Recognised by shape, not by a declaration, because this
    sweep reads the finished SVG: short, springing from an end of the owner,
    leaning 10-70 degrees off it, and with a SECOND such stroke at the same
    end (a head has two barbs)."""
    L = math.hypot(q[0] - p[0], q[1] - p[1])
    la = math.hypot(b[0] - a[0], b[1] - a[1])
    if not 0 < la < 0.35 * L:
        return False
    tip = None
    for u in (a, b):
        for e in (p, q):
            if _d(u, e) < 0.8:
                tip = e
    if tip is None:
        return False
    ang = abs(math.degrees(math.atan2(b[1] - a[1], b[0] - a[0])) -
              math.degrees(math.atan2(q[1] - p[1], q[0] - p[0]))) % 180.0
    ang = min(ang, 180.0 - ang)
    if not 10.0 <= ang <= 70.0:
        return False
    mates = 0
    for dx in (-1, 0, 1):
        for dy in (-1, 0, 1):
            for c, e, lb in ends.get((round(tip[0]) + dx,
                                      round(tip[1]) + dy), ()):
                if (c, e) == (a, b) or lb >= 0.35 * L:
                    continue
                if min(_d(c, tip), _d(e, tip)) < 0.8:
                    mates += 1
    return mates >= 1


def label_ownership(svg, owners, factor=OWN_FACTOR):
    """`owners`: [(text, (p, q))] or [(text, (p, q), (x, y))] in the SVG's own
    coordinates, (x, y) near where the label is written. The label must be
    nearer its segment than any other dark stroke by `factor`.

    Several figures in one string (a row) are judged block by block; a label
    counts as missing only when no block holds it. Stage-1 open issue (C1
    row-ownership-duplicate-text): an owner's coordinates belong to ONE
    figure of the row, so a label is refused only when every block that
    prints its text refuses it -- two figures each printing '5' no longer
    judge one figure's '5' against the other figure's strokes."""
    if not isinstance(svg, Model):
        bl = blocks(svg)
        if len(bl) > 1:
            out, missing = [], []
            for ow in owners:
                said, found = [], False
                # C7N-07: a block that DRAWS the owner's stroke is that
                # owner's figure, and each such block is judged; the '5' of a
                # second figure drawing the same stroke was hidden by a first
                # figure's correct '5'. Only when no block draws the stroke
                # (coordinates of another frame) does one passing block do.
                p_, q_ = ow[1]
                drawing = [b for b in bl if any(_along_owner(a, c, p_, q_)
                                                for a, c, _ in _M(b).dark_segs())]
                for b in bl:
                    got = label_ownership(b, [ow], factor)
                    if any(g.endswith("not found in the SVG") for g in got):
                        continue
                    found = True
                    if drawing:
                        if b in drawing:
                            said += got
                        continue
                    if not got:
                        said = []
                        break
                    said = said or got
                if not found:
                    missing.append("label %r not found in the SVG" % ow[0])
                out += said
            return out + sorted(missing)
    M = _M(svg)
    segs = M.dark_segs()
    # C3 r3: the two strokes of every right-angle mark, with its vertex. A
    # mark standing at the foot of a height belongs to that height (and to
    # the base): trapz_kit's 'h' beside a short dashed height was refused as
    # 'nearer another stroke' -- the mark's own side, 1.4 units away
    mm = _mark_model(M)
    head_ends = _short_ends(segs)
    rmarks = [(v, [(mm[k][0], mm[k][1]) for k in ij])
              for v, _, _, _, ij in _right_marks(M, mm)]
    out = []
    for ow in owners:
        text, (p, q) = ow[0], ow[1]
        # v6 C3: an optional third item is the point the label was written
        # at, which tells two equal texts apart (the value '6' on an edge and
        # the axis number '6' stood equally near the edge)
        at = ow[2] if len(ow) > 2 else None
        want = true_minus(text)
        cands = [T for T in M.texts if T.text == want or T.text == text]
        if not cands:
            out.append("label %r not found in the SVG" % text)
            continue
        if at is not None:
            T = min(cands, key=lambda T: math.hypot(T.centre()[0] - at[0],
                                                    T.centre()[1] - at[1]))
        else:
            T = min(cands, key=lambda T: _pt_seg(T.centre(), p, q))
        own = _box_seg_dist(T.box, p, q)
        Lpq = math.hypot(q[0] - p[0], q[1] - p[1])
        across = _across_the_row(M, T, p, q)
        if across:
            out.append(across)
            continue
        # v6 C3: a stroke lying along the owner, or a short mark crossing it
        # (its own equality tick or parallel arrow), is part of the owner
        mine = [pc for v, pcs in rmarks if _pt_seg(v, p, q) < 0.8 for pc in pcs]
        others = [_box_seg_dist(T.box, a, b) for a, b, _ in segs
                  if not _along_owner(a, b, p, q)
                  and not (math.hypot(b[0] - a[0], b[1] - a[1]) < 0.35 * Lpq
                           and _on_owner(a, b, p, q))
                  and not _beyond_joint(T.box, a, b, p, q)
                  and not _is_head_of(a, b, p, q, head_ends)
                  and not any(_d(a, c) < 0.05 and _d(b, e) < 0.05 or
                              _d(a, e) < 0.05 and _d(b, c) < 0.05
                              for c, e in mine)
                  and not _shielded(T.box, a, b, p, q)]
        if not others:
            continue
        near = min(others)
        if own * factor > near + 1e-6:
            out.append("label %r is %.1f from its own stroke but %.1f from "
                       "another; it reads as that stroke's label (needs x%.1f)"
                       % (text, own, near, factor))
    return out


def _scale(ax, labs, tol=TICK_TOL):
    """The axis's value at a position, read through its TICKS: each aligned
    number names the tick it sits on, and value = v0 + k * dv over tick index
    k. Reading through the label centres instead would carry the label's own
    offset from its tick (a y-axis number is centred by an estimated glyph
    box) into every value."""
    s, t0 = ax["spacing"], ax.get("t0", ax["ticks"][0])
    pairs = []
    for T, pos, e in labs:
        if e <= tol:
            t = _near_tick(pos, ax)
            pairs.append((round((t - t0) / s), _value(T.text)))
    if len(set(k for k, _ in pairs)) < 2:
        return None
    n = float(len(pairs))
    mk = sum(k for k, _ in pairs) / n
    mv = sum(v for _, v in pairs) / n
    kk = sum((k - mk) ** 2 for k, _ in pairs)
    dv = sum((k - mk) * (v - mv) for k, v in pairs) / kk
    if abs(dv) < 1e-12:
        return None
    v0 = mv - dv * mk
    return lambda pos: v0 + (pos - t0) / s * dv, dv


ROOM_HOPELESS = 3.0      # more units per value than a sheet can give


def _room(off, r, touch_pt, ppu):
    """The concrete fix for a dot on a neighbouring tick: how much more length
    per unit the axis needs so the disc clears the tick.

    Stage review (doctrine 4): this named 'a larger unit / size / maxw in the
    builder' -- knobs a builder need not have (z01_a's own _fit only ever
    SHRINKS the unit, and on a vertical line returns after the first render),
    so the one fix the message named was one the author could not reach. It
    now names fixes that belong to the FIGURE, and when the axis would have
    to grow more than ROOM_HOPELESS times -- a figure no sheet can hold -- it
    says so and names the zoom, which is how a crowded value is really
    shown."""
    need = (r + touch_pt / ppu) / max(off, 1e-6)
    fix = ("give the axis at least %.2fx the drawing units per value so the "
           "disc clears the tick — the dot's radius stays put: a WINDOW whose "
           "ticks miss this value (change lo/hi or the step), a finer "
           "numbering step, or a larger figure" % need)
    if need > ROOM_HOPELESS:
        fix += ("; at %.2fx this range prints far wider than a sheet holds, "
                "so draw the crowded values on a SECOND, zoomed line instead "
                "of squeezing them onto this one "
                "(numberline.NL(...).zoom(lo, hi), which draws the stretch "
                "they sit in under the whole line)" % need)
    return fix + ". Never move the point off its value or drop it"


@_per_block
def dot_on_other_tick(svg, values=None, touch_pt=0.5):
    """A dot on an axis must not print on a tick that is not its value.

    Without `values` the sweep cannot know what a dot means, so it refuses
    only what no reader can resolve: a dot visibly off-centre from a tick
    (by >= `touch_pt` printed) whose disc still reaches that tick (rim within
    `touch_pt`). With `values` (what the dots on this axis stand for) it reads
    each dot back through the axis's own numbers: a dot must read as one of
    them (within 0.05 x spacing), and a dot whose value is NOT the value of
    the tick its disc covers is refused however centred it looks — z01 left
    -0.5 off its sea-level scale because at 0.105 px per metre it printed on
    the 0 tick."""
    M = _M(svg)
    axes = _axes(M)
    if not axes:
        return []
    groups = _axis_labels(M, axes)
    ppu = M.pt_per_unit
    out = []
    for i, ax in enumerate(axes):
        s = ax["spacing"]
        sc = _scale(ax, _tick_row(ax, groups[i]))
        for cx, cy, r, _ in M.dots:
            perp = abs(cy - ax["at"]) if ax["orient"] == "h" else abs(cx - ax["at"])
            if perp > max(r, 1.0) or r > 8.0:
                continue
            pos = cx if ax["orient"] == "h" else cy
            if not ax["lo"] - 1 <= pos <= ax["hi"] + 1:
                continue
            t = _near_tick(pos, ax)
            off = abs(pos - t)
            touching = off < r + touch_pt / ppu
            if values is not None and sc:
                read, dv = sc
                v = read(pos)
                w = min(values, key=lambda x: abs(x - v))
                # C4: the tick's value by its INDEX on the lattice, exactly;
                # read(t) carried the fitted spacing's error into it, so a dot
                # for 0.75 was refused "on the tick of 0.7469"
                s0, t00 = ax["spacing"], ax.get("t0", ax["ticks"][0])
                tv = read(t00 + round((t - t00) / s0) * s0)
                if abs(v - w) > 0.05 * abs(dv):
                    out.append("dot at %.1f reads as %.4g, not one of %s — "
                               "draw it at its value" % (pos, v, list(values)))
                elif touching and abs(w - tv) > 1e-6 * abs(dv):
                    out.append("dot for %.4g prints on the tick of %.4g "
                               "(%.2fpt off it) — it reads as %.4g. %s"
                               % (w, tv, off * ppu, tv,
                                  _room(off, r, touch_pt, ppu)))
            elif touching and off * ppu >= touch_pt:
                out.append("dot at %.1f touches the tick at %.1f %.2fpt off its "
                           "centre — it reads as that tick's value. If its value "
                           "IS that tick's, draw it exactly on the tick; if "
                           "not: %s"
                           % (pos, t, off * ppu, _room(off, r, touch_pt, ppu)))
    return out


# ------------------------------------------------- marks (v6 C3: E5, E8, E24) ---
RIGHT_TOL = 0.5          # degrees: a right-angle mark sits on 90 +- this
EQUAL_TOL = 0.02         # equality-tick groups: marked lengths within 2%
PARALLEL_TOL = 0.5       # degrees: chevron carriers of one count
ANGLE_TOL = 0.6          # degrees: an angle text against its arc
TICK_LEN_PT = 5.0        # an equality tick, printed
TICK_GAP_PT = 2.5        # paper between two ticks of a group, printed
MARK_MAX_PT = 16.0       # a stroke longer than this is not a mark
# v6.2 Q1 (adjacent-equal-arcs-read-as-one, r3-arc-stepout-unbounded): the
# two sweeps that read an ANGLE ARC nest off the finished file.
ARC_READ_MIN_PT = 2.2    # v6.2 Q1 r1: a curve smaller than this is not an
                         # angle arc (the floor used to be 3.0 figure units,
                         # which at a printed nest's scale hid its first ring)
ARC_SAME_R_PT = 1.5      # two arcs printed this near in radius are ONE ring
ARC_JOIN_PT = 1.6        # ... and ends this near on it are JOINED, not broken
ARC_JOIN_TOL = 2.5       # degrees: the angular slack on 'the same end'
ARC_CROSS_PT = 0.6       # paper an arc keeps from a dot, a label or a side
# v6.2 Q1 r1 (equal-arcs-not-checked-against-the-angles): what "the same
# number of strokes" claims. Equality TICKS have been held to their lengths
# since v6 C3 and parallel arrows to their directions; arcs claimed equality
# and nothing measured it.
ARC_EQ_DEG = 3.0         # two angles marked alike may differ by this much...
ARC_EQ_PCT = 0.05        # ... and by this fraction of the larger
# a marker's half extent, printed. P1 (the author, 2026-09-17, against
# Typst/LaTeX): 3.5pt read as a blob next to 8pt numbers; an open marker of
# 2.4pt with a white fill reads as open. Below 2.4pt it no longer does.
MARKER_R_PT = 2.4
MARKER_MAX_PT = 8.0      # a closed shape wider than 2x this is a drawn shape
ROW_GAP_EM = 0.12        # C7P-01: two numbers of one axis row, box to box (the box model runs 0.05 em wide of each glyph run)
# P3 leftovers r1 (pilot-c17b): paper between a number of the X row and a
# number of the Y row where the two rows meet at the crossing, measured on
# the digits' INK. They are not a row a reader scans -- they are two strings
# side by side, and on level c page 11 the x '-2' and the y '-5' printed
# 0.66 em apart on one line and read as '-2-5'.
CROSS_ROW_EM = 0.90
CROSS_BAND = 0.15        # ... and only when their digits share this much of a
                         # line: the house corner puts the x '-1' and the y
                         # '-1' corner to corner (they touch, and read fine);
                         # side by side ON ONE LINE they are one string
OUTSIDE_FAR_EM = 6.0     # how far a letter printed off the plane may still be
                         # paired with the point it was meant to name
OUTSIDE_NEAR_EM = 1.2    # ... and how near it may stand and still be its
                         # point's name where it is: the conventional 'O'
                         # below-left of a first-quadrant origin sits just
                         # outside the axes' box, 0.7-0.9 em from its dot,
                         # and reads right. The pilot defect stood 1.66 em
                         # out, above the y arrow beside the axis's name.
MERGE_EM = 0.6           # two labels on one band closer than this merge
# P3 leftovers r1 (origin-letter-flies-off-its-point): two marks a reader
# cannot tell apart at 8pt -- the origin's letter 'O' beside the axis '0',
# 'I' beside '1' -- need a whole em, not the 0.6 that parts two ordinary
# labels. Twelve pilot figures printed 'O' and '0' 0.67 em apart: two
# near-identical rings one glyph-width apart, read as one mark or a doubled
# zero.
CONFUSE_EM = 1.0
_CONFUSABLE = {"O": "0", "o": "0", "I": "1", "l": "1", "S": "5", "Z": "2",
               "B": "8"}


def confusable(ta, tb):
    """Do the two label texts print as the same mark ('O' and '0')?"""
    a = (ta or "").strip().lstrip(MINUS + "-")
    b = (tb or "").strip().lstrip(MINUS + "-")
    return _CONFUSABLE.get(a) == b or _CONFUSABLE.get(b) == a


def merge_em(ta=None, tb=None, em=MERGE_EM):
    """The paper two labels need between them, in ems of the larger."""
    return max(em, CONFUSE_EM) if confusable(ta, tb) else em
AXIS_MARK_CLEAR = 0.35   # a mark on an axis-lying edge, from the axis ticks
GROUP_PT = 4.0           # marks nearer than this, of one length, are a group
# ...but figkit spaces a group at max(3.4 FIGURE UNITS, TICK_GAP_PT x upt +
# stroke), so on a large figure the gap stops shrinking with the paper: at
# width=400 three ticks 4.4 units apart print 4.4pt apart, more than GROUP_PT,
# and a correct edge along an axis was refused ('stand 0.00pt from the axis
# tick', with no way out). No lattice spacing under MIN_SPACING_U is ever
# considered an axis, so a gap under that floor is a group at any scale.
GROUP_U = 4.0            # ...and nearer than this many figure units
MIN_SPACING_U = 4.0      # the smallest gap _best_lattice will call an axis
_DEG = re.compile(u"^\\s*(\\d+(?:[.,]\\d+)?)\\s*°\\s*$")
# v6.4 T2-1 (angle-text-without-degree-sign-unchecked): a BARE number printed
# beside an angle arc is a degree claim too -- shapekit.angle_arc(text="50")
# on a 36.87 degree wedge shipped, because this reader only ever looked at the
# form WITH the sign. A bare number is read as degrees, but only through the
# two associations that cannot be confused with a LENGTH label: it stands
# strictly INSIDE exactly one wedge, or a leader line ties it to one arc. (The
# wide ring band the degree-sign form also uses would grab a side's length
# number standing just outside the wedge.) A non-numeric text ('x', '2x') is
# the unknown the question asks for and stays unchecked, as before.
_BARE_NUM = re.compile(u"^\\s*(\\d+(?:[.,]\\d+)?)\\s*$")
NUM_REACH_EM = 6.0       # a bare number farther from the vertex than r + this
                         # many em is not that wedge's own number
NAME_MAX = 10.0          # a bare integer under this is an angle's NAME


def _d(p, q):
    return math.hypot(q[0] - p[0], q[1] - p[1])


def _cross_pt(a, b, p, q):
    """(t on a-b, s on p-q, point) of the two LINES' intersection, or None."""
    rx, ry = b[0] - a[0], b[1] - a[1]
    sx, sy = q[0] - p[0], q[1] - p[1]
    den = rx * sy - ry * sx
    if abs(den) < 1e-12:
        return None
    t = ((p[0] - a[0]) * sy - (p[1] - a[1]) * sx) / den
    u = ((p[0] - a[0]) * ry - (p[1] - a[1]) * rx) / den
    return t, u, (a[0] + t * rx, a[1] + t * ry)


def _acute(u, v):
    """The angle between two directions, 0..90 degrees."""
    n = math.hypot(*u) * math.hypot(*v)
    if n <= 0:
        return 0.0
    c = abs(u[0] * v[0] + u[1] * v[1]) / n
    return math.degrees(math.acos(max(-1.0, min(1.0, c))))


def _mark_model(M):
    """Straight dark pieces: (a, b, el, is_mark). A mark is a lone two-point
    stroke no longer than MARK_MAX_PT printed."""
    ppu = M.pt_per_unit
    out = []
    for s in M.strokes:
        lone = len(s.pts) == 2 and not s.closed
        for a, b in s.segs():
            L = _d(a, b)
            if L <= 1e-9:
                continue
            out.append((a, b, s.el, lone and L * ppu <= MARK_MAX_PT and L >= 1.0))
    return out


def _covered(pt, segs, skip, tol=0.9):
    return any(_pt_seg(pt, a, b) <= tol for i, (a, b, el, mk) in enumerate(segs)
               if i not in skip and not mk)


def _right_marks(M, segs):
    """Right-angle marks: two equal short strokes meeting at a corner p2 whose
    far ends p1, p3 lie on two long strokes that meet at v = p1 + p3 - p2 and
    run on past the mark. The corner's angle is the vertex's angle."""
    out = []
    marks = [i for i, s in enumerate(segs) if s[3]]
    for x in range(len(marks)):
        for y in range(x + 1, len(marks)):
            i, j = marks[x], marks[y]
            a1, b1 = segs[i][0], segs[i][1]
            a2, b2 = segs[j][0], segs[j][1]
            found = None
            for p1, c1 in ((a1, b1), (b1, a1)):
                for p3, c2 in ((a2, b2), (b2, a2)):
                    if _d(c1, c2) < 0.35:
                        found = (p1, c1, p3)
            if not found:
                continue
            p1, p2, p3 = found
            l1, l2 = _d(p1, p2), _d(p3, p2)
            if abs(l1 - l2) > 0.2 * max(l1, l2):
                continue
            corner = _angle3(p1, p2, p3)
            if not 25.0 <= corner <= 155.0:
                continue
            v = (p1[0] + p3[0] - p2[0], p1[1] + p3[1] - p2[1])
            ok = True
            for p, l in ((p1, l1), (p3, l2)):
                ux, uy = (p[0] - v[0]) / l, (p[1] - v[1]) / l
                for k in (0.5, 1.8):
                    if not _covered((v[0] + ux * l * k, v[1] + uy * l * k),
                                    segs, {i, j}):
                        ok = False
            if ok:
                out.append((v, corner, min(l1, l2), _grid_step((p1, p2, p3)),
                            (i, j)))
    return out


def _grid_step(pts):
    """C3 r2: the coordinate rounding the SVG was written with, read from the
    points themselves: 0.01 when every coordinate is a multiple of 0.01, 0.1
    for 0.1, else None (unknown -- transformed, or written at full
    precision)."""
    for step in (0.1, 0.01):
        if all(abs(c / step - round(c / step)) < 1e-4 for p in pts for c in p):
            return step
    return None


def _angle3(a, v, b):
    ux, uy = a[0] - v[0], a[1] - v[1]
    wx, wy = b[0] - v[0], b[1] - v[1]
    n = math.hypot(ux, uy) * math.hypot(wx, wy)
    if n <= 0:
        return 0.0
    return math.degrees(math.acos(max(-1.0, min(1.0, (ux * wx + uy * wy) / n))))


def _axis_like(M, segs):
    """Indices of straight strokes that are a coordinate system's axes even
    when _axes cannot measure them (one or two data ticks): a long horizontal
    and a long vertical stroke crossing each other, each at least 60% of the
    figure's extent in its direction."""
    pts = [p for a, b, _, _ in segs for p in (a, b)]
    if not pts:
        return set()
    W = max(p[0] for p in pts) - min(p[0] for p in pts)
    H = max(p[1] for p in pts) - min(p[1] for p in pts)
    # v6.3 r1 (S2-1-duplicate-marks, found while fixing it): a CLOSED stroke
    # is a shape's outline, never a coordinate system's axis. Two adjacent
    # sides of an axis-aligned rectangle satisfy the crossing test below --
    # they meet at their corner -- so all four sides counted as axes and
    # _tick_groups threw away every equality tick on them: at rotate 0 the
    # equal-lengths sweep (E5) was VACUOUS on the commonest figure the skill
    # draws, which is how one segment carrying two different tick counts
    # passed problems() == []. An axis of a plane is an open stroke and is
    # untouched by this.
    closed = set(st.el for st in M.strokes if st.closed)
    hs = [i for i, (a, b, el, mk) in enumerate(segs)
          if el not in closed
          and abs(a[1] - b[1]) < 0.3 and abs(a[0] - b[0]) >= max(30.0, 0.6 * W)]
    vs = [i for i, (a, b, el, mk) in enumerate(segs)
          if el not in closed
          and abs(a[0] - b[0]) < 0.3 and abs(a[1] - b[1]) >= max(30.0, 0.6 * H)]
    out = set()
    for i in hs:
        a, b = segs[i][0], segs[i][1]
        for j in vs:
            c, d = segs[j][0], segs[j][1]
            if min(a[0], b[0]) - 0.5 <= c[0] <= max(a[0], b[0]) + 0.5 and \
                    min(c[1], d[1]) - 0.5 <= a[1] <= max(c[1], d[1]) + 0.5:
                out.update((i, j))
    # v6.1: a LONE axis. A number line has no crossing vertical, so the pair
    # above never fires, and its OWN tick marks were then read as equality
    # ticks: numberline.sign_chart draws the house tick (4.4pt) at each
    # boundary and svgcheck reported both as marks under the 5pt floor, on a
    # drawing every builder and gate passes. A long stroke that ENDS IN AN
    # ARROWHEAD is an axis -- that is what the arrow means -- so it joins the
    # axis lines and its ticks stop being anybody's equality ticks.
    heads = _arrows(M)[0]
    for i in hs + vs:
        a, b = segs[i][0], segs[i][1]
        for tip, tail, _ids, hl, _walk in heads:
            reach = max(1.5, 1.6 * (hl or 0.0))
            if _d(tail, a) <= reach or _d(tail, b) <= reach or \
                    _d(tip, a) <= reach or _d(tip, b) <= reach:
                out.add(i)
                break
    return out


def _tick_groups(M, segs, axes):
    """Equality ticks: a short stroke crossing a longer, non-axis stroke at
    60-90 degrees, through its own middle (0.3-0.7), away from the carrier's
    ends. Ticks a stroke's width apart on one carrier are one group."""
    ppu = M.pt_per_unit
    hits = []
    axis_like = _axis_like(M, segs)
    # every axis, measured or not, as a line: (orient, at)
    # (an "axis" measured by its grid through one or two crossing marks may
    # be a polygon edge carrying an equality tick on a grid line: not an axis)
    lines = [(ax["orient"], ax["at"]) for ax in axes if not ax.get("marks")] + \
        [("h", segs[k][0][1]) if abs(segs[k][0][1] - segs[k][1][1]) < 0.3
         else ("v", segs[k][0][0]) for k in axis_like]

    def on_axis_line(p, q):
        return any((o == "h" and abs(p[1] - at) < 0.5 and abs(q[1] - at) < 0.5) or
                   (o == "v" and abs(p[0] - at) < 0.5 and abs(q[0] - at) < 0.5)
                   for o, at in lines)
    ends = [(i, e) for i, (a, b, el, mk) in enumerate(segs) if mk for e in (a, b)]
    for i, (a, b, el, mk) in enumerate(segs):
        if not mk:
            continue
        # a tick is a LONE stroke: one whose end meets another mark's end AT
        # AN ANGLE is a right-angle mark's side or a chevron's arm (an axis
        # tick standing end to end with it, in line, is not)
        if any(k != i and (_d(e, a) < 0.35 or _d(e, b) < 0.35) and
               _acute((b[0] - a[0], b[1] - a[1]),
                      (segs[k][1][0] - segs[k][0][0],
                       segs[k][1][1] - segs[k][0][1])) > 20.0
               for k, e in ends):
            continue
        # an axis's own tick mark is not an equality tick, whatever crosses it
        mid = ((a[0] + b[0]) / 2.0, (a[1] + b[1]) / 2.0)
        if any((o == "h" and abs(mid[1] - at) < 0.6 and abs(a[0] - b[0]) < 0.3) or
               (o == "v" and abs(mid[0] - at) < 0.6 and abs(a[1] - b[1]) < 0.3)
               for o, at in lines):
            continue
        l = _d(a, b)
        for j, (p, q, el2, mk2) in enumerate(segs):
            if j == i or el2 == el or mk2:
                continue
            Lc = _d(p, q)
            if Lc < 2.5 * l or on_axis_line(p, q):
                continue
            x = _cross_pt(a, b, p, q)
            if not x:
                continue
            t, u, X = x
            if not 0.3 <= t <= 0.7 or not 0.0 < u < 1.0:
                continue
            if min(u, 1 - u) * Lc < max(1.5, 0.6 * l):
                continue
            if _acute((b[0] - a[0], b[1] - a[1]), (q[0] - p[0], q[1] - p[1])) < 60.0:
                continue
            hits.append((j, u * Lc, X, i, l))
    groups = []
    for j in sorted(set(h[0] for h in hits)):
        hs = sorted([h for h in hits if h[0] == j], key=lambda h: h[1])
        cur = [hs[0]]
        for h in hs[1:]:
            if h[1] - cur[-1][1] <= 1.6 * max(h[4], cur[-1][4]) + 4.0 / ppu:
                cur.append(h)
            else:
                groups.append((j, cur))
                cur = [h]
        groups.append((j, cur))
    return groups


def _curve_ends(M):
    """(el, point) of the two ends of every open CURVED stroke: three or more
    points turning gently (under 45 degrees a joint) and turning somewhere.
    An angle arc or a curve ending on a side does not divide it (C3 r2)."""
    out = []
    for s in M.strokes:
        if s.closed or len(s.pts) < 3:
            continue
        turns = []
        for a, b, c in zip(s.pts, s.pts[1:], s.pts[2:]):
            u = (b[0] - a[0], b[1] - a[1])
            v = (c[0] - b[0], c[1] - b[1])
            if math.hypot(*u) < 1e-9 or math.hypot(*v) < 1e-9:
                continue
            turns.append(180.0 - _angle3(a, b, c))
        if turns and max(turns) < 45.0 and sum(turns) > 3.0:
            out += [(s.el, s.pts[0]), (s.el, s.pts[-1])]
    return out


def _axis_edge_groups(M, segs, axes):
    """C3 r2: equality-tick groups on a segment lying ALONG a measured axis
    (a rectangle's side on the x-axis). _tick_groups reads every short stroke
    across an axis as the axis's own tick; here a stroke OFF the axis's tick
    lattice, on a drawn edge that is not the axis stroke itself, is a mark.
    Returns (carrier index, [(pos, stroke index, length)], ax)."""
    ppu = M.pt_per_unit
    out = []
    for ax in axes:
        if ax.get("marks"):
            continue
        h = ax["orient"] == "h"
        i, k = (0, 1) if h else (1, 0)          # i: along, k: across
        at, s = ax["at"], ax["spacing"]
        on = [n for n, (a, b, el, mk) in enumerate(segs)
              if not mk and abs(a[k] - at) < 0.5 and abs(b[k] - at) < 0.5]
        if not on:
            continue
        axis_el = segs[max(on, key=lambda n: _d(segs[n][0], segs[n][1]))][2]
        hits = []
        for n, (a, b, el, mk) in enumerate(segs):
            # stage-1 fix r1 (PR8): marks on an axis side LEAN (figkit
            # ON_AXIS_TICK_LEAN, 25 degrees) so they are not read as axis
            # ticks; up to 35 degrees off the perpendicular is a mark here
            if not mk or abs(a[i] - b[i]) > 0.3 + 0.7 * abs(a[k] - b[k]):
                continue
            pos = (a[i] + b[i]) / 2.0
            if not min(a[k], b[k]) + 0.5 < at < max(a[k], b[k]) - 0.5:
                continue
            if abs(((a[k] + b[k]) / 2.0) - at) > 0.6:
                continue
            # the axis's own tick: a mark the lattice was read from (C3 r3:
            # not any mark within 0.15 spacing of one -- a group straddling
            # a tick lost the marks beside it and was counted as one)
            if any(abs(pos - t) <= 0.3 for t in ax["ticks"]):
                continue
            car = [c for c in on if segs[c][2] != axis_el and
                   min(segs[c][0][i], segs[c][1][i]) + 0.5 < pos <
                   max(segs[c][0][i], segs[c][1][i]) - 0.5]
            if car:
                hits.append((pos, n, _d(a, b), car[0]))
        hits.sort()
        cur = []
        for hh in hits:
            if cur and hh[0] - cur[-1][0] > 1.6 * max(hh[2], cur[-1][2]) + 4.0 / ppu:
                out.append((cur[0][3], cur, ax))
                cur = []
            cur.append(hh)
        if cur:
            out.append((cur[0][3], cur, ax))
    return out


def _marked_length(M, segs, j, X, piece=False):
    """The length of the piece of carrier j that a mark at X names.

    The carrier's EXTENT is segment j chained, end to start, through any
    collinear piece that continues it across a gap (a line cut behind a
    number goes on beyond it); a collinear stroke lying over it (the axis an
    edge lies on) is not the carrier. Its stops are the extent's two ends,
    every straight stroke ending on it inside the extent (a vertex, a
    cevian's foot) and every dot on it -- never the end of an angle arc or a
    curve with one end elsewhere (C3 r2), but both ends of a curve standing on
    the line (C3 r3). Of the pieces between a stop behind X and one ahead of it,
    the mark names the one whose middle it stands nearest (Figure.ticks draws
    at the middle, or half-way between axis ticks); the shorter wins a tie."""
    p, q = segs[j][0], segs[j][1]
    L = _d(p, q)
    ux, uy = (q[0] - p[0]) / L, (q[1] - p[1]) / L
    cends = _curve_ends(M)

    def on_line(e):
        return abs((e[0] - X[0]) * uy - (e[1] - X[1]) * ux) < 0.8

    def along(e):
        return (e[0] - X[0]) * ux + (e[1] - X[1]) * uy
    col = [(min(along(a), along(b)), max(along(a), along(b)))
           for a, b, el, mk in segs if not mk and on_line(a) and on_line(b)]
    lo, hi = sorted((along(p), along(q)))
    grew = True
    while grew:
        grew = False
        for c0, c1 in col:
            if c0 < lo - 0.5 or c1 > hi + 0.5:
                # continues the extent across a gap; a piece reaching past
                # BOTH ends lies over the carrier (an axis) and is not it
                if c0 < lo - 0.5 and c1 > hi + 0.5:
                    continue
                if lo - 16.0 <= c1 <= lo + 0.5 and c0 < lo - 0.5:
                    lo, grew = c0, True
                elif hi - 0.5 <= c0 <= hi + 16.0 and c1 > hi + 0.5:
                    hi, grew = c1, True
    stops = [lo, hi]
    for k, (a, b, el, mk) in enumerate(segs):
        if mk or (on_line(a) and on_line(b)):
            continue
        for e in (a, b):
            if not on_line(e):
                continue
            # C3 r3: an arc or curve with ONE end on the line (an angle arc)
            # does not divide it; one standing on the line with BOTH ends (a
            # semicircle on a sub-segment PQ) does, at both ends
            ends = [cp for ce, cp in cends if ce == el]
            if any(_d(e, cp) < 0.05 for cp in ends) and \
                    not (len(ends) == 2 and all(on_line(cp) for cp in ends)):
                continue
            if lo - 0.5 <= along(e) <= hi + 0.5:
                stops.append(along(e))
    for cx, cy, r, _ in M.dots:
        if on_line((cx, cy)) and lo - 0.5 <= along((cx, cy)) <= hi + 0.5:
            stops.append(along((cx, cy)))
    fwd = sorted(set(round(v, 3) for v in stops if v > 0.5))[:8]
    back = sorted(set(round(-v, 3) for v in stops if v < -0.5))[:8]
    if not fwd or not back:
        return None
    best = min(((round(abs(b / (b + f) - 0.5), 2), b + f), (b, f))
               for b in back for f in fwd)
    if piece:
        # v6.3 r1: WHICH piece, not only how long. Two halves of one side can
        # be the same length (AM and MB of a median), so a length alone
        # cannot say two marks name the same segment.
        (b, f) = best[1]
        m = (f - b) / 2.0
        return best[0][1], (X[0] + ux * m, X[1] + uy * m)
    return best[0][1]


def _chevrons(M, segs):
    """Parallel-arrow chevrons: two equal short strokes meeting at an apex,
    opening 40-110 degrees, astride a longer stroke that runs on past both
    the apex and the chevron's base (an arrowhead ends its shaft)."""
    out = []
    ppu = M.pt_per_unit
    marks = [i for i, s in enumerate(segs) if s[3]]
    for x in range(len(marks)):
        for y in range(x + 1, len(marks)):
            i, j = marks[x], marks[y]
            apex = None
            for p, q1 in ((segs[i][0], segs[i][1]), (segs[i][1], segs[i][0])):
                for r, q2 in ((segs[j][0], segs[j][1]), (segs[j][1], segs[j][0])):
                    if _d(p, r) < 0.35:
                        apex = (p, q1, q2)
            if not apex:
                continue
            p, q1, q2 = apex
            l1, l2 = _d(p, q1), _d(p, q2)
            if abs(l1 - l2) > 0.15 * max(l1, l2):
                continue
            if not 40.0 <= _angle3(q1, p, q2) <= 110.0:
                continue
            w = ((p[0] - q1[0]) + (p[0] - q2[0]), (p[1] - q1[1]) + (p[1] - q2[1]))
            n = math.hypot(*w)
            if n <= 0:
                continue
            w = (w[0] / n, w[1] / n)
            l = max(l1, l2)
            for k, (a, b, el, mk) in enumerate(segs):
                if mk or k in (i, j):
                    continue
                if _pt_seg(p, a, b) > 0.8 or _acute(w, (b[0] - a[0], b[1] - a[1])) > 12.0:
                    continue
                s_a = (a[0] - p[0]) * w[0] + (a[1] - p[1]) * w[1]
                s_b = (b[0] - p[0]) * w[0] + (b[1] - p[1]) * w[1]
                if max(s_a, s_b) >= l and min(s_a, s_b) <= -2.0 * l:
                    out.append((p, k, l))
                    break
    return out


def _gap_to_box(box, p):
    """Distance from a point to a text box (0 inside it)."""
    if not box:
        return 1e9
    dx = max(box[0] - p[0], 0.0, p[0] - box[2])
    dy = max(box[1] - p[1], 0.0, p[1] - box[3])
    return math.hypot(dx, dy)


def _fit_circle(pts):
    """(centre, radius) of the circle that best fits `pts` (Kasa's algebraic
    least squares), or (None, 0) when they are too straight to fit. Stable
    where a three-point fit is not: a short arc's three points, rounded to
    the SVG's 0.01, put the centre a unit out."""
    n = len(pts)
    if n < 3:
        return None, 0.0
    mx = sum(p[0] for p in pts) / n
    my = sum(p[1] for p in pts) / n
    suu = suv = svv = suuu = svvv = suvv = svuu = 0.0
    for x, y in pts:
        u, v = x - mx, y - my
        suu += u * u
        svv += v * v
        suv += u * v
        suuu += u * u * u
        svvv += v * v * v
        suvv += u * v * v
        svuu += v * u * u
    den = 2.0 * (suu * svv - suv * suv)
    if abs(den) < 1e-12:
        return None, 0.0
    b1 = suuu + suvv
    b2 = svvv + svuu
    uc = (svv * b1 - suv * b2) / den
    vc = (suu * b2 - suv * b1) / den
    r = math.sqrt(max(0.0, uc * uc + vc * vc + (suu + svv) / n))
    return (mx + uc, my + vc), r


def _arcs(M, segs):
    """Angle arcs: an open curved stroke on one circle whose centre is where
    straight strokes meet and whose two ends lie on those strokes. Returns
    (centre, r, start angle, span in degrees)."""
    out = []
    for s in M.strokes:
        if s.closed or len(s.pts) < 6:
            continue
        pts = s.pts
        a, b, c = pts[0], pts[len(pts) // 2], pts[-1]
        # v6.4 T2-3 (bisector-arcs-refused-only-at-axis-aligned-rotations):
        # the centre and radius come from a LEAST-SQUARES fit over every
        # point of the stroke, not from its first, middle and last. Through
        # three points rounded to 0.01 the fit is ill-conditioned when the
        # arc is short: the two 10.9 degree halves of a bisected angle
        # (rectangle, bisector(g, d, 'A', 'B', 'C')) came out at r 16.26 on
        # a ring of 17.00, and 0.74 out is past the 0.7 that arc_crossings
        # allows before it stops recognising an arc's own chords -- so the
        # arc was refused for running through ITSELF, at rotate 0 and 90 and
        # nowhere else (the same figure, a different answer per rotation).
        cen, r = _fit_circle(pts)
        if cen is None:
            ax, ay = b[0] - a[0], b[1] - a[1]
            bx, by = c[0] - a[0], c[1] - a[1]
            den = 2.0 * (ax * by - ay * bx)
            if abs(den) < 1e-9:
                continue
            ux = (by * (ax * ax + ay * ay) - ay * (bx * bx + by * by)) / den
            uy = (ax * (bx * bx + by * by) - bx * (ax * ax + ay * ay)) / den
            cen = (a[0] + ux, a[1] + uy)
            r = math.hypot(ux, uy)
        # v6.2 Q1 r1 (arcs-under-3-units-unread): the floor is a PRINTED size.
        # It was 3.0 figure units, written when the innermost ring stood 18
        # units out; a nest spaced in printed pt puts its first ring 7.5pt
        # out, which is 2.75 units at 2.65pt per unit -- so above that scale
        # the ring every arc sweep exists to police was invisible to all of
        # them (arcs_join, arc_crossings, coincident_arcs_in and the
        # angle-text rule all read _arcs) and they passed vacuously.
        if r * M.pt_per_unit < ARC_READ_MIN_PT or \
                any(abs(_d(cen, p) - r) > 0.03 * r + 0.15 for p in pts):
            continue
        span = 0.0
        for p, q in zip(pts, pts[1:]):
            d = math.atan2(q[1] - cen[1], q[0] - cen[0]) - \
                math.atan2(p[1] - cen[1], p[0] - cen[0])
            while d > math.pi:
                d -= 2 * math.pi
            while d < -math.pi:
                d += 2 * math.pi
            span += d
        span = math.degrees(span)
        if not 3.0 <= abs(span) <= 181.0:
            continue
        rays = [(p, q) for p, q, el, mk in segs
                if not mk and el != s.el and (_d(p, cen) < 1.0 or _d(q, cen) < 1.0
                                              or _pt_seg(cen, p, q) < 1.0)]
        hit = []
        for e in (a, c):
            on = [(p, q) for p, q in rays if _pt_seg(e, p, q) < 1.2]
            if not on:
                break
            hit.append(on[0])
        if len(hit) < 2:
            continue
        # measure the angle by its RAYS, not by the arc's rounded points: the
        # arc's centre fitted through three points rounded to 0.1 unit was a
        # degree off on a 20-unit arc
        x = _cross_pt(hit[0][0], hit[0][1], hit[1][0], hit[1][1])
        if x and _d(x[2], cen) < 2.0:
            v = x[2]
            u1 = (a[0] - v[0], a[1] - v[1])
            u2 = (c[0] - v[0], c[1] - v[1])
            d1 = (hit[0][1][0] - hit[0][0][0], hit[0][1][1] - hit[0][0][1])
            d2 = (hit[1][1][0] - hit[1][0][0], hit[1][1][1] - hit[1][0][1])
            if d1[0] * u1[0] + d1[1] * u1[1] < 0:
                d1 = (-d1[0], -d1[1])
            if d2[0] * u2[0] + d2[1] * u2[1] < 0:
                d2 = (-d2[0], -d2[1])
            meas = _angle3((v[0] + d1[0], v[1] + d1[1]), v,
                           (v[0] + d2[0], v[1] + d2[1]))
            span = math.copysign(meas, span) if abs(abs(span) - meas) < 5.0 \
                else span
            cen = v
            # v6.4 T2-3: the RADIUS comes off the true centre too. Fitting a
            # short arc's own points leaves r a unit out however it is done
            # (three points or least squares -- over 11 degrees the sagitta
            # is 0.08 unit and the SVG rounds to 0.01), and arc_crossings
            # stops recognising an arc's own chords as its own once r is
            # 0.7 out: the arc was then refused for crossing ITSELF.
            r = sum(_d(v, q) for q in pts) / float(len(pts))
        out.append((cen, r, math.degrees(math.atan2(a[1] - cen[1], a[0] - cen[0])),
                    span))
    return out


@_per_block
def mark_geometry(svg, lengths=True, projected=False):
    """v6 C3 (E5): every mark read back against the geometry it marks.

      * a right-angle mark sits on 90 +- 0.5 degrees (plus the SVG's own
        coordinate rounding over the mark's size);
      * equality ticks: every group of the same count names pieces of the
        same length, within 2% (`lengths=False` skips this for a projection,
        where equal edges are drawn unequal), each tick is at least 5pt long
        and two ticks of a group stand 2.5pt of paper apart;
      * parallel-arrow chevrons of the same count sit on parallel strokes;
      * an angle text ('59°') next to an angle arc agrees with the arc's
        measured span within 0.6 degrees.
    v6.4 `projected=True` (a figure carrying a `<!--proj:...-->` tag): the
    right-angle mark's own corner and an angle text beside an arc are claims
    about the SOLID, not about the page — a cabinet drawing shows a real 90°
    as 117° and the mark is drawn as the projected square. Those two readings
    are skipped here and made instead by the 3D reader over the figure's
    `<!--v3d:...-->` vertices (selfcheck_solidkit.py); every size and spacing
    rule below still runs.

    Reads the finished SVG only."""
    M = _M(svg)
    projected = projected or getattr(M, "projected", False)
    ppu = M.pt_per_unit
    segs = _mark_model(M)
    out = []
    for v, ang, l, step, _ in _right_marks(M, segs):
        # the corner is measured on the mark's own rounded points: each end
        # may be off by half the rounding step (C3 r2: the old 0.15-unit
        # allowance passed a 89.2-degree mark written to 0.01)
        slack = 1.5 * step if step else 0.15
        tol = RIGHT_TOL + math.degrees(math.atan(slack / max(l, 1e-6)))
        if projected:
            continue              # the claim is 3D; read it from <!--v3d:-->
        if abs(ang - 90.0) > tol:
            out.append("right-angle mark at (%.1f, %.1f) sits on an angle of "
                       "%.1f° — a mark says 90°: put it on the vertex whose angle "
                       "is 90°, or draw the figure from numbers that make it right"
                       % (v[0], v[1], ang))
    axes = _axes(M)
    by_n = {}
    one_piece = []
    for j, g in _tick_groups(M, segs, axes):
        n = len(g)
        X = (sum(h[2][0] for h in g) / n, sum(h[2][1] for h in g) / n)
        for h in g:
            if h[4] * ppu < TICK_LEN_PT - 0.1:
                out.append("equality tick at (%.1f, %.1f) prints %.2fpt long, "
                           "under %.1fpt — draw it with figkit Figure.ticks"
                           % (h[2][0], h[2][1], h[4] * ppu, TICK_LEN_PT))
                break
        for h1, h2 in zip(g, g[1:]):
            gap = (h2[1] - h1[1]) - max(
                [s.width for s in M.strokes if s.el == segs[h1[3]][2]] or [1.0])
            if gap * ppu < TICK_GAP_PT - 0.1:
                out.append("equality ticks at (%.1f, %.1f) stand %.2fpt apart, "
                           "under %.1fpt — two ticks read as one"
                           % (X[0], X[1], gap * ppu, TICK_GAP_PT))
                break
        Lp = _marked_length(M, segs, j, X, piece=True)
        if Lp is not None:
            L, mid = Lp
            by_n.setdefault(n, []).append((L, X))
            one_piece.append((n, L, X, j, mid))
    # C3 r2: a group on an edge lying along an axis: off the axis's ticks by
    # AXIS_MARK_CLEAR x spacing (its centre) and 2 x TICK_GAP_PT of paper
    # (its outer stroke), or it reads as one more tick ('|| |')
    for j, g, ax in _axis_edge_groups(M, segs, axes):
        n = len(g)
        c = sum(hh[0] for hh in g) / n
        h = ax["orient"] == "h"
        X = (c, ax["at"]) if h else (ax["at"], c)
        wid = max([st.width for st in M.strokes
                   if st.el == segs[g[0][1]][2]] or [1.0])
        half = (g[-1][0] - g[0][0]) / 2.0 + wid / 2.0
        # every place of the lattice between its first and last tick, not
        # only the ticks it kept: a group centred ON an axis tick absorbs that
        # tick into the group, and the tick it hides was not in the list
        tk = sorted(ax["ticks"])
        s_, t0_ = ax["spacing"], ax.get("t0", tk[0])
        k0 = int(math.ceil((tk[0] - t0_) / s_ - 0.2))
        k1 = int(math.floor((tk[-1] - t0_) / s_ + 0.2))
        near = sorted(set([round(t0_ + k * s_, 2) for k in range(k0, k1 + 1)]
                          + list(tk))) + \
            [o["at"] for o in axes if o["orient"] != ax["orient"]]
        for t in near:
            d = abs(t - c)
            if d < AXIS_MARK_CLEAR * ax["spacing"] - 0.05 or \
                    (d - half) * ppu < 2 * TICK_GAP_PT - 0.1:
                out.append("%d equality tick(s) at (%.1f, %.1f) stand %.2fpt from "
                           "the axis tick at %.1f, in line with it — they read "
                           "as one more tick: put them half-way between two "
                           "axis ticks (figkit Figure.ticks(..., t=None) does it)"
                           % (n, X[0], X[1], max(d - half, 0.0) * ppu, t))
                break
        Lp = _marked_length(M, segs, j, X, piece=True)
        if Lp is not None:
            L, mid = Lp
            by_n.setdefault(n, []).append((L, X))
            one_piece.append((n, L, X, j, mid))
    # v6.3 r1 (S2-1-duplicate-marks): ONE segment carrying two tick groups of
    # DIFFERENT counts. A count is a length, so that segment is claimed to be
    # two lengths at once -- on a square 'AB = CD' drawn twice it printed n=1
    # on all four sides AND n=2 on AB and CD, and every sweep passed: the
    # groups agree inside each count, which is all the equal-lengths rule
    # asks. The claim is read off the finished SVG: the same carrier stroke,
    # the same resolved piece, two counts.
    for i1 in range(len(one_piece)):
        for i2 in range(i1 + 1, len(one_piece)):
            n1, L1, X1, j1, m1 = one_piece[i1]
            n2, L2, X2, j2, m2 = one_piece[i2]
            if n1 == n2 or j1 != j2 or L1 <= 0:
                continue
            # the same PIECE: the same length AND the same middle (two halves
            # of one side are equally long and are not the same segment)
            if abs(L1 - L2) > 0.01 * max(L1, L2) or _d(m1, m2) > 1.0:
                continue
            out.append("%d and %d equality tick(s) at (%.1f, %.1f) and "
                       "(%.1f, %.1f) mark the SAME segment (%.1f long) — a "
                       "count is a length, so one segment with two counts "
                       "reads as two different lengths: mark the claim once, "
                       "with the count the segment already carries"
                       % (n1, n2, X1[0], X1[1], X2[0], X2[1], L1))
    if lengths and not projected:
        for n, lst in sorted(by_n.items()):
            if len(lst) < 2:
                continue
            lo, hi = min(lst), max(lst)
            if hi[0] > 0 and (hi[0] - lo[0]) / hi[0] > EQUAL_TOL:
                out.append("%d equality tick(s) at (%.1f, %.1f) and (%.1f, %.1f) "
                           "mark pieces of %.1f and %.1f (%.1f%% apart) — equal "
                           "marks on unequal segments: give each length its own "
                           "tick count" % (n, lo[1][0], lo[1][1], hi[1][0],
                                           hi[1][1], lo[0], hi[0],
                                           100 * (hi[0] - lo[0]) / hi[0]))
    chev = _chevrons(M, segs)
    groups = {}
    for p, k, l in chev:
        groups.setdefault(k, []).append((p, l))
    by_n = {}
    for k, lst in groups.items():
        lst.sort(key=lambda t: (t[0][0], t[0][1]))
        cur = [lst[0]]
        for t in lst[1:]:
            if _d(t[0], cur[-1][0]) <= 2.0 * t[1] + 4.0 / ppu:
                cur.append(t)
            else:
                by_n.setdefault(len(cur), []).append((k, cur[0][0]))
                cur = [t]
        by_n.setdefault(len(cur), []).append((k, cur[0][0]))
    for n, lst in sorted(by_n.items()):
        base = None
        for k, p in lst:
            a, b = segs[k][0], segs[k][1]
            ang = math.degrees(math.atan2(b[1] - a[1], b[0] - a[0])) % 180.0
            tol = PARALLEL_TOL + math.degrees(math.atan(0.3 / max(_d(a, b), 1e-6)))
            if base is None:
                base = (ang, p)
                continue
            dd = abs(ang - base[0]) % 180.0
            dd = min(dd, 180.0 - dd)
            if dd > tol:
                out.append("%d parallel arrow(s) at (%.1f, %.1f) and (%.1f, %.1f) "
                           "sit on strokes %.1f° apart — parallel marks on lines "
                           "that are not parallel" % (n, base[1][0], base[1][1],
                                                     p[0], p[1], dd))
                break
    arcs = _arcs(M, segs)
    # v6.4 T2-1: an AXIS number is a bare number too, and a shaded triangle
    # drawn on a coordinate plane can stand its angle arc right over the
    # axis's '2' (selfcheck_plus.py:280). A number that an axis owns is that
    # axis's, never a wedge's, so it is taken out before the reading below.
    axis_nums = set()
    if arcs and any(_BARE_NUM.match(T.text) for T in M.texts):
        try:
            _ax = _axes(M)
            if _ax:
                for _rows in _axis_labels(M, _ax).values():
                    for _T, _pos, _e in _rows:
                        axis_nums.add(id(_T))
        except Exception:
            pass
    for T in M.texts:
        m = _DEG.match(T.text)
        bare = False
        if not m:
            m = _BARE_NUM.match(T.text)
            bare = m is not None
        if not m or not T.box:
            continue
        if bare and id(T) in axis_nums:
            continue
        val = float(m.group(1).replace(",", "."))
        if bare and val < NAME_MAX and "." not in m.group(1) \
                and "," not in m.group(1):
            # v6.4 T2-1: a single digit inside a wedge is the angle's NAME,
            # not its size -- euclid.parallels(58, mark=(1, 5)) numbers the
            # eight angles at a transversal 1..8 and prints each number on
            # its own wedge's bisector, the ordinary school convention for
            # "angle 1". No school figure draws a wedge of 9 degrees or less
            # (under LEAD_SPAN the value is called out on a leader anyway),
            # so nothing real is lost by reading one digit as a name. Two
            # digits and up, and anything with a decimal, are a measurement.
            continue
        c = T.centre()
        best = None
        for cen, r, a0, span in arcs:
            if bare:
                break          # bare numbers: inside-the-wedge or leader only
            dist = _d(c, cen)
            if not 0.3 * r <= dist <= r + 4.5 * T.size:
                continue
            th = math.degrees(math.atan2(c[1] - cen[1], c[0] - cen[0]))
            rel = (th - a0) % 360.0 if span > 0 else (a0 - th) % 360.0
            if rel > abs(span) + 25.0 and rel < 360.0 - 25.0:
                continue
            key = abs(dist - r)
            if best is None or key < best[0]:
                best = (key, abs(span), r)
        if best is None:
            # v6.3 r1 (S2-3): a CALLED-OUT number. A wedge too narrow to hold
            # its number inside it has the number just outside, tied to the
            # arc by a short LEADER line (shapekit.angle_arc lead=). The
            # leader is what makes the claim, and it is in the finished SVG,
            # so this reader can use it: a short straight stroke with one end
            # on the text and the other on the arc's own ring names that arc.
            # It only ADDS association -- without it a called-out number
            # would be measured by nothing, which is how a wrong number
            # would ship.
            led = []
            for cen, r_, a0, span in arcs:
                for p, q, _el, mk in segs:
                    if mk or _d(p, q) > 3.5 * T.size:
                        continue
                    for e, o in ((p, q), (q, p)):
                        if _gap_to_box(T.box, e) > 1.6 * T.size:
                            continue
                        if 0.35 * r_ <= _d(o, cen) <= 1.6 * r_:
                            led.append((abs(span), r_))
            if len(set(led)) == 1:
                best = (0.0, led[0][0], led[0][1])
        if best is None:
            # Stage review (L1-Stage-03): the radius band (r + 4.5 em) was
            # the only reach, so a degree value printed FARTHER out was
            # measured by nothing -- euclid.angles_at_point(labels={0: '70'})
            # prints its text at the ray's far end, 83 units from a vertex
            # whose arcs stand at r = 16-28, and the wedge it sits over
            # measured 55 degrees with problems() == []. A degree text that
            # lies strictly INSIDE exactly one wedge names that wedge,
            # however far out it stands.
            inside = []
            for cen, r_, a0, span in arcs:
                if _d(c, cen) < 0.3 * r_:
                    continue
                if bare and _d(c, cen) > r_ + NUM_REACH_EM * T.size:
                    continue   # too far out to be this wedge's own number
                th = math.degrees(math.atan2(c[1] - cen[1], c[0] - cen[0]))
                rel = (th - a0) % 360.0 if span > 0 else (a0 - th) % 360.0
                if 3.0 <= rel <= abs(span) - 3.0:
                    inside.append((abs(span), r_))
            if len(inside) != 1:
                continue
            best = (0.0, inside[0][0], inside[0][1])
        meas, r = best[1], best[2]
        dec = len(m.group(1).split(".")[1]) if "." in m.group(1) else 0
        tol = ANGLE_TOL + 0.5 * 10 ** -dec - 0.5 + \
            math.degrees(math.atan(0.3 / max(r, 1e-6)))
        tol = max(tol, ANGLE_TOL)
        if projected:
            continue          # a 3D angle, printed as itself, drawn squashed
        if abs(val - meas) > tol and abs(val - (360.0 - meas)) > tol:
            out.append("angle text %r labels an angle that measures %.1f° — "
                       "write the measured value, or draw the figure from the "
                       "given angle" % (T.text, meas))
    # P1 r2 (arcs-coincide-at-shared-vertex): two angle arcs at one vertex
    # on ONE circle over a common stretch print as one arc -- BAD = DAC drawn
    # on BAC's inner arc lost the equal-angles marking, and no sweep saw it
    out += coincident_arcs_in(arcs, M.pt_per_unit)
    return out


def coincident_arcs_in(arcs, ppu=None):
    """P1 r2: messages for angle arcs (svgcheck._arcs rows) that share a
    centre and a radius over more than 2 degrees of their spans.

    v6.2 Q1 r1 (arcs-coincident-false-refusal): 'one circle' is a PRINTED
    distance (ARC_SAME_R_PT, 1.5pt), not an absolute number of figure units.
    The old test, abs(r1 - r2) <= max(1.0, 0.08 * r1) in figure units, was
    written when a nest was spaced 4.5 units apart and could never fall
    inside 1.0; a nest spaced in printed pt does, above ~2.6pt per unit, so
    the author's own case was refused at width=430 (the head-figure width the
    skill itself uses) although the rings printed a correct 2.6pt apart -- and
    the message's cure ran the wrong way, since widening at a fixed window
    RAISES pt per unit. `ppu=None` keeps the old units test for a caller that
    has no scale to hand."""
    out = []

    def iv(a0, span):
        lo = a0 if span > 0 else a0 + span
        return lo % 360.0, abs(span)
    for i in range(len(arcs)):
        for j in range(i + 1, len(arcs)):
            (c1, r1, a1, s1), (c2, r2, a2, s2) = arcs[i], arcs[j]
            if _d(c1, c2) > 1.0:
                continue
            if ppu:
                if abs(r1 - r2) * ppu > ARC_SAME_R_PT:
                    continue
            elif abs(r1 - r2) > max(1.0, 0.08 * r1):
                continue
            l1, w1 = iv(a1, s1)
            l2, w2 = iv(a2, s2)
            ov = max(max(0.0, min(l1 + w1, l2 + sh + w2) - max(l1, l2 + sh))
                     for sh in (-360.0, 0.0, 360.0))
            if ov > 2.0:
                out.append("two angle arcs at (%.1f, %.1f) lie on one circle "
                           "(r %.1f) over %.0f° -- they print as one arc and "
                           "the angle marking is lost. Nothing is dropped: "
                           "give the nest room so its rings separate -- "
                           "bigger squares (size=) or a wider figure "
                           "(width=/max_width=); figkit.arc then steps the "
                           "containing angle's arcs outside the arcs of the "
                           "angle it contains"
                           % (c1[0], c1[1], r1, ov))
                break
    return out


def _arc_ends(a):
    """(centre, radius, the two end points, the interval in degrees)."""
    cen, r, a0, span = a
    lo = a0 if span > 0 else a0 + span
    p = (cen[0] + r * math.cos(math.radians(a0)),
         cen[1] + r * math.sin(math.radians(a0)))
    q = (cen[0] + r * math.cos(math.radians(a0 + span)),
         cen[1] + r * math.sin(math.radians(a0 + span)))
    return cen, r, (p, q), (lo % 360.0, abs(span))


@_per_block
def arcs_join(svg):
    """v6.2 Q1 (adjacent-equal-arcs-read-as-one): two angle arcs at ONE
    vertex, on ONE radius, meeting END TO END under an arc that spans them
    both.

    The author's case: arcs=[(A,B,D,1), (A,D,C,1), (A,B,C,3)] -- two
    adjacent angles marked equal, plus the angle containing them. The two
    single arcs were drawn at the SAME radius and touched along the shared
    ray AD, so the page showed one unbroken ring right across BAC with the
    triple arc outside it: the containing angle looked like it carried four
    arcs and 'BAD = DAC' could not be read at all. coincident_arcs_in does
    not see it -- the two arcs do not OVERLAP, they only touch.

    Read off the finished file: the arcs, their radii and their ends, with
    no help from the builder's bookkeeping."""
    M = _M(svg)
    arcs = [_arc_ends(a) for a in _arcs(M, _mark_model(M))]
    ppu = M.pt_per_unit
    out = []
    for i in range(len(arcs)):
        for j in range(i + 1, len(arcs)):
            c1, r1, e1, v1 = arcs[i]
            c2, r2, e2, v2 = arcs[j]
            if _d(c1, c2) > 1.0 or abs(r1 - r2) * ppu > ARC_SAME_R_PT:
                continue
            # end to end: an end of one within ARC_JOIN_PT of an end of the
            # other, and the two spans NOT overlapping (that is the other
            # sweep's case)
            gap = min(_d(p, q) for p in e1 for q in e2)
            if gap * ppu > ARC_JOIN_PT:
                continue
            ov = max(max(0.0, min(v1[0] + v1[1], v2[0] + sh + v2[1])
                         - max(v1[0], v2[0] + sh))
                     for sh in (-360.0, 0.0, 360.0))
            if ov > ARC_JOIN_TOL:
                continue
            lo = min(v1[0], v2[0])
            wide = v1[1] + v2[1]
            span = [a for a in arcs
                    if _d(a[0], c1) <= 1.0 and (a[1] - r1) * ppu > ARC_SAME_R_PT
                    and any(a[3][0] - sh <= lo + ARC_JOIN_TOL and
                            a[3][0] + a[3][1] - sh >= lo + wide - ARC_JOIN_TOL
                            for sh in (-360.0, 0.0, 360.0))]
            if not span:
                continue
            out.append(
                "two angle arcs at the vertex (%.1f, %.1f) are drawn on ONE "
                "circle (r %.1f, %.1fpt printed) and MEET end to end (%.2fpt "
                "of paper between them), with an arc of r %.1f spanning them "
                "both -- on paper that is one unbroken ring across the whole "
                "of the containing angle, so the two angles marked equal "
                "cannot be told apart and the containing angle reads as "
                "carrying one arc more than it was given. Draw the two at "
                "different radii (figkit.arc steps an arc off any arc at its "
                "vertex whose angle OVERLAPS OR TOUCHES it), or give the "
                "figure room for the nest: a wider figure (width=/"
                "max_width=) or bigger squares (size=)."
                % (c1[0], c1[1], r1, r1 * ppu, gap * ppu, span[0][1]))
    return out


def arc_markings(arcs):
    """v6.2 Q1 r1: the angle arcs of one figure gathered into MARKINGS.

    A marking is the whole group of rings that one arcs= entry drew: one
    vertex, one wedge, n concentric strokes ('equal to the other angles
    marked with n strokes'). Read off the finished file with no help from the
    builder: rings that share a centre and a wedge are one marking, however
    they are spaced. Returns dicts with cen, lo, w (the wedge, in degrees)
    and r (the radii, innermost first)."""
    out = []
    for cen, r, a0, span in arcs:
        lo = (a0 if span > 0 else a0 + span) % 360.0
        w = abs(span)
        for g in out:
            if _d(g["cen"], cen) > 1.0 or abs(g["w"] - w) > 2.0:
                continue
            d = abs(g["lo"] - lo)
            if min(d, 360.0 - d) <= 2.0:
                g["r"].append(r)
                break
        else:
            out.append(dict(cen=cen, lo=lo, w=w, r=[r]))
    for g in out:
        g["r"].sort()
    return out


@_per_block
def equal_arc_angles(svg):
    """v6.2 Q1 r1 (equal-arcs-not-checked-against-the-angles): two angles
    marked with the SAME number of strokes have to BE equal.

    That is the whole content of an equal-angle mark, and nothing anywhere
    measured it. An equality TICK is held to the lengths it marks
    (mark_geometry refuses two 1-tick segments 31.3% apart) and a parallel
    arrow to the directions it marks; an arc had only the angle-TEXT rule
    (which needs a text) and the coincidence rule (which is about where the
    ink lands). So a figure could mark a 30 degree angle and a 60 degree
    angle each with one stroke, at one vertex or at two, and render with
    problems() == [].

    An arc that carries its own text is a LABEL, not an equality claim
    ('55°', 'x', the name of the angle), and is left to the angle-text rule.

    Read off the finished SVG: the arcs, grouped into markings by their
    vertex and their wedge (arc_markings), and the wedges measured from the
    rays the arcs stand on."""
    M = _M(svg)
    arcs = _arcs(M, _mark_model(M))
    marks = arc_markings(arcs)
    for g in marks:
        # the text has to stand INSIDE the wedge (an axis number lying along
        # a ray is not the angle's label) and within reach of the rings
        edge = min(5.0, 0.2 * g["w"])
        g["text"] = any(
            T.text.strip() and T.box and
            0.3 * min(g["r"]) <= _d(T.centre(), g["cen"])
            <= max(g["r"]) + 2.5 * T.size and
            edge <= ((math.degrees(math.atan2(T.centre()[1] - g["cen"][1],
                                              T.centre()[0] - g["cen"][0]))
                      - g["lo"]) % 360.0) <= g["w"] - edge
            for T in M.texts)
    out = []
    by_n = {}
    for g in marks:
        if not g["text"]:
            by_n.setdefault(len(g["r"]), []).append(g)
    for n, lst in sorted(by_n.items()):
        # A SINGLE arc at one vertex names a wedge -- that is how angles
        # round a point and angles on a straight line are drawn, each
        # neighbour told from the next by its radius (euclid.
        # angles_at_point), and those wedges are not equal and do not claim
        # to be. So one stroke is a claim only against a marking at ANOTHER
        # vertex; two strokes have no second meaning and are a claim
        # anywhere. (Known gap: two adjacent wedges of ONE vertex marked
        # with one stroke each -- the author's own arcs=[(A,B,D,1),
        # (A,D,C,1)] -- read as equal to a person and are not measured here.
        # Write n=2 for a pair that must be read as equal.)
        pairs = [(g, f) for i, g in enumerate(lst) for f in lst[i + 1:]
                 if n > 1 or _d(g["cen"], f["cen"]) > 1.0]
        for g, f in pairs:
            lo, hi = sorted((g, f), key=lambda e: e["w"])
            if hi["w"] - lo["w"] <= max(ARC_EQ_DEG, ARC_EQ_PCT * hi["w"]):
                continue
            out.append(
                "%d angle arc(s) at (%.1f, %.1f) and %d at (%.1f, %.1f) say "
                "the two angles are equal, but one measures %.1f\u00b0 and the "
                "other %.1f\u00b0 -- on the page the number of strokes IS the "
                "claim ('equal to the other angles with the same number'), "
                "and this one is false. Nothing is dropped: give each angle "
                "its own stroke count in arcs= (n=1 for one pair, n=2 for "
                "the next), or draw the figure from angles that really are "
                "equal."
                % (n, lo["cen"][0], lo["cen"][1], n, hi["cen"][0],
                   hi["cen"][1], lo["w"], hi["w"]))
            break
    return out


@_per_block
def arc_crossings(svg):
    """v6.2 Q1 (r3-arc-stepout-unbounded): an angle arc that runs through a
    dot, a label or a side of the drawing.

    The step-out that keeps arcs off each other had no bound and nothing
    checked what the arc it moved landed on. On a -1..3 window the outer
    ring of the containing angle came out at r 22.3 with the vertex dot D
    22.63 away and the side BC 22.63 away: the arc ran through the dot and
    along the side, and mark_geometry, coincident_arcs_in and problems()
    were all silent.

    A stroke through the arc's OWN VERTEX is not a crossing -- the two rays
    of the angle and any cevian drawn from it leave the vertex by
    construction, and an arc must cross them. Everything else is."""
    M = _M(svg)
    segs = _mark_model(M)
    arcs = _arcs(M, segs)
    ppu = M.pt_per_unit
    pad = ARC_CROSS_PT / max(ppu, 1e-6)
    # what an arc may NOT cross: the DATA. The axis, its tick marks and the
    # light grid are furniture (_data_segs), the other marks at the vertex
    # are marks, and an arc is not a crossing of itself or of the other
    # rings of its own nest.
    mk = set()
    for a, b, el, m in segs:
        if m:
            mk.add((round(a[0], 2), round(a[1], 2), round(b[0], 2),
                    round(b[1], 2)))

    def _on_a_ring(p, q):
        return any(abs(_d(p, c) - r) < 0.7 and abs(_d(q, c) - r) < 0.7
                   for c, r, _, _ in arcs)
    data = [(a, b) for a, b in _data_segs(M, _axes(M))
            if (round(a[0], 2), round(a[1], 2), round(b[0], 2),
                round(b[1], 2)) not in mk and not _on_a_ring(a, b)]
    out = []
    for cen, r, a0, span in arcs:
        pts = [(cen[0] + r * math.cos(math.radians(a0 + span * k / 36.0)),
                cen[1] + r * math.sin(math.radians(a0 + span * k / 36.0)))
               for k in range(37)]
        hit = None
        for d in M.dots:
            if _d((d[0], d[1]), cen) < max(2.0, 0.25 * r):
                continue            # the vertex's own dot
            if min(_d(p, (d[0], d[1])) for p in pts) <= d[2] + pad:
                hit = ("the plotted point at (%.1f, %.1f)" % (d[0], d[1]))
                break
        if not hit:
            for T in M.texts:
                if not T.box or not T.text.strip():
                    continue
                b = (T.box[0] - pad, T.box[1] - pad,
                     T.box[2] + pad, T.box[3] + pad)
                if any(b[0] <= p[0] <= b[2] and b[1] <= p[1] <= b[3]
                       for p in pts):
                    hit = "the label %r" % T.text.strip()
                    break
        if not hit:
            for a, b in data:
                if _pt_seg(cen, a, b) < max(1.2, 0.12 * r):
                    continue        # a ray (or a cevian) out of the vertex
                if any(_pt_seg(p, a, b) <= pad for p in pts):
                    hit = ("the stroke from (%.1f, %.1f) to (%.1f, %.1f)"
                           % (a[0], a[1], b[0], b[1]))
                    break
        if hit:
            out.append(
                "the angle arc at (%.1f, %.1f) (r %.1f, %.1fpt printed) runs "
                "through %s -- an arc marks the angle at its vertex and has "
                "to stay inside it; out here it reads as part of the "
                "drawing. Nothing is dropped: give the arcs room (a wider "
                "figure, width=/max_width=, or bigger squares, size=), or "
                "mark fewer angles at that one vertex so the nest is "
                "shallower (figkit.ARC_INSIDE keeps a nest inside the "
                "shorter ray of its own angle)."
                % (cen[0], cen[1], r, r * ppu, hit))
    return out


@_per_block
def markers(svg, r_pt=MARKER_R_PT):
    """v6 C3 (E8): point markers as printed.

    A small closed white-filled shape with a dark outline (an open circle, a
    triangle, a square) is a marker: half its extent is at least 3.5pt, and no
    stroke is painted over it (a line drawn after an open end point shows
    through it and the point reads as filled). A small dark ring filled with
    nothing, with a stroke through its inside, is refused: the line shows
    through an 'open' point."""
    M = _M(svg)
    ppu = M.pt_per_unit
    out = []
    for s in M.strokes:
        if not s.closed or len(s.pts) < 3:
            continue
        xs = [p[0] for p in s.pts]
        ys = [p[1] for p in s.pts]
        ext = max(max(xs) - min(xs), max(ys) - min(ys))
        if ext * ppu > 2 * MARKER_MAX_PT or ext <= 0:
            continue
        c = ((max(xs) + min(xs)) / 2.0, (max(ys) + min(ys)) / 2.0)
        half = ext / 2.0
        fill = (s.fill or "").strip().lower()
        inside = [(a, b) for o in M.strokes if o.el != s.el
                  for a, b in o.segs() if _pt_seg(c, a, b) < 0.6 * half]
        if fill in ("", "none", "transparent"):
            ring = s.tag in ("circle", "ellipse") or (
                len(s.pts) >= 8 and all(abs(_d(c, pp) - half) <= 0.15 * half + 0.1
                                        for pp in s.pts))  # C3 r2: a <path> ring
            if ring and fill in ("none", "transparent") and inside:
                out.append("open point at (%.1f, %.1f) is filled with nothing and "
                           "a stroke shows through it — fill it white "
                           "(Figure.marker(p, 'open'))" % c)
            continue
        if _dark(fill):
            continue
        if half * ppu < r_pt - 0.05:
            out.append("marker at (%.1f, %.1f) prints %.2fpt across half, under "
                       "%.1fpt — too small to tell open from filled: draw it with "
                       "figkit Figure.marker(p, style), which prints at the floor "
                       "at any scale, or give it r >= %.2f units; keep the marker"
                       % (c[0], c[1], half * ppu, r_pt, r_pt / ppu))
        later = [1 for o in M.strokes if o.el > s.el
                 for a, b in o.segs() if _pt_seg(c, a, b) < 0.6 * half]
        if later:
            out.append("a stroke is painted over the marker at (%.1f, %.1f) — "
                       "draw markers after the strokes" % c)
    return out


MARKER_CLEAR_PT = 1.0    # paper between a label and a point marker's rim


def marker_gaps(svg, dots=False):
    """P2-02: (text, gap_pt, (cx, cy)) for every label beside a point marker
    (a white-filled open/tri/square marker; with dots=True a filled dot too):
    the printed paper between the label's box (a number's digits' ink) and
    the marker's outer edge (its rim plus half its stroke). A letter close to
    a filled dot reads as that dot's name, which is what it is; beside a
    RING it reads as one glyph ('QO'), so only rings are judged."""
    M = _M(svg)
    ppu = M.pt_per_unit
    shapes = []
    for s in M.strokes:
        if not s.closed or len(s.pts) < 3:
            continue
        xs = [p[0] for p in s.pts]
        ys = [p[1] for p in s.pts]
        ext = max(max(xs) - min(xs), max(ys) - min(ys))
        fill = (s.fill or "").strip().lower()
        if ext <= 0 or ext * ppu > 2 * MARKER_MAX_PT or \
                fill in ("", "none", "transparent") or _dark(fill):
            continue
        c = ((max(xs) + min(xs)) / 2.0, (max(ys) + min(ys)) / 2.0)
        shapes.append((c, s.segs(), (s.width or 0.0) / 2.0))
    if dots:
        for d in M.dots:
            cx, cy, r = d[0], d[1], d[2]
            if 2 * r * ppu > 2 * MARKER_MAX_PT:
                continue
            shapes.append(((cx, cy), r, 0.0))
    out = []
    for T in M.texts:
        if not T.box or not T.text.strip():
            continue
        b = T.box
        inks = [r.ink for r in T.runs if r.ink]
        if inks and len(inks) == len([r for r in T.runs if r.text.strip()]):
            # a number: its digits' ink, as every number sweep reads it
            b = (min(i[0] for i in inks), min(i[1] for i in inks),
                 max(i[2] for i in inks), max(i[3] for i in inks))
        for c, geo, hw in shapes:
            if isinstance(geo, list):
                if b[0] <= c[0] <= b[2] and b[1] <= c[1] <= b[3]:
                    g = 0.0
                else:
                    g = min(_box_seg_dist(b, a, q) for a, q in geo) - hw
            else:
                dx = max(b[0] - c[0], 0.0, c[0] - b[2])
                dy = max(b[1] - c[1], 0.0, c[1] - b[3])
                g = math.hypot(dx, dy) - geo
            if g * ppu < 3.0 * MARKER_CLEAR_PT:
                out.append((T.text, g * ppu, c))
    return out


NUM_MARKER_EM = 0.55      # paper a SLID axis number keeps from a point
                          # marker's rim, in ems of the number: under it the
                          # two read as one mark (the ring labelled '2')


def _ink_box(T):
    """A text's DIGITS' ink where it has runs with ink, else its box."""
    i = [r.ink for r in T.runs if r.ink]
    if not i:
        return T.box
    return (min(q[0] for q in i), min(q[1] for q in i),
            max(q[2] for q in i), max(q[3] for q in i))


def _marker_centres(M):
    """(centre, radius) of every POINT marker in the file: a filled dot and a
    small white-filled closed shape (the open ring, the square, the
    triangle). Drawn shapes (wider than 2 x MARKER_MAX_PT) are not markers."""
    out = []
    ppu = M.pt_per_unit
    for d in M.dots:
        if 2 * d[2] * ppu <= 2 * MARKER_MAX_PT:
            out.append(((d[0], d[1]), d[2]))
    for s in M.strokes:
        if not s.closed or len(s.pts) < 3:
            continue
        xs = [q[0] for q in s.pts]
        ys = [q[1] for q in s.pts]
        ext = max(max(xs) - min(xs), max(ys) - min(ys))
        fill = (s.fill or "").strip().lower()
        if ext <= 0 or ext * ppu > 2 * MARKER_MAX_PT or \
                fill in ("", "none", "transparent") or _dark(fill):
            continue
        out.append(((( max(xs) + min(xs)) / 2.0, (max(ys) + min(ys)) / 2.0),
                    ext / 2.0))
    return out


@_per_block
def number_owns_its_tick(svg):
    """C7r3-P2 (P3 leftovers r1): a NAMED point's nearest text is its own
    letter, never an axis number that stepped aside.

    On the +-7 Q plane at the shipped default width the x '2' slid 0.30 of a
    tick spacing (0.6 of a square) along the axis and came to rest 0.63
    squares from the open ring at (2, -1) -- nearer the ring than its own
    tick (0.95 squares) and 2.3x nearer than the point's OWN letter Q (1.43
    squares). On paper the ring is labelled '2' and Q floats unattached two
    squares away: 'O-two'. problems() and letter_side() both returned [].

    Judged here off the finished file, with no solver in the loop: every
    point marker that carries a letter, that letter's distance to it, and
    the distance of every axis number that is off its tick ALONG the axis.
    A number that only crossed its axis or stepped straight out stays in its
    tick's column and still reads as that tick's, so only a number that slid
    along the axis is judged; a marker with no letter has no name to lose."""
    M = _M(svg)
    axes = _axes(M)
    if not axes:
        return []
    marks = _marker_centres(M)
    if not marks:
        return []
    letters = [T for T in M.texts if T.box and len(T.text.strip()) == 1
               and T.text.strip().isalpha() and T.text.strip().isupper()]
    named = {}
    for T in letters:
        c = T.centre()
        k = min(range(len(marks)),
                key=lambda q: math.hypot(c[0] - marks[q][0][0],
                                         c[1] - marks[q][0][1]))
        d = math.hypot(c[0] - marks[k][0][0], c[1] - marks[k][0][1])
        if d > LETTER_FAR_EM * T.size:
            continue                    # not a point's name at all
        if k not in named or d < named[k][1]:
            named[k] = (T, d)
    if not named:
        return []
    groups = _axis_labels(M, axes)
    out = []
    for i, ax in enumerate(axes):
        h = ax["orient"] == "h"
        for T, pos, e in _tick_row(ax, groups.get(i, [])):
            if not T.box or e <= 0.05 or e > MOVED_TOL + 1e-6:
                continue
            if not _NUMTXT.match(T.text.strip()):
                continue
            c = T.centre()
            t = min(ax["ticks"], key=lambda q: abs(q - pos)) if ax["ticks"] \
                else None
            if t is None:
                continue
            own = (t, ax["at"]) if h else (ax["at"], t)
            dt = math.hypot(c[0] - own[0], c[1] - own[1])
            row = abs((c[1] if h else c[0]) - ax["at"])
            for k, (L, dl) in named.items():
                mc = marks[k][0]
                dn = math.hypot(c[0] - mc[0], c[1] - mc[1])
                # all four, as the drawing reads: the number slid; the marker
                # stands OUT IN THE PLANE, further from the axis than the row
                # of numbers itself (a point sitting on the axis at this very
                # tick is what the number is about, and the number beside it
                # reads right); the number ended nearer the marker than its
                # own tick; and nearer it than the point's own letter stands
                if abs((mc[1] if h else mc[0]) - ax["at"]) <= row:
                    continue
                if dn >= dl or dn >= dt:
                    continue
                out.append(
                    "the %s-axis number %r stepped %.2f x spacing aside "
                    "along its axis and now stands nearer the point marker "
                    "at %s than its own tick, and nearer it than "
                    "that point's own letter %r does "
                    "(%.2f against %.2f spacings) -- the marker reads as "
                    "labelled with the number and %r names nothing; give "
                    "the number its tick back: a step of 2 squares, a "
                    "larger size= or a wider figure (max_width=)"
                    % ("x" if h else "y", T.text, e,
                       _at_point(M, axes, mc) or "the point it names",
                       L.text.strip(), dn / ax["spacing"], dl / ax["spacing"],
                       L.text.strip()))
                break
    return out


def marker_clearance(svg, clear_pt=MARKER_CLEAR_PT):
    """P2-02: a label printed touching a point marker reads as one glyph
    with it ('QO' for the letter Q beside an open point) and hides which is
    the ring. The paper between a label's box and a marker's outer edge (a
    white-filled open/tri/square marker, or a filled dot) is at least
    MARKER_CLEAR_PT printed. figkit pads markers in printed pt
    (MARKER_PAD_PT), so a plane shrunk to fit keeps the gap."""
    out = []
    M0 = _M(svg)
    for text, g, c in marker_gaps(svg):
        # a tick number under a marker on a number line keeps the builder's
        # own fixed clearance (the axis row); a LETTER is what reads as one
        # glyph with a ring
        if _NUMTXT.match(text.strip()):
            # ... but a number's digits under (or on) a white marker are hidden
            # by it: the square markers at (2, +-0.5) printed over the x '2'
            if g <= 0.0:
                out.append("number %r prints under the point marker at "
                           "%s -- the marker covers its digits; give "
                           "the number room (a step that leaves this tick "
                           "unnumbered, larger squares or a wider figure)"
                           % (text, _at_point(M0, _axes(M0), c)
                              or "a point of the drawing"))
            continue
        if g < clear_pt - ROUND_PT:
            out.append("label %r prints %.2fpt from the point marker at "
                       "%s, under %.1fpt -- it reads as one glyph "
                       "with the marker; draw the point with figkit (its "
                       "label keeps the printed gap), or give the label room "
                       "(another side, a larger size= or a wider figure)"
                       % (text, max(g, 0.0),
                          _at_point(M0, _axes(M0), c)
                          or "a point of the drawing", clear_pt))
    return out


@_per_block
def reading_merge(svg, em=MERGE_EM):
    """v6 C3 (E24): two labels whose boxes share a baseline band (their heights
    overlap by at least half the smaller) with less than 0.6 em of paper
    between them read as one word: '5 16', '4 Q', 'B D'. Numbers in the row
    of an axis are a row of numbers, not a merge."""
    M = _M(svg)
    axes = _axes(M)
    row = set()
    aligned = set()
    out = []
    ts = [T for T in M.texts if T.box and T.text.strip()]
    row_ax = {}
    if axes:
        groups = _axis_labels(M, axes)
        for i, labs in groups.items():
            for T, pos, e in labs:
                row.add(id(T))
                # P3 leftovers r1 (pilot-c17b): WHICH row. The close-row
                # concession below belongs to two numbers of ONE row; two
                # numbers of DIFFERENT axes meeting at the crossing have no
                # row to be read along and merge into one string ('-2-5').
                row_ax.setdefault(id(T), i)
        # a label standing IN the row of an axis's numbers, between them,
        # reads as one of them ('4 Q 6', '2 6 4' with the value '6' of an
        # edge lying on the axis) even when no gap is under 0.6 em
        # v6 stage 1b: a number moved aside to keep a stroke whole (up to
        # MOVED_TOL) is still one of the row's numbers, not a foreign label
        # standing in it
        mains = [[(T, pos) for T, pos, e in _tick_row(ax, groups[i])
                  if e <= MOVED_TOL] for i, ax in enumerate(axes)]
        aligned = set(id(T) for m in mains for T, _ in m)
        zeros = set()
        for i, ax in enumerate(axes):
            main = mains[i]
            if len(main) < 2:
                continue
            ids = aligned
            sc = _scale(ax, [(T, pos, 0.0) for T, pos in main])
            sp = ax["spacing"]
            over = min(0.5 * sp, em * max(T.size for T, _ in main))
            lo = min(pos for _, pos in main) - over
            hi = max(pos for _, pos in main) + over
            k0, k1 = (1, 3) if ax["orient"] == "h" else (0, 2)
            band = (min(T.box[k0] for T, _ in main), max(T.box[k1] for T, _ in main))
            # C3 r3: the origin's '0' in the band, within 1.5 spacings of the
            # end number, starts the row: a value between it and the first
            # number ('0 2 2 4 6') stands in the row
            for T in ts:
                if T.text.strip() != "0" or id(T) in ids:
                    continue
                ext = T.box[k1] - T.box[k0]
                if min(T.box[k1], band[1]) - max(T.box[k0], band[0]) < 0.25 * ext:
                    continue
                c = _along(T, ax)
                if lo + over - 1.5 * sp <= c < lo + over:
                    lo = min(lo, c - over)
                    zeros.add(id(T))
                elif hi - over < c <= hi - over + 1.5 * sp:
                    hi = max(hi, c + over)
                    zeros.add(id(T))
            for T in ts:
                # a number of a row is judged by tick_alignment; any other
                # text -- a letter, a value, a number off every tick -- here
                if id(T) in ids or (T.text.strip() == "0" and
                                    (id(T) in row or id(T) in zeros)):
                    continue
                ext = T.box[k1] - T.box[k0]
                if min(T.box[k1], band[1]) - max(T.box[k0], band[0]) < 0.25 * ext:
                    continue
                if not lo <= _along(T, ax) <= hi:
                    continue
                if sc and _NUMTXT.match(T.text.strip()):
                    read, dv = sc
                    if abs(read(_along(T, ax)) - _value(T.text.strip())) <= \
                            0.05 * abs(dv):
                        continue        # '2.5' printed at 2.5 reads true
                if True:
                    out.append("label %r stands in the row of the %s-axis numbers "
                               "— it reads as one of them; place it off the row"
                               % (T.text, "x" if ax["orient"] == "h" else "y"))
    # C6 r6: a point's LETTER stacked in the column of an axis number, beyond
    # it on the same side of the axis and within STACK_EM, reads with it as a
    # pair: F4's 'P' over the x '-2' (moved above the axis) read as P(-2, ..)
    # (a plane only: a number line's letters stand above it, its numbers below)
    if axes and len(set(a["orient"] for a in axes)) == 2:
        for i, labs in groups.items():
            ax = axes[i]
            h = ax["orient"] == "h"
            a_, c_ = (0, 1) if h else (1, 0)      # along, across
            for N, _pos, e in labs:
                if not _NUMTXT.match(N.text.strip()) or e > MOVED_TOL:
                    continue
                nb = N.box
                ns = 1 if (nb[c_] + nb[c_ + 2]) / 2.0 > ax["at"] else -1
                for T in ts:
                    if not _POINT_NAME.match(T.text.strip()) or \
                            _NUMTXT.match(T.text.strip()):
                        continue
                    b = T.box
                    over = min(b[a_ + 2], nb[a_ + 2]) - max(b[a_], nb[a_])
                    if over < 0.5 * min(b[a_ + 2] - b[a_], nb[a_ + 2] - nb[a_]):
                        continue
                    if (1 if (b[c_] + b[c_ + 2]) / 2.0 > ax["at"] else -1) != ns:
                        continue
                    gap = (b[c_] - nb[c_ + 2]) if ns > 0 else (nb[c_] - b[c_ + 2])
                    if -0.5 < gap < STACK_EM * max(T.size, N.size) - 1e-6:
                        out.append("label %r stands in the column of the %s-axis "
                                   "number %r, %.2f em beyond it -- the two read "
                                   "as a pair; place the letter off the "
                                   "number's column"
                                   % (T.text, "x" if h else "y", N.text,
                                      max(gap, 0.0) / max(T.size, N.size)))
    # P3 leftovers r1 (pilot-c17b): where the two rows meet, a number of the
    # x row and a number of the y row are two strings side by side, with no
    # row for a reader to scan along. Judged on the digits' ink, in both
    # directions (they may stand corner to corner as well as side by side).
    if axes and len(set(row_ax.values())) > 1:
        nums = [T for T in ts if id(T) in row_ax and
                _NUMTXT.match(T.text.strip())]
        for i in range(len(nums)):
            for j in range(i + 1, len(nums)):
                a, b = nums[i], nums[j]
                if row_ax[id(a)] == row_ax[id(b)]:
                    continue
                if "0" in (a.text.strip(), b.text.strip()):
                    continue            # the corner '0' has its own rule
                A, B = _ink_box(a), _ink_box(b)
                # only a pair standing SIDE BY SIDE on one line: the house
                # corner has the x and y numbers touching corner to corner
                # and a reader tells them apart by the line they sit on
                ov = min(A[3], B[3]) - max(A[1], B[1])
                hh = min(A[3] - A[1], B[3] - B[1])
                if hh <= 0 or ov < CROSS_BAND * hh:
                    continue
                g = max(A[0] - B[2], B[0] - A[2], 0.0)
                if g >= CROSS_ROW_EM * max(a.size, b.size) - 1e-6:
                    continue
                out.append(
                    "the x-axis number %r and the y-axis number %r print "
                    "%.2f em apart on one line where the rows meet (needs "
                    "%.2f) -- they "
                    "are not one row and read as one string, %r; give the "
                    "crossing room: a step of 2 squares, a larger size=, a "
                    "wider figure (width=/max_width=) or a window that does "
                    "not crowd the corner, never a dropped number"
                    % (a.text if row_ax[id(a)] == 0 else b.text,
                       b.text if row_ax[id(a)] == 0 else a.text,
                       g / max(a.size, b.size), CROSS_ROW_EM,
                       (a.text + b.text) if row_ax[id(a)] == 0
                       else (b.text + a.text)))
    for i in range(len(ts)):
        for j in range(i + 1, len(ts)):
            a, b = ts[i], ts[j]
            # P3 leftovers r1 (pilot-c17b): the '0' at the crossing belongs
            # to both rows; any other pair from two DIFFERENT axes is judged
            # as two ordinary labels, not as a row.
            same_row = (id(a) in row and id(b) in row and
                        (row_ax.get(id(a)) == row_ax.get(id(b)) or
                         "0" in (a.text.strip(), b.text.strip())))
            if same_row and not (
                    id(a) in aligned and id(b) in aligned):
                continue
            if same_row:
                # C7P-01: two numbers OF a row may stand closer than a word
                # space, but not closer than ROW_GAP_EM: a '-2' slid toward
                # '-1' printed 0.6pt from it, and the row read '-2-1' (the
                # PDF text extractor joined them into one word)
                A, B = a.box, b.box
                h = min(A[3] - A[1], B[3] - B[1])
                if min(A[3], B[3]) - max(A[1], B[1]) < 0.5 * h:
                    continue
                gap = max(A[0] - B[2], B[0] - A[2])
                if gap < ROW_GAP_EM * max(a.size, b.size) - 1e-6:
                    out.append("axis numbers %r and %r print %.2f em apart "
                               "(needs %.2f) — they read as one number; give the "
                               "moved one room (a step of 2 squares, a larger "
                               "size=, a wider figure), never drop it"
                               % (a.text, b.text, max(gap, 0.0) / max(a.size, b.size),
                                  ROW_GAP_EM))
                continue
            A, B = a.box, b.box
            h = min(A[3] - A[1], B[3] - B[1])
            if min(A[3], B[3]) - max(A[1], B[1]) < 0.5 * h:
                continue
            gap = max(A[0] - B[2], B[0] - A[2])
            want = merge_em(a.text, b.text, em)
            lim = want * max(a.size, b.size)
            if gap < lim - 1e-6:
                out.append("labels %r and %r share a baseline %.2f em apart "
                           "(needs %.1f)%s — they read as one %s"
                           % (a.text, b.text,
                              max(gap, 0.0) / max(a.size, b.size), want,
                              ": they print as the same mark"
                              if confusable(a.text, b.text) else "",
                              "mark" if confusable(a.text, b.text)
                              else "word"))
    return out


@_per_block
def letter_in_slot(svg, share=SLOT_SHARE):
    """Stage-1 fix r1 (PR2): a point's LETTER standing where an axis number
    belongs reads as that tick's name. On the F4 fixture the x '-2' stepped
    above the axis (a curve took its spot) and the letter P of (-1, 0) was
    placed in the empty slot below tick -2: 12.4 units from that tick, 25.3
    from its own dot, and the page read P as x = -2.

    Read off the file: each axis's row of numbers (the side most of them
    stand on, its centre line and the numbers' width), the numbering lattice
    fitted from their values, and every slot of that lattice along the ticks.
    A lone point name (one Latin letter, primes, an index) whose box covers
    `share` of its own area inside a slot is refused, whether or not the
    slot's number still stands there."""
    M = _M(svg)
    axes = _axes(M)
    if not axes:
        return []
    groups = _axis_labels(M, axes)
    out = []
    for i, ax in enumerate(axes):
        labs = [T for T, pos, e in groups.get(i, []) if e <= TICK_TOL]
        if len(labs) < 2:
            continue
        h = ax["orient"] == "h"
        sides = [1 if (T.centre()[1] if h else T.centre()[0]) > ax["at"] else -1
                 for T in labs]
        home = 1 if sides.count(1) >= sides.count(-1) else -1
        row = [T for T, sd in zip(labs, sides) if sd == home]
        if len(row) < 2:
            continue
        pv = sorted(set((_along(T, ax), _value(T.text.strip())) for T in labs))
        f = _fit([(p_, v) for p_, v in pv])
        vals = sorted(set(v for _, v in pv))
        steps = [b - a for a, b in zip(vals, vals[1:]) if b - a > 1e-9]
        if not f or not steps:
            continue
        a_, b_ = f
        step = min(steps)
        perp = sorted((T.centre()[1] if h else T.centre()[0]) for T in row)
        mid = perp[len(perp) // 2]
        # a slot is as wide as ITS number prints: the row's widest glyph
        # width times the characters of that value
        cw = max((T.box[2] - T.box[0]) / max(len(T.text.strip()), 1)
                 for T in row)
        hh = max(T.box[3] - T.box[1] for T in row) / 2.0
        lo = min(ax["ticks"]) - 0.5 * ax["spacing"]
        hi = max(ax["ticks"]) + 0.5 * ax["spacing"]
        v0 = (min(a_ + b_ * lo, a_ + b_ * hi))
        v1 = (max(a_ + b_ * lo, a_ + b_ * hi))
        k0 = int(math.ceil(v0 / step - 1e-6))
        k1 = int(math.floor(v1 / step + 1e-6))
        if k1 - k0 > 400:
            continue
        slots = []
        for k in range(k0, k1 + 1):
            pos = (k * step - a_) / b_
            if abs(pos - _near_tick(pos, ax)) > TICK_TOL * ax["spacing"]:
                continue
            v = k * step
            hw = cw * len(("%g" % v)) / 2.0
            if h:
                slots.append((v, (pos - hw, mid - hh, pos + hw, mid + hh),
                              (pos, ax["at"])))
            else:
                slots.append((v, (mid - hw, pos - hh, mid + hw, pos + hh),
                              (ax["at"], pos)))
        pts = [(d[0], d[1]) for d in M.dots if d[2] * M.pt_per_unit <= MARKER_MAX_PT]
        for k in M.strokes:
            if k.closed and len(k.pts) >= 3 and k.fill and \
                    not _dark(k.fill) and k.fill.strip().lower() not in \
                    ("none", "transparent") and \
                    _extent(k.pts) * M.pt_per_unit <= 2 * MARKER_MAX_PT:
                xs_ = [q[0] for q in k.pts]
                ys_ = [q[1] for q in k.pts]
                pts.append(((max(xs_) + min(xs_)) / 2.0,
                            (max(ys_) + min(ys_)) / 2.0))
        for T in M.texts:
            t = T.text.strip()
            if not T.box or not _POINT_NAME.match(t) or t in ("x", "y"):
                continue
            bx = T.box
            area = max((bx[2] - bx[0]) * (bx[3] - bx[1]), 1e-9)
            c = T.centre()
            near = min([math.hypot(c[0] - q[0], c[1] - q[1]) for q in pts]
                       or [None])
            for v, sb, tk in slots:
                ov = (max(0.0, min(bx[2], sb[2]) - max(bx[0], sb[0])) *
                      max(0.0, min(bx[3], sb[3]) - max(bx[1], sb[1])))
                # ... or, in the row's band, nearer that tick than any point:
                # the letter names the tick, not a point
                band = (abs(c[1] - mid) <= 2.0 * hh + 1.0 if h else
                        abs(c[0] - mid) <= hw + 2.0 * hh + 1.0)
                closer = (near is not None and band and
                          all(math.hypot(tk[0] - q[0], tk[1] - q[1]) > 0.5
                              for q in pts) and
                          math.hypot(c[0] - tk[0], c[1] - tk[1]) < near)
                if ov >= share * area or closer:
                    out.append("letter %r stands in the slot of the %s-axis "
                               "number %s -- it reads as that tick's name, "
                               "not its point's; place the letter on another "
                               "side of its point (prefer=), or give the "
                               "figure room (a larger size= or width=)"
                               % (t, "x" if h else "y",
                                  ("%g" % v).replace("-", MINUS)))
                    break
    return out


@_per_block
def number_boxes(svg):
    """Stage-1 fix r1 (PR11): two NUMBERS whose text boxes overlap print as
    one cluster -- the y '1' stacked on the origin's '0' read as '1 over 0'
    and an x '-1' and a y '-1' overlapping by a corner printed as a
    staircase. Row numbers side by side are judged by reading_merge; this
    reads any two numeric labels whose font boxes overlap in both directions
    one column (a box over the other's width) with their heights overlapping
    -- less than half, or the pair is a struck label, not a stack. A corner
    overlap of an x and a y number is not judged here (see not_done r1)."""
    M = _M(svg)
    nums = [T for T in M.texts if T.box and _NUMTXT.match(T.text.strip())]
    axes = _axes(M)
    owner = {}
    if axes:
        for g, labs in _axis_labels(M, axes).items():
            for T, pos, e in labs:
                owner[id(T)] = g
    out = []
    for i in range(len(nums)):
        for j in range(i + 1, len(nums)):
            # one axis's own column of numbers is a row, not a stack (a slid
            # '2' under its '3' is judged by the row sweeps); a stack is two
            # axes' numbers, or the origin's '0' under a number
            gi, gj = owner.get(id(nums[i])), owner.get(id(nums[j]))
            zero = 0.0 in (_value(nums[i].text), _value(nums[j].text))
            if gi is not None and gi == gj and not zero:
                continue
            a, b = nums[i].box, nums[j].box
            ox = min(a[2], b[2]) - max(a[0], b[0])
            oy = min(a[3], b[3]) - max(a[1], b[1])
            narrow = min(a[2] - a[0], b[2] - b[0])
            if ox >= 0.9 * narrow and oy > 0.5 and \
                    oy < 0.5 * min(a[3] - a[1], b[3] - b[1]):
                out.append("numbers %r and %r print STACKED, their boxes "
                           "overlapping (%.1f x %.1f units) -- they read as one "
                           "cluster; "
                           "give them room (a step of 2 squares, a larger "
                           "size= or a wider figure)"
                           % (nums[i].text, nums[j].text, ox, oy))
    return out


LETTER_FAR_EM = 3.0    # a point's letter within this x its size of its point
LETTER_NEAR_EM = 1.4   # ... and a letter this close to a point NAMES it: past
LETTER_REFUSE_EM = 1.65  # v6.2 Q1b: ... and refused from here (see letter_side)
                       # Re-measured by LOOKING at the renders (the PNGs in
                       # v62/work/shots): the 3-4-5 triangle with K on the
                       # origin puts 'K' a square up the y-axis at 1.44 em
                       # and reads perfectly; the pilot's 12b at 1.46 em is
                       # a square diagonally out and still reads; 18b at
                       # 1.65 em prints 'O' ABOVE the plane beside the y
                       # arrow and 14b at 1.74 em two rows under the x-axis
                       # -- those two name nothing. 1.75 (the v6.2 figure)
                       # let all four through.
                       # it the point's nearest text is something else (at the
                       # origin, the axis '0' beside the dot) and the letter
                       # reads as naming whatever it landed by. P3 leftovers
                       # r2 (origin-letter-far-from-its-point): 24 of the 209
                       # rebuilt pilot planes stood 'O' a full square or more
                       # from the origin dot, worst 2.27 squares / 1.92 em,
                       # with problems() and letter_side() empty on every one;
                       # every NON-origin letter of that corpus was inside
                       # 1.26 em.


def letter_side(svg, far_em=LETTER_FAR_EM, reading=True, curable=False):
    """P3 (L2C7r3-04 / C7r3-P2): a point's letter stands on its point's side
    of the ink, and within reach of it.

    The solver's ring search had a pass that dropped the reach rule when the
    near spots were taken. It printed 'Q' on the far side of the triangle's
    base, two squares from its ring, where it names the point the base
    crosses -- and the ring was left nameless. Read here off the finished
    file: every single-letter label, the dot or marker nearest it, and the
    DATA strokes between the two (the axes, their tick marks and the light
    grid are not data, and a stroke that ends AT the point does not part them
    from each other)."""
    M = _M(svg)
    axes = _axes(M)
    # a COORDINATE PLANE only: on a number line the letters name points on
    # one axis and the brackets, arcs and bars of the item stand between a
    # letter and its dot by design (a span's bracket over its own point)
    if not [a for a in axes if a["orient"] == "h"] or \
            not [a for a in axes if a["orient"] == "v"]:
        return []
    pts = [(d[0], d[1], d[2]) for d in M.dots]
    for s in M.strokes:                     # open/tri/square markers: rims
        if not s.closed or len(s.pts) < 3:
            continue
        xs = [p[0] for p in s.pts]
        ys = [p[1] for p in s.pts]
        ext = max(max(xs) - min(xs), max(ys) - min(ys))
        fill = (s.fill or "").strip().lower()
        if ext <= 0 or ext * M.pt_per_unit > 2 * MARKER_MAX_PT or \
                fill in ("", "none", "transparent") or _dark(fill):
            continue
        pts.append(((max(xs) + min(xs)) / 2.0, (max(ys) + min(ys)) / 2.0,
                    ext / 2.0))
    if not pts:
        return []
    H = [a for a in axes if a["orient"] == "h"]
    V = [a for a in axes if a["orient"] == "v"]
    box = (min(a["lo"] for a in H), min(a["lo"] for a in V),
           max(a["hi"] for a in H), max(a["hi"] for a in V))
    # the axes' OWN names ('x', 'y'): a lone letter standing at an axis's far
    # end.  A point's letter printed nearer one of them than its own point
    # reads as naming the axis (pilot level a page 9: 'y O' above the y
    # arrow, with the origin dot left nameless).
    names = []
    for a in axes:
        end = ((a["hi"], a["at"]) if a["orient"] == "h"
               else (a["at"], a["lo"]))
        for T in M.texts:
            q = T.text.strip()
            if not T.box or len(q) != 1 or not q.isalpha():
                continue
            cc = T.centre()
            if math.hypot(cc[0] - end[0], cc[1] - end[1]) <= 2.0 * T.size:
                names.append((cc, q))

    def on_axis(a, b):
        for ax in axes:
            j = 1 if ax["orient"] == "h" else 0
            if abs(a[j] - ax["at"]) < 0.6 and abs(b[j] - ax["at"]) < 0.6:
                return True             # the axis line itself
            if abs(a[j] - ax["at"]) < 6.0 and abs(b[j] - ax["at"]) < 6.0 and \
                    math.hypot(b[0] - a[0], b[1] - a[1]) < 12.0:
                return True             # one of its tick marks
        return False
    data = [(a, b) for a, b, el in M.dark_segs() if not on_axis(a, b)
            and math.hypot(b[0] - a[0], b[1] - a[1]) > 1.0]
    out = []
    for T in M.texts:
        t = T.text.strip()
        if not T.box or len(t) != 1 or not t.isalpha() or not t.isupper():
            continue
        c = T.centre()
        own = min(pts, key=lambda q: math.hypot(c[0] - q[0], c[1] - q[1]))
        # v6.2 Q1b: 'O' names the ORIGIN, wherever it ended up. Paired with
        # the nearest dot instead, the letter escaped every reading rule by
        # walking far enough: on the pilot's 14b the solver's no-reach
        # fallback parked 'O' 0.78 em from the OTHER point's dot (2.16 em
        # from the origin), and the sweep then read it as that point's
        # letter, standing comfortably within reach -- so the figure passed
        # while 'O' sat beside P. A dot at the axes' crossing owns 'O'.
        if t == "O":
            cross = [(a["at"], b["at"]) for a in axes if a["orient"] == "v"
                     for b in axes if b["orient"] == "h"]
            for q in pts:
                if any(math.hypot(q[0] - x, q[1] - y)
                       <= 0.5 * (_grid_square(M, None, None) or
                                 min(a["spacing"] for a in axes))
                       for x, y in cross):
                    own = q
                    break
        d = math.hypot(c[0] - own[0], c[1] - own[1])
        # P3 leftovers r1 (origin-letter-flies-off-its-point): a point's
        # letter printed OUTSIDE the drawn plane -- past an axis's arrow tip,
        # off the grid -- names nothing a reader can find, and beside the
        # axis's own name it reads as naming the AXIS. On pilot level a page
        # 9 the origin's 'O' printed above the y arrow, 2.1 squares from its
        # dot and one glyph from the 'y', and the origin dot was left unnamed.
        # A letter whose own point is inside the plane belongs inside it too.
        if OUTSIDE_NEAR_EM * T.size < d <= OUTSIDE_FAR_EM * T.size and \
                box[0] <= own[0] <= box[2] and box[1] <= own[1] <= box[3]:
            pad = 0.5 * T.size
            outside = not (box[0] - pad <= c[0] <= box[2] + pad and
                           box[1] - pad <= c[1] <= box[3] + pad)
            nm = min((math.hypot(c[0] - q[0], c[1] - q[1]), n)
                     for q, n in names) if names else None
            if outside and nm and nm[0] < d:
                out.append(
                    "the letter %r prints OUTSIDE the drawn plane, past the "
                    "end of an axis, NEARER that axis's own name %r (%.2f em "
                    "away) than its own point (%.2f em) -- a reader takes the "
                    "pair for the axis being named and the point is left "
                    "nameless. Give the letter room inside the plane: a wider "
                    "figure (width=/max_width=), bigger squares (size=), a "
                    "window with room beside the point, or place it by hand "
                    "(the point in dots=[p], its letter in "
                    "labels=[(p, %r, (dx, dy))])"
                    % (t, nm[1], nm[0] / T.size, d / T.size, t))
                continue
        # r2: ... and a letter that DOES name a point stands within reading
        # distance of it -- see LETTER_NEAR_EM
        at_origin = any(
            math.hypot(own[0] - a["at"], own[1] - b["at"])
            <= 0.5 * (_grid_square(M, b, a) or min(a["spacing"],
                                                   b["spacing"]))
            for a in axes if a["orient"] == "v"
            for b in axes if b["orient"] == "h")
        if reading and at_origin and d <= far_em * T.size \
                and d > LETTER_NEAR_EM * T.size:
            # ... and only when the point is CLAIMED by another text. The
            # clause is the ORIGIN's: there the axis '0' stands beside the
            # dot by construction, so a letter out of reading distance
            # leaves the dot reading as named by the NUMBER. Elsewhere a
            # letter far from its point is judged by the 3 em cap and by
            # the side-of-the-ink rule below -- a point that sits ON an
            # axis always has a tick number near it (the F4 figure's
            # P(-1, 0) beside the origin's '0'), and holding those to the
            # reading distance refused figure after figure that reads
            # correctly.
            rivals = sorted((math.hypot(own[0] - q.centre()[0],
                                        own[1] - q.centre()[1]), i, q)
                            for i, q in enumerate(M.texts)
                            if q.box and q is not T and q.text.strip())
            near = (rivals[0][0], rivals[0][2].text.strip())
            if near[0] >= d:
                continue
            # v6.2 Q1: `curable` is what problems() passes. The clause
            # REPORTS from LETTER_NEAR_EM (1.4, where it was calibrated: over
            # the rebuilt pilot every letter that was not the origin's stood
            # within 1.26 em). It REFUSES from LETTER_REFUSE_EM, because a
            # point ON the origin with the axis '0' beside it has a floor of
            # its own: the skill's own gallery q15 (a circle centred on the
            # origin with two chords through it) prints 'O' at 1.56-1.62 em
            # at EVERY width from 210 to 430 and at every hand offset, so a
            # refusal there would name no fix that renders -- the escape
            # doctrine 4 forbids. Above the refusal line the letter is out of
            # reach by half a square more, which is the defect the author
            # saw (1.67-2.93 em across the pilot). And only where a near spot
            # is actually free, so the ladder's bigger figure can take it.
            # v6.2 Q1b (the verifier's V1): when the text that owns the
            # point is the origin's own '0', the figure has a cure that
            # RENDERS and doctrine 4 is satisfied at the reading distance
            # itself -- origin=False prints the zero nowhere and hands the
            # corner to the letter. Measured over the 70 rebuilt pilot
            # planes: 12 stood past the reading distance, every one of them
            # with the '0' as the nearer text, and origin=False rendered all
            # 12 and brought the letter to 0.88-1.41 em (11 of the 12 then
            # nearer their point than any other text). So THAT case is
            # refused from the reading distance, whether or not a near spot
            # is free -- the cure is not a near spot, it is taking the
            # rival off the paper. Every other rival keeps the old, higher
            # floor and the free-spot test.
            zero_rival = near[1].strip() == "0"
            if curable and (d <= LETTER_REFUSE_EM * T.size or
                            not (zero_rival
                                 or _letter_near_spot_free(M, own, T))):
                continue
            out.append(
                "the letter %r stands %.2f em from the point it names (the "
                "reading distance is %.2f em) -- the nearest text to that "
                "point is %r, so the point reads as named by THAT and the "
                "letter as naming whatever it landed beside. %s"
                % (t, d / T.size, LETTER_NEAR_EM, near[1],
                   ("The origin has ONE name here, not two: print the axes' "
                    "zero nowhere and let the letter be it -- "
                    "origin=False. (Or bring the letter to its point: "
                    "bigger squares (size=), a wider figure "
                    "(width=/max_width=), or place it by hand -- the point "
                    "in dots=[p], its letter in labels=[(p, %r, (dx, "
                    "dy))].) Never drop the letter." % t) if zero_rival else
                   ("Bring the letter to its point: a wider figure "
                    "(width=/max_width=), bigger squares (size=), or place "
                    "it by hand (the point in dots=[p], its letter in "
                    "labels=[(p, %r, (dx, dy))])" % t)))
            continue
        if d > far_em * T.size:
            # a letter that far from every dot is not a point's name (a
            # number line's reference label, a set's name): the solver holds
            # a POINT letter to its reach, and this sweep judges only the
            # letters it can pair with a point
            continue
        near = (own[0], own[1])
        # a stroke that ends at the point, or grazes it (a thin triangle's
        # far edge passes a quarter-square from the middle vertex), does not
        # part the letter from its point -- the letter is beside both
        graze = own[2] + 0.6 * T.size
        for a, b in data:
            if math.hypot(a[0] - near[0], a[1] - near[1]) < graze or \
                    math.hypot(b[0] - near[0], b[1] - near[1]) < graze:
                continue
            if _pt_seg(near, a, b) < graze:
                continue
            if _seg_cross(near, c, a, b):
                out.append(
                    "the letter %r is parted from its point by a stroke -- "
                    "on the far side of an edge it names another point (the "
                    "one the edge passes through), and its own point is left "
                    "nameless. Place the letter on its point's side of the "
                    "ink: give the figure room (a wider figure, width=/"
                    "max_width=, or bigger squares, size=)" % t)
                break
    return out


def _seg_cross(p, q, a, b):
    """Do segments pq and ab cross (proper crossing)?"""
    def side(o, u, v):
        return (u[0] - o[0]) * (v[1] - o[1]) - (u[1] - o[1]) * (v[0] - o[0])
    d1, d2 = side(a, b, p), side(a, b, q)
    d3, d4 = side(p, q, a), side(p, q, b)
    return ((d1 > 0) != (d2 > 0)) and ((d3 > 0) != (d4 > 0))


class LayoutError(AssertionError):
    """A refusal a BIGGER or differently numbered drawing can cure.

    v6 stage 1b r2. figkit_plus.plane climbs the author's rule-5 ladder (every
    2 squares, then bigger squares within max_width) when a refusal is about
    where things SIT; it used to decide that by looking for a phrase in the
    prose, so every refusal svgcheck raised off the finished file stopped the
    ladder at rung 0 -- a triangle refused at size=12 for a number 0.43 of a
    spacing off its tick rendered perfectly at size=15, and the author was
    told the number was the problem. The class is the flag now; the wording
    is free to change."""


# which sweep a message came from, and whether a larger figure could cure it
_LAYOUT_KINDS = ("struck", "font", "ticks", "arrows", "dots", "owners",
                 "marker", "merges", "lost", "slot", "arcs")


def _letter_near_spot_free(M, own, T):
    """v6.2 Q1 (doctrine 4): is there anywhere within reading distance of this
    point that the letter could have gone?

    The reading clause is the origin's, and the origin is the one place where
    the four near spots can ALL be taken: the axis '0' itself, the x-number
    row, the y-number column and the data. The gallery's own q15 (a circle on
    the origin with two chords through it) is such a figure -- no width, no
    size and no hand offset brings 'O' inside 1.4 em, so refusing it would
    name no fix that renders, which is the escape doctrine 4 forbids. So
    problems() refuses the reading distance only where a near spot IS free:
    there the ladder's bigger squares or wider figure really do cure it.

    Read off the finished file: the ring of boxes a letter of this size could
    occupy, against the data strokes, the other texts and the two number
    bands of the axes."""
    axes = _axes(M)
    w = (T.box[2] - T.box[0]) / 2.0
    h = (T.box[3] - T.box[1]) / 2.0
    segs = _data_segs(M, axes)
    others = [q.box for q in M.texts if q is not T and q.box and q.text.strip()]
    rows = []
    for i, labs in _axis_labels(M, axes).items():
        j = 1 if axes[i]["orient"] == "h" else 0
        ys = [l[0].centre()[j] for l in labs]
        if ys:
            rows.append((j, sum(ys) / float(len(ys))))
    for k in range(24):
        th = math.pi * k / 12.0
        for f in (0.75, 1.0, 1.25):
            r = f * LETTER_NEAR_EM * T.size
            c = (own[0] + r * math.cos(th), own[1] + r * math.sin(th))
            box = (c[0] - w, c[1] - h, c[0] + w, c[1] + h)
            if math.hypot(c[0] - own[0], c[1] - own[1]) < own[2] + 0.5 * T.size:
                continue                      # on its own dot
            if any(_box_gap(box, p, q) <= 0.5 for p, q in segs):
                continue
            if any(box[0] < b[2] and b[0] < box[2] and
                   box[1] < b[3] and b[1] < box[3] for b in others):
                continue
            # the axis LINE itself, and the band each axis keeps its row of
            # numbers in (where that row actually prints, not a guess)
            if any(abs(c[1 if ax["orient"] == "h" else 0] - ax["at"])
                   < 0.8 * T.size for ax in axes):
                continue
            if any(abs(c[j] - row) < 1.0 * T.size for j, row in rows):
                continue
            return True
    return False


def problems(svg, min_pt=MIN_PT, ticks=True, arrows=True, dots=True,
             owners=None, dot_values=None, minus=True, irregular=False,
             marks=True, marker=True, merges=True, lost=True, tagged=False,
             slots=True):
    """Every sweep, as a list of strings. An HTML fragment holding several
    <svg> blocks (a figkit_plus.row) is checked block by block.

    `ticks`: True runs tick_alignment in full; "values" only its wrong-tick
    vote (distance=False); False skips it. `irregular` is passed on to it.
    v6 C3: `marks` runs mark_geometry (True; "angles" skips the equal-length
    reading of equality ticks, for a projection; False skips it), `marker`
    runs markers, `merges` runs reading_merge. v6 stage 1b: `lost` runs
    lost_ink -- a data stroke printed in pieces with a number in the hole.

    `tagged=True` returns (sweep, message) pairs instead of messages, so a
    caller can tell a LAYOUT refusal (where things sit -- curable by a bigger
    figure) from a refusal about the data itself (a right-angle mark on a 53
    degree corner, Hebrew in the figure)."""
    if not isinstance(svg, Model):
        bl = blocks(svg)
        if len(bl) > 1:
            out = []
            for b in bl:
                out += problems(b, min_pt, ticks, arrows, dots, None,
                                dot_values, minus, irregular, marks, marker,
                                merges, lost, True, slots)
            if owners:          # one owner list for the row: each label is
                out += [("owners", m) for m in       # judged where it is
                        label_ownership(svg, owners)]
            return out if tagged else [m for _, m in out]
    M = _M(svg)
    # P3 leftovers r1 (critique-line-trips-the-sweep-it-should-pass): a
    # numberline that DECLARES its wrong scale (student_drawing= /
    # wrong_scale=, asks=['find_error']) renders -- the error is the item --
    # but a sweep run on the finished string then reported that error as a
    # defect, and the skill tells builders to sweep every figure. A builder
    # under deadline "fixes" it by removing the wrong number, which removes
    # the item. The declaration reaches the sweep now.
    if getattr(M, "critique", False):
        irregular = True
        if ticks is True:
            ticks = "values"
    out = []
    for t in rtl_text(M):
        out.append(("rtl",
                    "label %r is Hebrew inside <svg><text> — it prints reversed "
                    "(G49); keep Latin letters, digits and signs in the figure "
                    "and put the Hebrew in the HTML beside it" % t))
    for t in struck(M):
        out.append(("struck", "struck label %r: ink runs through it" % t))
    if minus:
        for t in ascii_minus(M):
            out.append(("minus",
                        "label %r uses ASCII '-' (or a dash) before a digit; "
                        "print U+2212" % t))
    if min_pt:
        for t, run, pt in font_floor(M, min_pt):
            out.append(("font", "text %r: run %r prints at %.2fpt, under %.1fpt"
                        % (t, run, pt, min_pt)))
    if ticks:
        out += [("ticks", m) for m in
                tick_alignment(M, distance=(ticks != "values"),
                               irregular=irregular)]
    if arrows:
        out += [("arrows", m) for m in arrowhead_clearance(M)]
    if dots:
        out += [("dots", m) for m in dot_on_other_tick(M, dot_values)]
    if owners:
        out += [("owners", m) for m in label_ownership(M, owners)]
    if marks:
        # v6.4: a figure that declares a projection has its 2D angle and
        # length readings delegated to the 3D reader (see mark_geometry)
        out += [("marks", m) for m in
                mark_geometry(M, lengths=(marks != "angles"),
                              projected=getattr(M, "projected", False))]
        # v6.2 Q1: the two ARC sweeps, in the normal path. Both are layout
        # refusals -- a wider figure is fewer figure units per printed pt,
        # so plane()'s ladder really does cure them.
        # v6.2 Q1 r1 (L3-03): tagged "arcs", a LAYOUT kind. They were tagged
        # "marks" -- which is not a layout kind, because a right-angle mark on
        # a 53 degree corner is no size's fault -- so assert_clean raised a
        # plain AssertionError, figkit._layout_refusal called it incurable and
        # plane()'s ladder never climbed, on the one family of refusals whose
        # own message says a bigger drawing cures it. It does: a wider figure
        # is fewer figure units per printed pt.
        out += [("arcs", m) for m in arcs_join(M)]
        out += [("arcs", m) for m in arc_crossings(M)]
        # ... but an EQUAL-ANGLES claim is not a layout fault: no width cures
        # one stroke over 30 degrees and one over 60. It stays "marks".
        out += [("marks", m) for m in equal_arc_angles(M)]
        # v6.3 (describe/generate.violate): a "find the mistake" figure
        # DECLARES that one of its marks contradicts the drawing --
        # `<!--critique:find_error:marks-->`. The mark-vs-geometry messages
        # are then the ITEM, not a defect, and are not reported. This does
        # not weaken the rule, it turns it round: a figure that declares an
        # error and does not have one is refused, because a correct drawing
        # beside "find the error" gives the answer away (the giveaway rule,
        # L7 -- the same doctrine numberline.critique_guard enforces at the
        # question level). Every other sweep runs on it unchanged.
        _kinds = str(getattr(M, "critique_kind", "")).split(":")
        if "marks" in _kinds:
            # v6.3 r1 (S2-4-critique-seen-bypass): the declaration used to
            # drop EVERY mark message and ":seen" used to waive the giveaway
            # requirement outright, so `<!--critique:find_error:marks:seen-->`
            # pasted onto a correct figure silenced right-angle marks on
            # non-right angles, unequal ticks, non-parallel chevrons and
            # angle-text-vs-arc, and passed. A declaration is now BOUNDED and
            # COUNTED: it says how many wrong marks the item carries (":n=K",
            # default 1), figkit says how many its own check already caught
            # (":seen=J", a number -- a bare ":seen" counts as none), and at
            # most K - J messages are taken as the item. Anything beyond that
            # is a second, unintended wrong mark and is reported as ever.
            n_dec, seen = 1, 0
            for _k in _kinds:
                if _k.startswith("n="):
                    try:
                        n_dec = int(_k[2:])
                    except ValueError:
                        n_dec = 1
                elif _k.startswith("seen="):
                    try:
                        seen = int(_k[5:])
                    except ValueError:
                        seen = 0
            bad_dec = []
            if not 1 <= n_dec <= 3:
                bad_dec.append((
                    "marks",
                    "this figure declares %d deliberate wrong marks "
                    "(<!--critique:...:n=%d-->) -- a find-the-error item "
                    "carries 1 to 3 of them, or the reader cannot say which "
                    "one is the mistake" % (n_dec, n_dec)))
                n_dec = max(1, min(3, n_dec))
            if seen > n_dec:
                bad_dec.append((
                    "marks",
                    "this figure declares %d deliberate wrong mark(s) but "
                    "reports %d already found (:n=%d:seen=%d) -- the counts "
                    "have to agree" % (n_dec, seen, n_dec, seen)))
                seen = 0
            wrong = [pair for pair in out if pair[0] == "marks"]
            allow = max(0, n_dec - seen)
            item, extra = wrong[:allow], wrong[allow:]
            out = [pair for pair in out if pair[0] != "marks"] + extra + bad_dec
            if not item and seen <= 0:
                out.append((
                    "marks",
                    "this figure declares a deliberate error in its marks "
                    "(<!--critique:find_error:marks-->) but every mark on it "
                    "agrees with the drawing -- a correct figure beside a "
                    "find-the-error item gives the answer away (the giveaway "
                    "rule). Draw the error (generate.violate), or drop the "
                    "declaration"))
    if marker:
        out += [("marker", m) for m in markers(M)]
        out += [("marker", m) for m in marker_clearance(M)]
        out += [("marker", m) for m in number_owns_its_tick(M)]
        # v6.2 Q1 (L1-P3r3-02): the ORIGIN's '0' by rule 4 taken literally,
        # in the normal path. It was a public sweep problems() never ran and
        # a builder switch shipped off, so seven of the 206 rebuilt pilot
        # figures printed a '0' nearer another tick than the crossing with
        # every gate silent. A layout refusal: plane()'s ladder cures it.
        # v6.2 Q1 (doctrine 4): only where a better corner exists -- see
        # _zero_has_a_free_corner. The both-diagonals plane keeps rendering.
        # v6.2 Q1 r1 (zero-owner-test-vacuous / L3-05): only what the LOOSE
        # sweep has not already said. tick_alignment runs _zero_owner without
        # strict=, and where both fire the two produce the SAME sentence: the
        # author read the refusal twice, and the pass+fail test written for
        # this wiring passed with the wiring deleted, because its fixture was
        # already named by the loose sweep. What the strict call adds is the
        # '0' pushed ALONG an axis (ZERO_SLIDE, not ZERO_RATIO), and that is
        # what it now contributes.
        if _zero_has_a_free_corner(M):
            said = set(m for k, m in out if k == "ticks")
            out += [("marker", m) for m in zero_owner_strict(M)
                    if m not in said]
    if merges:
        out += [("merges", m) for m in reading_merge(M)]
    if lost:
        out += [("lost", m) for m in lost_ink(M)]
    # stage review: a NUMBER printed on a plane is a claim about the drawing
    out += [("values", m) for m in value_labels(M)]
    if slots:
        out += [("slot", m) for m in letter_in_slot(M)]
        # P3 leftovers r2: the READING-distance clause is not a refusal --
        # a point whose own square is full (a triangle's vertex on the
        # origin) has no nearer spot at any width, so problems() would name
        # no fix that works. letter_side(svg) reports it for an audit, and
        # figkit's ring search prefers a near spot in its first pass.
        # v6.2 Q1 (L1-P3r3-03): reading=True in the NORMAL path. The clause
        # was detection-only, and 27 of the 206 rebuilt pilot figures printed
        # the origin's 'O' far enough from its dot that the axis '0' was the
        # nearest text to it -- the point read as named by the number and the
        # letter as naming nothing, unrefused and unreported. It is a layout
        # refusal (LayoutError), so plane()'s rule-5 ladder climbs: bigger
        # squares and a wider figure are what make room beside the origin.
        # v6.2 Q1b: it stays a LAYOUT refusal, and now it bites. The
        # escape it used to have was not the ladder but the PAIRING: a
        # letter far enough from the origin was read as the nearest OTHER
        # point's letter, so the biggest rungs looked clean and the ladder
        # settled on one of them. With 'O' pinned to the axes' crossing
        # (see letter_side) no rung can hide it, and the climb does real
        # work -- the pilot's 14b came down from 1.74 em to 1.48. Where no
        # rung cures it the author reads the refusal, and origin=False is
        # the first fix it names.
        out += [("slot", m) for m in letter_side(M, reading=True,
                                                  curable=True)]
        out += [("merges", m) for m in number_boxes(M)]
    return out if tagged else [m for _, m in out]


_FIX = ("Fix it in the drawing, never by deleting information: re-place or "
        "halo the label, move the number aside (v6 stage 1b: a stroke is "
        "never cut behind one), enlarge the figure or the "
        "font, pin tick numbers to their ticks, shorten an arrow so its tip "
        "stops before the next shaft or dot, or move a dot exactly onto its "
        "value.")


def fix_text(kinds=None):
    """The generic fix tail, with only the clauses that can apply (stage-1
    fix r1): an arrow's clause when an arrow sweep refused, a dot's when a dot
    sweep did. A zero-owner refusal on a figure with neither was told to
    'shorten an arrow' and 'move a dot exactly onto its value'."""
    if kinds is None:
        return _FIX
    t = _FIX
    if "arrows" not in kinds:
        t = t.replace(", shorten an arrow so its tip stops before the next "
                      "shaft or dot", "")
    if "dots" not in kinds:
        t = t.replace(", or move a dot exactly onto its value", "")
        t = t.replace(" or move a dot exactly onto its value", "")
    if "arrows" not in kinds and "dots" not in kinds:
        t = t.replace(", pin tick numbers to their ticks.",
                      ", or pin tick numbers to their ticks.")
    return t


def assert_clean(svg, where="figure", **kw):
    kw.pop("tagged", None)
    bad = problems(svg, tagged=True, **kw)
    if bad:
        msgs = [m for _, m in bad]
        # a refusal every message of which is about WHERE something sits is a
        # LayoutError: plane()'s enlarge ladder may still cure it (rule 5)
        kinds = set(k for k, _ in bad)
        err = LayoutError if kinds and kinds <= set(_LAYOUT_KINDS) \
            else AssertionError
        raise err("svgcheck: %s — %s. %s"
                  % (where, "; ".join(msgs[:6]) +
                     (" (+%d more)" % (len(msgs) - 6)
                      if len(msgs) > 6 else ""), fix_text(kinds)))
    return svg


# ------------------------------------------------------------- house look ---
# P1 (the author, 2026-09-17, comparing v6.0 with Typst/LaTeX): a coordinate
# plane prints at ONE house look whatever its width. This sweep reads the
# FINISHED SVG only (doctrine 3) and measures everything in printed pt
# (size x display / viewBox x 0.75, doctrine 6). figkit_plus.HOUSE holds the
# sizes the builder aims at; the bands below are what the page must show.
HOUSE_BANDS = dict(
    number_pt=(7.6, 8.4),      # axis numbers
    letter_pt=(8.8, 10.4),     # italic letters (x, y, point and curve names)
    main_pt=(0.85, 1.15),      # data strokes
    axis_pt=(0.65, 0.95),      # the axes
    tick_len_pt=(3.0, 5.5),    # a tick mark end to end -- longer reads as '+'
    tick_w_pt=(0.4, 0.8),      # a tick mark's stroke
    dot_pt=(1.8, 2.25),        # a plotted point's radius
    open_pt=(2.3, 2.7),        # an open marker's radius
    head_pt=(3.5, 7.0),        # an axis arrowhead, tip to base
    dashed_pt=(0.6, 1.0),      # P1 r1: a dashed guide, diagonal, image
    head_clear_pt=1.0,         # P1 r1: axis between the last tick and the head
)
GRID_OFF_TAG = "<!--grid:off-->"   # P1 r1: plane(grid=False) says so


def _lum(col):
    h = col.strip().lower().lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    try:
        return min(int(h[i:i + 2], 16) for i in (0, 2, 4)) / 255.0
    except ValueError:
        return None


def house_look(svg, arrows=True, number_pt=None, grid_on=None):
    """Problems with a coordinate plane's printed look, [] when it has the
    house look: numbers at ~8pt (or `number_pt`), letters ~9.5pt, data
    strokes ~1pt, axes ~0.8pt, a grid in GRID_GREY inside GRID_BAND at
    GRID_PT, short thin tick marks, 2pt dots, 2.4pt white open markers, and
    (arrows=True) a filled arrowhead at the positive end of each axis with
    its letter beside it."""
    out = []
    s = _FAM_TAG_RE_H.sub("", strip_copies(svg))
    w = re.search(r'<svg[^>]*\bwidth="([\d.]+)"', s)
    vb = re.search(r'viewBox="[-\d.]+ [-\d.]+ ([\d.]+) ([\d.]+)"', s)
    if not (w and vb):
        return ["house look: not an SVG with width and viewBox"]
    k = float(w.group(1)) / float(vb.group(1)) * PX_TO_PT
    B = HOUSE_BANDS
    bad = lambda v, band: not (band[0] - 1e-9 <= v <= band[1] + 1e-9)
    attr = lambda tag, a: (re.search(r'\b%s="([^"]*)"' % a, tag) or
                           [None, None])[1]
    # -- text
    texts = []
    for m in re.finditer(r'<text\b([^>]*)>(.*?)</text>', s, re.S):
        t = re.sub(r"<[^>]+>", "", m.group(2))
        texts.append((float(attr(m.group(1), "x")), float(attr(m.group(1), "y")),
                      float(attr(m.group(1), "font-size")),
                      'font-style="italic"' in m.group(1), html.unescape(t)))
    nb = B["number_pt"] if number_pt is None else (number_pt - 0.4,
                                                   number_pt + 0.4)
    nums = [t for t in texts if re.fullmatch(r"[−\-]?\d+(?:[.,]\d+)?", t[4])]
    for t in nums:
        if bad(t[2] * k, nb):
            out.append("axis number %r prints at %.2fpt, outside %.1f-%.1fpt"
                       % (t[4], t[2] * k, nb[0], nb[1]))
    lb = B["letter_pt"] if number_pt is None else (
        number_pt * 9.5 / 8 - 0.7, number_pt * 9.5 / 8 + 0.9)
    for t in texts:
        # P1 r1: every text that is not a number is a letter -- the italic
        # axis letters and curve names AND the upright point names (A, B),
        # whose size went unread
        if t in nums:
            continue
        if bad(t[2] * k, lb):
            out.append("%s %r prints at %.2fpt, outside %.1f-%.1fpt"
                       % ("letter" if t[3] else "point name", t[4], t[2] * k,
                          lb[0], lb[1]))
    # -- strokes
    lines = []
    for m in re.finditer(r"<line\b([^>]*)/?>", s):
        a = m.group(1)
        p = (float(attr(a, "x1")), float(attr(a, "y1")))
        q = (float(attr(a, "x2")), float(attr(a, "y2")))
        lines.append((p, q, attr(a, "stroke") or "", float(attr(a, "stroke-width") or 1),
                      attr(a, "stroke-dasharray")))
    grid = [l for l in lines if l[2].lower() == GRID_GREY]
    white = ("#fff", "#ffffff", "white")
    # P1 r1: any grey that is not white is a grid candidate -- #f8f8f8 (lum
    # 0.97) was passed as white, though it vanishes in print
    light = [l for l in lines if l[2] and not _dark(l[2]) and l[2].lower() != GRID_GREY
             and l[2].lower() not in white]
    for l in light[:1]:
        out.append("a light grey line %s is not the house grid grey %s (a grid "
                   "that may vanish in print)" % (l[2], GRID_GREY))
    # P1 r1: a grid drawn too DARK was read as data ('data line prints
    # 0.35pt'), sending the author to the stroke widths. A family of >= 4
    # thin axis-parallel lines in one grey that is not the house grey is a grid.
    fam_ = {}
    for l in lines:
        c = l[2].lower()
        if (_dark(c) and c not in ("#111", "#111111", "#000", "#000000", "black")
                and (abs(l[0][0] - l[1][0]) < 1e-3 or abs(l[0][1] - l[1][1]) < 1e-3)
                and not l[4] and l[3] * k < 0.6):
            fam_.setdefault((c, round(l[3], 3)), []).append(l)
    dark_grid = set()
    for (c, _w), ls in fam_.items():
        if len(ls) >= 4:
            out.append("the grid is drawn in %s, darker than the house grid grey "
                       "%s (luminance %.2f, outside %.2f-%.2f) -- it prints as "
                       "data" % (c, GRID_GREY, _lum(c) or 0, GRID_BAND[0],
                                 GRID_BAND[1]))
            dark_grid.update(id(l) for l in ls)
            break
    for (c, _w), ls in fam_.items():
        if len(ls) >= 4:
            dark_grid.update(id(l) for l in ls)
    if (grid_on if grid_on is not None else GRID_OFF_TAG not in str(svg)) \
            and not grid and not light and not dark_grid:
        out.append("no grid: a coordinate plane prints its grid in %s "
                   "(plane(grid=False) tags a deliberate one %s)"
                   % (GRID_GREY, GRID_OFF_TAG))
    for l in grid[:1]:
        L = _lum(l[2])
        if L is None or bad(L, GRID_BAND):
            out.append("grid luminance %.2f outside %.2f-%.2f" % (L, GRID_BAND[0],
                                                                GRID_BAND[1]))
    for l in grid:
        if bad(l[3] * k, GRID_PT):
            out.append("grid line prints %.2fpt wide, outside %.2f-%.2fpt"
                       % (l[3] * k, GRID_PT[0], GRID_PT[1]))
            break
    dark = [l for l in lines if _dark(l[2]) and id(l) not in dark_grid]
    ax_al = lambda l: abs(l[0][0] - l[1][0]) < 1e-3 or abs(l[0][1] - l[1][1]) < 1e-3
    # a tick candidate: up to 14pt (a '+'-cross tick of v6.0 is still a tick
    # to judge, not a data line), centred on the axis (below)
    short = [l for l in dark if ax_al(l) and _d(l[0], l[1]) * k <= 14.0
             and not l[4]]
    # the axes: the longest horizontal and vertical dark lines on which the
    # short strokes stand, centred
    xaxis = yaxis = None
    for l in dark:
        if not ax_al(l) or l[4]:
            continue
        horiz = abs(l[0][1] - l[1][1]) < 1e-3
        on = [t for t in short if (abs(t[0][0] - t[1][0]) < 1e-3 if horiz else
                                   abs(t[0][1] - t[1][1]) < 1e-3) and
              abs(((t[0][1] + t[1][1]) / 2 if horiz else (t[0][0] + t[1][0]) / 2)
                  - l[0][1 if horiz else 0]) < 0.05]
        if len(on) < 2:
            continue
        cur = xaxis if horiz else yaxis
        if cur is None or _d(l[0], l[1]) > _d(cur[0][0], cur[0][1]):
            if horiz:
                xaxis = (l, on)
            else:
                yaxis = (l, on)
    if xaxis is None and yaxis is None:
        out.append("no axis with tick marks found")
    ticks = []
    for ax in (xaxis, yaxis):
        if ax is None:
            continue
        l, on = ax
        if bad(l[3] * k, B["axis_pt"]):
            out.append("axis prints %.2fpt wide, outside %.2f-%.2fpt"
                       % (l[3] * k, B["axis_pt"][0], B["axis_pt"][1]))
        ticks += on
    for t in ticks:
        if bad(_d(t[0], t[1]) * k, B["tick_len_pt"]):
            out.append("tick mark prints %.2fpt long, outside %.1f-%.1fpt -- it "
                       "reads as a cross" % (_d(t[0], t[1]) * k,
                                             B["tick_len_pt"][0], B["tick_len_pt"][1]))
            break
    for t in ticks:
        if bad(t[3] * k, B["tick_w_pt"]):
            out.append("tick mark prints %.2fpt wide, outside %.1f-%.1fpt"
                       % (t[3] * k, B["tick_w_pt"][0], B["tick_w_pt"][1]))
            break
    axes_l = set(id(a[0]) for a in (xaxis, yaxis) if a)
    tick_ids = set(id(t) for t in ticks)
    for l in dark:
        # P1 r1: a dashed stroke has its own band (HOUSE dashed_pt 0.8); it
        # was skipped, so a 2pt dashed diagonal passed
        if l[4] and _d(l[0], l[1]) * k >= 8.0 and bad(l[3] * k, B["dashed_pt"]):
            out.append("dashed line prints %.2fpt wide, outside %.2f-%.2fpt"
                       % (l[3] * k, B["dashed_pt"][0], B["dashed_pt"][1]))
            break
    for l in dark:
        if id(l) in axes_l or id(l) in tick_ids or l[4]:
            continue
        if _d(l[0], l[1]) * k < 8.0:
            continue                      # a mark, a barb
        if bad(l[3] * k, B["main_pt"]):
            out.append("data line prints %.2fpt wide, outside %.2f-%.2fpt"
                       % (l[3] * k, B["main_pt"][0], B["main_pt"][1]))
            break
    for m in re.finditer(r"<(polygon|path)\b([^>]*)/?>", s):
        a = m.group(2)
        st, fl = attr(a, "stroke"), (attr(a, "fill") or "none")
        if not _dark(st):
            continue
        if fl.lower() not in ("none", "") :
            continue                      # arrowheads, open markers
        if attr(a, "stroke-dasharray"):
            if bad(float(attr(a, "stroke-width") or 1) * k, B["dashed_pt"]):
                out.append("dashed %s prints %.2fpt wide, outside %.2f-%.2fpt"
                           % (m.group(1), float(attr(a, "stroke-width") or 1) * k,
                              B["dashed_pt"][0], B["dashed_pt"][1]))
                break
            continue
        if bad(float(attr(a, "stroke-width") or 1) * k, B["main_pt"]):
            out.append("data %s prints %.2fpt wide, outside %.2f-%.2fpt"
                       % (m.group(1), float(attr(a, "stroke-width") or 1) * k,
                          B["main_pt"][0], B["main_pt"][1]))
            break
    # -- dots and markers
    for m in re.finditer(r"<circle\b([^>]*)/?>", s):
        a = m.group(1)
        r = float(attr(a, "r")) * k
        fl, st = (attr(a, "fill") or "").lower(), attr(a, "stroke")
        if _dark(fl):
            # P1 r1: a filled dark disc is a dot whatever its size -- one
            # over MARKER_MAX_PT (a 9pt blot) was skipped
            if bad(r, B["dot_pt"]):
                out.append("dot prints r=%.2fpt, outside %.2f-%.2fpt"
                           % (r, B["dot_pt"][0], B["dot_pt"][1]))
        elif fl in ("#fff", "#ffffff", "white") and _dark(st) and r <= MARKER_MAX_PT:
            if bad(r, B["open_pt"]):
                out.append("open marker prints r=%.2fpt, outside %.2f-%.2fpt"
                           % (r, B["open_pt"][0], B["open_pt"][1]))
    # -- arrowheads and axis letters
    if arrows:
        heads = []
        for m in re.finditer(r"<path\b([^>]*)/?>", s):
            a = m.group(1)
            if not _dark(attr(a, "fill") or ""):
                continue
            nums_ = [float(v) for v in re.findall(r"-?\d+\.?\d*", attr(a, "d") or "")]
            heads.append(list(zip(nums_[0::2], nums_[1::2])))
        for name, ax, end in (("x", xaxis, "right"), ("y", yaxis, "top")):
            if ax is None:
                continue
            l = ax[0]
            tip = max((l[0], l[1]), key=lambda p: p[0]) if end == "right" \
                else min((l[0], l[1]), key=lambda p: p[1])
            hd = [h for h in heads if h and min(_d(tip, p) for p in h) * k < 1.0]
            if not hd:
                out.append("the %s-axis has no arrowhead at its positive end" % name)
                continue
            h = hd[0]
            ext = max(_d(p, q) for p in h for q in h) * k
            if bad(ext, B["head_pt"]):
                out.append("the %s-axis arrowhead is %.1fpt, outside %.1f-%.1fpt"
                           % (name, ext, B["head_pt"][0], B["head_pt"][1]))
            # P1 r1: the head stands clear of the last tick and past the
            # grid. 'The head never covers the last tick' rested on how the
            # builder draws; a head moved onto the tick at 4 passed.
            ax_pos = (lambda p: p[0]) if end == "right" else (lambda p: -p[1])
            back = min(ax_pos(p) for p in h)
            tk = [ax_pos(((t[0][0] + t[1][0]) / 2, (t[0][1] + t[1][1]) / 2))
                  for t in ax[1]]
            if tk and (back - max(tk)) * k < B["head_clear_pt"]:
                out.append("the %s-axis arrowhead covers its last tick (its base "
                           "is %.1fpt past the tick, under %.1fpt) -- the axis "
                           "runs on past the last number to its head"
                           % (name, (back - max(tk)) * k, B["head_clear_pt"]))
            gl = [ax_pos(g[0]) for g in grid if (abs(g[0][0] - g[1][0]) < 1e-3)
                  == (end == "right")]
            if gl and ax_pos(tip) < max(gl) - 1e-3:
                out.append("the %s-axis stops before the grid's edge (its tip "
                           "is %.1fpt inside the last grid line)"
                           % (name, (max(gl) - ax_pos(tip)) * k))
            lt = [t for t in texts if t[3] and t[4] == name]
            near = [t for t in lt if math.hypot(
                t[0] - tip[0], (t[1] - 0.33 * t[2]) - tip[1]) * k <= 14.0]
            if not near:
                out.append("the %s-axis letter is not beside its arrowhead "
                           "(within 14pt of the tip)" % name)
    return out


_FAM_TAG_RE_H = re.compile(r"<!--\s*fam:[^>]*?-->")


PLANE_TAG = "<!--coordinate-plane-->"   # P1 r2: every plane() figure says so


def is_coordinate_plane(svg):
    """P1 r1 (G78): True when the SVG draws a coordinate plane -- a
    horizontal and a vertical dark line, each carrying at least two short
    tick strokes centred on it. A number line has one axis.

    P1 r2: the two axes need not cross. A window that leaves out 0
    (xr=(1, 8), or (-10, -2) x (-6, -1)) draws each axis at its true 0,
    outside the grid, and G78 skipped the figure. A figure plane() tagged
    PLANE_TAG, or one carrying a house-fallback tag, is a plane however it
    is drawn -- an unnumbered sketch with ticks=False has no tick to read."""
    s = strip_copies(svg)
    if PLANE_TAG in s or "<!--house-fallback:" in s:
        return True
    L = []
    for m in re.finditer(r"<line\b([^>]*)/?>", s):
        a = m.group(1)
        g = lambda k: re.search(r'\b%s="([^"]*)"' % k, a)
        if not all(g(k) for k in ("x1", "y1", "x2", "y2")):
            continue
        st = g("stroke")
        if not _dark(st.group(1) if st else None) or "stroke-dasharray" in a:
            continue
        L.append(tuple(float(g(k).group(1)) for k in ("x1", "y1", "x2", "y2")))
    H = [l for l in L if abs(l[1] - l[3]) < 1e-3]
    V = [l for l in L if abs(l[0] - l[2]) < 1e-3]
    n = lambda l: math.hypot(l[2] - l[0], l[3] - l[1])

    def ticked(ax, horiz, others):
        at = ax[1] if horiz else ax[0]
        return sum(1 for t in others if n(t) < 0.25 * n(ax)
                   and abs((t[1] + t[3]) / 2 - at if horiz else
                           (t[0] + t[2]) / 2 - at) < 0.05) >= 2
    hs = [h for h in H if ticked(h, True, V)]
    vs = [v for v in V if ticked(v, False, H)]
    return bool(hs and vs)


def axis_heads(svg):
    """P1 r2 (G78): True when both axes of a plane end in a filled
    arrowhead at their positive end, False when either does not, None when
    no axes are found. The axes are the ticked horizontal / vertical dark
    lines, or -- on an unnumbered sketch -- the longest ones spanning half
    the drawing. Reads the finished SVG only."""
    s = strip_copies(svg)
    vb = re.search(r'viewBox="[-\d.]+ [-\d.]+ ([\d.]+) ([\d.]+)"', s)
    L = []
    for m in re.finditer(r"<line\b([^>]*)/?>", s):
        a = m.group(1)
        g = lambda k: re.search(r'\b%s="([^"]*)"' % k, a)
        if not all(g(k) for k in ("x1", "y1", "x2", "y2")):
            continue
        st = g("stroke")
        if not _dark(st.group(1) if st else None) or "stroke-dasharray" in a:
            continue
        L.append(tuple(float(g(k).group(1)) for k in ("x1", "y1", "x2", "y2")))
    n = lambda l: math.hypot(l[2] - l[0], l[3] - l[1])
    H = [l for l in L if abs(l[1] - l[3]) < 1e-3]
    V = [l for l in L if abs(l[0] - l[2]) < 1e-3]

    def pick(lines, others, horiz, span):
        tk = [l for l in lines if sum(
            1 for t in others if n(t) < 0.25 * n(l) and abs(
                ((t[1] + t[3]) / 2 - l[1]) if horiz else
                ((t[0] + t[2]) / 2 - l[0])) < 0.05) >= 2]
        pool = tk or [l for l in lines if span and n(l) >= 0.5 * span]
        return max(pool, key=n) if pool else None
    hx = pick(H, V, True, float(vb.group(1)) if vb else 0)
    vy = pick(V, H, False, float(vb.group(2)) if vb else 0)
    if hx is None or vy is None:
        return None
    heads = []
    for m in re.finditer(r"<path\b([^>]*)/?>", s):
        a = m.group(1)
        fl = re.search(r'\bfill="([^"]*)"', a)
        d = re.search(r'\bd="([^"]*)"', a)
        if not (fl and _dark(fl.group(1)) and d):
            continue
        v = [float(x) for x in re.findall(r"-?\d+\.?\d*", d.group(1))]
        pts = list(zip(v[0::2], v[1::2]))
        # A native closed triangular head has the same geometry as its
        # polygon form: the shaft meets the base midpoint. Require the
        # actual three-vertex closed path, not merely a data-arrow label.
        if (re.search(r'\sdata-arrow="[xy]"', " " + a)
                and re.fullmatch(r"[MLZmlz\s,0-9.\-+]+", d.group(1))
                and d.group(1).strip().upper().endswith("Z") and len(pts) == 3):
            pts += [((p[0] + q[0]) / 2, (p[1] + q[1]) / 2)
                    for p, q in zip(pts, pts[1:] + pts[:1])]
        heads.append(pts)
    # v6.12 fix_r1 (t08_b D1): the wspec coordinate-plane engine draws its
    # heads as filled <polygon data-arrow=...> (dialect wspec-coord-svg/1);
    # the axis line ends at the head's BASE midpoint, not at a vertex
    for m in re.finditer(r"<polygon\b([^>]*)/?>", s):
        a = m.group(1)
        fl = re.search(r'\bfill="([^"]*)"', a)
        pp = re.search(r'\bpoints="([^"]*)"', a)
        # v6.13 integ: the attribute itself (data-arrow="x" / "y"), not a
        # substring of another attribute's value
        if not (fl and _dark(fl.group(1)) and pp and
                re.search(r'\sdata-arrow="[xy]"', " " + a)):
            continue
        v = [float(x) for x in re.findall(r"-?\d+\.?\d*", pp.group(1))]
        pts = list(zip(v[0::2], v[1::2]))
        pts += [((p[0] + q[0]) / 2, (p[1] + q[1]) / 2)
                for p, q in zip(pts, pts[1:] + pts[:1])]
        heads.append(pts)
    tipx = max(((hx[0], hx[1]), (hx[2], hx[3])), key=lambda p: p[0])
    tipy = min(((vy[0], vy[1]), (vy[2], vy[3])), key=lambda p: p[1])
    w = re.search(r'<svg[^>]*\bwidth="([\d.]+)"', s)
    k = float(w.group(1)) / float(vb.group(1)) * PX_TO_PT if (w and vb) else 1.0
    near = lambda tip: any(h and min(math.hypot(tip[0] - p[0], tip[1] - p[1])
                                     for p in h) * k < 1.0 for h in heads)
    return near(tipx) and near(tipy)
