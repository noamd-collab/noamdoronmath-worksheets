# -*- coding: utf-8 -*-
"""nline_cases.py -- v6.12 (family B): the number-line specs the
selfcheck_v612_nline.py tests render and check. Each builder returns
(spec, figure id, display settings, harness positions {place: value}).
Every spec validates clean (wspec.schema.validate)."""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

from wspec import author as W            # noqa: E402

ST = W.stated()


def tgt(item, rel, args, ans, **kw):
    t = W.fact(item, rel, args, "target", ST)
    return t, W.answer(t, ans, **kw)


def frame(lo, hi, step, every=None, at=None, form=None):
    fr = {"family": "number_line", "axis": "axis:n", "min": lo, "max": hi,
          "step": step}
    if every is not None:
        fr["label_every"] = every
    else:
        fr["label_at"] = list(at)
    if form:
        fr["form"] = form
    return fr


def item(qid, pos, tt, targets, text, ma=False):
    return {"id": qid + "abcdef"[pos], "label": "אבגדהו"[pos],
            "task_type": tt, "measurement_allowed": ma,
            "targets": sorted(t["id"] for t in targets), "text": text}


def fig(fid, scope, ents, draws, fr):
    return {"id": fid, "scope": scope, "figure_accuracy": "accurate",
            "entities": list(ents), "draws": [d["id"] for d in draws],
            "frame": fr}


def L1_integers():
    """-5..5 by 1, labels at -5 and 5 only; Q = 2 (given), -4 marked; a:
    which number is P (-3); b: interval value; c: plot -1/2 and 3 1/2; d: |P|
    as distance; e: the jump P -> Q; f: whole numbers between P and Q."""
    ents = [W.ent("axis", name="n")] + W.points("PQ") + [
        W.ent("number", value="-1/2", form="fraction"),
        W.ent("number", value="7/2", form="mixed"),
        W.ent("number", value=-4)]
    jump = W.ent("jump", **{"from": "P", "to": "Q"})
    ivl = W.ent("interval", lo="P", hi="Q", lo_in=False, hi_in=False)
    ents += [jump, ivl]
    q_is = W.fact("q1", "coordinate", ["Q", "axis:n"], "given", ST, value=2)
    mk = W.fact("q1", "mark", ["num:-4"], "context", W.ctx("number_mark"))
    ta, aa = tgt("q1a", "coordinate", ["P", "axis:n"], -3)
    tb, ab = tgt("q1b", "interval_value", ["axis:n"], 1)
    p1 = W.fact("q1c", "plot", ["num:-1/2", "axis:n"], "to_plot", ST)
    p2 = W.fact("q1c", "plot", ["num:7/2", "axis:n"], "to_plot", ST)
    td, ad = tgt("q1d", "abs_value", ["P"], 3)
    te, ae = tgt("q1e", "jump_value", [jump["id"]], 5)
    tf, af = tgt("q1f", "count_integers", [ivl["id"]], 4)
    facts = [q_is, mk, ta, aa, tb, ab, p1, W.answer(p1), p2, W.answer(p2),
             td, ad, te, ae, tf, af]
    g = fig("q1_head", "q1", ["axis:n", "P", "Q", "num:-4", jump["id"]],
            [mk], frame(-5, 5, 1, at=(-5, 5)))
    items = [
        item("q1", 0, "read_off", [ta], [W.T("nl_which_number", [ta])], True),
        item("q1", 1, "compute", [tb], [W.T("interval_value_line", [tb])]),
        item("q1", 2, "plot", [p1, p2], [W.T("plot_number_2", [p1, p2])],
             True),
        item("q1", 3, "compute", [td], [W.T("abs_distance_q", [td])]),
        item("q1", 4, "compute", [te], [W.T("jump_size_q", [te], [jump])]),
        item("q1", 5, "compute", [tf], [W.T("count_int_open", [tf], [ivl])]),
    ]
    q = {"id": "q1", "n": 1, "figure": "q1_head",
         "text": [W.T("nl_point_is", [q_is])], "items": items}
    return (W.spec("G7-T1/a", ents, [q], facts, [g]), "q1_head",
            {"figure": "q1_head", "layout": [{"p": "P", "at": "-3"}]},
            {"P": "-3"})


def L2_fractions():
    """0..2 by 1/4, every second tick printed as a stacked fraction; B = 1/4
    (given, printed under its dot); 3/4 marked (stacked caption); a: which
    number is A (5/4); b: plot 7/4."""
    ents = [W.ent("axis", name="n")] + W.points("AB") + [
        W.ent("number", value="3/4", form="fraction"),
        W.ent("number", value="7/4", form="fraction")]
    b_is = W.fact("q1", "coordinate", ["B", "axis:n"], "given", ST,
                  value="1/4")
    b_is["form"] = "fraction"
    mk = W.fact("q1", "mark", ["num:3/4"], "context", W.ctx("number_mark"))
    ta, aa = tgt("q1a", "coordinate", ["A", "axis:n"], "5/4")
    p1 = W.fact("q1b", "plot", ["num:7/4", "axis:n"], "to_plot", ST)
    facts = [b_is, mk, ta, aa, p1, W.answer(p1)]
    g = fig("q1_head", "q1", ["axis:n", "A", "B", "num:3/4"], [b_is, mk],
            frame(0, 2, "1/4", every=2, form="fraction"))
    items = [
        item("q1", 0, "read_off", [ta], [W.T("nl_which_number", [ta])], True),
        item("q1", 1, "plot", [p1], [W.T("plot_number_1", [p1])], True)]
    q = {"id": "q1", "n": 1, "figure": "q1_head",
         "text": [W.T("nl_point_is", [b_is])], "items": items}
    return (W.spec("G7-T1/b", ents, [q], facts, [g]), "q1_head",
            {"figure": "q1_head", "layout": [{"p": "A", "at": "5/4"}]},
            {"A": "5/4"})


def L3_mixed_negative():
    """-3..-1 by 1/4, every second tick printed as a mixed number
    (−2½); −9/4 marked (−2¼: sign, whole, stacked fraction); a: which
    number is K (−7/4)."""
    ents = [W.ent("axis", name="n")] + W.points("K") + [
        W.ent("number", value="-9/4", form="mixed")]
    mk = W.fact("q1", "mark", ["num:-9/4"], "context", W.ctx("number_mark"))
    ta, aa = tgt("q1a", "coordinate", ["K", "axis:n"], "-7/4")
    facts = [mk, ta, aa]
    g = fig("q1_head", "q1", ["axis:n", "K", "num:-9/4"], [mk],
            frame(-3, -1, "1/4", every=2, form="mixed"))
    items = [item("q1", 0, "read_off", [ta], [W.T("nl_which_number", [ta])],
                  True)]
    q = {"id": "q1", "n": 1, "figure": "q1_head", "text": [],
         "items": items}
    return (W.spec("G7-T1/c", ents, [q], facts, [g]), "q1_head",
            {"figure": "q1_head", "width": 320,
             "layout": [{"p": "K", "at": "-7/4"}]}, {"K": "-7/4"})


def L4_decimals():
    """−1..1 by 0.1, every fifth tick printed as a decimal; C = −0.3
    (given, printed); a: which number is D (0.7)."""
    ents = [W.ent("axis", name="n")] + W.points("CD")
    c_is = W.fact("q1", "coordinate", ["C", "axis:n"], "given", ST,
                  value="-0.3")
    c_is["form"] = "decimal"
    ta, aa = tgt("q1a", "coordinate", ["D", "axis:n"], "0.7")
    facts = [c_is, ta, aa]
    g = fig("q1_head", "q1", ["axis:n", "C", "D"], [c_is],
            frame(-1, 1, "1/10", every=5, form="decimal"))
    items = [item("q1", 0, "read_off", [ta], [W.T("nl_which_number", [ta])],
                  True)]
    q = {"id": "q1", "n": 1, "figure": "q1_head",
         "text": [W.T("nl_point_is", [c_is])], "items": items}
    return (W.spec("G7-T1/a", ents, [q], facts, [g]), "q1_head",
            {"figure": "q1_head", "layout": [{"p": "D", "at": "7/10"}]},
            {"D": "7/10"})


def L5_vertical():
    """An upright line −10..6 by 2 (a thermometer), every tick printed; T =
    −4 (given, printed); 3 marked; the jump T -> 3 of +7 (given, printed
    over its arc)."""
    ents = [W.ent("axis", name="n")] + W.points("T") + [
        W.ent("number", value=3)]
    jump = W.ent("jump", **{"from": "T", "to": "num:3"})
    ents.append(jump)
    t_is = W.fact("q1", "coordinate", ["T", "axis:n"], "given", ST, value=-4)
    mk = W.fact("q1", "mark", ["num:3"], "context", W.ctx("number_mark"))
    jv = W.fact("q1", "jump_value", [jump["id"]], "given", ST, value=7)
    ta, aa = tgt("q1a", "abs_value", ["T"], 4)
    facts = [t_is, mk, jv, ta, aa]
    g = fig("q1_head", "q1", ["axis:n", "T", "num:3", jump["id"]],
            [t_is, mk, jv], frame(-10, 6, 2, every=1))
    items = [item("q1", 0, "compute", [ta], [W.T("abs_value_q", [ta])])]
    q = {"id": "q1", "n": 1, "figure": "q1_head",
         "text": [W.T("nl_point_is", [t_is]),
                  W.T("jump_start_given", [jv], [jump])], "items": items}
    return (W.spec("G7-T1/a", ents, [q], facts, [g]), "q1_head",
            {"figure": "q1_head", "orientation": "vertical", "height": 260},
            {})


def L6_interval():
    """−5..5 by 1, every tick printed; A = −2, B = 3 (given); the interval
    [A, B) drawn (A filled, B hollow); the distance AB = 5 and |A| = 2 given
    and drawn as brackets; the axis letter x; a: |B|."""
    ents = [W.ent("axis", name="x")] + W.points("AB")
    ivl = W.ent("interval", lo="A", hi="B", lo_in=True, hi_in=False)
    ents.append(ivl)
    a_is = W.fact("q1", "coordinate", ["A", "axis:x"], "given", ST, value=-2)
    b_is = W.fact("q1", "coordinate", ["B", "axis:x"], "given", ST, value=3)
    dg = W.fact("q1", "distance", ["A", "B"], "given", ST, value=5)
    ag = W.fact("q1", "abs_value", ["A"], "given", ST, value=2)
    nm = W.fact("q1", "name", ["axis:x"], "context", W.ctx("axis_name"))
    ta, aa = tgt("q1a", "abs_value", ["B"], 3)
    facts = [a_is, b_is, dg, ag, nm, ta, aa]
    fr = frame(-5, 5, 1, every=1)
    fr["axis"] = "axis:x"
    g = fig("q1_head", "q1", ["axis:x", "A", "B", ivl["id"]], [dg, ag, nm],
            fr)
    items = [item("q1", 0, "compute", [ta], [W.T("abs_value_q", [ta])])]
    q = {"id": "q1", "n": 1, "figure": "q1_head",
         "text": [W.T("nl_point_is", [a_is]), W.T("nl_point_is", [b_is]),
                  W.T("distance_given", [dg]), W.T("abs_given", [ag])],
         "items": items}
    return (W.spec("G7-T1/a", ents, [q], facts, [g]), "q1_head",
            {"figure": "q1_head", "width": 300}, {})


def L7_negatives():
    """−8..−1 by 1, printed at −8, −6, −4, −2 (step 2); the jump between the
    marked numbers −7 and −2 (its size asked); a: the jump's size; b: the
    whole numbers from −7 to −2, both ends included."""
    ents = [W.ent("axis", name="n")] + [W.ent("number", value=-7),
                                         W.ent("number", value=-2)]
    jump = W.ent("jump", **{"from": "num:-7", "to": "num:-2"})
    ivl = W.ent("interval", lo="num:-7", hi="num:-2", lo_in=True,
                hi_in=True)
    ents += [jump, ivl]
    m1 = W.fact("q1", "mark", ["num:-7"], "context", W.ctx("number_mark"))
    m2 = W.fact("q1", "mark", ["num:-2"], "context", W.ctx("number_mark"))
    ta, aa = tgt("q1a", "jump_value", [jump["id"]], 5)
    tb, ab = tgt("q1b", "count_integers", [ivl["id"]], 6)
    facts = [m1, m2, ta, aa, tb, ab]
    g = fig("q1_head", "q1", ["axis:n", "num:-7", "num:-2", jump["id"]],
            [m1, m2], frame(-8, -1, 1, at=(-8, -6, -4, -2)))
    items = [item("q1", 0, "compute", [ta], [W.T("jump_size_q", [ta],
                                                  [jump])]),
             item("q1", 1, "compute", [tb], [W.T("count_int_closed", [tb],
                                                  [ivl])])]
    q = {"id": "q1", "n": 1, "figure": "q1_head", "text": [],
         "items": items}
    return (W.spec("G7-T1/a", ents, [q], facts, [g]), "q1_head",
            {"figure": "q1_head", "width": 260}, {})


def L8_dense():
    """−40..40 by 2 (40 intervals), every tick printed: the numbers need
    room -- the figure GROWS (never drops a number)."""
    ents = [W.ent("axis", name="n")] + W.points("R")
    ta, aa = tgt("q1a", "coordinate", ["R", "axis:n"], 14)
    g = fig("q1_head", "q1", ["axis:n", "R"], [], frame(-40, 40, 2,
                                                        every=1))
    items = [item("q1", 0, "read_off", [ta], [W.T("nl_which_number", [ta])],
                  True)]
    q = {"id": "q1", "n": 1, "figure": "q1_head", "text": [],
         "items": items}
    return (W.spec("G7-T1/a", ents, [q], [ta, aa], [g]), "q1_head",
            {"figure": "q1_head", "width": 500,
             "layout": [{"p": "R", "at": "14"}]}, {"R": "14"})


def L9_signed_fractions():
    """−1..1 by 1/4, every second tick printed as a stacked fraction (−½:
    the sign left of its bar); −1/4 marked; a: which number is M (−3/4)."""
    ents = [W.ent("axis", name="n")] + W.points("M") + [
        W.ent("number", value="-1/4", form="fraction")]
    mk = W.fact("q1", "mark", ["num:-1/4"], "context", W.ctx("number_mark"))
    ta, aa = tgt("q1a", "coordinate", ["M", "axis:n"], "-3/4")
    g = fig("q1_head", "q1", ["axis:n", "M", "num:-1/4"], [mk],
            frame(-1, 1, "1/4", every=2, form="fraction"))
    items = [item("q1", 0, "read_off", [ta], [W.T("nl_which_number", [ta])],
                  True)]
    q = {"id": "q1", "n": 1, "figure": "q1_head", "text": [],
         "items": items}
    return (W.spec("G7-T1/b", ents, [q], [mk, ta, aa], [g]), "q1_head",
            {"figure": "q1_head", "layout": [{"p": "M", "at": "-3/4"}]},
            {"M": "-3/4"})


LEGIT = [("L1 integers", L1_integers), ("L2 fractions", L2_fractions),
         ("L3 mixed negative", L3_mixed_negative),
         ("L4 decimals", L4_decimals), ("L5 vertical", L5_vertical),
         ("L6 interval + brackets", L6_interval),
         ("L7 negatives", L7_negatives), ("L8 dense grows", L8_dense),
         ("L9 signed fractions", L9_signed_fractions)]
