# -*- coding: utf-8 -*-
"""wspec -- deterministic worksheet spec, stage 1: schema, canonical form,
phrasing templates, public/private split, baseline diff. Stdlib only."""


def _register_family_reasons():
    """(v6.16 integrate) the reason tables of the two v6.16 families join
    the ONE closed table errors.REASONS: the graph family's GRAPH_* codes
    (wspec/graph/kinds.py REASONS) and the pie family's PIE_* codes
    (wspec/pie.py PIE_REASONS). Each family keeps its own table (its own
    Issue class asserts on it); a code of one family never shadows a house
    code (asserted)."""
    from . import errors as _E
    from .pie import PIE_REASONS as _PIE
    from .graph.kinds import REASONS as _GRAPH
    for table in (_GRAPH, _PIE):
        for code, why in table.items():
            assert _E.REASONS.get(code, why) == why, \
                "family reason %s shadows a house reason" % code
            _E.REASONS[code] = why


_register_family_reasons()
