"""Explicit ownership of head givens in an item's new figure (H-B3).

The question's public claims remain complete. Only the claims assigned to
one visual model are scoped here. A missing point in an applicable/local
claim remains an error in the ordinary independent V1 checker.
"""
from .errors import Issue, REASONS

FIELD = "inherit_givens"
CODE = "FIGURE_INHERIT_GIVENS_BAD"
REASONS.setdefault(CODE, "an item figure's inherited head givens are not "
                   "an explicit list of public given fact IDs of its question")


def validate(spec, ix, out):
    for fig in spec.get("figures") or []:
        _state, why = state_record(spec, fig)
        if why:
            out.append(Issue(STATE_CODE, str(fig.get("id")), why))
        if FIELD not in fig:
            continue
        fid, scope = fig.get("id"), fig.get("scope")
        qid = ix.scope_question.get(scope)
        refs = fig[FIELD]
        item = ix.items.get(scope) or {}
        if (scope not in ix.items or not qid or item.get("figure") != fid
                or not isinstance(refs, list)
                or any(not isinstance(x, str) for x in refs)
                or len(set(refs)) != len(refs)):
            out.append(Issue(CODE, str(fid),
                             "only an explicitly linked own item figure "
                             "may declare a unique list (including [])"))
            continue
        for ref in refs:
            fact = ix.facts.get(ref) or {}
            if (fact.get("item") != qid or fact.get("role") != "given"
                    or (fact.get("source") or {}).get("kind") != "stated"):
                out.append(Issue(CODE, str(fid),
                                 "%r is not a stated head given of %s" %
                                 (ref, qid)))


def public_faults(pub):
    facts = {f.get("id"): f for f in pub.get("facts") or []}
    owners = {i.get("id"): (q.get("id"), i)
              for q in pub.get("questions") or []
              for i in q.get("items") or []}
    out = []
    for fig in pub.get("figures") or []:
        _state, why = state_record(pub, fig)
        if why:
            out.append("%s: %s" % (fig.get("id"), why))
        if FIELD not in fig:
            continue
        refs = fig[FIELD]
        qid, item = owners.get(fig.get("scope"), (None, {}))
        if (not qid or item.get("figure") != fig.get("id")
                or not isinstance(refs, list)
                or any(not isinstance(x, str) for x in refs)
                or len(set(refs)) != len(refs)):
            out.append("%s: invalid explicit item inheritance" % fig.get("id"))
            continue
        for ref in refs:
            fact = facts.get(ref) or {}
            if (fact.get("item") != qid or fact.get("role") != "given"
                    or (fact.get("source") or {}).get("kind") != "stated"):
                out.append("%s: inherited fact %r is not public head data" %
                           (fig.get("id"), ref))
    return out


def served_rows(entry, figures, q_items):
    """An own item figure serves that item, not every figure of its head."""
    qid = entry["question"]
    if entry.get("item"):
        return [qid, entry["item"]]
    own = {f.get("item") for f in figures
           if f.get("question") == qid and f.get("item") and not f.get("aux")}
    return [qid] + [i for i in q_items.get(qid, []) if i not in own]


def visual_claims(level, entry, rid, claims, claim_of, canonical):
    """Select declared inherited givens; never filter by missing points.

    Local claims are returned intact, even when malformed. The explicit
    list names the source facts, not a list of errors to suppress.
    """
    if level is None or not entry.get("item") or rid != entry["question"]:
        return claims
    fig = level.ix.figures.get(entry["id"]) or {}
    if FIELD not in fig:
        return claims
    wanted = set(fig[FIELD])
    allowed = [claim_of(level, level.ix.facts[fid]) for fid in wanted]
    keys = {canonical(c) for c in allowed if canonical(c) is not None}
    texts = {c.get("text") for c in allowed if c.get("text")}
    selected = []
    for claim in claims.get("given") or []:
        if not isinstance(claim, dict):
            continue
        k = canonical(claim)
        if ((k is not None and k in keys)
                or (claim.get("facts") and set(claim["facts"]) <= wanted)
                or (k is None and claim.get("text") in texts)):
            selected.append(claim)
    return {"given": selected, "to_prove": [], "to_construct": []}


# A new figure alone is not a mathematical state boundary. This closed
# declaration supports only the original ladder/base movement source form.
# It licenses two exact cross-state quantity pairs; it never drops all
# head/later claims and never consumes a private answer or layout.
STATE_FIELD = "state_change"
STATE_CODE = "FIGURE_STATE_SOURCE_BAD"
REASONS.setdefault(STATE_CODE, "a changed-position figure lacks exact public source/invariant bindings")
_STATE_KEYS = {"kind", "from_figure", "source", "ladder", "right_angle",
               "old_height", "new_base", "height_target"}


def _state_blocks(row):
    if isinstance(row.get("text"), list):
        return [x["bound"] for x in row["text"] if isinstance(x, dict)
                and isinstance(x.get("bound"), dict)]
    return [x for x in row.get("bound") or [] if isinstance(x, dict)]


def _state_norm(text):
    return " ".join(str(text).replace("$", "").split())


def state_record(spec, fig):
    """Verified public source contract, or (None, reason); no numeric answer."""
    if STATE_FIELD not in fig:
        return None, None
    try:
        return _state_record(spec, fig), None
    except (ValueError, KeyError, TypeError, IndexError, StopIteration, AttributeError, ZeroDivisionError):
        return None, "state_change must bind the original ladder, old height, moved base and new-height query"


def _state_record(spec, fig):
    import re
    from fractions import Fraction
    def number(value):
        return Fraction(str(value))
    def need(ok):
        if not ok:
            raise ValueError("invalid state source")
    d = fig[STATE_FIELD]
    need(isinstance(d, dict) and set(d) == _STATE_KEYS)
    need(d["kind"] == "rigid_ladder_base_move")
    need(all(isinstance(d[k], str) and d[k] for k in _STATE_KEYS - {"source"}))
    src = d["source"]
    need(isinstance(src, dict) and set(src) == {"scope", "text"})
    need(all(isinstance(src[k], str) and src[k] for k in src))
    owners = [(q, it) for q in spec.get("questions") or []
              for it in q.get("items") or [] if it.get("id") == fig.get("scope")]
    need(len(owners) == 1)
    q, it = owners[0]
    need(it.get("figure") == fig["id"] and src["scope"] == it["id"])
    heads = [g for g in spec.get("figures") or [] if g.get("id") == d["from_figure"]]
    need(len(heads) == 1)
    head = heads[0]
    need(head["id"] == q.get("figure") and head.get("scope") == q["id"])
    need(STATE_FIELD not in head)
    for g in (head, fig):
        need(g.get("figure_accuracy") == "accurate")
        need(not any(k in g for k in ("frame", "graph", "data", "loci", "base_height")))
    need(set(head.get("entities") or []) == set(fig.get("entities") or []))
    facts = {f["id"]: f for f in spec.get("facts") or []}
    ents = {e["id"]: e for e in spec.get("entities") or []}
    ladder, right, old, base, target = [facts[d[k]] for k in
                                      ("ladder", "right_angle", "old_height", "new_base", "height_target")]
    for f, scope in ((ladder, q["id"]), (right, q["id"]),
                     (old, q["id"]), (base, it["id"])):
        need(f.get("role") == "given" and f.get("item") == scope
             and f.get("source") == {"kind": "stated"})
    for f in (ladder, old, base):
        need(f.get("rel") == "length" and len(f.get("args") or []) == 1
             and f.get("unit") == "m")
        need(ents[f["args"][0]].get("kind") == "segment")
    need(target.get("role") == "target" and target.get("rel") == "length"
         and target.get("item") == it["id"] and target.get("args") == old["args"]
         and "value" not in target)
    target_ids = [t.get("id") if isinstance(t, dict) else t for t in it.get("targets") or []]
    need(target["id"] in target_ids)
    h, b, l = old["args"][0], base["args"][0], ladder["args"][0]
    H, B, L = (set(ents[e].get("ends") or []) for e in (h, b, l))
    need(len(H) == len(B) == len(L) == 2 and len(H & B) == 1
         and L == (H | B) - (H & B))
    vertices = H | B
    need(len(vertices) == 3 and all(ents[p].get("kind") == "point" for p in vertices))
    need(right.get("rel") == "perpendicular" and set(right.get("args") or []) == {h, b})
    need(vertices | {h, b, l} <= set(fig.get("entities") or []))
    need(all(ents[e].get("kind") in ("point", "segment", "angle", "polygon")
             for e in fig.get("entities") or []))
    need({e for e in fig.get("entities") or [] if ents[e].get("kind") == "point"} == vertices)
    need({e for e in fig.get("entities") or [] if ents[e].get("kind") == "segment"} == {h, b, l})
    invariant = {right["id"], ladder["id"]}
    need(isinstance(fig.get(FIELD), list) and len(fig[FIELD]) == 2 and set(fig[FIELD]) == invariant)
    need(invariant | {base["id"]} <= set(it.get("uses") or []))
    for g, datum in ((head, old), (fig, base)):
        drawn = set(g.get("draws") or [])
        need(invariant | {datum["id"]} <= drawn)
        need(all(fid in invariant | {datum["id"]} or
                 (facts[fid].get("rel") == "name" and facts[fid].get("role") == "context"
                  and facts[fid].get("args", [None])[0] in vertices) for fid in drawn))
    vals = [number(f["value"]) for f in (ladder, old, base)]
    need(all(v > 0 for v in vals) and vals[1] < vals[0] and vals[2] < vals[0])
    need(vals[2] ** 2 != vals[0] ** 2 - vals[1] ** 2)  # a genuine move, not the old position
    num = r"([0-9]+(?:\.[0-9]+)?)"
    old_pattern = r"סולם באורך " + num + r" מטרים נשען על קיר ומגיע לגובה " + num + r" מטרים\."
    move_pattern = r"אם מזיזים את הבסיס למרחק " + num + r" מטרים, חשבו את הגובה החדש\."
    def bound_value(block, token, f):
        return any(x.get("fact") == f["id"] and number(x.get("tok")) == number(token)
                   for x in block.get("bind") or [] if isinstance(x, dict) and x.get("fact") == f["id"])
    old_blocks = [(z, re.fullmatch(old_pattern, _state_norm(z.get("text")))) for z in _state_blocks(q)]
    need(any(m and number(m[1]) == vals[0] and number(m[2]) == vals[1]
             and bound_value(z, m[1], ladder) and bound_value(z, m[2], old)
             and right["id"] in z.get("prints", []) for z, m in old_blocks))
    move_blocks = [z for z in _state_blocks(it) if _state_norm(z.get("text")) == _state_norm(src["text"])]
    need(len(move_blocks) == 1)
    z = move_blocks[0]; m = re.fullmatch(move_pattern, _state_norm(z.get("text")))
    need(m and number(m[1]) == vals[2] and bound_value(z, m[1], base)
         and {base["id"], target["id"]} <= set(z.get("prints") or []))
    return {"figure": fig["id"], "head": head["id"], "question": q["id"],
            "item": it["id"], "old_height": old["id"], "new_base": base["id"],
            "height_target": target["id"], "base_entity": b}


def _state_records(spec):
    return [r for fig in spec.get("figures") or []
            for r, _why in [state_record(spec, fig)] if r is not None]


def distinct_state_pair(target, given, ix):
    """Only the old-height/new-target or old-base/new-base exact collision."""
    if target.get("role") != "target" or target.get("rel") != "length":
        return False
    for r in _state_records(ix.spec):
        if target.get("id") == r["height_target"] and given.get("id") == r["old_height"]:
            return True
        iid = target.get("item"); it = ix.items.get(iid) or {}
        if (given.get("id") == r["new_base"] and target.get("args") == [r["base_entity"]]
                and ix.scope_question.get(iid) == r["question"]
                and ix.scope_key.get(iid, (0, 0)) < ix.scope_key.get(r["item"], (0, 0))
                and (it.get("figure") or ix.questions[r["question"]].get("figure")) == r["head"]):
            return True
    return False


def state_recompute_facts(ix, scope, facts):
    """Drop one obsolete height only for the validated moving item's solve."""
    excluded = {r["old_height"] for r in _state_records(ix.spec) if r["item"] == scope}
    return [f for f in facts if f.get("id") not in excluded]
