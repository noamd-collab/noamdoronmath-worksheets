# -*- coding: utf-8 -*-
"""Stable reason codes. Every refusal in wspec carries one of these codes.
The table is closed: raising an unknown code is itself a bug (asserted)."""

REASONS = {
    "BASE_HEIGHT_SOURCE": "base/height diagram declaration is not source-bound native geometry",
    # --- schema: structure
    "UNKNOWN_FIELD": "a field outside the closed schema",
    "MISSING_FIELD": "a required field is absent",
    "BAD_TYPE": "a field has the wrong JSON type",
    "BAD_ID": "an identifier breaks the id grammar",
    "DUPLICATE_ID": "two questions/items/figures/prose blocks/releases share an id",
    "SCOPE_NOT_CANONICAL": "a question/item/figure id, an item label or the question order is not the one the fixed rule derives",
    # --- entities
    "UNKNOWN_ENTITY_KIND": "entity kind outside the closed list",
    "ENTITY_ID_NOT_CANONICAL": "entity id is not the one the fixed rule derives",
    "DUPLICATE_ENTITY": "two entities with the same id",
    "UNKNOWN_ENTITY_REF": "a reference to an entity that does not exist",
    # --- facts
    "UNKNOWN_REL": "relation outside the closed vocabulary",
    "REL_ARG_KIND": "relation argument of the wrong entity kind / arity",
    "REL_DEGENERATE": "a fact that says nothing or cannot hold by its own arguments: a point on (or the midpoint of) a segment it is an end of ('H על AH', 'H אמצע AH'), or a two-object relation of one object with itself",
    "FACT_ID_NOT_CANONICAL": "fact id is not the one the fixed rule derives",
    "DUPLICATE_FACT": "two facts with the same id",
    "UNKNOWN_SCOPE": "fact/figure/prose scope is not a question or item id",
    "UNKNOWN_FACT_REF": "a reference to a fact that does not exist",
    "UNKNOWN_ROLE": "role outside {given, context, derived, target, to_prove, to_construct, answer, to_plot}",
    "UNKNOWN_SOURCE": "source kind outside {stated, derived, context}",
    "ROLE_SOURCE_MISMATCH": "the role does not accept this source kind",
    "UNKNOWN_CONTEXT_KIND": "context kind outside the closed list",
    "CONTEXT_KIND_MISMATCH": "context kind used on a relation/entity it does not describe",
    "UNKNOWN_RULE": "derived fact names a rule outside the rule registry",
    "DERIVED_FROM_MISSING": "derived fact has no 'from' facts",
    "DERIVED_FROM_LATER": "derived fact is derived from a fact of a later scope",
    "DERIVED_FROM_PRIVATE": "a released/given derived fact is derived from a private fact",
    "VALUE_REQUIRED": "a measure fact without a value",
    "VALUE_FORBIDDEN": "a value on a relation / role that cannot carry one",
    "TARGET_HAS_VALUE": "a target carries its value (the value is the answer's, private)",
    "BAD_NUMBER": "a value that is not an exact number",
    "UNKNOWN_UNIT": "unit outside the declared unit table",
    "UNIT_DIMENSION_MISMATCH": "unit dimension does not fit the relation",
    "ANSWER_WITHOUT_TARGET": "an answer whose target does not exist in the same item",
    "TARGET_WITHOUT_ANSWER": "a target/to_prove with no answer",
    "DISPLAY_MISMATCH": "a display name that does not name the referenced entity",
    # --- items / figures
    "UNKNOWN_TASK_TYPE": "task_type outside measure|read_off|compute|prove|construct|verify|plot",
    "MEASURE_NEEDS_MEASUREMENT": "a measure/read_off item with measurement_allowed=false",
    "ITEM_TARGETS_MISMATCH": "item.targets differ from the target facts of its scope",
    "BAD_FIGURE_ACCURACY": "figure_accuracy outside {accurate, schematic}",
    "UNKNOWN_FIGURE": "item/question names a figure that does not exist",
    "FIGURE_DRAWS_UNLISTED": "a figure draws a fact whose entities (or their points) are not among the figure's entities",
    "FIGURE_DRAWS_PRIVATE": "a figure draws a fact that is not public-eligible",
    "USES_PRIVATE": "an item's Noam-AI 'uses' names a fact that is not public-eligible",
    "ENTITY_VALUE_UNLICENSED": "a value-carrying entity (number, tick) made public without the public fact that states its value",
    # --- text / prose
    "STATED_NOT_PRINTED": "a 'stated' fact that no generated text prints",
    "TPL_SOURCE_NOT_STATED": "generated text prints a fact whose source is not 'stated'",
    "PROSE_UNAPPROVED": "prose whose approved_hash is not sha256 of its exact text",
    "PROSE_HAS_MATH": "prose carries digits / math markup (prose is never a source of facts)",
    "UNKNOWN_PROSE": "a text segment names prose that does not exist",
    # --- public / private (C3)
    "UNNEEDED_PUBLIC": "a public-eligible fact that nothing needs (not printed/drawn/used)",
    "FIGURE_NOT_SHOWN": "a figure that no question or item shows (its figure field): an orphan -- the scope it was drawn for shows another figure",
    "BASELINE_FIGURE_LINK_CHANGED": "a question or item shows another figure than in the baseline (or gained / lost its figure)",
    "BASELINE_DISPLAY_CHANGED": "a fact's display override (how its names print) differs from the baseline",
    "RELEASE_UNREVIEWED": "a release without a valid basis: no reason, or an 'approval' without a reviewer or an ISO 8601 timestamp, or a basis that is neither 'from_item' nor 'approval'",
    "RELEASE_FAKE_APPROVAL": "a 'from_item' release (provenance: the claim an earlier item proved) that carries a reviewer or timestamp -- an import from an earlier item is not a human approval and may not be shown as one",
    "RELEASE_PROVENANCE_BAD": "a 'from_item' release whose item is not an earlier item of the same question, or whose fact is not the claim a to_prove of that item states -- or, for a carried given, the stated given of that item (same relation, arguments and value, named in the fact's source)",
    "RELEASE_STALE": "a release whose fact changed after review",
    "RELEASE_OF_PRIVATE": "a release of an answer / target value (never releasable)",
    "PUBLIC_KEY_NOT_WHITELISTED": "the public model holds a key outside the whitelist",
    "PUBLIC_VALUE_NOT_WHITELISTED": "the public model holds a value outside its grammar (sheet id, label, ids, names, unlicensed entity value)",
    # --- target already given (C4)
    "KEY_ALSO_BAD": "an item's key_also (a value the answer key restates beside the item's own answers, e.g. the known third angle of 'compute the angles of the triangle') is not a public given / to_prove with a value of the same question, at or before the item, or it repeats one of the item's own targets",
    "TARGET_ALREADY_GIVEN": "a target's quantity is already given in the same question (its text or ANY of its items, earlier or later)",
    "TO_PROVE_ALREADY_GIVEN": "the relation to prove is already given in the same question text, an earlier item or the item itself",
    "CONSTRUCT_ALREADY_DRAWN": "the RESULT of a construction (declared by its template) is already drawn on the page of its question (the question's figure, any item's figure earlier or later, or a figure the item names; a segment / line / ray also as a side or an angle arm); also drawn as a piece of the result's line (its points and every point the public givens put on that line: inside a longer drawn segment, as several collinear pieces); and, for a construction that locates without a new point (construct_segment / line / ray / point / triangle), every defining point drawn (they fix it -- joining given points is construct_join); the objects it is built on may be drawn",
    "CONSTRUCT_JOIN_UNSHOWN": "a join construction (construct_join: 'draw the segment between the two given points') one of whose points is not shown in the figure the item's reader sees (the item's or its question's figure): the declaration does not match the drawing",
    "CONSTRUCT_NEW_POINT_IN_BASE": "a construction that declares a new point (altitude, median, bisector, midpoint, perpendicular, parallel) names every point of its result inside its base: the point it finds is hidden in the base (the foot H named in the line BH) or the construction cannot exist (PQ parallel to BQ through P)",
    "CONSTRUCT_ITEM_NO_TARGET": "an item of task_type 'construct' has no to_construct target (the task type declares what it asks for)",
    "CONSTRUCT_STEP_DRAWN": "a construction that declares new_point (altitude, median, bisector, midpoint, perpendicular, parallel) has its NEW point -- a point of the result that is not a point of the base, e.g. the foot H -- drawn on the page of its question (the construction's essential step)",
    "ENTITY_DEGENERATE": "an entity names the same point twice (a ray from A through A, an angle whose vertex is one of its arms)",
    "ENTITY_REF_KIND": "an entity field references an entity of the wrong kind (a segment's end that is not a point, an arc's circle that is not a circle)",
    "BASELINE_SHEET_CHANGED": "the spec's sheet id differs from the baseline's (a baseline belongs to one sheet)",
    "CONSTRUCT_NOT_IN_CONSTRUCT_ITEM": "a to_construct fact in an item whose task_type is not 'construct'",
    "CONSTRUCT_REL_ROLE": "a construction relation with a role other than to_construct/answer, or a to_construct whose relation is not a construction",
    "TPL_CONSTRUCT_DECL": "a to_construct template without a valid result/base declaration (result = arg 0, base = the other args, the same for every template of a relation)",
    # --- v6.10 language (spec_language, BRIEF_V610 part 2)
    "LIN_FORM": "a 'linear' relation of the wrong shape: 2-5 distinct quantity arguments, one non-zero exact rational coefficient per argument after the first (coef), a constant (value) that is non-zero when present, no plain equality of two segments / angles (equal_length / equal_angle say that)",
    "LIN_DIMENSION": "a 'linear' / 'greater' relation mixes dimensions (a length with an angle or an area; the constant's unit is not the dimension of its terms)",
    "LIN_ROLE": "a relation between quantities ('linear', 'greater') as a target: a relation is given or proved; a quantity is computed",
    "CLASSIFY_VALUE": "a 'classify' fact of the wrong shape: its answer names no class of the closed list (or a class of another vertex count); its target / to_prove carries a value",
    "SHAPE_VERTEX_COUNT": "a shape class stated for a polygon with the wrong number of vertices (a trapezoid has 4, a right / acute / obtuse triangle 3)",
    "ROOT_HINT_RATIONAL": "the text asks to express the answer with a root, and the answer is rational (or absent)",
    "DEDUCE_WITHOUT_PREMISE": "'הסיקו כי' with nothing proved before it in the question (no to_prove in an earlier item or earlier in the same text)",
    "CLINE_DRAWN": "a construction result the sheet does not name (a cline: the line through P parallel / perpendicular to a base) is drawn by a figure the item shows, listed in a figure, or named by a drawn fact",
    "LANG_TEXT_CHECK": "a v6.10 template's check against its SCOPE fails: an item reference that is not an earlier item, a shape word ('המלבן') that the question does not state, or an angle known from nothing",
    # --- v6.12 families: coordinate plane, number line (family.py)
    "FRAME_BAD": "a figure's frame (coordinate_plane / number_line) of the wrong shape: unknown or missing field, family outside the closed list, a schematic framed figure (unless its frame is a sketch plane, v6.16 gaps r3: then schematic, every axis label_at [], no coordinate / guide drawn, a sketch place only for a shown point), an axis that is not an axis entity, min >= max, step <= 0, a range that is no whole number of steps or more than MAX_INTERVALS, a plane axis that does not pass through the origin, not exactly one of label_every / label_at, a label off the ticks, a form that cannot print a label",
    "FRAME_UNLISTED": "the plane / axis a frame names is not listed among the figure's entities",
    "FAMILY_ENTITY": "a framed figure shows an entity kind outside its family's closed list (an angle on a number line), or a figure without a number_line frame shows a jump / interval",
    "FAMILY_VALUE": "a family value of the wrong shape: a surd where a rational is required, a negative distance / absolute value, a count that is not a whole number >= 0, an interval <= 0, a jump of 0, a unit on anything but a distance (length), or a printed form ('decimal' / 'fraction' / 'mixed') that cannot print the value or sits on a fact without a family value",
    "FAMILY_INCONSISTENT": "family facts that disagree: one point with two coordinates on one axis in a question, a distance / absolute value / jump / whole-number count that differs from what the coordinates give, an interval value that is not the frame's step, an interval whose lo is not below its hi",
    "FRAME_POINT_UNPLACED": "a framed figure shows a point without its coordinate on every axis of the frame (given, derived, context or an answer of its question): the figure cannot place it",
    "FRAME_POINT_OUTSIDE": "a framed figure shows a point / number outside the frame's range",
    "PLOT_REL_ROLE": "the 'plot' relation with a role other than to_plot / answer, or a to_plot whose relation is not 'plot'",
    "PLOT_NOT_IN_PLOT_ITEM": "a to_plot fact in an item whose task_type is not 'plot'",
    "PLOT_ITEM_NO_TARGET": "an item of task_type 'plot' has no to_plot target",
    "PLOT_UNDETERMINED": "a to_plot whose place is not fixed: a point without its coordinate on every axis (given before or in its item, or asked in the same item), or a number plotted on a plane",
    "FIGURE_SHOWS_TO_PLOT": "a figure of the question shows the point / number a to_plot asks the student to plot (a point to plot is private until answered)",
    "FAMILY_GUIDE": "a reading guide (the helper line from a point to an axis) that is not a stated given, or that no framed figure of its question with that axis draws: guides appear only where a given states them",
    "FRAME_SHOWS_TARGET": "a framed figure of the question gives a target away: it shows a point whose coordinate a non-read_off item asks, or prints the numbers of two neighbouring ticks of an axis whose interval value is asked",
    # --- templates
    "TPL_SET_UNAPPROVED": "templates file differs from the approved set (hash)",
    "TPL_UNKNOWN": "a text segment names a template that does not exist",
    "TPL_BAD_SLOT": "a template slot outside the slot grammar",
    "TPL_TARGET_HAS_VALUE_SLOT": "a target/mention template with a value/unit/relation slot",
    "TPL_PRINTS_TARGET_VALUE": "a template call that would print a target's value",
    "TPL_PRINTS_ANSWER": "a template call that would print an answer",
    "TPL_ROLE_MISMATCH": "a template applied to a fact of a role it does not accept",
    "TPL_REL_MISMATCH": "a template applied to a fact of a relation it does not accept",
    "TPL_ARITY": "a template called with the wrong number of facts/entities",
    "TPL_CONSTRAINT": "a template's declared constraint between its arguments fails",
    "TPL_BAD_PARAM": "a template parameter outside its closed word list",
    "TPL_BAD_CONNECTOR": "a connector outside the closed connector list",
    "TPL_BAD_SEGMENT": "a text segment of unknown shape",
    "TPL_NO_NAME": "a template would print an entity kind that has no printed name (table cell)",
    "TPL_SCOPE_MISMATCH": "a text prints a fact of another item/question",
    # --- baseline (C4)
    "BASELINE_STALE": "the baseline file was edited after it was frozen",
    "BASELINE_ITEM_ADDED": "an item not in the baseline",
    "BASELINE_ITEM_REMOVED": "a baseline item is missing",
    "BASELINE_TASK_CHANGED": "an item's task_type changed",
    "BASELINE_STATED_ADDED": "a stated/given fact added to a question or item",
    "BASELINE_FACT_ADDED": "a non-stated public fact added",
    "BASELINE_FACT_REMOVED": "a baseline fact is missing",
    "BASELINE_VALUE_CHANGED": "a fact's value changed",
    "BASELINE_UNIT_CHANGED": "a fact's unit changed",
    "BASELINE_ROLE_CHANGED": "a fact's role or source kind changed",
    "BASELINE_TARGET_ADDED": "a target added",
    "BASELINE_TARGET_REMOVED": "a baseline target is missing",
    "BASELINE_ANSWER_CHANGED": "an answer's value changed",
    "BASELINE_ANSWER_REMOVED": "a baseline answer is missing",
    "BASELINE_ANSWER_ADDED": "an answer not in the baseline",
    "BASELINE_MEASUREMENT_CHANGED": "an item's measurement_allowed changed",
    "BASELINE_TEXT_CHANGED": "what a question / item prints changed: its text, its given lines, its target descriptions or its answer key line (a released step printed as a new given line, a wording that adds a requirement such as 'justify')",
    "BASELINE_PUBLIC_CHANGED": "a fact became public or private (a derived step released or its release withdrawn)",
    "BASELINE_FIGURE_CHANGED": "a figure added, removed, moved to another scope, its figure_accuracy changed, or the entities it lists / the facts it draws changed",
    "BASELINE_ORDER_CHANGED": "question order, item order or an item label differs from the baseline",
    # --- geometry check on the ORIGINAL svg (C5)
    "GEOM_MISSING_ELEMENT": "the svg lacks an element the spec requires",
    "GEOM_ENDPOINT_OFF": "a segment endpoint misses its point by more than JOIN_TOL_PX",
    "GEOM_MIDPOINT_OFF": "a midpoint is off by more than ON_TOL_PX",
    "GEOM_NOT_ON_SEGMENT": "a point on a segment is off it by more than ON_TOL_PX",
    "GEOM_ANGLE_OFF": "in an accurate figure, a drawn angle differs from its value (or two angles the spec says are equal differ, or lines are not parallel / perpendicular) by more than ANGLE_TOL_DEG, or an arm is shorter than MIN_ARM_PX",
    "GEOM_BAD_SVG": "the svg cannot be parsed",
    "GEOM_DUPLICATE_MARKER": "two svg elements carry the same point / segment / line / ray / polygon hook (a segment hook in either order: BM and MB are one hook), or one object carries two different marks",
    "GEOM_POLY_MISMATCH": "a data-poly polygon's vertices are not on that polygon's points (count, order or > JOIN_TOL_PX)",
    "GEOM_HOOK_UNKNOWN": "a hook (data-pt / data-seg / data-line / data-ray / data-poly, or the object of a data-mark) names an object the figure does not show (not an entity of the spec, not listed, not drawn on by a drawn fact, not a drawn side / both arms) -- nothing in the file is measured",
    "GEOM_MARK_OFF": "a mark (arc, right-angle mark, tick) is not drawn as it says: an arc off its circle about the vertex (at a sample, or a chord between samples more than ARC_SAGITTA_PX inside it) or not from arm to arm, a right-angle mark that is not a square corner along both arms or on an angle not drawn at 90 degrees, a tick not across the middle of its segment, a mark on an object that is not drawn, or the wrong number of strokes for its count",
    "GEOM_MARK_UNSUPPORTED": "a mark claims what the reader of the figure is not given: a right-angle mark on an angle no seen fact makes 90 degrees, or marks of the same kind and count on objects no seen fact makes equal (a to_prove or an answer printed as marks)",
    "GEOM_POINTS_TOO_CLOSE": "two different marked points are within NEAR_POINT_PX of each other (they read as one point)",
    "GEOM_LENGTH_OFF": "in an accurate figure, lengths the spec says are equal (or in a ratio) differ by more than LEN_TOL_PX / SCALE_TOL_REL, or the length / perimeter / area values of the figure are not drawn to one scale",
    "GEOM_SHAPE_OFF": "in an accurate figure, a polygon is not drawn as the shape class the spec states (rectangle, square, parallelogram, rhombus, equilateral, isosceles, congruent, trapezoid, right / acute / obtuse triangle)",
    "GEOM_LABEL_MISMATCH": "a label does not print what its source (data-for) is: a point label whose text is not its point's name or whose point the figure does not show; a value label for an object the figure does not show, or whose text is not the value of a given/context fact the figure draws of that object (a swapped or foreign name, an answer, a target's value)",
    "GEOM_LABEL_OFF": "a label is not at its object, or also reads as another object's: a point's name farther than LABEL_NEAR_PX from its point or nearer to another point; an angle's value outside its sector, farther than LABEL_VALUE_PX, not nearer (by LABEL_MARGIN_PX) to its vertex than to any other point, or inside a narrower drawn angle at the vertex; a segment's value away from its middle part or not nearer (by LABEL_MARGIN_PX) to it than to any other drawn piece; a polygon's value outside it or inside a smaller drawn polygon; or a label box covering a marked point",
    "GEOM_LABEL_CLIPPED": "a label's estimated glyph box runs past the canvas (the anchor is on it, the text is cut)",
    "GEOM_LABEL_COVERS": "a label's estimated glyph box covers a mark stroke (arc, right-angle mark, tick) or a drawn straight piece runs through it for more than LABEL_STROKE_TOL_PX",
    "GEOM_KIND_OFF": "a line or ray is drawn only up to its points (a line must run past both of its points, a ray past its second point, by LINE_OVERHANG_PX): it prints as a segment",
    "GEOM_DIALECT": "the svg is outside the closed dialect of svg_dialect.json (an element, attribute, value, grammar or ordering rule; the element and attribute are named) -- the file is not measured",
}


class SpecError(Exception):
    """A refusal. .issues is a list of Issue."""

    def __init__(self, issues):
        if isinstance(issues, Issue):
            issues = [issues]
        self.issues = list(issues)
        Exception.__init__(self, "; ".join(str(i) for i in self.issues))

    @property
    def codes(self):
        return sorted(set(i.code for i in self.issues))


class Issue(object):
    __slots__ = ("code", "where", "detail")

    def __init__(self, code, where="", detail=""):
        assert code in REASONS, "unregistered reason code %r" % code
        self.code, self.where, self.detail = code, where, detail

    def __repr__(self):
        return "Issue(%s @ %s: %s)" % (self.code, self.where, self.detail)

    __str__ = __repr__

    def as_dict(self):
        return {"code": self.code, "where": self.where, "detail": self.detail}


def codes(issues):
    return sorted(set(i.code for i in issues))
