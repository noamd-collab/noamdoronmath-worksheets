"""Independent finished-SVG proof for coordinate observations.

No renderer, source model, placements or private values are read. Coordinates
are recovered from measured axis maps; public givens, marker declarations and
source-bound legends/readings constrain them. Exact selected element sets are
then checked by the ordinary object-map/highlight checker.
"""
import re
from fractions import Fraction
from .report import CheckerInputError

CHECKS = ('DATA_MARKER_CONSISTENT', 'LEGEND_MATCHES_MARKERS_IF_ANY',
          'AXIS_READING_AT_VALUES', 'MUST_NOT_DRAW')
TOKEN = re.compile(r'^[A-Za-z][A-Za-z0-9_-]{0,31}$')


def _q(v):
    try:
        return Fraction(str(v))
    except (ValueError, TypeError, ZeroDivisionError):
        return None


def _norm(s):
    return ' '.join(s.replace('$','').split()) if isinstance(s,str) else ''


def public_objects(raw, fig, facts):
    d=fig.get('data')
    if d is None: return {}
    def refuse(msg): raise CheckerInputError('coordinate data: '+msg)
    def fields(obj,allow,need):
        return isinstance(obj,dict) and not set(obj)-set(allow) and set(need)<=set(obj)
    if not fields(d,('series','points','readings'),('series','points')) or any(not isinstance(d.get(k,[]),list) for k in ('series','points','readings')):
        refuse('closed data record required')
    text, owners, printed = {},{},set()
    for q in raw.get('questions',[]):
        for sc in [q]+q.get('items',[]):
            owners[sc['id']]=q['id'];text[sc['id']]=_norm(sc.get('text'))
            for b in sc.get('bound',[]):
                printed.update(b.get('prints',[]))
                for row in b.get('bind',[]):
                    f=row.get('fact');printed.update(f if isinstance(f,list) else [f] if f else [])
    question=owners.get(fig.get('scope'))
    def sourced(src):
        return fields(src,('scope','text'),('scope','text')) and isinstance(src['scope'],str) and owners.get(src['scope'])==question and bool(_norm(src['text'])) and _norm(src['text']) in text.get(src['scope'],'')
    series,out={},{}
    for s in d['series']:
        if not fields(s,('id','marker','label','legend'),('id','marker')) or not isinstance(s.get('id'),str) or not TOKEN.fullmatch(s['id']) or s['id'] in series or s.get('marker') not in ('circle','square'):
            refuse('invalid/duplicate series')
        if 'label' in s and (not isinstance(s['label'],str) or not s['label'] or not any(s['label'] in t for sc,t in text.items() if owners.get(sc)==question)):
            refuse('series label is not printed in this question')
        if 'legend' in s and (not sourced(s['legend']) or {'circle':'●','square':'□'}[s['marker']] not in s['legend']['text'] or (s.get('label') and s['label'] not in s['legend']['text'])):
            refuse('legend disagrees with source symbol/label')
        series[s['id']]=s
        out['series:'+s['id']]=dict(s,kind='data_series',points=[])
    if not series:refuse('no series')
    legend=[s['marker'] for s in series.values() if s.get('legend')]
    if len(set(legend))!=len(legend):refuse('legend markers indistinguishable')
    for p in d['points']:
        if not fields(p,('id','series','coords','drawn','role','coord_facts'),('id','series','drawn','role')) or not isinstance(p.get('id'),str) or not TOKEN.fullmatch(p['id']) or not isinstance(p.get('series'),str) or p['series'] not in series or not isinstance(p.get('drawn'),bool) or p.get('role') not in ('given','read_off','to_plot','to_find'):
            refuse('invalid point')
        oid='data:'+p['series']+':'+p['id']
        if oid in out:refuse('duplicate point')
        if p['role'] in ('to_plot','to_find') and p['drawn']:refuse('student point is drawn')
        xy=p.get('coords'); ff=p.get('coord_facts')
        if xy is not None:
            if not isinstance(xy,list) or len(xy)!=2 or any(_q(v) is None for v in xy) or not isinstance(ff,list) or len(ff)!=2 or any(not isinstance(f,str) for f in ff) or p['role'] in ('read_off','to_find'):
                refuse('private/malformed public coordinates')
            fs=[facts.get(f,{}) for f in ff]
            if any(f.get('rel')!='coordinate' or f.get('role')!='given' or f.get('id') not in printed or owners.get(f.get('item'))!=question for f in fs) or [f.get('args',[None,None])[-1] for f in fs]!=['axis:x','axis:y'] or fs[0].get('args',[None])[0]!=fs[1].get('args',[None])[0] or any(_q(f.get('value'))!=_q(v) for f,v in zip(fs,xy)):
                refuse('public pair lacks exact printed coordinate facts')
        elif p['role']=='given':refuse('given point lacks public facts')
        out[oid]=dict(p,kind='data_point',marker=series[p['series']]['marker'])
        out['series:'+p['series']]['points'].append(oid)
    for r in d.get('readings',[]):
        if not fields(r,('id','axis','lo','hi','lo_in','hi_in','source'),('id','axis','lo_in','hi_in','source')) or not isinstance(r.get('id'),str) or not TOKEN.fullmatch(r['id']) or r.get('axis') not in ('axis:x','axis:y') or not isinstance(r.get('lo_in'),bool) or not isinstance(r.get('hi_in'),bool) or not sourced(r.get('source')):
            refuse('invalid/source-unbound reading')
        bounds=[k for k in ('lo','hi') if k in r]
        if not bounds or any(_q(r[k]) is None for k in bounds) or ('lo' in r and 'hi' in r and _q(r['lo'])>_q(r['hi'])):refuse('invalid reading bounds')
        if any(not re.search(r'(?<![\d.])'+re.escape(str(r[k]))+r'(?![\d.])',_norm(r['source']['text'])) for k in bounds):refuse('reading bound not printed')
        oid='reading:'+r['id']
        if oid in out:refuse('duplicate reading')
        out[oid]=dict(r,kind='axis_reading')
    return out


def measure(cc):
    objects=cc.pub.data_objects
    if not objects:return
    cc.data_checked=True;cc.data_elements={};seen={};sizes={}
    F=cc.F
    native=cc.pub.shown_points()
    for e in cc.els('data-pt'):
        if e.hv not in native:
            F.fail('CHK_EXTRA_NATIVE_OBSERVATION','PT_NOT_DRAWN_ANY_FORM','data figure contains an undeclared named marker',e.hv)
    for e in cc.dr.els:
        if e.hook not in ('data-dot','data-square'):continue
        ps=e.hv.split(' ')
        oid='data:'+':'.join(ps);p=objects.get(oid)
        if not p or p.get('kind')!='data_point' or not p['drawn']:
            F.fail('CHK_OBSERVATION_FORBIDDEN','PT_NOT_DRAWN_ANY_FORM','undeclared or student observation has visible ink: '+oid,oid)
            if p and p.get('role') in ('to_plot','to_find'):
                F.fail('CHK_OBSERVATION_ANSWER','NO_ANSWER_ANYWHERE_SVG','visible observation supplies the student construction: '+oid,oid)
            continue
        if oid in seen:F.fail('CHK_OBSERVATION_TWICE','DATA_MARKER_CONSISTENT','multiple markers for '+oid,oid)
        seen[oid]=e;cc.data_elements.setdefault(oid,set()).add(e.ref)
        marker='circle' if e.hook=='data-dot' else 'square'
        if marker!=p['marker']:
            F.fail('CHK_OBSERVATION_MARKER','DATA_MARKER_CONSISTENT','wrong marker shape for '+oid,oid)
            if objects['series:'+p['series']].get('legend'):
                F.fail('CHK_LEGEND_MARKER','LEGEND_MATCHES_MARKERS_IF_ANY','measured marker contradicts the printed legend',oid)
        if marker=='circle':
            c=e.pts[0];size=float(e.a.get('r',0))*2
        else:
            xs=[v[0] for v in e.pts];ys=[v[1] for v in e.pts]
            if not xs:continue
            x0,x1,y0,y1=min(xs),max(xs),min(ys),max(ys)
            c=((x0+x1)/2,(y0+y1)/2);size=x1-x0
            if len(e.pts)!=4 or len(set(e.pts))!=4 or set(e.pts)!={(x0,y0),(x1,y0),(x1,y1),(x0,y1)} or any(a[0]!=b[0] and a[1]!=b[1] for a,b in zip(e.pts,e.pts[1:]+e.pts[:1])) or abs(size-(y1-y0))>.03 or not 4<=size<=8 or e.a.get('fill')!='none':
                F.fail('CHK_OBSERVATION_SQUARE','DATA_MARKER_CONSISTENT','marker is not an outlined square',oid)
        old=sizes.setdefault(p['series'],size)
        if abs(old-size)>.03:F.fail('CHK_OBSERVATION_SIZE','DATA_MARKER_CONSISTENT','series marker sizes differ',oid)
        cc.pts[oid]=c
        idx=[cc.index(cc.ax,c[0]),cc.index(cc.ay,c[1])]
        vals=[cc.value(A,i) for A,i in zip((cc.ax,cc.ay),idx)]
        cc.measured_coords[oid]={'index':[round(i,4) for i in idx],'value':[None if v is None else str(v) for v in vals]}
        for A,i,k in zip((cc.ax,cc.ay),idx,range(2)):
            if not (1 if A.broken else 0)-.01<=i<=A.n+.01:F.fail('CHK_OBSERVATION_OUTSIDE','PT_AT_COORDS','observation lies outside printed range',oid)
            if 'coords' in p and A.step is not None:
                want=float(_q(p['coords'][k])/A.step)+A.zero
                if abs(i-want)*abs(A.fit[1])>.3:F.fail('CHK_OBSERVATION_OFF','PT_AT_COORDS','observation differs from printed given coordinate',oid)
    for oid,p in objects.items():
        if p['kind']=='data_point' and p['drawn'] and oid not in seen:
            F.fail('CHK_OBSERVATION_MISSING','PT_AT_COORDS','declared observation missing',oid)
        if p['kind']=='data_series':
            cc.data_elements[oid]=set().union(*(cc.data_elements.get(o,set()) for o in p['points']))
        elif p['kind']=='axis_reading':
            A=cc.axes[p['axis']];refs=set()
            for e in cc.els('data-tick')+cc.els('data-num'):
                toks=e.hv.split(' ')
                if len(toks)!=2 or toks[0]!=A.letter:continue
                # Index is independently tied to measured tick/grid geometry by
                # AX_TICKS_AT_VALUES; also derive the physical element position.
                i=int(toks[1]);v=cc.value(A,i)
                if v is None:continue
                if 'lo' in p and (v<_q(p['lo']) or (v==_q(p['lo']) and not p['lo_in'])):continue
                if 'hi' in p and (v>_q(p['hi']) or (v==_q(p['hi']) and not p['hi_in'])):continue
                refs.add(e.ref)
            cc.data_elements[oid]=refs
            if not refs:F.fail('CHK_READING_EMPTY','AXIS_READING_AT_VALUES','reading selects no visible tick/number',oid)
            faults=[f for f in F.items if f['check'] in ('AX_TICKS_AT_VALUES','AX_SCALE_CONSISTENT','AX_NUMBERS_PARTIAL_AS_DECLARED') and f['level'] in ('FAIL','REVIEW')]
            if faults:
                record=F.fail if any(f['level']=='FAIL' for f in faults) else F.review
                record('CHK_READING_AXIS_UNVERIFIED','AXIS_READING_AT_VALUES','reading marks are not at verified axis values',oid)
    # A dot plot forbids extra bars/curve/region ink. Existing native entities
    # may still own strokes; only strokes without an explicit native contract
    # are prohibited. This is a measured drawing-type constraint, not a waiver.
    allowed=cc.pub.listed
    for e in cc.dr.els:
        if e.hook in ('data-seg','data-line','data-ray'):
            names=e.hv.split(' ')
            legitimate=any(set(cc.pub.points_of(n))==set(names) for n in allowed if cc.pub.kind(n) in ('segment','line','ray','polygon'))
            if not legitimate:F.fail('CHK_DATA_EXTRA_STROKE','MUST_NOT_DRAW','dot plot contains an undeclared data stroke',None)
