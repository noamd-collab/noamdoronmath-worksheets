# -*- coding: utf-8 -*-
"""v6.13 (BRIEF_V613 s.3): OCR reliability for the family checkers
(coordinate plane, number line) -- crop-level reading with EXPECTED-SET
matching. Stdlib only (the crops are raster.Gray images).

OCR stays evidence of what is VISIBLE, never the source of truth. The
checker knows the label's text; Vision is asked whether the crop shows it.
Three things made correct figures REVIEW in the v6.12 synthetic corpora, and
each is handled here by a DOCUMENTED rule that cannot turn a wrong glyph
into a PASS:

1. THE READ FOLD (fold_read) -- a representation change only, never a
   different glyph:
     * every dash form Vision returns for the printed minus (U+2212) -> '-':
       '-' U+2010 U+2011 U+2012 U+2013 U+2014 U+2015 U+2212 U+FE63 U+FF0D.
       Which glyph the figure prints is checked in the SVG text itself
       (U+2212 only: NL_MINUS_U2212 / CHK_NUMBER_WRONG), not by OCR.
     * a Cyrillic / Greek capital with the SAME shape as a Latin capital ->
       that Latin capital (tol.OCR_HOMOGLYPHS: Cyrillic 'В' U+0412 -> 'B',
       'О' U+041E -> 'O', Greek 'Ο' -> 'O', ...). The SVG text is Latin (the
       dialect / name checks); Vision's script choice is not a glyph.
     * spaces are dropped.
   Nothing else is folded: O / 0, B / 8, 6 / 9, S / 5 stay different
   characters (tol.OCR_CONFUSABLE lists what the checkers accept as a
   look-alike, and a look-alike is ambiguous when another label of the
   figure is that look-alike -- ocr.read_labels, coord._ocr, nline._ocr).

2. TILED READS (tiled_read) -- a short label is read from a crop tiled n
   times ('−5 −5 −5'). A read confirms the label when, after the fold, it is
   exactly 1, 2 or n copies of the label (up to the look-alikes), or
   ('consensus') it STARTS with at least two exact copies -- the same pixels
   read the same way twice, with the sign in place -- and the rest of the
   read is only a dash, look-alikes of the label's own characters, or JUNK:
   letters outside ASCII that no label prints (Vision's 'sł', 'ął', 'ąś',
   U+FFFE after the last copy). A digit, an ASCII letter or any other
   character that is not the label's in the rest -> no match (REVIEW).
   A read of the crop turned upside down ('9-9-9' at '−6') never matches:
   the sign is at the wrong end.

3. EXPECTED-SET MATCHING ON THE CROP (decide_glyphs) -- for the characters
   Vision cannot tell apart alone the crop is measured, per character
   (column segments of the binarised crop; no decision unless there is one
   segment per visible character):
     O / 0   the ink box aspect (w / h) is compared with the SAME character
             pair rendered by MuPDF in the label's own font attributes: the
             crop must sit in the expected character's third of the
             (log-)interval between the two references, and the references
             must differ by GLYPH_ASPECT_MIN_LOG (else: no decision).
     6 / 9   the enclosed hole (background not reached from the border):
             its centre in the lower part (6: > GLYPH_HOLE_LOW) or the upper
             part (9: < GLYPH_HOLE_HIGH) of the character.
     B / 8   B has a straight left stem: the left edge of the ink, row by row
             over the middle 70 % of the height, varies by at most
             GLYPH_STEM_FLAT of the width; an 8 (two bowls and a waist)
             varies by at least GLYPH_STEM_CURVED.
   A decision is 'expected', 'rival' (the look-alike) or None (undecided).
   The checkers use it ONLY to (a) confirm a look-alike read that is
   ambiguous with another label of the figure when the crop decides
   'expected', and (b) refuse a read when the crop decides 'rival' (with
   the read also the rival: WRONG_GLYPH, FAIL; with a read of the label
   itself: CONTRADICTS, REVIEW). Undecided never confirms anything.

4. THE SIGN BY ITS INK (is_minus_bar) -- a signed number Vision does not
   read whole is confirmed only when its FIRST column segment is a solid
   horizontal bar (one run of rows, ink >= BAR_SOLID of its box, at least
   BAR_MIN_WIDE times wider than tall, its middle within the digits' middle
   half) and the digits alone are read exactly; a 6 or a 9 among the
   digits must then be decided 'expected' by its hole (the digits read
   alone lose the sign's protection against an upside-down read)."""
import math

from . import tol as T

# ------------------------------------------------------------- the fold --
DASH_FORMS = u"-‐‑‒–—―−﹣－"
MINUS = u"−"


def fold_read(s):
    """The documented read fold (see the module docstring, 1)."""
    out = []
    for ch in (s or ""):
        if ch.isspace():
            continue
        if ch in DASH_FORMS:
            out.append("-")
            continue
        out.append(T.OCR_HOMOGLYPHS.get(ch, ch))
    return "".join(out)


def is_junk(ch):
    """A character no label prints and no look-alike stands for: a letter
    outside ASCII (after the homoglyph fold) or a non-character."""
    o = ord(ch)
    if o in (0xFFFE, 0xFFFF, 0xFFFD):
        return True
    return o > 0x7F and ch.isalpha() and ch not in T.OCR_HOMOGLYPHS


def _conf_eq(a, b):
    if a == b:
        return True
    return any(a in g and b in g for g in T.OCR_CONFUSABLE)


def _copies_eq(read, want, n):
    w = want * n
    return len(read) == len(w) and all(_conf_eq(a, b)
                                       for a, b in zip(read, w))


def tiled_read(want, read, tile):
    """want, read: FOLDED strings. -> 'exact' (1, 2 or `tile` copies, up to
    the look-alikes) | 'consensus' (>= 2 exact copies first, then only a
    dash / the label's own look-alikes / junk) | None."""
    if not want or not read:
        return None
    for n in sorted(set([1, min(2, tile), tile])):
        if _copies_eq(read, want, n):
            return "exact"
    if tile < 2:
        return None
    k, i = 0, 0
    while read[i:i + len(want)] == want:
        k += 1
        i += len(want)
    if k < 2 or k > tile:
        return None
    rest = read[i:]
    own = set(want)
    for ch in rest:
        if ch == "-" or is_junk(ch):
            continue
        if any(_conf_eq(ch, c) for c in own):
            continue
        return None
    return "consensus"


# ------------------------------------------------------ crop geometry ----
def _bin(g):
    """rows of booleans (True = ink) of a Gray crop, trimmed to its ink."""
    b = g.binarise()
    bb = b.ink_bbox()
    if bb is None:
        return None
    b = b.crop(bb)
    return [[v < 128 for v in r] for r in b.rows]


def segments(g):
    """Column segments of a crop: [(x0, x1)] of the runs of ink columns of
    the binarised, trimmed crop, and the trimmed boolean image."""
    m = _bin(g)
    if m is None:
        return [], None
    w = len(m[0])
    cols = [any(r[x] for r in m) for x in range(w)]
    segs, x = [], 0
    while x < w:
        if not cols[x]:
            x += 1
            continue
        x0 = x
        while x < w and cols[x]:
            x += 1
        segs.append((x0, x))
    return segs, m


def _sub(m, x0, x1):
    rows = [r[x0:x1] for r in m]
    ys = [y for y, r in enumerate(rows) if any(r)]
    if not ys:
        return None
    return rows[ys[0]:ys[-1] + 1]


def holes(m):
    """Enclosed background components of a boolean image: [(size, cy)]
    with cy the centre row / height (0 top .. 1 bottom), biggest first."""
    h, w = len(m), len(m[0])
    seen = [[False] * w for _ in range(h)]
    out = []

    def flood(sy, sx):
        st, pts, edge = [(sy, sx)], [], False
        seen[sy][sx] = True
        while st:
            y, x = st.pop()
            pts.append(y)
            if y in (0, h - 1) or x in (0, w - 1):
                edge = True
            for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                yy, xx = y + dy, x + dx
                if 0 <= yy < h and 0 <= xx < w and not seen[yy][xx] and \
                        not m[yy][xx]:
                    seen[yy][xx] = True
                    st.append((yy, xx))
        return pts, edge
    for y in range(h):
        for x in range(w):
            if not m[y][x] and not seen[y][x]:
                pts, edge = flood(y, x)
                if not edge:
                    out.append((len(pts), (sum(pts) / float(len(pts)) + 0.5)
                                / h))
    minsz = max(2, int(T.GLYPH_HOLE_MIN_FRAC * h * w))
    return sorted([o for o in out if o[0] >= minsz], reverse=True)


def aspect(m):
    return len(m[0]) / float(len(m))


def stem_range(m):
    """How much the left edge of the ink moves over the middle 70 % of the
    rows, as a share of the width (B: ~0, 8: large); None if unmeasurable."""
    h, w = len(m), len(m[0])
    if h < 8 or w < 3:
        return None
    lo, hi = int(0.15 * h), int(math.ceil(0.85 * h))
    xs = []
    for y in range(lo, hi):
        r = m[y]
        for x in range(w):
            if r[x]:
                xs.append(x)
                break
    if len(xs) < 4:
        return None
    # a straight stem may be slanted (italic): measure the left edge's
    # largest distance from its own least-squares line
    n = float(len(xs))
    ys = list(range(len(xs)))
    my, mx = sum(ys) / n, sum(xs) / n
    vy = sum((y - my) ** 2 for y in ys)
    k = sum((y - my) * (x - mx) for y, x in zip(ys, xs)) / vy if vy else 0.0
    dev = max(abs(x - (mx + k * (y - my))) for y, x in zip(ys, xs))
    return dev / float(w)


def is_minus_bar(m, seg, digits_h):
    """The first segment of a signed number is a solid horizontal bar at
    the digits' middle (module docstring, 4)."""
    x0, x1 = seg
    rows = [y for y, r in enumerate(m) if any(r[x0:x1])]
    if not rows:
        return False
    y0, y1 = rows[0], rows[-1] + 1
    if rows != list(range(y0, y1)):
        return False                       # two bars ('=') or a broken bar
    bh, bw = y1 - y0, x1 - x0
    ink = sum(1 for y in range(y0, y1) for x in range(x0, x1) if m[y][x])
    if bw < T.BAR_MIN_WIDE * bh or ink < T.BAR_SOLID * bw * bh:
        return False
    mid = (y0 + y1) / 2.0
    H = float(digits_h or len(m))
    return 0.25 * H <= mid <= 0.75 * H


# --------------------------------------------------- expected-set match --
PAIRS = {"O": "0", "0": "O", "6": "9", "9": "6", "B": "8", "8": "B",
         # (v6.16 fix r1, T08B-D12) the capital Q that Vision reads as O / 0:
         # CONFIRM-ONLY (decide_char never returns 'rival' for it)
         "Q": "O"}
Q_RIVALS = "O0"


def _ref_aspect(render, ch):
    if render is None:
        return None
    try:
        g = render(ch)
    except Exception:                                   # noqa: BLE001
        return None
    m = _bin(g) if g is not None else None
    return aspect(m) if m else None


def decide_char(m, want, render=None):
    """'expected' | 'rival' | None for ONE character image `m` that should
    be `want` (one of PAIRS)."""
    riv = PAIRS.get(want)
    if riv is None or m is None:
        return None
    if want in "69":
        hs = holes(m)
        if len(hs) != 1:
            return None
        cy = hs[0][1]
        low = cy > T.GLYPH_HOLE_LOW
        high = cy < T.GLYPH_HOLE_HIGH
        if not (low or high):
            return None
        is6 = low
        return "expected" if (want == "6") == is6 else "rival"
    if want in "O0":
        e, r = _ref_aspect(render, want), _ref_aspect(render, riv)
        if not e or not r:
            return None
        span = math.log(r / e)
        if abs(span) < T.GLYPH_ASPECT_MIN_LOG:
            return None
        t = math.log(aspect(m) / e) / span   # 0 = expected, 1 = rival
        q = T.GLYPH_ASPECT_THIRD
        if abs(t) <= q:
            return "expected"
        if abs(t - 1.0) <= q:
            return "rival"
        return None                          # between, or neither shape
    if want == "Q":
        # (v6.16 fix r1, T08B-D12) Q against BOTH its look-alikes O and 0,
        # by the ink box aspect against each rendered in the label's own
        # font (the tail makes Q taller than O, the bowl wider than 0): the
        # crop must sit within a third of the smaller log-distance of its
        # own reference; the references must differ by GLYPH_Q_MIN_LOG.
        # CONFIRM-ONLY: a crop that is not Q is undecided (None), never
        # 'rival' -- the rule can resolve a look-alike read, never fail one
        e = _ref_aspect(render, "Q")
        rs = [_ref_aspect(render, c) for c in Q_RIVALS]
        if not e or not all(rs):
            return None
        span = min(abs(math.log(r / e)) for r in rs)
        if span < T.GLYPH_Q_MIN_LOG:
            return None
        d = abs(math.log(aspect(m) / e))
        return "expected" if d <= T.GLYPH_ASPECT_THIRD * span else None
    if want in "B8":
        s = stem_range(m)
        if s is None:
            return None
        isB = s <= T.GLYPH_STEM_FLAT
        is8 = s >= T.GLYPH_STEM_CURVED
        if not (isB or is8):
            return None
        return "expected" if (want == "B") == isB else "rival"
    return None


def decide_glyphs(crop, text, render=None):
    """Per-character expected-set decision on a label crop.
    -> {"segments": n, "chars": [(index, char, decision)], "verdict":
    'expected' | 'rival' | None}. verdict 'rival' when any decided
    character is its look-alike; 'expected' when every PAIRS character is
    decided 'expected'; None otherwise (or when the crop does not split
    into one segment per visible character)."""
    vis = fold_read(text).replace("-", MINUS) if text else ""
    segs, m = segments(crop) if crop is not None else ([], None)
    res = {"segments": len(segs), "chars": [], "verdict": None}
    idx = [i for i, ch in enumerate(vis) if ch in PAIRS]
    if not idx or m is None or len(segs) != len(vis):
        return res
    dec = []
    for i in idx:
        sub = _sub(m, *segs[i])
        d = decide_char(sub, vis[i], render)
        dec.append(d)
        res["chars"].append((i, vis[i], d))
    if "rival" in dec:
        res["verdict"] = "rival"
    elif all(d == "expected" for d in dec):
        res["verdict"] = "expected"
    return res


def glyph_crop(display, box, font_size):
    """The label's own ink for the shape decision: the display cropped with
    a pad of GLYPH_PAD_EM * font size around the approved box (a WIDER
    glyph than the approved one -- a letter O printed for a digit 0 -- is
    not cut by the approved box), keeping the ink components (8-connected)
    that reach into the approved box. None (no decision) when such a
    component reaches the padded crop's edge (the label's ink is joined to
    a stroke) or nothing is left."""
    from .raster import Gray
    try:
        fs = float(font_size)
    except (TypeError, ValueError):
        fs = 12.0
    pad = T.GLYPH_PAD_EM * fs
    big = display.crop(box, pad=pad)
    if big is None:
        return None
    bx0, by0, bx1, by1 = display.to_px((box[0] - pad, box[1] - pad,
                                        box[2] + pad, box[3] + pad))
    cx0, cy0, cx1, cy1 = display.to_px(box)
    ox, oy = max(0, int(bx0)), max(0, int(by0))
    core = (cx0 - ox, cy0 - oy, cx1 - ox, cy1 - oy)
    b = big.binarise()
    h, w = b.h, b.w
    ink = [[v < 128 for v in r] for r in b.rows]
    seen = [[False] * w for _ in range(h)]
    keep = [[False] * w for _ in range(h)]
    for y in range(h):
        for x in range(w):
            if not ink[y][x] or seen[y][x]:
                continue
            st, pts = [(y, x)], []
            seen[y][x] = True
            while st:
                yy, xx = st.pop()
                pts.append((yy, xx))
                for dy in (-1, 0, 1):
                    for dx in (-1, 0, 1):
                        y2, x2 = yy + dy, xx + dx
                        if 0 <= y2 < h and 0 <= x2 < w and ink[y2][x2] \
                                and not seen[y2][x2]:
                            seen[y2][x2] = True
                            st.append((y2, x2))
            inside = any(core[0] <= px + 0.5 <= core[2] and
                         core[1] <= py + 0.5 <= core[3] for py, px in pts)
            if not inside:
                continue
            if any(py in (0, h - 1) or px in (0, w - 1) for py, px in pts):
                return None
            for py, px in pts:
                keep[py][px] = True
    if not any(any(r) for r in keep):
        return None
    rows = [bytes(0 if v else 255 for v in r) for r in keep]
    return Gray(w, h, rows)


def split_signed(crop):
    """(bar ok, digits Gray) for a signed-number crop: the first column
    segment must be the minus bar; the digits are the rest of the crop."""
    segs, m = segments(crop)
    if m is None or len(segs) < 2:
        return False, None
    rest = [r[segs[1][0]:] for r in m]
    ys = [y for y, r in enumerate(rest) if any(r)]
    dh = (ys[-1] - ys[0] + 1) if ys else len(m)
    # the bar's middle is measured against the digits' own rows
    sub = [r for r in m[ys[0]:ys[-1] + 1]] if ys else m
    ok = is_minus_bar(sub, segs[0], dh)
    from .raster import Gray
    rows = [bytes(0 if v else 255 for v in r[segs[1][0]:]) for r in m]
    return ok, Gray(len(rows[0]), len(rows), rows)


def text_renderer(el_attrs, scale):
    """A function ch -> Gray of `ch` alone, rendered by MuPDF with the
    label's font attributes at the display's scale (None without MuPDF)."""
    from . import raster as R
    if not R.available():
        return None
    a = el_attrs or {}
    fs = a.get("font-size", "12")
    try:
        size = float(fs)
    except ValueError:
        size = 12.0
    attrs = []
    for k in ("font-family", "font-style", "font-weight"):
        if a.get(k):
            attrs.append('%s="%s"' % (k, a[k].replace('"', "'")))
    W, H = size * 4.0, size * 2.0

    def render(ch):
        svg = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %s %s" '
               'width="%s" height="%s"><text x="%s" y="%s" font-size="%s" %s>'
               '%s</text></svg>' % (W, H, W, H, size, size * 1.4, size,
                                    " ".join(attrs), ch))
        pm = R.gray_pixmap(svg, scale)
        return R.sub_pixmap(pm, 0, 0, pm.width, pm.height)
    return render
