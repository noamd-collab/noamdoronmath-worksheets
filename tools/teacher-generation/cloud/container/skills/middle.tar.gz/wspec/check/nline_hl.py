# -*- coding: utf-8 -*-
"""check_highlight for a NUMBER-LINE figure (v6.12), independent of the
renderer: it reads the base SVG, the highlighted SVG and the checker's own
report of the base figure (rep = nline.check_number_line(...)).

  HIGHLIGHT_EXACT_ELEMENTS        the overlay marks exactly the elements the
                                  checker MEASURED for the object (its dot,
                                  letter, caption; a jump's arc / head /
                                  caption; an interval's bar and ends; the
                                  axis with its ticks and numbers; a span's
                                  piece of the axis) -- HL_MISSING / HL_EXTRA
  HIGHLIGHT_ON_MEASURED_GEOMETRY  each overlay element lies on its element
                                  (a copy of a line / path / polygon, a disk
                                  on a dot, a box hugging a text's ink within
                                  6 px, a span between the measured places)
  HIGHLIGHT_ADDS_NO_MATH          the base figure is unchanged byte for byte
                                  apart from ONE overlay group; the overlay
                                  has no text, no hook, nothing else"""
import math
import re
import xml.etree.ElementTree as ET

from .report import FAIL, PASS, worst

NS = "{http://www.w3.org/2000/svg}"
_GROUP = re.compile(r'<g data-layer="highlight" data-object="([^"]*)">\n'
                    r'(.*?)\n</g>\n', re.S)
OK_ATTRS = {"x1", "y1", "x2", "y2", "cx", "cy", "r", "points", "d", "fill",
            "stroke", "stroke-width", "stroke-linecap", "stroke-linejoin",
            "data-hl", "data-span"}
HUG_PX = 6.0
GEOM_TOL = 0.02
SPAN_TOL = 0.6


def _nums(s):
    return [float(x) for x in re.findall(r"[0-9]+(?:\.[0-9]+)?", s or "")]


def check_highlight(base_svg, hl_svg, rep, object_id):
    out = []

    def fail(code, check, detail):
        out.append({"level": FAIL, "code": code, "check": check,
                    "object": object_id, "detail": detail})
    m = _GROUP.search(hl_svg)
    if m is None:
        fail("HL_NO_OVERLAY", "HIGHLIGHT_ADDS_NO_MATH", "no highlight group")
        return {"status": FAIL, "findings": out}
    if hl_svg[:m.start()] + hl_svg[m.end():] != base_svg:
        fail("HL_FIGURE_CHANGED", "HIGHLIGHT_ADDS_NO_MATH", "the figure is "
             "not byte for byte the base figure around the overlay")
    if len(_GROUP.findall(hl_svg)) != 1:
        fail("HL_EXTRA", "HIGHLIGHT_ADDS_NO_MATH", "more than one overlay")
    obj = m.group(1).replace("&gt;", ">").replace("&lt;", "<").replace(
        "&quot;", '"').replace("&amp;", "&")
    if obj != object_id:
        fail("HL_WRONG_OBJECT", "HIGHLIGHT_EXACT_ELEMENTS", "the overlay is "
             "for %r" % obj)
    try:
        grp = ET.fromstring('<g xmlns="http://www.w3.org/2000/svg">' +
                            m.group(2) + "</g>")
        base = ET.fromstring(base_svg.encode("utf-8"))
    except ET.ParseError as e:
        fail("HL_UNREADABLE", "HIGHLIGHT_ADDS_NO_MATH", str(e))
        return {"status": FAIL, "findings": out}
    els = dict((el.get("id"), el) for el in base.iter() if el.get("id"))
    meas = rep.get("measured") or {}
    want = set((meas.get("elements_of") or {}).get(object_id) or [])
    if not want:
        fail("HL_UNMEASURED", "HIGHLIGHT_EXACT_ELEMENTS", "the checker "
             "measured no element of %s" % object_id)
    got = []
    for ch in list(grp):
        tag = ch.tag.replace(NS, "")
        if tag == "text" or (ch.text or "").strip() or list(ch):
            fail("HL_ADDS_MATH", "HIGHLIGHT_ADDS_NO_MATH", "the overlay "
                 "prints text")
            continue
        extra = set(ch.attrib) - OK_ATTRS
        if extra or tag not in ("line", "circle", "polygon", "path"):
            fail("HL_ADDS_MATH", "HIGHLIGHT_ADDS_NO_MATH", "overlay <%s> %s"
                 % (tag, sorted(extra)))
            continue
        ref = ch.get("data-hl")
        got.append(ref)
        b = els.get(ref)
        if b is None:
            fail("HL_EXTRA", "HIGHLIGHT_EXACT_ELEMENTS", "%r is no element "
                 "of the figure" % ref)
            continue
        btag = b.tag.replace(NS, "")
        span = ch.get("data-span")
        if span is not None:
            _span(ch, b, span.split(" "), meas, fail, ref)
        elif btag == "line" and tag == "line":
            if any(abs(float(ch.get(k)) - float(b.get(k))) > GEOM_TOL
                   for k in ("x1", "y1", "x2", "y2")):
                fail("HL_OFF_GEOMETRY", "HIGHLIGHT_ON_MEASURED_GEOMETRY",
                     "%s: the overlay line is not the element" % ref)
        elif btag == "circle" and tag == "circle":
            if abs(float(ch.get("cx")) - float(b.get("cx"))) > GEOM_TOL or \
                    abs(float(ch.get("cy")) - float(b.get("cy"))) > GEOM_TOL:
                fail("HL_OFF_GEOMETRY", "HIGHLIGHT_ON_MEASURED_GEOMETRY",
                     "%s: the disk is not on the dot" % ref)
        elif btag in ("polygon", "path") and tag == btag:
            k = "points" if tag == "polygon" else "d"
            if _nums(ch.get(k)) != _nums(b.get(k)):
                fail("HL_OFF_GEOMETRY", "HIGHLIGHT_ON_MEASURED_GEOMETRY",
                     "%s: the overlay is not a copy of the element" % ref)
        elif btag == "text" and tag == "polygon":
            ink = (meas.get("boxes") or {}).get(ref)
            v = _nums(ch.get("points"))
            xs, ys = v[0::2], v[1::2]
            if len(xs) != 4 or ink is None:
                fail("HL_OFF_GEOMETRY", "HIGHLIGHT_ON_MEASURED_GEOMETRY",
                     "%s: no box / no measured ink" % ref)
                continue
            bx = (min(xs), min(ys), max(xs), max(ys))
            inside = bx[0] <= ink[0] + 0.3 and bx[1] <= ink[1] + 0.3 and \
                bx[2] >= ink[2] - 0.3 and bx[3] >= ink[3] - 0.3
            hug = max(ink[0] - bx[0], ink[1] - bx[1], bx[2] - ink[2],
                      bx[3] - ink[3]) <= HUG_PX
            if not (inside and hug):
                fail("HL_OFF_GEOMETRY", "HIGHLIGHT_ON_MEASURED_GEOMETRY",
                     "%s: the box does not hug the label's ink" % ref)
        else:
            fail("HL_OFF_GEOMETRY", "HIGHLIGHT_ON_MEASURED_GEOMETRY", "%s: a "
                 "<%s> overlay on a <%s>" % (ref, tag, btag))
    gs = set(got)
    if len(gs) != len(got):
        fail("HL_EXTRA", "HIGHLIGHT_EXACT_ELEMENTS", "an element is marked "
             "twice")
    for r in sorted(want - gs):
        fail("HL_MISSING", "HIGHLIGHT_EXACT_ELEMENTS", "%s of %s is not "
             "highlighted" % (r, object_id))
    for r in sorted(gs - want):
        fail("HL_EXTRA", "HIGHLIGHT_EXACT_ELEMENTS", "%s is highlighted but "
             "is not part of %s" % (r, object_id))
    return {"status": worst([f["level"] for f in out], PASS),
            "findings": out}


def _span(ch, b, ends, meas, fail, ref):
    if b.get("data-nl") != "axis" or ch.tag.replace(NS, "") != "line":
        fail("HL_OFF_GEOMETRY", "HIGHLIGHT_ON_MEASURED_GEOMETRY", "%s: a span "
             "lies on the axis line" % ref)
        return
    pts = []
    for x in ends:
        if x == "0":
            pts.append(meas.get("zero_px"))
        else:
            pts.append((meas.get("places_px") or {}).get(x))
    if None in pts or len(pts) != 2:
        fail("HL_OFF_GEOMETRY", "HIGHLIGHT_ON_MEASURED_GEOMETRY", "%s: span "
             "ends %s are not measured places" % (ref, ends))
        return
    a = (float(ch.get("x1")), float(ch.get("y1")))
    c = (float(ch.get("x2")), float(ch.get("y2")))
    ok = (math.hypot(a[0] - pts[0][0], a[1] - pts[0][1]) <= SPAN_TOL and
          math.hypot(c[0] - pts[1][0], c[1] - pts[1][1]) <= SPAN_TOL) or \
        (math.hypot(a[0] - pts[1][0], a[1] - pts[1][1]) <= SPAN_TOL and
         math.hypot(c[0] - pts[0][0], c[1] - pts[0][1]) <= SPAN_TOL)
    if not ok:
        fail("HL_OFF_GEOMETRY", "HIGHLIGHT_ON_MEASURED_GEOMETRY", "%s: the "
             "span does not run between the measured %s" % (ref, ends))
