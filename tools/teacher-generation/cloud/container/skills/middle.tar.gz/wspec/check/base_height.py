# -*- coding: utf-8 -*-
"""Independent measured licensing of a source-stated dashed base extension.
No renderer, author helper, private placement or private answer is consulted.
"""
import math
import re
import xml.etree.ElementTree as ET

def native_extension_dashes(svg, public, fid, object_map, visible_text):
    def norm(x): return ' '.join(str(x).replace('$', '').split())
    def dist(a,b): return math.hypot(a[0]-b[0],a[1]-b[1])
    def sub(a,b): return (a[0]-b[0],a[1]-b[1])
    def dot(a,b): return a[0]*b[0]+a[1]*b[1]
    def cross(a,b): return a[0]*b[1]-a[1]*b[0]
    try:
        g=next(g for g in public['figures'] if g['id']==fid)
        d=g['base_height']; src=d['source']
        q=next(q for q in public['questions'] if q['id']==g['scope'])
        if set(d)!={'triangle','base','height','perpendicular','extension','source'} or set(src)!={'scope','text'} or src['scope']!=q['id'] or not norm(src['text']) or norm(src['text']) not in norm(q['text']) or norm(src['text']) not in norm(visible_text): return set()
        source_text=' '.join(r.get('text','') for r in [q]+q.get('items',[]))
        if not re.search('הקו המקווקו|בקו מקווקו',source_text) or not re.search('הקו המקווקו|בקו מקווקו',visible_text): return set()
        if object_map.get('figure')!=fid or g.get('figure_accuracy')!='accurate' or any(k in g for k in ('frame','graph','data','loci')): return set()
        facts={f['id']:f for f in public['facts']}; ents={e['id']:e for e in public['entities']}
        fs={k:facts[d[k]] for k in ('base','height','perpendicular','extension')}
        if any(f['role']!='given' or f['item']!=q['id'] or f['source']!={'kind':'stated'} for f in fs.values()): return set()
        bf,hf=fs['base'],fs['height']
        if any(f['rel']!='length' or len(f['args'])!=1 or 'unit' in f or float(f['value'])<=0 for f in (bf,hf)): return set()
        be,he=ents[bf['args'][0]],ents[hf['args'][0]]
        bb,hh,vv=set(be['ends']),set(he['ends']),set(ents[d['triangle']]['vertices'])
        if len(bb)!=2 or len(hh)!=2 or len(vv)!=3 or not bb<vv or hh&vv!=vv-bb or len(hh-vv)!=1: return set()
        foot=next(iter(hh-vv)); apex=next(iter(hh&vv)); near,longid=fs['extension']['args']; far=next(iter(bb-{near}))
        if fs['extension']['rel']!='on_segment' or near not in bb or set(ents[longid]['ends'])!={far,foot}: return set()
        if fs['perpendicular']['rel']!='perpendicular' or set(fs['perpendicular']['args'])!={be['id'],he['id']}: return set()
        ext=next(e['id'] for e in ents.values() if e.get('kind')=='segment' and set(e.get('ends',[]))=={near,foot})
        if not vv|{foot,be['id'],he['id'],ext} <= set(g['entities']): return set()
        parts=object_map['objects'][ext]['parts']
        if len(parts)!=1 or parts[0].get('span')!='whole': return set()
        sid=parts[0]['element']; tree=ET.fromstring(svg)
        els=list(tree.iter())
        if any(any(k in e.attrib for k in ('transform','style')) for e in els): return set()
        byid={e.get('id'):e for e in els if e.get('id')}
        if len(byid)!=sum(bool(e.get('id')) for e in els): return set()
        pts={e.get('data-pt'):(float(e.get('cx')),float(e.get('cy'))) for e in els if e.tag.split('}')[-1]=='circle' and e.get('data-pt')}
        A,B,H,C=(pts[p] for p in (far,near,foot,apex)); ab=sub(B,A); ah=sub(H,A); hc=sub(C,H)
        if min(dist(A,B),dist(B,H),dist(H,C))<2 or abs(cross(ab,ah))>0.05*dist(A,B) or dot(ab,ah)<=dot(ab,ab) or abs(dot(ab,hc))>0.015*dist(A,B)*dist(H,C): return set()
        e=byid[sid]
        if e.tag.split('}')[-1]!='line' or set(re.findall(r"[A-Z][0-9]*'*",e.get('data-seg','')))!={near,foot} or e.get('stroke-dasharray')!='4 3': return set()
        ends=[(float(e.get('x1')),float(e.get('y1'))),(float(e.get('x2')),float(e.get('y2')))]
        if not (dist(ends[0],B)<.05 and dist(ends[1],H)<.05 or dist(ends[1],B)<.05 and dist(ends[0],H)<.05): return set()
        return {sid}
    except (KeyError,ValueError,TypeError,StopIteration,ET.ParseError,IndexError):
        return set()
