# -*- coding: utf-8 -*-
"""Geometry and text checks of one figure against the PUBLIC spec. Every
finding names the acceptance check (acceptance/corpus.json check_catalog)
it belongs to and the object(s) it concerns."""
import math

from . import geom as G
from . import tol as T
from . import spec as SP
from .dialect import split_names


class Piece(object):
    """A drawn straight piece: a line element (segment / line / ray) or a
    stroked polygon's side."""

    def __init__(self, p, q, kind, names, ref):
        self.p, self.q, self.kind, self.names, self.ref = p, q, kind, names, ref

    @property
    def pq(self):
        return (self.p, self.q)


class Label(object):
    def __init__(self, el):
        self.el, self.ref = el, el.ref
        self.target = el.a.get("data-for")
        self.text = el.text or ""
        self.x, self.y = el.pts[0] if el.pts else (0.0, 0.0)
        self.fs = float(el.a.get("font-size") or 12)
        self.anchor = el.a.get("text-anchor", "start")
        self.box = self.est_box()
        self.box_from = "estimate"

    def est_box(self):
        w = T.GLYPH_W * self.fs * max(1, len(self.text))
        x0 = {"start": self.x, "middle": self.x - w / 2.0,
              "end": self.x - w}.get(self.anchor, self.x)
        return (x0, self.y - T.GLYPH_H * self.fs, x0 + w,
                self.y + T.GLYPH_D * self.fs)


class FigureCheck(object):
    def __init__(self, drawing, fspec, findings, ink_boxes=None,
                 full_boxes=None, ink=None):
        self.dr, self.fs, self.F = drawing, fspec, findings
        self.ink = ink or {}                 # ref -> ink pixel centres
        self.ink_boxes = ink_boxes or {}     # ref -> ink box on the canvas
        self.full_boxes = full_boxes or {}   # ref -> ink box incl. off-canvas
        self.pts, self.pt_ref = {}, {}
        self.pieces, self.marks, self.labels, self.polys = [], [], [], []
        self.reader = []                     # facts the reader sees
        self.elements_of = {}                # entity id -> set of refs (measured)

    # ------------------------------------------------------------ util ---
    def own(self, eid, ref):
        self.elements_of.setdefault(eid, set()).add(ref)

    def P(self, name):
        return self.pts.get(name)

    def fail(self, code, check, detail, obj=None):
        self.F.fail(code, check, detail, obj)

    def review(self, code, check, detail, obj=None):
        self.F.review(code, check, detail, obj)

    def seg_of(self, eid):
        """The two drawn end positions of a segment / line / ray entity."""
        ns = self.fs.points_of(eid)
        if len(ns) >= 2 and self.P(ns[0]) and self.P(ns[-1]):
            return self.P(ns[0]), self.P(ns[-1])
        return None

    def on_piece(self, c, tol=T.ON_TOL_PX):
        return [pc for pc in self.pieces if G.seg_dist(c, pc.p, pc.q) <= tol]

    # ------------------------------------------------------------ run ----
    def run(self):
        dr = self.dr
        for code, detail in dr.issues:
            chk = "NO_ANSWER_ANYWHERE_SVG" if code == "CHK_DIALECT_ID" \
                else "DIALECT_CLOSED"
            self.fail(code, chk, detail)
        if dr.issues:
            return
        self.reader_facts()
        self.collect()
        self.check_entities()
        self.check_facts()
        self.check_marks()
        self.check_extensions()             # v6.17 (V4)
        self.check_labels()
        self.check_constructions()
        self.check_clines()
        self.elements_of = dict((e, self.measured_elements(e))
                                for e in self.scope_objects())

    # ------------------------------------------ what draws each object ---
    def scope_objects(self):
        """Every object a scenario may name on this figure: its entities,
        what its marks / captions / polygons draw, and the objects of the
        facts it draws and of the items that use it (targets included)."""
        fs = self.fs
        out = set(fs.entities) | set(self.extra_objects())
        facts = list(fs.draws) + list(fs.targets)
        for it in fs.items:
            facts += [fs.facts[u] for u in it.get("uses") or []
                      if u in fs.facts]
        results = set()
        for f in facts:
            args = f.get("args") or []
            if (f.get("rel") or "").startswith("construct"):
                results.add(args[0] if args else None)   # not drawn: the task
            for a in args:
                out.add(a)
        out -= results
        cand = sorted(e for e in out if fs.kind(e) in SP.PLANE_KINDS and
                      fs.points_of(e) and
                      all(n in self.pts for n in fs.points_of(e)))
        # (pilot_build) an object whose points are drawn but a side / arm
        # is NOT (the sheet's figure leaves BD out; the student draws it)
        # cannot be highlighted: it is reported NOT DRAWN (REVIEW for that
        # object), not required of the map
        self.not_drawn = sorted(e for e in cand if not self.spans_drawn(e))
        # (v6.10 fix r1, L2) ... unless every span it lacks is a segment the
        # STUDENT draws (a construct_join result of this figure's items:
        # 'ME = ½BC' -- ∠CME has the arm ME only after the student draws
        # it). Not a gap of the figure: a note, never a REVIEW
        self.after_construction = sorted(
            e for e in self.not_drawn if self._missing_are(e, results))
        return [e for e in cand if e not in self.not_drawn]

    def _missing_are(self, eid, results):
        fs = self.fs
        k = fs.kind(eid)
        ns = fs.points_of(eid)
        if k == "segment":
            spans = [(ns[0], ns[1])]
        elif k == "angle":
            spans = [(ns[1], ns[0]), (ns[1], ns[2])]
        elif k == "polygon":
            spans = [(ns[i], ns[(i + 1) % len(ns)]) for i in range(len(ns))]
        else:
            return False
        miss = [(a, b) for a, b in spans
                if not self.cover(self.P(a), self.P(b))[0]]
        return bool(miss) and all(SP.seg_id(a, b) in results
                                  for a, b in miss)

    def spans_drawn(self, eid):
        """Every straight span of the object (a segment, an angle's two
        arms, a polygon's sides) is covered by drawn pieces; a line / ray
        has its own piece. Points are not asked here."""
        fs = self.fs
        k = fs.kind(eid)
        ns = fs.points_of(eid)
        if any(n not in self.pts for n in ns):
            return False
        if k == "segment":
            spans = [(ns[0], ns[1])]
        elif k == "angle":
            spans = [(ns[1], ns[0]), (ns[1], ns[2])]
        elif k == "polygon":
            spans = [(ns[i], ns[(i + 1) % len(ns)]) for i in range(len(ns))]
        elif k in ("line", "ray"):
            idf = {"line": SP.line_id, "ray": SP.ray_id}[k]
            return any(pc.kind == k and idf(*pc.names) == eid
                       for pc in self.pieces)
        else:
            return True
        return all(self.cover(self.P(a), self.P(b))[0] for a, b in spans)

    def measured_elements(self, eid):
        """The elements that draw an object, found on the drawing alone:
        point = its dot + its name label; segment = the straight pieces
        covering it + its marks + its caption; line / ray = its piece;
        angle = the pieces covering both arms + its marks + its caption;
        polygon = its polygon element + the pieces covering its sides + its
        caption."""
        fs = self.fs
        k = fs.kind(eid)
        ns = fs.points_of(eid)
        out = set()
        if k == "point":
            if eid in self.pt_ref:
                out.add(self.pt_ref[eid])
            out.update(l.ref for l in self.labels if l.target == eid)
            return out
        if any(n not in self.pts for n in ns):
            return out
        spans = []
        if k == "segment":
            spans = [(ns[0], ns[1])]
        elif k == "angle":
            spans = [(ns[1], ns[0]), (ns[1], ns[2])]
        elif k == "polygon":
            spans = [(ns[i], ns[(i + 1) % len(ns)]) for i in range(len(ns))]
            out.update(p["ref"] for p in self.polys if p["id"] == eid)
        elif k in ("line", "ray"):
            idf = {"line": SP.line_id, "ray": SP.ray_id}[k]
            out.update(pc.ref for pc in self.pieces
                       if pc.kind == k and idf(*pc.names) == eid)
        for a, b in spans:
            ok, used = self.cover(self.P(a), self.P(b))
            if ok:
                out.update(pc.ref for pc in used)
        out.update(m["ref"] for m in self.marks if m.get("obj") == eid)
        out.update(l.ref for l in self.labels
                   if " " in l.target and self.label_obj(l) == eid)
        return out

    def reader_facts(self):
        fs = self.fs
        order = []
        for q in fs.spec.get("questions") or []:
            order.append((q["id"], [q["id"]] + [it["id"] for it in
                                                q.get("items") or []]))
        vis = set()
        for qid, scopes in order:
            if fs.fig["scope"] in scopes:
                vis = set(scopes[:scopes.index(fs.fig["scope"]) + 1])
        drawn = set(f["id"] for f in fs.draws)
        self.reader = [f for f in fs.facts.values()
                       if f["id"] in drawn or
                       (f.get("item") in vis and
                        f.get("role") in ("given", "context"))]
        if "state_change" in fs.fig:
            from . import figure_state
            try:
                obsolete = figure_state.obsolete_height(fs.spec, fs.fig)
            except (ValueError, KeyError, TypeError, IndexError, AttributeError, ZeroDivisionError):
                self.fail("CHK_STATE_SOURCE", "FIGURE_STATE_SOURCE",
                          "new-position reader context is not bound to its public source")
                obsolete = set()  # malformed metadata cannot hide any fact
            self.reader = [f for f in self.reader if f["id"] not in obsolete]
        for f in fs.facts.values():
            if f["id"] in drawn and f.get("rel") not in SP.SUPPORTED_RELS:
                self.review("CHK_UNSUPPORTED_FACT", "DIALECT_CLOSED",
                            "the figure draws %s (%s): outside the plane "
                            "geometry this checker measures" % (f["id"],
                                                                f["rel"]))
        for eid in fs.entities:
            k = fs.kind(eid)
            if k not in SP.PLANE_KINDS:
                self.review("CHK_UNSUPPORTED_ENTITY", "DIALECT_CLOSED",
                            "entity %s of kind %s is not measured" % (eid, k),
                            eid)

    # ------------------------------------------------------- collect -----
    def collect(self):
        fs = self.fs
        figents = set(fs.entities)
        fig_pts = set(e for e in figents if fs.kind(e) == "point")
        rd = None
        from .dialect import DialectReader
        rd = DialectReader()
        for el in self.dr.elements:
            k, v = el.hook if el.hook else (None, None)
            if k == "data-pt":
                if v in self.pts:
                    self.fail("CHK_HOOK_DUP", "PT_POSITION",
                              "point %s drawn twice (%s)" % (v, el.ref), v)
                if v not in fig_pts:
                    self.fail("CHK_HOOK_UNKNOWN", "PT_POSITION",
                              "%s draws point %s, which the figure does not "
                              "show" % (el.ref, v), v)
                self.pts[v] = el.pts[0]
                self.pt_ref[v] = el.ref
                self.own(v, el.ref)
        for el in self.dr.elements:
            k, v = el.hook if el.hook else (None, None)
            if k in ("data-seg", "data-line", "data-ray"):
                a, b = split_names(v)
                kind = {"data-seg": "seg", "data-line": "line",
                        "data-ray": "ray"}[k]
                eid = {"seg": SP.seg_id, "line": SP.line_id,
                       "ray": SP.ray_id}[kind](a, b)
                self.pieces.append(Piece(el.pts[0], el.pts[1], kind, (a, b),
                                         el.ref))
                self.check_hook_piece(el, kind, a, b, eid, figents)
            elif k == "data-poly":
                self.check_hook_poly(el, v, figents)
            elif k == "data-mark":
                kind, cnt, names = rd.parse_mark(v)
                self.marks.append({"kind": kind, "cnt": cnt, "names": names,
                                   "ref": el.ref, "pts": el.pts, "el": el,
                                   "obj": SP.ang_id(*names) if len(names) == 3
                                   else SP.seg_id(*names)})
            elif el.tag == "text":
                lab = Label(el)
                if el.ref in self.full_boxes:
                    lab.box = self.full_boxes[el.ref]
                    lab.box_from = "raster"
                self.labels.append(lab)
        for name in sorted(fig_pts):
            if name not in self.pts:
                self.fail("CHK_PT_UNDRAWN", "PT_POSITION",
                          "point %s of the figure is not drawn" % name, name)

    def poly_sides_eids(self, names):
        n = len(names)
        return [SP.seg_id(names[i], names[(i + 1) % n]) for i in range(n)]

    def check_hook_piece(self, el, kind, a, b, eid, figents):
        fs = self.fs
        sides = set()
        for e in figents:
            if fs.kind(e) == "polygon":
                sides.update(self.poly_sides_eids(fs.points_of(e)))
        chk = {"seg": "SEG_ENDS_MATCH", "line": "LINE_THROUGH_POINTS",
               "ray": "RAY_FROM_THROUGH"}[kind]
        if eid not in figents and not (kind == "seg" and eid in sides):
            self.fail("CHK_HOOK_UNKNOWN", chk, "%s draws %s, which the figure "
                      "does not show (a drawing shows exactly the given + "
                      "shown)" % (el.ref, eid), eid)
        A, B = self.P(a), self.P(b)
        if A is None or B is None:
            self.fail("CHK_HOOK_POINT_UNDRAWN", chk, "%s: %s names a point "
                      "that is not drawn" % (el.ref, eid), eid)
            return
        p, q = el.pts
        if kind == "seg":
            ok = (G.d(p, A) <= T.PT_TOL_PX and G.d(q, B) <= T.PT_TOL_PX) or \
                 (G.d(p, B) <= T.PT_TOL_PX and G.d(q, A) <= T.PT_TOL_PX)
            if not ok:
                self.fail("CHK_SEG_ENDS", chk, "%s: segment %s%s ends at %s, "
                          "%s, not at its points %s, %s" % (el.ref, a, b, p, q,
                                                            A, B), eid)
        else:
            for nm, X in ((a, A), (b, B)):
                if G.line_dist(X, p, q) > T.ON_TOL_PX:
                    self.fail("CHK_LINE_OFF_POINT", chk, "%s: %s does not "
                              "pass through %s" % (el.ref, eid, nm), eid)
            ta, tb = G.param(A, p, q), G.param(B, p, q)
            L = G.d(p, q)
            if kind == "line":
                lo, hi = min(ta, tb) * L, (1 - max(ta, tb)) * L
                if lo < T.LINE_EXT_MIN_PX or hi < T.LINE_EXT_MIN_PX:
                    self.fail("CHK_LINE_SHORT", "LINE_EXTENDS_PAST_POINTS",
                              "%s: line %s does not run past both points by "
                              "%s px (drawn as a segment?)"
                              % (el.ref, eid, T.LINE_EXT_MIN_PX), eid)
            else:
                # a ray: one end at its first point, past the second
                if G.d(p, A) <= T.PT_TOL_PX:
                    t_through = tb
                elif G.d(q, A) <= T.PT_TOL_PX:
                    t_through = 1 - tb
                else:
                    t_through = None
                if t_through is None:
                    self.fail("CHK_RAY_FROM", "RAY_FROM_THROUGH", "%s: ray %s "
                              "does not start at %s" % (el.ref, eid, a), eid)
                elif t_through <= 0:
                    self.fail("CHK_RAY_DIRECTION", "RAY_DIRECTION", "%s: ray %s"
                              " runs away from %s" % (el.ref, eid, b), eid)
                elif (1 - t_through) * L < T.LINE_EXT_MIN_PX:
                    self.fail("CHK_RAY_SHORT", "RAY_NOT_SEGMENT_OR_LINE",
                              "%s: ray %s stops at %s (a segment?)"
                              % (el.ref, eid, b), eid)
        self.own(eid, el.ref)

    def check_hook_poly(self, el, v, figents):
        names = split_names(v)
        pid = SP.poly_id(names)
        sides_shown = pid in self.fs.ents and all(
            e in figents for e in self.poly_sides_eids(names))
        if pid not in figents and not sides_shown:
            self.fail("CHK_HOOK_UNKNOWN", "POLY_VERTICES_MATCH", "%s draws %s,"
                      " which the figure does not show" % (el.ref, pid), pid)
        want = [self.P(n) for n in names]
        if None in want:
            self.fail("CHK_HOOK_POINT_UNDRAWN", "POLY_VERTICES_MATCH",
                      "%s: %s names a point that is not drawn" % (el.ref, pid),
                      pid)
            return
        got = el.pts
        ok = False
        if len(got) == len(want):
            n = len(want)
            for s in range(n):
                for sg in (1, -1):
                    if all(G.d(got[i], want[(s + sg * i) % n]) <= T.PT_TOL_PX
                           for i in range(n)):
                        ok = True
        if not ok:
            self.fail("CHK_POLY_VERTICES", "POLY_VERTICES_MATCH", "%s: polygon "
                      "%s vertices are not at its points" % (el.ref, pid), pid)
        filled = el.a.get("fill") != "none"
        stroked = el.a.get("stroke") != "none"
        self.polys.append({"names": names, "pts": want, "ref": el.ref,
                           "filled": filled, "stroked": stroked, "id": pid})
        self.own(pid, el.ref)
        if stroked:
            n = len(names)
            for i in range(n):
                a, b = names[i], names[(i + 1) % n]
                self.pieces.append(Piece(self.P(a), self.P(b), "side", (a, b),
                                         el.ref))

    # ------------------------------------------------------- entities ----
    def cover(self, a, b):
        pcs = [pc.pq for pc in self.pieces]
        ok, used = G.covered(a, b, pcs, T.COLLINEAR_TOL_PX, T.COVER_GAP_PX)
        return ok, [self.pieces[i] for i in used]

    def extra_objects(self):
        """Objects drawn without being listed as figure entities: a polygon
        whose sides are shown, the angle / segment of a mark or caption."""
        out = set(p["id"] for p in self.polys)
        for m in self.marks:
            ns = m["names"]
            out.add(SP.ang_id(*ns) if len(ns) == 3 else SP.seg_id(*ns))
        for lab in self.labels:
            if " " in lab.target:
                out.add(self.label_obj(lab))
        return sorted(out - set(self.fs.entities))

    def check_entities(self):
        fs = self.fs
        for eid in list(fs.entities) + self.extra_objects():
            k = fs.kind(eid)
            ns = fs.points_of(eid)
            if k in ("segment",) and all(self.P(n) for n in ns):
                ok, used = self.cover(self.P(ns[0]), self.P(ns[1]))
                if not ok:
                    self.fail("CHK_SEG_UNDRAWN", "SEG_ENDS_MATCH", "segment %s "
                              "is not drawn" % eid, eid)
                exact = [pc for pc in used if pc.kind in ("seg", "side") and
                         set(pc.names) == set(ns)]
                if ok and not exact:
                    self.F.note("CHK_SEG_PIECE_OF_LONGER",
                                "SEG_PIECE_OF_LONGER_MAPPED",
                                "segment %s is drawn as part of %s" % (
                                    eid, ", ".join(pc.ref for pc in used)),
                                eid)
                for pc in used:
                    self.own(eid, pc.ref)
            elif k == "angle" and all(self.P(n) for n in ns):
                a, v, b = ns
                if not self.P(v):
                    continue
                for arm in (a, b):
                    ok, used = self.cover(self.P(v), self.P(arm))
                    if not ok:
                        self.fail("CHK_ANG_ARM_UNDRAWN", "ANG_ARMS_MATCH",
                                  "angle %s: arm %s%s is not drawn"
                                  % (eid, v, arm), eid)
                    for pc in used:
                        self.own(eid, pc.ref)
                ang = G.angle_deg(self.P(v), self.P(a), self.P(b))
                if not (0.5 < ang < 179.5):
                    self.fail("CHK_ANG_DEGENERATE", "ANG_VERTEX_MATCH",
                              "angle %s measures %.1f deg: no angle to show"
                              % (eid, ang), eid)
            elif k == "polygon" and all(self.P(n) for n in ns):
                for i in range(len(ns)):
                    a, b = ns[i], ns[(i + 1) % len(ns)]
                    ok, used = self.cover(self.P(a), self.P(b))
                    if not ok:
                        self.fail("CHK_POLY_SIDE_UNDRAWN", "POLY_SIDES_MAPPED",
                                  "polygon %s: side %s%s is not drawn"
                                  % (eid, a, b), eid)
                    for pc in used:
                        self.own(eid, pc.ref)
            elif k in ("line", "ray") and all(self.P(n) for n in ns):
                hooked = [pc for pc in self.pieces
                          if pc.kind == k and
                          ({"line": SP.line_id, "ray": SP.ray_id}[k](
                              *pc.names) == eid)]
                if not hooked:
                    self.fail("CHK_LINE_UNDRAWN", "LINE_THROUGH_POINTS" if
                              k == "line" else "RAY_FROM_THROUGH",
                              "%s %s is not drawn as a %s" % (k, eid, k), eid)

    # ---------------------------------------------------------- facts ----
    def check_facts(self):
        fs = self.fs
        lengths = []
        for f in fs.draws:
            rel, args = f.get("rel"), f.get("args") or []
            objs = args
            try:
                if rel == "on_segment":
                    self.fact_on_segment(f, args)
                elif rel == "inside":
                    self.fact_inside(f, args)
                elif rel == "midpoint":
                    self.fact_on_segment(f, args)
                    if fs.accurate:
                        M, (A, B) = self.P(args[0]), self.seg_of(args[1])
                        if G.d(M, G.mid(A, B)) > T.MID_TOL_PX:
                            self.fail("CHK_FACT_MIDPOINT", "PT_POSITION",
                                      "%s is not the middle of %s"
                                      % (args[0], args[1]), objs)
                elif not fs.accurate:
                    continue
                elif rel == "angle_measure":
                    ns = fs.points_of(args[0])
                    m = G.angle_deg(self.P(ns[1]), self.P(ns[0]),
                                    self.P(ns[2]))
                    if f.get("value") not in (None, ""):
                        want = float(SP.C.parse_number(f["value"])[0])
                        if abs(m - want) > T.ANGLE_TOL_DEG:
                            self.fail("CHK_FACT_ANGLE", "ANG_VERTEX_MATCH",
                                      "%s measures %.2f deg, the spec says %s"
                                      % (args[0], m, f["value"]), objs)
                elif rel in ("length", "perimeter", "area"):
                    lengths.append(f)
                elif rel in ("rectangle", "square", "parallelogram", "rhombus",
                             "isosceles", "equilateral", "trapezoid",
                             "isosceles_trapezoid", "right_triangle",
                             "acute_triangle", "obtuse_triangle"):
                    self.fact_shape(f, args[0])
                elif rel in ("linear", "greater"):
                    self.fact_quantities(f, args)
                elif rel == "not_parallel":
                    s1, s2 = self.seg_of(args[0]), self.seg_of(args[1])
                    if G.line_dir_diff(s1[0], s1[1], s2[0], s2[1]) <= \
                            T.PAR_TOL_DEG:
                        self.fail("CHK_FACT_NOT_PARALLEL",
                                  "POLY_SHAPE_MEASURED", "%s and %s are "
                                  "drawn parallel" % tuple(args[:2]), objs)
                elif rel in ("perpendicular", "parallel"):
                    s1, s2 = self.seg_of(args[0]), self.seg_of(args[1])
                    dd = G.line_dir_diff(s1[0], s1[1], s2[0], s2[1])
                    want = 90.0 if rel == "perpendicular" else 0.0
                    if abs(dd - want) > T.PAR_TOL_DEG:
                        self.fail("CHK_FACT_" + rel.upper(), "POLY_SHAPE_MEASURED",
                                  "%s and %s meet at %.2f deg (%s)"
                                  % (args[0], args[1], dd, rel), objs)
                elif rel == "equal_length":
                    l1 = G.d(*self.seg_of(args[0]))
                    l2 = G.d(*self.seg_of(args[1]))
                    if abs(l1 - l2) > T.LEN_REL_TOL * max(l1, l2):
                        self.fail("CHK_FACT_EQUAL_LENGTH", "POLY_SHAPE_MEASURED",
                                  "%s = %.2f px, %s = %.2f px" % (
                                      args[0], l1, args[1], l2), objs)
                elif rel == "equal_angle":
                    m = []
                    for a in args:
                        ns = fs.points_of(a)
                        m.append(G.angle_deg(self.P(ns[1]), self.P(ns[0]),
                                             self.P(ns[2])))
                    if abs(m[0] - m[1]) > T.ANGLE_TOL_DEG:
                        self.fail("CHK_FACT_EQUAL_ANGLE", "ANG_VERTEX_MATCH",
                                  "%s %.2f vs %s %.2f deg" % (args[0], m[0],
                                                              args[1], m[1]),
                                  objs)
            except (TypeError, KeyError, IndexError, ValueError):
                self.review("CHK_FACT_UNMEASURABLE", "POLY_SHAPE_MEASURED",
                            "fact %s could not be measured on the drawing"
                            % f["id"], objs)
        self.fact_scale(lengths)

    def fact_on_segment(self, f, args):
        X = self.P(args[0])
        s = self.seg_of(args[1])
        if X is None or s is None:
            raise KeyError(args[0])
        A, B = s
        t = G.param(X, A, B)
        if G.line_dist(X, A, B) > T.ON_TOL_PX or not (0 < t < 1):
            self.fail("CHK_FACT_ON_SEGMENT", "PT_POSITION", "%s is not on %s "
                      "(%s)" % (args[0], args[1], f["id"]), list(args))

    def fact_inside(self, f, args):
        """(v6.10) the point is inside the polygon, off its sides."""
        X = self.P(args[0])
        ns = self.fs.points_of(args[1])
        P = [self.P(n) for n in ns]
        if X is None or None in P:
            raise KeyError(args[0])
        edge = min(G.seg_dist(X, P[i], P[(i + 1) % len(P)])
                   for i in range(len(P)))
        if not G.in_polygon(X, P) or edge <= T.ON_TOL_PX:
            self.fail("CHK_FACT_INSIDE", "PT_POSITION", "%s is not inside "
                      "%s (%s)" % (args[0], args[1], f["id"]), list(args))

    def _size(self, eid):
        k = self.fs.kind(eid)
        ns = self.fs.points_of(eid)
        P = [self.P(n) for n in ns]
        if None in P or not P:
            raise KeyError(eid)
        if k == "segment":
            return "length", G.d(P[0], P[1])
        if k == "angle":
            return "angle", G.angle_deg(P[1], P[0], P[2])
        if k == "polygon":
            return "area", G.area(P)
        raise KeyError(eid)

    def fact_quantities(self, f, args):
        """(v6.10) a drawn linear / greater relation, measured: lengths to
        LEN_REL_TOL, angles to ANGLE_TOL_DEG per term; a length / area
        constant needs the scale and is not measured."""
        q = [self._size(a) for a in args]
        dim = q[0][0]
        if f["rel"] == "greater":
            tol = T.ANGLE_TOL_DEG if dim == "angle" else \
                T.LEN_REL_TOL * max(q[0][1], q[1][1])
            if q[0][1] - q[1][1] <= tol:
                self.fail("CHK_FACT_GREATER", "POLY_SHAPE_MEASURED",
                          "%s = %.2f is not greater than %s = %.2f" % (
                              args[0], q[0][1], args[1], q[1][1]), args)
            return
        cs = [float(SP.C.parse_exact(c)[0]) for c in f.get("coef") or []]
        rhs = sum(c * v for c, (_d, v) in zip(cs, q[1:]))
        if f.get("value") not in (None, ""):
            if dim != "angle":
                return
            a, b, r = SP.C.parse_exact(f["value"])
            rhs += float(a) + float(b) * math.sqrt(r)
        if dim == "angle":
            bad = abs(q[0][1] - rhs) > T.ANGLE_TOL_DEG * (
                1 + sum(abs(c) for c in cs))
        else:
            tol = T.LEN_REL_TOL * (2 if dim == "area" else 1)
            bad = not rhs or abs(q[0][1] / rhs - 1) > tol
        if bad:
            self.fail("CHK_FACT_LINEAR", "POLY_SHAPE_MEASURED", "%s: %.3f "
                      "drawn vs %.3f" % (f["id"], q[0][1], rhs), args)

    # --------------------------------------------- unnamed constructions --
    def check_clines(self):
        """(v6.10) an unnamed construction result (cline: the line through
        P parallel / perpendicular to a base) the sheet asks for is never
        on the figure: no drawn piece through P along that direction, and
        no second drawn point on that line."""
        fs = self.fs
        for eid, e in sorted(fs.ents.items()):
            if e.get("kind") != "cline":
                continue
            P = self.P(fs.name_of(e.get("through")) or e.get("through"))
            base = self.seg_of(e.get("base"))
            if P is None or base is None:
                continue
            u = G.sub(base[1], base[0])
            if e.get("op") == "perpendicular":
                u = (-u[1], u[0])
            Q = G.add(P, u)
            for pc in self.pieces:
                if G.line_dist(pc.p, P, Q) <= T.COLLINEAR_TOL_PX and \
                        G.line_dist(pc.q, P, Q) <= T.COLLINEAR_TOL_PX and \
                        G.d(pc.p, pc.q) > T.COVER_GAP_PX:
                    self.fail("CHK_CLINE_DRAWN",
                              "CONS_RESULT_NOT_DRAWN_ANY_FORM",
                              "%s (%s) draws %s, the unnamed construction "
                              "the sheet asks for" % (pc.ref, "".join(
                                  pc.names), eid), eid)
            for n, X in sorted(self.pts.items()):
                if G.d(X, P) > T.COVER_GAP_PX and \
                        G.line_dist(X, P, Q) <= T.ON_TOL_PX:
                    self.fail("CHK_CLINE_DRAWN",
                              "CONS_RESULT_NOT_DRAWN_ANY_FORM",
                              "point %s is drawn on %s, the unnamed "
                              "construction the sheet asks for" % (n, eid),
                              eid)

    def fact_shape(self, f, pid):
        ns = self.fs.points_of(pid)
        P = [self.P(n) for n in ns]
        n = len(P)
        rel = f["rel"]
        sides = [G.d(P[i], P[(i + 1) % n]) for i in range(n)]
        angs = [G.angle_deg(P[i], P[i - 1], P[(i + 1) % n]) for i in range(n)]
        bad = []
        if rel in ("rectangle", "square", "parallelogram", "rhombus"):
            if n != 4:
                bad.append("not four vertices")
            else:
                for i in (0, 1):
                    if G.line_dir_diff(P[i], P[i + 1], P[i + 2],
                                       P[(i + 3) % 4]) > T.PAR_TOL_DEG:
                        bad.append("sides %s%s, %s%s not parallel" % (
                            ns[i], ns[i + 1], ns[i + 2], ns[(i + 3) % 4]))
        if rel in ("rectangle", "square"):
            for i, a in enumerate(angs):
                if abs(a - 90.0) > T.ANGLE_TOL_DEG:
                    bad.append("angle at %s = %.2f" % (ns[i], a))
        if rel in ("square", "rhombus", "equilateral"):
            if max(sides) - min(sides) > T.LEN_REL_TOL * max(sides):
                bad.append("sides differ %s" % ["%.2f" % s for s in sides])
        if rel == "isosceles":
            if n != 3 or not any(
                    abs(sides[i] - sides[j]) <= T.LEN_REL_TOL * max(sides)
                    for i in range(3) for j in range(i + 1, 3)):
                bad.append("no two equal sides")
        if rel in ("trapezoid", "isosceles_trapezoid"):
            if n != 4:
                bad.append("not four vertices")
            else:
                par = [G.line_dir_diff(P[i], P[i + 1], P[i + 2],
                                       P[(i + 3) % 4]) <= T.PAR_TOL_DEG
                       for i in (0, 1)]
                if par.count(True) != 1:
                    bad.append("%d pairs of parallel sides"
                               % par.count(True))
                elif rel == "isosceles_trapezoid":
                    legs = (sides[1], sides[3]) if par[0] else \
                        (sides[0], sides[2])
                    if abs(legs[0] - legs[1]) > T.LEN_REL_TOL * max(legs):
                        bad.append("legs differ")
        if rel == "right_triangle" and (n != 3 or min(
                abs(a - 90.0) for a in angs) > T.ANGLE_TOL_DEG):
            bad.append("no right angle")
        if rel == "acute_triangle" and (n != 3 or max(angs) >=
                                        90.0 - T.ANGLE_TOL_DEG):
            bad.append("an angle is not acute")
        # (v6.17-noam V1)
        if rel == "obtuse_triangle" and (n != 3 or max(angs) <=
                                         90.0 + T.ANGLE_TOL_DEG):
            bad.append("no angle is obtuse")
        if bad:
            self.fail("CHK_FACT_SHAPE", "POLY_SHAPE_MEASURED", "%s is drawn "
                      "as no %s: %s" % (pid, rel, "; ".join(bad)), pid)

    def fact_scale(self, facts):
        scales = []
        for f in facts:
            try:
                v = float(SP.C.parse_number(f["value"])[0])
                r = SP.C.parse_number(f["value"])[1]
                v = v * math.sqrt(r)
                # (v6.17, V5) a value in another unit of its dimension is
                # compared in the base unit (1.2 km beside 900 m)
                u = SP.C.canon_unit(f.get("unit")) if f.get("unit") else None
                if u:
                    v = v * float(SP.C.UNITS[u][1])
            except Exception:
                continue
            a = f["args"][0]
            ns = self.fs.points_of(a)
            P = [self.P(n) for n in ns]
            if None in P or not v:
                continue
            if f["rel"] == "length":
                px = G.d(P[0], P[1])
            elif f["rel"] == "perimeter":
                px = sum(G.d(P[i], P[(i + 1) % len(P)]) for i in range(len(P)))
            else:
                px = math.sqrt(G.area(P))
                v = math.sqrt(v)
            scales.append((px / v, f))
        for s, f in scales[1:]:
            s0, f0 = scales[0]
            if abs(s - s0) > T.LEN_REL_TOL * max(s, s0):
                self.fail("CHK_FACT_SCALE", "POLY_SHAPE_MEASURED",
                          "%s and %s are drawn at different scales (%.3f vs "
                          "%.3f px per unit)" % (f0["id"], f["id"], s0, s),
                          [f0["args"][0], f["args"][0]])

    # ---------------------------------------------------------- marks ----
    def check_marks(self):
        right, eq, par = self.claims()
        groups = {}
        for m in self.marks:
            a = self.mark_geometry(m)
            if not a:
                continue
            groups.setdefault((m["kind"], m["cnt"]), []).append(m)
        for (kind, cnt), ms in sorted(groups.items()):
            if kind == "right":
                for m in ms:
                    a, v, b = m["names"]
                    if not self.right_claimed(a, v, b, right):
                        self.fail("CHK_MARK_UNSUPPORTED", "RIGHT_MARK_IF_ANY",
                                  "%s: a right-angle mark on %s%s%s, which no "
                                  "fact the reader sees makes 90 deg (it "
                                  "would tell more than the given)"
                                  % (m["ref"], a, v, b), m["obj"])
                continue
            objs = sorted(set(m["obj"] for m in ms))
            chk = {"arc": "ANG_ARC_GEOMETRY_IF_ANY", "tick": "SEG_TICKS_IF_ANY"
                   }.get(kind, "PARALLEL_ARROWS_IF_ANY")
            if kind not in ("arc", "tick"):
                dirs = [m["dir"] for m in ms if m.get("dir")]
                for d2 in dirs[1:]:
                    if G.dot(dirs[0], d2) <= 0:
                        self.fail("CHK_ARROW_DIRECTION", chk, "parallel arrows "
                                  "%s do not all point the same way" %
                                  "+".join(m["ref"] for m in ms), objs)
                        break
            if len(objs) == 1:
                o = objs[0]
                if kind == "arc" and any(
                        f.get("rel") == "angle_measure" and
                        f["args"][0] == o and f.get("value") not in (None, "")
                        for f in self.reader):
                    continue
                self.review("CHK_MARK_UNEXPLAINED", chk, "%s: a lone %s mark "
                            "on %s claims nothing the reader sees"
                            % (ms[0]["ref"], kind, o), o)
                continue
            rel = par if kind not in ("arc", "tick") else eq
            for o in objs[1:]:
                if rel.find(o) != rel.find(objs[0]):
                    self.fail("CHK_MARK_UNSUPPORTED", chk, "marks %s claim %s "
                              "%s %s, which no fact the reader sees says "
                              "(it would tell more than the given)" % (
                                  "+".join(m["ref"] for m in ms), objs[0],
                                  "parallel to" if rel is par else "=", o),
                              objs)
            if self.fs.accurate and kind not in ("arc", "tick"):
                segs = [self.seg_of(o) for o in objs]
                if None not in segs and any(
                        G.line_dir_diff(segs[0][0], segs[0][1], s2[0], s2[1])
                        > T.PAR_TOL_DEG for s2 in segs[1:]):
                    self.fail("CHK_MARK_MEASURE", chk, "marked parallel but "
                              "the drawn directions differ: %s" % objs, objs)
            if self.fs.accurate:
                vals = [self.measure_obj(o) for o in objs]
                if kind in ("arc", "tick") and None not in vals:
                    tolv = T.ANGLE_TOL_DEG if kind == "arc" else \
                        T.LEN_REL_TOL * max(vals)
                    if max(vals) - min(vals) > tolv:
                        self.fail("CHK_MARK_MEASURE", chk, "marked equal but "
                                  "measured %s" % ["%.2f" % v for v in vals],
                                  objs)

    # ----------------------------- v6.17 (V4): the height outside -------
    def _drawn_polys(self):
        """[(polygon id, vertex names)] of the public spec the drawing shows:
        every vertex drawn, every side covered by drawn pieces"""
        out = []
        for eid in sorted(self.fs.ents):
            e = self.fs.ents[eid]
            if e.get("kind") != "polygon" or e.get("tag") is not None:
                continue
            vs = list(e.get("vertices") or [])
            n = len(vs)
            if n < 3 or not all(self.P(v) for v in vs):
                continue
            if all(self.cover(self.P(vs[i]), self.P(vs[(i + 1) % n]))[0]
                   for i in range(n)):
                out.append((eid, vs))
        # a triangle the reader is told has an OBTUSE angle (a given angle
        # of more than 90 deg, arm-vertex-arm), drawn by its three sides,
        # also when the public model lists no polygon for it
        have = set(frozenset(vs) for _e, vs in out)
        for f in self.reader:
            if f.get("rel") != "angle_measure" or \
                    f.get("value") in (None, ""):
                continue
            ns = self.fs.points_of((f.get("args") or [None])[0])
            try:
                a0, b0, r0 = SP.C.parse_exact(f["value"])
                big = float(a0) + float(b0) * r0 ** 0.5 > 90.0
            except Exception:                           # noqa: BLE001
                continue
            if len(ns) != 3 or not big or frozenset(ns) in have or \
                    not all(self.P(v) for v in ns):
                continue
            vs = [ns[0], ns[1], ns[2]]
            if all(self.cover(self.P(vs[i]), self.P(vs[(i + 1) % 3]))[0]
                   for i in range(3)):
                have.add(frozenset(vs))
                out.append((SP.poly_id(vs), vs))
        return out

    def _obtuse_at(self, vs):
        """the vertices of polygon vs at which its angle is obtuse: a given
        value the reader sees (> 90), or -- an accurate figure -- measured"""
        out = set()
        n = len(vs)
        for i, v in enumerate(vs):
            a, b = vs[i - 1], vs[(i + 1) % n]
            aid = SP.ang_id(a, v, b)
            for f in self.reader:
                if f.get("rel") == "angle_measure" and \
                        (f.get("args") or [None])[0] == aid and \
                        f.get("value") not in (None, ""):
                    try:
                        a0, b0, r0 = SP.C.parse_exact(f["value"])
                        if float(a0) + float(b0) * r0 ** 0.5 > 90.0:
                            out.add(v)
                    except Exception:           # noqa: BLE001
                        pass
            if self.fs.accurate and self.P(a) and self.P(v) and self.P(b) \
                    and G.angle_deg(self.P(v), self.P(a), self.P(b)) > \
                    90.0 + T.ANGLE_TOL_DEG:
                out.add(v)
        return out

    def check_extensions(self):
        """(v6.17, BRIEF_V617 V4) THE HEIGHT OF AN OBTUSE TRIANGLE FALLS
        OUTSIDE IT (G7-T19 a/b/c q7). Read from the drawing:
          * a drawn point H on the LINE of a side XY of a drawn TRIANGLE but
            outside the side, joined by a drawn piece to the opposite vertex
            Q at a right angle to XY (measured on an accurate figure, or a
            right-angle mark at H), is the FOOT OF AN OUTSIDE HEIGHT -- unless
            H is a corner of a drawn polygon or another drawn object runs
            on past H along that line (a diagonal, a longer side: H is a
            point of it, v6.16.2 G9-T18 a q12 / q15, not an extension's end).
            Then the extension from the nearer end E to H must be drawn
            (CHK_EXT_MISSING), every piece of it DASHED (CHK_EXT_SOLID), the
            side XY itself solid (CHK_BASE_DASHED), and the right-angle mark
            must sit at the foot H (CHK_FOOT_NO_RIGHT_MARK);
          * a right-angle mark at a point H strictly INSIDE a side XY whose
            arm goes to the opposite vertex, while the polygon's angle at X
            or Y is obtuse (a given > 90, or measured on an accurate
            figure), draws the height INSIDE an obtuse triangle -- its true
            foot is outside (CHK_HEIGHT_INSIDE_OBTUSE).
        Findings are charged to the catalog checks POLY_SHAPE_MEASURED /
        RIGHT_MARK_IF_ANY (no new catalog check)."""
        el_of = dict((el.ref, el) for el in self.dr.elements)

        def dashed(pc):
            el = el_of.get(pc.ref)
            return el is not None and "stroke-dasharray" in el.a

        rights = [m for m in self.marks if m["kind"] == "right" and
                  len(m["names"]) == 3]
        polys = self._drawn_polys()
        corners = set(v for _p, vs in polys for v in vs)
        tri = [(p, vs) for p, vs in polys if len(vs) == 3]
        for pid, vs in tri:
            obtuse = self._obtuse_at(vs)
            for i in range(3):
                X, Y, Q = vs[i], vs[(i + 1) % 3], vs[(i + 2) % 3]
                pX, pY, pQ = self.P(X), self.P(Y), self.P(Q)
                L_ = G.d(pX, pY)
                if L_ <= 0:
                    continue
                for H in sorted(self.pts):
                    if H in corners:
                        continue
                    pH = self.P(H)
                    if G.line_dist(pH, pX, pY) > T.ON_TOL_PX or \
                            not self.cover(pQ, pH)[0]:
                        continue
                    t = G.param(pH, pX, pY)
                    inside = T.ON_TOL_PX / L_ < t < 1 - T.ON_TOL_PX / L_
                    outside = t < -T.ON_TOL_PX / L_ or \
                        t > 1 + T.ON_TOL_PX / L_
                    marked = [m for m in rights if m["names"][1] == H and
                              Q in (m["names"][0], m["names"][2])]
                    if inside and marked and (X in obtuse or Y in obtuse):
                        self.fail(
                            "CHK_HEIGHT_INSIDE_OBTUSE", "RIGHT_MARK_IF_ANY",
                            "%s: the height from %s to %s%s is drawn to %s "
                            "INSIDE the side, but %s is obtuse at %s: its "
                            "foot lies outside, on the extension of %s%s"
                            % (marked[0]["ref"], Q, X, Y, H, pid,
                               sorted(set([X, Y]) & obtuse)[0], X, Y),
                            SP.seg_id(Q, H))
                        continue
                    if not outside:
                        continue
                    E = Y if t > 1 else X
                    pE = self.P(E)
                    far = pX if E == Y else pY
                    square = abs(G.angle_deg(pH, pQ, far) - 90) <= \
                        T.ANGLE_TOL_DEG
                    if not ((self.fs.accurate and square) or marked):
                        continue
                    LEH = G.d(pE, pH)
                    over, past = [], False
                    for pc in self.pieces:
                        if G.line_dist(pc.p, pE, pH) > T.ON_TOL_PX or \
                                G.line_dist(pc.q, pE, pH) > T.ON_TOL_PX:
                            continue
                        t1, t2 = sorted((G.param(pc.p, pE, pH) * LEH,
                                         G.param(pc.q, pE, pH) * LEH))
                        if t2 > LEH + T.ON_TOL_PX and \
                                t1 < LEH - T.ON_TOL_PX:
                            past = True         # another object runs on
                        elif min(t2, LEH) - max(t1, 0.0) > T.COVER_GAP_PX:
                            over.append(pc)
                    if past:
                        continue                # H lies on another object
                    ok, _used = self.cover(pE, pH)
                    if not ok:
                        self.fail(
                            "CHK_EXT_MISSING", "POLY_SHAPE_MEASURED",
                            "the height %s%s falls outside %s: the extension "
                            "%s%s of the side %s%s to its foot is not drawn "
                            "(the foot floats off the base)"
                            % (Q, H, pid, E, H, X, Y), SP.seg_id(E, H))
                    solid = [pc.ref for pc in over if not dashed(pc)]
                    if solid:
                        self.fail(
                            "CHK_EXT_SOLID", "POLY_SHAPE_MEASURED",
                            "%s: the extension %s%s of the side %s%s (the "
                            "height %s%s falls outside %s) is drawn SOLID -- "
                            "it reads as a part of the side; an extension is "
                            "dashed" % ("+".join(sorted(set(solid))), E, H,
                                        X, Y, Q, H, pid), SP.seg_id(E, H))
                    _ok, sused = self.cover(pX, pY)
                    if any(dashed(pc) for pc in sused):
                        self.fail(
                            "CHK_BASE_DASHED", "POLY_SHAPE_MEASURED",
                            "the side %s%s of %s is drawn dashed: the base is "
                            "solid, only its extension %s%s is dashed"
                            % (X, Y, pid, E, H), SP.seg_id(X, Y))
                    if not marked:
                        self.fail(
                            "CHK_FOOT_NO_RIGHT_MARK", "RIGHT_MARK_IF_ANY",
                            "the height %s%s of %s falls outside it: the "
                            "right-angle mark must sit at its foot %s (none "
                            "there)" % (Q, H, pid, H), SP.ang_id(Q, H, E))

    def measure_obj(self, eid):
        ns = self.fs.points_of(eid) or split_names(eid.split(":")[1])
        P = [self.P(n) for n in ns]
        if None in P:
            return None
        if len(P) == 3:
            return G.angle_deg(P[1], P[0], P[2])
        return G.d(P[0], P[1])

    def right_claimed(self, a, v, b, right):
        A, V, B = self.P(a), self.P(v), self.P(b)
        for (rv, l1, l2) in right:
            if rv != v:
                continue
            d1 = [G.line_dir_diff(V, A, *l) for l in (l1, l2)]
            d2 = [G.line_dir_diff(V, B, *l) for l in (l1, l2)]
            if (d1[0] <= T.PAR_TOL_DEG and d2[1] <= T.PAR_TOL_DEG) or \
                    (d1[1] <= T.PAR_TOL_DEG and d2[0] <= T.PAR_TOL_DEG):
                return True
        return False

    def claims(self):
        """What the reader of the figure is told: right angles (vertex +
        two lines), a union of EQUAL segments / angles, a union of PARALLEL
        lines. Closed rules, each a statement in front of the reader."""
        fs = self.fs
        right, eq, par = [], _Union(), _Union()
        valued = []
        for f in self.reader:
            rel, args = f.get("rel"), f.get("args") or []
            try:
                if rel == "angle_measure":
                    if f.get("value") not in (None, ""):
                        valued.append(f)
                        if SP.C.parse_number(f["value"]) == \
                                SP.C.parse_number("90"):
                            a, v, b = fs.points_of(args[0])
                            if None in (self.P(v), self.P(a), self.P(b)):
                                # (v6.17) a right angle the reader knows
                                # from the question, on points this (item)
                                # figure does not draw: nothing to claim
                                # here (it crashed the claims before)
                                continue
                            right.append((v, (self.P(v), self.P(a)),
                                          (self.P(v), self.P(b))))
                elif rel == "length" and f.get("value") not in (None, ""):
                    valued.append(f)
                elif rel == "perpendicular":
                    s1, s2 = self.seg_of(args[0]), self.seg_of(args[1])
                    for n in self.pts:
                        X = self.P(n)
                        if G.line_dist(X, *s1) <= T.ON_TOL_PX and \
                                G.line_dist(X, *s2) <= T.ON_TOL_PX:
                            right.append((n, s1, s2))
                elif rel in ("equal_length", "equal_angle", "parallel"):
                    (par if rel == "parallel" else eq).join(args[0], args[1])
                elif rel == "midpoint":
                    m = args[0]
                    a, b = fs.points_of(args[1])
                    eq.join(SP.seg_id(a, m), SP.seg_id(m, b))
                vs = fs.points_of(args[0]) if args and \
                    fs.kind(args[0]) == "polygon" else []
                n = len(vs)
                sides = [SP.seg_id(vs[i], vs[(i + 1) % n]) for i in range(n)]
                if rel in ("rectangle", "square") and n == 4:
                    for i in range(4):
                        right.append((vs[i], (self.P(vs[i]), self.P(vs[i - 1])),
                                      (self.P(vs[i]),
                                       self.P(vs[(i + 1) % 4]))))
                if rel in ("square", "rhombus", "equilateral"):
                    for s in sides[1:]:
                        eq.join(sides[0], s)
                if rel in ("rectangle", "parallelogram", "square",
                           "rhombus") and n == 4:
                    eq.join(sides[0], sides[2])
                    eq.join(sides[1], sides[3])
                    par.join(sides[0], sides[2])
                    par.join(sides[1], sides[3])
                if rel == "isosceles" and n == 3 and fs.accurate:
                    L = [G.d(self.P(vs[i]), self.P(vs[(i + 1) % 3]))
                         for i in range(3)]
                    for i in range(3):
                        for j in range(i + 1, 3):
                            if abs(L[i] - L[j]) <= T.LEN_REL_TOL * max(L):
                                eq.join(sides[i], sides[j])
            except (TypeError, KeyError, IndexError, ValueError):
                continue
        for i, f in enumerate(valued):
            for g in valued[i + 1:]:
                try:
                    if f["rel"] == g["rel"] and SP.C.same_quantity(
                            f["value"], f.get("unit"), g["value"],
                            g.get("unit")):
                        eq.join(f["args"][0], g["args"][0])
                except Exception:
                    pass
        return right, eq, par

    def mark_geometry(self, m):
        kind, names = m["kind"], m["names"]
        ref, pts = m["ref"], m["pts"]
        if len(names) == 3:
            a, v, b = names
            m["obj"] = SP.ang_id(a, v, b)
        else:
            a, b = names
            m["obj"] = SP.seg_id(a, b)
        P = [self.P(n) for n in names]
        if None in P:
            self.fail("CHK_HOOK_POINT_UNDRAWN", "ANG_ARC_GEOMETRY_IF_ANY" if
                      len(names) == 3 else "SEG_TICKS_IF_ANY", "%s: mark on %s"
                      " names a point that is not drawn" % (ref, m["obj"]),
                      m["obj"])
            return False
        self.own(m["obj"], ref)
        if kind == "arc":
            return self.arc_ok(m, P)
        if kind == "right":
            return self.right_ok(m, P)
        if kind == "tick":
            return self.tick_ok(m, P)
        return self.arrow_ok(m, P)

    def arc_ok(self, m, P):
        A, V, B = P
        pts, ref, obj = m["pts"], m["ref"], m["obj"]
        ok = True
        rs = [G.d(p, V) for p in pts]
        r = sum(rs) / len(rs)
        if max(rs) - min(rs) > 2 * T.ARC_RADIUS_TOL_PX:
            self.fail("CHK_ARC_NOT_CIRCLE", "ANG_ARC_GEOMETRY_IF_ANY", "%s: "
                      "samples of the arc of %s are not on one circle about "
                      "the vertex (r %.2f..%.2f)" % (ref, obj, min(rs),
                                                     max(rs)), obj)
            ok = False
        if not (T.ARC_MIN_R_PX <= r <= T.ARC_MAX_R_PX):
            self.fail("CHK_ARC_RADIUS", "ANG_ARC_GEOMETRY_IF_ANY", "%s: arc "
                      "radius %.1f outside [%s, %s]" % (ref, r, T.ARC_MIN_R_PX,
                                                        T.ARC_MAX_R_PX), obj)
            ok = False
        worst_s, worst_step = 0.0, 0.0
        for i in range(len(pts) - 1):
            p, q = pts[i], pts[i + 1]
            sag = r - G.d(G.mid(p, q), V)
            worst_s = max(worst_s, sag)
            worst_step = max(worst_step, G.ang_diff(G.direction(V, p),
                                                    G.direction(V, q)))
        if worst_s > T.ARC_SAGITTA_PX or worst_step > T.ARC_MAX_STEP_DEG:
            self.fail("CHK_ARC_CHORD", "ANG_ARC_CHORDS", "%s: the arc of %s "
                      "is drawn with chords that leave its circle (sagitta "
                      "%.2f px > %s, or step %.1f deg > %s)"
                      % (ref, obj, worst_s, T.ARC_SAGITTA_PX, worst_step,
                         T.ARC_MAX_STEP_DEG), obj)
            ok = False
        dA, dB = G.direction(V, A), G.direction(V, B)
        d0, d1 = G.direction(V, pts[0]), G.direction(V, pts[-1])
        ends_ok = (G.ang_diff(d0, dA) <= T.ARC_END_TOL_DEG and
                   G.ang_diff(d1, dB) <= T.ARC_END_TOL_DEG) or \
                  (G.ang_diff(d0, dB) <= T.ARC_END_TOL_DEG and
                   G.ang_diff(d1, dA) <= T.ARC_END_TOL_DEG)
        inside = all(G.in_sector(p, V, A, B) for p in pts[1:-1])
        if not ends_ok or not inside:
            self.fail("CHK_ARC_ARMS", "ANG_ARC_GEOMETRY_IF_ANY", "%s: the arc "
                      "of %s does not run inside the angle from arm to arm"
                      % (ref, obj), obj)
            ok = False
        m["r"] = r
        return ok

    def right_ok(self, m, P):
        A, V, B = P
        pts, ref, obj = m["pts"], m["ref"], m["obj"]
        if len(pts) != 3:
            self.fail("CHK_RIGHT_SHAPE", "RIGHT_MARK_IF_ANY", "%s: a right "
                      "mark has 3 points" % ref, obj)
            return False
        p, c, q = pts
        good = False
        for (x, y) in ((p, q), (q, p)):
            s1, s2 = G.d(V, x), G.d(V, y)
            on1 = G.seg_dist(x, V, A) <= T.RIGHT_TOL_PX
            on2 = G.seg_dist(y, V, B) <= T.RIGHT_TOL_PX
            corner = G.d(c, G.sub(G.add(x, y), V)) <= T.RIGHT_TOL_PX
            size = T.RIGHT_MIN_PX <= min(s1, s2) and \
                max(s1, s2) <= T.RIGHT_MAX_PX and \
                abs(s1 - s2) <= T.RIGHT_TOL_PX
            if on1 and on2 and corner and size:
                good = True
        if not good:
            self.fail("CHK_RIGHT_SHAPE", "RIGHT_MARK_IF_ANY", "%s: not a square "
                      "corner at %s along both arms of %s" % (ref, m["names"][1],
                                                              obj), obj)
            return False
        if self.fs.accurate and abs(G.angle_deg(V, A, B) - 90) > \
                T.ANGLE_TOL_DEG:
            self.fail("CHK_RIGHT_MEASURE", "RIGHT_MARK_IF_ANY", "%s: %s is "
                      "marked right but measures %.2f" % (
                          ref, obj, G.angle_deg(V, A, B)), obj)
            return False
        return True

    def tick_ok(self, m, P):
        A, B = P
        (p, q), ref, obj = m["pts"], m["ref"], m["obj"]
        c = G.mid(p, q)
        L = G.d(p, q)
        t = G.param(c, A, B)
        steep = G.line_dir_diff(p, q, A, B)
        ok = (T.TICK_MIN_PX <= L <= T.TICK_MAX_PX and
              G.line_dist(c, A, B) <= T.ON_TOL_PX and
              abs(t - 0.5) * G.d(A, B) <= T.TICK_SPREAD_PX and
              steep >= T.TICK_MIN_DEG)
        if not ok:
            self.fail("CHK_TICK_SHAPE", "SEG_TICKS_IF_ANY", "%s: not a tick "
                      "across the middle of %s" % (ref, obj), obj)
        return ok

    def arrow_ok(self, m, P):
        A, B = P
        pts, ref, obj = m["pts"], m["ref"], m["obj"]
        ok = len(pts) == 3 and G.line_dist(pts[1], A, B) <= T.ON_TOL_PX and \
            abs(G.param(pts[1], A, B) - 0.5) * G.d(A, B) <= \
            T.PAR_ARROW_SPREAD_PX and \
            abs(G.line_dist(pts[0], A, B) - G.line_dist(pts[2], A, B)) <= \
            T.RIGHT_TOL_PX
        if not ok:
            self.fail("CHK_ARROW_SHAPE", "PARALLEL_ARROWS_IF_ANY", "%s: not a "
                      "parallel arrow on the middle of %s" % (ref, obj), obj)
            return ok
        tip = pts[1]
        back = G.mid(pts[0], pts[2])
        u = G.sub(B, A)
        s = 1.0 if G.dot(G.sub(tip, back), u) > 0 else -1.0
        L = math.hypot(*u)
        m["dir"] = (s * u[0] / L, s * u[1] / L)
        return ok

    # --------------------------------------------------------- labels ----
    def dirs_at(self, V):
        out = []
        for pc in self.pieces:
            for (x, y) in ((pc.p, pc.q), (pc.q, pc.p)):
                if G.d(x, V) <= T.ON_TOL_PX and G.d(y, V) > T.ON_TOL_PX:
                    out.append(G.direction(V, y))
            if G.seg_dist(V, pc.p, pc.q) <= T.ON_TOL_PX and \
                    G.d(V, pc.p) > T.ON_TOL_PX and G.d(V, pc.q) > T.ON_TOL_PX:
                out += [G.direction(V, pc.p), G.direction(V, pc.q)]
        return out

    def check_labels(self):
        fs = self.fs
        W, H = self.dr.W, self.dr.H
        valued = {}
        for f in self.reader:
            if f.get("rel") in SP.VALUE_RELS and \
                    f.get("value") not in (None, ""):
                valued.setdefault(f["args"][0], []).append(f)
        drawn_values = {}
        for f in fs.draws:
            if f.get("rel") in SP.VALUE_RELS and \
                    f.get("value") not in (None, ""):
                drawn_values.setdefault(f["args"][0], []).append(f)
        names_drawn = set(f["args"][0] for f in fs.draws
                          if f.get("rel") == "name")
        target_objs = set()
        for t in fs.targets:
            for a in t.get("args") or []:
                target_objs.add(a)
        seen_names = {}
        for lab in self.labels:
            tgt = lab.target
            if tgt.startswith("line "):
                obj = self.label_obj(lab)
                seen_names.setdefault(obj, []).append(lab)
                self.label_line(lab, obj, names_drawn)
                self.label_box(lab, obj, W, H)
                continue
            n = split_names(tgt)
            if n is not None:
                obj = tgt
                seen_names.setdefault(tgt, []).append(lab)
                if lab.text != tgt:
                    self.fail("CHK_LABEL_TEXT", "PT_LABEL_OWNED", "%s: the label"
                              " of point %s prints %r" % (lab.ref, tgt, lab.text),
                              tgt)
                if tgt not in self.pts:
                    self.fail("CHK_LABEL_SOURCE", "PT_LABEL_OWNED", "%s: label "
                              "for %s, which is not drawn" % (lab.ref, tgt), tgt)
                    continue
                self.own(tgt, lab.ref)
                self.label_point(lab, tgt)
            else:
                kind, names = tgt.split(" ")
                ns = split_names(names)
                obj = {"ang": lambda: SP.ang_id(ns[0], ns[1], ns[2]),
                       "seg": lambda: SP.seg_id(ns[0], ns[1]),
                       "poly": lambda: SP.poly_id(ns),
                "line": lambda: SP.line_id(ns[0], ns[1])}[kind]()
                facts = drawn_values.get(obj, [])
                chk = {"ang": "ANG_CAPTION_OWNED_IF_ANY",
                       "seg": "SEG_CAPTION_OWNED_IF_ANY"}.get(
                           kind, "POLY_SHAPE_MEASURED")
                if not facts:
                    code = "CHK_TARGET_SHOWN" if obj in target_objs else \
                        "CHK_CAPTION_SOURCE"
                    self.fail(code, "TARGET_VALUE_NOT_SHOWN" if obj in
                              target_objs else chk, "%s: caption %r for %s, "
                              "which has no drawn given value%s" % (
                                  lab.ref, lab.text, obj,
                                  " (it is a TARGET of this figure's items)"
                                  if obj in target_objs else ""), obj)
                    continue
                if not any(SP.same_value(f, lab.text) for f in facts):
                    self.fail("CHK_CAPTION_VALUE", chk, "%s: caption %r for %s "
                              "is not its drawn value %s" % (
                                  lab.ref, lab.text, obj,
                                  [f.get("value") for f in facts]), obj)
                    continue
                if not all(self.P(x) for x in ns):
                    self.fail("CHK_HOOK_POINT_UNDRAWN", chk, "%s: caption of "
                              "%s names a point that is not drawn" % (lab.ref,
                                                                    obj), obj)
                    continue
                self.own(obj, lab.ref)
                if kind == "ang":
                    self.label_angle(lab, ns, obj)
                elif kind == "seg":
                    self.label_segment(lab, ns, obj)
                else:
                    self.label_poly(lab, ns, obj)
            self.label_box(lab, obj, W, H)
        for name in sorted(names_drawn):
            if fs.kind(name) == "line" and len(seen_names.get(name, [])) != 1:
                self.fail("CHK_LINE_LABEL_COUNT", "LINE_LABEL_OWNED", "line %s has %d name labels (1 expected)" %
                          (name, len(seen_names.get(name, []))), name)
            if name in self.pts and len(seen_names.get(name, [])) != 1:
                self.fail("CHK_PT_LABEL_COUNT", "PT_LABEL_OWNED", "point %s has"
                          " %d name labels (1 expected)" % (
                              name, len(seen_names.get(name, []))), name)
        for f in fs.draws:
            if f.get("rel") in SP.VALUE_RELS and \
                    f.get("value") not in (None, ""):
                a = f["args"][0]
                kinds = {"ang": "ang", "seg": "seg", "poly": "poly"}
                pre = a.split(":")[0]
                has = [lab for lab in self.labels if lab.target.startswith(
                    kinds.get(pre, "?") + " ") and self.label_obj(lab) == a]
                if not has and f["rel"] == "angle_measure" and any(
                        m["kind"] == "right" and m.get("obj") == a
                        for m in self.marks) and SP.C.parse_number(
                            f["value"]) == SP.C.parse_number("90"):
                    has = ["right mark"]
                if not has:
                    self.fail("CHK_CAPTION_MISSING", "OCR_CAPTION_IF_ANY",
                              "the figure draws %s but prints no caption of "
                              "its value" % f["id"], a)

    def label_obj(self, lab):
        kind, names = lab.target.split(" ")
        ns = split_names(names)
        return {"ang": lambda: SP.ang_id(ns[0], ns[1], ns[2]),
                "seg": lambda: SP.seg_id(ns[0], ns[1]),
                "poly": lambda: SP.poly_id(ns),
                "line": lambda: SP.line_id(ns[0], ns[1])}[kind]()

    def near_points(self, box):
        return sorted((G.box_dist(p, box), n) for n, p in self.pts.items())

    def label_line(self, lab, obj, names_drawn):
        e = self.fs.ents.get(obj) or {}
        pieces = [p for p in self.pieces if p.kind == "line" and SP.line_id(*p.names) == obj]
        if obj not in names_drawn or e.get("kind") != "line" or e.get("name") != lab.text or len(pieces) != 1:
            self.fail("CHK_LINE_LABEL_SOURCE", "LINE_LABEL_OWNED",
                      "%s: %r is not a declared drawn name of %s" % (lab.ref, lab.text, obj), obj)
            return
        p = pieces[0]
        c = G.box_center(lab.box)
        own = G.seg_dist(c, p.p, p.q)
        if own > T.LABEL_NEAR_PX or any(G.seg_dist(c, pc.p, pc.q) < own + T.LABEL_MARGIN_PX
                                       for pc in self.pieces if pc.kind == "line" and SP.line_id(*pc.names) != obj):
            self.fail("CHK_LINE_LABEL_OWNER", "LINE_LABEL_OWNED",
                      "%s: line name is not unambiguously beside its own line" % lab.ref, obj)
        self.own(obj, lab.ref)

    def label_point(self, lab, name):
        ds = self.near_points(lab.box)
        own = G.box_dist(self.P(name), lab.box)
        if own > T.LABEL_NEAR_PX:
            self.fail("CHK_LABEL_FAR", "PT_LABEL_OWNED", "%s: label %s is %.1f "
                      "px from its point (> %s)" % (lab.ref, name, own,
                                                    T.LABEL_NEAR_PX), name)
        for dd, n in ds:
            if n != name and dd < own + T.LABEL_MARGIN_PX:
                self.fail("CHK_LABEL_OWNER", "PT_LABEL_OWNED", "%s: label %s "
                          "is as near to point %s (%.1f px) as to its own "
                          "(%.1f px): a reader may read it as %s's" % (
                              lab.ref, name, n, dd, own, n), name)
                break

    def label_angle(self, lab, ns, obj):
        a, v, b = ns
        A, V, B = self.P(a), self.P(v), self.P(b)
        c = G.box_center(lab.box)
        if not G.in_sector(c, V, A, B):
            self.fail("CHK_CAPTION_SECTOR", "ANG_CAPTION_OWNED_IF_ANY", "%s: "
                      "caption %r of %s is outside its angle's sector" % (
                          lab.ref, lab.text, obj), obj)
            return
        ds = self.near_points(lab.box)
        own = G.box_dist(V, lab.box)
        for dd, n in ds:
            if n != v and dd < own + T.LABEL_MARGIN_PX:
                self.fail("CHK_CAPTION_VERTEX", "ANG_CAPTION_OWNED_IF_ANY",
                          "%s: caption %r of %s is nearer to point %s (%.1f) "
                          "than to the vertex %s (%.1f)" % (
                              lab.ref, lab.text, obj, n, dd, v, own), obj)
                return
        dA, dB = G.direction(V, A), G.direction(V, B)
        inner = [dd for dd in self.dirs_at(V)
                 if G.ang_diff(dd, dA) > T.PAR_TOL_DEG and
                 G.ang_diff(dd, dB) > T.PAR_TOL_DEG and
                 G.in_sector(G.add(V, (math.cos(math.radians(dd)),
                                       math.sin(math.radians(dd)))), V, A, B)]
        if inner:
            # the caption sits in a narrower drawn angle at the same vertex
            self.review("CHK_CAPTION_SPLIT", "ANG_CAPTION_OWNED_IF_ANY",
                        "%s: a drawn line splits %s at %s; its caption %r "
                        "could be read as a part's" % (lab.ref, obj, v,
                                                       lab.text), obj)
        arcs = [m for m in self.marks if m["kind"] == "arc" and "r" in m]
        own_arcs = [m for m in arcs if m["obj"] == obj]
        if own_arcs:
            da = min(G.polyline_box_dist(m["pts"], lab.box) for m in own_arcs)
            if da > T.CAPTION_ARC_PX:
                self.fail("CHK_CAPTION_ARC", "ANG_CAPTION_OWNED_IF_ANY", "%s: "
                          "caption %r is %.1f px from its arc (> %s)" % (
                              lab.ref, lab.text, da, T.CAPTION_ARC_PX), obj)
            for m in arcs:
                if m["obj"] != obj and G.polyline_box_dist(m["pts"], lab.box) \
                        < da + T.LABEL_MARGIN_PX:
                    self.fail("CHK_CAPTION_OTHER_ARC",
                              "ANG_CAPTION_OWNED_IF_ANY", "%s: caption %r of "
                              "%s is as near to the arc of %s" % (
                                  lab.ref, lab.text, obj, m["obj"]), obj)
                    break

    def label_segment(self, lab, ns, obj):
        A, B = self.P(ns[0]), self.P(ns[1])
        c = G.box_center(lab.box)
        t = G.param(c, A, B)
        own = G.seg_box_dist(A, B, lab.box)
        if not (T.LABEL_SEG_END_FRAC <= t <= 1 - T.LABEL_SEG_END_FRAC):
            self.fail("CHK_CAPTION_SEG_END", "SEG_CAPTION_OWNED_IF_ANY", "%s: "
                      "caption %r of %s is by its end, not its middle" % (
                          lab.ref, lab.text, obj), obj)
            return
        if own > T.LABEL_VALUE_PX:
            self.fail("CHK_CAPTION_FAR", "SEG_CAPTION_OWNED_IF_ANY", "%s: "
                      "caption %r is %.1f px from %s" % (lab.ref, lab.text, own,
                                                         obj), obj)
            return
        for pc in self.pieces:
            on = G.line_dist(pc.p, A, B) <= T.COLLINEAR_TOL_PX and \
                G.line_dist(pc.q, A, B) <= T.COLLINEAR_TOL_PX
            if on:
                continue
            if self.far_side(lab.box, A, B, pc.p, pc.q):
                continue          # (fix r1) the segment stands between them
            dd = G.seg_box_dist(pc.p, pc.q, lab.box)
            if dd < own + T.LABEL_MARGIN_PX:
                self.fail("CHK_CAPTION_OWNER", "SEG_CAPTION_OWNED_IF_ANY",
                          "%s: caption %r of %s is as near to %s (%s)" % (
                              lab.ref, lab.text, obj, "".join(pc.names),
                              pc.ref), obj)
                return
        self.label_segment_parts(lab, ns, obj, A, B)

    # (v6.9 fix r1, N1/P1) a caption of a segment that a drawn point splits
    @staticmethod
    def _sd(x, A, B):
        L = G.d(A, B) or 1.0
        return G.cross(G.sub(B, A), G.sub(x, A)) / L

    def far_side(self, box, A, B, p, q):
        """The whole caption box on one side of line AB and the piece p-q
        wholly on the other (an end may touch the line)."""
        cs = [self._sd(c, A, B) for c in ((box[0], box[1]), (box[2], box[1]),
                                          (box[0], box[3]), (box[2], box[3]))]
        if not (all(s > T.ON_TOL_PX for s in cs) or
                all(s < -T.ON_TOL_PX for s in cs)):
            return False
        up = cs[0] > 0
        for x in (p, q):
            s = self._sd(x, A, B)
            if abs(s) > T.ON_TOL_PX and (s > 0) == up:
                return False
        return True

    def label_segment_parts(self, lab, ns, obj, A, B):
        """A drawn point P strictly inside segment AB splits it: its
        caption must stand OVER a split point (under the middle half of the
        caption box) -- beside one part it reads as that part's length
        (b q10: BC = 8 printed by E, under BE, read BE = 8) -> FAIL; and it
        must not stand beside P's own name on the same side of AB ('E 8'
        reads as E's number) -> REVIEW."""
        L = G.d(A, B)
        if L <= 1e-9:
            return
        inner = []
        for n, q in sorted(self.pts.items()):
            if n in ns:
                continue
            t = G.param(q, A, B)
            if G.line_dist(q, A, B) <= T.ON_TOL_PX and \
                    T.ON_TOL_PX / L < t < 1 - T.ON_TOL_PX / L:
                inner.append((t, n))
        if not inner:
            return
        box = lab.box
        ts = [G.param(c, A, B) for c in ((box[0], box[1]), (box[2], box[1]),
                                         (box[0], box[3]), (box[2], box[3]))]
        t0, t1 = min(ts), max(ts)
        mid, half = (t0 + t1) / 2.0, (t1 - t0) / 2.0
        over = [n for t, n in inner if abs(t - mid) <= half / 2.0 +
                T.ON_TOL_PX / L]
        if not over:
            parts = [ns[0]] + [n for t, n in sorted(inner)] + [ns[1]]
            tt = [0.0] + [t for t, n in sorted(inner)] + [1.0]
            k = max(i for i in range(len(tt) - 1) if tt[i] <= mid)
            self.fail("CHK_CAPTION_SUBSEGMENT", "SEG_CAPTION_OWNED_IF_ANY",
                      "%s: caption %r of %s stands beside the part %s%s only "
                      "(a drawn point splits %s): it reads as that part's "
                      "length" % (lab.ref, lab.text, obj, parts[k],
                                  parts[k + 1], obj), obj)
            return
        side = self._sd(G.box_center(box), A, B)
        for n in over:
            for other in self.labels:
                if other.target != n:
                    continue
                os_ = self._sd(G.box_center(other.box), A, B)
                gap = max(other.box[0] - box[2], box[0] - other.box[2],
                          other.box[1] - box[3], box[1] - other.box[3], 0.0)
                if (os_ > 0) == (side > 0) and \
                        gap < T.CAPTION_NAME_GAP_PX:
                    self.review("CHK_CAPTION_BESIDE_NAME",
                                "SEG_CAPTION_OWNED_IF_ANY",
                                "%s: caption %r of %s stands %.1f px beside "
                                "the name %s of the point that splits it, on "
                                "the same side: it may read as %s's" % (
                                    lab.ref, lab.text, obj, gap, n, n), obj)

    def label_poly(self, lab, ns, obj):
        P = [self.P(n) for n in ns]
        c = G.box_center(lab.box)
        if not G.in_polygon(c, P):
            self.fail("CHK_CAPTION_POLY", "POLY_SHAPE_MEASURED", "%s: caption "
                      "%r is outside %s" % (lab.ref, lab.text, obj), obj)
            return
        a0 = G.area(P)
        for e in self.fs.entities:
            if self.fs.kind(e) == "polygon" and e != obj:
                Q = [self.P(n) for n in self.fs.points_of(e)]
                if None not in Q and G.area(Q) < a0 and G.in_polygon(c, Q):
                    self.review("CHK_CAPTION_POLY_INNER", "POLY_SHAPE_MEASURED",
                                "%s: caption %r of %s lies inside the smaller "
                                "%s" % (lab.ref, lab.text, obj, e), obj)

    def label_box(self, lab, obj, W, H):
        box = lab.box
        mg = T.CANVAS_MARGIN_PX
        if box[0] < mg or box[1] < mg or box[2] > W - mg or box[3] > H - mg:
            self.fail("CHK_LABEL_CLIPPED", "TEXT_BOX_IN_CANVAS", "%s: label %r "
                      "box %s (%s) leaves the canvas 0 0 %s %s" % (
                          lab.ref, lab.text, tuple(round(v, 1) for v in box),
                          lab.box_from, W, H), obj)
        ink = self.ink.get(lab.ref)
        core = G.grow(box, -T.LABEL_CORE_PX)
        g = G.grow(box, T.LABEL_CLEAR_PX)
        for n, p in self.pts.items():
            r = getattr(self.dr.by_ref[self.pt_ref[n]], "r", 2.0)
            if ink is not None:
                hit = G.box_dist(p, core) == 0 or any(
                    G.d(p, q) <= r + T.LABEL_CLEAR_PX for q in ink
                    if abs(p[0] - q[0]) <= r + 1 and abs(p[1] - q[1]) <= r + 1)
            else:
                hit = G.box_dist(p, g) <= r
            if hit:
                self.fail("CHK_LABEL_COVERS", "TEXT_NOT_COVERING_MARKS", "%s: "
                          "label %r covers / touches the dot of %s" % (
                              lab.ref, lab.text, n), obj)
        for m in self.marks:
            if ink is not None:
                sw = float(m["el"].a.get("stroke-width") or 1) / 2.0
                near = [q for q in ink
                        if G.polyline_box_dist(m["pts"], (q[0], q[1], q[0],
                                                          q[1])) <=
                        sw + T.LABEL_CLEAR_PX] if \
                    G.polyline_box_dist(m["pts"], g) <= sw else []
                hit = bool(near) or (core[0] < core[2] and core[1] < core[3]
                                     and G.polyline_box_dist(m["pts"],
                                                             core) <= 0)
            else:
                hit = G.polyline_box_dist(m["pts"], g) <= 0
            if hit:
                self.fail("CHK_LABEL_COVERS", "TEXT_NOT_COVERING_MARKS", "%s: "
                          "label %r covers / touches the %s mark %s" % (
                              lab.ref, lab.text, m["kind"], m["ref"]), obj)
        for pc in self.pieces:
            ln = G.clip_len(pc.p, pc.q, box)
            if ln > T.LABEL_STROKE_TOL_PX:
                self.fail("CHK_LABEL_COVERS", "TEXT_NOT_COVERING_MARKS", "%s: "
                          "%s (%s) runs %.1f px through label %r" % (
                              lab.ref, "".join(pc.names), pc.ref, ln,
                              lab.text), obj)

    # -------------------------------------------------- constructions ----
    def check_constructions(self):
        fs = self.fs
        for t in fs.targets:
            rel = t.get("rel") or ""
            if not rel.startswith("construct"):
                continue
            args = t.get("args") or []
            try:
                self.construction(t, rel, args)
            except (TypeError, KeyError, IndexError, ValueError,
                    ZeroDivisionError) as e:
                self.review("CHK_CONS_UNMEASURABLE", "CONS_DECLARED_GIVEN_SHOWN_TODO",
                            "construction %s could not be located on the "
                            "drawing (%s)" % (t.get("id"), e), args[:1])

    def construction(self, t, rel, args):
        fs = self.fs
        res = args[0]
        rk = fs.kind(res)
        tid = t.get("id")
        inputs = args[1:]
        for i in inputs:
            for n in fs.points_of(i):
                if n not in self.pts:
                    self.fail("CHK_CONS_INPUT_UNDRAWN", "CONS_INPUTS_SHOWN",
                              "%s: input %s of the construction is not drawn "
                              "(point %s)" % (tid, i, n), [res, i])
            if fs.kind(i) in ("segment", "line", "ray"):
                ns = fs.points_of(i)
                if all(self.P(n) for n in ns) and \
                        not self.cover(self.P(ns[0]), self.P(ns[1]))[0]:
                    self.fail("CHK_CONS_INPUT_UNDRAWN", "CONS_INPUTS_SHOWN",
                              "%s: input %s is not drawn" % (tid, i), [res, i])
        # where the result is (support line through a point + direction)
        rpts = fs.points_of(res)
        if res in fs.entities and rk != "point":
            self.fail("CHK_CONS_RESULT_DRAWN", "CONS_RESULT_NOT_DRAWN_ANY_FORM",
                      "%s: the figure lists the result %s as shown" % (tid, res),
                      res)
        new_pts = [n for n in rpts if n not in fs.entities]
        for n in new_pts:
            if n in self.pts:
                self.fail("CHK_CONS_RESULT_DRAWN", "CONS_RESULT_NOT_DRAWN_ANY_FORM",
                          "%s: the new point %s is drawn" % (tid, n), res)
        if rel == "construct_join":
            if new_pts:
                self.fail("CHK_CONS_JOIN_UNSHOWN", "CONS_DECLARED_GIVEN_SHOWN_TODO",
                          "%s: 'join given points' but %s is not shown"
                          % (tid, ",".join(new_pts)), res)
                return
            A, B = self.P(rpts[0]), self.P(rpts[1])
            self.result_on_line(tid, res, A, B, "segment", A, B)
            return
        if rk == "point":
            spot = self.locate_point(rel, inputs)
            if spot is not None:
                for n, p in self.pts.items():
                    if G.d(p, spot) <= T.ON_TOL_PX and n not in fs.points_of(
                            inputs[0] if inputs else ""):
                        self.fail("CHK_CONS_RESULT_DRAWN",
                                  "CONS_RESULT_NOT_DRAWN_ANY_FORM", "%s: a point"
                                  " (%s) is drawn where the result %s is" % (
                                      tid, n, res), res)
            return
        base, direction = self.result_support(rel, rpts, inputs, tid)
        if base is None:
            return
        far = G.add(base, direction)
        end = None
        if rk == "segment":
            end = self.P(rpts[1]) if rpts[1] in self.pts else \
                self.foot_of(rel, rpts, inputs)
        self.result_on_line(tid, res, base, far, rk, base, end)

    def locate_point(self, rel, inputs):
        if rel == "construct_midpoint" and inputs:
            s = self.seg_of(inputs[0])
            return G.mid(*s) if s else None
        return None

    def foot_of(self, rel, rpts, inputs):
        v = self.P(rpts[0])
        poly = self.fs.points_of(inputs[0]) if inputs else []
        opp = [n for n in poly if n != rpts[0]]
        if len(opp) != 2 or v is None:
            return None
        X, Y = self.P(opp[0]), self.P(opp[1])
        if rel == "construct_median":
            return G.mid(X, Y)
        if rel == "construct_altitude":
            t = G.param(v, X, Y)
            return G.add(X, G.mul(G.sub(Y, X), t))
        return None

    def result_support(self, rel, rpts, inputs, tid):
        """(base point, unit direction) of the result's supporting line."""
        fs = self.fs
        if rel in ("construct_median", "construct_altitude"):
            v = self.P(rpts[0])
            foot = self.foot_of(rel, rpts, inputs)
            if v is None or foot is None:
                raise ValueError("vertex / foot")
            if G.d(v, foot) <= T.ON_TOL_PX:
                self.fail("CHK_CONS_DEGENERATE", "CONS_NO_EMPTY_OR_CIRCULAR_GIVEN",
                          "%s: the vertex lies on the opposite side: nothing "
                          "to construct" % tid, rpts)
                return None, None
            return v, _unit(G.sub(foot, v))
        if rel == "construct_bisector":
            a, v, b = fs.points_of(inputs[0])
            V = self.P(v)
            u1 = _unit(G.sub(self.P(a), V))
            u2 = _unit(G.sub(self.P(b), V))
            s = G.add(u1, u2)
            if math.hypot(*s) < 1e-6:
                raise ValueError("straight angle")
            return V, _unit(s)
        if rel in ("construct_parallel", "construct_perpendicular"):
            ref, pt = inputs[0], inputs[1]
            s = self.seg_of(ref)
            P = self.P(fs.points_of(pt)[0])
            if s is None or P is None:
                raise ValueError("reference / point")
            u = _unit(G.sub(s[1], s[0]))
            if rel == "construct_perpendicular":
                u = (-u[1], u[0])
            elif G.line_dist(P, s[0], s[1]) <= T.ON_TOL_PX:
                self.fail("CHK_CONS_DEGENERATE", "CONS_NO_EMPTY_OR_CIRCULAR_GIVEN",
                          "%s: %s lies on %s: the parallel through it is %s "
                          "itself (an empty given)" % (tid, pt, ref, ref),
                          [pt, ref])
                return None, None
            if rpts and rpts[0] in self.pts and \
                    G.d(self.P(rpts[0]), P) > T.ON_TOL_PX and \
                    G.line_dist(self.P(rpts[0]), P, G.add(P, u)) > T.ON_TOL_PX:
                raise ValueError("result point off the result line")
            return P, u
        if rel == "construct" and len(rpts) >= 2 and \
                all(self.P(n) for n in rpts[:2]):
            A, B = self.P(rpts[0]), self.P(rpts[1])
            return A, _unit(G.sub(B, A))
        raise ValueError("construction %s is not located by this checker" % rel)

    def result_on_line(self, tid, res, A, far, kind, start, end):
        """No drawn piece lies on the result's supporting line (in any form:
        itself, inside a longer line, as collinear pieces, a ray either way),
        and no two drawn points on it already show it."""
        u = _unit(G.sub(far, A))
        B = G.add(A, u)
        on = []
        for pc in self.pieces:
            if G.line_dist(pc.p, A, B) <= T.COLLINEAR_TOL_PX and \
                    G.line_dist(pc.q, A, B) <= T.COLLINEAR_TOL_PX and \
                    G.d(pc.p, pc.q) > T.COVER_GAP_PX:
                on.append(pc)
        if on:
            t = sorted(G.param(x, A, B) for pc in on for x in pc.pq)
            where = "overlapping it" if (end is None or any(
                -T.COVER_GAP_PX < G.param(x, A, B) for x in (
                    on[0].p, on[0].q))) else "on its line"
            self.fail("CHK_CONS_RESULT_DRAWN", "CONS_RESULT_NOT_DRAWN_ANY_FORM",
                      "%s: the result %s (%s) is already drawn: %s lie on its "
                      "line, %s (from %.1f to %.1f px along it)" % (
                          tid, res, kind, ", ".join("%s %s" % (
                              pc.ref, "".join(pc.names)) for pc in on), where,
                          t[0], t[-1]), res)
        if end is not None:
            for n, p in self.pts.items():
                if G.d(p, end) <= T.ON_TOL_PX and G.d(p, start) > T.ON_TOL_PX:
                    if n not in self.fs.points_of(res):
                        self.fail("CHK_CONS_RESULT_DRAWN",
                                  "CONS_RESULT_NOT_DRAWN_ANY_FORM", "%s: point "
                                  "%s is drawn at the end of the result %s" % (
                                      tid, n, res), res)


def _unit(v):
    L = math.hypot(*v)
    if not L:
        raise ValueError("zero direction")
    return (v[0] / L, v[1] / L)


class _Union(object):
    def __init__(self):
        self.up = {}

    def find(self, x):
        self.up.setdefault(x, x)
        while self.up[x] != x:
            self.up[x] = self.up[self.up[x]]
            x = self.up[x]
        return x

    def join(self, a, b):
        self.up[self.find(a)] = self.find(b)
