# -*- coding: utf-8 -*-
"""python3 -m wspec.check --svg F.svg --spec public.json --figure ID
       [--map objmap.json] [--no-ocr] [--png display.png] [--guard answers.json]
Prints the JSON report; exit 0 PASS, 1 REVIEW, 2 FAIL."""
import argparse
import json
import sys

from . import check_figure


def main(argv=None):
    ap = argparse.ArgumentParser(prog="python3 -m wspec.check")
    ap.add_argument("--svg", required=True)
    ap.add_argument("--spec", required=True, help="the PUBLIC model (json)")
    ap.add_argument("--figure", required=True)
    ap.add_argument("--map", help="object map (json)")
    ap.add_argument("--no-ocr", action="store_true")
    ap.add_argument("--png", help="write the final display raster here")
    ap.add_argument("--guard", help="json list of values not to expose")
    a = ap.parse_args(argv)
    with open(a.spec, "rb") as fh:
        spec = json.loads(fh.read().decode("utf-8"))
    om = None
    if a.map:
        with open(a.map, "rb") as fh:
            om = json.loads(fh.read().decode("utf-8"))
    guard = None
    if a.guard:
        with open(a.guard, "rb") as fh:
            guard = json.loads(fh.read().decode("utf-8"))
    rep = check_figure(a.svg, om, spec, a.figure, ocr=not a.no_ocr,
                       png_out=a.png, answer_guard=guard)
    rep.pop("_map_entities", None)
    sys.stdout.write(json.dumps(rep, ensure_ascii=False, indent=1,
                                sort_keys=True) + "\n")
    return {"PASS": 0, "REVIEW": 1}.get(rep["status"], 2)


if __name__ == "__main__":
    sys.exit(main())
