# -*- coding: utf-8 -*-
"""Checking the renderer's object map (the format wspec.render emits, read
from its OUTPUT only -- see CONTRACT.txt) against the drawing as MEASURED by
the checker. The map is not trusted: every display item must be the
element(s) it claims, every element must belong to exactly one item, every
object's elements must equal the elements the checker itself finds drawing
that object, and every part must lie on the drawing where it says. The map
carries no free text: every string is a public spec id, a point name, a
positional element id, a closed-list token or the label text itself."""
import re

from . import geom as G
from . import tol as T
from . import spec as SP
from .dialect import split_names, DialectReader

CHK = "OBJMAP_TOTAL_NO_UNMAPPED_INK"
LEAK = "NO_ANSWER_ANYWHERE_SVG"
TOP_KEYS = {"construction", "dialect", "display_items", "elements", "engine",
            "figure", "objects", "public_hash", "settings_hash"}
ITEM_RE = re.compile(r"^d[0-9]{3,4}$")
TOKEN_RE = re.compile(r"^[A-Za-z0-9._/+-]{1,80}$")
HEX_RE = re.compile(r"^[0-9a-f]{64}$")
# role -> (element tags, hook attribute, what the hook must name)
ROLES = {
    "point": (("circle",), "data-pt", "point"),
    "point_name": (("text",), "data-for", "name"),
    "line_name": (("text",), "data-for", "line"),
    "segment": (("line",), "data-seg", "seg"),
    "line": (("line",), "data-line", "line"),
    "ray": (("line",), "data-ray", "ray"),
    "polygon": (("polygon",), "data-poly", "poly"),
    "angle_arc": (("path", "polyline"), "data-mark", "arc"),
    "right_mark": (("path", "polyline"), "data-mark", "right"),
    "tick": (("line",), "data-mark", "tick"),
    "parallel_arrow": (("polyline", "path"), "data-mark", "par"),
    "angle_caption": (("text",), "data-for", "ang"),
    "segment_caption": (("text",), "data-for", "seg"),
    "polygon_caption": (("text",), "data-for", "poly"),
}
CONS_KEYS = {"item", "fact", "rel", "mode", "given", "shown", "student_does"}
CONS_MODES = {"locate", "join"}


def _k(ref):
    return int(ref[1:])


def element_object(el, rd):
    """(kind word, object id) an element draws, from its hook."""
    k, v = el.hook if el.hook else (None, None)
    if k == "data-pt":
        return "point", v
    if k in ("data-seg", "data-line", "data-ray"):
        a, b = split_names(v)
        w = k[5:]
        return w, {"seg": SP.seg_id, "line": SP.line_id,
                   "ray": SP.ray_id}[w](a, b)
    if k == "data-poly":
        return "poly", SP.poly_id(split_names(v))
    if k == "data-mark":
        kind, cnt, names = rd.parse_mark(v)
        return kind, (SP.ang_id(*names) if len(names) == 3
                      else SP.seg_id(*names))
    if k == "data-for":
        n = split_names(v)
        if n is not None:
            return "name", v
        kind, names = v.split(" ")
        ns = split_names(names)
        return kind, {"ang": lambda: SP.ang_id(*ns),
                      "seg": lambda: SP.seg_id(*ns),
                      "poly": lambda: SP.poly_id(ns),
                      "line": lambda: SP.line_id(*ns)}[kind]()
    return None, None


def check_map(om, fc, fs, F):
    """om: the object map. fc: the FigureCheck (measured drawing). Returns
    {object: {"elements": set, "parts": {ref: [X, Y]}}} for the highlight
    check, or None when the map is unusable."""
    dr, rd = fc.dr, DialectReader()
    if not isinstance(om, dict) or not {"display_items", "elements",
                                        "objects", "figure"} <= set(om):
        F.fail("CHK_MAP_FORMAT", CHK, "object map lacks display_items / "
               "elements / objects / figure")
        return None
    extra = set(om) - TOP_KEYS
    if extra:
        F.fail("CHK_MAP_FIELDS", LEAK, "object map has fields outside the "
               "format: %s" % sorted(extra))
    for k in ("engine", "dialect"):
        if k in om and not (isinstance(om[k], str) and TOKEN_RE.match(om[k])):
            F.fail("CHK_MAP_FIELDS", LEAK, "object map %s is not a plain "
                   "token" % k)
    for k in ("public_hash", "settings_hash"):
        if k in om and not (isinstance(om[k], str) and HEX_RE.match(om[k])):
            F.fail("CHK_MAP_FIELDS", LEAK, "object map %s is not a sha256" % k)
    if om.get("public_hash") and fs.spec.get("public_hash") and \
            om["public_hash"] != fs.spec["public_hash"]:
        F.fail("CHK_MAP_SPEC", CHK, "the map was made from another public "
               "model (public_hash %s..., the spec has %s...)" % (
                   om["public_hash"][:12], fs.spec["public_hash"][:12]))
    if om.get("figure") != fs.id:
        F.fail("CHK_MAP_FIGURE", CHK, "object map is for figure %r, not %r"
               % (om.get("figure"), fs.id))
    known_ent = set(fs.ents)
    items = om.get("display_items")
    if not isinstance(items, list):
        F.fail("CHK_MAP_FORMAT", CHK, "display_items is not a list")
        return None
    byid, owner = {}, {}
    for it in items:
        if not isinstance(it, dict) or not {"id", "role", "source",
                                            "elements"} <= set(it) or \
                not set(it) <= {"id", "role", "source", "elements", "text"}:
            F.fail("CHK_MAP_ITEM", LEAK, "display item %r: fields must be id, "
                   "role, source, elements (+ text)" % (it,))
            continue
        iid = it["id"]
        if not isinstance(iid, str) or not ITEM_RE.match(iid) or iid in byid:
            F.fail("CHK_MAP_ITEM", LEAK, "display item id %r (d001.., "
                   "unique)" % (iid,))
            continue
        byid[iid] = it
        role, src = it["role"], it["source"]
        if role not in ROLES:
            F.fail("CHK_MAP_ROLE", CHK, "item %s: role %r is not in the "
                   "closed list" % (iid, role))
            continue
        if not isinstance(src, dict) or not src or \
                not set(src) <= {"entity", "fact"}:
            F.fail("CHK_MAP_SOURCE", LEAK, "item %s: source %r" % (iid, src))
            continue
        ent, fact = src.get("entity"), src.get("fact")
        if ent is not None and ent not in known_ent and \
                not (isinstance(ent, str) and fs.kind(ent) and
                     all(p in fc.pts for p in fs.points_of(ent))):
            F.fail("CHK_MAP_SOURCE", LEAK, "item %s: source entity %r is not "
                   "an object of the public spec" % (iid, ent))
            continue
        if fact is not None and fact not in fs.facts:
            F.fail("CHK_MAP_SOURCE", LEAK, "item %s: source fact %r is not a "
                   "fact of the public spec" % (iid, fact))
            continue
        els = it["elements"]
        if not isinstance(els, list) or not els:
            F.fail("CHK_MAP_ITEM", CHK, "item %s draws nothing" % iid)
            continue
        for ref in els:
            if not isinstance(ref, str) or ref not in dr.by_ref:
                F.fail("CHK_MAP_REF", CHK, "item %s: element %r is not in the "
                       "SVG" % (iid, ref))
                continue
            if ref in owner:
                F.fail("CHK_MAP_SHARED", CHK, "element %s belongs to items %s "
                       "and %s (exactly one)" % (ref, owner[ref], iid))
                continue
            owner[ref] = iid
            item_vs_element(it, dr.by_ref[ref], fc, fs, F, rd)
    for el in dr.elements:
        if el.ref not in owner:
            F.fail("CHK_MAP_UNMAPPED", CHK, "element %s (%s %s) is in no "
                   "display item: unmapped ink" % (el.ref, el.tag, el.hook))
    # the element index agrees with the items and the SVG
    idx = om.get("elements")
    if not isinstance(idx, dict):
        F.fail("CHK_MAP_FORMAT", CHK, "elements is not a mapping")
    else:
        for ref, v in sorted(idx.items()):
            el = dr.by_ref.get(ref)
            if el is None or not isinstance(v, dict) or \
                    v.get("item") != owner.get(ref) or \
                    v.get("tag") != el.tag or set(v) != {"item", "tag"}:
                F.fail("CHK_MAP_INDEX", CHK, "elements[%s] = %r disagrees with "
                       "the SVG / the display items" % (ref, v))
        missing = sorted(set(dr.by_ref) - set(idx), key=_k)
        if missing:
            F.fail("CHK_MAP_INDEX", CHK, "elements index lacks %s" % missing)
    out = check_objects(om, fc, fs, F, byid)
    check_construction(om, fc, fs, F)
    return out


def item_vs_element(it, el, fc, fs, F, rd):
    iid, role, src = it["id"], it["role"], it["source"]
    tags, hook, want = ROLES[role]
    word, obj = element_object(el, rd)
    k = el.hook[0] if el.hook else None
    if el.tag not in tags or k != hook or word != want:
        F.fail("CHK_MAP_ROLE", CHK, "item %s (%s) claims %s, which is a %s "
               "%s" % (iid, role, el.ref, el.tag, el.hook))
        return
    ent, fact = src.get("entity"), src.get("fact")
    if ent is not None and ent != obj:
        F.fail("CHK_MAP_SOURCE", CHK, "item %s: element %s draws %s, the map "
               "says %s" % (iid, el.ref, obj, ent), obj)
    if "text" in it and it["text"] != (el.text or None):
        F.fail("CHK_MAP_TEXT", LEAK, "item %s: text %r is not the text of %s"
               % (iid, it["text"], el.ref), obj)
    if "text" in it and el.tag != "text":
        F.fail("CHK_MAP_TEXT", LEAK, "item %s: text on a non-text item" % iid)
    if fact is None:
        if role.endswith("_caption") or role == "line_name":
            F.fail("CHK_MAP_SOURCE", CHK, "item %s: a caption must name the "
                   "value fact it prints" % iid, obj)
        return
    f = fs.facts[fact]
    drawn = set(g["id"] for g in fs.draws)
    reader = set(g["id"] for g in fc.reader)
    if role.endswith("_caption"):
        if fact not in drawn or f.get("rel") not in SP.VALUE_RELS or \
                (f.get("args") or [None])[0] != obj:
            F.fail("CHK_MAP_SOURCE", CHK, "item %s: caption %s of %s names "
                   "%s, not a drawn value fact of it" % (iid, el.ref, obj,
                                                        fact), obj)
    elif role in ("point_name", "line_name"):
        if f.get("rel") != "name" or f.get("args") != [obj] or (role == "line_name" and fact not in drawn):
            F.fail("CHK_MAP_SOURCE", CHK, "item %s: name label of %s names "
                   "%s" % (iid, obj, fact), obj)
    else:
        if fact not in reader:
            F.fail("CHK_MAP_SOURCE", CHK, "item %s: %s cites %s, which the "
                   "reader of the figure does not see" % (iid, el.ref, fact),
                   obj)
            return
        pts = set()
        for a in f.get("args") or []:
            pts.update(fs.points_of(a))
        if not set(fs.points_of(obj)) <= pts:
            F.fail("CHK_MAP_SOURCE", CHK, "item %s: %s on %s is not about "
                   "fact %s" % (iid, el.ref, obj, fact), obj)


def check_objects(om, fc, fs, F, byid):
    objs = om.get("objects")
    if not isinstance(objs, dict):
        F.fail("CHK_MAP_FORMAT", CHK, "objects is not a mapping")
        return None
    for eid in fc.scope_objects():
        if eid not in objs:
            F.fail("CHK_MAP_ENTITY_MISSING", CHK, "object %s (an entity of the "
                   "figure, or named by a fact / item it shows) has no object "
                   "in the map: it could not be highlighted" % eid, eid)
    out = {}
    for eid, ob in sorted(objs.items()):
        kind = fs.kind(eid)
        if kind is None or not isinstance(ob, dict) or \
                set(ob) != {"kind", "parts"} or ob.get("kind") != kind or \
                not isinstance(ob.get("parts"), list):
            F.fail("CHK_MAP_OBJECT", LEAK, "object %r: %r (kind %s expected)"
                   % (eid, ob if isinstance(ob, dict) else type(ob), kind),
                   eid)
            continue
        if not all(p in fc.pts for p in fs.points_of(eid)):
            F.fail("CHK_MAP_OBJECT", CHK, "object %s: a point of it is not "
                   "drawn" % eid, eid)
            continue
        got, parts = set(), {}
        for pt in ob["parts"]:
            if not isinstance(pt, dict) or set(pt) != {"element", "span"} or \
                    pt["element"] not in fc.dr.by_ref:
                F.fail("CHK_MAP_PART", CHK, "object %s: part %r" % (eid, pt),
                       eid)
                continue
            ref, span = pt["element"], pt["span"]
            got.add(ref)
            if span != "whole":
                parts[ref] = span
            part_ok(eid, fc.dr.by_ref[ref], span, fc, fs, F)
        want = fc.measured_elements(eid)
        if got != want:
            F.fail("CHK_MAP_MISMATCH", "HIGHLIGHT_ON_MEASURED_GEOMETRY",
                   "object %s: the map says elements %s, the drawing measures "
                   "%s" % (eid, sorted(got, key=_k), sorted(want, key=_k)),
                   eid)
        out[eid] = {"elements": got, "parts": parts}
    return out


def part_ok(eid, el, span, fc, fs, F):
    """'whole': the element lies within the object (a highlight of it does
    not overreach); [X, Y]: X and Y are drawn points of the object on the
    element (a straight piece or a polygon's side)."""
    ns = fs.points_of(eid)
    P = [fc.P(n) for n in ns]
    hook = el.hook[0] if el.hook else None
    straight = hook in ("data-seg", "data-line", "data-ray") or (
        el.tag == "polygon" and fs.kind(eid) != "polygon")
    if span == "whole":
        if not straight:
            return
        if el.tag == "polygon":
            F.fail("CHK_MAP_OVERREACH", "SEG_PIECE_OF_LONGER_MAPPED", "object "
                   "%s: drawn by the whole polygon %s; the part must name its "
                   "span" % (eid, el.ref), eid)
            return
        kind = fs.kind(eid)
        own = {"line": ("data-line", SP.line_id),
               "ray": ("data-ray", SP.ray_id)}.get(kind)
        hn = split_names(el.hook[1]) if own and hook == own[0] else []
        if own and len(hn) == 2 and own[1](*hn) == eid:
            # (pilot_build) a line / ray's OWN element runs past its named
            # points by design (the line is infinite, the ray one way):
            # 'whole' is the object itself; its geometry is checked by
            # LINE_* / RAY_* on the drawing
            return
        for end in el.pts:
            if not any(G.d(end, x) <= T.PT_TOL_PX for x in P):
                F.fail("CHK_MAP_OVERREACH", "SEG_PIECE_OF_LONGER_MAPPED",
                       "object %s: element %s reaches past it (span 'whole'); "
                       "the part must name its span" % (eid, el.ref), eid)
                return
        return
    def on_obj(x):
        # a drawn point OF the object: its own point, or (pilot_build) a
        # drawn point lying on a straight object between its points (E on
        # AC: AC drawn as the pieces AE + EC)
        if x in ns:
            return True
        Q = fc.P(x)
        if Q is None or fs.kind(eid) not in ("segment", "line", "ray") or \
                len(P) != 2 or None in P:
            return False
        if G.line_dist(Q, P[0], P[1]) > T.ON_TOL_PX:
            return False
        tt = G.param(Q, P[0], P[1])
        k = fs.kind(eid)
        return k == "line" or (tt >= 0 and (k == "ray" or tt <= 1))
    if not (isinstance(span, list) and len(span) == 2 and
            all(isinstance(x, str) and fc.P(x) and on_obj(x) for x in span)
            and span[0] != span[1]):
        F.fail("CHK_MAP_PART", CHK, "object %s: span %r is not two drawn "
               "points of it" % (eid, span), eid)
        return
    X, Y = fc.P(span[0]), fc.P(span[1])
    n = len(el.pts)
    segs = [(el.pts[i], el.pts[(i + 1) % n])
            for i in range(n if el.tag == "polygon" else n - 1)]
    if not straight or not any(G.seg_dist(X, p, q) <= T.ON_TOL_PX and
                               G.seg_dist(Y, p, q) <= T.ON_TOL_PX
                               for p, q in segs):
        F.fail("CHK_MAP_PART", "HIGHLIGHT_ON_MEASURED_GEOMETRY", "object %s: "
               "span %s%s is not on element %s" % (eid, span[0], span[1],
                                                   el.ref), eid)


def check_construction(om, fc, fs, F):
    """The renderer's construction declaration (given / shown / what the
    student does), checked against the public spec and the drawing."""
    decl = om.get("construction")
    if decl is None:
        decl = []
    if not isinstance(decl, list):
        F.fail("CHK_MAP_FORMAT", CHK, "construction is not a list")
        return
    want = [t for t in fs.targets
            if (t.get("rel") or "").startswith("construct")]
    seen = set()
    for d in decl:
        if not isinstance(d, dict) or set(d) != CONS_KEYS:
            F.fail("CHK_CONS_DECL", "CONS_DECLARED_GIVEN_SHOWN_TODO",
                   "construction declaration %r: fields %s expected" % (
                       d, sorted(CONS_KEYS)))
            continue
        _no_free_text(d, fs, F)
        f = fs.facts.get(d["fact"])
        res = (f.get("args") or [None])[0] if f else None
        if f is None or f.get("role") != "to_construct" or \
                f.get("rel") != d["rel"] or f.get("item") != d["item"]:
            F.fail("CHK_CONS_DECL", "CONS_DECLARED_GIVEN_SHOWN_TODO",
                   "construction declaration %s does not restate a "
                   "to_construct fact of the figure's items" % d.get("fact"),
                   res)
            continue
        seen.add(d["fact"])
        sd = d["student_does"] if isinstance(d["student_does"], dict) else {}
        new = sd.get("new_points") or []
        mode = d["mode"]
        if sd.get("result") != res:
            F.fail("CHK_CONS_DECL", "CONS_DECLARED_GIVEN_SHOWN_TODO",
                   "%s: the declaration's result %r is not the fact's %s" % (
                       d["fact"], sd.get("result"), res), res)
        if mode not in CONS_MODES or (mode == "join") != (not new) or \
                (d["rel"] == "construct_join" and mode != "join"):
            F.fail("CHK_CONS_DECL", "CONS_DECLARED_GIVEN_SHOWN_TODO",
                   "%s: mode %r with new points %s ('connect given points' "
                   "is not 'find the point')" % (d["fact"], mode, new), res)
        for n in new:
            if n in fc.pts:
                F.fail("CHK_CONS_RESULT_DRAWN", "CONS_RESULT_NOT_DRAWN_ANY_FORM",
                       "%s: the declared new point %s is drawn" % (
                           d["fact"], n), res)
        for n in (sd.get("defining_points") or []):
            if n not in new and n not in fc.pts:
                F.fail("CHK_CONS_INPUT_UNDRAWN", "CONS_INPUTS_SHOWN", "%s: "
                       "defining point %s is declared given but not drawn"
                       % (d["fact"], n), res)
        shown = d["shown"] if isinstance(d["shown"], list) else []
        drawn_objs = set(fs.entities)
        for s in shown:
            if s not in drawn_objs:
                F.fail("CHK_CONS_DECL", "CONS_DECLARED_GIVEN_SHOWN_TODO",
                       "%s: declared shown %r is not in the figure" % (
                           d["fact"], s), res)
            elif s == res:
                F.fail("CHK_CONS_RESULT_DRAWN",
                       "CONS_RESULT_NOT_DRAWN_ANY_FORM", "%s: the result %s "
                       "is declared shown" % (d["fact"], s), res)
        for e in fs.entities:
            if e not in shown and fs.kind(e) in ("point", "segment"):
                F.fail("CHK_CONS_DECL", "CONS_DECLARED_GIVEN_SHOWN_TODO",
                       "%s: the figure shows %s but the declaration does not "
                       "list it" % (d["fact"], e), res)
    for t in want:
        if t["id"] not in seen:
            F.fail("CHK_CONS_DECL", "CONS_DECLARED_GIVEN_SHOWN_TODO",
                   "construction %s of this figure has no declaration (given"
                   " / shown / student does)" % t["id"],
                   (t.get("args") or [None])[0])


def _no_free_text(obj, fs, F):
    """Every string of a declaration is a public id, a point name or a
    closed token (no prose, no numbers that could be an answer)."""
    ok_tok = re.compile(r"^[a-z_]{1,40}$")
    item_ids = set()
    for q in fs.spec.get("questions") or []:
        item_ids.add(q.get("id"))
        item_ids.update(it.get("id") for it in q.get("items") or [])

    def walk(x):
        if isinstance(x, dict):
            for k, v in x.items():
                if not ok_tok.match(k):
                    return k
                r = walk(v)
                if r is not None:
                    return r
        elif isinstance(x, list):
            for v in x:
                r = walk(v)
                if r is not None:
                    return r
        elif isinstance(x, str):
            if not (x in fs.ents or x in fs.facts or ok_tok.match(x) or
                    x in item_ids or
                    split_names(x) is not None or
                    (fs.kind(x) and x.split(":")[0] in
                     ("seg", "ang", "poly", "line", "ray"))):
                return x
        elif x is not None and not isinstance(x, bool):
            return repr(x)
        return None
    bad = walk(obj)
    if bad is not None:
        F.fail("CHK_MAP_FIELDS", LEAK, "construction declaration carries "
               "free text %r" % (bad,))
