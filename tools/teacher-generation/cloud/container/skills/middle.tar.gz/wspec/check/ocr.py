# -*- coding: utf-8 -*-
"""OCR of the final display with macOS Vision (tools/wspec_ocr, compiled
once from tools/wspec_ocr.swift). Each expected label is read from its own
crop of the display: binarised, height-normalised, padded and, for a
one-character label, tiled (Vision skips lone letters even in a clean crop).
OCR is evidence of what is VISIBLE, never the source of truth: a label is
confirmed when a read matches its text (up to the confusables Vision cannot
tell apart, and a look-alike read that is also another label of the same
figure is ambiguous, not a match); a blank crop is a missing label (FAIL); no read or a different
read is REVIEW (never a guess)."""
import os
import subprocess
import tempfile

from . import tol as T
from .raster import Gray

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__))))
HELPER_SRC = os.path.join(ROOT, "tools", "wspec_ocr.swift")
HELPER = os.environ.get("WSPEC_OCR", os.path.join(ROOT, "tools", "wspec_ocr"))
HEB = set(chr(c) for c in range(0x05D0, 0x05EB)) | set(u"׳״")


def build_helper():
    """swiftc -O -o tools/wspec_ocr tools/wspec_ocr.swift (once)."""
    subprocess.check_call(["swiftc", "-O", "-o", HELPER, HELPER_SRC])


_BUILD_TRIED = []


def helper_ok():
    """The OCR helper is ready. v6.9 (skill vendoring): when the compiled
    helper is missing and its source ships beside it, it is built ON FIRST
    USE (once per process) with the command above; a machine without swiftc
    simply has no helper (the checker then reports REVIEW, never PASS)."""
    if os.path.isfile(HELPER) and os.access(HELPER, os.X_OK):
        return True
    if not _BUILD_TRIED and os.path.isfile(HELPER_SRC) and \
            "WSPEC_OCR" not in os.environ:
        _BUILD_TRIED.append(1)
        try:
            build_helper()
        except (OSError, subprocess.CalledProcessError):
            return False
    return os.path.isfile(HELPER) and os.access(HELPER, os.X_OK)


class OCRUnavailable(Exception):
    """The OCR service itself failed (helper crash, timeout, a batch it did
    not answer): an INFRASTRUCTURE reason, never a read of the display."""


class Reads(dict):
    """{path: reads} + .errors {path: why} (the helper's own failures)."""
    errors = None


def run_helper(paths, lang="en-US", timeout=300):
    """{path: [(text, conf), ...]} for a batch of images. v6.9 (Codex F1):
    the helper's failures are never swallowed -- a '#ERR' line, a non-zero
    exit, a crash / timeout or an image the helper never answered puts that
    path into the result's .errors ({path: reason}): read_labels makes it
    OCR_ERROR (OCR_UNAVAILABLE), never a read."""
    out = Reads((p, []) for p in paths)
    out.errors = {}
    if not paths:
        return out
    errs = {}
    try:
        r = subprocess.run([HELPER, "--lang", lang] + list(paths),
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           timeout=timeout)
    except (OSError, subprocess.SubprocessError) as e:
        for p in paths:
            errs[p] = "helper did not run: %s" % (type(e).__name__)
        r = None
    seen = set()
    if r is not None:
        cur = None
        for line in r.stdout.decode("utf-8", "replace").splitlines():
            parts = line.split("\t")
            if parts[0] == "#FILE":
                cur = parts[1] if len(parts) > 1 else None
                if cur in out:
                    seen.add(cur)
                continue
            if cur is None or cur not in out:
                continue
            if parts[0] == "#ERR":
                errs[cur] = "helper error '%s'" % (
                    parts[1] if len(parts) > 1 else "?")
                continue
            if parts[0] == "#ALT":
                if len(parts) >= 3:
                    out[cur].append((parts[1], float(parts[2]), "alt"))
                continue
            if len(parts) >= 2:
                try:
                    out[cur].append((parts[0], float(parts[1]), "top"))
                except ValueError:
                    errs[cur] = "helper output unreadable"
        if r.returncode != 0:
            for p in paths:
                errs.setdefault(p, "helper exited %d" % r.returncode)
        for p in paths:
            if p not in seen:
                errs.setdefault(p, "helper gave no answer for the image")
    out.errors.update(errs)
    return out


def conf_eq(a, b):
    if a == b:
        return True
    for grp in T.OCR_CONFUSABLE:
        if a in grp and b in grp:
            return True
    return False


def visible_part(text):
    """What the en-US reader is asked to confirm: the text without Hebrew
    letters, geresh / gershayim and spaces."""
    return "".join(ch for ch in text if ch not in HEB and ch != " ")


def matches(expected, read, tile):
    e = visible_part(expected)
    r = "".join(T.OCR_HOMOGLYPHS.get(ch, ch) for ch in read.replace(" ", ""))
    if any(ch in HEB for ch in expected):
        # mixed Hebrew text: the non-Hebrew part must be read as one run
        rr = "".join(ch for ch in r if ch not in HEB)
        return any(len(rr) >= i + len(e) and
                   all(conf_eq(x, y) for x, y in zip(rr[i:i + len(e)], e))
                   for i in range(max(1, len(rr) - len(e) + 1)))
    if tile > 1 and len(e) == 1:
        return len(r) >= 2 and abs(len(r) - tile) <= 1 and \
            all(conf_eq(ch, e) for ch in r)
    if len(r) != len(e):
        return False
    return all(conf_eq(x, y) for x, y in zip(r, e))


def exact(expected, read, tile):
    """The read is the expected text itself (up to homoglyphs and case-free
    only where the text is identical): no look-alike substitution needed."""
    e = visible_part(expected)
    r = "".join(T.OCR_HOMOGLYPHS.get(ch, ch) for ch in read.replace(" ", ""))
    if any(ch in HEB for ch in expected):
        return e in "".join(ch for ch in r if ch not in HEB)
    if tile > 1 and len(e) == 1:
        return len(r) >= 2 and abs(len(r) - tile) <= 1 and \
            all(ch == e for ch in r)
    return r == e


def rivals_of(ref, text, figure_texts):
    """The other labels of the same figure whose visible text differs."""
    e = visible_part(text)
    return sorted(set(t for (rf, t) in figure_texts
                      if rf != ref and visible_part(t) and
                      visible_part(t) != e))


def rival_hit(read, rivals):
    """A rival label the read also matches (exactly or by look-alike)."""
    for t in rivals:
        vt = visible_part(t)
        tile = T.OCR_TILE if len(vt) == 1 else 1
        if matches(t, read, tile):
            return t
    return None


def prepare(crop, height, tile):
    """Binarised, trimmed, height-normalised, (tiled,) padded crop."""
    g = crop.binarise()
    bb = g.ink_bbox()
    if bb is None:
        return None
    g = g.crop(bb)
    g = g.scaled(float(height) / max(1, g.h))
    gap = max(2, int(g.w * 0.25)) if tile > 1 else 0
    W = g.w * tile + gap * (tile - 1) + 2 * g.h
    H = 3 * g.h
    out = Gray.blank(W, H)
    for k in range(tile):
        out.paste(g, g.h + k * (g.w + gap), g.h)
    return out


def read_labels(display, labels, workdir=None, keep=False):
    """labels: list of (ref, text, box). Returns {ref: result} with result
    {status, reads, detail, ink}."""
    tmp = workdir or tempfile.mkdtemp(prefix="wspec_ocr_")
    jobs, res = {}, {}
    for ref, text, box in labels:
        crop = display.crop(box) if box else None
        ink = crop.ink_count() if crop else 0
        res[ref] = {"text": text, "ink_px": ink, "reads": [],
                    "status": None, "detail": ""}
        if crop is None or ink == 0:
            res[ref]["status"] = "MISSING"
            res[ref]["detail"] = "no ink where the label should be"
            continue
        e = visible_part(text)
        if not e:
            res[ref]["status"] = "NOT_OCR"
            res[ref]["detail"] = "only Hebrew characters: not read by OCR"
            continue
        tile = T.OCR_TILE if len(e) == 1 else 1
        for i, h in enumerate(T.OCR_GLYPH_H_PX):
            img = prepare(crop, h, tile)
            if img is None:
                continue
            p = os.path.join(tmp, "%s_%d.png" % (ref, i))
            with open(p, "wb") as fh:
                fh.write(img.png())
            jobs[p] = (ref, tile)
    reads = run_helper(sorted(jobs)) if jobs else {}
    errs = dict(getattr(reads, "errors", None) or {})
    figure_texts = [(ref, text) for ref, text, _ in labels]
    for p, (ref, tile) in sorted(jobs.items()):
        text = res[ref]["text"]
        rivals = rivals_of(ref, text, figure_texts)
        for (s, conf, kind) in reads.get(p, []):
            m = matches(text, s, tile)
            rec = {"read": s, "conf": round(conf, 3), "kind": kind,
                   "match": m}
            # a look-alike read (not the text itself) confirms the label
            # only when it is not also a read of another label of this
            # figure: D/O, B/8, S/5 swapped on the page must not PASS
            if m and not exact(text, s, tile):
                hit = rival_hit(s, rivals)
                if hit is not None:
                    rec["match"] = False
                    rec["ambiguous_with"] = hit
            res[ref]["reads"].append(rec)
    for p, why in sorted(errs.items()):
        ref = jobs[p][0]
        if res[ref]["status"] is None:
            # an infrastructure failure: OCR_UNAVAILABLE, never "not read"
            res[ref]["status"] = "OCR_ERROR"
            res[ref]["detail"] = "OCR_UNAVAILABLE: %s" % why
    for ref, r in res.items():
        if r["status"]:
            continue
        tops = [x for x in r["reads"] if x["kind"] == "top" and
                x["conf"] >= T.OCR_MIN_CONF]
        if any(x["match"] for x in tops):
            others = [x["read"] for x in tops if not x["match"]]
            r["status"] = "CONFIRMED"
            r["detail"] = "read %r" % [x["read"] for x in tops if x["match"]][0]
            if others:
                r["detail"] += " (other crops read %s)" % others
        elif tops:
            r["status"] = "CONTRADICTS"
            r["detail"] = "expected %r, read %s" % (
                r["text"], sorted(set(x["read"] for x in tops)))
            amb = sorted(set(x["ambiguous_with"] for x in tops
                             if x.get("ambiguous_with")))
            if amb:
                r["detail"] += (" -- a look-alike read that is also the "
                                "figure's label %s: ambiguous" % amb)
        else:
            r["status"] = "UNREAD"
            r["detail"] = "ink present but Vision read nothing"
    if not keep and workdir is None:
        for p in jobs:
            try:
                os.remove(p)
            except OSError:
                pass
        try:
            os.rmdir(tmp)
        except OSError:
            pass
    return res
