# -*- coding: utf-8 -*-
"""check_highlight for a PIE CHART figure (v6.16), independent of the
renderer: it reads the base SVG, the highlighted SVG and the checker's own
report of the base figure (rep = check.pie.check_pie(...)).

  HIGHLIGHT_EXACT_ELEMENTS        the overlay marks exactly the elements the
                                  checker MEASURED for the object (a sector:
                                  its wedge, name / value labels, leader,
                                  legend entry; a pie: all of its sectors'
                                  + outline, caption, total, legend; a build
                                  circle: the circle + its dot) -- HL_MISSING
                                  / HL_EXTRA; a highlight in one pie never
                                  marks the other pie
  HIGHLIGHT_ON_MEASURED_GEOMETRY  each overlay element lies on its element
                                  (the same wedge / leader path, the same
                                  circle, the same swatch square, a box that
                                  holds a label's MEASURED ink box and hugs
                                  it within 6 px, or 6 % of a long
                                  label's width)
  HIGHLIGHT_ADDS_NO_MATH          the base figure is unchanged byte for byte
                                  apart from ONE overlay group, placed right
                                  before the labels layer; the overlay has
                                  no text, no hook, no attribute outside its
                                  closed list (no arc, no number, no mark)"""
import re
import xml.etree.ElementTree as ET

from .report import FAIL, PASS, worst

NS = "{http://www.w3.org/2000/svg}"
_GROUP = re.compile(r'<g data-layer="highlight" data-object="([^"]*)">\n'
                    r'(.*?)\n</g>\n', re.S)
OK_ATTRS = {"cx", "cy", "r", "points", "d", "fill", "fill-opacity", "stroke",
            "stroke-width", "stroke-linecap", "stroke-linejoin", "data-hl"}
HUG_PX = 6.0
HUG_FRAC = 0.06
HOLD_PX = 1.0


def _nums(s):
    return [float(x) for x in re.findall(r"[0-9]+(?:\.[0-9]+)?", s or "")]


def check_highlight(base_svg, hl_svg, rep, object_id):
    out = []

    def fail(code, check, detail):
        out.append({"level": FAIL, "code": code, "check": check,
                    "object": object_id, "detail": detail})
    m = _GROUP.search(hl_svg)
    if m is None:
        fail("HL_NO_OVERLAY", "HIGHLIGHT_ADDS_NO_MATH", "no highlight group")
        return {"status": FAIL, "findings": out}
    if hl_svg[:m.start()] + hl_svg[m.end():] != base_svg:
        fail("HL_FIGURE_CHANGED", "HIGHLIGHT_ADDS_NO_MATH", "the figure is "
             "not byte for byte the base figure around the overlay")
    if len(_GROUP.findall(hl_svg)) != 1:
        fail("HL_EXTRA", "HIGHLIGHT_ADDS_NO_MATH", "more than one overlay")
    after = hl_svg[m.end():]
    if '<g data-layer="labels">' in base_svg and not after.startswith(
            '<g data-layer="labels">'):
        fail("HL_PLACE", "HIGHLIGHT_ADDS_NO_MATH", "the overlay is not right "
             "before the labels layer (it must lie under every label)")
    obj = m.group(1).replace("&gt;", ">").replace("&lt;", "<").replace(
        "&quot;", '"').replace("&amp;", "&")
    if obj != object_id:
        fail("HL_WRONG_OBJECT", "HIGHLIGHT_EXACT_ELEMENTS", "the overlay is "
             "for %r" % obj)
    try:
        grp = ET.fromstring('<g xmlns="http://www.w3.org/2000/svg">%s</g>'
                            % m.group(2))
        base = ET.fromstring(base_svg.encode("utf-8"))
    except ET.ParseError as e:
        fail("HL_UNREADABLE", "HIGHLIGHT_ADDS_NO_MATH", str(e))
        return {"status": FAIL, "findings": out}
    els = dict((e.get("id"), e) for e in base.iter() if e.get("id"))
    want = set((rep.get("measured") or {}).get("elements_of", {}).get(
        object_id) or [])
    boxes = (rep.get("measured") or {}).get("boxes") or {}
    if not want:
        fail("HL_UNKNOWN_OBJECT", "HIGHLIGHT_EXACT_ELEMENTS", "the checker "
             "measured no element for %s" % object_id)
    seen = []
    for h in grp:
        tag = h.tag.replace(NS, "")
        if tag not in ("path", "circle", "polygon") or len(h) or \
                (h.text or "").strip():
            fail("HL_ADDS_MATH", "HIGHLIGHT_ADDS_NO_MATH", "overlay element "
                 "%s (text / children)" % tag)
            continue
        bad = sorted(set(h.attrib) - OK_ATTRS)
        if bad:
            fail("HL_ADDS_MATH", "HIGHLIGHT_ADDS_NO_MATH", "overlay "
                 "attributes %s" % bad)
        ref = h.get("data-hl")
        seen.append(ref)
        el = els.get(ref)
        if el is None:
            fail("HL_EXTRA", "HIGHLIGHT_EXACT_ELEMENTS", "overlay for %r, no "
                 "such element" % ref)
            continue
        if ref not in want:
            fail("HL_EXTRA", "HIGHLIGHT_EXACT_ELEMENTS", "overlay for %s (%s "
                 "of %s), not a part of %s" % (ref, el.get("data-pie"),
                                               el.get("data-for"), object_id))
        etag = el.tag.replace(NS, "")
        ok = True
        if etag == "path":
            ok = tag == "path" and h.get("d") == el.get("d")
        elif etag == "circle":
            ok = tag == "circle" and h.get("cx") == el.get("cx") and \
                h.get("cy") == el.get("cy")
            if ok and el.get("data-pie") == "bdot":
                ok = float(h.get("r")) <= float(el.get("r")) + 4.0
            elif ok:
                ok = h.get("r") == el.get("r") and h.get("fill") == "none"
        elif etag == "polygon":
            ok = tag == "polygon" and h.get("points") == el.get("points")
        elif etag == "text":
            b = boxes.get(ref)
            p = _nums(h.get("points"))
            if tag != "polygon" or len(p) != 8 or b is None:
                ok = False
            else:
                xs, ys = p[0::2], p[1::2]
                hb = (min(xs), min(ys), max(xs), max(ys))
                # hugs: 6 px, or 6 % of a long label's width (the renderer
                # boxes by font metrics, the checker measures raster ink)
                hug = max(HUG_PX, HUG_FRAC * (b[2] - b[0]))
                ok = hb[0] <= b[0] + HOLD_PX and hb[1] <= b[1] + HOLD_PX and \
                    hb[2] >= b[2] - HOLD_PX and hb[3] >= b[3] - HOLD_PX and \
                    b[0] - hb[0] <= hug and b[1] - hb[1] <= HUG_PX and \
                    hb[2] - b[2] <= hug and hb[3] - b[3] <= HUG_PX
        if not ok:
            fail("HL_OFF_GEOMETRY", "HIGHLIGHT_ON_MEASURED_GEOMETRY", "the "
                 "overlay of %s (%s) does not lie on it" % (
                     ref, el.get("data-pie")))
    if len(seen) != len(set(seen)):
        fail("HL_EXTRA", "HIGHLIGHT_EXACT_ELEMENTS", "an element highlighted "
             "twice")
    miss = sorted(want - set(seen))
    if miss:
        fail("HL_MISSING", "HIGHLIGHT_EXACT_ELEMENTS", "parts of %s not "
             "highlighted: %s" % (object_id, miss))
    st = worst([f["level"] for f in out]) if out else PASS
    return {"status": st, "findings": out}
