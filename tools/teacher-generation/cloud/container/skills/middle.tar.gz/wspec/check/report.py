# -*- coding: utf-8 -*-
"""Findings and verdicts. A finding is FAIL (a known defect: wrong maths,
answer exposure, wrong / misleading display, outside the dialect), REVIEW
(ambiguous or not confirmable: a human must look; never a guess) or NOTE
(recorded evidence, no effect on the verdict)."""

FAIL, REVIEW, NOTE, PASS, NA, UNSUPPORTED = (
    "FAIL", "REVIEW", "NOTE", "PASS", "NA", "UNSUPPORTED")
_RANK = {PASS: 0, NA: 0, NOTE: 0, UNSUPPORTED: 1, REVIEW: 2, FAIL: 3}


def worst(statuses, default=PASS):
    out = default
    for s in statuses:
        if _RANK.get(s, 0) > _RANK.get(out, 0):
            out = s
    return out


class Findings(object):
    def __init__(self):
        self.items = []

    def add(self, level, code, check, detail, obj=None):
        f = {"level": level, "code": code, "check": check,
             "object": obj, "detail": detail}
        if f not in self.items:
            self.items.append(f)
        return f

    def fail(self, code, check, detail, obj=None):
        return self.add(FAIL, code, check, detail, obj)

    def review(self, code, check, detail, obj=None):
        return self.add(REVIEW, code, check, detail, obj)

    def note(self, code, check, detail, obj=None):
        return self.add(NOTE, code, check, detail, obj)

    def status(self, pred=None):
        return worst(f["level"] for f in self.items
                     if pred is None or pred(f))


class CheckerInputError(Exception):
    """The checker was given something it must not read (the private
    model / answer store) or cannot read at all."""
