"""Independently measure source-bound, axis-aligned parameter lines.

Only public source clauses, roles and printed fixed coordinates enter this
proof. The free parameter never receives a numeric public value. A declared
illustrative point is a private placement, not a solution of the question.
"""
import re
from fractions import Fraction
from .report import CheckerInputError


def num(v):
    try:return Fraction(str(v))
    except (ValueError,TypeError,ZeroDivisionError):return None

def norm(v):return ' '.join(v.replace('$','').split()) if isinstance(v,str) else ''

def public_objects(raw,fig,facts):
    if 'loci' not in fig:return {}
    def bad(msg):raise CheckerInputError('parameter locus: '+msg)
    rows=fig['loci']
    if not isinstance(rows,list) or not rows or (fig.get('frame') or {}).get('family')!='coordinate_plane' or (fig.get('frame') or {}).get('sketch') or 'data' in fig or 'graph' in fig:bad('invalid locus frame/list')
    text,owners,printed={},{},set()
    for q in raw.get('questions',[]):
        for sc in [q]+q.get('items',[]):
            owners[sc['id']]=q['id'];text[sc['id']]=norm(sc.get('text'))
            for block in sc.get('bound',[]):
                printed.update(block.get('prints',[]))
                for b in block.get('bind',[]):
                    fs=b.get('fact');printed.update(fs if isinstance(fs,list) else [fs] if fs else [])
    ents={e['id']:e for e in raw.get('entities',[])};question=owners.get(fig['scope']);out={};tokens=set()
    for r in rows:
        if not isinstance(r,dict) or set(r)!={'id','point','variable','coordinate_fact','domain','source','example'} or not all(isinstance(r.get(k),str) for k in ('id','point','variable','coordinate_fact')) or not re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]{0,31}',r['id']) or not isinstance(r.get('example'),bool):bad('closed locus row required')
        p=ents.get(r['point'],{});v=ents.get(r['variable'],{});f=facts.get(r['coordinate_fact'],{});args=f.get('args') or []
        if p.get('kind')!='point' or v.get('kind')!='variable' or f.get('role')!='given' or f.get('rel')!='coordinate' or len(args)!=2 or args[0]!=r['point'] or args[1] not in ('axis:x','axis:y') or num(f.get('value')) is None or f.get('id') not in printed or owners.get(f.get('item'))!=question:bad('point/variable/fixed coordinate is not a printed given')
        src=r['source'];dom=r['domain']
        if not isinstance(src,dict) or set(src)!={'scope','text'} or not isinstance(src.get('scope'),str) or owners.get(src['scope'])!=question or not norm(src.get('text')) or norm(src['text']) not in text.get(src['scope'],''):bad('source clause is not printed in this question')
        pair=[v['name'],str(f['value'])] if args[1]=='axis:y' else [str(f['value']),v['name']]
        if not re.search(re.escape(p['name'])+r'\s*\(\s*'+re.escape(pair[0])+r'\s*,\s*'+re.escape(pair[1])+r'\s*\)',norm(src['text'])) or 'מקווקו' not in src['text']:bad('source does not state the parameter pair/dashed line')
        if not isinstance(dom,dict) or set(dom)!={'lo','lo_in'} or num(dom.get('lo'))!=0 or dom.get('lo_in') is not True or not re.search(r'\b'+re.escape(v['name'])+r'\b.*אינו שלילי',norm(src['text'])):bad('domain is not the stated nonnegative parameter')
        if r['example'] != (r['point'] in fig.get('entities',[])):bad('illustrative point declaration disagrees with displayed entities')
        free='axis:y' if args[1]=='axis:x' else 'axis:x'
        if any(ff.get('rel')=='coordinate' and ff.get('args')==[r['point'],free] and owners.get(ff.get('item'))==question and 'value' in ff for ff in facts.values()):bad('a free parameter coordinate has a public numeric value')
        oid='line:'+args[1].split(':')[1]+'='+str(f['value'])
        if oid in out or r['id'] in tokens:bad('duplicate locus identity')
        tokens.add(r['id']);out[oid]=dict(r,id=oid,token=r['id'],kind='line',through=[],axis=args[1],value=f['value'],free_axis=free,locus=True)
    return out


def measure(cc):
    cc.locus_elements={}
    objects=cc.pub.locus_objects
    bytoken={r['token']:(oid,r) for oid,r in objects.items()}
    seen=set()
    for e in cc.els('data-locus'):
        if e.hv not in bytoken:
            cc.F.fail('CHK_LOCUS_UNDECLARED','LINE_THROUGH_COORDS','parameter line is not declared by public source',None);continue
        oid,r=bytoken[e.hv]
        if oid in seen:cc.F.fail('CHK_LOCUS_TWICE','LINE_THROUGH_COORDS','parameter line occurs twice',oid)
        seen.add(oid);cc.locus_elements.setdefault(oid,set()).add(e.ref)
        fixed=cc.axes[r['axis']];free=cc.axes[r['free_axis']]
        if fixed.step is None or free.step is None:
            cc.F.review('CHK_LOCUS_AXIS_UNMEASURED','LINE_THROUGH_COORDS','axis values unavailable for line proof',oid);continue
        i=float(num(r['value'])/fixed.step)+fixed.zero
        lo=max(0,float(num(r['domain']['lo'])/free.step)+free.zero)
        fp=cc.px(fixed,i);a=cc.px(free,lo);b=cc.px(free,free.n)
        want=[(a,fp),(b,fp)] if r['axis']=='axis:y' else [(fp,a),(fp,b)]
        points=e.pts
        fixedk=1 if r['axis']=='axis:y' else 0
        if len(points)!=2 or any(abs(p[fixedk]-fp)>.3 for p in points):
            cc.F.fail('CHK_LOCUS_OFF_COORDINATE','LINE_THROUGH_COORDS','dashed line is not at its printed fixed coordinate',oid)
        if len(points)!=2 or min(max(sum((x-y)**2 for x,y in zip(p,q))**.5 for p,q in zip(points,want)),max(sum((x-y)**2 for x,y in zip(p,q))**.5 for p,q in zip(points,want[::-1])))>.3:
            cc.F.fail('CHK_LOCUS_NOT_FULL_DOMAIN','LINE_EXTENDS_PAST_POINTS','parameter line does not cover the visible stated domain',oid)
        if e.a.get('stroke-dasharray')!='3 3':cc.F.fail('CHK_LOCUS_NOT_DASHED','LINE_THROUGH_COORDS','source states a dashed parameter line',oid)
        if len(points)==2:cc.pieces.append((e,points[0],points[1],'line'))
        if r['example'] and r['point'] in cc.pts:
            p=cc.pts[r['point']]
            if abs(p[fixedk]-fp)>.3 or not min(a,b)-.3<=p[1-fixedk]<=max(a,b)+.3:
                cc.F.fail('CHK_PARAMETER_EXAMPLE_OFF_LOCUS','PT_AT_COORDS','illustrative point is outside the public parameter locus',r['point'])
    for oid in objects:
        if oid not in seen:cc.F.fail('CHK_LOCUS_MISSING','LINE_THROUGH_COORDS','declared parameter locus is absent',oid)
