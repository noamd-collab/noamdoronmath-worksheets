# -*- coding: utf-8 -*-
"""A strict reader of the closed SVG dialect, written for the checker on its
own (it shares only the dialect DATA file wspec/svg_dialect.json with the
renderer, never code). Anything outside the dialect is a FAIL with the
element and attribute named; nothing outside it is measured.

Element references follow the dialect's id rule (wspec-svg/4 grammar
element_id): the k-th drawable element (line, circle, polygon, polyline,
path, text) in document order, k from 1, is "e%04d" % k. Elements carry
id="e0001", ... on all or none; an id must equal its positional reference
(ids carry no information; any other id is outside the dialect, VD3-05).
Without an element_id rule in the dialect, ids are refused altogether."""
import json
import math
import os
import re
import xml.etree.ElementTree as ET

from . import tol as T

HERE = os.path.dirname(os.path.abspath(__file__))
DIALECT_JSON = os.path.join(os.path.dirname(HERE), "svg_dialect.json")
SVG_NS = "http://www.w3.org/2000/svg"
XML_DECL = '<?xml version="1.0" encoding="UTF-8"?>'
DRAWABLE = ("line", "circle", "polygon", "polyline", "path", "text")
PAINTED = ("line", "circle", "polygon", "polyline", "path")
NAME = r"[A-Z][1-9]?'{0,3}"
NAME_RE = re.compile("^%s$" % NAME)
NAMES_RE = re.compile("(%s)" % NAME)
PAIR = "(%s)(%s)" % (NAME, NAME)
TRIPLE = "(%s)(%s)(%s)" % (NAME, NAME, NAME)
HOOK_ATTRS = ("data-pt", "data-seg", "data-line", "data-ray", "data-poly",
              "data-mark")


# (wspec-svg/5) the checker's OWN reading of the bidi rule -- it does not
# import the renderer's wspec.bidi: a Hebrew run (letters, geresh,
# gershayim; a space / prime between two of them inside it) is the END of
# a label; stored in visual order it is that run reversed
_HEB = re.compile(u"[\u05d0-\u05ea]")          # a Hebrew LETTER ('A׳' is a prime)
_HEB_RUN = re.compile(u"[\u05d0-\u05ea\u05f3\u05f4]"
                      u"(?:[\u05d0-\u05ea\u05f3\u05f4 '\"]*"
                      u"[\u05d0-\u05ea\u05f3\u05f4])?")
_OVERRIDE = (("direction", "ltr"), ("unicode-bidi", "bidi-override"))


def _logical(t):
    runs = list(_HEB_RUN.finditer(t))
    if len(runs) != 1 or t[runs[0].end():].strip():
        return t
    m = runs[0]
    return t[:m.start()] + m.group(0)[::-1] + t[m.end():]


def _bidi_issue(t, a):
    have = [k for k, _v in _OVERRIDE if k in a]
    if _HEB.search(t):
        if not all(a.get(k) == v for k, v in _OVERRIDE):
            return ("a Hebrew label without direction=ltr unicode-bidi="
                    "bidi-override prints its letters reversed (no bidi in "
                    "the PDF's SVG text)")
        runs = list(_HEB_RUN.finditer(t))
        if len(runs) != 1 or t[runs[0].end():].strip():
            return "the Hebrew run is not the end of the label"
        return None
    if have:
        return "%s on a label without a Hebrew letter" % "/".join(have)
    return None


def load_dialect(path=DIALECT_JSON):
    with open(path, "rb") as fh:
        return json.loads(fh.read().decode("utf-8"))


def split_names(s):
    """'ABC' -> ['A','B','C']; "A'B1" -> ["A'", 'B1']; None if not names."""
    if not isinstance(s, str) or not s:
        return None
    out = NAMES_RE.findall(s)
    if "".join(out) != s:
        return None
    return out


class Element(object):
    def __init__(self, ref, tag, attrs, depth):
        self.ref, self.tag, self.a, self.depth = ref, tag, attrs, depth
        self.text = None
        self.hook = None       # (hook attr, value)
        self.pts = []          # geometry: list of (x, y)
        self.paint = None      # stroke paint name
        self.layer = None

    def __repr__(self):
        return "<%s %s %s>" % (self.ref, self.tag, self.hook)


class Drawing(object):
    """The parsed figure: canvas, elements in document order, and the
    dialect findings."""

    def __init__(self):
        self.W = self.H = None
        self.elements = []
        self.by_ref = {}
        self.issues = []       # (code, detail)
        self.raw = b""

    def bad(self, code, detail):
        self.issues.append((code, detail))

    @property
    def ok(self):
        return not self.issues


class DialectReader(object):
    def __init__(self, dialect=None):
        d = dialect or load_dialect()
        self.d = d
        self.num_re = re.compile(d["grammar"]["number"])
        self.paint = dict((v, k) for k, v in d["paint"].items())
        self.widths = set(d["stroke_widths"].values())
        self.dashes = set(v for v in d["dash_styles"].values() if v != "none")
        self.radii = set(d["point_radii"])
        self.fsizes = set(d["font_sizes"])
        self.families = set(d["font_families"])
        self.caps = set(d["linecaps"])
        self.joins = set(d["linejoins"])
        self.anchors = set(d["text_anchors"])
        self.layers = set(d["layers"])
        self.marks = d["marks"]
        self.mark_counts = set(d["mark_counts"])
        self.max_depth = int(d["max_depth"])
        self.canvas_max = float(d["canvas_max_px"])
        al = d["text_alphabet"]
        self.alpha_ranges = [(a, b) for a, b in al["ranges"]]
        self.alpha_singles = set(al["singles"])
        self.between_digits = set(al.get("between_digits", ""))
        rule = d["grammar"].get("element_id")
        self.id_re = re.compile(rule) if rule else None

    def ref(self, k):
        """The positional reference of the k-th drawable (k from 0)."""
        return "e%04d" % (k + 1)

    # ------------------------------------------------------------ values --
    def number(self, s):
        if not isinstance(s, str) or not self.num_re.match(s):
            raise ValueError("not a dialect number: %r" % s)
        return float(s)

    def points(self, s):
        if not isinstance(s, str) or s != s.strip() or "  " in s:
            raise ValueError("bad points: %r" % s)
        out = []
        for pair in s.split(" "):
            xy = pair.split(",")
            if len(xy) != 2:
                raise ValueError("bad points pair %r" % pair)
            out.append((self.number(xy[0]), self.number(xy[1])))
        return out

    def path(self, s):
        toks = s.split(" ") if isinstance(s, str) else []
        if len(toks) < 6 or toks[0] != "M" or len(toks) % 3:
            raise ValueError("bad path d: %r" % s)
        out = []
        for i in range(0, len(toks), 3):
            cmd = toks[i]
            if cmd != ("M" if i == 0 else "L"):
                raise ValueError("path command %r (only M then L)" % cmd)
            out.append((self.number(toks[i + 1]), self.number(toks[i + 2])))
        return out

    def text_ok(self, t):
        if not t:
            return False
        has_range = False
        for i, ch in enumerate(t):
            if any(a <= ch <= b for a, b in self.alpha_ranges):
                has_range = True
                continue
            if ch in self.alpha_singles:
                continue
            if ch in self.between_digits and 0 < i < len(t) - 1 and \
                    t[i - 1].isdigit() and t[i + 1].isdigit() and \
                    t[i - 1] in "0123456789" and t[i + 1] in "0123456789":
                continue
            return False
        return has_range

    # ------------------------------------------------------------- parse --
    def read(self, data):
        dr = Drawing()
        if isinstance(data, str):
            data = data.encode("utf-8")
        dr.raw = data
        try:
            txt = data.decode("utf-8")
        except UnicodeDecodeError:
            dr.bad("CHK_DIALECT", "not UTF-8")
            return dr
        body = txt[len(XML_DECL):] if txt.startswith(XML_DECL) else txt
        if "<?" in body:
            dr.bad("CHK_DIALECT", "a processing instruction other than the "
                   "XML declaration")
        if "<!" in body:
            dr.bad("CHK_DIALECT", "'<!' (comment, DOCTYPE, ENTITY or CDATA) "
                   "- could carry hidden text")
        if "&" in body:
            dr.bad("CHK_DIALECT", "a character / entity reference ('&')")
        if dr.issues:
            return dr
        try:
            root = ET.fromstring(body)
        except ET.ParseError as e:
            dr.bad("CHK_DIALECT", "XML parse error: %s" % e)
            return dr
        if root.tag != "{%s}svg" % SVG_NS:
            dr.bad("CHK_DIALECT", "root is %s, not svg in the SVG namespace"
                   % root.tag)
            return dr
        if body.rstrip()[-6:] != "</svg>":
            dr.bad("CHK_DIALECT", "content after the root element")
        self._root(root, dr)
        counter = [0]
        ids = []
        self._walk(root, dr, 1, counter, ids, None)
        if ids and len(ids) != len(dr.elements):
            dr.bad("CHK_DIALECT_ID", "id on %d of %d drawable elements: all "
                   "or none" % (len(ids), len(dr.elements)))
        self._corner_dots(dr)
        return dr

    def _attrs(self, el, dr, where):
        out = {}
        for k, v in el.attrib.items():
            if k.startswith("{"):
                dr.bad("CHK_DIALECT", "%s: namespaced attribute %s" % (where, k))
                continue
            out[k] = v
        return out

    def _root(self, root, dr):
        a = self._attrs(root, dr, "svg")
        spec = self.d["elements"]["svg"]
        for k in a:
            if k not in spec["required"] + spec["optional"]:
                dr.bad("CHK_DIALECT", "svg: attribute %s" % k)
        vb = a.get("viewBox", "")
        m = re.match(r"^0 0 (\S+) (\S+)$", vb)
        try:
            if not m:
                raise ValueError
            W, H = self.number(m.group(1)), self.number(m.group(2))
            if not (0 < W <= self.canvas_max and 0 < H <= self.canvas_max):
                raise ValueError
            dr.W, dr.H = W, H
        except ValueError:
            dr.bad("CHK_DIALECT", "svg: viewBox %r" % vb)
            dr.W, dr.H = 1.0, 1.0
        for k, want in (("width", dr.W), ("height", dr.H)):
            if k in a:
                try:
                    if self.number(a[k]) != want:
                        raise ValueError
                except ValueError:
                    dr.bad("CHK_DIALECT", "svg: %s %r != viewBox" % (k, a[k]))
        if (root.text or "").strip():
            dr.bad("CHK_DIALECT", "svg: character data %r" % root.text.strip())

    def _corner_dots(self, dr):
        """(wspec-svg/5, P4; the checker's own reading) a dot of radius
        0.75 hides in the join of the strokes that END at it: it must sit
        where >= 2 solid strokes of width >= 1.5 end at an angle and no
        stroke passes through -- else the point it stands for is not
        visible."""
        pieces = []
        for e in dr.elements:
            a = e.a
            if e.tag not in ("line", "polygon") or \
                    a.get("stroke", "none") == "none" or len(e.pts) < 2:
                continue
            ps = list(e.pts)
            pairs = list(zip(ps, ps[1:])) + (
                [(ps[-1], ps[0])] if e.tag == "polygon" else [])
            for p, q in pairs:
                pieces.append((p, q, a.get("stroke-width"),
                               "stroke-dasharray" in a))
        for e in dr.elements:
            if e.tag != "circle" or e.a.get("r") != "0.75" or not e.pts:
                continue
            c = e.pts[0]
            dirs, through = [], False
            for p, q, w, dashed in pieces:
                dp = math.hypot(c[0] - p[0], c[1] - p[1])
                dq = math.hypot(c[0] - q[0], c[1] - q[1])
                if dp > 0.05 and dq > 0.05:
                    L2 = (q[0] - p[0]) ** 2 + (q[1] - p[1]) ** 2
                    t = max(0.0, min(1.0, ((c[0] - p[0]) * (q[0] - p[0]) +
                                           (c[1] - p[1]) * (q[1] - p[1])) /
                                     L2)) if L2 else 0.0
                    if math.hypot(c[0] - p[0] - t * (q[0] - p[0]),
                                  c[1] - p[1] - t * (q[1] - p[1])) <= 0.05:
                        through = True
                    continue
                if dashed or float(w or 0) < 1.5:
                    continue
                o = q if dp <= 0.05 else p
                L = math.hypot(o[0] - c[0], o[1] - c[1])
                if L > 0.05:
                    dirs.append(((o[0] - c[0]) / L, (o[1] - c[1]) / L))
            opposite = any(u[0] * v[0] + u[1] * v[1] < -0.9998
                           for i, u in enumerate(dirs) for v in dirs[i + 1:])
            if through or len(dirs) < 2 or opposite:
                dr.bad("CHK_DIALECT", "%s <circle>: r=0.75 is a corner dot "
                       "but %s is no corner of the drawn strokes (the point "
                       "would not be visible)" % (e.ref, c))

    def _walk(self, el, dr, depth, counter, ids, layer):
        spec_el = self.d["elements"]
        me = el.tag.split("}")[-1]
        for ch in list(el):
            if not isinstance(ch.tag, str):
                dr.bad("CHK_DIALECT", "non-element node")
                continue
            if not ch.tag.startswith("{%s}" % SVG_NS):
                dr.bad("CHK_DIALECT", "element %s outside the SVG namespace"
                       % ch.tag)
                continue
            tag = ch.tag.split("}")[-1]
            if (ch.tail or "").strip():
                dr.bad("CHK_DIALECT", "character data %r after <%s>"
                       % (ch.tail.strip(), tag))
            if tag not in spec_el or tag == "svg":
                dr.bad("CHK_DIALECT", "element <%s> (not in the dialect)" % tag)
                continue
            if tag not in spec_el[me]["children"]:
                dr.bad("CHK_DIALECT", "<%s> inside <%s>" % (tag, me))
            if depth + 1 > self.max_depth:
                dr.bad("CHK_DIALECT", "<%s> nested deeper than %d"
                       % (tag, self.max_depth))
            if tag == "g":
                a = self._attrs(ch, dr, "g")
                lay = layer
                for k, v in a.items():
                    if k == "data-layer" and v in self.layers:
                        lay = v
                    else:
                        dr.bad("CHK_DIALECT", "g: attribute %s=%r" % (k, v))
                if (ch.text or "").strip():
                    dr.bad("CHK_DIALECT", "g: character data %r"
                           % ch.text.strip())
                self._walk(ch, dr, depth + 1, counter, ids, lay)
                continue
            ref = self.ref(counter[0])
            counter[0] += 1
            e = Element(ref, tag, self._attrs(ch, dr, tag), depth + 1)
            e.layer = layer
            dr.elements.append(e)
            dr.by_ref[ref] = e
            if "id" in e.a:
                ids.append(e.a["id"])
                if self.id_re is None or not self.id_re.match(e.a["id"]) \
                        or e.a["id"] != ref:
                    dr.bad("CHK_DIALECT_ID", "%s: id=%r (must be the positional "
                           "reference %s)" % (tag, e.a["id"], ref))
            self._element(ch, e, dr)

    def _element(self, node, e, dr):
        spec = self.d["elements"][e.tag]
        a = e.a
        where = "%s <%s>" % (e.ref, e.tag)
        allowed = set(spec["required"] + spec["optional"] + ["id"])
        for k in a:
            if k not in allowed:
                dr.bad("CHK_DIALECT", "%s: attribute %s=%r" % (where, k, a[k]))
        for k in spec["required"]:
            if k not in a:
                dr.bad("CHK_DIALECT", "%s: missing %s" % (where, k))
        if len(list(node)):
            dr.bad("CHK_DIALECT", "%s: child elements" % where)
        if e.tag != "text" and (node.text or "").strip():
            dr.bad("CHK_DIALECT", "%s: character data" % where)
        hooks = [h for h in HOOK_ATTRS if h in a]
        if e.tag in PAINTED:
            if len(hooks) != 1:
                dr.bad("CHK_DIALECT", "%s: %d hooks (exactly one)"
                       % (where, len(hooks)))
            elif hooks[0] not in spec["hooks"]:
                dr.bad("CHK_DIALECT", "%s: hook %s" % (where, hooks[0]))
            else:
                e.hook = (hooks[0], a[hooks[0]])
        # paint
        stroke = a.get("stroke")
        if stroke is not None:
            nm = self.paint.get(stroke)
            ok = {"circle": ("none",), "polygon": ("none", "ink", "guide")
                  }.get(e.tag, ("ink", "guide"))
            if nm not in ok:
                dr.bad("CHK_DIALECT", "%s: stroke %r" % (where, stroke))
            e.paint = nm
            if nm == "none":
                if "stroke-width" in a:
                    dr.bad("CHK_DIALECT", "%s: stroke-width with no stroke"
                           % where)
            elif e.tag != "circle" and a.get("stroke-width") not in self.widths:
                dr.bad("CHK_DIALECT", "%s: stroke-width %r"
                       % (where, a.get("stroke-width")))
        fill = a.get("fill")
        if fill is not None:
            okf = {"circle": ("ink",), "polygon": ("none", "shade"),
                   "text": ("ink",)}.get(e.tag, ("none",))
            if self.paint.get(fill) not in okf:
                dr.bad("CHK_DIALECT", "%s: fill %r" % (where, fill))
        if e.tag == "polygon" and self.paint.get(fill) == "none" and \
                self.paint.get(stroke) == "none":
            dr.bad("CHK_DIALECT", "%s: invisible polygon" % where)
        if "stroke-dasharray" in a:
            if a["stroke-dasharray"] not in self.dashes or "data-mark" in a:
                dr.bad("CHK_DIALECT", "%s: stroke-dasharray %r"
                       % (where, a["stroke-dasharray"]))
        for k, allowed_vals in (("stroke-linecap", self.caps),
                                ("stroke-linejoin", self.joins),
                                ("font-size", self.fsizes),
                                ("font-family", self.families),
                                ("text-anchor", self.anchors)):
            if k in a and a[k] not in allowed_vals:
                dr.bad("CHK_DIALECT", "%s: %s=%r" % (where, k, a[k]))
        # geometry
        try:
            if e.tag == "line":
                e.pts = [(self.number(a["x1"]), self.number(a["y1"])),
                         (self.number(a["x2"]), self.number(a["y2"]))]
            elif e.tag == "circle":
                e.pts = [(self.number(a["cx"]), self.number(a["cy"]))]
                if a.get("r") not in self.radii:
                    dr.bad("CHK_DIALECT", "%s: r=%r" % (where, a.get("r")))
                e.r = float(a.get("r") or 0)
            elif e.tag in ("polygon", "polyline"):
                e.pts = self.points(a["points"])
            elif e.tag == "path":
                e.pts = self.path(a["d"])
            elif e.tag == "text":
                e.pts = [(self.number(a["x"]), self.number(a["y"]))]
        except (ValueError, KeyError) as ex:
            dr.bad("CHK_DIALECT", "%s: geometry %s" % (where, ex))
            e.pts = []
        need = {"line": 2, "polygon": 3, "polyline": 2, "path": 2}.get(e.tag, 1)
        if len(e.pts) < need:
            dr.bad("CHK_DIALECT", "%s: %d points" % (where, len(e.pts)))
        for i in range(1, len(e.pts)):
            if e.pts[i] == e.pts[i - 1]:
                dr.bad("CHK_DIALECT", "%s: repeated point" % where)
        if e.tag == "polygon" and e.pts and e.pts[0] == e.pts[-1]:
            dr.bad("CHK_DIALECT", "%s: polygon repeats its first point" % where)
        for (x, y) in e.pts:
            if not (0 <= x <= dr.W and 0 <= y <= dr.H):
                dr.bad("CHK_DIALECT", "%s: (%s, %s) off the canvas"
                       % (where, x, y))
        if e.tag == "circle" and e.pts:
            (x, y), r = e.pts[0], getattr(e, "r", 0)
            if x - r < 0 or y - r < 0 or x + r > dr.W or y + r > dr.H:
                dr.bad("CHK_DIALECT", "%s: dot crosses the canvas edge" % where)
        # hooks' grammar
        if e.hook:
            self._hook_grammar(e, dr, where)
        if e.tag == "text":
            t = node.text or ""
            # wspec-svg/5 (v6.9 fix r2, E1b): a label with a Hebrew letter
            # carries the bidi override and stores its text in VISUAL order
            # (WeasyPrint prints SVG text without bidi); e.text is LOGICAL
            why = _bidi_issue(t, a)
            if why:
                dr.bad("CHK_DIALECT", "%s: text %r: %s" % (where, t, why))
            e.text = _logical(t) if _HEB.search(t) else t
            e.stored_text = t
            if not self.text_ok(t):
                dr.bad("CHK_DIALECT", "%s: text %r outside the alphabet"
                       % (where, t))
            e.hook = ("data-for", a.get("data-for"))
            if not self._for_ok(a.get("data-for")):
                dr.bad("CHK_DIALECT", "%s: data-for=%r" % (where,
                                                           a.get("data-for")))

    def _hook_grammar(self, e, dr, where):
        k, v = e.hook
        n = split_names(v) if k != "data-mark" else None
        if k == "data-pt":
            ok = n is not None and len(n) == 1
        elif k in ("data-seg", "data-line", "data-ray"):
            ok = n is not None and len(n) == 2 and n[0] != n[1]
        elif k == "data-poly":
            ok = n is not None and len(n) >= 3 and len(set(n)) == len(n)
        else:
            ok = self.parse_mark(v) is not None
            if ok:
                kind = self.parse_mark(v)[0]
                if e.tag not in self.marks[kind]["elements"]:
                    ok = False
        if not ok:
            dr.bad("CHK_DIALECT", "%s: %s=%r" % (where, k, v))

    def parse_mark(self, v):
        """'arc2 ABC' -> ('arc', '2', ['A','B','C']) or None."""
        if not isinstance(v, str) or v.count(" ") != 1:
            return None
        head, ref = v.split(" ")
        m = re.match(r"^([a-z]+)([0-9]*)$", head)
        if not m or m.group(1) not in self.marks:
            return None
        kind, cnt = m.group(1), m.group(2)
        if cnt and (cnt not in self.mark_counts or
                    not self.marks[kind].get("counted")):
            return None
        names = split_names(ref)
        want = {"angle": 3, "segment": 2}.get(self.marks[kind]["ref"])
        if names is None or len(names) != want or len(set(names)) != want:
            return None
        return kind, cnt, names

    def _for_ok(self, v):
        if not isinstance(v, str):
            return False
        n = split_names(v)
        if n is not None:
            return len(n) == 1
        parts = v.split(" ")
        if len(parts) != 2:
            return False
        n = split_names(parts[1])
        want = {"ang": 3, "seg": 2, "poly": None, "line": 2}.get(parts[0], -1)
        if n is None or want == -1 or len(set(n)) != len(n):
            return False
        return len(n) >= 3 if want is None else len(n) == want
