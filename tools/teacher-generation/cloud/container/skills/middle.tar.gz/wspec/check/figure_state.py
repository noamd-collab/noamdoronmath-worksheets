"""Independent public reader context for a source-bound ladder movement.

This checker does not call the authoring state validator and never reads
private answers, source display layouts, or renderer state. Invalid input
is a failure, never permission to discard a public fact.
"""
from fractions import Fraction
import re

KEYS = {"kind", "from_figure", "source", "ladder", "right_angle",
        "old_height", "new_base", "height_target"}


def obsolete_height(spec, figure):
    d = figure.get("state_change")
    if d is None:
        return set()
    def must(value):
        if not value:
            raise ValueError("unproved changed-position reader context")
    def norm(text):
        return " ".join(str(text).replace("$", "").split())
    def blocks(row):
        return [b for b in row.get("bound") or [] if isinstance(b, dict)]
    def bound(block, fact, token):
        return any(b.get("fact") == fact["id"] and Fraction(str(b["tok"])) == Fraction(token)
                   for b in block.get("bind") or [] if isinstance(b, dict) and b.get("fact") == fact["id"])
    must(isinstance(d, dict) and set(d) == KEYS and d["kind"] == "rigid_ladder_base_move")
    must(all(isinstance(d[k], str) and d[k] for k in KEYS - {"source"}))
    src = d["source"]
    must(isinstance(src, dict) and set(src) == {"scope", "text"}
         and all(isinstance(src[k], str) and src[k] for k in src))
    owners = [(q, i) for q in spec.get("questions", []) for i in q.get("items", [])
              if i.get("id") == figure.get("scope")]
    must(len(owners) == 1)
    q, item = owners[0]
    must(item.get("figure") == figure["id"] and src["scope"] == item["id"])
    old = [g for g in spec.get("figures", []) if g.get("id") == d["from_figure"]]
    must(len(old) == 1)
    old = old[0]
    must(old["id"] == q.get("figure") and old.get("scope") == q["id"] and "state_change" not in old)
    for frame in (old, figure):
        must(frame.get("figure_accuracy") == "accurate")
        must(not any(k in frame for k in ("frame", "graph", "data", "loci", "base_height")))
    must(set(old.get("entities", [])) == set(figure.get("entities", [])))
    f = {v["id"]: v for v in spec.get("facts", [])}
    e = {v["id"]: v for v in spec.get("entities", [])}
    ladder, right, initial, base, target = [f[d[k]] for k in
                                          ("ladder", "right_angle", "old_height", "new_base", "height_target")]
    for datum, owner in ((ladder, q["id"]), (right, q["id"]), (initial, q["id"]), (base, item["id"])):
        must(datum.get("role") == "given" and datum.get("item") == owner
             and datum.get("source") == {"kind": "stated"})
    for datum in (ladder, initial, base):
        must(datum.get("rel") == "length" and len(datum.get("args", [])) == 1 and datum.get("unit") == "m")
        must(e[datum["args"][0]].get("kind") == "segment")
    h, b, l = initial["args"][0], base["args"][0], ladder["args"][0]
    hv, bv, lv = [set(e[z].get("ends", [])) for z in (h, b, l)]
    vertices = hv | bv
    must(len(hv) == len(bv) == len(lv) == 2 and len(hv & bv) == 1
         and lv == vertices - (hv & bv) and len(vertices) == 3)
    must(all(e[z].get("kind") == "point" for z in vertices))
    must(right.get("rel") == "perpendicular" and set(right.get("args", [])) == {h, b})
    must(target.get("role") == "target" and target.get("rel") == "length"
         and target.get("args") == [h] and target.get("item") == item["id"] and "value" not in target)
    must(target["id"] in [t["id"] for t in item.get("targets", [])])
    listed = set(figure.get("entities", []))
    must(vertices | {h, b, l} <= listed)
    must({z for z in listed if e[z].get("kind") == "point"} == vertices)
    must({z for z in listed if e[z].get("kind") == "segment"} == {h, b, l})
    must(all(e[z].get("kind") in ("point", "segment", "angle", "polygon") for z in listed))
    kept = {right["id"], ladder["id"]}
    must(isinstance(figure.get("inherit_givens"), list) and len(figure["inherit_givens"]) == 2
         and set(figure["inherit_givens"]) == kept)
    must(kept | {base["id"]} <= set(item.get("uses", [])))
    for frame, datum in ((old, initial), (figure, base)):
        shown = set(frame.get("draws", []))
        must(kept | {datum["id"]} <= shown)
        must(all(z in kept | {datum["id"]} or
                 (f[z].get("rel") == "name" and f[z].get("role") == "context"
                  and f[z].get("args", [None])[0] in vertices) for z in shown))
    length, height, distance = [Fraction(str(v["value"])) for v in (ladder, initial, base)]
    must(0 < height < length and 0 < distance < length)
    must(distance ** 2 != length ** 2 - height ** 2)  # same-position metadata cannot waive a leak
    atom = r"([0-9]+(?:\.[0-9]+)?)"
    before = r"סולם באורך " + atom + r" מטרים נשען על קיר ומגיע לגובה " + atom + r" מטרים\."
    found = False
    for block in blocks(q):
        m = re.fullmatch(before, norm(block.get("text")))
        if (m and Fraction(m[1]) == length and Fraction(m[2]) == height
                and bound(block, ladder, m[1]) and bound(block, initial, m[2])
                and right["id"] in block.get("prints", [])):
            found = True
    must(found)
    local = [x for x in blocks(item) if norm(x.get("text")) == norm(src["text"])]
    must(len(local) == 1)
    block = local[0]
    m = re.fullmatch(r"אם מזיזים את הבסיס למרחק " + atom + r" מטרים, חשבו את הגובה החדש\.", norm(block.get("text")))
    must(m and Fraction(m[1]) == distance and bound(block, base, m[1])
         and {base["id"], target["id"]} <= set(block.get("prints", [])))
    return {initial["id"]}
