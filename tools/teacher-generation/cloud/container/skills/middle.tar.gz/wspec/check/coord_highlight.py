# -*- coding: utf-8 -*-
"""Checking a highlight of a coordinate-plane figure (v6.12 family A) on
the EXISTING figure: the highlighted SVG holds the base figure unchanged
plus overlay elements that trace EXACTLY the object's elements (the checked
map entry = the checker's measured set) -- a copy of a line / arrow / mark /
dot, a line on a span between two drawn points, a box hugging a label's ink
-- nothing more (HL_EXTRA / HL_ADDS_MATH), nothing less (HL_MISSING). A
coordinate plane gets no focus arc (that is an angle's)."""
import xml.etree.ElementTree as ET
import re

from .coord import read_svg, _d
from .report import Findings, worst, FAIL

TOL = 0.5
RECT_MARGIN_PX = 6.0
DRAWABLE = ("line", "circle", "polygon", "polyline", "path", "text", "rect")


def _elements(root):
    out = []
    for el in root.iter():
        tag = el.tag.split("}")[-1] if isinstance(el.tag, str) else ""
        if tag in DRAWABLE:
            out.append((tag, dict(el.attrib), (el.text or "").strip()))
    return out


def _geom(tag, a):
    f = float
    try:
        if tag == "line":
            return [(f(a["x1"]), f(a["y1"])), (f(a["x2"]), f(a["y2"]))]
        if tag == "circle":
            return [(f(a["cx"]), f(a["cy"]))]
        if tag == "rect":
            x, y = f(a["x"]), f(a["y"])
            return [(x, y), (x + f(a["width"]), y + f(a["height"]))]
        if tag in ("polygon", "polyline"):
            return [tuple(map(f, p.split(","))) for p in a["points"].split()]
        if tag == "path" and re.fullmatch(r"M [0-9.]+,[0-9.]+(?: L [0-9.]+,[0-9.]+){2,3} Z", a.get("d", "")):
            return [tuple(map(f,p.split(","))) for p in a["d"][2:-2].split(" L ")]
    except (KeyError, ValueError, IndexError):
        return None
    return None


def _near(p, q):
    return _d(p, q) <= TOL


def check_highlight(base_svg, hl_svg, report, object_id):
    F = Findings()
    raw = base_svg if isinstance(base_svg, bytes) else base_svg.encode("utf-8")
    dr = read_svg(raw)
    mapped = (report.get("_map_entities") or {}).get(object_id)
    measured = set(report["measured"]["elements_of"].get(object_id, []))
    if not dr.ok:
        F.fail("HL_BASE_BAD", "HIGHLIGHT_EXACT_ELEMENTS", "the base figure is "
               "outside the dialect")
        return _out(F, {})
    if mapped is None:
        F.fail("HL_NO_MAP", "HIGHLIGHT_EXACT_ELEMENTS", "object %s has no "
               "checked object-map entry" % object_id)
        return _out(F, {})
    want = set(mapped["elements"])
    if want != measured:
        F.fail("HL_MAP_NOT_MEASURED", "HIGHLIGHT_ON_MEASURED_GEOMETRY",
               "the map's elements %s differ from the measured %s"
               % (sorted(want), sorted(measured)), object_id)
    parts = mapped.get("parts") or {}
    pts = dict((n, tuple(p)) for n, p in report["measured"]["points"].items())
    boxes = dict((k, v["box"]) for k, v in
                 report["measured"]["label_boxes"].items())
    try:
        root = ET.fromstring(hl_svg if isinstance(hl_svg, bytes)
                             else hl_svg.encode("utf-8"))
        base_root = ET.fromstring(raw.split(b"?>", 1)[-1]
                                  if raw.startswith(b"<?") else raw)
    except ET.ParseError as e:
        F.fail("HL_PARSE", "HIGHLIGHT_ADDS_NO_MATH", "highlight SVG: %s" % e)
        return _out(F, {})
    base_els = _elements(base_root)
    hl_els = _elements(root)
    i, overlay = 0, []
    for e in hl_els:
        if i < len(base_els) and e == base_els[i]:
            i += 1
        else:
            overlay.append(e)
    if i != len(base_els):
        F.fail("HL_BASE_CHANGED", "HIGHLIGHT_ADDS_NO_MATH", "the highlight "
               "changes or drops base element e%04d" % (i + 1))
    covered = {}
    for tag, a, text in overlay:
        if tag == "text" or text:
            F.fail("HL_ADDS_MATH", "HIGHLIGHT_ADDS_NO_MATH", "the overlay "
                   "prints text %r" % text, object_id)
            continue
        if a.get("data-focus") is not None or any(
                k.startswith("data-") and k not in ("data-hl", "data-span")
                for k in a):
            F.fail("HL_ADDS_MATH", "HIGHLIGHT_ADDS_NO_MATH", "overlay <%s> "
                   "carries %s" % (tag, sorted(k for k in a if
                                               k.startswith("data-"))),
                   object_id)
            continue
        g = _geom(tag, a)
        if g is None:
            F.fail("HL_OVERLAY_SHAPE", "HIGHLIGHT_ADDS_NO_MATH", "overlay <%s> "
                   "is not a traced line / mark / dot / label" % tag)
            continue
        hit = _match(tag, g, dr, want, parts, pts, boxes)
        if hit is None:
            other = _match(tag, g, dr, set(e.ref for e in dr.els), {}, pts,
                           boxes)
            if other:
                F.fail("HL_EXTRA", "HIGHLIGHT_EXACT_ELEMENTS", "overlay <%s> "
                       "traces %s, which is not part of %s" % (
                           tag, other, object_id), object_id)
            else:
                F.fail("HL_ADDS_MATH", "HIGHLIGHT_ADDS_NO_MATH", "overlay <%s>"
                       " %s traces nothing drawn: it adds geometry" % (tag, g),
                       object_id)
            continue
        covered[hit] = covered.get(hit, 0) + 1
    miss = sorted(want - set(covered), key=lambda r: int(r[1:]))
    if miss:
        F.fail("HL_MISSING", "HIGHLIGHT_EXACT_ELEMENTS", "the highlight of %s "
               "omits %s" % (object_id, miss), object_id)
    return _out(F, covered)


def _match(tag, g, dr, refs, parts, pts, boxes):
    for ref in sorted(refs, key=lambda r: int(r[1:])):
        el = dr.by_ref.get(ref)
        if el is None:
            continue
        if tag == "rect":
            b = boxes.get(ref)
            if el.tag == "text" and b:
                (x0, y0), (x1, y1) = g
                inside = x0 <= b[0] + TOL and y0 <= b[1] + TOL and \
                    x1 >= b[2] - TOL and y1 >= b[3] - TOL
                hugs = b[0] - x0 <= RECT_MARGIN_PX and \
                    b[1] - y0 <= RECT_MARGIN_PX and \
                    x1 - b[2] <= RECT_MARGIN_PX and \
                    y1 - b[3] <= RECT_MARGIN_PX
                if inside and hugs:
                    return ref
            continue
        if el.tag == "text":
            continue
        if tag == "circle" or el.tag == "circle":
            if tag == el.tag and _near(g[0], el.pts[0]):
                return ref
            continue
        if tag == "line" and el.tag == "line":
            part = parts.get(ref)
            if part:
                span = (pts.get(part[0]), pts.get(part[1]))
                if None in span:
                    continue
                if (_near(g[0], span[0]) and _near(g[1], span[1])) or \
                        (_near(g[0], span[1]) and _near(g[1], span[0])):
                    return ref
                continue
            p, q = el.pts
            if (_near(g[0], p) and _near(g[1], q)) or \
                    (_near(g[0], q) and _near(g[1], p)):
                return ref
            continue
        if tag == el.tag and len(g) == len(el.pts) and (
                all(_near(x, y) for x, y in zip(g, el.pts)) or
                all(_near(x, y) for x, y in zip(g, el.pts[::-1]))):
            return ref
    return None


def _out(F, covered):
    return {"status": worst([f["level"] for f in F.items]),
            "findings": F.items, "covered": covered}
