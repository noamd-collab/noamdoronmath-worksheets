# -*- coding: utf-8 -*-
"""Checking a highlight (brief section 4) on the EXISTING figure: the
highlighted SVG must contain the base figure unchanged plus overlay
elements, and the overlay must trace exactly the object's display elements
(as the checked object map + the checker's own measurement give them) --
nothing more, nothing less, and no new geometry.

v6.9 (Codex F3): the one allowed addition is the FOCUS ARC of an angle the
figure prints no arc / right-angle mark for (<path data-focus="ang:..">).
It is checked here on its own, from the measured points: its centre is the
angle's vertex (every sample at one radius), its ends lie on the two arms,
every sample lies inside the angle's own non-reflex sector, the radius is
within the arc range and short of both drawn arms, the chords are fine; it
is unfilled, carries no text, and there is exactly one. An angle that
already prints its arc / right mark gets none; a focus arc for any other
object, or of another angle, is HL_ADDS_MATH."""
import math
import xml.etree.ElementTree as ET

from . import geom as G
from . import tol as T
from .dialect import DialectReader, SVG_NS, DRAWABLE, split_names
from .report import Findings, worst, FAIL

TOL = T.PT_TOL_PX * 5       # overlay coordinates may be rounded differently
RECT_MARGIN_PX = 6.0        # a box behind a label hugs its ink box within this


def _elements(root):
    out = []
    for el in root.iter():
        tag = el.tag.split("}")[-1] if isinstance(el.tag, str) else ""
        if tag in DRAWABLE or tag == "rect":
            out.append((tag, dict(el.attrib), (el.text or "").strip()))
    return out


def _focus_problems(g, a, object_id, pts, dr, want):
    """[problem] of one focus arc (see the module note)."""
    out = []
    if not object_id.startswith("ang:"):
        return ["a focus arc on %s, which is not an angle" % object_id]
    if a.get("data-focus") != object_id:
        return ["a focus arc of %s, not of %s" % (a.get("data-focus"),
                                                   object_id)]
    for ref in want:
        el = dr.by_ref.get(ref)
        mk = ((el.a.get("data-mark") if el is not None else "") or "")
        if mk.split(" ")[0] in ("arc", "right"):
            return ["%s prints its own %s mark (%s): no focus arc"
                    % (object_id, mk.split(" ")[0], ref)]
    if (a.get("fill") or "none") != "none":
        out.append("the focus arc is filled")
    names = split_names(object_id[4:]) or []
    if len(names) != 3 or any(n not in pts for n in names):
        return out + ["the points of %s are not drawn" % object_id]
    A, V, B = pts[names[0]], pts[names[1]], pts[names[2]]
    if not g or len(g) < 3:
        return out + ["the focus arc has %d sample(s)" % len(g or [])]
    rs = [G.d(V, p) for p in g]
    r = sum(rs) / len(rs)
    if max(abs(x - r) for x in rs) > T.ARC_RADIUS_TOL_PX:
        out.append("the focus arc is not centred on the vertex %s" % names[1])
    la, lb = G.d(V, A), G.d(V, B)
    if not (T.ARC_MIN_R_PX <= r <= T.ARC_MAX_R_PX) or r >= min(la, lb):
        out.append("the focus arc's radius %.1f is outside [%s, %s] or not "
                   "short of the arms (%.1f, %.1f)" % (
                       r, T.ARC_MIN_R_PX, T.ARC_MAX_R_PX, la, lb))
    ua = math.atan2(A[1] - V[1], A[0] - V[0])
    ub = math.atan2(B[1] - V[1], B[0] - V[0])
    sw = (ub - ua + math.pi) % (2 * math.pi) - math.pi
    if abs(math.degrees(sw)) >= 180.0 - T.ARC_END_TOL_DEG:
        return out + ["%s has no sector to show" % object_id]

    def pos(p):          # the sample's angle measured from arm A toward B
        u = math.atan2(p[1] - V[1], p[0] - V[0])
        x = (u - ua) * (1 if sw > 0 else -1)
        return math.degrees(x % (2 * math.pi))
    full = abs(math.degrees(sw))
    ps = [pos(p) for p in g]
    ps = [x - 360.0 if x > 360.0 - T.ARC_END_TOL_DEG else x for x in ps]
    ends = sorted([ps[0], ps[-1]])
    if abs(ends[0]) > T.ARC_END_TOL_DEG or abs(ends[1] - full) > \
            T.ARC_END_TOL_DEG:
        out.append("the focus arc does not run from arm %s%s to arm %s%s "
                   "(ends at %.1f and %.1f of %.1f deg)" % (
                       names[1], names[0], names[1], names[2], ends[0],
                       ends[1], full))
    if any(x < -T.ARC_END_TOL_DEG or x > full + T.ARC_END_TOL_DEG
           for x in ps):
        out.append("the focus arc leaves the sector of %s (the reflex side "
                   "or past an arm)" % object_id)
    steps = [abs(ps[i + 1] - ps[i]) for i in range(len(ps) - 1)]
    if steps and max(steps) > T.ARC_MAX_STEP_DEG:
        out.append("the focus arc's chords span %.1f deg (> %s)" % (
            max(steps), T.ARC_MAX_STEP_DEG))
    if any(abs(steps[i]) < 1e-9 for i in range(len(steps))) or \
            sorted(ps) not in (ps, ps[::-1]):
        out.append("the focus arc doubles back")
    return out


def _geom(tag, a, text):
    f = float
    try:
        if tag == "line":
            return [(f(a["x1"]), f(a["y1"])), (f(a["x2"]), f(a["y2"]))]
        if tag == "circle":
            return [(f(a["cx"]), f(a["cy"]))]
        if tag == "rect":
            x, y = f(a["x"]), f(a["y"])
            return [(x, y), (x + f(a["width"]), y + f(a["height"]))]
        if tag in ("polygon", "polyline"):
            return [tuple(map(f, p.split(","))) for p in a["points"].split()]
        if tag == "path":
            t = a["d"].replace(",", " ").split()
            pts, i = [], 0
            while i < len(t):
                if t[i] in ("M", "L"):
                    pts.append((f(t[i + 1]), f(t[i + 2])))
                    i += 3
                else:
                    return None
            return pts
        if tag == "text":
            return [(f(a["x"]), f(a["y"]))]
    except (KeyError, ValueError, IndexError):
        return None
    return None


def check_highlight(base_svg, hl_svg, report, object_id):
    """Returns {status, findings, covered}."""
    F = Findings()
    raw = base_svg if isinstance(base_svg, bytes) else base_svg.encode("utf-8")
    dr = DialectReader().read(raw)
    mapped = (report.get("_map_entities") or {}).get(object_id)
    measured = set(report["measured"]["elements_of"].get(object_id, []))
    if not dr.ok:
        F.fail("HL_BASE_BAD", "HIGHLIGHT_EXACT_ELEMENTS", "the base figure is "
               "outside the dialect")
        return _out(F, {})
    if mapped is None:
        F.fail("HL_NO_MAP", "HIGHLIGHT_EXACT_ELEMENTS", "object %s has no "
               "checked object-map entry" % object_id)
        return _out(F, {})
    want = set(mapped["elements"])
    if want != measured:
        F.fail("HL_MAP_NOT_MEASURED", "HIGHLIGHT_ON_MEASURED_GEOMETRY",
               "the map's elements %s differ from the measured %s"
               % (sorted(want), sorted(measured)), object_id)
    parts = mapped.get("parts") or {}
    pts = dict((n, tuple(p)) for n, p in report["measured"]["points"].items())
    try:
        root = ET.fromstring(hl_svg if isinstance(hl_svg, bytes)
                             else hl_svg.encode("utf-8"))
    except ET.ParseError as e:
        F.fail("HL_PARSE", "HIGHLIGHT_ADDS_NO_MATH", "highlight SVG: %s" % e)
        return _out(F, {})
    base_root = ET.fromstring(raw.split(b"?>", 1)[-1] if raw.startswith(b"<?")
                              else raw)
    base_els = _elements(base_root)
    hl_els = _elements(root)
    # the base figure, unchanged and in order, is a subsequence of the highlight
    i, overlay = 0, []
    for e in hl_els:
        if i < len(base_els) and e == base_els[i]:
            i += 1
        else:
            overlay.append(e)
    if i != len(base_els):
        F.fail("HL_BASE_CHANGED", "HIGHLIGHT_ADDS_NO_MATH", "the highlight "
               "changes or drops base element e%d" % i)
    covered = {}
    focus = [(tag, a, text) for tag, a, text in overlay
             if a.get("data-focus") is not None]
    if len(focus) > 1:
        F.fail("HL_ADDS_MATH", "HIGHLIGHT_ADDS_NO_MATH", "%d focus arcs: one "
               "at most" % len(focus), object_id)
    for tag, a, text in focus:
        g = _geom(tag, a, text) if tag == "path" and not text else None
        probs = _focus_problems(g, a, object_id, pts, dr, want) if g else \
            ["the focus arc is not an unlabelled path of samples"]
        for pr in probs:
            F.fail("HL_ADDS_MATH", "HIGHLIGHT_ADDS_NO_MATH", pr, object_id)
    for tag, a, text in overlay:
        if a.get("data-focus") is not None:
            continue
        g = _geom(tag, a, text)
        if g is None:
            F.fail("HL_OVERLAY_SHAPE", "HIGHLIGHT_ADDS_NO_MATH", "overlay <%s> "
                   "is not a traced line / mark / dot / label" % tag)
            continue
        boxes = dict((k, v["box"]) for k, v in
                     report["measured"]["label_boxes"].items())
        hit = _match(tag, g, text, dr, want, parts, pts, boxes)
        if hit is None:
            other = _match(tag, g, text, dr, set(e.ref for e in dr.elements),
                           {}, pts, boxes)
            if other:
                F.fail("HL_EXTRA", "HIGHLIGHT_EXACT_ELEMENTS", "overlay <%s> "
                       "traces %s, which is not part of %s" % (tag, other,
                                                               object_id),
                       object_id)
            else:
                F.fail("HL_ADDS_MATH", "HIGHLIGHT_ADDS_NO_MATH", "overlay "
                       "<%s> %s traces nothing drawn: it adds geometry"
                       % (tag, g), object_id)
            continue
        covered[hit] = covered.get(hit, 0) + 1
    miss = sorted(want - set(covered), key=lambda r: int(r[1:]))
    if miss:
        F.fail("HL_MISSING", "HIGHLIGHT_EXACT_ELEMENTS", "the highlight of %s "
               "omits %s" % (object_id, miss), object_id)
    return _out(F, covered)


def _near(p, q):
    return G.d(p, q) <= TOL


def _match(tag, g, text, dr, refs, parts, pts, boxes):
    for ref in sorted(refs, key=lambda r: int(r[1:])):
        el = dr.by_ref.get(ref)
        if el is None:
            continue
        if tag == "rect":
            b = boxes.get(ref)
            if el.tag == "text" and b:
                (x0, y0), (x1, y1) = g
                inside = x0 <= b[0] + TOL and y0 <= b[1] + TOL and \
                    x1 >= b[2] - TOL and y1 >= b[3] - TOL
                hugs = b[0] - x0 <= RECT_MARGIN_PX and \
                    b[1] - y0 <= RECT_MARGIN_PX and \
                    x1 - b[2] <= RECT_MARGIN_PX and y1 - b[3] <= RECT_MARGIN_PX
                if inside and hugs:
                    return ref
            continue
        if tag == "text" or el.tag == "text":
            if tag == el.tag and text == (el.text or "").strip() and \
                    _near(g[0], el.pts[0]):
                return ref
            continue
        if tag == "circle" or el.tag == "circle":
            if tag == el.tag and _near(g[0], el.pts[0]):
                return ref
            continue
        if tag == "line" and el.tag in ("line", "polygon"):
            part = parts.get(ref)
            if part:
                span = (pts.get(part[0]), pts.get(part[1]))
                if None in span:
                    continue
                if (_near(g[0], span[0]) and _near(g[1], span[1])) or \
                        (_near(g[0], span[1]) and _near(g[1], span[0])):
                    return ref
                continue
            if el.tag == "line":
                p, q = el.pts
                if (_near(g[0], p) and _near(g[1], q)) or \
                        (_near(g[0], q) and _near(g[1], p)):
                    return ref
            continue
        if tag == el.tag or ({tag, el.tag} <= {"polyline", "path"}):
            if len(g) == len(el.pts) and (
                    all(_near(x, y) for x, y in zip(g, el.pts)) or
                    all(_near(x, y) for x, y in zip(g, el.pts[::-1]))):
                return ref
    return None


def _out(F, covered):
    return {"status": worst([f["level"] for f in F.items]),
            "findings": F.items, "covered": covered}
