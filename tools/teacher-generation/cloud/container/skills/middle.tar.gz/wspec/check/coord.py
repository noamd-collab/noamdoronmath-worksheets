# -*- coding: utf-8 -*-
"""wspec.check.coord -- the INDEPENDENT checker of a coordinate-plane figure
(v6.12, BRIEF_V612 section 1, family A).

It imports nothing from wspec.render and never reads the renderer's code.
It reads the SVG (the closed dialect wspec-coord-svg/1, the data file
check/coord_dialect.json), the renderer's object map, and the PUBLIC spec
(any private key, an answer fact or a target with a value is refused:
CheckerInputError). From the rest of wspec it uses only wspec.canon.

    rep = check_coord(svg, object_map, public_spec, figure_id, ocr=True,
                      display_image=None, display_scale=None,
                      display_origin=(0, 0), answer_guard=None, ...)
    (wspec.check.check_figure hands a coordinate-plane figure here)

What it MEASURES on the drawing (nothing is taken from the map or the hooks'
word alone):
  axes      each axis line; its arrowhead at the positive end; its tick marks
            and grid lines -> px = a + b * index by a robust fit; every tick /
            grid line on the fit (AX_TICKS_AT_VALUES), equal spacing and
            square cells (AX_SCALE_CONSISTENT), cells >= MIN_SQUARE_PX
            (AX_MIN_SQUARE), the interval count = the public frame's; the axes
            cross at the index where the printed numbers put 0 (ORIGIN_AT_ZERO)
  numbers   every public label printed once at its tick, as the public value
            with U+2212 (AX_NUMBERS_NEVER_DROPPED / _PARTIAL_AS_DECLARED /
            AX_MINUS_U2212); nearest its own tick; inside the canvas, crossed
            by no data stroke, no dot (AX_NUMBERS_NOT_CUT); the step read from
            the printed numbers and the tick spacing = the public labels'
            (SCALE_PER_AXIS_MEASURED); OCR of each number / axis letter from
            crops of the final display (OCR_AXIS_NUMBERS / OCR_AXIS_NAMES)
  points    each dot's coordinates under the measured map (reported in
            measured.coords); a point with public coordinates sits at them
            (PT_AT_COORDS); its name is nearest its own dot (PT_LABEL_OWNED)
            and read by OCR (OCR_PT_LABEL_AT_POINT)
  data      segments end at their dots (SEG_ENDS_AT_COORDS), polygons have
            every side (POLY_SIDES_MAPPED / POLY_VERTICES_AT_COORDS), lines pass
            through their points and run past them (LINE_THROUGH_COORDS /
            LINE_EXTENDS_PAST_POINTS), right marks at right angles
  didactic  a reading guide only where a stated given draws it
            (GUIDES_ONLY_IF_STATED); a point to plot / to find is not drawn
            in any form (PT_NOT_DRAWN_ANY_FORM); no guarded value and no asked
            interval value printed (TARGET_VALUE_NOT_SHOWN /
            NO_ANSWER_ANYWHERE_SVG); a caption prints only a drawn given
  map       the object map total, one owner per element, roles agree with
            hooks, every object's parts = the measured elements
  v6.16     (corpus-v2 G1 / G2 / G5, from the PUBLIC model only) a listed
            origin: its measured elements = the two axis lines + the printed
            origin '0'; a PARTIAL polygon (a polygon the figure's question
            names -- a public fact of it or a bound name of its text -- not
            listed, some of its vertices shown):
            its drawn sides between consecutive shown vertices + their dots,
            and every missing vertex / side to it drawn in no form
            (POLY_MISSING_VERTEX_NOT_DRAWN, target or not); a polygon TO
            PLOT: no dot at any vertex's given place (PT_NOT_DRAWN_ANY_FORM --
            the only form an unnamed vertex can take) and no stroke along any
            side, whole or a piece (SEG_NOT_DRAWN)

A read-off point's true coordinates are not public: the checker reports what
it measured (measured.coords); the harness, which holds the private model,
compares with private_position_check(report, {name: (x, y)}) OUTSIDE it.

v6.16 gaps r3 -- a SKETCH plane (public frame "sketch": {"origin": [i, j],
"places": {pt: [i, j]}} in tick indices; G7-T08 c 1ד / 11ד): nothing is
read off it, so it is measured on its own terms:
  axes      no tick mark at all (a tick -> AX_TICKS_AT_VALUES FAIL) and no
            number (the labels are empty: any number is EXTRA); the index
            map px = a + b * index comes from the grid lines when the frame
            has a grid, else from the DOTS at their public places, anchored
            at the other axis (it crosses at the sketch's origin index):
            b = the median over every dot coordinate off the origin of
            (px - crossing) / (place - origin), one b for both axes (the
            cells are square) -- so one moved dot is an outlier
            (AX_MIN_SQUARE on b; ORIGIN_AT_ZERO: the axes cross at the
            sketch's origin index)
  points    a dot sits at its public sketch place (PT_AT_COORDS, FIT_TOL_PX;
            a shown point without a place, or a dot off it, FAILs) and, for
            every two drawn points with public values on an axis, in their
            order (and each on the side of its value): CHK_SKETCH_ORDER
            under PT_AT_COORDS. Its place is reported as measured.sketch
            -- never as a value in measured.coords (a sketch position is no
            coordinate: the harness's private position check skips it)."""
import json
import math
import os
import re
import xml.etree.ElementTree as ET
from fractions import Fraction

from .. import canon
from . import tol as T
from .report import Findings, CheckerInputError, worst, FAIL, REVIEW, \
    NOTE, PASS, NA
from . import raster as R
from . import ocr as O
from . import ocr_expect as X
from . import inkcmp as IC
from . import coord_data as CD
from . import coord_locus as CL

FAMILY = "coordinate_plane"
DIALECT_JSON = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            "coord_dialect.json")
SVG_NS = "{http://www.w3.org/2000/svg}"
MINUS = u"−"
# named tolerances (px of the SVG)
FIT_TOL_PX = 0.3          # a tick / grid line / dot on the measured axis map
SQUARE_REL_TOL = 0.01     # cells square within 1 %
MIN_SQUARE_PX = 10.0      # the house minimum cell (7.5 pt printed)
END_TOL_PX = 0.15         # a segment end on its dot
ON_TOL_PX = 0.5           # a point on a line
LINE_EXT_MIN_PX = 6.0     # a line runs past its points by at least this
GUIDE_GAP_MAX_PX = 2.6    # the dashes of a guide leave no larger gap
AXIS_ON_TOL_PX = 0.35     # a guide ends on its axis
NUM_NEAR_PX = 9.0         # an axis number's box this near its axis line
NUM_GAP_MIN_PX = 1.5      # two numbers' ink this far apart (no "−10")
LABEL_NEAR_PX = 24.0
OWN_MARGIN_PX = 1.5
RIGHT_MIN_PX, RIGHT_MAX_PX = 5.0, 20.0
RIGHT_TOL_DEG = 0.5
PARALLEL_TOL_PX = 0.5     # (v6.13 fix_r2) a segment stated parallel to an
                          # axis: its ends differ this little across it
CORE_SHRINK_PX = 1.0
STROKE_IN_CORE_PX = 0.8   # a data stroke may graze a label's core this long
PRIVATE_KEYS = ("answers", "answer_key", "target_values", "not_public",
                "releases", "didactic", "frames")
TARGET_ROLES = ("target", "to_prove", "to_construct", "to_plot")
READ_TASKS = ("read_off", "measure")
FIGURE_CHECKS = [
    "DIALECT_CLOSED", "OBJMAP_TOTAL_NO_UNMAPPED_INK", "NO_ANSWER_ANYWHERE_SVG",
    "TEXT_BOX_IN_CANVAS", "TEXT_NOT_COVERING_MARKS", "GUIDES_ONLY_IF_STATED",
    "AX_SCALE_CONSISTENT", "AX_TICKS_AT_VALUES", "AX_NUMBERS_NEVER_DROPPED",
    "AX_NUMBERS_NOT_CUT", "AX_MINUS_U2212", "AX_MIN_SQUARE",
    "OCR_AXIS_NUMBERS", "OCR_AXIS_NAMES", "TARGET_VALUE_NOT_SHOWN",
    "PT_NOT_DRAWN_ANY_FORM", "ORIGIN_AT_ZERO", "SCALE_PER_AXIS_MEASURED",
    "AX_NUMBERS_PARTIAL_AS_DECLARED", "AXIS_ARROW_DIRECTION",
    "GRID_LINES_AT_STEPS", "DISPLAY_INK_MATCHES_FIGURE",
    "ORIGIN_LABEL_IF_ANY", "SEG_NOT_DRAWN", "POLY_MISSING_VERTEX_NOT_DRAWN",
    "HIGHLIGHT_ON_MEASURED_GEOMETRY"]
OBJECT_CHECKS = {
    "point": ["PT_AT_COORDS", "PT_LABEL_OWNED", "OCR_PT_LABEL_AT_POINT"],
    "segment": ["SEG_ENDS_AT_COORDS", "SEG_ENDS_MATCH", "RIGHT_MARK_IF_ANY",
                # v6.13 fix_r2: a stated axis_parallel is measured
                "AXIS_PARALLEL_MEASURED_IF_STATED"],
    "polygon": ["POLY_VERTICES_AT_COORDS", "POLY_SIDES_MAPPED",
                "RIGHT_MARK_IF_ANY"],
    "line": ["LINE_THROUGH_COORDS", "LINE_EXTENDS_PAST_POINTS"],
    "ray": ["LINE_THROUGH_COORDS", "LINE_EXTENDS_PAST_POINTS"],
    "axis": ["AXIS_LINE_MAPPED", "AXIS_ARROW_DIRECTION", "OCR_AXIS_NAMES",
             "OCR_AXIS_NUMBERS"],
    "plane": ["GRID_LINES_AT_STEPS", "ORIGIN_AT_ZERO"],
    "tick": ["AX_TICKS_AT_VALUES", "OCR_AXIS_NUMBERS"],
    "guide": ["GUIDES_ONLY_IF_STATED"],
}
ALL_CHECKS = FIGURE_CHECKS + sorted(set(c for v in OBJECT_CHECKS.values()
                                        for c in v) - set(FIGURE_CHECKS))
ROLE_HOOK = {"grid_line": "data-grid", "axis_line": "data-axis",
             "axis_arrow": "data-arrow", "axis_tick": "data-tick",
             "axis_number": "data-num", "origin_number": "data-num",
             "axis_name": "data-axname", "point": "data-pt",
             "point_name": "data-for", "coord_caption": "data-for",
             "segment": "data-seg", "polygon_side": "data-seg",
             "line": "data-line", "ray": "data-ray", "guide": "data-guide",
             "right_mark": "data-mark", "segment_caption": "data-for",
             "data_dot": "data-dot", "data_square": "data-square", "axis_break":"data-break", "parameter_locus":"data-locus"}
MAP_TOP = {"construction", "dialect", "display_items", "elements", "engine",
           "figure", "objects", "public_hash", "settings_hash"}


def load_dialect(path=DIALECT_JSON):
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def is_coord(public_spec, figure_id):
    for g in (public_spec or {}).get("figures") or []:
        if isinstance(g, dict) and g.get("id") == figure_id:
            fr = g.get("frame")
            return isinstance(fr, dict) and fr.get("family") == FAMILY
    return False


# ------------------------------------------------------------ geometry ----
def _d(p, q):
    return math.hypot(p[0] - q[0], p[1] - q[1])


def _seg_dist(p, a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    L2 = dx * dx + dy * dy
    if L2 == 0:
        return _d(p, a)
    t = max(0.0, min(1.0, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / L2))
    return _d(p, (a[0] + t * dx, a[1] + t * dy))


def _line_dist(p, a, b):
    L = _d(a, b)
    if L == 0:
        return _d(p, a)
    return abs((b[0] - a[0]) * (a[1] - p[1]) - (a[0] - p[0]) *
               (b[1] - a[1])) / L


def _clip_len(a, b, box):
    """length of the segment a-b inside box."""
    x0, y0, x1, y1 = box
    dx, dy = b[0] - a[0], b[1] - a[1]
    t0, t1 = 0.0, 1.0
    for pk, qk in ((-dx, a[0] - x0), (dx, x1 - a[0]), (-dy, a[1] - y0),
                   (dy, y1 - a[1])):
        if abs(pk) < 1e-12:
            if qk < 0:
                return 0.0
            continue
        t = qk / pk
        if pk < 0:
            t0 = max(t0, t)
        else:
            t1 = min(t1, t)
    if t0 >= t1:
        return 0.0
    return (t1 - t0) * math.hypot(dx, dy)


def _box_dist(box, p):
    dx = max(box[0] - p[0], 0.0, p[0] - box[2])
    dy = max(box[1] - p[1], 0.0, p[1] - box[3])
    return math.hypot(dx, dy)


def _overlap(a, b):
    return not (a[2] <= b[0] or b[2] <= a[0] or a[3] <= b[1] or
                b[3] <= a[1])


def _box_gap(a, b):
    dx = max(b[0] - a[2], a[0] - b[2], 0.0)
    dy = max(b[1] - a[3], a[1] - b[3], 0.0)
    return math.hypot(dx, dy)


def _q(v):
    try:
        a, b, r = canon.parse_exact(v)
    except Exception:                                  # noqa: BLE001
        return None
    return a if r == 1 else None


def _fmt_q(q):
    return canon.canon_number(str(q))


def num_display(q):
    """the printed form of an axis value: U+2212, a decimal point."""
    return canon.family_display(str(q), mode="plain")


def parse_printed(t):
    """a printed number -> Fraction (U+2212 only; None otherwise)."""
    if not re.match(u"^−?(?:0|[1-9][0-9]{0,5})(?:\\.[0-9]{1,4})?$", t):
        return None
    return Fraction(t.replace(MINUS, "-"))


# --------------------------------------------------------------- reader ---
class El(object):
    def __init__(self, ref, tag, a, text, layer):
        self.ref, self.tag, self.a, self.text, self.layer = \
            ref, tag, a, text, layer
        self.hook = None
        self.hv = None
        self.pts = []

    def __repr__(self):
        return "<%s %s %s=%s>" % (self.ref, self.tag, self.hook, self.hv)


class Drawing(object):
    def __init__(self):
        self.els, self.by_ref, self.problems = [], {}, []
        self.W = self.H = None

    @property
    def ok(self):
        return not self.problems


_NUMRE = None


def read_svg(raw, dialect=None):
    """-> Drawing (problems = the dialect violations)."""
    D = dialect or load_dialect()
    num = re.compile(D["number"])
    dr = Drawing()
    bad = dr.problems.append
    txt = raw.decode("utf-8") if isinstance(raw, bytes) else raw
    body = txt
    if body.startswith("<?"):
        head, _sep, body = body.partition("?>")
        if head + "?>" != '<?xml version="1.0" encoding="UTF-8"?>':
            bad("prolog %r" % (head + "?>"))
    if "<!" in body or "<?" in body:
        bad("a DOCTYPE / comment / CDATA / processing instruction")
    try:
        root = ET.fromstring(body.strip().encode("utf-8"))
    except ET.ParseError as e:
        bad("not XML: %s" % e)
        return dr
    if root.tag != SVG_NS + "svg":
        bad("root <%s>" % root.tag)
        return dr
    extra = set(root.attrib) - set(D["root_attrs"])
    if extra:
        bad("root attributes %s" % sorted(extra))
    if root.get("data-dialect") != D["dialect"]:
        bad("data-dialect %r" % root.get("data-dialect"))
    try:
        vb = [float(v) for v in root.get("viewBox", "").split()]
        dr.W, dr.H = vb[2], vb[3]
        if vb[:2] != [0.0, 0.0] or root.get("width") != \
                root.get("viewBox").split()[2] or root.get("height") != \
                root.get("viewBox").split()[3]:
            bad("viewBox / width / height disagree")
    except (ValueError, IndexError, AttributeError):
        bad("viewBox %r" % root.get("viewBox"))
        return dr
    k = 0
    seen_layers = []
    for g in root:
        if g.tag != SVG_NS + "g" or set(g.attrib) != {"data-layer"} or \
                g.get("data-layer") not in D["layers"]:
            bad("top-level <%s %s>" % (g.tag.replace(SVG_NS, ""),
                                       dict(g.attrib)))
            continue
        layer = g.get("data-layer")
        if layer in seen_layers or (seen_layers and D["layers"].index(
                layer) < D["layers"].index(seen_layers[-1])):
            bad("layer %s out of order / twice" % layer)
        seen_layers.append(layer)
        if (g.text or "").strip():
            bad("text directly in layer %s" % layer)
        for el in g:
            k += 1
            tag = el.tag.replace(SVG_NS, "")
            ref = "e%04d" % k
            e = El(el.get("id") or ref, tag, dict(el.attrib),
                   (el.text or "") if tag == "text" else "", layer)
            if el.get("id") != ref:
                bad("%s: id %r, want the positional %s" % (ref, el.get("id"),
                                                          ref))
            if len(el):
                bad("%s: nested elements" % ref)
            _check_el(e, D, num, bad)
            dr.els.append(e)
            dr.by_ref[e.ref] = e
    return dr


def _check_el(e, D, num, bad):
    hooks = [h for h in D["hooks"] if h in e.a]
    if len(hooks) != 1:
        bad("%s <%s>: %d hooks %s (exactly one)" % (e.ref, e.tag, len(hooks),
                                                   hooks))
        return
    h = hooks[0]
    spec = D["hooks"][h]
    e.hook, e.hv = h, e.a[h]
    if e.tag not in spec.get("tags", [spec["tag"]]) or e.layer != spec["layer"]:
        bad("%s: %s on <%s> in layer %s" % (e.ref, h, e.tag, e.layer))
        return
    allowed = set(spec.get("attrs") or D["text_attrs"]) | {"id", h}
    allowed.discard("points" if e.tag == "path" else "d")
    extra = set(e.a) - allowed
    if extra:
        bad("%s: attributes %s" % (e.ref, sorted(extra)))
    for key in ("stroke", "stroke-width", "fill", "r", "stroke-dasharray"):
        if key in spec and e.a.get(key) not in spec[key]:
            bad("%s: %s=%r" % (e.ref, key, e.a.get(key)))
    if not _hook_ok(spec["grammar"], e.hv):
        bad("%s: %s=%r" % (e.ref, h, e.hv))
    try:
        if e.tag == "line":
            vs = [e.a[c] for c in ("x1", "y1", "x2", "y2")]
            if not all(num.match(v) for v in vs):
                bad("%s: coordinates %s" % (e.ref, vs))
            f = [float(v) for v in vs]
            e.pts = [(f[0], f[1]), (f[2], f[3])]
        elif e.tag == "circle":
            vs = [e.a["cx"], e.a["cy"]]
            if not all(num.match(v) for v in vs):
                bad("%s: centre %s" % (e.ref, vs))
            e.pts = [(float(vs[0]), float(vs[1]))]
        elif e.tag in ("polygon", "polyline", "path"):
            if e.tag == "path":
                path=e.a.get("d","")
                if not re.fullmatch(r"M [0-9.]+,[0-9.]+(?: L [0-9.]+,[0-9.]+){2,3} Z",path):
                    bad("%s: path must be a closed straight triangle/square" % e.ref)
                    return
                ps=path[2:-2].split(" L ")
            else: ps = e.a["points"].split(" ")
            for p in ps:
                xy = p.split(",")
                if len(xy) != 2 or not all(num.match(v) for v in xy):
                    bad("%s: points %r" % (e.ref, e.a["points"]))
                    break
                e.pts.append((float(xy[0]), float(xy[1])))
            want_points = 4 if h in ("data-square", "data-break") else 3
            if len(e.pts) != want_points:
                bad("%s: %d points (%d)" % (e.ref, len(e.pts), want_points))
        elif e.tag == "text":
            for key in ("x", "y"):
                if not num.match(e.a.get(key, "")):
                    bad("%s: %s=%r" % (e.ref, key, e.a.get(key)))
            e.pts = [(float(e.a["x"]), float(e.a["y"]))]
            if e.a.get("font-family") not in D["font_families"] or \
                    e.a.get("font-size") not in D["font_sizes"] or \
                    e.a.get("fill") != "#000000" or \
                    e.a.get("text-anchor", "start") not in D["text_anchors"]:
                bad("%s: text style %s" % (e.ref, dict(
                    (k, e.a.get(k)) for k in ("font-family", "font-size",
                                              "fill", "text-anchor"))))
            if (e.a.get("font-style") == "italic") != bool(
                    spec.get("italic")) or e.a.get("font-style") not in (
                        None, "italic"):
                bad("%s: font-style %r" % (e.ref, e.a.get("font-style")))
            if not e.text or e.text != e.text.strip():
                bad("%s: empty / padded text %r" % (e.ref, e.text))
    except (KeyError, ValueError) as ex:
        bad("%s: %s" % (e.ref, ex))


def _name_ok(n):
    return bool(canon.NAME_RE.match(n)) if hasattr(canon, "NAME_RE") else \
        bool(re.match(r"^[A-Z][0-9]?'{0,3}$", n))


def _hook_ok(gr, v):
    ps = v.split(" ")
    if gr == "token":
        return bool(re.fullmatch(r"[A-Za-z][A-Za-z0-9_-]{0,31}", v))
    if gr == "data_tokens":
        return len(ps) == 2 and all(re.fullmatch(r"[A-Za-z][A-Za-z0-9_-]{0,31}", p) for p in ps)
    if gr == "axis":
        return bool(re.match(r"^[a-z]$", v))
    if gr == "axis_index":
        return bool(re.match(r"^[a-z] (?:0|[1-9][0-9]?)$", v))
    if gr == "axis_index_or_origin":
        return v == "origin" or bool(re.match(r"^[a-z] (?:0|[1-9][0-9]?)$", v))
    if gr == "name":
        return _name_ok(v)
    if gr == "two_names":
        return len(ps) == 2 and all(_name_ok(p) for p in ps) and \
            ps == sorted(ps) and ps[0] != ps[1]
    if gr == "two_names_ordered":
        return len(ps) == 2 and all(_name_ok(p) for p in ps) and \
            ps[0] != ps[1]
    if gr == "name_axis":
        return len(ps) == 2 and _name_ok(ps[0]) and bool(
            re.match(r"^[a-z]$", ps[1]))
    if gr == "right_mark":
        return len(ps) == 4 and ps[0] == "right" and all(
            _name_ok(p) for p in ps[1:]) and ps[1] < ps[3] and \
            len(set(ps[1:])) == 3
    if gr == "label_for":
        if len(ps) == 1:
            return _name_ok(ps[0])
        if len(ps) == 2 and ps[0] == "coord":
            return _name_ok(ps[1])
        if len(ps) == 3 and ps[0] == "seg":
            return _name_ok(ps[1]) and _name_ok(ps[2]) and ps[1] < ps[2]
        return False
    return False


# --------------------------------------------------------- public spec ----
class Pub(object):
    """What the checker may know: the PUBLIC model."""

    def __init__(self, pub, fid):
        if not isinstance(pub, dict):
            raise CheckerInputError("the public spec is not a dict")
        from .. import point_transform as PT
        transform_faults = PT.problems(pub, public=True)
        if transform_faults:
            raise CheckerInputError("invalid source-bound point transform: %s" % transform_faults[0])
        self.spec = pub
        bad = sorted(k for k in pub if k in PRIVATE_KEYS)
        if bad:
            raise CheckerInputError("private key(s) %s: the checker reads the "
                                    "PUBLIC model only" % bad)
        self.ents = dict((e["id"], e) for e in pub.get("entities") or [])
        self.facts = dict((f["id"], f) for f in pub.get("facts") or [])
        for f in self.facts.values():
            if f.get("role") == "answer":
                raise CheckerInputError("answer fact %s in the spec" %
                                        f["id"])
            if f.get("role") in TARGET_ROLES and "value" in f:
                raise CheckerInputError("target %s carries a value" % f["id"])
        figs = dict((g["id"], g) for g in pub.get("figures") or [])
        if fid not in figs:
            raise CheckerInputError("figure %r is not in the spec" % fid)
        self.fig = figs[fid]
        self.data_objects = CD.public_objects(pub, self.fig, self.facts)
        self.ents.update(self.data_objects)
        self.locus_objects = CL.public_objects(pub, self.fig, self.facts)
        self.ents.update(self.locus_objects)
        fr = self.fig.get("frame") or {}
        if fr.get("family") != FAMILY:
            raise CheckerInputError("figure %s is not a coordinate plane"
                                    % fid)
        self.frame = fr
        self.axes = [a for a in fr.get("axes") or []]
        # (v6.16 gaps r3, F1) a sketch plane: origin + places, tick indices
        self.sketch = None
        if "sketch" in fr:
            sk = fr.get("sketch")
            try:
                org = [int(i) for i in sk["origin"]]
                places = dict((p, tuple(_q(c) for c in xy))
                              for p, xy in sk["places"].items())
            except Exception:                        # noqa: BLE001
                raise CheckerInputError("figure %s: an unreadable sketch %r"
                                        % (fid, sk))
            if any(None in xy or len(xy) != 2 for xy in places.values()):
                raise CheckerInputError("figure %s: a sketch place is no "
                                        "pair of exact numbers" % fid)
            self.sketch = {"origin": org, "places": places}
        self.item_q, self.task = {}, {}
        self.q_bound = {}      # v6.16 gaps: entities a question's text binds
        for q in pub.get("questions") or []:
            self.item_q[q["id"]] = q["id"]
            bound = self.q_bound.setdefault(q["id"], set())
            for sc in [q] + list(q.get("items") or []):
                for blk in sc.get("bound") or []:
                    for b in (blk.get("bind") or []) if isinstance(
                            blk, dict) else []:
                        if isinstance(b, dict) and b.get("entity"):
                            bound.add(b["entity"])
            for it in q.get("items") or []:
                self.item_q[it["id"]] = q["id"]
                self.task[it["id"]] = it.get("task_type")
        self.qid = self.item_q.get(self.fig.get("scope"))
        self.draws = set(self.fig.get("draws") or [])
        self.listed = set(self.fig.get("entities") or [])

    def kind(self, e):
        return (self.ents.get(e) or {}).get("kind")

    def q_facts(self):
        return [f for f in self.facts.values()
                if self.item_q.get(f.get("item")) == self.qid]

    def value_coords(self):
        """{(point, axis): Fraction} of the question's public values."""
        out = {}
        for f in self.q_facts():
            if f.get("rel") == "coordinate" and f.get("value") is not None \
                    and f.get("role") in ("given", "derived", "context"):
                q = _q(f["value"])
                if q is not None:
                    out[tuple(f["args"])] = q
        return out

    # ------------------------------------------- v6.16 gaps: G1 / G2 / G5 --
    def shown_points(self):
        """the points the figure SHOWS by its declaration (its listed
        entities and what its drawn facts are drawn on, through their
        points) -- never read off the drawing."""
        out = set()
        for e in set(self.listed) | set(
                a for d in self.draws
                for a in (self.facts.get(d) or {}).get("args") or []):
            out |= set(p for p in self.points_of(e) if self.kind(p) ==
                       "point")
        return out

    def partial_polygons(self):
        """(corpus-v2 G1) {polygon: [its vertices]} of the public polygons
        the figure's question names (a public fact of it, or a name its
        bound text binds), not listed by the figure, with SOME but not all
        of their (named) vertices shown."""
        shown = self.shown_points()
        named = set(e for e in self.q_bound.get(self.qid, ())
                    if self.kind(e) == "polygon")
        for f in self.q_facts():
            for a in f.get("args") or []:
                if self.kind(a) == "polygon":
                    named.add(a)
        out = {}
        for e in sorted(named - set(self.listed)):
            vs = list((self.ents.get(e) or {}).get("vertices") or [])
            if not vs or any(self.kind(v) != "point" for v in vs):
                continue
            have = [v for v in vs if v in shown]
            if have and len(have) < len(vs):
                out[e] = vs
        return out

    def origins(self):
        """(corpus-v2 G2) the origin entities the figure lists."""
        return sorted(e for e in self.listed if self.kind(e) == "origin")

    def points_of(self, e):
        ent = self.ents.get(e) or {}
        k = ent.get("kind")
        if k == "point":
            return [e]
        if k == "segment":
            return sorted(ent["ends"])
        if k == "line":
            return sorted(ent["through"])
        if k == "ray":
            return [ent["from"], ent["through"]]
        if k == "polygon":
            return list(ent["vertices"])
        return []


# -------------------------------------------------------------- checker ---
class _Axis(object):
    pass


class CoordCheck(object):
    def __init__(self, dr, pub, F, boxes, disp):
        self.dr, self.pub, self.F, self.boxes, self.disp = \
            dr, pub, F, boxes, disp
        self.elements_of = {}
        self.measured_coords = {}
        self.pts = {}
        self.label_boxes = {}

    def els(self, hook, value=None):
        return [e for e in self.dr.els if e.hook == hook and
                (value is None or e.hv == value)]

    def box(self, e):
        b = self.boxes.get(e.ref)
        if b is not None:
            return b
        fs = float(e.a.get("font-size", 12))
        w = T.GLYPH_W * fs * len(e.text)
        x, y = e.pts[0]
        anc = e.a.get("text-anchor", "start")
        x0 = {"start": x, "middle": x - w / 2, "end": x - w}[anc]
        return (x0, y - T.GLYPH_H * fs, x0 + w, y + T.GLYPH_D * fs)

    # ------------------------------------------------------------ axes --
    def run(self):
        F = self.F
        self.axes = {}
        pax = self.pub.axes
        if len(pax) != 2:
            F.fail("CHK_FRAME", "AX_TICKS_AT_VALUES", "the public frame has "
                   "%d axes" % len(pax))
            return
        for n, pa in enumerate(pax):
            A = _Axis()
            # A malformed/missing axis may stop measurement before _zero;
            # keep the failed report serializable instead of crashing.
            A.zero, A.step = None, None
            A.aid, A.letter = pa["axis"], pa["axis"].split(":", 1)[1]
            A.n = int(pa["intervals"])
            A.labels = [(int(i), _q(v)) for i, v in pa.get("labels") or []]
            A.horizontal = (n == 0)
            A.broken = pa.get("break_before") is True
            if "break_before" in pa and (not A.broken or n != 1 or len(A.labels)<2 or A.labels[0][0]!=1 or A.labels[0][1] is None or A.labels[0][1]<=0):
                F.fail("CHK_BROKEN_FRAME", "AX_BROKEN_START_DECLARED", "invalid public broken-start declaration", A.aid)
            self.axes[A.aid] = A
        self.ax, self.ay = self.axes[pax[0]["axis"]], self.axes[pax[1]["axis"]]
        for A in (self.ax, self.ay):
            self._axis_line(A)
        if self.pub.sketch is not None:
            self._sketch_map()                     # v6.16 gaps r3 (F1)
        else:
            for A in (self.ax, self.ay):
                self._axis_map(A)
        if not all(getattr(A, "fit", None) for A in (self.ax, self.ay)):
            return
        self._square()
        self._breaks()
        for A in (self.ax, self.ay):
            self._zero(A)
            self._numbers(A)
            self._arrow(A)
        self._origin_number()
        self._points()
        CD.measure(self)
        self._data()
        CL.measure(self)
        self._axis_parallel()
        self._guides()
        self._marks()
        self._captions()
        self._texts()
        self._leaks()
        self._objects()
        self.elements_of.update(getattr(self, "data_elements", {}))
        self.elements_of.update(getattr(self, "locus_elements", {}))

    def _axis_line(self, A):
        ls = self.els("data-axis", A.letter)
        if len(ls) != 1:
            self.F.fail("CHK_AXIS_LINE", "AXIS_LINE_MAPPED", "%d axis lines "
                        "for %s" % (len(ls), A.aid), A.aid)
            A.line = None
            return
        e = ls[0]
        p, q = e.pts
        if A.horizontal and abs(p[1] - q[1]) > 0.01 or \
                not A.horizontal and abs(p[0] - q[0]) > 0.01:
            self.F.fail("CHK_AXIS_LINE", "AXIS_LINE_MAPPED", "%s is not %s"
                        % (A.aid, "horizontal" if A.horizontal else
                           "vertical"), A.aid)
        A.line = e
        A.pos = p[1] if A.horizontal else p[0]          # where it runs
        A.span = sorted([p[0], q[0]] if A.horizontal else [p[1], q[1]])

    def _axis_map(self, A):
        """px = a + b * index from the tick marks and grid lines."""
        F = self.F
        A.fit = None
        obs = []
        for hook in ("data-tick", "data-grid"):
            for e in self.els(hook):
                ax, i = e.hv.split(" ")
                if ax != A.letter:
                    continue
                p, q = e.pts
                if hook == "data-tick":
                    along = p[0] if A.horizontal else p[1]
                    other = q[0] if A.horizontal else q[1]
                    cross = (p[1], q[1]) if A.horizontal else (p[0], q[0])
                    ok = abs(along - other) <= 0.01 and A.line is not None \
                        and min(cross) < A.pos < max(cross)
                    if not ok:
                        F.fail("CHK_TICK_SHAPE", "AX_TICKS_AT_VALUES",
                               "%s: tick %s does not cross %s squarely" % (
                                   e.ref, e.hv, A.aid), A.aid)
                else:
                    along = p[0] if A.horizontal else p[1]
                    other = q[0] if A.horizontal else q[1]
                    if abs(along - other) > 0.01:
                        F.fail("CHK_GRID_SHAPE", "GRID_LINES_AT_STEPS",
                               "%s: grid line %s is not parallel to the "
                               "other axis" % (e.ref, e.hv), "plane")
                obs.append((int(i), along, e))
        idx = sorted(set(i for i, _p, _e in obs))
        if len(idx) < 2:
            F.fail("CHK_AXIS_UNMEASURED", "AX_SCALE_CONSISTENT", "%s has %d "
                   "measurable tick positions" % (A.aid, len(idx)), A.aid)
            return
        per = {}
        for i, px, e in obs:
            per.setdefault(i, []).append(px)
        med = dict((i, sorted(v)[len(v) // 2]) for i, v in per.items())
        slopes = sorted((med[j] - med[i]) / (j - i)
                        for i, j in zip(idx, idx[1:]))
        b = slopes[len(slopes) // 2]
        a = sorted(med[i] - b * i for i in idx)[len(idx) // 2]
        A.fit = (a, b)
        for i, px, e in obs:
            r = px - (a + b * i)
            if abs(r) > FIT_TOL_PX:
                chk = "AX_TICKS_AT_VALUES" if e.hook == "data-tick" else \
                    "GRID_LINES_AT_STEPS"
                F.fail("CHK_TICK_OFF_VALUE", chk, "%s (%s %s) is %.2f px off "
                       "its value's place on %s (equal steps of %.2f px)" % (
                           e.ref, e.hook, e.hv, r, A.aid, abs(b)),
                       A.aid if e.hook == "data-tick" else "plane")
        want = set(range(A.n + 1))
        have = set(idx)
        if max(idx) > A.n or min(idx) < 0:
            F.fail("CHK_INTERVALS", "AX_TICKS_AT_VALUES", "%s draws ticks at "
                   "%s; the frame has %d intervals" % (A.aid, idx, A.n),
                   A.aid)
        A.index_seen = have
        A.index_want = want

    # ------------------------------------ v6.16 gaps r3: a SKETCH plane --
    def _sketch_map(self):
        """(F1) a sketch plane's index map. No tick mark at all; the grid
        lines (when the frame has a grid) fix it as on any plane; without a
        grid the dots at their PUBLIC sketch places do, anchored at the
        other axis's line (it crosses at the sketch's origin index), with one
        median scale for both axes (square cells)."""
        F, sk = self.F, self.pub.sketch
        for e in self.els("data-tick"):
            F.fail("CHK_SKETCH_TICK", "AX_TICKS_AT_VALUES", "%s: a tick mark "
                   "(%s) on a sketch plane, which prints none" % (e.ref,
                                                                  e.hv))
        for n, A in enumerate((self.ax, self.ay)):
            A.sketch_origin = sk["origin"][n]
        if self.pub.frame.get("grid"):
            for A in (self.ax, self.ay):
                self._axis_map(A)
            return
        if self.els("data-grid"):
            F.fail("CHK_SKETCH_GRID", "GRID_LINES_AT_STEPS", "grid lines on "
                   "a sketch plane whose frame has no grid")
        if self.ax.line is None or self.ay.line is None:
            for A in (self.ax, self.ay):
                A.fit = None
            return
        est = []
        per_axis = [[], []]
        for e in self.els("data-pt"):
            pl = sk["places"].get(e.hv)
            if pl is None:
                continue
            c = e.pts[0]
            for n, (A, O_) in enumerate(((self.ax, self.ay),
                                         (self.ay, self.ax))):
                d = float(pl[n]) - A.sketch_origin
                if abs(d) > 1e-9:
                    scale = abs((c[n] - O_.pos) / d)
                    est.append(scale)
                    per_axis[n].append(scale)
        for A in (self.ax, self.ay):
            A.fit = None
            A.index_seen, A.index_want = set(), set()
        if not est:
            F.review("CHK_SKETCH_UNMEASURED", "AX_SCALE_CONSISTENT", "a "
                     "sketch without grid and without a dot off the axes: "
                     "nothing fixes its scale")
            return
        # Do not impose square cells before testing them: using one pooled
        # scale made _square tautological on a gridless sketch. A coherent
        # stretch of all x places must fail the SCALE check, not only the
        # downstream point-position check. No values/private answers used.
        if all(per_axis):
            bx, by = [sorted(v)[len(v) // 2] for v in per_axis]
            if abs(bx - by) > SQUARE_REL_TOL * max(bx, by):
                F.fail("CHK_SCALE_STRETCHED", "AX_SCALE_CONSISTENT",
                       "sketch point spacings imply %.2f x %.2f px cells; "
                       "one axis is stretched" % (bx, by))
        b = sorted(est)[len(est) // 2]
        self.ax.fit = (self.ay.pos - b * self.ax.sketch_origin, b)
        self.ay.fit = (self.ax.pos + b * self.ay.sketch_origin, -b)

    def _square(self):
        F = self.F
        bx, by = abs(self.ax.fit[1]), abs(self.ay.fit[1])
        self.sq = (bx, by)
        if min(bx, by) < MIN_SQUARE_PX:
            F.fail("CHK_SQUARE_SMALL", "AX_MIN_SQUARE", "grid cells %.2f x "
                   "%.2f px; the house minimum is %s px" % (bx, by,
                                                            MIN_SQUARE_PX))
        if abs(bx - by) > SQUARE_REL_TOL * max(bx, by):
            F.fail("CHK_SCALE_STRETCHED", "AX_SCALE_CONSISTENT", "the cells "
                   "are %.2f px wide and %.2f px tall: an axis is stretched "
                   "(cells are square; each axis's VALUE per cell is its own)"
                   % (bx, by))
        if self.ax.fit[1] <= 0 or self.ay.fit[1] >= 0:
            F.fail("CHK_AXIS_DIRECTION", "AXIS_ARROW_DIRECTION", "the tick "
                   "indices do not grow rightward on x / upward on y")

    def px(self, A, i):
        a, b = A.fit
        return a + b * float(i)

    def index(self, A, px):
        a, b = A.fit
        return (px - a) / b

    def _zero(self, A):
        """the index where the other axis crosses; the printed numbers must
        put 0 there."""
        F = self.F
        O_ = self.ay if A is self.ax else self.ax
        A.zero = None
        if O_.line is None:
            return
        z = self.index(A, O_.pos)
        zi = int(round(z))
        if abs(z - zi) * abs(A.fit[1]) > FIT_TOL_PX or not 0 <= zi <= A.n:
            F.fail("CHK_ORIGIN_OFF_TICK", "ORIGIN_AT_ZERO", "%s crosses %s "
                   "between ticks (index %.2f)" % (O_.aid, A.aid, z), "plane")
            return
        A.zero = zi
        so = getattr(A, "sketch_origin", None)
        if so is not None and zi != so:
            # (v6.16 gaps r3) a sketch: the axes cross at its origin index
            F.fail("CHK_ORIGIN_NOT_ZERO", "ORIGIN_AT_ZERO", "the axes cross "
                   "at index %d of %s; the sketch's origin is at %d" % (
                       zi, A.aid, so), "plane")
        labs = dict(A.labels)
        A.step = None
        ks = sorted(labs)
        if len(ks) >= 2:
            A.step = (labs[ks[-1]] - labs[ks[0]]) / (ks[-1] - ks[0])
            base = labs[ks[0]] - ks[0] * A.step
            if A.broken:
                if zi != 0 or A.step <= 0 or base <= 0:
                    F.fail("CHK_BROKEN_START", "AX_BROKEN_START_DECLARED", "broken axis does not place its crossing one interval before its positive first label", A.aid)
                else:
                    A.zero = -base/A.step
            elif base + zi * A.step != 0:
                F.fail("CHK_ORIGIN_NOT_ZERO", "ORIGIN_AT_ZERO", "the axes "
                       "cross at index %d of %s, where the printed numbers "
                       "give %s, not 0" % (zi, A.aid, _fmt_q(base + zi *
                                                             A.step)),
                       "plane")
        elif len(ks) == 1 and labs[ks[0]] == 0 and ks[0] != zi:
            F.fail("CHK_ORIGIN_NOT_ZERO", "ORIGIN_AT_ZERO", "0 of %s is "
                   "printed at index %d, the axes cross at %d" % (
                       A.aid, ks[0], zi), "plane")
        # the grid / ticks cover every index (the axis itself stands at 0)
        # -- a sketch: only its grid, when it has one (index_want empty)
        miss = sorted(A.index_want - A.index_seen - {zi})
        if miss:
            F.fail("CHK_TICKS_MISSING", "AX_TICKS_AT_VALUES", "%s draws no "
                   "tick / grid line at index(es) %s of its %d intervals" % (
                       A.aid, miss, A.n), A.aid)

    def value(self, A, idx):
        """the value at a (fractional) index, from the public labels: the
        nearest fraction of an interval with a denominator <= 12, when the
        drawing puts the point there (FIT_TOL_PX); else None."""
        if A.step is None or A.zero is None:
            return None
        q = Fraction(round(idx, 4)).limit_denominator(12)
        if abs(float(q) - idx) * abs(A.fit[1]) > FIT_TOL_PX:
            return None
        return (q - A.zero) * A.step

    def _numbers(self, A):
        F = self.F
        want = dict((i, v) for i, v in A.labels if i != A.zero)
        got = {}
        A.num_els = {}
        for e in self.els("data-num"):
            if e.hv == "origin":
                continue
            ax, i = e.hv.split(" ")
            if ax != A.letter:
                continue
            i = int(i)
            if i in got:
                F.fail("CHK_NUMBER_TWICE", "AX_NUMBERS_PARTIAL_AS_DECLARED",
                       "%s prints two numbers at index %d" % (A.aid, i),
                       A.aid)

            got[i] = e
            A.num_els[i] = e
            if "-" in e.text or u"–" in e.text or u"—" in e.text:
                F.fail("CHK_HYPHEN_MINUS", "AX_MINUS_U2212", "%s: %r prints "
                       "a hyphen, not U+2212" % (e.ref, e.text), A.aid)
            if i not in want:
                F.fail("CHK_NUMBER_EXTRA", "AX_NUMBERS_PARTIAL_AS_DECLARED",
                       "%s: %r at index %d of %s -- the frame prints no "
                       "number there" % (e.ref, e.text, i, A.aid), A.aid)
                continue
            if e.text != num_display(want[i]):
                F.fail("CHK_NUMBER_WRONG", "OCR_AXIS_NUMBERS", "%s: %s prints "
                       "%r at index %d; the frame's number there is %r" % (
                           e.ref, A.aid, e.text, i, num_display(want[i])),
                       A.aid)
            b = self.box(e)
            c = ((b[0] + b[2]) / 2.0, (b[1] + b[3]) / 2.0)
            along = c[0] if A.horizontal else c[1]
            d_own = abs(along - self.px(A, i))
            if d_own >= abs(A.fit[1]) / 2.0 - 0.25:
                F.fail("CHK_NUMBER_NOT_OWNED", "AX_TICKS_AT_VALUES", "%s: %r "
                       "stands %.1f px from its tick (index %d of %s): it "
                       "reads as the number of another tick" % (
                           e.ref, e.text, d_own, i, A.aid), A.aid)
            gap = (b[1] - A.pos if b[1] > A.pos else A.pos - b[3]) \
                if A.horizontal else \
                (b[0] - A.pos if b[0] > A.pos else A.pos - b[2])
            if A.line is not None and gap > NUM_NEAR_PX:
                F.fail("CHK_NUMBER_FAR", "AX_TICKS_AT_VALUES", "%s: %r is "
                       "%.1f px from %s" % (e.ref, e.text, gap, A.aid), A.aid)
        for i in sorted(set(want) - set(got)):
            F.fail("CHK_NUMBER_DROPPED", "AX_NUMBERS_NEVER_DROPPED", "%s: the "
                   "number %r at index %d is not printed" % (
                       A.aid, num_display(want[i]), i), A.aid)
        # the step the printed numbers and the tick spacing give = public
        pts = []
        for i, e in sorted(A.num_els.items()):
            v = parse_printed(e.text)
            if v is None:
                continue
            b = self.box(e)
            along = (b[0] + b[2]) / 2.0 if A.horizontal else \
                (b[1] + b[3]) / 2.0
            pts.append((self.index(A, along), v))
        if len(pts) >= 2 and A.step is not None:
            (i0, v0), (i1, v1) = pts[0], pts[-1]
            if abs(i1 - i0) > 0.5:
                st = (float(v1) - float(v0)) / (i1 - i0)
                if abs(st - float(A.step)) > 0.1 * abs(float(A.step)):
                    F.fail("CHK_STEP_MEASURED", "SCALE_PER_AXIS_MEASURED",
                           "%s: the printed numbers step %.4g per interval "
                           "on the drawing; the frame's labels say %s" % (
                               A.aid, st, _fmt_q(A.step)), A.aid)
        # neighbours on one axis never merge into one number
        seq = sorted(A.num_els.items())
        for (i, e), (j, f) in zip(seq, seq[1:]):
            if _box_gap(self.box(e), self.box(f)) < NUM_GAP_MIN_PX:
                F.fail("CHK_NUMBERS_MERGE", "AX_NUMBERS_NOT_CUT", "%s %r and "
                       "%s %r of %s touch: they read as one number" % (
                           e.ref, e.text, f.ref, f.text, A.aid), A.aid)

    def _breaks(self):
        """Measure the explicit break symbol inside the declared gap."""
        self.broken_checked = any(A.broken for A in (self.ax,self.ay)) or bool(self.els("data-break")) or any(f["check"]=="AX_BROKEN_START_DECLARED" for f in self.F.items)
        letters={self.ax.letter,self.ay.letter}
        for e in self.els("data-break"):
            if e.hv not in letters:self.F.fail("CHK_BREAK_UNDECLARED","AX_BROKEN_START_DECLARED","break does not belong to a public axis",None)
        for A in (self.ax,self.ay):
            marks=self.els("data-break", A.letter)
            if not A.broken:
                if marks:self.F.fail("CHK_BREAK_UNDECLARED","AX_BROKEN_START_DECLARED","axis has an undeclared break",A.aid)
                continue
            cy=self.px(A,.5)
            want=[(A.pos-3,cy+3),(A.pos+3,cy+1),(A.pos-3,cy-1),(A.pos+3,cy-3)]
            if len(marks)!=1 or len(marks[0].pts)!=4 or any(_d(p,q)>.15 for p,q in zip(marks[0].pts,want)):
                self.F.fail("CHK_BREAK_MISSING_OR_MOVED","AX_BROKEN_START_DECLARED","declared break needs the measured zigzag between crossing and first printed value",A.aid)

    def _origin_number(self):
        F = self.F
        zs = [A for A in (self.ax, self.ay) if A.zero is not None and
              any(i == A.zero for i, _v in A.labels)]
        os_ = self.els("data-num", "origin")
        if len(os_) > 1:
            F.fail("CHK_NUMBER_TWICE", "AX_NUMBERS_PARTIAL_AS_DECLARED",
                   "%d origin numbers" % len(os_), "plane")
        if zs and not os_:
            F.fail("CHK_NUMBER_DROPPED", "AX_NUMBERS_NEVER_DROPPED", "the 0 "
                   "the frame prints at the origin is not printed", "plane")
        if os_ and not zs:
            F.fail("CHK_NUMBER_EXTRA", "AX_NUMBERS_PARTIAL_AS_DECLARED",
                   "an origin 0 the frame does not print", "plane")
        self.origin_els = os_
        for e in os_:
            if e.text != "0":
                F.fail("CHK_NUMBER_WRONG", "OCR_AXIS_NUMBERS", "%s: the origin "
                       "prints %r" % (e.ref, e.text), "plane")
            if self.ax.line is None or self.ay.line is None:
                continue
            b = self.box(e)
            o = (self.ay.pos, self.ax.pos)
            sq = min(self.sq)
            if _box_dist(b, o) > NUM_NEAR_PX or _box_dist(b, o) < 0.5:
                F.fail("CHK_NUMBER_NOT_OWNED", "ORIGIN_LABEL_IF_ANY", "%s: the "
                       "origin's 0 stands %.1f px from the origin" % (
                           e.ref, _box_dist(b, o)), "plane")
            for A in (self.ax, self.ay):
                for i, f in getattr(A, "num_els", {}).items():
                    if _box_gap(b, self.box(f)) < 2 * NUM_GAP_MIN_PX:
                        F.fail("CHK_NUMBERS_MERGE", "AX_NUMBERS_NOT_CUT",
                               "the origin's 0 and %s %r touch" % (
                                   f.ref, f.text), A.aid)
            del sq

    def _arrow(self, A):
        F = self.F
        ars = self.els("data-arrow", A.letter)
        if len(ars) != 1 or A.line is None:
            F.fail("CHK_ARROW", "AXIS_ARROW_DIRECTION", "%d arrowheads on %s"
                   % (len(ars), A.aid), A.aid)
            return
        pts = ars[0].pts
        if A.horizontal:
            tip = max(pts, key=lambda p: p[0])
            ok = abs(tip[1] - A.pos) <= 0.05 and tip[0] > A.span[1] and \
                min(p[0] for p in pts) >= A.span[1] - 0.05 and \
                self.px(A, A.n) < A.span[1]
        else:
            tip = min(pts, key=lambda p: p[1])
            ok = abs(tip[0] - A.pos) <= 0.05 and tip[1] < A.span[0] and \
                max(p[1] for p in pts) <= A.span[0] + 0.05 and \
                self.px(A, A.n) > A.span[0]
        if not ok:
            F.fail("CHK_ARROW", "AXIS_ARROW_DIRECTION", "the arrowhead of %s "
                   "is not at its positive end, on the axis" % A.aid, A.aid)
        A.tip = tip
        names = self.els("data-axname", A.letter)
        f_name = [f for f in self.pub.facts.values()
                  if f.get("rel") == "name" and f.get("args") == [A.aid] and
                  f["id"] in self.pub.draws]
        if len(names) > 1 or (names and names[0].text != A.letter):
            F.fail("CHK_AXIS_NAME", "OCR_AXIS_NAMES", "the name of %s: %s" % (
                A.aid, [n.text for n in names]), A.aid)
        if bool(names) != bool(f_name):
            F.fail("CHK_AXIS_NAME", "AXIS_LINE_MAPPED", "%s %s its letter, "
                   "the figure %s its name fact" % (
                       A.aid, "prints" if names else "does not print",
                       "does not draw" if names else "draws"), A.aid)
        for n in names:
            b = self.box(n)
            if _box_dist(b, tip) > 14.0:
                F.fail("CHK_AXIS_NAME", "OCR_AXIS_NAMES", "%s: the letter %s "
                       "stands %.1f px from its arrow" % (
                           n.ref, n.text, _box_dist(b, tip)), A.aid)

    # ---------------------------------------------------------- points --
    def _sketch_points(self):
        """(v6.16 gaps r3, F1) every dot at its PUBLIC sketch place; every
        two drawn points with public values in their order on each axis,
        each on the side of its value. Places go to measured.sketch, never
        to measured.coords (no value is read off a sketch)."""
        F, sk = self.F, self.pub.sketch
        vals = self.pub.value_coords()
        self.sketch_measured = {}
        for e in self.els("data-pt"):
            n = e.hv
            if n in self.pts:
                F.fail("CHK_POINT_TWICE", "PT_AT_COORDS", "two dots for %s"
                       % n, n)
            if self.pub.kind(n) != "point":
                F.fail("CHK_POINT_UNKNOWN", "OBJMAP_TOTAL_NO_UNMAPPED_INK",
                       "%s: a dot for %r, not a public point" % (e.ref, n), n)
            c = e.pts[0]
            self.pts[n] = c
            idx = (self.index(self.ax, c[0]), self.index(self.ay, c[1]))
            self.sketch_measured[n] = [round(idx[0], 4), round(idx[1], 4)]
            pl = sk["places"].get(n)
            if pl is None:
                F.fail("CHK_SKETCH_UNPLACED", "PT_AT_COORDS", "%s: a dot for "
                       "%s, which has no place in the sketch" % (e.ref, n), n)
                continue
            for A, i, w in ((self.ax, idx[0], pl[0]),
                            (self.ay, idx[1], pl[1])):
                if not -0.01 <= i <= A.n + 0.01:
                    F.fail("CHK_POINT_OUTSIDE", "PT_AT_COORDS", "%s lies "
                           "outside the frame on %s" % (n, A.aid), n)
                off = (i - float(w)) * abs(A.fit[1])
                if abs(off) > FIT_TOL_PX:
                    F.fail("CHK_POINT_OFF", "PT_AT_COORDS", "%s is drawn at "
                           "index %.3g of %s; its sketch place is %s (%.2f px "
                           "off)" % (n, i, A.aid, _fmt_q(w), off), n)
        drawn = sorted(self.pts)
        for k, A in enumerate((self.ax, self.ay)):
            o = A.sketch_origin
            for n in drawn:
                v = vals.get((n, A.aid))
                pl = sk["places"].get(n)
                if v is None or pl is None:
                    continue
                side = float(self.sketch_measured[n][k]) - o
                sd = 0 if abs(side) * abs(A.fit[1]) <= FIT_TOL_PX else \
                    (1 if side > 0 else -1)
                if sd != (v > 0) - (v < 0):
                    F.fail("CHK_SKETCH_ORDER", "PT_AT_COORDS", "%s is drawn "
                           "on the other side of %s than its coordinate %s"
                           % (n, "the y axis" if k == 0 else "the x axis",
                              _fmt_q(v)), n)
            for i in range(len(drawn)):
                for j in range(i + 1, len(drawn)):
                    p, q = drawn[i], drawn[j]
                    vp, vq = vals.get((p, A.aid)), vals.get((q, A.aid))
                    if vp is None or vq is None or p not in \
                            self.sketch_measured or q not in \
                            self.sketch_measured:
                        continue
                    d = (self.sketch_measured[p][k] -
                         self.sketch_measured[q][k]) * abs(A.fit[1])
                    sd = 0 if abs(d) <= FIT_TOL_PX else (1 if d > 0 else -1)
                    if sd != (vp > vq) - (vp < vq):
                        F.fail("CHK_SKETCH_ORDER", "PT_AT_COORDS", "%s and %s "
                               "are drawn in another order on %s than their "
                               "coordinates %s, %s" % (
                                   p, q, A.aid, _fmt_q(vp), _fmt_q(vq)), p)

    def _points(self):
        F = self.F
        if self.pub.sketch is not None:
            return self._sketch_points()          # v6.16 gaps r3 (F1)
        vals = self.pub.value_coords()
        for e in self.els("data-pt"):
            n = e.hv
            if n in self.pts:
                F.fail("CHK_POINT_TWICE", "PT_AT_COORDS", "two dots for %s"
                       % n, n)
            if self.pub.kind(n) != "point":
                F.fail("CHK_POINT_UNKNOWN", "OBJMAP_TOTAL_NO_UNMAPPED_INK",
                       "%s: a dot for %r, not a public point" % (e.ref, n), n)
            c = e.pts[0]
            self.pts[n] = c
            ix_, iy_ = self.index(self.ax, c[0]), self.index(self.ay, c[1])
            got = []
            for A, i in ((self.ax, ix_), (self.ay, iy_)):
                if not -0.01 <= i <= A.n + 0.01:
                    F.fail("CHK_POINT_OUTSIDE", "PT_AT_COORDS", "%s lies "
                           "outside the frame on %s" % (n, A.aid), n)
                v = self.value(A, i)
                got.append(v)
                want = vals.get((n, A.aid))
                if want is not None and A.step is not None:
                    wi = float(want / A.step) + A.zero
                    off = (i - wi) * abs(A.fit[1])
                    if abs(off) > FIT_TOL_PX:
                        F.fail("CHK_POINT_OFF", "PT_AT_COORDS", "%s is drawn "
                               "at %s = %s on the measured axes; its public "
                               "coordinate is %s (%.2f px off)" % (
                                   n, A.letter, "%.3g" % float(v) if v is
                                   not None else "?", _fmt_q(want), off), n)
            self.measured_coords[n] = {
                "index": [round(ix_, 4), round(iy_, 4)],
                "value": [None if v is None else _fmt_q(v) for v in got]}

    def _data(self):
        F = self.F
        self.pieces = []            # (element, p, q, kind)
        for hook, kind in (("data-seg", "segment"), ("data-line", "line"),
                           ("data-ray", "ray")):
            for e in self.els(hook):
                a, b = e.hv.split(" ")
                p, q = e.pts
                self.pieces.append((e, p, q, kind))
                if a not in self.pts or b not in self.pts:
                    F.fail("CHK_DATA_UNDRAWN_POINT", "SEG_ENDS_AT_COORDS",
                           "%s: %s %s names a point with no dot" % (
                               e.ref, hook, e.hv), [a, b])
                    continue
                A_, B_ = self.pts[a], self.pts[b]
                if kind == "segment":
                    if not ((_d(p, A_) <= END_TOL_PX and _d(q, B_) <=
                             END_TOL_PX) or (_d(p, B_) <= END_TOL_PX and
                                             _d(q, A_) <= END_TOL_PX)):
                        F.fail("CHK_SEG_ENDS", "SEG_ENDS_AT_COORDS", "%s: "
                               "segment %s does not end at the dots of %s and "
                               "%s" % (e.ref, e.hv, a, b), "seg:" + a + b)
                    continue
                for n_, P in ((a, A_), (b, B_)):
                    if _seg_dist(P, p, q) > ON_TOL_PX:
                        F.fail("CHK_LINE_MISSES", "LINE_THROUGH_COORDS",
                               "%s: %s %s misses the dot of %s" % (
                                   e.ref, kind, e.hv, n_), kind[:4] + ":")
                if kind == "ray":
                    if _d(p, A_) > END_TOL_PX:
                        F.fail("CHK_RAY_START", "LINE_THROUGH_COORDS", "%s: "
                               "the ray does not start at %s" % (e.ref, a),
                               "ray:" + a + b)
                    ends = [(q, B_)]
                else:
                    ends = [(p, A_), (q, B_)] if _d(p, A_) < _d(p, B_) else \
                        [(p, B_), (q, A_)]
                for end, P in ends:
                    if _d(end, P) < LINE_EXT_MIN_PX:
                        F.fail("CHK_LINE_SHORT", "LINE_EXTENDS_PAST_POINTS",
                               "%s: the %s ends %.1f px past its point (>= %s)"
                               % (e.ref, kind, _d(end, P), LINE_EXT_MIN_PX),
                               ("line:" if kind == "line" else "ray:") +
                               "".join(sorted([a, b]) if kind == "line"
                                       else [a, b]))

    def _axis_parallel(self):
        """(v6.13 fix_r2) AXIS_PARALLEL_MEASURED_IF_STATED: every drawn
        segment / line / ray a public axis_parallel fact states parallel to
        an axis runs along that axis on the drawing (its two ends differ by
        at most PARALLEL_TOL_PX across it). A stated one that is not drawn
        (a segment the student finds) is not measured.
        (v6.16 gaps r2, K5 of t08_c) only the facts of the FIGURE'S
        question: two questions of a level may both name an AB (G7-T08 c q4
        vertical, q5 'AB ∥ ציר x'); an unscoped figure keeps every fact."""
        facts = self.pub.q_facts() if self.pub.qid is not None else \
            list(self.pub.facts.values())
        for f in sorted(facts, key=lambda f: f["id"]):
            if f.get("rel") != "axis_parallel":
                continue
            args = f.get("args") or []
            if len(args) != 2:
                continue
            ent = (self.pub.ents.get(args[0]) if hasattr(self.pub, "ents")
                   else None) or {}
            ends = ent.get("ends") or ent.get("through") or (
                [ent.get("from"), ent.get("through")] if ent.get("from")
                else None)
            if not ends:
                m = re.match(r"^seg:([A-Z][0-9]*'*)([A-Z][0-9]*'*)$",
                             args[0])
                ends = [m.group(1), m.group(2)] if m else None
            if not ends or len(ends) != 2:
                continue
            A = self.axes.get(args[1])
            if A is None:
                self.F.fail("CHK_PARALLEL_AXIS", "AXIS_PARALLEL_MEASURED_IF_"
                            "STATED", "%s: %s is no axis of the frame"
                            % (f["id"], args[1]), args[0])
                continue
            hit = [(e, p, q) for e, p, q, _k in self.pieces
                   if set(e.hv.split(" ")) == set(ends)]
            for e, p, q in hit:
                off = abs(p[1] - q[1]) if A.horizontal else abs(p[0] - q[0])
                if off > PARALLEL_TOL_PX:
                    self.F.fail("CHK_PARALLEL_AXIS", "AXIS_PARALLEL_MEASURED_"
                                "IF_STATED", "%s: %s is stated parallel to %s "
                                "but its ends differ by %.2f px across it"
                                % (e.ref, args[0], args[1], off), args[0])

    def cover(self, a, b):
        """the element drawing the straight piece a..b: (ref, 'whole' |
        [a, b]) or None."""
        A_, B_ = self.pts.get(a), self.pts.get(b)
        if A_ is None or B_ is None:
            return None
        best = None
        for e, p, q, kind in self.pieces:
            if _seg_dist(A_, p, q) <= END_TOL_PX and \
                    _seg_dist(B_, p, q) <= END_TOL_PX:
                whole = kind == "segment" and sorted(e.hv.split(" ")) == \
                    sorted([a, b])
                cand = (0 if whole else 1, _d(p, q), e.ref,
                        "whole" if whole else sorted([a, b]))
                if best is None or cand < best:
                    best = cand
        return (best[2], best[3]) if best else None

    def _guides(self):
        F = self.F
        groups = {}
        for e in self.els("data-guide"):
            groups.setdefault(e.hv, []).append(e)
        stated = {}
        for f in self.pub.facts.values():
            if f.get("rel") == "guide" and f["id"] in self.pub.draws:
                stated[(f["args"][0], f["args"][1])] = f
        self.guide_els = {}
        for hv, es in sorted(groups.items()):
            n, letter = hv.split(" ")
            aid = "axis:" + letter
            f = stated.get((n, aid))
            ok_src = f is not None and f.get("role") == "given" and \
                (f.get("source") or {}).get("kind") == "stated"
            if not ok_src:
                F.fail("CHK_GUIDE_UNSTATED", "GUIDES_ONLY_IF_STATED", "a "
                       "reading guide from %s to %s: no stated given of the "
                       "figure draws it (didactic policy)" % (n, aid),
                       f["id"] if f else n)
                continue
            self.guide_els[f["id"]] = [e.ref for e in es]
            A = self.axes.get(aid)
            P = self.pts.get(n)
            if A is None or P is None or A.line is None:
                F.fail("CHK_GUIDE_SHAPE", "GUIDES_ONLY_IF_STATED", "the guide "
                       "%s has no drawn point / axis" % hv, f["id"])
                continue
            foot = (P[0], A.pos) if A.horizontal else (A.pos, P[1])
            L = _d(P, foot)
            ts = []
            bad = False
            for e in es:
                for p in e.pts:
                    if _line_dist(p, P, foot) > 0.05 or L == 0:
                        bad = True
                t0 = ((e.pts[0][0] - P[0]) * (foot[0] - P[0]) +
                      (e.pts[0][1] - P[1]) * (foot[1] - P[1])) / (L * L or 1)
                t1 = ((e.pts[1][0] - P[0]) * (foot[0] - P[0]) +
                      (e.pts[1][1] - P[1]) * (foot[1] - P[1])) / (L * L or 1)
                ts.append(tuple(sorted([t0 * L, t1 * L])))
            ts.sort()
            if bad or not ts or ts[0][0] > GUIDE_GAP_MAX_PX or \
                    abs(ts[-1][1] - L) > AXIS_ON_TOL_PX or any(
                        b[0] - a[1] > GUIDE_GAP_MAX_PX for a, b in
                        zip(ts, ts[1:])) or ts[0][0] < -0.05:
                F.fail("CHK_GUIDE_SHAPE", "GUIDES_ONLY_IF_STATED", "the guide "
                       "%s does not run from %s square to %s and end on it"
                       % (hv, n, aid), f["id"])

    def _marks(self):
        F = self.F
        for e in self.els("data-mark"):
            _r, a, v, b = e.hv.split(" ")
            if any(x not in self.pts for x in (a, v, b)):
                F.fail("CHK_MARK_POINTS", "RIGHT_MARK_IF_ANY", "%s: right mark "
                       "on undrawn points" % e.ref)
                continue
            V, A_, B_ = self.pts[v], self.pts[a], self.pts[b]
            p0, p1, p2 = e.pts
            ua = ((A_[0] - V[0]) / _d(A_, V), (A_[1] - V[1]) / _d(A_, V))
            ub = ((B_[0] - V[0]) / _d(B_, V), (B_[1] - V[1]) / _d(B_, V))
            ang = math.degrees(math.acos(max(-1, min(1, ua[0] * ub[0] +
                                                       ua[1] * ub[1]))))
            ok = abs(ang - 90) <= RIGHT_TOL_DEG
            ends_ok = False
            for x, y in ((p0, p2), (p2, p0)):
                la, lb = _d(x, V), _d(y, V)
                if _line_dist(x, V, A_) <= 0.3 and _line_dist(y, V, B_) <= 0.3 \
                        and RIGHT_MIN_PX <= la <= RIGHT_MAX_PX and \
                        RIGHT_MIN_PX <= lb <= RIGHT_MAX_PX:
                    ends_ok = True
            corner = (p0[0] + p2[0] - V[0], p0[1] + p2[1] - V[1])
            if not ok or not ends_ok or _d(corner, p1) > 0.3:
                F.fail("CHK_RIGHT_MARK", "RIGHT_MARK_IF_ANY", "%s: the right "
                       "mark at %s is not on a measured right angle %s%s%s "
                       "(%.1f deg)" % (e.ref, v, a, v, b, ang))
            # the claim must be a drawn given
            segs = set(["seg:" + "".join(sorted([a, v])),
                        "seg:" + "".join(sorted([v, b]))])
            claimed = False
            for f in self.pub.facts.values():
                if f["id"] not in self.pub.draws:
                    continue
                if f.get("rel") == "perpendicular":
                    pts = [set(self.pub.points_of(x)) for x in f["args"][:2]]
                    if len(pts) == 2 and {a, v} <= (pts[0] | pts[1]) and \
                            {v, b} <= (pts[0] | pts[1]) and v in pts[0] & \
                            pts[1]:
                        claimed = True
                elif f.get("rel") == "angle_measure" and \
                        _q(f.get("value")) == 90:
                    ent = self.pub.ents.get(f["args"][0]) or {}
                    if ent.get("vertex") == v and set(ent.get("arms") or
                                                      ()) == {a, b}:
                        claimed = True
            if not claimed:
                F.fail("CHK_MARK_UNSTATED", "RIGHT_MARK_IF_ANY", "%s: a right "
                       "angle at %s that no drawn fact states" % (e.ref, v))
            del segs

    def _captions(self):
        """a caption prints a drawn given's value, beside its object."""
        F = self.F
        self.captions = {}
        for e in self.els("data-for"):
            ps = e.hv.split(" ")
            if ps[0] == "coord":
                n = ps[1]
                fx = [f for f in self.pub.facts.values()
                      if f["id"] in self.pub.draws and
                      f.get("rel") == "coordinate" and f["args"][0] == n and
                      f.get("value") is not None and
                      f.get("role") in ("given", "derived", "context")]
                vx = [f for f in fx if f["args"][1] == self.ax.aid]
                vy = [f for f in fx if f["args"][1] == self.ay.aid]
                want = "(%s, %s)" % (num_display(_q(vx[0]["value"])),
                                     num_display(_q(vy[0]["value"]))) \
                    if vx and vy else None
                if want is None or e.text != want:
                    F.fail("CHK_CAPTION_UNSTATED", "TARGET_VALUE_NOT_SHOWN",
                           "%s: %r beside %s -- the drawn givens say %r" % (
                               e.ref, e.text, n, want), n)
                self.captions[e.ref] = n
                if n in self.pts and _box_dist(self.box(e), self.pts[n]) > \
                        LABEL_NEAR_PX + 12:
                    F.fail("CHK_CAPTION_FAR", "PT_LABEL_OWNED", "%s: the "
                           "coordinates of %s stand far from it" % (e.ref, n),
                           n)
            elif ps[0] == "seg":
                a, b = ps[1], ps[2]
                sid = "seg:" + a + b
                fl = [f for f in self.pub.facts.values()
                      if f["id"] in self.pub.draws and
                      f.get("rel") == "length" and f["args"] == [sid] and
                      f.get("value") is not None]
                want = num_display(_q(fl[0]["value"])) if fl and \
                    _q(fl[0]["value"]) is not None else None
                if want is None or e.text != want:
                    F.fail("CHK_CAPTION_UNSTATED", "TARGET_VALUE_NOT_SHOWN",
                           "%s: %r beside %s -- the drawn givens say %r" % (
                               e.ref, e.text, sid, want), sid)
                self.captions[e.ref] = sid
                if a in self.pts and b in self.pts:
                    bx = self.box(e)
                    c = ((bx[0] + bx[2]) / 2.0, (bx[1] + bx[3]) / 2.0)
                    own = _seg_dist(c, self.pts[a], self.pts[b])
                    for e2, p, q, _k in self.pieces:
                        if sorted(e2.hv.split(" ")) != [a, b] and \
                                _seg_dist(c, p, q) + OWN_MARGIN_PX < own:
                            F.fail("CHK_CAPTION_OWNER", "TARGET_VALUE_NOT_SHOWN",
                                   "%s: %r stands nearer %s than its own "
                                   "segment" % (e.ref, e.text, e2.hv), sid)
                            break
            else:
                n = ps[0]
                if e.text != n:
                    F.fail("CHK_NAME_TEXT", "OCR_PT_LABEL_AT_POINT", "%s: "
                           "the name label of %s prints %r" % (e.ref, n,
                                                               e.text), n)
                f = [x for x in self.pub.facts.values()
                     if x.get("rel") == "name" and x.get("args") == [n] and
                     x["id"] in self.pub.draws]
                if not f:
                    F.fail("CHK_NAME_UNSTATED", "PT_LABEL_OWNED", "%s: the "
                           "letter %s is printed, the figure draws no name "
                           "fact of it" % (e.ref, n), n)
                if n not in self.pts:
                    F.fail("CHK_NAME_NO_DOT", "PT_NOT_DRAWN_ANY_FORM", "%s: "
                           "the letter %s with no dot" % (e.ref, n), n)
                    continue
                b = self.box(e)
                self.label_boxes[e.ref] = (n, b)
                d0 = _box_dist(b, self.pts[n])
                near = [m for m, c in self.pts.items() if m != n and
                        _box_dist(b, c) < d0 + OWN_MARGIN_PX]
                if d0 > LABEL_NEAR_PX or near:
                    F.fail("CHK_LABEL_NOT_OWNED", "PT_LABEL_OWNED", "%s: %s "
                           "stands %.1f px from its dot%s" % (
                               e.ref, n, d0, "; nearer %s" % near if near
                               else ""), n)
        # a drawn name fact must print
        for f in self.pub.facts.values():
            if f.get("rel") == "name" and f["id"] in self.pub.draws and \
                    self.pub.kind(f["args"][0]) == "point":
                n = f["args"][0]
                if not self.els("data-for", n):
                    F.fail("CHK_NAME_MISSING", "PT_LABEL_OWNED", "the figure "
                           "draws the name of %s; it is not printed" % n, n)

    def _texts(self):
        """every label inside the canvas, clear of data strokes, dots,
        ticks and arrows (grid lines: REVIEW -- the house knocks them out)."""
        F = self.F
        W, H = self.dr.W, self.dr.H
        strokes = []
        for e in self.dr.els:
            if e.tag == "line" and e.hook != "data-grid":
                strokes.append((e, e.pts[0], e.pts[1]))
            elif e.tag in ("polygon", "polyline", "path"):
                ps = e.pts + ([e.pts[0]] if e.tag in ("polygon", "path") else [])
                for p, q in zip(ps, ps[1:]):
                    strokes.append((e, p, q))
        grid = [(e, e.pts[0], e.pts[1]) for e in self.els("data-grid")]
        dots = [(e.hv, e.pts[0], float(e.a.get("r", 2))) for e in
                self.els("data-pt") + self.els("data-dot")]
        texts = [e for e in self.dr.els if e.tag == "text"]
        for e in texts:
            b = self.box(e)
            is_num = e.hook == "data-num"
            chk = "AX_NUMBERS_NOT_CUT" if is_num else "TEXT_BOX_IN_CANVAS"
            if b[0] < T.CANVAS_MARGIN_PX or b[1] < T.CANVAS_MARGIN_PX or \
                    b[2] > W - T.CANVAS_MARGIN_PX or \
                    b[3] > H - T.CANVAS_MARGIN_PX:
                F.fail("CHK_TEXT_CLIPPED", chk, "%s %r reaches past the "
                       "canvas %s" % (e.ref, e.text, [round(v, 1)
                                                        for v in b]),
                       self._owner(e))
            core = (b[0] + CORE_SHRINK_PX, b[1] + CORE_SHRINK_PX,
                    b[2] - CORE_SHRINK_PX, b[3] - CORE_SHRINK_PX)
            if core[0] >= core[2] or core[1] >= core[3]:
                continue
            for s, p, q in strokes:
                ln = _clip_len(p, q, core)
                if ln > STROKE_IN_CORE_PX:
                    F.fail("CHK_TEXT_CROSSED", chk if is_num else
                           "TEXT_NOT_COVERING_MARKS", "%s %r is crossed by "
                           "%s (%s %s) for %.1f px" % (
                               e.ref, e.text, s.ref, s.hook, s.hv, ln),
                           self._owner(e))
                    break
            for s, p, q in grid:
                if _clip_len(p, q, core) > STROKE_IN_CORE_PX:
                    F.review("CHK_GRID_UNDER_TEXT", chk if is_num else
                             "TEXT_NOT_COVERING_MARKS", "%s %r: grid line %s "
                             "runs through it (the house knocks the grid out "
                             "under a text)" % (e.ref, e.text, s.ref),
                             self._owner(e))
                    break
            for n, c, r in dots:
                if _box_dist(core, c) < r * 0.5:
                    F.fail("CHK_TEXT_ON_DOT", chk if is_num else
                           "TEXT_NOT_COVERING_MARKS", "%s %r covers the dot "
                           "of %s" % (e.ref, e.text, n), self._owner(e))
        for i, e in enumerate(texts):
            for f in texts[i + 1:]:
                if _overlap(self.box(e), self.box(f)):
                    F.fail("CHK_TEXT_OVERLAP", "TEXT_NOT_COVERING_MARKS",
                           "%s %r and %s %r overlap" % (e.ref, e.text, f.ref,
                                                        f.text))

    def _owner(self, e):
        if e.hook == "data-num":
            if e.hv == "origin":
                return "plane"
            return "axis:" + e.hv.split(" ")[0]
        if e.hook == "data-axname":
            return "axis:" + e.hv
        ps = e.hv.split(" ")
        return ps[-1] if ps[0] == "coord" else ("seg:" + ps[1] + ps[2]) \
            if ps[0] == "seg" else ps[0]

    # ------------------------------------------------------------ leaks --
    def _leaks(self):
        F = self.F
        pub = self.pub
        hidden = {r["point"]: "the parameter has no supplied position" for r in pub.locus_objects.values() if not r["example"]}
        vals = pub.value_coords()
        # C1: locally recompute the public task's transform, then measure
        # real marker ink at its result. No private answer enters the SVG,
        # object map or public model; anonymous dots are checked as well.
        from .. import point_transform as PT
        if pub.sketch is None and all(v is not None for v in
                                     (self.ax.step, self.ay.step, self.ax.zero, self.ay.zero)):
            for q, item, row in PT.rows(pub.spec):
                if q.get("id") != pub.qid:
                    continue
                truth = PT.expected(pub.spec, q["id"], item["id"], row)
                if truth is None:
                    continue
                pos = (self.px(self.ax, float(truth[0] / self.ax.step) + self.ax.zero),
                       self.px(self.ay, float(truth[1] / self.ay.step) + self.ay.zero))
                licensed = set()
                for e in self.dr.els:
                    if e.tag != "circle" or e.layer != "points":
                        continue
                    try:
                        center = (float(e.a["cx"]), float(e.a["cy"]))
                        radius = float(e.a.get("r", 0))
                    except (KeyError, ValueError, TypeError):
                        continue
                    if radius <= 0 or e.a.get("fill") == "none" or _d(center, pos) > 1.0:
                        continue
                    # A supplied point fixed by the transform is still
                    # legitimate given ink; an extra marker is not licensed.
                    named = next((p for p in pub.shown_points()
                                  if pub.ents.get(p, {}).get("name") == e.hv), None)
                    om = getattr(self, "object_map", {}) or {}
                    entry = (om.get("elements") or {}).get(e.ref, {})
                    display = next((d for d in om.get("display_items") or []
                                    if d.get("id") == entry.get("item")), {})
                    obj = (om.get("objects") or {}).get(named, {})
                    supplied = {tuple(f.get("args") or []): _q(f["value"])
                                for f in pub.q_facts() if f.get("rel") == "coordinate"
                                and f.get("role") == "given" and "value" in f}
                    if named != row["result_point"] and named is not None and named not in licensed and \
                            tuple(supplied.get((named, a)) for a in PT.AXES) == truth and \
                            display.get("role") == "point" and \
                            (display.get("source") or {}).get("entity") == named and \
                            obj.get("kind") == "point" and any(
                                p.get("element") == e.ref and p.get("span") == "whole" for p in obj.get("parts") or []):
                        licensed.add(named)
                        continue
                    F.fail("CHK_TRANSFORM_RESULT_DRAWN", "PT_NOT_DRAWN_ANY_FORM",
                           "%s: marker %s supplies a computed transform result" % (row["id"], e.ref), row["result_point"])
                    F.fail("CHK_TRANSFORM_RESULT_DRAWN", "NO_ANSWER_ANYWHERE_SVG",
                           "%s: computed student result is present as marker ink" % row["id"], row["result_point"])
        plot_polys = {}
        for f in pub.q_facts():
            role, rel, args = f.get("role"), f.get("rel"), f.get("args") or []
            if role in ("to_plot", "to_construct") and args and pub.kind(args[0]) == "polygon":
                # (v6.16 gaps, G5) a polygon to plot: every vertex (named or
                # an unnamed vertex placed by its given coordinates) and
                # every side is the student's to draw
                vs = pub.points_of(args[0])
                plot_polys[args[0]] = (vs, f["id"])
                for v in vs:
                    if role == "to_construct" and v in pub.shown_points():
                        continue  # a supplied vertex is part of the givens
                    hidden[v] = "%s asks to plot polygon %s" % (f["id"],
                                                                args[0])
                continue
            if (role == "to_plot" or role == "to_construct" and args and pub.kind(args[0]) == "point") and args:
                if role == "to_construct" and args[0] in pub.shown_points():
                    continue
                hidden[args[0]] = "%s asks to plot it" % f["id"]
            elif role == "target" and rel == "coordinate" and \
                    pub.task.get(f.get("item")) not in READ_TASKS:
                hidden[args[0]] = "%s asks to find its coordinate (%s)" % (
                    f["id"], pub.task.get(f.get("item")))
            elif role == "to_construct" and args and \
                    pub.kind(args[0]) in ("segment", "line", "ray"):
                a, b = (pub.points_of(args[0]) + [None, None])[:2]
                c = self.cover(a, b) if a and b else None
                if c is not None:
                    F.fail("CHK_ANSWER_DRAWN", "SEG_NOT_DRAWN", "%s: %s is "
                           "the student's to draw (%s) and the figure draws "
                           "it (%s)" % (args[0], args[0], f["id"], c[0]),
                           args[0])
                    F.fail("CHK_CONSTRUCTION_ANSWER_INK", "NO_ANSWER_ANYWHERE_SVG",
                           "%s supplies the student's construction (%s)" % (args[0], f["id"]), args[0])
        for n, why in sorted(hidden.items()):
            forms = []
            for e in self.dr.els:
                if e.hook in ("data-pt", "data-for", "data-seg", "data-line",
                              "data-ray", "data-guide", "data-mark") and \
                        n in e.hv.split(" "):
                    forms.append("%s %s=%r" % (e.ref, e.hook, e.hv))
            # its given place (a plot) holds no dot either
            if (n, self.ax.aid) in vals and (n, self.ay.aid) in vals and \
                    self.ax.step is not None and self.ay.step is not None:
                P = (self.px(self.ax, float(vals[(n, self.ax.aid)] /
                                            self.ax.step) + self.ax.zero),
                     self.px(self.ay, float(vals[(n, self.ay.aid)] /
                                            self.ay.step) + self.ay.zero))
                for m, c in self.pts.items():
                    if _d(c, P) <= 1.0:
                        forms.append("a dot (%s) at its place" % m)
            if forms:
                F.fail("CHK_ANSWER_DRAWN", "PT_NOT_DRAWN_ANY_FORM", "%s must "
                       "not be drawn (%s): %s" % (n, why, "; ".join(forms)),
                       n)
                F.fail("CHK_CONSTRUCTION_ANSWER_INK", "NO_ANSWER_ANYWHERE_SVG",
                       "%s supplies a student point that the public task leaves undrawn: %s" % (n, "; ".join(forms)), n)
                for e in self.els("data-seg"):
                    if n in e.hv.split(" "):
                        F.fail("CHK_PARAMETER_OR_CONSTRUCTION_SEGMENT", "SEG_NOT_DRAWN",
                               "segment uses the unsupplied point %s" % n,
                               "seg:" + "".join(e.hv.split(" ")))
                polys = [e for e, x in pub.ents.items()
                         if x.get("kind") == "polygon" and
                         n in (x.get("vertices") or [])]
                if polys:
                    F.fail("CHK_ANSWER_DRAWN", "POLY_MISSING_VERTEX_NOT_DRAWN",
                           "%s is the vertex to find of %s: neither it nor "
                           "its sides are drawn" % (n, ", ".join(polys)), n)
        self._gap_leaks(hidden, plot_polys, vals)
        # an asked interval value is not printed by two neighbouring numbers
        for f in pub.q_facts():
            if f.get("role") == "target" and f.get("rel") == \
                    "interval_value":
                A = self.axes.get(f["args"][0])
                if A is None:
                    continue
                idx = sorted(i for i, e in getattr(A, "num_els", {}).items())
                if A.zero is not None and self.origin_els:
                    idx = sorted(set(idx) | {A.zero})
                if any(b - a == 1 for a, b in zip(idx, idx[1:])):
                    F.fail("CHK_INTERVAL_PRINTED", "TARGET_VALUE_NOT_SHOWN",
                           "%s asks the value of an interval of %s; two "
                           "neighbouring ticks print their numbers" % (
                               f["id"], A.aid), A.aid)

    def _place_px(self, n, vals):
        """the px place of a point / unnamed vertex from its public
        coordinates, or None."""
        if (n, self.ax.aid) not in vals or (n, self.ay.aid) not in vals or \
                self.ax.step is None or self.ay.step is None:
            return None
        return (self.px(self.ax, float(vals[(n, self.ax.aid)] /
                                       self.ax.step) + self.ax.zero),
                self.px(self.ay, float(vals[(n, self.ay.aid)] /
                                       self.ay.step) + self.ay.zero))

    def _strokes_on(self, P, Q):
        """the drawn data strokes (segment / line / ray / guide pieces) that
        lie along the piece P..Q (collinear within ON_TOL_PX) and overlap it
        by more than 1 px."""
        out = []
        L = _d(P, Q)
        if L < 1.0:
            return out
        u = ((Q[0] - P[0]) / L, (Q[1] - P[1]) / L)
        for e in self.dr.els:
            if e.hook not in ("data-seg", "data-line", "data-ray",
                              "data-guide") or len(e.pts) != 2:
                continue
            p, q = e.pts
            if _line_dist(p, P, Q) > ON_TOL_PX or \
                    _line_dist(q, P, Q) > ON_TOL_PX:
                continue
            t = sorted(((p[0] - P[0]) * u[0] + (p[1] - P[1]) * u[1],
                        (q[0] - P[0]) * u[0] + (q[1] - P[1]) * u[1]))
            if min(t[1], L) - max(t[0], 0.0) > 1.0:
                out.append("%s %s=%r" % (e.ref, e.hook, e.hv))
        return out

    def _gap_leaks(self, hidden, plot_polys, vals):
        """(v6.16 gaps) G5: a polygon to plot -- its vertices are hidden
        points (the loop above: no dot at a vertex's given place, which is
        how an unnamed vertex, with no name a hook could carry, is checked:
        PT_NOT_DRAWN_ANY_FORM) and no stroke runs along any of its sides
        (SEG_NOT_DRAWN). G1: a partial polygon's vertices the
        figure does not show, and every side touching one, are drawn in no
        form (POLY_MISSING_VERTEX_NOT_DRAWN) -- whether or not they are a
        target."""
        F, pub = self.F, self.pub
        for pid, (vs, fid) in sorted(plot_polys.items()):
            # every vertex is in `hidden` (the loop above found a dot at its
            # given place, or a hook naming it); here: the sides
            places = [(v, self._place_px(v, vals)) for v in vs]
            n = len(places)
            for i in range(n):
                (a, P), (b, Q) = places[i], places[(i + 1) % n]
                supplied = any(pub.kind(e) in ("segment","line","ray") and
                               {a,b} <= set(pub.points_of(e))
                               for e in pub.listed)
                if supplied and a not in hidden and b not in hidden:
                    continue  # an explicitly supplied side stays a given
                claimed = self.els("data-seg", " ".join(sorted([a,b])))
                if claimed:
                    F.fail("CHK_CONSTRUCTION_SIDE_INK", "SEG_NOT_DRAWN",
                           "side %s-%s supplies the student polygon %s" % (a,b,pid),pid)
                    F.fail("CHK_CONSTRUCTION_SIDE_INK", "NO_ANSWER_ANYWHERE_SVG",
                           "side %s-%s supplies the student polygon %s" % (a,b,pid),pid)
                if P is None or Q is None:
                    continue
                got = self._strokes_on(P, Q)
                if got:
                    F.fail("CHK_ANSWER_DRAWN", "SEG_NOT_DRAWN", "side %s-%s "
                           "of %s is the student's to draw (%s) and the "
                           "figure draws it: %s" % (
                               a, b, pid, fid, "; ".join(got)), pid)
                    F.fail("CHK_CONSTRUCTION_SIDE_INK", "NO_ANSWER_ANYWHERE_SVG",
                           "a measured side supplies the student polygon %s: %s" % (pid,"; ".join(got)),pid)
        shown = pub.shown_points()
        for pid, vs in sorted(pub.partial_polygons().items()):
            miss = [v for v in vs if v not in shown]
            for v in miss:
                if v in hidden:
                    continue             # reported above (the answer)
                forms = ["%s %s=%r" % (e.ref, e.hook, e.hv)
                         for e in self.dr.els
                         if e.hook in ("data-pt", "data-for", "data-seg",
                                       "data-line", "data-ray", "data-guide",
                                       "data-mark") and
                         v in e.hv.split(" ")]
                P = self._place_px(v, vals)
                if P is not None:
                    forms += ["a dot (%s) at its place" % m for m, c in
                              sorted(self.pts.items()) if _d(c, P) <= 1.0]
                if forms:
                    F.fail("CHK_ANSWER_DRAWN", "POLY_MISSING_VERTEX_NOT_DRAWN",
                           "%s is a vertex of %s the figure does not show; "
                           "it is drawn: %s" % (v, pid, "; ".join(forms)),
                           v)
        # (v6.16 gaps r2) an UNNAMED place -- a vertex of a polygon declared
        # by coordinates (G5) or a place of an unnamed LIST ("לפניכם רשימת
        # נקודות, (5,0), (0,3), ...", G7-T08 b q8: vertex entities of the
        # list's tag, no polygon) -- is never shown (a vertex is no
        # coordinate-plane kind, FAMILY_ENTITY): a dot at its public place
        # draws it (PT_NOT_DRAWN_ANY_FORM). A dot of a point the figure
        # SHOWS by declaration is that point's, not a drawing of the place.
        mine = set(self.pub.shown_points())
        # A table's unnamed coordinate place can be explicitly displayed as
        # an observation. Only its validated given-fact binding licenses it.
        mine.update(oid for oid,p in pub.data_objects.items()
                    if p.get("kind")=="data_point" and p.get("drawn") and
                    p.get("coords") is not None and p.get("coord_facts"))
        for v in sorted(e for e, x in pub.ents.items()
                        if x.get("kind") == "vertex"):
            if v in hidden:
                continue                 # reported above (a to_plot)
            P = self._place_px(v, vals)
            if P is None:
                continue                 # not a place of this question
            forms = ["a dot (%s) at its place" % m for m, c in
                     sorted(self.pts.items()) if _d(c, P) <= 1.0 and
                     m not in mine]
            if forms:
                F.fail("CHK_ANSWER_DRAWN", "PT_NOT_DRAWN_ANY_FORM", "%s, an "
                       "unnamed place the text lists, is never drawn: %s"
                       % (v, "; ".join(forms)), v)

    # ---------------------------------------------------------- objects --
    def _objects(self):
        """the measured element set of every object the figure shows."""
        E = self.elements_of
        for A in (self.ax, self.ay):
            refs = [e.ref for e in self.els("data-axis", A.letter) +
                    self.els("data-break", A.letter) +
                    self.els("data-arrow", A.letter) +
                    self.els("data-axname", A.letter)]
            refs += [e.ref for e in self.els("data-tick")
                     if e.hv.split(" ")[0] == A.letter]
            refs += [e.ref for e in getattr(A, "num_els", {}).values()]
            if A.zero is not None and any(i == A.zero for i, _v in A.labels):
                refs += [e.ref for e in self.origin_els]
            E[A.aid] = set(refs)
        pl = self.pub.frame.get("plane")
        E[pl] = set(e.ref for e in self.els("data-grid"))
        for n in self.pts:
            E[n] = set(e.ref for e in self.els("data-pt", n) +
                       self.els("data-for", n) +
                       self.els("data-for", "coord " + n))
        self.parts = {}
        for eid in sorted(self.pub.listed | self._drawn_args()):
            k = self.pub.kind(eid)
            if k in ("segment", "polygon", "line", "ray"):
                refs, parts = set(), {}
                pts = self.pub.points_of(eid)
                sides = [(pts[0], pts[1])] if k != "polygon" else \
                    [(pts[i], pts[(i + 1) % len(pts)])
                     for i in range(len(pts))]
                if k in ("line", "ray"):
                    hook = "data-" + k
                    hv = " ".join(sorted(pts) if k == "line" else pts)
                    for e in self.els(hook, hv):
                        refs.add(e.ref)
                else:
                    for a, b in sides:
                        c = self.cover(a, b)
                        if c is None:
                            if k == "segment" and a in self.pts and b in self.pts:
                                self.F.fail("CHK_SEGMENT_SPAN_ENDPOINTS", "SEG_ENDS_AT_COORDS",
                                            "%s: no drawn stroke joins its measured endpoint centres" % eid, eid)
                            self.F.fail("CHK_SIDE_MISSING", "POLY_SIDES_MAPPED"
                                        if k == "polygon" else
                                        "SEG_ENDS_MATCH", "%s: its piece %s%s "
                                        "is not drawn" % (eid, a, b), eid)
                            continue
                        refs.add(c[0])
                        if c[1] != "whole":
                            parts[c[0]] = tuple(c[1])
                if k == "segment":
                    a, b = sorted(pts)
                    refs |= set(e.ref for e in self.els(
                        "data-for", "seg %s %s" % (a, b)))
                refs |= set(e.ref for e in self.els("data-mark")
                            if self._mark_on(e, eid, k, pts))
                E[eid] = refs
                self.parts[eid] = parts
            elif k == "tick":
                ent = self.pub.ents[eid]
                A = self.axes.get(ent.get("axis"))
                at = _q(ent.get("at"))
                if A is None or at is None or A.step is None:
                    continue
                i = at / A.step + A.zero
                if i.denominator != 1:
                    continue
                i = int(i)
                E[eid] = set(e.ref for e in self.els("data-tick", "%s %d" % (
                    A.letter, i))) | set(e.ref for e in self.els(
                        "data-num", "%s %d" % (A.letter, i)))
        for fid, refs in self.guide_els.items():
            E[fid] = set(refs)
        # (v6.16 gaps, G2) the origin: the two axis LINES (they cross
        # there) + the origin's printed '0' -- no ink of its own
        for o in self.pub.origins():
            E[o] = set(e.ref for e in self.els("data-axis")) | \
                set(e.ref for e in self.origin_els)
        # (v6.16 gaps, G1) a partial polygon: its drawn sides between
        # consecutive SHOWN vertices + the dots of its shown vertices
        shown = self.pub.shown_points()
        for eid, vs in sorted(self.pub.partial_polygons().items()):
            refs, parts = set(), {}
            n = len(vs)
            for i in range(n):
                a, b = vs[i], vs[(i + 1) % n]
                if a in shown and b in shown:
                    c = self.cover(a, b)
                    if c is not None:
                        refs.add(c[0])
                        if c[1] != "whole":
                            parts[c[0]] = tuple(c[1])
            for v in vs:
                if v in shown:
                    refs |= set(e.ref for e in self.els("data-pt", v))
            E[eid] = refs
            self.parts[eid] = parts

    def _drawn_args(self):
        out = set()
        for d in self.pub.draws:
            for a in (self.pub.facts.get(d) or {}).get("args") or []:
                if self.pub.kind(a) in ("segment", "polygon", "line", "ray"):
                    out.add(a)
        return out

    def _mark_on(self, e, eid, k, pts):
        _r, a, v, b = e.hv.split(" ")
        if k == "segment":
            return set(pts) in ({a, v}, {v, b})
        if k in ("line", "ray"):
            return v in pts and (a in pts or b in pts)
        return False


# ---------------------------------------------------------------- map ----
def check_map(om, cc, dr, pub, F):
    """the object map against the drawing and the measurement."""
    if not isinstance(om, dict) or set(om) != MAP_TOP:
        F.fail("CHK_MAP_KEYS", "OBJMAP_TOTAL_NO_UNMAPPED_INK", "map keys %s"
               % (sorted(om) if isinstance(om, dict) else type(om)))
        return None
    refs = [e.ref for e in dr.els]
    owner = {}
    for it in om.get("display_items") or []:
        role = it.get("role")
        if role not in ROLE_HOOK:
            F.fail("CHK_MAP_ROLE", "OBJMAP_TOTAL_NO_UNMAPPED_INK", "item %s "
                   "role %r" % (it.get("id"), role))
            continue
        src = it.get("source") or {}
        if src.get("entity") and src["entity"] not in pub.ents or \
                src.get("fact") and src["fact"] not in pub.facts:
            F.fail("CHK_MAP_SOURCE", "OBJMAP_TOTAL_NO_UNMAPPED_INK", "item %s "
                   "source %r" % (it.get("id"), src))
        for r in it.get("elements") or []:
            if r in owner:
                F.fail("CHK_MAP_SHARED", "OBJMAP_TOTAL_NO_UNMAPPED_INK",
                       "%s in items %s and %s" % (r, owner[r], it.get("id")))
            owner[r] = it.get("id")
            e = dr.by_ref.get(r)
            if e is None:
                F.fail("CHK_MAP_UNKNOWN", "OBJMAP_TOTAL_NO_UNMAPPED_INK",
                       "item %s names %s, not an element" % (it.get("id"), r))
                continue
            if e.hook != ROLE_HOOK[role] or (role == "origin_number") != (
                    e.hv == "origin" and e.hook == "data-num"):
                F.fail("CHK_MAP_ROLE", "OBJMAP_TOTAL_NO_UNMAPPED_INK", "%s "
                       "(%s) is mapped as %s" % (r, e.hook, role))
            if "text" in it and e.tag == "text" and it["text"] != e.text:
                F.fail("CHK_MAP_TEXT", "OBJMAP_TOTAL_NO_UNMAPPED_INK", "%s "
                       "prints %r, the map says %r" % (r, e.text, it["text"]))
    for r in refs:
        if r not in owner:
            F.fail("CHK_MAP_UNMAPPED", "OBJMAP_TOTAL_NO_UNMAPPED_INK", "%s "
                   "(%s %s) is ink no display item owns" % (
                       r, dr.by_ref[r].hook, dr.by_ref[r].hv))
    els = om.get("elements") or {}
    if set(els) != set(refs) or any(owner.get(r) != (els.get(r) or {}).get(
            "item") for r in refs):
        F.fail("CHK_MAP_ELEMENTS", "OBJMAP_TOTAL_NO_UNMAPPED_INK", "the map's "
               "element table disagrees with its items / the file")
    mapped = {}
    for oid, o in sorted((om.get("objects") or {}).items()):
        refs_o = set(p.get("element") for p in o.get("parts") or [])
        spans = dict((p["element"], tuple(p["span"])) for p in
                     o.get("parts") or [] if p.get("span") != "whole")
        mapped[oid] = {"elements": refs_o, "parts": spans}
        want = cc.elements_of.get(oid)
        if want is None:
            if oid in pub.ents or oid in pub.facts:
                F.fail("CHK_MAP_MISMATCH", "OBJMAP_TOTAL_NO_UNMAPPED_INK",
                       "object %s is mapped but the drawing does not show it"
                       % oid, oid)
            else:
                F.fail("CHK_MAP_OBJECT", "OBJMAP_TOTAL_NO_UNMAPPED_INK",
                       "object %r is not a public id" % oid)
            continue
        if refs_o != want:
            F.fail("CHK_MAP_MISMATCH", "OBJMAP_TOTAL_NO_UNMAPPED_INK",
                   "object %s: map %s, measured %s" % (
                       oid, sorted(refs_o, key=lambda r: int(r[1:])),
                       sorted(want, key=lambda r: int(r[1:]))), oid)
        if spans != (cc.parts.get(oid) or {}) and oid in cc.parts:
            F.fail("CHK_MAP_SPAN", "OBJMAP_TOTAL_NO_UNMAPPED_INK", "object %s: "
                   "spans %s, measured %s" % (oid, spans, cc.parts[oid]), oid)
    for oid, want in sorted(cc.elements_of.items()):
        if want and oid not in mapped:
            F.fail("CHK_MAP_MISSING_OBJECT", "OBJMAP_TOTAL_NO_UNMAPPED_INK",
                   "object %s is drawn (%d elements) but not in the map" % (
                       oid, len(want)), oid)
    return mapped


# ------------------------------------------------------------------ OCR --
_DASHES = X.DASH_FORMS


def _fold(s):
    """v6.13: the documented read fold (ocr_expect.fold_read): every dash
    form -> '-', Cyrillic / Greek homoglyphs -> Latin, no spaces."""
    return X.fold_read(s)


OCR_HEIGHTS = (24, 32, 40, 52)


def _tile_of(text):
    """Vision skips a lone short label and misreads a lone minus: a label of
    up to four visible characters is read TILED three times ('-5-5-5')."""
    return 3 if len(_fold(text)) <= 4 else 1


def _read_ok(expected, read, tile):
    e1 = _fold(expected)
    r = "".join(T.OCR_HOMOGLYPHS.get(ch, ch) for ch in _fold(read))
    if len(e1) == 1 and tile > 1:
        # a tiled letter: Vision may drop / add one copy (ocr.matches)
        return len(r) >= 2 and abs(len(r) - tile) <= 1 and \
            all(O.conf_eq(ch, e1) for ch in r)
    # v6.13: 1, 2 or `tile` copies, or >= 2 exact copies then only a dash /
    # the label's own look-alikes / junk (ocr_expect.tiled_read)
    return X.tiled_read(e1, r, tile)


def _read_exact(expected, read, tile):
    e1 = _fold(expected)
    r = "".join(T.OCR_HOMOGLYPHS.get(ch, ch) for ch in _fold(read))
    if len(e1) == 1 and tile > 1:
        return len(r) >= 2 and abs(len(r) - tile) <= 1 and \
            all(ch == e1 for ch in r)
    return r == e1 * tile


def _ocr(disp, dr, cc, F, keep_dir):
    """OCR of every label from its crop of the final display (numbers with
    their minus sign, axis letters, point names, captions)."""
    import tempfile
    tmp = keep_dir or tempfile.mkdtemp(prefix="wspec_coord_ocr_")
    res, jobs, meta = {}, {}, {}
    texts = [e for e in dr.els if e.tag == "text"]
    for e in texts:
        b = cc.box(e)
        if e.hook == "data-num":
            chk = "OCR_AXIS_NUMBERS"
        elif e.hook == "data-axname":
            chk = "OCR_AXIS_NAMES"
        else:
            chk = "OCR_PT_LABEL_AT_POINT"
        meta[e.ref] = (chk, cc._owner(e), e.text)
        crop = disp.crop(b) if b else None
        ink = crop.ink_count() if crop else 0
        res[e.ref] = {"text": e.text, "ink_px": ink, "reads": [],
                      "status": None, "detail": ""}
        if crop is None or ink == 0:
            res[e.ref]["status"] = "MISSING"
            res[e.ref]["detail"] = "no ink where the label should be"
            continue
        tiles = [_tile_of(e.text)]
        if len(_fold(e.text)) == 1:
            tiles.append(5)         # a lone I / l: five copies read better
        for tile in tiles:
            for k, h in enumerate(OCR_HEIGHTS):
                img = O.prepare(crop, h, tile)
                if img is None:
                    continue
                path = os.path.join(tmp, "%s_%d_%d.png" % (e.ref, tile, k))
                with open(path, "wb") as fh:
                    fh.write(img.png())
                jobs[path] = (e.ref, tile)
    infra = []
    try:
        reads = O.run_helper(sorted(jobs)) if jobs else {}
        errs = dict(getattr(reads, "errors", None) or {})
    except Exception as ex:                             # noqa: BLE001
        reads, errs = {}, dict((p, "%s: %s" % (type(ex).__name__, ex))
                               for p in jobs)
    others = [(e.ref, e.text) for e in texts]
    by_ref = dict((e.ref, e) for e in texts)
    # v6.13: expected-set matching on the crop for the look-alike pairs
    # O/0, 6/9, B/8 (ocr_expect.decide_glyphs; None = undecided)
    glyph = {}
    for e in texts:
        if res[e.ref]["status"] is None and \
                any(ch in X.PAIRS for ch in _fold(e.text)):
            try:
                glyph[e.ref] = X.decide_glyphs(
                    X.glyph_crop(disp, cc.box(e), e.a.get("font-size")),
                    e.text, X.text_renderer(e.a, disp.scale))
            except Exception:                           # noqa: BLE001
                glyph[e.ref] = {"verdict": None}
    for path, (ref, tile) in sorted(jobs.items()):
        text = res[ref]["text"]
        gv = (glyph.get(ref) or {}).get("verdict")
        for (s_, conf, kind) in reads.get(path, []):
            m = _read_ok(text, s_, tile)
            rec = {"read": s_, "conf": round(conf, 3), "kind": kind,
                   "match": bool(m)}
            if m == "consensus":
                rec["consensus"] = True
            if m and not _read_exact(text, s_, tile):
                rec["lookalike"] = True
                riv = [t for r2, t in others if r2 != ref and _fold(t) !=
                       _fold(text) and _read_ok(t, s_, tile)]
                if riv and gv == "expected":
                    # the crop itself decides the look-alike pair
                    rec["resolved_by_glyph"] = riv[0]
                elif riv:
                    rec["match"] = False
                    rec["ambiguous_with"] = riv[0]
            res[ref]["reads"].append(rec)
        if path in errs and res[ref]["status"] is None:
            res[ref]["status"] = "OCR_ERROR"
            res[ref]["detail"] = "OCR_UNAVAILABLE: %s" % errs[path]
    for ref, r in res.items():
        if r["status"]:
            continue
        tops = [x for x in r["reads"] if x["kind"] == "top" and
                x["conf"] >= T.OCR_MIN_CONF]
        g = glyph.get(ref) or {}
        if g.get("verdict") == "rival":
            # the crop shows the look-alike of a character of the label
            r["glyph"] = g
            same = [x for x in tops if x["match"] and not x.get("lookalike")]
            alike = [x for x in tops if x.get("lookalike") or
                     x.get("ambiguous_with")]
            if alike and not same:
                r["status"] = "WRONG_GLYPH"
                r["detail"] = ("expected %r: the crop shows its look-alike "
                               "(%s) and Vision reads %s" % (
                                   r["text"], g.get("chars"),
                                   sorted(set(x["read"] for x in alike))))
            else:
                r["status"] = "CONTRADICTS"
                r["detail"] = ("expected %r: the crop's shape is the "
                               "look-alike (%s), reads %s" % (
                                   r["text"], g.get("chars"),
                                   sorted(set(x["read"] for x in tops))))
            continue
        if any(x["match"] for x in tops):
            r["status"] = "CONFIRMED"
            first = [x for x in tops if x["match"]][0]
            r["detail"] = "read %r" % first["read"]
            if first.get("consensus"):
                r["detail"] += " (tiled copies agree)"
            if first.get("resolved_by_glyph"):
                r["detail"] += (" (look-alike of %r decided by the crop: %s)"
                                % (first["resolved_by_glyph"], g.get("chars")))
        elif tops:
            r["status"] = "CONTRADICTS"
            r["detail"] = "expected %r, read %s" % (
                r["text"], sorted(set(x["read"] for x in tops)))
        else:
            r["status"] = "UNREAD"
            r["detail"] = "ink present but Vision read nothing"
    # v6.13: a signed number Vision does not read whole -- its first column
    # segment must be the minus bar (by its ink) and the digits are read
    # alone (ocr_expect.split_signed); a 6 / 9 among them must be decided
    # by its hole (the digits alone lose the sign's orientation guard)
    jobs2 = {}
    for ref, r in res.items():
        e = by_ref[ref]
        if r["status"] not in ("CONTRADICTS", "UNREAD") or r.get("glyph") \
                or not (e.text or "").startswith(MINUS) or len(e.text) < 2:
            continue
        try:
            ok, dig = X.split_signed(disp.crop(cc.box(e)))
        except Exception:                               # noqa: BLE001
            ok, dig = False, None
        if not ok or dig is None:
            continue
        want = _fold(e.text[1:])
        if any(ch in "69" for ch in want):
            gd = X.decide_glyphs(dig, want, X.text_renderer(e.a, disp.scale))
            if gd.get("verdict") != "expected":
                continue
        r["sign_ink"] = True
        tile = _tile_of(want)
        for k, h in enumerate(OCR_HEIGHTS):
            img = O.prepare(dig, h, tile)
            if img is None:
                continue
            path = os.path.join(tmp, "%s_d%d_%d.png" % (ref, tile, k))
            with open(path, "wb") as fh:
                fh.write(img.png())
            jobs2[path] = (ref, tile, want)
    if jobs2:
        try:
            reads2 = O.run_helper(sorted(jobs2))
        except Exception:                               # noqa: BLE001
            reads2 = {}
        for path, (ref, tile, want) in sorted(jobs2.items()):
            r = res[ref]
            for (s_, conf, kind) in reads2.get(path, []):
                if kind != "top" or conf < T.OCR_MIN_CONF or \
                        r["status"] == "CONFIRMED":
                    continue
                rd = _fold(s_)
                if X.tiled_read(want, rd, tile) == "exact" and \
                        all(ch == c for ch, c in zip(rd, want * tile)):
                    r["status"] = "CONFIRMED"
                    r["detail"] = ("the minus by its ink (a solid bar), the "
                                   "digits read %r" % s_)
        jobs.update(dict((k, v[:2]) for k, v in jobs2.items()))
    if not keep_dir:
        for path in jobs:
            try:
                os.remove(path)
            except OSError:
                pass
        try:
            os.rmdir(tmp)
        except OSError:
            pass
    for ref, r in sorted(res.items()):
        chk, obj, text = meta[ref]
        st = r["status"]
        if st == "OCR_ERROR":
            F.review("CHK_OCR_UNAVAILABLE", chk, "%s: %r: %s" % (
                ref, text, r["detail"]), obj)
            if "OCR_UNAVAILABLE" not in infra:
                infra.append("OCR_UNAVAILABLE")
        elif st == "MISSING":
            F.fail("CHK_OCR_MISSING", chk, "%s: %r is not visible in the "
                   "final display (%s)" % (ref, text, r["detail"]), obj)
        elif st == "WRONG_GLYPH":
            F.fail("CHK_OCR_WRONG_GLYPH", chk, "%s: %s" % (
                ref, r["detail"]), obj)
        elif st == "UNREAD":
            F.review("CHK_OCR_UNREAD", chk, "%s: %r: %s" % (
                ref, text, r["detail"]), obj)
        elif st == "CONTRADICTS":
            F.review("CHK_OCR_CONTRADICTS", chk, "%s: %s" % (
                ref, r["detail"]), obj)
    return res, infra


def _display_ink(disp, svg, dr, cc, boxes, F):
    def render(one, x0, y0, w, h, s):
        return R.gray_pixmap(R._with_viewbox(one, x0, y0, w, h), s)
    try:
        res = IC.compare(disp, svg, dr.W, dr.H, list(boxes.values()), render)
    except Exception as e:                              # noqa: BLE001
        F.review("CHK_DISPLAY_INK_UNREAD", "DISPLAY_INK_MATCHES_FIGURE",
                 "the display's ink could not be compared: %s" % e)
        return None
    s2 = res["scale"] ** 2
    owners = {}
    for eid, refs in cc.elements_of.items():
        for ref in refs or ():
            owners.setdefault(ref, set()).add(eid)
    for ref, (miss, ink) in sorted(res["missing"].items()):
        if ink == 0 or miss < T.INK_MIN_SVG_PX2 * s2:
            continue
        frac = miss / float(ink)
        if frac <= T.INK_MISSING_REVIEW:
            continue
        own = sorted(owners.get(ref, ()))
        lvl = F.fail if frac > T.INK_MISSING_FAIL else F.review
        lvl("CHK_DISPLAY_INK_MISSING", "DISPLAY_INK_MATCHES_FIGURE",
            "%s (%s): %.0f%% of its ink is not in the final display" % (
                ref, ", ".join(own) or "no object", 100 * frac),
            own if len(own) > 1 else (own[0] if own else None))
    for ref, gap in sorted((res.get("gaps") or {}).items()):
        if (res["missing"].get(ref) or (0, 0))[1] == 0:
            continue        # a grid line: light grey, no ink at the raster's
            # ink level -- its gaps say nothing (G79 G checks its drawing)
        if gap >= T.INK_GAP_FAIL_SVG_PX:
            own = sorted(owners.get(ref, ()))
            F.fail("CHK_DISPLAY_INK_GAP", "DISPLAY_INK_MATCHES_FIGURE",
                   "%s (%s): the final display cuts a %.1f px gap into this "
                   "stroke" % (ref, ", ".join(own) or "no object", gap),
                   own if len(own) > 1 else (own[0] if own else None))
    if res["extra_px"] >= T.INK_MIN_SVG_PX2 * s2:
        lvl = F.fail if res["extra_px"] >= T.INK_EXTRA_FAIL_SVG_PX2 * s2 \
            else F.review
        lvl("CHK_DISPLAY_INK_EXTRA", "DISPLAY_INK_MATCHES_FIGURE",
            "the final display has %.1f px^2 of ink the approved figure does "
            "not draw, at %s" % (res["extra_px"] / s2, res["extra_box"]))
    return {"elements": len(res["missing"]),
            "missing": dict((k, [m, i]) for k, (m, i) in
                            res["missing"].items() if m),
            "extra_px": res["extra_px"], "extra_box": res["extra_box"],
            "r_px": res["r_px"]}


def _answer_guard(guard, dr, cc, F):
    """guarded values (the harness's answer values) are printed by no text
    but the frame's own numbers / letters and a caption of a drawn given
    (checked in _captions)."""
    vals = set()
    for g in guard or []:
        v = g.get("answer") if isinstance(g, dict) else g
        if v not in (None, ""):
            vals.add(_fold(str(v)))
    if not vals:
        return
    nums = set()
    for v in vals:
        nums |= set(re.findall(r"-?\d+(?:\.\d+)?", v))
    # (v6.16 fix r1) the drawn NAME of a drawn point (a name fact the figure
    # draws) is a given of the figure, never an answer exposure: "which
    # point is the middle of PR?" asks for one of the printed names (G7-T08
    # b q13d, answer S, with P, Q, R, S printed as in the source). A value
    # printed in a label (a pair, a number) is still checked.
    named = set(x["args"][0] for x in cc.pub.facts.values()
                if x.get("rel") == "name" and len(x.get("args") or []) == 1
                and x["id"] in cc.pub.draws)
    for e in dr.els:
        if e.tag != "text" or e.hook in ("data-num", "data-axname"):
            continue
        if e.ref in cc.captions:
            continue            # a caption: its value is a drawn given's
        if e.hook == "data-for" and e.hv == e.text and e.text in named and \
                e.text in cc.pts:
            continue            # a drawn point's own drawn name
        t = _fold(e.text)
        hit = [v for v in vals if v and v == t] or sorted(
            set(re.findall(r"-?\d+(?:\.\d+)?", t)) & nums)
        if hit:
            F.fail("CHK_ANSWER_EXPOSED", "NO_ANSWER_ANYWHERE_SVG", "%s: %r "
                   "prints the answer %s" % (e.ref, e.text, hit),
                   cc._owner(e))


# --------------------------------------------------------------- entry ----
def check_coord(svg, object_map, public_spec, figure_id, ocr=True,
                display_image=None, display_scale=None,
                display_origin=(0.0, 0.0), answer_guard=None, png_out=None,
                keep_ocr_dir=None):
    F = Findings()
    pub = Pub(public_spec, figure_id)
    if isinstance(svg, str) and not svg.lstrip().startswith("<"):
        with open(svg, "rb") as fh:
            svg = fh.read()
    raw = svg if isinstance(svg, bytes) else svg.encode("utf-8")
    dr = read_svg(raw)
    for p in dr.problems:
        F.fail("CHK_DIALECT", "DIALECT_CLOSED", p)
    rep = {"checker_version": T.CHECKER_VERSION + "+coord/1",
           "family": FAMILY, "figure": figure_id,
           "figure_accuracy": pub.fig.get("figure_accuracy")}
    disp, boxes = None, {}
    if dr.W is not None and dr.els and R.available():
        try:
            disp = R.Display(raw.decode("utf-8"), dr.W, dr.H,
                             image=display_image, image_scale=display_scale,
                             image_origin=display_origin)
            texts = [e.ref for e in dr.els if e.tag == "text"]
            boxes = disp.text_boxes(texts)
            for ref, b in boxes.items():
                if b is None:
                    F.fail("CHK_LABEL_NO_INK", "TEXT_BOX_IN_CANVAS", "%s: the "
                           "label draws no ink" % ref)
            boxes = dict((k, v) for k, v in boxes.items() if v)
            if png_out:
                disp.save_png(png_out)
        except Exception as e:                          # pragma: no cover
            F.review("CHK_RASTER_FAILED", "OCR_AXIS_NUMBERS", "the final "
                     "display could not be rasterised: %s" % e)
            disp = None
    elif not R.available():
        F.review("CHK_RASTER_UNAVAILABLE", "OCR_AXIS_NUMBERS", "PyMuPDF is "
                 "not installed: the final display is not seen")
    cc = CoordCheck(dr, pub, F, boxes, disp)
    cc.object_map = object_map
    cc.captions, cc.guide_els, cc.parts, cc.origin_els = {}, {}, {}, []
    if dr.W is not None and dr.els:
        try:
            cc.run()
        except (KeyError, ValueError, IndexError, ZeroDivisionError,
                AttributeError, TypeError) as e:
            F.fail("CHK_UNREADABLE", "DIALECT_CLOSED", "the drawing cannot be "
                   "measured: %s: %s" % (type(e).__name__, e))
    mapped = None
    if object_map is not None and dr.els:
        mapped = check_map(object_map, cc, dr, pub, F)
    elif object_map is None:
        F.note("CHK_MAP_ABSENT", "OBJMAP_TOTAL_NO_UNMAPPED_INK", "no object "
               "map given: map checks not run")
    _answer_guard(answer_guard, dr, cc, F)
    blank_canvas_checked = _blank_canvas_check(raw, cc, pub, F)
    ink_res = None
    if disp is not None and display_image is not None and dr.ok:
        ink_res = _display_ink(disp, raw.decode("utf-8"), dr, cc, boxes, F)
    ocr_res, infra = {}, []
    if disp is not None and ocr and dr.ok:
        if not O.helper_ok():
            F.review("CHK_OCR_UNAVAILABLE", "OCR_AXIS_NUMBERS",
                     "OCR_UNAVAILABLE: the OCR helper %s is not built"
                     % O.HELPER)
            infra.append("OCR_UNAVAILABLE")
        else:
            ocr_res, infra = _ocr(disp, dr, cc, F, keep_ocr_dir)
    elif not ocr:
        F.note("CHK_OCR_SKIPPED", "OCR_AXIS_NUMBERS", "OCR not requested")
    rep["status"] = worst(f["level"] for f in F.items)
    rep["findings"] = F.items
    checks = {}
    for c in ALL_CHECKS:
        fl = [f["level"] for f in F.items if f["check"] == c and
              f["level"] in (FAIL, REVIEW)]
        if fl:
            checks[c] = worst(fl)
        elif c in ("OBJMAP_TOTAL_NO_UNMAPPED_INK",
                   "HIGHLIGHT_ON_MEASURED_GEOMETRY") and mapped is None:
            checks[c] = NA
        elif c.startswith("OCR_") and not ocr_res:
            checks[c] = NA
        elif c == "DISPLAY_INK_MATCHES_FIGURE" and ink_res is None:
            checks[c] = NA
        else:
            checks[c] = PASS
    rep["checks"] = checks
    if getattr(cc, "data_checked", False):
        for c in CD.CHECKS:
            checks[c] = worst(f["level"] for f in F.items if f["check"] == c)
    if getattr(cc, "broken_checked", False):
        checks["AX_BROKEN_START_DECLARED"] = worst(f["level"] for f in F.items if f["check"] == "AX_BROKEN_START_DECLARED")
    if blank_canvas_checked:
        checks["SET_NOT_DRAWN"] = worst(f["level"] for f in F.items
                                        if f["check"] == "SET_NOT_DRAWN")
    rep["objects"] = _objects(cc, pub, F)
    rep["measured"] = {
        "canvas": [dr.W, dr.H],
        "points": dict((n, [round(p[0], 2), round(p[1], 2)])
                       for n, p in sorted(cc.pts.items())),
        "coords": cc.measured_coords,
        # (v6.16 gaps r3) a sketch plane's dots in tick indices (no value)
        "sketch": getattr(cc, "sketch_measured", None),
        "axes": dict((A.aid, {"px_of_index": [round(A.fit[0], 3),
                                               round(A.fit[1], 3)],
                              "zero_index": float(A.zero) if A.broken and A.zero is not None else A.zero,
                              "step": None if A.step is None else
                              _fmt_q(A.step)})
                     for A in getattr(cc, "axes", {}).values()
                     if getattr(A, "fit", None)),
        "label_boxes": dict((e.ref, {"for": cc._owner(e), "text": e.text,
                                     "box": [round(v, 2) for v in cc.box(e)],
                                     "from": "ink" if e.ref in boxes else
                                     "estimate"})
                            for e in dr.els if e.tag == "text" and e.hook),
        "elements_of": dict((k, sorted(v, key=lambda r: int(r[1:])))
                            for k, v in sorted(cc.elements_of.items())),
        "display": disp.source if disp else None,
    }
    rep["ocr"] = ocr_res
    rep["display_ink"] = ink_res
    rep["infrastructure"] = infra
    rep["_map_entities"] = mapped
    return rep


def _frame_only_contract(pub):
    """A positive PUBLIC declaration of an empty plotting canvas.

    This is deliberately narrower than arbitrary set/region semantics:
    both axes and their plane, no plotted entity, no non-frame drawn fact.
    Question givens/targets may name points or sets without drawing them.
    """
    axes = {a.get("axis") for a in pub.axes}
    plane = pub.frame.get("plane")
    if (len(axes) != 2 or None in axes or pub.kind(plane) != "plane"
            or any(pub.kind(a) != "axis" for a in axes)
            or pub.listed != axes | {plane}):
        return False
    for fid in pub.draws:
        f = pub.facts.get(fid) or {}
        args = f.get("args") or []
        if not ((f.get("rel") == "name" and len(args) == 1 and args[0] in axes)
                or (f.get("rel") == "grid" and args == [plane])):
            return False
    return not pub.fig.get("graph") and not pub.fig.get("data") and not pub.fig.get("loci") and not any(a.get("break_before") for a in pub.axes)


def _blank_canvas_check(raw, cc, pub, F):
    """Measure that a declared blank canvas contains ONLY frame ink.

    No object-map label, answer, private position or corpus row is used.
    The whole XML is walked, including unmapped and out-of-dialect nodes.
    Only the closed frame primitives are admitted, with public labels and
    axis indices and measured geometry. Thus a dot, curve, label, segment
    or filled region is forbidden anywhere, whether or not it happens to
    coincide with an answer. Nonblank/unsupported figures return False so
    SET_NOT_DRAWN is OMITTED from their report, never defaulted to PASS.
    """
    if not _frame_only_contract(pub):
        return False
    errors, reviews = [], []
    def bad(reason):
        errors.append(str(reason))
    try:
        root = ET.fromstring(raw)
    except ET.ParseError:
        bad("the complete SVG XML cannot be read")
        root = None
    # An invalid dialect cannot establish a positive frame-only proof;
    # notably the ordinary parser skips illegal top-level/nested content.
    if not cc.dr.ok:
        bad("the complete SVG violates the closed coordinate dialect")
    # A frame hook is not proof of frame geometry. Existing independent
    # axis measurements establish that a number actually belongs to its
    # tick, a name is at its axis tip, and lines are the public frame.
    # No point/set/answer verdict is used as evidence for this contract.
    frame_checks = {"AXIS_LINE_MAPPED", "AXIS_ARROW_DIRECTION",
                    "AX_TICKS_AT_VALUES", "GRID_LINES_AT_STEPS",
                    "ORIGIN_AT_ZERO", "ORIGIN_LABEL_IF_ANY",
                    "AX_SCALE_CONSISTENT", "SCALE_PER_AXIS_MEASURED",
                    "AX_NUMBERS_PARTIAL_AS_DECLARED", "AX_NUMBERS_NEVER_DROPPED",
                    "AX_MINUS_U2212", "OCR_AXIS_NUMBERS", "OCR_AXIS_NAMES"}
    frame_faults = [f["code"] for f in F.items if f["check"] in frame_checks
                    and f["level"] == FAIL]
    reviews = [f["code"] for f in F.items if f["check"] in frame_checks
               and f["level"] == REVIEW]
    if frame_faults:
        bad("frame primitive identity is not established by its measured geometry: " +
            ", ".join(sorted(set(frame_faults))))
    D = load_dialect()
    num = re.compile(D["number"])
    frame_hooks = {"data-grid", "data-axis", "data-arrow", "data-tick",
                   "data-num", "data-axname"}
    axes = {a.letter: a for a in getattr(cc, "axes", {}).values()}
    if len(axes) != 2 or any(not getattr(a, "fit", None) or
                             getattr(a, "line", None) is None for a in axes.values()):
        F.fail("CHK_BLANK_CANVAS_INK", "SET_NOT_DRAWN",
               "public blank plotting canvas cannot be verified: its two frame axes cannot be measured")
        return True
    counts = {}
    if root is not None:
        for layer in root:
            if layer.tag != SVG_NS + "g" or set(layer.attrib) != {"data-layer"}:
                bad("non-frame top-level element <%s>" % layer.tag.replace(SVG_NS, ""))
                continue
            lname = layer.get("data-layer")
            for node in layer:
                ref = node.get("id", "unmapped")
                if len(node):
                    bad("%s: nested ink is not a frame primitive" % ref)
                    continue
                e = El(ref, node.tag.replace(SVG_NS, ""), dict(node.attrib),
                       node.text or "", lname)
                hooks = [h for h in D["hooks"] if h in e.a]
                if len(hooks) != 1 or hooks[0] not in frame_hooks:
                    bad("%s: non-frame mathematical ink <%s>" % (ref, e.tag))
                    continue
                before = len(errors)
                _check_el(e, D, num, bad)
                if len(errors) != before or not e.pts:
                    continue
                key = (e.hook, e.hv)
                counts[key] = counts.get(key, 0) + 1
                if e.hook != "data-grid" and counts[key] > 1:
                    bad("%s: extra copy of frame primitive %s" % (ref, key))
                if e.hv == "origin":
                    if e.hook != "data-num" or e.text != "0" or not any(
                            any(i == getattr(a, "zero", None) for i, v in a.labels)
                            for a in axes.values()):
                        bad("%s: undeclared origin label" % ref)
                    continue
                bits = e.hv.split(" ")
                A = axes.get(bits[0])
                if A is None or not getattr(A, "fit", None):
                    bad("%s: primitive does not belong to a measured frame axis" % ref)
                    continue
                if e.hook == "data-axname":
                    if e.text != A.letter:
                        bad("%s: extra mathematical label masquerades as axis name" % ref)
                elif e.hook == "data-num":
                    i = int(bits[1])
                    wanted = dict(A.labels)
                    if i not in wanted or e.text != num_display(wanted[i]):
                        bad("%s: label is not the public axis number" % ref)
                elif e.hook in ("data-tick", "data-grid"):
                    i = int(bits[1])
                    if not 0 <= i <= A.n:
                        bad("%s: index outside public frame" % ref)
                        continue
                    along = 0 if A.horizontal else 1
                    across = 1 - along
                    if any(abs(p[along] - cc.px(A, i)) > FIT_TOL_PX for p in e.pts):
                        bad("%s: line is not at its declared frame index" % ref)
                    if e.hook == "data-tick":
                        if pub.sketch is not None or any(abs(p[across] - A.pos) > 3.5
                                                       for p in e.pts):
                            bad("%s: stroke extends beyond a frame tick" % ref)
                    else:
                        O_ = cc.ay if A is cc.ax else cc.ax
                        lo, hi = sorted([cc.px(O_, 0), cc.px(O_, O_.n)])
                        if not pub.frame.get("grid") or any(not lo - FIT_TOL_PX <= p[across]
                                                              <= hi + FIT_TOL_PX for p in e.pts):
                            bad("%s: grid-like ink outside the declared grid" % ref)
                elif e.hook == "data-arrow":
                    # A filled solution region cannot be disguised as an
                    # axis arrow: it is a small triangle at the axis end.
                    span = [max(p[k] for p in e.pts)-min(p[k] for p in e.pts)
                            for k in (0, 1)]
                    tip = getattr(A, "tip", None)
                    if max(span) > 14 or tip is None or not any(_d(p, tip) < 0.1 for p in e.pts):
                        bad("%s: filled ink is not a small axis arrow" % ref)
    if errors:
        F.fail("CHK_BLANK_CANVAS_INK", "SET_NOT_DRAWN",
               "public blank plotting canvas has non-frame/unverifiable ink: " +
               "; ".join(errors[:8]))
    elif reviews:
        F.review("CHK_BLANK_FRAME_UNVERIFIED", "SET_NOT_DRAWN",
                 "frame-only proof is incomplete: " + ", ".join(sorted(set(reviews))))
    return True


def dependencies(eid, pub):
    k = pub.kind(eid)
    if k in ("segment", "line", "ray"):
        return set(pub.points_of(eid))
    if k == "polygon":
        vs = pub.points_of(eid)
        return set(vs) | set("seg:" + "".join(sorted([vs[i], vs[(i + 1) %
                                                               len(vs)]]))
                             for i in range(len(vs)))
    if k == "tick":
        return {(pub.ents.get(eid) or {}).get("axis")}
    if k == "origin":
        # (v6.16 gaps, G2) the axes cross there; its '0' is the plane's
        return {a["axis"] for a in pub.axes} | {"plane"}
    if (pub.facts.get(eid) or {}).get("rel") == "guide":
        return set(pub.facts[eid]["args"])
    return set()


def unnamed_place_at(public_spec, figure_id, xy):
    """(v6.16 gaps r2, hook for the acceptance runner: corpus objects
    'coord:(x,y)' of an unnamed listed place, G7-T08 b q8 / c q14) the id of
    the unnamed vertex entity ("vtx:<tag>:<n>") the figure's question places
    at the public coordinates xy, or None. Public data only."""
    pub = Pub(public_spec, figure_id)
    vals = pub.value_coords()
    ax = [a.get("axis") for a in pub.axes][:2]
    want = tuple(_q(v) for v in xy)
    hit = sorted(e for e, x in pub.ents.items() if x.get("kind") == "vertex"
                 and len(ax) == 2 and tuple(vals.get((e, a)) for a in ax) ==
                 want)
    return hit[0] if len(hit) == 1 else None


def unnamed_vertex_places(public_spec, figure_id, of=None):
    """(v6.16 gaps r2, hook for the acceptance runner: GMC6_ANSWER_DRAWN on
    poly:<tag> (c q14) or on a listed place (b q8) = a dot at a declared
    place / a side between two consecutive places) {vtx id: (x, y)} of the
    unnamed vertices the figure's question places publicly -- all of them,
    or those of tag `of` in vertex order (an OrderedDict). Public data only;
    the checker fails such a dot (PT_NOT_DRAWN_ANY_FORM) and, for a polygon
    to plot, such a side (SEG_NOT_DRAWN)."""
    import collections
    pub = Pub(public_spec, figure_id)
    vals = pub.value_coords()
    ax = [a.get("axis") for a in pub.axes][:2]
    rows = sorted((x.get("of"), x.get("n"), e) for e, x in pub.ents.items()
                  if x.get("kind") == "vertex" and
                  (of is None or x.get("of") == of))
    out = collections.OrderedDict()
    for _t, _n, e in rows:
        xy = tuple(vals.get((e, a)) for a in ax)
        if len(xy) == 2 and None not in xy:
            out[e] = tuple(float(v) for v in xy)
    return out


def _concerns(f, eid, deps):
    o = f["object"]
    if o is None:
        return True
    want = set(deps) | {eid}
    if isinstance(o, (list, tuple)):
        return bool(want & set(o))
    return o in want


def _objects(cc, pub, F):
    objs = set(pub.listed) | set(k for k in cc.elements_of if k)
    any_fail = any(f["level"] == FAIL for f in F.items)
    out = {}
    for eid in sorted(o for o in objs if o):
        deps = dependencies(eid, pub)
        mine = [f for f in F.items if _concerns(f, eid, deps) and
                f["level"] in (FAIL, REVIEW)]
        st = worst([f["level"] for f in mine] + ([FAIL] if any_fail else []))
        kind = pub.kind(eid) or ("guide" if eid in pub.facts else "point")
        out[eid] = {"kind": kind, "status": st,
                    "findings": [f["code"] for f in mine],
                    "depends_on": sorted(deps),
                    "blocked_by": sorted(set(
                        f["object"] for f in mine
                        if isinstance(f["object"], str) and
                        f["object"] != eid))}
    return out


def object_report(rep, eid, construction=False):
    """one scenario object's verdict (figure-wide checks + its kind's)."""
    o = rep["objects"].get(eid)
    if o is None:
        return {"status": REVIEW, "reason": "object %s is not in the figure's "
                "check report" % eid}
    deps = o.get("depends_on") or []
    names = FIGURE_CHECKS + OBJECT_CHECKS.get(o["kind"], [])
    if "SET_NOT_DRAWN" in rep["checks"]:
        names = names + ["SET_NOT_DRAWN"]
    names = names + [c for c in CD.CHECKS if c in rep["checks"]]
    if "AX_BROKEN_START_DECLARED" in rep["checks"]: names += ["AX_BROKEN_START_DECLARED"]
    checks = dict((c, NA if rep["checks"].get(c, NA) == NA else PASS)
                  for c in names)
    for f in rep["findings"]:
        if _concerns(f, eid, deps) and f["level"] in (FAIL, REVIEW):
            checks[f["check"]] = worst([checks.get(f["check"], PASS),
                                        f["level"]])
    return {"status": o["status"], "checks": checks,
            "depends_on": list(deps),
            "blocked_by": list(o.get("blocked_by") or []),
            "infrastructure": list(rep.get("infrastructure") or []),
            "findings": [f for f in rep["findings"]
                         if _concerns(f, eid, deps)]}


def private_position_check(rep, expected):
    """HARNESS side (it holds the private model): the measured coordinates
    of the drawn points against their true values {name: (x, y)} ->
    [problem]. The checker itself never sees these values."""
    out = []
    for n, (x, y) in sorted(expected.items()):
        m = (rep.get("measured") or {}).get("coords", {}).get(n)
        if m is None:
            out.append("%s is not drawn" % n)
            continue
        got = [_q(v) if v is not None else None for v in m["value"]]
        if got != [_q(x), _q(y)]:
            out.append("%s is drawn at (%s, %s), its value is (%s, %s)" % (
                n, m["value"][0], m["value"][1], _fmt_q(_q(x)),
                _fmt_q(_q(y))))
    return out
