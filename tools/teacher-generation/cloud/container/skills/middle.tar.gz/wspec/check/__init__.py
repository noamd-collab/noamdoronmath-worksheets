# -*- coding: utf-8 -*-
"""wspec.check -- the INDEPENDENT checker of a finished figure (brief
section 3). It reads the SVG, the renderer's object map and the PUBLIC spec,
measures the drawing with named tolerances (tol.py), rasterises the final
display with MuPDF and reads every label back with macOS Vision OCR.

It imports nothing from wspec.render (and never reads the renderer's code);
from the rest of wspec it uses only wspec.canon (numbers, units, ids) to
read the public spec, and the dialect DATA file svg_dialect.json.

    report = check_figure(svg, object_map, public_spec, figure_id)
    report["status"]            PASS | REVIEW | FAIL
    report["findings"]          [{level, code, check, object, detail}]
    report["checks"]            {acceptance check name: PASS|REVIEW|FAIL|NA}
    report["objects"][eid]      {status, checks}
    object_report(report, eid)  the verdict of one acceptance scenario's object
"""
import re

from . import tol as T
from .report import (Findings, CheckerInputError, worst, FAIL, REVIEW, NOTE,
                     PASS, NA)
from .dialect import DialectReader
from .spec import FigureSpec, number_tokens
from .figure import FigureCheck
from . import objmap as OM
from . import spec as SP
from . import raster as R
from . import ocr as O
from . import inkcmp as IC
from .highlight import check_highlight as _check_highlight_geo


def check_highlight(base_svg, hl_svg, report, object_id):
    """the highlight check of the figure's family (v6.12: a coordinate
    plane's report carries family 'coordinate_plane')."""
    # (v6.16 integrate) a graph report (wspec.hooks_graph) / a pie report
    if _is_graph_report(report):
        from .. import hooks_graph as _hg
        return _hg.check_highlight(base_svg, hl_svg, report, object_id)
    if report.get("family") == "pie_chart":
        from .pie_hl import check_highlight as _hl_pie
        return _hl_pie(base_svg, hl_svg, report, object_id)
    if report.get("family") == "number_line":        # (v6.12, family B)
        from .nline_hl import check_highlight as _hl_nline
        return _hl_nline(base_svg, hl_svg, report, object_id)
    if report.get("family") == "coordinate_plane":
        from .coord_highlight import check_highlight as _hl_coord
        return _hl_coord(base_svg, hl_svg, report, object_id)
    return _check_highlight_geo(base_svg, hl_svg, report, object_id)

__all__ = ["check_figure", "object_report", "check_highlight",
           "CheckerInputError",
           "CHECKER_VERSION", "FIGURE_CHECKS"]
CHECKER_VERSION = T.CHECKER_VERSION

# the acceptance checks this module decides (the rest belong to the
# renderer / baseline / highlight harness and are reported NA here)
FIGURE_CHECKS = [
    "DIALECT_CLOSED", "OBJMAP_TOTAL_NO_UNMAPPED_INK", "NO_ANSWER_ANYWHERE_SVG",
    "TEXT_BOX_IN_CANVAS", "TEXT_NOT_COVERING_MARKS", "OCR_POINT_NAMES",
    "OCR_PT_LABEL_AT_POINT", "OCR_CAPTION_IF_ANY", "TARGET_VALUE_NOT_SHOWN",
    "HIGHLIGHT_ON_MEASURED_GEOMETRY", "DISPLAY_INK_MATCHES_FIGURE"]
OBJECT_CHECKS = {
    "point": ["PT_POSITION", "PT_LABEL_OWNED"],
    "segment": ["SEG_ENDS_MATCH", "SEG_PIECE_OF_LONGER_MAPPED",
                "SEG_CAPTION_OWNED_IF_ANY", "SEG_TICKS_IF_ANY"],
    "line": ["LINE_THROUGH_POINTS", "LINE_EXTENDS_PAST_POINTS", "LINE_LABEL_OWNED"],
    "ray": ["RAY_FROM_THROUGH", "RAY_DIRECTION", "RAY_NOT_SEGMENT_OR_LINE"],
    "angle": ["ANG_VERTEX_MATCH", "ANG_ARMS_MATCH", "ANG_ARC_GEOMETRY_IF_ANY",
              "ANG_ARC_CHORDS", "ANG_CAPTION_OWNED_IF_ANY",
              "RIGHT_MARK_IF_ANY"],
    "polygon": ["POLY_VERTICES_MATCH", "POLY_SIDES_MAPPED",
                "POLY_SHAPE_MEASURED", "PARALLEL_ARROWS_IF_ANY"],
    "construction": ["CONS_DECLARED_GIVEN_SHOWN_TODO", "CONS_INPUTS_SHOWN",
                     "CONS_NO_EMPTY_OR_CIRCULAR_GIVEN",
                     "CONS_RESULT_NOT_DRAWN_ANY_FORM",
                     "CONS_KIND_AND_DIRECTION"],
}
ALL_CHECKS = FIGURE_CHECKS + sorted(set(c for v in OBJECT_CHECKS.values()
                                        for c in v))


def _graph_guard(guard):
    """(v6.16 integrate) the house answer guard (G79 hands the answer
    VALUES of the level) as the graph checker's guard: bare values the
    figure's texts may not state beyond its given labels"""
    if not guard:
        return None
    if isinstance(guard, dict):
        return guard
    vals = [str(g.get("answer") if isinstance(g, dict) else g).strip()
            for g in guard]
    return {"points": [], "curves": [], "texts": [], "equations": [],
            "bare": [v for v in vals if v not in ("", "None")]}


def _is_graph_report(rep):
    """(v6.16 integrate) a report of the graph checker (hooks_graph.check)"""
    return isinstance(rep, dict) and (
        rep.get("api") == "v616-graph/1" or
        ((rep.get("object_map") or {}).get("dialect") ==
         "wspec-graph-svg/1"))


def _figure_of(public_spec, figure_id):
    for g in (public_spec or {}).get("figures") or [] if isinstance(
            public_spec, dict) else []:
        if isinstance(g, dict) and g.get("id") == figure_id:
            return g
    return None


def _answer_guard(guard, dr, om, F):
    """Values the harness says must not be exposed (it holds the answer
    store; the checker is handed the values only). A guarded value may be
    printed only as the checked caption of a drawn given with that value."""
    vals = set()
    for g in guard or []:
        v = g.get("answer") if isinstance(g, dict) else g
        if v not in (None, ""):
            vals.add(str(v).strip())
    if not vals:
        return
    # (v6.17, V3) an IRRATIONAL answer is exposed by its surd in any
    # spelling ('√88' for 2√22) and by any decimal rounding of it ('9.4',
    # '9.38'): read the value, not the digits
    irr = []
    for v in vals:
        try:
            if SP.C.is_irrational(v.replace("$", "")):
                irr.append((v, SP.C.canon_number(v.replace("$", "")),
                            SP.C.exact_float(v.replace("$", ""))))
        except Exception:                               # noqa: BLE001
            pass
    for el in dr.elements:
        if el.tag == "text":
            hit = set(number_tokens(el.text)) & vals
            for v, cv, fv in irr:
                for m in re.finditer(u"(\\d*)\\s*√\\s*(\\d+)",
                                     el.text or ""):
                    try:
                        if SP.C.canon_number(m.group(0).replace(" ", "")) \
                                == cv:
                            hit.add(v)
                    except Exception:                   # noqa: BLE001
                        pass
                for t in re.findall(r"\d+\.\d+", el.text or ""):
                    dec = len(t.split(".")[1])
                    if abs(float(t) - fv) <= 0.5 * 10 ** -dec + 1e-9:
                        hit.add(v)
            if hit and el.a.get("data-for", "").split(" ")[0] not in (
                    "ang", "seg", "poly"):
                F.fail("CHK_ANSWER_EXPOSED", "NO_ANSWER_ANYWHERE_SVG", "%s: "
                       "text %r prints the answer %s" % (el.ref, el.text,
                                                        sorted(hit)))
    # attribute values and the map are grammar-restricted (numbers, point
    # names, closed lists, positional ids e<k>/d<k>, public spec ids): the
    # dialect / map checks refuse anything else (VD3-05).


def check_figure(svg, object_map, public_spec, figure_id, ocr=True,
                 display_image=None, display_scale=None,
                 display_origin=(0.0, 0.0), answer_guard=None,
                 png_out=None, keep_ocr_dir=None):
    """Check one finished figure. svg: bytes / str / path. object_map: dict
    or None (then the map checks are NA). display_image: an optional raster
    of the FINAL page / figure to read instead of the checker's own MuPDF
    render (display_scale px per SVG unit, display_origin = where the
    figure's (0, 0) is in the image)."""
    # (v6.16 integrate) a GRAPH figure: the graph family's independent
    # checker (wspec/graph/check.py through wspec.hooks_graph.check); a PIE
    # CHART: check/pie.py. Both before the coordinate plane (a graph's frame
    # is a coordinate_plane frame). The page's own raster (display_image)
    # is G79's; these checkers raster the SVG themselves.
    _g = _figure_of(public_spec, figure_id)
    if _g is not None and isinstance(_g.get("graph"), dict):
        from .. import hooks_graph as _hg
        rep = _hg.check(svg, object_map, public_spec, figure_id, ocr=ocr,
                        answer_guard=_graph_guard(answer_guard),
                        keep_ocr_dir=keep_ocr_dir)
        rep.setdefault("family", "graph")
        return rep
    if _g is not None and (_g.get("frame") or {}).get("family") == \
            "pie_chart":
        from .pie import check_pie as _check_pie
        return _check_pie(svg, object_map, public_spec, figure_id, ocr=ocr,
                          answer_guard=answer_guard, png_out=png_out,
                          keep_ocr_dir=keep_ocr_dir)
    # (v6.12, family B) a number-line figure: check/nline.py
    from . import nline as _nline
    if _nline.is_number_line(public_spec, figure_id):
        return _nline.check_number_line(
            svg, object_map, public_spec, figure_id, ocr=ocr,
            display_image=display_image, display_scale=display_scale,
            display_origin=display_origin, answer_guard=answer_guard,
            png_out=png_out, keep_ocr_dir=keep_ocr_dir)
    # (v6.12, family A) a coordinate-plane figure: check/coord.py
    from . import coord as _coord
    if _coord.is_coord(public_spec, figure_id):
        return _coord.check_coord(
            svg, object_map, public_spec, figure_id, ocr=ocr,
            display_image=display_image, display_scale=display_scale,
            display_origin=display_origin, answer_guard=answer_guard,
            png_out=png_out, keep_ocr_dir=keep_ocr_dir)
    F = Findings()
    fs = FigureSpec(public_spec, figure_id)          # refuses a private model
    if isinstance(svg, str) and not svg.lstrip().startswith("<"):
        with open(svg, "rb") as fh:
            svg = fh.read()
    raw = svg if isinstance(svg, bytes) else svg.encode("utf-8")
    dr = DialectReader().read(raw)
    rep = {"checker_version": CHECKER_VERSION, "figure": figure_id,
           "figure_accuracy": fs.fig.get("figure_accuracy")}
    disp, full_boxes = None, {}
    if dr.ok:
        if R.available():
            try:
                disp = R.Display(raw.decode("utf-8"), dr.W, dr.H,
                                 image=display_image,
                                 image_scale=display_scale,
                                 image_origin=display_origin)
                texts = [e.ref for e in dr.elements if e.tag == "text"]
                full_boxes = disp.text_boxes(texts)
                for ref, b in full_boxes.items():
                    if b is None:
                        F.fail("CHK_LABEL_NO_INK", "OCR_POINT_NAMES",
                               "%s: the label draws no ink at all" % ref)
                full_boxes = dict((k, v) for k, v in full_boxes.items() if v)
                if png_out:
                    disp.save_png(png_out)
            except Exception as e:                    # pragma: no cover
                F.review("CHK_RASTER_FAILED", "OCR_POINT_NAMES",
                         "the final display could not be rasterised: %s" % e)
                disp = None
        else:
            F.review("CHK_RASTER_UNAVAILABLE", "OCR_POINT_NAMES",
                     "PyMuPDF is not installed: the final display is not seen")
    fc = FigureCheck(dr, fs, F, full_boxes=full_boxes,
                     ink=disp.ink if disp is not None else None)
    fc.run()
    mapped = None
    if object_map is not None and dr.ok:
        mapped = OM.check_map(object_map, fc, fs, F)
        # a map object that is not a figure entity (e.g. ang:AMB drawn by
        # its arms only) is still measured on the drawing alone: check_map
        # compared its parts with measured_elements (CHK_MAP_MISMATCH), so
        # the measured set -- not the map's -- joins the report and a
        # scenario naming it is judged, not sent to REVIEW (fix_engine M1)
        for eid in sorted(mapped or {}):
            if eid not in fc.elements_of and fs.points_of(eid) and \
                    all(n in fc.pts for n in fs.points_of(eid)):
                fc.elements_of[eid] = fc.measured_elements(eid)
    elif object_map is None:
        F.note("CHK_MAP_ABSENT", "OBJMAP_TOTAL_NO_UNMAPPED_INK",
               "no object map given: map checks not run")
    after = set(getattr(fc, "after_construction", []) or [])
    for eid in getattr(fc, "not_drawn", []) or []:
        if eid in after:
            # (v6.10 fix r1, L2) its missing side / arm is the student's
            # construction (a to_construct of the figure): drawn by the
            # student, never by the figure
            F.note("CHK_OBJECT_AFTER_CONSTRUCTION",
                   "HIGHLIGHT_ON_MEASURED_GEOMETRY",
                   "object %s: a side / arm is a segment the student draws "
                   "(to_construct): highlightable after the construction"
                   % eid)
            continue
        F.review("CHK_OBJECT_NOT_DRAWN", "HIGHLIGHT_ON_MEASURED_GEOMETRY",
                 "object %s: its points are drawn but not all of its sides / "
                 "arms -- the figure does not show it, so it cannot be "
                 "highlighted (REVIEW; the figure is not changed)" % eid, eid)
    _answer_guard(answer_guard, dr, object_map, F)
    ink_res = None
    if dr.ok and disp is not None and display_image is not None:
        ink_res = _display_ink(disp, raw.decode("utf-8"), dr, fc, full_boxes,
                               F)
    # ---- OCR of the final display
    ocr_res = {}
    infra = []
    if dr.ok and disp is not None and ocr:
        if not O.helper_ok():
            F.review("CHK_OCR_UNAVAILABLE", "OCR_POINT_NAMES",
                     "OCR_UNAVAILABLE: the OCR helper %s is not built (swiftc "
                     "-O -o tools/wspec_ocr tools/wspec_ocr.swift)" % O.HELPER)
            infra.append("OCR_UNAVAILABLE")
        else:
            jobs = []
            for lab in fc.labels:
                b = full_boxes.get(lab.ref)
                if b is None:
                    continue
                vis = (max(0.0, b[0]), max(0.0, b[1]), min(dr.W, b[2]),
                       min(dr.H, b[3]))
                if vis[2] - vis[0] <= 0 or vis[3] - vis[1] <= 0:
                    vis = None
                jobs.append((lab.ref, lab.text, vis))
            try:
                ocr_res = O.read_labels(disp, jobs, workdir=keep_ocr_dir,
                                        keep=bool(keep_ocr_dir))
            except Exception as e:                    # noqa: BLE001
                # the OCR service crashed: an infrastructure reason, and
                # every label stays unconfirmed (REVIEW, never PASS)
                ocr_res = dict((ref, {"text": text, "reads": [],
                                      "status": "OCR_ERROR",
                                      "detail": "OCR_UNAVAILABLE: %s: %s" % (
                                          type(e).__name__, e)})
                               for ref, text, _b in jobs)
            for lab in fc.labels:
                r = ocr_res.get(lab.ref)
                if not r:
                    continue
                is_pt = " " not in lab.target
                chk = "OCR_POINT_NAMES" if is_pt else "OCR_CAPTION_IF_ANY"
                obj = lab.target if is_pt else fc.label_obj(lab)
                st = r["status"]
                if st == "OCR_ERROR":
                    F.review("CHK_OCR_UNAVAILABLE", chk, "%s: %r: %s" % (
                        lab.ref, lab.text, r["detail"]), obj)
                    if "OCR_UNAVAILABLE" not in infra:
                        infra.append("OCR_UNAVAILABLE")
                elif st == "MISSING":
                    F.fail("CHK_OCR_MISSING", chk, "%s: %r is not visible in "
                           "the final display (%s)" % (lab.ref, lab.text,
                                                       r["detail"]), obj)
                elif st == "UNREAD":
                    F.review("CHK_OCR_UNREAD", chk, "%s: %r: %s" % (
                        lab.ref, lab.text, r["detail"]), obj)
                elif st == "CONTRADICTS":
                    F.review("CHK_OCR_CONTRADICTS", chk, "%s: %s" % (
                        lab.ref, r["detail"]), obj)
                elif st == "NOT_OCR":
                    F.note("CHK_OCR_NOT_READ", chk, "%s: %s" % (
                        lab.ref, r["detail"]), obj)
                elif any(ch in O.HEB for ch in lab.text):
                    F.note("CHK_OCR_UNIT_NOT_READ", chk, "%s: the number of %r "
                           "is confirmed; its Hebrew unit is not read by OCR"
                           % (lab.ref, lab.text), obj)
    elif not ocr:
        F.note("CHK_OCR_SKIPPED", "OCR_POINT_NAMES", "OCR not requested")
    # ---- verdicts
    rep["status"] = worst(f["level"] for f in F.items)
    rep["findings"] = F.items
    ran_map = mapped is not None
    ran_ocr = bool(ocr_res)
    checks = {}
    for c in ALL_CHECKS:
        fl = [f["level"] for f in F.items if f["check"] == c and
              f["level"] in (FAIL, REVIEW)]
        if fl:
            checks[c] = worst(fl)
        elif c in ("OBJMAP_TOTAL_NO_UNMAPPED_INK",
                   "HIGHLIGHT_ON_MEASURED_GEOMETRY") and not ran_map:
            checks[c] = NA
        elif c.startswith("OCR_") and not ran_ocr:
            checks[c] = NA
        elif c == "DISPLAY_INK_MATCHES_FIGURE" and ink_res is None:
            checks[c] = NA
        else:
            checks[c] = PASS
    rep["checks"] = checks
    rep["objects"] = _objects(fc, fs, F)
    rep["measured"] = {
        "canvas": [dr.W, dr.H],
        "points": dict((n, [round(p[0], 2), round(p[1], 2)])
                       for n, p in sorted(fc.pts.items())),
        "label_boxes": dict((l.ref, {"for": l.target, "text": l.text,
                                     "box": [round(v, 2) for v in l.box],
                                     "from": l.box_from})
                            for l in fc.labels),
        "elements_of": dict((k, sorted(v, key=lambda r: int(r[1:])))
                            for k, v in sorted(fc.elements_of.items())
                            if k is not None),
        "display": disp.source if disp else None,
    }
    rep["ocr"] = ocr_res
    rep["display_ink"] = ink_res
    rep["infrastructure"] = infra
    rep["_map_entities"] = mapped
    return rep


def _display_ink(disp, svg, dr, fc, boxes, F):
    """Codex F2: the supplied display must carry the approved figure's
    GEOMETRIC ink -- every element's ink present (not dropped, cut, shifted
    or rescaled) and no foreign ink in the canvas outside the labels."""
    def render(one, x0, y0, w, h, s):
        return R.gray_pixmap(R._with_viewbox(one, x0, y0, w, h), s)
    try:
        res = IC.compare(disp, svg, dr.W, dr.H, list(boxes.values()), render)
    except Exception as e:                            # noqa: BLE001
        F.review("CHK_DISPLAY_INK_UNREAD", "DISPLAY_INK_MATCHES_FIGURE",
                 "the display's ink could not be compared: %s" % e)
        return None
    s2 = res["scale"] ** 2
    owners = {}
    for eid, refs in fc.elements_of.items():
        for ref in refs or ():
            if eid:
                owners.setdefault(ref, set()).add(eid)
    for ref, (miss, ink) in sorted(res["missing"].items()):
        if ink == 0 or miss < T.INK_MIN_SVG_PX2 * s2:
            continue
        frac = miss / float(ink)
        if frac <= T.INK_MISSING_REVIEW:
            continue
        own = sorted(owners.get(ref, ()))
        lvl = F.fail if frac > T.INK_MISSING_FAIL else F.review
        lvl("CHK_DISPLAY_INK_MISSING", "DISPLAY_INK_MATCHES_FIGURE",
            "%s (%s): %.0f%% of its ink is not in the final display (a "
            "line / mark dropped, cut, moved or rescaled)" % (
                ref, ", ".join(own) or "no object", 100 * frac),
            own if len(own) > 1 else (own[0] if own else None))
    for ref, gap in sorted((res.get("gaps") or {}).items()):
        if gap >= T.INK_GAP_FAIL_SVG_PX:
            own = sorted(owners.get(ref, ()))
            F.fail("CHK_DISPLAY_INK_GAP", "DISPLAY_INK_MATCHES_FIGURE",
                   "%s (%s): the final display cuts a %.1f px gap into this "
                   "stroke (>= %s px): a line is interrupted" % (
                       ref, ", ".join(own) or "no object", gap,
                       T.INK_GAP_FAIL_SVG_PX),
                   own if len(own) > 1 else (own[0] if own else None))
    if res["extra_px"] >= T.INK_MIN_SVG_PX2 * s2:
        lvl = F.fail if res["extra_px"] >= T.INK_EXTRA_FAIL_SVG_PX2 * s2 \
            else F.review
        lvl("CHK_DISPLAY_INK_EXTRA", "DISPLAY_INK_MATCHES_FIGURE",
            "the final display has %.1f px^2 of ink the approved figure does "
            "not draw, at %s (an element added, a copy shifted, page ink "
            "over the figure)" % (res["extra_px"] / s2, res["extra_box"]))
    return {"elements": len(res["missing"]),
            "missing": dict((k, [m, i]) for k, (m, i) in
                            res["missing"].items() if m),
            "extra_px": res["extra_px"], "extra_box": res["extra_box"],
            "r_px": res["r_px"]}


def _obj_kind(eid, fs):
    k = fs.kind(eid)
    if k:
        return k
    pre = eid.split(":")[0]
    return {"seg": "segment", "ang": "angle", "poly": "polygon",
            "line": "line", "ray": "ray"}.get(pre, "point")


def _concerns(f, eid, deps=None):
    """the finding is about eid, about one of its dependencies (deps), or
    about the whole figure (object None)."""
    o = f["object"]
    if o is None:
        return True
    want = set(deps or ()) | {eid}
    if isinstance(o, (list, tuple)):
        return bool(want & set(o))
    return o in want


def dependencies(eid, fs):
    """v6.9 (Codex F1): what an object needs to be IDENTIFIED on the page --
    its points (dot + name label: point findings carry the point's name),
    and the components it is read by: an angle's two arms, a polygon's
    sides; its own marks and caption report under its own id. A REVIEW /
    FAIL on any of them blocks the object's PASS (a C read as A breaks
    ang:ACB, seg:AC and poly:ABCD); a finding on an unrelated point / piece
    stays local."""
    deps = set()
    kind = _obj_kind(eid, fs)
    pts = [p for p in (fs.points_of(eid) or []) if p]
    if kind == "point":
        return deps
    deps |= set(pts)
    try:
        if kind == "angle" and len(pts) == 3:
            a, v, b = pts
            deps |= {SP.seg_id(v, a), SP.seg_id(v, b), SP.ray_id(v, a),
                     SP.ray_id(v, b)}
        elif kind == "polygon" and len(pts) >= 3:
            n = len(pts)
            deps |= set(SP.seg_id(pts[i], pts[(i + 1) % n])
                        for i in range(n))
    except Exception:                                 # noqa: BLE001
        pass
    deps.discard(eid)
    return deps


def _objects(fc, fs, F):
    objs = set(fs.entities) | set(k for k in fc.elements_of if k) | \
        set(getattr(fc, "not_drawn", []) or [])
    for t in fs.targets:
        if (t.get("rel") or "").startswith("construct"):
            objs.add((t.get("args") or [None])[0])
    any_fail = any(f["level"] == FAIL for f in F.items)
    out = {}
    for eid in sorted(o for o in objs if o):
        deps = dependencies(eid, fs)
        mine = [f for f in F.items if _concerns(f, eid, deps) and
                f["level"] in (FAIL, REVIEW)]
        st = worst([f["level"] for f in mine] + ([FAIL] if any_fail else []))
        out[eid] = {"kind": _obj_kind(eid, fs), "status": st,
                    "findings": [f["code"] for f in mine],
                    "depends_on": sorted(deps),
                    "blocked_by": sorted(set(
                        f["object"] for f in mine
                        if isinstance(f["object"], str) and
                        f["object"] != eid))}
    return out


def object_report(rep, eid, construction=False):
    """The verdict of one scenario object: the figure-wide checks plus the
    object's own. A FAIL anywhere in the figure fails every object of it (a
    broken figure is not delivered)."""
    if _is_graph_report(rep):                        # (v6.16 integrate)
        from .. import hooks_graph as _hg
        return _hg.object_report(rep, eid)
    if rep.get("family") == "pie_chart":             # (v6.16 integrate)
        from .pie import object_report as _or_pie
        return _or_pie(rep, eid)
    if rep.get("family") == "number_line":           # (v6.12, family B)
        from . import nline as _nline
        return _nline.object_report(rep, eid)
    if rep.get("family") == "coordinate_plane":      # (v6.12, family A)
        from . import coord as _coord
        return _coord.object_report(rep, eid, construction)
    o = rep["objects"].get(eid)
    if o is None:
        return {"status": REVIEW, "reason": "object %s is not in the figure's "
                "check report" % eid}
    kind = "construction" if construction else o["kind"]
    deps = o.get("depends_on") or []
    names = FIGURE_CHECKS + OBJECT_CHECKS.get(kind, [])
    checks = dict((c, NA if rep["checks"].get(c, NA) == NA else PASS)
                  for c in names)
    for f in rep["findings"]:
        if _concerns(f, eid, deps) and f["level"] in (FAIL, REVIEW):
            # a dependency's finding counts under its own check name even
            # when that check is not one of this kind's (v6.9, Codex F1)
            checks[f["check"]] = worst([checks.get(f["check"], PASS),
                                        f["level"]])
    return {"status": o["status"], "checks": checks,
            "depends_on": list(deps),
            "blocked_by": list(o.get("blocked_by") or []),
            "infrastructure": list(rep.get("infrastructure") or []),
            "findings": [f for f in rep["findings"]
                         if _concerns(f, eid, deps)]}
