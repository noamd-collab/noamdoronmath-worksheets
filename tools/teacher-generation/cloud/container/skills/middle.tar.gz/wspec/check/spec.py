# -*- coding: utf-8 -*-
"""Reading the PUBLIC spec for one figure. The checker never takes the
private model / answer store: a spec carrying any of its keys, or a fact
with role 'answer' or a target with a value, is refused (CheckerInputError).
Only wspec.canon is used (number / unit / id canon), to read the spec."""
import re
import unicodedata

from .. import canon as C
from .report import CheckerInputError

PUBLIC_KEYS = {"entities", "facts", "figures", "public_hash", "questions",
               "sheet", "spec_version"}
PRIVATE_KEYS = {"answer_key", "answers", "didactic", "not_public", "releases",
                "target_values", "private", "answer_store"}
VALUE_RELS = {"angle_measure": "ang", "length": "seg", "area": "poly",
              "perimeter": "poly"}
PLANE_KINDS = {"point", "segment", "line", "ray", "angle", "polygon"}
# facts the checker measures (plane geometry of the pilot)
SUPPORTED_RELS = {"name", "angle_measure", "length", "area", "perimeter",
                  "on_segment", "midpoint", "rectangle", "square",
                  "parallelogram", "rhombus", "isosceles", "equilateral",
                  "perpendicular", "parallel", "equal_length", "equal_angle",
                  "congruent", "ratio",
                  # (v6.10) measured when drawn (figure.check_facts)
                  "linear", "greater", "not_parallel", "inside", "trapezoid",
                  "isosceles_trapezoid", "right_triangle", "acute_triangle",
                  # (v6.17-noam V1)
                  "obtuse_triangle"}


def refuse_private(spec):
    if not isinstance(spec, dict):
        raise CheckerInputError("the public spec must be a dict")
    bad = sorted(set(spec) & PRIVATE_KEYS)
    if bad:
        raise CheckerInputError("private model keys given to the checker: %s"
                                % ", ".join(bad))
    extra = sorted(set(spec) - PUBLIC_KEYS)
    if extra:
        raise CheckerInputError("not a public model (keys %s)" % extra)
    for f in spec.get("facts") or []:
        if f.get("role") == "answer":
            raise CheckerInputError("an answer fact %s in the input"
                                    % f.get("id"))
        if f.get("role") in ("target", "to_construct") and \
                f.get("value") not in (None, ""):
            raise CheckerInputError("target %s carries a value" % f.get("id"))


def nfc(s):
    return unicodedata.normalize("NFC", s)


class FigureSpec(object):
    """The public facts of one figure: its entities, the facts it draws, the
    items that use it and their targets / constructions."""

    def __init__(self, spec, figure_id):
        refuse_private(spec)
        self.spec = spec
        self.ents = dict((e["id"], e) for e in spec.get("entities") or [])
        self.facts = dict((f["id"], f) for f in spec.get("facts") or [])
        figs = [g for g in spec.get("figures") or [] if g["id"] == figure_id]
        if len(figs) != 1:
            raise CheckerInputError("figure %r: %d in the spec"
                                    % (figure_id, len(figs)))
        self.fig = figs[0]
        self.id = figure_id
        self.accurate = self.fig.get("figure_accuracy") == "accurate"
        self.entities = list(self.fig.get("entities") or [])
        self.draws = []
        for fid in self.fig.get("draws") or []:
            if fid not in self.facts:
                raise CheckerInputError("figure draws unknown fact %s" % fid)
            self.draws.append(self.facts[fid])
        # the items shown with this figure, their targets and constructions
        self.items = []
        for q in spec.get("questions") or []:
            for it in q.get("items") or []:
                if it.get("figure") == figure_id or \
                        (q.get("figure") == figure_id and not it.get("figure")):
                    self.items.append(it)
        self.targets = []
        for it in self.items:
            for t in it.get("targets") or []:
                self.targets.append(self.facts.get(t["id"], t))

    def kind(self, eid):
        e = self.ents.get(eid)
        if e:
            return e["kind"]
        if isinstance(eid, str) and ":" in eid:
            return {"seg": "segment", "ang": "angle", "poly": "polygon",
                    "line": "line", "ray": "ray"}.get(eid.split(":")[0])
        return None

    def points_of(self, eid):
        if eid not in self.ents and isinstance(eid, str) and ":" in eid and \
                self.kind(eid):
            from .dialect import split_names
            return split_names(eid.split(":", 1)[1]) or []
        e = self.ents.get(eid) or {}
        k = e.get("kind")
        if k == "point":
            return [e["name"]]
        if k == "segment":
            return list(e["ends"])
        if k == "line":
            return list(e["through"])
        if k == "ray":
            return [e["from"], e["through"]]
        if k == "angle":
            return [e["arms"][0], e["vertex"], e["arms"][1]]
        if k == "polygon":
            return list(e["vertices"])
        return []

    def name_of(self, eid):
        e = self.ents.get(eid) or {}
        return e.get("name")


# ------------------------------------------------------------ ids --------
def seg_id(a, b):
    return C.entity_id({"kind": "segment", "ends": [a, b]})


def line_id(a, b):
    return C.entity_id({"kind": "line", "through": [a, b]})


def ray_id(a, b):
    return C.entity_id({"kind": "ray", "from": a, "through": b})


def ang_id(a, v, b):
    return C.entity_id({"kind": "angle", "vertex": v, "arms": [a, b]})


def poly_id(vs):
    return C.entity_id({"kind": "polygon", "vertices": list(vs)})


# ------------------------------------------------------------ values -----
_UNIT_TAIL = re.compile(r"^(.*?)\s*(°|%|₪|ס״מ|סמ״ר|מ״מ|ממ״ר|מ״ר|מ׳|ס\"מ|"
                        r"סמ\"ר|מ\"מ|מ\"ר)$")


def parse_caption(text):
    """'35°' -> ('35', 'deg'); '12 ס״מ' -> ('12', 'cm'); '14' -> ('14', None);
    '3x + 4' -> ('3x+4', None). The number part is returned as written
    (spaces removed)."""
    t = nfc(text).strip()
    m = _UNIT_TAIL.match(t)
    unit = None
    if m:
        t = m.group(1).strip()
        try:
            unit = C.canon_unit(m.group(2))
        except Exception:
            unit = None
    return t.replace(" ", ""), unit


def same_value(fact, text):
    """Does the caption text print exactly this fact's value (and, if it shows
    a unit, the fact's unit)?"""
    num, unit = parse_caption(text)
    fu = fact.get("unit")
    try:
        fu = C.canon_unit(fu) if fu else None
    except Exception:
        fu = None
    if fact.get("rel") == "angle_measure":
        if unit != "deg":
            return False
    elif unit is not None and unit != fu:
        return False
    v = str(fact.get("value", ""))
    try:
        return C.parse_number(num) == C.parse_number(v)
    except Exception:
        return num == v.replace(" ", "")


def number_tokens(text):
    """All numbers printed in a text (for the answer guard)."""
    return re.findall(r"[0-9]+(?:\.[0-9]+)?", text or "")
