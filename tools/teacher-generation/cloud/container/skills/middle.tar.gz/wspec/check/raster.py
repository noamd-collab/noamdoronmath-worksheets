# -*- coding: utf-8 -*-
"""The final display: the figure rasterised by MuPDF (an SVG engine that is
not the renderer), and the measured ink box of every label. Pure stdlib +
PyMuPDF (no numpy / PIL)."""
import re
import math
import struct
import zlib

from . import tol as T

try:
    import pymupdf
except ImportError:          # pragma: no cover
    try:
        import fitz as pymupdf
    except ImportError:
        pymupdf = None

TEXT_RE = re.compile(r"<text\b[^>]*>[^<]*</text>")
EXT_M = 60.0                 # the extended canvas reaches this far past the edges


def available():
    return pymupdf is not None


_LINE = re.compile(r'<line\b(?P<attrs>[^<>]*?)(?:/>|>\s*</line>)')
_ATTR = re.compile(r'([\w:-]+)="([^"<>]*)"')
_DASH_NUMBER = re.compile(r'^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$')


def line_dash_segments(snip):
    """Exact painted spans of an explicit, unitless straight-line dash.

    MuPDF's SVG reader ignores stroke-dasharray on <line>. Preserve the
    SVG's pattern phase and each dash's original cap by making independent
    straight subpaths for the reference raster only. Unsupported units,
    inherited patterns and zero-length dash entries are not approximated.
    None denotes an ordinary solid line; [] a zero-length dashed line.
    """
    attrs = dict(_ATTR.findall(snip))
    pattern = attrs.get("stroke-dasharray")
    if pattern in (None, "none"):
        return None
    if any(k in attrs for k in ("pathLength", "marker-start", "marker-mid", "marker-end")):
        raise ValueError("unsupported dashed-line pathLength/marker semantics")
    toks = [v for v in re.split(r'[\s,]+', pattern.strip()) if v]
    if not toks or any(not _DASH_NUMBER.fullmatch(v) for v in toks):
        raise ValueError("unsupported unit/non-numeric line dash pattern")
    lengths = [float(v) for v in toks]
    if any(not math.isfinite(v) or v <= 0 for v in lengths):
        raise ValueError("reference requires positive finite line dash entries")
    if len(lengths) % 2:
        lengths *= 2             # SVG repeats an odd list before alternating
    off = attrs.get("stroke-dashoffset", "0")
    if not _DASH_NUMBER.fullmatch(off):
        raise ValueError("unsupported line dash offset unit")
    phase = float(off)
    if not math.isfinite(phase):
        raise ValueError("nonfinite line dash offset")
    if attrs.get("stroke-linecap", "butt") not in ("butt", "round", "square"):
        raise ValueError("unsupported line dash cap")
    coords = [float(attrs[k]) for k in ("x1", "y1", "x2", "y2")]
    if any(not math.isfinite(v) for v in coords):
        raise ValueError("nonfinite dashed-line endpoint")
    x0,y0,x1,y1 = coords
    length = math.hypot(x1-x0,y1-y0)
    if length == 0:
        if attrs.get("stroke-linecap", "butt") != "butt":
            raise ValueError("unsupported zero-length dashed line with a visible cap")
        return []
    phase %= sum(lengths)
    index = 0
    while phase >= lengths[index]:
        phase -= lengths[index]; index = (index+1) % len(lengths)
    remain = lengths[index]-phase
    pos, out = 0.0, []
    while pos < length:
        end = min(length,pos+remain)
        if index % 2 == 0 and end > pos:
            out.append(((x0+(x1-x0)*pos/length,y0+(y1-y0)*pos/length),
                        (x0+(x1-x0)*end/length,y0+(y1-y0)*end/length)))
        pos = end; index = (index+1) % len(lengths); remain = lengths[index]
    return out


def _materialize_line_dashes(svg_text):
    """Equivalent raster-only path encoding; the approved SVG is unchanged."""
    def replace(match):
        snip = match.group(0)
        segments = line_dash_segments(snip)
        if segments is None:
            return snip
        attrs = match.group("attrs")
        attrs = re.sub(r'\s+(?:x1|y1|x2|y2|stroke-dasharray|stroke-dashoffset)="[^"]*"', '', attrs)
        def n(v):return ('%.8f' % v).rstrip('0').rstrip('.') or '0'
        d = ' '.join('M%s,%s L%s,%s' % tuple(n(v) for p in pair for v in p) for pair in segments)
        return '<path%s d="%s"/>' % (attrs, d)
    return _LINE.sub(replace,svg_text)


def _open(svg_text):
    svg_text = _materialize_line_dashes(svg_text)
    return pymupdf.open(stream=svg_text.encode("utf-8"), filetype="svg")


def _with_viewbox(svg_text, x0, y0, w, h):
    head_end = svg_text.index(">", svg_text.index("<svg")) + 1
    head = svg_text[:head_end]
    head = re.sub(r'viewBox="[^"]*"', 'viewBox="%s %s %s %s"' % (
        _n(x0), _n(y0), _n(w), _n(h)), head)
    head = re.sub(r'\swidth="[^"]*"', "", head)
    head = re.sub(r'\sheight="[^"]*"', "", head)
    head = head[:-1] + ' width="%s" height="%s">' % (_n(w), _n(h))
    return head + svg_text[head_end:]


def _n(v):
    return ("%.3f" % v).rstrip("0").rstrip(".")


def gray_pixmap(svg_text, scale):
    doc = _open(svg_text)
    pm = doc[0].get_pixmap(matrix=pymupdf.Matrix(scale, scale),
                           colorspace=pymupdf.csGRAY, alpha=False)
    doc.close()
    return pm


_INK = re.compile(b"[\x00-%s]" % bytes([T.RASTER_INK_LEVEL - 1]))


def ink_bbox(pm, level=None):
    """Bounding box (x0, y0, x1, y1) in pixels of the pixels darker than the
    ink level, or None."""
    rx = _INK if level is None else re.compile(
        b"[\x00-%s]" % bytes([level - 1]))
    w, h, s = pm.width, pm.height, pm.samples
    stride = pm.stride
    x0, x1, y0, y1 = w, -1, None, None
    for y in range(h):
        row = s[y * stride: y * stride + w]
        m = rx.search(row)
        if not m:
            continue
        if y0 is None:
            y0 = y
        y1 = y
        x0 = min(x0, m.start())
        last = w - 1 - rx.search(row[::-1]).start()
        x1 = max(x1, last)
    if y0 is None:
        return None
    return (x0, y0, x1 + 1, y1 + 1)


_INK250 = re.compile(b"[\x00-\xf9]")


def ink_points(pm, scale, off):
    """Centres (SVG units) of the pixels a text alone inks."""
    out = []
    w, st, smp = pm.width, pm.stride, pm.samples
    for y in range(pm.height):
        row = smp[y * st: y * st + w]
        for m in _INK250.finditer(row):
            out.append(((m.start() + 0.5) / scale - off,
                        (y + 0.5) / scale - off))
    return out


def ink_count(pm):
    n = 0
    for m in _INK.finditer(pm.samples):
        n += 1
    return n


class Display(object):
    """The final display of one figure and where each label's ink is."""

    def __init__(self, svg_text, W, H, scale=T.RASTER_SCALE, image=None,
                 image_scale=None, image_origin=(0.0, 0.0)):
        self.svg, self.W, self.H = svg_text, W, H
        if image is not None:
            self.pm = pymupdf.Pixmap(image)
            if self.pm.n != 1 or self.pm.alpha:
                self.pm = pymupdf.Pixmap(pymupdf.csGRAY, self.pm)
            self.scale = image_scale or float(self.pm.width) / W
            self.origin = image_origin
            self.source = "supplied image"
        else:
            self.pm = gray_pixmap(svg_text, scale)
            self.scale = float(scale)
            self.origin = (0.0, 0.0)
            self.source = "MuPDF %s" % pymupdf.VersionBind
        self.texts = [m for m in TEXT_RE.finditer(svg_text)]
        self.ink = {}         # ref -> ink pixel centres (SVG units) of the text alone

    def text_boxes(self, text_refs):
        """ref -> full ink box of that text alone on an extended canvas (in
        SVG units; it may reach past the canvas: that is a clipped label)."""
        out = {}
        head_end = self.svg.index(">", self.svg.index("<svg")) + 1
        head = self.svg[:head_end]
        for ref, m in zip(text_refs, self.texts):
            one = head + m.group(0) + "</svg>"
            ext = _with_viewbox(one, -EXT_M, -EXT_M, self.W + 2 * EXT_M,
                                self.H + 2 * EXT_M)
            pm = gray_pixmap(ext, self.scale)
            bb = ink_bbox(pm, level=250)
            if bb is None:
                out[ref] = None
                continue
            s = self.scale
            self.ink[ref] = ink_points(pm, s, EXT_M)
            out[ref] = (bb[0] / s - EXT_M, bb[1] / s - EXT_M,
                        bb[2] / s - EXT_M, bb[3] / s - EXT_M)
        return out

    def to_px(self, box):
        s, (ox, oy) = self.scale, self.origin
        return (ox + box[0] * s, oy + box[1] * s, ox + box[2] * s,
                oy + box[3] * s)

    def crop(self, box, pad=0.5):
        """The display's pixels inside the box (SVG units) grown by pad,
        clipped to the image; a grey Pixmap, or None if empty."""
        x0, y0, x1, y1 = self.to_px((box[0] - pad, box[1] - pad,
                                     box[2] + pad, box[3] + pad))
        x0, y0 = max(0, int(x0)), max(0, int(y0))
        x1, y1 = min(self.pm.width, int(x1 + 0.999)), \
            min(self.pm.height, int(y1 + 0.999))
        if x1 - x0 < 2 or y1 - y0 < 2:
            return None
        return sub_pixmap(self.pm, x0, y0, x1, y1)

    def save_png(self, path):
        self.pm.save(path)


def sub_pixmap(pm, x0, y0, x1, y1):
    rows = []
    s, st = pm.samples, pm.stride
    for y in range(y0, y1):
        rows.append(bytes(s[y * st + x0: y * st + x1]))
    return Gray(x1 - x0, y1 - y0, rows)


class Gray(object):
    """A small 8-bit grey image as rows of bytes (stdlib only)."""

    def __init__(self, w, h, rows):
        self.w, self.h, self.rows = w, h, rows

    @classmethod
    def blank(cls, w, h):
        return cls(w, h, [b"\xff" * w for _ in range(h)])

    def binarise(self, level=T.RASTER_INK_LEVEL):
        tab = bytes(0 if v < level else 255 for v in range(256))
        return Gray(self.w, self.h, [r.translate(tab) for r in self.rows])

    def ink_bbox(self):
        x0, x1, y0, y1 = self.w, -1, None, None
        for y, row in enumerate(self.rows):
            m = _INK.search(row)
            if not m:
                continue
            if y0 is None:
                y0 = y
            y1 = y
            x0 = min(x0, m.start())
            x1 = max(x1, self.w - 1 - _INK.search(row[::-1]).start())
        if y0 is None:
            return None
        return (x0, y0, x1 + 1, y1 + 1)

    def ink_count(self):
        return sum(len(_INK.findall(r)) for r in self.rows)

    def crop(self, box):
        x0, y0, x1, y1 = box
        return Gray(x1 - x0, y1 - y0, [r[x0:x1] for r in self.rows[y0:y1]])

    def scaled(self, k):
        """Nearest-neighbour scale by k (> 0)."""
        W, H = max(1, int(round(self.w * k))), max(1, int(round(self.h * k)))
        xs = [min(self.w - 1, int(x / k)) for x in range(W)]
        out = []
        for y in range(H):
            r = self.rows[min(self.h - 1, int(y / k))]
            out.append(bytes(r[x] for x in xs))
        return Gray(W, H, out)

    def paste(self, other, x, y):
        for j, r in enumerate(other.rows):
            row = bytearray(self.rows[y + j])
            row[x:x + other.w] = r
            self.rows[y + j] = bytes(row)

    def png(self):
        raw = b"".join(b"\x00" + r for r in self.rows)

        def chunk(t, d):
            c = struct.pack(">I", len(d)) + t + d
            return c + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
        return (b"\x89PNG\r\n\x1a\n" +
                chunk(b"IHDR", struct.pack(">IIBBBBB", self.w, self.h, 8, 0,
                                           0, 0, 0)) +
                chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b""))
