# -*- coding: utf-8 -*-
"""Plane measurement helpers (SVG coordinates, y down)."""
import math


def d(p, q):
    return math.hypot(p[0] - q[0], p[1] - q[1])


def sub(p, q):
    return (p[0] - q[0], p[1] - q[1])


def add(p, q):
    return (p[0] + q[0], p[1] + q[1])


def mul(p, k):
    return (p[0] * k, p[1] * k)


def dot(u, v):
    return u[0] * v[0] + u[1] * v[1]


def cross(u, v):
    return u[0] * v[1] - u[1] * v[0]


def mid(p, q):
    return ((p[0] + q[0]) / 2.0, (p[1] + q[1]) / 2.0)


def param(p, a, b):
    """t of the projection of p on a + t (b - a)."""
    ab = sub(b, a)
    L2 = dot(ab, ab)
    return dot(sub(p, a), ab) / L2 if L2 else 0.0


def line_dist(p, a, b):
    """Distance from p to the infinite line ab."""
    L = d(a, b)
    return abs(cross(sub(b, a), sub(p, a))) / L if L else d(p, a)


def seg_dist(p, a, b):
    t = max(0.0, min(1.0, param(p, a, b)))
    return d(p, add(a, mul(sub(b, a), t)))


def angle_deg(v, a, b):
    """The (non-reflex) angle a-v-b in degrees."""
    u, w = sub(a, v), sub(b, v)
    nu, nw = math.hypot(*u), math.hypot(*w)
    if not nu or not nw:
        return float("nan")
    c = max(-1.0, min(1.0, dot(u, w) / (nu * nw)))
    return math.degrees(math.acos(c))


def direction(p, q):
    """Direction angle of p->q in degrees [0, 360)."""
    return math.degrees(math.atan2(q[1] - p[1], q[0] - p[0])) % 360.0


def ang_diff(a, b):
    """Smallest difference of two direction angles (degrees)."""
    x = abs(a - b) % 360.0
    return min(x, 360.0 - x)


def line_dir_diff(p1, q1, p2, q2):
    """Angle between two undirected lines, 0..90 degrees."""
    x = ang_diff(direction(p1, q1), direction(p2, q2)) % 180.0
    return min(x, 180.0 - x)


def in_sector(c, v, a, b, eps=1e-9):
    """c strictly inside the convex angle a-v-b (< 180)."""
    u, w, x = sub(a, v), sub(b, v), sub(c, v)
    s = cross(u, w)
    if abs(s) < eps:
        return False
    return cross(u, x) * s > eps and cross(x, w) * s > eps


def in_polygon(c, poly):
    x, y = c
    inside = False
    n = len(poly)
    for i in range(n):
        (x1, y1), (x2, y2) = poly[i], poly[(i + 1) % n]
        if (y1 > y) != (y2 > y):
            xi = x1 + (y - y1) * (x2 - x1) / (y2 - y1)
            if xi > x:
                inside = not inside
    return inside


def area(poly):
    s = 0.0
    n = len(poly)
    for i in range(n):
        s += cross(poly[i], poly[(i + 1) % n])
    return abs(s) / 2.0


def box_dist(p, box):
    """Distance from point p to the box (0 inside)."""
    x0, y0, x1, y1 = box
    dx = max(x0 - p[0], 0.0, p[0] - x1)
    dy = max(y0 - p[1], 0.0, p[1] - y1)
    return math.hypot(dx, dy)


def box_center(box):
    return ((box[0] + box[2]) / 2.0, (box[1] + box[3]) / 2.0)


def grow(box, k):
    return (box[0] - k, box[1] - k, box[2] + k, box[3] + k)


def clip_len(p, q, box):
    """Length of the part of segment pq inside the box (Liang-Barsky)."""
    x0, y0, x1, y1 = box
    dx, dy = q[0] - p[0], q[1] - p[1]
    t0, t1 = 0.0, 1.0
    for pp, qq in ((-dx, p[0] - x0), (dx, x1 - p[0]),
                   (-dy, p[1] - y0), (dy, y1 - p[1])):
        if pp == 0:
            if qq < 0:
                return 0.0
            continue
        r = qq / pp
        if pp < 0:
            t0 = max(t0, r)
        else:
            t1 = min(t1, r)
        if t0 > t1:
            return 0.0
    return (t1 - t0) * math.hypot(dx, dy)


def seg_box_dist(p, q, box):
    """Distance between segment pq and a box (0 if they meet)."""
    if clip_len(p, q, box) > 0 or box_dist(p, box) == 0:
        return 0.0
    x0, y0, x1, y1 = box
    corners = [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]
    best = min(box_dist(p, box), box_dist(q, box))
    for c in corners:
        best = min(best, seg_dist(c, p, q))
    return best


def polyline_box_dist(pts, box):
    return min(seg_box_dist(pts[i], pts[i + 1], box)
               for i in range(len(pts) - 1))


def covered(span_a, span_b, pieces, tol_line, gap):
    """Is the span [span_a, span_b] covered by the union of the pieces that
    lie on its line? pieces: list of (p, q). Returns (covered, used pieces
    indices)."""
    L = d(span_a, span_b)
    if not L:
        return False, []
    ivs, used = [], []
    for i, (p, q) in enumerate(pieces):
        if line_dist(p, span_a, span_b) > tol_line or \
                line_dist(q, span_a, span_b) > tol_line:
            continue
        t1, t2 = sorted((param(p, span_a, span_b), param(q, span_a, span_b)))
        if t2 * L < -gap or t1 * L > L + gap:
            continue
        # (pilot_build) a piece that only TOUCHES the span at an end (EC at
        # E for the span AE) draws none of it
        if min(t2 * L, L) - max(t1 * L, 0.0) <= gap:
            continue
        ivs.append((t1 * L, t2 * L))
        used.append(i)
    ivs.sort()
    reach = 0.0
    for a, b in ivs:
        if a > reach + gap:
            break
        reach = max(reach, b)
    return reach >= L - gap, used
