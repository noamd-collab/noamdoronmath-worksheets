# -*- coding: utf-8 -*-
"""wspec.check.nline -- the INDEPENDENT checker of a NUMBER-LINE figure
(v6.12, BRIEF_V612 section 1, family B).

It imports nothing from wspec.render and never reads the renderer's code.
It reads the renderer's OUTPUT (SVG + object map), the PUBLIC spec (a
private model / answer store is refused) and the dialect DATA file
wspec/svg_dialect_nline.json; from the rest of wspec only wspec.canon
(numbers). It MEASURES the drawing:

  * the dialect (closed elements, attributes, hooks, alphabet, positional
    ids) -- DIALECT_CLOSED;
  * the axis, its arrowhead and every tick 0..n: one line, ticks across it
    at equal spacing (0.1 px), values increasing toward the arrowhead (up
    on a vertical line) -- NL_SCALE_CONSISTENT, NL_TICKS_AT_VALUES,
    NL_ARROW_DIRECTION, NL_VERTICAL_ORIENTATION, NL_DRAWN_RANGE_AS_DECLARED;
  * the printed numbers: exactly the public frame's labels, at their ticks,
    in their form (whole / decimal / stacked fraction / mixed), U+2212 --
    NL_NUMBERS_NEVER_DROPPED, NL_NUMBERS_PARTIAL_AS_DECLARED,
    NL_UNLABELLED_TICKS_NOT_LABELLED, NL_MINUS_U2212;
  * the value mapping read from two printed labels (as the student reads
    the line): every place (dot / ring) of a public value at that value
    (0.3 px) -- NL_PT_AT_VALUE; a place whose value is private is checked
    against `positions` (the harness hands the values, never the checker's
    own store) and otherwise reported measured (REVIEW for its object);
  * letters and captions owned by their dot, values equal to the drawn
    given, jumps from dot to dot with the head at the end, intervals from
    end to end with closed / open ends as declared, brackets only for a
    drawn given -- NL_PT_LABEL_OWNED_IF_ANY, NL_JUMP_*, NL_INTERVAL_*,
    NL_ABS_AS_DISTANCE_FROM_ZERO, GUIDES_ONLY_IF_STATED;
  * leaks: a to_plot value has no marker / caption at its place, a target
    is never printed, an answer_guard value is printed nowhere but in the
    frame -- NL_NOT_DRAWN_ANY_FORM, TARGET_VALUE_NOT_SHOWN,
    NL_DISTANCE_NOT_SHOWN, NO_ANSWER_ANYWHERE_SVG;
  * text boxes (the ink of each text alone, rasterised) inside the canvas,
    crossed by no stroke, covering no mark, not merged -- TEXT_BOX_IN_CANVAS,
    NL_NUMBERS_NOT_CUT, TEXT_NOT_COVERING_MARKS;
  * OCR (macOS Vision) of every number / letter from its crop of the final
    display (a supplied page raster or MuPDF's) -- OCR_NL_NUMBERS,
    OCR_NL_LETTER_AT_POINT (a read hyphen / dash counts as the minus: the
    glyph is checked in the text; a lost minus on the print is a FAIL);
  * the object map: total, one owner per element, roles vs hooks, every
    object's parts exactly the elements the checker measures for it --
    OBJMAP_TOTAL_NO_UNMAPPED_INK, HIGHLIGHT_ON_MEASURED_GEOMETRY (a span's
    ends are the measured places).

    rep = check_number_line(svg, object_map, public_spec, figure_id, ...)
    object_report(rep, eid) / check_highlight(base, hl, rep, eid)
"""
import json
import math
import os
import re
import xml.etree.ElementTree as ET
from fractions import Fraction

from .. import canon as C
from . import tol as T
from .report import (Findings, CheckerInputError, worst, FAIL, REVIEW,
                     NOTE, PASS, NA)
from .spec import refuse_private

CHECKER_VERSION = "wspec-check-nl/1"
HERE = os.path.dirname(os.path.abspath(__file__))
DIALECT_JSON = os.path.join(os.path.dirname(HERE), "svg_dialect_nline.json")
NS = "{http://www.w3.org/2000/svg}"
MINUS = u"−"
DASHES = u"-‐‑‒–—―−﹣－"
DRAWABLE = ("line", "circle", "polygon", "path", "text")

# tolerances (px, SVG units)
TICK_POS_TOL = 0.1         # a tick at its place under one equal spacing
ON_AXIS_TOL = 0.3          # a mark centre on the axis line
PT_TOL = 0.3               # a place at its value
END_TOL = 0.6              # a jump / interval / span end at its place
LABEL_TICK_FRAC = 0.15     # a number's centre within this x spacing of its tick
LABEL_TICK_MIN = 1.0
NAME_NEAR = 24.0           # a letter within this of its dot
OWN_MARGIN = 2.0           # own dot nearer than any other by this
CORE_SHRINK = 1.0          # a text's core = its ink box shrunk by this
CANVAS_MARGIN = 0.5
MERGE_GAP = 0.5            # two texts' ink boxes closer than this: merged
STACK_TOL = 1.5            # stacked runs centred on their bar within this
PLOT_TOL = 1.5             # a marker / caption this near a to_plot value
CAPTION_NEAR = 30.0        # a value caption within this of its dot
JUMP_CAP_NEAR = 12.0       # a jump caption this near its arc's top

FIGURE_CHECKS = [
    "DIALECT_CLOSED", "OBJMAP_TOTAL_NO_UNMAPPED_INK", "NO_ANSWER_ANYWHERE_SVG",
    "TEXT_BOX_IN_CANVAS", "TEXT_NOT_COVERING_MARKS", "GUIDES_ONLY_IF_STATED",
    "NL_SCALE_CONSISTENT", "NL_TICKS_AT_VALUES", "NL_NUMBERS_NEVER_DROPPED",
    "NL_NUMBERS_NOT_CUT", "NL_MINUS_U2212", "OCR_NL_NUMBERS",
    "NL_ARROW_DIRECTION", "NL_VERTICAL_ORIENTATION",
    "NL_NUMBERS_PARTIAL_AS_DECLARED", "NL_UNLABELLED_TICKS_NOT_LABELLED",
    "NL_DRAWN_RANGE_AS_DECLARED", "NL_NOT_DRAWN_ANY_FORM",
    "NL_SOLUTION_NOT_DRAWN", "TARGET_VALUE_NOT_SHOWN",
    "NL_DISTANCE_NOT_SHOWN"]
OBJECT_CHECKS = {
    "point": ["NL_PT_AT_VALUE", "NL_PT_LABEL_OWNED_IF_ANY",
              "OCR_NL_LETTER_AT_POINT"],
    "number": ["NL_PT_AT_VALUE", "NL_PT_LABEL_OWNED_IF_ANY"],
    "jump": ["NL_JUMP_ENDS_AT_VALUES", "NL_JUMP_DIRECTION",
             "NL_JUMP_CAPTION_OWNED_IF_ANY"],
    "interval": ["NL_INTERVAL_ENDS_AT_VALUES",
                 "NL_INTERVAL_ENDPOINTS_OPEN_CLOSED"],
    "span": ["NL_ENDS_AT_VALUES_IF_DRAWN", "NL_ABS_AS_DISTANCE_FROM_ZERO",
             "HIGHLIGHT_ON_MEASURED_GEOMETRY"],
    "axis": [], "tick": ["NL_TICKS_AT_VALUES"],
}
ALL_CHECKS = FIGURE_CHECKS + sorted(set(c for v in OBJECT_CHECKS.values()
                                        for c in v))
# display item role -> the hooks its elements may carry
ROLE_HOOKS = {
    "axis_line": ("axis",), "axis_arrow": ("arrow",), "tick": ("tick",),
    "tick_number": ("num", "num-s", "num-w", "num-n", "num-d", "num-bar"),
    "dot": ("pt",), "open_end": ("ring",), "point_name": ("name",),
    "value_caption": ("val", "val-s", "val-w", "val-n", "val-d", "val-bar"),
    "jump_arc": ("jump",), "jump_head": ("jump-head",),
    "jump_caption": ("jump-val", "jump-val-s", "jump-val-w", "jump-val-n",
                     "jump-val-d", "jump-val-bar"),
    "interval_bar": ("ivl",), "span_bracket": ("span",),
    "span_caption": ("span-val", "span-val-s", "span-val-w", "span-val-n",
                     "span-val-d", "span-val-bar"),
    "axis_name": ("axis-name",)}
LABEL_BASES = ("num", "val", "jump-val", "span-val")
ENTITY_REFS = {"jump": ("from", "to"), "interval": ("lo", "hi"),
               "tick": ("axis",)}


def is_number_line(spec, figure_id):
    """the figure of the public spec carries a number_line frame."""
    for g in (spec.get("figures") if isinstance(spec, dict) else None) or []:
        if isinstance(g, dict) and g.get("id") == figure_id:
            return (g.get("frame") or {}).get("family") == "number_line"
    return False


def load_dialect(path=DIALECT_JSON):
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def _q(v):
    try:
        a, b, r = C.parse_exact(v)
    except Exception:                       # noqa: BLE001
        return None
    return a if r == 1 else None


def _s(v):
    return C.canon_number(str(v))


def _base(hook):
    """a label hook's family: 'num-n' -> 'num', 'jump-val-bar' -> 'jump-val'."""
    for b in sorted(LABEL_BASES, key=len, reverse=True):
        if hook == b or hook.startswith(b + "-"):
            return b
    return None


def _run(hook):
    b = _base(hook)
    if b is None:
        return None
    return hook[len(b):].lstrip("-") or "plain"


# ------------------------------------------------------------ the spec ---
class LineSpec(object):
    """The public facts one number-line figure is checked against."""

    def __init__(self, spec, figure_id):
        refuse_private(spec)
        self.spec = spec
        self.ents = dict((e["id"], e) for e in spec.get("entities") or [])
        self.facts = dict((f["id"], f) for f in spec.get("facts") or [])
        figs = dict((g["id"], g) for g in spec.get("figures") or [])
        if figure_id not in figs:
            raise CheckerInputError("figure %s is not in the public spec"
                                    % figure_id)
        self.fig = figs[figure_id]
        fr = self.fig.get("frame") or {}
        if fr.get("family") != "number_line" or len(fr.get("axes") or []) \
                != 1:
            raise CheckerInputError("figure %s is not a number line"
                                    % figure_id)
        ax = fr["axes"][0]
        self.axis = ax["axis"]
        self.n = int(ax["intervals"])
        self.form = ax.get("form")
        self.labels = dict((int(k), _q(v)) for k, v in ax.get("labels") or [])
        self.scope = {}
        for q in spec.get("questions") or []:
            self.scope[q["id"]] = q["id"]
            for it in q.get("items") or []:
                self.scope[it["id"]] = q["id"]
        self.items = dict((it["id"], it) for q in spec.get("questions") or []
                          for it in q.get("items") or [])
        self.qid = self.scope.get(self.fig.get("scope"))
        self.draws = [self.facts[d] for d in self.fig.get("draws") or []
                      if d in self.facts]
        self.shown = set()
        for e in self.fig.get("entities") or []:
            self.shown |= self.closure(e)
        for f in self.draws:
            for a in f.get("args") or []:
                self.shown |= self.closure(a)

    def closure(self, eid):
        seen, todo = set(), [eid]
        while todo:
            x = todo.pop()
            if x in seen or not isinstance(x, str) or x not in self.ents:
                continue
            seen.add(x)
            e = self.ents[x]
            for fld in ENTITY_REFS.get(e.get("kind"), ()):
                todo.append(e.get(fld))
        return seen

    def kind(self, eid):
        return (self.ents.get(eid) or {}).get("kind")

    def q_facts(self):
        return [f for f in sorted(self.facts.values(), key=lambda f: f["id"])
                if self.scope.get(f.get("item")) == self.qid]

    def public_value(self, eid):
        e = self.ents.get(eid) or {}
        if e.get("kind") == "number":
            return _q(e.get("value"))
        for f in self.q_facts():
            if f.get("rel") == "coordinate" and f.get("args") == [
                    eid, self.axis] and f.get("value") is not None and \
                    f.get("role") in ("given", "derived", "context"):
                return _q(f["value"])
        return None

    def form_of(self, value, form):
        """the printed shape of a number: 'plain' or 'stacked'."""
        v = Fraction(value)
        if v.denominator == 1:
            return "plain"
        if form is None:
            return "plain" if C.terminating(abs(v)) else "stacked"
        return "plain" if form == "decimal" else "stacked"


# ------------------------------------------------------------- the svg ---
class El(object):
    def __init__(self, ref, tag, a, text):
        self.ref, self.tag, self.a, self.text = ref, tag, a, text

    @property
    def hook(self):
        return self.a.get("data-nl")

    @property
    def fr(self):
        return self.a.get("data-for")

    @property
    def at(self):
        v = self.a.get("data-at")
        return int(v) if v is not None and v.isdigit() else None

    def f(self, k):
        return float(self.a.get(k, "nan"))

    def pts(self):
        if self.tag == "line":
            return [(self.f("x1"), self.f("y1")), (self.f("x2"),
                                                   self.f("y2"))]
        if self.tag == "circle":
            return [(self.f("cx"), self.f("cy"))]
        if self.tag == "polygon":
            v = [float(x) for x in re.findall(r"[0-9.]+",
                                              self.a.get("points", ""))]
            return list(zip(v[0::2], v[1::2]))
        if self.tag == "path":
            v = [float(x) for x in re.findall(r"[0-9.]+", self.a.get("d", ""))]
            return list(zip(v[0::2], v[1::2]))
        if self.tag == "text":
            return [(self.f("x"), self.f("y"))]
        return []


def read_svg(raw, D, F):
    """-> (elements, W, H) or (None, 0, 0) when unreadable. Every dialect
    violation is a FAIL of DIALECT_CLOSED."""
    def bad(detail):
        F.fail("CHK_NL_DIALECT", "DIALECT_CLOSED", detail)
    txt = raw.decode("utf-8") if isinstance(raw, bytes) else raw
    body = txt
    if body.startswith('<?xml version="1.0" encoding="UTF-8"?>'):
        body = body[len('<?xml version="1.0" encoding="UTF-8"?>'):]
    if "<?" in body or "<!" in body:
        bad("a processing instruction, comment or declaration in the file")
    try:
        root = ET.fromstring(txt.encode("utf-8"))
    except ET.ParseError as e:
        bad("not XML: %s" % e)
        return None, 0, 0
    if root.tag != NS + "svg":
        bad("the root is %s" % root.tag)
        return None, 0, 0
    num = re.compile(D["grammar"]["number"])
    ref_re = re.compile(D["grammar"]["ref"])
    idx_re = re.compile(D["grammar"]["index"])
    vb = (root.get("viewBox") or "").split(" ")
    try:
        W, H = float(vb[2]), float(vb[3])
        assert vb[0] == "0" and vb[1] == "0" and 0 < W <= float(
            D["canvas_max_px"]) and 0 < H <= float(D["canvas_max_px"])
        assert root.get("width") == vb[2] and root.get("height") == vb[3]
    except Exception:                           # noqa: BLE001
        bad("viewBox / width / height %r" % (root.attrib,))
        return None, 0, 0
    extra = set(root.attrib) - {"viewBox", "width", "height"}
    if extra:
        bad("svg attributes %s" % sorted(extra))
    alph = D["text_alphabet"]
    ok_ch = set(alph["singles"])
    for lo, hi in alph["ranges"]:
        ok_ch |= set(chr(c) for c in range(ord(lo), ord(hi) + 1))
    hooks = D["hooks"]
    els = []
    k = 0

    def walk(node, depth):
        nonlocal k
        for ch in list(node):
            tag = ch.tag.replace(NS, "")
            if tag == "g":
                if set(ch.attrib) != {"data-layer"} or \
                        ch.get("data-layer") not in D["layers"]:
                    bad("g %r" % (ch.attrib,))
                if (ch.text or "").strip():
                    bad("text inside a g")
                walk(ch, depth + 1)
                continue
            if tag not in D["elements"] or tag == "svg":
                bad("element <%s> is outside the dialect" % tag)
                continue
            k += 1
            spec = D["elements"][tag]
            a = dict(ch.attrib)
            for r_ in spec["required"]:
                if r_ not in a:
                    bad("<%s> e%04d misses %s" % (tag, k, r_))
            for x in a:
                if x not in spec["required"] and x not in spec["optional"]:
                    bad("<%s> e%04d attribute %s" % (tag, k, x))
            if a.get("id") != "e%04d" % k:
                bad("id %r is not the positional e%04d" % (a.get("id"), k))
            for x in ("x1", "y1", "x2", "y2", "cx", "cy", "x", "y"):
                if x in a and not num.match(a[x]):
                    bad("e%04d %s=%r" % (k, x, a[x]))
            for x in ("points",):
                if x in a:
                    for p in a[x].split(" "):
                        xy = p.split(",")
                        if len(xy) != 2 or not all(num.match(v) for v in xy):
                            bad("e%04d points %r" % (k, p))
                            break
            if "d" in a:
                toks = a["d"].split(" ")
                okd = len(toks) >= 6 and len(toks) % 3 == 0 and \
                    toks[0] == "M" and all(
                        t == "L" for t in toks[3::3]) and all(
                        num.match(t) for i, t in enumerate(toks) if i % 3)
                if not okd:
                    bad("e%04d d is not 'M x y L x y ...'" % k)
            for x in ("stroke", "fill"):
                if x in a and a[x] not in D["paint"].values():
                    bad("e%04d %s=%r" % (k, x, a[x]))
            if "stroke-width" in a and a["stroke-width"] not in \
                    D["stroke_widths"].values():
                bad("e%04d stroke-width %r" % (k, a["stroke-width"]))
            if "stroke-linecap" in a and a["stroke-linecap"] not in \
                    D["linecaps"]:
                bad("e%04d linecap" % k)
            if "stroke-linejoin" in a and a["stroke-linejoin"] not in \
                    D["linejoins"]:
                bad("e%04d linejoin" % k)
            if tag == "circle" and a.get("r") not in D["point_radii"]:
                bad("e%04d r=%r" % (k, a.get("r")))
            if tag == "text":
                if a.get("font-size") not in D["font_sizes"]:
                    bad("e%04d font-size %r" % (k, a.get("font-size")))
                if a.get("font-family") not in D["font_families"]:
                    bad("e%04d font-family" % k)
                if a.get("text-anchor") not in D["text_anchors"]:
                    bad("e%04d text-anchor" % k)
                t = ch.text or ""
                if not t or len(list(ch)):
                    bad("e%04d empty text or markup inside" % k)
                for i, c in enumerate(t):
                    if c in ok_ch:
                        continue
                    if c == "." and 0 < i < len(t) - 1 and t[i - 1].isdigit() \
                            and t[i + 1].isdigit():
                        continue
                    bad("e%04d text %r: character %r (U+%04X) is outside "
                        "the alphabet%s" % (k, t, c, ord(c), " -- a minus is "
                                            "U+2212" if c in DASHES else ""))
                    if c in DASHES:
                        # (v6.12 integration) the catalogue check of the
                        # minus names it too (the acceptance's GMN3 control)
                        F.fail("CHK_NL_HYPHEN_MINUS", "NL_MINUS_U2212",
                               "e%04d text %r: %r (U+%04X) for the minus "
                               "U+2212" % (k, t, c, ord(c)))
                    break
            hk = a.get("data-nl")
            hd = hooks.get(hk)
            if hd is None:
                bad("e%04d hook data-nl=%r" % (k, hk))
            elif hd["element"] != tag:
                bad("e%04d a %s hook on <%s>" % (k, hk, tag))
            if not ref_re.match(a.get("data-for", "")):
                bad("e%04d data-for %r" % (k, a.get("data-for")))
            if hd is not None and hd.get("at") and not idx_re.match(
                    a.get("data-at", "")):
                bad("e%04d data-at %r" % (k, a.get("data-at")))
            if hd is not None and not hd.get("at") and "data-at" in a:
                bad("e%04d data-at on a %s" % (k, hk))
            els.append(El("e%04d" % k, tag, a, ch.text if tag == "text"
                          else None))
            if len(list(ch)) and tag != "text":
                bad("e%04d has children" % k)
    walk(root, 1)
    return els, W, H


# --------------------------------------------------------------- geometry --
def _pt_seg_d(p, a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    L2 = dx * dx + dy * dy
    if L2 == 0:
        return math.hypot(p[0] - a[0], p[1] - a[1])
    t = max(0.0, min(1.0, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / L2))
    return math.hypot(p[0] - a[0] - t * dx, p[1] - a[1] - t * dy)


def _pt_box_d(p, box):
    dx = max(box[0] - p[0], 0.0, p[0] - box[2])
    dy = max(box[1] - p[1], 0.0, p[1] - box[3])
    return math.hypot(dx, dy)


def _seg_in_box_len(a, b, box):
    """length of segment ab inside the box (Liang-Barsky)."""
    x0, y0, x1, y1 = box
    dx, dy = b[0] - a[0], b[1] - a[1]
    t0, t1 = 0.0, 1.0
    for p, q in ((-dx, a[0] - x0), (dx, x1 - a[0]), (-dy, a[1] - y0),
                 (dy, y1 - a[1])):
        if abs(p) < 1e-12:
            if q < 0:
                return 0.0
            continue
        t = q / p
        if p < 0:
            t0 = max(t0, t)
        else:
            t1 = min(t1, t)
        if t0 > t1:
            return 0.0
    return (t1 - t0) * math.hypot(dx, dy)


def _grow(b, d):
    return (b[0] - d, b[1] - d, b[2] + d, b[3] + d)


def _union(bs):
    bs = [b for b in bs if b]
    if not bs:
        return None
    return (min(b[0] for b in bs), min(b[1] for b in bs),
            max(b[2] for b in bs), max(b[3] for b in bs))


def _overlap(a, b, gap=0.0):
    return not (a[2] + gap <= b[0] or b[2] + gap <= a[0] or
                a[3] + gap <= b[1] or b[3] + gap <= a[1])


def _est_box(el):
    """glyph box estimated from the text's font (no raster)."""
    fs = float(el.a.get("font-size", "12"))
    w = 0.0
    for ch in el.text or "":
        w += 0.5 if ch.isdigit() else 0.25 if ch in ".'" else \
            0.56 if ch in (MINUS, "+") else 0.72 if ch.isupper() else 0.5
    w *= fs
    x, y = el.f("x"), el.f("y")
    anc = el.a.get("text-anchor")
    x0 = x - w / 2 if anc == "middle" else (x - w if anc == "end" else x)
    top = y - (0.72 * fs if any(c.isdigit() or c.isupper() or c in "+"
                               for c in el.text or "") else 0.4 * fs)
    bot = y + 0.22 * fs * (1 if any(c in "gjpqy" for c in el.text or "")
                           else 0.1)
    if (el.text or "") in (MINUS, "+"):
        top, bot = y - 0.45 * fs, y - 0.2 * fs
    return (x0, top, x0 + w, bot)


# ------------------------------------------------------------ the check ---
class _Check(object):
    def __init__(self, els, W, H, ls, F, boxes, positions):
        self.els, self.W, self.H, self.ls, self.F = els, W, H, ls, F
        self.boxes = boxes or {}
        self.positions = dict((k, _q(v)) for k, v in (positions or {})
                              .items())
        self.by = {}
        for e in els:
            self.by.setdefault(e.hook, []).append(e)
        self.measured = {}
        self.of_obj = {}                # object -> set of element refs
        self.not_drawn = []

    def box(self, el):
        return self.boxes.get(el.ref) or _est_box(el)

    # -------------------------------------------------------------- axis --
    def axis(self):
        F, ls = self.F, self.ls
        ax = self.by.get("axis") or []
        if len(ax) != 1:
            F.fail("CHK_NL_AXIS", "NL_DRAWN_RANGE_AS_DECLARED", "%d axis lines "
                   "(one expected)" % len(ax))
            return False
        a = ax[0]
        if a.fr != ls.axis:
            F.fail("CHK_NL_AXIS", "DIALECT_CLOSED", "the axis draws %r, the "
                   "frame's axis is %s" % (a.fr, ls.axis))
        (x1, y1), (x2, y2) = a.pts()
        if abs(y1 - y2) < 1e-6:
            self.vert = False
            self.c0 = y1
            self.lo_, self.hi_ = sorted((x1, x2))
        elif abs(x1 - x2) < 1e-6:
            self.vert = True
            self.c0 = x1
            self.lo_, self.hi_ = sorted((y1, y2))
        else:
            F.fail("CHK_NL_AXIS", "NL_DRAWN_RANGE_AS_DECLARED", "the axis is "
                   "neither horizontal nor vertical")
            return False
        self.axis_el = a
        self.measured["orientation"] = "vertical" if self.vert else \
            "horizontal"
        return True

    def along(self, p):
        """position along the line, growing with the tick index direction
        measured later (raw: x, or -y on a vertical line)."""
        return p[0] if not self.vert else -p[1]

    def across(self, p):
        """signed distance from the line: + = above (right of a vertical
        line)."""
        return (self.c0 - p[1]) if not self.vert else (p[0] - self.c0)

    def ticks(self):
        F, ls = self.F, self.ls
        tk = {}
        for t in self.by.get("tick") or []:
            if t.at in tk:
                F.fail("CHK_NL_TICK_DOUBLE", "NL_TICKS_AT_VALUES", "two ticks "
                       "of index %d" % t.at)
            tk[t.at] = t
        want = set(range(ls.n + 1))
        if set(tk) != want:
            F.fail("CHK_NL_TICK_SET", "NL_DRAWN_RANGE_AS_DECLARED", "ticks %s, "
                   "the frame has %d intervals (ticks 0..%d): missing %s, "
                   "extra %s" % (sorted(tk), ls.n, ls.n, sorted(want - set(tk)),
                                 sorted(set(tk) - want)))
        pos = {}
        for k, t in sorted(tk.items()):
            (a, b) = t.pts()
            if self.vert:
                ok = abs(a[1] - b[1]) < 1e-6 and min(a[0], b[0]) < self.c0 < \
                    max(a[0], b[0])
            else:
                ok = abs(a[0] - b[0]) < 1e-6 and min(a[1], b[1]) < self.c0 < \
                    max(a[1], b[1])
            if not ok:
                F.fail("CHK_NL_TICK_ACROSS", "NL_TICKS_AT_VALUES", "tick %d "
                       "(%s) does not cross the axis at right angles"
                       % (k, t.ref))
            pos[k] = self.along(a)
            self.of_obj.setdefault(ls.axis, set()).add(t.ref)
        self.tick_el = tk
        self.tpos = pos
        if 0 not in pos or ls.n not in pos:
            return False
        u = (pos[ls.n] - pos[0]) / float(ls.n)
        self.t0, self.u = pos[0], u
        self.measured["px_per_interval"] = round(abs(u), 3)
        for k, x in sorted(pos.items()):
            d = x - (self.t0 + k * u)
            if abs(d) > TICK_POS_TOL:
                F.fail("CHK_NL_TICK_SHIFTED", "NL_SCALE_CONSISTENT", "tick %d "
                       "is %.2f px off the equal spacing of %.2f px"
                       % (k, d, abs(u)))
        if abs(u) < 1e-6:
            F.fail("CHK_NL_TICK_SET", "NL_SCALE_CONSISTENT", "no spacing")
            return False
        # the direction of increasing index is + along (right / up)
        if u < 0:
            F.fail("CHK_NL_DIRECTION", "NL_VERTICAL_ORIENTATION" if self.vert
                   else "NL_ARROW_DIRECTION", "the tick index grows %s"
                   % ("downward" if self.vert else "to the left"))
        # the axis runs past both end ticks; the arrow at the growing end
        lo_t, hi_t = sorted((pos[0], pos[ls.n]))
        a_lo, a_hi = (self.lo_, self.hi_) if not self.vert else \
            (-self.hi_, -self.lo_)
        if not (a_lo < lo_t - 2.0 and a_hi > hi_t + 2.0):
            F.fail("CHK_NL_RANGE", "NL_DRAWN_RANGE_AS_DECLARED", "the axis "
                   "line does not run past its first and last ticks")
        ar = self.by.get("arrow") or []
        if len(ar) != 1 or len(ar[0].pts()) != 3:
            F.fail("CHK_NL_ARROW", "NL_ARROW_DIRECTION", "%d arrowheads "
                   "(one triangle expected)" % len(ar))
        else:
            ps = ar[0].pts()
            tip = max(ps, key=lambda p: self.along(p) if u > 0 else
                      -self.along(p))
            if abs(self.across(tip)) > ON_AXIS_TOL or not (
                    self.along(tip) > hi_t + 2.0 if u > 0 else
                    self.along(tip) < lo_t - 2.0):
                F.fail("CHK_NL_ARROW", "NL_ARROW_DIRECTION", "the arrowhead "
                       "is not at the end of increasing values")
            base = [p for p in ps if p != tip]
            if not all(abs(self.along(p) - (a_hi if u > 0 else a_lo)) < 0.6
                       for p in base):
                F.fail("CHK_NL_ARROW", "NL_ARROW_DIRECTION", "the arrowhead "
                       "does not sit on the axis's end")
            self.of_obj.setdefault(ls.axis, set()).add(ar[0].ref)
        self.of_obj.setdefault(ls.axis, set()).add(self.axis_el.ref)
        return True

    def pix(self, idx):
        return self.t0 + float(idx) * self.u

    # ----------------------------------------------------------- labels ---
    def groups(self, base):
        """{(data-for, data-at): [elements]} of one label family."""
        g = {}
        for e in self.els:
            h = e.hook or ""
            if _base(h) == base:
                g.setdefault((e.fr, e.at), []).append(e)
        return g

    def compose(self, els, where, check):
        """(value Fraction or None, shape, text, box, centre point) of a
        printed number from its runs; FAILs a malformed one."""
        F = self.F
        runs = {}
        for e in els:
            r = _run(e.hook)
            if r in runs:
                F.fail("CHK_NL_LABEL_FORM", check, "%s: two %s runs"
                       % (where, r))
            runs[r] = e
        box = _union([self.box(e) for e in els if e.tag == "text"] +
                     [self._bar_box(e) for e in els if e.tag == "line"])
        if set(runs) == {"plain"}:
            t = runs["plain"].text or ""
            v = _parse_plain(t)
            if v is None:
                F.fail("CHK_NL_LABEL_FORM", check, "%s: %r is not a number"
                       % (where, t))
            return v, "plain", t, box, runs["plain"].pts()[0]
        need = {"n", "bar", "d"}
        if not need <= set(runs) or set(runs) - need - {"s", "w"} or \
                "plain" in runs:
            F.fail("CHK_NL_LABEL_FORM", check, "%s: runs %s are neither a "
                   "number nor a stacked fraction" % (where, sorted(runs)))
            return None, "?", "", box, None
        nt, dt = runs["n"].text or "", runs["d"].text or ""
        (b0, b1) = runs["bar"].pts()
        bx0, bx1, by = min(b0[0], b1[0]), max(b0[0], b1[0]), b0[1]
        mid = (bx0 + bx1) / 2.0
        nb, db = self.box(runs["n"]), self.box(runs["d"])
        ok = abs(b0[1] - b1[1]) < 1e-6 and nb[3] <= by + 0.5 and \
            db[1] >= by - 0.5 and abs((nb[0] + nb[2]) / 2 - mid) <= \
            STACK_TOL and abs((db[0] + db[2]) / 2 - mid) <= STACK_TOL
        if not ok:
            F.fail("CHK_NL_STACK", check, "%s: numerator / bar / denominator "
                   "are not stacked" % where)
        sign, whole = "", ""
        for r in ("s", "w"):
            if r in runs:
                bb = self.box(runs[r])
                if not (bb[2] <= bx0 + 0.5 and abs((bb[1] + bb[3]) / 2 - by)
                        <= 0.45 * float(runs[r].a.get("font-size", 12))):
                    F.fail("CHK_NL_STACK", check, "%s: the %s run is not "
                           "left of the bar at its height" % (
                               where, "sign" if r == "s" else "whole"))
        if "s" in runs:
            sign = runs["s"].text or ""
            if sign not in (MINUS, "+"):
                F.fail("CHK_NL_MINUS", "NL_MINUS_U2212", "%s: the sign of a "
                       "fraction is %r (U+2212 or +)" % (where, sign))
        if "w" in runs:
            whole = runs["w"].text or ""
            if whole.startswith(MINUS) and "s" not in runs:
                sign, whole = MINUS, whole[1:]    # a signed whole part
        if "s" in runs and "w" in runs and self.box(runs["s"])[2] > \
                self.box(runs["w"])[0] + 0.5:
            F.fail("CHK_NL_STACK", check, "%s: the sign is not before the "
                   "whole part" % where)
        try:
            v = Fraction(int(nt), int(dt)) + (int(whole) if whole else 0)
            if not whole.isdigit() and whole:
                raise ValueError(whole)
            if int(dt) < 2 or (whole and int(nt) >= int(dt)):
                F.fail("CHK_NL_LABEL_FORM", check, "%s: %s/%s is not a proper "
                       "fraction" % (where, nt, dt))
        except ValueError:
            F.fail("CHK_NL_LABEL_FORM", check, "%s: %r / %r are not whole "
                   "numbers" % (where, nt, dt))
            return None, "stacked", "", box, (mid, by)
        if sign == MINUS:
            v = -v
        text = sign + (whole + " " if whole else "") + "%s/%s" % (nt, dt)
        # a mixed number stands centred over its tick; a signed fraction
        # keeps its FRACTION there (the sign hangs left of it)
        c = ((box[0] + box[2]) / 2.0, by) if whole and box else (mid, by)
        return v, "stacked", text, box, c

    def _bar_box(self, e):
        (a, b) = e.pts()
        return (min(a[0], b[0]), a[1] - 0.4, max(a[0], b[0]), a[1] + 0.4)

    def numbers(self):
        F, ls = self.F, self.ls
        g = self.groups("num")
        got = {}
        self.num_groups = {}
        for (fr, at), els in sorted(g.items(), key=lambda x: (x[0][1] or 0)):
            where = "the number of tick %s" % at
            if fr != ls.axis:
                F.fail("CHK_NL_LABEL_FOR", "DIALECT_CLOSED", "%s names %r"
                       % (where, fr))
            v, shape, text, box, c = self.compose(els, where,
                                                  "NL_NUMBERS_NEVER_DROPPED")
            got[at] = (v, shape, text, box, c, els)
            self.num_groups[at] = els
            for e in els:
                self.of_obj.setdefault(ls.axis, set()).add(e.ref)
        want = ls.labels
        for k in sorted(set(want) - set(got)):
            F.fail("CHK_NL_NUMBER_DROPPED", "NL_NUMBERS_NEVER_DROPPED", "the "
                   "number %s of tick %d is not printed" % (
                       _disp(want[k]), k))
        for k in sorted(set(got) - set(want)):
            F.fail("CHK_NL_NUMBER_EXTRA", "NL_UNLABELLED_TICKS_NOT_LABELLED",
                   "tick %d prints %r, which the frame does not print" % (
                       k, got[k][2]))
        for k in sorted(set(got) & set(want)):
            v, shape, text, box, c, els = got[k]
            if v is None:
                continue
            if v != want[k]:
                lost = v == -want[k] and want[k] < 0
                F.fail("CHK_NL_MINUS_LOST" if lost else "CHK_NL_NUMBER_WRONG",
                       "NL_MINUS_U2212" if lost else
                       "NL_NUMBERS_PARTIAL_AS_DECLARED",
                       "tick %d prints %r, the frame's number is %s" % (
                           k, text, _disp(want[k])))
            want_shape = ls.form_of(want[k], ls.form)
            if shape != want_shape:
                F.fail("CHK_NL_NUMBER_FORM", "NL_NUMBERS_PARTIAL_AS_DECLARED",
                       "tick %d prints %r as %s, the frame's form is %s" % (
                           k, text, shape, want_shape))
            if want[k] < 0 and MINUS not in text:
                F.fail("CHK_NL_MINUS", "NL_MINUS_U2212", "tick %d: %r has no "
                       "U+2212" % (k, text))
            # at its tick, on the numbers' side
            if c is not None and k in self.tpos and box is not None:
                self._owned_by_tick(k, c, box, text)
        self.frame_numbers = got
        # the mapping read from two printed numbers
        pairs = sorted((k, got[k][0]) for k in got if got[k][0] is not None
                       and k in want and got[k][0] == want[k])
        self.vmap = None
        if len(pairs) >= 2:
            (k1, v1), (k2, v2) = pairs[0], pairs[-1]
            b = (v2 - v1) / (k2 - k1)
            a = v1 - k1 * b
            if b != 0 and all(a + k * b == v for k, v in pairs):
                self.vmap = (a, b)
            else:
                F.fail("CHK_NL_SCALE_READ", "NL_SCALE_CONSISTENT", "the printed "
                       "numbers do not step equally along the ticks")
        self.measured["value_map"] = None if self.vmap is None else \
            {"at_tick0": _s(self.vmap[0]), "per_tick": _s(self.vmap[1])}

    def _owned_by_tick(self, k, c, box, text):
        F = self.F
        tol = max(LABEL_TICK_MIN, LABEL_TICK_FRAC * abs(self.u))
        cx = self.along(c) if not self.vert else self.along(
            (0, (box[1] + box[3]) / 2.0))
        d = cx - self.tpos[k]
        near = min(self.tpos, key=lambda j: abs(self.tpos[j] - cx))
        if abs(d) > tol or near != k:
            F.fail("CHK_NL_NUMBER_OFF_TICK", "NL_TICKS_AT_VALUES", "%r stands "
                   "%.2f px from tick %d (%.2f allowed)" % (text, d, k, tol))
        side = self.across(((box[0] + box[2]) / 2.0, (box[1] + box[3]) / 2.0))
        edge = -self.across((box[0], box[1])) if not self.vert else \
            self.c0 - box[2]
        if side >= 0 or (not self.vert and box[1] <= self.c0) or \
                (self.vert and box[2] >= self.c0):
            F.fail("CHK_NL_NUMBER_SIDE", "NL_TICKS_AT_VALUES", "%r is not on "
                   "the numbers' side of the line" % text)
        return edge

    def value_of_index(self, idx):
        if self.vmap is None:
            return None
        return self.vmap[0] + self.vmap[1] * idx

    def index_of_value(self, v):
        if self.vmap is None:
            return None
        return (Fraction(v) - self.vmap[0]) / self.vmap[1]

    def pos_of_value(self, v):
        i = self.index_of_value(v)
        return None if i is None else self.pix(i)

    # ----------------------------------------------------------- places ---
    def places(self):
        F, ls = self.F, self.ls
        marks = {}
        for e in (self.by.get("pt") or []) + (self.by.get("ring") or []):
            marks.setdefault(e.fr, []).append(e)
        shown = sorted(p for p in ls.shown if ls.kind(p) in ("point",
                                                             "number"))
        self.mark = {}
        self.cent = {}
        for p in sorted(set(marks) - set(shown)):
            F.fail("CHK_NL_PLACE_EXTRA", "NL_NOT_DRAWN_ANY_FORM", "a marker "
                   "for %r, which the figure does not show" % p, obj=p)
        for p in shown:
            ms = marks.get(p) or []
            if len(ms) != 1:
                F.fail("CHK_NL_PLACE_MARKER", "NL_PT_AT_VALUE", "%s has %d "
                       "markers (one expected)" % (p, len(ms)), obj=p)
                if not ms:
                    continue
            m = ms[0]
            if m.tag == "circle":
                c = m.pts()[0]
            else:
                ps = m.pts()
                c = (sum(x for x, _ in ps) / len(ps),
                     sum(y for _, y in ps) / len(ps))
                rs = [math.hypot(x - c[0], y - c[1]) for x, y in ps]
                if len(ps) < 12 or max(rs) - min(rs) > 0.3:
                    F.fail("CHK_NL_RING", "NL_INTERVAL_ENDPOINTS_OPEN_CLOSED",
                           "%s: the open end is no ring" % p, obj=p)
                if m.a.get("fill") != "#ffffff":
                    F.fail("CHK_NL_RING", "NL_INTERVAL_ENDPOINTS_OPEN_CLOSED",
                           "%s: an open end is paper inside" % p, obj=p)
            self.mark[p] = m
            self.cent[p] = c
            self.of_obj.setdefault(p, set()).add(m.ref)
            if abs(self.across(c)) > ON_AXIS_TOL:
                F.fail("CHK_NL_PT_OFF_AXIS", "NL_PT_AT_VALUE", "%s is %.2f px "
                       "off the line" % (p, self.across(c)), obj=p)
        vals = {}
        for p, c in sorted(self.cent.items()):
            idx = (self.along(c) - self.t0) / self.u
            v = ls.public_value(p)
            src = "public"
            if v is None and p in self.positions:
                v, src = self.positions[p], "harness"
            rec = {"index": round(idx, 4), "source": src if v is not None
                   else None}
            if self.vmap is not None:
                rec["reads"] = round(float(self.value_of_index(Fraction(
                    idx).limit_denominator(10000))), 4)
            if v is not None:
                want = self.pos_of_value(v)
                if want is None:
                    F.review("CHK_NL_VALUE_UNREADABLE", "NL_PT_AT_VALUE",
                             "%s: the line prints fewer than two numbers -- "
                             "its value %s cannot be read off" % (p, _disp(v)),
                             obj=p)
                elif abs(self.along(c) - want) > PT_TOL:
                    F.fail("CHK_NL_PT_OFF_VALUE", "NL_PT_AT_VALUE", "%s stands "
                           "at %.2f px, its value %s is at %.2f px" % (
                               p, self.along(c), _disp(v), want), obj=p)
                rec["value"] = _s(v)
            else:
                # the layout's place is the answer key's business (the
                # harness passes `positions` from the private model): here
                # it is recorded, not judged
                F.note("CHK_NL_VALUE_PRIVATE", "NL_PT_AT_VALUE", "%s: its "
                       "value is not public and no harness position was "
                       "given (measured at tick index %.3f)" % (p, idx),
                       obj=p)
            vals[p] = rec
        self.measured["places"] = vals

    def names(self):
        F, ls = self.F, self.ls
        by_p = {}
        for e in self.by.get("name") or []:
            by_p.setdefault(e.fr, []).append(e)
        for p in sorted(by_p):
            if ls.kind(p) != "point" or p not in self.cent:
                F.fail("CHK_NL_NAME_FOR", "NL_PT_LABEL_OWNED_IF_ANY", "a "
                       "letter for %r, which is no drawn point" % p, obj=p)
                continue
        for p in sorted(self.cent):
            if ls.kind(p) != "point":
                continue
            es = by_p.get(p) or []
            name = (ls.ents.get(p) or {}).get("name") or p
            if len(es) != 1:
                F.fail("CHK_NL_NAME_MISSING", "NL_PT_LABEL_OWNED_IF_ANY",
                       "%s has %d letters (one expected)" % (p, len(es)),
                       obj=p)
                if not es:
                    continue
            e = es[0]
            self.of_obj.setdefault(p, set()).add(e.ref)
            if (e.text or "") != name:
                F.fail("CHK_NL_NAME_WRONG", "NL_PT_LABEL_OWNED_IF_ANY", "the "
                       "letter of %s prints %r" % (p, e.text), obj=p)
            self._owned(p, self.box(e), "letter %r" % e.text, NAME_NEAR)

    def axis_name(self):
        F, ls = self.F, self.ls
        es = self.by.get("axis-name") or []
        drawn = [f for f in ls.draws if f.get("rel") == "name" and
                 f.get("args") == [ls.axis]]
        if len(es) != len(drawn[:1]):
            F.fail("CHK_NL_AXIS_NAME", "GUIDES_ONLY_IF_STATED", "%d axis "
                   "letters, %d drawn name facts" % (len(es), len(drawn)))
        for e in es:
            self.of_obj.setdefault(ls.axis, set()).add(e.ref)
            name = (ls.ents.get(ls.axis) or {}).get("name")
            if e.text != name:
                F.fail("CHK_NL_AXIS_NAME", "OCR_NL_LETTER_AT_POINT", "the axis "
                       "letter prints %r, the axis is %r" % (e.text, name))

    def _owned(self, p, box, what, near):
        F = self.F
        mine = _pt_box_d(self.cent[p], box)
        if mine > near:
            F.fail("CHK_NL_LABEL_FAR", "NL_PT_LABEL_OWNED_IF_ANY", "%s of %s "
                   "is %.1f px from its marker (%.0f allowed)" % (
                       what, p, mine, near), obj=p)
        for o, c in sorted(self.cent.items()):
            if o == p or math.hypot(c[0] - self.cent[p][0],
                                    c[1] - self.cent[p][1]) < 0.01:
                continue
            if _pt_box_d(c, box) <= mine + OWN_MARGIN:
                F.fail("CHK_NL_LABEL_NOT_OWNED", "NL_PT_LABEL_OWNED_IF_ANY",
                       "%s of %s is as near %s's marker (%.1f vs %.1f px)" % (
                           what, p, o, _pt_box_d(c, box), mine), obj=p)

    def captions(self):
        """value captions (val*): drawn given coordinates / marks."""
        F, ls = self.F, self.ls
        drawn = dict((f["id"], f) for f in ls.draws)
        seen = set()
        for (fid, _at), els in sorted(self.groups("val").items(),
                                      key=lambda x: str(x[0][0])):
            f = drawn.get(fid)
            where = "caption %s" % fid
            if f is None or f.get("rel") not in ("coordinate", "mark"):
                F.fail("CHK_NL_CAPTION_UNSTATED", "GUIDES_ONLY_IF_STATED",
                       "%s prints a value no drawn given of the figure "
                       "states" % where)
                continue
            p = (f.get("args") or [None])[0]
            seen.add(fid)
            v, shape, text, box, c = self.compose(els, where,
                                                  "TARGET_VALUE_NOT_SHOWN")
            want = _q(f.get("value")) if f["rel"] == "coordinate" else \
                _q((ls.ents.get(p) or {}).get("value"))
            form = f.get("form") if f["rel"] == "coordinate" else \
                (ls.ents.get(p) or {}).get("form")
            for e in els:
                self.of_obj.setdefault(p, set()).add(e.ref)
            if v is not None and want is not None and v != want:
                F.fail("CHK_NL_CAPTION_WRONG", "NL_PT_AT_VALUE", "%s prints "
                       "%r, the given is %s" % (where, text, _disp(want)),
                       obj=p)
            if want is not None and shape != ls.form_of(want, form):
                F.fail("CHK_NL_NUMBER_FORM",
                       "NL_NUMBERS_PARTIAL_AS_DECLARED", "%s prints %s as %s"
                       % (where, text, shape), obj=p)
            if want is not None and want < 0 and MINUS not in text:
                F.fail("CHK_NL_MINUS", "NL_MINUS_U2212", "%s: %r has no "
                       "U+2212" % (where, text), obj=p)
            if p in self.cent and box is not None:
                self._owned(p, box, where, CAPTION_NEAR)
                if self.across(((box[0] + box[2]) / 2, (box[1] + box[3]) /
                                2)) >= 0:
                    F.fail("CHK_NL_CAPTION_SIDE", "NL_PT_LABEL_OWNED_IF_ANY",
                           "%s is not on the numbers' side" % where, obj=p)
        # a drawn coordinate / mark is shown (a mark may be the frame's own
        # printed number at that place)
        for f in ls.draws:
            if f.get("rel") not in ("coordinate", "mark") or f["id"] in seen:
                continue
            p = (f.get("args") or [None])[0]
            if p in self.cent and self.vmap:
                v = _q((ls.ents.get(p) or {}).get("value")) if \
                    f["rel"] == "mark" else _q(f.get("value"))
                k = self.index_of_value(v)
                if k is not None and k.denominator == 1 and int(k) in \
                        self.frame_numbers and self.frame_numbers[int(k)][0] \
                        == v:
                    for e in self.frame_numbers[int(k)][5]:
                        self.of_obj.setdefault(p, set()).add(e.ref)
                    continue
            F.fail("CHK_NL_DRAWN_NOT_SHOWN", "GUIDES_ONLY_IF_STATED", "the "
                   "figure draws %s but prints no value for it" % f["id"],
                   obj=p)

    # ------------------------------------------------------------ jumps ---

    def _chord(self, ls, j):
        """(low, high) along the line of jump j's two ends, or None."""
        ent = ls.ents.get(j) or {}
        e = [self.cent.get(ent.get("from")), self.cent.get(ent.get("to"))]
        if None in e:
            return None
        a, b = self.along(e[0]), self.along(e[1])
        return (min(a, b), max(a, b))

    def _caption_over_chord(self, ls, j, box):
        """v6.12 fix_r1 (NS35): two jumps that share an end (-2 -> 3 -> 1):
        the long arc's arrowhead at the shared end can stand nearer the
        short arc's caption than the short arc's own arrowhead does, though
        the caption is plainly over its own arc. The caption belongs to arc
        j when its centre, along the line, lies over j's chord and j's chord
        midpoint is strictly the nearest of all the arcs' midpoints."""
        own = self._chord(ls, j)
        if own is None or box is None:
            return False
        cx = self.along(((box[0] + box[2]) / 2.0, (box[1] + box[3]) / 2.0))
        tol = 1.0
        if not (own[0] - tol <= cx <= own[1] + tol):
            return False
        dm = abs(cx - (own[0] + own[1]) / 2.0)
        for jj, _pts in self.arc_pts:
            if jj == j:
                continue
            ch = self._chord(ls, jj)
            if ch is not None and abs(cx - (ch[0] + ch[1]) / 2.0) <= dm + tol:
                return False
        return True
    def jumps(self):
        F, ls = self.F, self.ls
        arcs, heads = {}, {}
        for e in self.by.get("jump") or []:
            arcs.setdefault(e.fr, []).append(e)
        for e in self.by.get("jump-head") or []:
            heads.setdefault(e.fr, []).append(e)
        shown = sorted(j for j in ls.shown if ls.kind(j) == "jump")
        for j in sorted((set(arcs) | set(heads)) - set(shown)):
            F.fail("CHK_NL_JUMP_EXTRA", "GUIDES_ONLY_IF_STATED", "an arc for "
                   "%r, which the figure does not show" % j, obj=j)
        self.arc_pts = []
        tol_s = max(END_TOL, 0.0)
        for j in shown:
            ent = ls.ents[j]
            a_, h_ = arcs.get(j) or [], heads.get(j) or []
            if len(a_) != 1 or len(h_) != 1:
                F.fail("CHK_NL_JUMP_MISSING", "NL_JUMP_ENDS_AT_VALUES", "%s "
                       "has %d arcs and %d heads (one each)" % (
                           j, len(a_), len(h_)), obj=j)
                continue
            arc, head = a_[0], h_[0]
            self.of_obj.setdefault(j, set()).update([arc.ref, head.ref])
            pts = arc.pts()
            self.arc_pts.append((j, pts))
            fa, ta = ent["from"], ent["to"]
            if fa not in self.cent or ta not in self.cent:
                F.fail("CHK_NL_JUMP_ENDS", "NL_JUMP_ENDS_AT_VALUES", "%s: its "
                       "ends %s, %s are not both drawn" % (j, fa, ta), obj=j)
                continue
            sa, sb = self.along(self.cent[fa]), self.along(self.cent[ta])
            if abs(self.along(pts[0]) - sa) > tol_s:
                F.fail("CHK_NL_JUMP_ENDS", "NL_JUMP_ENDS_AT_VALUES", "%s "
                       "starts %.2f px from %s" % (
                           j, self.along(pts[0]) - sa, fa), obj=j)
            if any(self.across(p) <= 0 for p in pts):
                F.fail("CHK_NL_JUMP_SIDE", "NL_JUMP_ENDS_AT_VALUES", "%s dips "
                       "to the line or below it" % j, obj=j)
            hp = head.pts()
            if len(hp) != 3:
                F.fail("CHK_NL_JUMP_HEAD", "NL_JUMP_DIRECTION", "%s: the head "
                       "is no triangle" % j, obj=j)
                continue
            end = pts[-1]
            tip = max(hp, key=lambda p: math.hypot(p[0] - end[0],
                                                   p[1] - end[1]))
            wings = [p for p in hp if p is not tip]
            basec = ((wings[0][0] + wings[1][0]) / 2.0,
                     (wings[0][1] + wings[1][1]) / 2.0)
            if math.hypot(basec[0] - end[0], basec[1] - end[1]) > 1.0:
                F.fail("CHK_NL_JUMP_HEAD", "NL_JUMP_DIRECTION", "%s: the head "
                       "is not on the arc's end" % j, obj=j)
            if abs(self.along(tip) - sb) > tol_s:
                F.fail("CHK_NL_JUMP_ENDS", "NL_JUMP_ENDS_AT_VALUES", "%s ends "
                       "%.2f px from %s" % (j, self.along(tip) - sb, ta),
                       obj=j)
            if (self.along(tip) - self.along(end)) * (sb - sa) <= 0:
                F.fail("CHK_NL_JUMP_DIRECTION", "NL_JUMP_DIRECTION", "%s: the "
                       "head points back to its start" % j, obj=j)
            if self.across(tip) > self.r_of(ta) + 2.5:
                F.fail("CHK_NL_JUMP_ENDS", "NL_JUMP_ENDS_AT_VALUES", "%s: the "
                       "tip stops %.1f px above its end" % (
                           j, self.across(tip)), obj=j)
            self.arc_pts.append((j, [tip] + wings + [tip]))
        # captions of drawn given sizes
        drawn = dict((f["id"], f) for f in ls.draws)
        seen = set()
        for (fid, _at), els in sorted(self.groups("jump-val").items(),
                                      key=lambda x: str(x[0][0])):
            f = drawn.get(fid)
            if f is None or f.get("rel") != "jump_value" or \
                    f.get("value") is None:
                F.fail("CHK_NL_CAPTION_UNSTATED", "GUIDES_ONLY_IF_STATED",
                       "a jump caption for %r, no drawn given size" % fid)
                continue
            j = f["args"][0]
            seen.add(fid)
            v, shape, text, box, c = self.compose(els, "caption %s" % fid,
                                                  "NL_JUMP_CAPTION_OWNED_IF_ANY")
            for e in els:
                self.of_obj.setdefault(j, set()).add(e.ref)
            want = _q(f["value"])
            if v != want:
                F.fail("CHK_NL_CAPTION_WRONG", "NL_JUMP_CAPTION_OWNED_IF_ANY",
                       "%s prints %r, the given is %s" % (fid, text,
                                                           _disp(want)), obj=j)
            if want is not None and want > 0 and not text.startswith("+"):
                F.fail("CHK_NL_CAPTION_WRONG", "NL_JUMP_CAPTION_OWNED_IF_ANY",
                       "%s: a jump's size prints its sign (+%s)" % (
                           fid, _disp(want)), obj=j)
            # the size printed is the size drawn: (to - from) read off the
            # line through its printed numbers
            ent = ls.ents.get(j) or {}
            ends = [self.cent.get(ent.get("from")), self.cent.get(ent.get("to"))]
            if self.vmap is not None and None not in ends and want is not None:
                a_ = self.value_of_index(Fraction(
                    (self.along(ends[0]) - self.t0) / self.u).limit_denominator(
                        1000))
                b_ = self.value_of_index(Fraction(
                    (self.along(ends[1]) - self.t0) / self.u).limit_denominator(
                        1000))
                if abs(float((b_ - a_) - want)) > abs(float(self.vmap[1])) * \
                        PT_TOL / max(abs(self.u), 1e-6) + 1e-9:
                    F.fail("CHK_NL_JUMP_LENGTH", "NL_JUMP_ENDS_AT_VALUES", "%s "
                           "is drawn %s long, its caption says %s" % (
                               j, _disp(b_ - a_), _disp(want)), obj=j)
            own = [pts for jj, pts in self.arc_pts if jj == j]
            if own and box is not None:
                top = max(own[0], key=lambda p: self.across(p))
                d = _pt_box_d(top, box)
                others = [min(_pt_box_d(p, box) for p in pts)
                          for jj, pts in self.arc_pts if jj != j]
                if d > JUMP_CAP_NEAR or (any(o < d for o in others) and
                                         not self._caption_over_chord(
                                             ls, j, box)):
                    F.fail("CHK_NL_JUMP_CAPTION", "NL_JUMP_CAPTION_OWNED_IF_ANY",
                           "%s is not over its own arc" % fid, obj=j)
        for f in ls.draws:
            if f.get("rel") == "jump_value" and f["id"] not in seen:
                F.fail("CHK_NL_DRAWN_NOT_SHOWN", "GUIDES_ONLY_IF_STATED",
                       "the figure draws %s but prints no size" % f["id"],
                       obj=(f.get("args") or [None])[0])

    def r_of(self, p):
        m = self.mark.get(p)
        if m is None:
            return 3.2
        if m.tag == "circle":
            return float(m.a.get("r", "3.2"))
        ps, c = m.pts(), self.cent[p]
        return max(math.hypot(x - c[0], y - c[1]) for x, y in ps)

    # -------------------------------------------------------- intervals ---
    def intervals(self):
        F, ls = self.F, self.ls
        bars = {}
        for e in self.by.get("ivl") or []:
            bars.setdefault(e.fr, []).append(e)
        shown = sorted(i for i in ls.shown if ls.kind(i) == "interval")
        for i in sorted(set(bars) - set(shown)):
            F.fail("CHK_NL_IVL_EXTRA", "NL_SOLUTION_NOT_DRAWN", "a bar for %r, "
                   "which the figure does not show" % i, obj=i)
        ends = {}
        for i in shown:
            ent = ls.ents[i]
            for end, inn in ((ent["lo"], ent["lo_in"]),
                             (ent["hi"], ent["hi_in"])):
                ends.setdefault(end, set()).add(bool(inn))
            b = bars.get(i) or []
            if len(b) != 1:
                F.fail("CHK_NL_IVL_MISSING", "NL_INTERVAL_ENDS_AT_VALUES", "%s "
                       "has %d bars" % (i, len(b)), obj=i)
                continue
            bar = b[0]
            self.of_obj.setdefault(i, set()).add(bar.ref)
            (p, q) = bar.pts()
            if abs(self.across(p)) > ON_AXIS_TOL or \
                    abs(self.across(q)) > ON_AXIS_TOL:
                F.fail("CHK_NL_IVL_OFF_AXIS", "NL_INTERVAL_ENDS_AT_VALUES",
                       "%s: the bar is not on the line" % i, obj=i)
            s0, s1 = sorted((self.along(p), self.along(q)))
            for end, inn, s, sgn in ((ent["lo"], ent["lo_in"], s0, 1),
                                     (ent["hi"], ent["hi_in"], s1, -1)):
                if end not in self.cent:
                    F.fail("CHK_NL_IVL_ENDS", "NL_INTERVAL_ENDS_AT_VALUES",
                           "%s: its end %s is not drawn" % (i, end), obj=i)
                    continue
                self.of_obj.setdefault(i, set()).add(self.mark[end].ref)
                want = self.along(self.cent[end]) + (
                    0.0 if inn else sgn * self.r_of(end))
                if abs(s - want) > END_TOL:
                    F.fail("CHK_NL_IVL_ENDS", "NL_INTERVAL_ENDS_AT_VALUES",
                           "%s: the bar ends %.2f px from %s" % (
                               i, s - want, end), obj=i)
        for p, m in sorted(self.mark.items()):
            want = ends.get(p)
            if want is None:
                if m.tag != "circle":
                    F.fail("CHK_NL_ENDPOINT", "NL_INTERVAL_ENDPOINTS_OPEN_CLOSED",
                           "%s is a ring but no open end of a shown interval"
                           % p, obj=p)
                continue
            if len(want) > 1:
                F.fail("CHK_NL_ENDPOINT", "NL_INTERVAL_ENDPOINTS_OPEN_CLOSED",
                       "%s is an open and a closed end" % p, obj=p)
                continue
            closed = list(want)[0]
            if closed != (m.tag == "circle"):
                F.fail("CHK_NL_ENDPOINT", "NL_INTERVAL_ENDPOINTS_OPEN_CLOSED",
                       "%s is drawn %s, the interval declares it %s" % (
                           p, "closed" if m.tag == "circle" else "open",
                           "closed" if closed else "open"), obj=p)
                for i in shown:
                    if p in (ls.ents[i]["lo"], ls.ents[i]["hi"]):
                        F.fail("CHK_NL_ENDPOINT",
                               "NL_INTERVAL_ENDPOINTS_OPEN_CLOSED",
                               "%s: end %s flipped" % (i, p), obj=i)

    # ------------------------------------------------------------ spans ---
    def zero_pos(self):
        return self.pos_of_value(0)

    def spans(self, om):
        F, ls = self.F, self.ls
        drawn = dict((f["id"], f) for f in ls.draws)
        for e in self.by.get("span") or []:
            f = drawn.get(e.fr)
            if f is None or f.get("rel") not in ("distance", "abs_value") or \
                    f.get("value") is None or f.get("role") not in (
                        "given", "context"):
                F.fail("CHK_NL_SPAN_UNSTATED", "GUIDES_ONLY_IF_STATED", "a "
                       "bracket for %r, which is no drawn given distance"
                       % e.fr)
                continue
            ends = self.span_ends(f)
            self.of_obj.setdefault(f["id"], set()).add(e.ref)
            ps = e.pts()
            if ends is None or len(ps) != 4:
                F.fail("CHK_NL_SPAN", "NL_ABS_AS_DISTANCE_FROM_ZERO", "%s: the "
                       "bracket's ends cannot be measured" % f["id"],
                       obj=f["id"])
                continue
            got = sorted((self.along(ps[0]), self.along(ps[3])))
            if abs(got[0] - min(ends)) > END_TOL or \
                    abs(got[1] - max(ends)) > END_TOL:
                F.fail("CHK_NL_SPAN", "NL_ABS_AS_DISTANCE_FROM_ZERO" if
                       f["rel"] == "abs_value" else
                       "NL_ENDS_AT_VALUES_IF_DRAWN", "%s: the bracket does "
                       "not span its ends" % f["id"], obj=f["id"])
            if any(self.across(p) <= 0 for p in ps):
                F.fail("CHK_NL_SPAN", "NL_ENDS_AT_VALUES_IF_DRAWN", "%s: the "
                       "bracket is not above the line" % f["id"], obj=f["id"])
        for (fid, _at), els in sorted(self.groups("span-val").items(),
                                      key=lambda x: str(x[0][0])):
            f = drawn.get(fid)
            if f is None or f.get("value") is None:
                F.fail("CHK_NL_SPAN_UNSTATED", "GUIDES_ONLY_IF_STATED", "a "
                       "bracket value for %r" % fid)
                continue
            v, shape, text, box, c = self.compose(els, "bracket %s" % fid,
                                                  "NL_DISTANCE_NOT_SHOWN")
            for e in els:
                self.of_obj.setdefault(fid, set()).add(e.ref)
            if v != _q(f["value"]):
                F.fail("CHK_NL_CAPTION_WRONG", "NL_ABS_AS_DISTANCE_FROM_ZERO",
                       "%s prints %r, the given is %s" % (
                           fid, text, _disp(_q(f["value"]))), obj=fid)
        # the span objects of the map: their ends are the measured places
        for oid, o in sorted(((om or {}).get("objects") or {}).items()):
            if o.get("kind") != "span":
                continue
            f = ls.facts.get(oid)
            for part in o.get("parts") or []:
                if isinstance(part.get("span"), list):
                    ends = self.ends_px(part["span"])
                    if ends is None:
                        F.fail("CHK_MAP_SPAN", "HIGHLIGHT_ON_MEASURED_GEOMETRY",
                               "%s: span %s names no drawn places" % (
                                   oid, part["span"]), obj=oid)
                        continue
                    self.of_obj.setdefault(oid, set()).add(part["element"])
                    if part["element"] != self.axis_el.ref:
                        F.fail("CHK_MAP_SPAN", "HIGHLIGHT_ON_MEASURED_GEOMETRY",
                               "%s: a span lies on the axis, not %s" % (
                                   oid, part["element"]), obj=oid)
                    if f is not None and sorted(part["span"]) != sorted(
                            self.fact_places(f) or []):
                        F.fail("CHK_MAP_SPAN", "NL_ENDS_AT_VALUES_IF_DRAWN",
                               "%s: span %s, the fact is between %s" % (
                                   oid, part["span"], self.fact_places(f)),
                               obj=oid)
                    px = part.get("px")
                    if px is not None:
                        got = sorted(self.along(tuple(p)) for p in px)
                        if abs(got[0] - min(ends)) > END_TOL or \
                                abs(got[1] - max(ends)) > END_TOL or \
                                any(abs(self.across(tuple(p))) > ON_AXIS_TOL
                                    for p in px):
                            F.fail("CHK_MAP_SPAN",
                                   "HIGHLIGHT_ON_MEASURED_GEOMETRY",
                                   "%s: the span's px ends are not the "
                                   "measured places" % oid, obj=oid)

    def fact_places(self, f):
        rel, args = f.get("rel"), f.get("args") or []
        if rel == "distance" and len(args) == 2:
            return list(args)
        if rel == "abs_value" and args:
            return ["0", args[0]]
        if rel == "jump_value" and args:
            e = self.ls.ents.get(args[0]) or {}
            return [e.get("from"), e.get("to")]
        if rel == "count_integers" and args:
            e = self.ls.ents.get(args[0]) or {}
            return [e.get("lo"), e.get("hi")]
        return None

    def ends_px(self, names):
        out = []
        for x in names:
            if x == "0":
                z = self.zero_pos()
                if z is None:
                    return None
                out.append(z)
            elif x in self.cent:
                out.append(self.along(self.cent[x]))
            else:
                return None
        return out

    def span_ends(self, f):
        pl = self.fact_places(f)
        return None if pl is None else self.ends_px(pl)

    # ------------------------------------------------------------ leaks ---
    def leaks(self, guard):
        F, ls = self.F, self.ls
        texts_nonframe = []
        for base in ("val", "jump-val", "span-val"):
            for (fid, _at), els in self.groups(base).items():
                texts_nonframe.append((fid, els))
        for f in ls.q_facts():
            role, rel, args = f.get("role"), f.get("rel"), f.get("args") or []
            if role == "to_plot" and args:
                what = args[0]
                for e in self.els:
                    if e.fr == what:
                        F.fail("CHK_NL_PLOT_DRAWN", "NL_NOT_DRAWN_ANY_FORM",
                               "%s draws %s, which the student plots (%s)" % (
                                   e.ref, what, f["id"]), obj=what)
                v = _q((ls.ents.get(what) or {}).get("value")) if \
                    ls.kind(what) == "number" else ls.public_value(what)
                self.not_drawn.append(what)
                x = self.pos_of_value(v) if v is not None else None
                if x is None:
                    continue
                for p, c in sorted(self.cent.items()):
                    if abs(self.along(c) - x) <= PLOT_TOL:
                        F.fail("CHK_NL_PLOT_DRAWN", "NL_NOT_DRAWN_ANY_FORM",
                               "a marker (%s) stands where the student "
                               "plots %s" % (p, _disp(v)), obj=what)
                for fid, els in texts_nonframe:
                    for e in els:
                        b = self.box(e)
                        cx = self.along(((b[0] + b[2]) / 2, (b[1] + b[3]) / 2))
                        if abs(cx - x) <= PLOT_TOL + 3.0 and \
                                _parse_plain(e.text or "") == v:
                            F.fail("CHK_NL_PLOT_DRAWN",
                                   "NL_NOT_DRAWN_ANY_FORM", "%s prints %s at "
                                   "the place the student plots" % (
                                       e.ref, _disp(v)), obj=what)
            if role != "target":
                continue
            if rel == "coordinate" and args:
                for fid, els in texts_nonframe:
                    ff = ls.facts.get(fid) or {}
                    if (ff.get("args") or [None])[0] == args[0] and \
                            ff.get("rel") == "coordinate":
                        F.fail("CHK_NL_TARGET_SHOWN", "TARGET_VALUE_NOT_SHOWN",
                               "%s prints the value of %s, which %s asks" % (
                                   fid, args[0], f["id"]), obj=args[0])
            elif rel == "interval_value":
                ks = sorted(k for k, g in self.frame_numbers.items())
                if any(b - a == 1 for a, b in zip(ks, ks[1:])):
                    F.fail("CHK_NL_TARGET_SHOWN", "TARGET_VALUE_NOT_SHOWN",
                           "two neighbouring ticks print their numbers: the "
                           "interval value %s asks is printed" % f["id"])
            elif rel == "jump_value" and args:
                if self.groups("jump-val") and any(
                        (ls.facts.get(fid) or {}).get("args") == args
                        for (fid, _a) in self.groups("jump-val")):
                    F.fail("CHK_NL_TARGET_SHOWN", "TARGET_VALUE_NOT_SHOWN",
                           "the size of %s is printed; %s asks it" % (
                               args[0], f["id"]), obj=args[0])
            elif rel in ("distance", "abs_value"):
                for e in self.by.get("span") or []:
                    ff = ls.facts.get(e.fr) or {}
                    if ff.get("rel") == rel and sorted(ff.get("args") or []) \
                            == sorted(args):
                        F.fail("CHK_NL_TARGET_SHOWN", "NL_DISTANCE_NOT_SHOWN",
                               "%s is drawn as a bracket; %s asks it" % (
                                   e.fr, f["id"]), obj=f["id"])
        # the harness's answer values: printed nowhere but the frame
        vals = set()
        for g in guard or []:
            v = g.get("answer") if isinstance(g, dict) else g
            for tok in _guard_numbers(v):
                vals.add(tok)
        if vals:
            for fid, els in texts_nonframe:
                ff = ls.facts.get(fid) or {}
                given = ff.get("role") in ("given", "context") and fid in [
                    x["id"] for x in ls.draws]
                v, _sh, text, _b, _c = self.compose(els, "caption %s" % fid,
                                                    "NO_ANSWER_ANYWHERE_SVG")
                if v is not None and (v in vals or abs(v) in vals) and \
                        not given:
                    F.fail("CHK_ANSWER_EXPOSED", "NO_ANSWER_ANYWHERE_SVG",
                           "%r printed by %s is an answer" % (text, fid))
            for e in self.els:
                for k, a in e.a.items():
                    if k.startswith("data-") and k != "data-at":
                        for tok in re.findall(r"num:(-?[0-9/.]+)", a):
                            if _q(tok) in vals and ls.kind("num:" + tok) \
                                    and ("num:" + tok) not in ls.shown:
                                F.fail("CHK_ANSWER_EXPOSED",
                                       "NO_ANSWER_ANYWHERE_SVG", "%s names "
                                       "the answer %s in %s" % (e.ref, tok, k))

    # ------------------------------------------------------------ texts ---
    def texts(self):
        F = self.F
        texts = [e for e in self.els if e.tag == "text"]
        strokes = []
        for e in self.els:
            if e.tag == "line":
                strokes.append((e, e.pts()))
            elif e.tag in ("path", "polygon"):
                ps = e.pts()
                if e.tag == "polygon":
                    ps = ps + ps[:1]
                strokes.append((e, ps))
        grp = {}
        for e in self.els:
            b = _base(e.hook or "")
            if b:
                grp[e.ref] = (b, e.fr, e.at)
        for t in texts:
            b = self.box(t)
            if b[0] < CANVAS_MARGIN or b[1] < CANVAS_MARGIN or \
                    b[2] > self.W - CANVAS_MARGIN or \
                    b[3] > self.H - CANVAS_MARGIN:
                F.fail("CHK_NL_TEXT_CUT", "TEXT_BOX_IN_CANVAS", "%s %r reaches "
                       "past the canvas (%s)" % (
                           t.ref, t.text, [round(v, 1) for v in b]),
                       obj=self._obj_of(t))
            core = _grow(b, -CORE_SHRINK)
            if core[2] <= core[0] or core[3] <= core[1]:
                core = b
            for s, ps in strokes:
                if grp.get(s.ref) and grp.get(s.ref) == grp.get(t.ref):
                    continue            # a fraction's own bar
                ln = sum(_seg_in_box_len(p, q, core)
                         for p, q in zip(ps, ps[1:]))
                if ln > 0.2:
                    F.fail("CHK_NL_TEXT_CROSSED", "NL_NUMBERS_NOT_CUT", "%s %r "
                           "is crossed by %s (%s) for %.1f px" % (
                               t.ref, t.text, s.ref, s.hook, ln),
                           obj=self._obj_of(t))
            for p, c in sorted(self.cent.items()):
                if _pt_box_d(c, b) < self.r_of(p) * 0.5:
                    F.fail("CHK_NL_TEXT_COVERS", "TEXT_NOT_COVERING_MARKS",
                           "%s %r covers the marker of %s" % (t.ref, t.text,
                                                              p),
                           obj=self._obj_of(t))
        for i, a in enumerate(texts):
            for bb in texts[i + 1:]:
                if grp.get(a.ref) and grp.get(a.ref) == grp.get(bb.ref):
                    continue
                if _overlap(self.box(a), self.box(bb), MERGE_GAP):
                    F.fail("CHK_NL_TEXT_MERGED", "NL_NUMBERS_NOT_CUT", "%s %r "
                           "and %s %r touch: they read as one" % (
                               a.ref, a.text, bb.ref, bb.text),
                           obj=self._obj_of(a))

    def _obj_of(self, e):
        for o, refs in self.of_obj.items():
            if e.ref in refs and o != self.ls.axis:
                return o
        return None

    # -------------------------------------------------------- object map --
    def objmap(self, om):
        F, ls = self.F, self.ls
        chk = "OBJMAP_TOTAL_NO_UNMAPPED_INK"
        if om is None:
            return
        refs = set(e.ref for e in self.els)
        byref = dict((e.ref, e) for e in self.els)
        if set(om.get("elements") or {}) != refs:
            F.fail("CHK_MAP_NOT_TOTAL", chk, "map elements %d vs drawn %d "
                   "(unmapped %s, phantom %s)" % (
                       len(om.get("elements") or {}), len(refs),
                       sorted(refs - set(om.get("elements") or {}))[:5],
                       sorted(set(om.get("elements") or {}) - refs)[:5]))
        owner = {}
        for it in om.get("display_items") or []:
            role = it.get("role")
            hooks = ROLE_HOOKS.get(role)
            if hooks is None:
                F.fail("CHK_MAP_ROLE", chk, "%s: role %r" % (it.get("id"),
                                                             role))
                continue
            src = it.get("source") or {}
            for r in it.get("elements") or []:
                if r in owner:
                    F.fail("CHK_MAP_SHARED", chk, "%s is in %s and %s" % (
                        r, owner[r], it["id"]))
                owner[r] = it.get("id")
                e = byref.get(r)
                if e is None:
                    continue
                if e.hook not in hooks:
                    F.fail("CHK_MAP_ROLE", chk, "%s (%s) in a %s item" % (
                        r, e.hook, role))
                want = src.get("fact") if role in (
                    "value_caption", "jump_caption", "span_bracket",
                    "span_caption") else src.get("entity")
                if e.fr != want:
                    F.fail("CHK_MAP_SOURCE", chk, "%s draws %r, its item %s "
                           "names %r" % (r, e.fr, it.get("id"), want))
                if role in ("tick", "tick_number") and src.get("at") != e.at:
                    F.fail("CHK_MAP_SOURCE", chk, "%s is tick %s, its item "
                           "says %s" % (r, e.at, src.get("at")))
                if "text" in it and role not in ("tick_number",
                                                 "value_caption",
                                                 "jump_caption",
                                                 "span_caption") and \
                        e.tag == "text" and it["text"] != e.text:
                    F.fail("CHK_MAP_TEXT", chk, "%s prints %r, the map says "
                           "%r" % (r, e.text, it["text"]))
            if src.get("fact") and src["fact"] not in ls.facts:
                F.fail("CHK_MAP_SOURCE", chk, "%s: fact %r is not public" % (
                    it.get("id"), src["fact"]))
            if src.get("entity") and src["entity"] not in ls.ents:
                F.fail("CHK_MAP_SOURCE", chk, "%s: entity %r is not public"
                       % (it.get("id"), src["entity"]))
        for r in sorted(refs - set(owner)):
            F.fail("CHK_MAP_NOT_TOTAL", chk, "%s is drawn by no display item"
                   % r)
        for r, rec in sorted((om.get("elements") or {}).items()):
            if owner.get(r) != rec.get("item") or (
                    r in byref and rec.get("tag") != byref[r].tag):
                F.fail("CHK_MAP_NOT_TOTAL", chk, "%s: elements says %r, the "
                       "items %r" % (r, rec, owner.get(r)))
        objs = om.get("objects") or {}
        need = set(e for e in ls.shown if ls.kind(e) in (
            "point", "number", "jump", "interval", "axis"))
        for o in sorted(need - set(objs)):
            F.fail("CHK_MAP_OBJECT_MISSING", chk, "the map has no object %s"
                   % o, obj=o)
        for oid, o in sorted(objs.items()):
            got = set(p.get("element") for p in o.get("parts") or [])
            mine = self.of_obj.get(oid)
            if mine is None and o.get("kind") == "number":
                mine = self._frame_number(oid)
            if mine is None and o.get("kind") == "tick":
                mine = self._tick_obj(oid)
            if mine is None:
                F.review("CHK_MAP_OBJECT_UNMEASURED", chk, "object %s: the "
                         "checker measures no element of it" % oid, obj=oid)
                continue
            if got != mine:
                F.fail("CHK_MAP_PARTS", chk, "object %s: map parts %s, "
                       "measured %s" % (oid, sorted(got), sorted(mine)),
                       obj=oid)
            self.of_obj[oid] = set(mine)

    def _frame_number(self, oid):
        v = _q((self.ls.ents.get(oid) or {}).get("value"))
        if v is None or self.vmap is None:
            return None
        k = self.index_of_value(v)
        if k is None or k.denominator != 1 or int(k) not in \
                self.frame_numbers:
            return None
        k = int(k)
        return set([self.tick_el[k].ref] + [e.ref for e in
                                            self.frame_numbers[k][5]])

    def _tick_obj(self, oid):
        ent = self.ls.ents.get(oid) or {}
        k = self.index_of_value(_q(ent.get("at"))) if self.vmap else None
        if k is None or k.denominator != 1 or int(k) not in self.tick_el:
            return None
        k = int(k)
        out = {self.tick_el[k].ref}
        if k in self.frame_numbers:
            out |= set(e.ref for e in self.frame_numbers[k][5])
        return out


def _disp(v):
    if v is None:
        return "?"
    s = _s(v)
    return s.replace("-", MINUS)


def _parse_plain(t):
    """a printed whole / decimal number ('−2.5', '+5', '3') -> Fraction;
    None for anything else (a hyphen-minus is not a minus)."""
    m = re.match(u"^([−+]?)([0-9]+(?:\\.[0-9]+)?)$", t or "")
    if not m:
        return None
    v = Fraction(m.group(2))
    return -v if m.group(1) == MINUS else v


def _guard_numbers(v):
    """the numbers an answer string names ('$-2.5 , -1$', '−4 , 2', '3/4')."""
    out = set()
    s = str(v or "")
    for ch in DASHES:
        s = s.replace(ch, "-")
    for tok in re.findall(r"-?\d+(?:\.\d+)?(?:/\d+)?", s):
        q = _q(tok)
        if q is not None:
            out.add(q)
    return out


# ------------------------------------------------------------------- OCR --
def _norm_read(t):
    """a read with every dash-like glyph as the hyphen (Vision returns -,
    en / em dash or U+2212 for the printed minus; the glyph itself is
    checked in the text, NL_MINUS_U2212). v6.13: the documented read fold
    of ocr_expect.fold_read -- also a Cyrillic / Greek capital of the same
    shape as a Latin one ('В' U+0412) -> the Latin capital."""
    from . import ocr_expect as X
    t = (t or "").replace(" ", "")
    for ch in DASHES:
        t = t.replace(ch, "-")
    return X.fold_read(t)


# (tile, glyph height) crops per label: Vision skips a lone glyph and a
# short signed number ('\u22125' read nothing at any height alone, '-5-5'
# at every height tiled twice; '\u22128' only at a few sizes / tilings), so
# short labels are read tiled, several ways: ONE confirming read suffices,
# no read at all is REVIEW, never a guess
OCR_PLAN_ONE = ((3, 40), (3, 32), (3, 52))
OCR_PLAN_MANY = ((1, 40), (2, 28), (2, 36), (2, 44), (4, 36), (4, 44), (1, 52))


def _split_sign(g):
    """(sign box, digits image) of a binarised crop whose first ink
    component (columns) is a horizontal bar at the digits' mid height;
    None otherwise."""
    bb = g.ink_bbox()
    if bb is None:
        return None
    g = g.crop(bb)
    cols = [any(r[x] < 128 for r in g.rows) for x in range(g.w)]
    x = 0
    while x < g.w and cols[x]:
        x += 1
    x1 = x
    while x < g.w and not cols[x]:
        x += 1
    if x1 == 0 or x >= g.w or x == x1:
        return None
    ys = [y for y, r in enumerate(g.rows) if any(v < 128 for v in r[:x1])]
    if not ys:
        return None
    h = ys[-1] - ys[0] + 1
    mid = (ys[0] + ys[-1]) / 2.0
    if x1 < 1.5 * h or not (0.25 * g.h <= mid <= 0.75 * g.h):
        return None
    return (0, ys[0], x1, ys[-1] + 1), g.crop((x, 0, g.w, g.h))


def _ocr_match(want, read, tile):
    """the read is the label (tiled `tile` times), char by char up to the
    confusables Vision cannot tell apart alone."""
    from . import ocr as O
    from . import ocr_expect as X
    for n in sorted(set([tile, 1, 2])):
        w = want * n
        if len(read) == len(w) and all(O.conf_eq(a, b) for a, b in
                                       zip(read, w)):
            return True
    # v6.13: >= 2 exact copies first, then only a dash / the label's own
    # look-alikes / junk (ocr_expect.tiled_read, 'consensus')
    if X.tiled_read(want, read, tile) == "consensus":
        return "consensus"
    return False


def _ocr_exact(want, read, tile):
    """the read is the label itself (1, 2 or `tile` copies), no look-alike
    substitution needed."""
    return any(read == want * n for n in set([tile, 1, 2]))


def _ocr(disp, els, F, keep_dir=None):
    """Read every number / letter from its crop of the final display.
    Returns {ref: {status, text, detail, reads}}. A lone sign run of a
    stacked fraction is read by its ink (a bar), not by OCR."""
    import tempfile
    from . import ocr as O
    labels, sign_runs = [], []
    for e in els:
        if e.tag != "text":
            continue
        (sign_runs if _run(e.hook or "") == "s" else labels).append(e)
    out = {}
    if not O.helper_ok():
        for e in labels:
            out[e.ref] = {"status": "OCR_ERROR", "text": e.text,
                          "detail": "OCR_UNAVAILABLE: no helper"}
        return out
    tmp = keep_dir or tempfile.mkdtemp(prefix="wspec_nl_ocr_")
    jobs = {}
    for e in labels:
        box = disp.boxes.get(e.ref)
        crop = disp.display.crop(box) if box else None
        ink = crop.ink_count() if crop is not None else 0
        want = _norm_read(e.text)
        out[e.ref] = {"text": e.text, "want": want, "reads": [],
                      "status": None, "detail": ""}
        if crop is None or ink == 0:
            out[e.ref].update(status="MISSING", detail="no ink where the "
                              "label should be")
            continue
        plan = OCR_PLAN_ONE if len(want) == 1 else OCR_PLAN_MANY
        for i, (tile, h) in enumerate(plan):
            img = O.prepare(crop, h, tile)
            if img is None:
                continue
            pth = os.path.join(tmp, "%s_%d.png" % (e.ref, i))
            with open(pth, "wb") as fh:
                fh.write(img.png())
            jobs[pth] = (e.ref, tile)
    reads = O.run_helper(sorted(jobs)) if jobs else {}
    errs = dict(getattr(reads, "errors", None) or {})
    # v6.13: expected-set matching on the crop for the look-alike pairs
    # O/0, 6/9, B/8 (ocr_expect.decide_glyphs; None = undecided), and a
    # look-alike read that is also another label of the figure is
    # ambiguous (as in ocr.read_labels / coord) unless the crop decides it
    from . import ocr_expect as X
    glyph = {}
    for e in labels:
        if out[e.ref]["status"] is None and \
                any(ch in X.PAIRS for ch in out[e.ref]["want"]):
            try:
                glyph[e.ref] = X.decide_glyphs(
                    X.glyph_crop(disp.display, disp.boxes.get(e.ref),
                                 e.a.get("font-size")),
                    e.text, X.text_renderer(e.a, disp.display.scale))
            except Exception:                           # noqa: BLE001
                glyph[e.ref] = {"verdict": None}
    others = [(e.ref, _norm_read(e.text)) for e in labels]
    for pth, (ref, tile) in sorted(jobs.items()):
        want = out[ref]["want"]
        gv = (glyph.get(ref) or {}).get("verdict")
        for (txt, conf, kind) in reads.get(pth, []):
            r = _norm_read(txt)
            m = _ocr_match(want, r, tile)
            rec = {"read": txt, "conf": round(conf, 3), "kind": kind,
                   "match": bool(m),
                   "bare": want.startswith("-") and
                   bool(_ocr_match(want[1:], r, tile))}
            if m == "consensus":
                rec["consensus"] = True
            if m and not _ocr_exact(want, r, tile):
                rec["lookalike"] = True
                riv = [t for r2, t in others if r2 != ref and t and
                       t != want and _ocr_match(t, r, tile)]
                if riv and gv == "expected":
                    rec["resolved_by_glyph"] = riv[0]
                elif riv:
                    rec["match"] = False
                    rec["ambiguous_with"] = riv[0]
            out[ref]["reads"].append(rec)
    for pth, why in sorted(errs.items()):
        ref = jobs[pth][0]
        if out[ref]["status"] is None:
            out[ref].update(status="OCR_ERROR", detail="OCR_UNAVAILABLE: %s"
                            % why)
    for ref, r in out.items():
        if r["status"]:
            continue
        tops = [x for x in r["reads"] if x["kind"] == "top" and
                x["conf"] >= T.OCR_MIN_CONF]
        want = r["want"]
        g = glyph.get(ref) or {}
        if g.get("verdict") == "rival":
            # v6.13: the crop shows the look-alike of a label character
            r["glyph"] = g
            same = [x for x in tops if x["match"] and not x.get("lookalike")]
            alike = [x for x in tops if x.get("lookalike") or
                     x.get("ambiguous_with")]
            if alike and not same:
                r["status"] = "WRONG_GLYPH"
                r["detail"] = ("expected %r: the crop shows its look-alike "
                               "(%s) and Vision reads %s" % (
                                   r["text"], g.get("chars"),
                                   sorted(set(x["read"] for x in alike))))
            else:
                r["status"] = "CONTRADICTS"
                r["detail"] = ("expected %r: the crop's shape is the "
                               "look-alike (%s), reads %s" % (
                                   r["text"], g.get("chars"),
                                   sorted(set(x["read"] for x in tops))))
            continue
        if any(x["match"] for x in tops):
            r["status"] = "CONFIRMED"
            first = [x for x in tops if x["match"]][0]
            r["detail"] = "read %r" % first["read"]
            if first.get("consensus"):
                r["detail"] += " (tiled copies agree)"
            if first.get("resolved_by_glyph"):
                r["detail"] += (" (look-alike of %r decided by the crop: %s)"
                                % (first["resolved_by_glyph"], g.get("chars")))
        elif tops and any(x.get("bare") for x in tops):
            r["status"] = "SIGN_LOST"
            r["detail"] = "read %s: the minus is not visible" % sorted(set(
                x["read"] for x in tops))
        elif tops:
            r["unread"] = ("CONTRADICTS", "expected %r, read %s" % (
                r["text"], sorted(set(x["read"] for x in tops))))
        else:
            r["unread"] = ("UNREAD", "ink present but Vision read nothing")
    # a signed number Vision does not read whole ('\u22128' at some
    # scales): its FIRST ink component must be the minus -- a bar at the
    # digits' mid height, wider than tall -- and the rest is read alone
    jobs2 = {}
    for e in labels:
        r = out[e.ref]
        if r["status"] is not None or not (e.text or "").startswith(MINUS) \
                or len(e.text) < 2:
            continue
        crop = disp.display.crop(disp.boxes.get(e.ref)).binarise()
        split = _split_sign(crop)
        if split is None:
            continue
        # v6.13: the bar must also be ONE solid run of rows (not '=' or a
        # broken bar: ocr_expect.is_minus_bar), and a 6 / 9 among the
        # digits read alone must be decided by its hole (the digits alone
        # lose the sign's orientation guard against an upside-down read)
        try:
            bar_ok, dig = X.split_signed(crop)
        except Exception:                               # noqa: BLE001
            bar_ok, dig = False, None
        if not bar_ok:
            continue
        want = _norm_read(e.text[1:])
        if any(ch in "69" for ch in want):
            gd = X.decide_glyphs(dig, want, X.text_renderer(
                e.a, disp.display.scale)) if dig is not None else {}
            if gd.get("verdict") != "expected":
                continue
        r["sign_ink"] = split[0]
        plan = OCR_PLAN_ONE if len(want) == 1 else OCR_PLAN_MANY
        for i, (tile, h) in enumerate(plan):
            img = O.prepare(split[1], h, tile)
            if img is None:
                continue
            pth = os.path.join(tmp, "%s_d%d.png" % (e.ref, i))
            with open(pth, "wb") as fh:
                fh.write(img.png())
            jobs2[pth] = (e.ref, tile, want)
    if jobs2:
        reads2 = O.run_helper(sorted(jobs2))
        for pth, (ref, tile, want) in sorted(jobs2.items()):
            for (txt, conf, kind) in reads2.get(pth, []):
                if kind == "top" and conf >= T.OCR_MIN_CONF and \
                        _ocr_match(want, _norm_read(txt), tile) and \
                        out[ref]["status"] is None:
                    out[ref]["status"] = "CONFIRMED"
                    out[ref]["detail"] = ("the minus by its ink (a bar), the "
                                          "digits read %r" % txt)
        jobs.update(dict((k, v[:2]) for k, v in jobs2.items()))
    for ref, r in out.items():
        if r["status"] is None and r.get("unread"):
            r["status"], r["detail"] = r["unread"]
    if not keep_dir:
        for pth in jobs:
            try:
                os.remove(pth)
            except OSError:
                pass
        try:
            os.rmdir(tmp)
        except OSError:
            pass
    for e in sign_runs:
        b = disp.boxes.get(e.ref)
        crop = disp.display.crop(b) if b else None
        ink = crop.ink_count() if crop is not None else 0
        bb = crop.binarise().ink_bbox() if crop is not None and ink else None
        if not ink or bb is None:
            out[e.ref] = {"status": "MISSING", "text": e.text,
                          "detail": "no ink where the sign should be"}
        elif (bb[2] - bb[0]) < 1.5 * (bb[3] - bb[1]):
            out[e.ref] = {"status": "CONTRADICTS", "text": e.text,
                          "detail": "the sign's ink is not a bar"}
        else:
            out[e.ref] = {"status": "CONFIRMED", "text": e.text,
                          "detail": "a horizontal bar (a lone sign is read "
                          "by its ink, not by OCR)"}
    return out


class _Disp(object):
    def __init__(self, display, boxes):
        self.display, self.boxes = display, boxes


# ------------------------------------------------------------ entrypoint --
def check_number_line(svg, object_map, public_spec, figure_id, ocr=True,
                      display_image=None, display_scale=None,
                      display_origin=(0.0, 0.0), answer_guard=None,
                      positions=None, png_out=None, keep_ocr_dir=None):
    """Check one finished number-line figure (see the module docstring).
    positions: {place id: value} the HARNESS supplies for places whose value
    is private (a point the student reads off); values only."""
    F = Findings()
    ls = LineSpec(public_spec, figure_id)
    if isinstance(svg, str) and not svg.lstrip().startswith("<"):
        with open(svg, "rb") as fh:
            svg = fh.read()
    raw = svg if isinstance(svg, bytes) else svg.encode("utf-8")
    D = load_dialect()
    els, W, H = read_svg(raw, D, F)
    rep = {"checker_version": CHECKER_VERSION, "family": "number_line",
           "figure": figure_id, "infrastructure": []}
    boxes, disp = {}, None
    if els:
        from . import raster as R
        if R.available():
            try:
                d = R.Display(raw.decode("utf-8"), W, H, image=display_image,
                              image_scale=display_scale,
                              image_origin=display_origin)
                refs = [e.ref for e in els if e.tag == "text"]
                boxes = dict((k, v) for k, v in d.text_boxes(refs).items()
                             if v)
                for r in refs:
                    if r not in boxes:
                        F.fail("CHK_NL_TEXT_NO_INK", "OCR_NL_NUMBERS", "%s "
                               "draws no ink" % r)
                disp = _Disp(d, boxes)
                if png_out:
                    d.save_png(png_out)
            except Exception as e:              # pragma: no cover
                F.review("CHK_RASTER_FAILED", "OCR_NL_NUMBERS", "the display "
                         "could not be rasterised: %s" % e)
        else:
            F.review("CHK_RASTER_UNAVAILABLE", "OCR_NL_NUMBERS", "PyMuPDF is "
                     "not installed: the final display is not seen")
    ck = _Check(els or [], W, H, ls, F, boxes, positions)
    if els and ck.axis() and ck.ticks():
        ck.numbers()
        ck.places()
        ck.names()
        ck.axis_name()
        ck.captions()
        ck.jumps()
        ck.intervals()
        ck.spans(object_map)
        ck.leaks(answer_guard)
        ck.texts()
        ck.objmap(object_map)
        if ocr and disp is not None:
            res = _ocr(disp, els, F, keep_dir=keep_ocr_dir)
            for ref, r in sorted(res.items()):
                e = [x for x in els if x.ref == ref][0]
                is_name = e.hook == "name"
                chk = "OCR_NL_LETTER_AT_POINT" if is_name else "OCR_NL_NUMBERS"
                obj = ck._obj_of(e)
                st = r.get("status")
                if st == "MISSING":
                    F.fail("CHK_OCR_MISSING", chk, "%s %r: %s" % (
                        ref, r.get("text"), r.get("detail")), obj=obj)
                elif st == "WRONG_GLYPH":
                    F.fail("CHK_OCR_WRONG_GLYPH", chk, "%s %r: %s" % (
                        ref, r.get("text"), r.get("detail")), obj=obj)
                elif st == "SIGN_LOST":
                    F.fail("CHK_OCR_SIGN_LOST", "NL_MINUS_U2212", "%s %r reads "
                           "without its minus" % (ref, r.get("text")), obj=obj)
                elif st == "OCR_ERROR":
                    F.review("CHK_OCR_UNAVAILABLE", chk, "%s: %s" % (
                        ref, r.get("detail")), obj=obj)
                    if "OCR_UNAVAILABLE" not in rep["infrastructure"]:
                        rep["infrastructure"].append("OCR_UNAVAILABLE")
                elif st in ("CONTRADICTS", "UNREAD"):
                    F.review("CHK_OCR_" + st, chk, "%s %r: %s" % (
                        ref, r.get("text"), r.get("detail")), obj=obj)
            rep["ocr"] = dict((k, {"status": v.get("status"),
                                   "text": v.get("text"),
                                   "detail": v.get("detail", "")})
                              for k, v in res.items())
        elif not ocr:
            rep["ocr"] = {}
    rep["findings"] = F.items
    checks = dict((c, PASS) for c in ALL_CHECKS)
    for f in F.items:
        if f["level"] in (FAIL, REVIEW) and f["check"] in checks:
            checks[f["check"]] = worst([checks[f["check"]], f["level"]])
    if not ocr:
        checks["OCR_NL_NUMBERS"] = checks["OCR_NL_LETTER_AT_POINT"] = NA
    rep["checks"] = checks
    rep["status"] = F.status()
    rep["measured"] = dict(ck.measured, elements_of=dict(
        (k, sorted(v)) for k, v in ck.of_obj.items()),
        boxes=dict((k, [round(x, 2) for x in v]) for k, v in boxes.items()))
    rep["measured"]["places_px"] = dict(
        (p, [round(c[0], 3), round(c[1], 3)]) for p, c in
        getattr(ck, "cent", {}).items())
    z = ck.zero_pos() if getattr(ck, "vmap", None) is not None else None
    if z is not None:
        rep["measured"]["zero_px"] = [round(v, 3) for v in (
            (z, ck.c0) if not ck.vert else (ck.c0, -z))]
    rep["objects"] = _objects(ck, ls, F, object_map)
    return rep


def _kind(eid, ls, om):
    k = ls.kind(eid)
    if k:
        return k
    o = ((om or {}).get("objects") or {}).get(eid) or {}
    return o.get("kind") or ("span" if eid in ls.facts else "point")


def _deps(eid, ls, om):
    k = _kind(eid, ls, om)
    ent = ls.ents.get(eid) or {}
    deps = set([ls.axis]) if eid != ls.axis else set()
    if k == "jump":
        deps |= {ent.get("from"), ent.get("to")}
    elif k == "interval":
        deps |= {ent.get("lo"), ent.get("hi")}
    elif k == "span":
        f = ls.facts.get(eid) or {}
        args = f.get("args") or []
        if f.get("rel") == "jump_value" and args:
            deps.add(args[0])
            j = ls.ents.get(args[0]) or {}
            deps |= {j.get("from"), j.get("to")}
        elif f.get("rel") == "count_integers" and args:
            i = ls.ents.get(args[0]) or {}
            deps |= {i.get("lo"), i.get("hi")}
        else:
            deps |= set(a for a in args if a in ls.ents)
    deps.discard(None)
    deps.discard(eid)
    return deps


def _concerns(f, eid, deps):
    o = f["object"]
    if o is None:
        return True
    return o == eid or o in deps


def _objects(ck, ls, F, om):
    objs = set(e for e in ls.shown) | set(((om or {}).get("objects") or {}))
    objs |= set(ck.not_drawn)
    any_fail = any(f["level"] == FAIL for f in F.items)
    out = {}
    for eid in sorted(o for o in objs if o):
        deps = _deps(eid, ls, om)
        mine = [f for f in F.items if _concerns(f, eid, deps) and
                f["level"] in (FAIL, REVIEW)]
        st = worst([f["level"] for f in mine] + ([FAIL] if any_fail else []))
        out[eid] = {"kind": _kind(eid, ls, om), "status": st,
                    "findings": [f["code"] for f in mine],
                    "depends_on": sorted(deps),
                    "blocked_by": sorted(set(
                        f["object"] for f in mine
                        if isinstance(f["object"], str) and
                        f["object"] != eid))}
    return out


def object_report(rep, eid):
    """The verdict of one scenario object: the figure-wide checks plus its
    own (a FAIL anywhere fails every object: a broken figure ships no
    object)."""
    o = rep["objects"].get(eid)
    if o is None:
        return {"status": REVIEW, "reason": "object %s is not in the "
                "figure's check report" % eid}
    deps = set(o.get("depends_on") or [])
    names = FIGURE_CHECKS + OBJECT_CHECKS.get(o["kind"], [])
    checks = dict((c, NA if rep["checks"].get(c, NA) == NA else PASS)
                  for c in names)
    for f in rep["findings"]:
        if _concerns(f, eid, deps) and f["level"] in (FAIL, REVIEW):
            checks[f["check"]] = worst([checks.get(f["check"], PASS),
                                        f["level"]])
    return {"status": o["status"], "checks": checks,
            "depends_on": sorted(deps),
            "blocked_by": list(o.get("blocked_by") or []),
            "infrastructure": list(rep.get("infrastructure") or []),
            "findings": [f for f in rep["findings"]
                         if _concerns(f, eid, deps)]}
