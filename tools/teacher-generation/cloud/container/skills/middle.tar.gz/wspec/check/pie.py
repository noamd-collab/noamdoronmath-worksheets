# -*- coding: utf-8 -*-
"""wspec.check.pie -- the INDEPENDENT checker of a PIE CHART figure (v6.16,
BRIEF_V616 PIE scope; the checks of v616/corpus_pie/SCORING_pie.txt s7 that
a figure decides). Owner: the pie engine.

It imports nothing from wspec.render and never reads the renderer's code.
It reads the renderer's OUTPUT (SVG + object map), the PUBLIC spec (a
private model / answer store is refused: check.spec.refuse_private) and the
dialect DATA file wspec/svg_dialect_pie.json; from the rest of wspec only
wspec.canon (numbers, units). The pie data are resolved HERE with exact
arithmetic of its own (a missing sector = the rest, an equal group = equal
shares), the RTL visual order of a label is computed HERE (UAX #9 subset),
and the drawing is MEASURED:

  * dialect: closed elements / attributes / hooks / grammar / alphabet,
    positional ids, layers, data-for of the hook's kind -- DIALECT_CLOSED;
    the figure's public frame in the pie grammar -- DIALECT_CLOSED;
  * data: every value > 0, sum exactly 100 % / 360 deg -- DATA_VALID (an
    invalid pie that was drawn at all FAILS REFUSES_INVALID_DATA);
  * wedges (SVG): one centre, one radius, arcs on the circle, the outline
    circle -- PIE_CIRCLE_ROUND; contiguous, no gap / overlap, 360 deg --
    PIE_FULL_TILING; each span = value x 3.6 / value (0.2 deg) --
    SECTOR_ANGLE_EXACT; the declared start / direction / cyclic order --
    SECTOR_ORDER_AS_DECLARED; stroke >= 0.5 pt, 3:1 against both fills,
    neighbours' fills differ -- SECTOR_BOUNDARIES_STROKED;
  * the same on a MuPDF raster (4 px per unit): the rim sampled every 5 deg
    (1 %), unpainted disc area (0.5 %), boundary rays found at 0.6r..0.9r
    (1.0 deg);
  * labels: exactly the declared inventory (a name per sector; a value
    label for each DRAWN GIVEN value only -- a missing sector's value is
    never printed: TARGET_VALUE_NOT_SHOWN), the form N% / N° / names as
    declared -- LABEL_FORM; the ink box (the text alone rasterised) inside
    its own wedge, or outside with a leader -- LABEL_OWNED; >= 7 pt, 1 pt
    clear of every stroke and label, 4.5:1 contrast -- LABEL_LEGIBLE;
    inside the canvas -- TEXT_BOX_IN_CANVAS; leaders from inside the own
    wedge to the label, crossing nothing -- LEADER_LINE_OWNED(_IF_ANY);
    legend -- LEGEND_MATCHES_SECTORS; total / caption as declared --
    TOTAL_AS_DECLARED, CAPTION_OWNED;
  * two parts: one line, disjoint, gap >= 10 % r -- TWO_PIES_LAYOUT; radii
    -- SAME_RADIUS_IF_DECLARED;
  * build circle: ONE empty circle (+ a declared centre dot), nothing in or
    at it -- BUILD_CIRCLE_EMPTY; 18..45 mm printed -- BUILD_CIRCLE_SIZE;
  * leaks: no hidden value (a missing / equal sector's value, an angle /
    percent the student finds, a target) and no answer_guard value in any
    text that is not its own given label, attribute or map text --
    TARGET_VALUE_NOT_SHOWN, ANSWER_NOT_EXPOSED; no mark (arc, tick, right
    mark, radius) anywhere -- MUST_NOT_DRAW;
  * OCR (macOS Vision, check.ocr) of every label with a Latin letter or a
    digit from its crop of the display -- OCR_SECTOR_LABELS;
  * (v6.16 r2, pie corpus ADDENDUM 1) a REGION (frame part "regions") is
    one undivided tile: nothing -- no ray, boundary, tick, arc, label, dot,
    leader, fill change -- strictly inside its angular range except its own
    wedge and its own declared value label, read in the RAW SVG (every
    element, also one outside the dialect), the object map and the raster
    -- REGION_UNDIVIDED; its span is its resolved extent (0.2 deg SVG,
    1.0 deg raster boundaries) -- REGION_EXTENT_EXACT (a wedge keeps
    SECTOR_ANGLE_EXACT); two or three discs (side by side / a row): one
    line, disjoint, gap >= 10 % r, inside the canvas, in the declared order
    read right to left -- MULTI_PIE_LAYOUT; a row's captions: one per disc,
    exactly as declared, under its own disc, no digit and no word of a whole
    or a count -- CAPTION_POLICY; every EMPTY disc (also in a row): its
    outline, a declared dot, its declared caption under it and nothing else
    -- BUILD_CIRCLE_EMPTY; the whole figure is the object "figure"
    (object_report / check_highlight; not an object-map entry);
  * the object map: total, one owner per element, roles vs hooks, sources
    vs data-for, texts vs the logical labels, every object's parts EXACTLY
    the elements measured for it -- OBJMAP_TOTAL_NO_UNMAPPED_INK,
    HIGHLIGHT_EXACT_ELEMENTS.

    rep = check_pie(svg, object_map, public_spec, figure_id, ...)
    object_report(rep, eid) / check.pie_hl.check_highlight(base, hl, rep, eid)
"""
import json
import math
import os
import re
import unicodedata
import xml.etree.ElementTree as ET
from fractions import Fraction

from .. import canon as C
from .report import (Findings, CheckerInputError, worst, FAIL, REVIEW,
                     NOTE, PASS, NA)
from .spec import refuse_private

CHECKER_VERSION = "wspec-check-pie/1"
HERE = os.path.dirname(os.path.abspath(__file__))
DIALECT_JSON = os.path.join(os.path.dirname(HERE), "svg_dialect_pie.json")
NS = "{http://www.w3.org/2000/svg}"
FAMILY = "pie_chart"

# tolerances (SCORING_pie.txt s7; px = SVG units, 0.75 pt per unit)
PT_PER_PX = 0.75
ANGLE_TOL = 0.2            # SVG spans / start (deg)
RASTER_ANGLE_TOL = 1.0     # raster boundary rays (deg)
TILE_TOL = 0.1             # contiguity and the 360 sum (deg)
CENTRE_FRAC = 0.005        # wedges share one centre (of r)
RADIUS_FRAC = 0.005        # arc radii / same size (of r)
ON_CIRCLE_PX = 0.05        # an arc end on the circle (2-decimal rounding)
ROUND_FRAC = 0.01          # raster rim radius variation
UNPAINTED_FRAC = 0.005     # raster unpainted disc share
STROKE_MIN_PT = 0.5
STROKE_CONTRAST = 3.0
TEXT_CONTRAST = 4.5
FONT_MIN_PT = 7.0
LABEL_CLEAR_PT = 1.0       # ink box to every stroke edge / other label box
CANVAS_MARGIN = 0.5
LEADER_END_PX = 4.0        # a leader ends this near its label's ink box (3 pt)
TWO_Y_PT = 1.0             # two parts' centres on one line
TWO_GAP_FRAC = 0.10        # two discs this far apart (of r)
BUILD_MM = (18.0, 45.0)
BUILD_EMPTY_PX = 6.0       # nothing within the circle's box grown by this
RASTER_SCALE = 4.0
MM_PER_PT = 25.4 / 72.0

FIGURE_CHECKS = [
    "DIALECT_CLOSED", "OBJMAP_TOTAL_NO_UNMAPPED_INK", "TEXT_BOX_IN_CANVAS",
    "DATA_VALID", "REFUSES_INVALID_DATA", "PIE_CIRCLE_ROUND",
    "PIE_FULL_TILING", "SECTOR_ANGLE_EXACT", "SECTOR_ORDER_AS_DECLARED",
    "SECTOR_BOUNDARIES_STROKED", "OCR_SECTOR_LABELS", "LABEL_OWNED",
    "LABEL_LEGIBLE", "LABEL_FORM", "LEADER_LINE_OWNED_IF_ANY",
    "LEADER_LINE_OWNED", "LEGEND_MATCHES_SECTORS", "TOTAL_AS_DECLARED",
    "CAPTION_OWNED", "TWO_PIES_LAYOUT", "SAME_RADIUS_IF_DECLARED",
    "BUILD_CIRCLE_EMPTY", "BUILD_CIRCLE_SIZE", "ANSWER_NOT_EXPOSED",
    "TARGET_VALUE_NOT_SHOWN", "MUST_NOT_DRAW", "HIGHLIGHT_EXACT_ELEMENTS",
    # (v6.16 r2, AAF1)
    "REGION_UNDIVIDED", "REGION_EXTENT_EXACT", "MULTI_PIE_LAYOUT",
    "CAPTION_POLICY"]
ALL_CHECKS = FIGURE_CHECKS
FIGURE_OBJECT = "figure"   # (v6.16 r2) the whole figure (AAF1 objects)
# (v6.16 r2) the checker's own copy of the row caption rule (AAF1
# CAPTION_POLICY): no digit, none of these words of a whole / a count
CAPTION_WHOLE_WORDS = (u"השלם", u"סה״כ", u"סך הכול", u"תלמידים", u"פריטים",
                       u"נשאלים", u"אנשים")
REGION_EDGE_PX = 0.75      # a point this near a boundary ray / the rim is ON it
REGION_OFF_RGB2 = 900      # raster: a sample this far (RGB^2) from the fill

HOOK_ROLE = {"wedge": "sector_wedge", "outline": "pie_outline",
             "leader": "leader_line", "swatch": "legend_swatch",
             "bcirc": "build_circle", "bdot": "center_dot",
             "name": "sector_name_label", "val": "sector_value_label",
             "leg": "legend_text", "cap": "caption", "total": "total_label",
             "bcap": "caption"}                               # v6.16 r2
HOOK_KIND = {"wedge": "sector", "leader": "sector", "swatch": "sector",
             "name": "sector", "val": "sector", "leg": "sector",
             "outline": "pie", "cap": "pie", "total": "pie",
             "bcirc": "build_circle", "bdot": "build_circle",
             "bcap": "build_circle"}                          # v6.16 r2
NUM = r"(?:0|[1-9][0-9]{0,3})(?:\.[0-9]{1,2})?"
WEDGE_RE = re.compile(r"^M (%s) (%s) L (%s) (%s)((?: A %s %s 0 0 1 %s %s)"
                      r"{1,8}) Z$" % ((NUM,) * 8))
ARC_RE = re.compile(r" A (%s) (%s) 0 0 1 (%s) (%s)" % ((NUM,) * 4))
LEADER_RE = re.compile(r"^M (%s) (%s)((?: L %s %s){1,2})$" % ((NUM,) * 4))
PT_RE = re.compile(r" L (%s) (%s)" % (NUM, NUM))
POINTS_RE = re.compile(r"^(%s),(%s) (%s),(%s) (%s),(%s) (%s),(%s)$"
                       % ((NUM,) * 8))
_HEB = u"א-ת"
ALPHA_RE = re.compile(u"^[%s׳״A-Za-z0-9 %%°.:,–-]+$" % _HEB)
TOTAL_WORDS = u"סך הכול: "


def load_dialect(path=DIALECT_JSON):
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def is_pie(spec, figure_id):
    for g in (spec or {}).get("figures") or []:
        if g.get("id") == figure_id:
            fr = g.get("frame")
            return isinstance(fr, dict) and fr.get("family") == FAMILY
    return False


def _q(v):
    try:
        a, _b, r = C.parse_exact(v)
    except Exception:                   # noqa: BLE001
        return None
    return a if r == 1 else None


def _dec(q):
    """a terminating rational as its decimal text, else None"""
    q = Fraction(q)
    d = q.denominator
    while d % 2 == 0:
        d //= 2
    while d % 5 == 0:
        d //= 5
    if d != 1:
        return None
    if q.denominator == 1:
        return str(q.numerator)
    s = "-" if q < 0 else ""
    q = abs(q)
    w = q.numerator // q.denominator
    f = q - w
    ds = ""
    while f:
        f *= 10
        g = f.numerator // f.denominator
        ds += str(g)
        f -= g
    return s + str(w) + "." + ds


def number_tokens(t):
    """whole-token numbers of a text (digits, optional .digits)"""
    return re.findall(r"(?<![0-9.])[0-9]+(?:\.[0-9]+)?(?![0-9])", t or "")


# ------------------------------------------------------------ own bidi ---
def _btype(c):
    if u"א" <= c <= u"ת" or c in u"׳״":
        return "R"
    if (u"A" <= c <= u"Z") or (u"a" <= c <= u"z"):
        return "L"
    if c.isdigit():
        return "EN"
    if c in u"%°":
        return "ET"
    if c in u".,:":
        return "CS"
    if c == u"-":
        return "ES"
    if c == u" ":
        return "WS"
    return "ON"


def has_rtl(t):
    return any(u"א" <= c <= u"ת" for c in t or "")


def visual(text):
    """UAX #9 visual order of an RTL label (rules W4-W7, N1-N2, I1-I2, L2;
    the checker's own implementation)."""
    if not has_rtl(text):
        return text
    ty = [_btype(c) for c in text]
    n = len(ty)
    for i in range(1, n - 1):
        if ty[i] in ("ES", "CS") and ty[i - 1] == ty[i + 1] == "EN":
            ty[i] = "EN"
    ch = True
    while ch:
        ch = False
        for i in range(n):
            if ty[i] == "ET" and ((i and ty[i - 1] == "EN") or
                                  (i + 1 < n and ty[i + 1] == "EN")):
                ty[i] = "EN"
                ch = True
    ty = ["ON" if x in ("ES", "CS", "ET") else x for x in ty]
    last = "R"
    for i in range(n):
        if ty[i] in ("L", "R"):
            last = ty[i]
        elif ty[i] == "EN" and last == "L":
            ty[i] = "L"
    i = 0
    while i < n:
        if ty[i] in ("WS", "ON"):
            j = i
            while j < n and ty[j] in ("WS", "ON"):
                j += 1
            b = "R" if i == 0 or ty[i - 1] in ("R", "EN") else "L"
            a = "R" if j == n or ty[j] in ("R", "EN") else "L"
            for k in range(i, j):
                ty[k] = b if a == b else "R"
            i = j
        else:
            i += 1
    lv = [1 if x == "R" else 2 for x in ty]
    out = list(text)
    i = 0
    while i < n:
        if lv[i] >= 2:
            j = i
            while j < n and lv[j] >= 2:
                j += 1
            out[i:j] = out[i:j][::-1]
            i = j
        else:
            i += 1
    return u"".join(out[::-1])


# ------------------------------------------------------------ colours ---
def _lum(hexc):
    c = [int(hexc[i:i + 2], 16) / 255.0 for i in (1, 3, 5)]
    c = [v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
         for v in c]
    return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]


def contrast(a, b):
    la, lb = _lum(a), _lum(b)
    return (max(la, lb) + 0.05) / (min(la, lb) + 0.05)


def _rgb(hexc):
    return tuple(int(hexc[i:i + 2], 16) for i in (1, 3, 5))


# ------------------------------------------------------------ geometry ---
def _ang(dx, dy):
    a = math.degrees(math.atan2(dx, -dy)) % 360.0
    return 0.0 if a >= 360.0 - 1e-9 else a


def _adiff(a, b):
    """signed smallest difference a - b in (-180, 180]"""
    d = (a - b) % 360.0
    return d - 360.0 if d > 180.0 else d


def _in_arc(a, lo, span, tol=0.0):
    return (a - lo) % 360.0 <= span + tol or \
        (a - lo) % 360.0 >= 360.0 - tol


def _pt_seg_d(p, a, b):
    vx, vy = b[0] - a[0], b[1] - a[1]
    L = vx * vx + vy * vy
    t = 0.0 if L == 0 else max(0.0, min(1.0, ((p[0] - a[0]) * vx +
                                            (p[1] - a[1]) * vy) / L))
    return math.hypot(p[0] - a[0] - t * vx, p[1] - a[1] - t * vy)


def _seg_seg_d(a, b, c, d):
    def cr(o, p, q):
        return (p[0] - o[0]) * (q[1] - o[1]) - (p[1] - o[1]) * (q[0] - o[0])
    d1, d2, d3, d4 = cr(c, d, a), cr(c, d, b), cr(a, b, c), cr(a, b, d)
    if ((d1 > 0) != (d2 > 0)) and ((d3 > 0) != (d4 > 0)):
        return 0.0
    return min(_pt_seg_d(a, c, d), _pt_seg_d(b, c, d), _pt_seg_d(c, a, b),
               _pt_seg_d(d, a, b))


def _seg_box_d(a, b, box):
    x0, y0, x1, y1 = box
    for p in (a, b):
        if x0 <= p[0] <= x1 and y0 <= p[1] <= y1:
            return 0.0
    sides = [((x0, y0), (x1, y0)), ((x1, y0), (x1, y1)),
             ((x1, y1), (x0, y1)), ((x0, y1), (x0, y0))]
    return min(_seg_seg_d(a, b, c, d) for c, d in sides)


def _box_gap(a, b):
    dx = max(a[0] - b[2], b[0] - a[2], 0.0)
    dy = max(a[1] - b[3], b[1] - a[3], 0.0)
    return math.hypot(dx, dy)


def _box_pt_far(box, c):
    return max(math.hypot(x - c[0], y - c[1]) for x in (box[0], box[2])
               for y in (box[1], box[3]))


def _box_pt_near(box, c):
    dx = max(box[0] - c[0], 0.0, c[0] - box[2])
    dy = max(box[1] - c[1], 0.0, c[1] - box[3])
    return math.hypot(dx, dy)


def _grow(b, d):
    return (b[0] - d, b[1] - d, b[2] + d, b[3] + d)


# ---------------------------------------------------------- the spec ---
class PieSpec(object):
    """The public facts of one pie figure (read with canon only)."""

    def __init__(self, spec, figure_id):
        refuse_private(spec)
        self.spec = spec
        self.ents = dict((e.get("id"), e) for e in spec.get("entities") or [])
        self.facts = dict((f.get("id"), f) for f in spec.get("facts") or [])
        figs = [g for g in spec.get("figures") or []
                if g.get("id") == figure_id]
        if not figs:
            raise CheckerInputError("figure %r is not in the public spec"
                                    % figure_id)
        self.fig = figs[0]
        self.fr = self.fig.get("frame") or {}
        if self.fr.get("family") != FAMILY:
            raise CheckerInputError("figure %s is not a pie figure"
                                    % figure_id)
        self.drawn = set(self.fig.get("draws") or [])
        self.parts = [p for p in self.fr.get("parts") or []
                      if isinstance(p, dict)]
        self.frame_problems = self._frame_shape()
        self.res = {}
        for p in self.parts:
            if p.get("part") == "pie":
                self.res[p.get("pie")] = self._resolve(p)

    def _frame_shape(self):
        out = []
        fk = {"family", "layout", "parts", "same_size", "shared_legend"}
        pk = {"part", "pie", "side", "unit", "order", "start", "direction",
              "names", "values", "outside", "caption", "fills",
              "regions"}                                        # v6.16 r2
        bk = {"part", "circle", "side", "centre_dot",
              "caption"}                                        # v6.16 r2
        for k in self.fr:
            if k not in fk:
                out.append("frame key %r" % k)
        lay = self.fr.get("layout")
        n_ok = {"single": (1,), "side_by_side": (2,), "row": (2, 3)}
        if lay not in n_ok or len(self.parts) not in n_ok[lay]:
            out.append("layout %r with %d parts" % (lay, len(self.parts)))
        if lay == "row" and (self.fr.get("same_size") is not True or
                             self.fr.get("shared_legend")):
            out.append("a row: same_size true, no shared legend")
        for i, p in enumerate(self.parts):
            keys = pk if p.get("part") == "pie" else bk
            if p.get("part") not in ("pie", "build"):
                out.append("part %d: %r" % (i, p.get("part")))
                continue
            for k in p:
                if k not in keys:
                    out.append("part %d key %r" % (i, k))
            if "caption" in p and not (
                    isinstance(p["caption"], str) and
                    ALPHA_RE.match(p["caption"]) and
                    len(p["caption"]) <= 40):
                out.append("part %d: caption %r" % (i, p["caption"]))
            if lay == "row" and not p.get("caption"):
                out.append("part %d: a disc of a row has a caption" % i)
            if p.get("part") == "pie":
                if p.get("unit") not in ("percent", "degree", "fraction") or \
                        p.get("direction") not in ("clockwise",
                                                   "counterclockwise") or \
                        p.get("names") not in ("in_sector", "legend",
                                               "none") or \
                        p.get("values") not in ("in_sector", "legend",
                                                "none") or (
                            p.get("unit") == "fraction" and
                            p.get("values") != "none"):
                    out.append("part %d: unit / direction / names / values"
                               % i)
                st = p.get("start")
                if not (isinstance(st, int) and not isinstance(st, bool) and
                        0 <= st <= 359):
                    out.append("part %d: start %r" % (i, st))
                mine = sorted(e for e, v in self.ents.items()
                              if v.get("kind") == "sector" and
                              v.get("pie") == p.get("pie"))
                if sorted(p.get("order") or []) != mine:
                    out.append("part %d: order is not the pie's sectors" % i)
                regs = p.get("regions", [])
                if not isinstance(regs, list) or len(set(regs)) != len(
                        regs) or any(x not in mine for x in regs) or (
                            regs and (p.get("names") == "legend" or
                                      set(regs) & set(p.get("outside")
                                                      or []))):
                    out.append("part %d: regions %r" % (i, regs))
                for f in p.get("fills") or []:
                    if not re.match(r"^#[0-9a-f]{6}$", str(f)):
                        out.append("part %d: fill %r" % (i, f))
            else:
                if (self.ents.get(p.get("circle")) or {}).get("kind") != \
                        "build_circle":
                    out.append("part %d: circle %r" % (i, p.get("circle")))
        return out

    def _resolve(self, p):
        """exact values of a pie part (the checker's own arithmetic)"""
        unit = p.get("unit")
        total = {"percent": Fraction(100), "fraction": Fraction(1)}.get(
            unit, Fraction(360))
        ucode = {"percent": "%", "fraction": None}.get(unit, "deg")
        order = list(p.get("order") or [])
        val, src, problems, gfact = {}, {}, [], {}
        for s in order:
            for f in sorted(self.facts.values(), key=lambda f: f.get("id")):
                if f.get("rel") == "sector_value" and f.get("role") == \
                        "given" and (f.get("args") or [None])[0] == s:
                    v = _q(f.get("value"))
                    u = C.canon_unit(f.get("unit")) if f.get("unit") else \
                        None
                    if v is None or u != ucode:
                        problems.append("PIE_VALUE_UNIT %s" % s)
                        continue
                    if v <= 0:
                        problems.append("PIE_VALUE_NOT_POSITIVE %s = %s"
                                        % (s, _dec(v)))
                    val[s] = v
                    src[s] = "given"
                    gfact[s] = f["id"]
        groups = []
        for f in sorted(self.facts.values(), key=lambda f: f.get("id")):
            if f.get("rel") == "sector_equal" and f.get("role") == "given":
                a = [x for x in f.get("args") or [] if x in order]
                if len(a) == len(f.get("args") or []):
                    groups.append(set(a))
        merged = []
        for g in groups:
            for m in [m for m in merged if m & g]:
                merged.remove(m)
                g = g | m
            merged.append(g)
        for g in merged:
            vs = set(val[s] for s in g if s in val)
            if len(vs) > 1:
                problems.append("PIE_EQUAL_CONFLICT %s" % sorted(g))
            elif vs:
                v = vs.pop()
                for s in g:
                    if s not in val:
                        val[s], src[s] = v, "equal"
        unknown = [s for s in order if s not in val]
        rest = total - sum(val.values(), Fraction(0))
        if not unknown:
            if rest != 0:
                problems.append("PIE_SUM_NOT_TOTAL %s" % _dec(total - rest))
        else:
            one = len(unknown) == 1 or any(set(unknown) <= g for g in merged)
            if not one:
                problems.append("PIE_UNDERDETERMINED %s" % unknown)
            else:
                share = rest / len(unknown)
                if share <= 0:
                    problems.append("PIE_REST_NOT_POSITIVE %s" % _dec(rest))
                for s in unknown:
                    val[s] = share
                    src[s] = "rest" if len(unknown) == 1 else "equal"
        return {"unit": unit, "total": total, "order": order, "value": val,
                "source": src, "problems": problems, "given_fact": gfact,
                "part": p}

    def name(self, s):
        return (self.ents.get(s) or {}).get("name")

    def regions(self, pid=None):
        """(v6.16 r2) the sectors declared as undivided regions"""
        out = set()
        for p in self.parts:
            if p.get("part") == "pie" and (pid is None or
                                           p.get("pie") == pid):
                out |= set(x for x in p.get("regions") or []
                           if isinstance(x, str))
        return out

    def part_of(self, eid):
        for p in self.parts:
            if p.get("pie") == eid or p.get("circle") == eid:
                return p
        return None

    def pie_of(self, s):
        return (self.ents.get(s) or {}).get("pie")

    def drawn_value(self, s):
        """the drawn given sector_value fact of s, or None"""
        for fid in sorted(self.drawn):
            f = self.facts.get(fid) or {}
            if f.get("rel") == "sector_value" and f.get("role") == \
                    "given" and (f.get("args") or [None])[0] == s:
                return f
        return None

    def drawn_total(self, pie):
        for fid in sorted(self.drawn):
            f = self.facts.get(fid) or {}
            if f.get("rel") == "pie_total" and f.get("role") == "given" \
                    and (f.get("args") or [None])[0] == pie:
                return f
        return None

    def value_text(self, s):
        f = self.drawn_value(s)
        if f is None:
            return None
        r = self.res.get(self.pie_of(s)) or {}
        if r.get("unit") == "fraction":
            return None             # (v6.16 r2) a fraction prints no value
        t = _dec(_q(f.get("value")))
        if t is None:
            return None
        return t + ("%" if r.get("unit") == "percent" else u"°")

    def hidden(self):
        """values the student finds: never printed (checker's own list)"""
        out = set()
        for pid, r in self.res.items():
            if r["problems"]:
                continue
            for s in r["order"]:
                v = r["value"][s]
                ang = v * 360 / r["total"]
                if r["source"][s] != "given":
                    out.add(v)
                if r["unit"] == "fraction":
                    # (v6.16 r2) no number prints on a fraction pie
                    out.add(ang)
                    out.add(ang * 100 / 360)
                else:
                    out.add(ang if r["unit"] == "percent" else v * 100 / 360)
        return out


# ------------------------------------------------------------- the SVG ---
class El(object):
    def __init__(self, tag, a, text, layer, k):
        self.tag, self.a, self.text, self.layer = tag, a, text, layer
        self.ref = a.get("id")
        self.hook = a.get("data-pie")
        self.for_ = a.get("data-for")
        self.k = k

    def f(self, name):
        return float(self.a[name])


def read_svg(raw, D, F):
    """elements in the closed dialect (FAILs for anything else)."""
    def bad(detail):
        F.fail("CHK_PIE_DIALECT", "DIALECT_CLOSED", detail)
    txt = raw.decode("utf-8")
    if "<!" in txt or txt.count("<?") > (1 if txt.startswith(
            '<?xml version="1.0" encoding="UTF-8"?>') else 0):
        bad("prolog: a '<!' or a processing instruction")
    try:
        root = ET.fromstring(raw)
    except ET.ParseError as e:
        bad("not XML: %s" % e)
        return [], 0.0, 0.0
    num = re.compile(D["grammar"]["number"])
    if root.tag != NS + "svg":
        bad("root %s" % root.tag)
        return [], 0.0, 0.0
    ra = dict(root.attrib)
    if sorted(ra) != sorted(["viewBox", "width", "height"]):
        bad("svg attributes %s" % sorted(ra))
    try:
        vb = ra.get("viewBox", "").split(" ")
        W, H = float(ra["width"]), float(ra["height"])
        if vb != ["0", "0", ra["width"], ra["height"]] or not (
                num.match(ra["width"]) and num.match(ra["height"])):
            bad("viewBox / size %r" % ra)
    except (KeyError, ValueError):
        bad("svg size")
        return [], 0.0, 0.0
    if root.text and root.text.strip():
        bad("text directly in <svg>")
    els = []
    k = 0
    layers = [g.get("data-layer") for g in root]
    want = [x for x in D["layers"] if x in layers]
    if layers != want:
        bad("layers %s (closed order %s)" % (layers, D["layers"]))
    hooks = D["hooks"]
    allowed = D["elements"]
    fgrammar = re.compile(D["grammar"]["for"])
    hexre = re.compile(D["grammar"]["fill_hex"])
    for g in root:
        if g.tag != NS + "g" or sorted(g.attrib) != ["data-layer"]:
            bad("a top-level %s %r" % (g.tag.replace(NS, ""), g.attrib))
            continue
        lay = g.get("data-layer")
        for el in g:
            tag = el.tag.replace(NS, "")
            if tag not in allowed or tag in ("svg", "g"):
                bad("element %s" % tag)
                continue
            if len(el):
                bad("%s has children" % tag)
            a = dict(el.attrib)
            for key in a:
                if key not in allowed[tag]:
                    bad("%s attribute %r" % (tag, key))
            k += 1
            e = El(tag, a, el.text, lay, k)
            if e.ref != "e%04d" % k:
                bad("id %r at position %d" % (e.ref, k))
            h = hooks.get(e.hook)
            if h is None or h["element"] != tag or h["layer"] != lay:
                bad("%s hook %r in layer %s" % (e.ref, e.hook, lay))
            if not (e.for_ and fgrammar.match(e.for_)):
                bad("%s data-for %r" % (e.ref, e.for_))
            for key in ("x", "y", "cx", "cy", "r", "font-size",
                        "stroke-width"):
                if key in a and not num.match(a[key]):
                    bad("%s %s=%r" % (e.ref, key, a[key]))
            if tag == "text":
                t = e.text or ""
                if not ALPHA_RE.match(t) or t != unicodedata.normalize(
                        "NFC", t):
                    bad("%s text %r outside the alphabet" % (e.ref, t))
                if a.get("font-size") not in D["font_sizes"] or \
                        a.get("font-family") not in D["font_families"] or \
                        a.get("text-anchor") not in D["text_anchors"] or \
                        a.get("fill") not in D["text_fills"]:
                    bad("%s font / anchor / fill" % e.ref)
                ov = a.get("direction") == "ltr" and \
                    a.get("unicode-bidi") == "bidi-override"
                if has_rtl(t) != ov or (not ov and (
                        "direction" in a or "unicode-bidi" in a)):
                    bad("%s bidi override %s for %r" % (e.ref, ov, t))
            if tag == "path":
                d = a.get("d", "")
                rx = WEDGE_RE if e.hook == "wedge" else LEADER_RE
                if not rx.match(d):
                    bad("%s path d %r" % (e.ref, d[:60]))
                if e.hook == "wedge":
                    if not hexre.match(a.get("fill", "")) or (
                            a.get("stroke") != "none" and
                            a.get("stroke") not in D["stroke_colors"]):
                        bad("%s wedge fill / stroke" % e.ref)
                    if a.get("stroke") != "none" and a.get(
                            "stroke-width") != D["stroke_widths"]["wedge"]:
                        bad("%s wedge stroke-width" % e.ref)
                else:
                    if a.get("fill") != "none" or a.get("stroke") != \
                            "#000000" or a.get("stroke-width") != \
                            D["stroke_widths"]["leader"]:
                        bad("%s leader paint" % e.ref)
            if tag == "polygon":
                if not POINTS_RE.match(a.get("points", "")) or \
                        not hexre.match(a.get("fill", "")):
                    bad("%s swatch points / fill" % e.ref)
            if tag == "circle":
                if e.hook == "outline" and (a.get("fill") != "none" or
                                            a.get("stroke") not in
                                            D["stroke_colors"]):
                    bad("%s outline paint" % e.ref)
                if e.hook == "bcirc" and (a.get("fill") != "none" or
                                          a.get("stroke") != "#000000" or
                                          a.get("stroke-width") !=
                                          D["stroke_widths"]["build"]):
                    bad("%s build circle paint" % e.ref)
                if e.hook == "bdot" and (a.get("fill") != "#000000" or
                                         a.get("r") != D["dot_radius"]):
                    bad("%s centre dot" % e.ref)
            els.append(e)
    return els, W, H


# ------------------------------------------------------------ raster ---
class Raster(object):
    """The figure rasterised by MuPDF (RGB, RASTER_SCALE px per unit) and
    each text's ink box (the text alone, filled black)."""

    def __init__(self, svg_text, W, H):
        import pymupdf
        self.pymupdf = pymupdf
        self.svg, self.W, self.H = svg_text, W, H
        self.s = RASTER_SCALE
        doc = pymupdf.open(stream=svg_text.encode("utf-8"), filetype="svg")
        self.pm = doc[0].get_pixmap(matrix=pymupdf.Matrix(self.s, self.s),
                                    alpha=False)
        doc.close()
        self.w, self.h, self.n = self.pm.width, self.pm.height, self.pm.n
        self.samples = self.pm.samples
        self.stride = self.pm.stride

    def rgb(self, x, y):
        """pixel at SVG point (x, y), or None outside"""
        px, py = int(x * self.s), int(y * self.s)
        if not (0 <= px < self.w and 0 <= py < self.h):
            return None
        o = py * self.stride + px * self.n
        return tuple(self.samples[o:o + 3])

    def text_box(self, el_xml, pad=40.0):
        """ink box (SVG units) of one <text> rendered alone in black"""
        pymupdf = self.pymupdf
        one = re.sub(r'fill="#[0-9a-f]{6}"', 'fill="#000000"', el_xml)
        W, H = self.W + 2 * pad, self.H + 2 * pad
        svg = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="%s %s %s %s"'
               ' width="%s" height="%s">%s</svg>' % (
                   -pad, -pad, W, H, W, H, one))
        doc = pymupdf.open(stream=svg.encode("utf-8"), filetype="svg")
        pm = doc[0].get_pixmap(matrix=pymupdf.Matrix(self.s, self.s),
                               colorspace=pymupdf.csGRAY, alpha=False)
        doc.close()
        sm, st = pm.samples, pm.stride
        x0, y0, x1, y1 = pm.width, pm.height, -1, -1
        for y in range(pm.height):
            row = sm[y * st: y * st + pm.width]
            m = re.search(b"[\x00-\xf9]", row)
            if not m:
                continue
            last = pm.width - 1 - re.search(b"[\x00-\xf9]", row[::-1]).start()
            x0, x1 = min(x0, m.start()), max(x1, last)
            y0, y1 = min(y0, y), max(y1, y)
        if x1 < 0:
            return None
        return (x0 / self.s - pad, y0 / self.s - pad, (x1 + 1) / self.s - pad,
                (y1 + 1) / self.s - pad)

    def gray_crop(self, box, invert=False, pad=0.5):
        from .raster import Gray
        x0 = max(0, int((box[0] - pad) * self.s))
        y0 = max(0, int((box[1] - pad) * self.s))
        x1 = min(self.w, int((box[2] + pad) * self.s + 0.999))
        y1 = min(self.h, int((box[3] + pad) * self.s + 0.999))
        if x1 - x0 < 2 or y1 - y0 < 2:
            return None
        rows = []
        for y in range(y0, y1):
            o = y * self.stride
            row = bytearray()
            for x in range(x0, x1):
                p = self.samples[o + x * self.n: o + x * self.n + 3]
                g = int(0.299 * p[0] + 0.587 * p[1] + 0.114 * p[2])
                row.append(255 - g if invert else g)
            rows.append(bytes(row))
        return Gray(x1 - x0, y1 - y0, rows)


class _OcrDisplay(object):
    def __init__(self, ras, invert):
        self.ras, self.invert = ras, invert

    def crop(self, box, pad=0.5):
        return self.ras.gray_crop(box, self.invert, pad)


# ------------------------------------------------------------- checks ---
class _Check(object):
    def __init__(self, els, W, H, ps, F, raster, raw_text, print_pt_per_px):
        self.els, self.W, self.H, self.ps, self.F = els, W, H, ps, F
        self.ras = raster
        self.raw = raw_text
        self.ptpx = print_pt_per_px
        self.by_ref = dict((e.ref, e) for e in els)
        self.boxes = {}
        self.of_obj = {}
        self.measured = {"parts": []}
        self.pies = {}           # pid -> measured geometry
        self.label_owner = {}    # text ref -> sector / pie

    def fail(self, code, check, detail, obj=None):
        self.F.fail(code, check, detail, obj=obj)

    def review(self, code, check, detail, obj=None):
        self.F.review(code, check, detail, obj=obj)

    def own(self, obj, ref):
        if obj:
            self.of_obj.setdefault(obj, set()).add(ref)

    # ------------------------------------------------------------ kinds --
    def kinds(self):
        for e in self.els:
            want = HOOK_KIND.get(e.hook)
            got = (self.ps.ents.get(e.for_) or {}).get("kind")
            if want and got != want:
                self.fail("CHK_PIE_FOR_KIND", "DIALECT_CLOSED", "%s (%s) "
                          "draws %r, a %s, not a %s" % (e.ref, e.hook,
                                                        e.for_, got, want))
            listed = set(self.ps.fig.get("entities") or [])
            if e.for_ and e.for_ not in listed:
                self.fail("CHK_PIE_FOR_UNLISTED", "DIALECT_CLOSED", "%s "
                          "draws %s, not listed in the figure" % (
                              e.ref, e.for_))
        for p in self.ps.frame_problems:
            self.fail("CHK_PIE_FRAME", "DIALECT_CLOSED", p)

    # ------------------------------------------------------------- data --
    def data(self):
        for pid, r in sorted(self.ps.res.items()):
            if r["problems"]:
                self.fail("CHK_PIE_DATA_INVALID", "DATA_VALID", "%s: %s" % (
                    pid, "; ".join(r["problems"])), obj=pid)
                self.fail("CHK_PIE_INVALID_DRAWN", "REFUSES_INVALID_DATA",
                          "%s has invalid data and was drawn" % pid, obj=pid)

    # ----------------------------------------------------------- wedges --
    def parse_wedge(self, e):
        m = WEDGE_RE.match(e.a.get("d", ""))
        if not m:
            return None
        c = (float(m.group(1)), float(m.group(2)))
        pts = [(float(m.group(3)), float(m.group(4)))]
        radii = []
        for a in ARC_RE.finditer(m.group(5)):
            radii.append((float(a.group(1)), float(a.group(2))))
            pts.append((float(a.group(3)), float(a.group(4))))
        return {"c": c, "pts": pts, "radii": radii}

    def wedges(self):
        for part in self.ps.parts:
            if part.get("part") != "pie":
                continue
            pid = part.get("pie")
            r = self.ps.res[pid]
            ws = [e for e in self.els if e.hook == "wedge" and
                  self.ps.pie_of(e.for_) == pid]
            outl = [e for e in self.els if e.hook == "outline" and
                    e.for_ == pid]
            g = {"pid": pid, "wedges": {}, "outline": None, "part": part}
            self.pies[pid] = g
            if len(outl) != 1:
                self.fail("CHK_PIE_OUTLINE", "PIE_CIRCLE_ROUND", "%s: %d "
                          "outline circles" % (pid, len(outl)), obj=pid)
            elif outl[0].tag != "circle" or not all(
                    k in outl[0].a for k in ("cx", "cy", "r")):
                # (v6.16 integrate, runner finding P-F1) a finding, never
                # an exception: an outline that is no <circle> is not round
                self.fail("CHK_PIE_OUTLINE", "PIE_CIRCLE_ROUND", "%s: the "
                          "outline %s is a <%s>, not a circle" % (
                              pid, outl[0].ref, outl[0].tag), obj=pid)
            else:
                o = outl[0]
                g["outline"] = ((o.f("cx"), o.f("cy")), o.f("r"), o)
                self.own(pid, o.ref)
            seen = {}
            for e in ws:
                seen.setdefault(e.for_, []).append(e)
                self.own(e.for_, e.ref)
                self.own(pid, e.ref)
            for s in r["order"]:
                if len(seen.get(s, [])) != 1:
                    self.fail("CHK_PIE_WEDGE_COUNT", "PIE_FULL_TILING",
                              "%s: %d wedges" % (s, len(seen.get(s, []))),
                              obj=s)
            geo = {}
            for s, lst in seen.items():
                if s not in r["order"] or len(lst) != 1:
                    continue
                w = self.parse_wedge(lst[0])
                if w is None:
                    continue
                geo[s] = w
            if not geo:
                continue
            cs = [w["c"] for w in geo.values()]
            c0 = cs[0]
            rad = None
            if g["outline"]:
                c0, rad = g["outline"][0], g["outline"][1]
            else:
                rad = geo[sorted(geo)[0]]["radii"][0][0]
            g["c"], g["r"] = c0, rad
            for s, w in sorted(geo.items()):
                if math.hypot(w["c"][0] - c0[0], w["c"][1] - c0[1]) > \
                        CENTRE_FRAC * rad:
                    self.fail("CHK_PIE_CENTRE", "PIE_CIRCLE_ROUND", "%s: "
                              "centre %s, the pie's %s" % (s, w["c"], c0),
                              obj=s)
                for rx, ry in w["radii"]:
                    if abs(rx - ry) > 1e-9 or abs(rx - rad) > \
                            RADIUS_FRAC * rad:
                        self.fail("CHK_PIE_RADIUS", "PIE_CIRCLE_ROUND",
                                  "%s: arc radii %s / %s, the pie's %s" % (
                                      s, rx, ry, rad), obj=s)
                        break
                angs = []
                for p in w["pts"]:
                    d = math.hypot(p[0] - w["c"][0], p[1] - w["c"][1])
                    if abs(d - rad) > max(ON_CIRCLE_PX, RADIUS_FRAC * rad):
                        self.fail("CHK_PIE_OFF_CIRCLE", "PIE_CIRCLE_ROUND",
                                  "%s: a wedge point %.2f from the centre, "
                                  "r %.2f" % (s, d, rad), obj=s)
                    angs.append(_ang(p[0] - c0[0], p[1] - c0[1]))
                span = 0.0
                for a0, a1 in zip(angs, angs[1:]):
                    step = (a1 - a0) % 360.0
                    if len(angs) == 2 and step < 1e-9:
                        step = 360.0
                    if step > 90.05 or step < -1e-9:
                        self.fail("CHK_PIE_ARC_STEP", "DIALECT_CLOSED",
                                  "%s: an arc of %.2f deg" % (s, step), obj=s)
                    span += step
                if len(angs) > 2 and abs(angs[-1] - angs[0]) < 1e-6 and \
                        span < 1e-6:
                    span = 360.0
                w["lo"], w["span"] = angs[0], span
                w["hi"] = (angs[0] + span) % 360.0
            g["geo"] = geo
            self.tiling(g, r)
            self.angles(g, r)
            self.order(g, r)
            self.strokes(g, r, seen)

    def tiling(self, g, r):
        geo = g["geo"]
        pid = g["pid"]
        if len(geo) != len(r["order"]):
            return
        tot = sum(w["span"] for w in geo.values())
        if abs(tot - 360.0) > TILE_TOL:
            self.fail("CHK_PIE_SUM", "PIE_FULL_TILING", "%s: spans sum to "
                      "%.3f deg" % (pid, tot), obj=pid)
        if len(geo) < 2:
            return
        items = sorted(geo.items(), key=lambda kv: kv[1]["lo"])
        for (s, w), (s2, w2) in zip(items, items[1:] + items[:1]):
            d = _adiff(w2["lo"], w["lo"] + w["span"])
            if abs(d) > TILE_TOL:
                self.fail("CHK_PIE_GAP" if d > 0 else "CHK_PIE_OVERLAP",
                          "PIE_FULL_TILING", "%s ends at %.3f, %s starts at "
                          "%.3f" % (s, (w["lo"] + w["span"]) % 360, s2,
                                    w2["lo"]), obj=s)

    def angles(self, g, r):
        regs = self.ps.regions(g["pid"])
        for s, w in sorted(g["geo"].items()):
            v = r["value"].get(s)
            if v is None:
                continue
            want = float(v * 360 / r["total"])
            if abs(w["span"] - want) > ANGLE_TOL:
                if s in regs:
                    # (v6.16 r2) a region's extent (AAF1)
                    self.fail("CHK_PIE_REGION_SPAN", "REGION_EXTENT_EXACT",
                              "region %s: span %.3f deg, its extent is "
                              "%.3f" % (s, w["span"], want), obj=s)
                    continue
                self.fail("CHK_PIE_SPAN", "SECTOR_ANGLE_EXACT", "%s: span "
                          "%.3f deg, the data give %.3f" % (
                              s, w["span"], want), obj=s)

    def order(self, g, r):
        geo, part = g["geo"], g["part"]
        order = r["order"]
        if any(s not in geo for s in order):
            return
        cw = part.get("direction") == "clockwise"
        st = float(part.get("start", 0))
        first = geo[order[0]]
        edge = first["lo"] if cw else first["hi"]
        if len(order) > 1 and abs(_adiff(edge, st)) > ANGLE_TOL:
            self.fail("CHK_PIE_START", "SECTOR_ORDER_AS_DECLARED", "%s "
                      "starts at %.3f deg, declared %s (%s)" % (
                          order[0], edge, st, part.get("direction")),
                      obj=g["pid"])
        for a, b in zip(order, order[1:]):
            wa, wb = geo[a], geo[b]
            d = _adiff(wb["lo"], wa["lo"] + wa["span"]) if cw else \
                _adiff(wa["lo"], wb["lo"] + wb["span"])
            if abs(d) > ANGLE_TOL:
                self.fail("CHK_PIE_ORDER", "SECTOR_ORDER_AS_DECLARED", "%s "
                          "does not follow %s %s" % (
                              b, a, "clockwise" if cw else
                              "counterclockwise"), obj=b)
        cwseq = [s for s, _w in sorted(geo.items(),
                                       key=lambda kv: (kv[1]["lo"] -
                                                       st) % 360.0)]
        g["cw_names"] = [self.ps.name(s) for s in cwseq]

    def strokes(self, g, r, seen):
        order = r["order"]
        fills = {}
        for s in order:
            if len(seen.get(s, [])) == 1:
                fills[s] = seen[s][0].a.get("fill")
        n = len(order)
        minw = STROKE_MIN_PT / self.ptpx
        if n == 1:
            o = g["outline"]
            if o and (float(o[2].a.get("stroke-width", "0")) < minw or
                      contrast(o[2].a["stroke"], fills.get(order[0],
                                                           "#ffffff")) <
                      STROKE_CONTRAST and contrast(o[2].a["stroke"],
                                                   "#ffffff") <
                      STROKE_CONTRAST):
                self.fail("CHK_PIE_OUTLINE_STROKE",
                          "SECTOR_BOUNDARIES_STROKED", "%s: outline stroke"
                          % g["pid"], obj=g["pid"])
            return
        for i, s in enumerate(order):
            if s not in fills:
                continue
            e = seen[s][0]
            nb = [order[(i - 1) % n], order[(i + 1) % n]]
            if e.a.get("stroke") in (None, "none") or \
                    float(e.a.get("stroke-width", "0")) < minw:
                self.fail("CHK_PIE_UNSTROKED", "SECTOR_BOUNDARIES_STROKED",
                          "%s: boundary not stroked >= %.2f pt" % (
                              s, STROKE_MIN_PT), obj=s)
                continue
            for x in [s] + nb:
                if x in fills and contrast(e.a["stroke"], fills[x]) < \
                        STROKE_CONTRAST:
                    self.fail("CHK_PIE_STROKE_CONTRAST",
                              "SECTOR_BOUNDARIES_STROKED", "%s: stroke %s "
                              "on fill %s: %.2f:1" % (
                                  s, e.a["stroke"], fills[x],
                                  contrast(e.a["stroke"], fills[x])), obj=s)
            for x in nb:
                if x in fills and fills[x] == fills[s]:
                    self.fail("CHK_PIE_SAME_FILL",
                              "SECTOR_BOUNDARIES_STROKED", "%s and %s share "
                              "the fill %s" % (s, x, fills[s]), obj=s)

    # ----------------------------------------------------------- raster --
    def raster_pies(self):
        if self.ras is None:
            return
        for pid, g in sorted(self.pies.items()):
            if "geo" not in g or len(g["geo"]) != len(
                    self.ps.res[pid]["order"]):
                continue
            self.raster_round(g)
            self.raster_paint(g)
            self.raster_rays(g)

    def _blocked(self, p, g, pad=2.0):
        for ref, b in self.boxes.items():
            if _box_pt_near(_grow(b, pad), p) == 0.0:
                return True
        for e in self.els:
            if e.hook == "leader":
                pts = self._leader_pts(e)
                for a, b in zip(pts, pts[1:]):
                    if _pt_seg_d(p, a, b) < pad:
                        return True
        return False

    def raster_round(self, g):
        c, r = g["c"], g["r"]
        edges = []
        for k in range(72):
            th = 5.0 * k
            ux, uy = math.sin(math.radians(th)), -math.cos(math.radians(th))
            blocked = any(self._blocked((c[0] + ux * d, c[1] + uy * d), g)
                          for d in (r * 0.95, r, r * 1.05, r * 1.1))
            if blocked:
                continue
            d = 0.9 * r
            edge = None
            while d < 1.2 * r:
                px = self.ras.rgb(c[0] + ux * d, c[1] + uy * d)
                if px is None:
                    break
                if min(px) >= 245:
                    edge = d
                    break
                d += 0.25 / RASTER_SCALE * 4
            if edge is not None:
                edges.append(edge)
        if len(edges) < 36:
            self.review("CHK_PIE_RIM_UNREAD", "PIE_CIRCLE_ROUND", "%s: the "
                        "rim was read on %d of 72 rays" % (g["pid"],
                                                          len(edges)),
                        obj=g["pid"])
            return
        m = sum(edges) / len(edges)
        if (max(edges) - min(edges)) / m > ROUND_FRAC:
            self.fail("CHK_PIE_RIM_NOT_ROUND", "PIE_CIRCLE_ROUND", "%s: the "
                      "printed rim radius varies %.2f..%.2f" % (
                          g["pid"], min(edges), max(edges)), obj=g["pid"])
        g["raster_rim"] = [round(min(edges), 2), round(max(edges), 2)]

    def raster_paint(self, g):
        c, r = g["c"], g["r"]
        step = 1.0 / RASTER_SCALE
        n = white = 0
        rr = 0.97 * r
        # a WHITE boundary stroke is paint, not a gap: its pixels (1.5 px
        # of a ray) are not counted
        ws = [x for x in self.els if x.hook == "wedge" and
              self.ps.pie_of(x.for_) == g["pid"]]
        rays = self._rays_of(g) if any(x.a.get("stroke") == "#ffffff"
                                       for x in ws) else []
        y = c[1] - rr
        while y <= c[1] + rr:
            x = c[0] - rr
            while x <= c[0] + rr:
                if math.hypot(x - c[0], y - c[1]) <= rr and \
                        not self._in_label(x, y) and not any(
                            _pt_seg_d((x, y), a, b) < 1.5 for a, b in rays):
                    n += 1
                    px = self.ras.rgb(x, y)
                    if px is not None and min(px) >= 250:
                        white += 1
                x += step * 2
            y += step * 2
        if n and white / float(n) > UNPAINTED_FRAC:
            self.fail("CHK_PIE_UNPAINTED", "PIE_FULL_TILING", "%s: %.2f %% "
                      "of the disc is unpainted" % (
                          g["pid"], 100.0 * white / n), obj=g["pid"])
        g["raster_unpainted"] = round(100.0 * white / max(1, n), 3)

    def _in_label(self, x, y, pad=1.0):
        for b in self.boxes.values():
            if b[0] - pad <= x <= b[2] + pad and b[1] - pad <= y <= b[3] + pad:
                return True
        return False

    def raster_rays(self, g):
        c, r, geo = g["c"], g["r"], g["geo"]
        pid = g["pid"]
        fills = []
        for s, w in geo.items():
            e = [x for x in self.els if x.hook == "wedge" and x.for_ == s]
            if e:
                fills.append(_rgb(e[0].a["fill"]))
        want = sorted(w["lo"] for w in geo.values()) if len(geo) > 1 else []
        found = []
        for frac in (0.6, 0.7, 0.8, 0.9):
            rho = frac * r
            runs, cur = [], None
            N = 3600
            for k in range(N + 1):
                th = 360.0 * k / N
                p = (c[0] + rho * math.sin(math.radians(th)),
                     c[1] - rho * math.cos(math.radians(th)))
                if self._blocked(p, g, pad=1.5):
                    hit = None
                else:
                    px = self.ras.rgb(*p)
                    hit = px is not None and min(
                        sum((a - b) ** 2 for a, b in zip(px, f))
                        for f in fills) > 900
                if hit:
                    if cur is None:
                        cur = [th, th]
                    else:
                        cur[1] = th
                elif cur is not None:
                    runs.append(cur)
                    cur = None
            if cur is not None:
                runs.append(cur)
            found.append([((a + b) / 2.0) % 360.0 for a, b in runs
                          if (b - a) < 8.0])
        rays = []
        for a in found[0] + found[1] + found[2] + found[3]:
            n = sum(1 for lst in found if any(abs(_adiff(a, x)) <=
                                              RASTER_ANGLE_TOL for x in lst))
            if n >= 3 and not any(abs(_adiff(a, x)) <= RASTER_ANGLE_TOL
                                  for x in rays):
                rays.append(a)
        g["raster_rays"] = sorted(round(x, 2) for x in rays)
        regs = self.ps.regions(pid)
        for wv in want:
            if not any(abs(_adiff(wv, x)) <= RASTER_ANGLE_TOL for x in rays):
                # (v6.16 r2) a boundary of a region is its extent's; of a
                # wedge, its angle's (a boundary between the two: both)
                bounded = [s for s, w in geo.items() if
                           abs(_adiff(wv, w["lo"])) < 1e-6 or
                           abs(_adiff(wv, w["lo"] + w["span"])) < 1e-6]
                names = []
                if not bounded or any(s not in regs for s in bounded):
                    names.append("SECTOR_ANGLE_EXACT")
                if any(s in regs for s in bounded):
                    names.append("REGION_EXTENT_EXACT")
                for nm in names:
                    self.fail("CHK_PIE_RASTER_RAY", nm, "%s: no printed "
                              "boundary within %.1f deg of %.2f" % (
                                  pid, RASTER_ANGLE_TOL, wv), obj=pid)
        for x in rays:
            if not any(abs(_adiff(wv, x)) <= RASTER_ANGLE_TOL for wv in want):
                self.fail("CHK_PIE_RASTER_EXTRA_RAY", "MUST_NOT_DRAW", "%s: a "
                          "printed ray at %.2f deg that is no boundary (a "
                          "radius / mark)" % (pid, x), obj=pid)

    # ----------------------------------------------------------- labels --
    def text_xml(self, e):
        m = re.search(r'<text id="%s"[^>]*>[^<]*</text>' % e.ref, self.raw)
        return m.group(0) if m else None

    def measure_texts(self):
        for e in self.els:
            if e.tag != "text":
                continue
            b = None
            if self.ras is not None:
                x = self.text_xml(e)
                b = self.ras.text_box(x) if x else None
                if b is None:
                    self.fail("CHK_PIE_TEXT_NO_INK", "LABEL_LEGIBLE", "%s "
                              "draws no ink" % e.ref, obj=e.for_)
                    continue
            else:
                fs = e.f("font-size")
                w = 0.62 * fs * len(e.text or "")
                x0 = e.f("x") - (w / 2 if e.a["text-anchor"] == "middle" else
                                 w if e.a["text-anchor"] == "end" else 0)
                b = (x0, e.f("y") - 0.9 * fs, x0 + w, e.f("y") + 0.3 * fs)
            self.boxes[e.ref] = b
            if b[0] < CANVAS_MARGIN or b[1] < CANVAS_MARGIN or \
                    b[2] > self.W - CANVAS_MARGIN or \
                    b[3] > self.H - CANVAS_MARGIN:
                self.fail("CHK_PIE_TEXT_CLIPPED", "TEXT_BOX_IN_CANVAS", "%s "
                          "%r: ink box %s leaves the canvas %sx%s" % (
                              e.ref, e.text, [round(v, 2) for v in b],
                              self.W, self.H), obj=e.for_)

    def labels(self):
        ps = self.ps
        for part in ps.parts:
            if part.get("part") != "pie":
                continue
            pid = part["pie"]
            g = self.pies.get(pid) or {}
            r = ps.res[pid]
            for s in r["order"]:
                names = [e for e in self.els if e.hook == "name" and
                         e.for_ == s]
                vals = [e for e in self.els if e.hook == "val" and
                        e.for_ == s]
                # (v6.16 r2) names none / a region: no name printed
                want_name = part.get("names") == "in_sector" and \
                    s not in ps.regions(pid)
                vt = ps.value_text(s)
                want_val = part.get("values") == "in_sector" and \
                    vt is not None
                if len(names) != (1 if want_name else 0):
                    self.fail("CHK_PIE_NAME_COUNT", "LABEL_OWNED", "%s: %d "
                              "name labels (declared %d)" % (
                                  s, len(names), 1 if want_name else 0),
                              obj=s)
                if vals and vt is None:
                    self.fail("CHK_PIE_VALUE_PRINTED", "TARGET_VALUE_NOT_SHOWN",
                              "%s: a value label %r for a sector whose value "
                              "is not a drawn given (a missing / equal "
                              "sector: the student finds it)" % (
                                  s, [visual(v.text) for v in vals]), obj=s)
                elif len(vals) != (1 if want_val else 0):
                    self.fail("CHK_PIE_VALUE_COUNT", "LABEL_OWNED", "%s: %d "
                              "value labels (declared %d)" % (
                                  s, len(vals), 1 if want_val else 0), obj=s)
                for e in names:
                    self.own(s, e.ref)
                    self.own(pid, e.ref)
                    if e.text != visual(ps.name(s)):
                        self.fail("CHK_PIE_NAME_TEXT", "LABEL_FORM", "%s: "
                                  "%r, declared %r" % (e.ref, e.text,
                                                       ps.name(s)), obj=s)
                for e in vals:
                    self.own(s, e.ref)
                    self.own(pid, e.ref)
                    self.value_form(e, vt, r["unit"], s)
                for e in names + vals:
                    self.label_place(e, s, g, part)

    def value_form(self, e, vt, unit, s):
        t = e.text or ""
        rx = r"^[0-9]+(?:\.[0-9]+)?%$" if unit == "percent" else \
            u"^[0-9]+(?:\\.[0-9]+)?°$"
        if not re.match(rx, t):
            self.fail("CHK_PIE_VALUE_FORM", "LABEL_FORM", "%s: %r is not "
                      "the %s form" % (e.ref, t, "N%" if unit == "percent"
                                       else u"N°"), obj=s)
        elif vt is not None and t != vt:
            self.fail("CHK_PIE_VALUE_TEXT", "LABEL_FORM", "%s: %r, the "
                      "declared value is %r" % (e.ref, t, vt), obj=s)

    def _rays_of(self, g):
        if len(g.get("geo") or {}) < 2:
            return []
        c, r = g["c"], g["r"]
        return [(c, (c[0] + r * math.sin(math.radians(w["lo"])),
                     c[1] - r * math.cos(math.radians(w["lo"]))))
                for w in g["geo"].values()]

    def label_place(self, e, s, g, part):
        b = self.boxes.get(e.ref)
        if b is None or "geo" not in g or s not in g["geo"]:
            return
        c, r = g["c"], g["r"]
        w = g["geo"][s]
        centre = ((b[0] + b[2]) / 2.0, (b[1] + b[3]) / 2.0)
        inside = math.hypot(centre[0] - c[0], centre[1] - c[1]) < r
        halfw = float(g["outline"][2].a.get("stroke-width", "1")) / 2.0 \
            if g.get("outline") else 0.5
        clear = LABEL_CLEAR_PT / self.ptpx + halfw
        fs_pt = e.f("font-size") * self.ptpx
        if fs_pt < FONT_MIN_PT:
            self.fail("CHK_PIE_FONT_SMALL", "LABEL_LEGIBLE", "%s: %.2f pt"
                      % (e.ref, fs_pt), obj=s)
        if inside:
            # in its own wedge: inside the circle, crossing no ray, its
            # centre in the wedge's angular range
            far = _box_pt_far(b, c)
            rays = self._rays_of(g)
            own_ok = far <= r and _in_arc(_ang(centre[0] - c[0],
                                                centre[1] - c[1]),
                                           w["lo"], w["span"]) and all(
                _seg_box_d(a, bb, b) > 0.0 for a, bb in rays)
            if not own_ok:
                self.fail("CHK_PIE_LABEL_NOT_OWNED", "LABEL_OWNED", "%s %r "
                          "is not inside the wedge of %s" % (
                              e.ref, e.text, s), obj=s)
            gap = min([r - far] + [_seg_box_d(a, bb, b) for a, bb in rays])
            if gap < clear:
                self.fail("CHK_PIE_LABEL_ON_STROKE", "LABEL_LEGIBLE", "%s "
                          "%r: %.2f px from a stroke (%.2f needed)" % (
                              e.ref, e.text, gap, clear), obj=s)
            fill = [x for x in self.els if x.hook == "wedge" and
                    x.for_ == s]
            if fill and contrast(e.a["fill"], fill[0].a["fill"]) < \
                    TEXT_CONTRAST:
                self.fail("CHK_PIE_LABEL_CONTRAST", "LABEL_LEGIBLE", "%s: "
                          "%s on %s" % (e.ref, e.a["fill"],
                                        fill[0].a["fill"]), obj=s)
            self.label_owner[e.ref] = ("in", s)
        else:
            if _box_pt_near(b, c) < r + clear:
                self.fail("CHK_PIE_LABEL_ON_RIM", "LABEL_LEGIBLE", "%s %r "
                          "touches the rim" % (e.ref, e.text), obj=s)
            if contrast(e.a["fill"], "#ffffff") < TEXT_CONTRAST:
                self.fail("CHK_PIE_LABEL_CONTRAST", "LABEL_LEGIBLE", "%s: %s "
                          "on paper" % (e.ref, e.a["fill"]), obj=s)
            leads = [x for x in self.els if x.hook == "leader" and
                     x.for_ == s]
            if not leads:
                self.fail("CHK_PIE_OUTSIDE_NO_LEADER", "LABEL_OWNED", "%s %r "
                          "is outside the disc with no leader line" % (
                              e.ref, e.text), obj=s)
            self.label_owner[e.ref] = ("out", s)

    def label_gaps(self):
        refs = sorted(self.boxes)
        for i, a in enumerate(refs):
            for b in refs[i + 1:]:
                if _box_gap(self.boxes[a], self.boxes[b]) < \
                        LABEL_CLEAR_PT / self.ptpx:
                    ea, eb = self.by_ref[a], self.by_ref[b]
                    self.fail("CHK_PIE_LABELS_TOUCH", "LABEL_LEGIBLE", "%s %r "
                              "and %s %r are closer than %.1f pt" % (
                                  a, ea.text, b, eb.text, LABEL_CLEAR_PT),
                              obj=ea.for_)

    def _leader_pts(self, e):
        m = LEADER_RE.match(e.a.get("d", ""))
        if not m:
            return []
        pts = [(float(m.group(1)), float(m.group(2)))]
        for q in PT_RE.finditer(m.group(3)):
            pts.append((float(q.group(1)), float(q.group(2))))
        return pts

    def leaders(self):
        ps = self.ps
        for e in self.els:
            if e.hook != "leader":
                continue
            s = e.for_
            pid = ps.pie_of(s)
            part = ([p for p in ps.parts if p.get("pie") == pid] or [{}])[0]
            chk = "LEADER_LINE_OWNED" if s in (part.get("outside") or []) \
                else "LEADER_LINE_OWNED_IF_ANY"
            self.own(s, e.ref)
            self.own(pid, e.ref)
            g = self.pies.get(pid) or {}
            if "geo" not in g or s not in g["geo"]:
                continue
            c, r, w = g["c"], g["r"], g["geo"][s]
            pts = self._leader_pts(e)
            if len(pts) < 2:
                continue
            p0 = pts[0]
            if not (math.hypot(p0[0] - c[0], p0[1] - c[1]) < r + 0.5 and
                    _in_arc(_ang(p0[0] - c[0], p0[1] - c[1]), w["lo"],
                            w["span"])):
                self.fail("CHK_PIE_LEADER_START", chk, "%s starts outside "
                          "the wedge of %s" % (e.ref, s), obj=s)
            # inside the disc it stays in its own wedge
            for a, b in zip(pts, pts[1:]):
                for k in range(41):
                    t = k / 40.0
                    x, y = a[0] + t * (b[0] - a[0]), a[1] + t * (b[1] - a[1])
                    if math.hypot(x - c[0], y - c[1]) < r - 0.5 and \
                            not _in_arc(_ang(x - c[0], y - c[1]), w["lo"],
                                        w["span"], 0.05):
                        self.fail("CHK_PIE_LEADER_CROSSES", chk, "%s runs "
                                  "through another wedge" % e.ref, obj=s)
                        break
            own = [x.ref for x in self.els if x.tag == "text" and
                   x.for_ == s and x.hook in ("name", "val") and
                   self.label_owner.get(x.ref, ("", ""))[0] == "out"]
            if not own:
                self.fail("CHK_PIE_LEADER_NO_LABEL", chk, "%s leads to no "
                          "outside label of %s" % (e.ref, s), obj=s)
                continue
            end = pts[-1]
            if min(_box_pt_near(self.boxes[x], end) for x in own) > \
                    LEADER_END_PX:
                self.fail("CHK_PIE_LEADER_END", chk, "%s ends %.2f px from "
                          "its label" % (e.ref, min(_box_pt_near(
                              self.boxes[x], end) for x in own)), obj=s)
            for ref, bx in sorted(self.boxes.items()):
                if ref in own:
                    continue
                for a, b in zip(pts, pts[1:]):
                    if _seg_box_d(a, b, bx) < 0.5:
                        self.fail("CHK_PIE_LEADER_ON_LABEL", chk, "%s "
                                  "crosses the label %s" % (e.ref, ref),
                                  obj=s)
            for o in self.els:
                if o.hook != "leader" or o.ref <= e.ref:
                    continue
                qo = self._leader_pts(o)
                for a, b in zip(pts, pts[1:]):
                    for cc, dd in zip(qo, qo[1:]):
                        if _seg_seg_d(a, b, cc, dd) < 0.5:
                            self.fail("CHK_PIE_LEADERS_CROSS", chk, "%s and "
                                      "%s cross" % (e.ref, o.ref), obj=s)

    def legend(self):
        ps = self.ps
        shared = bool(ps.fr.get("shared_legend"))
        pies = [p for p in ps.parts if p.get("part") == "pie"]
        legs = [e for e in self.els if e.hook == "leg"]
        sws = [e for e in self.els if e.hook == "swatch"]
        want = []
        if shared:
            p = pies[0]
            for s in p.get("order") or []:
                want.append((s, ps.name(s), [s] + [
                    x for q in pies[1:] for x in q.get("order") or []
                    if ps.name(x) == ps.name(s)], "legend:shared"))
        else:
            for p in pies:
                if p.get("names") != "legend":
                    continue
                for s in p.get("order") or []:
                    t = ps.name(s)
                    if p.get("values") == "legend" and \
                            ps.value_text(s) is not None:
                        t = t + u" " + ps.value_text(s)
                    want.append((s, t, [s], "legend:" + p["pie"][4:]))
        got_for = [e.for_ for e in legs]
        if sorted(got_for) != sorted(w[0] for w in want) or \
                sorted(x.for_ for x in sws) != sorted(w[0] for w in want):
            self.fail("CHK_PIE_LEGEND_ENTRIES", "LEGEND_MATCHES_SECTORS",
                      "legend entries %s / swatches %s, declared %s" % (
                          got_for, [x.for_ for x in sws],
                          [w[0] for w in want]))
            return
        by = {}
        for s, t, owners, lobj in want:
            e = [x for x in legs if x.for_ == s][0]
            sw = [x for x in sws if x.for_ == s][0]
            by.setdefault(lobj, []).append((s, e, sw))
            for o in owners:
                self.own(o, e.ref)
                self.own(o, sw.ref)
                self.own(ps.pie_of(o), e.ref)
                self.own(ps.pie_of(o), sw.ref)
            self.own(lobj, e.ref)
            self.own(lobj, sw.ref)
            if e.text != visual(t):
                self.fail("CHK_PIE_LEGEND_TEXT", "LEGEND_MATCHES_SECTORS",
                          "%s: %r, declared %r" % (e.ref, e.text, t), obj=s)
            if contrast(e.a["fill"], "#ffffff") < TEXT_CONTRAST:
                self.fail("CHK_PIE_LABEL_CONTRAST", "LABEL_LEGIBLE", "%s"
                          % e.ref, obj=s)
            for o in owners:
                wd = [x for x in self.els if x.hook == "wedge" and
                      x.for_ == o]
                if wd and wd[0].a["fill"] != sw.a["fill"]:
                    self.fail("CHK_PIE_SWATCH_FILL", "LEGEND_MATCHES_SECTORS",
                              "%s swatch %s, wedge of %s %s" % (
                                  sw.ref, sw.a["fill"], o, wd[0].a["fill"]),
                              obj=o)
            sb = self._poly_box(sw)
            eb = self.boxes.get(e.ref)
            if eb and sb and not (abs((sb[1] + sb[3]) / 2.0 -
                                      (eb[1] + eb[3]) / 2.0) < 6.0 and
                                  _box_gap(sb, eb) < 12.0):
                self.fail("CHK_PIE_SWATCH_FAR", "LEGEND_MATCHES_SECTORS",
                          "%s is not next to its text %s" % (sw.ref, e.ref),
                          obj=s)
            for g in self.pies.values():
                if "c" not in g:
                    continue
                for bx in (sb, eb):
                    if bx and _box_pt_near(bx, g["c"]) < g["r"]:
                        self.fail("CHK_PIE_LEGEND_IN_DISC",
                                  "LEGEND_MATCHES_SECTORS", "%s lies on the "
                                  "disc of %s" % (e.ref, g["pid"]), obj=s)
        for lobj, rows in by.items():
            ys = [(sw_box[1] if sw_box else 0) for sw_box in [
                self._poly_box(sw) for _s, _e, sw in rows]]
            if ys != sorted(ys):
                self.fail("CHK_PIE_LEGEND_ORDER", "LEGEND_MATCHES_SECTORS",
                          "%s entries are not in the declared order top to "
                          "bottom" % lobj)

    @staticmethod
    def _poly_box(e):
        m = POINTS_RE.match(e.a.get("points", ""))
        if not m:
            return None
        xs = [float(m.group(i)) for i in (1, 3, 5, 7)]
        ys = [float(m.group(i)) for i in (2, 4, 6, 8)]
        return (min(xs), min(ys), max(xs), max(ys))

    def captions(self):
        ps = self.ps
        pies = [p for p in ps.parts if p.get("part") == "pie"]
        for p in pies:
            pid = p["pie"]
            caps = [e for e in self.els if e.hook == "cap" and e.for_ == pid]
            tots = [e for e in self.els if e.hook == "total" and
                    e.for_ == pid]
            want_cap = p.get("caption")
            if len(caps) != (1 if want_cap else 0):
                self.fail("CHK_PIE_CAPTION_COUNT", "TOTAL_AS_DECLARED", "%s: "
                          "%d captions (declared %d)" % (
                              pid, len(caps), 1 if want_cap else 0), obj=pid)
            for e in caps:
                self.own(pid, e.ref)
                if want_cap and e.text != visual(want_cap):
                    self.fail("CHK_PIE_CAPTION_TEXT", "CAPTION_OWNED", "%s: "
                              "%r, declared %r" % (e.ref, e.text, want_cap),
                              obj=pid)
                self.caption_owner(e, pid)
            tf = ps.drawn_total(pid)
            if len(tots) != (1 if tf else 0):
                self.fail("CHK_PIE_TOTAL_COUNT", "TOTAL_AS_DECLARED", "%s: "
                          "%d total labels (declared %d)" % (
                              pid, len(tots), 1 if tf else 0), obj=pid)
            for e in tots:
                self.own(pid, e.ref)
                if tf:
                    want = TOTAL_WORDS + (_dec(_q(tf.get("value"))) or "?")
                    if e.text != visual(want):
                        self.fail("CHK_PIE_TOTAL_TEXT", "TOTAL_AS_DECLARED",
                                  "%s: %r, declared %r" % (e.ref, e.text,
                                                           want), obj=pid)
                self.caption_owner(e, pid)

    def caption_owner(self, e, pid):
        b = self.boxes.get(e.ref)
        if b is None:
            return
        cen = ((b[0] + b[2]) / 2.0, (b[1] + b[3]) / 2.0)
        mine = self.pies.get(pid) or getattr(self, "builds", {}).get(
            pid) or {}                                  # v6.16 r2: builds
        if "c" not in mine:
            return
        dm = math.hypot(cen[0] - mine["c"][0], cen[1] - mine["c"][1])
        if _box_pt_near(b, mine["c"]) < mine["r"]:
            self.fail("CHK_PIE_CAPTION_IN_DISC", "CAPTION_OWNED", "%s lies "
                      "on the disc" % e.ref, obj=pid)
        for g in list(self.pies.values()) + list(getattr(
                self, "builds", {}).values()):
            if g.get("pid") == pid or "c" not in g:
                continue
            if math.hypot(cen[0] - g["c"][0], cen[1] - g["c"][1]) <= dm:
                self.fail("CHK_PIE_CAPTION_NOT_OWNED", "CAPTION_OWNED", "%s "
                          "is as near %s as its own pie %s" % (
                              e.ref, g.get("pid"), pid), obj=pid)

    # ------------------------------------------------------------ build --
    def build(self):
        self.builds = {}
        for part in self.ps.parts:
            if part.get("part") != "build":
                continue
            cid = part.get("circle")
            circ = [e for e in self.els if e.hook == "bcirc" and
                    e.for_ == cid]
            dots = [e for e in self.els if e.hook == "bdot" and
                    e.for_ == cid]
            for e in circ + dots:
                self.own(cid, e.ref)
            if len(circ) != 1:
                self.fail("CHK_PIE_BUILD_CIRCLES", "BUILD_CIRCLE_EMPTY", "%s:"
                          " %d circles" % (cid, len(circ)), obj=cid)
                continue
            e = circ[0]
            if e.tag != "circle" or not all(k in e.a
                                            for k in ("cx", "cy", "r")):
                # (v6.16 integrate, runner finding P-F1: KeyError 'cx' on a
                # build circle drawn as a <path>) a named finding
                self.fail("CHK_PIE_BUILD_NOT_CIRCLE", "PIE_CIRCLE_ROUND",
                          "%s: the build circle %s is a <%s>, not a circle"
                          % (cid, e.ref, e.tag), obj=cid)
                continue
            c, r = (e.f("cx"), e.f("cy")), e.f("r")
            self.builds[cid] = {"pid": cid, "c": c, "r": r}
            # (v6.16 r2) its declared caption, UNDER it (never in / at it)
            caps = [x for x in self.els if x.hook == "bcap" and
                    x.for_ == cid]
            want_cap = part.get("caption")
            for x in caps:
                self.own(cid, x.ref)
            if len(caps) != (1 if want_cap else 0):
                self.fail("CHK_PIE_BUILD_CAPTION_COUNT", "CAPTION_OWNED",
                          "%s: %d captions (declared %d)" % (
                              cid, len(caps), 1 if want_cap else 0),
                          obj=cid)
            own_caps = []
            for x in caps:
                if want_cap and x.text != visual(want_cap):
                    self.fail("CHK_PIE_CAPTION_TEXT", "CAPTION_OWNED", "%s: "
                              "%r, declared %r" % (x.ref, x.text, want_cap),
                              obj=cid)
                bx = self.boxes.get(x.ref)
                half = float(e.a.get("stroke-width", "1")) / 2.0
                if bx is not None and _box_pt_near(bx, c) < r + half + 1.0:
                    self.fail("CHK_PIE_BUILD_CAPTION_IN", "BUILD_CIRCLE_EMPTY",
                              "%s: the caption %r lies in / on the empty "
                              "disc %s" % (x.ref, x.text, cid), obj=cid)
                elif bx is not None and bx[1] < c[1]:
                    self.fail("CHK_PIE_BUILD_CAPTION_IN", "BUILD_CIRCLE_EMPTY",
                              "%s: the caption %r is not under the empty "
                              "disc %s" % (x.ref, x.text, cid), obj=cid)
                else:
                    own_caps.append(x)
            if len(dots) != (1 if part.get("centre_dot") else 0):
                self.fail("CHK_PIE_BUILD_DOT", "BUILD_CIRCLE_EMPTY", "%s: %d "
                          "centre dots (declared %s)" % (
                              cid, len(dots), part.get("centre_dot")),
                          obj=cid)
            for d in dots:
                if math.hypot(d.f("cx") - c[0], d.f("cy") - c[1]) > 0.05:
                    self.fail("CHK_PIE_BUILD_DOT_OFF", "BUILD_CIRCLE_EMPTY",
                              "%s is not at the centre" % d.ref, obj=cid)
            zone = _grow((c[0] - r, c[1] - r, c[0] + r, c[1] + r),
                         BUILD_EMPTY_PX)
            for o in self.els:
                if o in circ or o in dots or o in own_caps:
                    continue
                bx = self._el_box(o)
                if bx and _box_gap(bx, zone) == 0.0 and self._touches_disc(
                        o, bx, c, r + BUILD_EMPTY_PX):
                    self.fail("CHK_PIE_BUILD_NOT_EMPTY", "BUILD_CIRCLE_EMPTY",
                              "%s (%s %r) is drawn in / at the build circle "
                              "%s" % (o.ref, o.hook, o.text or "", cid),
                              obj=cid)
                    if o.tag == "text" and number_tokens(o.text):
                        self.fail("CHK_PIE_BUILD_NUMBER", "MUST_NOT_DRAW",
                                  "%s prints %r at the build circle %s" % (
                                      o.ref, o.text, cid), obj=cid)
            mm = r * self.ptpx * MM_PER_PT
            if not (BUILD_MM[0] <= mm <= BUILD_MM[1]):
                self.fail("CHK_PIE_BUILD_SIZE", "BUILD_CIRCLE_SIZE", "%s: "
                          "radius %.2f mm printed (%.0f..%.0f)" % (
                              cid, mm, BUILD_MM[0], BUILD_MM[1]), obj=cid)
            ent = {"part": "build", "circle": cid, "centre_px": [
                round(c[0], 3), round(c[1], 3)], "radius_px": r,
                "radius_mm_at_print": round(mm, 2),
                "centre_dot": bool(dots)}
            if caps:
                ent["caption"] = _logical(caps[0], self.ps)     # v6.16 r2
            self.measured["parts"].append(ent)
        for part in self.ps.parts:
            if part.get("part") == "build" and part.get("circle") in \
                    self.builds:
                for x in self.els:
                    if x.hook == "bcap" and x.for_ == part.get("circle"):
                        self.caption_owner(x, part.get("circle"))

    def _el_box(self, o):
        if o.tag == "text":
            return self.boxes.get(o.ref)
        if o.tag == "circle":
            cx, cy, r = o.f("cx"), o.f("cy"), o.f("r")
            return (cx - r, cy - r, cx + r, cy + r)
        if o.tag == "polygon":
            return self._poly_box(o)
        if o.tag == "path":
            nums = [float(x) for x in re.findall(NUM, o.a.get("d", ""))]
            if o.hook == "wedge":
                m = self.parse_wedge(o)
                if m:
                    pts = m["pts"] + [m["c"]]
                    rr = m["radii"][0][0] if m["radii"] else 0
                    xs = [m["c"][0] - rr, m["c"][0] + rr]
                    ys = [m["c"][1] - rr, m["c"][1] + rr]
                    return (min(xs + [p[0] for p in pts]),
                            min(ys + [p[1] for p in pts]),
                            max(xs + [p[0] for p in pts]),
                            max(ys + [p[1] for p in pts]))
            if len(nums) >= 2:
                xs, ys = nums[0::2], nums[1::2]
                return (min(xs), min(ys), max(xs), max(ys))
        return None

    @staticmethod
    def _touches_disc(o, bx, c, R):
        return _box_pt_near(bx, c) <= R

    # ------------------------------------------------------------ parts --
    def layout(self):
        fr = self.ps.fr
        discs = []
        for part in self.ps.parts:
            if part.get("part") == "pie":
                g = self.pies.get(part.get("pie")) or {}
                if "c" in g:
                    discs.append((part.get("side"), g["c"], g["r"],
                                  part.get("pie")))
            else:
                b = getattr(self, "builds", {}).get(part.get("circle"))
                if b:
                    discs.append((part.get("side"), b["c"], b["r"],
                                  part.get("circle")))
        for side, c, r, eid in discs:
            if c[0] - r < 0 or c[1] - r < 0 or c[0] + r > self.W or \
                    c[1] + r > self.H:
                self.fail("CHK_PIE_DISC_CLIPPED", "MULTI_PIE_LAYOUT" if
                          fr.get("layout") == "row" else "TWO_PIES_LAYOUT"
                          if len(discs) > 1 else "PIE_CIRCLE_ROUND", "%s "
                          "leaves the canvas" % eid, obj=eid)
        self.multi_layout(discs)
        if fr.get("layout") != "side_by_side" or len(discs) != 2:
            return
        (s1, c1, r1, e1), (s2, c2, r2, e2) = sorted(
            discs, key=lambda d: d[1][0])
        if (s1, s2) != ("left", "right"):
            self.fail("CHK_PIE_SIDES", "TWO_PIES_LAYOUT", "%s is printed on "
                      "the left, declared %s" % (e1, s1))
        if abs(c1[1] - c2[1]) > TWO_Y_PT / self.ptpx:
            self.fail("CHK_PIE_NOT_ONE_LINE", "TWO_PIES_LAYOUT", "centres at "
                      "y %.2f and %.2f" % (c1[1], c2[1]))
        gap = math.hypot(c2[0] - c1[0], c2[1] - c1[1]) - r1 - r2
        if gap < TWO_GAP_FRAC * max(r1, r2):
            self.fail("CHK_PIE_TOO_CLOSE", "TWO_PIES_LAYOUT", "the discs are "
                      "%.2f px apart (%.2f needed)" % (
                          gap, TWO_GAP_FRAC * max(r1, r2)))
        if fr.get("same_size") and abs(r1 - r2) > RADIUS_FRAC * max(r1, r2):
            self.fail("CHK_PIE_SIZES", "SAME_RADIUS_IF_DECLARED", "radii "
                      "%.2f and %.2f, declared the same size" % (r1, r2))

    def multi_layout(self, discs):
        """(v6.16 r2) MULTI_PIE_LAYOUT: 2..3 discs (a side_by_side pair or
        a row) in ONE row: centres on one horizontal line (1 pt), pairwise
        disjoint with a gap >= 10 % r, inside the canvas, in the DECLARED
        order read RIGHT TO LEFT (a row: its parts in order, d1 rightmost;
        a pair: the right part first); a row's discs have one radius
        (SAME_RADIUS_IF_DECLARED)."""
        fr = self.ps.fr
        lay = fr.get("layout")
        if lay not in ("side_by_side", "row"):
            return
        parts = list(self.ps.parts)
        if lay == "side_by_side":
            parts.sort(key=lambda p: 0 if p.get("side") == "right" else 1)
        got = dict((d[3], d) for d in discs)
        seq = []
        for p in parts:
            eid = p.get("pie") or p.get("circle")
            if eid not in got:
                self.fail("CHK_PIE_ROW_DISC_MISSING", "MULTI_PIE_LAYOUT",
                          "%s: no disc measured" % eid, obj=eid)
                continue
            seq.append(got[eid])
        if len(seq) != len(parts) or not 2 <= len(seq) <= 3:
            self.fail("CHK_PIE_ROW_COUNT", "MULTI_PIE_LAYOUT", "%d discs "
                      "measured, %d declared (2..3)" % (len(seq), len(parts)))
            return
        ys = [d[1][1] for d in seq]
        if max(ys) - min(ys) > TWO_Y_PT / self.ptpx:
            self.fail("CHK_PIE_ROW_NOT_ONE_LINE", "MULTI_PIE_LAYOUT", "disc "
                      "centres at y %s (one line within %.1f pt)" % (
                          [round(y, 2) for y in ys], TWO_Y_PT))
        for a, b in zip(seq, seq[1:]):
            if not a[1][0] > b[1][0]:
                self.fail("CHK_PIE_ROW_ORDER", "MULTI_PIE_LAYOUT", "%s is "
                          "declared before %s but is not to its right (a "
                          "row reads right to left)" % (a[3], b[3]),
                          obj=b[3])
        for i, a in enumerate(seq):
            for b in seq[i + 1:]:
                gap = math.hypot(a[1][0] - b[1][0], a[1][1] - b[1][1]) - \
                    a[2] - b[2]
                if gap < TWO_GAP_FRAC * max(a[2], b[2]):
                    self.fail("CHK_PIE_ROW_TOO_CLOSE", "MULTI_PIE_LAYOUT",
                              "%s and %s are %.2f px apart (%.2f needed)" % (
                                  a[3], b[3], gap,
                                  TWO_GAP_FRAC * max(a[2], b[2])))
        if lay == "row" and fr.get("same_size"):
            rs = [d[2] for d in seq]
            if max(rs) - min(rs) > RADIUS_FRAC * max(rs):
                self.fail("CHK_PIE_SIZES", "SAME_RADIUS_IF_DECLARED", "the "
                          "discs of the row have radii %s" % (
                              [round(x, 2) for x in rs],))

    def caption_policy(self):
        """(v6.16 r2) CAPTION_POLICY of a ROW: one caption per disc, exactly
        the declared text, under its own disc, no digit, none of the words
        of a whole or a count."""
        if self.ps.fr.get("layout") != "row":
            return
        for p in self.ps.parts:
            eid = p.get("pie") or p.get("circle")
            hook = "cap" if p.get("part") == "pie" else "bcap"
            caps = [e for e in self.els if e.hook == hook and e.for_ == eid]
            want = p.get("caption")
            if len(caps) != 1 or not want:
                self.fail("CHK_PIE_ROW_CAPTION_COUNT", "CAPTION_POLICY", "%s: "
                          "%d captions printed, %s declared (one per disc)"
                          % (eid, len(caps), 1 if want else 0), obj=eid)
            for e in caps:
                t = e.text or ""
                if want and t != visual(want):
                    self.fail("CHK_PIE_ROW_CAPTION_TEXT", "CAPTION_POLICY",
                              "%s: %r, declared %r" % (e.ref, t, want),
                              obj=eid)
                if re.search(r"[0-9]", t):
                    self.fail("CHK_PIE_ROW_CAPTION_DIGIT", "CAPTION_POLICY",
                              "%s: the caption %r carries a digit" % (
                                  e.ref, t), obj=eid)
                forms = (t, t[::-1], visual(t))
                hit = [w for w in CAPTION_WHOLE_WORDS
                       if any(w in f for f in forms)]
                if hit:
                    self.fail("CHK_PIE_ROW_CAPTION_WHOLE", "CAPTION_POLICY",
                              "%s: the caption %r states a whole / a count "
                              "(%s)" % (e.ref, t, hit[0]), obj=eid)
                g = self.pies.get(eid) or getattr(self, "builds", {}).get(
                    eid) or {}
                b = self.boxes.get(e.ref)
                if "c" in g and b is not None and not (
                        b[1] >= g["c"][1] + g["r"] - 0.5 and
                        abs((b[0] + b[2]) / 2.0 - g["c"][0]) <= g["r"]):
                    self.fail("CHK_PIE_ROW_CAPTION_PLACE", "CAPTION_POLICY",
                              "%s: the caption of %s is not under its disc"
                              % (e.ref, eid), obj=eid)

    # ----------------------------------------------------------- regions --
    def raw_geometry(self):
        """(v6.16 r2) sample points of EVERY drawn element of the raw SVG
        (also one outside the dialect: a <line>, a <polyline>, a <rect>, a
        relative path): [(ref, tag, hook, for, [(x, y)])]. Text: its
        measured ink box (else an estimate)."""
        try:
            root = ET.fromstring(self.raw.encode("utf-8"))
        except ET.ParseError:
            return []
        out = []
        k = 0

        def seg(a, b, n=24):
            return [(a[0] + (b[0] - a[0]) * i / float(n),
                     a[1] + (b[1] - a[1]) * i / float(n)) for i in
                    range(n + 1)]

        def fl(v, d=0.0):
            try:
                return float(v)
            except (TypeError, ValueError):
                return d
        for el in root.iter():
            tag = el.tag.replace(NS, "")
            if tag in ("svg", "g"):
                continue
            k += 1
            a = el.attrib
            ref = a.get("id") or "#%s%d" % (tag, k)
            pts = []
            if tag == "line":
                pts = seg((fl(a.get("x1")), fl(a.get("y1"))),
                          (fl(a.get("x2")), fl(a.get("y2"))))
            elif tag in ("polyline", "polygon"):
                nums = [float(x) for x in re.findall(
                    r"-?[0-9]*\.?[0-9]+", a.get("points", ""))]
                pp = list(zip(nums[0::2], nums[1::2]))
                if tag == "polygon" and pp:
                    pp.append(pp[0])
                for p0, p1 in zip(pp, pp[1:]):
                    pts += seg(p0, p1)
                pts += pp
            elif tag in ("circle", "ellipse"):
                cx, cy = fl(a.get("cx")), fl(a.get("cy"))
                rx = fl(a.get("r", a.get("rx")))
                ry = fl(a.get("r", a.get("ry")))
                pts = [(cx, cy)] + [(cx + rx * math.sin(math.radians(t)),
                                     cy - ry * math.cos(math.radians(t)))
                                    for t in range(0, 360, 15)]
            elif tag == "rect":
                x, y = fl(a.get("x")), fl(a.get("y"))
                w, h = fl(a.get("width")), fl(a.get("height"))
                cs = [(x, y), (x + w, y), (x + w, y + h), (x, y + h), (x, y)]
                for p0, p1 in zip(cs, cs[1:]):
                    pts += seg(p0, p1)
            elif tag == "path":
                pts = _path_points(a.get("d", ""), seg)
            elif tag == "text":
                b = self.boxes.get(ref)
                if b is None:
                    fs = fl(a.get("font-size"), 12.0)
                    w = 0.6 * fs * len(el.text or "")
                    x0 = fl(a.get("x")) - (w / 2 if a.get("text-anchor") ==
                                           "middle" else w if a.get(
                                               "text-anchor") == "end"
                                           else 0)
                    b = (x0, fl(a.get("y")) - 0.8 * fs, x0 + w,
                         fl(a.get("y")) + 0.2 * fs)
                xs = (b[0], (b[0] + b[2]) / 2.0, b[2])
                ys = (b[1], (b[1] + b[3]) / 2.0, b[3])
                pts = [(x, y) for x in xs for y in ys]
            else:
                if "x" in a and "y" in a:
                    pts = [(fl(a.get("x")), fl(a.get("y")))]
            out.append((ref, tag, a.get("data-pie"), a.get("data-for"), pts))
        return out

    @staticmethod
    def strictly_inside(p, c, r, lo, span):
        """(v6.16 r2) p lies strictly inside the open sector lo..lo+span of
        the disc (c, r): off its two boundary rays and the rim by
        REGION_EDGE_PX, and off the centre"""
        d = math.hypot(p[0] - c[0], p[1] - c[1])
        if d < 1.0 or d > r - REGION_EDGE_PX:
            return False
        off = (_ang(p[0] - c[0], p[1] - c[1]) - lo) % 360.0
        if not 0.0 < off < span:
            return False
        for th in (lo, lo + span):
            rim = (c[0] + r * math.sin(math.radians(th)),
                   c[1] - r * math.cos(math.radians(th)))
            if _pt_seg_d(p, c, rim) < REGION_EDGE_PX:
                return False
        return True

    def regions_undivided(self, om):
        """(v6.16 r2) REGION_UNDIVIDED: see the module docstring."""
        ps = self.ps
        raw = None
        for part in ps.parts:
            if part.get("part") != "pie":
                continue
            pid = part["pie"]
            regs = [x for x in part.get("order") or []
                    if x in ps.regions(pid)]
            g = self.pies.get(pid) or {}
            if not regs or "geo" not in g:
                continue
            if raw is None:
                raw = self.raw_geometry()
            c, r = g["c"], g["r"]
            expect = self.expected_tiles(part)
            for s in regs:
                # the measured extent; the declared one when the region's
                # own path is unreadable (never skipped)
                w = g["geo"].get(s) or expect.get(s)
                if w is None:
                    continue
                lo, span = w["lo"], w["span"]
                vt = ps.value_text(s)
                own_lab = set(x.ref for x in self.els if x.for_ == s and
                              x.hook == "val" and vt is not None and
                              part.get("values") == "in_sector")
                for ref, tag, hook, for_, pts in raw:
                    # its own wedge path is scanned too (its rays and arc
                    # lie ON its boundary; anything else it strokes is in)
                    if (hook == "outline" and for_ == pid and
                            tag == "circle") or ref in own_lab:
                        continue
                    hit = [q for q in pts
                           if self.strictly_inside(q, c, r, lo, span)]
                    if hit:
                        self.fail("CHK_PIE_REGION_DIVIDED", "REGION_UNDIVIDED",
                                  "%s (<%s> %s of %s) lies inside the "
                                  "undivided region %s (e.g. at %.2f, %.2f)"
                                  % (ref, tag, hook, for_, s, hit[0][0],
                                     hit[0][1]), obj=s)
                # the object map: the region's own wedge + its declared
                # value label, nothing else mapped to it
                if om:
                    roles = [it.get("role") for it in om.get(
                        "display_items") or [] if (it.get("source") or {})
                        .get("entity") == s]
                    want = ["sector_wedge"] + (["sector_value_label"]
                                               if own_lab else [])
                    if sorted(roles) != sorted(want):
                        self.fail("CHK_PIE_REGION_MAP", "REGION_UNDIVIDED",
                                  "region %s: map items %s, an undivided "
                                  "region has %s" % (s, sorted(roles),
                                                     sorted(want)), obj=s)
                self.region_raster(g, s, w, own_lab)

    def expected_tiles(self, part):
        """(v6.16 r2) the declared extent of each tile of a pie part (the
        checker's own resolution, start and direction): {sid: {lo, span}}"""
        r = self.ps.res.get(part.get("pie")) or {}
        if r.get("problems") or not r.get("order"):
            return {}
        out = {}
        acc = float(part.get("start") or 0)
        cw = part.get("direction") == "clockwise"
        for s in r["order"]:
            sp = float(r["value"][s] * 360 / r["total"])
            lo = acc if cw else acc - sp
            acc = acc + sp if cw else acc - sp
            out[s] = {"lo": lo % 360.0, "span": sp}
        return out

    def region_raster(self, g, s, w, own_lab):
        """(v6.16 r2) the printed region is ONE fill: sampled at 0.3..0.9 r
        every 0.5 deg strictly inside its range (clear of its boundary
        strokes and its own label), no sample off its fill colour."""
        if self.ras is None:
            return
        e = [x for x in self.els if x.hook == "wedge" and x.for_ == s]
        if not e or not re.match(r"^#[0-9a-f]{6}$", e[0].a.get("fill", "")):
            return
        fill = _rgb(e[0].a["fill"])
        c, r = g["c"], g["r"]
        boxes = [_grow(self.boxes[x], 2.0) for x in own_lab
                 if x in self.boxes]
        off = []
        for frac in (0.3, 0.45, 0.6, 0.75, 0.9):
            rho = frac * r
            m = max(1.5, math.degrees(2.5 / rho))
            if w["span"] <= 2 * m:
                continue
            k = 0
            while True:
                th = w["lo"] + m + 0.5 * k
                if th > w["lo"] + w["span"] - m:
                    break
                k += 1
                p = (c[0] + rho * math.sin(math.radians(th)),
                     c[1] - rho * math.cos(math.radians(th)))
                if any(_box_pt_near(b, p) == 0.0 for b in boxes):
                    continue
                px = self.ras.rgb(*p)
                if px is None:
                    continue
                if sum((u - v) ** 2 for u, v in zip(px, fill)) > \
                        REGION_OFF_RGB2:
                    off.append((round(th % 360.0, 1), round(frac, 2)))
        if len(off) >= 2:
            self.fail("CHK_PIE_REGION_RASTER", "REGION_UNDIVIDED", "region "
                      "%s is not one fill on the print: %d samples off its "
                      "colour (deg, r) %s" % (s, len(off), off[:4]), obj=s)

    # ------------------------------------------------------------ leaks --
    def leaks(self, answer_guard, om):
        ps = self.ps
        hidden = ps.hidden()
        guard = set()
        for gv in answer_guard or []:
            v = gv.get("answer") if isinstance(gv, dict) else gv
            if v in (None, ""):
                continue
            q = _q(str(v).strip())
            if q is not None:
                guard.add(q)
        owned = {}
        for e in self.els:
            if e.tag != "text":
                continue
            # an own given label: a value / legend value of a drawn given,
            # the total of a drawn given total
            if e.hook in ("val", "leg"):
                vt = ps.value_text(e.for_)
                if vt:
                    owned[e.ref] = set([_q(x) for x in number_tokens(vt)])
            if e.hook == "total":
                tf = ps.drawn_total(e.for_)
                if tf:
                    owned[e.ref] = set([_q(tf.get("value"))])
        for e in self.els:
            if e.tag != "text":
                continue
            toks = [_q(t) for t in number_tokens(e.text)]
            for t in toks:
                if t in owned.get(e.ref, ()):
                    continue
                if t in hidden:
                    self.fail("CHK_PIE_HIDDEN_PRINTED",
                              "TARGET_VALUE_NOT_SHOWN", "%s %r prints %s, a "
                              "value the student finds" % (
                                  e.ref, e.text, _dec(t)), obj=e.for_)
                if t in guard:
                    self.fail("CHK_PIE_ANSWER_EXPOSED", "ANSWER_NOT_EXPOSED",
                              "%s %r prints the answer %s" % (
                                  e.ref, e.text, _dec(t)), obj=e.for_)
        # attributes: ids / data-for are grammar-bound (no number); the
        # dialect refuses title / desc / metadata / class / style
        for e in self.els:
            for k in ("data-for", "data-pie"):
                if number_tokens(e.a.get(k, "")):
                    self.fail("CHK_PIE_NUMBER_IN_ATTR", "ANSWER_NOT_EXPOSED",
                              "%s %s=%r" % (e.ref, k, e.a.get(k)))
        if om:
            by_item = dict((it.get("id"), it) for it in
                           om.get("display_items") or [])
            for it in by_item.values():
                t = it.get("text")
                if not t:
                    continue
                own = set()
                for ref in it.get("elements") or []:
                    own |= owned.get(ref, set())
                for x in number_tokens(t):
                    q = _q(x)
                    if q in own:
                        continue
                    if q in hidden or q in guard:
                        self.fail("CHK_PIE_MAP_EXPOSES",
                                  "ANSWER_NOT_EXPOSED", "map item %s text "
                                  "%r carries %s" % (it.get("id"), t, x))
            for oid in (om.get("objects") or {}):
                if number_tokens(oid):
                    self.fail("CHK_PIE_MAP_EXPOSES", "ANSWER_NOT_EXPOSED",
                              "map object id %r carries a number" % oid)

    def marks(self):
        """MUST_NOT_DRAW: nothing but the dialect's wedges / outline /
        leaders / swatches / build circle / dot / labels exists; a wedge in
        a pie with one sector draws no radius (stroke none)."""
        for e in self.els:
            if e.hook not in HOOK_ROLE:
                self.fail("CHK_PIE_MARK", "MUST_NOT_DRAW", "%s: a drawn "
                          "element outside the pie dialect (%s)" % (
                              e.ref, e.tag))
        for pid, g in self.pies.items():
            if len(g.get("geo") or {}) == 1:
                e = [x for x in self.els if x.hook == "wedge" and
                     self.ps.pie_of(x.for_) == pid][0]
                if e.a.get("stroke") not in (None, "none"):
                    self.fail("CHK_PIE_RADIUS_DRAWN", "MUST_NOT_DRAW", "%s: "
                              "a one-sector pie with a stroked wedge draws "
                              "a radius" % e.ref, obj=pid)

    # ------------------------------------------------------------- OCR --
    def ocr(self, F, keep_dir=None):
        from . import ocr as O
        if self.ras is None:
            return {}
        if not O.helper_ok():
            F.review("CHK_OCR_UNAVAILABLE", "OCR_SECTOR_LABELS",
                     "OCR_UNAVAILABLE: no helper")
            return {"__infra__": "OCR_UNAVAILABLE"}
        res = {}
        for invert in (False, True):
            labels = [(e.ref, _ocr_text(_logical(e, self.ps)),
                       self.boxes[e.ref])
                      for e in self.els if e.tag == "text" and
                      e.ref in self.boxes and
                      (e.a.get("fill") == "#ffffff") == invert]
            if labels:
                res.update(O.read_labels(_OcrDisplay(self.ras, invert),
                                         labels, workdir=keep_dir,
                                         keep=bool(keep_dir)))
        return res

    # ----------------------------------------------------------- objmap --
    def objmap(self, om):
        if om is None:
            self.F.review("CHK_PIE_NO_MAP", "OBJMAP_TOTAL_NO_UNMAPPED_INK",
                          "no object map")
            return
        keys = {"engine", "dialect", "figure", "family", "public_hash",
                "settings_hash", "elements", "display_items", "objects"}
        if set(om) != keys:
            self.fail("CHK_PIE_MAP_KEYS", "OBJMAP_TOTAL_NO_UNMAPPED_INK",
                      "map keys %s" % sorted(set(om) ^ keys))
        items = om.get("display_items") or []
        owner = {}
        for it in items:
            for r in it.get("elements") or []:
                if r in owner:
                    self.fail("CHK_PIE_MAP_SHARED",
                              "OBJMAP_TOTAL_NO_UNMAPPED_INK", "%s in %s and "
                              "%s" % (r, owner[r], it.get("id")))
                owner[r] = it
        for e in self.els:
            it = owner.get(e.ref)
            if it is None:
                self.fail("CHK_PIE_UNMAPPED", "OBJMAP_TOTAL_NO_UNMAPPED_INK",
                          "%s (%s) is in no display item" % (e.ref, e.hook))
                continue
            if it.get("role") != HOOK_ROLE.get(e.hook):
                self.fail("CHK_PIE_MAP_ROLE", "OBJMAP_TOTAL_NO_UNMAPPED_INK",
                          "%s: role %r for hook %r" % (e.ref, it.get("role"),
                                                       e.hook))
            if (it.get("source") or {}).get("entity") != e.for_:
                self.fail("CHK_PIE_MAP_SOURCE", "OBJMAP_TOTAL_NO_UNMAPPED_INK",
                          "%s: source %r, the element draws %s" % (
                              e.ref, it.get("source"), e.for_))
            fid = (it.get("source") or {}).get("fact")
            if fid is not None and fid not in self.ps.facts:
                self.fail("CHK_PIE_MAP_SOURCE", "OBJMAP_TOTAL_NO_UNMAPPED_INK",
                          "%s: fact %r not public" % (e.ref, fid))
            if e.tag == "text" and visual(it.get("text") or "") != e.text:
                self.fail("CHK_PIE_MAP_TEXT", "OBJMAP_TOTAL_NO_UNMAPPED_INK",
                          "%s: map text %r, printed %r" % (
                              e.ref, it.get("text"), e.text))
            me = (om.get("elements") or {}).get(e.ref) or {}
            if me.get("tag") != e.tag or me.get("item") != it.get("id"):
                self.fail("CHK_PIE_MAP_ELEMENT",
                          "OBJMAP_TOTAL_NO_UNMAPPED_INK", "%s: elements "
                          "entry %r" % (e.ref, me))
        extra = set(owner) - set(self.by_ref)
        if extra or set(om.get("elements") or {}) != set(self.by_ref):
            self.fail("CHK_PIE_MAP_EXTRA", "OBJMAP_TOTAL_NO_UNMAPPED_INK",
                      "map elements that are not in the file: %s" % sorted(
                          extra | (set(om.get("elements") or {}) -
                                   set(self.by_ref))))
        objs = om.get("objects") or {}
        need = set(self.of_obj) - {FIGURE_OBJECT}   # v6.16 r2: not a map entry
        for oid in sorted(need | set(objs)):
            got = set(p.get("element") for p in (objs.get(oid) or {}).get(
                "parts") or [])
            want = self.of_obj.get(oid, set())
            if oid not in objs:
                self.fail("CHK_PIE_MAP_NO_OBJECT", "HIGHLIGHT_EXACT_ELEMENTS",
                          "object %s is not in the map" % oid, obj=oid)
                continue
            if any(p.get("span") != "whole" for p in objs[oid].get("parts")
                   or []):
                self.fail("CHK_PIE_MAP_SPAN", "HIGHLIGHT_EXACT_ELEMENTS",
                          "%s: a pie part is whole" % oid, obj=oid)
            if got != want:
                self.fail("CHK_PIE_MAP_PARTS", "HIGHLIGHT_EXACT_ELEMENTS",
                          "%s: map parts %s, measured %s" % (
                              oid, sorted(got - want), sorted(want - got)),
                          obj=oid)
            kind = objs[oid].get("kind")
            wk = "legend" if oid.startswith("legend:") else (
                self.ps.ents.get(oid) or {}).get("kind")
            if kind != wk:
                self.fail("CHK_PIE_MAP_KIND", "HIGHLIGHT_EXACT_ELEMENTS",
                          "%s: kind %r, is %r" % (oid, kind, wk), obj=oid)
        for part in self.ps.parts:
            eid = part.get("pie") or part.get("circle")
            if eid and eid not in objs:
                self.fail("CHK_PIE_MAP_NO_OBJECT", "HIGHLIGHT_EXACT_ELEMENTS",
                          "%s is not in the map" % eid, obj=eid)

    # --------------------------------------------------------- measured --
    def report_parts(self):
        for part in self.ps.parts:
            if part.get("part") != "pie":
                continue
            pid = part["pie"]
            g = self.pies.get(pid) or {}
            if "geo" not in g:
                continue
            secs = []
            for s in self.ps.res[pid]["order"]:
                w = g["geo"].get(s)
                if w is None:
                    continue
                labs = [e for e in self.els if e.for_ == s and e.tag ==
                        "text"]
                nm = [_logical(e, self.ps) for e in labs if e.hook == "name"]
                vl = [e.text for e in labs if e.hook == "val"]
                lg = [_logical(e, self.ps) for e in labs if e.hook == "leg"]
                place = [self.label_owner.get(e.ref, ("", ""))[0]
                         for e in labs if e.hook in ("name", "val")]
                secs.append({
                    "sector": s, "name": self.ps.name(s),
                    "tile": "region" if s in self.ps.regions(pid)
                    else "wedge",                               # v6.16 r2
                    "span_deg": round(w["span"], 3),
                    "lo_deg_cw_from_12": round(w["lo"], 3),
                    "hi_deg_cw_from_12": round((w["lo"] + w["span"]) % 360,
                                               3),
                    "fill": [e.a["fill"] for e in self.els if e.hook ==
                             "wedge" and e.for_ == s][0],
                    "name_label": nm[0] if nm else None,
                    "value_label": vl[0] if vl else None,
                    "legend_text": lg[0] if lg else None,
                    "label_place": sorted(set(place))})
            caps = [_logical(e, self.ps) for e in self.els if e.hook ==
                    "cap" and e.for_ == pid]
            tots = [_logical(e, self.ps) for e in self.els if e.hook ==
                    "total" and e.for_ == pid]
            self.measured["parts"].append({
                "part": "pie", "pie": pid, "centre_px": [
                    round(g["c"][0], 3), round(g["c"][1], 3)],
                "radius_px": g["r"], "sectors": secs,
                "names_clockwise_from_12": [
                    self.ps.name(s) for s, _w in sorted(
                        g["geo"].items(), key=lambda kv: kv[1]["lo"])],
                "caption": caps[0] if caps else None,
                "total_label": tots[0] if tots else None,
                "raster": {"rim_radius_px": g.get("raster_rim"),
                           "unpainted_pct": g.get("raster_unpainted"),
                           "rays_deg": g.get("raster_rays")}})
        # (v6.16 r2) the discs as printed, read RIGHT TO LEFT (d1 = the
        # rightmost): drawn / empty, centre, radius, caption
        discs = []
        for part in self.ps.parts:
            eid = part.get("pie") or part.get("circle")
            g = self.pies.get(eid) if part.get("part") == "pie" else \
                getattr(self, "builds", {}).get(eid)
            if not g or "c" not in g:
                continue
            hook = "cap" if part.get("part") == "pie" else "bcap"
            cap = [_logical(e, self.ps) for e in self.els
                   if e.hook == hook and e.for_ == eid]
            discs.append({"entity": eid, "state": "drawn" if part.get(
                "part") == "pie" else "empty", "centre_px": [
                    round(g["c"][0], 3), round(g["c"][1], 3)],
                "radius_px": g["r"], "caption": cap[0] if cap else None})
        discs.sort(key=lambda d: -d["centre_px"][0])
        self.measured["discs_rtl"] = discs
        self.measured["layout"] = self.ps.fr.get("layout")


def _path_points(d, seg):
    """(v6.16 r2) sample points of an SVG path of ANY commands (absolute or
    relative M L H V A C S Q T Z): the segments between on-curve points,
    control points included (a conservative reading)."""
    toks = re.findall(r"[MmLlHhVvAaCcSsQqTtZz]|-?[0-9]*\.?[0-9]+(?:e-?[0-9]+)?",
                      d or "")
    pts, out = [], []
    cur = (0.0, 0.0)
    start = None
    cmd = None
    i = 0
    need = {"M": 2, "L": 2, "H": 1, "V": 1, "A": 7, "C": 6, "S": 4, "Q": 4,
            "T": 2, "Z": 0}
    while i < len(toks):
        t = toks[i]
        if re.match(r"[A-Za-z]", t):
            cmd = t
            i += 1
            if cmd in "Zz":
                if start is not None:
                    out += seg(cur, start)
                    cur = start
            continue
        if cmd is None:
            break
        n = need[cmd.upper()]
        vals = []
        try:
            vals = [float(x) for x in toks[i:i + n]]
        except ValueError:
            break
        if len(vals) < n:
            break
        i += n
        rel = cmd.islower()
        u = cmd.upper()
        if u == "H":
            nxt = (vals[0] + (cur[0] if rel else 0.0), cur[1])
        elif u == "V":
            nxt = (cur[0], vals[0] + (cur[1] if rel else 0.0))
        else:
            ctrl = [(vals[j] + (cur[0] if rel else 0.0),
                     vals[j + 1] + (cur[1] if rel else 0.0))
                    for j in range(0, n - 1, 2)] if u != "A" else []
            if u == "A":
                nxt = (vals[5] + (cur[0] if rel else 0.0),
                       vals[6] + (cur[1] if rel else 0.0))
            else:
                nxt = ctrl[-1]
                pts += ctrl[:-1]
        if u == "M":
            start = nxt
            pts.append(nxt)
            cmd = "l" if rel else "L"
        elif u == "A" and vals[0] == vals[1] and vals[0] > 0 and \
                vals[2] == 0:
            out += _arc_points(cur, nxt, vals[0], int(vals[3]), int(vals[4]))
        else:
            out += seg(cur, nxt)
        cur = nxt
    return out + pts


def _arc_points(p0, p1, R, large, sweep, n=24):
    """(v6.16 r2) points ON a circular SVG arc (endpoint parameterization,
    SVG 1.1 F.6.5, rx = ry = R, no rotation): the arc of a wedge lies on
    its rim, not on its chord"""
    x1p, y1p = (p0[0] - p1[0]) / 2.0, (p0[1] - p1[1]) / 2.0
    if x1p == 0 and y1p == 0:
        return [p0]
    lam = (x1p * x1p + y1p * y1p) / (R * R)
    if lam > 1:
        R *= math.sqrt(lam)
    num = R * R * R * R - R * R * y1p * y1p - R * R * x1p * x1p
    den = R * R * y1p * y1p + R * R * x1p * x1p
    co = math.sqrt(max(0.0, num / den)) * (-1.0 if large == sweep else 1.0)
    cxp, cyp = co * y1p, -co * x1p
    cx, cy = cxp + (p0[0] + p1[0]) / 2.0, cyp + (p0[1] + p1[1]) / 2.0
    t1 = math.atan2((y1p - cyp) / R, (x1p - cxp) / R)
    t2 = math.atan2((-y1p - cyp) / R, (-x1p - cxp) / R)
    dt = t2 - t1
    if sweep and dt < 0:
        dt += 2 * math.pi
    elif not sweep and dt > 0:
        dt -= 2 * math.pi
    return [(cx + R * math.cos(t1 + dt * k / float(n)),
             cy + R * math.sin(t1 + dt * k / float(n))) for k in range(n + 1)]


def _ocr_text(t):
    """what the en-US reader is asked to confirm of a label: an LTR label
    as it is; an RTL label (a caption, a Hebrew legend entry) keeps its
    Hebrew (never read), its digits, %, ° and Latin letters, and drops the
    separators (en dash, colon, comma, hyphen; a point between two digits
    stays) -- the exact text is LABEL_FORM / CAPTION_OWNED / TOTAL_AS_DECLARED
    on the SVG, OCR confirms what is visible."""
    if not has_rtl(t):
        return t
    out = []
    for i, ch in enumerate(t):
        if ch == "." and 0 < i < len(t) - 1 and t[i - 1].isdigit() and \
                t[i + 1].isdigit():
            out.append(ch)
        elif ch in u"\u2013-:,.":
            out.append(" ")
        else:
            out.append(ch)
    return re.sub(" +", " ", "".join(out)).strip()


def _logical(e, ps):
    """the declared logical text a printed element stands for (verified by
    visual() == printed); the printed text itself when none matches."""
    cands = []
    if e.hook in ("name", "leg"):
        n = ps.name(e.for_) or ""
        cands.append(n)
        vt = ps.value_text(e.for_)
        if vt:
            cands.append(n + u" " + vt)
    if e.hook in ("cap", "bcap"):                       # bcap: v6.16 r2
        for p in ps.parts:
            if (p.get("pie") or p.get("circle")) == e.for_ and \
                    p.get("caption"):
                cands.append(p["caption"])
    if e.hook == "total":
        tf = ps.drawn_total(e.for_)
        if tf:
            cands.append(TOTAL_WORDS + (_dec(_q(tf.get("value"))) or ""))
    for c in cands:
        if visual(c) == e.text:
            return c
    return e.text


def check_pie(svg, object_map, public_spec, figure_id, ocr=True,
              answer_guard=None, raster=True, print_pt_per_px=PT_PER_PX,
              png_out=None, keep_ocr_dir=None):
    """Check one finished pie figure (see the module docstring).
    answer_guard: values the harness says must not be exposed (values only).
    print_pt_per_px: printed pt per SVG unit (0.75 unless the page scales
    the figure)."""
    F = Findings()
    ps = PieSpec(public_spec, figure_id)
    if isinstance(svg, str) and not svg.lstrip().startswith("<"):
        with open(svg, "rb") as fh:
            svg = fh.read()
    raw = svg if isinstance(svg, bytes) else svg.encode("utf-8")
    D = load_dialect()
    els, W, H = read_svg(raw, D, F)
    rep = {"checker_version": CHECKER_VERSION, "family": FAMILY,
           "figure": figure_id, "infrastructure": []}
    ras = None
    if els and raster:
        try:
            ras = Raster(raw.decode("utf-8"), W, H)
            if png_out:
                ras.pm.save(png_out)
        except Exception as e:                   # pragma: no cover
            F.review("CHK_RASTER_FAILED", "LABEL_OWNED", "the figure could "
                     "not be rasterised: %s" % e)
    elif els:
        F.review("CHK_RASTER_OFF", "LABEL_OWNED", "raster off: label ink "
                 "boxes are estimated (never PASS on the raster halves)")
    ck = _Check(els, W, H, ps, F, ras, raw.decode("utf-8"), print_pt_per_px)
    if els:
        ck.kinds()
        ck.data()
        ck.measure_texts()
        ck.wedges()
        ck.labels()
        ck.label_gaps()
        ck.leaders()
        ck.legend()
        ck.build()
        ck.captions()
        ck.layout()
        ck.caption_policy()                             # v6.16 r2
        ck.raster_pies()
        ck.regions_undivided(object_map)                # v6.16 r2
        ck.leaks(answer_guard, object_map)
        ck.marks()
        ck.objmap(object_map)
        ck.report_parts()
        if ocr and ras is not None:
            res = ck.ocr(F, keep_dir=keep_ocr_dir)
            if res.pop("__infra__", None):
                rep["infrastructure"].append("OCR_UNAVAILABLE")
            for ref, r in sorted(res.items()):
                e = ck.by_ref[ref]
                st = r.get("status")
                if st == "MISSING":
                    F.fail("CHK_OCR_MISSING", "OCR_SECTOR_LABELS", "%s %r: %s"
                           % (ref, r.get("text"), r.get("detail")),
                           obj=e.for_)
                elif st == "OCR_ERROR":
                    F.review("CHK_OCR_UNAVAILABLE", "OCR_SECTOR_LABELS",
                             "%s: %s" % (ref, r.get("detail")), obj=e.for_)
                    if "OCR_UNAVAILABLE" not in rep["infrastructure"]:
                        rep["infrastructure"].append("OCR_UNAVAILABLE")
                elif st in ("CONTRADICTS", "UNREAD"):
                    F.review("CHK_OCR_" + st, "OCR_SECTOR_LABELS", "%s %r: %s"
                             % (ref, r.get("text"), r.get("detail")),
                             obj=e.for_)
            rep["ocr"] = dict((k, {"status": v.get("status"),
                                   "text": v.get("text"),
                                   "detail": v.get("detail", "")})
                              for k, v in res.items())
    rep["findings"] = F.items
    checks = dict((c, PASS) for c in ALL_CHECKS)
    for f in F.items:
        if f["level"] in (FAIL, REVIEW) and f["check"] in checks:
            checks[f["check"]] = worst([checks[f["check"]], f["level"]])
    if not ocr or ras is None:
        checks["OCR_SECTOR_LABELS"] = NA
    if not any(p.get("part") == "build" for p in ps.parts):
        checks["BUILD_CIRCLE_EMPTY"] = checks["BUILD_CIRCLE_SIZE"] = NA
    if ps.fr.get("layout") != "side_by_side":
        checks["TWO_PIES_LAYOUT"] = NA
    # (v6.16 r2) a row too has one radius; MULTI_PIE_LAYOUT on 2..3 discs
    if ps.fr.get("layout") not in ("side_by_side", "row"):
        checks["SAME_RADIUS_IF_DECLARED"] = NA
        checks["MULTI_PIE_LAYOUT"] = NA
    if ps.fr.get("layout") != "row":
        checks["CAPTION_POLICY"] = NA
    if not ps.regions():
        for c in ("REGION_UNDIVIDED", "REGION_EXTENT_EXACT"):
            checks[c] = NA
    if not any(p.get("names") == "legend" for p in ps.parts):
        checks["LEGEND_MATCHES_SECTORS"] = worst(
            [NA, checks["LEGEND_MATCHES_SECTORS"]], NA) \
            if checks["LEGEND_MATCHES_SECTORS"] == PASS else \
            checks["LEGEND_MATCHES_SECTORS"]
    if not any(e.hook == "leader" for e in els):
        for c in ("LEADER_LINE_OWNED_IF_ANY", "LEADER_LINE_OWNED"):
            if checks[c] == PASS:
                checks[c] = NA
    if not any(p.get("outside") for p in ps.parts):
        if checks["LEADER_LINE_OWNED"] == PASS:
            checks["LEADER_LINE_OWNED"] = NA
    rep["checks"] = checks
    rep["status"] = F.status()
    eo = dict((k, sorted(v)) for k, v in ck.of_obj.items())
    # (v6.16 r2) the whole figure: every element of the file
    eo[FIGURE_OBJECT] = sorted(e.ref for e in els)
    rep["measured"] = dict(ck.measured, elements_of=eo,
                           boxes=dict((k, [round(x, 2) for x in v]) for k, v
                                      in ck.boxes.items()))
    rep["objects"] = _objects(ck, ps, F, object_map)
    return rep


def _kind(eid, ps, om):
    if eid == FIGURE_OBJECT:
        return "figure"
    if eid.startswith("legend:"):
        return "legend"
    k = (ps.ents.get(eid) or {}).get("kind")
    if k:
        return k
    return (((om or {}).get("objects") or {}).get(eid) or {}).get("kind")


def _deps(eid, ps):
    if eid == FIGURE_OBJECT:
        # (v6.16 r2) the whole figure depends on every entity it lists
        return set(ps.fig.get("entities") or []) | set(
            "legend:" + (p.get("pie") or "")[4:] for p in ps.parts
            if p.get("pie")) | {"legend:shared"}
    e = ps.ents.get(eid) or {}
    if e.get("kind") == "sector":
        return set([e.get("pie")])
    if e.get("kind") == "pie":
        return set(s for s, v in ps.ents.items() if v.get("kind") ==
                   "sector" and v.get("pie") == eid)
    return set()


def _concerns(f, eid, deps):
    o = f["object"]
    return o is None or o == eid or o in deps


def _objects(ck, ps, F, om):
    objs = set(ck.of_obj) | set(((om or {}).get("objects") or {}))
    for p in ps.parts:
        objs.add(p.get("pie") or p.get("circle"))
    objs.add(FIGURE_OBJECT)                             # v6.16 r2
    any_fail = any(f["level"] == FAIL for f in F.items)
    out = {}
    for eid in sorted(o for o in objs if o):
        deps = _deps(eid, ps)
        mine = [f for f in F.items if _concerns(f, eid, deps) and
                f["level"] in (FAIL, REVIEW)]
        st = worst([f["level"] for f in mine] + ([FAIL] if any_fail else []))
        out[eid] = {"kind": _kind(eid, ps, om), "status": st,
                    "findings": [f["code"] for f in mine],
                    "depends_on": sorted(d for d in deps if d),
                    "blocked_by": sorted(set(
                        f["object"] for f in mine
                        if isinstance(f["object"], str) and
                        f["object"] != eid))}
    return out


def object_report(rep, eid):
    """The verdict of one scenario object: the figure-wide checks plus its
    own (a FAIL anywhere fails every object: a broken figure ships no
    object)."""
    o = rep["objects"].get(eid)
    if o is None:
        return {"status": REVIEW, "reason": "object %s is not in the "
                "figure's check report" % eid}
    deps = set(o.get("depends_on") or [])
    checks = dict((c, NA if rep["checks"].get(c, NA) == NA else PASS)
                  for c in FIGURE_CHECKS)
    for f in rep["findings"]:
        if _concerns(f, eid, deps) and f["level"] in (FAIL, REVIEW):
            checks[f["check"]] = worst([checks.get(f["check"], PASS),
                                        f["level"]])
    return {"status": o["status"], "checks": checks,
            "depends_on": sorted(deps),
            "blocked_by": list(o.get("blocked_by") or []),
            "infrastructure": list(rep.get("infrastructure") or []),
            "findings": [f for f in rep["findings"]
                         if _concerns(f, eid, deps)]}


__all__ = ["check_pie", "object_report", "is_pie", "visual",
           "CHECKER_VERSION", "FIGURE_CHECKS", "NOTE", "FIGURE_OBJECT"]
