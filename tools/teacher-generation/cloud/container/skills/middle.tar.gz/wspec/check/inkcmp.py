# -*- coding: utf-8 -*-
"""v6.9 (Codex F2): the GEOMETRIC ink of a supplied final display (a page
raster) compared with the approved figure.

The checker measures the geometry on the SVG; a supplied display (the PDF
raster of the figure's box) was read only for its labels. This module binds
the two: every drawable element of the approved SVG (line, dot, arc, mark,
outline) is rendered ALONE by MuPDF at the display's scale and placed where
the display's origin puts it, and

  missing  the element's ink pixels with no display ink within
           INK_MATCH_SVG_PX (text boxes masked out: the labels are the OCR's)
           -- a line that is gone, cut, shifted or rescaled on one axis;
  extra    the display's ink inside the canvas with no approved ink within
           INK_MATCH_SVG_PX and outside every label box -- an element the
           approved figure does not have, a rule across the figure, a
           shifted copy.

Pure stdlib + PyMuPDF. Rows are Python ints (bit x = pixel x is ink)."""
import re

from . import tol as T

DRAW_RE = re.compile(r"<(line|circle|polygon|polyline|path|text)\b"
                     r"(?:[^>]*?/>|[^>]*>[^<]*</\1>)")
NUM_RE = re.compile(r"-?\d+(?:\.\d+)?")
ATTR_RE = re.compile(r'([\w:-]+)="([^"]*)"')


def elements(svg):
    """[(ref, tag, snippet, bbox)] of the drawables in document order (the
    dialect's positional ref e%04d); bbox in SVG units, grown by the stroke
    width, None for text."""
    out = []
    for k, m in enumerate(DRAW_RE.finditer(svg), 1):
        tag, snip = m.group(1), m.group(0)
        a = dict(ATTR_RE.findall(snip.split(">", 1)[0]))
        ref = a.get("id") or "e%04d" % k
        if tag == "text":
            out.append((ref, tag, snip, None))
            continue
        xs, ys = [], []
        if tag == "line":
            xs = [float(a["x1"]), float(a["x2"])]
            ys = [float(a["y1"]), float(a["y2"])]
        elif tag == "circle":
            r = float(a.get("r", 0))
            xs = [float(a["cx"]) - r, float(a["cx"]) + r]
            ys = [float(a["cy"]) - r, float(a["cy"]) + r]
        else:
            nums = [float(v) for v in NUM_RE.findall(
                a.get("d") or a.get("points") or "")]
            xs, ys = nums[0::2], nums[1::2]
        if not xs or not ys:
            continue
        g = float(a.get("stroke-width") or 0) + 1.0
        out.append((ref, tag, snip, (min(xs) - g, min(ys) - g,
                                     max(xs) + g, max(ys) + g)))
    return out


def _rows(pm, level=T.RASTER_INK_LEVEL):
    """bit rows of a grey pixmap (bit x set = ink)."""
    tab = bytes((49 if v < level else 48) for v in range(256))   # '1' / '0'
    w, st, s = pm.width, pm.stride, pm.samples
    out = []
    for y in range(pm.height):
        row = bytes(s[y * st: y * st + w]).translate(tab)
        out.append(int(row[::-1], 2) if row else 0)
    return out


def _dilate(rows, r):
    h = [m for m in rows]
    for i in range(1, r + 1):
        h = [m | (m << i) | (m >> i) for m in h]
    out = []
    n = len(h)
    for y in range(n):
        m = 0
        for j in range(max(0, y - r), min(n, y + r + 1)):
            m |= h[j]
        out.append(m)
    return out


def _count(m):
    return bin(m).count("1")


def _box_mask(boxes, s, ox, oy, n_rows, width, pad):
    """rows of the label boxes (SVG units, grown by pad) in display px."""
    rows = [0] * n_rows
    for b in boxes:
        x0 = max(0, int(ox + (b[0] - pad) * s))
        x1 = min(width, int(ox + (b[2] + pad) * s + 1))
        y0 = max(0, int(oy + (b[1] - pad) * s))
        y1 = min(n_rows, int(oy + (b[3] + pad) * s + 1))
        if x1 <= x0:
            continue
        m = ((1 << (x1 - x0)) - 1) << x0
        for y in range(y0, y1):
            rows[y] |= m
    return rows


def compare(disp, svg, W, H, text_boxes, render):
    """{missing: {ref: (miss_px, ink_px)}, extra_px, extra_box, r_px,
    scale} -- disp: the Display holding the supplied image; render(svg,
    x0, y0, w, h, scale) -> grey pixmap of that viewBox at that scale."""
    s = float(disp.scale)
    ox, oy = disp.origin
    pm = disp.pm
    r = max(1, int(round(T.INK_MATCH_SVG_PX * s)))
    shown = _rows(pm)
    n, width = len(shown), pm.width
    # the canvas on the display: only ink there is the figure's business
    cx0, cy0 = max(0, int(ox)), max(0, int(oy))
    cx1, cy1 = min(width, int(ox + W * s + 0.999)), \
        min(n, int(oy + H * s + 0.999))
    canvas = ((1 << max(0, cx1 - cx0)) - 1) << cx0
    mask = _box_mask(text_boxes, s, ox, oy, n, width, T.INK_TEXT_PAD_SVG_PX)
    shown_d = _dilate(shown, r)
    head_end = svg.index(">", svg.index("<svg")) + 1
    head = svg[:head_end]
    ref_rows = [0] * n
    missing, gaps = {}, {}
    for ref, tag, snip, bb in elements(svg):
        if bb is None:
            continue
        x0, y0, x1, y1 = bb
        epm = render(head + snip + "</svg>", x0, y0, x1 - x0, y1 - y0, s)
        er = _rows(epm)
        dx = int(round(ox + x0 * s))
        dy = int(round(oy + y0 * s))
        ink = miss = 0
        for j, m in enumerate(er):
            if not m:
                continue
            y = dy + j
            m = (m << dx) if dx >= 0 else (m >> -dx)
            if 0 <= y < n:
                ref_rows[y] |= m
                m &= ~mask[y]
                ink += _count(m)
                miss += _count(m & ~shown_d[y])
            else:
                c = _count(m)
                ink += c
                miss += c
        missing[ref] = (miss, ink)
        if tag in ("line", "polygon", "polyline"):
            gaps[ref] = _longest_gap(tag, snip, s, ox, oy, shown_d, mask, n,
                                     width)
    ref_d = _dilate(ref_rows, r)
    extra, eb = 0, None
    for y in range(n):
        m = shown[y] & canvas & ~ref_d[y] & ~mask[y]
        if not m:
            continue
        c = _count(m)
        extra += c
        xa, xb = (m & -m).bit_length() - 1, m.bit_length() - 1
        eb = [xa, y, xb, y] if eb is None else [min(eb[0], xa), eb[1],
                                                max(eb[2], xb), y]
    if eb is not None:
        eb = [round((eb[0] - ox) / s, 1), round((eb[1] - oy) / s, 1),
              round((eb[2] + 1 - ox) / s, 1), round((eb[3] + 1 - oy) / s, 1)]
    return {"missing": missing, "gaps": gaps, "extra_px": extra,
            "extra_box": eb, "r_px": r, "scale": s}


def _vertices(tag, snip):
    a = dict(ATTR_RE.findall(snip.split(">", 1)[0]))
    if tag == "line":
        return [(float(a["x1"]), float(a["y1"])),
                (float(a["x2"]), float(a["y2"]))]
    nums = [float(v) for v in NUM_RE.findall(a.get("points") or "")]
    pts = list(zip(nums[0::2], nums[1::2]))
    if tag == "polygon" and pts:
        pts.append(pts[0])
    return pts


def _longest_gap(tag, snip, s, ox, oy, shown_d, mask, n, width):
    """(v6.9 fix r1, E3) the longest run (SVG px) along a straight stroke
    with no display ink within INK_MATCH_SVG_PX -- a white patch that cuts a
    visible gap into a line removes only a small SHARE of a long line's
    ink, but the gap is there all the same. Label boxes count as ink."""
    step = T.INK_GAP_STEP_SVG_PX
    worst = 0.0
    pts = _vertices(tag, snip)
    pieces = list(zip(pts, pts[1:]))
    if tag == "line":
        from .raster import line_dash_segments
        dashed = line_dash_segments(snip)
        if dashed is not None:
            # Intentional spaces are not missing ink. Sample every real
            # painted dash, with the same source phase/caps as the reference.
            pieces = dashed
    for (x0, y0), (x1, y1) in pieces:
        L = ((x1 - x0) ** 2 + (y1 - y0) ** 2) ** 0.5
        k = max(1, int(L / step))
        run = 0.0
        for i in range(k + 1):
            x = x0 + (x1 - x0) * i / float(k)
            y = y0 + (y1 - y0) * i / float(k)
            px, py = int(ox + x * s), int(oy + y * s)
            if not (0 <= py < n and 0 <= px < width):
                run += L / k
            elif (mask[py] >> px) & 1 or (shown_d[py] >> px) & 1:
                run = 0.0
            else:
                run += L / k
            worst = max(worst, run)
    return round(worst, 2)
