# -*- coding: utf-8 -*-
"""Named tolerances of the independent checker (all in SVG user units = px of
the figure canvas unless the name says otherwise). Every comparison in
wspec/check uses one of these names; nothing is compared against a bare
number."""

CHECKER_VERSION = "wspec-check/1"

# --- incidence / positions
PT_TOL_PX = 0.1          # a hook end / polygon vertex sits on its point dot
ON_TOL_PX = 0.5          # a point lies on a drawn straight piece
COLLINEAR_TOL_PX = 0.5   # two pieces are on one line (end distance to the line)
COVER_GAP_PX = 0.5       # collinear pieces that leave no larger gap cover a span
LINE_EXT_MIN_PX = 6.0    # a line / ray runs past its named point(s) by at least this
RAY_BACK_TOL_PX = 0.5    # a ray does not start behind its first point

# --- metric facts (figure_accuracy == accurate only)
ANGLE_TOL_DEG = 0.5
LEN_REL_TOL = 0.01       # equal lengths / one scale for all length facts
PAR_TOL_DEG = 0.5        # parallel / perpendicular directions
MID_TOL_PX = 0.5         # a midpoint is the middle within this

# --- marks
ARC_MIN_R_PX = 8.0
ARC_MAX_R_PX = 40.0
ARC_RADIUS_TOL_PX = 0.3  # every arc sample at the same distance from the vertex
ARC_SAGITTA_PX = 0.1     # every chord between two samples stays on the circle
ARC_MAX_STEP_DEG = 10.0  # and spans at most this angle (a 3-sample arc is a chord pair)
ARC_END_TOL_DEG = 1.5    # first / last sample on the arms
RIGHT_MIN_PX = 5.0
RIGHT_MAX_PX = 20.0
RIGHT_TOL_PX = 0.3
TICK_MIN_PX = 4.0
TICK_MAX_PX = 16.0
TICK_MIN_DEG = 45.0      # a tick crosses its segment at least this steeply
TICK_SPREAD_PX = 10.0    # the ticks of one mark stay this close to the middle
PAR_ARROW_SPREAD_PX = 14.0

# --- labels (boxes are the ink boxes measured on the raster, or the
#     estimated glyph box when no raster is available)
GLYPH_W = 0.6            # estimated glyph box: width per char * font-size
GLYPH_H = 0.72           # cap height * font-size (above the baseline)
GLYPH_D = 0.22           # descent * font-size (below the baseline)
LABEL_NEAR_PX = 24.0     # a point name within this of its point (box to dot)
LABEL_MARGIN_PX = 2.0    # own point / piece / arc nearer than any other by this
LABEL_VALUE_PX = 40.0    # a segment value within this of its segment
CAPTION_ARC_PX = 20.0    # an angle value within this of its own arc
LABEL_SEG_END_FRAC = 0.1  # a segment value beside its middle part (not its ends)
CAPTION_NAME_GAP_PX = 8.0  # (v6.9 fix r1) a segment value this near the name of a
                           # point that splits the segment, on its side: REVIEW
CANVAS_MARGIN_PX = 0.5   # the whole ink box inside the canvas by this
LABEL_CLEAR_PX = 0.5     # a label box grown by this touches no dot / mark
LABEL_STROKE_TOL_PX = 2.0  # a straight piece may cross a label box for this long
LABEL_CORE_PX = 1.0      # a label's core = its ink box shrunk by this: no dot
                         # centre and no mark may enter it, and no ink pixel may
                         # come within LABEL_CLEAR_PX of a dot / mark stroke

# --- raster / OCR
RASTER_SCALE = 4         # final display raster: 4 px per SVG unit
RASTER_INK_LEVEL = 160   # a raster pixel is ink below this grey level (shade #e6 is not)
# --- v6.9 (Codex F2): the geometric ink of a SUPPLIED final display
INK_MATCH_SVG_PX = 0.6   # approved ink and displayed ink match within this
INK_TEXT_PAD_SVG_PX = 2.0  # label boxes (the OCR's business) grown by this
INK_MISSING_FAIL = 0.20  # an element missing more than this share of its ink: FAIL
INK_MISSING_REVIEW = 0.05  # ... more than this share (and INK_MIN_SVG_PX2): REVIEW
INK_MIN_SVG_PX2 = 0.5    # smallest ink area (SVG px^2) that counts as a finding
INK_GAP_FAIL_SVG_PX = 3.0  # (v6.9 fix r1, E3) a straight stroke cut by a gap this
                           # long (no display ink along it): FAIL, whatever share
INK_GAP_STEP_SVG_PX = 0.5  # sampling step along the stroke
INK_EXTRA_FAIL_SVG_PX2 = 2.0  # foreign ink in the canvas at least this area: FAIL
DIFF_LEVEL = 24          # a pixel belongs to a text when removing it changes it by this
OCR_GLYPH_H_PX = (40, 32, 52)  # crops are height-normalised to these (Vision
                                # reads glyphs ~30-50 px tall; bigger fails)
OCR_TILE = 3             # a one-character label is tiled 3x (Vision skips lone letters)
OCR_MIN_CONF = 0.3
# characters Vision confuses in isolation; a read of a confusable of the
# expected character confirms it (it cannot tell them apart on its own) --
# but only when the read is not also a read of ANOTHER label of the same
# figure (ocr.read_labels: then it is ambiguous -> REVIEW, never a guess).
# D is not in the O group: Vision reads O as 0/O and D as D, so a D read at
# an O label is a different letter, not a look-alike (fix_engine S1).
# Cyrillic / Greek capitals Vision may return for a Latin glyph (the same shape)
OCR_HOMOGLYPHS = dict(zip(u"АВСЕНКМОРТХУаеорсухΑΒΕΖΗΙΚΜΝΟΡΤΥΧ",
                          u"ABCEHKMOPTXYaeopcyxABEZHIKMNOPTYX"))
OCR_CONFUSABLE = [set("O0oQ"), set("Il1|i!"), set("S5s"), set("Z2z"),
                  set("B8"), set("°o0"), set("Cc"), set("Kk"), set("Pp"),
                  set("Uu"), set("Vv"), set("Ww"), set("Xx"), set("Yy")]
# --- v6.13 (BRIEF_V613 s.3): expected-set matching on crops (ocr_expect.py;
#     used by the family checkers coord / nline only)
GLYPH_HOLE_MIN_FRAC = 0.01   # a hole smaller than this share of the char box is noise
GLYPH_HOLE_LOW = 0.55        # 6: the hole's centre below this share of the height
GLYPH_HOLE_HIGH = 0.45       # 9: the hole's centre above this share of the height
GLYPH_ASPECT_MIN_LOG = 0.15  # O / 0 references must differ by this (|log| of aspects)
GLYPH_ASPECT_THIRD = 1.0 / 3  # the crop sits in this share of the interval by its reference
GLYPH_Q_MIN_LOG = 0.10       # (v6.16 fix r1) Q vs O and vs 0 references must differ by this
GLYPH_STEM_FLAT = 0.06       # B: the left edge moves by at most this share of the width
GLYPH_STEM_CURVED = 0.18     # 8: ... by at least this share
BAR_MIN_WIDE = 1.5           # a minus bar is this many times wider than tall
BAR_SOLID = 0.75             # and inks this share of its box
GLYPH_PAD_EM = 0.5           # the shape crop reaches this share of the font size past the approved box
