# -*- coding: utf-8 -*-
u"""v6.13 -- BOUND PROSE, TABLES and WORKED EXAMPLES in a spec (author
decision W-BOUND-PROSE, wspec/approvals/APPROVALS_NOAM.json, 2026-09-24).

The ORIGINAL wording of a question may be printed as it is -- no per-sentence
template -- when every NUMBER, VARIABLE and POINT / SEGMENT / ANGLE / POLYGON
NAME in it is BOUND to a spec fact or entity. The binding table is part of
the spec, the public model carries it, and gate G80 (textbind.py) verifies
the printed block against it. What was prose before (free Hebrew, approved
by hash, no maths at all) stays as it was; bound prose is another segment:

  a text segment      {"bound": BLOCK}          (question or item text)
  a question's table  "table":   {"head": [CELL...], "rows": [[CELL...]...],
                                  "hcol": bool, "cls": "wide"}
  a worked example    "example": {"title": BLOCK, "lines": [BLOCK...]}
  CELL                BLOCK | {"blank": true}   (an empty cell to fill in)
  BLOCK               {"text": u"...", "bind": [BIND...], "prints": [fid...]}
  BIND                {"tok": <atom as printed>, ONE OF
                         "fact": fid        a number = that fact's value
                                 [fid...]   (v6.13 fix_r1) one number /
                                            number word stating the SAME
                                            value of several facts ("קווי
                                            רשת של חצאי יחידות": the step
                                            of axis x AND of axis y)
                         "entity": eid      a name = that entity's name, or
                                            a number = a number / tick entity
                         "count": [eid...]  a number (or number word) = how
                                            many entities are listed
                         "intervals": figid (v6.13 fix_r1) a number (word) =
                                            how many equal intervals the
                                            figure's frame draws ("שישה
                                            מרווחים שווים"); every axis of
                                            the frame has that many
                         "enum": k          a list marker (1)(2)(3): 1..n
                         "question": qid    a question number ("שאלה 3")
                         "calc": u"6 - 6"   (v6.13 fix_r2) a number that is
                                            the RESULT of arithmetic on the
                                            number atoms printed just before
                                            it ("$6 - 6 = 0$": a student's
                                            calculation quoted by the item);
                                            the expression's numbers are
                                            exactly those atoms, in order,
                                            and it must evaluate to the
                                            printed number}

THE ATOMS (atoms(text)): the text is read island by island ($...$) and
outside the islands -- numbers (a unary minus U+2212 or '-' belongs to the
number: "(−2, 3)"; "6 − 6" is two numbers; a hyphen after a Hebrew letter
is a maqaf), fractions \\f{p}{q}, mixed 1\\f{1}{2}, roots 2\\sqrt{3},
upper-case names (A, AB, ABCD, A', A1), angle names (∠ABC, \\angle{ABC}),
triangle names (△ABC, \\tri ABC), lower-case names (x, y, xy) and -- outside
the islands -- Hebrew NUMBER WORDS (schema.PROSE_NUMBER_WORDS with its
prefix / suffix rule; "כל אחד" / "אחד מה…" are not numbers). The bind list
is the atom list, in order, one entry per atom (BOUND_UNBOUND: an atom with
no entry; BOUND_STALE: an entry no atom prints). Operators and relation
signs are not atoms; the printed text itself is frozen by the baseline and
bound to the PDF by G80. (v6.14 F1) The one structure that IS read: a
COORDINATE PAIR "(a, b)" (optionally after a point name, "C(−3, 2)") is one
unit -- its first number is bound to the point's x-coordinate fact, its
second to its y-coordinate fact (BOUND_COORD_ROLE; coord_role_problems).

WHAT A BINDING PROVES (BOUND_* refusals):
  * a number bound to a fact is that fact's value; the fact is visible from
    the block's scope and PUBLIC-valued: given / context / to_prove, or a
    released derived. A number bound to a target, an answer, a to_plot or a
    to_construct is BOUND_TARGET_VALUE -- a number that merely EQUALS a
    private answer of the block's item (or a later item; the stem: every
    item) is refused too unless it is bound to a public fact or is a datum
    the block's printed facts are built on;
  * a name bound to an entity is that entity's name (a segment either way
    round, an angle arm-vertex-arm, a polygon any rotation / direction);
  * W-ANGLE-3-LETTERS: an angle is named by three letters (∠A is refused,
    BOUND_ANGLE_ONE_LETTER); W-TRIANGLE-SYMBOL: a triangle's name carries
    △ (BOUND_TRI_SIGN);
  * `prints` lists what the block STATES beyond its numbers (a target it
    asks, a to_plot, a relation such as parallel): facts of the block's
    own scope, never an answer; a printed fact that carries a public value
    must have that value bound in the block (BOUND_FACT_UNSTATED) and the
    objects it names must be named in the block or before it in the
    question (BOUND_FACT_UNNAMED). A fact a number is bound to is printed
    by the block as well.
Tables and examples belong to their QUESTION (scope = the question id).
A table is data: each cell is a block (or a blank to fill in); a worked
example is bound prose. Both reach the public model -- and Noam AI -- only
through the whitelist of project.PUBLIC_KEYS."""
import re
import unicodedata
from fractions import Fraction

from . import canon
from .errors import Issue, REASONS

# ------------------------------------------------------ reason codes ---
_CODES = {
    "BOUND_BAD_BLOCK": "a bound block / table / example is not in its closed form (fields, types)",
    "BOUND_UNBOUND": "an atom of bound prose (a number, a number word, a name, a variable) has no binding",
    "BOUND_STALE": "a binding names an atom the bound text does not print (or in another order)",
    "BOUND_REF": "a binding names no existing fact / entity / question, or more than one kind of target",
    "BOUND_VALUE_MISMATCH": "a bound number is not the value of the fact / entity / count it is bound to",
    "BOUND_NAME_MISMATCH": "a bound name is not the printed name of the entity it is bound to",
    "BOUND_KIND": "a binding of the wrong kind for its atom (a name to a fact, a number to a point ...)",
    "BOUND_TARGET_VALUE": "bound prose prints a private value: a number bound to a target / answer / to_plot / to_construct, or equal to a private answer of its item",
    "BOUND_PRIVATE": "a bound number's fact is not public (a derived fact without a release)",
    "BOUND_SCOPE": "a binding or a printed fact is outside the scopes the block can see / state",
    "BOUND_FACT_UNSTATED": "a fact the block says it prints carries a public value that no atom of the block is bound to",
    "BOUND_FACT_UNNAMED": "a fact the block says it prints names an object that neither the block nor the question before it names",
    "BOUND_PRINTS_PRIVATE": "a bound block claims to print an answer (or a derived fact without a release)",
    "BOUND_ANGLE_ONE_LETTER": "an angle printed with one letter (W-ANGLE-3-LETTERS: always three letters)",
    "BOUND_TRI_SIGN": "a triangle printed by name without the sign \u25b3 (W-TRIANGLE-SYMBOL)",
    "BOUND_ENUM": "list markers (1)(2)(3) of a block are not 1, 2, 3 ... in order",
    "BOUND_COORD_ROLE": "(v6.14) a coordinate pair (a, b) does not carry its roles: the first number is not bound to the x-coordinate fact, the second to the y-coordinate fact, of the one point printed before the pair",
}
for _k, _v in _CODES.items():
    REASONS.setdefault(_k, _v)

BLOCK_FIELDS = {"text": True, "bind": True, "prints": False}
BIND_REFS = ("fact", "entity", "count", "enum", "question", "intervals",
             "calc",
             # (v6.16 integrate) a PUBLIC number / name of a graph figure of
             # the block's question ("<figure>/<object>/<part>",
             # wspec/sheet_graph.py) and a percent word bound to its pie's
             # unit ("pie:<name>/unit", wspec/sheet_pie.py)
             "graph", "pie")
TABLE_FIELDS = {"head": False, "rows": True, "hcol": False, "cls": False}
TABLE_CLASSES = ("", "wide")
EXAMPLE_FIELDS = {"title": True, "lines": True}
# roles whose value a bound number may print
PUBLIC_VALUE_ROLES = ("given", "context", "to_prove")
PRIVATE_VALUE_ROLES = ("target", "answer", "to_plot", "to_construct")
# entity kinds a name atom may be bound to, by atom kind
NAME_KINDS = {"name": ("point", "segment", "line", "ray", "polygon",
                       "circle", "arc",
                       "sector"),        # v6.16 integrate: a sector 'A'

              "angle": ("angle",), "triangle": ("polygon",),
              "var": ("variable", "axis", "plane", "line")}
# kinds that need not be named for a printed fact (the frame, not a name)
# (v6.16 gaps, G2: the origin -- the axes' crossing, called by its term
# "ראשית הצירים", never by a letter the sheet prints)
UNNAMED_OK = ("axis", "plane", "tick", "cline", "table_cell", "origin",
              # (v6.16 integrate) a pie / an empty build circle has no
              # printed name (a question says "התרשים", "העוגה"); a sector
              # has one -- its category label -- and must be named
              "pie", "build_circle")

# ---------------------------------------------------------- number words -
WORD_VALUES = {}
for _w, _v in (
        (u"אפס", 0), (u"אחד", 1), (u"אחת", 1), (u"שניים", 2), (u"שנים", 2),
        (u"שתיים", 2), (u"שתים", 2), (u"שני", 2), (u"שתי", 2),
        (u"שלוש", 3), (u"שלושה", 3), (u"שלשה", 3), (u"שלושת", 3),
        (u"שלש", 3), (u"ארבע", 4), (u"ארבעה", 4), (u"ארבעת", 4),
        (u"חמש", 5), (u"חמישה", 5), (u"חמשה", 5), (u"חמשת", 5),
        (u"שש", 6), (u"שישה", 6), (u"ששה", 6), (u"ששת", 6), (u"שבע", 7),
        (u"שבעה", 7), (u"שבעת", 7), (u"שמונה", 8), (u"שמונת", 8),
        (u"תשע", 9), (u"תשעה", 9), (u"תשעת", 9), (u"עשר", 10),
        (u"עשרה", 10), (u"עשרת", 10), (u"עשרים", 20), (u"שלושים", 30),
        (u"שלשים", 30), (u"ארבעים", 40), (u"חמישים", 50), (u"שישים", 60),
        (u"ששים", 60), (u"שבעים", 70), (u"שמונים", 80), (u"תשעים", 90),
        (u"מאה", 100), (u"מאתיים", 200), (u"אלף", 1000), (u"אלפיים", 2000),
        (u"תריסר", 12), (u"חצי", "1/2"), (u"חציו", "1/2"),
        (u"חציה", "1/2"), (u"מחצית", "1/2"), (u"מחציתו", "1/2"),
        (u"מחציתה", "1/2"), (u"שליש", "1/3"), (u"רבע", "1/4"),
        # v6.13 fix_r1 (C3): the plural unit fractions of a scale ("מרווחיו
        # הם חצאים", "קווי רשת של חצאי יחידות") are number words with a value
        (u"חצאים", "1/2"), (u"חצאי", "1/2"), (u"שלישים", "1/3"),
        (u"רבעים", "1/4"), (u"חמישיות", "1/5"), (u"עשיריות", "1/10"),
        (u"חמישית", "1/5"), (u"עשירית", "1/10"), (u"ראשון", 1),
        (u"ראשונה", 1), (u"שנייה", 2), (u"שנית", 2), (u"שלישי", 3),
        (u"שלישית", 3), (u"רביעי", 4), (u"רביעית", 4), (u"חמישי", 5),
        (u"שישי", 6), (u"שביעי", 7), (u"שמיני", 8), (u"תשיעי", 9),
        (u"עשירי", 10), (u"פעמיים", 2), (u"כפליים", 2), (u"זוג", 2)):
    WORD_VALUES[_w] = Fraction(_v)


def word_value(tok):
    """The value of a Hebrew number word (prefixes / one suffix stripped as
    schema._number_word does), or None when the word has no fixed value
    (מאות, ישרה ...): such a word is bound without a value check.
    (v6.16 fix r1 cont.) a maqaf compound 11..19 and a fraction phrase
    '<number word> חלקי <number word>' (_merge_teens / _merge_fraction_
    phrases) have their value: 'אחד־עשר' 11, 'אחד חלקי אחד־עשר' 1/11."""
    from . import schema as S
    tok = tok or u""
    if (u" %s " % FRACTION_WORD) in tok:
        p, _w, q = tok.partition(u" %s " % FRACTION_WORD)
        vp, vq = word_value(p), word_value(q)
        return (vp / vq) if (vp is not None and vq) else None
    for mq in MAQAF:
        if mq in tok:
            u, _m, t = tok.partition(mq)
            if u in TEEN_UNITS and t in TEEN_TAILS:
                return Fraction(TEEN_UNITS[u] + 10)
    stems = S._strip_prefixes(tok)
    for st in list(stems):
        for suf in S.PROSE_SUFFIXES:
            if st.endswith(suf) and len(st) - len(suf) >= 2:
                stems.append(st[:-len(suf)])
    for st in stems:
        if st in WORD_VALUES:
            return WORD_VALUES[st]
    return None


# ------------------------------------------------------------- atoms ---
_ISLAND = re.compile(r"(?<!\\)\$([^$]*)\$")
_NAME = r"(?:[A-Z][1-9]?'{0,3})+"
_NUM = r"(?:\d+(?:\.\d+)?(?:_\d+/\d+|/\d+)?(?:√\d+)?|√\d+)"
_SCAN = re.compile(
    u"(?P<angle>∠\\s*(?P<an>" + _NAME + u"))"
    u"|(?P<tri>△\\s*(?P<tn>" + _NAME + u"))"
    u"|(?P<sign>[\u2212+\\-]?)(?P<num>" + _NUM + u")"
    u"|(?P<name>" + _NAME + u")"
    u"|(?P<var>[a-z]+)"
    u"|(?P<heb>[\u05d0-\u05ea]+)")
# the chars after which a sign is binary ("6 − 6", "x − 1", "(a) − 2")
_BINARY_BEFORE = re.compile(u"[0-9A-Za-z)\\]'\u2032]")


def _untex(s):
    """An island's TeX as the plain string the scanner reads."""
    s = s.replace(u"\u2032", "'")
    s = re.sub(r"\\angle\s*\{([^}]*)\}", u"∠\\1", s)
    s = re.sub(r"\\(?:tri|triangle)(?![a-zA-Z])\s*\{?\s*(" + _NAME +
               r")\s*\}?", u"△\\1", s)
    # a mixed number 1\f{1}{2} -> 1_1/2 (one atom); a fraction -> p/q
    s = re.sub(r"(\d+)\s*\\(?:f|frac|dfrac|tfrac|d)\s*\{\s*(\d+)\s*\}\s*"
               r"\{\s*(\d+)\s*\}", r"\1_\2/\3", s)
    s = re.sub(r"\\(?:f|frac|dfrac|tfrac|d)\s*\{([^}]*)\}\s*\{([^}]*)\}",
               r"\1/\2", s)
    s = re.sub(r"\\sqrt\s*\{\s*(\d+)\s*\}", u"√\\1", s)
    s = re.sub(r"([A-Z]'{0,3})_\{?([1-9])\}?", r"\1\2", s)
    s = re.sub(r"\\[a-zA-Z]+", " ", s)
    return s.replace("{", " ").replace("}", " ")


def _scan(s, outside):
    """[(kind, tok)] of a plain string. outside: Hebrew text (number words
    are atoms, a hyphen after a Hebrew letter is a maqaf)."""
    return [(k, t) for k, t, _a, _b in _scan_spans(s, outside)]


def _scan_spans(s, outside):
    """(v6.14 F1) _scan with each atom's span in `s`: [(kind, tok, start,
    end)] (a number's span includes its sign)."""
    from . import schema as S
    out = []
    spans = []
    heb_spans = []
    for m in _SCAN.finditer(s):
        spans.append((m.start(), m.end()))
        if m.group("angle"):
            nm = m.group("an")
            out.append(("angle", u"∠" + nm))
        elif m.group("tri"):
            out.append(("triangle", u"△" + m.group("tn")))
        elif m.group("num"):
            sign = m.group("sign") or ""
            if sign:
                before = s[:m.start()].rstrip()
                prev = before[-1:] if before else ""
                binary = bool(prev) and (
                    _BINARY_BEFORE.match(prev) is not None or
                    (sign == "-" and u"\u05d0" <= prev <= u"\u05ea") or
                    (sign == "-" and outside and prev == u"\u05be"))
                if binary:
                    sign = ""
            tok = m.group("num").replace("_", " ")
            if sign in (u"\u2212", "-"):
                tok = u"\u2212" + tok
            elif sign == "+":
                tok = "+" + tok
            out.append(("number", tok))
        elif m.group("name"):
            out.append(("name", m.group("name")))
        elif m.group("var"):
            out.append(("var", m.group("var")))
        elif m.group("heb") and outside:
            heb_spans.append((len(out), m.group("heb"), m.start(), m.end()))
            out.append(("heb", m.group("heb")))
        else:
            spans.pop()                     # a Hebrew word inside an island
    # (v6.16 fix r1 cont., D-C1) a MAQAF compound of 11..19 ('אחד־עשר') is
    # ONE number word, not 'אחד' + 'עשר'
    heb_spans, drop, merged = _merge_teens(s, heb_spans)
    # Hebrew words: only number words are atoms; "כל אחד" / "אחד מה…" not
    toks = [h[1] for h in heb_spans]
    glued = [False] + [set(s[heb_spans[j - 1][3]:heb_spans[j][2]]) == set(" ")
                       for j in range(1, len(heb_spans))]
    keep = set()
    for i, (pos, w, _a, _b) in enumerate(heb_spans):
        if pos in merged or (
                S._number_word(w) and not S._fixed_one(toks, i, glued) and
                not _adjacent_pair(toks, i, glued) and
                not _one_of_lines(toks, i, glued)):
            keep.add(pos)
    # (v6.16 fix r1 cont., D-C1) a FRACTION PHRASE '<number word> חלקי
    # <number word>' ('אחד חלקי אחד־עשר' = 1/11) is ONE number atom
    drop2 = _merge_fraction_phrases(s, heb_spans, keep, merged)
    drop |= drop2
    return [("word", merged.get(n, (t, a, b))[0], merged.get(n, (t, a, b))[1],
             merged.get(n, (t, a, b))[2]) if k == "heb" else (k, t, a, b)
            for n, ((k, t), (a, b)) in enumerate(zip(out, spans))
            if n not in drop and (k != "heb" or n in keep)]


# (v6.16 fix r1 continuation, the G8-T30 c pilot's skill gap D-C1: 9ג prints
# "אחד חלקי אחד־עשר", one eleventh; the scanner read three number words 1, 1,
# 10, so no atom could carry the given value 1/11 and the declared figure
# c:q9c could not be printed). Two narrow atoms, nothing else changes:
#   * a MAQAF compound of a unit word and עשר / עשרה (11..19) is one number
#     word ('אחד־עשר' 11, 'שתים־עשרה' 12); written with a SPACE ('אחד עשר')
#     it stays two words, as before (no sheet prints a maqaf compound but
#     G8-T30 c q9c -- checked over every v6.16 level file);
#   * '<number word> חלקי <number word>' (spaces only between) is one number
#     atom whose value is the quotient ('אחד חלקי אחד־עשר' = 1/11); 'הערך
#     חלקי השיעור' (no number words) is untouched.
TEEN_UNITS = {u"אחד": 1, u"אחת": 1, u"שנים": 2, u"שניים": 2, u"שתים": 2,
              u"שתיים": 2, u"שלושה": 3, u"שלוש": 3, u"שלשה": 3, u"שלש": 3,
              u"ארבעה": 4, u"ארבע": 4, u"חמישה": 5, u"חמשה": 5, u"חמש": 5,
              u"שישה": 6, u"ששה": 6, u"שש": 6, u"שבעה": 7, u"שבע": 7,
              u"שמונה": 8, u"תשעה": 9, u"תשע": 9}
TEEN_TAILS = frozenset([u"עשר", u"עשרה"])
MAQAF = (u"\u05be", u"-")
FRACTION_WORD = u"חלקי"


def _merge_teens(s, heb_spans):
    """(heb_spans with each maqaf compound as one entry, the out-positions
    dropped, {pos: (tok, a, b)} of the merged entries)"""
    out, drop, merged = [], set(), {}
    i = 0
    while i < len(heb_spans):
        p1, w1, a1, b1 = heb_spans[i]
        if i + 1 < len(heb_spans):
            p2, w2, a2, b2 = heb_spans[i + 1]
            if w1 in TEEN_UNITS and w2 in TEEN_TAILS and s[b1:a2] in MAQAF:
                tok = s[a1:b2]
                out.append((p1, tok, a1, b2))
                merged[p1] = (tok, a1, b2)
                drop.add(p2)
                i += 2
                continue
        out.append(heb_spans[i])
        i += 1
    return out, drop, merged


def _merge_fraction_phrases(s, heb_spans, keep, merged):
    """merge '<kept number word> חלקי <kept number word>' (single spaces
    between) into the first entry; -> the out-positions dropped"""
    drop = set()
    i = 0
    while i + 2 < len(heb_spans):
        (p1, w1, a1, b1), (p2, w2, a2, b2), (p3, w3, a3, b3) = \
            heb_spans[i], heb_spans[i + 1], heb_spans[i + 2]
        # a teen written with a SPACE ('אחד עשר') next to the phrase makes
        # it ambiguous (1/1 + 10 or 1/11?): not merged, read as before
        amb = (i + 3 < len(heb_spans) and heb_spans[i + 3][1] in TEEN_TAILS
               and s[b3:heb_spans[i + 3][2]] == u" ") or (
            i >= 1 and w1 in TEEN_TAILS and heb_spans[i - 1][1] in
            TEEN_UNITS and s[heb_spans[i - 1][3]:a1] == u" ")
        if not amb and p1 in keep and p3 in keep and w2 == FRACTION_WORD \
                and s[b1:a2] == u" " and s[b2:a3] == u" " and \
                word_value(w1) is not None and word_value(w3):
            tok = s[a1:b3]
            merged[p1] = (tok, a1, b3)
            drop |= {p2, p3}
            keep.discard(p3)
            i += 3
            continue
        i += 1
    return drop


_CALC_TOK = re.compile(u"\\s*(?:(\\d+(?:\\.\\d+)?)|([-+\u2212\u00d7*/:]))")


def calc_problem(expr, before, val):
    """(v6.13 fix_r2) why the calc binding `expr` (u"6 - 6") is not the
    printed result `val` of the numbers printed just before it (`before`:
    the block's number atoms before this one, in order); None when it is.
    Only + - (− U+2212) × * / : between non-negative numbers."""
    if not isinstance(expr, str) or not expr.strip():
        return "calc is an expression string"
    nums, ops, pos = [], [], 0
    s = expr.strip()
    while pos < len(s):
        m = _CALC_TOK.match(s, pos)
        if not m or m.end() == pos:
            return "calc %r: not + - x / between numbers" % expr
        if m.group(1) is not None:
            if len(nums) != len(ops):
                return "calc %r: two numbers in a row" % expr
            nums.append(Fraction(m.group(1)))
        else:
            if len(nums) != len(ops) + 1:
                return "calc %r: an operator without a number" % expr
            ops.append(m.group(2))
        pos = m.end()
    if not nums or len(nums) != len(ops) + 1:
        return "calc %r: incomplete" % expr
    if len(before) < len(nums) or [atom_value("number", t) for t in
                                   before[-len(nums):]] != nums:
        return "calc %r: its numbers are not the %d numbers printed just " \
            "before it %s" % (expr, len(nums), before[-len(nums):])
    acc = nums[0]
    for o, x in zip(ops, nums[1:]):
        if o in "+":
            acc += x
        elif o in "-\u2212":
            acc -= x
        elif o in "\u00d7*":
            acc *= x
        else:
            if x == 0:
                return "calc %r divides by 0" % expr
            acc /= x
    if val is None or acc != val:
        return "calc %r is %s, the text prints %s" % (
            expr, canon.canon_number(str(acc)), val)
    return None


# (v6.13 fix_r2) "two NEIGHBOURING ..." is a fixed phrase, not a count:
# "שתי שנתות סמוכות" (the author-approved template wording of
# W-NL-TICK-DIFFERENCE), "בין שני קווי רשת סמוכים" (G7-T08 a q3). The word
# שני / שתי (up to four one-letter prefixes) is followed, in the same clause
# (only spaces between), within ADJ_MAX_GAP words, by סמוכים / סמוכות. Any
# other שני / שתי is still a number word that must be bound.
ADJ_TWO = frozenset([u"שני", u"שתי"])
ADJ_WORDS = frozenset([u"סמוכים", u"סמוכות"])
ADJ_MAX_GAP = 3


# (v6.13 fix_r2) "אחד מקווי הישר" ("one of the lines of the number line",
# G7-T01 c q4 / q8 / q22) is "one of", like the v6.10 phrases "אחד מה…" /
# "אחד מן" / "אחד מבין": אחד / אחת followed, in the same clause, by the
# construct form "מקווי". Only this word -- any other "אחד מ…" is still a
# number word.
ONE_OF_NEXT = frozenset([u"מקווי"])


def _one_of_lines(toks, i, glued):
    from . import schema as S
    if not any(st in S.PROSE_ONE for st in S._strip_prefixes(toks[i])):
        return False
    return i + 1 < len(toks) and glued[i + 1] and toks[i + 1] in ONE_OF_NEXT


def _adjacent_pair(toks, i, glued):
    from . import schema as S
    if not any(st in ADJ_TWO for st in S._strip_prefixes(toks[i])):
        return False
    for j in range(i + 1, min(len(toks), i + 2 + ADJ_MAX_GAP)):
        if not glued[j]:
            return False
        if toks[j] in ADJ_WORDS:
            return True
    return False


_ROMAN = {"i": 1, "v": 5, "x": 10}


def roman_value(tok):
    """(v6.16 fix r1, I-3) the value of a lower-case roman list marker
    ('i' 1, 'ii' 2, 'iii' 3, 'iv' 4 ... 'x' 10), else None"""
    t = str(tok or "")
    if not t or not re.fullmatch(r"x|ix|iv|v?i{0,3}", t):
        return None
    tot, prev = 0, 0
    for ch in reversed(t):
        v = _ROMAN[ch]
        tot = tot - v if v < prev else tot + v
        prev = max(prev, v)
    return tot or None


def atoms(text):
    """[(kind, tok)] of a bound block's text, in reading order. kind is
    number | word | name | angle | triangle | var."""
    text = unicodedata.normalize("NFC", text or u"")
    out, pos = [], 0
    for m in _ISLAND.finditer(text):
        out.extend(_scan(text[pos:m.start()].replace(u"\u2032", "'"), True))
        out.extend(_scan(_untex(m.group(1)), False))
        pos = m.end()
    out.extend(_scan(text[pos:].replace(u"\u2032", "'"), True))
    return out


def atoms_plain(text):
    """(v6.14 F1) (plain, [(kind, tok, start, end)]): the block text as the
    scanner reads it -- the text outside the islands and each island's
    untexed content, joined in order -- and atoms(text) with each atom's
    span in that plain string."""
    text = unicodedata.normalize("NFC", text or u"")
    plain, out, pos = u"", [], 0

    def add(s, outside):
        base = len(plain)
        return s, [(k, t, a + base, b + base)
                   for k, t, a, b in _scan_spans(s, outside)]
    for m in _ISLAND.finditer(text):
        for s, outside in ((text[pos:m.start()].replace(u"\u2032", "'"),
                            True), (_untex(m.group(1)), False)):
            s, got = add(s, outside)
            plain += s
            out.extend(got)
        pos = m.end()
    s, got = add(text[pos:].replace(u"\u2032", "'"), True)
    plain += s
    out.extend(got)
    return plain, out


# (v6.14 F1, Codex review v6.13 section 4) A COORDINATE PAIR "(a, b)" --
# two atoms, each a number or a variable, between "(" and ")" with only a
# comma / semicolon between them, optionally right after a point name
# ("C(\u22123, 2)") -- is ONE structured unit. Its first position is the FIRST
# axis of the plane (x), its second the SECOND (y): a printed number there
# must be bound to a coordinate fact of THAT axis, both positions of the
# SAME point, and that point is the one whose name precedes the pair.
# Swapping the two numbers together with their two bindings
# (C(\u22123, 2) -> C(2, \u22123), x-fact bound to the second position) is refused
# (BOUND_COORD_ROLE); so is a pair number bound to anything but its
# coordinate fact.
COORD_PAIR_KINDS = ("number", "var")
COORD_SEPS = (",", ";")
AXIS_ORDER = {"x": 0, "y": 1}


def coord_pairs(text):
    """[(i, j, name_i)]: the coordinate pairs of a block text, by atom index
    (atoms(text) order); name_i is the index of the point-name atom right
    before the "(" (only spaces between), or None."""
    plain, at = atoms_plain(text)
    out = []
    for i in range(len(at) - 1):
        (k1, _t1, a1, b1), (k2, _t2, a2, b2) = at[i], at[i + 1]
        if k1 not in COORD_PAIR_KINDS or k2 not in COORD_PAIR_KINDS:
            continue
        if plain[b1:a2].strip() not in COORD_SEPS:
            continue
        before = plain[:a1].rstrip()
        if not before.endswith("(") or \
                not plain[b2:].lstrip().startswith(")"):
            continue
        name_i = None
        head = before[:-1].rstrip()
        if i > 0 and at[i - 1][0] == "name" and at[i - 1][3] == len(head):
            name_i = i - 1
        out.append((i, i + 1, name_i))
    return out


def axis_order(ents):
    """{axis entity id: 0 | 1} -- the position of the axis in a coordinate
    pair: a plane named by its two axis letters ("xy") orders them; the
    default is x first, y second."""
    order = dict(AXIS_ORDER)
    for e in (ents or {}).values():
        if isinstance(e, dict) and e.get("kind") == "plane" and \
                isinstance(e.get("name"), str) and len(e["name"]) == 2 and \
                e["name"][0] != e["name"][1]:
            order.setdefault(e["name"][0], 0)
            order.setdefault(e["name"][1], 1)
    out = {}
    for eid, e in (ents or {}).items():
        if isinstance(e, dict) and e.get("kind") == "axis" and \
                e.get("name") in order:
            out[eid] = order[e["name"]]
    return out


# (v6.16 fix r1 continuation, skill gap D-PAIRVAR, G8-T15 c q1 "ישר ששיפועו 2
# עובר דרך הנקודות (2,a) וגם (5,11)"): a pair whose OTHER position is a
# VARIABLE ('a', the unknown the item asks) is the point of a graph find at
# a given place: its number is the find's 'at' -- the x of a value_at find
# (first position) or the y of an x_for_value find (second position). Bound
# to that 'at' (graph binding <figure>/find:<id>/at, value-checked by
# sheet_graph like any 'at'), the pair carries its roles; any other binding
# of a pair number is still refused. `finds` {"<figure>/find:<id>": rel},
# when the caller knows the figures, also checks the find's rel.
_FIND_AT = re.compile(r"^(?P<fig>[^/]+)/find:(?P<fid>[^/]+)/at$")
_AT_REL = {0: "value_at", 1: "x_for_value"}


def _pair_at_of_find(b, pos, other_kind, finds=None):
    """True when the pair number bound by `b` in position `pos` is the 'at'
    of a graph find whose asked value is the pair's other (variable)
    position"""
    if other_kind != "var" or not isinstance(b, dict):
        return False
    m = _FIND_AT.match(str(b.get("graph") or ""))
    if not m:
        return False
    if finds is None:
        return True
    return finds.get("%s/find:%s" % (m.group("fig"), m.group("fid"))) == \
        _AT_REL[pos]


def graph_find_rels(figures):
    """{"<figure>/find:<id>": rel} of spec / public figures (a list or an
    {id: figure} map)"""
    out = {}
    figs = figures.values() if isinstance(figures, dict) else (figures or [])
    for g in figs:
        if not isinstance(g, dict):
            continue
        for fd in ((g.get("graph") or {}).get("finds") or []):
            if isinstance(fd, dict) and fd.get("id"):
                out["%s/find:%s" % (g.get("id"), fd["id"])] = fd.get("rel")
    return out


def coord_role_problems(text, bind, facts, ents, finds=None):
    """(v6.14 F1) [str]: why the coordinate pairs of a bound block do not
    carry their roles. `bind` is the block's binding list (= its atom list,
    checked elsewhere; nothing is said when the lengths differ), `facts` /
    `ents` {id: dict} (the spec's, or the public model's); `finds` (v6.16
    fix r1 cont.) graph_find_rels of the figures, when known."""
    at = atoms(text)
    if not isinstance(bind, list) or len(bind) != len(at):
        return []
    axpos = axis_order(ents)
    out = []
    for i, j, name_i in coord_pairs(text):
        pair = u"(%s, %s)" % (at[i][1], at[j][1])
        want_pt = None
        if name_i is not None:
            nb = bind[name_i] if isinstance(bind[name_i], dict) else {}
            e = (ents or {}).get(nb.get("entity"))
            if isinstance(e, dict) and e.get("kind") == "point":
                want_pt = e.get("id", nb.get("entity"))
            pair = at[name_i][1] + pair
        pts = []
        for pos, n in ((0, i), (1, j)):
            if at[n][0] != "number":
                pts.append(None)            # a variable: no value to bind
                continue
            b = bind[n] if isinstance(bind[n], dict) else {}
            fl = bind_facts(b)
            if not fl and _pair_at_of_find(
                    b, pos, at[j if pos == 0 else i][0], finds):
                pts.append(None)            # the 'at' of the find's point
                continue
            if not fl:
                out.append(u"%s: %r (position %s) is bound to %s, not to a "
                           u"coordinate fact" % (
                               pair, at[n][1], "xy"[pos],
                               "/".join(k for k in BIND_REFS if k in b)
                               or "nothing"))
                pts.append(set())
                continue
            ok = set()
            for fid in fl:
                f = (facts or {}).get(fid) or {}
                args = f.get("args") or []
                if f.get("rel") == "coordinate" and len(args) == 2 and \
                        axpos.get(args[1]) == pos:
                    ok.add(args[0])
            if not ok:
                got = []
                for fid in fl:
                    f = (facts or {}).get(fid) or {}
                    got.append("%s=%s(%s)" % (fid, f.get("rel"), ",".join(
                        str(a) for a in f.get("args") or [])))
                out.append(u"%s: %r is in the %s position; it is bound to "
                           u"%s -- not a coordinate on the %s axis" % (
                               pair, at[n][1], "first" if pos == 0
                               else "second", "; ".join(got),
                               "first (x)" if pos == 0 else "second (y)"))
            pts.append(ok)
        if any(p is not None and not p for p in pts):
            continue
        common = None
        for p in pts:
            if p is not None:
                common = set(p) if common is None else common & p
        if common is not None and not common:
            out.append(u"%s: its two numbers are coordinates of different "
                       u"points (%s / %s)" % (pair, sorted(pts[0]),
                                              sorted(pts[1])))
            continue
        if want_pt is not None and common is not None and \
                want_pt not in common:
            out.append(u"%s: its numbers are coordinates of %s, not of the "
                       u"point %s printed before the pair" % (
                           pair, sorted(common), want_pt))
    return out


def atom_value(kind, tok):
    """Fraction (or canon string for a root) of a number / number word;
    None when the word has no fixed value."""
    if kind == "word":
        return word_value(tok)
    t = tok.replace(u"\u2212", "-")
    neg = t.startswith("-")
    t = t.lstrip("+-")
    if " " in t:                          # mixed: 1 1/2
        w, fr = t.split(" ", 1)
        v = Fraction(int(w)) + Fraction(fr)
        return -v if neg else v
    a, b, r = canon.parse_exact(t)
    if r != 1:
        return canon.canon_number(("-" if neg else "") + t)
    return -a if neg else a


def value_of(v):
    """A fact / entity value in the form atom_value returns."""
    a, b, r = canon.parse_exact(v)
    if r != 1:
        return canon.canon_number(v)
    return a


# ------------------------------------------------------------ helpers ---
def blocks_of(spec):
    """Every bound block of the spec: [(scope, at, block)] in sheet order.
    at: 'text:<k>' (the k-th bound segment of the scope's text),
    'table:head:<c>', 'table:<r>:<c>', 'example:title', 'example:<l>'."""
    out = []
    for q in spec.get("questions") or []:
        if not isinstance(q, dict):
            continue
        for sc in [q] + [it for it in q.get("items") or []
                         if isinstance(it, dict)]:
            k = 0
            for seg in sc.get("text") or []:
                if isinstance(seg, dict) and "bound" in seg:
                    out.append((sc.get("id"), "text:%d" % k, seg["bound"]))
                    k += 1
        t = q.get("table")
        if isinstance(t, dict):
            for c, cell in enumerate(t.get("head") or []):
                if isinstance(cell, dict) and "text" in cell:
                    out.append((q.get("id"), "table:head:%d" % c, cell))
            for r, row in enumerate(t.get("rows") or []):
                for c, cell in enumerate(row if isinstance(row, list)
                                         else []):
                    if isinstance(cell, dict) and "text" in cell:
                        out.append((q.get("id"), "table:%d:%d" % (r, c),
                                    cell))
        e = q.get("example")
        if isinstance(e, dict):
            if isinstance(e.get("title"), dict):
                out.append((q.get("id"), "example:title", e["title"]))
            for n, ln in enumerate(e.get("lines") or []):
                if isinstance(ln, dict):
                    out.append((q.get("id"), "example:%d" % n, ln))
    return out


def bind_facts(b):
    """the fact ids one binding names: "fact": fid, or (v6.13 fix_r1) a
    non-empty list of fact ids that share the atom's value; [] otherwise."""
    f = b.get("fact") if isinstance(b, dict) else None
    if isinstance(f, str):
        return [f]
    if isinstance(f, list) and f and all(isinstance(x, str) for x in f):
        return list(f)
    return []


def bound_facts(block):
    """Fact ids a block prints: its `prints` and the facts its numbers are
    bound to (a bound value states its fact), in order, once each."""
    out = []
    for b in block.get("bind") or []:
        for fid in bind_facts(b):
            if fid not in out:
                out.append(fid)
    for f in block.get("prints") or []:
        if f not in out:
            out.append(f)
    return out


def bound_entities(block):
    """Entity ids a block names (entity and count bindings)."""
    out = []
    for b in block.get("bind") or []:
        if not isinstance(b, dict):
            continue
        if isinstance(b.get("entity"), str):
            out.append(b["entity"])
        for e in b.get("count") or [] if isinstance(b.get("count"),
                                                    list) else []:
            out.append(e)
    return out


def name_ok(e, kind, name, ix):
    """Does printed name `name` (atom kind) name entity e?"""
    k = e.get("kind")
    if kind == "angle":
        if k != "angle" or len(name) < 3:
            return False
        a, b = e["arms"]
        return name in (a + e["vertex"] + b, b + e["vertex"] + a)
    if kind == "triangle":
        vs = re.findall(r"[A-Z][1-9]?'{0,3}", name)
        return k == "polygon" and len(e["vertices"]) == 3 and \
            len(vs) == 3 and canon.canon_cycle(vs) == \
            canon.canon_cycle(e["vertices"])
    if kind == "var":
        return k in ("variable", "axis", "plane", "line") and name == e.get("name")
    parts = re.findall(r"[A-Z][1-9]?'{0,3}", name)
    if "".join(parts) != name:
        return False
    if k == "point":
        return name == e.get("name")
    if k in ("segment", "arc", "line"):
        ab = e["through"] if k == "line" else e["ends"]
        return parts in (list(ab), list(reversed(ab)))
    if k == "ray":
        return parts == [e["from"], e["through"]]
    if k == "polygon":
        return len(parts) == len(e["vertices"]) and \
            canon.canon_cycle(parts) == canon.canon_cycle(e["vertices"])
    if k == "circle":
        return name in (e.get("name"), e.get("center"))
    if k == "sector":
        # (v6.16 integrate) a sector is named by its printed label
        return name == e.get("name")
    return False


def _entity_value(e):
    if e.get("kind") == "number":
        return value_of(e["value"])
    if e.get("kind") == "tick":
        return value_of(e["at"])
    return None


def _named(eid, named, ix, depth=0):
    """eid is named by the entities in `named` (itself, or all its parts)."""
    if eid in named or depth > 6:
        return True
    e = ix.entities.get(eid) or {}
    if e.get("kind") in UNNAMED_OK:
        return True
    from . import schema as S
    flds = S.ENTITY_REFS.get(e.get("kind"), ())
    if not flds:
        return False
    refs = []
    for fld in flds:
        v = e.get(fld)
        refs.extend(v if isinstance(v, list) else [v])
    return all(_named(r, named, ix, depth + 1) for r in refs)


# ----------------------------------------------------------- validate ---
def _check_block(blk, scope, at, ix, out, named_before):
    """One bound block; returns the entity ids it names."""
    from . import schema as S
    from . import project as P
    w = "bound %s %s" % (scope, at)
    if not S._fields(blk, BLOCK_FIELDS, w, out):
        return set()
    if not isinstance(blk.get("text"), str) or not blk["text"].strip():
        out.append(Issue("BOUND_BAD_BLOCK", w, "text is not a non-empty "
                         "string"))
        return set()
    bind = blk.get("bind")
    prints = blk.get("prints", [])
    if not isinstance(bind, list) or not all(isinstance(b, dict)
                                             for b in bind):
        out.append(Issue("BOUND_BAD_BLOCK", w, "bind is not a list of "
                         "objects"))
        return set()
    if not S._is_list_of_str(prints):
        out.append(Issue("BOUND_BAD_BLOCK", w, "prints is not a list of "
                         "fact ids"))
        return set()
    at_list = atoms(blk["text"])
    # the bind list IS the atom list, in order
    import difflib
    want = [t for _k, t in at_list]
    have = [b.get("tok") for b in bind]
    sm = difflib.SequenceMatcher(a=want, b=have, autojunk=False)
    for op, i1, i2, j1, j2 in sm.get_opcodes():
        if op == "equal":
            continue
        for t in want[i1:i2]:
            out.append(Issue("BOUND_UNBOUND", w, "%r is printed but not "
                             "bound" % t))
        for t in have[j1:j2]:
            out.append(Issue("BOUND_STALE", w, "binding %r: the text does "
                             "not print it here" % (t,)))
    # (v6.14 F1) a coordinate pair is one unit: x first, y second, one point
    if want == have:
        for why in coord_role_problems(blk["text"], bind, ix.facts,
                                       ix.entities,
                                       graph_find_rels(ix.figures)):
            out.append(Issue("BOUND_COORD_ROLE", w, why))
        # (v6.17, V3 / V5) a surd in its one canonical form; a unit word
        # after a bound number names the unit of its fact
        from . import numform as NF
        for code, why in NF.bound_form_problems(blk["text"], bind, ix.facts):
            out.append(Issue(code, w, why))
    for kind, tok in at_list:
        if kind == "angle" and len(re.findall(r"[A-Z][1-9]?'{0,3}",
                                              tok[1:])) < 3:
            out.append(Issue("BOUND_ANGLE_ONE_LETTER", w, "%s: "
                             "W-ANGLE-3-LETTERS -- name the angle by three "
                             "letters" % tok))
    names = set()
    vis = set(ix.visible_scopes(scope))
    qid = ix.scope_question.get(scope)
    enums = []
    kinds = dict()
    for (kind, tok) in at_list:
        kinds.setdefault(tok, kind)
    # the answers this block may not print: its item and the later items
    # (a stem: every item of the question)
    priv = []
    if qid in ix.questions:
        its = [it.get("id") for it in ix.questions[qid].get("items") or []]
        later = its if scope == qid else its[its.index(scope):] \
            if scope in its else []
        for f in ix.facts.values():
            if f.get("role") == "answer" and f.get("item") in later and \
                    f.get("value") is not None:
                try:
                    priv.append((value_of(f["value"]), f.get("id")))
                except Exception:           # noqa: BLE001
                    pass
    datum_ents = set()
    for fid in bound_facts(blk):
        f = ix.facts.get(fid) or {}
        if f.get("role") in ("given", "context", "to_prove", "target",
                             "to_plot", "to_construct"):
            for a in f.get("args") or []:
                datum_ents |= S.entity_closure(a, ix)
    for n, b in enumerate(bind):
        tok = b.get("tok")
        wb = "%s bind[%d] %r" % (w, n, tok)
        refs = [r for r in BIND_REFS if r in b]
        extra = [k for k in b if k not in BIND_REFS + ("tok",)]
        if not isinstance(tok, str) or len(refs) != 1 or extra:
            out.append(Issue("BOUND_REF", wb, "a binding is {tok, and ONE "
                             "of %s}%s" % ("/".join(BIND_REFS),
                                           " (extra %s)" % extra
                                           if extra else "")))
            continue
        kind = kinds.get(tok)
        if kind is None:
            continue                        # BOUND_STALE above
        ref = refs[0]
        val = None
        if kind in ("number", "word"):
            try:
                val = atom_value(kind, tok)
            except Exception:               # noqa: BLE001
                out.append(Issue("BOUND_VALUE_MISMATCH", wb, "not a number"))
                continue
        if ref == "fact":
            fl = bind_facts(b)
            if not fl:
                out.append(Issue("BOUND_REF", wb, "fact is a fact id or a "
                                 "non-empty list of fact ids"))
                continue
            if kind not in ("number", "word"):
                out.append(Issue("BOUND_KIND", wb, "a name is bound to an "
                                 "entity, not to a fact"))
                continue
            for fid in fl:
                f = ix.facts.get(fid)
                if f is None:
                    out.append(Issue("BOUND_REF", wb, "no fact %r" % fid))
                    continue
                role = f.get("role")
                if role in PRIVATE_VALUE_ROLES:
                    out.append(Issue("BOUND_TARGET_VALUE", wb, "bound to %s "
                                     "(%s): its value is private" % (
                                         f["id"], role)))
                    continue
                if role == "derived" or (f.get("source") or {}).get(
                        "kind") == "derived":
                    if not P.released(f, ix):
                        out.append(Issue("BOUND_PRIVATE", wb, "%s is derived "
                                         "and not released" % f["id"]))
                        continue
                elif role not in PUBLIC_VALUE_ROLES:
                    out.append(Issue("BOUND_PRIVATE", wb, "%s (%s)" % (
                        f["id"], role)))
                    continue
                if f.get("item") not in vis:
                    out.append(Issue("BOUND_SCOPE", wb, "%s belongs to %s, "
                                     "which %s does not see" % (
                                         f["id"], f.get("item"), scope)))
                if f.get("value") is None:
                    out.append(Issue("BOUND_VALUE_MISMATCH", wb, "%s carries "
                                     "no value" % f["id"]))
                elif val is not None and val != value_of(f["value"]):
                    out.append(Issue("BOUND_VALUE_MISMATCH", wb, "%s is %s"
                                     % (f["id"], canon.canon_number(
                                         f["value"]))))
        elif ref == "entity":
            e = ix.entities.get(b["entity"])
            if e is None:
                out.append(Issue("BOUND_REF", wb, "no entity %r"
                                 % b["entity"]))
                continue
            if kind in ("number", "word"):
                ev = _entity_value(e)
                if e.get("kind") not in ("number", "tick"):
                    out.append(Issue("BOUND_KIND", wb, "a number bound to "
                                     "a %s" % e.get("kind")))
                    continue
                if val is not None and val != ev:
                    out.append(Issue("BOUND_VALUE_MISMATCH", wb, "%s is %s"
                                     % (e["id"], canon.canon_number(
                                         e.get("value", e.get("at"))))))
                    continue
                hit = [a for v, a in priv if v == ev]
                if hit and e["id"] not in datum_ents:
                    out.append(Issue("BOUND_TARGET_VALUE", wb, "%s equals "
                                     "the private answer %s" % (tok,
                                                                hit[0])))
                names.add(e["id"])
                continue
            if kind == "angle" and len(re.findall(r"[A-Z][1-9]?'{0,3}",
                                                  tok[1:])) < 3:
                continue                    # BOUND_ANGLE_ONE_LETTER above
            if e.get("kind") not in NAME_KINDS.get(kind, ()):
                out.append(Issue("BOUND_KIND", wb, "a %s atom bound to a %s"
                                 % (kind, e.get("kind"))))
                continue
            if kind == "name" and e.get("kind") == "polygon" and \
                    len(e.get("vertices") or []) == 3:
                out.append(Issue("BOUND_TRI_SIGN", wb, "W-TRIANGLE-SYMBOL: "
                                 "print \u25b3%s" % tok))
                continue
            if not name_ok(e, kind, tok[1:] if kind in ("angle", "triangle")
                           else tok, ix):
                out.append(Issue("BOUND_NAME_MISMATCH", wb, "%s is not %s"
                                 % (tok, e["id"])))
                continue
            names.add(e["id"])
        elif ref == "count":
            lst = b["count"]
            if kind not in ("number", "word") or not S._is_list_of_str(lst) \
                    or not lst or len(set(lst)) != len(lst):
                out.append(Issue("BOUND_KIND", wb, "count binds a number to "
                                 "a list of distinct entity ids"))
                continue
            miss = [x for x in lst if x not in ix.entities]
            if miss:
                out.append(Issue("BOUND_REF", wb, "no entity %s" % miss))
                continue
            if val is not None and val != len(lst):
                out.append(Issue("BOUND_VALUE_MISMATCH", wb, "%d entities "
                                 "are listed" % len(lst)))
                continue
            names.update(lst)
        elif ref == "intervals":
            # (v6.13 fix_r1, C4) the number of intervals the figure draws:
            # tied to the frame, so a changed line fails the word
            from . import family as FAM
            g = ix.figures.get(b["intervals"]) if isinstance(
                b["intervals"], str) else None
            if g is None:
                out.append(Issue("BOUND_REF", wb, "no figure %r"
                                 % (b["intervals"],)))
                continue
            if kind not in ("number", "word"):
                out.append(Issue("BOUND_KIND", wb, "intervals binds a number"))
                continue
            if ix.scope_question.get(g.get("scope")) != qid:
                out.append(Issue("BOUND_SCOPE", wb, "figure %s is not of "
                                 "question %s" % (g.get("id"), qid)))
                continue
            ns = set(len(FAM.ticks(ax)) - 1
                     for ax in FAM.frame_axes(g.get("frame")))
            if len(ns) != 1 or min(ns) < 1:
                out.append(Issue("BOUND_KIND", wb, "figure %s has no single "
                                 "interval count (%s)" % (g.get("id"),
                                                          sorted(ns))))
                continue
            if val is not None and val != min(ns):
                out.append(Issue("BOUND_VALUE_MISMATCH", wb, "figure %s "
                                 "draws %d intervals" % (g.get("id"),
                                                         min(ns))))
                continue
        elif ref == "calc":
            # (v6.13 fix_r2) the result of a printed calculation: the
            # expression's numbers are the number atoms printed right before
            # this one (in order), and it evaluates to the printed number
            why = calc_problem(b["calc"], [t for k_, t in at_list[:n]
                                           if k_ == "number"], val) \
                if kind == "number" else "calc binds a number"
            if why:
                out.append(Issue("BOUND_VALUE_MISMATCH", wb, why))
                continue
            hit = [a for v, a in priv if v == val]
            if hit:
                out.append(Issue("BOUND_TARGET_VALUE", wb, "%s equals the "
                                 "private answer %s" % (tok, hit[0])))
                continue
        elif ref == "enum":
            k = b["enum"]
            # (v6.16 fix r1, I-3) a ROMAN list marker '(i)', '(ii)', '(iii)'
            # is a list marker too: the scanner reads it as a lower-case
            # var atom, and a variable name is one letter (+ a digit), so a
            # source question with roman options could not be bound at all
            # (G9-T06 5ו). It binds {"enum": k} when its roman value is k.
            if kind == "var" and S.is_count(k) and roman_value(tok) == k:
                enums.append(k)
                continue
            if kind != "number" or not S.is_count(k) or val != k:
                out.append(Issue("BOUND_VALUE_MISMATCH", wb, "enum %r" % (k,)))
                continue
            enums.append(k)
        elif ref == "question":
            q = ix.questions.get(b["question"])
            if q is None:
                out.append(Issue("BOUND_REF", wb, "no question %r"
                                 % b["question"]))
                continue
            if kind != "number" or val != q.get("n"):
                out.append(Issue("BOUND_VALUE_MISMATCH", wb, "question %s "
                                 "is number %s" % (q["id"], q.get("n"))))
        elif ref == "graph":
            # (v6.16 integrate) a public number / name of a graph figure
            # of this question (wspec/sheet_graph.py bind_problem)
            from . import sheet_graph as SGR
            why = SGR.bind_problem(SGR.question_graphs(ix.spec, qid),
                                   b["graph"], kind, tok, val, blk["text"])
            if why:
                out.append(Issue("BOUND_PRIVATE" if "not public" in why
                                 else "BOUND_VALUE_MISMATCH", wb, why))
        elif ref == "pie":
            # (v6.16 integrate) a percent word = its pie's unit
            from . import sheet_pie as SPI
            why = SPI.bind_problem(ix.spec, b["pie"], kind, tok)
            if why:
                out.append(Issue("BOUND_VALUE_MISMATCH", wb, why))
            else:
                names.add(b["pie"].split("/")[0])
    if enums and enums != list(range(1, len(enums) + 1)):
        out.append(Issue("BOUND_ENUM", w, "markers %s" % enums))
    # what the block prints
    known = names | named_before
    from . import point_transform as PT
    for fid in bound_facts(blk):
        f = ix.facts.get(fid)
        if f is None or fid in prints:
            continue
        for a in f.get("args") or []:
            if not _named(a, known, ix) and not PT.source_named(ix.spec, scope, blk, a):
                out.append(Issue("BOUND_FACT_UNNAMED", w, "%s (bound by its "
                                 "value) names %s, which the block does not "
                                 "name" % (fid, a)))
    for fid in prints:
        f = ix.facts.get(fid)
        if f is None:
            out.append(Issue("BOUND_REF", w, "prints %r: no such fact"
                             % fid))
            continue
        if f.get("item") != scope and not stem_item_of(ix, scope,
                                                        f.get("item")):
            out.append(Issue("BOUND_SCOPE", w, "prints %s of %s" % (
                fid, f.get("item"))))
            continue
        role = f.get("role")
        if role == "answer" or (role == "derived" and
                                not P.released(f, ix)):
            out.append(Issue("BOUND_PRINTS_PRIVATE", w, "%s (%s)"
                             % (fid, role)))
            continue
        if f.get("value") is not None and role in PUBLIC_VALUE_ROLES + (
                "derived",) and not any(fid in bind_facts(b) for b in bind):
            out.append(Issue("BOUND_FACT_UNSTATED", w, "%s = %s: no atom "
                             "is bound to its value" % (
                                 fid, canon.canon_number(f["value"]))))
        for a in f.get("args") or []:
            transformed = PT.target_row(ix.spec, f)
            transform_result = transformed is not None and a == transformed.get("result_point")
            if not _named(a, known, ix) and not transform_result and not PT.source_named(ix.spec, scope, blk, a) and not _source_unnamed_construction(f, a, blk, ix, scope):
                out.append(Issue("BOUND_FACT_UNNAMED", w, "%s names %s, "
                                 "which the block does not name" % (fid, a)))
    return names


def _source_unnamed_construction(fact, entity, block, ix, scope):
    """An explicitly described open polygon has no invented vertex letters.

    Only a source-declared, unsupported generic construction may use this
    path. Its own printed block must contain the exact construction query;
    a given, numeric target, other object or other scope cannot borrow it.
    """
    if fact.get("rel") != "construct" or fact.get("role") != "to_construct" or fact.get("item") != scope or fact.get("args") != [entity]:
        return False
    e = ix.entities.get(entity, {})
    if e.get("kind") != "polygon" or not e.get("tag"):
        return False
    q = ix.questions.get(ix.scope_question.get(scope), {})
    decl = q.get("printed_claims") or {}
    if decl.get("unsupported") is not True:
        return False
    from . import printed_claims as PC
    for c in ((decl.get("scopes") or {}).get(scope) or {}).get("to_construct") or []:
        if c.get("polygon_entity") == entity and c.get("printed_in", scope) == scope:
            excerpts = PC.excerpts(c, "to_construct")
            if excerpts and all(t and t in PC.norm(block.get("text")) for t in excerpts):
                return True
    return False


def stem_item(q):
    """(v6.13 fix_r2, NOITEM) the id of a question's STEM ITEM: its ONE item,
    whose text is empty -- the original prints the whole task as the
    question's sentence, with no item letter (G7-T01 a / b q9 "סמנו על ישר
    המספרים שלפניכם את שלושת המספרים, ..."). The stem's bound block prints
    that item's targets; the sheet prints the question with no item row
    (wspec_build.expand_question). None otherwise."""
    its = [it for it in (q or {}).get("items") or [] if isinstance(it, dict)]
    if len(its) != 1 or its[0].get("text") not in ([], None):
        return None
    return its[0].get("id")


def stem_item_of(ix, scope, item):
    """is `item` the stem item of question `scope`?"""
    q = ix.questions.get(scope)
    return bool(q) and item is not None and stem_item(q) == item


def _named_before(ix, scope, blocks_by_scope):
    """Entities named before `scope`'s blocks: bound in an earlier visible
    scope's blocks, or arguments of a given / context fact of a visible
    scope (printed by a template or drawn)."""
    from . import schema as S
    named = set()
    for sc in ix.visible_scopes(scope):
        if sc != scope:
            for blk in blocks_by_scope.get(sc, []):
                named.update(bound_entities(blk))
        for f in ix.facts_in(sc):
            if f.get("role") in ("given", "context"):
                for a in f.get("args") or []:
                    named |= S.entity_closure(a, ix)
    return named


def validate_bound(spec, ix, out):
    """The bound blocks, tables and examples of a spec (appends Issues)."""
    from . import schema as S
    for qn, q in enumerate(spec.get("questions") or []):
        if not isinstance(q, dict):
            continue
        wq = "question %s" % q.get("id")
        t = q.get("table")
        if t is not None:
            if not S._fields(t, TABLE_FIELDS, wq + " table", out):
                pass
            else:
                rows = t.get("rows")
                if not isinstance(rows, list) or not rows or not all(
                        isinstance(r, list) and r for r in rows):
                    out.append(Issue("BOUND_BAD_BLOCK", wq + " table",
                                     "rows: a non-empty list of non-empty "
                                     "rows"))
                if "head" in t and (not isinstance(t["head"], list) or
                                    not t["head"]):
                    out.append(Issue("BOUND_BAD_BLOCK", wq + " table",
                                     "head: a non-empty list"))
                if not isinstance(t.get("hcol", False), bool):
                    out.append(Issue("BOUND_BAD_BLOCK", wq + " table",
                                     "hcol: a boolean"))
                if t.get("cls", "") not in TABLE_CLASSES:
                    out.append(Issue("BOUND_BAD_BLOCK", wq + " table",
                                     "cls %r (one of %s)" % (
                                         t.get("cls"), TABLE_CLASSES)))
                for r in ([t.get("head")] if "head" in t else []) + (
                        rows if isinstance(rows, list) else []):
                    for c in r if isinstance(r, list) else []:
                        if not isinstance(c, dict) or (
                                "blank" in c and c != {"blank": True}) or (
                                "blank" not in c and "text" not in c):
                            out.append(Issue("BOUND_BAD_BLOCK", wq +
                                             " table", "a cell is a bound "
                                             "block or {\"blank\": true}: "
                                             "%r" % (c,)))
        e = q.get("example")
        if e is not None:
            if S._fields(e, EXAMPLE_FIELDS, wq + " example", out):
                if not isinstance(e.get("title"), dict) or \
                        not isinstance(e.get("lines"), list) or \
                        not e["lines"] or not all(isinstance(x, dict)
                                                  for x in e["lines"]):
                    out.append(Issue("BOUND_BAD_BLOCK", wq + " example",
                                     "{title: block, lines: [block...]}"))
        for sc in [q] + [it for it in q.get("items") or []
                         if isinstance(it, dict)]:
            for seg in sc.get("text") or [] if isinstance(
                    sc.get("text"), list) else []:
                if isinstance(seg, dict) and "bound" in seg and (
                        len(seg) != 1 or not isinstance(seg["bound"], dict)):
                    out.append(Issue("BOUND_BAD_BLOCK", "text of %s"
                                     % sc.get("id"), "a bound segment is "
                                     "{\"bound\": {text, bind, prints}}"))
    blocks = [(s, a, b) for s, a, b in blocks_of(spec) if isinstance(b, dict)]
    by_scope = {}
    for s, a, b in blocks:
        by_scope.setdefault(s, []).append(b)
    for s, a, b in blocks:
        _check_block(b, s, a, ix, out, _named_before(ix, s, by_scope))


def render_table(t):
    """A spec table as the emitter's table dict (text of each cell)."""
    def cell(c):
        return u"" if not isinstance(c, dict) or c.get("blank") else \
            c.get("text", u"")
    out = {"rows": [[cell(c) for c in r] for r in t.get("rows") or []]}
    if t.get("head") is not None:
        out["head"] = [cell(c) for c in t["head"]]
    if t.get("hcol"):
        out["hcol"] = True
    if t.get("cls"):
        out["cls"] = t["cls"]
    return out


def render_example(e):
    """A spec example as the emitter's (title, [lines])."""
    return (e["title"]["text"], [ln["text"] for ln in e.get("lines") or []])


def question_extras(q):
    """What a spec question prints beside its texts, in the builder's
    content form: {"table": {...}, "example": (title, lines)} -- the keys
    only when the question has them (wspec_build.expand_question sets them
    on the expanded question; they are _SPEC_OWNS keys)."""
    out = {}
    if isinstance(q.get("table"), dict):
        out["table"] = render_table(q["table"])
    if isinstance(q.get("example"), dict):
        out["example"] = render_example(q["example"])
    return out


def public_bind(b):
    """A binding as the public model carries it (whitelisted keys)."""
    out = {"tok": b["tok"]}
    for r in BIND_REFS:
        if r in b:
            out[r] = list(b[r]) if isinstance(b[r], list) else b[r]
    return out


def public_blocks(spec, scope_id):
    """The public 'bound' list of one scope: [{at, text, bind, prints}]."""
    out = []
    for s, at, blk in blocks_of(spec):
        if s != scope_id:
            continue
        out.append({"at": at, "text": blk["text"],
                    "bind": [public_bind(b) for b in blk.get("bind") or []],
                    "prints": list(bound_facts(blk))})
    return out
