# -*- coding: utf-8 -*-
"""v6.10 language features (BRIEF_V610 part 2): the validation of what the
closed tables of schema.py cannot say alone.

  linear       args[0] = coef[0]*args[1] + ... + value   (AC = 3x + 4,
               BD = 1/2 AC, angle DMB = 2 angle A, angle APB = angle DAP +
               angle CBP, S(BOC) = 1/4 S(ABCD), angle DAP = 2 angle CBP + 10)
  greater      args[0] > args[1]                         (CM > CH, A > B)
  not_parallel AE not parallel to BF
  inside       P inside the rectangle ABCD
  trapezoid, isosceles_trapezoid, right_triangle, acute_triangle
  classify     "which special quadrilateral is ABCD?" (answer: a class)
  cline        an entity: a construction result with NO sheet name (the
               line through P parallel to AD), referred to by its id
Checks that read an item's TEXT (which template asks what):
  ROOT_HINT_RATIONAL      "express the answer with a root" over a rational
                          answer
  DEDUCE_WITHOUT_PREMISE  "הסיקו כי" with nothing proved before it
  CLINE_DRAWN             a figure the item shows already draws the
                          unnamed construction result its text asks for
Every function appends Issues to `out` and never raises on a malformed spec
(the structural checks of schema.py report those)."""
from fractions import Fraction

from . import canon
from .errors import Issue

NEW_SHAPES = ("trapezoid", "isosceles_trapezoid", "right_triangle",
              "acute_triangle",
              # (v6.17-noam V1) measured when drawn, as acute_triangle
              "obtuse_triangle")
# a relation between quantities names no mark: it is DRAWN (when a figure
# lists it in draws) only as the geometry the renderer's layout makes; the
# render's own geometry check and the independent checker MEASURE it on an
# accurate figure. A relation with a variable, and classify, are never
# drawn (nothing on a figure can show them).
DRAWABLE_NEW = ("linear", "greater", "not_parallel", "inside") + NEW_SHAPES


def _S():
    from . import schema as S
    return S


def coefs(f):
    """[Fraction] of a linear fact (ValueError on a bad one)."""
    out = []
    for c in f.get("coef") or []:
        a, b, r = canon.parse_exact(c)
        if r != 1:
            raise ValueError("a coefficient is a rational number")
        out.append(a)
    return out


def qty_dim(eid, ix):
    return _S().QTY_DIM.get(ix.kind(eid), "?")


def lin_dimension(f, ix):
    """The dimension of a linear / greater fact's terms (length / angle /
    area), None for variables only; '?' when they disagree."""
    dims = set(qty_dim(a, ix) for a in f.get("args") or [])
    dims.discard(None)
    if len(dims) > 1:
        return "?"
    return dims.pop() if dims else None


def validate_language(spec, ix, out):
    S = _S()
    for f in ix.facts.values():
        try:
            _fact_checks(f, ix, out, S)
        except Exception as e:           # noqa: BLE001 -- malformed input
            out.append(Issue("BAD_TYPE", "fact %s" % f.get("id"),
                             "unreadable (%s)" % type(e).__name__))
    for e in ix.entities.values():
        if e.get("kind") == "cline":
            if e.get("op") not in S.CLINE_OPS:
                out.append(Issue("BAD_TYPE", "entity %s" % e.get("id"),
                                 "op %r not in %s" % (e.get("op"),
                                                      S.CLINE_OPS)))
            base = ix.entities.get(e.get("base")) or {}
            if e.get("through") in (base.get("ends") or []):
                out.append(Issue("ENTITY_DEGENERATE", "entity %s" %
                                 e.get("id"), "the line through %s along "
                                 "%s is %s itself" % (e.get("through"),
                                                     e.get("base"),
                                                     e.get("base"))))
    try:
        _text_checks(spec, ix, out)
        _cline_checks(spec, ix, out)
        _drawn_checks(spec, ix, out)
    except Exception as e:               # noqa: BLE001
        out.append(Issue("BAD_TYPE", "spec", "unreadable texts (%s)"
                         % type(e).__name__))


def _fact_checks(f, ix, out, S):
    rel, role = f.get("rel"), f.get("role")
    args = f.get("args") or []
    w = "fact %s" % f.get("id")
    if rel in ("linear", "greater") and role not in S.QTY_REL_ROLES:
        out.append(Issue("LIN_ROLE", w, "%s as %s" % (rel, role)))
    if rel == "linear":
        _linear(f, ix, out, w)
    elif rel == "greater":
        if len(args) == 2 and qty_dim(args[0], ix) != qty_dim(args[1], ix):
            out.append(Issue("LIN_DIMENSION", w, "%s > %s" % tuple(args)))
    elif rel == "not_parallel" and len(args) == 2:
        from .baseline import _line_key
        k1, k2 = _line_key(args[0], ix), _line_key(args[1], ix)
        if k1 and k1 == k2:
            out.append(Issue("REL_DEGENERATE", w, "%s and %s are one line"
                             % tuple(args)))
    elif rel == "inside" and len(args) == 2:
        p = (ix.entities.get(args[0]) or {}).get("name")
        vs = (ix.entities.get(args[1]) or {}).get("vertices") or []
        if p in vs:
            out.append(Issue("REL_DEGENERATE", w, "%s is a vertex of %s"
                             % (p, args[1])))
    if rel in S.SHAPE_VERTICES and args:
        vs = (ix.entities.get(args[0]) or {}).get("vertices") or []
        want = S.SHAPE_VERTICES[rel]
        if rel == "classify" and role == "answer" and \
                isinstance(f.get("value"), str):
            want = S.CLASS_VALUES.get(f["value"])
        if want is not None and len(vs) != want:
            out.append(Issue("SHAPE_VERTEX_COUNT", w, "%s has %d vertices, "
                             "%s needs %d" % (args[0], len(vs),
                                              f.get("value") or rel, want)))
    if rel == "classify" and role not in ("target", "to_prove", "answer"):
        out.append(Issue("CLASSIFY_VALUE", w, "classify as %s (it is "
                         "asked, justified or answered)" % role))


def _linear(f, ix, out, w):
    args = f.get("args") or []
    cf = f.get("coef")
    if not isinstance(cf, list) or len(cf) != max(0, len(args) - 1):
        out.append(Issue("LIN_FORM", w, "coef %r for %d arguments (one per "
                         "argument after the first)" % (cf, len(args))))
        return
    try:
        cs = coefs(f)
    except Exception:                    # noqa: BLE001
        out.append(Issue("LIN_FORM", w, "coef %r: exact rationals" % (cf,)))
        return
    if any(c == 0 for c in cs):
        out.append(Issue("LIN_FORM", w, "a zero coefficient"))
    if len(set(args)) != len(args):
        out.append(Issue("LIN_FORM", w, "an argument repeated"))
    if f.get("value") is not None:
        try:
            if canon.parse_exact(f["value"]) == (Fraction(0), Fraction(0),
                                                 1):
                out.append(Issue("LIN_FORM", w, "a zero constant (leave "
                                 "value out)"))
        except Exception:                # noqa: BLE001
            pass
    d = lin_dimension(f, ix)
    if d == "?":
        out.append(Issue("LIN_DIMENSION", w, "terms of different "
                         "dimensions: %s" % ", ".join(
                             "%s (%s)" % (a, qty_dim(a, ix)) for a in args)))
        return
    if f.get("value") is not None and f.get("role") != "target":
        u = f.get("unit")
        try:
            cu = canon.canon_unit(u)
        except Exception:                # noqa: BLE001
            cu = "?"
        want = d
        got = canon.unit_dimension(cu) if cu not in (None, "?") else cu
        if want is not None and got != want:
            out.append(Issue("LIN_DIMENSION", w, "the constant's unit %r is "
                             "not a %s" % (u, want)))
        if want is None and cu is not None:
            out.append(Issue("LIN_DIMENSION", w, "a constant of variables "
                             "only carries no unit"))
    kinds = [ix.kind(a) for a in args]
    if len(args) == 2 and cs == [1] and f.get("value") is None and \
            kinds[0] == kinds[1] and kinds[0] in ("segment", "angle"):
        out.append(Issue("LIN_FORM", w, "%s = %s is %s" % (
            args[0], args[1], "equal_length" if kinds[0] == "segment"
            else "equal_angle")))
    if f.get("role") == "answer":
        t = ix.facts.get(str(f.get("id", ""))[:-1] + "t") or {}
        if (f.get("coef") is not None and t.get("coef") is not None and
                [canon.canon_number(x) for x in f["coef"]] !=
                [canon.canon_number(x) for x in t["coef"]]):
            out.append(Issue("LIN_FORM", w, "the answer's coef differs from "
                             "its to_prove's"))


# ------------------------------------------------------------ texts ------
def _segs(scope_obj):
    return [s for s in scope_obj.get("text") or [] if isinstance(s, dict)]


def _text_checks(spec, ix, out):
    # a PRINTED congruence states its correspondence: the order of the
    # vertices is the author's (display), never the canonical rotation of
    # the polygon ids (ABC with DFE would print as "ABC ≅ DEF")
    for q in spec.get("questions") or []:
        if not isinstance(q, dict):
            continue
        for sc in [q] + [it for it in q.get("items") or []
                         if isinstance(it, dict)]:
            for seg in _segs(sc):
                for fid in seg.get("facts") or []:
                    f = ix.facts.get(fid) or {}
                    d = f.get("display")
                    if f.get("rel") == "congruent" and not (
                            isinstance(d, list) and len(d) == 2 and
                            all(isinstance(x, str) for x in d)):
                        out.append(Issue("DISPLAY_MISMATCH", "fact %s" % fid,
                                         "a printed congruence names its "
                                         "correspondence: display both "
                                         "polygons in matching order"))
    for q in spec.get("questions") or []:
        if not isinstance(q, dict):
            continue
        proved_before = False
        for it in q.get("items") or []:
            if not isinstance(it, dict):
                continue
            proved_here = False
            for seg in _segs(it):
                tid = seg.get("tpl")
                fids = seg.get("facts") or []
                if tid == "express_as_root":
                    asked = set(x for sg in _segs(it)[:_segs(it).index(seg)]
                                for x in sg.get("facts") or [])
                    for fid in fids:
                        if fid not in asked:
                            out.append(Issue(
                                "LANG_TEXT_CHECK", "item %s" % it.get("id"),
                                "express_as_root binds %s, which the text "
                                "does not ask before it" % fid))
                        a = ix.facts.get(str(fid)[:-1] + "a") or {}
                        irr = False
                        try:
                            irr = a.get("value") is not None and \
                                canon.parse_exact(a["value"])[2] != 1
                        except Exception:        # noqa: BLE001
                            irr = False
                        if not irr:
                            out.append(Issue(
                                "ROOT_HINT_RATIONAL", "item %s" %
                                it.get("id"), "%s: the answer %r has no "
                                "root" % (fid, a.get("value"))))
                if tid == "deduce_that" and not (proved_before or
                                                 proved_here):
                    out.append(Issue("DEDUCE_WITHOUT_PREMISE", "item %s" %
                                     it.get("id"), "nothing is proved "
                                     "before 'הסיקו כי' in question %s"
                                     % q.get("id")))
                if any((ix.facts.get(x) or {}).get("role") == "to_prove"
                       for x in fids):
                    proved_here = True
            proved_before = proved_before or proved_here


def text_entities(scope_obj):
    out = []
    for seg in _segs(scope_obj):
        out.extend(seg.get("entities") or [])
    return out


def _cline_checks(spec, ix, out):
    """A cline (an unnamed construction result) is never drawn: no figure
    lists it, no fact names it outside a text mention, and no figure the
    mentioning item's QUESTION shows (its head or any item's figure) draws
    a segment / line through its point that a fact of the question makes
    parallel / perpendicular to its base -- the same line under a
    name."""
    from .baseline import _line_key
    clines = [e for e in ix.entities.values() if e.get("kind") == "cline"]
    if not clines:
        return
    cids = set(e["id"] for e in clines)
    for g in spec.get("figures") or []:
        for x in g.get("entities") or []:
            if x in cids:
                out.append(Issue("CLINE_DRAWN", "figure %s" % g.get("id"),
                                 "lists %s" % x))
    for f in ix.facts.values():
        for a in f.get("args") or []:
            if a in cids:
                out.append(Issue("CLINE_DRAWN", "fact %s" % f.get("id"),
                                 "names %s (a cline is only mentioned by a "
                                 "text)" % a))
    rel_of = {"parallel": "parallel", "perpendicular": "perpendicular"}
    for q in spec.get("questions") or []:
        for it in [q] + list(q.get("items") or []):
            mentioned = [x for x in text_entities(it) if x in cids]
            if not mentioned:
                continue
            # every figure of the question: a later item's figure that
            # shows the line reveals it as plainly as the item's own
            figs = set([q.get("figure")] + [x.get("figure") for x in
                                            q.get("items") or []])
            figs.discard(None)
            vis = set(sc for sc, qq in ix.scope_question.items()
                      if qq == q.get("id"))
            for x in mentioned:
                c = ix.entities[x]
                bk = _line_key(c.get("base"), ix)
                for fid in figs:
                    g = ix.figures.get(fid) or {}
                    shown = set(g.get("entities") or [])
                    for d in g.get("draws") or []:
                        shown |= set((ix.facts.get(d) or {}).get("args")
                                     or [])
                    # the points the reader knows on each line: its own
                    # ends, and a point stated on it (on_segment / midpoint)
                    on = {}
                    for f in ix.facts.values():
                        if f.get("rel") in ("on_segment", "midpoint") and \
                                f.get("item") in vis and \
                                f.get("role") in ("given", "context"):
                            a_ = f.get("args") or []
                            if len(a_) == 2:
                                on.setdefault(a_[1], set()).add(a_[0])
                    for f in ix.facts.values():
                        if f.get("rel") != rel_of[c["op"]] or \
                                f.get("item") not in vis or \
                                f.get("role") not in ("given", "context"):
                            continue
                        ks = [_line_key(a, ix) for a in f.get("args") or []]
                        if bk not in ks:
                            continue
                        for a, k in zip(f.get("args") or [], ks):
                            if k and k != bk and (c["through"] in k or
                                                  c["through"] in
                                                  on.get(a, ())) and \
                                    a in shown:
                                out.append(Issue(
                                    "CLINE_DRAWN", "figure %s" % fid,
                                    "draws %s, the line %s asks for (%s)"
                                    % (a, x, f["id"])))


def _drawn_checks(spec, ix, out):
    """A figure draws a new relation only when it can be measured."""
    S = _S()
    for g in spec.get("figures") or []:
        for d in g.get("draws") or []:
            f = ix.facts.get(d) or {}
            rel = f.get("rel")
            if rel == "classify" or (rel == "linear" and any(
                    ix.kind(a) == "variable" for a in f.get("args") or [])):
                out.append(Issue("FIGURE_DRAWS_PRIVATE" if rel == "classify"
                                 else "LIN_FORM", "figure %s" % g.get("id"),
                                 "%s cannot be drawn (%s)" % (
                                     d, "a class is an answer" if rel ==
                                     "classify" else "a variable has no "
                                     "drawing")))
    del S
