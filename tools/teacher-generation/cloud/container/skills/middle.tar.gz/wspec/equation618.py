"""H-F2: exact private root checks tied to actual printed bound math.

For G9-T31 every var_value answer requires one printed equation in its
own item or stem. Other packages opt in with item.root_equation, a location
reference, never a duplicate equation string. Unsupported grammar refuses
the build; it never counts as a verified root. No symbolic eval is used.
"""
import ast
from fractions import Fraction as Q
import re
from .errors import Issue, REASONS, SpecError
from . import numform as N

FIELD = "root_equation"
for code, why in {
    "ROOT_EQUATION_MISSING": "an algebra root has no printed equation in its item or stem",
    "ROOT_EQUATION_AMBIGUOUS": "more than one printed equation; bind a unique island explicitly",
    "ROOT_EQUATION_BINDING_BAD": "root_equation must locate its own item's or stem's bound math island",
    "ROOT_EQUATION_UNSUPPORTED": "the printed equation is outside exact rational polynomial grammar (degree <= 4)",
}.items():
    REASONS.setdefault(code, why)

def _clean(s, var):
    s = s.replace("−", "-").replace("²", "^2").replace("³", "^3")
    s = s.replace(r"\left", "").replace(r"\right", "").replace(r"\cdot", "*").replace(r"\times", "*").replace(r"\text{}", "")
    # Innermost fractions first; division below accepts a constant only.
    for _ in range(5):
        t = re.sub(r"\\(?:f|frac|dfrac|tfrac)\s*\{([^{}]+)\}\s*\{([^{}]+)\}", r"((\1)/(\2))", s)
        if t == s:
            break
        s = t
    s = s.replace("{", "(").replace("}", ")")
    if len(s) > 500 or not re.fullmatch(r"[0-9\s.+*/^()\-" + re.escape(var) + r"]+", s):
        raise ValueError("unrecognised operator or variable")
    tokens = re.findall(r"\d+(?:\.\d+)?|[A-Za-z]|[()+*/^.-]", s)
    if "".join(tokens) != re.sub(r"\s", "", s):
        raise ValueError("bad token")
    out = []
    for t in tokens:
        if out and (out[-1] == var or out[-1] == ")" or out[-1][0].isdigit()) and (t == var or t == "(" or t[0].isdigit()):
            if out[-1][0].isdigit() and t[0].isdigit():
                raise ValueError("adjacent numbers need an operator")
            out.append("*")
        out.append(t)
    return "".join(out).replace("^", "**")

def _add(a, b, sign=1):
    c = dict(a)
    for k, v in b.items():
        c[k] = c.get(k, Q(0)) + sign * v
    return {k: v for k, v in c.items() if v}

def _mul(a, b):
    c = {}
    for i, u in a.items():
        for j, v in b.items():
            if i + j > 4:
                raise ValueError("degree above four")
            c[i+j] = c.get(i+j, Q(0)) + u*v
    return {k: v for k, v in c.items() if v}

def polynomial(tex, var):
    if len(var) != 1 or not var.isascii() or not var.isalpha() or tex.count("=") != 1:
        raise ValueError("one equation in one named variable required")
    def side(s):
        text = _clean(s, var)
        tree = ast.parse(text, mode="eval")
        if sum(1 for _ in ast.walk(tree)) > 100:
            raise ValueError("equation too long")
        def read(n):
            if isinstance(n, ast.Expression): return read(n.body)
            if isinstance(n, ast.Constant) and type(n.value) in (int, float):
                return {0: Q(ast.get_source_segment(text, n))}
            if isinstance(n, ast.Name) and n.id == var: return {1: Q(1)}
            if isinstance(n, ast.UnaryOp) and isinstance(n.op, (ast.UAdd, ast.USub)):
                return {k: (v if isinstance(n.op, ast.UAdd) else -v) for k,v in read(n.operand).items()}
            if isinstance(n, ast.BinOp):
                a, b = read(n.left), read(n.right)
                if isinstance(n.op, ast.Add): return _add(a,b)
                if isinstance(n.op, ast.Sub): return _add(a,b,-1)
                if isinstance(n.op, ast.Mult): return _mul(a,b)
                if isinstance(n.op, ast.Div) and set(b) <= {0} and b.get(0):
                    return {k:v/b[0] for k,v in a.items()}
                if isinstance(n.op, ast.Pow) and set(b) <= {0} and b.get(0, Q(0)).denominator == 1 and 0 <= b.get(0,0) <= 4:
                    c = {0:Q(1)}
                    for _ in range(int(b.get(0,0))): c = _mul(c,a)
                    return c
            raise ValueError("unsupported expression")
        return read(tree)
    a,b = tex.split("=")
    p = _add(side(a),side(b),-1)
    if not p or max(p) == 0:
        raise ValueError("identity or constant equation is not a root task")
    return p

def candidates(spec, scope, vid, var):
    from . import schema_bound as SB
    got = []
    for sid, at, blk in SB.blocks_of(spec):
        if sid != scope or not at.startswith("text:") or not isinstance(blk,dict): continue
        text = blk.get("text", "")
        if not isinstance(text, str):
            continue
        for k,m in enumerate(SB._ISLAND.finditer(text)):
            tex = m.group(1)
            if "=" in tex and re.search(r"(?<![A-Za-z])" + re.escape(var) + r"(?![A-Za-z])", tex):
                # Bind THIS island's variable atoms, not another island's x.
                offset = len(SB.atoms(text[:m.start()]))
                atom_list = SB.atoms("$" + tex + "$")
                bindings = blk.get("bind") if isinstance(blk.get("bind"), list) else []
                positions = [offset+j for j,(kind,tok) in enumerate(atom_list)
                             if kind == "var" and tok == var]
                bound = bool(positions) and all(j < len(bindings) and
                    isinstance(bindings[j],dict) and bindings[j].get("entity") == vid
                    for j in positions)
                got.append((int(at.split(":")[1]), k, tex, bound))
    return got

def issues(spec, ix):
    out = []
    mandatory = str(spec.get("sheet", "")).split("/")[0] == "G9-T31"
    for iid,it in ix.items.items():
        bind = it.get(FIELD)
        answers = [f for f in ix.facts.values() if f.get("item") == iid and f.get("role") == "answer" and f.get("rel") == "var_value"]
        if not mandatory and bind is None: continue
        if bind is not None and (not isinstance(bind,dict) or set(bind) != {"scope","block","island","variable"} or bind.get("scope") not in (iid,ix.scope_question.get(iid)) or any(type(bind.get(k)) is not int or bind[k] < 0 for k in ("block","island")) or not answers):
            out.append(Issue("ROOT_EQUATION_BINDING_BAD", iid, "invalid location reference")); continue
        for f in answers:
            vid = (f.get("args") or [None])[0]
            var = (ix.entities.get(vid) or {}).get("name", "")
            if not var: continue
            got = []
            for scope in ([bind["scope"]] if bind is not None else [iid,ix.scope_question.get(iid)]):
                got = candidates(spec,scope,vid,var)
                if got: break
            if bind is not None:
                got = [r for r in got if r[:2] == (bind["block"],bind["island"]) and bind["variable"] == vid]
            if len(got) != 1:
                code = "ROOT_EQUATION_BINDING_BAD" if bind is not None else ("ROOT_EQUATION_AMBIGUOUS" if got else "ROOT_EQUATION_MISSING")
                out.append(Issue(code, f["id"], "root must be tied to one printed item/stem equation")); continue
            _b,_i,tex,bound = got[0]
            if not bound:
                out.append(Issue("ROOT_EQUATION_BINDING_BAD",f["id"],"the equation's variable is not bound")); continue
            try:
                poly = polynomial(tex,var)
            except (ValueError, SyntaxError, TypeError, ZeroDivisionError, OverflowError) as ex:
                out.append(Issue("ROOT_EQUATION_UNSUPPORTED",f["id"],str(ex))); continue
            try:
                x = N._ex(f["value"])
                val = (Q(0),Q(0),1)
                for deg in range(max(poly),-1,-1):
                    a,b,r = val
                    c,d,t = x
                    rad = r if b else t
                    if b and d and r != t:
                        raise ValueError("mixed radicals")
                    val = N.C._norm_exact(a*c + b*d*rad, a*d + b*c, rad)
                    val = N._add(val,(poly.get(deg,Q(0)),Q(0),1))
                if val != (Q(0),Q(0),1):
                    out.append(Issue("ANSWER_RECOMPUTE_MISMATCH", f["id"], "exact substitution in $%s$ is nonzero" % tex))
            except (ValueError, TypeError, KeyError):
                # The ordinary fact-number validator reports invalid values.
                pass
    return out


# Original G9-T31 root keys use x. Coefficient keys such as a=1, b=-6
# are not roots; other variables require the item's explicit solve wording.
_ASSIGNMENT = re.compile(r'(?<![A-Za-z0-9])x(?:_\{?[12]\}?)?\s*=')
_ROOT_TASK = re.compile(r'פתרו|מצאו\s+את\s+הפתרון|רשמו\s+את\s+הפתרונות')


def _key_roots(text):
    """Closed private-key grammar: x=exact [or x=exact], with one ±.

    Each complete math island or plain alternative must be a root
    assignment. Unknown root expressions refuse; nothing is evaluated as
    Python and no unparsed assignment is dropped.
    """
    source = text.replace('$', '').replace('−', '-').replace(r'\pm', '±')
    source = re.sub(r'\\text\{\s*או\s*\}', ' או ', source)
    chunks = re.split(r'\s+או\s+|\s+or\s+|[,;]|\\(?:lor|vee)\b', source)
    roots = []
    for chunk in chunks:
        chunk = chunk.strip().rstrip('.').strip()
        m = re.fullmatch(r'([a-z])(?:_\{?[12]\}?)?\s*=\s*(.+)', chunk)
        if not m:
            raise ValueError('key must contain only explicit variable = exact-root alternatives')
        var, expression = m.groups()
        if expression.count('±') > 1:
            raise ValueError('at most one plus/minus per exact root expression')
        if '±' in expression:
            left, right = (N._ex(v.strip()) for v in expression.split('±'))
            for sign in (1, -1):
                roots.append((var, N._add(left, (right[0]*sign, right[1]*sign, right[2]))))
        else:
            roots.append((var, N._ex(expression)))
    if not roots:
        raise ValueError('root key has no exact roots')
    return roots


def _substitute(poly, x):
    """Horner evaluation in one exact quadratic extension."""
    value = (Q(0), Q(0), 1)
    for degree in range(max(poly), -1, -1):
        a, b, r = value
        c, d, t = x
        radical = r if b else t
        if b and d and r != t:
            raise ValueError('mixed radicals')
        value = N.C._norm_exact(a*c+b*d*radical, a*d+b*c, radical)
        value = N._add(value, (poly.get(degree, Q(0)), Q(0), 1))
    return value


def key_issues(spec, ix, iid, text):
    """Check original G9-T31 roots before targetless-key permission.

    Discriminant/explanation keys are not root assignments and remain on
    their existing path. A solve item with a non-root/unsupported key is
    refused explicitly rather than called verified.
    """
    if str(spec.get('sheet', '')).split('/')[0] != 'G9-T31':
        return []
    from . import schema_bound as SB
    own_words = ' '.join(block.get('text', '') for scope, _at, block in SB.blocks_of(spec)
                         if scope == iid and isinstance(block, dict) and isinstance(block.get('text'), str))
    if not _ASSIGNMENT.search(text) and not _ROOT_TASK.search(own_words):
        return []
    try:
        roots = _key_roots(text)
    except (ValueError, TypeError, ZeroDivisionError, OverflowError, SpecError) as ex:
        return [Issue('ROOT_KEY_UNSUPPORTED', iid, str(ex))]
    out = []
    equations = {}
    for var, root in roots:
        if var not in equations:
            entities = [e for e in ix.entities.values() if e.get('kind') == 'variable' and e.get('name') == var]
            if len(entities) != 1:
                out.append(Issue('ROOT_EQUATION_BINDING_BAD', iid, 'root variable is not one declared variable'))
                continue
            vid = entities[0]['id']
            got = []
            for scope in (iid, ix.scope_question.get(iid)):
                got = candidates(spec, scope, vid, var)
                if got:
                    break
            if len(got) != 1:
                code = 'ROOT_EQUATION_AMBIGUOUS' if got else 'ROOT_EQUATION_MISSING'
                out.append(Issue(code, iid, 'original root key needs one printed bound item/stem equation'))
                continue
            _block, _island, tex, bound = got[0]
            if not bound:
                out.append(Issue('ROOT_EQUATION_BINDING_BAD', iid, 'the equation variable is not bound in its own island'))
                continue
            try:
                equations[var] = (polynomial(tex, var), tex)
            except (ValueError, SyntaxError, TypeError, ZeroDivisionError, OverflowError) as ex:
                out.append(Issue('ROOT_EQUATION_UNSUPPORTED', iid, str(ex)))
                continue
        poly, tex = equations[var]
        try:
            if _substitute(poly, root) != (Q(0), Q(0), 1):
                out.append(Issue('ANSWER_RECOMPUTE_MISMATCH', iid, 'original key root does not satisfy $%s$ exactly' % tex))
        except (ValueError, TypeError, ZeroDivisionError, OverflowError) as ex:
            out.append(Issue('ROOT_KEY_UNSUPPORTED', iid, str(ex)))
    return out


REASONS.setdefault('ROOT_KEY_UNSUPPORTED', 'an original root key is outside the explicit exact-root alternatives grammar')
