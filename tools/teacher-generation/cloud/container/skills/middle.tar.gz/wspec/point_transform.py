"""Source-bound Cartesian reflection/translation tasks (C1).

An item carries transforms, never result coordinates. Each row references
an existing source point with two printed GIVEN coordinates and a distinct
result with two private coordinate targets. Anonymous vertex handles are
supported without inventing printed letters. A closed two-step source case
also permits an immediately preceding translation followed by x reflection;
other chained private results and arbitrary matrices are unsupported.
"""
import re
from fractions import Fraction
from . import canon as C
from .errors import Issue, REASONS
from .sheet_data import _context, norm, number

OPS = ("reflect_x", "reflect_y", "reflect_origin", "translate")
FIELDS = {"id", "source_point", "result_point", "op", "instruction", "request"}
TOKEN = re.compile(r"^[A-Za-z][A-Za-z0-9_-]{0,31}$")
AXES = ("axis:x", "axis:y")
for code, detail in {
    "TRANSFORM_SOURCE_BAD": "a Cartesian transform is not bound to its printed source task",
    "TRANSFORM_ANSWER_BAD": "a private transformed coordinate differs from exact recomputation",
}.items():
    REASONS.setdefault(code, detail)


def rows(spec):
    for q in spec.get("questions") or []:
        for item in q.get("items") or []:
            rs = item.get("transforms")
            if isinstance(rs, list):
                for row in rs:
                    if isinstance(row, dict):
                        yield q, item, row


def target_row(spec, fact):
    args = fact.get("args") or []
    if fact.get("role") != "target" or fact.get("rel") != "coordinate" or len(args) != 2:
        return None
    return next((r for _q, it, r in rows(spec) if it.get("id") == fact.get("item")
                 and r.get("result_point") == args[0]), None)


def description(spec, fact):
    row = target_row(spec, fact)
    request = (row or {}).get("request")
    return request.get("text") if isinstance(request, dict) else None


def find_what(spec, fact):
    """Distinct answer-free coordinate query, without inventing point names."""
    row = target_row(spec, fact)
    if row is None:
        return None
    q, it, _ = next((q, it, r) for q, it, r in rows(spec) if r is row)
    prior = _prior(spec, q["id"], it["id"], row)
    if prior is not None:
        pi, pr = prior
        source = source_xy(spec, q["id"], pi["id"], pr["source_point"])
    else:
        source = source_xy(spec, q["id"], it["id"], row["source_point"])
    op = {"reflect_x": "השיקוף ביחס לציר x", "reflect_y": "השיקוף ביחס לציר y",
          "reflect_origin": "השיקוף ביחס לראשית", "translate": "ההזזה"}[row["op"]]
    if prior is not None:
        op += " של תוצאת ההזזה"
    return "שיעור %s של %s של (%s,%s)" % (fact["args"][1].split(":")[1], op,
                                           C.canon_number(str(source[0])), C.canon_number(str(source[1])))


def _facts(spec):
    return [f for f in spec.get("facts") or [] if isinstance(f, dict)]


def source_xy(spec, qid, iid, point):
    vals = {}
    for axis in AXES:
        fs = [f for f in _facts(spec) if f.get("rel") == "coordinate" and
              f.get("role") == "given" and f.get("item") in (qid, iid) and
              f.get("args") == [point, axis]]
        if len(fs) != 1 or number(fs[0].get("value")) is None:
            return None
        vals[axis] = number(fs[0]["value"])
    return tuple(vals[a] for a in AXES)


def _prior(spec, qid, iid, row):
    """Only the immediately preceding, own-question translation result."""
    if not isinstance(row.get("from_item"), str) or row.get("op") != "reflect_x":
        return None
    q = next((q for q in spec.get("questions") or [] if q.get("id") == qid), {})
    items = q.get("items") or []
    indices = [n for n, it in enumerate(items) if it.get("id") == iid]
    if len(indices) != 1 or indices[0] == 0:
        return None
    previous = items[indices[0]-1]
    if previous.get("id") != row["from_item"]:
        return None
    matches = [r for r in previous.get("transforms") or [] if isinstance(r, dict)
               and r.get("result_point") == row.get("source_point")]
    if len(matches) != 1 or matches[0].get("op") != "translate" or "from_item" in matches[0]:
        return None
    return previous, matches[0]


def expected(spec, qid, iid, row, _seen=None):
    """Exact value for private validation / local absence proof, not export."""
    seen = set(_seen or ())
    identity = (qid, iid, row.get("id"))
    if identity in seen:
        return None
    seen.add(identity)
    if "from_item" in row:
        prior = _prior(spec, qid, iid, row)
        if prior is None:
            return None
        pi, pr = prior
        xy = expected(spec, qid, pi["id"], pr, seen)
    else:
        xy = source_xy(spec, qid, iid, row.get("source_point"))
    if xy is None:
        return None
    x, y = xy
    op = row.get("op")
    if op == "reflect_x": return x, -y
    if op == "reflect_y": return -x, y
    if op == "reflect_origin": return -x, -y
    if op != "translate": return None
    ents = {e.get("id"): e for e in spec.get("entities") or []}
    moves = row.get("move")
    if not isinstance(moves, dict) or set(moves) != {"x", "y"}: return None
    shifts = []
    for ax in ("x", "y"):
        move = moves.get(ax)
        if not isinstance(move, dict) or set(move) != {"amount", "direction"}: return None
        entity = ents.get(move.get("amount"), {}) if isinstance(move.get("amount"), str) else {}
        amount = number(entity.get("value"))
        directions = {"x": {"right": 1, "left": -1}, "y": {"up": 1, "down": -1}}
        direction = move.get("direction")
        if entity.get("kind") != "number" or amount is None or amount <= 0 or not isinstance(direction, str) or direction not in directions[ax]:
            return None
        shifts.append(amount * directions[ax][direction])
    return x + shifts[0], y + shifts[1]


def _excerpt(rec, scopes, texts):
    return isinstance(rec, dict) and set(rec) == {"scope", "text"} and \
        isinstance(rec.get("scope"), str) and rec["scope"] in scopes and \
        isinstance(rec.get("text"), str) and bool(norm(rec["text"])) and \
        norm(rec["text"]) in texts.get(rec["scope"], "")


def _pair_printed(text, xy):
    from . import schema_bound as SB
    atoms = SB.atoms(text)
    for xi, yi, _ni in SB.coord_pairs(text):
        try:
            if (SB.atom_value(*atoms[xi]), SB.atom_value(*atoms[yi])) == xy:
                return True
        except (ValueError, TypeError):
            pass
    return False


def _move_printed(text, amount, direction):
    # Parse a complete numeric atom: 1 must never match 11 or 10.5.
    # Fractions and finite decimals are compared exactly, by value.
    pattern = r"(?<![\w./+\-])([+\-]?\d+(?:\.\d+)?(?:/\d+)?)(?![\d./])\s*(?:יחידות\s*)?" + direction + r"(?![א-ת])"
    for m in re.finditer(pattern, text):
        try:
            if Fraction(m.group(1)) == amount:
                return True
        except (ValueError, ZeroDivisionError):
            pass
    return False


def source_named(spec, scope, block, entity):
    """An anonymous source is identified by its own printed ordered pair."""
    for q, item, row in rows(spec):
        instruction = row.get("instruction")
        if row.get("source_point") != entity or not isinstance(instruction, dict) or instruction.get("scope") != scope:
            continue
        xy = source_xy(spec, q.get("id"), item.get("id"), entity)
        if xy is not None and _pair_printed(block.get("text", ""), xy):
            return True
    return False


def problems(spec, public=False):
    texts, owners, printed = _context(spec, public)
    ents = {e.get("id"): e for e in spec.get("entities") or []}
    facts = _facts(spec)
    out = []
    for q in spec.get("questions") or []:
        result_ids = set()
        for it in q.get("items") or []:
            if "transforms" not in it: continue
            records = it["transforms"]
            if not isinstance(records, list) or not records:
                out.append(("TRANSFORM_SOURCE_BAD", it.get("id"), "transforms is not a nonempty list"));continue
            seen = set()
            for row in records:
                where = it.get("id")
                fail = lambda why: out.append(("TRANSFORM_SOURCE_BAD", where, why))
                if not isinstance(row, dict) or not all(isinstance(row.get(k), str) for k in ("id", "source_point", "result_point", "op")):
                    fail("invalid transform record types");continue
                op = row["op"]
                if op not in OPS or set(row) != FIELDS | ({"move"} if op == "translate" else set()) | ({"from_item"} if "from_item" in row else set()) or not TOKEN.fullmatch(row["id"]):
                    fail("unknown operation or fields");continue
                if row["id"] in seen or row["result_point"] in result_ids:
                    fail("duplicate operation id or result point")
                seen.add(row["id"]);result_ids.add(row["result_point"])
                src, dst = row["source_point"], row["result_point"]
                if src == dst or any(ents.get(p, {}).get("kind") not in ("point", "vertex") for p in (src, dst)):
                    fail("source and result must be distinct point/vertex entities");continue
                if it.get("task_type") != "compute" or it.get("measurement_allowed") is not False:
                    fail("a transform computes coordinates; it is not a read-off task")
                instr, req = row["instruction"], row["request"]
                if not _excerpt(instr, {q.get("id"), where}, texts) or not _excerpt(req, {where}, texts):
                    fail("instruction/request is not an exact own stem/item excerpt");continue
                if not re.search("רשמו|מצאו|חשבו", req["text"]):
                    fail("the own item must ask for the result")
                prior = None
                if "from_item" in row:
                    prior = _prior(spec, q.get("id"), where, row)
                    if prior is None:
                        fail("only an immediately preceding own-item translation may feed x reflection");continue
                    pi, pr = prior
                    if instr != pr.get("instruction") or instr.get("scope") != q.get("id") or \
                            not re.search(r"ולאחר מכן\s+שיקו[ףפ]", norm(instr["text"])) or \
                            not re.search(r"אחרי\s+השיקו[ףפ]", norm(req["text"])):
                        fail("the printed stem/request does not bind translation then reflection");continue
                    source_scope, source_id = pi["id"], pr["source_point"]
                else:
                    source_scope, source_id = where, src
                xy = source_xy(spec, q.get("id"), source_scope, source_id)
                if xy is None or not _pair_printed(instr["text"], xy):
                    fail("instruction must print the source point's ordered given pair");continue
                given = [f for f in facts if f.get("rel") == "coordinate" and f.get("role") == "given" and f.get("item") in (q.get("id"), source_scope) and (f.get("args") or [None])[0] == source_id]
                if not all(f.get("id") in printed for f in given):
                    fail("source coordinates are not printed givens")
                clause = norm(instr["text"]).replace("−", "-")
                if re.search(r"(?:^|\s)(?:אינו|אינה|לא|אין)(?:\s|$)", clause):
                    fail("negated operation is not a transform instruction")
                if op.startswith("reflect_"):
                    if not re.search("שיקו[ףפ]|סימטרי", clause): fail("no printed reflection")
                    if op == "reflect_origin":
                        if "לראשית" not in clause: fail("origin reflection not stated")
                    else:
                        ax = op[-1]
                        if "לשני הצירים" not in clause and not re.search(r"לציר\s*(?:ה[־-]?\s*)?"+ax+r"\b", clause):
                            fail("reflection axis not stated")
                    if not re.search("שיקו[ףפ]|סימטרי", req["text"]): fail("item asks no reflection")
                else:
                    if "הזזה" not in clause or "ההזזה" not in req["text"]: fail("translation not stated/requested")
                    moves = row.get("move")
                    if not isinstance(moves, dict) or set(moves) != {"x", "y"}:
                        fail("translation needs two source-bound directions");continue
                    for ax in ("x", "y"):
                        move = moves[ax]
                        if not isinstance(move, dict) or set(move) != {"amount", "direction"} or not isinstance(move.get("amount"), str) or not isinstance(move.get("direction"), str):
                            fail("invalid direction record");continue
                        amount = number(ents.get(move["amount"], {}).get("value"))
                        direction = {"right": "ימינה", "left": "שמאלה", "up": "למעלה", "down": "למטה"}.get(move["direction"])
                        if amount is None or not direction or not _move_printed(clause, amount, direction):
                            fail("move amount/direction not printed")
                want = expected(spec, q.get("id"), where, row)
                if want is None: fail("operation has no exact source result");continue
                targets = []
                for axis, value in zip(AXES, want):
                    ts = [f for f in facts if f.get("role") == "target" and f.get("rel") == "coordinate" and f.get("item") == where and f.get("args") == [dst, axis]]
                    ids = {t.get("id") if isinstance(t, dict) else t for t in it.get("targets") or []}
                    if len(ts) != 1 or ts[0].get("id") not in ids or ts[0].get("id") not in printed:
                        fail("result needs exactly two printed coordinate targets");continue
                    targets += ts
                    if not public:
                        answers = [f for f in facts if f.get("role") == "answer" and f.get("rel") == "coordinate" and f.get("item") == where and f.get("args") == [dst, axis]]
                        if len(answers) != 1 or number(answers[0].get("value")) != value:
                            out.append(("TRANSFORM_ANSWER_BAD", where, "%s exact recomputation disagrees" % axis))
                if any(owners.get(f.get("item")) == q.get("id") and f.get("role") != "answer" and f.get("value") is not None and f.get("rel") == "coordinate" and (f.get("args") or [None])[0] == dst for f in facts):
                    fail("a result coordinate is not public placement data")
    return out


def validate(spec, ix, out):
    out.extend(Issue(*entry) for entry in problems(spec))


def scan_public(pub, out):
    out.extend(Issue("PUBLIC_VALUE_NOT_WHITELISTED", where, detail)
               for _code, where, detail in problems(pub, True))


def answer_pairs(spec, item, ix):
    """Private key entries for transforms, from already validated answers."""
    pairs = []
    for row in item.get("transforms") or []:
        point = row["result_point"]
        vals = []
        for axis in AXES:
            f = next(f for f in ix.facts.values() if f.get("item") == item["id"] and
                     f.get("role") == "answer" and f.get("rel") == "coordinate" and
                     f.get("args") == [point, axis])
            vals.append(C.family_display(f["value"], "tex"))
        name = (ix.entities.get(point) or {}).get("name") or ""
        pairs.append("$%s(%s,%s)$" % (name, vals[0], vals[1]))
    return pairs
