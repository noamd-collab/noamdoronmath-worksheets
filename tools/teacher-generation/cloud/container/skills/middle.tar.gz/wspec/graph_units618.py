"""H-B4: key units read against the units printed in the axis titles.

Closed title forms: UNIT or quantity (UNIT). Legacy unitless diagrams are
not reinterpreted. A dimensional answer needs its unit beside its value;
an unrelated occurrence of the right unit elsewhere does not license it.
"""
import re
from fractions import Fraction
from . import canon as C

WORDS = dict(C.UNIT_WORDS)
WORDS.update({"%":"%", "יחידות":"u", "יחידה":"u"})
_UNIT = re.compile(r"^(" + "|".join(re.escape(w) for w in sorted(WORDS,key=len,reverse=True)) + r")(?![א-תA-Za-z])")
_NUM = re.compile(r"(?<![\d.A-Za-z])[+−-]?\d+(?:\.\d+)?(?:/\d+)?(?![\d.])")

def axis_unit(axis):
    title = (axis or {}).get("title")
    if not isinstance(title,str): return None
    m=re.fullmatch(r"[^()]+\(([^()]+)\)\s*",title)
    word=(m.group(1) if m else title).strip()
    return WORDS.get(word)

def _unit_start(s):
    m=_UNIT.match(s.lstrip())
    if not m: return None, s
    return WORDS[m.group(1)], s.lstrip()[m.end():]

def _unit_expr(s):
    unit,rest=_unit_start(s)
    if not unit: return None
    # rate: litres per minute / kilometres per hour, in Hebrew.
    m=re.match(r"\s*(?:/|לכל\s+|ל)(.*)",rest)
    if m:
        den,tail=_unit_start(m.group(1))
        if den and re.match(r"\s*(?:/|לכל\s+|ל)",tail):
            return (unit,den,"MULTIPLE_DENOMINATORS")
        return (unit,den or "UNSUPPORTED_DENOMINATOR")
    return unit

def expected(axes, rel, nums):
    x,y=(axis_unit((axes or {}).get(a)) for a in ('x','y'))
    if x is None and y is None: return None
    if rel in ('slope',): return [(y,x)]*len(nums) if x and y else False
    if rel in ('y_intercept','min_value','value_at'): return [y]*len(nums) if y else False
    if rel in ('x_intercept','axis_of_symmetry','zeros','x_for_value','increase_interval','decrease_interval','positive_interval','negative_interval'):
        return [x]*len(nums) if x else False
    if rel in ('vertex','plot_point','intersection','shift'):
        return ([x,y]*(len(nums)//2)) if x and y else False
    return None

def problem(line, axes, rel, nums):
    want=expected(axes,rel,nums or [])
    if want is None: return None
    if want is False: return 'GRAPH_KEY_UNIT: dimensional find has no declared unit on its relevant axis'
    if not nums: return None
    from .sheet_graph import _untex
    text=_untex(line).replace('$','').replace('−','-')
    text=re.sub(r"\\(?:f|frac|dfrac|tfrac)\{([^{}]+)\}\{([^{}]+)\}",r"\1/\2",text)
    seen=[]
    for m in _NUM.finditer(text):
        try: value=Fraction(m.group(0))
        except ValueError: continue
        seen.append((value,_unit_expr(text[m.end():])))
    if rel in ('vertex','plot_point','intersection','shift'):
        # Ordered pairs require the x-unit before the y-unit, including
        # when both numerical coordinates happen to be equal.
        ordered=[(v,u) for v,u in seen if u is not None]
        needed=[(Fraction(v),u) for v,u in zip(nums,want)]
        if ordered != needed:
            return 'GRAPH_KEY_UNIT: coordinate values/units are not in x,y order'
    remaining=list(seen)
    for value,unit in zip(nums,want):
        value=Fraction(value)
        if (value,unit) not in remaining:
            return 'GRAPH_KEY_UNIT: answer %s must state axis unit %s beside its value' % (value,unit)
        remaining.remove((value,unit))
    # A contradictory second unit for the SAME requested value is not
    # repaired merely by adding a correct-unit restatement later.
    for value,unit in remaining:
        permitted={u for v,u in zip(nums,want) if Fraction(v)==value}
        if permitted and unit is not None and unit not in permitted:
            return 'GRAPH_KEY_UNIT: contradictory unit %s for answer %s' % (unit,value)
    return None
