# -*- coding: utf-8 -*-
"""Authoring helpers: build entities / facts with ids by the fixed rule.
Pure convenience -- validate() re-derives every id and refuses a mismatch."""
from . import canon
from .schema import SPEC_VERSION


def ent(kind, **kw):
    e = dict(kind=kind, **kw)
    e["id"] = canon.entity_id(e)
    return e


def points(names):
    return [ent("point", name=n) for n in names]


def seg(a, b):
    return ent("segment", ends=[a, b])


def line(a, b, name=None):
    """A geometric line; an optional printed lowercase name is not its ID."""
    return ent("line", through=[a, b], **({"name": name} if name is not None else {}))


def ang(vertex, a, b):
    return ent("angle", vertex=vertex, arms=[a, b])


def poly(vs):
    return ent("polygon", vertices=list(vs))


def stated():
    return {"kind": "stated"}


def derived(rule, frm):
    return {"kind": "derived", "rule": rule, "from": list(frm)}


def ctx(kind):
    return {"kind": "context", "context_kind": kind}


def fact(item, rel, args, role, source, value=None, unit=None, display=None,
         text_template=None):
    f = {"item": item, "rel": rel, "args": list(args), "role": role,
         "source": source}
    if value is not None:
        f["value"] = value
    if unit is not None:
        f["unit"] = unit
    if display is not None:
        f["display"] = list(display)
    if text_template is not None:
        f["text_template"] = text_template
    f["id"] = canon.fact_id(f)
    return f


def answer(target, value=None, unit=None):
    """The private answer of a target (same item/rel/args, slot a)."""
    a = {"item": target["item"], "rel": target["rel"],
         "args": list(target["args"]), "role": "answer"}
    a["id"] = canon.fact_id(a)
    a["source"] = derived("answer_key", [target["id"]])
    if value is not None:
        a["value"] = value
    if unit is not None:
        a["unit"] = unit
    if target.get("display") is not None:
        a["display"] = list(target["display"])
    return a


def release(f, reviewer, reason, timestamp):
    """A release a PERSON approved: reviewer, the time (ISO 8601) and the
    hash of the fact approved. No defaults: an approval is recorded, never
    generated (close_gaps). Normally read from an approvals file
    (load_approvals)."""
    return {"fact": f["id"], "basis": "approval", "reviewer": reviewer,
            "timestamp": timestamp, "reason": reason,
            "fact_hash": canon.fact_hash(f)}


def release_from_item(f, item, reason):
    """PROVENANCE, not an approval: f restates the claim that the earlier
    item `item` proved (a to_prove there, named in f's source). The check is
    mechanical (project.release_problem); nobody is named as a reviewer."""
    return {"fact": f["id"], "basis": "from_item", "from_item": item,
            "reason": reason, "fact_hash": canon.fact_hash(f)}


def carried_given(f_given, item):
    """(v6.10 fix r1, L1) the given an EARLIER item stated, carried into
    the later item `item` without printing it again (v6.7.3 b q5d: item ג
    says "נתון גם: ∠OAB = 20°", item ד uses it). Returns (fact, release):
    a derived given of `item` (rule prior_item_result, from the earlier
    given) and its from_item provenance record. Its Noam-AI given reads
    "... (נתון בסעיף ג)"."""
    f = fact(item, f_given["rel"], f_given["args"], "given",
             derived("prior_item_result", [f_given["id"]]),
             value=f_given.get("value"), unit=f_given.get("unit"),
             display=f_given.get("display"))
    for k in ("coef",):
        if k in f_given:
            f[k] = list(f_given[k])
    return f, release_from_item(f, f_given["item"],
                                "stated in item %s" % f_given["item"])


def load_approvals(path, spec):
    """The approval releases of an APPROVALS FILE: a JSON list of
    {"fact", "fact_hash", "reviewer", "timestamp", "reason"} written by the
    person who approved them. Each entry becomes a release of basis
    'approval'; an entry whose fact is not in spec is skipped (listed in
    the second return value). The hash is the file's, not recomputed: a
    fact changed after the approval is refused (RELEASE_STALE)."""
    import json
    with open(path, encoding="utf-8") as fh:
        entries = json.load(fh)
    ids = set(f["id"] for f in spec.get("facts") or [])
    out, skipped = [], []
    for e in entries:
        if e.get("fact") not in ids:
            skipped.append(e.get("fact"))
            continue
        out.append({"fact": e["fact"], "basis": "approval",
                    "reviewer": e.get("reviewer"),
                    "timestamp": e.get("timestamp"),
                    "reason": e.get("reason"),
                    "fact_hash": e.get("fact_hash")})
    return out, skipped


def prose(pid, scope, text, approved_by):
    """A prose block as the author approved it. approved_by has no default:
    recording an approval is the author's act, not a checksum the helper
    computes on its own (verifier r1, V1)."""
    return {"id": pid, "scope": scope, "text": text,
            "approved_hash": canon.sha256_text(text),
            "approved_by": approved_by}


def prose_pending(pid, scope, text):
    """(v6.10) a prose block PROPOSED for the author: no approval recorded,
    so validate() refuses it (PROSE_UNAPPROVED) and nothing prints it until
    the author approves this exact text in an approvals file
    (load_prose_approvals). An agent writes proposals, never approvals."""
    return {"id": pid, "scope": scope, "text": text, "approved_hash": "",
            "approved_by": ""}


def load_prose_approvals(path, prose_list):
    """(v6.10) bind the author's prose approvals to the proposed blocks.
    The APPROVALS FILE is a JSON list of {"prose": id, "approved_hash":
    sha256 of the exact text approved, "reviewer": who, "timestamp": ISO
    8601, optional "number_words": ["אחד"] -- number words of the text the
    reviewer declares are no value}, written by the person who approved. A
    block gets
    approved_by = "<reviewer> <timestamp>" and the file's hash -- which is
    the text's own hash only when the text is still the one approved (an
    edit after the approval stays PROSE_UNAPPROVED). Returns (blocks,
    [ids with no approval])."""
    import json
    import re
    with open(path, encoding="utf-8") as fh:
        entries = json.load(fh)
    iso = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2})?"
                     r"(?:Z|[+-]\d{2}:\d{2})\Z")
    by = {}
    for e in entries:
        if isinstance(e, dict) and isinstance(e.get("reviewer"), str) and \
                e["reviewer"].strip() and \
                iso.match(str(e.get("timestamp") or "")):
            by[e.get("prose")] = e
    out, missing = [], []
    for p in prose_list:
        q = dict(p)
        e = by.get(p.get("id"))
        if e is None:
            missing.append(p.get("id"))
        else:
            q["approved_hash"] = e.get("approved_hash") or ""
            q["approved_by"] = "%s %s" % (e["reviewer"].strip(),
                                          e["timestamp"])
            if e.get("number_words"):
                # the reviewer declares these number words are no value
                q["approved_words"] = list(e["number_words"])
        out.append(q)
    return out, missing


def T(tpl, facts=(), entities=(), **params):
    s = {"tpl": tpl}
    if facts:
        s["facts"] = [f["id"] if isinstance(f, dict) else f for f in facts]
    if entities:
        s["entities"] = [e["id"] if isinstance(e, dict) else e
                         for e in entities]
    if params:
        s["params"] = params
    return s


def J(s):
    return {"join": s}


def spec(sheet, entities, questions, facts, figures, prose=(), releases=(),
         didactic=None):
    d = {"spec_version": SPEC_VERSION, "sheet": sheet,
         "entities": list(entities), "questions": list(questions),
         "facts": list(facts), "figures": list(figures)}
    if prose:
        d["prose"] = list(prose)
    if releases:
        d["releases"] = list(releases)
    if didactic is not None:
        d["didactic"] = didactic
    return d
