# -*- coding: utf-8 -*-
"""Baseline + diff (C4), and the "target already given" check.

A pilot promises the SAME questions. Reclassifying an answer as stated and
printing it changes the exercise, so it must fail here even though every
schema rule would then be satisfied. freeze() records, per question and
item, the facts, targets and answers; diff() reports every added, removed
or changed one with a reason code. Nothing is tolerated: an added fact, a
changed value, a removed target or a changed answer is a failure. The
structure is frozen too -- question order, the items of each question in
order, labels -- and a spec with a duplicated question/item id is refused:
ids key the comparison, so a duplicate could otherwise hide an added item
(verifier r1, V6b). measurement_allowed (per item) and figure_accuracy
(per figure) are frozen as well (R3-06)."""
import hashlib

from . import canon
from . import project as P
from . import schema as S
from .errors import Issue, SpecError

BASELINE_VERSION = 6
# v6.13 (W-BOUND-PROSE, same version: a record without bound prose is
# unchanged): a scope's printed record also holds, when present, its bound
# blocks with their binding tables and the question's table / worked
# example -- rebinding a number or changing a cell is BASELINE_TEXT_CHANGED.
# v6 (close_gaps 2026-09-23, verifier semantics r3 SV3-04): which figure
# each question and item SHOWS (item <-> figure link) and each fact's
# display override are frozen -- pointing q1c at q1b's figure changed what
# the student sees with every other record equal.
# v5 (fix structural r2, verifier semantics r2 SR2-01/SR2-05): what the
# student READS is frozen -- per question and item, the printed text, the
# given lines, the target descriptions and the answer key line -- and each
# fact records whether it is public. Releasing a derived step (a new given
# line) or changing an item's wording ("compute" -> "compute and justify")
# changed the exercise with every fact record equal.
# v4 (fix structural r1, verifier semantics r1 V8/V9): each figure's listed
# entities and drawn facts are frozen (a helper segment added to a figure
# changes the exercise the student sees), and the sheet id is compared.
# v3 (verifier r3, R3-06): each item's measurement_allowed and each
# figure's figure_accuracy are frozen too -- flipping a compute item to
# measurement_allowed=true makes solving by measuring legitimate, which
# changes the exercise as surely as a new given does.


def _fact_rec(f, ix):
    rec = {"rel": f.get("rel"), "args": canon.fact_key_args(f),
           "role": f.get("role"), "display": f.get("display"),
           "source": (f.get("source") or {}).get("kind"),
           "public": bool(P.eligible(f, ix))}
    if f.get("value") is not None:
        try:
            rec["value"] = canon.canon_number(f["value"])
        except Exception:
            rec["value"] = repr(f["value"])
    if f.get("coef") is not None:
        # (v6.10) a linear relation's coefficients are part of what it says
        try:
            rec["coef"] = [canon.canon_number(c) for c in f["coef"]]
        except Exception:
            rec["coef"] = repr(f["coef"])
    try:
        u = canon.canon_unit(f.get("unit"))
    except Exception:
        u = repr(f.get("unit"))
    if u:
        rec["unit"] = u
    return rec


def _content(spec):
    """(content, duplicated scope ids)."""
    ix = S.Index(spec)
    scopes, dups, order = {}, [], []
    for q in spec.get("questions") or []:
        if q["id"] in scopes:
            dups.append(q["id"])
        order.append(q["id"])
        scopes[q["id"]] = {"kind": "question", "n": q.get("n"),
                           "figure": q.get("figure"),
                           "items": [it["id"] for it in q.get("items") or []],
                           "facts": {}, "targets": {}, "answers": {}}
        for it in q.get("items") or []:
            if it["id"] in scopes:
                dups.append(it["id"])
            scopes[it["id"]] = {"kind": "item", "label": it.get("label"),
                                "figure": it.get("figure"),
                                "task_type": it.get("task_type"),
                                "measurement_allowed":
                                    it.get("measurement_allowed"),
                                "facts": {}, "targets": {}, "answers": {}}
    for f in ix.facts.values():
        sc = scopes.get(f.get("item"))
        if sc is None:
            continue
        role = f.get("role")
        bucket = "answers" if role == "answer" else (
            "targets" if role in S.TARGET_ROLES else "facts")
        sc[bucket][f["id"]] = _fact_rec(f, ix)
    printed = _printed(spec)
    for sid, sc in scopes.items():
        sc["printed"] = None if printed is None else printed.get(sid)
    figures = {}
    for g in spec.get("figures") or []:
        if isinstance(g, dict):
            if g.get("id") in figures:
                dups.append(g.get("id"))
            figures[g.get("id")] = {
                "scope": g.get("scope"),
                "figure_accuracy": g.get("figure_accuracy"),
                "entities": sorted(str(x) for x in g.get("entities") or []),
                "draws": sorted(str(x) for x in g.get("draws") or [])}
            if g.get("frame") is not None:
                # (v6.12) a family figure's frame (range, step, labels,
                # grid) is what the student reads: frozen (only when
                # present, so a figure without one keeps its record)
                try:
                    figures[g.get("id")]["frame"] = canon.canon_frame(
                        g["frame"])
                except Exception:       # noqa: BLE001
                    figures[g.get("id")]["frame"] = repr(g["frame"])
    return {"baseline_version": BASELINE_VERSION, "sheet": spec.get("sheet"),
            "order": order, "scopes": scopes, "figures": figures}, dups


def _printed(spec):
    """What each question / item PRINTS: {scope id: {text, given_lines,
    targets (descriptions), answer_key}}, from the public and private
    models; None when the spec cannot be printed (then every scope's
    printed record is None, and a spec that prints differs from it)."""
    from . import templates as TT
    try:
        tset = TT.load_templates()
        pub = P.public_model(spec, tset)
        key = P.private_model(spec, tset)["answer_key"]
    except Exception:                   # noqa: BLE001 -- unprintable
        return None
    out = {}
    for q in pub.get("questions") or []:
        out[q["id"]] = {"text": q.get("text"),
                        "given_lines": q.get("given_lines")}
        # (v6.13, W-BOUND-PROSE) the printed table / worked example and the
        # binding table of the bound blocks are what the student reads (a
        # number rebound to another fact changes the exercise with the
        # same wording); recorded only when present, so a record without
        # them is unchanged
        for k in ("table", "example", "bound"):
            if q.get(k) is not None:
                out[q["id"]][k] = q[k]
        for it in q.get("items") or []:
            out[it["id"]] = {"text": it.get("text"),
                             "given_lines": it.get("given_lines"),
                             "targets": [t.get("description")
                                         for t in it.get("targets") or []],
                             "answer_key": key.get(it["id"])}
            if it.get("bound") is not None:
                out[it["id"]]["bound"] = it["bound"]
    return out


def _hash(content):
    return hashlib.sha256(canon.dumps(content).encode("utf-8")).hexdigest()


def _dup_issues(dups):
    return [Issue("DUPLICATE_ID", "scope %r" % d, "question/item id used "
                  "twice") for d in sorted(set(dups))]


def freeze(spec):
    c, dups = _content(spec)
    if dups:
        raise SpecError(_dup_issues(dups))
    return {"content": c, "sha256": _hash(c)}


def _multiset_diff(a, b):
    rest = list(b)
    extra = []
    for x in a:
        if x in rest:
            rest.remove(x)
        else:
            extra.append(x)
    return extra


def diff(spec, baseline):
    """[Issue]: every difference between spec and baseline."""
    out = []
    if _hash(baseline.get("content")) != baseline.get("sha256"):
        return [Issue("BASELINE_STALE", "baseline", "content hash")]
    if baseline["content"].get("baseline_version") != BASELINE_VERSION:
        return [Issue("BASELINE_STALE", "baseline", "version %r" % (
            baseline["content"].get("baseline_version"),))]
    newc, dups = _content(spec)
    out.extend(_dup_issues(dups))
    if newc.get("sheet") != baseline["content"].get("sheet"):
        out.append(Issue("BASELINE_SHEET_CHANGED", "sheet", "%r -> %r" % (
            baseline["content"].get("sheet"), newc.get("sheet"))))
    old = baseline["content"]["scopes"]
    new = newc["scopes"]
    oo, no = baseline["content"]["order"], newc["order"]
    if oo != no and sorted(oo) == sorted(no):
        out.append(Issue("BASELINE_ORDER_CHANGED", "sheet", "%s -> %s" % (
            ",".join(oo), ",".join(no))))
    for sid in old:
        if sid not in new:
            out.append(Issue("BASELINE_ITEM_REMOVED", sid))
    for sid, sc in new.items():
        if sid not in old:
            out.append(Issue("BASELINE_ITEM_ADDED", sid))
            continue
        o = old[sid]
        if sc["kind"] == "question" and o.get("kind") == "question":
            for x in _multiset_diff(sc["items"], o["items"]):
                out.append(Issue("BASELINE_ITEM_ADDED", sid, "item " + x))
            for x in _multiset_diff(o["items"], sc["items"]):
                out.append(Issue("BASELINE_ITEM_REMOVED", sid, "item " + x))
            if sc["items"] != o["items"] and \
                    sorted(sc["items"]) == sorted(o["items"]):
                out.append(Issue("BASELINE_ORDER_CHANGED", sid,
                                 "items reordered"))
        if sc.get("n") != o.get("n") or sc.get("label") != o.get("label"):
            out.append(Issue("BASELINE_ORDER_CHANGED", sid, "number/label "
                             "%r/%r -> %r/%r" % (o.get("n"), o.get("label"),
                                                 sc.get("n"),
                                                 sc.get("label"))))
        if sc.get("figure") != o.get("figure"):
            out.append(Issue("BASELINE_FIGURE_LINK_CHANGED", sid,
                             "shows figure %r -> %r" % (o.get("figure"),
                                                        sc.get("figure"))))
        if sc.get("task_type") != o.get("task_type"):
            out.append(Issue("BASELINE_TASK_CHANGED", sid, "%s -> %s" % (
                o.get("task_type"), sc.get("task_type"))))
        if sc.get("printed") != o.get("printed"):
            op, np_ = o.get("printed") or {}, sc.get("printed") or {}
            what = sorted(k for k in set(op) | set(np_)
                          if op.get(k) != np_.get(k)) or ["printable"]
            out.append(Issue("BASELINE_TEXT_CHANGED", sid, "%s: %r -> %r" % (
                ", ".join(what), [op.get(k) for k in what],
                [np_.get(k) for k in what])))
        if sc.get("measurement_allowed") != o.get("measurement_allowed"):
            out.append(Issue("BASELINE_MEASUREMENT_CHANGED", sid,
                             "measurement_allowed %r -> %r" % (
                                 o.get("measurement_allowed"),
                                 sc.get("measurement_allowed"))))
        # facts
        for fid, rec in o["facts"].items():
            if fid not in sc["facts"]:
                out.append(Issue("BASELINE_FACT_REMOVED", fid))
        for fid, rec in sc["facts"].items():
            if fid not in o["facts"]:
                code = "BASELINE_STATED_ADDED" if (
                    rec["source"] == "stated" or rec["role"] == "given") \
                    else "BASELINE_FACT_ADDED"
                out.append(Issue(code, fid, rec.get("value", "")))
                continue
            _cmp(fid, o["facts"][fid], rec, out, "BASELINE_VALUE_CHANGED")
        # targets
        for fid in o["targets"]:
            if fid not in sc["targets"]:
                out.append(Issue("BASELINE_TARGET_REMOVED", fid))
        for fid, rec in sc["targets"].items():
            if fid not in o["targets"]:
                out.append(Issue("BASELINE_TARGET_ADDED", fid))
            else:
                _cmp(fid, o["targets"][fid], rec, out,
                     "BASELINE_VALUE_CHANGED")
        # answers
        for fid in o["answers"]:
            if fid not in sc["answers"]:
                out.append(Issue("BASELINE_ANSWER_REMOVED", fid))
        for fid, rec in sc["answers"].items():
            if fid not in o["answers"]:
                out.append(Issue("BASELINE_ANSWER_ADDED", fid))
            else:
                _cmp(fid, o["answers"][fid], rec, out,
                     "BASELINE_ANSWER_CHANGED")
    ofig = baseline["content"].get("figures") or {}
    nfig = newc.get("figures") or {}
    for gid in sorted(set(ofig) | set(nfig), key=str):
        o, n = ofig.get(gid), nfig.get(gid)
        if o != n:
            out.append(Issue("BASELINE_FIGURE_CHANGED", "figure %s" % gid,
                             "%r -> %r" % (o, n)))
    return out


def _cmp(fid, o, n, out, value_code):
    if o.get("display") != n.get("display"):
        out.append(Issue("BASELINE_DISPLAY_CHANGED", fid, "display %r -> %r"
                         % (o.get("display"), n.get("display"))))
    if o.get("public") != n.get("public"):
        out.append(Issue("BASELINE_PUBLIC_CHANGED", fid, "public %r -> %r" % (
            o.get("public"), n.get("public"))))
    if o.get("role") != n.get("role") or o.get("source") != n.get("source"):
        out.append(Issue("BASELINE_ROLE_CHANGED", fid, "%s/%s -> %s/%s" % (
            o.get("role"), o.get("source"), n.get("role"), n.get("source"))))
    if o.get("value") != n.get("value") or o.get("coef") != n.get("coef"):
        out.append(Issue(value_code, fid, "%s%s -> %s%s" % (
            o.get("value"), " coef %s" % o.get("coef") if o.get("coef")
            else "", n.get("value"), " coef %s" % n.get("coef")
            if n.get("coef") else "")))
    if o.get("unit") != n.get("unit"):
        out.append(Issue("BASELINE_UNIT_CHANGED", fid, "%s -> %s" % (
            o.get("unit"), n.get("unit"))))


# ------------------------------------------------- target already given ---
LINE_RELS = ("parallel", "perpendicular")


def _line_key(eid, ix):
    """The supporting line of a segment / line / ray: its two points."""
    e = ix.entities.get(eid) or {}
    k = e.get("kind")
    if k == "segment":
        return frozenset(e.get("ends") or [])
    if k == "line":
        return frozenset(e.get("through") or [])
    if k == "ray":
        return frozenset([e.get("from"), e.get("through")])
    return None


def _right_angle(f):
    try:
        return f.get("value") is not None and canon.same_quantity(
            f["value"], f.get("unit"), 90, "deg")
    except Exception:                   # noqa: BLE001
        return False


def _claims(f, ix):
    """The claims a fact states, as (key, value, unit). One claim can be
    written several ways (verifier r2, R2-03), so the key is normalised:
      * parallel / perpendicular are about the supporting LINES: segment
        AB, line AB and ray AB (or BA) are the same line;
      * an angle of 90 degrees is also the claim "its arms are
        perpendicular" (and a target asking for an angle is answered by
        a given perpendicularity of its arms).
    Other relations are compared literally (canonical id args)."""
    rel = f.get("rel")
    args = f.get("args") or []
    out = []
    lines = [_line_key(a, ix) for a in args]
    if rel in LINE_RELS and len(args) == 2 and all(
            k is not None and len(k) == 2 for k in lines):
        out.append(((rel, frozenset(lines)), None, None))
    elif rel == "linear":
        # (v6.10) the same arguments with other coefficients say another
        # thing: the coefficients are part of the key
        try:
            cf = tuple(canon.canon_number(c) for c in f.get("coef") or [])
        except Exception:               # noqa: BLE001
            cf = ("?",)
        out.append(((rel, tuple(canon.fact_key_args(f)), cf),
                    f.get("value"), f.get("unit")))
    else:
        out.append(((rel, tuple(canon.fact_key_args(f))), f.get("value"),
                    f.get("unit")))
    if rel == "angle_measure" and len(args) == 1:
        e = ix.entities.get(args[0]) or {}
        v, arms = e.get("vertex"), e.get("arms") or []
        if e.get("kind") == "angle" and len(arms) == 2:
            perp = ("perpendicular", frozenset([frozenset([v, arms[0]]),
                                                frozenset([v, arms[1]])]))
            if f.get("role") == "target" or _right_angle(f):
                out.append((perp, None, None))
    return out


def _same(v1, u1, v2, u2):
    if v1 is None or v2 is None:
        return v1 is None and v2 is None
    try:
        return canon.same_quantity(v1, u1, v2, u2)
    except Exception:                   # noqa: BLE001
        return False


def target_given_issues(spec, ix=None):
    """A target whose quantity (or a to_prove whose claim) is already
    given publicly in the same question -- its own text, an earlier item,
    or the item itself. Other questions do not count (the same number in
    another question is legitimate). task_type 'verify' is exempt on
    purpose (declared in schema.TARGET_GIVEN_ALLOWED).

    "Given" = a public given/context/derived fact, AND a to_prove that
    carries a value: "prove that ∠MBC = 28°" prints 28 as plainly as a given
    does, so a target asking for ∠MBC in the same or a later item is
    already answered (verifier r1, V8). Values are compared as quantities
    (130 mm is 13 cm; 13 mm is not). Claims are compared in normal form
    (_claims): AB ⊥ BC as segments is the same claim as lines AB ⊥ BC, and
    as ∠ABC = 90° (verifier r2, R2-03).

    A TARGET is checked against EVERY scope of its question -- the
    question text and every item, earlier AND later (verifier r3, R3-03):
    a later item that states "∠AMB = 56°" prints the answer of an earlier
    "compute ∠AMB" just as plainly, and no baseline is needed to see it
    (a new sheet has none). Any value given for the quantity a target asks
    for counts: equal to its answer it leaks it, different from it the
    question contradicts itself. A later item's genuinely NEW datum (another
    quantity, even with the same number) is not touched.
    A TO_PROVE is checked against its visible scopes only (question,
    earlier items, itself): its claim is printed in its own text, so a
    later item that restates it as a given ("MB = MC", proved in א, given
    in ב/ג/ד of the worked example) reveals nothing -- that is the normal
    way a later item builds on a proof."""
    ix = ix or S.Index(spec)
    out = []
    for f in ix.facts.values():
        role = f.get("role")
        if role not in ("target", "to_prove"):
            continue
        item = ix.items.get(f.get("item"))
        if item is None or item.get("task_type") in S.TARGET_GIVEN_ALLOWED:
            continue
        mine = _claims(f, ix)
        vis = set(ix.visible_scopes(f.get("item")))
        if role == "target":
            qid = ix.scope_question.get(f.get("item"))
            vis = set(sc for sc, qq in ix.scope_question.items()
                      if qq == qid)
        for g in ix.facts.values():
            if g is f or g.get("item") not in vis:
                continue
            grole = g.get("role")
            if grole in ("given", "context", "derived"):
                pass
            elif grole == "to_prove" and role == "target" and \
                    g.get("value") is not None:
                pass              # a printed claim with a value
            else:
                continue
            if not P.eligible(g, ix):
                continue          # a private step is not "given"
            hit = False
            for k, fv, fu in mine:
                for k2, gv, gu in _claims(g, ix):
                    if k != k2:
                        continue
                    if role == "target":
                        # given when the given carries a value, or states
                        # the right angle as a perpendicularity
                        hit = hit or gv is not None or k[0] in LINE_RELS
                    else:
                        hit = hit or _same(fv, fu, gv, gu)
            if role == "target" and f.get("rel") == "classify" and \
                    g.get("rel") == _classify_answer(f, ix) and \
                    (g.get("args") or [None])[0] == (f.get("args") or
                                                     [None])[0]:
                hit = True        # (v6.10) the class asked is stated
            if hit:
                from . import figure_scopes618 as FS618
                if FS618.distinct_state_pair(f, g, ix):
                    continue  # two precisely source-bound positions, not a scope waiver
                from . import base_height as BH
                if BH.read_off_pair(f, g, ix):
                    continue  # exact source read-off of the figure label
                code = "TARGET_ALREADY_GIVEN" if role == "target" else \
                    "TO_PROVE_ALREADY_GIVEN"
                later = ix.scope_key.get(g.get("item"), (0, 0)) > \
                    ix.scope_key.get(f.get("item"), (0, 0))
                out.append(Issue(code, f["id"], "given as %s%s" % (
                    g["id"], " (a LATER item of the same question)"
                    if later else "")))
    return out


def _classify_answer(f, ix):
    a = ix.facts.get(str(f.get("id", ""))[:-1] + "a") or {}
    return a.get("value")


def _figure_shows(g, ix):
    """Entity ids figure g draws: its listed entities and everything a
    drawn fact is drawn on (as geomcheck reads a figure)."""
    shown = set(g.get("entities") or [])
    for d in g.get("draws") or []:
        for a in (ix.facts.get(d) or {}).get("args") or []:
            shown |= S.entity_closure(a, ix)
    return shown


def _drawn_pairs(o):
    """The straight pieces an entity is DRAWN with, as point pairs: a
    segment / line / ray by its two points, a polygon by its sides, an
    angle by its two ARMS (vertex, arm) -- a figure that shows an angle
    shows its arms (verifier semantics r1, V1: the bisector AD passed when
    the figure listed the angle BAD). Other kinds draw no straight piece."""
    k = o.get("kind")
    if k in ("segment", "line"):
        return [frozenset(o.get("ends") or o.get("through") or [])]
    if k == "ray":
        return [frozenset([o.get("from"), o.get("through")])]
    if k == "polygon":
        v = o.get("vertices") or []
        return [frozenset([v[i], v[(i + 1) % len(v)]])
                for i in range(len(v))]
    if k == "angle":
        return [frozenset([o.get("vertex"), a]) for a in o.get("arms") or []]
    return []


def _object_drawn(eid, shown, ix):
    """Is entity eid drawn by a figure that shows `shown`? By its id; a
    point also as an end/vertex of a shown object; a segment, line or ray
    also when a shown object draws the straight piece through the same two
    points (_drawn_pairs: a segment, line, ray, polygon side or angle arm
    -- closing verifier r2, CR2-05; semantics r1, V1); a polygon also when
    EVERY side is drawn."""
    if eid in shown:
        return True
    e = ix.entities.get(eid) or {}
    k = e.get("kind")
    if k == "point":
        return any(eid in S.entity_closure(x, ix) for x in shown)
    pairs = set()
    for x in shown:
        pairs.update(_drawn_pairs(ix.entities.get(x) or {}))
    if k in ("segment", "line"):
        return frozenset(e.get("ends") or e.get("through") or []) in pairs
    if k == "ray":
        return frozenset([e.get("from"), e.get("through")]) in pairs
    if k == "polygon":
        v = e.get("vertices") or []
        return bool(v) and all(frozenset([v[i], v[(i + 1) % len(v)]]) in
                               pairs for i in range(len(v)))
    # (fix structural r2, VT2-10: an angle branch here had no caller -- a
    # construction's result is a segment / line / ray / point / polygon, a
    # hook names a point / segment / line / ray / polygon, and a mark is
    # resolved by its points and MEASURED on its drawn arms (geomcheck) --
    # so it was dead code and is gone; an angle is "drawn" by listing)
    return False


def _points_in(eid, ix):
    """The point ids an entity is built from (its closure's points)."""
    return set(x for x in S.entity_closure(eid, ix)
               if ix.kind(x) == "point")


# (close_gaps SV3-05: _vertices_drawn -- "a polygon result is drawn when
# every vertex is", verifier semantics r2 SR2-03 -- is now the general
# locate rule in construct_drawn_issues: every DEFINING point of a result
# drawn (a polygon's vertices, a segment's ends, a line's / ray's points)
# fixes it, for every construction that locates without a new point.)


# the facts that FIX a point where a reader sees it: the midpoint of a
# segment; a point on two segments of different lines (their crossing)
POINT_FIXED_BY = {"midpoint": 1, "on_segment": 2}


def _incidences(ix, scopes):
    """The PUBLIC, non-degenerate incidence givens (on_segment / midpoint
    of a point and a segment) of `scopes`, as (fact, point, {points})."""
    from . import project as P
    from .schema import _degenerate
    out = []
    for g in sorted(ix.facts.values(), key=lambda f: str(f.get("id"))):
        if g.get("item") not in scopes or \
                g.get("role") not in ("given", "context") or \
                g.get("rel") not in POINT_FIXED_BY or \
                not P.eligible(g, ix):
            continue
        args = g.get("args") or []
        if len(args) != 2 or ix.kind(args[0]) != "point" or \
                ix.kind(args[1]) != "segment" or \
                _degenerate(g["rel"], args, ix):
            continue
        out.append((g, args[0], set([args[0]]) | _points_in(args[1], ix)))
    return out


def _collinear_lines(ix, scopes):
    """The straight lines the public givens of `scopes` state (close_gaps
    SV3-02, verifier semantics r3: 'H על BC' and 'H על BD' with 'D על BC'
    named ONE line twice): each incidence puts its point and its segment's
    ends on one line; two lines that share two points are one line."""
    sets = [set(pts) for _, _, pts in _incidences(ix, scopes)]
    merged = True
    while merged:
        merged = False
        for i in range(len(sets)):
            for j in range(i + 1, len(sets)):
                if len(sets[i] & sets[j]) >= 2:
                    sets[i] |= sets.pop(j)
                    merged = True
                    break
            if merged:
                break
    return [frozenset(x) for x in sets]


def _line_of(pts, lines):
    """The collinearity closure of a set of points: the stated line that
    holds them all, else the points themselves."""
    pts = frozenset(pts)
    for L in lines:
        if pts <= L:
            return L
    return pts


def _given_points(ix, item, result_pts=()):
    """The points a PUBLIC given the item's reader sees (its question and
    the items up to it) fixes (POINT_FIXED_BY). Such a point is data, not a
    step of a construction (verifier semantics r2, SR2-02: 'M אמצע BC'
    given, printed and drawn, then 'בנו את התיכון AM' -- drawing M is
    drawing the given). close_gaps (verifier semantics r3): a degenerate
    given fixes nothing (SV3-01: 'H על AH', 'H אמצע AH' -- refused by the
    schema as REL_DEGENERATE); two names of one line are one constraint
    (SV3-02: lines by their collinearity closure); and a given whose line
    holds another point of the construction's RESULT is circular -- 'H על
    AD' for the altitude AH puts H on the altitude line itself (SV3-01)."""
    vis = set(ix.visible_scopes(item))
    lines = _collinear_lines(ix, vis)
    own = set(result_pts)
    fixed, ons = set(), {}
    for g, p, pts in _incidences(ix, vis):
        L = _line_of(pts, lines)
        if (own - set([p])) & L:
            continue                    # circular: the result's own line
        if g["rel"] == "midpoint":
            fixed.add(p)
        else:
            ons.setdefault(p, set()).add(L)
    fixed |= set(p for p, ls in ons.items()
                 if len(ls) >= POINT_FIXED_BY["on_segment"])
    return fixed


def _defining_points(eid, ix):
    """The points that fix a result: a segment's ends, a line's / ray's
    two points, a polygon's vertices, a point itself."""
    e = ix.entities.get(eid) or {}
    k = e.get("kind")
    if k == "point":
        return [eid]
    if k == "segment":
        return list(e.get("ends") or [])
    if k == "line":
        return list(e.get("through") or [])
    if k == "ray":
        return [e.get("from"), e.get("through")]
    if k == "polygon":
        return list(e.get("vertices") or [])
    return []


def construct_drawn_issues(ix, tset):
    """A construction's answer is already DRAWN on the page of its
    question. What the construction makes comes from the DECLARATION of its
    templates (templates.construct_decl), never from the wording:
      result    -- the new object (arg 0): drawn = CONSTRUCT_ALREADY_DRAWN;
                   also (close_gaps SV3-03) when a figure draws a piece of
                   the result's LINE -- the result's points and every point
                   the public givens put on that line (collinearity
                   closure): the altitude AH inside a drawn AD with 'H על
                   AD', the median AM drawn as AD + DM with 'D על AM', the
                   bisector's ray AD inside a drawn AQ with 'D על AQ';
                   and (SV3-05) for a LOCATE construction without a new
                   point (construct_segment / line / ray / point /
                   triangle) when every defining point is drawn: they fix
                   it (PQ = 5 cm with P and Q drawn 5 cm apart is the
                   answer). To join points the page gives, the task says so
                   (construct_join, mode 'join');
      join      -- (mode 'join') every defining point must be SHOWN in the
                   figure the item's reader sees (the item's or its
                   question's): CONSTRUCT_JOIN_UNSHOWN otherwise -- 'join
                   the given points' is checked against the drawing;
      new point -- for a construction that declares new_point (altitude,
                   median, bisector, midpoint, perpendicular, parallel):
                   every point of the result that is not a point of the
                   base -- the foot H, the median's M, the bisector's D --
                   is the construction's essential step; drawn =
                   CONSTRUCT_STEP_DRAWN (verifier semantics r1, V5), unless
                   a public given fixes it (_given_points). To join two
                   points that are GIVEN, use construct_join;
      base      -- the objects it is built on: may (and usually must) be
                   drawn.
    The page is the WHOLE question: its figure and every item's figure,
    earlier or LATER, and any figure the item / its question names
    (verifier semantics r1, V4: a later item's figure showed the answer of
    an earlier construction on the same printed page; the same rule as a
    later item's given that leaks a target, R3-03). Every to_construct is
    checked, whatever its item's task_type (a to_construct outside a
    construct item is refused by the schema). A sketch (schematic) counts
    too. V4, V5 and the locate/join rule are fixer decisions awaiting the
    author."""
    from . import templates as TT
    out = []
    for f in sorted(ix.facts.values(), key=lambda f: str(f.get("id"))):
        if f.get("role") != "to_construct":
            continue
        decl = TT.construct_decl(tset, f.get("rel"))
        args = f.get("args") or []
        if decl is None or decl[0] >= len(args) or \
                any(b >= len(args) for b in decl[1]):
            # no template prints it (STATED_NOT_PRINTED), or its arity is
            # wrong (REL_ARG_KIND): nothing to read the result from
            continue
        result = args[decl[0]]
        mode = decl[3]
        base_pts = set()
        for b in decl[1]:
            base_pts |= _points_in(args[b], ix)
        if decl[2] and not (_points_in(result, ix) - base_pts):
            # (verifier semantics r2, SR2-04: the foot H named inside the
            # base line BH escaped the step check; PQ ∥ BQ through P shares
            # Q with its base and cannot exist) -- a construction that
            # DECLARES a new point must have one outside its base
            out.append(Issue("CONSTRUCT_NEW_POINT_IN_BASE", f["id"],
                             "every point of the result %s is a point of "
                             "its base %s" % (result, ", ".join(
                                 args[b] for b in decl[1]))))
        rpts = _points_in(result, ix)
        given = _given_points(ix, f.get("item"), rpts)
        new_pts = sorted(p for p in rpts - base_pts
                         if p != result and p not in given) \
            if decl[2] else []
        it = ix.items.get(f.get("item")) or {}
        qid = ix.scope_question.get(f.get("item"))
        q = ix.questions.get(qid) or {}
        page = set(sc for sc, qq in ix.scope_question.items() if qq == qid)
        named = set([it.get("figure"), q.get("figure")]) - set([None])
        # the result's line, by the public givens of the whole page
        linear = ix.kind(result) in ("segment", "line", "ray")
        line = _line_of(_defining_points(result, ix),
                        _collinear_lines(ix, page)) if linear else None
        for gid in sorted(ix.figures):
            g = ix.figures[gid]
            if g.get("scope") not in page and gid not in named:
                continue
            shown = _figure_shows(g, ix)
            implied = mode == "locate" and not decl[2] and all(
                _object_drawn(p, shown, ix)
                for p in _defining_points(result, ix))
            on_line = sorted("".join(sorted(pr)) for x in shown
                             for pr in _drawn_pairs(ix.entities.get(x) or {})
                             if linear and len(line) > 2 and pr <= line)
            if _object_drawn(result, shown, ix):
                out.append(Issue("CONSTRUCT_ALREADY_DRAWN", f["id"],
                                 "the result %s is drawn in figure %s"
                                 % (result, gid)))
            elif on_line:
                out.append(Issue("CONSTRUCT_ALREADY_DRAWN", f["id"],
                                 "figure %s draws %s on the line of the "
                                 "result %s (the givens put %s on it)" % (
                                     gid, ", ".join(sorted(set(on_line))),
                                     result, ", ".join(sorted(line)))))
            elif implied:
                out.append(Issue("CONSTRUCT_ALREADY_DRAWN", f["id"],
                                 "every point of the result %s is drawn in "
                                 "figure %s (they fix it; to join given "
                                 "points the task is construct_join)"
                                 % (result, gid)))
            for p in new_pts:
                if _object_drawn(p, shown, ix):
                    out.append(Issue("CONSTRUCT_STEP_DRAWN", f["id"],
                                     "the new point %s of %s is drawn in "
                                     "figure %s" % (p, result, gid)))
        if mode == "join":
            seen = set()
            for gid in named:
                if gid in ix.figures:
                    seen |= _figure_shows(ix.figures[gid], ix)
            miss = [p for p in _defining_points(result, ix)
                    if not _object_drawn(p, seen, ix)]
            if miss:
                out.append(Issue("CONSTRUCT_JOIN_UNSHOWN", f["id"],
                                 "join %s: point(s) %s are not shown in the "
                                 "figure the item's reader sees (%s)" % (
                                     result, ", ".join(miss), ", ".join(
                                         sorted(named)) or "none")))
    return out
