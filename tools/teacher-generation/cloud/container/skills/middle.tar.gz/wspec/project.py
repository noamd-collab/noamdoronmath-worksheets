# -*- coding: utf-8 -*-
"""Public / private split (C2, C3).

A fact is PUBLIC only when BOTH hold:
  (a) eligible: an allowed role with a verified source --
        given    + stated (printed by a generated text), or
        given/derived + derived AND an explicit reviewed release,
        context  + context (closed kind list),
        target / to_prove / to_construct + stated: the DESCRIPTION only;
      an answer is never eligible; a target's value never exists publicly.
  (b) needed: printed by a generated text, drawn by a figure, or named by
      an item's `uses` (the allowed Noam-AI actions: show / highlight).
"Used by the drawing" alone is not (a): a figure that draws an answer is
refused (FIGURE_DRAWS_PRIVATE), never licensed. The same holds for an
ENTITY that carries a value (a number, a tick): listing it in a figure is
no licence -- it is public only together with the public fact that states
its value (ENTITY_VALUE_UNLICENSED).

The public model is CONSTRUCTED from a whitelist (never copy-then-delete):
unknown or private fields cannot reach it."""
import hashlib
import re

from . import canon
from . import schema as S
from . import templates as T
from . import schema_bound as SB
from . import base_height as BH
from .errors import Issue, SpecError

PUBLIC_ROLES = ("given", "context", "derived", "target", "to_prove",
                "to_construct", "to_plot")
VALUE_ROLES = ("given", "context", "derived", "to_prove")
USE_ROLES = ("given", "context", "derived")
# entity kind -> (the field that carries its value, the (rel, context kind)
# of the one public fact that may state that value, or None = no fact can:
# a free number has no licensing relation in stage 1)
# (v6.12) a number is stated by a 'mark' context (the number line prints
# it) or, through number_licence, by a printed family fact that names it
VALUE_ENTITIES = {"number": ("value", ("mark", "number_mark")),
                  "tick": ("at", ("tick", "axis_tick"))}
# (v6.12) roles of a printed (stated) family fact that states the numbers
# it names ("סמנו את המספר −0.5", "מה המרחק בין −3 ל־5?")
NUMBER_STATING_ROLES = ("given", "target", "to_prove", "to_plot")


def _licence_ok(f, eid, spec_):
    if not spec_ or not spec_[1]:
        return False
    rel, ck = spec_[1]
    return (f.get("rel") == rel and list(f.get("args") or []) == [eid] and
            f.get("role") == "context" and
            (f.get("source") or {}).get("context_kind") == ck)


def licensing_facts(eid, ix, among):
    """The facts among `among` (ids) that state value-entity eid's value."""
    k = ix.kind(eid)
    return [fid for fid in among if fid in ix.facts and
            (_licence_ok(ix.facts[fid], eid, VALUE_ENTITIES.get(k)) or
             (k == "number" and _number_stated(ix.facts[fid], eid, ix)))]


def _number_stated(f, eid, ix):
    """(v6.12) a printed family fact states every number it is built on:
    its arguments and what they reference (a jump from −2)."""
    if f.get("rel") not in S.FAMILY_RELS or \
            (f.get("source") or {}).get("kind") != "stated" or \
            f.get("role") not in NUMBER_STATING_ROLES:
        return False
    return any(eid in S.entity_closure(a, ix) for a in f.get("args") or [])


def bound_licensed(eid, ix, rendered, qid=None):
    """(v6.13, W-BOUND-PROSE) a value-carrying entity (a number, a tick) a
    printed bound block names by its value (schema_bound checked the
    printed number IS the entity's value): the text states it. qid: only
    blocks of that question count (a figure of the question)."""
    for sc, ents in (getattr(rendered, "bound_entities", None) or
                     {}).items():
        if eid in ents and (qid is None or
                            ix.scope_question.get(sc) == qid):
            return True
    return False


def released(f, ix, _depth=0):
    """An explicit, reviewed, current release of a derived fact whose
    sources carry no private value."""
    if (f.get("source") or {}).get("kind") != "derived":
        return False
    if f.get("role") not in ("given", "derived"):
        return False
    r = ix.releases.get(f.get("id"))
    if not r:
        return False
    if release_problem(r, f, ix):
        return False
    if r.get("fact_hash") != canon.fact_hash(f):
        return False
    return not private_sources(f, ix, _depth)


# an approval's time, ISO 8601 with its offset (close_gaps: an approval
# records WHO approved WHAT (the fact's hash) and WHEN)
TIMESTAMP_RE = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2})?"
                          r"(?:Z|[+-]\d{2}:\d{2})\Z")


def release_problem(r, f, ix):
    """(code, why) when release r of fact f has no valid BASIS, else None
    (close_gaps, brief section 1: never show a human approval that did not
    happen). Two bases, never mixed:
      from_item -- PROVENANCE, not an approval: f is the claim an EARLIER
                   item of the same question proved (a to_prove there with
                   the same relation, arguments and value, named in f's
                   source), so its statement is already public. Checked
                   mechanically; it carries no reviewer (a reviewer on it
                   would present the import as a human review:
                   RELEASE_FAKE_APPROVAL);
      approval  -- a person's approval: reviewer + timestamp (ISO 8601) +
                   the fact's hash (fact_hash, RELEASE_STALE when the fact
                   changed), as recorded in an approvals file
                   (author.load_approvals)."""
    if not (isinstance(r.get("reason"), str) and r["reason"].strip()):
        return ("RELEASE_UNREVIEWED", "no reason")
    basis = r.get("basis")
    if basis == "from_item":
        if "reviewer" in r or "timestamp" in r:
            return ("RELEASE_FAKE_APPROVAL", "a from_item provenance record "
                    "carries a reviewer / timestamp")
        it = r.get("from_item")
        if it not in ix.items or ix.scope_question.get(it) != \
                ix.scope_question.get(f.get("item")) or \
                not ix.scope_key[it] < ix.scope_key.get(f.get("item"),
                                                         (0, 0)):
            return ("RELEASE_PROVENANCE_BAD", "%r is not an earlier item of "
                    "the question of %s" % (it, f.get("id")))
        for x in (f.get("source") or {}).get("from") or []:
            g = ix.facts.get(x) or {}
            # (v6.10 fix r1, L1) ... or the GIVEN an earlier item stated
            # ("נתון גם: ∠OAB = 20°" in item ג, used again in item ד): a
            # stated given of that item is public already -- carried, not
            # re-printed; f is a given of the later item
            if g.get("item") == it and (
                    g.get("role") == "to_prove" or
                    (g.get("role") == "given" and f.get("role") == "given"
                     and (g.get("source") or {}).get("kind") == "stated")) \
                    and g.get("rel") == f.get("rel") and \
                    canon.fact_key_args(g) == canon.fact_key_args(f) and \
                    _same_value(g, f):
                return None
        return ("RELEASE_PROVENANCE_BAD", "%s is not the claim a to_prove of "
                "%s states (named in its source)" % (f.get("id"), it))
    if basis == "approval":
        if "from_item" in r:
            return ("RELEASE_UNREVIEWED", "an approval names no from_item")
        if not (isinstance(r.get("reviewer"), str) and r["reviewer"].strip()):
            return ("RELEASE_UNREVIEWED", "no reviewer")
        if not (isinstance(r.get("timestamp"), str) and
                TIMESTAMP_RE.match(r["timestamp"])):
            return ("RELEASE_UNREVIEWED", "no ISO 8601 timestamp")
        return None
    return ("RELEASE_UNREVIEWED", "basis %r is neither from_item nor "
            "approval" % (basis,))


def _same_value(g, f):
    if g.get("value") is None or f.get("value") is None:
        return g.get("value") is None and f.get("value") is None
    try:
        return canon.same_quantity(g["value"], g.get("unit"), f["value"],
                                   f.get("unit"))
    except Exception:                   # noqa: BLE001
        return False


def private_sources(f, ix, _depth=0):
    """The `from` facts through which f would carry private information."""
    bad = []
    for x in (f.get("source") or {}).get("from") or []:
        g = ix.facts.get(x)
        if g is None:
            continue
        if g.get("role") == "answer":
            bad.append(x)
        elif g.get("role") == "target" and f.get("value") is not None:
            bad.append(x)          # a target's value is its (private) answer
        elif (g.get("source") or {}).get("kind") == "derived" and \
                g.get("role") != "answer" and \
                (_depth > 8 or not released(g, ix, _depth + 1)):
            bad.append(x)
    return bad


def eligible(f, ix):
    role = f.get("role")
    kind = (f.get("source") or {}).get("kind")
    if role not in PUBLIC_ROLES:
        return False
    if role in S.TARGET_ROLES:
        return kind == "stated"
    if role == "context":
        return kind == "context" and \
            (f.get("source") or {}).get("context_kind") in S.CONTEXT_KINDS
    if kind == "stated":
        return role == "given"
    if kind == "derived":
        return released(f, ix)
    return False


def needs(spec, ix, rendered):
    need = set(rendered.printed)
    for g in spec.get("figures") or []:
        need.update(g.get("draws") or [])
    for q in spec.get("questions") or []:
        for it in q.get("items") or []:
            need.update(it.get("uses") or [])
    return need


def check_public(spec, ix, rendered, out):
    """C3 checks, appended to `out`."""
    for g in spec.get("figures") or []:
        vis = set(ix.visible_scopes(g.get("scope")))
        for d in g.get("draws") or []:
            f = ix.facts.get(d)
            if f is None:
                continue
            if not eligible(f, ix):
                out.append(Issue("FIGURE_DRAWS_PRIVATE", "figure %s" %
                                 g.get("id"), "%s (%s)" % (d, f.get("role"))))
            elif f.get("item") not in vis:
                out.append(Issue("FIGURE_DRAWS_PRIVATE", "figure %s" %
                                 g.get("id"), "%s not visible here" % d))
    for q in spec.get("questions") or []:
        for it in q.get("items") or []:
            vis = set(ix.visible_scopes(it.get("id")))
            for u in it.get("uses") or []:
                f = ix.facts.get(u)
                if f is None:
                    continue
                if not eligible(f, ix) or f.get("role") not in USE_ROLES:
                    out.append(Issue("USES_PRIVATE", "item %s" % it.get("id"),
                                     "%s (%s)" % (u, f.get("role"))))
                elif f.get("item") not in vis:
                    out.append(Issue("USES_PRIVATE", "item %s" % it.get("id"),
                                     "%s not visible here" % u))
    for f in ix.facts.values():
        if (f.get("source") or {}).get("kind") == "derived" and \
                f.get("id") in ix.releases:
            bad = private_sources(f, ix)
            if bad:
                out.append(Issue("DERIVED_FROM_PRIVATE", f.get("id"),
                                 ",".join(bad)))
    need = needs(spec, ix, rendered)
    for f in ix.facts.values():
        if eligible(f, ix) and f.get("id") not in need:
            out.append(Issue("UNNEEDED_PUBLIC", f.get("id"),
                             "not printed, drawn or used"))
    # value-carrying entities (V11): a figure that lists one must draw the
    # public fact stating its value; a public fact naming one must be (or
    # sit beside) that fact.
    pub = set(f["id"] for f in ix.facts.values()
              if eligible(f, ix) and f.get("id") in need)
    stated_pub = [x for x in pub if (ix.facts[x].get("source") or {}).get(
        "kind") == "stated"]
    for g in spec.get("figures") or []:
        drawn = [d for d in g.get("draws") or [] if d in pub]
        # (v6.12) a number the text prints may be shown (a dot at −2 when
        # the item says "from −2"); a printed family fact licenses it
        qid = ix.scope_question.get(g.get("scope"))
        drawn += [x for x in stated_pub
                  if ix.scope_question.get(ix.facts[x].get("item")) == qid
                  and ix.facts[x].get("rel") in S.FAMILY_RELS]
        for e in g.get("entities") or []:
            if ix.kind(e) in VALUE_ENTITIES and \
                    not licensing_facts(e, ix, drawn) and \
                    not bound_licensed(e, ix, rendered, qid):
                out.append(Issue("ENTITY_VALUE_UNLICENSED", "figure %s" %
                                 g.get("id"), "%s drawn without the fact "
                                 "stating its value" % e))
    for fid in sorted(pub):
        for a in ix.facts[fid].get("args") or []:
            if ix.kind(a) in VALUE_ENTITIES and \
                    not licensing_facts(a, ix, pub) and \
                    not bound_licensed(a, ix, rendered):
                out.append(Issue("ENTITY_VALUE_UNLICENSED", fid,
                                 "%s is public without the fact stating "
                                 "its value" % a))


# ---------------------------------------------------------- public model ---
# point lists whose written order carries no meaning (verifier r3, R3-02):
# they are normalised by the SAME rule the entity id uses, so the public
# model (and public_hash) does not depend on how the author wrote them.
#   segment/arc ends, line through, angle arms -> sorted;
#   polygon vertices -> canon_cycle (rotation + reflection).
# A ray is ordered (from, through are separate fields); nothing to do.
UNORDERED_POINT_LISTS = ("ends", "through", "arms")


def _pub_entity(e):
    k = e["kind"]
    keep = ["id", "kind"] + list(S.ENTITY_KINDS[k]) + \
        list(S.ENTITY_OPTIONAL.get(k, ()))
    out = {}
    for f in keep:
        if f in e:
            v = e[f]
            out[f] = list(v) if isinstance(v, list) else v
    for f in UNORDERED_POINT_LISTS:
        if isinstance(out.get(f), list):
            out[f] = sorted(canon.nfc(p) for p in out[f])
    if isinstance(out.get("vertices"), list):
        out["vertices"] = canon.canon_cycle([canon.nfc(p)
                                             for p in out["vertices"]])
    for f in ("value", "at"):
        if f in out:
            out[f] = canon.canon_number(out[f])
    return out


def _pub_fact(f):
    src = f["source"]
    out = {"id": f["id"], "rel": f["rel"], "args": list(f["args"]),
           "role": f["role"], "item": f["item"],
           "source": {"kind": src["kind"]}}
    if src["kind"] == "context":
        out["source"]["context_kind"] = src["context_kind"]
    if src["kind"] == "derived":
        out["source"]["rule"] = src["rule"]
        out["source"]["from"] = sorted(src["from"])
    if f.get("display") is not None:
        out["display"] = list(f["display"])
    if f.get("form") is not None and f["role"] in VALUE_ROLES and \
            f.get("value") is not None:
        out["form"] = f["form"]                 # (v6.12) printed form
    if f.get("coef") is not None and f["role"] in VALUE_ROLES:
        # (v6.10) a linear relation's coefficients are its statement
        out["coef"] = [canon.canon_number(c) for c in f["coef"]]
    if f["role"] in VALUE_ROLES and f.get("value") is not None:
        out["value"] = canon.canon_number(f["value"])
        u = canon.canon_unit(f.get("unit"))
        if u:
            out["unit"] = u
    return out


def _given_lines(scope, pub_ids, ix, tset, rendered):
    """Given-list lines of a scope: printed facts in print order, then the
    other public givens (released derived) in id order."""
    facts = [f for f in ix.facts_in(scope)
             if f["id"] in pub_ids and f["role"] in ("given", "derived")]
    order = list(rendered.printed)
    facts.sort(key=lambda f: (0, order.index(f["id"])) if f["id"] in order
               else (1, f["id"]))
    # two facts may print the same line (on_segment(O, AC) and
    # on_segment(O, BD) both read "the diagonals meet at O"): the student
    # sees it once (fix_engine M2); the facts stay separate in the model
    out = []
    for f in facts:
        from . import base_height as BH
        line = BH.description(f, ix) or T.fact_line(tset, f, ix)
        if line not in out:
            out.append(line)
    return out


def _build(spec, tset, mode=None):
    ix = S.Index(spec)
    sink = []
    rendered = T.render_spec(spec, tset, ix, sink, mode=mode)
    if sink:
        raise SpecError(sink)
    need = needs(spec, ix, rendered)
    pub_facts = [f for f in ix.facts.values()
                 if eligible(f, ix) and f["id"] in need]
    pub_ids = set(f["id"] for f in pub_facts)
    return ix, rendered, pub_facts, pub_ids


def public_model(spec, templates=None, check=True, mode=None):
    """The public model: everything needed to present the exercise, no
    solution information beyond that. mode (v6.10 fix r1): the text form
    -- None = the tex form (the engine's own), 'sheet' = the worksheet's
    (one math island per datum), which a printed level uses so its public
    texts are the printed ones."""
    from . import printed_claims as PC
    import copy
    tset = templates or T.load_templates()
    if check:
        issues = S.validate(spec, tset)
        if issues:
            raise SpecError(issues)
    ix, rendered, pub_facts, pub_ids = _build(spec, tset, mode)

    def shown(eid, among, qid=None):
        # a value-carrying entity only beside the fact stating its value
        # (v6.13: or named by its value in a printed bound block)
        return ix.kind(eid) not in VALUE_ENTITIES or \
            bool(licensing_facts(eid, ix, among)) or \
            bound_licensed(eid, ix, rendered, qid)
    ents = set()
    for f in pub_facts:
        ents.update(a for a in f["args"] if shown(a, pub_ids))
    # (v6.13, W-BOUND-PROSE) what printed bound blocks name
    for _sc, bents in sorted(rendered.bound_entities.items()):
        ents.update(bents)
    # (v6.10) an unnamed construction a text mentions ("העבירו דרך P ישר
    # מקביל ל־AD") is public by its id, so Noam AI can refer to it; only
    # clines are added this way (a named entity is public through facts)
    from . import language as LANG
    for q in spec["questions"]:
        for sc in [q] + list(q.get("items") or []):
            ents.update(e for e in LANG.text_entities(sc)
                        if ix.kind(e) == "cline")
    figs = []
    for g in spec.get("figures") or []:
        draws = sorted(d for d in g.get("draws") or [] if d in pub_ids)
        # (v6.12) as check_public: a printed family fact of the figure's
        # question licenses the numbers it names
        qid = ix.scope_question.get(g["scope"])
        lic = draws + [x for x in sorted(pub_ids)
                       if ix.facts[x].get("rel") in S.FAMILY_RELS and
                       (ix.facts[x].get("source") or {}).get("kind") ==
                       "stated" and
                       ix.scope_question.get(ix.facts[x].get("item")) == qid]
        fents = sorted(e for e in g.get("entities") or []
                       if shown(e, lic, qid))
        ents.update(fents)
        pg = {"id": g["id"], "scope": g["scope"],
              "figure_accuracy": g["figure_accuracy"],
              "entities": fents, "draws": draws}
        if "base_height" in g:
            pg["base_height"] = dict(g["base_height"], source=dict(g["base_height"]["source"]))
        if g.get("frame") is not None:
            # (v6.12) what the figure PRINTS of its frame, never min /
            # max / step (family.public_frame)
            from . import family as FAM
            pg["frame"] = FAM.public_frame(g["frame"])
        if "graph" in g:
            # (v6.16 integrate) the PUBLIC graph model (no answer, no
            # number of an asked curve / mark): wspec/sheet_graph.py
            from . import sheet_graph as SGR
            pg["graph"] = SGR.public_graph(g)
        if "inherit_givens" in g:
            pg["inherit_givens"] = list(g["inherit_givens"])
        if "state_change" in g:
            pg["state_change"] = dict(g["state_change"], source=dict(g["state_change"]["source"]))
        if "data" in g:
            from . import sheet_data as SDA
            pg["data"] = SDA.public_data(g)
        if "loci" in g:
            from . import sheet_locus as SLO
            pg["loci"] = SLO.public_loci(g)
        figs.append(pg)
    # entities referenced by other entities (a segment's points, ...)
    changed = True
    while changed:
        changed = False
        for eid in list(ents):
            e = ix.entities.get(eid) or {}
            for fld in S.ENTITY_REFS.get(e.get("kind"), ()):
                v = e.get(fld)
                for r in (v if isinstance(v, list) else [v]):
                    if r not in ents:
                        ents.add(r)
                        changed = True
    questions = []
    for q in spec["questions"]:
        items = []
        for it in q["items"]:
            targets = []
            for tid in sorted(it["targets"]):
                f = ix.facts[tid]
                targets.append({"id": f["id"], "rel": f["rel"],
                                "args": list(f["args"]), "role": f["role"],
                                "description": BH.description(f, ix) or T.fact_line(tset, f, ix)})
            item = {"id": it["id"], "label": it["label"],
                    "task_type": it["task_type"],
                    "measurement_allowed": bool(it["measurement_allowed"]),
                    "text": rendered.texts[it["id"]],
                    "given_lines": _given_lines(it["id"], pub_ids, ix, tset,
                                                rendered),
                    "targets": targets,
                    "uses": sorted(u for u in it.get("uses") or []
                                   if u in pub_ids)}
            if it.get("figure") is not None:
                item["figure"] = it["figure"]
            if "transforms" in it:
                item["transforms"] = copy.deepcopy(it["transforms"])
            bl = SB.public_blocks(spec, it["id"])
            if bl:
                item["bound"] = bl
            item["given_lines"] += [PC.line(c, "given") for c in
                                    PC.rows(q, it["id"], "given")
                                    if PC.line(c, "given") not in item["given_lines"]]
            descriptions = PC.construction_lines(q, it["id"])
            for target in targets:
                if target.get("role") in ("to_plot", "to_construct"):
                    eid = (target.get("args") or [None])[0]
                    ent = ix.entities.get(eid) or {}
                    name = ":".join(ent["vertices"]) if ent.get("kind") == "polygon" else ent.get("name") or eid
                    if eid in descriptions:
                        target["description"] = descriptions[eid]
                    elif name in descriptions:
                        target["description"] = descriptions[name]
            items.append(item)
        qq = {"id": q["id"], "n": q["n"], "text": rendered.texts[q["id"]],
              "given_lines": _given_lines(q["id"], pub_ids, ix, tset,
                                          rendered),
              "items": items}
        if q.get("figure") is not None:
            qq["figure"] = q["figure"]
        if q.get("star"):
            qq["star"] = True
        # (v6.13, W-BOUND-PROSE) the table as data, the worked example,
        # and the binding table of every bound block (only when present:
        # a spec without them keeps its public model and hash)
        if q["id"] in rendered.tables:
            t = rendered.tables[q["id"]]
            qq["table"] = dict([("rows", [list(r) for r in t["rows"]])] + (
                [("head", list(t["head"]))] if "head" in t else []))
        if q["id"] in rendered.examples:
            ti, lines = rendered.examples[q["id"]]
            qq["example"] = {"title": ti, "lines": list(lines)}
        bl = SB.public_blocks(spec, q["id"])
        if bl:
            qq["bound"] = bl
        if "printed_claims" in q:
            qq["printed_claims"] = copy.deepcopy(q["printed_claims"])
            qq["given_lines"] += [PC.line(c, "given") for c in
                                  PC.rows(q, q["id"], "given")
                                  if PC.line(c, "given") not in qq["given_lines"]]
        questions.append(qq)
    pub = {"spec_version": spec["spec_version"],
           "sheet": spec["sheet"] if isinstance(spec.get("sheet"), str) and
           S.SHEET_RE.match(spec["sheet"]) else None,
           "entities": sorted((_pub_entity(ix.entities[e]) for e in ents
                               if e in ix.entities), key=lambda e: e["id"]),
           "facts": sorted((_pub_fact(f) for f in pub_facts),
                           key=lambda f: f["id"]),
           "questions": questions,
           "figures": sorted(figs, key=lambda g: g["id"])}
    pub["public_hash"] = hashlib.sha256(
        canon.dumps(pub).encode("utf-8")).hexdigest()
    bad = scan_public(pub)
    if bad:
        raise SpecError(bad)
    return pub


# the ONLY keys the public model may hold, per level
PUBLIC_KEYS = {
    "top": {"spec_version", "sheet", "entities", "facts", "questions",
            "figures", "public_hash"},
    "entity": {"id", "kind", "name", "ends", "through", "from", "vertex",
               "arms", "vertices", "center", "circle", "value", "axis", "at",
               "table", "row", "col", "op", "base",
               "to", "lo", "hi", "lo_in", "hi_in", "form",         # v6.12
               "of", "n", "tag",           # v6.16 gaps: unnamed vertices (G5)
               "key", "pie"},              # v6.16 integrate: a pie's sector
    "fact": {"id", "rel", "args", "role", "item", "source", "display",
             "value", "unit", "coef", "form"},
    "source": {"kind", "context_kind", "rule", "from"},
    "question": {"id", "n", "text", "given_lines", "items", "figure", "star",
                 "table", "example", "bound", "printed_claims"},
    "item": {"id", "label", "task_type", "measurement_allowed", "text",
             "given_lines", "targets", "uses", "figure", "bound", "transforms"},
    # (v6.13, W-BOUND-PROSE) a bound block, one binding, a table (data),
    # a worked example
    "bound": {"at", "text", "bind", "prints"},
    "bind": {"tok", "fact", "entity", "count", "enum", "question",
             "intervals",                                   # v6.13 fix_r1
             "calc",                                        # v6.13 fix_r2
             "graph", "pie"},                           # v6.16 integrate
    "table": {"head", "rows"},
    "example": {"title", "lines"},
    "target": {"id", "rel", "args", "role", "description"},
    "figure": {"id", "scope", "figure_accuracy", "entities", "draws",
               "frame",
               "graph", "data", "loci", "base_height", "inherit_givens", "state_change"},
    # (v6.12) the printed frame of a family figure; (v6.16 integrate) a pie
    # chart's frame (wspec/pie.py public_frame: every key is printed data)
    "frame": {"family", "plane", "grid", "axes",
              "layout", "parts", "same_size", "shared_legend",
              "sketch"},                     # v6.16 gaps r3 (F1 sketch plane)
    "frame_axis": {"axis", "intervals", "labels", "form", "break_before"},
    # (v6.16 gaps r3) a sketch plane: tick indices only (family.public_sketch)
    "frame_sketch": {"origin", "places"},
}


# a display is a run of point names (canon.NAME_RE without anchors)
_DISPLAY_RE = re.compile(r"^(?:[A-Z][1-9]?'{0,3})+\Z")


def _scan_values(pub, out):
    """Every public VALUE inside its grammar: no free string, no value that
    no public fact states (V10, V11)."""
    def bad(where, what):
        out.append(Issue("PUBLIC_VALUE_NOT_WHITELISTED", where, what))
    sheet = pub.get("sheet")
    if not (isinstance(sheet, str) and S.SHEET_RE.match(sheet)):
        bad("public.sheet", "not a sheet id: %r" % (sheet,))
    facts = pub.get("facts", [])
    ents = dict((e.get("id"), e) for e in pub.get("entities", []))
    # (v6.13) value entities a public bound block names by its value
    bound_vals = set()
    for q in pub.get("questions", []):
        for sc in [q] + list(q.get("items") or []):
            for b in sc.get("bound") or []:
                for x in b.get("bind") or []:
                    if isinstance(x.get("entity"), str):
                        bound_vals.add(x["entity"])
    for e in pub.get("entities", []):
        k = e.get("kind")
        if k not in S.ENTITY_KINDS or e.get("id") != canon.entity_id(e):
            bad("entity %s" % e.get("id"), "kind/id")
            continue
        for fld, rx in S.ENTITY_NAME_RULES.get(k, {}).items():
            if fld in e and not (isinstance(e[fld], str) and
                                 rx.match(e[fld])):
                bad("entity %s" % e.get("id"), "%s %r" % (fld, e[fld]))
        if k == "cline" and (e.get("op") not in S.CLINE_OPS or
                             e.get("through") not in ents or
                             e.get("base") not in ents):
            bad("entity %s" % e.get("id"), "cline op / parts")
        if k in VALUE_ENTITIES:
            fld, lic = VALUE_ENTITIES[k]
            if k == "number":
                # (v6.12) a mark context, or a printed family fact naming
                # it (directly or through a public jump / interval)
                ok = any(_licence_ok(f, e["id"], (fld, lic)) or (
                    f.get("rel") in S.FAMILY_RELS and
                    (f.get("source") or {}).get("kind") == "stated" and
                    f.get("role") in NUMBER_STATING_ROLES and
                    e["id"] in _pub_closure(f.get("args") or [], ents))
                    for f in facts)
            else:
                ok = lic is not None and any(
                    _licence_ok(f, e["id"], (fld, lic)) and
                    f.get("value") == e.get(fld) for f in facts)
            if not ok and e["id"] in bound_vals:
                ok = True                   # (v6.13) a bound block prints it
            if not ok:
                bad("entity %s" % e["id"], "%s %r with no public fact "
                    "stating it" % (fld, e.get(fld)))
    for f in facts:
        w = "fact %s" % f.get("id")
        if f.get("id") != canon.fact_id(f) or f.get("rel") not in S.RELS \
                or f.get("role") not in PUBLIC_ROLES:
            bad(w, "id/rel/role")
        if any(a not in ents for a in f.get("args") or []):
            bad(w, "argument not among the public entities")
        for d in f.get("display") or []:
            if d is not None and not _DISPLAY_RE.match(str(d)):
                bad(w, "display %r" % (d,))
        if "value" in f:
            try:
                ok = canon.canon_number(f["value"]) == f["value"]
            except Exception:           # noqa: BLE001
                ok = False
            if not ok:
                bad(w, "value %r" % (f["value"],))
        if "unit" in f and f["unit"] not in canon.UNITS:
            bad(w, "unit %r" % (f["unit"],))
        if "coef" in f:
            try:
                ok = f.get("rel") == "linear" and all(
                    canon.canon_number(c) == c and
                    canon.parse_exact(c)[2] == 1 for c in f["coef"])
            except Exception:           # noqa: BLE001
                ok = False
            if not ok:
                bad(w, "coef %r" % (f["coef"],))
    fig_ids = set()
    for g in pub.get("figures", []):
        fig_ids.add(g.get("id"))
        if g.get("figure_accuracy") not in S.FIGURE_ACCURACY:
            bad("figure %s" % g.get("id"), "figure_accuracy")
        if "frame" in g:
            _scan_frame(g, ents, bad)
        if any(e not in ents for e in g.get("entities") or []):
            bad("figure %s" % g.get("id"), "entity not public")
    for q in pub.get("questions", []):
        wq = "question %s" % q.get("id")
        if not S.is_count(q.get("n")) or q.get("id") != S.question_id(
                q.get("n")):
            bad(wq, "id/n %r/%r" % (q.get("id"), q.get("n")))
        if q.get("star", True) is not True:
            bad(wq, "star %r" % (q.get("star"),))
        want_figs = [q.get("figure")] if "figure" in q else []
        for pos, it in enumerate(q.get("items", [])):
            wi = "item %s" % it.get("id")
            if it.get("id") != S.item_id(str(q.get("id")), pos) or \
                    it.get("label") != S.item_label(pos):
                bad(wi, "id/label %r/%r" % (it.get("id"), it.get("label")))
            if it.get("task_type") not in S.TASK_TYPES or \
                    not isinstance(it.get("measurement_allowed"), bool):
                bad(wi, "task_type/measurement_allowed")
            if "figure" in it:
                want_figs.append(it["figure"])
        for fg in want_figs:
            if fg not in fig_ids:
                bad(wq, "figure %r not public" % (fg,))
        # (v6.13, W-BOUND-PROSE) every binding names a PUBLIC fact / entity
        fids = dict((f.get("id"), f) for f in facts)
        qids = set(x.get("id") for x in pub.get("questions", []))
        for sc in [q] + list(q.get("items") or []):
            ws = "%s %s" % ("question" if sc is q else "item", sc.get("id"))
            for b in sc.get("bound") or []:
                if not isinstance(b.get("text"), str) or \
                        not isinstance(b.get("at"), str):
                    bad(ws, "bound block text/at")
                for x in b.get("bind") or []:
                    # (v6.13 fix_r1) "fact" may list several facts
                    if "fact" in x and (not SB.bind_facts(x) or any(
                            fx not in fids or "value" not in fids[fx]
                            for fx in SB.bind_facts(x))):
                        bad(ws, "binding %r: no public fact with a value"
                            % (x.get("tok"),))
                    if "entity" in x and x["entity"] not in ents:
                        bad(ws, "binding %r: entity not public"
                            % (x.get("tok"),))
                    if "count" in x and any(e not in ents
                                            for e in x["count"] or []):
                        bad(ws, "binding %r: counted entity not public"
                            % (x.get("tok"),))
                    if "question" in x and x["question"] not in qids:
                        bad(ws, "binding %r: question not public"
                            % (x.get("tok"),))
                    if "intervals" in x and x["intervals"] not in fig_ids:
                        bad(ws, "binding %r: figure not public"
                            % (x.get("tok"),))
                    # (v6.16 integrate) a graph / pie binding names a
                    # public graph figure / a public pie
                    if "graph" in x:
                        from . import sheet_graph as SGR
                        gf = SGR.ref_figure(x["graph"])
                        if gf not in fig_ids or not any(
                                "graph" in gg for gg in pub.get("figures", [])
                                if gg.get("id") == gf):
                            bad(ws, "binding %r: no public graph figure"
                                % (x.get("tok"),))
                    if "pie" in x and str(x["pie"]).split("/")[0] \
                            not in ents:
                        bad(ws, "binding %r: pie not public"
                            % (x.get("tok"),))
                for fid in b.get("prints") or []:
                    if fid not in fids and not any(
                            t.get("id") == fid for it in q.get("items", [])
                            for t in it.get("targets", [])):
                        bad(ws, "bound block prints %r, which is not "
                            "public" % (fid,))


def _pub_closure(args, ents):
    """(v6.12) public entity ids the arguments are built from."""
    from . import schema as S_
    seen, todo = set(), list(args)
    while todo:
        x = todo.pop()
        if x in seen or not isinstance(x, str):
            continue
        seen.add(x)
        e = ents.get(x) or {}
        for fld in S_.ENTITY_REFS.get(e.get("kind"), ()):
            v = e.get(fld)
            todo.extend(v if isinstance(v, list) else [v])
    return seen


def _scan_frame(g, ents, bad):
    """(v6.12) a public frame: the printed labels by tick index only."""
    from . import family as FAM
    w = "figure %s" % g.get("id")
    fr = g["frame"]
    if fr.get("family") == "pie_chart":
        return      # (v6.16 integrate) scanned by sheet_pie.scan_public
    if fr.get("family") not in FAM.FAMILIES:
        bad(w, "frame family %r" % (fr.get("family"),))
        return
    if fr["family"] == "coordinate_plane":
        if fr.get("plane") not in ents or not isinstance(fr.get("grid"),
                                                         bool):
            bad(w, "frame plane / grid")
    elif "plane" in fr or "grid" in fr:
        bad(w, "a number line has no plane / grid")
    axes = fr.get("axes")
    if not isinstance(axes, list) or len(axes) != (
            2 if fr["family"] == "coordinate_plane" else 1):
        bad(w, "frame axes")
        return
    for a in axes:
        n = a.get("intervals")
        if a.get("axis") not in ents or not S.is_count(n) or \
                n > FAM.MAX_INTERVALS:
            bad(w, "frame axis %r" % (a.get("axis"),))
            continue
        if "form" in a and a["form"] not in canon.NUMBER_FORMS:
            bad(w, "frame form %r" % (a["form"],))
        if "break_before" in a:
            labs = a.get("labels") or []
            if a["break_before"] is not True or fr["family"] != "coordinate_plane" or a.get("axis") != "axis:y" or "sketch" in fr or len(labs)<2 or labs[0][0]!=1 or not S.is_count(n) or labs[-1][0]>n:
                bad(w, "invalid explicitly broken y axis")
            else:
                try:
                    if canon.parse_exact(labs[0][1])[0]<=0: bad(w,"broken start must be positive")
                except Exception: bad(w,"unreadable broken start")
        last = -1
        for lab in a.get("labels") or []:
            try:
                ok = (isinstance(lab, list) and len(lab) == 2 and
                      isinstance(lab[0], int) and
                      not isinstance(lab[0], bool) and
                      last < lab[0] <= n and
                      canon.canon_number(lab[1]) == lab[1] and
                      canon.parse_exact(lab[1])[2] == 1)
            except Exception:           # noqa: BLE001
                ok = False
            if not ok:
                bad(w, "frame label %r" % (lab,))
                break
            last = lab[0]
    if "sketch" in fr:
        _scan_sketch(fr, axes, ents, w, bad)          # v6.16 gaps r3


def _scan_sketch(fr, axes, ents, w, bad):
    """(v6.16 gaps r3, F1) a public sketch: the origin's tick index per axis
    and every place in tick indices -- no number printed on any axis."""
    sk = fr.get("sketch")
    if fr.get("family") != "coordinate_plane" or not isinstance(sk, dict):
        bad(w, "frame sketch")
        return
    if any(a.get("labels") for a in axes) or any("form" in a for a in axes):
        bad(w, "a sketch plane prints no number")
    org = sk.get("origin")
    if not (isinstance(org, list) and len(org) == 2 and all(
            isinstance(i, int) and not isinstance(i, bool) and
            0 <= i <= a.get("intervals", -1) for i, a in zip(org, axes))):
        bad(w, "frame sketch origin %r" % (org,))
    pl = sk.get("places")
    if not isinstance(pl, dict):
        bad(w, "frame sketch places")
        return
    for p, xy in sorted(pl.items()):
        try:
            ok = (p in ents and isinstance(xy, list) and len(xy) == 2 and
                  all(canon.canon_number(c) == c and
                      canon.parse_exact(c)[2] == 1 and
                      0 <= canon.parse_exact(c)[0] <= a.get("intervals", -1)
                      for c, a in zip(xy, axes)))
        except Exception:               # noqa: BLE001
            ok = False
        if not ok:
            bad(w, "frame sketch place %r %r" % (p, xy))


def scan_public(pub):
    """Independent leak scan of a built public model: every key on the
    whitelist; every value inside its grammar; no answer fact; no value on
    a target."""
    out = []

    def keys(obj, level, where):
        for k in obj:
            if k not in PUBLIC_KEYS[level]:
                out.append(Issue("PUBLIC_KEY_NOT_WHITELISTED", where, k))
    keys(pub, "top", "public")
    for e in pub.get("entities", []):
        keys(e, "entity", "entity %s" % e.get("id"))
    for f in pub.get("facts", []):
        keys(f, "fact", "fact %s" % f.get("id"))
        keys(f.get("source", {}), "source", "fact %s" % f.get("id"))
        if f.get("role") == "answer" or f.get("id", "").endswith("#a"):
            out.append(Issue("PUBLIC_KEY_NOT_WHITELISTED", f.get("id"),
                             "answer in public"))
        if f.get("role") == "target" and "value" in f:
            out.append(Issue("PUBLIC_KEY_NOT_WHITELISTED", f.get("id"),
                             "target value in public"))
    def bound_keys(sc, where):
        for b in sc.get("bound") or []:
            keys(b, "bound", where + " bound")
            for x in b.get("bind") or []:
                keys(x, "bind", where + " bind")
    for q in pub.get("questions", []):
        keys(q, "question", "question %s" % q.get("id"))
        bound_keys(q, "question %s" % q.get("id"))
        if isinstance(q.get("table"), dict):
            keys(q["table"], "table", "question %s table" % q.get("id"))
        if isinstance(q.get("example"), dict):
            keys(q["example"], "example", "question %s example"
                 % q.get("id"))
        for it in q.get("items", []):
            keys(it, "item", "item %s" % it.get("id"))
            bound_keys(it, "item %s" % it.get("id"))
            for t in it.get("targets", []):
                keys(t, "target", "target %s" % t.get("id"))
    for g in pub.get("figures", []):
        keys(g, "figure", "figure %s" % g.get("id"))
        if isinstance(g.get("frame"), dict):
            keys(g["frame"], "frame", "figure %s frame" % g.get("id"))
            for a in g["frame"].get("axes") or []:
                if isinstance(a, dict):
                    keys(a, "frame_axis", "figure %s frame" % g.get("id"))
            if isinstance(g["frame"].get("sketch"), dict):
                keys(g["frame"]["sketch"], "frame_sketch", "figure %s frame "
                     "sketch" % g.get("id"))      # v6.16 gaps r3
    try:
        _scan_values(pub, out)
        # (v6.16 integrate) the graph and pie parts: their own grammar and
        # leak scans (wspec/sheet_graph.py, wspec/sheet_pie.py)
        from . import sheet_graph as SGR
        from . import sheet_pie as SPI
        SGR.scan_public(pub, out)
        SPI.scan_public(pub, out)
        from . import sheet_data as SDA
        SDA.scan_public(pub, out)
        from . import figure_scopes618 as FS618
        out.extend(Issue("PUBLIC_VALUE_NOT_WHITELISTED", "figure inheritance", why)
                   for why in FS618.public_faults(pub))
        from . import sheet_locus as SLO
        SLO.scan_public(pub, out)
        from . import base_height as BH
        BH.validate(pub, S.Index(pub), out)
        from . import named_lines as NL
        out.extend(NL.schema_issues(pub, S.Index(pub)))
        from . import point_transform as PT
        PT.scan_public(pub, out)
        # Source-backed metadata has its own closed grammar and checks.
        # It never manufactures a typed relation or carries an answer.
        from . import printed_claims as PC
        entities = {e.get("id"): e for e in pub.get("entities") or []}
        facts = {f.get("id"): f for f in pub.get("facts") or []}
        for q in pub.get("questions") or []:
            texts = {r.get("id"): r.get("text") for r in
                     [q] + list(q.get("items") or [])}
            out.extend(Issue("PUBLIC_VALUE_NOT_WHITELISTED", "public claims", why)
                       for why in PC.faults(q, entities, facts, texts,
                                            pub.get("figures") or []))
    except Exception as e:             # noqa: BLE001 -- odd shape = refusal
        out.append(Issue("PUBLIC_VALUE_NOT_WHITELISTED", "public",
                         "unscannable: %s" % type(e).__name__))
    return out


# --------------------------------------------------------- private part ---
def answer_key(spec, ix, tset, item, rendered=None):
    """The private answer-key line of an item (the sheet's style). Its
    parts follow the order in which the item's TEXT asks for the targets
    (then id order for a target the text does not print) -- never the
    order the author listed them in, which canon sorts away (verifier
    semantics r1, V3: two specs with one spec_hash gave two keys)."""
    segs = item.get("text") or []
    tpls = [s.get("tpl") for s in segs if isinstance(s, dict)]
    printed = list((rendered.printed if rendered else {}))
    from . import point_transform as PT
    parts = PT.answer_pairs(spec, item, ix)
    for tid in sorted(item["targets"], key=lambda t: (
            (0, printed.index(t)) if t in printed else (1, 0), t)):
        a = ix.facts[tid[:-1] + "a"]
        if PT.target_row(spec, ix.facts[tid]) is not None:
            continue
        if (ix.facts.get(tid) or {}).get("role") == "to_plot":
            # (v6.12) the key of a plot task is the plotted place (the key
            # figure), no value
            parts.append("סימון")
        elif (ix.facts.get(tid) or {}).get("role") == "to_construct":
            # (v6.10 fix r1, L2) a join the item's text does not print --
            # its claim presupposes it -- is no answer of its own
            said = any(tid in (sg.get("facts") or []) for sg in segs
                       if isinstance(sg, dict))
            if said or not S.claim_presupposes_join(ix.facts[tid], ix):
                parts.append("בנייה")
        elif a.get("rel") == "classify" and a.get("value") is not None:
            # (v6.10) the class the answer names, in its shape phrase
            parts.append(T._phrase(tset, dict(a, rel=a["value"]), ix, "tex",
                                   "answer key"))
        elif a.get("value") is None and \
                (ix.facts.get(tid) or {}).get("role") == "to_prove" and \
                _deduce_only(segs, item, ix):
            # (v6.10 fix r1, m1) "הסיקו כי ...": the key states the claim
            parts.append(T._phrase(tset, ix.facts[tid], ix, "sheet",
                                   "answer key"))
        elif a.get("value") is None:
            parts.append("נימוק" if any(
                x in tpls for x in JUSTIFY_TPLS) else "הוכחה")
        else:
            parts.append(T._phrase(tset, a, ix, "tex", "answer key"))
    # (v6.10 fix r1, K) the known values the key restates (schema key_also)
    for x in item.get("key_also") or []:
        parts.append(T._phrase(tset, ix.facts[x], ix, "tex", "answer key"))
    line = ", ".join(parts)
    if any(x in tpls for x in COMPUTE_JUSTIFY_TPLS):
        line += " · נימוק"
    return line


# templates whose item asks for a reason (the key says "נימוק"), and the
# compute templates that ask to justify too (" · נימוק" after the value)
JUSTIFY_TPLS = ("justify_why", "explain_why", "justify_one_sentence")
DEDUCE_TPLS = ("deduce_that",)


def _deduce_only(segs, item, ix):
    """(v6.10 fix r1, m1) every to_prove of the item is printed by a
    deduce_that segment ('הסיקו כי AE = BF' alone): its key states it"""
    ded = set(fid for sg in segs if isinstance(sg, dict) and
              sg.get("tpl") in DEDUCE_TPLS for fid in sg.get("facts") or [])
    tps = [t for t in item.get("targets") or []
           if (ix.facts.get(t) or {}).get("role") == "to_prove"]
    return bool(tps) and set(tps) <= ded
COMPUTE_JUSTIFY_TPLS = ("compute_justify", "compute_length_justify",
                        "what_is_explain", "determine_justify")


def private_model(spec, templates=None):
    tset = templates or T.load_templates()
    ix, rendered, pub_facts, pub_ids = _build(spec, tset)
    answers, targets = [], {}
    for f in sorted(ix.facts.values(), key=lambda f: f["id"]):
        if f["role"] == "answer":
            a = {"id": f["id"], "target": f["id"][:-1] + "t",
                 "rel": f["rel"], "args": list(f["args"])}
            if f.get("value") is not None:
                a["value"] = f["value"] if f["rel"] == "classify" else \
                    canon.canon_number(f["value"])
                targets[a["target"]] = a["value"]
            u = canon.canon_unit(f.get("unit"))
            if u:
                a["unit"] = u
            if f.get("approx") is not None:
                # (v6.17, V3 / D6) the printed rounding next to the exact
                # value, computed from it (never typed)
                a["approx"] = f["approx"]
            answers.append(a)
    keys = {}
    for q in spec["questions"]:
        for it in q["items"]:
            keys[it["id"]] = answer_key(spec, ix, tset, it, rendered)
    frames = dict((g["id"], _private_frame(g["frame"]))
                  for g in spec.get("figures") or []
                  if isinstance(g, dict) and g.get("frame") is not None)
    extra = {"frames": frames} if frames else {}
    return dict({
        "sheet": spec["sheet"],
        "answers": answers,
        "target_values": targets,
        "answer_key": keys,
        "not_public": sorted(f["id"] for f in ix.facts.values()
                             if f["id"] not in pub_ids),
        "releases": sorted((dict(r) for r in spec.get("releases") or []),
                           key=lambda r: (str(r.get("fact")),
                                          canon.dumps(r))),
        "didactic": spec.get("didactic"),
    }, **extra)


def _private_frame(fr):
    """(v6.12) the full frame (min / max / step / labels) of a family
    figure: private -- the renderer and the checker place from it."""
    from . import family as FAM
    return FAM.private_frame(fr)
