# -*- coding: utf-8 -*-
"""wspec.pie -- the PIE CHART family of the spec (v6.16, BRIEF_V616 "PIE
(new chart family)", PLAN18 engine_scope.charts.pie, W-PLAN18-LIST D3).
Stdlib only. Owner: the pie engine (v616/progress/engine_pie.md). Nothing in
this module edits another module: the integrator wires the hooks listed in
REGISTRY (v616/HOOKS.txt, section PIE).

WHAT A PIE FIGURE IS (the mathematics it shows, never a display setting)

  entities  pie           {"id": "pie:<name>", "kind": "pie", "name": NAME}
            sector        {"id": "sector:<pie name>:<key>", "kind": "sector",
                           "pie": "pie:<name>", "key": KEY, "name": LABEL}
            build_circle  {"id": "bcirc:<name>", "kind": "build_circle",
                           "name": NAME}
            NAME ^[a-z][a-z_]{0,23}$ and KEY ^[a-z]{1,2}$ carry NO digit: an
            id is printed into the SVG (data-for) and the object map, and a
            digit there would read as a number token (MUST_NOT_DRAW scans
            ids). LABEL is what prints: one Latin capital (A) or 1..3 Hebrew
            words ("תחבורה ציבורית"). pie_name(n) gives the question-derived
            digit-free pie name (7 -> "qg", 13 -> "qm").

  facts     sector_value(sector)   given (value, unit % | deg) -- the
                                   declared data; target -- a MISSING
                                   sector (no value: the renderer draws the
                                   exact rest and never prints it); answer
            sector_equal(s, s, ..) given, no value: equal shares (the
                                   renderer computes them; args sorted)
            sector_angle(sector)   target / answer (deg): a FIND target
            sector_percent(sector) target / answer (%): a FIND target
            sector_count(sector)   given / target / answer (a count; stem
                                   data only -- a figure never draws it)
            pie_total(pie)         given (drawn = the total label
                                   "סך הכול: N") / target / answer
            construct_pie(bcirc)   to_construct / answer: the student builds
                                   the pie in the empty circle

  frame     {"family": "pie_chart",
             "layout": "single" | "side_by_side" | "row",
             "parts": [PART] (1 part single, 2 parts side_by_side, 2..3
             parts row), "same_size": bool (side_by_side; row: true),
             "shared_legend": bool (side_by_side, both pies names=legend,
             same names in order)}
    PIE     {"part": "pie", "pie": ID, "side": "left"|"right" (side_by_side),
             "unit": "percent" | "degree" | "fraction",
             "order": [sector ids] (every
             sector of the pie once; the first one starts at `start`),
             "start": 0..359 (degrees clockwise from 12 o'clock),
             "direction": "clockwise" | "counterclockwise",
             "names": "in_sector" | "legend" | "none",
             "values": "in_sector" | "legend" | "none",
             "outside": [sector ids] (names in_sector only: printed outside
             next to the wedge with a leader line), "caption": TEXT,
             "fills": ["#rrggbb", ...] (one per sector, in order),
             "regions": [sector ids] (v6.16 r2, AAF1: the tiles that are
             undivided REGIONS)}
    BUILD   {"part": "build", "circle": ID, "side": ..., "centre_dot": bool,
             "caption": TEXT (v6.16 r2: an empty disc of a row)}

  (v6.16 r2, pie corpus ADDENDUM 1 / W-FIGURE-DENSITY) the additions that
  let every declared figure of the addendum be drawn, all additive (a spec
  without them renders byte for byte as before):
    layout "row"     two or three discs in ONE row, read RIGHT TO LEFT: the
                     first part is the rightmost disc (d1). Every disc of a
                     row is a pie or an EMPTY disc (a build part), all of one
                     radius (same_size true), each with exactly one caption
                     (its own ordinal / group word: no digit, no word of a
                     whole or a count -- השלם, סה״כ, סך הכול, תלמידים,
                     פריטים, נשאלים, אנשים -- captions distinct). No side key,
                     no shared legend.
    names "none"     no sector name is printed on that disc (an unlabelled
                     wedge); the entity name stays a handle, never printed.
    regions          a REGION is one undivided tile over its range (a
                     numeric value or the rest): drawn as one filled wedge,
                     it prints no name, at most its GIVEN value label (values
                     in_sector) INSIDE it -- never outside, never a leader,
                     never in a legend pie. Nothing else is ever drawn inside
                     its range (the checker's REGION_UNDIVIDED).
    unit "fraction"  a value is a fraction of the disc ("1/6"; exact
                     rational, no unit), the values sum to 1; a fraction
                     pie prints no value label (values none).
    build caption    the caption of an empty disc, printed under it.

  what is printed: every sector's name (in its wedge / outside with a leader
  / in the legend) unless names none or the sector is a region; the value of
  every GIVEN sector_value the figure draws
  (values in_sector | legend -- then every given value of the pie is drawn;
  values none -- none is drawn); the caption when declared; the total label
  when a given pie_total is drawn. A target is never drawn; a missing
  sector's value, an angle, a percent or a count the student finds are
  never printed anywhere (the renderer refuses / fails its validation).

  data (exact rationals): every given value > 0; sectors tied by
  sector_equal share one value; the sectors without a value are either ONE
  sector (the rest) or ONE equal group (equal shares of the rest); the
  values sum to exactly 100 (percent) / 360 (degree) / 1 (fraction).
  Anything else is
  refused with a NAMED reason (PIE_REASONS): PIE_VALUE_NOT_POSITIVE,
  PIE_SUM_NOT_TOTAL, PIE_REST_NOT_POSITIVE, PIE_UNDERDETERMINED,
  PIE_EQUAL_CONFLICT, PIE_VALUE_UNIT.
"""
import hashlib
import re
import unicodedata
from fractions import Fraction

from . import canon

FAMILY = "pie_chart"
# (v6.16 r2) 1 -> 1.1: additive (layout row, names none, regions, unit
# fraction, build caption); every wspec-pie/1 spec is a 1.1 spec
FAMILY_VERSION = "wspec-pie/1.1"

# ------------------------------------------------------------- reasons ---
PIE_REASONS = {
    "PIE_UNKNOWN_FIELD": "a field outside the closed pie grammar",
    "PIE_MISSING_FIELD": "a required pie field is absent",
    "PIE_BAD_VALUE": "a pie field value outside its grammar",
    "PIE_BAD_ID": "a pie entity id / name / key breaks the id rule",
    "PIE_UNKNOWN_REF": "a pie frame / fact names an entity that is not there",
    "PIE_REL_ARGS": "a pie relation with the wrong argument kinds / arity",
    "PIE_ROLE": "a pie relation with a role it does not take",
    "PIE_VALUE_FORBIDDEN": "a value on a pie relation / role that has none",
    "PIE_VALUE_REQUIRED": "a given pie measure without a value",
    "PIE_TARGET_HAS_VALUE": "a pie target carries its value",
    "PIE_VALUE_UNIT": "a sector value in a unit other than its pie's",
    "PIE_VALUE_NOT_POSITIVE": "a declared sector value is 0 or negative",
    "PIE_SUM_NOT_TOTAL": "the sector values do not sum to 100 % / 360 deg",
    "PIE_REST_NOT_POSITIVE": "the missing sector(s) would get 0 or less",
    "PIE_UNDERDETERMINED": "more than one sector without a value and no "
                           "equal-share relation that fixes them",
    "PIE_EQUAL_CONFLICT": "sectors declared equal carry different values",
    "PIE_ORDER": "the order is not every sector of the pie exactly once",
    "PIE_OUTSIDE": "an outside label on a pie whose names are not in_sector "
                   "/ a sector of another pie",
    "PIE_FILLS": "fills: not one colour per sector, or two neighbours equal",
    "PIE_VALUES_DRAWN": "the drawn values disagree with the frame's values "
                        "mode (all given values or none)",
    "PIE_DRAWS": "a pie figure draws a fact it cannot mark (a target, an "
                 "answer, a count, a fact of another figure)",
    "PIE_UNLISTED": "a pie / sector / circle the frame uses is not listed "
                    "in the figure",
    "PIE_CAPTION": "a caption outside the closed caption alphabet",
    "PIE_LAYOUT": "parts / sides / same_size / shared_legend do not fit the "
                  "layout",
    "PIE_ANSWER_MISMATCH": "an answer disagrees with the exact data",
    "PIE_PRINTS_ANSWER": "a printed text (caption) states an answer",
    "PIE_PUBLIC_LEAK": "a pie part of a public model outside its grammar "
                       "(a value on a target, an answer, a free string)",
}


class PieIssue(object):
    """Same interface as wspec.errors.Issue, over the closed PIE_REASONS
    table (errors.REASONS is not the pie owner's file: the integrator merges
    the two tables, v616/HOOKS.txt)."""
    __slots__ = ("code", "where", "detail")

    def __init__(self, code, where="", detail=""):
        assert code in PIE_REASONS, "unregistered pie reason %r" % code
        self.code, self.where, self.detail = code, where, detail

    def __repr__(self):
        return "PieIssue(%s @ %s: %s)" % (self.code, self.where, self.detail)

    __str__ = __repr__

    def as_dict(self):
        return {"code": self.code, "where": self.where, "detail": self.detail}


# ------------------------------------------------------------- grammar ---
NAME_RE = re.compile(r"^[a-z][a-z_]{0,23}\Z")
KEY_RE = re.compile(r"^[a-z]{1,2}\Z")
_H = u"א-ת"
_HW = u"[%s][%s׳״]*" % (_H, _H)
LABEL_RE = re.compile(u"^(?:[A-Z]|%s(?: %s){0,2})\\Z" % (_HW, _HW))
LABEL_MAX = 16
# a caption: Hebrew / Latin letters, digits, geresh / gershayim, and the
# separators space, en dash, hyphen, colon, period, comma; 1..40 characters,
# no leading / trailing / double space
CAPTION_RE = re.compile(u"^[%sA-Za-z0-9׳״](?:[%sA-Za-z0-9׳"
                        u"״:.,–-]| (?! ))*\\Z" % (_H, _H))
CAPTION_MAX = 40
HEX_RE = re.compile(r"^#[0-9a-f]{6}\Z")
ID_RE = re.compile(r"^(?:pie:[a-z][a-z_]{0,23}|sector:[a-z][a-z_]{0,23}:"
                   r"[a-z]{1,2}|bcirc:[a-z][a-z_]{0,23})\Z")

ENTITY_KINDS = {"pie": ("name",), "sector": ("pie", "key", "name"),
                "build_circle": ("name",)}
ENTITY_REFS = {"sector": ("pie",)}
# keys a pie entity adds to project.PUBLIC_KEYS["entity"]
PUBLIC_ENTITY_KEYS = ("key", "pie")

UNIT_OF = {"percent": ("%", Fraction(100)), "degree": ("deg", Fraction(360)),
           # (v6.16 r2) a fraction of the disc ("1/6"): no unit, sum 1
           "fraction": (None, Fraction(1))}
RELS = {
    "sector_value": {"args": ("sector",), "roles": ("given", "target",
                                                    "answer"),
                     "units": ("%", "deg", None)},
    "sector_equal": {"args": ("sector", "+"), "roles": ("given",),
                     "units": ()},
    "sector_angle": {"args": ("sector",), "roles": ("target", "answer"),
                     "units": ("deg",)},
    "sector_percent": {"args": ("sector",), "roles": ("target", "answer"),
                       "units": ("%",)},
    "sector_count": {"args": ("sector",), "roles": ("given", "target",
                                                    "answer"),
                     "units": (None,)},
    "pie_total": {"args": ("pie",), "roles": ("given", "target", "answer"),
                  "units": (None,)},
    "construct_pie": {"args": ("build_circle",),
                      "roles": ("to_construct", "answer"), "units": ()},
}
# what a pie figure may list in `draws`: a given sector_value (its value
# label), a given sector_equal (by geometry, no mark), a given pie_total
# (the total label)
DRAWABLE = {"sector_value": ("given",), "sector_equal": ("given",),
            "pie_total": ("given",)}
VALUE_RELS = ("sector_value", "sector_angle", "sector_percent",
              "sector_count", "pie_total")

FRAME_KEYS = {"family": True, "layout": True, "parts": True,
              "same_size": False, "shared_legend": False}
PIE_PART_KEYS = {"part": True, "pie": True, "side": False, "unit": True,
                 "order": True, "start": True, "direction": True,
                 "names": True, "values": True, "outside": False,
                 "caption": False, "fills": False,
                 "regions": False}                          # v6.16 r2
BUILD_PART_KEYS = {"part": True, "circle": True, "side": False,
                   "centre_dot": True,
                   "caption": False}                        # v6.16 r2
FACT_KEYS = ("id", "rel", "args", "role", "item", "source", "value", "unit")
FIGURE_KEYS = ("id", "scope", "figure_accuracy", "entities", "draws",
               "frame")
LAYOUTS = ("single", "side_by_side", "row")                 # row: v6.16 r2
DIRECTIONS = ("clockwise", "counterclockwise")
NAMES_MODES = ("in_sector", "legend", "none")               # none: v6.16 r2
VALUES_MODES = ("in_sector", "legend", "none")
SIDES = ("left", "right")
MAX_SECTORS = 12
TOTAL_TEMPLATE = u"סך הכול: {v}"
# (v6.16 r2) a row holds 2..3 discs; its captions state no whole / count
# (AAF1 CAPTION_POLICY: a caption carries no digit and none of these words)
ROW_PARTS = (2, 3)
ROW_CAPTION_WORDS = (u"השלם", u"סה״כ", u"סך הכול", u"תלמידים", u"פריטים",
                     u"נשאלים", u"אנשים")
PART_COUNT = {"single": (1,), "side_by_side": (2,), "row": ROW_PARTS}


def row_caption_problem(c):
    """why a caption cannot print under a disc of a ROW, or None"""
    c = nfc(c) if isinstance(c, str) else c
    if not isinstance(c, str) or not c:
        return "a disc of a row carries its caption"
    if re.search(r"[0-9]", c):
        return "caption %r carries a digit" % c
    hit = [w for w in ROW_CAPTION_WORDS if w in c]
    if hit:
        return "caption %r states a whole / a count (%s)" % (c, hit[0])
    return None


def nfc(s):
    return unicodedata.normalize("NFC", s) if isinstance(s, str) else s


def pie_name(n):
    """The digit-free pie name for question n: 'q' + n in bijective base 26
    (1 -> 'qa', 7 -> 'qg', 13 -> 'qm', 27 -> 'qaa')."""
    if not isinstance(n, int) or isinstance(n, bool) or n < 1:
        raise ValueError("question number %r" % (n,))
    s = ""
    while n:
        n, r = divmod(n - 1, 26)
        s = chr(ord("a") + r) + s
    return "q" + s


def entity_id(e):
    """The fixed id rule of the pie kinds; None for another kind, '?' for a
    malformed pie entity."""
    k = e.get("kind")
    try:
        if k == "pie":
            return "pie:" + nfc(e["name"])
        if k == "sector":
            p = nfc(e["pie"])
            if not p.startswith("pie:"):
                return "?"
            return "sector:%s:%s" % (p[4:], nfc(e["key"]))
        if k == "build_circle":
            return "bcirc:" + nfc(e["name"])
    except (KeyError, TypeError, AttributeError):
        return "?"
    return None


def is_pie_figure(fig):
    fr = (fig or {}).get("frame")
    return isinstance(fr, dict) and fr.get("family") == FAMILY


def is_pie_entity(e):
    return (e or {}).get("kind") in ENTITY_KINDS


def is_pie_fact(f):
    return (f or {}).get("rel") in RELS


def _q(v):
    """exact rational of a spec value, or None"""
    try:
        a, _b, r = canon.parse_exact(v)
    except Exception:                   # noqa: BLE001
        return None
    return a if r == 1 else None


def decimal_text(q):
    """A terminating rational as its printed decimal ('12.5'), else None."""
    q = Fraction(q)
    d = q.denominator
    k = 0
    while d % 2 == 0 or d % 5 == 0:
        d //= 2 if d % 2 == 0 else 5
        k += 1
    if d != 1:
        return None
    if q.denominator == 1:
        return str(q.numerator)
    neg = q < 0
    q = abs(q)
    whole = q.numerator // q.denominator
    frac = q - whole
    digits = ""
    while frac:
        frac *= 10
        dg = frac.numerator // frac.denominator
        digits += str(dg)
        frac -= dg
    return ("-" if neg else "") + str(whole) + "." + digits


def value_label(q, unit):
    """The printed value label of a sector ('40%', '12.5%', '144°'); None
    for a fraction of the disc (v6.16 r2: a fraction wedge prints no value
    label)."""
    if unit == "fraction":
        return None
    t = decimal_text(q)
    if t is None:
        return None
    return t + ("%" if unit == "percent" else u"°")


def total_label(q):
    t = decimal_text(q)
    return None if t is None else TOTAL_TEMPLATE.format(v=t)


# ------------------------------------------------------------ indexing ---
class PieIndex(object):
    """The pie-family view of a spec or a public model."""

    def __init__(self, spec):
        self.spec = spec
        self.ents = dict((e.get("id"), e) for e in spec.get("entities") or []
                         if isinstance(e, dict))
        self.facts = dict((f.get("id"), f) for f in spec.get("facts") or []
                          if isinstance(f, dict))
        self.figures = dict((g.get("id"), g) for g in spec.get("figures")
                            or [] if isinstance(g, dict))

    def sectors_of(self, pie):
        return sorted(e for e, v in self.ents.items()
                      if v.get("kind") == "sector" and v.get("pie") == pie)

    def facts_about(self, eid, rel=None, roles=None):
        out = []
        for fid in sorted(self.facts):
            f = self.facts[fid]
            if eid in (f.get("args") or []) and (rel is None or
                                                 f.get("rel") == rel) and \
                    (roles is None or f.get("role") in roles):
                out.append(f)
        return out


# ------------------------------------------------------ exact resolution --
class Resolved(object):
    """The exact data of one pie part: value[sid] (Fraction), source[sid]
    in {'given', 'equal', 'rest'} and the named problems (code, detail)."""

    def __init__(self):
        self.unit = None
        self.total = None
        self.order = []
        self.value = {}
        self.source = {}
        self.given_fact = {}
        self.problems = []

    @property
    def valid(self):
        return not self.problems

    def spans(self):
        """degrees of each sector, in order (exact)."""
        k = Fraction(360) / self.total if self.total else None
        return [self.value[s] * k if self.value.get(s) is not None else None
                for s in self.order]


def resolve(ix, part):
    """Exact values of a pie part from the GIVEN facts of the model (a
    public model has exactly the givens the student sees)."""
    r = Resolved()
    unit = part.get("unit")
    if unit not in UNIT_OF:
        r.problems.append(("PIE_BAD_VALUE", "unit %r" % (unit,)))
        return r
    r.unit = unit
    ucode, r.total = UNIT_OF[unit]
    r.order = [s for s in part.get("order") or [] if isinstance(s, str)]
    known = {}
    for s in r.order:
        gv = [f for f in ix.facts_about(s, "sector_value", ("given",))]
        if len(gv) > 1:
            r.problems.append(("PIE_EQUAL_CONFLICT", "%s has %d given values"
                               % (s, len(gv))))
            continue
        if gv:
            f = gv[0]
            v = _q(f.get("value"))
            if v is None:
                r.problems.append(("PIE_BAD_VALUE", "%s: value %r" % (
                    f.get("id"), f.get("value"))))
                continue
            u = canon.canon_unit(f.get("unit")) if f.get("unit") else None
            if u != ucode:
                r.problems.append(("PIE_VALUE_UNIT", "%s: unit %r in a %s "
                                   "pie" % (f.get("id"), f.get("unit"),
                                            unit)))
            if v <= 0:
                r.problems.append(("PIE_VALUE_NOT_POSITIVE", "%s = %s" % (
                    s, decimal_text(v) or str(v))))
            known[s] = v
            r.given_fact[s] = f["id"]
    # equal groups (union-find over given sector_equal among the order)
    parent = dict((s, s) for s in r.order)

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    for f in sorted(ix.facts.values(), key=lambda f: f.get("id")):
        if f.get("rel") != "sector_equal" or f.get("role") != "given":
            continue
        a = [x for x in f.get("args") or [] if x in parent]
        if len(a) != len(f.get("args") or []):
            continue
        for x in a[1:]:
            parent[find(x)] = find(a[0])
    groups = {}
    for s in r.order:
        groups.setdefault(find(s), []).append(s)
    for g, mem in sorted(groups.items()):
        vals = sorted(set(known[m] for m in mem if m in known))
        if len(vals) > 1:
            r.problems.append(("PIE_EQUAL_CONFLICT", "equal sectors %s carry "
                               "%s" % (mem, [decimal_text(v) for v in vals])))
            continue
        if vals and len(mem) > 1:
            for m in mem:
                if m not in known:
                    known[m] = vals[0]
                    r.source[m] = "equal"
    for s in known:
        r.source.setdefault(s, "given")
    unknown = [s for s in r.order if s not in known]
    rest = r.total - sum(known.values(), Fraction(0))
    if not unknown:
        if rest != 0:
            s = r.total - rest
            r.problems.append(("PIE_SUM_NOT_TOTAL", "the values sum to %s, "
                               "not %s" % (decimal_text(s) or str(s),
                                           decimal_text(r.total))))
    else:
        roots = set(find(s) for s in unknown)
        if len(unknown) > 1 and (len(roots) != 1 or any(
                find(s) != find(unknown[0]) for s in unknown)):
            r.problems.append(("PIE_UNDERDETERMINED", "sectors %s have no "
                               "value and no equal-share relation between "
                               "them" % unknown))
        else:
            share = rest / len(unknown)
            if share <= 0:
                r.problems.append(("PIE_REST_NOT_POSITIVE", "the rest %s "
                                   "for %s is not positive" % (
                                       decimal_text(rest) or str(rest),
                                       unknown)))
            for s in unknown:
                known[s] = share
                r.source[s] = "rest" if len(unknown) == 1 else "equal"
    r.value = dict((s, known.get(s)) for s in r.order)
    return r


# --------------------------------------------------------- frame shape ---
def frame_issues(spec, fig):
    """Shape of a pie figure (spec or public model): grammar, references,
    listing, drawing rules. Data validity: data_issues()."""
    out = []
    w = "figure %s frame" % (fig or {}).get("id")
    ix = spec if isinstance(spec, PieIndex) else PieIndex(spec)
    fr = (fig or {}).get("frame")

    def bad(code, detail):
        out.append(PieIssue(code, w, detail))

    def fields(obj, table, where):
        if not isinstance(obj, dict):
            bad("PIE_BAD_VALUE", "%s: not an object" % where)
            return False
        ok = True
        for k in sorted(obj):
            if k not in table:
                bad("PIE_UNKNOWN_FIELD", "%s: %r" % (where, k))
                ok = False
        for k, req in sorted(table.items()):
            if req and k not in obj:
                bad("PIE_MISSING_FIELD", "%s: %r" % (where, k))
                ok = False
        return ok

    if not fields(fr, FRAME_KEYS, "frame"):
        return out
    if fr.get("family") != FAMILY:
        bad("PIE_BAD_VALUE", "family %r" % fr.get("family"))
        return out
    lay = fr.get("layout")
    if lay not in LAYOUTS:
        bad("PIE_BAD_VALUE", "layout %r" % (lay,))
        return out
    parts = fr.get("parts")
    if not isinstance(parts, list) or len(parts) not in PART_COUNT[lay]:
        bad("PIE_LAYOUT", "layout %s takes %s part(s)" % (
            lay, " or ".join(str(n) for n in PART_COUNT[lay])))
        return out
    if lay == "single":
        for k in ("same_size", "shared_legend"):
            if k in fr:
                bad("PIE_LAYOUT", "%s on a single layout" % k)
    else:
        for k in ("same_size", "shared_legend"):
            if k in fr and not isinstance(fr[k], bool):
                bad("PIE_BAD_VALUE", "%s %r" % (k, fr[k]))
    if lay == "row":
        # (v6.16 r2) one row of 2..3 discs of ONE radius, read right to
        # left, each captioned; no legend shared across it
        if fr.get("same_size") is not True:
            bad("PIE_LAYOUT", "the discs of a row have one radius "
                "(same_size true)")
        if fr.get("shared_legend"):
            bad("PIE_LAYOUT", "a row has no shared legend")
        caps = []
        for i, p in enumerate(parts):
            if not isinstance(p, dict):
                continue
            why = row_caption_problem(p.get("caption"))
            if why:
                bad("PIE_CAPTION", "part %d: %s" % (i, why))
            caps.append(p.get("caption"))
        if len(set(c for c in caps if isinstance(c, str))) != len(caps):
            bad("PIE_CAPTION", "the captions of a row are distinct: %r"
                % caps)
    if fig.get("figure_accuracy") != "accurate":
        bad("PIE_BAD_VALUE", "a pie figure is accurate (the wedges are "
            "the data)")
    listed = set(fig.get("entities") or [])
    sides = []
    pies = []
    for i, p in enumerate(parts):
        where = "part %d" % i
        if not isinstance(p, dict) or p.get("part") not in ("pie", "build"):
            bad("PIE_BAD_VALUE", "%s: part %r" % (
                where, (p or {}).get("part") if isinstance(p, dict) else p))
            continue
        if not fields(p, PIE_PART_KEYS if p["part"] == "pie" else
                      BUILD_PART_KEYS, where):
            continue
        if lay == "side_by_side":
            if p.get("side") not in SIDES:
                bad("PIE_LAYOUT", "%s: side %r" % (where, p.get("side")))
            sides.append(p.get("side"))
        elif "side" in p:
            bad("PIE_LAYOUT", "%s: side on a %s layout (a row is read "
                "right to left in the order of its parts)" % (where, lay))
        if "caption" in p:
            c = p["caption"]
            if not (isinstance(c, str) and c == nfc(c) and
                    0 < len(c) <= CAPTION_MAX and CAPTION_RE.match(c)):
                bad("PIE_CAPTION", "%s: caption %r" % (where, c))
        if p["part"] == "build":
            c = p.get("circle")
            if (ix.ents.get(c) or {}).get("kind") != "build_circle":
                bad("PIE_UNKNOWN_REF", "%s: circle %r" % (where, c))
            elif c not in listed:
                bad("PIE_UNLISTED", "%s: %s" % (where, c))
            if not isinstance(p.get("centre_dot"), bool):
                bad("PIE_BAD_VALUE", "%s: centre_dot %r" % (
                    where, p.get("centre_dot")))
            continue
        pie = p.get("pie")
        if (ix.ents.get(pie) or {}).get("kind") != "pie":
            bad("PIE_UNKNOWN_REF", "%s: pie %r" % (where, pie))
            continue
        pies.append(pie)
        if pie not in listed:
            bad("PIE_UNLISTED", "%s: %s" % (where, pie))
        for k, allowed in (("unit", UNIT_OF), ("direction", DIRECTIONS),
                           ("names", NAMES_MODES), ("values", VALUES_MODES)):
            if p.get(k) not in allowed:
                bad("PIE_BAD_VALUE", "%s: %s %r" % (where, k, p.get(k)))
        st = p.get("start")
        if not (isinstance(st, int) and not isinstance(st, bool) and
                0 <= st <= 359):
            bad("PIE_BAD_VALUE", "%s: start %r (whole degrees 0..359 "
                "clockwise from 12 o'clock)" % (where, st))
        mine = ix.sectors_of(pie)
        order = p.get("order")
        if not isinstance(order, list) or sorted(order) != mine or \
                len(set(order)) != len(order) or not (
                    1 <= len(order) <= MAX_SECTORS):
            bad("PIE_ORDER", "%s: order %r vs the sectors of %s %r" % (
                where, order, pie, mine))
            order = mine
        for s in order:
            if s not in listed:
                bad("PIE_UNLISTED", "%s: %s" % (where, s))
        outs = p.get("outside", [])
        if not isinstance(outs, list) or len(set(outs)) != len(outs) or \
                any(s not in order for s in outs):
            bad("PIE_OUTSIDE", "%s: outside %r" % (where, outs))
        elif outs and p.get("names") != "in_sector":
            bad("PIE_OUTSIDE", "%s: outside labels need names in_sector"
                % where)
        # (v6.16 r2) regions: undivided tiles -- no name, nothing outside,
        # no legend pie
        regs = p.get("regions", [])
        if not isinstance(regs, list) or len(set(regs)) != len(regs) or \
                any(s not in order for s in regs):
            bad("PIE_BAD_VALUE", "%s: regions %r (sectors of the part, "
                "each once)" % (where, regs))
        else:
            if regs and p.get("names") == "legend":
                bad("PIE_LAYOUT", "%s: a region is never in a legend pie"
                    % where)
            both = sorted(set(regs) & set(outs if isinstance(outs, list)
                                          else []))
            if both:
                bad("PIE_OUTSIDE", "%s: region(s) %s outside (a region's "
                    "label stays inside it; no leader crosses a region)"
                    % (where, both))
        if p.get("unit") == "fraction" and p.get("values") != "none":
            bad("PIE_BAD_VALUE", "%s: values %r in a fraction pie (a "
                "fraction wedge prints no value label)" % (
                    where, p.get("values")))
        if "fills" in p:
            fl = p["fills"]
            if not isinstance(fl, list) or len(fl) != len(order) or any(
                    not (isinstance(x, str) and HEX_RE.match(x))
                    for x in fl):
                bad("PIE_FILLS", "%s: fills %r" % (where, fl))
            elif len(fl) > 1 and any(fl[i] == fl[(i + 1) % len(fl)]
                                     for i in range(len(fl))):
                bad("PIE_FILLS", "%s: two neighbouring sectors share a "
                    "fill" % where)
        # drawn values: every given sector_value of the pie, or none
        drawn = set(fig.get("draws") or [])
        gv = [f["id"] for s in order for f in
              ix.facts_about(s, "sector_value", ("given",))]
        dv = [x for x in gv if x in drawn]
        if p.get("values") == "none" and dv:
            bad("PIE_VALUES_DRAWN", "%s: values none but draws %s" % (
                where, dv))
        if p.get("values") in ("in_sector", "legend") and len(dv) != len(gv):
            bad("PIE_VALUES_DRAWN", "%s: values %s but %s not drawn" % (
                where, p.get("values"), sorted(set(gv) - set(dv))))
        if p.get("values") == "legend" and p.get("names") != "legend":
            bad("PIE_LAYOUT", "%s: values in the legend need names in the "
                "legend" % where)
    if lay == "side_by_side" and sorted(s for s in sides if s) != [
            "left", "right"]:
        bad("PIE_LAYOUT", "side_by_side needs one left and one right part")
    if fr.get("shared_legend"):
        pp = [p for p in parts if isinstance(p, dict) and
              p.get("part") == "pie"]
        names = [[(ix.ents.get(s) or {}).get("name") for s in
                  p.get("order") or []] for p in pp]
        if len(pp) != 2 or any(p.get("names") != "legend" for p in pp) or \
                names[0] != names[-1] or any(p.get("values") == "legend"
                                             for p in pp):
            bad("PIE_LAYOUT", "shared_legend: two pies, names in the legend, "
                "the same names in the same order, values not in the legend")
    # what the figure draws
    for fid in fig.get("draws") or []:
        f = ix.facts.get(fid)
        if f is None:
            bad("PIE_UNKNOWN_REF", "draws %r" % fid)
            continue
        rel = f.get("rel")
        if rel not in DRAWABLE or f.get("role") not in DRAWABLE[rel]:
            bad("PIE_DRAWS", "draws %s (%s, %s)" % (fid, rel, f.get("role")))
            continue
        args = f.get("args") or []
        own = set(pies) | set(s for p in pies for s in ix.sectors_of(p))
        if any(a not in own for a in args):
            bad("PIE_DRAWS", "draws %s about an entity of no pie of this "
                "figure" % fid)
    return out


def data_issues(spec, fig):
    """Named invalid-data reasons of every pie part of the figure."""
    ix = spec if isinstance(spec, PieIndex) else PieIndex(spec)
    out = []
    for i, p in enumerate(((fig or {}).get("frame") or {}).get("parts")
                          or []):
        if isinstance(p, dict) and p.get("part") == "pie":
            for code, detail in resolve(ix, p).problems:
                out.append(PieIssue(code, "figure %s part %d (%s)" % (
                    fig.get("id"), i, p.get("pie")), detail))
    return out


# -------------------------------------------------------- entity / fact --
def entity_issues(e):
    out = []
    w = "entity %s" % e.get("id")
    k = e.get("kind")
    table = ENTITY_KINDS.get(k)
    if table is None:
        return out
    allowed = set(("id", "kind") + table)
    for f in sorted(e):
        if f not in allowed:
            out.append(PieIssue("PIE_UNKNOWN_FIELD", w, f))
    for f in table:
        if f not in e:
            out.append(PieIssue("PIE_MISSING_FIELD", w, f))
    if out:
        return out
    if k in ("pie", "build_circle") and not NAME_RE.match(e["name"] or ""):
        out.append(PieIssue("PIE_BAD_ID", w, "name %r (^[a-z][a-z_]*$, no "
                            "digit)" % (e["name"],)))
    if k == "sector":
        if not (isinstance(e["key"], str) and KEY_RE.match(e["key"])):
            out.append(PieIssue("PIE_BAD_ID", w, "key %r" % (e["key"],)))
        n = e["name"]
        if not (isinstance(n, str) and n == nfc(n) and len(n) <= LABEL_MAX
                and LABEL_RE.match(n)):
            out.append(PieIssue("PIE_BAD_ID", w, "name %r (one Latin "
                                "capital or 1..3 Hebrew words)" % (n,)))
    if entity_id(e) != e.get("id") or not ID_RE.match(e.get("id") or ""):
        out.append(PieIssue("PIE_BAD_ID", w, "id is not %r" % entity_id(e)))
    return out


def fact_issues(f, ents, public=False):
    out = []
    w = "fact %s" % f.get("id")
    rel = f.get("rel")
    spec = RELS.get(rel)
    if spec is None:
        return out
    role = f.get("role")
    if role not in spec["roles"]:
        out.append(PieIssue("PIE_ROLE", w, "%s takes %s" % (
            rel, list(spec["roles"]))))
    args = f.get("args") or []
    kinds = [(ents.get(a) or {}).get("kind") for a in args]
    want = spec["args"]
    if want[-1] == "+":
        ok = len(args) >= 2 and all(k == want[0] for k in kinds) and \
            args == sorted(args) and len(set(args)) == len(args)
        if ok:
            pies = set((ents.get(a) or {}).get("pie") for a in args)
            ok = len(pies) == 1
    else:
        ok = kinds == list(want)
    if not ok:
        out.append(PieIssue("PIE_REL_ARGS", w, "%s(%s): kinds %s" % (
            rel, ",".join(args), kinds)))
    has = f.get("value") is not None
    if role in ("target", "to_construct") and has:
        out.append(PieIssue("PIE_TARGET_HAS_VALUE", w, "the value of a "
                            "target is the answer's (private)"))
    if rel == "sector_equal" or rel == "construct_pie":
        if has or f.get("unit") is not None:
            out.append(PieIssue("PIE_VALUE_FORBIDDEN", w, rel))
    elif role in ("given", "answer") and rel in VALUE_RELS:
        if not has:
            out.append(PieIssue("PIE_VALUE_REQUIRED", w, rel))
        elif _q(f.get("value")) is None:
            out.append(PieIssue("PIE_BAD_VALUE", w, "value %r" % (
                f.get("value"),)))
        u = canon.canon_unit(f.get("unit")) if f.get("unit") else None
        if u not in spec["units"]:
            out.append(PieIssue("PIE_VALUE_UNIT", w, "unit %r (%s takes %s)"
                                % (f.get("unit"), rel, list(spec["units"]))))
    if public and role == "answer":
        out.append(PieIssue("PIE_PUBLIC_LEAK", w, "an answer in public"))
    if f.get("id") != canon.fact_id(f):
        out.append(PieIssue("PIE_BAD_ID", w, "id is not %r"
                            % canon.fact_id(f)))
    return out


def spec_issues(spec):
    """Every pie-family problem of a spec (private side): entities, facts,
    figures, data, and the answers against the exact data."""
    ix = PieIndex(spec)
    out = []
    for e in spec.get("entities") or []:
        out += entity_issues(e)
        if e.get("kind") == "sector" and \
                (ix.ents.get(e.get("pie")) or {}).get("kind") != "pie":
            out.append(PieIssue("PIE_UNKNOWN_REF", "entity %s" % e.get("id"),
                                "pie %r" % (e.get("pie"),)))
    for f in spec.get("facts") or []:
        out += fact_issues(f, ix.ents)
        if is_pie_fact(f):
            for k in sorted(f):
                if k not in FACT_KEYS:
                    out.append(PieIssue("PIE_UNKNOWN_FIELD", "fact %s"
                                        % f.get("id"), k))
    for g in spec.get("figures") or []:
        if is_pie_figure(g):
            for k in sorted(g):
                if k not in FIGURE_KEYS:
                    out.append(PieIssue("PIE_UNKNOWN_FIELD", "figure %s"
                                        % g.get("id"), k))
            fi = frame_issues(ix, g)
            out += fi
            if not fi:
                out += data_issues(ix, g)
                out += answer_issues(ix, g)
    return out


def exact_quantities(ix, fig):
    """{(rel, entity id): Fraction} of every quantity the figure's data fix:
    sector_value / sector_angle / sector_percent of each sector of a VALID
    pie part. Used for the answers (private) and, by the renderer, for the
    hidden values it must never print."""
    out = {}
    for p in ((fig or {}).get("frame") or {}).get("parts") or []:
        if not (isinstance(p, dict) and p.get("part") == "pie"):
            continue
        r = resolve(ix, p)
        if not r.valid:
            continue
        for s in r.order:
            v = r.value[s]
            ang = v * Fraction(360) / r.total
            out[("sector_value", s)] = v
            out[("sector_angle", s)] = ang
            out[("sector_percent", s)] = ang * Fraction(100, 360)
    return out


def answer_issues(ix, fig):
    """Private side: every answer about a sector / pie of this figure equals
    the exact data; a caption never states an answer."""
    out = []
    q = exact_quantities(ix, fig)
    answers = []
    for f in sorted(ix.facts.values(), key=lambda f: f.get("id")):
        if f.get("role") != "answer" or f.get("rel") not in RELS:
            continue
        a = (f.get("args") or [None])[0]
        v = _q(f.get("value"))
        if v is not None:
            answers.append(v)
        key = (f.get("rel"), a)
        if key in q and v is not None and v != q[key]:
            out.append(PieIssue("PIE_ANSWER_MISMATCH", "fact %s" % f["id"],
                                "%s, the data give %s" % (
                                    f.get("value"), decimal_text(q[key]))))
    for p in fig["frame"]["parts"]:
        # (v6.16 r2) an empty disc's caption too
        c = p.get("caption") if p.get("part") in ("pie", "build") else None
        if not c:
            continue
        toks = set(re.findall(r"[0-9]+(?:\.[0-9]+)?", c))
        hit = sorted(t for t in toks if Fraction(t) in answers)
        if hit:
            out.append(PieIssue("PIE_PRINTS_ANSWER", "figure %s" % fig["id"],
                                "caption %r states %s" % (c, hit)))
    return out


# --------------------------------------------------------- public side ---
PUBLIC_FRAME_FIELDS = tuple(sorted(set(FRAME_KEYS) | set(PIE_PART_KEYS) |
                                   set(BUILD_PART_KEYS)))


def public_entity(e):
    """The whitelisted public form of a pie entity (project._pub_entity)."""
    keep = ("id", "kind") + ENTITY_KINDS[e["kind"]]
    return dict((k, nfc(e[k])) for k in keep if k in e)


def public_frame(fr):
    """A pie frame is wholly public: it is what the figure prints (no value
    is in it; values live in given facts). A canonical copy."""
    out = {"family": FAMILY, "layout": fr["layout"], "parts": []}
    for k in ("same_size", "shared_legend"):
        if k in fr:
            out[k] = bool(fr[k])
    for p in fr["parts"]:
        q = {}
        for k in sorted(p):
            v = p[k]
            q[k] = list(v) if isinstance(v, list) else (
                nfc(v) if isinstance(v, str) else v)
        out["parts"].append(q)
    return out


def scan_public_pie(pub):
    """Leak / grammar scan of the pie parts of a PUBLIC model (the pie half
    of project.scan_public): entity / fact / frame grammar, no answer, no
    value on a target, captions in their alphabet."""
    ix = PieIndex(pub)
    out = []
    for e in pub.get("entities") or []:
        if is_pie_entity(e):
            out += entity_issues(e)
    for f in pub.get("facts") or []:
        if not is_pie_fact(f):
            continue
        out += fact_issues(f, ix.ents, public=True)
        allowed = {"id", "rel", "args", "role", "item", "source", "value",
                   "unit"}
        for k in f:
            if k not in allowed:
                out.append(PieIssue("PIE_PUBLIC_LEAK", "fact %s" % f.get("id"),
                                    "key %r" % k))
    for g in pub.get("figures") or []:
        if is_pie_figure(g):
            out += frame_issues(ix, g)
    # data validity is not a leak: the renderer refuses invalid data with
    # its named reason (RENDER_PIE_DATA_INVALID), the spec side with
    # spec_issues()
    return [i for i in out if i is not None]


def _unregistered(i, pe, pf, pg):
    """True when a project.scan_public issue exists ONLY because the pie
    family is not (yet) registered in schema / project (the pie scan checks
    that element itself). Nothing else is ever tolerated."""
    code, where, detail = i.code, i.where, str(i.detail)
    if code == "PUBLIC_VALUE_NOT_WHITELISTED":
        if where.startswith("entity ") and where[7:] in pe and \
                detail == "kind/id":
            return True
        if where.startswith("fact ") and where[5:] in pf and \
                detail == "id/rel/role":
            return True
        if where.startswith("figure ") and where[7:] in pg and \
                detail == "frame family %r" % FAMILY:
            return True
    if code == "PUBLIC_KEY_NOT_WHITELISTED":
        if where.startswith("entity ") and where[7:] in pe and \
                detail in PUBLIC_ENTITY_KEYS:
            return True
        if where.startswith("figure ") and where.endswith(" frame") and \
                where[7:-6] in pg and detail in FRAME_KEYS:
            return True
    return False


def public_issues(pub):
    """project.scan_public (the house scan) + scan_public_pie, dropping
    only the house issues that exist because the pie family is not
    registered there yet (see _unregistered)."""
    from . import project as P
    pe = set(e.get("id") for e in pub.get("entities") or []
             if is_pie_entity(e))
    pf = set(f.get("id") for f in pub.get("facts") or [] if is_pie_fact(f))
    pg = set(g.get("id") for g in pub.get("figures") or []
             if is_pie_figure(g))
    house = [i for i in P.scan_public(pub)
             if not _unregistered(i, pe, pf, pg)]
    return house + scan_public_pie(pub)


def public_hash(body):
    return hashlib.sha256(canon.dumps(body).encode("utf-8")).hexdigest()


def public_model(spec):
    """The public model of a PIE-ONLY spec without questions (synthetic
    scenarios, unit tests): constructed from a whitelist, never copied.
    A sheet spec (questions, texts, other families) goes through
    project.public_model once the integrator registers this family.

    Public: every pie / sector / circle a figure lists; every GIVEN pie
    fact about them (the student's data: drawn or stated); every TARGET
    pie fact about them without its value. Never an answer."""
    if spec.get("questions"):
        raise ValueError("pie.public_model takes a spec without questions "
                         "(sheets go through project.public_model)")
    bad = [i for i in spec_issues(spec)]
    if bad:
        raise ValueError("pie spec refused: %s" % "; ".join(
            str(i) for i in bad[:6]))
    ix = PieIndex(spec)
    shown = set()
    figs = []
    for g in spec.get("figures") or []:
        if not is_pie_figure(g):
            raise ValueError("figure %s is not a pie figure" % g.get("id"))
        shown |= set(g.get("entities") or [])
        figs.append({"id": g["id"], "scope": g["scope"],
                     "figure_accuracy": "accurate",
                     "entities": sorted(g.get("entities") or []),
                     "draws": sorted(g.get("draws") or []),
                     "frame": public_frame(g["frame"])})
    for e in list(shown):
        if (ix.ents.get(e) or {}).get("kind") == "sector":
            shown.add(ix.ents[e]["pie"])
    ents = [public_entity(ix.ents[e]) for e in sorted(shown)
            if e in ix.ents]
    facts = []
    for fid in sorted(ix.facts):
        f = ix.facts[fid]
        if f.get("rel") not in RELS or f.get("role") == "answer":
            continue
        if not all(a in shown for a in f.get("args") or []):
            continue
        if f.get("role") not in ("given", "target", "to_construct"):
            continue
        o = {"id": f["id"], "rel": f["rel"], "args": list(f["args"]),
             "role": f["role"], "item": f["item"],
             "source": {"kind": "stated"}}
        if f["role"] == "given" and f.get("value") is not None:
            o["value"] = canon.canon_number(f["value"])
            u = canon.canon_unit(f.get("unit")) if f.get("unit") else None
            if u:
                o["unit"] = u
        facts.append(o)
    body = {"spec_version": spec.get("spec_version", "wspec/1"),
            "sheet": spec["sheet"], "entities": ents, "facts": facts,
            "questions": [], "figures": figs}
    body["public_hash"] = public_hash(body)
    return body


# ------------------------------------------------------ author helpers ---
def make_pie(name, scope, sectors, unit="percent", start=0,
             direction="clockwise", names="in_sector", values="in_sector",
             outside=(), caption=None, fills=None, missing=(), equal=(),
             total=None, item=None, side=None, regions=()):
    """Entities, facts and the frame PART of one pie (author helper; the
    spec author and the runner's translator may use it -- it adds nothing
    and drops nothing). sectors: [(key, label, value or None)] in order;
    value None for a sector in `missing` (target) or in `equal` (share).
    missing / equal / outside / regions name a sector by its label or, when
    labels repeat (names none), by its key. Returns (entities, facts, part,
    drawn fact ids)."""
    item = item or scope
    pid = "pie:" + name
    ents = [{"id": pid, "kind": "pie", "name": name}]
    facts, drawn, order = [], [], []
    ucode = UNIT_OF[unit][0]
    by_label, by_key = {}, {}
    for key, label, _val in sectors:
        by_label.setdefault(label, "sector:%s:%s" % (name, key))
        by_key[key] = "sector:%s:%s" % (name, key)

    def ref(x):
        return by_key[x] if x in by_key else by_label[x]
    miss = set(ref(x) for x in missing)
    for key, label, val in sectors:
        sid = "sector:%s:%s" % (name, key)
        order.append(sid)
        ents.append({"id": sid, "kind": "sector", "pie": pid, "key": key,
                     "name": label})
        if sid in miss:
            f = {"rel": "sector_value", "args": [sid], "role": "target",
                 "item": item, "source": {"kind": "stated"}}
            f["id"] = canon.fact_id(f)
            facts.append(f)
        elif val is not None:
            f = {"rel": "sector_value", "args": [sid], "role": "given",
                 "item": item, "source": {"kind": "stated"},
                 "value": val}
            if ucode is not None:
                f["unit"] = ucode
            f["id"] = canon.fact_id(f)
            facts.append(f)
            if values != "none":
                drawn.append(f["id"])
    if equal:
        args = sorted(ref(x) for x in equal)
        f = {"rel": "sector_equal", "args": args, "role": "given",
             "item": item, "source": {"kind": "stated"}}
        f["id"] = canon.fact_id(f)
        facts.append(f)
        drawn.append(f["id"])
    if total is not None:
        f = {"rel": "pie_total", "args": [pid], "role": "given",
             "item": item, "source": {"kind": "stated"}, "value": total}
        f["id"] = canon.fact_id(f)
        facts.append(f)
        drawn.append(f["id"])
    part = {"part": "pie", "pie": pid, "unit": unit, "order": order,
            "start": start, "direction": direction, "names": names,
            "values": values}
    if side:
        part["side"] = side
    if outside:
        part["outside"] = [ref(x) for x in outside]
    if caption:
        part["caption"] = caption
    if fills:
        part["fills"] = list(fills)
    if regions:
        # (v6.16 r2) the undivided tiles, in the pie's order
        rs = set(ref(x) for x in regions)
        part["regions"] = [s for s in order if s in rs]
    return ents, facts, part, drawn


def make_build(name, centre_dot=False, side=None, caption=None):
    cid = "bcirc:" + name
    part = {"part": "build", "circle": cid, "centre_dot": bool(centre_dot)}
    if side:
        part["side"] = side
    if caption:
        part["caption"] = caption                           # v6.16 r2
    return [{"id": cid, "kind": "build_circle", "name": name}], part


def make_spec(sheet, fig_id, scope, parts, layout="single", same_size=None,
              shared_legend=None):
    """A pie-only spec from make_pie / make_build results:
    parts = [("pie", (ents, facts, part, drawn)) | ("build", (ents, part))]
    (v6.16 r2) layout "row": the parts in READING order, right to left (the
    first part is the rightmost disc), same_size=True."""
    ents, facts, fparts, draws = [], [], [], []
    for kind, res in parts:
        if kind == "pie":
            e, f, p, d = res
            ents += e
            facts += f
            fparts.append(p)
            draws += d
        else:
            e, p = res
            ents += e
            fparts.append(p)
    fr = {"family": FAMILY, "layout": layout, "parts": fparts}
    if same_size is not None:
        fr["same_size"] = bool(same_size)
    if shared_legend is not None:
        fr["shared_legend"] = bool(shared_legend)
    fig = {"id": fig_id, "scope": scope, "figure_accuracy": "accurate",
           "entities": sorted(e["id"] for e in ents), "draws": sorted(draws),
           "frame": fr}
    return {"spec_version": "wspec/1", "sheet": sheet, "entities": ents,
            "facts": facts, "questions": [], "figures": [fig]}


# ------------------------------------------ discs (v6.16 r2, AAF1 R-A3) ---
def _disc_parts(fig):
    """the parts of a pie figure in READING order right to left (d1 = the
    rightmost disc): a row in its order, a pair right part first"""
    fr = fig["frame"]
    parts = list(fr.get("parts") or [])
    if fr.get("layout") == "side_by_side":
        parts.sort(key=lambda p: 0 if p.get("side") == "right" else 1)
    return parts


def _declared_num(v):
    """a value as the corpus writes it: an int when whole, else a string"""
    v = Fraction(v)
    if v.denominator == 1:
        return int(v)
    return decimal_text(v) or "%d/%d" % (v.numerator, v.denominator)


def figure_discs(spec, figure_id):
    """(v6.16 r2) the figure's discs in the corpus-neutral shape of the pie
    corpus ADDENDUM 1 baseline.discs, read right to left: [{disc "d1..",
    state drawn | empty, caption, entity; empty: center_dot; drawn: unit,
    start_deg_clockwise_from_12, direction, tiles [{tile "t1..", type wedge
    | region, sector (its id: discs_to_spec needs it), declared (a number |
    "rest" | "equal"), resolved_value, span_deg_exact "n/d", missing; a
    wedge: name_label, value_label; a region: label}]}]. Read from the
    public spec only (what the figure prints; no answer is in it)."""
    ix = spec if isinstance(spec, PieIndex) else PieIndex(spec)
    fig = ix.figures.get(figure_id)
    if not is_pie_figure(fig):
        raise ValueError("figure %r is not a pie figure" % (figure_id,))
    drawn = set(fig.get("draws") or [])
    out = []
    for i, p in enumerate(_disc_parts(fig)):
        d = {"disc": "d%d" % (i + 1), "caption": p.get("caption") or None}
        if p.get("part") == "build":
            d.update({"state": "empty", "entity": p.get("circle"),
                      "center_dot": bool(p.get("centre_dot"))})
            out.append(d)
            continue
        r = resolve(ix, p)
        regs = set(p.get("regions") or [])
        d.update({"state": "drawn", "entity": p.get("pie"),
                  "unit": p.get("unit"),
                  "start_deg_clockwise_from_12": p.get("start"),
                  "direction": p.get("direction"), "tiles": []})
        if p.get("names") == "legend":
            d["legend"] = [(ix.ents.get(s) or {}).get("name")
                           for s in r.order]
        if r.problems:
            d["problems"] = sorted(set(c for c, _d in r.problems))
        for k, s in enumerate(r.order):
            v, src = r.value.get(s), r.source.get(s)
            t = {"tile": "t%d" % (k + 1),
                 "type": "region" if s in regs else "wedge", "sector": s,
                 "declared": _declared_num(v) if src == "given" and
                 v is not None else (src or "rest"),
                 "missing": bool(ix.facts_about(s, "sector_value",
                                                 ("target",)))}
            if v is not None:
                sp = v * Fraction(360) / r.total
                t["resolved_value"] = decimal_text(v) or "%d/%d" % (
                    v.numerator, v.denominator)
                t["span_deg_exact"] = "%d/%d" % (sp.numerator, sp.denominator)
            vl = None
            if p.get("values") == "in_sector":
                for f in ix.facts_about(s, "sector_value", ("given",)):
                    if f["id"] in drawn:
                        vl = value_label(_q(f.get("value")), p.get("unit"))
            if s in regs:
                t["label"] = vl
            else:
                t["name_label"] = (ix.ents.get(s) or {}).get("name") if \
                    p.get("names") == "in_sector" else None
                t["value_label"] = vl
            d["tiles"].append(t)
        out.append(d)
    return out


def discs_to_spec(spec, figure_id, discs):
    """(v6.16 r2) the PUBLIC model with the figure's discs replaced by
    `discs` (figure_discs' shape, edited: a tile's declared value, the
    tiles' order -- each tile keeps its "sector" --, start, direction,
    caption, an empty disc's centre dot), re-hashed and re-scanned. For the
    runner's PM28-PM30 data mutations of an ADDENDUM 1 figure. A disc keeps
    its state, unit and sectors (else ValueError); a tile declared "equal"
    joins the ONE equal group of its pie (one sector_equal over them when
    two or more), "rest" has no value. Nothing outside the figure's pie
    facts / frame changes."""
    import copy
    pub = copy.deepcopy(spec)
    figs = [g for g in pub.get("figures") or [] if g.get("id") == figure_id]
    if not figs or not is_pie_figure(figs[0]):
        raise ValueError("figure %r is not a pie figure" % (figure_id,))
    fig = figs[0]
    seq = _disc_parts(fig)
    if len(discs) != len(seq):
        raise ValueError("%d discs for %d parts" % (len(discs), len(seq)))
    facts = pub.setdefault("facts", [])
    draws = set(fig.get("draws") or [])
    for d, p in zip(discs, seq):
        empty = (d.get("state") or "drawn") == "empty"
        if empty != (p.get("part") == "build"):
            raise ValueError("%s: a disc keeps its state" % d.get("disc"))
        if d.get("caption"):
            p["caption"] = d["caption"]
        else:
            p.pop("caption", None)
        if empty:
            p["centre_dot"] = bool(d.get("center_dot"))
            continue
        if d.get("unit") not in (None, p.get("unit")):
            raise ValueError("%s: a disc keeps its unit" % d.get("disc"))
        tiles = d.get("tiles") or []
        sids = [t.get("sector") for t in tiles]
        if sorted(s for s in sids if s) != sorted(p.get("order") or []) or \
                None in sids:
            raise ValueError("%s: the tiles must carry the pie's sectors "
                             "(figure_discs 'sector')" % d.get("disc"))
        if p.get("fills"):
            fill = dict(zip(p["order"], p["fills"]))
            p["fills"] = [fill[s] for s in sids]
        p["order"] = sids
        st = Fraction(str(d.get("start_deg_clockwise_from_12") or 0)) % 360
        if st.denominator != 1:
            raise ValueError("%s: start %s is not whole degrees"
                             % (d.get("disc"), st))
        p["start"] = int(st)
        if d.get("direction"):
            p["direction"] = d["direction"]
        regs = [t["sector"] for t in tiles if t.get("type") == "region"]
        if regs:
            p["regions"] = regs
        else:
            p.pop("regions", None)
        ucode = UNIT_OF[p["unit"]][0]
        mine = set(sids)
        old = dict((f["args"][0], f) for f in facts
                   if f.get("rel") == "sector_value" and
                   f.get("role") == "given" and
                   (f.get("args") or [None])[0] in mine)
        olde = [f for f in facts if f.get("rel") == "sector_equal" and
                f.get("role") == "given" and set(f.get("args") or []) <=
                mine]
        mfacts = [f for f in facts if set(f.get("args") or []) & mine]
        item = (mfacts[0] if mfacts else {}).get("item") or fig.get("scope")
        gone = set(f["id"] for f in list(old.values()) + olde)
        facts[:] = [f for f in facts if f.get("id") not in gone]
        draws -= gone
        eq = sorted(t["sector"] for t in tiles if str(t.get("declared")) ==
                    "equal")
        for t in tiles:
            dcl = t.get("declared")
            if str(dcl) in ("rest", "equal"):
                continue
            v = Fraction(str(dcl))
            f = dict(old.get(t["sector"]) or {
                "rel": "sector_value", "args": [t["sector"]],
                "role": "given", "item": item,
                "source": {"kind": "stated"}})
            f.pop("id", None)
            f["value"] = canon.canon_number(str(v))
            if ucode is not None:
                f["unit"] = ucode
            else:
                f.pop("unit", None)
            f["id"] = canon.fact_id(f)
            facts.append(f)
            if p.get("values") != "none":
                draws.add(f["id"])
        if len(eq) >= 2:
            f = dict(olde[0]) if olde else {
                "rel": "sector_equal", "role": "given", "item": item,
                "source": {"kind": "stated"}}
            f.pop("id", None)
            f["args"] = eq
            f["id"] = canon.fact_id(f)
            facts.append(f)
            draws.add(f["id"])
    fig["draws"] = sorted(draws)
    # the public model's order: facts by id (project / pie public_model)
    facts.sort(key=lambda f: f.get("id") or "")
    pub.pop("public_hash", None)
    pub["public_hash"] = public_hash(pub)
    bad = public_issues(pub)
    if bad:
        raise ValueError("discs_to_spec: public model refused: %s" % "; ".join(
            str(i) for i in bad[:5]))
    return pub


# ------------------------------------------------------------ registry ---
REGISTRY = {
    "family": FAMILY,
    "entity_kinds": dict((k, list(v)) for k, v in ENTITY_KINDS.items()),
    "entity_refs": dict((k, list(v)) for k, v in ENTITY_REFS.items()),
    "public_entity_keys": list(PUBLIC_ENTITY_KEYS),
    "rels": dict((k, {"args": list(v["args"]), "roles": list(v["roles"]),
                      "units": list(v["units"])}) for k, v in RELS.items()),
    "frame_keys": sorted(FRAME_KEYS),
    "part_keys": {"pie": sorted(PIE_PART_KEYS),
                  "build": sorted(BUILD_PART_KEYS)},
    "reasons": sorted(PIE_REASONS),
    "hooks": {
        "canon.entity_id": "pie.entity_id(e) for kinds pie / sector / "
                           "build_circle",
        "schema.validate": "pie.spec_issues(spec) (PieIssue, codes "
                           "PIE_REASONS)",
        "project.public_model": "pie.public_entity(e), pie.public_frame(fr)",
        "project.scan_public": "pie.scan_public_pie(pub)",
        "render.engine.render": "frame.family == 'pie_chart' -> "
                                "render.pie.render(public, settings, "
                                "render.pie.ENGINE_VERSION)",
        "check.check_figure": "pie figure -> check.pie.check_pie(...)",
        "check.object_report": "report family 'pie_chart' -> "
                               "check.pie.object_report",
        "check.check_highlight": "report family 'pie_chart' -> "
                                 "check.pie_hl.check_highlight",
    },
}
