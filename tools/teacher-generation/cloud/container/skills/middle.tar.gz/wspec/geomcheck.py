# -*- coding: utf-8 -*-
"""Independent geometry check of a FINISHED svg against the spec (C5),
inside a CLOSED SVG DIALECT (addendum S1).

The figure is produced by OUR renderer from the spec, so this check does
not try to understand arbitrary SVG. svg_dialect.json lists the exact
subset the renderer emits: the elements (svg, g, line, circle, polygon,
polyline, path with absolute M/L/Z only, text), the attributes of each,
and the values (a closed paint palette, fixed stroke widths, dash styles
by name, point radii, font sizes, a closed text alphabet, a strict number
grammar with at most two decimals, a bounded canvas and nesting depth).
Anything outside it -- style, <style>, class, transform, vector-effect,
pathLength, stroke-dashoffset, opacity, filters, masks, clips, markers,
use, defs, nested svg, other namespaces, relative or curved path commands,
a DOCTYPE, a coordinate off the canvas -- is refused with GEOM_DIALECT,
naming the element and the attribute. Such a file is not measured at all.
The dialect file itself is pinned by hash (APPROVED_DIALECT_SHA256), like
the template set: an edited svg_dialect.json is refused until re-approved.

Inside the dialect nothing can move, hide, scale or fade what an element's
own attributes say: there is no inheritance (a <g> carries no
presentation), no transform, no CSS, one user unit is one px (width /
height, when given, equal the viewBox size) and everything lies on the
canvas. So the check reads each element's attributes literally, from the
ORIGINAL file bytes. It imports neither the renderer nor svgnorm:
normalisation rounds coordinates for the reproducibility compare, and
rounding could hide a defect. Tolerances are fixed, named and documented
here; they are not parameters.

EVERY PAINTED ELEMENT IS HOOKED (wspec-svg/2; verifier dialect r2,
VD2-01/02: an unhooked right-angle mark, equality ticks, a second copy of a
segment, a second outline, a guide circle or a fake dot was neither
resolved nor measured). Each painted element carries exactly ONE hook
naming what of the spec it draws; an unhooked one is GEOM_DIALECT:
  <circle data-pt="A">      a point (the only circle: a dot);
  <line data-seg="AB">      a segment (AB and BA are the SAME hook);
  <line data-line="AB">     a line of the spec, drawn through A and B;
  <line data-ray="AB">      a ray of the spec, from A past B;
  <polygon data-poly="ABCD"> a polygon of the spec (outline or shade);
  data-mark="<kind>[n] <ref>" a MARK on an object: 'arc ACB' / 'arc2 ACB'
      (path / polyline: an arc of the angle at its vertex), 'right ABC'
      (path / polyline: a right-angle mark), 'tick BM' / 'tick2 BM' (line:
      a tick across the segment).
Every hook is RESOLVED against the figure: it must name an object the
figure shows (listed, drawn on by a drawn fact, or -- for a segment /
polygon / angle -- drawn as sides / arms, see baseline._object_drawn), else
GEOM_HOOK_UNKNOWN; and every hook is MEASURED. Two different marked points
closer than NEAR_POINT_PX read as one (GEOM_POINTS_TOO_CLOSE).

MARKS say something, so what they say is checked (GEOM_MARK_UNSUPPORTED):
a right-angle mark claims its angle is 90 degrees, and marks of the same
kind and count (every 'tick2', every 'arc') claim their objects EQUAL. The
claim must follow from the facts the READER of the figure sees -- the
facts it draws and the given / context facts of its visible scopes, each
public (project.eligible) -- by the closed rules of _claims_seen (equal
values, equal_length / equal_angle, a midpoint's halves, the sides of a
shape class, the right angles of a perpendicular / rectangle). So a
figure cannot print a to_prove or an answer as marks. And every mark is
measured (GEOM_MARK_OFF): an arc lies on one circle about the vertex from
arm to arm, a right-angle mark is a square corner along both drawn arms
of an angle drawn at 90 degrees, a tick crosses the middle of its drawn
segment; n marks of a count-n mark are n distinct strokes.

WHAT IS MEASURED. Every point, segment, line and ray the figure lists or
a drawn fact is drawn on (GEOM_MISSING_ELEMENT when not hooked, never
skipped silently); every hook; and every relation of the spec, by the
closed table MEASURE below, which names EVERY relation of schema.RELS: an
incidence (midpoint, on_segment) in any figure, a metric relation (angles,
parallel / perpendicular, equal lengths / angles, ratio, shape classes
such as rectangle, congruence, one common scale for all lengths) in an
`accurate` figure only -- or a declared reason why it is not measured. A
relation is measured when the figure draws it, or when it is a visible
given/context fact whose points the figure shows.

LABELS. What a <text> labels is read from its TEXT, resolved against the
spec: the name of a point the figure shows (then it must be printed next
to THAT point: within LABEL_NEAR_PX and nearer to it than to any other
point), or the value of a fact the figure draws (then it must be printed
at that fact's object: inside its angle, beside its segment, inside its
polygon). Any other text is GEOM_LABEL_MISMATCH -- so a figure can print
neither a swapped name nor a value the spec does not show (an answer, a
target's value). A label box may not cover a point. Every dot on the
page is a hooked point, so "nearest point" sees every dot there is.

Limits (documented): the glyph box of a label is an estimate from its
font size and length; axes, ticks, grids and legends have no hooks in the
dialect, and neither do circles and arcs of circles (a circle entity has
no radius relation to measure it by) -- a figure that lists one is
refused (GEOM_MISSING_ELEMENT) until the dialect gains them; a mark names
its object by the spec's names (an angle marked as MCB is not the same
object as ACB, even with M on CA), so an equality written with other
names is refused, never passed; isosceles and congruence give no
equality of marks (which sides is not stated)."""
import hashlib
import json
import math
import os
import re
import xml.etree.ElementTree as ET

from . import bidi as BIDI
from . import schema as S
from .errors import Issue

# Two ends the spec says coincide (a segment end on its point) are written
# by the renderer from ONE computed float at 2 decimals (the dialect's
# number grammar), so an honest pair differs by <= 0.01 px. 0.05 px leaves
# 5x headroom and stays 8x below a 0.4 px gap, which is a real defect (a
# visible break when zoomed/printed).
JOIN_TOL_PX = 0.05
# Incidence (a point on a segment, a midpoint): same reasoning -- computed
# positions printed at 2 decimals; anything beyond 0.05 px is a defect.
ON_TOL_PX = 0.05
# An `accurate` figure promises a protractor reading equal to the value:
# coordinates at 2 decimals on arms >= 20 px bound the error to ~0.03 deg;
# 0.5 deg is the promise ("reads as the right whole degree"). The same
# tolerance holds for parallel / perpendicular / equal angles and for the
# angles of a shape class (a rectangle's 90 deg), for the square corner of
# a right-angle mark and for the points of an arc staying in its angle.
ANGLE_TOL_DEG = 0.5
# Arms (and sides) shorter than this cannot carry an angle measurement.
MIN_ARM_PX = 1.0
# Two lengths the spec says are equal: each end is printed at 2 decimals,
# so a length is off by <= 0.015 px and a difference by <= 0.03 px; 0.1 px
# leaves 3x headroom and stays 4x below a 0.4 px defect.
LEN_TOL_PX = 0.1
# An accurate figure is drawn to ONE scale: every length / perimeter /
# area value of the figure gives px-per-unit, and they agree within 1 %
# (an honest figure at 2 decimals on lengths >= 5 px is within 0.3 %). A
# ratio is held to the same relative tolerance.
SCALE_TOL_REL = 0.01
# A point marker smaller than this radius is not a visible dot (a dialect
# invariant: every point radius of svg_dialect.json is at least this).
MIN_MARK_PX = 0.5
# A stroke thinner than this is not a visible line on paper (a dialect
# invariant: every stroke width of svg_dialect.json is at least this).
MIN_STROKE_PX = 0.1
# Two DIFFERENT marked points this close read as one.
NEAR_POINT_PX = 4.0
# The estimated glyph box of a label: each character GLYPH_W x GLYPH_H of
# the font size (an average for Latin capitals, digits and Hebrew letters;
# the baseline is the text's y). It is an estimate, used only for the
# label's centre and for "a label covers a point".
GLYPH_W = 0.6
GLYPH_H = 0.7
# A point's name is printed next to it: its estimated centre within this
# distance (a 16 px glyph beside a 2.5 px dot fits well inside).
LABEL_NEAR_PX = 24.0
# A value is printed at its object: inside its angle within this distance
# of the vertex, or within LABEL_NEAR_PX of its segment.
LABEL_VALUE_PX = 60.0
# MARKS (wspec-svg/2). An arc's radius: at least twice the near-point zone
# (so an arc never reads as a dot or a second point at the vertex) and at
# most what still reads as a mark of the vertex, not a circle of the
# figure (it is shorter than both arms: its ends lie on the drawn arms).
ARC_MIN_R_PX = 2 * NEAR_POINT_PX
ARC_MAX_R_PX = 40.0
# A right-angle mark's legs: long enough to read as a square (> the widest
# stroke and the near-point zone), short enough to stay a mark.
RIGHT_MIN_PX = 5.0
RIGHT_MAX_PX = 20.0
# A tick: its length (longer than the widest stroke, so never a dot); it
# crosses the segment at no less than TICK_MIN_DEG, within TICK_SPREAD_PX
# of the segment's middle (where a reader looks for it).
TICK_MIN_PX = 4.0
TICK_MAX_PX = 16.0
TICK_MIN_DEG = 45.0
TICK_SPREAD_PX = 10.0
# The n strokes of a count-n mark (two ticks, two arcs) are this far apart
# (tick centres / arc radii): closer, they print as one mark -- the count a
# reader sees would not be the count the file claims.
MARK_GAP_PX = 2.0
# LABELS (close_gaps 2026-09-23, verifier dialect r3 VD3-01/03/04). A drawn
# straight piece may cross a label's estimated glyph box for at most this
# length: a stroke that clips a corner of the box of a letter beside its
# vertex is normal (the box is a generous estimate), one that runs through
# the text makes it unreadable.
LABEL_STROKE_TOL_PX = 2.0
# A value label reads as ITS object only when every other candidate is
# farther by at least this margin (the nearest point, for an angle's value;
# the nearest drawn piece, for a segment's value): a tie is ambiguous.
LABEL_MARGIN_PX = 2.0
# A segment's value is printed beside its middle part: the foot of the
# label's centre on the segment lies within [f, 1 - f] of its length (at
# an end it reads as the value of the neighbouring piece).
LABEL_SEG_END_FRAC = 0.1
# An arc mark is a polyline ON its circle (VD3-02): every chord between two
# consecutive samples stays within this of the circle (the chord's
# sagitta, r * (1 - cos(step / 2))). A 5-step arc of radius 18 over 90 deg
# strays 0.22 px; a straight chord over the same arc strays 5.3 px.
ARC_SAGITTA_PX = 0.5
# A line is drawn past both of its points, a ray past its second point, by
# at least this much (SV3-03/05: segment, line and ray are told apart on
# the page -- drawn only between its points, a line or a ray prints as a
# segment). A segment's ends are its points (JOIN_TOL_PX).
LINE_OVERHANG_PX = 6.0
# a parallel arrow (par mark, wspec-svg/4): a chevron of two legs of
# PAR_LEG_MIN_PX..PAR_LEG_MAX_PX, each PAR_MIN_DEG..PAR_MAX_DEG off the
# segment, symmetric about it (the legs' ends mirror each other within
# JOIN_TOL_PX-scale rounding: their midpoint on the segment within
# ON_TOL_PX), its tip on the segment within TICK_SPREAD_PX of the middle
PAR_LEG_MIN_PX = 3.0
PAR_LEG_MAX_PX = 10.0
PAR_MIN_DEG = 20.0
PAR_MAX_DEG = 60.0
# its two legs are equally long (a lopsided chevron reads as a scribble)
PAR_LEG_DIFF_PX = 0.5

HERE = os.path.dirname(os.path.abspath(__file__))
DIALECT_JSON = os.path.join(HERE, "svg_dialect.json")
SVG_NS = "http://www.w3.org/2000/svg"
XML_DECL = '<?xml version="1.0" encoding="UTF-8"?>'
# sha256 of the canonical JSON of svg_dialect.json -- the approval of the
# dialect's closed lists (verifier tests r1, VT-01: an added attribute or
# value used to pass every test). Changing any entry voids it
# (DialectError at import) until the author re-approves. Approved
# 2026-09-23 BY THE FIXER, NOT THE AUTHOR (fix structural r2: wspec-svg/2,
# every painted element hooked, marks, max_depth, circles are dots only);
# awaits the author. Re-approved 2026-09-23 BY THE FIXER (close_gaps:
# wspec-svg/3 -- data-for on every label, data-layer a closed list,
# data-label removed; see svg_dialect.json "about"); awaits the author.
# Re-pinned 2026-09-23 BY THE RENDERER BUILDER, an agent -- NOT a human
# approval (build_renderer: wspec-svg/4 -- optional element ids e0001..,
# numbered in document order, all or none; and the mark kind par, parallel
# arrows); awaits the author.
# Re-pinned 2026-09-23 BY THE SKILL INTEGRATOR, an agent -- NOT a human
# approval (v6.9 skill integration: font_families gains 'David Libre,serif',
# the house print face the worksheet PDF requires; font_sizes gains 10.67
# and 12.67, the sheet's number / letter sizes; previous set
# a452db07...d19e); awaits the author.
# Re-pinned 2026-09-23 BY THE v6.9 FIX-ROUND-2 AGENT -- NOT a human approval
# (wspec-svg/5, E1b: a label with a Hebrew letter carries direction="ltr"
# unicode-bidi="bidi-override" and stores its text in visual order, because
# WeasyPrint prints SVG text without bidi; and P4: point radius 0.75, the
# CORNER dot, only where >= 2 solid normal strokes end at an angle -- the
# builder's look without a dot on a vertex; previous set 83c5b6bd...d5c9);
# awaits the author.
# v6.18 H-A2 user-authorized extension; previous pin 9f58d449...5456e.
APPROVED_DIALECT_SHA256 = \
    "2dc643eb8d906c1f287f62e08bbf70dcaad53a72b06b12f1abc983e811381b3f"
# glyphs that print as a dot or a point in some script; the text alphabet
# must hold none of them (a load-time invariant, a backstop to the closed
# alphabet itself)
DOT_LIKE = u"•·∙●○◦⋅∘⦁" \
    u"⚫⬤.,:;٠۰・‧。．｡܁" \
    u"܂ִׅׄ˙․⸳⸱º"
# a mark's object kind -> how many names its ref has
MARK_REF_NAMES = {"angle": 3, "segment": 2}


class DialectError(Exception):
    """The dialect file itself breaks one of its invariants."""


def _visible(hexcol):
    h = hexcol[1:]
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    return min(int(h[i:i + 2], 16) for i in (0, 2, 4)) < 0xF0


def dialect_hash(data):
    return hashlib.sha256(json.dumps(
        data, sort_keys=True, ensure_ascii=False,
        separators=(",", ":")).encode("utf-8")).hexdigest()


def _alphabet(d):
    a = d["text_alphabet"]
    letters = set()
    for lo, hi in a["ranges"]:
        letters |= set(chr(c) for c in range(ord(lo), ord(hi) + 1))
    return letters, letters | set(a["singles"]), set(a["between_digits"])


def load_dialect(path=DIALECT_JSON, approved=APPROVED_DIALECT_SHA256):
    """svg_dialect.json, with its invariants checked (DialectError): a dash
    never draws a dot (every dash of every style is longer than the widest
    stroke), every paint but none is visible on paper, every point radius
    and stroke width is visible, the alphabet holds no dot-like glyph, the
    canvas and the nesting depth are bounded, every painted element has a
    hook and every mark kind names elements that take data-mark -- and its
    hash is the approved one (approved=None skips only the hash, to test
    the invariants)."""
    with open(path, encoding="utf-8") as fh:
        d = json.load(fh)
    widths = [float(v) for v in d["stroke_widths"].values()]
    if min(widths) < MIN_STROKE_PX:
        raise DialectError("a stroke width below MIN_STROKE_PX")
    for name, v in d["dash_styles"].items():
        if v == "none":
            continue
        vals = [float(x) for x in v.split(" ")]
        if len(vals) != 2 or min(vals) <= 0:
            raise DialectError("dash style %s=%r is not 'dash gap'"
                               % (name, v))
        if vals[0] <= max(widths):
            raise DialectError("dash style %s=%r: a dash no longer than the "
                               "widest stroke draws a dot" % (name, v))
    for name, v in d["paint"].items():
        if v != "none" and not (re.match(r"^#[0-9a-f]{6}\Z", v) and
                                _visible(v)):
            raise DialectError("paint %s=%r is not a visible #rrggbb"
                               % (name, v))
    if min(float(r) for r in d["point_radii"]) < MIN_MARK_PX:
        raise DialectError("a point radius below MIN_MARK_PX")
    letters, alpha, between = _alphabet(d)
    bad = sorted((alpha & set(DOT_LIKE)) | (between - set(".")))
    if bad:
        raise DialectError("text alphabet holds dot-like glyph(s) %r" % bad)
    if not (0 < float(d["canvas_max_px"]) <= 10000):
        raise DialectError("canvas_max_px must be in (0, 10000]")
    if not (2 <= int(d["max_depth"]) <= 32):
        raise DialectError("max_depth must be in [2, 32]")
    for t in PAINTED:
        if not d["elements"][t]["hooks"]:
            raise DialectError("<%s> paints but takes no hook" % t)
    for k, m in d["marks"].items():
        if m["ref"] not in MARK_REF_NAMES or not m["elements"] or any(
                "data-mark" not in d["elements"][t]["hooks"]
                for t in m["elements"]):
            raise DialectError("mark %r: its ref kind or elements" % k)
    if approved is not None and dialect_hash(d) != approved:
        raise DialectError("svg_dialect.json is not the approved dialect "
                           "(sha256 %s != APPROVED_DIALECT_SHA256); an edit "
                           "is void until re-approved" % dialect_hash(d))
    # (close_gaps VD3-05) no attribute takes a free token: every attribute
    # an element allows is described in attribute_values, and none of them
    # as a bare token -- ids, titles and data-* cannot carry text
    for t, spec_ in d["elements"].items():
        for k in spec_["required"] + spec_["optional"]:
            v = d["attribute_values"].get(k)
            if v is None or v.split(" ")[0] == "token":
                raise DialectError("attribute %r of <%s> is not grammar-"
                                   "restricted" % (k, t))
    tok = re.compile(d["grammar"]["token"].replace("$", r"\Z"))
    if not d["layers"] or not all(tok.match(x) for x in d["layers"]):
        raise DialectError("layers must be tokens")
    d["_num"] = re.compile(d["grammar"]["number"].replace("$", r"\Z"))
    d["_name"] = re.compile(d["grammar"]["name"].replace("$", r"\Z"))
    d["_token"] = re.compile(d["grammar"]["token"].replace("$", r"\Z"))
    d["_id"] = re.compile(d["grammar"]["element_id"].replace("$", r"\Z"))
    n = d["grammar"]["name"][1:-1]
    d["_seg"] = re.compile(r"^(%s)(%s)\Z" % (n, n))
    d["_poly"] = re.compile(r"^(?:%s){3,}\Z" % n)
    d["_one"] = re.compile(n)
    # a label's source (close_gaps VD3-01): a point name, or the object
    # whose value it prints
    d["_for"] = re.compile(r"^(?:(%s)|(ang) ((?:%s){3})|(seg) ((?:%s){2})|"
                           r"(poly) ((?:%s){3,})|(line) ((?:%s){2}))\Z" % (n, n, n, n, n))
    d["_mark"] = re.compile(r"^(%s)(%s)? ((?:%s)+)\Z" % (
        "|".join(sorted(d["marks"])), "|".join(d["mark_counts"]), n))
    d["_dashes"] = dict((v, k) for k, v in d["dash_styles"].items()
                        if v != "none")
    d["_letters"], d["_alpha"], d["_between"] = letters, alpha, between
    d["_canvas"] = float(d["canvas_max_px"])
    d["_depth"] = int(d["max_depth"])
    return d


# the elements that paint (every one of them takes exactly one hook)
PAINTED = ("line", "circle", "polygon", "polyline", "path")
DIALECT = load_dialect()
PAINT = DIALECT["paint"]
PAINT_NAME = dict((v, k) for k, v in PAINT.items())
# which paints each element may use (by name); see attribute_values
STROKE_OK = {"line": ("ink", "guide"), "polyline": ("ink", "guide"),
             "path": ("ink", "guide"), "circle": ("none",),
             "polygon": ("ink", "guide", "none")}
FILL_OK = {"circle": ("ink",), "polygon": ("none", "shade"),
           "polyline": ("none",), "path": ("none",), "text": ("ink",)}
CLOSED_LISTS = {"stroke-linecap": "linecaps", "stroke-linejoin": "linejoins",
                "font-size": "font_sizes", "font-family": "font_families",
                "text-anchor": "text_anchors"}
NUM_ATTRS = ("x1", "y1", "x2", "y2", "cx", "cy", "x", "y")
HOOKS = ("data-pt", "data-seg", "data-line", "data-ray", "data-poly",
         "data-mark")


class Dialect(Exception):
    """One violation of the dialect (element + attribute named)."""


def _num(s, what, d=DIALECT):
    if not isinstance(s, str) or not d["_num"].match(s):
        raise Dialect("%s=%r is not a number of the dialect grammar"
                      % (what, s))
    return float(s)


def _points(s):
    """'x,y x,y ...' with ONE space between pairs."""
    out = []
    for pair in s.split(" "):
        xy = pair.split(",")
        if len(xy) != 2:
            raise Dialect("points=%r is not 'x,y x,y ...'" % s[:40])
        out.append((_num(xy[0], "points"), _num(xy[1], "points")))
    return out


def _path(s):
    """'M x y L x y ... [Z]' -> (points, closed)."""
    tok = s.split(" ")
    closed = bool(tok) and tok[-1] == "Z"
    if closed:
        tok = tok[:-1]
    if len(tok) < 6 or len(tok) % 3 or tok[0] != "M":
        raise Dialect("d=%r is not 'M x y L x y ... [Z]'" % s[:40])
    out = []
    for i in range(0, len(tok), 3):
        if tok[i] != ("M" if i == 0 else "L"):
            raise Dialect("d=%r: command %r (only absolute M, L, Z; one "
                          "subpath)" % (s[:40], tok[i]))
        out.append((_num(tok[i + 1], "d"), _num(tok[i + 2], "d")))
    return out, closed


def _no_repeat(pts, closed, what):
    for i in range(len(pts) - 1):
        if pts[i] == pts[i + 1]:
            raise Dialect("%s: point %d repeats the one before (degenerate)"
                          % (what, i + 1))
    if closed and pts[0] == pts[-1]:
        raise Dialect("%s: the last point repeats the first (degenerate)"
                      % what)


def _label_text(el):
    """The CLOSED text alphabet (verifier dialect r1, D5: a blocklist of
    dot glyphs let U+0660 and friends through). A child element is named
    first (verifier dialect r2, VD2-04: <tspan dx> read as 'no letter').
    wspec-svg/5 (E1b): a label with a Hebrew letter carries the bidi
    override and stores its text in visual order; without one, neither."""
    for c in el:
        raise Dialect("element <%s> inside <text> is outside the dialect "
                      "(a label is plain text)" % _tag(c))
    t = el.text or ""
    why = BIDI.attrs_issue(t, el.attrib)
    if why:
        raise Dialect("text %r: %s" % (t, why))
    if not any(c in DIALECT["_letters"] for c in t):
        raise Dialect("text %r has no letter or digit of text_alphabet" % t)
    for i, c in enumerate(t):
        if c in DIALECT["_alpha"]:
            continue
        if c in DIALECT["_between"] and 0 < i < len(t) - 1 and \
                t[i - 1] in "0123456789" and t[i + 1] in "0123456789":
            continue
        raise Dialect("text %r: glyph %r (U+%04X) outside text_alphabet"
                      % (t, c, ord(c)))


def _logical_text(el):
    """A label's text in LOGICAL order (wspec-svg/5: a Hebrew label is
    stored in visual order under the bidi override)."""
    t = el.text or ""
    return BIDI.logical(t) if BIDI.is_override(el.attrib) else t


def _tag(el):
    t = el.tag
    if t.startswith("{"):
        ns, t = t[1:].split("}", 1)
        if ns == SVG_NS:
            return t
        return "{%s}%s" % (ns, t)
    return "{}" + t                       # no namespace: not SVG


def _on_canvas(t, a, box):
    """Everything lies inside the viewBox (verifier dialect r1, D4: a
    figure drawn off the page, or clipped, used to pass)."""
    W, H = box

    def inside(x, y, r=0.0):
        return r <= x <= W - r and r <= y <= H - r
    if t == "line":
        pts = [(float(a["x1"]), float(a["y1"])),
               (float(a["x2"]), float(a["y2"]))]
    elif t == "circle":
        if not inside(float(a["cx"]), float(a["cy"]), float(a["r"])):
            raise Dialect("circle (cx, cy, r) reaches outside the viewBox "
                          "0 0 %g %g" % box)
        return
    elif t in ("polygon", "polyline"):
        pts = _points(a["points"])
    elif t == "path":
        pts = _path(a["d"])[0]
    elif t == "text":
        pts = [(float(a["x"]), float(a["y"]))]
    else:
        return
    for x, y in pts:
        if not inside(x, y):
            raise Dialect("point (%g, %g) outside the viewBox 0 0 %g %g"
                          % ((x, y) + box))


def _check_hook(t, spec, a):
    """Exactly ONE hook on a painted element, well-formed (verifier dialect
    r2, VD2-01/02: an unhooked stroke / dot / outline was never resolved
    nor measured)."""
    hooks = [k for k in HOOKS if k in a]
    if spec["hooks"] and len(hooks) != 1:
        raise Dialect("%s <%s>: every painted element carries exactly one "
                      "hook of %s" % ("an unhooked" if not hooks else
                                      "a doubly hooked", t,
                                      "/".join(spec["hooks"])))
    for k in hooks:
        v = a[k]
        if k == "data-pt":
            ok = DIALECT["_name"].match(v)
        elif k in ("data-seg", "data-line", "data-ray"):
            m = DIALECT["_seg"].match(v)
            ok = m and m.group(1) != m.group(2)
        elif k == "data-poly":
            ok = DIALECT["_poly"].match(v)
        else:
            m = DIALECT["_mark"].match(v)
            ok = m is not None
            if ok:
                mk = DIALECT["marks"][m.group(1)]
                names = DIALECT["_one"].findall(m.group(3))
                if t not in mk["elements"]:
                    raise Dialect("data-mark=%r: a %s mark is drawn as <%s>"
                                  % (v, m.group(1), "> or <".join(
                                      mk["elements"])))
                if m.group(2) and not mk["counted"]:
                    raise Dialect("data-mark=%r: a %s mark has no count"
                                  % (v, m.group(1)))
                if len(names) != MARK_REF_NAMES[mk["ref"]] or \
                        len(set(names)) != len(names):
                    raise Dialect("data-mark=%r: a %s is %d different "
                                  "names" % (v, mk["ref"],
                                             MARK_REF_NAMES[mk["ref"]]))
                if "stroke-dasharray" in a:
                    raise Dialect("data-mark=%r: a mark is never dashed" % v)
        if not ok:
            raise Dialect("%s=%r" % (k, v))


def _check_element(el, t, parent, box=None):
    """Raise Dialect for the first violation of element el. Returns the
    canvas (W, H) for the root."""
    if (t == "svg") != (parent is None):
        raise Dialect("<svg> must be the root and only the root")
    # every element but the root is checked against its parent's children
    # list, which names only dialect elements: an unknown element stops here
    if parent is not None and t not in \
            DIALECT["elements"][parent]["children"]:
        raise Dialect("element <%s> inside <%s> is outside the dialect"
                      % (t, parent))
    spec = DIALECT["elements"][t]
    allowed = set(spec["required"]) | set(spec["optional"])
    for k in el.attrib:
        if k not in allowed:
            raise Dialect("attribute %r is outside the dialect for <%s>"
                          % (k, t))
    for k in spec["required"]:
        if k not in el.attrib and k not in HOOKS:
            raise Dialect("required attribute %r missing" % k)
    a = el.attrib
    for k in NUM_ATTRS:
        if k in a:
            _num(a[k], k)
    for k, lst in CLOSED_LISTS.items():
        if k in a and a[k] not in DIALECT[lst]:
            raise Dialect("%s=%r outside %s" % (k, a[k], lst))
    if t == "svg":
        m = re.match(r"^0 0 (\S+) (\S+)\Z", a["viewBox"])
        if not m:
            raise Dialect("viewBox=%r is not '0 0 W H'" % a["viewBox"])
        wh = (_num(m.group(1), "viewBox"), _num(m.group(2), "viewBox"))
        if min(wh) <= 0 or max(wh) > DIALECT["_canvas"]:
            raise Dialect("viewBox=%r (0 < W, H <= canvas_max_px=%s)"
                          % (a["viewBox"], DIALECT["canvas_max_px"]))
        for k, v in (("width", wh[0]), ("height", wh[1])):
            if k in a and _num(a[k], k) != v:
                raise Dialect("%s=%r differs from the viewBox (one user "
                              "unit is one px)" % (k, a[k]))
        box = wh
    if "data-layer" in a and a["data-layer"] not in DIALECT["layers"]:
        # (close_gaps VD3-05: a free token could carry an answer into the
        # source, e.g. data-label="bm-13")
        raise Dialect("data-layer=%r outside layers" % a["data-layer"])
    if "id" in a and not DIALECT["_id"].match(a["id"]):
        # (wspec-svg/4) an id is its element's position, nothing else
        raise Dialect("id=%r is not an element id e0001.." % a["id"])
    if "data-for" in a and not DIALECT["_for"].match(a["data-for"]):
        raise Dialect("data-for=%r is not a point name or '<ang|seg|poly> "
                      "<names>'" % a["data-for"])
    # paint
    if "stroke" in a:
        if PAINT_NAME.get(a["stroke"]) not in STROKE_OK[t]:
            raise Dialect("stroke=%r outside the palette for <%s>"
                          % (a["stroke"], t))
        stroked = a["stroke"] != "none"
        if stroked and "stroke-width" not in a:
            raise Dialect("stroke-width missing on a stroked <%s>" % t)
        if not stroked and ("stroke-width" in a or "stroke-dasharray" in a):
            raise Dialect("stroke-width / dasharray on an unstroked <%s>" % t)
    if "stroke-width" in a and a["stroke-width"] not in \
            DIALECT["stroke_widths"].values():
        raise Dialect("stroke-width=%r outside stroke_widths"
                      % a["stroke-width"])
    if "stroke-dasharray" in a and a["stroke-dasharray"] not in \
            DIALECT["_dashes"]:
        raise Dialect("stroke-dasharray=%r is not a dash style"
                      % a["stroke-dasharray"])
    if "fill" in a and PAINT_NAME.get(a["fill"]) not in FILL_OK[t]:
        raise Dialect("fill=%r outside the palette for <%s>" % (a["fill"], t))
    # geometry
    if t == "line":
        if (_num(a["x1"], "x1"), _num(a["y1"], "y1")) == \
                (_num(a["x2"], "x2"), _num(a["y2"], "y2")):
            raise Dialect("zero-length line (degenerate)")
    elif t == "circle":
        r = _num(a["r"], "r")
        if r <= 0:
            raise Dialect("r=%r is not positive" % a["r"])
        if a["r"] not in DIALECT["point_radii"]:
            # (verifier dialect r1, D3: an ink disk of any radius buried
            # points and segments black on black; r2, VD2-01: a guide
            # circle nothing measures) -- a circle is a point dot
            raise Dialect("a circle is a point dot (fill ink, stroke none): "
                          "r=%r is not in point_radii" % a["r"])
    elif t in ("polygon", "polyline"):
        pts = _points(a["points"])
        if len(pts) < (3 if t == "polygon" else 2):
            raise Dialect("%s with %d points" % (t, len(pts)))
        _no_repeat(pts, t == "polygon", t)
        if t == "polygon" and a["stroke"] == "none" and \
                a["fill"] == "none":
            raise Dialect("a polygon that paints nothing")
    elif t == "path":
        pts, closed = _path(a["d"])
        if closed:
            # (fix structural r2: a path is only ever a MARK, and a mark is
            # an open stroke; an outline is a data-poly polygon)
            raise Dialect("d=%r: a path is an open mark stroke (no Z)"
                          % a["d"][:40])
        _no_repeat(pts, False, "path")
    elif t == "text":
        _label_text(el)
    if t != "text" and (el.text or "").strip():
        raise Dialect("text content inside <%s>" % t)
    if (el.tail or "").strip():
        raise Dialect("text content after <%s>" % t)
    # hooks last: an element outside the dialect for another reason is
    # named for that reason
    if t in PAINTED:
        _check_hook(t, spec, a)
    if box is not None:
        _on_canvas(t, a, box)
    return box


def _describe(el, t, where):
    hook = [k + "=" + el.attrib[k] for k in HOOKS if k in el.attrib]
    return "<%s%s> at %s" % (t, (" " + hook[0]) if hook else "", where)


def _prolog(raw):
    """The bytes before the root: nothing but an optional XML declaration;
    no DOCTYPE / ENTITY / comment / CDATA / processing instruction."""
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        raise Dialect("the file is not UTF-8")
    body = text[len(XML_DECL):] if text.startswith(XML_DECL) else text
    if "<!" in body or "<?" in body:
        raise Dialect("a DOCTYPE, ENTITY, comment, CDATA or processing "
                      "instruction")
    return text


# ---------------------------------------------------------------- read ---
class Drawing(object):
    def __init__(self):
        self.pts, self.segs, self.polys = {}, {}, {}
        self.lines, self.rays = {}, {}
        self.marks, self.texts, self.stroked_polys = [], [], set()
        self.dialect, self.dups = [], []
        self.canvas = None


# (wspec-svg/5, v6.9 fix r2, P4) the corner dot: radius half the normal
# stroke, so it lies wholly inside the join of the strokes that meet there --
# the point prints as the corner itself (the builder's look), while the
# figure still carries a dot for every point it shows (the checks' anchors)
CORNER_DOT_R = "0.75"
CORNER_TOL_PX = 0.05


def is_corner(c, pieces, tol=CORNER_TOL_PX):
    """c is a corner of the drawn straight pieces [(p, q, width, dashed)]:
    no piece passes through c, and at least two SOLID pieces at least as
    wide as the corner dot's diameter END at c, no two of them in opposite
    directions (that is a point on a straight line)."""
    dirs = []
    for p, q, w, dashed in pieces:
        at_p, at_q = _d(c, p) <= tol, _d(c, q) <= tol
        if not (at_p or at_q):
            if _seg_dist(c, p, q) <= tol:
                return False                    # a stroke runs through it
            continue
        if dashed or float(w or 0) < 2 * float(CORNER_DOT_R) - 1e-9:
            continue
        o = q if at_p else p
        L = _d(c, o)
        if L > tol:
            dirs.append(((o[0] - c[0]) / L, (o[1] - c[1]) / L))
    if len(dirs) < 2:
        return False
    for i in range(len(dirs)):
        for j in range(i + 1, len(dirs)):
            if dirs[i][0] * dirs[j][0] + dirs[i][1] * dirs[j][1] < -0.9998:
                return False                    # straight through
    return True


def _elem_points(t, a):
    if t == "line":
        return [(float(a["x1"]), float(a["y1"])),
                (float(a["x2"]), float(a["y2"]))]
    if t == "path":
        return _path(a["d"])[0]
    return _points(a["points"])


def read_svg(path):
    """Parse the ORIGINAL file inside the dialect. Returns a Drawing;
    .dialect holds GEOM_DIALECT issues (then nothing else is trusted).
    Raises ET.ParseError when the file is not well-formed XML.
    A segment / line hook is keyed by its two names SORTED (BM and MB are
    one hook: verifier dialect r1, D2); a ray by (from, through)."""
    with open(path, "rb") as fh:
        raw = fh.read()
    dr = Drawing()
    try:
        _prolog(raw)
    except Dialect as e:
        dr.dialect.append(Issue("GEOM_DIALECT", path, "file: %s" % e))
        return dr
    root = ET.fromstring(raw)
    inked = [None]                            # first element painting ink
    canvas = [None]
    ids = []                                  # (desc, id) painted + text
    pieces, corner_dots = [], []              # (wspec-svg/5, P4)

    def walk(el, parent, where, depth):
        t = _tag(el)
        desc = _describe(el, t, where)
        try:
            if depth > DIALECT["_depth"]:
                # (verifier dialect r2, VD2-03: 1200 nested <g> ran into
                # Python's recursion limit instead of a stated one)
                raise Dialect("nested deeper than max_depth=%d"
                              % DIALECT["_depth"])
            box = _check_element(el, t, parent, canvas[0])
        except Dialect as e:
            dr.dialect.append(Issue("GEOM_DIALECT", path,
                                    "%s: %s" % (desc, e)))
            return
        if parent is None:
            canvas[0] = box
            dr.canvas = box
        a = el.attrib
        if t in PAINTED or t == "text":
            ids.append((desc, a.get("id")))
        if a.get("fill") == PAINT["shade"] and inked[0] is not None:
            dr.dialect.append(Issue("GEOM_DIALECT", path, "%s: shade after "
                                    "%s (shade must not cover ink)"
                                    % (desc, inked[0])))
        if inked[0] is None and (a.get("stroke", "none") != "none" or
                                 a.get("fill") in (PAINT["ink"],
                                                   PAINT["guide"])):
            inked[0] = desc
        # (wspec-svg/5, P4) the pieces a corner dot must sit at
        if t == "line" and a.get("stroke", "none") != "none":
            pp = _elem_points(t, a)
            pieces.append((pp[0], pp[1], a.get("stroke-width"),
                           "stroke-dasharray" in a))
        elif t == "polygon" and a.get("stroke", "none") != "none":
            pp = _points(a["points"])
            for i in range(len(pp)):
                pieces.append((pp[i], pp[(i + 1) % len(pp)],
                               a.get("stroke-width"),
                               "stroke-dasharray" in a))
        elif t == "circle" and a.get("r") == CORNER_DOT_R:
            corner_dots.append((desc, (float(a["cx"]), float(a["cy"]))))
        hook = None
        if "data-pt" in a:
            hook, table = a["data-pt"], dr.pts
            val = (float(a["cx"]), float(a["cy"]))
        elif "data-seg" in a or "data-line" in a or "data-ray" in a:
            k = [x for x in ("data-seg", "data-line", "data-ray")
                 if x in a][0]
            m = DIALECT["_seg"].match(a[k])
            hook = m.groups() if k == "data-ray" else \
                tuple(sorted(m.groups()))
            table = {"data-seg": dr.segs, "data-line": dr.lines,
                     "data-ray": dr.rays}[k]
            val = tuple(_elem_points(t, a))
        elif "data-poly" in a:
            hook, table = a["data-poly"], dr.polys
            val = _points(a["points"])
            if a["stroke"] != "none":
                dr.stroked_polys.add(hook)
        elif "data-mark" in a:
            m = DIALECT["_mark"].match(a["data-mark"])
            dr.marks.append({"kind": m.group(1),
                             "n": int(m.group(2) or 1),
                             "names": DIALECT["_one"].findall(m.group(3)),
                             "ref": m.group(3), "pts": _elem_points(t, a),
                             "desc": desc, "value": a["data-mark"]})
        elif t == "text":
            dr.texts.append((_logical_text(el), float(a["x"]), float(a["y"]),
                             float(a["font-size"]),
                             a.get("text-anchor", "start"), desc,
                             a["data-for"]))
        if hook is not None:
            if hook in table:
                dr.dups.append(Issue("GEOM_DUPLICATE_MARKER", path,
                                     "%s %r twice" % (t, [a[k] for k in HOOKS
                                                          if k in a][0])))
            else:
                table[hook] = val
        count = {}
        for c in el:
            ct = _tag(c)
            count[ct] = count.get(ct, 0) + 1
            walk(c, t, "%s/%s[%d]" % (where, ct, count[ct]), depth + 1)
    walk(root, None, "svg", 1)
    # (wspec-svg/5, P4) a corner dot hides in the join of the strokes that
    # END at it; anywhere else it would print no visible point
    for desc, c in corner_dots:
        if not is_corner(c, pieces):
            dr.dialect.append(Issue(
                "GEOM_DIALECT", path, "%s: r=%s is a CORNER dot: it must sit "
                "where at least two solid normal strokes end at an angle and "
                "no stroke passes through (else it shows no point)"
                % (desc, CORNER_DOT_R)))
    # (wspec-svg/4) ids: on every painted element and text or on none, the
    # k-th one e%04d of k -- an id is the element's position, never a token
    if not dr.dialect and any(i is not None for _, i in ids):
        for k, (desc, i) in enumerate(ids):
            if i != "e%04d" % (k + 1):
                dr.dialect.append(Issue("GEOM_DIALECT", path, "%s: id=%r, "
                                        "the id rule wants %r (e0001.. in "
                                        "document order, on all or none)"
                                        % (desc, i, "e%04d" % (k + 1))))
                break
    return dr


# ------------------------------------------------------------- measure ---
def _d(p, q):
    return math.hypot(p[0] - q[0], p[1] - q[1])


def _seg_dist(p, a, b):
    ax, ay = a
    bx, by = b
    L2 = (bx - ax) ** 2 + (by - ay) ** 2
    if L2 == 0:
        return _d(p, a)
    t = max(0.0, min(1.0, ((p[0] - ax) * (bx - ax) + (p[1] - ay) *
                           (by - ay)) / L2))
    return _d(p, (ax + t * (bx - ax), ay + t * (by - ay)))


def _angle(v, a, b):
    """The angle a-v-b in degrees (0..180), None when an arm is shorter
    than MIN_ARM_PX."""
    if min(_d(v, a), _d(v, b)) < MIN_ARM_PX:
        return None
    ang = abs(math.degrees(math.atan2(a[1] - v[1], a[0] - v[0]) -
                           math.atan2(b[1] - v[1], b[0] - v[0]))) % 360
    return min(ang, 360 - ang)


def _dir_diff(p1, q1, p2, q2):
    """The angle between two undirected lines, 0..90 degrees."""
    a1 = math.degrees(math.atan2(q1[1] - p1[1], q1[0] - p1[0]))
    a2 = math.degrees(math.atan2(q2[1] - p2[1], q2[0] - p2[0]))
    d = abs(a1 - a2) % 180
    return min(d, 180 - d)


def eval_number(v):
    from .canon import parse_exact
    a, b, r = parse_exact(v)            # (v6.10) a + b*sqrt(r)
    return float(a) + float(b) * math.sqrt(r)


def _base_value(f):
    """(dimension, value in the dimension's base unit) of a scaled fact."""
    from . import canon
    u = canon.canon_unit(f.get("unit"))
    v = eval_number(f["value"])
    if u is None:
        return None, v
    dim, factor = canon.UNITS[u]
    return dim, v * float(factor)


# relation -> (how it is measured, why / what). EVERY relation of
# schema.RELS is here (checked at import): a new relation must be declared
# measured or not, with a reason (verifier dialect r1, D6: only midpoint,
# on_segment and angle_measure were measured).
#   incidence  -- in every figure (a sketch still puts M on AC)
#   metric     -- in an accurate figure only (C1: a schematic figure is
#                 not to scale)
#   scale      -- accurate only: all length / perimeter / area values of a
#                 figure give ONE px-per-unit (SCALE_TOL_REL)
#   none       -- not measured, for the reason given
MEASURE = {
    "midpoint": ("incidence", "the point is the midpoint (ON_TOL_PX)"),
    "on_segment": ("incidence", "the point is on the segment (ON_TOL_PX)"),
    "angle_measure": ("metric", "the drawn angle (ANGLE_TOL_DEG)"),
    "equal_angle": ("metric", "the two drawn angles (ANGLE_TOL_DEG)"),
    "parallel": ("metric", "the directions (ANGLE_TOL_DEG)"),
    "perpendicular": ("metric", "the directions (ANGLE_TOL_DEG)"),
    "equal_length": ("metric", "the two drawn lengths (LEN_TOL_PX)"),
    "ratio": ("metric", "the ratio of two drawn segments (SCALE_TOL_REL); "
              "a line or ray has no length and is not measured"),
    "rectangle": ("metric", "4 vertices, every angle 90"),
    "square": ("metric", "4 vertices, every angle 90, equal sides"),
    "parallelogram": ("metric", "4 vertices, opposite sides parallel"),
    "rhombus": ("metric", "4 vertices, equal sides"),
    "equilateral": ("metric", "every side equal"),
    "isosceles": ("metric", "two sides equal"),
    "congruent": ("metric", "the same vertex count; equal sorted sides "
                  "(LEN_TOL_PX) and sorted angles (ANGLE_TOL_DEG)"),
    "length": ("scale", "px per unit"),
    "perimeter": ("scale", "px per unit"),
    "area": ("scale", "sqrt(px^2 per unit^2)"),
    "var_value": ("none", "a variable has no drawing"),
    "coordinate": ("none", "axes and ticks have no hooks in the dialect "
                   "(stage-1 figures are geometric)"),
    "tick": ("none", "axes and ticks have no hooks in the dialect"),
    "scale": ("none", "axes have no hooks in the dialect"),
    "grid": ("none", "grids have no hooks in the dialect"),
    "legend": ("none", "legends have no hooks in the dialect"),
    "unit_label": ("none", "unit labels are not relations of the drawing"),
    "name": ("none", "read through the labels (a name printed next to "
             "its point), not as a relation"),
    # (v6.10) relations of quantities and the new shape classes: no mark,
    # measured when a figure draws them
    "linear": ("metric", "args[0] = sum coef*args[k] (+ an angle "
               "constant): the drawn lengths (SCALE_TOL_REL), angles "
               "(ANGLE_TOL_DEG per term) or areas; a length / area "
               "constant needs the figure's scale and is not measured; a "
               "variable is never drawn (LIN_FORM)"),
    "greater": ("metric", "args[0] exceeds args[1] (LEN_TOL_PX / "
                "ANGLE_TOL_DEG)"),
    "not_parallel": ("metric", "the directions differ by more than "
                     "ANGLE_TOL_DEG"),
    "inside": ("incidence", "the point lies inside the polygon, farther "
               "than ON_TOL_PX from every side"),
    "trapezoid": ("metric", "4 vertices, one pair of opposite sides "
                  "parallel, the other not"),
    "isosceles_trapezoid": ("metric", "a trapezoid whose legs are equal"),
    "right_triangle": ("metric", "3 vertices, one angle 90"),
    "acute_triangle": ("metric", "3 vertices, every angle below 90"),
    # (v6.17-noam V1)
    "obtuse_triangle": ("metric", "3 vertices, one angle above 90"),
    "classify": ("none", "a class is an answer, never drawn "
                 "(FIGURE_DRAWS_PRIVATE)"),
}
for _r in S.CONSTRUCT_RELS:
    MEASURE[_r] = ("none", "a construction's result is never drawn "
                   "(CONSTRUCT_ALREADY_DRAWN / CONSTRUCT_STEP_DRAWN)")
# (v6.12) the coordinate-plane / number-line relations: a family figure is
# placed by its frame and checked against the spec's numbers by the family
# checker (BRIEF_V612 section 1), not by this geometry checker
for _r in S.FAMILY_RELS:
    MEASURE.setdefault(_r, ("none", "a family relation: checked on the "
                                    "framed figure by the family checker"))
# (v6.16 integrate) the pie chart family: a pie figure is drawn by
# render/pie.py and measured by check/pie.py (wedge spans, labels, the
# empty build circle), never by this geometry checker
for _r in S.PIE_RELS:
    MEASURE.setdefault(_r, ("none", "a pie relation: checked on the pie "
                                    "figure by the pie checker"))
if set(MEASURE) != set(S.RELS):
    raise DialectError("MEASURE does not declare exactly schema.RELS: %s"
                       % sorted(set(MEASURE) ^ set(S.RELS)))


def _points_of(eid, ix):
    """The point NAMES an entity is drawn from, in its own order."""
    e = ix.entities.get(eid) or {}
    k = e.get("kind")
    if k == "point":
        return [e["name"]]
    if k == "segment":
        return list(e["ends"])
    if k == "line":
        return list(e["through"])
    if k == "ray":
        return [e["from"], e["through"]]
    if k == "angle":
        return [e["arms"][0], e["vertex"], e["arms"][1]]
    if k == "polygon":
        return list(e["vertices"])
    return []


def _fact_points(f, ix):
    """The point names a measured fact needs, its subject point first."""
    out = []
    for a in f.get("args") or []:
        for n in _points_of(a, ix):
            if n not in out:
                out.append(n)
    if f["rel"] == "angle_measure":
        e = ix.entities[f["args"][0]]
        out = [e["vertex"]] + list(e["arms"])
    return out


def _sides(vs):
    return [(vs[i], vs[(i + 1) % len(vs)]) for i in range(len(vs))]


def _shape(rel, P, vs):
    """[detail] for a polygon shape-class fact, measured on points P."""
    n = len(vs)
    if rel in ("rectangle", "square", "parallelogram", "rhombus") and n != 4:
        return ["a %s with %d vertices" % (rel, n)]
    sides = [_d(P[a], P[b]) for a, b in _sides(vs)]
    if min(sides) < MIN_ARM_PX:
        return ["a side shorter than MIN_ARM_PX=%s" % MIN_ARM_PX]
    angs = [_angle(P[vs[i]], P[vs[i - 1]], P[vs[(i + 1) % n]])
            for i in range(n)]
    out = []

    def equal(which):
        if max(which) - min(which) > LEN_TOL_PX:
            out.append("sides %s differ by %.3f px > LEN_TOL_PX=%s" % (
                "/".join("%.2f" % s for s in which),
                max(which) - min(which), LEN_TOL_PX))
    if rel in ("rectangle", "square"):
        worst = max(abs(a - 90) for a in angs)
        if worst > ANGLE_TOL_DEG:
            out.append("an angle off 90 by %.2f deg > ANGLE_TOL_DEG=%s"
                       % (worst, ANGLE_TOL_DEG))
    if rel == "parallelogram":
        for i in (0, 1):
            (a, b), (c, d) = _sides(vs)[i], _sides(vs)[i + 2]
            dd = _dir_diff(P[a], P[b], P[c], P[d])
            if dd > ANGLE_TOL_DEG:
                out.append("sides %s%s and %s%s are %.2f deg from parallel "
                           "> ANGLE_TOL_DEG=%s" % (a, b, c, d, dd,
                                                   ANGLE_TOL_DEG))
    if rel in ("square", "rhombus", "equilateral"):
        equal(sides)
    if rel == "isosceles":
        best = min(abs(sides[i] - sides[j]) for i in range(n)
                   for j in range(i + 1, n))
        if best > LEN_TOL_PX:
            out.append("no two sides equal (closest differ by %.3f px > "
                       "LEN_TOL_PX=%s)" % (best, LEN_TOL_PX))
    # (v6.10) the new shape classes
    if rel in ("trapezoid", "isosceles_trapezoid"):
        if n != 4:
            return ["a %s with %d vertices" % (rel, n)]
        par = []
        for i in (0, 1):
            (a, b), (c, d) = _sides(vs)[i], _sides(vs)[i + 2]
            par.append(_dir_diff(P[a], P[b], P[c], P[d]) <= ANGLE_TOL_DEG)
        if par.count(True) != 1:
            out.append("%d pairs of opposite sides parallel (a trapezoid "
                       "has one)" % par.count(True))
        elif rel == "isosceles_trapezoid":
            legs = [sides[1], sides[3]] if par[0] else [sides[0], sides[2]]
            if abs(legs[0] - legs[1]) > LEN_TOL_PX:
                out.append("legs %.2f / %.2f px differ > LEN_TOL_PX=%s"
                           % (legs[0], legs[1], LEN_TOL_PX))
    if rel in ("right_triangle", "acute_triangle", "obtuse_triangle"):
        if n != 3:
            return ["a %s with %d vertices" % (rel, n)]
        if rel == "right_triangle" and \
                min(abs(a - 90) for a in angs) > ANGLE_TOL_DEG:
            out.append("no angle of 90 (closest off by %.2f deg)"
                       % min(abs(a - 90) for a in angs))
        if rel == "acute_triangle" and max(angs) >= 90 - ANGLE_TOL_DEG:
            out.append("an angle of %.2f deg is not acute" % max(angs))
        # (v6.17-noam V1) an obtuse triangle drawn with no angle above 90
        if rel == "obtuse_triangle" and max(angs) <= 90 + ANGLE_TOL_DEG:
            out.append("the largest angle, %.2f deg, is not obtuse"
                       % max(angs))
    return out


def _qty(eid, ix, P):
    """(dimension, drawn size) of a quantity argument: a segment's length
    (px), an angle (deg), a polygon's area (px^2); None if it has none."""
    e = ix.entities.get(eid) or {}
    k = e.get("kind")
    if k == "segment":
        a, b = e["ends"]
        return "length", _d(P[a], P[b])
    if k == "angle":
        return "angle", _angle(P[e["vertex"]], P[e["arms"][0]],
                               P[e["arms"][1]])
    if k == "polygon":
        vs = e["vertices"]
        return "area", abs(sum(P[a][0] * P[b][1] - P[b][0] * P[a][1]
                               for a, b in _sides(vs))) / 2.0
    return None, None


def _measure_quantities(f, ix, P):
    """[(code, detail)] of a drawn linear / greater fact (v6.10)."""
    from . import language as LANG
    args = f["args"]
    if any((ix.entities.get(a) or {}).get("kind") == "variable"
           for a in args):
        # (v6.10 fix r1, S1) a relation with a declared variable (AC = 3x
        # + 4) states no drawn size: x is the question's unknown, never
        # drawn (CONVENTIONS_v610 s.2) -- nothing to measure, like an
        # angle_measure without a value
        return []
    q = [_qty(a, ix, P) for a in args]
    if any(v is None for _d0, v in q):
        return [("GEOM_LENGTH_OFF", "%s: a term has no drawn size"
                 % f["rel"])]
    dim = q[0][0]
    if f["rel"] == "greater":
        tol = ANGLE_TOL_DEG if dim == "angle" else LEN_TOL_PX
        if q[0][1] - q[1][1] <= tol:
            return [("GEOM_ANGLE_OFF" if dim == "angle" else
                     "GEOM_LENGTH_OFF", "%s is not greater than %s "
                     "(%.2f vs %.2f)" % (args[0], args[1], q[0][1],
                                         q[1][1]))]
        return []
    cs = [float(c) for c in LANG.coefs(f)]
    rhs = sum(c * v for c, (_d1, v) in zip(cs, q[1:]))
    if f.get("value") is not None:
        if dim != "angle":
            return []            # a length / area constant: scale unknown
        rhs += eval_number(f["value"])
    if dim == "angle":
        if abs(q[0][1] - rhs) > ANGLE_TOL_DEG * (1 + sum(map(abs, cs))):
            return [("GEOM_ANGLE_OFF", "linear %s: %.2f vs %.2f deg"
                     % (f["id"], q[0][1], rhs))]
        return []
    if not rhs or abs(q[0][1] / rhs - 1) > SCALE_TOL_REL * (
            2 if dim == "area" else 1):
        return [("GEOM_LENGTH_OFF", "linear %s: %.3f vs %.3f"
                 % (f["id"], q[0][1], rhs))]
    return []


def _measure(f, ix, P, scale_obs):
    """[(code, detail)] for one fact, points P (name -> xy) all marked."""
    rel = f["rel"]
    args = f["args"]
    out = []
    if rel in ("midpoint", "on_segment"):
        m = ix.entities[args[0]]["name"]
        a, b = ix.entities[args[1]]["ends"]
        if rel == "midpoint":
            off = _d(P[m], ((P[a][0] + P[b][0]) / 2, (P[a][1] + P[b][1]) / 2))
            if off > ON_TOL_PX:
                out.append(("GEOM_MIDPOINT_OFF", "%.3f px > ON_TOL_PX=%s"
                            % (off, ON_TOL_PX)))
        else:
            off = _seg_dist(P[m], P[a], P[b])
            if off > ON_TOL_PX:
                out.append(("GEOM_NOT_ON_SEGMENT", "%.3f px > ON_TOL_PX=%s"
                            % (off, ON_TOL_PX)))
    elif rel in ("angle_measure", "equal_angle"):
        if rel == "angle_measure" and f.get("value") is None:
            return []
        vals = []
        for eid in args:
            e = ix.entities[eid]
            ang = _angle(P[e["vertex"]], P[e["arms"][0]], P[e["arms"][1]])
            if ang is None:
                return [("GEOM_ANGLE_OFF", "arm shorter than MIN_ARM_PX=%s"
                         % MIN_ARM_PX)]
            vals.append(ang)
        want = float(eval_number(f["value"])) if rel == "angle_measure" \
            else vals[1]
        if abs(vals[0] - want) > ANGLE_TOL_DEG:
            out.append(("GEOM_ANGLE_OFF", "%.2f deg vs %.2f > "
                        "ANGLE_TOL_DEG=%s" % (vals[0], want, ANGLE_TOL_DEG)))
    elif rel in ("parallel", "perpendicular"):
        (p1, q1), (p2, q2) = [_points_of(a, ix) for a in args]
        dd = _dir_diff(P[p1], P[q1], P[p2], P[q2])
        off = dd if rel == "parallel" else 90 - dd
        if off > ANGLE_TOL_DEG:
            out.append(("GEOM_ANGLE_OFF", "%s: %.2f deg off > ANGLE_TOL_DEG"
                        "=%s" % (rel, off, ANGLE_TOL_DEG)))
    elif rel in ("equal_length", "ratio"):
        if any(ix.kind(a) != "segment" for a in args):
            return []                       # a line / ray has no length
        L = [_d(P[a], P[b]) for a, b in (ix.entities[x]["ends"]
                                         for x in args)]
        if rel == "equal_length" and abs(L[0] - L[1]) > LEN_TOL_PX:
            out.append(("GEOM_LENGTH_OFF", "%.3f vs %.3f px > LEN_TOL_PX=%s"
                        % (L[0], L[1], LEN_TOL_PX)))
        if rel == "ratio" and f.get("value") is not None:
            want = eval_number(f["value"])
            got = L[0] / L[1] if L[1] else float("inf")
            if abs(got / want - 1) > SCALE_TOL_REL:
                out.append(("GEOM_LENGTH_OFF", "ratio %.4f vs %s > "
                            "SCALE_TOL_REL=%s" % (got, want, SCALE_TOL_REL)))
    elif rel in ("rectangle", "square", "parallelogram", "rhombus",
                 "equilateral", "isosceles", "trapezoid",
                 "isosceles_trapezoid", "right_triangle", "acute_triangle",
                 "obtuse_triangle"):
        for d in _shape(rel, P, ix.entities[args[0]]["vertices"]):
            out.append(("GEOM_SHAPE_OFF", "%s: %s" % (rel, d)))
    elif rel in ("linear", "greater"):
        out.extend(_measure_quantities(f, ix, P))
    elif rel == "not_parallel":
        (p1, q1), (p2, q2) = [_points_of(a, ix) for a in args]
        if _dir_diff(P[p1], P[q1], P[p2], P[q2]) <= ANGLE_TOL_DEG:
            out.append(("GEOM_ANGLE_OFF", "not_parallel: the lines are "
                        "drawn parallel"))
    elif rel == "inside":
        m = ix.entities[args[0]]["name"]
        vs = ix.entities[args[1]]["vertices"]
        if not _in_polygon(P[m], [P[v] for v in vs]) or min(
                _seg_dist(P[m], P[a], P[b]) for a, b in _sides(vs)) <= \
                ON_TOL_PX:
            out.append(("GEOM_NOT_ON_SEGMENT", "%s is not inside %s"
                        % (m, args[1])))
    elif rel == "congruent":
        vss = [ix.entities[a]["vertices"] for a in args]
        if len(vss[0]) != len(vss[1]):
            return [("GEOM_SHAPE_OFF", "congruent polygons with %d and %d "
                     "vertices" % (len(vss[0]), len(vss[1])))]
        sides = [sorted(_d(P[a], P[b]) for a, b in _sides(vs)) for vs in vss]
        angs = [sorted(_angle(P[vs[i]], P[vs[i - 1]],
                              P[vs[(i + 1) % len(vs)]]) or 0.0
                       for i in range(len(vs))) for vs in vss]
        if max(abs(a - b) for a, b in zip(*sides)) > LEN_TOL_PX or \
                max(abs(a - b) for a, b in zip(*angs)) > ANGLE_TOL_DEG:
            out.append(("GEOM_SHAPE_OFF", "congruent: sides or angles "
                        "differ"))
    elif rel in ("length", "perimeter", "area") and \
            f.get("value") is not None:
        dim, v = _base_value(f)
        if rel == "length":
            a, b = ix.entities[args[0]]["ends"]
            px = _d(P[a], P[b])
        else:
            vs = ix.entities[args[0]]["vertices"]
            if rel == "perimeter":
                px = sum(_d(P[a], P[b]) for a, b in _sides(vs))
            else:
                px = abs(sum(P[a][0] * P[b][1] - P[b][0] * P[a][1]
                             for a, b in _sides(vs))) / 2.0
        if v > 0:
            s = math.sqrt(px / v) if rel == "area" else px / v
            if rel == "area":
                dim = "length" if dim == "area" else None
            scale_obs.append((dim, s, f["id"]))
    return out


def _label_box(text, x, y, fs, anchor):
    w = GLYPH_W * fs * len(text)
    h = GLYPH_H * fs
    cx = x + {"start": w / 2, "middle": 0.0, "end": -w / 2}[anchor]
    cy = y - h / 2
    return (cx, cy), (cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2)


def _in_sector(c, v, a, b):
    """Is c inside the (non-reflex) angle a-v-b?"""
    whole = _angle(v, a, b)
    p1, p2 = _angle(v, a, c), _angle(v, c, b)
    if None in (whole, p1, p2):
        return False
    return abs(p1 + p2 - whole) < 1e-6 * max(1.0, whole)


def _in_polygon(c, poly):
    x, y = c
    inside = False
    for (x1, y1), (x2, y2) in zip(poly, poly[1:] + poly[:1]):
        if (y1 > y) != (y2 > y) and \
                x < (x2 - x1) * (y - y1) / (y2 - y1) + x1:
            inside = not inside
    return inside


def _value_texts(f):
    from . import templates as TT
    v = TT._value_text(f)
    return set([v, v + TT._unit_text(f)])


def _check_labels(dr, ix, fig, shown_pt, figure_id, out):
    """Labels resolved against the spec (verifier dialect r1, D7), by their
    DECLARED source (close_gaps VD3-01: data-for; a number that matches a
    drawn value is never enough) AND by where they are printed: at their
    own object and at no other (_value_placed), with the whole glyph box on
    the canvas (VD3-03) and over no mark or drawn stroke (VD3-04)."""
    from .canon import entity_id
    pts = dr.pts
    names = dict((e["name"], eid) for eid, e in ix.entities.items()
                 if e.get("kind") == "point")
    drawn = [ix.facts[d] for d in sorted(fig.get("draws") or [])
             if d in ix.facts and ix.facts[d].get("value") is not None and
             ix.facts[d].get("role") in ("given", "context")]
    pieces = _pieces(dr)
    line_seen = {}
    for text, x, y, fs, anchor, desc, src in dr.texts:
        c, (x0, y0, x1, y1) = _label_box(text, x, y, fs, anchor)
        for n, p in sorted(pts.items()):
            if x0 <= p[0] <= x1 and y0 <= p[1] <= y1:
                out.append(Issue("GEOM_LABEL_OFF", figure_id, "label %r "
                                 "covers point %s" % (text, n)))
        _label_ink(text, (x0, y0, x1, y1), dr, pieces, figure_id, out)
        m = DIALECT["_for"].match(src)
        if src.startswith("line "):
            ns = tuple(sorted(DIALECT["_one"].findall(src[5:])))
            eid = entity_id({"kind": "line", "through": ns})
            e = ix.entities.get(eid) or {}
            line_seen[eid] = line_seen.get(eid, 0) + 1
            named = any(ix.facts[f].get("rel") == "name" and
                        ix.facts[f].get("args") == [eid] for f in fig.get("draws") or [] if f in ix.facts)
            if not named or e.get("kind") != "line" or e.get("name") != text or ns not in dr.lines:
                out.append(Issue("GEOM_LABEL_MISMATCH", figure_id, "line label %r has no matching drawn public name of %s" % (text, eid)))
                continue
            p, q = dr.lines[ns]
            distance = _seg_dist(c, p, q)
            if distance > LABEL_NEAR_PX or any(_seg_dist(c, a, b) < distance + 3.0
                                               for names2, (a, b) in dr.lines.items() if names2 != ns):
                out.append(Issue("GEOM_LABEL_OFF", figure_id, "line label %r is not unambiguously beside %s" % (text, eid)))
            continue
        if m.group(1):
            if text != src:
                out.append(Issue("GEOM_LABEL_MISMATCH", figure_id, "label %r "
                                 "is for point %s: its text is not that "
                                 "name" % (text, src)))
                continue
            if text not in names or text not in shown_pt:
                out.append(Issue("GEOM_LABEL_MISMATCH", figure_id,
                                 "label %r names a point figure %s does not "
                                 "show" % (text, figure_id)))
                continue
            if text not in pts:
                out.append(Issue("GEOM_MISSING_ELEMENT", figure_id,
                                 "point %s (labelled)" % text))
                continue
            d = _d(c, pts[text])
            near = sorted((_d(c, p), n) for n, p in pts.items() if n != text)
            if d > LABEL_NEAR_PX:
                out.append(Issue("GEOM_LABEL_OFF", figure_id, "label %r is "
                                 "%.1f px from its point > LABEL_NEAR_PX=%s"
                                 % (text, d, LABEL_NEAR_PX)))
            elif near and near[0][0] < d:
                out.append(Issue("GEOM_LABEL_OFF", figure_id, "label %r is "
                                 "nearer to %s (%.1f px) than to its point "
                                 "(%.1f px)" % (text, near[0][1],
                                                near[0][0], d)))
            continue
        kind = m.group(2) or m.group(4) or m.group(6)
        vs = DIALECT["_one"].findall(m.group(3) or m.group(5) or m.group(7))
        if kind == "ang":
            eid = entity_id({"kind": "angle", "vertex": vs[1],
                             "arms": [vs[0], vs[2]]})
        elif kind == "seg":
            eid = entity_id({"kind": "segment", "ends": vs})
        else:
            eid = entity_id({"kind": "polygon", "vertices": vs}) \
                if len(set(vs)) == len(vs) else None
        # (an object outside the spec, or one the figure does not show, has
        # no drawn fact: a drawn fact's objects are shown -- so it is
        # refused just below, as a value the figure does not draw)
        mine = [f for f in drawn if (f.get("args") or [None])[0] == eid]
        cands = [f for f in mine if text in _value_texts(f)]
        if not cands:
            out.append(Issue("GEOM_LABEL_MISMATCH", figure_id, "label %r is "
                             "not the value of a given/context fact the "
                             "figure draws of %s (it draws %s)" % (
                                 text, src, ", ".join(
                                     f["id"] for f in mine) or "none")))
            continue
        why = _value_placed(cands[0], c, ix, pts, dr, pieces)
        if why:
            out.append(Issue("GEOM_LABEL_OFF", figure_id, "label %r is not "
                             "at its object %s alone: %s" % (text, src, why)))
    for fid in fig.get("draws") or []:
        f = ix.facts.get(fid) or {}
        eid = (f.get("args") or [None])[0]
        if f.get("rel") == "name" and ix.kind(eid) == "line" and line_seen.get(eid, 0) != 1:
            out.append(Issue("GEOM_MISSING_ELEMENT", figure_id,
                             "line %s needs exactly one name label, found %d" % (eid, line_seen.get(eid, 0))))


def _clip_len(p, q, box):
    """Length of the segment p-q inside the box (Liang-Barsky)."""
    x0, y0, x1, y1 = box
    dx, dy = q[0] - p[0], q[1] - p[1]
    t0, t1 = 0.0, 1.0
    for pk, qk in ((-dx, p[0] - x0), (dx, x1 - p[0]), (-dy, p[1] - y0),
                   (dy, y1 - p[1])):
        if pk == 0:
            if qk < 0:
                return 0.0
            continue
        t = qk / pk
        if pk < 0:
            t0 = max(t0, t)
        else:
            t1 = min(t1, t)
        if t0 > t1:
            return 0.0
    return (t1 - t0) * math.hypot(dx, dy)


def _label_ink(text, box, dr, pieces, figure_id, out):
    """VD3-03/04: the whole glyph box on the canvas; no mark stroke inside
    it; no drawn straight piece through it for more than
    LABEL_STROKE_TOL_PX."""
    x0, y0, x1, y1 = box
    W, H = dr.canvas
    if x0 < 0 or y0 < 0 or x1 > W or y1 > H:
        out.append(Issue("GEOM_LABEL_CLIPPED", figure_id, "label %r: its box "
                         "%.1f,%.1f..%.1f,%.1f runs past the canvas 0 0 %g %g"
                         % (text, x0, y0, x1, y1, W, H)))
    for m in dr.marks:
        if any(_clip_len(p, q, box) > 0 for p, q in zip(m["pts"],
                                                         m["pts"][1:])):
            out.append(Issue("GEOM_LABEL_COVERS", figure_id, "label %r "
                             "covers the mark %r" % (text, m["value"])))
    worst = max([_clip_len(p, q, box) for p, q in pieces] or [0.0])
    if worst > LABEL_STROKE_TOL_PX:
        out.append(Issue("GEOM_LABEL_COVERS", figure_id, "a drawn line runs "
                         "%.1f px through label %r > LABEL_STROKE_TOL_PX=%s"
                         % (worst, text, LABEL_STROKE_TOL_PX)))


def _dirs_at(v, pieces):
    """The directions (unit vectors) of the drawn pieces leaving point v."""
    out = []
    for p, q in pieces:
        if _seg_dist(v, p, q) > ON_TOL_PX:
            continue
        for e in (p, q):
            L = _d(v, e)
            if L >= MIN_ARM_PX:
                out.append(((e[0] - v[0]) / L, (e[1] - v[1]) / L))
    return out


def _far_side(c, a, b, p, q):
    """(v6.9 fix r1, N1/P1) The piece p-q lies wholly on the other side of
    the line a-b from the label centre c (an end may touch the line): the
    segment a-b stands between the label and that piece, so the label
    cannot read as the piece's (the '8' under BC, with DE rising from BC's
    midpoint E above it)."""
    def side(x):
        L = math.hypot(b[0] - a[0], b[1] - a[1]) or 1.0
        return ((b[0] - a[0]) * (x[1] - a[1]) -
                (b[1] - a[1]) * (x[0] - a[0])) / L
    sc = side(c)
    if abs(sc) <= ON_TOL_PX:
        return False
    for x in (p, q):
        sx = side(x)
        if abs(sx) > ON_TOL_PX and (sx > 0) == (sc > 0):
            return False
    return True


def _value_placed(f, c, ix, pts, dr=None, pieces=()):
    """'' when a value label centred at c is printed at fact f's object and
    reads as no other; else why not (close_gaps VD3-01: in a small figure
    a label inside its angle was also next to another vertex, inside
    another angle)."""
    e = ix.entities.get(f["args"][0]) or {}
    need = _points_of(f["args"][0], ix)
    if not need or any(n not in pts for n in need):
        return "" if not need else "its points are not marked"
    k = e.get("kind")
    if k == "angle":
        v, a, b = pts[e["vertex"]], pts[e["arms"][0]], pts[e["arms"][1]]
        if not (_d(c, v) <= LABEL_VALUE_PX and _in_sector(c, v, a, b)):
            return "outside its angle or farther than LABEL_VALUE_PX=%s " \
                "from the vertex" % LABEL_VALUE_PX
        dv = _d(c, v)
        for n, p in sorted(pts.items()):
            if n != e["vertex"] and _d(c, p) < dv + LABEL_MARGIN_PX:
                return "it is %.1f px from %s, not nearer (by LABEL_MARGIN_" \
                    "PX=%s) to its vertex %s (%.1f px)" % (
                        _d(c, p), n, LABEL_MARGIN_PX, e["vertex"], dv)
        whole = _angle(v, a, b)
        for u in _dirs_at(v, pieces):
            w = (v[0] + 10 * u[0], v[1] + 10 * u[1])
            ta, tb = _angle(v, a, w), _angle(v, w, b)
            if ta is None or tb is None:
                continue
            if ta > ANGLE_TOL_DEG and tb > ANGLE_TOL_DEG and \
                    abs(ta + tb - whole) < 1e-6 * max(1.0, whole):
                return "a drawn line splits the angle at %s (the label " \
                    "reads as a part of it)" % e["vertex"]
        return ""
    if k == "segment":
        a, b = (pts[n] for n in e["ends"])
        if not (_seg_dist(c, a, b) <= LABEL_NEAR_PX):
            return "farther than LABEL_NEAR_PX=%s from the segment" \
                % LABEL_NEAR_PX
        L2 = (b[0] - a[0]) ** 2 + (b[1] - a[1]) ** 2
        t = ((c[0] - a[0]) * (b[0] - a[0]) + (c[1] - a[1]) * (b[1] - a[1])) \
            / L2
        if not LABEL_SEG_END_FRAC <= t <= 1 - LABEL_SEG_END_FRAC:
            return "beside an end, not the middle part (LABEL_SEG_END_FRAC" \
                "=%s)" % LABEL_SEG_END_FRAC
        own = _seg_dist(c, a, b)
        for p, q in pieces:
            if _seg_dist(a, p, q) <= ON_TOL_PX and \
                    _seg_dist(b, p, q) <= ON_TOL_PX:
                continue                  # a piece that draws the segment
            if _far_side(c, a, b, p, q):
                continue                  # (fix r1) across the segment's line
            if _seg_dist(c, p, q) < own + LABEL_MARGIN_PX:
                return "a drawn piece is %.1f px away, not farther (by " \
                    "LABEL_MARGIN_PX=%s) than its segment (%.1f px)" % (
                        _seg_dist(c, p, q), LABEL_MARGIN_PX, own)
        return ""
    if k == "polygon":
        poly = [pts[n] for n in e["vertices"]]
        if not _in_polygon(c, poly):
            return "outside its polygon"
        area = _area(poly)
        for name, got in sorted(((dr.polys if dr else {}) or {}).items()):
            if _in_polygon(c, got) and _area(got) < area - LEN_TOL_PX:
                return "inside the smaller drawn polygon %s" % name
        return ""
    return ""


def _area(poly):
    return abs(sum(p[0] * q[1] - q[0] * p[1]
                   for p, q in zip(poly, poly[1:] + poly[:1]))) / 2.0


def _check_polys(dr, ix, figure_id, out):
    """Every data-poly polygon: its vertices on the marked points of that
    polygon, in its cyclic order (either direction). (That it is a polygon
    the figure shows is checked with the other hooks.)"""
    from .canon import entity_id
    for name, got in sorted(dr.polys.items()):
        vs = DIALECT["_one"].findall(name)
        want = (ix.entities.get(entity_id({"kind": "polygon",
                                            "vertices": vs})) or {}).get(
            "vertices") or vs
        missing = [v for v in want if v not in dr.pts]
        if missing:
            out.append(Issue("GEOM_MISSING_ELEMENT", figure_id,
                             "point(s) %s of polygon %s not marked"
                             % (", ".join(missing), name)))
            continue
        if len(got) != len(want):
            out.append(Issue("GEOM_POLY_MISMATCH", figure_id,
                             "polygon %s drawn with %d vertices, the spec "
                             "has %d" % (name, len(got), len(want))))
            continue
        best = None
        n = len(want)
        for order in (want, want[::-1]):
            for k in range(n):
                cyc = order[k:] + order[:k]
                worst = max(_d(g, dr.pts[v]) for g, v in zip(got, cyc))
                best = worst if best is None else min(best, worst)
        if best > JOIN_TOL_PX:
            out.append(Issue("GEOM_POLY_MISMATCH", figure_id,
                             "polygon %s: a vertex off its point by %.3f px "
                             "> JOIN_TOL_PX=%s" % (name, best, JOIN_TOL_PX)))


def _mark_eid(m):
    """The entity id a mark names (its ref, by the spec's id rule)."""
    from .canon import entity_id
    n = m["names"]
    if DIALECT["marks"][m["kind"]]["ref"] == "angle":
        return entity_id({"kind": "angle", "vertex": n[1],
                          "arms": [n[0], n[2]]})
    return entity_id({"kind": "segment", "ends": n})


def _hook_drawn(kind, eid, shown, ix):
    """A segment / line / ray hook draws an object of ITS kind (close_gaps
    SV3-03/05: a figure that shows the segment BC may not draw the line BC,
    nor a ray, nor the other way round): a line or ray only when the figure
    shows that very line / ray; a segment when it shows the segment, or a
    polygon whose side or an angle whose arm it is."""
    from .baseline import _drawn_pairs
    if eid in shown:
        return True
    if kind != "segment":
        return False
    pair = frozenset(ix.entities[eid]["ends"])
    return any(pair in _drawn_pairs(ix.entities.get(x) or {})
               for x in shown if ix.kind(x) in ("polygon", "angle"))


def _check_hooks(dr, ix, shown, figure_id, out):
    """Every hook names an object the figure shows (verifier dialect r1,
    D1/D2: a marked extra point, a data-seg of an unlisted segment; r2,
    VD2-01: lines, rays and marks too)."""
    from .baseline import _object_drawn
    from .canon import entity_id
    names = dict((e["name"], eid) for eid, e in ix.entities.items()
                 if e.get("kind") == "point")

    def unknown(what, why=""):
        out.append(Issue("GEOM_HOOK_UNKNOWN", figure_id, "%s is not %s "
                         "figure %s shows%s" % (what[0], what[1], figure_id,
                                                why)))
    for n in sorted(dr.pts):
        if n not in names or not _object_drawn(names[n], shown, ix):
            unknown(("data-pt=" + n, "a point"))
    for table, kind, attr in ((dr.segs, "segment", "data-seg"),
                              (dr.lines, "line", "data-line"),
                              (dr.rays, "ray", "data-ray")):
        for a, b in sorted(table):
            e = {"kind": kind}
            if kind == "segment":
                e["ends"] = [a, b]
            elif kind == "line":
                e["through"] = [a, b]
            else:
                e["from"], e["through"] = a, b
            eid = entity_id(e)
            if eid not in ix.entities or not _hook_drawn(kind, eid, shown,
                                                         ix):
                unknown(("%s=%s%s" % (attr, a, b), "a %s" % kind))
    for name in sorted(dr.polys):
        vs = DIALECT["_one"].findall(name)
        eid = entity_id({"kind": "polygon", "vertices": vs}) \
            if len(set(vs)) == len(vs) else None
        e = ix.entities.get(eid) or {}
        if e.get("kind") != "polygon" or not _object_drawn(eid, shown, ix):
            unknown(("data-poly=" + name, "a polygon"))
    for m in dr.marks:
        # a mark names an entity of the spec whose points the figure shows;
        # that its segment / arms are DRAWN is measured (_measure_mark: a
        # tick on the half AM of a drawn AC is on a drawn piece)
        eid = _mark_eid(m)
        ref = DIALECT["marks"][m["kind"]]["ref"]
        if (ix.entities.get(eid) or {}).get("kind") != ref or not all(
                n in names and _object_drawn(names[n], shown, ix)
                for n in m["names"]):
            unknown(("data-mark=%r" % m["value"], "on %s" % (
                "an angle" if ref == "angle" else "a segment")),
                " (an entity of the spec whose points the figure shows)")


# ---------------------------------------------------------------- marks ---
class _Union(object):
    def __init__(self):
        self.up = {}

    def find(self, x):
        self.up.setdefault(x, x)
        while self.up[x] != x:
            self.up[x] = self.up[self.up[x]]
            x = self.up[x]
        return x

    def join(self, a, b):
        self.up[self.find(a)] = self.find(b)


def _reader_facts(fig, ix):
    """The facts the READER of figure `fig` sees: the facts it draws and
    the given / context facts of its visible scopes -- each given or
    context AND public (project.eligible: a stated given, a context of the
    closed list, a reviewed release). A to_prove, a target, an answer or an
    unreleased derived step is not among them."""
    from . import project as P
    vis = set(ix.visible_scopes(fig["scope"]))
    drawn = set(fig.get("draws") or [])
    facts = [f for f in sorted(ix.facts.values(), key=lambda f: f["id"])
             if (f["id"] in drawn or f.get("item") in vis) and
             f.get("role") in ("given", "context") and P.eligible(f, ix)]
    from . import figure_scopes618 as FS618
    state, _why = FS618.state_record(ix.spec, fig)
    return [f for f in facts if not state or f["id"] != state["old_height"]]


def _claims_seen(facts, ix):
    """(right, equal): the angle ids the facts make 90 degrees, and a
    union-find of the angle and segment ids they make EQUAL. The CLOSED
    rules (each a statement the reader has in front of him):
      right  -- an angle_measure of 90 deg; perpendicular x, y through ONE
                shared named point (the angle at it); every corner of a
                rectangle / square;
      equal  -- two facts of the same quantity with equal values (lengths,
                angles); equal_length; equal_angle; a midpoint's two
                halves; every side of a square / rhombus / equilateral
                polygon; the opposite sides of a rectangle / parallelogram;
                every right angle with every other."""
    from . import canon
    from .baseline import _line_key, _right_angle
    ent = canon.entity_id
    right, eq = set(), _Union()
    valued = []

    def ang(a, v, b):
        return ent({"kind": "angle", "vertex": v, "arms": [a, b]})

    def seg(a, b):
        return ent({"kind": "segment", "ends": [a, b]})
    # (build_renderer) the incidences the reader sees: a point on a
    # segment (on_segment / midpoint), so 'BH ⟂ AC' with 'H על AC' makes the
    # angles at the foot H right
    on = {}
    coll = set()        # (v6.17, V4) collinear triples a fact states
    for f in facts:
        a_ = f.get("args") or []
        if f.get("rel") in ("on_segment", "midpoint") and len(a_) == 2:
            e = ix.entities.get(a_[1]) or {}
            if e.get("kind") == "segment":
                on.setdefault(a_[0], set()).add(frozenset(e["ends"]))
                coll.add(frozenset([a_[0]] + list(e["ends"])))
    for f in facts:
        rel, args = f.get("rel"), f.get("args") or []
        if rel == "angle_measure" and _right_angle(f):
            right.add(args[0])
        elif rel == "perpendicular" and len(args) == 2:
            k1, k2 = (_line_key(x, ix) for x in args)
            if k1 and k2 and len(k1 & k2) == 1 and len(k1 | k2) == 3:
                v = list(k1 & k2)[0]
                right.add(ang(list(k1 - k2)[0], v, list(k2 - k1)[0]))
            elif k1 and k2 and len(k1) == 2 and len(k2) == 2 and \
                    not (k1 & k2):
                for ka, kb in ((k1, k2), (k2, k1)):
                    for x in sorted(ka):
                        # (v6.17, V4) or x on the LINE of kb by a stated
                        # collinearity: 'CH ⟂ AB' with 'B על AH' -- the
                        # height of an obtuse triangle, its foot H on the
                        # extension of AB: the right angle sits at H
                        if kb in on.get(x, ()) or kb | set([x]) in coll:
                            o = list(ka - set([x]))[0]
                            for y in sorted(kb):
                                right.add(ang(o, x, y))
        vs = (ix.entities.get(args[0]) or {}).get("vertices") or [] \
            if args else []
        if rel in ("rectangle", "square") and len(vs) == 4:
            for i in range(4):
                right.add(ang(vs[i - 1], vs[i], vs[(i + 1) % 4]))
        if rel in ("length", "angle_measure") and f.get("value") is not None:
            valued.append(f)
        elif rel in ("equal_length", "equal_angle") and len(args) == 2:
            eq.join(args[0], args[1])
        elif rel == "midpoint" and len(args) == 2:
            m = (ix.entities.get(args[0]) or {}).get("name")
            a, b = ((ix.entities.get(args[1]) or {}).get("ends") or
                    [None, None])
            if m and a and b:
                eq.join(seg(a, m), seg(m, b))
        sides = [seg(vs[i], vs[(i + 1) % len(vs)]) for i in range(len(vs))]
        if rel in ("square", "rhombus", "equilateral") and len(vs) >= 3:
            for s in sides[1:]:
                eq.join(sides[0], s)
        if rel in ("rectangle", "parallelogram") and len(vs) == 4:
            eq.join(sides[0], sides[2])
            eq.join(sides[1], sides[3])
    for i, f in enumerate(valued):
        for g in valued[i + 1:]:
            if f["rel"] == g["rel"] and _same_q(f, g):
                eq.join(f["args"][0], g["args"][0])
    rights = sorted(right)
    for r in rights[1:]:
        eq.join(rights[0], r)
    return right, eq


def _parallel_seen(facts, ix):
    """A union-find of the segment ids the facts the reader sees make
    PARALLEL (wspec-svg/4, par marks): a parallel fact of two segments /
    lines / rays (by their two points), and the opposite sides of a
    parallelogram, rectangle, square or rhombus."""
    from . import canon
    from .baseline import _line_key
    seg = lambda a, b: canon.entity_id({"kind": "segment", "ends": [a, b]})
    u = _Union()
    for f in facts:
        rel, args = f.get("rel"), f.get("args") or []
        if rel == "parallel" and len(args) == 2:
            k1, k2 = (_line_key(x, ix) for x in args)
            if k1 and k2 and len(k1) == 2 and len(k2) == 2:
                u.join(seg(*sorted(k1)), seg(*sorted(k2)))
        vs = (ix.entities.get(args[0]) or {}).get("vertices") or [] \
            if args else []
        if rel in ("parallelogram", "rectangle", "square", "rhombus") and \
                len(vs) == 4:
            u.join(seg(vs[0], vs[1]), seg(vs[2], vs[3]))
            u.join(seg(vs[1], vs[2]), seg(vs[3], vs[0]))
    return u


def _same_q(f, g):
    from . import canon
    try:
        return canon.same_quantity(f["value"], f.get("unit"), g["value"],
                                   g.get("unit"))
    except Exception:                   # noqa: BLE001
        return False


def _piece_drawn(ends, pts, dr):
    """(pilot_build 2026-09-23) A segment is drawn when a hooked segment /
    line / ray / stroked polygon side contains it as a PIECE -- OC inside
    the diagonal AC -- and both its end points are drawn. The renderer draws
    such a piece once (no second, overlapping stroke); its marks are
    measured on the points and the covering piece (_measure_mark)."""
    a, b = ends
    if a not in pts or b not in pts:
        return False
    return _covered(pts[a], pts[b], _pieces(dr))


def _covered(p, q, pieces):
    """Is the straight piece p-q drawn: inside ONE drawn straight piece
    (a hooked segment / line / ray, or a side of a stroked polygon)?"""
    return any(_seg_dist(p, a, b) <= ON_TOL_PX and
               _seg_dist(q, a, b) <= ON_TOL_PX for a, b in pieces)


def _pieces(dr):
    out = [v for v in dr.segs.values()] + [v for v in dr.lines.values()] + \
        [v for v in dr.rays.values()]
    for name in dr.stroked_polys:
        vs = dr.polys[name]
        out.extend((vs[i], vs[(i + 1) % len(vs)]) for i in range(len(vs)))
    return out


def _measure_mark(m, P, pieces):
    """[detail] of one mark stroke, measured on the marked points P."""
    n = m["names"]
    pts = m["pts"]
    if m["kind"] == "tick":
        a, b = P[n[0]], P[n[1]]
        if not _covered(a, b, pieces):
            return ["segment %s%s is not drawn" % tuple(n)]
        c = ((pts[0][0] + pts[1][0]) / 2, (pts[0][1] + pts[1][1]) / 2)
        L = _d(pts[0], pts[1])
        out = []
        if not TICK_MIN_PX <= L <= TICK_MAX_PX:
            out.append("a tick %.2f px long (TICK_MIN_PX=%s..TICK_MAX_PX=%s)"
                       % (L, TICK_MIN_PX, TICK_MAX_PX))
        if _seg_dist(c, a, b) > ON_TOL_PX:
            out.append("the tick's centre is %.3f px off the segment > "
                       "ON_TOL_PX=%s" % (_seg_dist(c, a, b), ON_TOL_PX))
        if _dir_diff(pts[0], pts[1], a, b) < TICK_MIN_DEG:
            out.append("the tick crosses at %.1f deg < TICK_MIN_DEG=%s"
                       % (_dir_diff(pts[0], pts[1], a, b), TICK_MIN_DEG))
        mid = ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)
        if _d(c, mid) > TICK_SPREAD_PX:
            out.append("the tick is %.1f px from the segment's middle > "
                       "TICK_SPREAD_PX=%s" % (_d(c, mid), TICK_SPREAD_PX))
        return out
    if m["kind"] == "par":
        a, b = P[n[0]], P[n[1]]
        if not _covered(a, b, pieces):
            return ["segment %s%s is not drawn" % tuple(n)]
        if len(pts) != 3:
            return ["a parallel arrow is 3 points (leg, tip, leg), not %d"
                    % len(pts)]
        e1, tip, e2 = pts
        out = []
        if _seg_dist(tip, a, b) > ON_TOL_PX:
            out.append("the arrow's tip is %.3f px off the segment > "
                       "ON_TOL_PX=%s" % (_seg_dist(tip, a, b), ON_TOL_PX))
        mid = ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)
        if _d(tip, mid) > TICK_SPREAD_PX:
            out.append("the arrow is %.1f px from the segment's middle > "
                       "TICK_SPREAD_PX=%s" % (_d(tip, mid), TICK_SPREAD_PX))
        em = ((e1[0] + e2[0]) / 2, (e1[1] + e2[1]) / 2)
        L = _d(a, b)
        u = ((b[0] - a[0]) / L, (b[1] - a[1]) / L)
        if abs((em[0] - a[0]) * u[1] - (em[1] - a[1]) * u[0]) > ON_TOL_PX:
            out.append("the arrow's legs are not symmetric about the "
                       "segment (ON_TOL_PX=%s)" % ON_TOL_PX)
        if abs(_d(e1, tip) - _d(e2, tip)) > PAR_LEG_DIFF_PX:
            out.append("the arrow's legs are %.2f and %.2f px long (differ "
                       "by > PAR_LEG_DIFF_PX=%s)" % (_d(e1, tip), _d(e2, tip),
                                                     PAR_LEG_DIFF_PX))
        for e in (e1, e2):
            leg = _d(e, tip)
            if not PAR_LEG_MIN_PX <= leg <= PAR_LEG_MAX_PX:
                out.append("a leg %.2f px (PAR_LEG_MIN_PX=%s..PAR_LEG_MAX_"
                           "PX=%s)" % (leg, PAR_LEG_MIN_PX, PAR_LEG_MAX_PX))
            elif not PAR_MIN_DEG <= _dir_diff(e, tip, a, b) <= PAR_MAX_DEG:
                out.append("a leg %.1f deg off the segment (PAR_MIN_DEG=%s.."
                           "PAR_MAX_DEG=%s)" % (_dir_diff(e, tip, a, b),
                                                PAR_MIN_DEG, PAR_MAX_DEG))
        return out
    A, V, B = P[n[0]], P[n[1]], P[n[2]]
    for arm, q in ((n[0], A), (n[2], B)):
        if not _covered(V, q, pieces):
            return ["arm %s%s of the angle is not drawn" % (n[1], arm)]
    whole = _angle(V, A, B)
    if whole is None:
        return ["an arm shorter than MIN_ARM_PX=%s" % MIN_ARM_PX]
    on = [(_seg_dist(p, V, A) <= ON_TOL_PX, _seg_dist(p, V, B) <= ON_TOL_PX)
          for p in (pts[0], pts[-1])]
    if not ((on[0][0] and on[1][1]) or (on[0][1] and on[1][0])):
        return ["the mark does not run from one drawn arm to the other "
                "(ends > ON_TOL_PX=%s off the arms)" % ON_TOL_PX]
    first = A if on[0][0] and on[1][1] else B
    if m["kind"] == "right":
        if len(pts) != 3:
            return ["a right-angle mark is 3 points (leg, corner, leg), "
                    "not %d" % len(pts)]
        out = []
        for p in (pts[0], pts[2]):
            if not RIGHT_MIN_PX <= _d(p, V) <= RIGHT_MAX_PX:
                out.append("a leg %.2f px (RIGHT_MIN_PX=%s..RIGHT_MAX_PX=%s)"
                           % (_d(p, V), RIGHT_MIN_PX, RIGHT_MAX_PX))
        corner = (pts[0][0] + pts[2][0] - V[0], pts[0][1] + pts[2][1] - V[1])
        if _d(pts[1], corner) > JOIN_TOL_PX:
            out.append("the corner is %.3f px off the square > JOIN_TOL_PX"
                       "=%s" % (_d(pts[1], corner), JOIN_TOL_PX))
        if abs(whole - 90) > ANGLE_TOL_DEG:
            out.append("the marked angle is drawn %.2f deg, not 90 "
                       "(ANGLE_TOL_DEG=%s)" % (whole, ANGLE_TOL_DEG))
        return out
    # arc
    r0 = _d(pts[0], V)
    out = []
    # (its ends lie ON the drawn arms, so it is shorter than both)
    if not ARC_MIN_R_PX <= r0 <= ARC_MAX_R_PX:
        out.append("radius %.2f px (ARC_MIN_R_PX=%s..ARC_MAX_R_PX=%s)"
                   % (r0, ARC_MIN_R_PX, ARC_MAX_R_PX))
    worst = max(abs(_d(p, V) - r0) for p in pts)
    if worst > JOIN_TOL_PX:
        out.append("not one circle about the vertex: a point %.3f px off "
                   "the radius > JOIN_TOL_PX=%s" % (worst, JOIN_TOL_PX))
    # (close_gaps VD3-02) between the samples too: every chord's midpoint
    # stays within ARC_SAGITTA_PX of the circle -- a 2-point chord or a bent
    # 3-point line is not an arc
    sag = max(r0 - _d(((p[0] + q[0]) / 2, (p[1] + q[1]) / 2), V)
              for p, q in zip(pts, pts[1:]))
    if sag > ARC_SAGITTA_PX:
        out.append("a chord between two samples strays %.2f px inside the "
                   "circle > ARC_SAGITTA_PX=%s (straight pieces, not an arc)"
                   % (sag, ARC_SAGITTA_PX))
    other = B if first is A else A
    last = -1.0
    for p in pts:
        t1, t2 = _angle(V, first, p), _angle(V, p, other)
        if t1 is None or t2 is None or \
                abs(t1 + t2 - whole) > ANGLE_TOL_DEG or t1 <= last:
            out.append("the arc leaves its angle or turns back (every point "
                       "inside the angle, from arm to arm)")
            break
        last = t1
    return out


def _check_marks(dr, ix, fig, figure_id, out):
    """Every mark: measured (GEOM_MARK_OFF), one mark per object
    (GEOM_DUPLICATE_MARKER), n strokes for a count-n mark, and its claim
    seen by the reader (GEOM_MARK_UNSUPPORTED)."""
    P = dr.pts
    pieces = _pieces(dr)
    by_obj = {}
    for m in dr.marks:
        # (wspec-svg/4) a segment may carry an equality mark AND a parallel
        # arrow; two marks of one family on one object are a duplicate
        by_obj.setdefault((_mark_eid(m), m["kind"] == "par"), []).append(m)
    classes = {}
    for eid, _fam in sorted(by_obj):
        ms = by_obj[(eid, _fam)]
        kinds = sorted(set((m["kind"], m["n"]) for m in ms))
        if len(kinds) > 1:
            out.append(Issue("GEOM_DUPLICATE_MARKER", figure_id, "%s carries "
                             "two marks: %s" % (eid, ", ".join(
                                 sorted(set(m["value"] for m in ms))))))
            continue
        kind, n = kinds[0]
        m0 = ms[0]
        missing = [x for x in m0["names"] if x not in P]
        if missing:
            out.append(Issue("GEOM_MISSING_ELEMENT", figure_id, "point(s) %s "
                             "of mark %r not marked" % (", ".join(missing),
                                                        m0["value"])))
            continue
        if len(ms) != n:
            out.append(Issue("GEOM_MARK_OFF", figure_id, "mark %r is drawn "
                             "with %d strokes, its count is %d" % (
                                 m0["value"], len(ms), n)))
            continue
        bad = []
        for m in ms:
            bad.extend(_measure_mark(m, P, pieces))
        if n > 1 and not bad:
            if kind == "arc":
                V = P[m0["names"][1]]
                rs = sorted(_d(m["pts"][0], V) for m in ms)
                gap = min(rs[i + 1] - rs[i] for i in range(n - 1))
            elif kind == "par":
                ts = [m["pts"][1] for m in ms]
                gap = min(_d(ts[i], ts[j]) for i in range(n)
                          for j in range(i + 1, n))
            else:
                cs = [((m["pts"][0][0] + m["pts"][1][0]) / 2,
                       (m["pts"][0][1] + m["pts"][1][1]) / 2) for m in ms]
                gap = min(_d(cs[i], cs[j]) for i in range(n)
                          for j in range(i + 1, n))
            if gap < MARK_GAP_PX:
                bad.append("its %d strokes are %.2f px apart < MARK_GAP_PX="
                           "%s (they print as one)" % (n, gap, MARK_GAP_PX))
        for b in bad:
            out.append(Issue("GEOM_MARK_OFF", figure_id, "%r: %s"
                             % (m0["value"], b)))
        classes.setdefault((kind, n), []).append(eid)
    if not classes:
        return
    right, eq = _claims_seen(_reader_facts(fig, ix), ix)
    par = _parallel_seen(_reader_facts(fig, ix), ix)
    for (kind, n), eids in sorted(classes.items()):
        if kind == "par":
            if len(set(par.find(e) for e in eids)) > 1:
                out.append(Issue("GEOM_MARK_UNSUPPORTED", figure_id, "the "
                                 "par%s arrows on %s claim them parallel; the "
                                 "facts the reader of the figure sees do "
                                 "not" % (n if n > 1 else "", ", ".join(
                                     eids))))
            # parallel arrows of one class point the same way
            dirs = []
            for m in dr.marks:
                if m["kind"] == "par" and m["n"] == n:
                    e1, tip, e2 = m["pts"]
                    em = ((e1[0] + e2[0]) / 2, (e1[1] + e2[1]) / 2)
                    L = _d(em, tip)
                    if L > 0:
                        dirs.append(((tip[0] - em[0]) / L,
                                     (tip[1] - em[1]) / L, m["value"]))
            for u in dirs[1:]:
                if u[0] * dirs[0][0] + u[1] * dirs[0][1] < \
                        math.cos(math.radians(ANGLE_TOL_DEG * 4)):
                    out.append(Issue("GEOM_MARK_OFF", figure_id, "the "
                                     "parallel arrows %r and %r do not point "
                                     "the same way" % (dirs[0][2], u[2])))
                    break
            continue
        if kind == "right":
            for eid in eids:
                if eid not in right:
                    out.append(Issue("GEOM_MARK_UNSUPPORTED", figure_id,
                                     "a right-angle mark on %s: no fact the "
                                     "reader of the figure sees makes it 90 "
                                     "degrees" % eid))
        elif len(set(eq.find(e) for e in eids)) > 1:
            out.append(Issue("GEOM_MARK_UNSUPPORTED", figure_id, "the %s%s "
                             "marks on %s claim them equal; the facts the "
                             "reader of the figure sees do not" % (
                                 kind, n if n > 1 else "", ", ".join(eids))))


def _overhang(x, y, p, q):
    """How far the drawn piece p-q runs past point x, going away from y
    (<= 0 when it stops at x or short of it)."""
    L = _d(x, y)
    if L == 0:
        return 0.0
    ux, uy = (x[0] - y[0]) / L, (x[1] - y[1]) / L
    return max((e[0] - x[0]) * ux + (e[1] - x[1]) * uy for e in (p, q))


def _check_lines(dr, figure_id, out):
    """A data-line passes through both its points; a data-ray starts on its
    first point and passes its second."""
    P = dr.pts
    for (a, b), (p, q) in sorted(dr.lines.items()):
        for n in (a, b):
            if n in P and _seg_dist(P[n], p, q) > ON_TOL_PX:
                out.append(Issue("GEOM_NOT_ON_SEGMENT", figure_id, "line "
                                 "%s%s drawn %.3f px off %s > ON_TOL_PX=%s"
                                 % (a, b, _seg_dist(P[n], p, q), n,
                                    ON_TOL_PX)))
        if a in P and b in P:
            # (close_gaps SV3-03/05) a line runs past BOTH of its points
            over = min(_overhang(P[a], P[b], p, q), _overhang(P[b], P[a], p, q))
            if over < LINE_OVERHANG_PX:
                out.append(Issue("GEOM_KIND_OFF", figure_id, "line %s%s ends "
                                 "%.1f px past its points < LINE_OVERHANG_PX"
                                 "=%s (it prints as a segment)" % (
                                     a, b, over, LINE_OVERHANG_PX)))
    for (a, b), (p, q) in sorted(dr.rays.items()):
        if a in P and _d(p, P[a]) > JOIN_TOL_PX:
            out.append(Issue("GEOM_ENDPOINT_OFF", figure_id, "ray %s%s starts"
                             " %.3f px off %s > JOIN_TOL_PX=%s" % (
                                 a, b, _d(p, P[a]), a, JOIN_TOL_PX)))
        if b in P and _seg_dist(P[b], p, q) > ON_TOL_PX:
            out.append(Issue("GEOM_NOT_ON_SEGMENT", figure_id, "ray %s%s "
                             "drawn %.3f px off %s > ON_TOL_PX=%s" % (
                                 a, b, _seg_dist(P[b], p, q), b, ON_TOL_PX)))
        elif a in P and b in P and \
                _overhang(P[b], P[a], p, q) < LINE_OVERHANG_PX:
            # (close_gaps SV3-03/05) a ray runs past its second point, away
            # from its first
            out.append(Issue("GEOM_KIND_OFF", figure_id, "ray %s%s ends %.1f "
                             "px past %s < LINE_OVERHANG_PX=%s (it prints as "
                             "a segment)" % (a, b, _overhang(P[b], P[a], p, q),
                                             b, LINE_OVERHANG_PX)))


def check_geometry(path, spec, figure_id):
    """[Issue] for figure `figure_id` of `spec`, measured on the file."""
    from .baseline import _figure_shows, _object_drawn
    out = []
    try:
        dr = read_svg(path)
    except Exception as e:   # noqa: BLE001 -- any parse failure is a refusal
        return [Issue("GEOM_BAD_SVG", path, str(e))]
    if dr.dialect:
        return dr.dialect    # nothing measured outside the dialect
    if dr.dups:
        return dr.dups
    pts, segs = dr.pts, dr.segs
    ix = S.Index(spec)
    fig = ix.figures[figure_id]
    ents = ix.entities
    shown = _figure_shows(fig, ix)
    _check_hooks(dr, ix, shown, figure_id, out)
    if out:
        return out           # an unknown hook: nothing it says is trusted
    # what the figure must mark: its listed entities and everything a drawn
    # fact is drawn on (a drawn name(M) shows M even when M is not listed)
    drawn = set(fig.get("draws") or [])
    listed = set(fig["entities"])
    for d in sorted(drawn):
        for a in (ix.facts.get(d) or {}).get("args") or []:
            listed |= S.entity_closure(a, ix)
    listed = sorted(x for x in listed if x in ents)
    for eid in listed:
        e = ents[eid]
        k = e["kind"]
        if k == "point" and e["name"] not in pts:
            out.append(Issue("GEOM_MISSING_ELEMENT", figure_id,
                             "point " + e["name"]))
        elif k == "segment" and tuple(sorted(e["ends"])) not in segs and \
                not _piece_drawn(e["ends"], pts, dr):
            out.append(Issue("GEOM_MISSING_ELEMENT", figure_id,
                             "segment " + "".join(e["ends"])))
        elif k == "line" and tuple(sorted(e["through"])) not in dr.lines:
            out.append(Issue("GEOM_MISSING_ELEMENT", figure_id,
                             "line " + "".join(e["through"])))
        elif k == "ray" and (e["from"], e["through"]) not in dr.rays:
            out.append(Issue("GEOM_MISSING_ELEMENT", figure_id,
                             "ray " + e["from"] + e["through"]))
        elif k in ("circle", "arc"):
            out.append(Issue("GEOM_MISSING_ELEMENT", figure_id,
                             "%s %s: the dialect draws no %s yet (no radius "
                             "relation to measure it by)" % (k, eid, k)))
    # every hooked segment is measured, listed or not
    for (a, b), (p, q) in sorted(segs.items()):
        pa, pb = pts.get(a), pts.get(b)
        if pa is None or pb is None:
            miss = [n for n in (a, b) if n not in pts and
                    ("point " + n) not in [i.detail for i in out]]
            for n in miss:
                out.append(Issue("GEOM_MISSING_ELEMENT", figure_id,
                                 "point " + n))
            continue
        worst = min(max(_d(p, pa), _d(q, pb)), max(_d(p, pb), _d(q, pa)))
        if worst > JOIN_TOL_PX:
            out.append(Issue("GEOM_ENDPOINT_OFF", figure_id,
                             "%s%s end off by %.3f px > JOIN_TOL_PX=%s"
                             % (a, b, worst, JOIN_TOL_PX)))
    _check_lines(dr, figure_id, out)
    _check_polys(dr, ix, figure_id, out)
    # two different marked points read as one
    names = sorted(pts)
    for i, n in enumerate(names):
        for m in names[i + 1:]:
            if _d(pts[n], pts[m]) <= NEAR_POINT_PX:
                out.append(Issue("GEOM_POINTS_TOO_CLOSE", figure_id,
                                 "%s and %s are %.3f px apart <= "
                                 "NEAR_POINT_PX=%s" % (
                                     n, m, _d(pts[n], pts[m]),
                                     NEAR_POINT_PX)))
    _check_marks(dr, ix, fig, figure_id, out)
    # the relations: drawn facts + visible given/context facts (MEASURE)
    shown_pt = set(e["name"] for eid, e in ents.items()
                   if e.get("kind") == "point" and
                   _object_drawn(eid, shown, ix))
    vis = set(ix.visible_scopes(fig["scope"]))
    accurate = fig["figure_accuracy"] == "accurate"
    scale_obs = []
    from . import figure_scopes618 as FS618
    _state, state_error = FS618.state_record(spec, fig)
    if state_error:
        out.append(Issue(FS618.STATE_CODE, figure_id, state_error))
    applicable = [f for f in sorted(ix.facts.values(), key=lambda f: f["id"])
                  if not _state or f["id"] != _state["old_height"]]
    for f in applicable:
        how = MEASURE.get(f.get("rel"), ("none",))[0]
        if how == "none":
            continue
        if f["id"] not in drawn and (f.get("item") not in vis or f.get(
                "role") not in ("given", "context")):
            continue
        if how in ("metric", "scale") and not accurate:
            continue
        need = _fact_points(f, ix)
        if f["id"] not in drawn:
            if how == "incidence":
                if need[0] not in shown_pt and need[0] not in pts:
                    continue              # the figure does not show it
            elif not all(n in shown_pt or n in pts for n in need):
                continue
        missing = [n for n in need if n not in pts]
        if missing:
            out.append(Issue("GEOM_MISSING_ELEMENT", f["id"],
                             "point(s) %s not marked" % ", ".join(missing)))
            continue
        for code, detail in _measure(f, ix, pts, scale_obs):
            out.append(Issue(code, f["id"], detail))
    for dim in sorted(set(o[0] for o in scale_obs), key=str):
        obs = sorted((s, fid) for d, s, fid in scale_obs if d == dim)
        if len(obs) > 1 and obs[0][0] > 0 and \
                obs[-1][0] / obs[0][0] - 1 > SCALE_TOL_REL:
            out.append(Issue("GEOM_LENGTH_OFF", figure_id, "not one scale: "
                             "%.4f px/unit (%s) vs %.4f (%s) > "
                             "SCALE_TOL_REL=%s" % (obs[0][0], obs[0][1],
                                                   obs[-1][0], obs[-1][1],
                                                   SCALE_TOL_REL)))
    _check_labels(dr, ix, fig, shown_pt, figure_id, out)
    # (v6.17-noam V2) a parallel-lines rule the spec states (a derived fact
    # of the spec given here -- the public one: released steps; the private
    # one: every step) must name the pair the figure DRAWS: the directions
    # of the two angles' arms, read off the marked points
    from . import rules617 as R617
    out.extend(R617.figure_issues(ix, pts, figure_id))
    return out
