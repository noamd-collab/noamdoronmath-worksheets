# -*- coding: utf-8 -*-
"""wspec.hooks_pie -- the PIE family's hooks for the v6.16 acceptance runner
(v616/HOOKS.txt, sections [RUNNER] and [PIE]). Owner: the pie engine. The
runner's adapter (acceptance/tools/v616_engine.py) imports this module and
reads the attributes below; nothing here reaches into another owner's code.

    API_VERSION                      "v616-pie/1"
    render(public_spec, figure_id, **settings)
        -> {"svg", "object_map", "placements", "validation"}
        refusal: wspec.render.gate.RenderRefused (.code, message) -- invalid
        data: .code RENDER_PIE_DATA_INVALID, the message names the reason
        (PIE_SUM_NOT_TOTAL / PIE_VALUE_NOT_POSITIVE / PIE_REST_NOT_POSITIVE
        / PIE_UNDERDETERMINED / PIE_EQUAL_CONFLICT / PIE_VALUE_UNIT); nothing
        is returned. validation["status"] FAIL = not fit to print (named
        issues), e.g. RENDER_LABEL_NO_PLACE.
    validate(spec) -> [(code, detail)]   [] = valid (closed grammar: an
        undeclared key anywhere in a pie entity / fact / figure / frame is an
        issue, PIE_UNKNOWN_FIELD)
    public_model(spec) -> dict           a pie-only spec without questions;
        (v6.16 integrate) or a SHEET public model without its public_hash
        (the runner's PM28-PM30 mutation of a pilot): re-scanned, re-hashed
    check(svg, object_map, public_spec, figure_id, ocr=True,
          answer_guard=None, **kw) -> report (check.pie.check_pie)
    object_report(report, object_id) -> the verdict of one object
    highlight(svg, object_map, object_id) -> svg
    check_highlight(base_svg, hl_svg, report, object_id) -> {status, findings}
        (v6.16 r2) object_id FIGURE_OBJECT = "figure" is the WHOLE figure
        (every element: all discs, tiles, labels, captions) -- the object
        of a pie corpus ADDENDUM 1 scenario; no object-map entry (earlier
        maps are byte-identical)
    data_verdict(spec, figure_id) -> {"valid": bool, "reasons": [code...],
        "parts": {pie id: {sector id: "exact value"}}}  (exact arithmetic)
    make_pie / make_build / make_spec    author helpers (wspec.pie) that add
        nothing and drop nothing -- the runner's translator may use them.
    (v6.16 r2, AAF1 R-A3 / R-A5; v616_engine.AAF1_HOOKS)
    figure_discs(public_spec, figure_id) -> [disc]  the figure's discs in the
        corpus-neutral shape of the pie corpus ADDENDUM 1 baseline.discs,
        read right to left (d1 rightmost); each tile carries its "sector"
    discs_to_spec(public_spec, figure_id, discs) -> public model  the
        figure's discs replaced (declared values, tile order, start,
        direction, caption, centre dot), re-hashed and re-scanned
    SPEC_SHAPE                           the keys of one pie figure (text)
"""
from . import pie as P

API_VERSION = "v616-pie/1"
FAMILY = P.FAMILY
FIGURE_OBJECT = "figure"        # (v6.16 r2) the whole figure

make_pie = P.make_pie
make_build = P.make_build
make_spec = P.make_spec
pie_name = P.pie_name
figure_discs = P.figure_discs                   # v6.16 r2 (AAF1 R-A3)
discs_to_spec = P.discs_to_spec                 # v6.16 r2 (AAF1 R-A5)

SPEC_SHAPE = u"""\
A pie figure of the spec (wspec/pie.py; a full example: selfcheck_v616_pie.py
CASES). Entities: pie {id "pie:<name>", name}; sector {id
"sector:<pie name>:<key>", pie, key, name (the printed label)}; build_circle
{id "bcirc:<name>", name}. <name> ^[a-z][a-z_]*$ and <key> ^[a-z]{1,2}$ carry
no digit. Facts: sector_value(sector) given {value, unit "%" | "deg"} /
target (a missing sector: NO value) / answer; sector_equal(sorted sectors)
given (equal shares, no value); pie_total(pie) given {value} (drawn = the
total label "סך הכול: N"); sector_angle / sector_percent / sector_count
target / answer. Figure {id, scope, figure_accuracy "accurate", entities,
draws (the drawn given fact ids), frame}. Frame {family "pie_chart", layout
"single" | "side_by_side", parts [PART] (1 | 2), same_size (side_by_side),
shared_legend (side_by_side)}. PIE PART {part "pie", pie, side "left" |
"right" (side_by_side), unit "percent" | "degree", order [sector ids, the
first starts at start], start 0..359 (deg clockwise from 12 o'clock),
direction "clockwise" | "counterclockwise", names "in_sector" | "legend",
values "in_sector" | "legend" | "none", outside [sector ids] (optional),
caption (optional text), fills ["#rrggbb" per sector] (optional)}. BUILD
PART {part "build", circle, side, centre_dot bool}.
Corpus description -> spec: kind pie -> PIE PART; value N -> sector_value
given N (drawn unless values none); "rest" -> sector_value TARGET (listed in
the description's missing) -- the renderer draws the exact rest and never
prints it; "equal" -> no sector_value, one sector_equal over the equal
sectors; label_mode in_sector | legend -> names; value_labels in_sector |
none -> values (legend_shows "name+value" -> values "legend");
outside_labels -> outside; caption -> caption; total_label "סך הכול: N" ->
pie_total given N (drawn); fills -> fills; start_deg_clockwise_from_12 ->
start; direction -> direction; layout side_by_side + same_size /
shared_legend -> the frame; kind build_circle + center_dot -> BUILD PART
centre_dot (its text_data is stem data, never drawn).
(v6.16 r2, wspec-pie/1.1, additive) layout "row": 2..3 parts in READING
order right to left (part 0 = d1, the rightmost disc), same_size true, no
side key, no shared legend, every part a "caption" (no digit, no word of a
whole / count: השלם סה״כ סך הכול תלמידים פריטים נשאלים אנשים; distinct);
a BUILD PART may carry "caption" (an EMPTY disc, printed under it, hook
bcap); names "none" (no sector name printed; the entity name is a never
printed handle); PIE PART "regions" [sector ids] = undivided REGIONS (one
wedge, never a name, at most its given value label INSIDE it, never
outside / a leader, not in a legend pie); unit "fraction" (a value is a
fraction of the disc, e.g. "1/6", NO unit, sum 1; values none). Display
setting row_radius (optional, 68.04..150 px; default 84 = 22.2 mm).
Corpus ADDENDUM 1 declared discs -> spec: disc state empty -> BUILD PART
(+ caption); drawn -> PIE PART (+ caption in a row); tile region -> its
sector in "regions"; wedge name_label -> names in_sector (a disc without
names -> names none); value_label / region label -> values in_sector (else
none); a declared number -> sector_value given; "rest" -> no value
("missing": true -> sector_value TARGET); "equal" -> sector_equal; unit
fraction -> the fraction as the value, no unit; 2..3 discs -> layout row,
same_size true (the engine owner's own reading: v616/pie_engine/r2/
aaf1_smoke.py translate())."""


def render(public_spec, figure_id, **settings):
    from .render import pie as RP
    ds = dict(settings)
    ds["figure"] = figure_id
    return RP.render(public_spec, ds, RP.ENGINE_VERSION)


def validate(spec):
    return [(i.code, "%s: %s" % (i.where, i.detail))
            for i in P.spec_issues(spec)]


def public_model(spec):
    """a pie-only spec without questions: pie.public_model. (v6.16
    integrate) A SHEET model -- a pilot's delivered public_spec.json whose
    public_hash the runner dropped after a PM28-PM30 data mutation -- is
    re-scanned (the house scan + the pie scan, pie.public_issues) and
    re-hashed exactly as project.public_model hashes; a scan issue refuses
    it (ValueError). An author sheet spec is not public: it goes through
    project.public_model (the level build), never through this hook."""
    if not spec.get("questions"):
        return P.public_model(spec)
    import copy
    import hashlib
    from . import canon
    from . import project as PR
    top = set(PR.PUBLIC_KEYS["top"]) - {"public_hash"}
    if set(spec) != top:
        raise ValueError("pie hook: a sheet model with keys %s is no public "
                         "model without its hash (an author sheet spec goes "
                         "through project.public_model)"
                         % sorted(set(spec) ^ top))
    pub = copy.deepcopy(spec)
    pub["public_hash"] = hashlib.sha256(
        canon.dumps(pub).encode("utf-8")).hexdigest()
    bad = P.public_issues(pub)
    if bad:
        raise ValueError("pie hook: public model refused: %s" % "; ".join(
            str(i) for i in bad[:6]))
    return pub


def check(svg, object_map, public_spec, figure_id, ocr=True,
          answer_guard=None, **kw):
    from .check import pie as CP
    return CP.check_pie(svg, object_map, public_spec, figure_id, ocr=ocr,
                        answer_guard=answer_guard, **kw)


def object_report(report, object_id):
    from .check import pie as CP
    return CP.object_report(report, object_id)


def highlight(svg, object_map, object_id):
    from .render import pie_hl as RH
    return RH.highlight(svg, object_map, object_id)


def check_highlight(base_svg, hl_svg, report, object_id):
    from .check import pie_hl as CH
    return CH.check_highlight(base_svg, hl_svg, report, object_id)


def data_verdict(spec, figure_id):
    ix = P.PieIndex(spec)
    fig = ix.figures.get(figure_id)
    if fig is None or not P.is_pie_figure(fig):
        return {"valid": False, "reasons": ["PIE_NO_FIGURE"], "parts": {}}
    reasons, parts = [], {}
    for p in fig["frame"].get("parts") or []:
        if p.get("part") != "pie":
            continue
        r = P.resolve(ix, p)
        reasons += [c for c, _d in r.problems]
        parts[p["pie"]] = dict((s, str(v)) for s, v in r.value.items()
                               if v is not None)
    return {"valid": not reasons, "reasons": sorted(set(reasons)),
            "parts": parts}
