# -*- coding: utf-8 -*-
"""SVG normalisation -- ONLY for the reproducibility comparison (C5).

Rebuilding a figure from the public model must give the same drawing; a
formatting difference (attribute order, "140" vs "140.00", whitespace) must
not read as a change. Coordinates are therefore rounded to REPRO_DECIMALS.
That rounding CAN equate a real 0.4 px defect with a correct file -- which
is exactly why the geometry check (geomcheck.py) never uses this module and
always reads the ORIGINAL file."""
import re
import xml.etree.ElementTree as ET

# decimals kept by the reproducibility compare. 0 = whole pixels: a renderer
# change below half a pixel is not a "different drawing" for this compare.
# NOT a correctness tolerance -- see geomcheck.py for those.
REPRO_DECIMALS = 0
NUM = re.compile(r"-?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?")
COORD_ATTRS = ("x", "y", "x1", "y1", "x2", "y2", "cx", "cy", "r", "rx", "ry",
               "width", "height", "points", "d", "transform")


def _round(m):
    v = round(float(m.group(0)), REPRO_DECIMALS)
    if REPRO_DECIMALS == 0:
        v = int(v)
    s = repr(v)
    return "0" if s in ("-0", "-0.0") else s


def _norm_el(el):
    tag = el.tag.split("}")[-1]
    attrs = []
    for k in sorted(el.attrib):
        v = " ".join(el.attrib[k].split())
        if k.split("}")[-1] in COORD_ATTRS:
            v = NUM.sub(_round, v)
        attrs.append('%s="%s"' % (k.split("}")[-1], v))
    text = " ".join((el.text or "").split())
    kids = "".join(_norm_el(c) for c in el)
    return "<%s %s>%s%s</%s>" % (tag, " ".join(attrs), text, kids, tag)


def normalise(svg_text):
    return _norm_el(ET.fromstring(svg_text))


def repro_equal(svg_a, svg_b):
    return normalise(svg_a) == normalise(svg_b)
