# -*- coding: utf-8 -*-
"""v6.12 (BRIEF_V612 section 1): the two figure FAMILIES of the spec -- the
coordinate plane and the number line -- as schema. A figure belongs to a
family when it carries a `frame`; the frame is the mathematics of its axes
(range, step, which ticks print a number, grid), not a display setting:
the student reads positions off it.

  coordinate_plane  {"family": "coordinate_plane", "plane": "plane:xy",
                     "axes": [AXIS(x), AXIS(y)], "grid": true|false}
  number_line       {"family": "number_line", AXIS fields on the frame}
  AXIS              {"axis": "axis:x", "min": n, "max": n, "step": n,
                     "label_every": k | "label_at": [n, ...], "form"?}

  * ticks are min, min+step, ..., max (1..MAX_INTERVALS intervals); on a
    plane both axes pass through the origin (min <= 0 <= max, 0 a tick);
  * label_every k: every k-th tick prints its number, counted from 0 when
    0 is a tick, else from min; label_at: exactly these ticks print;
  * a frame is always accurate (figure_accuracy 'accurate').

A figure that DRAWS a given coordinate fact prints that value at its point
(a labelled point of a number line: "P" above, "−3" below); a figure that
draws a 'guide' draws the dashed reading guide from the point to that axis
-- and only then (a guide is a stated given: FAMILY_GUIDE).

What a family figure SHOWS is placed by the numbers of the spec: every
shown point needs its coordinate on every axis of the frame (coordinate
facts of its question: given, derived, context or an answer), inside the
range. The facts of the families are checked against each other
(distance = |a - b|, |a|, jump = to - from, whole numbers of an interval,
interval_value = the frame's step).

Leaks (a point the student must plot is private until answered):
  FIGURE_SHOWS_TO_PLOT  a figure of the question shows the point / number
                        of a to_plot (a printed page shows every figure of
                        its question at once);
  FRAME_SHOWS_TARGET    a framed figure of the question shows a point whose
                        coordinate a non-read_off item asks (reading it off
                        the grid IS the answer), or prints two neighbouring
                        ticks of an axis whose interval value is asked.

The PUBLIC frame is what the figure prints: per axis the number of
intervals and the printed labels by tick index -- never min / max / step
(a target 'interval_value' is not leaked through them). The private model
carries the full frame.

(v6.16 gaps r3, the F1 SKETCH plane -- G7-T08 c 1ד / 11ד) a coordinate
plane may be a SKETCH: the frame carries
  "sketch": {"places": {"pt:A": [x, y], ...}}      (frame units)
and then:
  * the figure is schematic (figure_accuracy 'schematic'): the student
    reads NO position off it -- it prints no number (every axis
    "label_at": []) and no tick mark; the grid is the frame's choice;
  * every point it shows sits at its sketch place (inside the range),
    never at its coordinates, which it need not have in the question;
    exactly the shown points have a place (FRAME_POINT_UNPLACED /
    FRAME_BAD);
  * the places agree with every coordinate value of the question (any
    role, private included): the same side of each axis as the value, and
    the same order on each axis for every two shown points
    (FAMILY_INCONSISTENT) -- a sketch may move a point, never across;
  * it draws no coordinate (a caption prints a number) and no reading
    guide (FRAME_BAD / FAMILY_GUIDE); nothing is read off it, so it is no
    FRAME_SHOWS_TARGET and its step is no interval value.
  The PUBLIC sketch is {"origin": [i, j], "places": {"pt:A": [i, j]}} in
  tick indices (from min), like the labels: never a value, min or step."""
from fractions import Fraction

from . import canon
from .errors import Issue, SpecError

FAMILIES = ("coordinate_plane", "number_line")
MAX_INTERVALS = 40
LABEL_EVERY_MAX = 10
PLANE_FRAME_FIELDS = {"family": True, "plane": True, "axes": True,
                      "grid": True,
                      # (v6.16 gaps r3, F1) a sketch plane (docstring)
                      "sketch": False}
SKETCH_FIELDS = {"places": True}
PUBLIC_SKETCH_KEYS = ("origin", "places")
AXIS_FRAME_FIELDS = {"axis": True, "min": True, "max": True, "step": True,
                     "label_every": False, "label_at": False, "form": False,
                     "break_before": False}
LINE_FRAME_FIELDS = dict(AXIS_FRAME_FIELDS, family=True)
# entity kinds a figure of each family may show (closed)
FAMILY_ENTITY_KINDS = {
    "coordinate_plane": ("point", "segment", "line", "ray", "polygon",
                         "axis", "plane", "tick",
                         # (v6.16 gaps, G2) the origin. (An unnamed vertex,
                         # G5, is NOT here: a polygon declared by coordinates
                         # only is never shown -- FAMILY_ENTITY)
                         "origin"),
    "number_line": ("point", "number", "axis", "jump", "interval", "tick")}
# number-line-only kinds: never on a figure without a number_line frame
LINE_ONLY_KINDS = ("jump", "interval")
# roles whose value is the true coordinate / quantity
VALUE_ROLES = ("given", "derived", "context", "answer", "to_prove")
# family relations whose value is a rational (no surd); distance may be a
# surd (a slanted segment of the plane) and may carry a LENGTH unit
RATIONAL_RELS = ("coordinate", "abs_value", "jump_value", "interval_value",
                 "count_integers")
READ_TASKS = ("read_off", "measure")
PUBLIC_AXIS_KEYS = ("axis", "intervals", "labels", "form", "break_before")


def _S():
    from . import schema as S
    return S


def _q(v):
    """exact rational of v, or None"""
    try:
        a, b, r = canon.parse_exact(v)
    except Exception:                   # noqa: BLE001
        return None
    return a if r == 1 else None


# ---------------------------------------------------------------- frame ---
def frame_axes(fr):
    """The axis specs of a frame, in order (a number line: the frame)."""
    if not isinstance(fr, dict):
        return []
    if fr.get("family") == "coordinate_plane":
        return [a for a in fr.get("axes") or [] if isinstance(a, dict)]
    if fr.get("family") == "number_line":
        return [fr]
    return []


def _ax_nums(ax):
    return _q(ax.get("min")), _q(ax.get("max")), _q(ax.get("step"))


def ticks(ax):
    lo, hi, st = _ax_nums(ax)
    if None in (lo, hi, st) or st <= 0 or hi <= lo:
        return []
    n = (hi - lo) / st
    if n.denominator != 1 or n > MAX_INTERVALS:
        return []
    return [lo + i * st for i in range(int(n) + 1)]


def labelled(ax):
    """The tick values the axis prints, in order."""
    ts = ticks(ax)
    if not ts:
        return []
    if "label_at" in ax:
        want = set(_q(v) for v in ax.get("label_at") or [])
        return [t for t in ts if t in want]
    k = ax.get("label_every")
    if not isinstance(k, int) or isinstance(k, bool) or k < 1:
        return []
    st = _q(ax.get("step"))
    anchor = Fraction(0) if Fraction(0) in ts else ts[0]
    return [t for t in ts if ((t - anchor) / (k * st)).denominator == 1]


# ------------------------------------- v6.16 gaps r3: the SKETCH plane ---
def is_sketch(fr):
    """A coordinate-plane frame that is a sketch (docstring)."""
    return isinstance(fr, dict) and fr.get("family") == "coordinate_plane" \
        and "sketch" in fr


def sketch_places(fr):
    """{point: (x, y)} of a sketch frame in FRAME units (Fractions); {} when
    not a sketch or unreadable (validation reports it)."""
    if not is_sketch(fr) or not isinstance(fr.get("sketch"), dict):
        return {}
    pl = fr["sketch"].get("places")
    out = {}
    if not isinstance(pl, dict):
        return out
    for p, xy in pl.items():
        if isinstance(xy, list) and len(xy) == 2:
            v = [_q(c) for c in xy]
            if None not in v:
                out[p] = tuple(v)
    return out


def _sketch_index(ax, v):
    """a frame value -> its tick index (from min), a Fraction"""
    lo, _hi, st = _ax_nums(ax)
    return (Fraction(v) - lo) / st


def public_sketch(fr):
    """The public form of a sketch: the origin's tick index per axis and
    every place in tick indices (from min) -- never a value, min or step."""
    axes = frame_axes(fr)
    org = [int(_sketch_index(ax, 0)) for ax in axes]
    places = {}
    for p, xy in sorted(sketch_places(fr).items()):
        places[p] = [canon.canon_number(str(_sketch_index(ax, v)))
                     for ax, v in zip(axes, xy)]
    return {"origin": org, "places": places}


def public_frame(fr):
    """What the figure PRINTS of its frame (the public model's form)."""
    if fr.get("family") == "pie_chart":
        # (v6.16 integrate) a pie frame is wholly public (wspec/pie.py)
        from . import pie as _pie
        return _pie.public_frame(fr)
    out = {"family": fr["family"]}
    if fr["family"] == "coordinate_plane":
        out["plane"] = fr["plane"]
        out["grid"] = bool(fr["grid"])
    axes = []
    for ax in frame_axes(fr):
        ts = ticks(ax)
        labs = labelled(ax)
        a = {"axis": ax["axis"], "intervals": len(ts) - 1,
             "labels": [[ts.index(t), canon.canon_number(str(t))]
                        for t in labs]}
        if ax.get("break_before"):
            a["intervals"] += 1
            a["labels"] = [[i+1,v] for i,v in a["labels"]]
            a["break_before"] = True
        if ax.get("form") is not None:
            a["form"] = ax["form"]
        axes.append(a)
    out["axes"] = axes
    if is_sketch(fr):
        out["sketch"] = public_sketch(fr)     # v6.16 gaps r3 (F1)
    return out


def private_frame(fr):
    if fr.get("family") == "pie_chart":
        # (v6.16 integrate) no min / max / step: the public form is all
        from . import pie as _pie
        return _pie.public_frame(fr)
    return canon.canon_frame(fr)


def frame_document():
    """The frame grammar, for schema.json."""
    return {"families": list(FAMILIES),
            "coordinate_plane": PLANE_FRAME_FIELDS,
            "number_line": LINE_FRAME_FIELDS,
            "axis": AXIS_FRAME_FIELDS,
            "max_intervals": MAX_INTERVALS,
            "label_every_max": LABEL_EVERY_MAX,
            "entity_kinds": dict((k, list(v)) for k, v in
                                 FAMILY_ENTITY_KINDS.items()),
            "public_axis": list(PUBLIC_AXIS_KEYS),
            "rule": "a figure with a frame is accurate; every point it "
                    "shows is placed at its coordinates (facts of its "
                    "question) inside the range; the public frame is the "
                    "printed labels by tick index, never min/max/step",
            # (v6.16 gaps r3, F1)
            "sketch": SKETCH_FIELDS,
            "public_sketch": list(PUBLIC_SKETCH_KEYS),
            "sketch_rule": "a coordinate_plane frame with 'sketch': "
                           "{'places': {point: [x, y]}} is schematic: no "
                           "number (label_at []) and no tick mark; every "
                           "shown point at its sketch place, on the side and "
                           "in the order of its coordinates; no coordinate "
                           "caption, no guide"}


def _frame_issues(g, ix, out):
    """Shape of one figure's frame. Returns True when it is usable."""
    w = "figure %s frame" % g.get("id")
    fr = g.get("frame")
    ok = [True]

    def bad(code, detail):
        out.append(Issue(code, w, detail))
        ok[0] = False

    def fields(obj, table, where):
        if not isinstance(obj, dict):
            bad("FRAME_BAD", "%s: not an object" % where)
            return False
        for k in obj:
            if k not in table:
                bad("FRAME_BAD", "%s: unknown field %r" % (where, k))
        for k, req in table.items():
            if req and k not in obj:
                bad("FRAME_BAD", "%s: missing %r" % (where, k))
        return True

    if not isinstance(fr, dict) or fr.get("family") not in FAMILIES:
        bad("FRAME_BAD", "family %r" % ((fr or {}).get("family")
                                        if isinstance(fr, dict) else fr))
        return False
    fam = fr["family"]
    table = PLANE_FRAME_FIELDS if fam == "coordinate_plane" else \
        LINE_FRAME_FIELDS
    if not fields(fr, table, fam):
        return False
    sketch = is_sketch(fr)
    if sketch:
        # (v6.16 gaps r3, F1) a sketch plane (module docstring)
        if g.get("figure_accuracy") != "schematic":
            bad("FRAME_BAD", "a sketch plane is schematic (the student "
                "reads no position off it)")
        sk = fr.get("sketch")
        if fields(sk, SKETCH_FIELDS, "sketch"):
            pl = sk.get("places")
            if not isinstance(pl, dict):
                bad("FRAME_BAD", "sketch places: {point: [x, y]}")
            else:
                for p_, xy in sorted(pl.items()):
                    if ix.kind(p_) != "point":
                        bad("FRAME_BAD", "sketch place of %r: not a point "
                            "entity" % (p_,))
                    elif not (isinstance(xy, list) and len(xy) == 2 and
                              None not in [_q(c) for c in xy]):
                        bad("FRAME_BAD", "sketch place of %s: %r (two "
                            "exact rationals)" % (p_, xy))
        for d in g.get("draws") or []:
            f_ = ix.facts.get(d) or {}
            if f_.get("rel") in ("coordinate", "guide"):
                bad("FRAME_BAD", "a sketch plane draws no %s (%s): it "
                    "prints no number and no reading guide" % (
                        f_.get("rel"), d))
    elif g.get("figure_accuracy") != "accurate":
        bad("FRAME_BAD", "a framed figure is accurate (the student reads "
            "positions off it)")
    listed = set(g.get("entities") or [])
    if fam == "coordinate_plane":
        pl = ix.entities.get(fr.get("plane")) or {}
        if pl.get("kind") != "plane":
            bad("FRAME_BAD", "plane %r is not a plane entity"
                % (fr.get("plane"),))
            return False
        if not isinstance(fr.get("grid"), bool):
            bad("FRAME_BAD", "grid %r" % (fr.get("grid"),))
        axes = fr.get("axes")
        want = ["axis:" + c for c in pl.get("name", "")]
        if not isinstance(axes, list) or len(axes) != 2 or not all(
                isinstance(a, dict) for a in axes):
            bad("FRAME_BAD", "a plane has two axes")
            return False
        got = [a.get("axis") for a in axes]
        if got != want:
            bad("FRAME_BAD", "axes %r: plane %s takes %r in this order"
                % (got, pl.get("name"), want))
        if fr["plane"] not in listed:
            bad("FRAME_UNLISTED", "%s is not listed in the figure"
                % fr["plane"])
        specs = [(a, "axis %s" % a.get("axis")) for a in axes]
    else:
        specs = [(fr, "number line")]
    for ax, where in specs:
        if ax is not fr and not fields(ax, AXIS_FRAME_FIELDS, where):
            continue
        aid = ax.get("axis")
        if (ix.entities.get(aid) or {}).get("kind") != "axis":
            bad("FRAME_BAD", "%s: %r is not an axis entity" % (where, aid))
        elif aid not in listed:
            bad("FRAME_UNLISTED", "%s is not listed in the figure" % aid)
        lo, hi, st = _ax_nums(ax)
        if None in (lo, hi, st):
            bad("FRAME_BAD", "%s: min / max / step are exact rationals"
                % where)
            continue
        if st <= 0 or hi <= lo:
            bad("FRAME_BAD", "%s: needs min < max and step > 0" % where)
            continue
        n = (hi - lo) / st
        if n.denominator != 1:
            bad("FRAME_BAD", "%s: (max - min) is no whole number of steps"
                % where)
            continue
        if n > MAX_INTERVALS:
            bad("FRAME_BAD", "%s: %s intervals (at most %d)"
                % (where, n, MAX_INTERVALS))
            continue
        broken = ax.get("break_before") is True
        if "break_before" in ax and (not broken or fam != "coordinate_plane" or
                aid != "axis:y" or lo <= 0 or sketch or lo not in labelled(ax) or n+1 > MAX_INTERVALS):
            bad("FRAME_BAD", "break_before requires an ordinary positive y axis with its starting value printed")
        if fam == "coordinate_plane" and not broken and not (
                lo <= 0 <= hi and (lo / st).denominator == 1):
            bad("FRAME_BAD", "%s: the axes cross at the origin (0 is a "
                "tick of every axis of a plane)" % where)
        has_e, has_a = "label_every" in ax, "label_at" in ax
        if fam == "coordinate_plane" and sketch:
            # (v6.16 gaps r3, F1) a sketch prints no number
            if has_e or ax.get("label_at") != []:
                bad("FRAME_BAD", "%s: a sketch plane prints no number "
                    "(\"label_at\": [])" % where)
            if ax.get("form") is not None:
                bad("FRAME_BAD", "%s: a sketch plane prints no number (no "
                    "form)" % where)
            continue
        if has_e == has_a:
            bad("FRAME_BAD", "%s: exactly one of label_every / label_at"
                % where)
        elif has_e:
            k = ax["label_every"]
            if not isinstance(k, int) or isinstance(k, bool) or \
                    not 1 <= k <= LABEL_EVERY_MAX:
                bad("FRAME_BAD", "%s: label_every %r (1..%d)"
                    % (where, k, LABEL_EVERY_MAX))
        else:
            la = ax["label_at"]
            ts = set(ticks(ax))
            vals = [_q(v) for v in la] if isinstance(la, list) else None
            if not vals or None in vals or len(set(vals)) != len(vals):
                bad("FRAME_BAD", "%s: label_at %r (distinct exact values)"
                    % (where, la))
            elif not set(vals) <= ts:
                bad("FRAME_BAD", "%s: label_at %s off the ticks" % (
                    where, [canon.canon_number(str(v)) for v in vals
                            if v not in ts]))
        if ax.get("form") is not None:
            if ax["form"] not in canon.NUMBER_FORMS:
                bad("FRAME_BAD", "%s: form %r" % (where, ax["form"]))
            else:
                for t in labelled(ax):
                    if t.denominator != 1 and canon.form_problem(
                            str(t), ax["form"]):
                        bad("FRAME_BAD", "%s: %s" % (where, canon.form_problem(
                            str(t), ax["form"])))
                        break
    return ok[0]


# ------------------------------------------------------------- helpers ---
def figure_shows(g, ix):
    """Every entity a figure shows: its listed entities, what its drawn
    facts are drawn on, and everything those are built from."""
    S = _S()
    shown = set()
    for e in g.get("entities") or []:
        shown |= S.entity_closure(e, ix)
    for d in g.get("draws") or []:
        for a in (ix.facts.get(d) or {}).get("args") or []:
            shown |= S.entity_closure(a, ix)
    return shown


def _question_of(scope, ix):
    return ix.scope_question.get(scope)


def _figures_of_question(qid, ix):
    return [g for g in ix.figures.values()
            if _question_of(g.get("scope"), ix) == qid]


def coordinates(qid, ix, out=None):
    """{(point, axis): Fraction} of question qid, from its coordinate facts
    with a value (given / derived / context / to_prove / answer). Two
    different values for one place -> FAMILY_INCONSISTENT (when out)."""
    got, src = {}, {}
    for f in sorted(ix.facts.values(), key=lambda f: str(f.get("id"))):
        if f.get("rel") != "coordinate" or f.get("role") not in VALUE_ROLES \
                or _question_of(f.get("item"), ix) != qid:
            continue
        args = f.get("args") or []
        v = _q(f.get("value"))
        if len(args) != 2 or v is None:
            continue
        k = (args[0], args[1])
        if k in got and got[k] != v and out is not None:
            out.append(Issue("FAMILY_INCONSISTENT", "fact %s" % f.get("id"),
                             "%s on %s is %s, and %s in %s" % (
                                 k[0], k[1], _s(v), _s(got[k]), src[k])))
        got.setdefault(k, v)
        src.setdefault(k, f.get("id"))
    return got


def _s(v):
    return canon.canon_number(str(v))


def place(eid, axis, coords, ix):
    """The value of a place (a point: its coordinate on `axis`; a number:
    itself), or None."""
    e = ix.entities.get(eid) or {}
    if e.get("kind") == "number":
        return _q(e.get("value"))
    return coords.get((eid, axis))


def _point_axes(eid, coords):
    return sorted(a for (p, a) in coords if p == eid)


def _line_value(eid, coords, ix):
    """(value, axis) of a place on ONE axis (a number line): a number, or a
    point with exactly one coordinate; else (None, None)."""
    e = ix.entities.get(eid) or {}
    if e.get("kind") == "number":
        return _q(e.get("value")), None
    axes = _point_axes(eid, coords)
    if len(axes) == 1:
        return coords[(eid, axes[0])], axes[0]
    return None, None


# ------------------------------------------------------------ validate ---
def validate_family(spec, ix, out):
    try:
        _validate(spec, ix, out)
    except Exception as e:              # noqa: BLE001 -- malformed input
        out.append(Issue("BAD_TYPE", "spec", "unreadable family data (%s)"
                         % type(e).__name__))


def _validate(spec, ix, out):
    S = _S()
    frames = {}
    for g in ix.figures.values():
        if not isinstance(g, dict):
            continue
        if isinstance(g.get("frame"), dict) and \
                g["frame"].get("family") == "pie_chart":
            # (v6.16 integrate) a pie chart: its frame, entities and data
            # are the pie family's (wspec/pie.py, run by sheet_pie)
            continue
        if "frame" in g:
            if _frame_issues(g, ix, out):
                frames[g["id"]] = g["frame"]
            fam = (g.get("frame") or {}).get("family") \
                if isinstance(g.get("frame"), dict) else None
            allowed = FAMILY_ENTITY_KINDS.get(fam)
            if allowed:
                for e in sorted(figure_shows(g, ix)):
                    k = ix.kind(e)
                    if k is not None and k not in allowed:
                        out.append(Issue("FAMILY_ENTITY", "figure %s"
                                         % g.get("id"), "a %s (%s) on a %s"
                                         % (k, e, fam)))
        else:
            for e in sorted(figure_shows(g, ix)):
                if ix.kind(e) in LINE_ONLY_KINDS:
                    out.append(Issue("FAMILY_ENTITY", "figure %s"
                                     % g.get("id"), "a %s (%s) needs a "
                                     "number_line frame" % (ix.kind(e), e)))
    _value_issues(ix, out)
    for qid in list(ix.questions):
        coords = coordinates(qid, ix, out)
        figs = [g for g in _figures_of_question(qid, ix)
                if g.get("id") in frames]
        _placement_issues(figs, coords, ix, out)
        _consistency_issues(qid, figs, coords, ix, out)
        _axis_parallel_issues(qid, figs, coords, ix, out)
        _plot_issues(qid, coords, ix, out)
        _leak_issues(qid, figs, ix, out)
        _guide_issues(qid, figs, ix, out)


def _value_issues(ix, out):
    S = _S()
    for e in ix.entities.values():
        if e.get("kind") == "number" and e.get("form") is not None:
            why = canon.form_problem(e.get("value"), e.get("form")) \
                if _q(e.get("value")) is not None else "not rational"
            if why:
                out.append(Issue("FAMILY_VALUE", "entity %s" % e.get("id"),
                                 why))
    for f in ix.facts.values():
        rel, w = f.get("rel"), "fact %s" % f.get("id")
        has_v = f.get("value") is not None
        if "form" in f:
            if rel not in S.FAMILY_RELS or not has_v:
                out.append(Issue("FAMILY_VALUE", w, "a form belongs to the "
                                 "value of a family relation"))
            else:
                why = canon.form_problem(f["value"], f["form"]) \
                    if _q(f["value"]) is not None else "not rational"
                if why:
                    out.append(Issue("FAMILY_VALUE", w, why))
        if rel not in S.FAMILY_RELS or not has_v:
            continue
        try:
            a, b, r = canon.parse_exact(f["value"])
        except SpecError:
            continue                    # BAD_NUMBER already
        if rel in RATIONAL_RELS and r != 1:
            out.append(Issue("FAMILY_VALUE", w, "%s is rational" % rel))
            continue
        val = a if r == 1 else None
        u = f.get("unit")
        if u not in (None, ""):
            try:
                dim = canon.unit_dimension(canon.canon_unit(u))
            except SpecError:
                dim = "?"
            if rel != "distance" or dim != "length":
                out.append(Issue("FAMILY_VALUE", w, "unit %r on %s (only a "
                                 "distance may carry a length unit)"
                                 % (u, rel)))
        if rel == "count_integers" and (val is None or val < 0 or
                                        val.denominator != 1):
            out.append(Issue("FAMILY_VALUE", w, "a count is a whole "
                             "number >= 0"))
        elif rel in ("abs_value", "distance") and (a < 0 or (a == 0 and
                                                              b < 0)):
            out.append(Issue("FAMILY_VALUE", w, "%s is never negative" % rel))
        elif rel == "interval_value" and val is not None and val <= 0:
            out.append(Issue("FAMILY_VALUE", w, "an interval is positive"))
        elif rel == "jump_value" and val == 0:
            out.append(Issue("FAMILY_VALUE", w, "a jump of 0 is no jump"))


def _sketch_issues(g, coords, ix, out):
    """(v6.16 gaps r3, F1) a sketch plane's places: exactly its shown
    points, inside the range, on the side of each axis and in the order of
    their coordinate values (any role -- validation holds the private
    model)."""
    fr = g["frame"]
    axes = frame_axes(fr)
    w = "figure %s" % g["id"]
    places = sketch_places(fr)
    shown = sorted(e for e in figure_shows(g, ix) if ix.kind(e) == "point")
    for p in shown:
        if p not in places:
            out.append(Issue("FRAME_POINT_UNPLACED", w, "%s has no sketch "
                             "place (frame sketch.places)" % p))
    for p in sorted(set(places) - set(shown)):
        out.append(Issue("FRAME_BAD", w, "sketch place of %s, which the "
                         "figure does not show (a place never adds a point)"
                         % p))
    for n, ax in enumerate(axes):
        lo, hi = _q(ax["min"]), _q(ax["max"])
        aid = ax["axis"]
        have = [(p, places[p][n]) for p in shown if p in places]
        for p, v in have:
            if not lo <= v <= hi:
                out.append(Issue("FRAME_POINT_OUTSIDE", w, "%s at %s on %s, "
                                 "outside [%s, %s]" % (p, _s(v), aid, _s(lo),
                                                       _s(hi))))
            c = coords.get((p, aid))
            if c is not None and (c > 0) - (c < 0) != (v > 0) - (v < 0):
                out.append(Issue("FAMILY_INCONSISTENT", w, "the sketch puts "
                                 "%s at %s on %s, its coordinate is %s: a "
                                 "sketch keeps every point on its side of "
                                 "the axis" % (p, _s(v), aid, _s(c))))
        for i in range(len(have)):
            for j in range(i + 1, len(have)):
                (p, v), (q, u) = have[i], have[j]
                cp, cq = coords.get((p, aid)), coords.get((q, aid))
                if cp is None or cq is None:
                    continue
                if (cp > cq) - (cp < cq) != (v > u) - (v < u):
                    out.append(Issue("FAMILY_INCONSISTENT", w, "the sketch "
                                     "puts %s and %s in another order on %s "
                                     "than their coordinates (%s, %s)" % (
                                         p, q, aid, _s(cp), _s(cq))))


def _placement_issues(figs, coords, ix, out):
    for g in figs:
        if is_sketch(g["frame"]):
            _sketch_issues(g, coords, ix, out)       # v6.16 gaps r3 (F1)
            continue
        axes = frame_axes(g["frame"])
        rng = dict((ax["axis"], (_q(ax["min"]), _q(ax["max"])))
                   for ax in axes)
        w = "figure %s" % g["id"]
        for e in sorted(figure_shows(g, ix)):
            k = ix.kind(e)
            if k == "point":
                for aid, (lo, hi) in sorted(rng.items()):
                    v = coords.get((e, aid))
                    # A source-bound parameter's free coordinate is never
                    # a numeric mathematical given. Its explicitly marked
                    # illustrative placement is required privately by render;
                    # the fixed coordinate and measured domain remain checked.
                    illustrative_free = any(
                        isinstance(r, dict) and r.get("example") is True and
                        r.get("point") == e and e in g.get("entities", []) and
                        isinstance(r.get("coordinate_fact"), str) and
                        (ix.facts.get(r.get("coordinate_fact")) or {}).get("args")
                        in ([e, "axis:y"] if aid == "axis:x" else [e, "axis:x"],)
                        for r in (g.get("loci") if isinstance(g.get("loci"), list) else []))
                    if v is None and illustrative_free:
                        continue
                    if v is None:
                        out.append(Issue("FRAME_POINT_UNPLACED", w,
                                         "%s has no coordinate on %s in its "
                                         "question" % (e, aid)))
                    elif not lo <= v <= hi:
                        out.append(Issue("FRAME_POINT_OUTSIDE", w,
                                         "%s at %s on %s, outside [%s, %s]"
                                         % (e, _s(v), aid, _s(lo), _s(hi))))
            elif k == "number":
                v = _q((ix.entities.get(e) or {}).get("value"))
                for aid, (lo, hi) in sorted(rng.items()):
                    if v is None or not lo <= v <= hi:
                        out.append(Issue("FRAME_POINT_OUTSIDE", w,
                                         "the number %s outside [%s, %s]"
                                         % (e, _s(lo), _s(hi))))


def _consistency_issues(qid, figs, coords, ix, out):
    steps = {}
    for g in figs:
        if is_sketch(g["frame"]):
            continue        # (v6.16 gaps r3) a sketch's step is no value
        for ax in frame_axes(g["frame"]):
            steps.setdefault(ax["axis"], set()).add(_q(ax["step"]))
    for e in ix.entities.values():
        if e.get("kind") == "interval":
            lo, _ = _line_value(e["lo"], coords, ix) \
                if isinstance(e.get("lo"), str) else (None, None)
            hi, _ = _line_value(e["hi"], coords, ix) \
                if isinstance(e.get("hi"), str) else (None, None)
            if lo is not None and hi is not None and lo >= hi:
                out.append(Issue("FAMILY_INCONSISTENT", "entity %s"
                                 % e.get("id"), "lo %s is not below hi %s"
                                 % (_s(lo), _s(hi))))
    for f in ix.facts.values():
        if _question_of(f.get("item"), ix) != qid or \
                f.get("role") not in VALUE_ROLES:
            continue
        rel, args = f.get("rel"), f.get("args") or []
        v = _q(f.get("value"))
        w = "fact %s" % f.get("id")
        want = None
        if rel == "distance" and len(args) == 2:
            want = _distance(args[0], args[1], coords, ix)
        elif rel == "abs_value" and len(args) == 1:
            x, _ = _line_value(args[0], coords, ix)
            want = abs(x) if x is not None else None
        elif rel == "jump_value" and len(args) == 1:
            j = ix.entities.get(args[0]) or {}
            a, _ = _line_value(j.get("from"), coords, ix)
            b, _ = _line_value(j.get("to"), coords, ix)
            want = b - a if None not in (a, b) else None
        elif rel == "count_integers" and len(args) == 1:
            want = _count(ix.entities.get(args[0]) or {}, coords, ix)
        elif rel == "interval_value" and len(args) == 1:
            got = steps.get(args[0]) or set()
            if v is not None and got and got != {v}:
                out.append(Issue("FAMILY_INCONSISTENT", w, "the frame of %s "
                                 "steps by %s" % (args[0], ", ".join(
                                     sorted(_s(x) for x in got)))))
            continue
        if rel == "distance" and f.get("value") is not None and v is None \
                and want is not None:
            out.append(Issue("FAMILY_INCONSISTENT", w, "the distance is %s"
                             % _s(want)))
        elif want is not None and v is not None and want != v:
            out.append(Issue("FAMILY_INCONSISTENT", w, "%s is %s by the "
                             "coordinates, not %s" % (rel, _s(want), _s(v))))


def _figureless_cartesian_axes(qid, fact, ends, ix):
    """A stated x/y pair defines Cartesian axes without claiming a drawing.

    Only a question with NO figures can take this path. An endpoint must
    have a complete, public given pair in this fact's item or its question;
    answers, context placements and unrelated items cannot supply it.
    Figure validation and ink checks keep their existing framed path.
    """
    axes = {"axis:x", "axis:y"}
    if _figures_of_question(qid, ix) or not ends or \
            any(ix.kind(a) != "axis" for a in axes) or \
            (fact.get("args") or [None, None])[1] not in axes:
        return []
    scopes = {qid, fact.get("item")}
    stated = {}
    for f in ix.facts.values():
        args = f.get("args") or []
        if (f.get("rel") == "coordinate" and f.get("role") == "given"
                and f.get("source", {}).get("kind") == "stated"
                and f.get("item") in scopes and len(args) == 2
                and args[0] in ends and ix.kind(args[0]) == "point"
                and args[1] in axes and _q(f.get("value")) is not None):
            stated.setdefault(args[0], set()).add(args[1])
    return sorted(axes) if any(a == axes for a in stated.values()) else []


def _axis_parallel_issues(qid, figs, coords, ix, out):
    """(v6.13 fix_r2, B1) axis_parallel(AB, axis:x): the segment lies on a
    coordinate plane of its question whose axes include axis:x, or an
    explicit figureless Cartesian question with a stated endpoint pair.
    Its ends
    share their coordinate on the OTHER axis (when the question places
    them); ends at one place are no segment."""
    for f in sorted(ix.facts.values(), key=lambda f: str(f.get("id"))):
        if f.get("rel") != "axis_parallel" or \
                _question_of(f.get("item"), ix) != qid:
            continue
        args = f.get("args") or []
        if len(args) != 2:
            continue
        w = "fact %s" % f.get("id")
        e = ix.entities.get(args[0]) or {}
        ends = e.get("ends") if e.get("kind") == "segment" else \
            e.get("through") if e.get("kind") == "line" else \
            [e.get("from"), e.get("through")] if e.get("kind") == "ray" \
            else None
        planes = [g for g in figs if (g.get("frame") or {}).get(
            "family") == "coordinate_plane" and args[1] in [
                ax["axis"] for ax in frame_axes(g["frame"])]]
        axes = sorted(set(ax["axis"] for g in planes
                          for ax in frame_axes(g["frame"])))
        if not planes:
            axes = _figureless_cartesian_axes(qid, f, ends, ix)
        if not axes:
            out.append(Issue("FAMILY_ENTITY", w, "%s is no axis of a "
                             "coordinate plane or explicitly stated "
                             "figureless Cartesian pair of %s"
                             % (args[1], qid)))
            continue
        if not ends or len(ends) != 2:
            continue
        others = [a for a in axes if a != args[1]]
        for o in others:
            a, b = coords.get((ends[0], o)), coords.get((ends[1], o))
            if a is not None and b is not None and a != b:
                out.append(Issue("FAMILY_INCONSISTENT", w, "%s is not "
                                 "parallel to %s: its ends are at %s and %s "
                                 "on %s" % (args[0], args[1], _s(a), _s(b),
                                            o)))
        a, b = coords.get((ends[0], args[1])), coords.get((ends[1], args[1]))
        if a is not None and a == b and all(
                coords.get((ends[0], o)) == coords.get((ends[1], o))
                for o in others):
            out.append(Issue("FAMILY_INCONSISTENT", w, "%s has both ends at "
                             "one place" % args[0]))


def _distance(a, b, coords, ix):
    """|a - b| when both places are on one axis (a number line) or share a
    coordinate on a plane (an axis-parallel segment); None when unknown or
    slanted (not checked)."""
    ea, eb = ix.entities.get(a) or {}, ix.entities.get(b) or {}
    if "number" in (ea.get("kind"), eb.get("kind")):
        x, _ = _line_value(a, coords, ix)
        y, _ = _line_value(b, coords, ix)
        return abs(x - y) if None not in (x, y) else None
    axa, axb = _point_axes(a, coords), _point_axes(b, coords)
    if not axa or axa != axb:
        return None
    diff = [abs(coords[(a, x)] - coords[(b, x)]) for x in axa]
    nz = [d for d in diff if d != 0]
    if len(nz) <= 1:
        return nz[0] if nz else Fraction(0)
    return None


def _count(ivl, coords, ix):
    lo, _ = _line_value(ivl.get("lo"), coords, ix)
    hi, _ = _line_value(ivl.get("hi"), coords, ix)
    if lo is None or hi is None or lo > hi:
        return None
    import math
    first = math.ceil(lo) if ivl.get("lo_in") else math.floor(lo) + 1
    last = math.floor(hi) if ivl.get("hi_in") else math.ceil(hi) - 1
    return Fraction(max(0, last - first + 1))


def _plot_issues(qid, coords, ix, out):
    for f in ix.facts.values():
        if f.get("role") != "to_plot" or f.get("rel") != "plot" or \
                _question_of(f.get("item"), ix) != qid:
            continue
        args = f.get("args") or []
        if len(args) != 2:
            continue
        what, where = args
        w = "fact %s" % f.get("id")
        wk, hk = ix.kind(what), ix.kind(where)
        places = [what]
        if hk == "plane":
            if wk == "polygon":
                # (v6.16 gaps, G5) a polygon is plotted by its vertices
                places = list((ix.entities.get(what) or {}).get("vertices")
                              or [])
            elif wk != "point":
                out.append(Issue("PLOT_UNDETERMINED", w, "a number is "
                                 "plotted on a number line (an axis), not "
                                 "on a plane"))
                continue
            name = (ix.entities.get(where) or {}).get("name") or ""
            need = ["axis:" + c for c in name]
        else:
            if wk == "polygon":
                out.append(Issue("PLOT_UNDETERMINED", w, "a polygon is "
                                 "plotted on a plane, not on an axis"))
                continue
            need = [where] if wk == "point" else []
        vis = set(ix.visible_scopes(f.get("item")))
        for aid, what in [(a_, p_) for p_ in places for a_ in need]:
            ok = any(g.get("rel") == "coordinate" and
                     list(g.get("args") or []) == [what, aid] and
                     g.get("value") is not None and (
                         (g.get("role") in ("given", "derived", "context")
                          and g.get("item") in vis) or
                         (g.get("role") == "answer" and
                          g.get("item") == f.get("item")))
                     for g in ix.facts.values())
            if not ok:
                out.append(Issue("PLOT_UNDETERMINED", w, "no coordinate of "
                                 "%s on %s is given (or asked in the same "
                                 "item)" % (what, aid)))


def _guide_issues(qid, figs, ix, out):
    for f in sorted(ix.facts.values(), key=lambda f: str(f.get("id"))):
        if f.get("rel") != "guide" or _question_of(f.get("item"), ix) != qid:
            continue
        w = "fact %s" % f.get("id")
        if f.get("role") != "given" or \
                (f.get("source") or {}).get("kind") != "stated":
            out.append(Issue("FAMILY_GUIDE", w, "a guide is a stated given "
                             "(it appears only where a given states it)"))
            continue
        args = f.get("args") or []
        if not any(f.get("id") in (g.get("draws") or []) and len(args) == 2
                   and not is_sketch(g["frame"])        # v6.16 gaps r3
                   and args[1] in [ax["axis"] for ax in
                                   frame_axes(g["frame"])] for g in figs):
            out.append(Issue("FAMILY_GUIDE", w, "no framed figure of the "
                             "question with %s draws it" % (args[1:] or
                                                            ["?"])[0]))


def _leak_issues(qid, figs, ix, out):
    allfigs = _figures_of_question(qid, ix)
    shows = dict((g["id"], figure_shows(g, ix)) for g in allfigs)
    for f in sorted(ix.facts.values(), key=lambda f: str(f.get("id"))):
        if _question_of(f.get("item"), ix) != qid:
            continue
        role, rel, args = f.get("role"), f.get("rel"), f.get("args") or []
        if role == "to_plot" and args:
            # (v6.16 gaps, G5) a polygon to plot: any of its vertices shown
            # shows it
            hid = {args[0]} | set(
                (ix.entities.get(args[0]) or {}).get("vertices") or []
                if ix.kind(args[0]) == "polygon" else [])
            for g in allfigs:
                if hid & shows[g["id"]]:
                    out.append(Issue("FIGURE_SHOWS_TO_PLOT", "figure %s"
                                     % g["id"], "%s shows %s, which %s asks "
                                     "to plot" % (g["id"], args[0],
                                                  f.get("id"))))
            continue
        if role != "target":
            continue
        it = ix.items.get(f.get("item")) or {}
        if rel == "coordinate" and len(args) == 2 and \
                it.get("task_type") not in READ_TASKS and \
                ix.kind(args[0]) != "origin":
            # (v6.16 gaps, G2) the origin's coordinates are (0, 0) by the
            # frame itself (the axes cross there): asking them tests the
            # notion, nothing is read off the grid -- a figure showing the
            # origin is no leak
            for g in figs:
                if is_sketch(g["frame"]):
                    continue    # (v6.16 gaps r3) nothing is read off it
                axes = [ax["axis"] for ax in frame_axes(g["frame"])]
                if args[0] in shows[g["id"]] and args[1] in axes:
                    out.append(Issue("FRAME_SHOWS_TARGET", "figure %s"
                                     % g["id"], "%s shows %s on its grid: "
                                     "%s is read off, not %s" % (
                                         g["id"], args[0], f.get("id"),
                                         it.get("task_type"))))
        elif rel == "interval_value" and len(args) == 1:
            for g in figs:
                for ax in frame_axes(g["frame"]):
                    if ax["axis"] != args[0]:
                        continue
                    ts, labs = ticks(ax), labelled(ax)
                    idx = [ts.index(t) for t in labs]
                    if any(b - a == 1 for a, b in zip(idx, idx[1:])):
                        out.append(Issue("FRAME_SHOWS_TARGET", "figure %s"
                                         % g["id"], "two neighbouring ticks "
                                         "of %s print their numbers: the "
                                         "interval value %s asks is printed"
                                         % (args[0], f.get("id"))))
