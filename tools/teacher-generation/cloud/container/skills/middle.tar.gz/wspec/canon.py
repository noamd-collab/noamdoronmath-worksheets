# -*- coding: utf-8 -*-
"""Canonical form: exact numbers, normalised units, ids by a fixed rule,
canonical JSON bytes + sha256. Same meaning -> same bytes; any change of
meaning -> different bytes."""
import hashlib
import json
import math
import re
import unicodedata
from fractions import Fraction

from .errors import Issue, SpecError

# ------------------------------------------------------------- numbers ---
_DEC = re.compile(r"^([+-]?)(\d*)(?:\.(\d*))?$")
_FRAC = re.compile(r"^([+-]?\d+)\s*/\s*(\d+)$")
_SURD = re.compile(r"^(.*?)\s*√\s*(\d+)$")


def _rational(s):
    s = s.strip()
    m = _FRAC.match(s)
    if m:
        q = int(m.group(2))
        if q == 0:
            raise ValueError("zero denominator")
        return Fraction(int(m.group(1)), q)
    m = _DEC.match(s)
    if m and (m.group(2) or m.group(3)):
        sign, ip, fp = m.group(1), m.group(2) or "0", m.group(3) or ""
        v = Fraction(int(ip + fp), 10 ** len(fp))
        return -v if sign == "-" else v
    raise ValueError("not a rational: %r" % s)


def _squarefree(n):
    """n = k*k*r with r squarefree -> (k, r)."""
    k, r, d = 1, n, 2
    while d * d <= r:
        while r % (d * d) == 0:
            r //= d * d
            k *= d
        d += 1
    return k, r


def _parse_single(v):
    """One term -> (Fraction coefficient, radicand int) (the stage-1
    parse_number)."""
    if isinstance(v, bool) or v is None:
        raise SpecError(Issue("BAD_NUMBER", "", repr(v)))
    try:
        if isinstance(v, int):
            return Fraction(v), 1
        if isinstance(v, Fraction):
            return v, 1
        if isinstance(v, float):
            if v != v or v in (float("inf"), float("-inf")):
                raise ValueError("non-finite")
            return _rational(repr(v)), 1
        if isinstance(v, str):
            s = unicodedata.normalize("NFC", v).strip().replace("−", "-")
            m = _SURD.match(s)
            if m:
                coef = m.group(1).strip()
                c = Fraction(1) if coef in ("", "+") else (
                    Fraction(-1) if coef == "-" else _rational(coef))
                n = int(m.group(2))
                if n == 0:
                    return Fraction(0), 1
                k, r = _squarefree(n)
                return c * k, r
            return _rational(s), 1
    except (ValueError, ZeroDivisionError) as e:
        raise SpecError(Issue("BAD_NUMBER", "", "%r (%s)" % (v, e)))
    raise SpecError(Issue("BAD_NUMBER", "", repr(v)))


# (v6.10) an exact SUM of a rational and one surd term: "16 + 16√3",
# "30+6√2", "3 - √2", "6√2 + 30" -- the perimeter of a figure with one
# irrational side. Written as rational part and surd part with ONE sign
# between them (either order); nothing else (two surds, a product) parses.
_SUM_RS = re.compile(r"^([+-]?[0-9./\s]+?)\s*([+-])\s*([0-9./]*\s*√\s*\d+)$")
_SUM_SR = re.compile(r"^([+-]?[0-9./]*\s*√\s*\d+)\s*([+-])\s*([0-9./\s]+)$")


# (v6.17, BRIEF_V617 V3) the √ NUMBER FORM as an author writes it: TeX
# ("\sqrt{12}", "3\sqrt{2}", "\f{3\sqrt{5}}{2}", "\frac{3+\sqrt{5}}{2}"),
# a surd over a whole denominator ("3√5/2", "√5/2") and a sum over one
# ("(3+√5)/2", "(6-2√2)/4"). Each is read to the SAME exact value, so the
# canonical bytes (canon_number: "2√3", "3/2√5", "3/2+1/2√5") are one per
# value -- a form an older version refused (BAD_NUMBER) is the only change.
_TEX_SQRT = re.compile(r"\\sqrt\s*\{\s*(\d+)\s*\}")
_TEX_FRAC = re.compile(r"\\(?:f|frac|dfrac|tfrac)\s*\{([^{}]*)\}\s*\{\s*"
                       r"(\d+)\s*\}")
_OVER_Q = re.compile(r"^\(?\s*([^()]*?)\s*\)?\s*/\s*(\d+)$")


def _detex(s):
    """TeX roots / fractions as the plain form parse_exact reads"""
    s = _TEX_SQRT.sub(lambda m: u"√" + m.group(1), s)
    s = _TEX_FRAC.sub(lambda m: "(%s)/%s" % (m.group(1), m.group(2)), s)
    return s.replace("{", "").replace("}", "").replace(" ", "")


def _over_q(s):
    """'(3+√5)/2', '3√5/2', '√5/2' -> (numerator string, q) or None (a
    plain p/q, a surd times a fraction '3/2√5' and anything else: None)"""
    if u"√" not in s or "/" not in s:
        return None
    m = _OVER_Q.match(s)
    if not m or u"√" not in m.group(1) or "/" in m.group(1):
        return None
    return m.group(1), int(m.group(2))


def parse_exact(v):
    """Exact value -> (a, b, r) with value = a + b*sqrt(r), a and b
    Fractions, r a squarefree int; r == 1 exactly when b == 0 (a rational
    value). Accepts everything parse_number accepts plus the sum of a
    rational and ONE surd term ("16 + 16√3", "3 - √2", "6√2 + 30"), and
    (v6.17) the TeX / over-a-denominator forms of _detex / _over_q."""
    if isinstance(v, str) and ("\\" in v or (u"√" in v and "/" in v and (
            "(" in v or re.search(u"√\\s*\\d+\\s*/", v)))):
        s = _detex(unicodedata.normalize("NFC", v).strip().replace(
            u"−", "-"))
        oq = _over_q(s)
        if oq is not None:
            if oq[1] == 0:
                raise SpecError(Issue("BAD_NUMBER", "", repr(v)))
            a, b, r = parse_exact(oq[0])
            return _norm_exact(a / oq[1], b / oq[1], r)
        if s != v:
            return parse_exact(s)
    if isinstance(v, str):
        s = unicodedata.normalize("NFC", v).strip().replace("−", "-")
        m = _SUM_RS.match(s)
        if m and "√" not in m.group(1):
            a = _parse_single(m.group(1).replace(" ", ""))
            b = _parse_single(m.group(3).replace(" ", ""))
            if a[1] != 1 or b[1] == 1:
                raise SpecError(Issue("BAD_NUMBER", "", repr(v)))
            sg = -1 if m.group(2) == "-" else 1
            return _norm_exact(a[0], sg * b[0], b[1])
        m = _SUM_SR.match(s)
        if m and "√" not in m.group(3):
            b = _parse_single(m.group(1).replace(" ", ""))
            a = _parse_single(m.group(3).replace(" ", ""))
            if a[1] != 1 or b[1] == 1:
                raise SpecError(Issue("BAD_NUMBER", "", repr(v)))
            sg = -1 if m.group(2) == "-" else 1
            return _norm_exact(sg * a[0], b[0], b[1])
    c, r = _parse_single(v)
    if r == 1:
        return c, Fraction(0), 1
    return _norm_exact(Fraction(0), c, r)


def _norm_exact(a, b, r):
    if b == 0 or r == 1:
        return a + (b if r == 1 else 0), Fraction(0), 1
    return a, b, r


def is_sum(v):
    """Is v an exact value with a rational AND a surd part (16 + 16√3)?"""
    a, b, r = parse_exact(v)
    return a != 0 and r != 1


def parse_number(v):
    """Exact value -> (Fraction coefficient, radicand int). radicand 1 means
    rational. Accepts int, Fraction, float (via its shortest repr, never its
    binary expansion), "0.6", ".6", "3/5", "8√3", "√12", "3/2√5". bool and
    anything else is refused (BAD_NUMBER). A SUM (v6.10, "16 + 16√3") is no
    single term: refused here (BAD_NUMBER) -- read it with parse_exact."""
    a, b, r = parse_exact(v)
    if r == 1:
        return a, 1
    if a == 0:
        return b, r
    raise SpecError(Issue("BAD_NUMBER", "", "%r is a sum of a rational and "
                          "a surd (read it with parse_exact)" % (v,)))


def _rat_str(c):
    return str(c.numerator) if c.denominator == 1 else "%d/%d" % (
        c.numerator, c.denominator)


def canon_number(v):
    """The one canonical string of an exact value: "55", "-7/2", "8√3",
    "3/2√5". 0.6, ".6", "3/5", "6/10" all -> "3/5". A sum (v6.10): the
    rational part, then the surd term with its sign: "16+16√3", "3-√2"."""
    a, b, r = parse_exact(v)
    if r == 1:
        return "0" if a == 0 else _rat_str(a)
    bs = "" if abs(b) == 1 else _rat_str(abs(b))
    if a == 0:
        return "%s%s√%d" % ("-" if b < 0 else "", bs, r)
    return "%s%s%s√%d" % (_rat_str(a), "-" if b < 0 else "+", bs, r)


def number_display(canon):
    """How a canonical value is printed in a generated text (fixed rule, not
    part of the meaning): integer as is; a terminating fraction as a
    decimal; else \\f{p}{q}; a surd with the radical sign."""
    a0, b0, r0 = parse_exact(canon)
    if a0 != 0 and r0 != 1 and (a0.denominator != 1 or b0.denominator != 1):
        # (v6.17, V3) a sum with a fraction part: over ONE denominator,
        # \f{3 + \sqrt{5}}{2} (never '1.5 + ...')
        return "$%s$" % surd_tex(canon)
    if a0 != 0 and r0 != 1:
        # (v6.10) a sum: "16 + 16√3", "3 - √2"
        tail = number_display(canon_number("%s√%d" % (_rat_str(abs(b0)),
                                                       r0)))
        return "%s %s %s" % (number_display(_rat_str(a0)),
                             "-" if b0 < 0 else "+", tail)
    c, r = parse_number(canon)
    if r != 1 and c.denominator != 1:
        # (v6.17, V3) a surd's coefficient is never printed as a decimal
        # ('1.5√5' was): the ONE printed form is the fraction of the surd,
        # \f{3\sqrt{5}}{2} (bare maths in one island, as a fraction is)
        return "$%s$" % surd_tex(canon)
    if c.denominator == 1:
        cs = str(c.numerator)
    else:
        d = c.denominator
        while d % 2 == 0:
            d //= 2
        while d % 5 == 0:
            d //= 5
        if d == 1:
            neg = c < 0
            a = abs(c)
            ip = a.numerator // a.denominator
            rem = a - ip
            digits = ""
            while rem:
                rem *= 10
                digits += str(rem.numerator // rem.denominator)
                rem -= rem.numerator // rem.denominator
            cs = ("-" if neg else "") + "%d.%s" % (ip, digits)
        else:
            cs = "$\\f{%d}{%d}$" % (c.numerator, c.denominator)
    if r == 1:
        return cs
    if c == 1:
        cs = ""
    elif c == -1:
        cs = "-"                # (v6.17, V3) '-√2', never '-1√2'
    return "%s√%d" % (cs, r)


# ------------------------------------------- v6.17: the √ number form ---
# (BRIEF_V617 V3; author decision D6 in W-PLAN18-LIST: "√ מדויק; בשאלות
# מציאות גם עיגול לעשירית. אחיד בכל הדף ובמפתח") An irrational value is
# printed EXACT, in ONE canonical form: the radicand squarefree, the
# coefficient a whole number (never 1, never a decimal) or the fraction of
# the surd, a sum over one denominator -- 2\sqrt{3}, \f{3\sqrt{5}}{2},
# 3 - \sqrt{2}, \f{3 + \sqrt{5}}{2}. A rounded decimal is printed only NEXT
# TO the exact value ('\approx', approx_text), never instead of it.
def is_irrational(v):
    """is the exact value v a surd or a sum with a surd part?"""
    return parse_exact(v)[2] != 1


def _int_or_frac_tex(q):
    return str(q.numerator) if q.denominator == 1 else "\\f{%d}{%d}" % (
        q.numerator, q.denominator)


def surd_tex(v, minus="-"):
    """The one printed TeX of an exact value (bare maths, no $): a rational
    as number_display prints it (a terminating value as a decimal, else
    \\f{p}{q}); a surd / a sum in the canonical √ form above. `minus` is
    the sign character (the keys write an ASCII '-' inside an island)."""
    a, b, r = parse_exact(v)
    if r == 1:
        t = number_display(canon_number(v))
        t = t[1:-1] if t.startswith("$") and t.endswith("$") else t
        return t.replace("-", minus, 1) if t.startswith("-") else t
    q = 1
    for x in (a, b):
        q = q * x.denominator // _gcd(q, x.denominator)
    A, Bn = int(a * q), int(b * q)          # whole numbers over q
    sb = "" if abs(Bn) == 1 else str(abs(Bn))
    root = "%s\\sqrt{%d}" % (sb, r)
    if A == 0:
        num = (minus if Bn < 0 else "") + root
        if q == 1:
            return num
        return "%s\\f{%s}{%d}" % (minus if Bn < 0 else "", root, q)
    num = "%d %s %s" % (A, minus if Bn < 0 else "+", root) if A > 0 else \
        "%s%d %s %s" % (minus, -A, minus if Bn < 0 else "+", root)
    if q == 1:
        return num
    return "\\f{%s}{%d}" % (num, q)


def _gcd(x, y):
    while y:
        x, y = y, x % y
    return abs(x)


def surd_plain(v):
    """The same form in PLAIN text (a figure caption, Noam AI's public
    lines): '2√3', '3√5/2', '(3+√5)/2', '3−√2' (U+2212)."""
    a, b, r = parse_exact(v)
    if r == 1:
        t = canon_number(v)
        return t.replace("-", MINUS)
    q = 1
    for x in (a, b):
        q = q * x.denominator // _gcd(q, x.denominator)
    A, Bn = int(a * q), int(b * q)
    root = ("" if abs(Bn) == 1 else str(abs(Bn))) + u"√%d" % r
    if A == 0:
        s = (MINUS if Bn < 0 else "") + root
        return s if q == 1 else s + "/%d" % q
    s = ("%d" % A if A > 0 else MINUS + "%d" % -A) + (
        MINUS if Bn < 0 else "+") + root
    return s if q == 1 else "(%s)/%d" % (s, q)


def answer_surd_tex(v, sheet=None, minus="-"):
    """Private answer display, V617-Q6: G8 leaves the root unextracted.

    Canonical values and public given prose keep their existing rules.
    The grade is taken from the schema-validated sheet identity, never
    from a free display flag. Other grades retain the simplified form.
    A rational coefficient uses the same single integer denominator as
    surd_tex; only its integer numerator is brought under the radical.
    """
    if not isinstance(sheet, str) or not re.fullmatch(r"G8-T[0-9]+/[abc]", sheet):
        return surd_tex(v, minus)
    a, b, r = parse_exact(v)
    if r == 1:
        return surd_tex(v, minus)
    q = a.denominator * b.denominator // _gcd(a.denominator, b.denominator)
    A, Bn = int(a * q), int(b * q)
    root = "\\sqrt{%d}" % (Bn * Bn * r)
    if A == 0:
        return (minus if Bn < 0 else "") + (root if q == 1 else
                                            "\\f{%s}{%d}" % (root, q))
    num = "%s %s %s" % (str(A).replace("-", minus),
                          minus if Bn < 0 else "+", root)
    return num if q == 1 else "\\f{%s}{%d}" % (num, q)


def answer_surd_plain(v, sheet=None):
    """The same grade-aware private answer as plain text, without $/TeX."""
    if not isinstance(sheet, str) or not re.fullmatch(r"G8-T[0-9]+/[abc]", sheet):
        return surd_plain(v)
    text = _detex(answer_surd_tex(v, sheet, MINUS)).replace(" ", "")
    return re.sub(u"^([−-]?)\\((√[0-9]+)\\)/([0-9]+)$", r"\1\2/\3", text)


def exact_float(v):
    a, b, r = parse_exact(v)
    return float(a) + float(b) * math.sqrt(r)


APPROX_DECIMALS = (1, 2)


def approx_text(v, decimals=1):
    """The value rounded to `decimals` places (half away from zero), from
    the EXACT value (Decimal, 40 digits -- never a float's binary
    expansion): 2√22 -> '9.4', √13 (2 places) -> '3.61', 5√2 -> '7.07'."""
    from decimal import Decimal, ROUND_HALF_UP, localcontext
    if decimals not in APPROX_DECIMALS:
        raise SpecError(Issue("APPROX_BAD", "", "approx %r is not one of %s"
                              % (decimals, APPROX_DECIMALS)))
    a, b, r = parse_exact(v)
    with localcontext() as ctx:
        ctx.prec = 40
        x = Decimal(a.numerator) / Decimal(a.denominator) + (
            Decimal(b.numerator) / Decimal(b.denominator)) * \
            Decimal(r).sqrt()
        q = x.quantize(Decimal(1).scaleb(-decimals), rounding=ROUND_HALF_UP)
    s = "%s" % q
    return "0." + "0" * decimals if s.lstrip("-") == "0." + "0" * decimals \
        else s


def surd_problem(tok):
    """(v6.17) why a PRINTED surd token ('√50', '1√2', '1.5√2', '2√3') is
    not in the one canonical form ('' when it is): the radicand squarefree,
    the coefficient a whole number other than 1."""
    t = unicodedata.normalize("NFC", tok or "").replace(u"−", "-")
    t = t.lstrip("+-").replace(" ", "")
    m = re.match(u"^(\\d*(?:\\.\\d+)?)√(\\d+)$", t)
    if not m:
        return ""
    k, n = m.group(1), int(m.group(2))
    if "." in k:
        return "%s: a decimal coefficient (the canonical form is %s)" % (
            tok, surd_plain(t))
    if k == "1":
        return "%s: the coefficient 1 is not printed (%s)" % (tok,
                                                              surd_plain(t))
    kk, rr = _squarefree(n)
    if n == 0 or kk != 1:
        return "%s: the radicand %d is not squarefree (the canonical form " \
            "is %s)" % (tok, n, surd_plain(t))
    return ""


# ------------------------------------------ v6.12: family number display ---
# (v6.12, BRIEF_V612 section 1) the coordinate-plane and number-line
# families print their numbers with the true minus sign U+2212 (never the
# hyphen-minus), rationals only. The printed FORM of a non-integer is part
# of the exercise ("סמנו את ½" is not "סמנו את 0.5"): 'decimal' (a
# terminating value only), 'fraction' (\f{p}{q}), 'mixed' (1\f{1}{2}, |v| >
# 1). No form: the fixed rule of number_display (terminating -> decimal).
MINUS = "\u2212"
NUMBER_FORMS = ("decimal", "fraction", "mixed")


def terminating(q):
    d = q.denominator
    for p in (2, 5):
        while d % p == 0:
            d //= p
    return d == 1


def form_problem(v, form):
    """Why `form` cannot print value v ('' when it can)."""
    if form is None:
        return ""
    if form not in NUMBER_FORMS:
        return "form %r is not one of %s" % (form, NUMBER_FORMS)
    a, b, r = parse_exact(v)
    if r != 1:
        return "a form prints a rational only"
    if a.denominator == 1:
        return "%s is a whole number (it has no %s form)" % (
            canon_number(v), form)
    if form == "decimal" and not terminating(a):
        return "%s has no finite decimal" % canon_number(v)
    if form == "mixed" and abs(a) < 1:
        return "%s is no mixed number (|v| < 1)" % canon_number(v)
    return ""


def family_display(v, mode="tex", form=None, signed=False):
    """A family value as printed: U+2212 for a negative; 'plain' (the
    public descriptions) writes a fraction p/q, 'tex' / 'sheet' the bare
    maths \f{p}{q} (NO $: every family template puts it inside ONE math
    island, so a minus never parts from its number in RTL text). signed:
    a positive value with its '+' (the size of a jump, +5). Rationals only
    (BAD_NUMBER otherwise)."""
    a, b, r = parse_exact(v)
    if r != 1:
        raise SpecError(Issue("BAD_NUMBER", "", "%r: a family value is "
                              "rational" % (v,)))
    bad = form_problem(v, form)
    if bad:
        raise SpecError(Issue("BAD_NUMBER", "", bad))
    neg, m = a < 0, abs(a)
    if m.denominator == 1:
        s = str(m.numerator)
    else:
        f = form or ("decimal" if terminating(m) else "fraction")
        if f == "decimal":
            s = number_display(_rat_str(m))
        else:
            w = m.numerator // m.denominator if f == "mixed" else 0
            rem = m - w
            fr = ("%d/%d" if mode == "plain" else "\\f{%d}{%d}") % (
                rem.numerator, rem.denominator)
            s = (("%d " if mode == "plain" else "%d") % w if w else "") + fr
    if neg:
        return MINUS + s
    return ("+" + s) if signed and a != 0 else s


# --------------------------------------------------------------- units ---
# canonical unit -> (dimension, factor to the dimension's base unit).
# Declared conversions: only within one dimension.
UNITS = {
    "cm": ("length", Fraction(1)),
    "mm": ("length", Fraction(1, 10)),
    "m": ("length", Fraction(100)),
    "cm2": ("area", Fraction(1)),
    "mm2": ("area", Fraction(1, 100)),
    "m2": ("area", Fraction(10000)),
    "deg": ("angle", Fraction(1)),
    "%": ("percent", Fraction(1)),
    "ILS": ("money", Fraction(1)),
    # v6.13 fix_r2 (B2): the GRID UNIT of a coordinate plane ("יחידות",
    # "יחידות ריבועיות"): a length / area counted in the plane's own units.
    # It converts to nothing (same_quantity: a grid unit equals only itself)
    "u": ("length", Fraction(1)),
    "u2": ("area", Fraction(1)),
    # (v6.17, BRIEF_V617 V5) the real-life units of G8-T15 (and the graph
    # axes' titles): time, volume and the kilometre. Declared conversions
    # within a dimension only (1 h = 60 min, 1 km = 100000 cm)
    "min": ("time", Fraction(1)),
    "h": ("time", Fraction(60)),
    "L": ("volume", Fraction(1)),
    "km": ("length", Fraction(100000)),
}
# (v6.13 fix_r2) units that convert to no other unit of their dimension
NO_CONVERT_UNITS = frozenset(["u", "u2"])
UNIT_ALIASES = {
    "cm": "cm", 'ס"מ': "cm", "ס״מ": "cm", "סמ": "cm", "סנטימטר": "cm",
    "mm": "mm", 'מ"מ': "mm", "מ״מ": "mm", "מילימטר": "mm",
    "m": "m", "מטר": "m", "מ'": "m",
    "cm2": "cm2", "cm²": "cm2", 'סמ"ר': "cm2", "סמ״ר": "cm2",
    "mm2": "mm2", "mm²": "mm2", 'ממ"ר': "mm2", "ממ״ר": "mm2",
    "m2": "m2", "m²": "m2", 'מ"ר': "m2", "מ״ר": "m2",
    "deg": "deg", "°": "deg", "מעלות": "deg",
    "%": "%", "אחוז": "%", "אחוזים": "%",
    "ILS": "ILS", "₪": "ILS", 'ש"ח': "ILS", "ש״ח": "ILS",
    "u": "u", "יחידות": "u", "יחידה": "u",
    "u2": "u2", "יחידות ריבועיות": "u2", "יחידה ריבועית": "u2",
    # (v6.17, V5)
    "min": "min", "דקות": "min", "דקה": "min",
    "h": "h", "שעות": "h", "שעה": "h",
    "L": "L", "ליטר": "L", "ליטרים": "L",
    "km": "km", 'ק"מ': "km", "ק״מ": "km", "קמ": "km", "קילומטר": "km",
    "קילומטרים": "km",
}
# printed form of each canonical unit in generated text (fixed rule)
UNIT_DISPLAY = {"cm": " ס״מ", "mm": " מ״מ", "m": " מ׳", "cm2": " סמ״ר",
                "mm2": " ממ״ר", "m2": " מ״ר", "deg": "°", "%": "%",
                "ILS": " ₪", "u": " יחידות", "u2": " יחידות ריבועיות",
                # (v6.17, V5; PENDING_V617 -- new printed unit words)
                "min": " דקות", "h": " שעות", "L": " ליטר", "km": " ק״מ"}
# (v6.17, V5) Hebrew agreement: ONE minute / hour is 'דקה' / 'שעה' ('1 דקות'
# is wrong); the other units print the same for 1
UNIT_DISPLAY_ONE = {"min": " דקה", "h": " שעה"}


def unit_display(u, value=None):
    """The printed unit of a canonical unit after `value` (fixed rule)."""
    if not u:
        return ""
    if value is not None and u in UNIT_DISPLAY_ONE:
        try:
            if parse_exact(value) == (Fraction(1), Fraction(0), 1):
                return UNIT_DISPLAY_ONE[u]
        except SpecError:
            pass
    return UNIT_DISPLAY.get(u, "")


# (v6.17, V5) the unit WORDS a bound prose block may print after a number
# (read by schema_bound / numform: the word after a bound number must name
# the unit of the fact the number is bound to). Plural and singular.
UNIT_WORDS = dict(UNIT_ALIASES)
UNIT_WORDS.update({
    "סנטימטרים": "cm", "מילימטרים": "mm", "מטרים": "m", "מ׳": "m",
    "שקל": "ILS", "שקלים": "ILS", "ש״ח": "ILS", 'ש"ח': "ILS",
    "דק׳": "min", "דק'": "min",
})
for _k in ("u", "u2", "יחידות", "יחידה", "יחידות ריבועיות",
           "יחידה ריבועית", "%", "deg", "cm", "mm", "m", "cm2", "mm2", "m2",
           "ILS", "min", "h", "L", "km", "cm²", "mm²", "m²"):
    UNIT_WORDS.pop(_k, None)            # Latin ids / signs: not prose words


def canon_unit(u):
    if u is None or u == "":
        return None
    if not isinstance(u, str):
        raise SpecError(Issue("UNKNOWN_UNIT", "", repr(u)))
    k = unicodedata.normalize("NFC", u).strip()
    if k not in UNIT_ALIASES:
        raise SpecError(Issue("UNKNOWN_UNIT", "", repr(u)))
    return UNIT_ALIASES[k]


def unit_dimension(u):
    return UNITS[u][0] if u else None


def same_quantity(v1, u1, v2, u2):
    """Equal amount under the declared conversions (same dimension)."""
    u1, u2 = canon_unit(u1), canon_unit(u2)
    a1, b1, r1 = parse_exact(v1)
    a2, b2, r2 = parse_exact(v2)
    if (u1 is None) != (u2 is None) or r1 != r2:
        return False
    if u1 is None:
        return a1 == a2 and b1 == b2
    if UNITS[u1][0] != UNITS[u2][0]:
        return False
    if u1 != u2 and (u1 in NO_CONVERT_UNITS or u2 in NO_CONVERT_UNITS):
        return False
    f1, f2 = UNITS[u1][1], UNITS[u2][1]
    return a1 * f1 == a2 * f2 and b1 * f1 == b2 * f2


# ----------------------------------------------------------------- ids ---
# Name grammars (verifier r2, R2-02): a name is one letter with at most ONE
# index digit 1-9 and up to three primes. A multi-digit index ("M13",
# "x13") could carry a value, so it is outside the grammar.
NAME_RE = re.compile(r"^[A-Z][1-9]?'{0,3}\Z")   # a point name: A, A1, A'
VAR_RE = re.compile(r"^[a-z][1-9]?\Z")          # x, x1
TOKEN_RE = re.compile(r"^[A-Za-z0-9_]+\Z")
# (\Z, not $: "$" also matches before a final newline, so "q7\n" passed)


def nfc(s):
    return unicodedata.normalize("NFC", s).strip() if isinstance(s, str) else s


def _join(names):
    return "".join(names) if all(len(n) == 1 for n in names) else "-".join(names)


def canon_cycle(vs):
    """Polygon vertices -> canonical rotation/direction (start at the
    smallest name; of the two directions the lexicographically smaller)."""
    vs = list(vs)
    n = len(vs)
    if not n:
        return vs
    best = None
    for seq in (vs, vs[::-1]):
        i = seq.index(min(seq))
        cand = seq[i:] + seq[:i]
        if best is None or cand < best:
            best = cand
    return best if n else vs


def entity_id(e):
    """The fixed id rule. Returns None when the kind is unknown."""
    k = e.get("kind")
    try:
        if k == "point":
            return nfc(e["name"])
        if k == "segment":
            return "seg:" + _join(sorted(nfc(p) for p in e["ends"]))
        if k == "line":
            return "line:" + _join(sorted(nfc(p) for p in e["through"]))
        if k == "ray":
            return "ray:" + _join([nfc(e["from"]), nfc(e["through"])])
        if k == "angle":
            a = sorted(nfc(p) for p in e["arms"])
            return "ang:" + _join([a[0], nfc(e["vertex"]), a[1]])
        if k == "polygon":
            if e.get("tag") is not None:
                # (v6.16 gaps, G5) a polygon declared by coordinates only:
                # its vertices have no letters, its id is its tag ("poly:L6")
                return "poly:" + nfc(e["tag"])
            return "poly:" + _join(canon_cycle([nfc(p) for p in e["vertices"]]))
        if k == "origin":
            # (v6.16 gaps, G2) the axes' crossing point, "origin:O"
            return "origin:" + nfc(e["name"])
        if k == "vertex":
            # (v6.16 gaps, G5) the n-th unnamed vertex of polygon <of>
            return "vtx:%s:%d" % (nfc(e["of"]), int(e["n"]))
        if k == "circle":
            return "circ:" + nfc(e["center"]) + (
                ":" + nfc(e["name"]) if e.get("name") else "")
        if k == "arc":
            a = sorted(nfc(p) for p in e["ends"])
            return "arc:" + nfc(e["circle"]).split(":", 1)[1] + ":" + _join(a)
        if k == "number":
            return "num:" + canon_number(e["value"])
        if k == "variable":
            return "var:" + nfc(e["name"])
        if k == "axis":
            return "axis:" + nfc(e["name"])
        if k == "plane":
            return "plane:" + nfc(e["name"])
        if k == "tick":
            return "tick:" + nfc(e["axis"]).split(":", 1)[1] + ":" + \
                canon_number(e["at"])
        if k == "cline":
            # (v6.10) a construction result the sheet does NOT name: the
            # line through a point parallel / perpendicular to a base
            # ("העבירו דרך P ישר מקביל ל־AD"): no letter is invented for it;
            # it is referred to by this id
            return "cline:%s:%s:%s" % ({"parallel": "par", "perpendicular":
                                        "perp"}[e["op"]], nfc(e["through"]),
                                       nfc(e["base"]))
        if k == "jump":
            # (v6.12) a jump on a number line, ORDERED: from -> to
            return "jump:%s>%s" % (_ref_id(e["from"]), _ref_id(e["to"]))
        if k == "interval":
            # (v6.12) [lo, hi] with its ends in / out: "ivl:[num:-3,B)"
            return "ivl:%s%s,%s%s" % ("[" if e["lo_in"] is True else "(",
                                      _ref_id(e["lo"]), _ref_id(e["hi"]),
                                      "]" if e["hi_in"] is True else ")")
        if k == "table_cell":
            return "cell:%s:%d:%d" % (nfc(e["table"]), int(e["row"]),
                                      int(e["col"]))
        if k in ("pie", "sector", "build_circle"):
            # (v6.16 integrate) the pie chart family's own id rule
            # ("pie:qb", "sector:qb:a", "bcirc:qq"; wspec/pie.py)
            from . import pie as _pie
            return _pie.entity_id(e)
    except (KeyError, TypeError, IndexError, AttributeError, ValueError,
            SpecError):
        return "?"
    return None


def _ref_id(r):
    """A referenced entity id inside another id: a number reference is
    re-canonised (num:-0.5 and num:-1/2 are one number)."""
    r = nfc(r)
    if isinstance(r, str) and r.startswith("num:"):
        return "num:" + canon_number(r[4:])
    if not isinstance(r, str):
        raise TypeError(r)
    return r


def fact_slot(role):
    """answer -> 'a'; target / to_prove / to_construct / to_plot -> 't';
    else 'g'."""
    if role == "answer":
        return "a"
    if role in ("target", "to_prove", "to_construct", "to_plot"):
        return "t"
    return "g"


# relations whose argument order carries no meaning: the id sorts them
SYMMETRIC_RELS = frozenset(["equal_length", "equal_angle", "parallel",
                            "perpendicular", "congruent", "not_parallel",
                            "distance"])


def fact_key_args(f):
    a = [nfc(x) for x in f.get("args") or []]
    return sorted(a) if f.get("rel") in SYMMETRIC_RELS else a


def fact_id(f):
    """item:rel(arg,arg)#slot -- the fixed fact id rule (symmetric
    relations list their args sorted)."""
    args = ",".join(fact_key_args(f))
    return "%s:%s(%s)#%s" % (nfc(f.get("item", "")), nfc(f.get("rel", "")),
                             args, fact_slot(f.get("role")))


# ------------------------------------------------------ canonical json ---
def _canon_value(v):
    try:
        return canon_number(v)
    except SpecError:
        return v          # left as is; validation reports BAD_NUMBER


def _canon_unit(u):
    try:
        return canon_unit(u)
    except SpecError:
        return u


def _canon_fact(f):
    g = {}
    for k, v in f.items():
        if k in ("id", "item", "rel", "role", "text_template"):
            g[k] = nfc(v)
        elif k == "args":
            g[k] = [nfc(a) for a in v]
        elif k == "value":
            g[k] = None if v is None else _canon_value(v)
        elif k == "unit":
            g[k] = _canon_unit(v)
        elif k == "coef" and isinstance(v, list):
            # (v6.10) the coefficients of a 'linear' relation
            g[k] = [_canon_value(x) for x in v]
        elif k == "source" and isinstance(v, dict):
            s = dict((kk, nfc(vv)) for kk, vv in v.items() if kk != "from")
            if "from" in v:
                s["from"] = sorted(nfc(x) for x in v["from"])
            g[k] = s
        else:
            g[k] = v
    if g.get("unit") is None:
        g.pop("unit", None)
    return g


def _canon_entity(e):
    g = dict((k, nfc(v)) for k, v in e.items())
    for k in ("ends", "through", "arms"):
        if k in g and isinstance(g[k], list):
            g[k] = sorted(nfc(p) for p in g[k])
    if isinstance(g.get("vertices"), list):
        g["vertices"] = canon_cycle([nfc(p) for p in g["vertices"]])
    for k in ("value", "at"):
        if k in g:
            g[k] = _canon_value(g[k])
    return g


def canonical(spec):
    """A new dict: the canonical form of `spec` (never mutates it)."""
    c = {}
    for k, v in spec.items():
        if k == "entities":
            c[k] = sorted((_canon_entity(e) for e in v),
                          key=lambda e: str(e.get("id")))
        elif k == "facts":
            c[k] = sorted((_canon_fact(f) for f in v),
                          key=lambda f: str(f.get("id")))
        elif k == "figures":
            fs = []
            for fg in v:
                g = dict(fg)
                for kk in ("entities", "draws"):
                    if kk in g:
                        g[kk] = sorted(nfc(x) for x in g[kk])
                if isinstance(g.get("frame"), dict):
                    g["frame"] = canon_frame(g["frame"])
                fs.append(g)
            c[k] = sorted(fs, key=lambda g: str(g.get("id")))
        elif k in ("prose",):
            c[k] = sorted(v, key=lambda p: str(p.get("id")))
        elif k == "releases":
            c[k] = sorted(v, key=lambda r: str(r.get("fact")))
        elif k == "questions":
            qs = []
            for q in v:
                q2 = dict(q)
                q2["items"] = [dict(it, uses=sorted(it.get("uses") or []),
                                    targets=sorted(it.get("targets") or []))
                               for it in q.get("items") or []]
                qs.append(q2)
            c[k] = qs                     # sheet order is meaning
        else:
            c[k] = v
    return c


def _canon_axis_frame(a):
    g = dict(a)
    for kk in ("min", "max", "step"):
        if kk in g:
            g[kk] = _canon_value(g[kk])
    if isinstance(g.get("label_at"), list):
        vals = [_canon_value(x) for x in g["label_at"]]
        try:
            g["label_at"] = sorted(vals, key=lambda x: parse_exact(x))
        except Exception:               # noqa: BLE001 -- reported by family
            g["label_at"] = vals
    return g


def canon_frame(fr):
    """(v6.12) The canonical form of a figure's frame (numbers exact; the
    labelled values in increasing order). Axis order is meaning (x, y)."""
    g = _canon_axis_frame(fr)
    if isinstance(g.get("axes"), list):
        g["axes"] = [_canon_axis_frame(a) if isinstance(a, dict) else a
                     for a in g["axes"]]
    # (v6.16 gaps r3) a sketch plane's places: exact numbers
    sk = g.get("sketch")
    if isinstance(sk, dict) and isinstance(sk.get("places"), dict):
        sk = dict(sk)
        sk["places"] = dict(
            (p, [_canon_value(c) for c in xy] if isinstance(xy, list)
             else xy) for p, xy in sk["places"].items())
        g["sketch"] = sk
    return g


def dumps(obj):
    return json.dumps(obj, sort_keys=True, ensure_ascii=False,
                      separators=(",", ":"))


def canonical_bytes(spec):
    return dumps(canonical(spec)).encode("utf-8")


def spec_hash(spec):
    return hashlib.sha256(canonical_bytes(spec)).hexdigest()


def sha256_text(text):
    """Exact text, exact bytes: no normalisation (a prose approval is void
    on ANY change, including whitespace / Unicode form)."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def fact_hash(f):
    return hashlib.sha256(dumps(_canon_fact(f)).encode("utf-8")).hexdigest()
