# -*- coding: utf-8 -*-
u"""v6.17 (BRIEF_V617 V3 + V5) -- NUMBER FORMS and UNITS of a spec, checked.

V3, THE √ NUMBER FORM (author decision D6 of W-PLAN18-LIST: "√ מדויק;
בשאלות מציאות גם עיגול לעשירית. אחיד בכל הדף ובמפתח"):
  * a value is EXACT: canon.parse_exact reads "√13", "2√22", "3√5/2",
    "(3+√5)/2" and their TeX; canon_number gives ONE canonical byte form;
    canon.surd_tex / surd_plain give ONE printed form (the radicand
    squarefree, the coefficient whole and never 1, a fraction over one
    denominator);
  * an ANSWER is never a rounded decimal of an irrational value. The spec's
    own data RECOMPUTE the answer exactly (recompute(): Pythagoras in a
    right triangle, a triangle's area from a base and its height -- also a
    height that falls outside an obtuse triangle -- and a perimeter), and
    an answer that differs from it is refused: a rounding of a surd is
    ANSWER_ROUNDED_SURD, anything else ANSWER_RECOMPUTE_MISMATCH;
  * a rounded value is printed only NEXT TO the exact one: the answer field
    "approx": 1 | 2 (decimal places) prints '$2\\sqrt{22} \\approx 9.4$'
    in the key (the rounding is computed from the exact value, never
    typed). It is allowed on an irrational answer only (APPROX_ON_RATIONAL,
    APPROX_BAD, APPROX_ROLE) and REQUIRED on an irrational answer in a
    real-life unit -- metres, kilometres, litres, minutes, hours, shekels
    (APPROX_REQUIRED: "בשאלות מציאות גם עיגול לעשירית");
  * bound prose (G80) prints a surd in the canonical form only
    (BOUND_SURD_FORM: '√50' for 5√2, '1√2', '1.5√2' are refused), so the
    sheet and the key print one form.
V5, UNITS (דקות, שעות, ליטר, ק״מ, and ₪ which v6.16 had): canon.UNITS
  declares min / h / L / km, so a fact / an answer can carry them and the
  key prints them (canon.unit_display: '1 דקה', '6 דקות'); a number of bound
  prose followed by a unit WORD must be bound to a fact of THAT unit
  (BOUND_UNIT_MISMATCH: '2 שעות' bound to a fact in minutes).
v6.17 FIX (the verifier's M1 / M2, 2026-09-29):
  M1  an ALGEBRA answer (var_value) is recomputed too, as the ROOT of the
      equation its question prints -- one polynomial equation of degree 1
      or 2 in that one variable, in a bound math island of the item (else
      of the question's stem): a rounded root is ANSWER_ROUNDED_SURD, a
      wrong one ANSWER_RECOMPUTE_MISMATCH (root_issues). An answer whose
      question prints no such equation is NOT recomputed.
  M2  an answer's UNIT must be the unit its item's own words ask for
      ('כמה דקות', 'בס״מ', 'לקילומטרים'): ANSWER_UNIT_NOT_ASKED
      (asked_unit_issues)."""
import re
from fractions import Fraction

from . import canon as C
from .errors import Issue, REASONS

_CODES = {
    "APPROX_NOT_REQUESTED": "(v6.18, V617-W1-5) two decimal places require "
                             "an explicit rounding request in the item's "
                             "printed words or its own question stem",
    "APPROX_BAD": "(v6.17) an answer's approx is not 1 or 2 (decimal places)",
    "APPROX_ROLE": "(v6.17) approx on a fact that is not an answer",
    "APPROX_ON_RATIONAL": "(v6.17) approx on a rational answer: only an "
                          "irrational (√) value is printed with its rounding",
    "APPROX_REQUIRED": "(v6.17, D6) an irrational answer in a real-life unit "
                       "(m, km, L, min, h, ₪) without approx: a real-life "
                       "item prints the exact √ AND its rounding to a tenth",
    "ANSWER_ROUNDED_SURD": "(v6.17, D6) the answer is a rounded decimal of an "
                           "irrational value the spec's data give exactly: "
                           "write the exact √ (and approx in a real-life item)",
    "ANSWER_RECOMPUTE_MISMATCH": "(v6.17) the answer is not the value the "
                                 "spec's own data give (recomputed exactly)",
    "BOUND_SURD_FORM": "(v6.17) bound prose prints a surd outside the one "
                       "canonical form (radicand squarefree, coefficient "
                       "whole and not 1)",
    "BOUND_UNIT_MISMATCH": "(v6.17) a bound number is followed by a unit word "
                           "that is not the unit of the fact it is bound to",
    "ANSWER_UNIT_NOT_ASKED": "(v6.17 fix, V5) an answer's unit is not the "
                             "unit its item's own words ask for ('כמה דקות', "
                             "'בס״מ', 'לקילומטרים')",
}
for _k, _v in _CODES.items():
    REASONS.setdefault(_k, _v)

# units of a real-life quantity (D6: such an item prints its rounding too)
REAL_LIFE_UNITS = frozenset(["m", "km", "L", "min", "h", "ILS"])


# ------------------------------------------------------------- exact ----
def _ex(v):
    return C.parse_exact(v)


def _base(v, unit):
    """(a, b, r) of v in its dimension's base unit (exact)"""
    a, b, r = _ex(v)
    u = C.canon_unit(unit) if unit else None
    k = C.UNITS[u][1] if u else Fraction(1)
    return (a * k, b * k, r)


def _square(x):
    """x^2 as a Fraction when it is rational (a + b√r with a == 0 or
    b == 0), else None"""
    a, b, r = x
    if b == 0:
        return a * a
    if a == 0:
        return b * b * r
    return None


def _sqrt(q):
    """√q (q >= 0 a Fraction) as (a, b, r), exact"""
    if q < 0:
        return None
    n, d = q.numerator * q.denominator, q.denominator
    k, r = C._squarefree(n)
    c = Fraction(k, d)
    return (c, Fraction(0), 1) if r == 1 else (Fraction(0), c, r)


def _mul(x, y):
    a1, b1, r1 = x
    a2, b2, r2 = y
    if b1 == 0:
        return C._norm_exact(a1 * a2, a1 * b2, r2) if b2 else \
            (a1 * a2, Fraction(0), 1)
    if b2 == 0:
        return C._norm_exact(a2 * a1, a2 * b1, r1)
    if r1 == r2 and a1 == 0 and a2 == 0:
        return (b1 * b2 * r1, Fraction(0), 1)
    return None


def _add(x, y):
    a1, b1, r1 = x
    a2, b2, r2 = y
    if b1 and b2 and r1 != r2:
        return None
    r = r1 if b1 else r2
    return C._norm_exact(a1 + a2, b1 + b2, r if (b1 + b2) else 1)


def _float(x):
    a, b, r = x
    return float(a) + float(b) * (r ** 0.5)


def _canon(x):
    a, b, r = x
    if r == 1 or b == 0:
        return C.canon_number(C._rat_str(a))
    if a == 0:
        return C.canon_number("%s√%d" % (C._rat_str(b), r))
    return C.canon_number("%s%s%s√%d" % (C._rat_str(a), "-" if b < 0 else "+",
                                         C._rat_str(abs(b)), r))


# ---------------------------------------------------------- recompute ---
def _seg(a, b):
    return C.entity_id({"kind": "segment", "ends": [a, b]})


def _visible(ix, scope):
    try:
        return set(ix.visible_scopes(scope)) | set([scope])
    except Exception:                                   # noqa: BLE001
        return set([scope])


def recompute(ix, scope):
    """{target key: (a, b, r) in base units} of what the facts VISIBLE from
    `scope` give exactly: segment lengths (given, then Pythagoras in every
    right angle the facts state, to a fixpoint), triangle areas (a base and
    its height, a right triangle's legs) and perimeters. Keys:
    ('length', seg id), ('area', poly id), ('perimeter', poly id)."""
    vis = _visible(ix, scope)
    facts = [f for f in ix.facts.values() if isinstance(f, dict) and
             f.get("item") in vis and f.get("role") in
             ("given", "derived", "context")]
    from . import figure_scopes618 as FS618
    facts = FS618.state_recompute_facts(ix, scope, facts)
    known = {}
    for f in facts:
        if f.get("rel") == "length" and f.get("value") is not None:
            try:
                known[f["args"][0]] = _base(f["value"], f.get("unit"))
            except Exception:                           # noqa: BLE001
                pass
    # collinear triples a fact states (on_segment / midpoint)
    coll = set()
    for f in facts:
        if f.get("rel") in ("on_segment", "midpoint") and \
                len(f.get("args") or []) == 2:
            try:
                p = ix.entities[f["args"][0]]["name"]
                u, w = ix.entities[f["args"][1]]["ends"]
                coll.add(frozenset([p, u, w]))
            except (KeyError, TypeError, ValueError):
                pass
    rights = []                     # (vertex, arm1, arm2)
    for f in facts:
        rel, args = f.get("rel"), f.get("args") or []
        try:
            if rel == "angle_measure" and f.get("value") is not None and \
                    _ex(f["value"]) == (Fraction(90), Fraction(0), 1):
                e = ix.entities[args[0]]
                rights.append((e["vertex"], e["arms"][0], e["arms"][1]))
            elif rel == "perpendicular" and len(args) == 2:
                k1 = set(ix.entities[args[0]].get("ends") or [])
                k2 = set(ix.entities[args[1]].get("ends") or [])
                if len(k1) == 2 and len(k2) == 2 and len(k1 & k2) == 1:
                    v = list(k1 & k2)[0]
                    rights.append((v, list(k1 - k2)[0], list(k2 - k1)[0]))
                elif len(k1) == 2 and len(k2) == 2 and not (k1 & k2):
                    # 'PH ⟂ XY' with H on the line XY by a stated
                    # incidence (on the side, or -- an obtuse triangle --
                    # on its extension): the right angle at the foot H
                    for kh, ks in ((k1, k2), (k2, k1)):
                        for h in sorted(kh):
                            if ks | set([h]) in coll:
                                p_ = list(kh - set([h]))[0]
                                for x in sorted(ks):
                                    rights.append((h, p_, x))
            elif rel in ("rectangle", "square"):
                vs = ix.entities[args[0]]["vertices"]
                for i in range(len(vs)):
                    rights.append((vs[i], vs[i - 1], vs[(i + 1) % len(vs)]))
        except (KeyError, TypeError, IndexError, Exception):  # noqa: BLE001
            continue
    for _ in range(6):
        grew = False
        for v, a, b in rights:
            legs = (_seg(v, a), _seg(v, b))
            hyp = _seg(a, b)
            got = [known.get(x) for x in legs + (hyp,)]
            sq = [_square(g) if g is not None else None for g in got]
            if sq[0] is not None and sq[1] is not None and hyp not in known:
                known[hyp] = _sqrt(sq[0] + sq[1])
                grew = True
            for i in (0, 1):
                j = 1 - i
                if sq[j] is not None and sq[2] is not None and \
                        legs[i] not in known and sq[2] - sq[j] > 0:
                    known[legs[i]] = _sqrt(sq[2] - sq[j])
                    grew = True
        if not grew:
            break
    out = dict((("length", k), v) for k, v in known.items())
    for pid, e in ix.entities.items():
        if e.get("kind") != "polygon" or e.get("tag") is not None:
            continue
        vs = list(e.get("vertices") or [])
        n = len(vs)
        sides = [known.get(_seg(vs[i], vs[(i + 1) % n])) for i in range(n)]
        if None not in sides:
            s = (Fraction(0), Fraction(0), 1)
            for x in sides:
                s = _add(s, x) if s is not None else None
            if s is not None:
                out[("perimeter", pid)] = s
        if n != 3:
            continue
        area = None
        for i, P in enumerate(vs):
            X, Y = vs[(i + 1) % 3], vs[(i + 2) % 3]
            base = known.get(_seg(X, Y))
            if base is None:
                continue
            for v, a, b in rights:
                # the height P-H to the line XY: a right angle at H between
                # HP and a segment on the line XY (its ends among X, Y, H;
                # H on that line by a stated incidence unless it IS X / Y)
                arms = set([a, b])
                if P not in arms or v == P:
                    continue
                other = list(arms - set([P]))[0]
                H = v
                on_line = (H in (X, Y) and other in (X, Y)) or (
                    other in (X, Y) and frozenset([X, Y, H]) in coll)
                if not on_line:
                    continue
                h = known.get(_seg(P, H))
                if h is None:
                    continue
                prod = _mul(base, h)
                if prod is not None:
                    area = (prod[0] / 2, prod[1] / 2, prod[2])
                    break
            if area is not None:
                break
        if area is not None:
            out[("area", pid)] = area
    return out


def _area_base(v, unit):
    """an area value in base units (cm2 ...)"""
    return _base(v, unit)


def answer_issues(ix):
    """[Issue] of the ANSWERS against the recomputed exact values."""
    out = []
    cache = {}
    for f in sorted(ix.facts.values(), key=lambda g: str(g.get("id"))):
        if not isinstance(f, dict) or f.get("role") != "answer" or \
                f.get("value") is None or f.get("rel") not in (
                    "length", "area", "perimeter"):
            continue
        key = (f["rel"], (f.get("args") or [None])[0])
        sc = f.get("item")
        if sc not in cache:
            try:
                cache[sc] = recompute(ix, sc)
            except Exception:                           # noqa: BLE001
                cache[sc] = {}
        want = cache[sc].get(key)
        if want is None:
            continue
        try:
            got = _base(f["value"], f.get("unit"))
        except Exception:                               # noqa: BLE001
            continue
        if got == want:
            continue
        u = C.canon_unit(f.get("unit")) if f.get("unit") else None
        k = C.UNITS[u][1] if u else Fraction(1)
        exact_u = (want[0] / k, want[1] / k, want[2])
        shown = C.surd_plain(_canon(exact_u))
        if want[2] != 1 and got[2] == 1:
            ga = got[0] / k
            dec = None
            for d in range(0, 6):
                if (ga * 10 ** d).denominator == 1:
                    dec = d
                    break
            rounded = dec is not None and abs(float(ga) - _float(exact_u)) \
                <= 0.5 * 10 ** -dec + 1e-9
            if rounded:
                out.append(Issue("ANSWER_ROUNDED_SURD", f["id"], "%s is a "
                                 "rounding of the exact %s (≈ %s): print "
                                 "the exact √%s" % (
                                     C.canon_number(f["value"]), shown,
                                     C.approx_text(_canon(exact_u), 2),
                                     " and approx: 1" if u in
                                     REAL_LIFE_UNITS else "")))
                continue
        out.append(Issue("ANSWER_RECOMPUTE_MISMATCH", f["id"], "the answer "
                         "is %s; the spec's data give %s" % (
                             C.canon_number(f["value"]), shown)))
    return out


def _two_places_requested(ix, scope):
    """A supported explicit precision clause in this item or its stem.

    Only actual bound text is read, with the normal schema binding checks
    still active. Other items, answers and metadata never license rounding.
    This recognizer does not infer a precision from a displayed decimal.
    """
    from . import schema_bound as SB
    scopes = {scope, ix.scope_question.get(scope)}
    for sid, at, blk in SB.blocks_of(ix.spec):
        if sid not in scopes or not at.startswith("text:") or not isinstance(blk, dict):
            continue
        text = blk.get("text")
        if not isinstance(text, str):
            continue
        for clause in re.split(r"[.!?;\n]", text.replace("$", "")):
            if re.search(u"(?:^|\\s)(?:לא|אל|אין)(?:\\s|$)", clause):
                continue
            if re.search(u"(?:בדיוק של|בדיוק|לעגל ל־?|עגלו ל־?)\\s*"
                         u"(?:שתי|2)\\s+ספרות(?:\\s|$)", clause) or re.search(
                    u"(?:שתי|2)\\s+ספרות\\s+(?:אחרי|לאחר)\\s+הנקודה", clause):
                return True
    return False


def approx_issues(ix):
    out = []
    for f in sorted(ix.facts.values(), key=lambda g: str(g.get("id"))):
        if not isinstance(f, dict):
            continue
        w = "fact %s" % f.get("id")
        has = "approx" in f
        if has and f.get("role") != "answer":
            out.append(Issue("APPROX_ROLE", w, "approx on a %s"
                             % f.get("role")))
            continue
        if f.get("role") != "answer" or f.get("value") is None:
            continue
        try:
            irr = C.is_irrational(f["value"])
        except Exception:                               # noqa: BLE001
            continue
        if has:
            if f["approx"] not in C.APPROX_DECIMALS or \
                    isinstance(f["approx"], bool):
                out.append(Issue("APPROX_BAD", w, repr(f["approx"])))
            elif not irr:
                out.append(Issue("APPROX_ON_RATIONAL", w, "%s is rational"
                                 % C.canon_number(f["value"])))
            elif f["approx"] == 2 and not _two_places_requested(ix, f.get("item")):
                out.append(Issue("APPROX_NOT_REQUESTED", w,
                                 "approx: 2 has no explicit printed request "
                                 "for two decimal places in this item/stem"))
        elif irr:
            try:
                u = C.canon_unit(f.get("unit"))
            except Exception:                           # noqa: BLE001
                u = None
            if u in REAL_LIFE_UNITS:
                out.append(Issue("APPROX_REQUIRED", w, "%s %s: a real-life "
                                 "answer prints its rounding to a tenth too "
                                 "(approx: 1)" % (C.surd_plain(f["value"]),
                                                   u)))
    return out


def validate_numform(spec, ix, out):
    """schema._validate's hook (after the bound prose)."""
    out.extend(approx_issues(ix))
    out.extend(answer_issues(ix))
    out.extend(root_issues(spec, ix))
    from . import equation618 as E618
    out.extend(E618.issues(spec, ix))
    out.extend(asked_unit_issues(spec, ix))


# ------------------------------------------- v6.17 fix M1: algebra roots ---
# An ALGEBRA answer (var_value) is recomputed too when the question's bound
# prose prints the equation it solves: ONE polynomial equation of degree 1
# or 2 in that one variable, with rational coefficients, in a math island
# of the answer's OWN item (else of its question's stem) whose block binds
# the variable's atom to the answer's variable entity ("$x^2 - 6x + 7 = 0$",
# G9-T31). The answer must be a root, EXACTLY: a rounding of an irrational
# root is ANSWER_ROUNDED_SURD (D6: "√ מדויק"), anything else
# ANSWER_RECOMPUTE_MISMATCH. NOT recomputed (no issue, as before): an
# equation with another letter (y = 30x + 200), parentheses, a power above
# 2, a fraction with the variable in it, an inequality; an assignment
# "x = 4"; two different equations at the same level (ambiguous); an
# earlier item's equation.
_EQ_BAD = re.compile(u"\\\\(?:le|ge|leq|geq|ne|neq|lt|gt|approx|pm|mp)"
                     u"(?![a-zA-Z])|[<>≤≥≠±∓()\\[\\]|]")
_FRAC = re.compile(r"\\(?:f|frac|dfrac|tfrac)\s*\{\s*(\d+(?:\.\d+)?)\s*\}"
                   r"\s*\{\s*(\d+(?:\.\d+)?)\s*\}")


def _poly(side, var):
    """{degree: Fraction} of one side of an equation (TeX), or None."""
    s = side
    frs = []

    def keep(m):
        frs.append(Fraction(m.group(1)) / Fraction(m.group(2)))
        return u"#%d#" % (len(frs) - 1)
    s = _FRAC.sub(keep, s)
    s = s.replace(u"\\cdot", "*").replace(u"\\times", "*")
    s = s.replace(u"\\text{}", "").replace("{}", "")
    s = re.sub(r"\^\{\s*(\d+)\s*\}", r"^\1", s)
    s = s.replace(u"²", "^2").replace(u"−", "-").replace(" ", "")
    if not s or "\\" in s or "{" in s or "}" in s:
        return None
    if s[0] not in "+-":
        s = "+" + s
    terms = re.findall(r"[+-][^+-]*", s)
    if "".join(terms) != s:
        return None
    poly = {}
    for t in terms:
        sign = -1 if t[0] == "-" else 1
        body = t[1:]
        if not body:
            return None
        coef, deg, pos = Fraction(sign), 0, 0
        seen = False
        while pos < len(body):
            m = re.match(r"\d+(?:\.\d+)?", body[pos:])
            if m:
                coef *= Fraction(m.group(0))
                pos += m.end()
                seen = True
                continue
            m = re.match(r"#(\d+)#", body[pos:])
            if m:
                coef *= frs[int(m.group(1))]
                pos += m.end()
                seen = True
                continue
            if body.startswith(var, pos) and not (
                    pos + len(var) < len(body) and
                    body[pos + len(var)].isalpha()):
                pos += len(var)
                e = 1
                m = re.match(r"\^(\d+)", body[pos:])
                if m:
                    e = int(m.group(1))
                    pos += m.end()
                deg += e
                seen = True
                continue
            if body[pos] == "*" and seen:
                pos += 1
                continue
            return None
        if not seen or deg > 2:
            return None
        poly[deg] = poly.get(deg, Fraction(0)) + coef
    return poly


def equation_of(tex, var):
    """(c0, c1, c2) of one math island 'L = R' (L - R = 0) in the variable
    `var`, or None (not such an equation, or an assignment 'x = 4')."""
    if tex.count("=") != 1 or _EQ_BAD.search(tex):
        return None
    left, right = tex.split("=")
    pl, pr = _poly(left, var), _poly(right, var)
    if pl is None or pr is None:
        return None
    c = [pl.get(k, Fraction(0)) - pr.get(k, Fraction(0)) for k in (0, 1, 2)]
    if c[1] == 0 and c[2] == 0:
        return None
    for a, b in ((pl, pr), (pr, pl)):
        # an ASSIGNMENT 'x = 4' / '4 = x' names a value, it is no equation
        if a == {1: Fraction(1)} and set(b) <= set([0]):
            return None
    return tuple(c)


def roots_of(c):
    """the real roots of c0 + c1 x + c2 x^2 = 0 as exact (a, b, r)"""
    c0, c1, c2 = c
    if c2 == 0:
        return [(-c0 / c1, Fraction(0), 1)]
    d = c1 * c1 - 4 * c2 * c0
    if d < 0:
        return []
    sa, sb, sr = _sqrt(d)
    den = 2 * c2
    out = []
    for sg in (1, -1):
        out.append(C._norm_exact((-c1 + sg * sa) / den, sg * sb / den, sr))
    return sorted(set(out), key=_float)


def _eq_key(c):
    """one equation up to a non-zero factor"""
    lead = [x for x in (c[2], c[1], c[0]) if x != 0][0]
    return tuple(x / lead for x in c)


def _equations(spec, scope, var_id, var):
    """{eq key: (coefficients, island text)} printed by the bound blocks of
    `scope` whose bind list binds the variable to var_id"""
    from . import schema_bound as SB
    got = {}
    for sid, at, blk in SB.blocks_of(spec):
        if sid != scope or not at.startswith("text:") or \
                not isinstance(blk, dict) or \
                not isinstance(blk.get("text"), str):
            continue
        if not any(isinstance(b, dict) and b.get("entity") == var_id
                   for b in blk.get("bind") or []):
            continue
        for m in SB._ISLAND.finditer(blk["text"]):
            c = equation_of(m.group(1), var)
            if c is not None:
                got[_eq_key(c)] = (c, m.group(1).strip())
    return got


def _show(x):
    return C.surd_plain(_canon(x))


def _typed(v):
    """an answer's value as the key would print it (plain)"""
    try:
        if C.is_irrational(v):
            return C.surd_plain(v)
        return C.number_display(C.canon_number(v))
    except Exception:                                   # noqa: BLE001
        return repr(v)


def root_issues(spec, ix):
    """[Issue] of the var_value ANSWERS against the roots of the equation
    their question prints (see above)."""
    out = []
    for f in sorted(ix.facts.values(), key=lambda g: str(g.get("id"))):
        if not isinstance(f, dict) or f.get("role") != "answer" or \
                f.get("rel") != "var_value" or f.get("value") is None:
            continue
        vid = (f.get("args") or [None])[0]
        ve = ix.entities.get(vid) or {}
        var = ve.get("name")
        if ve.get("kind") != "variable" or not isinstance(var, str) or \
                not var:
            continue
        item = f.get("item")
        eqs = {}
        for sc in (item, ix.scope_question.get(item)):
            if sc is None:
                continue
            try:
                eqs = _equations(spec, sc, vid, var)
            except Exception:                           # noqa: BLE001
                eqs = {}
            if eqs:
                break
        if len(eqs) != 1:
            continue
        c, tex = list(eqs.values())[0]
        try:
            got = _ex(f["value"])
        except Exception:                               # noqa: BLE001
            continue
        rts = roots_of(c)
        if got in rts:
            continue
        shown = ", ".join(_show(r) for r in rts) or u"no real root"
        irr = [r for r in rts if r[2] != 1]
        if irr and got[2] == 1:
            ga = got[0]
            dec = None
            for d in range(0, 6):
                if (ga * 10 ** d).denominator == 1:
                    dec = d
                    break
            near = [r for r in irr if dec is not None and
                    abs(float(ga) - _float(r)) <= 0.5 * 10 ** -dec + 1e-9]
            if near:
                out.append(Issue("ANSWER_ROUNDED_SURD", f["id"],
                                 u"%s = %s is a rounding of the exact root "
                                 u"%s of $%s$: print the exact √" % (
                                     var, _typed(f["value"]),
                                     _show(near[0]), tex)))
                continue
        out.append(Issue("ANSWER_RECOMPUTE_MISMATCH", f["id"],
                         u"%s = %s is not a root of $%s$ (its roots: %s)" % (
                             var, _typed(f["value"]), tex, shown)))
    return out


# --------------------------------- v6.17 fix M2: the unit an item asks ---
# An answer's unit must be the unit its item's OWN bound prose asks for:
# "כמה <unit>" (כמה דקות, כמה ליטר, כמה ס״מ), "ב<unit>" / "ב־<unit>" and
# "ל<unit>" / "ל־<unit>" with a PLURAL unit word or (after ב only) an
# abbreviation (בס״מ, במטרים, בדקות; לקילומטרים, למטרים -- "המירו את
# התשובה לקילומטרים"). A unit word right after a printed number is that
# number's unit (BOUND_UNIT_MISMATCH's business), not a question; a
# SINGULAR word after ב / ל is a rate ("30 ליטר לדקה", "ק״מ בשעה") and
# asks nothing. An answer with no unit, or an item that names no unit, is
# not checked. The stem item of a question reads its question's blocks.
_ASK_PLURAL = (u"דקות", u"שעות", u"ליטרים", u"מטרים", u"קילומטרים",
               u"סנטימטרים", u"מילימטרים", u"שקלים", u"מעלות")
_ASK_ABBR = (u"ס״מ", u'ס"מ', u"מ״מ", u'מ"מ', u"ק״מ", u'ק"מ', u"סמ״ר",
             u'סמ"ר', u"מ״ר", u'מ"ר', u"ממ״ר", u'ממ"ר', u"ש״ח", u'ש"ח')


def _heb(ch):
    return u"א" <= ch <= u"ת"


def asked_units(text):
    """[(phrase, canonical unit)] a bound block's words ask for"""
    from . import schema_bound as SB
    plain, at = SB.atoms_plain(text)
    after_num = set()
    for kind, _tok, _a, b in at:
        if kind == "number":
            i = b
            while i < len(plain) and plain[i] in u"  ":
                i += 1
            after_num.add(i)
    words = sorted(set(C.UNIT_WORDS) | set(_ASK_PLURAL) | set(_ASK_ABBR),
                   key=len, reverse=True)
    out = []
    for i in range(len(plain)):
        glued = bool(i) and _heb(plain[i - 1])
        if glued and plain.startswith(u"כמה ", i):
            # "וכמה", "בכמה", "ובכמה": up to two prefix letters
            k = i
            while k > 0 and i - k < 2 and plain[k - 1] in u"ובלש":
                k -= 1
            glued = k > 0 and _heb(plain[k - 1])
        if glued:
            continue
        for pre, pool in ((u"כמה ", words), (u"ב־", _ASK_PLURAL + _ASK_ABBR),
                          (u"ב", _ASK_PLURAL + _ASK_ABBR),
                          (u"ל־", _ASK_PLURAL), (u"ל", _ASK_PLURAL)):
            if not plain.startswith(pre, i):
                continue
            j = i + len(pre)
            while pre == u"כמה " and j < len(plain) and plain[j] == " ":
                j += 1
            if j in after_num:
                continue
            hit = None
            for w in sorted(pool, key=len, reverse=True):
                if plain.startswith(w, j) and not (
                        j + len(w) < len(plain) and
                        _heb(plain[j + len(w)])):
                    hit = w
                    break
            if hit is None:
                continue
            try:
                u = C.canon_unit(C.UNIT_WORDS.get(hit, hit))
            except Exception:                           # noqa: BLE001
                u = None
            if u:
                out.append((plain[i:j + len(hit)], u))
                break
    return out


def asked_unit_issues(spec, ix):
    """[Issue] ANSWER_UNIT_NOT_ASKED"""
    from . import schema_bound as SB
    by_scope = {}
    try:
        for sid, at, blk in SB.blocks_of(spec):
            if at.startswith("text:") and isinstance(blk, dict) and \
                    isinstance(blk.get("text"), str):
                by_scope.setdefault(sid, []).append(blk["text"])
    except Exception:                                   # noqa: BLE001
        return []
    out = []
    for f in sorted(ix.facts.values(), key=lambda g: str(g.get("id"))):
        if not isinstance(f, dict) or f.get("role") != "answer" or \
                not f.get("unit"):
            continue
        try:
            u = C.canon_unit(f.get("unit"))
        except Exception:                               # noqa: BLE001
            continue
        item = f.get("item")
        texts = list(by_scope.get(item, []))
        q = ix.questions.get(ix.scope_question.get(item))
        if q is not None and SB.stem_item(q) == item:
            texts += by_scope.get(q.get("id"), [])
        asked = []
        for t in texts:
            asked.extend(asked_units(t))
        if not asked or u in set(x[1] for x in asked):
            continue
        out.append(Issue("ANSWER_UNIT_NOT_ASKED", f["id"],
                         u"the item asks %s (%s); the answer is in %s" % (
                             u" / ".join(sorted(set(x[0] for x in asked))),
                             u"/".join(sorted(set(x[1] for x in asked))),
                             u)))
    return out


# ------------------------------------------------------- bound prose ----
def _unit_word_at(plain, pos):
    """(word, canonical unit) of the unit word starting after spaces at
    plain[pos:], else (None, None). The longest word wins; the word must
    end at a non-letter."""
    i = pos
    while i < len(plain) and plain[i] in u"  ":
        i += 1
    best = None
    for w, u in C.UNIT_WORDS.items():
        if plain.startswith(w, i):
            j = i + len(w)
            if j < len(plain) and (u"א" <= plain[j] <= u"ת"):
                continue
            if best is None or len(w) > len(best[0]):
                best = (w, u)
    return best if best else (None, None)


def bound_form_problems(text, bind, facts):
    """[(code, detail)] of one bound block whose bind list IS its atom list
    (schema_bound checked that): BOUND_SURD_FORM, BOUND_UNIT_MISMATCH."""
    from . import schema_bound as SB
    plain, at = SB.atoms_plain(text)
    out = []
    if len(at) != len(bind):
        return out
    for (kind, tok, _a, b), bd in zip(at, bind):
        if kind != "number" or not isinstance(bd, dict):
            continue
        if u"√" in tok:
            why = C.surd_problem(tok)
            if why:
                out.append(("BOUND_SURD_FORM", why))
        if "fact" not in bd:
            continue
        units = set()
        for fid in SB.bind_facts(bd):
            f = facts.get(fid) or {}
            try:
                u = C.canon_unit(f.get("unit"))
            except Exception:                           # noqa: BLE001
                u = None
            if u:
                units.add(u)
        if not units:
            continue
        word, wu = _unit_word_at(plain, b)
        if word is not None and wu not in units:
            out.append(("BOUND_UNIT_MISMATCH", "%s %s: the number is bound "
                        "to a fact in %s" % (tok, word,
                                             "/".join(sorted(units)))))
    return out
