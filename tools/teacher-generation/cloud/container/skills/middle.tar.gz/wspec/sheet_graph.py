# -*- coding: utf-8 -*-
u"""wspec.sheet_graph -- (v6.16 integrate) a GRAPH figure on the SHEET-level
spec path. Owner: the integrator. The graph family itself (the author spec
'wspec-graph/1', its exact validation, leak rules, public projection,
renderer and independent checker) is wspec/graph/ (graphs owner); this
module only wires it into schema / project / render / check / bound prose,
permanently (the run-time hooks_graph.install() of the graphs owner is no
longer needed: it is a no-op once this module is merged).

A GRAPH FIGURE of a sheet spec is a coordinate_plane figure with one more
key, "graph": the author graph block WITHOUT graph_version / figure / frame
(the figure's own id and frame are used):

    {"id": "q4_head", "scope": "q4", "figure_accuracy": "accurate",
     "entities": ["axis:x", "axis:y", "plane:xy"], "draws": [<name facts>],
     "frame": {"family": "coordinate_plane", "plane": "plane:xy", ...},
     "graph": {"axes": {...}, "aspect": "equal" | "free", "curves": [...],
               "marks": [...], "parallel": [...], "finds": [...]}}

(grammar: wspec/graph/kinds.py docstring). A FIND is the graph's target: it
names the ITEM that asks it ("item": "q4a") -- an item of the figure's own
question -- and carries its answer (private; checked against the
mathematics, GRAPH_ANSWER_MISMATCH). The item itself lists no spec target
for it (its "targets" are spec facts only); the sheet path reads the finds
of an item from here (finds_of_item).

What this module decides:
  validate(spec, ix, out)   the graph block of every figure (kinds.validate,
                            a coordinate_plane frame, finds of the figure's
                            question's ITEMS)
  public_graph(fig)         the public graph model the public figure carries
                            (kinds.public_model: no answer, no hidden number)
  scan_public(pub, out)     the leak scan of a public model's graph parts
  finds_of_item(ix, iid)    [(figure id, find record, exact truth)]
  display_layout(fig)       the renderer's settings for what is not public
  BOUND PROSE: the binding {"tok": t, "graph": "<figure>/<object>/<part>"}
    binds an atom of a printed block to a PUBLIC number / name of a graph
    figure of the block's question (bind_problem):
      curve:<t>/m | b     a line's slope / intercept (its def public)
      curve:<t>/x         a vertical line's x
      curve:<t>/p | k     a parabola's vertex (p, k)
      curve:<t>/eq        a number of the curve's equation PRINTED in the
                          same block (any form; the whole printed equation
                          is read by the graph's own parser and must be
                          this curve -- kinds.same_curve_as_text)
      curve:<t>/name      a curve's printed label name ('f', 'g')
      mark:<t>/x | y      a mark's public coordinates
      mark:<t>/name       a mark's printed name ('P')
      find:<id>/at        the x (value_at) / the y (x_for_value) a find
                          asks at -- printed by the question, public
      find:<id>/zero      the number word "אפס" of "נקודות האפס" (the
                          zeros a find asks: rel zeros / x_intercept /
                          positive_interval / negative_interval): value 0
    A number bound to a hidden curve / mark (its numbers are asked) is
    refused (BOUND_PRIVATE): the text may not print what the figure hides.
"""
import copy
import re

from .graph import kinds as K

FIELD = "graph"
# codes as names (the house reason-table test reads call sites)
_C_SHAPE, _C_FIND = "GRAPH_BAD_SHAPE", "GRAPH_FIND_BAD"
_C_PUBLIC = "PUBLIC_VALUE_NOT_WHITELISTED"
# a find the student answers by DRAWING (the item's task is plot)
PLOT_FINDS = ("to_plot", "plot_point")


def is_graph(fig):
    return isinstance(fig, dict) and FIELD in fig


def author_of(fig):
    """the author graph spec of a sheet figure (kinds grammar)"""
    d = dict(fig[FIELD])
    d.update({"graph_version": K.GRAPH_VERSION, "figure": fig["id"],
              "frame": fig.get("frame")})
    return d


def _issue(code, where, detail):
    from .errors import Issue
    return Issue(code, where, detail)


def validate(spec, ix, out):
    """the graph blocks of a sheet spec (see the module docstring)."""
    for g in (spec.get("figures") or []) if isinstance(spec, dict) else []:
        if not isinstance(g, dict) or FIELD not in g:
            continue
        w = "figure %s graph" % g.get("id")
        if not isinstance(g.get(FIELD), dict) or \
                not isinstance(g.get("frame"), dict) or \
                g["frame"].get("family") != "coordinate_plane":
            out.append(_issue(_C_SHAPE, w, "a graph lives on a "
                              "coordinate_plane frame"))
            continue
        try:
            gi, _M = K.validate(author_of(g))
        except Exception as ex:          # noqa: BLE001 -- malformed block
            out.append(_issue(_C_SHAPE, w, "%s: %s" % (type(ex).__name__,
                                                        ex)))
            continue
        for i in gi:
            out.append(_issue(i.code, "%s: %s" % (w, i.where), i.detail))
        qid = ix.scope_question.get(g.get("scope"))
        for f in g[FIELD].get("finds") or []:
            it = f.get("item") if isinstance(f, dict) else None
            fid = f.get("id") if isinstance(f, dict) else f
            if it not in ix.items or ix.scope_question.get(it) != qid:
                out.append(_issue(_C_FIND, w, "find %s: item %r is not an "
                                  "item of %s" % (fid, it, qid)))
                continue
            if f.get("rel") in PLOT_FINDS and \
                    ix.items[it].get("task_type") != "plot":
                out.append(_issue(_C_FIND, w, "find %s (%s): its item %s "
                                  "is a %r item, not 'plot'" % (
                                      fid, f.get("rel"), it,
                                      ix.items[it].get("task_type"))))
    _cross_figure_leaks(spec, ix, out)
    _givens_rules(spec, out)


def _givens_rules(spec, out):
    """(v6.16 integrate r2, graph I4 / HOOKS B2-B3) the two sheet-level
    rules of givens-only figures, as build-time refusals:
      GRAPH_GIVENS_NOT_GIVEN  an OPTIONAL mark ('a datum the question's text
          prints') whose pair no text of its question prints (bound to the
          coordinate facts of one point) -- the engine exempts optional
          marks from the key points of an undrawn curve, so 'optional' must
          be honest (givens.stated_marks_problems)
      GRAPH_TARGET_DRAWN      a label of a GIVENS-ONLY figure that prints an
          answer another graph figure of the sheet guards (the corpus reads
          figure texts sheet-wide, SCORING s7 (i)); a SOURCE figure's own
          label is exempt (only_givens=True)"""
    if not isinstance(spec, dict) or not spec.get("questions") or not any(
            is_graph(g) for g in spec.get("figures") or []):
        return
    from .graph import givens as GV
    try:
        probs = GV.stated_marks_problems(spec)
    except Exception:                    # noqa: BLE001 -- validate says why
        probs = []
    for p in probs:
        out.append(_issue("GRAPH_GIVENS_NOT_GIVEN", "figure %s graph" % (
            p.split(":", 1)[0]), p))
    try:
        leaks = GV.sheet_label_leaks(spec.get("figures") or [],
                                     only_givens=True)
    except Exception:                    # noqa: BLE001
        leaks = []
    for fid, oid, t, h, gid in leaks:
        out.append(_issue("GRAPH_TARGET_DRAWN", "figure %s graph" % fid,
                          "%s prints %r, which contains %r -- an answer "
                          "figure %s guards (sheet-wide)" % (oid, t, h, gid)))


def _cross_figure_leaks(spec, ix, out):
    """(v6.16 integrate) the leak rules of kinds are FIGURE-local: a curve
    asked in one figure of a question and drawn with PUBLIC numbers in
    another figure of the same question (an item figure repeating the
    plane) would give the answer away -- the public model is one file.
    GRAPH_TARGET_DRAWN: every figure of a question that draws an asked
    curve (same equation) must hide it too (carry a find on it)."""
    byq = {}
    for g in (spec.get("figures") or []) if isinstance(spec, dict) else []:
        if not is_graph(g) or not isinstance(g.get(FIELD), dict):
            continue
        try:
            M = K.checked(author_of(g))
            pub = K.public_model(author_of(g))
        except Exception:                 # noqa: BLE001 -- validate says why
            continue
        qid = ix.scope_question.get(g.get("scope"))
        pubc = dict((c["id"], "def" in c) for c in pub["curves"])
        asked = set()
        for f in M.finds:
            asked.update(f.rec.get("args") or [])
        for cid, cur in M.curves.items():
            byq.setdefault(qid, []).append(
                (g["id"], cid, cur, pubc.get(cid, False), cid in asked))
    for qid, rows in sorted(byq.items(), key=lambda kv: str(kv[0])):
        for gid, cid, cur, _pub, is_asked in rows:
            if not is_asked:
                continue
            for gid2, cid2, cur2, pub2, _a in rows:
                if gid2 != gid and pub2 and cur.same(cur2):
                    out.append(_issue(
                        "GRAPH_TARGET_DRAWN", "figure %s graph" % gid2,
                        "%s draws %s with public numbers; figure %s of the "
                        "same question %s asks about it (%s)" % (
                            gid2, cid2, gid, qid, cid)))


def plot_items(ix):
    """items a graph find asks to DRAW (a plot item's target)"""
    out = set()
    for g in ix.figures.values():
        if is_graph(g) and isinstance(g.get(FIELD), dict):
            for f in g[FIELD].get("finds") or []:
                if isinstance(f, dict) and f.get("rel") in PLOT_FINDS:
                    out.add(f.get("item"))
    return out


def public_graph(fig):
    return K.public_model(author_of(fig))


def display_layout(fig):
    """the renderer's 'curves' / 'marks' settings of a sheet graph figure:
    the numbers the public model does not carry (only the renderer reads
    them; the delivered figure keeps them in figures/<fig>.settings.json)"""
    return K.display_layout(author_of(fig))


def scan_public(pub, out):
    """leak scan of the graph parts of a public model"""
    from .graph import render as GR
    for g in (pub.get("figures") or []) if isinstance(pub, dict) else []:
        if not isinstance(g, dict) or FIELD not in g:
            continue
        gp = g[FIELD]
        w = "figure %s graph" % g.get("id")
        probs = GR.scan_public(gp) if isinstance(gp, dict) else \
            ["not an object"]
        if isinstance(gp, dict) and K.public_hash(gp) != \
                gp.get("public_hash"):
            probs.append("graph public_hash")
        if isinstance(gp, dict) and (gp.get("figure") != g.get("id") or
                                     gp.get("frame") != g.get("frame")):
            probs.append("graph figure / frame differ from the figure's")
        for p in probs:
            out.append(_issue(_C_PUBLIC, w, p))


def finds_of_item(ix, iid):
    """[(figure id, find record, exact truth)] of item iid, in the figure's
    find order (the truth is kinds' own, never the author's answer)"""
    out = []
    for gid in sorted(ix.figures):
        g = ix.figures[gid]
        if not is_graph(g):
            continue
        recs = [f for f in g[FIELD].get("finds") or []
                if isinstance(f, dict) and f.get("item") == iid]
        if not recs:
            continue
        M = K.checked(author_of(g))
        truth = dict((f.id, f.truth) for f in M.finds)
        for f in recs:
            out.append((gid, f, truth.get(f.get("id"))))
    return out


def figures_of_question(ix, qid):
    return [g for gid, g in sorted(ix.figures.items())
            if is_graph(g) and ix.scope_question.get(g.get("scope")) == qid]


# ------------------------------------------------------------ binding ---
REF_RE = re.compile(r"^([a-z0-9][a-z0-9_]{0,31})/((?:curve|mark|find):"
                    r"[A-Za-z0-9_.:#-]{1,64})/([a-z]{1,4})\Z")
CURVE_PARTS = {"line": ("m", "b", "eq", "name"), "vline": ("x", "eq", "name"),
               "parabola": ("p", "k", "eq", "name")}
MARK_PARTS = ("x", "y", "name")
FIND_PARTS = ("at", "zero")
# finds whose question names "the zero(s)" ("נקודות האפס", value 0)
ZERO_FINDS = ("zeros", "x_intercept", "positive_interval",
              "negative_interval")
_EQ = re.compile(u"[xy]\\s*=\\s*[^,;:?!\u05d0-\u05ea]*")
_NUM = re.compile(u"[\u2212-]?\\d+(?:\\.\\d+)?")


def _untex(s):
    return s.replace("$", "").replace("^2", u"\u00b2").replace(
        "\\left", "").replace("\\right", "")


def _eq_numbers(text):
    """exact numbers printed in an equation text (their absolute values:
    a binary minus is an operator of the printed form)"""
    from fractions import Fraction
    return set(abs(Fraction(n.replace(u"\u2212", "-")))
               for n in _NUM.findall(text))


def bind_problem(graphs, ref, kind, tok, val, text):
    """None when the binding holds, else why. graphs: {figure id: PUBLIC
    graph model} of the figures the block's question shows; ref: the
    binding's "graph" value; kind / tok / val: the atom (kind, printed
    token, its value or None); text: the whole printed block."""
    from fractions import Fraction
    m = REF_RE.match(ref) if isinstance(ref, str) else None
    if m is None:
        return "graph ref %r is not <figure>/<object>/<part>" % (ref,)
    fid, obj, part = m.groups()
    gp = graphs.get(fid)
    if gp is None:
        return "figure %s is no graph figure of this question" % fid

    def num(v):
        q = K.Q(v)
        return None if q is None else Fraction(q)
    if obj.startswith("curve:"):
        c = [x for x in gp.get("curves") or [] if x.get("id") == obj]
        if not c:
            return "%s has no %s" % (fid, obj)
        c = c[0]
        if part not in CURVE_PARTS.get(c.get("fn"), ()):
            return "%s is a %s: no part %r" % (obj, c.get("fn"), part)
        if part == "name":
            nm = (c.get("label") or {}).get("name")
            if kind not in ("var", "name") or nm != tok:
                return "%r is not the printed name of %s (%r)" % (tok, obj,
                                                                 nm)
            return None
        d = c.get("def")
        if d is None:
            return "%s is not public (its numbers are asked): a text may " \
                "not print them" % obj
        if kind not in ("number", "word") or val is None:
            return "a %s part binds a number" % part
        if part == "eq":
            cur = K.Curve.from_def(d)
            eqs = [e.strip() for e in _EQ.findall(_untex(text))]
            hit = [e for e in eqs if K.same_curve_as_text(cur, e)]
            if not hit:
                return "the block prints no equation of %s (%s)" % (
                    obj, ", ".join(K.all_equation_texts(cur)))
            if not isinstance(val, Fraction) or not any(
                    abs(val) in _eq_numbers(e) for e in hit):
                return "%s is not a number of the printed equation %r" % (
                    tok, hit[0])
            return None
        want = num(d.get(part))
        if want is None or val != want:
            return "%s.%s is %s" % (obj, part, d.get(part))
        return None
    if obj.startswith("mark:"):
        mk = [x for x in gp.get("marks") or [] if x.get("id") == obj]
        if not mk:
            return "%s has no %s" % (fid, obj)
        mk = mk[0]
        if part not in MARK_PARTS:
            return "a mark has no part %r" % part
        if part == "name":
            nm = (mk.get("label") or {}).get("name")
            if nm != tok:
                return "%r is not the printed name of %s (%r)" % (tok, obj,
                                                                 nm)
            return None
        xy = mk.get("xy")
        if xy is None:
            return "%s is not public (its place is asked)" % obj
        want = num(xy[0 if part == "x" else 1])
        if kind != "number" or val != want:
            return "%s.%s is %s" % (obj, part, xy[0 if part == "x" else 1])
        return None
    fd = [x for x in gp.get("finds") or [] if "find:" + str(x.get("id")) ==
          obj]
    if not fd:
        return "%s has no %s" % (fid, obj)
    if part == "zero":
        if fd[0].get("rel") not in ZERO_FINDS:
            return "%s (%s) asks no zeros" % (obj, fd[0].get("rel"))
        if kind not in ("number", "word") or val != 0:
            return "%r is not the zero of %s" % (tok, obj)
        return None
    if part not in FIND_PARTS or "at" not in fd[0]:
        return "%s has no public %r" % (obj, part)
    if kind != "number" or val != num(fd[0]["at"]):
        return "%s.at is %s" % (obj, fd[0]["at"])
    return None


def ref_figure(ref):
    m = REF_RE.match(ref) if isinstance(ref, str) else None
    return m.group(1) if m else None


def question_graphs(spec_or_pub, qid, public=False):
    """{figure id: PUBLIC graph model} of the graph figures of question
    qid: from a spec (projected here) or from a public model (as carried)"""
    out = {}
    for g in (spec_or_pub.get("figures") or []):
        if not isinstance(g, dict) or FIELD not in g:
            continue
        sc = g.get("scope") or ""
        q = re.match(r"^(q\d+)", sc)
        if q is None or q.group(1) != qid:
            continue
        try:
            out[g["id"]] = g[FIELD] if public else public_graph(g)
        except Exception:                # noqa: BLE001 -- validate says why
            continue
    return out


def answer_numbers(truth, rel):
    """the exact numbers a key line restates for a find's truth (used by
    wspec_build's key check); None for an answer that is not numeric"""
    from fractions import Fraction
    if truth is None:
        return None
    if rel in ("slope", "y_intercept", "x_intercept", "axis_of_symmetry",
               "min_value", "value_at"):
        return [Fraction(truth)]
    if rel in ("zeros", "x_for_value"):
        return [Fraction(v) for v in truth]
    if rel in ("vertex", "plot_point"):
        return [Fraction(v) for v in truth]
    if rel == "intersection":
        return [Fraction(v) for p in truth for v in p]
    if rel in ("increase_interval", "decrease_interval",
               "positive_interval", "negative_interval"):
        return [Fraction(iv[k]) for iv in truth for k in ("lo", "hi")
                if iv[k] is not None]
    if rel == "shift":
        return [Fraction(truth["dx"]), Fraction(truth["dy"])]
    return None


# (v6.16 integrate r2, graph I2) the answers a printed equation STATES in
# its own form: 'y = 3x − 2' states the slope 3 and the y-intercept −2 (the
# '−' of '3x − 2' is an operator for schema_bound.atoms, which read '2');
# 'y = (x − 2)² − 9' states the vertex (2, −9), its axis and its least
# value; 'y = (x − 3)(x + 3)' its zeros; 'y = x² − 9' its y-intercept.
FORM_STATES = {"slope_intercept": ("slope", "y_intercept"),
               "vertex": ("vertex", "axis_of_symmetry", "min_value"),
               "factored": ("zeros",),
               "expanded": ("y_intercept",)}


def _norm_eq(s):
    return re.sub(r"\s+", "", s.replace("-", K.MINUS))


def equation_states(line, curve, rel):
    """True when the key line prints the equation of `curve` (an author
    curve def) in a form that states the answer of a find `rel` on it --
    the printed text is exactly that form's text (kinds.equation_text), so
    every number of the answer is read off it with its sign"""
    try:
        cur = K.Curve.from_def(dict((k, v) for k, v in curve.items()
                                    if k in ("fn", "m", "b", "x", "p",
                                             "k")))
    except Exception:                    # noqa: BLE001 -- not a curve def
        return False
    eqs = [_norm_eq(e.strip()) for e in _EQ.findall(_untex(line))]
    for form in K.EQ_FORMS.get(cur.fn, ()):
        if rel not in FORM_STATES.get(form, ()):
            continue
        t = K.equation_text(cur, form)
        if not t:
            continue
        forms = [t]
        m = re.match(r"^y = (\(.+?\)|x)(\(.+?\)|x)\Z", t)
        if form == "factored" and m:
            # the factors in either order: 'y = (x − 3)(x + 3)'
            forms.append("y = " + m.group(2) + m.group(1))
        if any(_norm_eq(f) in eqs for f in forms):
            return True
    return False


def key_restates(line, fid, rec, truth, curve=None, axes=None):
    """None when the original key line restates the find's exact answer,
    else why (an equation is read as an equation; numbers with their
    printed sign). curve: the author def of the curve a one-curve find asks
    about (drawn or not) -- its equation printed in a form that states the
    answer restates it (equation_states)."""
    from . import schema_bound as SB
    rel = rec.get("rel")
    from . import graph_units618 as GU618
    why = GU618.problem(line, axes, rel, answer_numbers(truth, rel))
    if why:
        return why
    if isinstance(curve, dict) and truth is not None and \
            rel not in ("equation", "to_plot", "monotone") and \
            equation_states(line, curve, rel):
        return None
    if rel in ("equation", "to_plot"):
        cur = K.Curve.from_def(truth)
        eqs = [e.strip() for e in _EQ.findall(_untex(line))]
        if any(K.same_curve_as_text(cur, e) for e in eqs):
            return None
        return "the key %r states no equation of %s (%s)" % (
            line, rec.get("args") or rec.get("id"),
            " / ".join(K.all_equation_texts(cur)))
    if rel == "monotone":
        words = {"increasing": u"עולה", "decreasing": u"יורדת",
                 "constant": u"קבועה"}
        return None if words.get(truth, "\0") in line else \
            "the key %r does not say %s" % (line, words.get(truth, truth))
    want = answer_numbers(truth, rel)
    if want is None:
        return "find %s (%s): no numeric answer to restate" % (
            rec.get("id"), rel)
    got = []
    for k, t in SB.atoms(line):
        if k == "number":
            try:
                got.append(SB.atom_value(k, t))
            except Exception:            # noqa: BLE001
                pass
    miss = [v for v in want if v not in got]
    if miss:
        return "the key %r does not state %s of find %s" % (
            line, ", ".join(K.cstr(v) for v in miss), rec.get("id"))
    return None


def copy_graph_block(g):
    return copy.deepcopy(g[FIELD])
