# -*- coding: utf-8 -*-
"""The LAYOUT program of a figure: where its points go, in model units
(x to the right, y UP). It is a display setting (the public spec states the
mathematics, not coordinates), written as a short list of CONSTRUCTIVE
steps so that incidences are exact by construction:

  {"p": "A", "xy": [x, y]}            a free point
  {"p": "M", "mid": ["A", "C"]}       the midpoint of AC
  {"p": "E", "on": ["D", "C", t]}     D + t (C - D)   (t any real number)
  {"p": "H", "foot": ["B", "A", "C"]} the foot of the perpendicular from B
                                      to the line AC
  {"p": "O", "meet": ["A", "C", "B", "D"]}  lines AC and BD meet
  {"p": "D", "par4": ["A", "B", "C"]} A + C - B (ABCD a parallelogram)
  {"p": "C", "polar": ["A", r, deg]}  A + r (cos deg, sin deg)
  {"p": "C", "turn": ["A", "B", deg, k]}  A + k * rot(deg)(B - A)
  {"p": "E", "bisect_meet": ["A", "B", "D", "D", "C"]}  the bisector of
                                      the angle BAD meets the line DC

Closed: any other key, a point defined twice, a step that uses a point not
yet placed, a non-finite number or a degenerate construction (parallel
lines, a zero-length base) is refused (LayoutError). Nothing here knows the
spec; the engine checks that every point the figure shows is placed and
that the placed figure satisfies the public facts (geomcheck)."""
import math
import re

NAME_RE = re.compile(r"^[A-Z][1-9]?'{0,3}\Z")
OPS = {"xy": ("num", "num"),
       "mid": ("pt", "pt"),
       "on": ("pt", "pt", "num"),
       "foot": ("pt", "pt", "pt"),
       "meet": ("pt", "pt", "pt", "pt"),
       "par4": ("pt", "pt", "pt"),
       "polar": ("pt", "num", "num"),
       "turn": ("pt", "pt", "num", "num"),
       "bisect_meet": ("pt", "pt", "pt", "pt", "pt")}
EPS = 1e-12


class LayoutError(Exception):
    pass


def _num(v, where):
    if isinstance(v, bool) or not isinstance(v, (int, float)) or \
            not math.isfinite(float(v)):
        raise LayoutError("%s: %r is not a finite number" % (where, v))
    return float(v)


def _meet(a, b, c, d, where):
    r = (b[0] - a[0], b[1] - a[1])
    s = (d[0] - c[0], d[1] - c[1])
    den = r[0] * s[1] - r[1] * s[0]
    scale = max(1.0, math.hypot(*r) * math.hypot(*s))
    if abs(den) <= 1e-9 * scale:
        raise LayoutError("%s: the lines are parallel" % where)
    t = ((c[0] - a[0]) * s[1] - (c[1] - a[1]) * s[0]) / den
    return (a[0] + t * r[0], a[1] + t * r[1])


def solve(steps):
    """{name: (x, y)} in model units, in step order. Raises LayoutError."""
    if not isinstance(steps, list) or not steps:
        raise LayoutError("layout: a non-empty list of steps")
    P = {}
    for i, st in enumerate(steps):
        where = "layout[%d]" % i
        if not isinstance(st, dict) or set(st) - set(OPS) != {"p"} or \
                len(st) != 2:
            raise LayoutError("%s: {'p': name, <one op of %s>: args}"
                              % (where, "/".join(sorted(OPS))))
        name = st["p"]
        if not isinstance(name, str) or not NAME_RE.match(name):
            raise LayoutError("%s: %r is not a point name" % (where, name))
        if name in P:
            raise LayoutError("%s: %s placed twice" % (where, name))
        op = [k for k in st if k != "p"][0]
        args = st[op]
        kinds = OPS[op]
        if not isinstance(args, list) or len(args) != len(kinds):
            raise LayoutError("%s: %s takes %d arguments" % (where, op,
                                                             len(kinds)))
        v = []
        for a, k in zip(args, kinds):
            if k == "num":
                v.append(_num(a, where))
            else:
                if a not in P:
                    raise LayoutError("%s: %r is not placed before %s"
                                      % (where, a, name))
                v.append(P[a])
        if op == "xy":
            p = (v[0], v[1])
        elif op == "mid":
            p = ((v[0][0] + v[1][0]) / 2, (v[0][1] + v[1][1]) / 2)
        elif op == "on":
            a, b, t = v
            p = (a[0] + t * (b[0] - a[0]), a[1] + t * (b[1] - a[1]))
        elif op == "foot":
            q, a, b = v
            dx, dy = b[0] - a[0], b[1] - a[1]
            L2 = dx * dx + dy * dy
            if L2 <= EPS:
                raise LayoutError("%s: foot on a zero-length base" % where)
            t = ((q[0] - a[0]) * dx + (q[1] - a[1]) * dy) / L2
            p = (a[0] + t * dx, a[1] + t * dy)
        elif op == "meet":
            p = _meet(v[0], v[1], v[2], v[3], where)
        elif op == "par4":
            a, b, c = v
            p = (a[0] + c[0] - b[0], a[1] + c[1] - b[1])
        elif op == "polar":
            a, r, deg = v
            t = math.radians(deg)
            p = (a[0] + r * math.cos(t), a[1] + r * math.sin(t))
        elif op == "turn":
            a, b, deg, k = v
            t = math.radians(deg)
            dx, dy = b[0] - a[0], b[1] - a[1]
            p = (a[0] + k * (dx * math.cos(t) - dy * math.sin(t)),
                 a[1] + k * (dx * math.sin(t) + dy * math.cos(t)))
        else:                                     # bisect_meet
            vv, a, b, c, d = v
            ua = (a[0] - vv[0], a[1] - vv[1])
            ub = (b[0] - vv[0], b[1] - vv[1])
            la, lb = math.hypot(*ua), math.hypot(*ub)
            if la <= EPS or lb <= EPS:
                raise LayoutError("%s: an arm of zero length" % where)
            w = (ua[0] / la + ub[0] / lb, ua[1] / la + ub[1] / lb)
            if math.hypot(*w) <= 1e-9:
                raise LayoutError("%s: a straight angle has no inner "
                                  "bisector direction here" % where)
            p = _meet(vv, (vv[0] + w[0], vv[1] + w[1]), c, d, where)
        if not all(math.isfinite(x) for x in p):
            raise LayoutError("%s: %s is not finite" % (where, name))
        P[name] = p
    return P
