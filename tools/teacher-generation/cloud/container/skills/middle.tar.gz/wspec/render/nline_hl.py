# -*- coding: utf-8 -*-
"""highlight(svg, object_map, object_id) for a NUMBER-LINE figure (v6.12).

The figure's bytes are kept: one group
    <g data-layer="highlight" data-object="<object id>"> ... </g>
is inserted right after the <svg> start tag (painted UNDER the figure). It
holds one element per PART of the object in the object map, nothing else:
  a line / path / polygon  -> a copy of its geometry, thick, highlight colour
                              (data-hl="<element id>");
  a span [a, b] of the axis -> a line on the axis between the two places
                              (their px ends from the map; data-span="a b");
  a dot                    -> a disk under it;
  a text                   -> a box behind its glyph box.
No text, no hook (data-nl), no number, no new tick or mark. Stdlib only."""
import re
import xml.etree.ElementTree as ET

HL = "#f59f00"
HL_SOFT = "#ffe8a3"
HL_W = "6"
BOX_PAD = 2.0
NS = "{http://www.w3.org/2000/svg}"
_START = re.compile(r"<svg\b[^>]*>\n")


class HighlightError(Exception):
    pass


def _n(v):
    s = ("%.2f" % max(0.0, round(v, 2))).rstrip("0").rstrip(".")
    return s or "0"


def _adv(t, fs):
    w = 0.0
    for ch in t:
        w += 0.5 if ch.isdigit() else 0.25 if ch in ".'" else \
            0.56 if ch in (u"−", "+") else 0.72 if ch.isupper() else 0.5
    return w * fs


def _text_box(el):
    fs = float(el.get("font-size"))
    t = el.text or ""
    w = _adv(t, fs)
    x, y = float(el.get("x")), float(el.get("y"))
    anc = el.get("text-anchor")
    x0 = x - w / 2 if anc == "middle" else (x - w if anc == "end" else x)
    if t in (u"\u2212", "+"):             # a lone sign: a bar at mid height
        return (x0 - BOX_PAD, y - 0.5 * fs - BOX_PAD, x0 + w + BOX_PAD,
                y - 0.15 * fs + BOX_PAD)
    top = 0.72 * fs if any(c.isdigit() or c.isupper() or c == "+"
                           for c in t) else 0.5 * fs
    bot = 0.22 * fs if any(c in "gjpqyQ" for c in t) else 0.05 * fs
    return (x0 - BOX_PAD, y - top - BOX_PAD, x0 + w + BOX_PAD,
            y + bot + BOX_PAD)


def highlight(svg, object_map, object_id):
    obj = (object_map.get("objects") or {}).get(object_id)
    if obj is None:
        raise HighlightError("object %r is not in the object map" % object_id)
    root = ET.fromstring(svg.encode("utf-8"))
    els = {}
    for el in root.iter():
        if el.get("id"):
            els[el.get("id")] = (el.tag.replace(NS, ""), el)
    out = []
    for part in obj.get("parts") or []:
        eid = part["element"]
        if eid not in els:
            raise HighlightError("part %s is not in the figure" % eid)
        tag, el = els[eid]
        span = part.get("span")
        if isinstance(span, list):
            px = part.get("px")
            if not px or len(px) != 2:
                raise HighlightError("span part %s has no px ends" % eid)
            out.append('<line x1="%s" y1="%s" x2="%s" y2="%s" stroke="%s" '
                       'stroke-width="%s" stroke-linecap="round" '
                       'data-hl="%s" data-span="%s"/>' % (
                           _n(px[0][0]), _n(px[0][1]), _n(px[1][0]),
                           _n(px[1][1]), HL, HL_W, eid, " ".join(span)))
            continue
        if tag == "line":
            out.append('<line x1="%s" y1="%s" x2="%s" y2="%s" stroke="%s" '
                       'stroke-width="%s" stroke-linecap="round" '
                       'data-hl="%s"/>' % (el.get("x1"), el.get("y1"),
                                           el.get("x2"), el.get("y2"), HL,
                                           HL_W, eid))
        elif tag == "circle":
            r = float(el.get("r")) + 3.0
            out.append('<circle cx="%s" cy="%s" r="%s" fill="%s" '
                       'data-hl="%s"/>' % (el.get("cx"), el.get("cy"), _n(r),
                                           HL, eid))
        elif tag == "polygon":
            out.append('<polygon points="%s" fill="%s" stroke="%s" '
                       'stroke-width="4" stroke-linejoin="round" '
                       'data-hl="%s"/>' % (el.get("points"), HL, HL, eid))
        elif tag == "path":
            out.append('<path d="%s" fill="none" stroke="%s" '
                       'stroke-width="%s" stroke-linecap="round" '
                       'stroke-linejoin="round" data-hl="%s"/>' % (
                           el.get("d"), HL, HL_W, eid))
        elif tag == "text":
            b = _text_box(el)
            out.append('<polygon points="%s,%s %s,%s %s,%s %s,%s" fill="%s" '
                       'data-hl="%s"/>' % (
                           _n(b[0]), _n(b[1]), _n(b[2]), _n(b[1]), _n(b[2]),
                           _n(b[3]), _n(b[0]), _n(b[3]), HL_SOFT, eid))
        else:
            raise HighlightError("part %s is a %s" % (eid, tag))
    m = _START.search(svg)
    if m is None:
        raise HighlightError("no <svg> start tag")
    grp = '<g data-layer="highlight" data-object="%s">\n%s\n</g>\n' % (
        object_id.replace("&", "&amp;").replace("<", "&lt;").replace(
            ">", "&gt;").replace('"', "&quot;"), "\n".join(out))
    return svg[:m.end()] + grp + svg[m.end():]


def verify_highlight(base_svg, hl_svg, object_map, object_id):
    """[problem]: the highlighted file must be exactly highlight()'s output
    for this object (the figure unchanged, one overlay group)."""
    try:
        want = highlight(base_svg, object_map, object_id)
    except HighlightError as e:
        return ["HL_REFUSED: %s" % e]
    return [] if want == hl_svg else ["HL_NOT_EXACT: the highlighted file "
                                      "is not the overlay of %s" % object_id]
