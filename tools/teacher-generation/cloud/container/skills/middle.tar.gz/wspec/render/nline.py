# -*- coding: utf-8 -*-
"""wspec.render.nline -- the NUMBER-LINE family renderer (v6.12,
BRIEF_V612 section 1, family B). Stdlib only.

    out = nline.render(public_model, display_settings, nline.ENGINE_VERSION)
        -> {"svg", "object_map", "placements", "validation"}
    engine.render() hands every figure whose frame is a number_line here.

INPUT: only a validated public model (gate.require_public) -- the frame it
carries is what the figure PRINTS (per axis: number of intervals, printed
labels by tick index; never min / max / step). Places are put by the
numbers: a number entity at its value, a point at its public coordinate
(a given / derived / context fact of the figure's question); a point whose
value is not public (the student reads it off) is placed by the display
settings' layout {"p": id, "at": value} or {"p": id, "tick": index}. Values
map to ticks through two printed labels (as the student reads the line);
with fewer than two printed labels a place needs "tick".

DISPLAY SETTINGS (closed; defaults in brackets)
  figure (required)   layout [[]]   width [280] (horizontal)  height [240]
  (vertical: the line's length)   orientation [horizontal] | vertical
  margin [4]  font_family [David Libre,serif] (| serif)
  number_size [10.67] (10.67 | 12)  name_size [12.67] (12 | 12.67 | 14)
  point_radius [3.2] (2.67 | 3.2)  grow [true]

WHAT IS DRAWN (closed dialect wspec-nl-svg/1, svg_dialect_nline.json)
  the axis: a line, a filled arrowhead at the end of increasing values
  (right; up on a vertical line), every tick (index 0..n), the printed
  numbers of the frame at their ticks (U+2212 minus; a fraction stacked:
  numerator / bar / denominator, its sign U+2212 left of the bar; a mixed
  number with its whole part) -- never dropped: a crowded row GROWS the
  figure (x1.15 .. x2.0), and only then the validation FAILS naming it;
  every shown point / number: a filled dot at its value (a ring when it is
  an OPEN end of a shown interval); a point's letter beside it (above the
  line; right of a vertical one), never nearer another dot;
  drawn facts: coordinate / mark (the value under its dot), jump_value
  (the signed size over its arc), distance / abs_value (a bracket above the
  line + its value), name of the axis (its letter past the arrowhead).
  Anything else drawn -> RENDER_FACT_NOT_MARKED (validation FAIL);
  jumps: an arc above the line from its start to its end (a filled head,
  tip at the end value), never cut: arcs that would meet are raised;
  intervals: a thick bar between the ends, closed end filled, open hollow.
Deterministic: sorted iteration, fixed number format, no clock.
"""
import hashlib
import json
import math
from fractions import Fraction

from .. import baseline as B
from .. import canon
from .. import schema as S
from . import gate
from .gate import RenderRefused

ENGINE_VERSION = "wspec-render-nl/1.0.0"
DIALECT_VERSION = "wspec-nl-svg/1"
MINUS = u"−"
INK, PAPER = "#000000", "#ffffff"
W_AXIS, W_TICK, W_JUMP, W_BAR = "1.07", "0.8", "1.07", "2.67"
TICK_MAJOR_HALF = 2.93     # a printed tick (house: 2 x 2.2 pt across)
TICK_MINOR_HALF = 1.96     # an unprinted tick (6 : 9 of it)
NUM_GAP = 1.87             # tick end to number (house 1.4 pt)
PAD = 7.0                  # axis overhang past the first / last tick
HEAD_L, HEAD_HW = 6.67, 2.43       # axis / jump head (house 5 pt, 20 deg)
MIN_TICK_GAP = 8.0         # printed floor between two ticks (6 pt)
LABEL_GAP = 2.0            # clear paper between two printed labels
STROKE_CLEAR = 1.0         # a label box this far from every stroke / dot
NAME_NEAR = 24.0           # a letter within this of its dot
OWN_MARGIN = 2.0           # its own dot nearer than any other by this
ARC_MIN, ARC_MAX, ARC_PREF = 6.0, 22.0, 0.34
ARC_STEP, ARC_TOP = 6.0, 60.0
ARC_APART = 2.5            # two arcs keep this apart (away from shared ends)
ARC_SHARE = 5.0            # ... except this near an end they share
RING_N = 24
GROW_STEPS = (1.0, 1.15, 1.3, 1.5, 1.75, 2.0)
LAYERS = ("lines", "marks", "points", "labels")
ROLES = ("axis_line", "axis_arrow", "tick", "tick_number", "dot",
         "open_end", "point_name", "value_caption", "jump_arc", "jump_head",
         "jump_caption", "interval_bar", "span_bracket", "span_caption",
         "axis_name")
VALUE_ROLES = ("given", "derived", "context")
MARKED_RELS = ("name", "coordinate", "mark", "jump_value", "distance",
               "abs_value")

SETTINGS = {
    "figure": (lambda v: isinstance(v, str), None),
    "layout": (lambda v: isinstance(v, list), []),
    "width": (lambda v: gate._pos(v) and 80 <= v <= 1200, 280),
    "height": (lambda v: v is None or (gate._pos(v) and 80 <= v <= 1200),
               240),
    "orientation": (lambda v: v in ("horizontal", "vertical"), "horizontal"),
    "margin": (lambda v: gate._pos(v) and 2 <= v <= 40, 4),
    "font_family": (lambda v: v in ("David Libre,serif", "serif"),
                    "David Libre,serif"),
    "number_size": (lambda v: v in (10.67, 12), 10.67),
    "name_size": (lambda v: v in (12, 12.67, 14), 12.67),
    "point_radius": (lambda v: v in (2.67, 3.2), 3.2),
    "grow": (lambda v: isinstance(v, bool), True),
}


def is_number_line(fig):
    fr = (fig or {}).get("frame")
    return isinstance(fr, dict) and fr.get("family") == "number_line"


def settings(ds):
    if not isinstance(ds, dict):
        raise RenderRefused("RENDER_BAD_SETTINGS", "not a dict")
    extra = sorted(set(ds) - set(SETTINGS))
    if extra:
        raise RenderRefused("RENDER_BAD_SETTINGS", "unknown key(s) %s (the "
                            "number-line settings are closed: %s)" % (
                                extra, sorted(SETTINGS)))
    out = {}
    for k, (ok, dflt) in sorted(SETTINGS.items()):
        if k not in ds:
            if k == "figure":
                raise RenderRefused("RENDER_BAD_SETTINGS", "figure missing")
            out[k] = list(dflt) if isinstance(dflt, list) else dflt
            continue
        if not ok(ds[k]):
            raise RenderRefused("RENDER_BAD_SETTINGS", "%s=%r" % (k, ds[k]))
        out[k] = ds[k]
    return out


# ----------------------------------------------------------- numbers ------
def _q(v):
    try:
        a, b, r = canon.parse_exact(v)
    except Exception:                   # noqa: BLE001
        return None
    return a if r == 1 else None


def _adv(t, fs):
    w = 0.0
    for ch in t:
        if ch.isdigit():
            w += 0.5
        elif ch in ".'":
            w += 0.25
        elif ch in (MINUS, "+"):
            w += 0.56
        elif ch.isupper():
            w += 0.72
        else:
            w += 0.5
    return w * fs


def number_parts(v, form=None, signed=False):
    """How a family number prints on the line: {"plain": text} or a stacked
    {"sign", "whole", "num", "den"} (sign U+2212 / '+' / '')."""
    v = Fraction(v)
    sign = MINUS if v < 0 else ("+" if signed and v > 0 else "")
    av = abs(v)
    if av.denominator == 1:
        return {"plain": sign + str(av.numerator)}
    f = form
    if f == "mixed" and av < 1:
        f = "fraction"
    if f is None:
        f = "decimal" if canon.terminating(av) else "fraction"
    if f == "decimal":
        return {"plain": sign + canon.family_display(str(av), "plain",
                                                     "decimal")}
    whole = av.numerator // av.denominator if f == "mixed" else 0
    fr = av - whole
    return {"sign": sign, "whole": str(whole) if whole else "",
            "num": str(fr.numerator), "den": str(fr.denominator)}


def parts_text(p):
    """The logical text of a printed number (the object map's)."""
    if "plain" in p:
        return p["plain"]
    return p["sign"] + (p["whole"] + " " if p["whole"] else "") + \
        "%s/%s" % (p["num"], p["den"])


class _Label(object):
    """A printed number / letter: runs relative to its box's top-left."""

    def __init__(self, hook, ref, parts, fs, at=None):
        self.hook, self.ref, self.parts, self.fs, self.at = \
            hook, ref, parts, fs, at
        asc = 0.72 * fs
        self.runs, self.bars = [], []
        if "plain" in parts:
            t = parts["plain"]
            self.w = _adv(t, fs)
            self.h = asc + 0.22 * fs
            self.runs.append((hook, t, self.w / 2.0, asc))
            return
        yn = asc
        yv = yn + 0.09 * fs + 1.4
        yd = yv + 1.4 + asc
        wf = max(_adv(parts["num"], fs), _adv(parts["den"], fs)) + 2.0
        head = parts["whole"]
        if head and parts["sign"]:
            # a signed mixed number: its sign and whole part are ONE run
            # ('\u22122'), as a PDF prints them (one span)
            head = parts["sign"] + head
            parts = dict(parts, sign="")
        ws = _adv(parts["sign"], fs) + 1.0 if parts["sign"] else 0.0
        wh = _adv(head, fs) + 1.0 if head else 0.0
        self.w = ws + wh + wf
        self.h = yd + 0.12 * fs
        x = 0.0
        if parts["sign"]:
            self.runs.append((hook + "-s", parts["sign"], ws / 2.0 - 0.3,
                              yv + 0.3 * fs))
            x += ws
        if head:
            self.runs.append((hook + "-w", head, x + wh / 2.0 - 0.3,
                              yv + 0.33 * fs))
            x += wh
        cx = x + wf / 2.0
        self.runs.append((hook + "-n", parts["num"], cx, yn))
        self.bars.append((hook + "-bar", x + 0.6, x + wf - 0.6, yv))
        self.runs.append((hook + "-d", parts["den"], cx, yd))
        # the fraction's centre (it sits over its tick)
        self.frac_cx = cx

    def centre_dx(self):
        """x offset (from the box's left) of the point the label stands
        over: a stacked fraction's own centre (its sign hangs left)."""
        if "plain" in self.parts or not (self.parts["sign"] or
                                         self.parts["whole"]):
            return self.w / 2.0
        return self.frac_cx if not self.parts["whole"] else self.w / 2.0


# ----------------------------------------------------------- geometry -----
def _r2(x):
    v = round(x + 0.0, 2)
    return 0.0 if v == 0 else v


def _r6(x):
    v = round(x + 0.0, 6)
    return 0.0 if v == 0 else v


def _fmt(x):
    v = _r2(x)
    if v < 0:
        raise ValueError("negative coordinate %r" % x)
    s = ("%.2f" % v).rstrip("0").rstrip(".")
    return s or "0"


def _seg_box_d(a, b, box):
    """distance from segment ab to an axis-aligned box (0 when they meet)."""
    x0, y0, x1, y1 = box
    if _seg_hits(a, b, box):
        return 0.0
    best = min(_pt_box_d(a, box), _pt_box_d(b, box))
    for c, d in (((x0, y0), (x1, y0)), ((x1, y0), (x1, y1)),
                 ((x1, y1), (x0, y1)), ((x0, y1), (x0, y0))):
        best = min(best, _seg_seg_d(a, b, c, d))
    return best


def _pt_box_d(p, box):
    dx = max(box[0] - p[0], 0.0, p[0] - box[2])
    dy = max(box[1] - p[1], 0.0, p[1] - box[3])
    return math.hypot(dx, dy)


def _pt_seg_d(p, a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    L2 = dx * dx + dy * dy
    if L2 == 0:
        return math.hypot(p[0] - a[0], p[1] - a[1])
    t = max(0.0, min(1.0, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / L2))
    return math.hypot(p[0] - a[0] - t * dx, p[1] - a[1] - t * dy)


def _seg_seg_d(a, b, c, d):
    if _cross(a, b, c, d):
        return 0.0
    return min(_pt_seg_d(a, c, d), _pt_seg_d(b, c, d), _pt_seg_d(c, a, b),
               _pt_seg_d(d, a, b))


def _cross(a, b, c, d):
    def o(p, q, r):
        return (q[0] - p[0]) * (r[1] - p[1]) - (q[1] - p[1]) * (r[0] - p[0])
    d1, d2, d3, d4 = o(c, d, a), o(c, d, b), o(a, b, c), o(a, b, d)
    return d1 * d2 < 0 and d3 * d4 < 0


def _seg_hits(a, b, box):
    x0, y0, x1, y1 = box
    if x0 <= a[0] <= x1 and y0 <= a[1] <= y1:
        return True
    if x0 <= b[0] <= x1 and y0 <= b[1] <= y1:
        return True
    for c, d in (((x0, y0), (x1, y0)), ((x1, y0), (x1, y1)),
                 ((x1, y1), (x0, y1)), ((x0, y1), (x0, y0))):
        if _cross(a, b, c, d):
            return True
    return False


def _box_gap(a, b):
    dx = max(a[0] - b[2], b[0] - a[2], 0.0)
    dy = max(a[1] - b[3], b[1] - a[3], 0.0)
    if dx == 0 and dy == 0:
        return -1.0
    return math.hypot(dx, dy)


# ------------------------------------------------------------- builder ----
class _El(object):
    def __init__(self, tag, layer, attrs, text=None):
        self.tag, self.layer, self.attrs, self.text = tag, layer, attrs, text
        self.id = None
        self.item = None


class _Item(object):
    def __init__(self, iid, role, source, text=None):
        self.id, self.role, self.source, self.text = iid, role, source, text
        self.els = []


class _Build(object):
    def __init__(self, pub, ix, fig, st, length):
        self.pub, self.ix, self.fig, self.st = pub, ix, fig, st
        self.vert = st["orientation"] == "vertical"
        self.L = float(length)          # width (horizontal) / axis length
        self.els, self.items, self.issues = [], [], []
        self.boxes = []                  # (box, owner label ref)
        self.strokes = []                # (a, b, halfwidth, what)
        self.dots = {}                   # place -> (x, y)
        self.objects = {}
        self.fr = fig["frame"]
        ax = self.fr["axes"][0]
        self.axis = ax["axis"]
        self.n = int(ax["intervals"])
        self.form = ax.get("form")
        self.labels = [(int(k), v) for k, v in ax.get("labels") or []]
        self.qid = ix.scope_question.get(fig["scope"])
        self.shown = sorted(B._figure_shows(fig, ix))
        self.draws = [ix.facts[d] for d in sorted(fig.get("draws") or [])
                      if d in ix.facts]
        self.bands = None       # (above, below) measured by a first pass

    # ------------------------------------------------------------ issues --
    def issue(self, code, where, detail):
        self.issues.append({"code": code, "where": where, "detail": detail})

    # ----------------------------------------------------------- mapping --
    def value_map(self):
        """(a, b): value = a + b * index, from two printed labels; None
        when fewer than two are printed (or they disagree)."""
        if len(self.labels) < 2:
            return None
        (k1, v1), (k2, v2) = self.labels[0], self.labels[-1]
        b = (Fraction(v2) - Fraction(v1)) / (k2 - k1)
        a = Fraction(v1) - k1 * b
        if b == 0 or any(a + k * b != Fraction(v) for k, v in self.labels):
            return None
        return a, b

    def index_of(self, v):
        m = self.value_map()
        if m is None:
            return None
        return (Fraction(v) - m[0]) / m[1]

    def public_value(self, eid):
        e = self.ix.entities.get(eid) or {}
        if e.get("kind") == "number":
            return _q(e.get("value")), None
        for f in sorted(self.ix.facts.values(), key=lambda f: f["id"]):
            if f.get("rel") == "coordinate" and f.get("args") == [
                    eid, self.axis] and f.get("value") is not None and \
                    f.get("role") in VALUE_ROLES and \
                    self.ix.scope_question.get(f.get("item")) == self.qid:
                return _q(f["value"]), f
        return None, None

    def place_all(self):
        lay = {}
        for step in self.st["layout"]:
            if not isinstance(step, dict) or set(step) not in (
                    {"p", "at"}, {"p", "tick"}):
                raise RenderRefused("RENDER_LAYOUT", "a layout step is "
                                    "{p, at} or {p, tick}: %r" % (step,))
            lay[step["p"]] = step
        self.index = {}
        self.places = [e for e in self.shown if self.ix.kind(e) in
                       ("point", "number")]
        for p in self.places:
            v, _f = self.public_value(p)
            step = lay.get(p)
            idx = None
            if v is not None:
                idx = self.index_of(v)
                if step is not None and "at" in step and \
                        _q(step["at"]) != v:
                    raise RenderRefused("RENDER_LAYOUT", "%s is %s in the "
                                        "public model, the layout says %s"
                                        % (p, v, step["at"]))
                if idx is None and step is not None and "tick" in step:
                    idx = _q(step["tick"])
            elif step is not None:
                if "at" in step:
                    if _q(step["at"]) is None:
                        raise RenderRefused("RENDER_LAYOUT", "at %r"
                                            % (step["at"],))
                    idx = self.index_of(step["at"])
                else:
                    idx = _q(step["tick"])
            if idx is None:
                raise RenderRefused("RENDER_LAYOUT", "%s has no place: no "
                                    "public value mapped by two printed "
                                    "labels and no layout step" % p)
            if not 0 <= idx <= self.n:
                raise RenderRefused("RENDER_LAYOUT", "%s at tick index %s is "
                                    "off the line (0..%d)" % (p, idx,
                                                              self.n))
            self.index[p] = Fraction(idx)
        for p in lay:
            if p not in self.index:
                raise RenderRefused("RENDER_LAYOUT", "the layout places %s, "
                                    "which the figure does not show" % p)

    # ------------------------------------------------------------ frame ---
    def frame_geometry(self, g):
        """Tick positions along the line for a length multiplied by g."""
        st, fs = self.st, self.st["number_size"]
        m = st["margin"]
        self.num_labels = {}
        for k, v in self.labels:
            self.num_labels[k] = _Label("num", self.axis, number_parts(
                v, self.form), fs, at=k)
        named = any(f.get("rel") == "name" and f.get("args") == [self.axis]
                    for f in self.draws)
        ns = st["name_size"]
        if not self.vert:
            W = min(1200.0 * 2, round(self.L * g))
            first = self.num_labels.get(0)
            last = self.num_labels.get(self.n)
            lpad = max(PAD, (first.w / 2.0 + 0.5) if first else 0.0)
            rpad = PAD + HEAD_L + 1.0 + (
                2.0 + _adv(self.ix.entities[self.axis].get("name") or "x",
                           ns) + 1.0 if named else 0.0)
            if last:
                rpad = max(rpad, last.w / 2.0 + 0.5)
            self.s0 = m + lpad
            self.u = (W - m - rpad - self.s0) / float(self.n)
            self.W = W
        else:
            Hl = min(1200.0 * 2, round(self.L * g))
            self.s0 = m + PAD + 2.0 + max(
                (l.h / 2.0 for l in self.num_labels.values()), default=0.0)
            self.u = (Hl - self.s0 - (m + PAD + HEAD_L + 1.0 + (
                2.0 + 0.72 * ns + 1.0 if named else 0.0))) / float(self.n)
            self.Hlen = Hl
        return self.u

    def dense_problems(self):
        out = []
        if self.u < MIN_TICK_GAP:
            out.append(("RENDER_TICKS_TOO_DENSE", self.axis, "%.2f px between "
                        "two ticks (at least %.0f)" % (self.u, MIN_TICK_GAP)))
        ks = sorted(self.num_labels)
        for a, b in zip(ks, ks[1:]):
            la, lb = self.num_labels[a], self.num_labels[b]
            need = (la.w + lb.w) / 2.0 + LABEL_GAP if not self.vert else \
                (la.h + lb.h) / 2.0 + LABEL_GAP
            if (b - a) * self.u < need:
                out.append(("RENDER_LABEL_NO_PLACE", "%s@%d" % (self.axis, b),
                            "the numbers of ticks %d and %d need %.1f px, the "
                            "line gives %.1f" % (a, b, need, (b - a) *
                                                 self.u)))
        return out

    def S(self, idx):
        return self.s0 + float(idx) * self.u

    # frame (s along, n across: + = letters / jumps side) -> svg
    def P(self, s, n):
        if not self.vert:
            return (s, self.Y0 - n)
        return (self.X0 + n, self.Ybase - s)

    # -------------------------------------------------------------- ink ---
    def item(self, role, source, text=None):
        it = _Item("d%03d" % (len(self.items) + 1), role, source, text)
        self.items.append(it)
        return it

    def add(self, it, tag, layer, attrs, text=None):
        el = _El(tag, layer, attrs, text)
        el.item = it
        it.els.append(el)
        self.els.append(el)
        return el

    def line(self, it, layer, a, b, w, hook, ref, at=None, cap="butt"):
        attrs = [("x1", _fmt(a[0])), ("y1", _fmt(a[1])), ("x2", _fmt(b[0])),
                 ("y2", _fmt(b[1])), ("stroke", INK), ("stroke-width", w),
                 ("stroke-linecap", cap), ("data-nl", hook),
                 ("data-for", ref)]
        if at is not None:
            attrs.append(("data-at", str(at)))
        self.strokes.append((a, b, float(w) / 2.0, hook))
        return self.add(it, "line", layer, attrs)

    def poly(self, it, layer, pts, hook, ref, fill=INK, stroke=None):
        attrs = [("points", " ".join("%s,%s" % (_fmt(x), _fmt(y))
                                     for x, y in pts)), ("fill", fill)]
        if stroke:
            attrs += [("stroke", INK), ("stroke-width", stroke)]
        attrs += [("data-nl", hook), ("data-for", ref)]
        for a, b in zip(pts, pts[1:] + pts[:1]):
            self.strokes.append((a, b, 0.6, hook))
        return self.add(it, "polygon", layer, attrs)

    def path(self, it, layer, pts, hook, ref, w):
        d = "M %s %s" % (_fmt(pts[0][0]), _fmt(pts[0][1])) + "".join(
            " L %s %s" % (_fmt(x), _fmt(y)) for x, y in pts[1:])
        for a, b in zip(pts, pts[1:]):
            self.strokes.append((a, b, float(w) / 2.0, hook))
        return self.add(it, "path", layer, [
            ("d", d), ("fill", "none"), ("stroke", INK), ("stroke-width", w),
            ("stroke-linecap", "round"), ("stroke-linejoin", "round"),
            ("data-nl", hook), ("data-for", ref)])

    def text(self, it, x, y, t, fs, hook, ref, at=None, anchor="middle"):
        attrs = [("x", _fmt(x)), ("y", _fmt(y)),
                 ("font-family", self.st["font_family"]),
                 ("font-size", _fmt(fs)), ("text-anchor", anchor),
                 ("fill", INK), ("data-nl", hook), ("data-for", ref)]
        if at is not None:
            attrs.append(("data-at", str(at)))
        return self.add(it, "text", "labels", attrs, t)

    def put_label(self, it, lab, left, top):
        """Draw a label with its box at (left, top); returns the box."""
        for hook, t, dx, dy in lab.runs:
            self.text(it, left + dx, top + dy, t, lab.fs, hook, lab.ref,
                      lab.at)
        for hook, x0, x1, dy in lab.bars:
            self.line(it, "labels", (left + x0, top + dy),
                      (left + x1, top + dy), W_TICK, hook, lab.ref, lab.at)
        box = (left, top, left + lab.w, top + lab.h)
        self.boxes.append((box, lab.ref))
        return box

    # -------------------------------------------------------------- draw --
    def build(self):
        st = self.st
        r = float(st["point_radius"])
        self.r = r
        # the axis and its ticks, in the frame; the canvas origin is fixed
        # after the bands above / below are known: place provisionally at 0
        self.Y0 = self.X0 = self.Ybase = 0.0
        self.plan_places()
        self.plan_jumps()
        top = self.band_above()
        below = self.band_below()
        m = st["margin"]
        if not self.vert:
            self.Y0 = m + top
            self.H = self.Y0 + below + m
        else:
            self.X0 = m + below
            self.W = self.X0 + top + m
            self.Ybase = self.Hlen
            self.H = self.Hlen
        self.draw_axis()
        self.draw_intervals()
        self.draw_jumps()
        self.draw_places()
        self.draw_numbers()
        self.draw_captions()
        self.draw_spans()
        self.draw_names()
        self.draw_axis_name()
        self.draw_unmarked()
        self.canvas_check()

    # bands (frame units across the line) ---------------------------------
    def plan_places(self):
        self.ivl_end = {}                    # place -> "open" | "closed"
        for e in self.shown:
            ent = self.ix.entities.get(e) or {}
            if ent.get("kind") != "interval":
                continue
            for end, inn in ((ent["lo"], ent["lo_in"]),
                             (ent["hi"], ent["hi_in"])):
                kind = "closed" if inn else "open"
                if self.ivl_end.get(end, kind) != kind:
                    self.issue("RENDER_CONFLICT", end, "%s is an open end of "
                               "one interval and a closed end of another"
                               % end)
                self.ivl_end[end] = kind
        self.captions = []                   # (fact, place, parts)
        self.mark_by_frame = {}
        for f in self.draws:
            rel, args = f.get("rel"), f.get("args") or []
            if rel == "coordinate" and f.get("value") is not None and \
                    args[:1] and args[0] in self.index:
                k = self.index[args[0]]
                if k.denominator == 1 and int(k) in dict(self.labels) and \
                        Fraction(dict(self.labels)[int(k)]) == \
                        Fraction(f["value"]):
                    # the frame prints that value at that tick already
                    self.mark_by_frame[f["id"]] = int(k)
                    continue
                self.captions.append((f, args[0], number_parts(
                    f["value"], f.get("form"))))
            elif rel == "mark" and args and args[0] in self.index:
                e = self.ix.entities[args[0]]
                k = self.index[args[0]]
                if k.denominator == 1 and int(k) in dict(self.labels) and \
                        Fraction(dict(self.labels)[int(k)]) == \
                        Fraction(e["value"]):
                    self.mark_by_frame[f["id"]] = int(k)
                    continue
                self.captions.append((f, args[0], number_parts(
                    e["value"], e.get("form"))))

    def plan_jumps(self):
        self.jumps = []
        for e in self.shown:
            ent = self.ix.entities.get(e) or {}
            if ent.get("kind") == "jump":
                a, b = ent["from"], ent["to"]
                if a in self.index and b in self.index:
                    self.jumps.append((e, a, b))
        self.jump_caption = {}
        for f in self.draws:
            if f.get("rel") == "jump_value" and f.get("value") is not None:
                self.jump_caption[f["args"][0]] = f

    def band_above(self):
        """How far above the line (frame n) the drawing may reach: letters,
        arcs, their captions and brackets. Worst case, refined when drawn."""
        ns = self.st["name_size"]
        base = self.r + 3.0 + 0.72 * ns + 8.0 + 2.0
        h = 0.0
        for e, a, b in self.jumps:
            span = abs(self.S(self.index[b]) - self.S(self.index[a]))
            h = max(h, min(ARC_MAX, max(ARC_MIN, ARC_PREF * span)))
        extra = (ARC_STEP * len(self.jumps)) if len(self.jumps) > 1 else 0.0
        capt = (0.72 * self.st["number_size"] + 0.22 *
                self.st["number_size"] + 3.0) if self.jump_caption else 0.0
        spans = 0.0
        if any(f.get("rel") in ("distance", "abs_value") for f in self.draws):
            spans = 6.0 + self.st["number_size"] + 4.0
        self.jump_band = h + extra + capt + self.r + 2.0
        if self.bands is not None:
            return self.bands[0]
        return max(base, self.jump_band + 0.72 * ns + 4.0) + spans + 2.0

    def band_below(self):
        fs = self.st["number_size"]
        h = TICK_MAJOR_HALF + NUM_GAP
        rows = max([l.h if not self.vert else l.w
                    for l in self.num_labels.values()] + [0.0])
        cap = 0.0
        for f, p, parts in self.captions:
            lab = _Label("val", f["id"], parts, fs)
            cap = max(cap, lab.h if not self.vert else lab.w)
        # a caption row below the numbers when it would crowd them
        self.row2 = h + rows + LABEL_GAP
        if self.bands is not None:
            return self.bands[1]
        return max(h + rows, self.row2 + cap if cap else 0.0,
                   self.r + 2.0) + 1.0

    def extents(self):
        """(above, below): how far the drawn ink reaches across the line
        (label boxes and strokes), measured after a first build."""
        ns = []
        for bx, _r in self.boxes:
            for p in ((bx[0], bx[1]), (bx[2], bx[3])):
                ns.append(self._across(p))
        for a, b, hw, _w in self.strokes:
            for p in (a, b):
                ns.append(self._across(p) + hw)
                ns.append(self._across(p) - hw)
        for c in self.dots.values():
            ns += [self.r, -self.r]
        return max(ns + [0.0]), -min(ns + [0.0])

    def _across(self, p):
        return (self.Y0 - p[1]) if not self.vert else (p[0] - self.X0)

    # the axis ---------------------------------------------------------------
    def draw_axis(self):
        it = self.item("axis_line", {"entity": self.axis})
        a = self.P(self.S(0) - PAD, 0)
        b = self.P(self.S(self.n) + PAD, 0)
        self.line(it, "lines", a, b, W_AXIS, "axis", self.axis)
        tip = self.S(self.n) + PAD + HEAD_L
        ah = self.item("axis_arrow", {"entity": self.axis})
        self.poly(ah, "marks", [self.P(tip, 0),
                                self.P(self.S(self.n) + PAD, HEAD_HW),
                                self.P(self.S(self.n) + PAD, -HEAD_HW)],
                  "arrow", self.axis)
        self.tick_el = {}
        printed = set(k for k, _v in self.labels)
        for k in range(self.n + 1):
            half = TICK_MAJOR_HALF if k in printed else TICK_MINOR_HALF
            ti = self.item("tick", {"entity": self.axis, "at": k})
            self.tick_el[k] = self.line(ti, "lines", self.P(self.S(k), half),
                                        self.P(self.S(k), -half), W_TICK,
                                        "tick", self.axis, at=k)

    def draw_numbers(self):
        self.num_item = {}
        for k in sorted(self.num_labels):
            lab = self.num_labels[k]
            it = self.item("tick_number", {"entity": self.axis, "at": k},
                           text=parts_text(lab.parts))
            if not self.vert:
                left = self.S(k) - lab.centre_dx()
                top = self.Y0 + TICK_MAJOR_HALF + NUM_GAP
            else:
                left = self.X0 - TICK_MAJOR_HALF - NUM_GAP - lab.w
                top = self.Ybase - self.S(k) - lab.h / 2.0
            self.put_label(it, lab, left, top)
            self.num_item[k] = it

    # places --------------------------------------------------------------
    def draw_places(self):
        self.place_el = {}
        for p in self.places:
            s = self.S(self.index[p])
            c = self.P(s, 0)
            self.dots[p] = c
            if self.ivl_end.get(p) == "open":
                it = self.item("open_end", {"entity": p})
                pts = [(c[0] + self.r * math.cos(2 * math.pi * i / RING_N),
                        c[1] + self.r * math.sin(2 * math.pi * i / RING_N))
                       for i in range(RING_N)]
                self.place_el[p] = self.poly(it, "points", pts, "ring", p,
                                             fill=PAPER, stroke=W_AXIS)
            else:
                it = self.item("dot", {"entity": p})
                self.place_el[p] = self.add(it, "circle", "points", [
                    ("cx", _fmt(c[0])), ("cy", _fmt(c[1])),
                    ("r", _fmt(self.r)), ("fill", INK), ("data-nl", "pt"),
                    ("data-for", p)])

    def draw_intervals(self):
        self.ivl_el = {}
        for e in self.shown:
            ent = self.ix.entities.get(e) or {}
            if ent.get("kind") != "interval":
                continue
            lo, hi = ent["lo"], ent["hi"]
            if lo not in self.index or hi not in self.index:
                continue
            s0, s1 = self.S(self.index[lo]), self.S(self.index[hi])
            if s0 >= s1:
                self.issue("RENDER_CONFLICT", e, "lo is not below hi")
                continue
            a = s0 + (self.r if not ent["lo_in"] else 0.0)
            b = s1 - (self.r if not ent["hi_in"] else 0.0)
            it = self.item("interval_bar", {"entity": e})
            self.ivl_el[e] = self.line(it, "lines", self.P(a, 0),
                                       self.P(b, 0), W_BAR, "ivl", e)

    # jumps ----------------------------------------------------------------
    def draw_jumps(self):
        self.jump_els = {}
        self.jump_polys = []
        n0 = self.r + 0.8
        order = sorted(self.jumps, key=lambda j: (
            abs(self.index[j[2]] - self.index[j[1]]), j[0]))
        for e, a, b in order:
            sa, sb = self.S(self.index[a]), self.S(self.index[b])
            span = abs(sb - sa)
            if span < 1e-6:
                self.issue("RENDER_CONFLICT", e, "a jump of length 0")
                continue
            h = min(ARC_MAX, max(ARC_MIN, ARC_PREF * span))
            chosen = None
            while h <= ARC_TOP:
                pts = self._arc_pts(sa, sb, h, n0)
                if self._arc_clear(pts, sa, sb):
                    chosen = (h, pts)
                    break
                h += ARC_STEP
            if chosen is None:
                self.issue("RENDER_JUMP_NO_PLACE", e, "no height up to %.0f px "
                           "keeps the arc clear of the other arcs" % ARC_TOP)
                h = min(ARC_MAX, max(ARC_MIN, ARC_PREF * span))
                chosen = (h, self._arc_pts(sa, sb, h, n0))
            h, pts = chosen
            self.jump_polys.append((e, pts, sa, sb, h))
            # the head: tip at the end value, base on the arc hl back
            hl = min(HEAD_L, 0.4 * span)
            body = self._arc_pts(sa, sb, h, n0, cut=hl)
            base = body[-1]
            tip = (sb, n0)
            ux, un = tip[0] - base[0], tip[1] - base[1]
            L = math.hypot(ux, un) or 1.0
            k = HEAD_HW * hl / HEAD_L
            px, pn = -un / L * k, ux / L * k
            it = self.item("jump_arc", {"entity": e})
            arc_el = self.path(it, "marks", [self.P(*q) for q in body],
                               "jump", e, W_JUMP)
            ih = self.item("jump_head", {"entity": e})
            head_el = self.poly(ih, "marks", [
                self.P(*tip), self.P(base[0] + px, base[1] + pn),
                self.P(base[0] - px, base[1] - pn)], "jump-head", e)
            self.jump_els[e] = {"arc": arc_el, "head": head_el, "h": h,
                                "apex": ((sa + sb) / 2.0, n0 + h)}

    def _arc_geom(self, sa, sb, h, n0):
        """(mx, cn, R, t0, t1): the circle of an arc from sa to sb bulging
        to +n by h over the chord at height n0, and its end angles (the
        arc runs from t0 to t1 through t = pi/2, its top)."""
        c = abs(sb - sa) / 2.0
        R = (c * c + h * h) / (2.0 * h)
        mx = (sa + sb) / 2.0
        cn = n0 + h - R
        tr = math.atan2(n0 - cn, c)             # the right end, (-pi/2, pi/2]
        tl = math.atan2(n0 - cn, -c)            # the left end
        if tl < 0:
            tl += 2 * math.pi                   # (pi/2, 3pi/2)
        t0, t1 = (tl, tr) if sa < sb else (tr, tl)
        return mx, cn, R, t0, t1

    def _arc_pts(self, sa, sb, h, n0, cut=0.0):
        """Samples (frame s, n) of that arc; cut: stop this arc length
        before the end (where a head's base is)."""
        mx, cn, R, t0, t1 = self._arc_geom(sa, sb, h, n0)
        te = t1 - math.copysign(cut / R, t1 - t0)
        steps = 32
        out = [(mx + R * math.cos(t0 + (te - t0) * i / float(steps)),
                cn + R * math.sin(t0 + (te - t0) * i / float(steps)))
               for i in range(steps + 1)]
        out[0] = (sa, n0)
        if cut == 0.0:
            out[-1] = (sb, n0)
        return out

    def _arc_clear(self, pts, sa, sb):
        for _e, other, oa, ob, _h in self.jump_polys:
            shared = [s for s in (sa, sb) if abs(s - oa) < 0.01 or
                      abs(s - ob) < 0.01]
            for p, q in zip(pts, pts[1:]):
                for c, d in zip(other, other[1:]):
                    if any(abs(x[0] - s) < ARC_SHARE for s in shared
                           for x in (p, q, c, d)):
                        continue
                    if _seg_seg_d(p, q, c, d) < ARC_APART:
                        return False
        return True

    # captions --------------------------------------------------------------
    def _free(self, box, own=None, clear=STROKE_CLEAR, skip=()):
        for a, b, hw, what in self.strokes:
            if what in skip:
                continue
            if _seg_box_d(a, b, box) < hw + clear:
                return False
        for p, c in self.dots.items():
            if _pt_box_d(c, box) < self.r + clear:
                return False
        for bx, _ref in self.boxes:
            if _box_gap(bx, box) < LABEL_GAP:
                return False
        return True

    def _owned(self, box, place):
        mine = _pt_box_d(self.dots[place], box)
        if mine > NAME_NEAR:
            return False
        return all(_pt_box_d(c, box) > mine + OWN_MARGIN
                   for p, c in self.dots.items() if p != place and
                   math.hypot(c[0] - self.dots[place][0],
                              c[1] - self.dots[place][1]) > 0.01)

    def draw_captions(self):
        fs = self.st["number_size"]
        for f, p, parts in sorted(self.captions, key=lambda x: x[0]["id"]):
            lab = _Label("val", f["id"], parts, fs)
            it = self.item("value_caption", {"fact": f["id"], "entity": p},
                           text=parts_text(parts))
            s = self.S(self.index[p])
            cands = []
            if not self.vert:
                for top in (self.Y0 + TICK_MAJOR_HALF + NUM_GAP,
                            self.Y0 + self.row2):
                    for dx in (0.0, -2.0, 2.0, -4.0, 4.0):
                        cands.append((s - lab.centre_dx() + dx, top))
            else:
                for right in (self.X0 - TICK_MAJOR_HALF - NUM_GAP,
                              self.X0 - self.row2):
                    for dy in (0.0, -2.0, 2.0, -4.0, 4.0):
                        cands.append((right - lab.w, self.Ybase - s -
                                      lab.h / 2.0 + dy))
            placed = False
            for left, top in cands:
                box = (left, top, left + lab.w, top + lab.h)
                if self._free(box, skip=("ivl",)) and self._owned(box, p):
                    self.put_label(it, lab, left, top)
                    placed = True
                    break
            if not placed:
                self.issue("RENDER_LABEL_NO_PLACE", f["id"], "the value of %s "
                           "has no free place under its dot" % p)
                left, top = cands[0]
                self.put_label(it, lab, left, top)

    def draw_names(self):
        ns = self.st["name_size"]
        named = {}
        for f in self.draws:
            if f.get("rel") == "name" and f.get("args", [None])[0] in \
                    self.index:
                named[f["args"][0]] = f
        for p in self.places:
            if self.ix.kind(p) != "point":
                continue
            name = (self.ix.entities.get(p) or {}).get("name") or p
            src = {"entity": p}
            if p in named:
                src["fact"] = named[p]["id"]
            it = self.item("point_name", src, text=name)
            w, h = _adv(name, ns), 0.72 * ns
            c = self.dots[p]
            cands = []
            if not self.vert:
                for lift in (0.0, 3.0, 6.0, 9.0):
                    for dx in (0.0, -(w / 2 + self.r * 0.6),
                               (w / 2 + self.r * 0.6), -(w / 2 + self.r + 2),
                               (w / 2 + self.r + 2)):
                        bottom = c[1] - self.r - 2.5 - lift
                        cands.append((c[0] - w / 2 + dx, bottom - h))
                for top in (self.Y0 + self.row2 + 12.0,):
                    cands.append((c[0] - w / 2, top))
            else:
                for push in (0.0, 3.0, 6.0, 9.0):
                    for dy in (0.0, -(h / 2 + self.r * 0.6),
                               (h / 2 + self.r * 0.6), -(h / 2 + self.r + 2),
                               (h / 2 + self.r + 2)):
                        cands.append((c[0] + self.r + 2.5 + push,
                                      c[1] - h / 2 + dy))
            placed = False
            for left, top in cands:
                box = (left, top, left + w, top + h)
                if self._free(box) and self._owned(box, p):
                    placed = True
                    break
            if not placed:
                self.issue("RENDER_LABEL_NO_PLACE", p, "the letter %s has no "
                           "free place beside its dot" % name)
                left, top = cands[0]
            self.text(it, left + w / 2.0, top + h, name, ns, "name", p)
            self.boxes.append(((left, top, left + w, top + h), p))

    def draw_spans(self):
        fs = self.st["number_size"]
        # jump captions over their apex
        for e, _pts, sa, sb, h in self.jump_polys:
            f = self.jump_caption.get(e)
            if f is None:
                continue
            parts = number_parts(f["value"], f.get("form"), signed=True)
            lab = _Label("jump-val", f["id"], parts, fs)
            it = self.item("jump_caption", {"fact": f["id"], "entity": e},
                           text=parts_text(parts))
            ap = self.jump_els[e]["apex"]
            placed = None
            for lift in (1.5, 3.0, 5.0, 8.0):
                if not self.vert:
                    p = self.P(ap[0], ap[1] + lift)
                    left, top = p[0] - lab.w / 2.0, p[1] - lab.h
                else:
                    p = self.P(ap[0], ap[1] + lift)
                    left, top = p[0], p[1] - lab.h / 2.0
                box = (left, top, left + lab.w, top + lab.h)
                if self._free(box):
                    placed = (left, top)
                    break
            if placed is None:
                self.issue("RENDER_LABEL_NO_PLACE", f["id"], "the size of %s "
                           "has no free place over its arc" % e)
                placed = (left, top)
            self.put_label(it, lab, placed[0], placed[1])
        # brackets of drawn given distances / absolute values
        top_n = max([self.r + 3.0 + 0.72 * self.st["name_size"] + 9.0] +
                    [h + self.r + 0.8 + 2.0 + (fs + 2.0 if e in
                                               self.jump_caption else 0.0)
                     for e, _p, _a, _b, h in self.jump_polys])
        for f in self.draws:
            rel, args = f.get("rel"), f.get("args") or []
            if rel not in ("distance", "abs_value") or f.get("value") is None:
                continue
            ends = list(args) if rel == "distance" else [None, args[0]]
            ks = []
            for x in ends:
                if x is None:
                    k0 = self.index_of(0)
                    ks.append(k0)
                else:
                    ks.append(self.index.get(x))
            if None in ks or not all(0 <= k <= self.n for k in ks):
                self.issue("RENDER_FACT_NOT_MARKED", f["id"], "its ends are "
                           "not placed on the line")
                continue
            s0, s1 = sorted(self.S(k) for k in ks)
            n1, n2 = top_n, top_n + 4.0
            it = self.item("span_bracket", {"fact": f["id"]})
            self.path(it, "marks", [self.P(s0, n1), self.P(s0, n2),
                                    self.P(s1, n2), self.P(s1, n1)],
                      "span", f["id"], W_TICK)
            parts = number_parts(f["value"], f.get("form"))
            lab = _Label("span-val", f["id"], parts, fs)
            ic = self.item("span_caption", {"fact": f["id"]},
                           text=parts_text(parts))
            p = self.P((s0 + s1) / 2.0, n2 + 1.5)
            if not self.vert:
                left, top = p[0] - lab.w / 2.0, p[1] - lab.h
            else:
                left, top = p[0], p[1] - lab.h / 2.0
            box = (left, top, left + lab.w, top + lab.h)
            if not self._free(box):
                self.issue("RENDER_LABEL_NO_PLACE", f["id"], "the bracket's "
                           "value has no free place")
            self.put_label(ic, lab, left, top)
            top_n = n2 + lab.h + 4.0

    def draw_axis_name(self):
        for f in self.draws:
            if f.get("rel") != "name" or f.get("args") != [self.axis]:
                continue
            ns = self.st["name_size"]
            name = (self.ix.entities.get(self.axis) or {}).get("name") or "x"
            it = self.item("axis_name", {"entity": self.axis,
                                         "fact": f["id"]}, text=name)
            tip = self.P(self.S(self.n) + PAD + HEAD_L, 0)
            w = _adv(name, ns)
            if not self.vert:
                left, top = tip[0] + 2.0, tip[1] - 0.36 * ns
            else:
                left, top = tip[0] - w / 2.0, tip[1] - 2.0 - 0.72 * ns
            self.text(it, left + w / 2.0, top + 0.72 * ns, name, ns,
                      "axis-name", self.axis)
            self.boxes.append(((left, top, left + w, top + 0.72 * ns),
                               self.axis))

    def draw_unmarked(self):
        for f in self.draws:
            rel = f.get("rel")
            args = f.get("args") or []
            if rel in MARKED_RELS:
                if rel == "coordinate" and (f.get("value") is None or
                                            args[:1][0] not in self.index):
                    self.issue("RENDER_FACT_NOT_MARKED", f["id"], "a drawn "
                               "coordinate needs its value and its point")
                if rel == "jump_value" and args and args[0] not in [
                        j[0] for j in self.jumps]:
                    self.issue("RENDER_FACT_NOT_MARKED", f["id"], "its jump "
                               "is not drawn")
                continue
            if rel == "tick":
                continue
            self.issue("RENDER_FACT_NOT_MARKED", f["id"], "%s is not marked "
                       "on a number line" % rel)

    def canvas_check(self):
        W, H = self.W, self.H
        for bx, ref in self.boxes:
            if bx[0] < 0.5 or bx[1] < 0.5 or bx[2] > W - 0.5 or \
                    bx[3] > H - 0.5:
                self.issue("RENDER_LABEL_CUT", ref, "a label box %s reaches "
                           "past the canvas %sx%s" % (
                               [round(v, 1) for v in bx], round(W, 1),
                               round(H, 1)))
        for a, b, hw, what in self.strokes:
            for p in (a, b):
                if p[0] < 0 or p[1] < 0 or p[0] > W or p[1] > H:
                    self.issue("RENDER_INK_CUT", what, "a stroke reaches "
                               "past the canvas")
                    break

    # --------------------------------------------------------------- out --
    def number(self):
        order = [el for layer in LAYERS for el in self.els
                 if el.layer == layer]
        for k, el in enumerate(order):
            el.id = "e%04d" % (k + 1)
        self.order = order

    def svg(self):
        W, H = _fmt(self.W), _fmt(self.H)
        out = ['<?xml version="1.0" encoding="UTF-8"?>',
               '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %s %s" '
               'width="%s" height="%s">' % (W, H, W, H)]
        for layer in LAYERS:
            els = [el for el in self.order if el.layer == layer]
            if not els:
                continue
            out.append('<g data-layer="%s">' % layer)
            for el in els:
                attrs = " ".join('%s="%s"' % (k, _esc(v)) for k, v in
                                 [("id", el.id)] + el.attrs)
                if el.tag == "text":
                    out.append("<text %s>%s</text>" % (attrs, _esc(el.text)))
                else:
                    out.append("<%s %s/>" % (el.tag, attrs))
            out.append("</g>")
        out.append("</svg>")
        return "\n".join(out) + "\n"

    def object_map(self, public_hash, settings_hash):
        elements = dict((el.id, {"tag": el.tag, "item": el.item.id})
                        for el in self.order)
        items = []
        for it in self.items:
            if not it.els:
                continue
            d = {"id": it.id, "role": it.role, "source": it.source,
                 "elements": sorted(el.id for el in it.els)}
            if it.text is not None:
                # the item's text is its element's own text; a number drawn
                # in runs (a stacked fraction) carries its logical value
                # as "value" instead (G79 reads text per element)
                if sum(1 for el in it.els if el.tag == "text") == 1:
                    d["text"] = it.text
                else:
                    d["value"] = it.text
            items.append(d)
        objs = {}

        def parts(els):
            return [{"element": e.id, "span": "whole"}
                    for e in sorted(els, key=lambda e: e.id)]
        by_item = dict((it.id, it) for it in self.items)
        # the axis: line, arrow, ticks, printed numbers
        ax = [el for el in self.order if el.item.role in (
            "axis_line", "axis_arrow", "tick", "tick_number", "axis_name")]
        objs[self.axis] = {"kind": "axis", "parts": parts(ax)}
        for p in self.places:
            els = [el for el in self.order if el.item.source.get("entity") ==
                   p and el.item.role in ("dot", "open_end", "point_name",
                                          "value_caption")]
            kind = self.ix.kind(p)
            for fid, kk in sorted(self.mark_by_frame.items()):
                if self.ix.facts[fid]["args"][0] == p:
                    els += self.num_item[kk].els
            objs[p] = {"kind": kind, "parts": parts(els)}
        # numbers the frame prints (a public number entity at a printed tick)
        vals = dict((Fraction(v), k) for k, v in self.labels)
        for e in sorted(self.ix.entities):
            ent = self.ix.entities[e]
            if ent.get("kind") != "number" or e in objs:
                continue
            v = _q(ent.get("value"))
            if v is not None and v in vals:
                k = vals[v]
                objs[e] = {"kind": "number", "parts": parts(
                    [self.tick_el[k]] + self.num_item[k].els)}
        for e, d in sorted(self.jump_els.items()):
            els = [d["arc"], d["head"]] + [
                el for el in self.order if el.item.role == "jump_caption" and
                el.item.source.get("entity") == e]
            objs[e] = {"kind": "jump", "parts": parts(els)}
        for e, el in sorted(self.ivl_el.items()):
            ent = self.ix.entities[e]
            els = [el] + [self.place_el[x] for x in (ent["lo"], ent["hi"])
                          if x in self.place_el]
            objs[e] = {"kind": "interval", "parts": parts(els)}
        for e in self.shown:
            ent = self.ix.entities.get(e) or {}
            if ent.get("kind") == "tick":
                k = self.index_of(ent.get("at"))
                if k is not None and k.denominator == 1 and \
                        0 <= k <= self.n:
                    els = [self.tick_el[int(k)]] + (
                        self.num_item[int(k)].els if int(k) in self.num_item
                        else [])
                    objs[e] = {"kind": "tick", "parts": parts(els)}
        # spans: family facts of the figure's question between two drawn
        # places (the highlight traces the line between them); a bracket
        # of a drawn given is its own ink
        axis_el = [el for el in self.order if el.item.role == "axis_line"][0]
        for f in sorted(self.ix.facts.values(), key=lambda f: f["id"]):
            if self.ix.scope_question.get(f.get("item")) != self.qid:
                continue
            rel, args = f.get("rel"), f.get("args") or []
            if rel == "distance":
                ends = list(args)
            elif rel == "abs_value":
                ends = ["0", args[0]] if args else []
            elif rel in ("jump_value",) and args and args[0] in \
                    self.jump_els:
                ent = self.ix.entities[args[0]]
                ends = [ent["from"], ent["to"]]
            elif rel == "count_integers" and args:
                ent = self.ix.entities.get(args[0]) or {}
                ends = [ent.get("lo"), ent.get("hi")]
            else:
                continue
            ok = all((x == "0" and self.index_of(0) is not None and
                      0 <= self.index_of(0) <= self.n) or x in self.index
                     for x in ends)
            if len(ends) != 2 or not ok:
                continue
            els = [el for el in self.order if el.item.source.get("fact") ==
                   f["id"] and el.item.role in ("span_bracket",
                                                "span_caption")]
            px = []
            for x in ends:
                k = self.index_of(0) if x == "0" else self.index[x]
                px.append([_r2(v) for v in self.P(self.S(k), 0)])
            ps = [{"element": axis_el.id, "span": list(ends), "px": px}] + \
                parts(els)
            objs[f["id"]] = {"kind": "span", "parts": ps}
        return {"engine": ENGINE_VERSION, "dialect": DIALECT_VERSION,
                "figure": self.fig["id"], "family": "number_line",
                "public_hash": public_hash, "settings_hash": settings_hash,
                "elements": elements, "display_items": items,
                "objects": objs}

    def placements(self):
        pts = dict((p, [_r2(c[0]), _r2(c[1])]) for p, c in self.dots.items())
        ticks = dict((str(k), [_r2(v) for v in self.P(self.S(k), 0)])
                     for k in range(self.n + 1))
        # model -> svg (X = a x + e, Y = d y + f): the VALUE on the model's
        # x (horizontal) / y (vertical) when two printed numbers fix the
        # scale, else the tick index (model "tick_index")
        m = self.value_map()
        if m is not None:
            k = self.u / float(m[1])
            s00 = self.s0 - float(m[0]) * k       # along-px of value 0
            unit = "value"
        else:
            k, s00, unit = self.u, self.s0, "tick_index"
        if not self.vert:
            mat = [_r6(k), 0.0, 0.0, -1.0, _r6(s00), _r6(self.Y0)]
        else:
            mat = [1.0, 0.0, 0.0, _r6(-k), _r6(self.X0),
                   _r6(self.Ybase - s00)]
        return {"canvas_px": [_r2(self.W), _r2(self.H)],
                "model_to_svg": {"matrix": mat, "model": unit,
                                 "value_axis": "y" if self.vert else "x"},
                "orientation": self.st["orientation"],
                "points_px": pts, "ticks_px": ticks,
                "px_per_interval": _r2(self.u),
                "page": {"unit": "pt", "pt_per_px": 0.75,
                         "size_pt": [_r2(self.W * 0.75), _r2(self.H * 0.75)]}}


def _esc(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(
        ">", "&gt;").replace('"', "&quot;")


def _map_issues(svg_text, om, pub):
    import re
    ids = re.findall(r' id="(e[0-9]{4})"', svg_text)
    out = []
    if sorted(ids) != sorted(om["elements"]) or len(set(ids)) != len(ids):
        out.append({"code": "MAP_NOT_TOTAL", "where": om["figure"],
                    "detail": "file ids %d vs map %d" % (
                        len(ids), len(om["elements"]))})
    ents = set(e["id"] for e in pub["entities"])
    facts = set(f["id"] for f in pub["facts"])
    owner = {}
    for it in om["display_items"]:
        if it["role"] not in ROLES:
            out.append({"code": "MAP_BAD_ROLE", "where": it["id"],
                        "detail": it["role"]})
        src = it["source"]
        if (src.get("entity") and src["entity"] not in ents) or \
                (src.get("fact") and src["fact"] not in facts):
            out.append({"code": "MAP_BAD_SOURCE", "where": it["id"],
                        "detail": repr(src)})
        for e in it["elements"]:
            if e in owner:
                out.append({"code": "MAP_SHARED_ELEMENT", "where": e,
                            "detail": "%s and %s" % (owner[e], it["id"])})
            owner[e] = it["id"]
    return out


def render(public_spec, display_settings, engine_version=ENGINE_VERSION):
    """See the module docstring."""
    if engine_version not in (ENGINE_VERSION,):
        raise RenderRefused("RENDER_VERSION", "this engine is %s, not %r"
                            % (ENGINE_VERSION, engine_version))
    gate.require_public(public_spec)
    st = settings(display_settings)
    ix = S.Index(public_spec)
    fig = ix.figures.get(st["figure"])
    if fig is None:
        raise RenderRefused("RENDER_BAD_SETTINGS", "figure %r is not in the "
                            "public model" % st["figure"])
    if not is_number_line(fig):
        raise RenderRefused("RENDER_BAD_SETTINGS", "figure %s has no "
                            "number_line frame" % fig["id"])
    length = st["width"] if st["orientation"] == "horizontal" else \
        st["height"]
    b = None
    for g in GROW_STEPS:
        b = _Build(public_spec, ix, fig, st, length)
        b.frame_geometry(g)
        b.place_all()
        for code, where, detail in b.dense_problems():
            b.issue(code, where, detail)
        if b.vert:
            b.W = 0.0
        b.build()
        # second pass: the bands across the line are what the first pass
        # drew (nothing cut at the canvas edge, no empty strip)
        above, below = b.extents()
        # v6.12 fix_r1 (NS13 NS23 NS40, RENDER_LABEL_CUT): with the tighter
        # bands of the second pass a caption can take the second row under
        # the numbers, which the first pass never drew -- so the bands are
        # re-measured until they hold what the pass drew (never shrinking;
        # at most three passes, deterministic)
        bands = (above + 1.0, below + 1.0)
        for _pass in range(3):
            b2 = _Build(public_spec, ix, fig, st, length)
            b2.bands = bands
            b2.frame_geometry(g)
            b2.place_all()
            for code, where, detail in b2.dense_problems():
                b2.issue(code, where, detail)
            if b2.vert:
                b2.W = 0.0
            b2.build()
            a2, w2 = b2.extents()
            if a2 + 1.0 <= bands[0] + 1e-6 and w2 + 1.0 <= bands[1] + 1e-6:
                break
            bands = (max(bands[0], a2 + 1.0), max(bands[1], w2 + 1.0))
        b = b2
        crowded = [i for i in b.issues if i["code"] in (
            "RENDER_LABEL_NO_PLACE", "RENDER_TICKS_TOO_DENSE",
            "RENDER_JUMP_NO_PLACE")]
        if not crowded or not st["grow"]:
            break
    b.number()
    svg = b.svg()
    sh = hashlib.sha256(canon.dumps(st).encode("utf-8")).hexdigest()
    om = b.object_map(public_spec["public_hash"], sh)
    issues = sorted(b.issues + _map_issues(svg, om, public_spec),
                    key=lambda i: (i["code"], i["where"], i["detail"]))
    validation = {"engine": ENGINE_VERSION, "figure": fig["id"],
                  "status": "PASS" if not issues else "FAIL",
                  "issues": issues,
                  "checked": ["gate: public model only", "settings closed",
                              "places by public values / layout, on the line",
                              "labels never dropped, inside the canvas, "
                              "clear of every stroke and dot",
                              "arcs apart", "object map total"],
                  "svg_sha256": hashlib.sha256(svg.encode("utf-8"))
                  .hexdigest()}
    pl = b.placements()
    pl["asked_px"] = length
    pl["grown"] = (b.W if not b.vert else b.Hlen) != length
    return {"svg": svg, "object_map": om, "placements": pl,
            "validation": validation}


def dumps(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, indent=1) + \
        "\n"
