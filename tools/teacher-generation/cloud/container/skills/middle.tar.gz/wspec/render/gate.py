# -*- coding: utf-8 -*-
"""What the renderer accepts: ONLY a validated public model
(project.public_model output) and closed display settings.

A public model is recognised by what it IS, not by a flag it carries:
  * exactly the top-level keys of project.PUBLIC_KEYS["top"];
  * project.scan_public() finds nothing (every key whitelisted, every
    value in its grammar, no answer fact, no value on a target);
  * its public_hash is the sha256 of its own canonical content, so an
    edited model (an answer put back in, a fact added) is refused.
The private model, the full spec or an answer store fails the first test
(other keys) and is refused with RENDER_NOT_PUBLIC before anything is
drawn. The display settings are a closed dict too (RENDER_BAD_SETTINGS):
nothing in them is mathematics beyond where the points go."""
import hashlib
import math
import numbers

from .. import canon
from .. import project as P


class RenderRefused(Exception):
    def __init__(self, code, detail):
        Exception.__init__(self, "%s: %s" % (code, detail))
        self.code = code
        self.detail = detail


def require_public(pub):
    if not isinstance(pub, dict):
        raise RenderRefused("RENDER_NOT_PUBLIC", "not a dict")
    keys = set(pub)
    want = P.PUBLIC_KEYS["top"]
    if keys != want:
        raise RenderRefused("RENDER_NOT_PUBLIC", "top-level keys %s are not "
                            "the public model's %s (a private model, a spec "
                            "or an answer store is refused)" % (
                                sorted(keys ^ want), sorted(want)))
    bad = P.scan_public(pub)
    if bad:
        raise RenderRefused("RENDER_NOT_PUBLIC", "scan_public: %s" % "; ".join(
            str(i) for i in bad[:5]))
    body = dict((k, v) for k, v in pub.items() if k != "public_hash")
    h = hashlib.sha256(canon.dumps(body).encode("utf-8")).hexdigest()
    if h != pub.get("public_hash"):
        raise RenderRefused("RENDER_NOT_PUBLIC", "public_hash does not match "
                            "the content (the model was edited after "
                            "project.public_model built it)")


# display settings: key -> (type check, default)
def _pos(v):
    return isinstance(v, numbers.Real) and not isinstance(v, bool) and \
        math.isfinite(v) and v > 0


SETTINGS = {
    "figure": (lambda v: isinstance(v, str), None),
    "layout": (lambda v: isinstance(v, list), None),
    "width": (lambda v: _pos(v) and 60 <= v <= 1200, 280),
    "height": (lambda v: v is None or (_pos(v) and 60 <= v <= 1200), None),
    "margin": (lambda v: _pos(v) and 16 <= v <= 80, 26),
    # v6.9: 'David Libre,serif' is the skill's print face (a figure printed
    # on a worksheet must name it: gate G70; CSS never reaches SVG text)
    "font_family": (lambda v: v in ("serif", "sans-serif",
                                    "David Libre,serif"), "serif"),
    # v6.9: 12.67 / 10.67 px are the worksheet's letter (9.5 pt) and number
    # (8 pt) sizes -- an engine figure beside builder figures prints the
    # sheet's one look (gate G78)
    "name_size": (lambda v: v in (12, 12.67, 14, 16), 14),
    "value_size": (lambda v: v in (10.67, 12, 14, 16), 12),
    "point_radius": (lambda v: v in (1.5, 2, 2.5), 2),
    "arc_radius": (lambda v: _pos(v) and 10 <= v <= 30, 16),
    "segment_captions_with_unit": (lambda v: isinstance(v, bool), False),
    "grow": (lambda v: isinstance(v, bool), True),
    "dashed": (lambda v: isinstance(v, list) and all(
        isinstance(x, str) for x in v), []),
    # v6.9 fix r1 (P4): 'thin' draws the INNER segments (drawn points on
    # both sides of the line: diagonals, cevians, midsegments) at the
    # dialect's thin width, the outline stays normal -- the builder's look,
    # so a sheet mixing both prints one look (gate G78). Absent = normal
    # (the settings of a figure that does not name it are unchanged).
    "inner_stroke": (lambda v: v in ("normal", "thin"), None),
    # v6.9 fix r2 (P4): 'corner' prints a point that is a CORNER of the
    # drawn strokes (>= 2 solid normal strokes end there at an angle, none
    # passes through: a polygon's vertex) with the corner dot r=0.75, hidden
    # in the join -- the builder's look (no dot on a vertex); every other
    # point keeps point_radius. Absent = every dot at point_radius (the
    # settings of a figure that does not name it are unchanged).
    "vertex_dots": (lambda v: v in ("dot", "corner"), None),
}
OPTIONAL_NOT_DEFAULTED = ("inner_stroke", "vertex_dots")
REQUIRED = ("figure", "layout")


def settings(ds):
    if not isinstance(ds, dict):
        raise RenderRefused("RENDER_BAD_SETTINGS", "not a dict")
    extra = sorted(set(ds) - set(SETTINGS))
    if extra:
        raise RenderRefused("RENDER_BAD_SETTINGS", "unknown key(s) %s (closed "
                            "list: %s)" % (extra, sorted(SETTINGS)))
    out = {}
    for k, (ok, dflt) in sorted(SETTINGS.items()):
        if k not in ds:
            if k in OPTIONAL_NOT_DEFAULTED:
                continue
            if k in REQUIRED:
                raise RenderRefused("RENDER_BAD_SETTINGS", "%s missing" % k)
            out[k] = list(dflt) if isinstance(dflt, list) else dflt
            continue
        if not ok(ds[k]):
            raise RenderRefused("RENDER_BAD_SETTINGS", "%s=%r" % (k, ds[k]))
        out[k] = ds[k]
    return out
