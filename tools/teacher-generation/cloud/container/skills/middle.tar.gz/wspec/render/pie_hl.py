# -*- coding: utf-8 -*-
"""highlight(svg, object_map, object_id) for a PIE CHART figure (v6.16).

The figure's bytes are kept: ONE group
    <g data-layer="highlight" data-object="<object id>"> ... </g>
is inserted right BEFORE the labels layer (<g data-layer="labels">; at the
end of the file when there is none): a wedge is a filled area, so an
overlay under the figure would be hidden -- this one lies on the wedges and
under every label, which stays readable. It holds one element per PART of
the object in the object map, nothing else:
  a wedge path    -> the same path, highlight fill at 0.45 opacity + a 3 px
                     highlight stroke (data-hl="<element id>");
  a circle        -> outline / build circle: the same circle, a 5 px
                     highlight stroke, fill none; a centre dot: a disk r+3;
  a leader path   -> the same path, a 5 px highlight stroke;
  a swatch        -> the same square, highlight fill + 4 px stroke;
  a text          -> a box behind its glyph box (the renderer's estimate).
No text, no hook (data-pie), no number, no angle arc, no new mark.
(v6.16 r2) object "figure" = the WHOLE figure (every element of the file:
every disc's outline, tiles, labels, leaders, legend, captions) -- the
object of a pie corpus ADDENDUM 1 scenario; it is no object-map entry.
Stdlib only."""
import re
import xml.etree.ElementTree as ET

from .pie import text_width, text_extent, _has_rtl

FIGURE_OBJECT = "figure"      # (v6.16 r2) the whole figure
HL = "#f59f00"
HL_SOFT = "#ffe8a3"
BOX_PAD = 1.5
NS = "{http://www.w3.org/2000/svg}"
_LABELS = re.compile(r'<g data-layer="labels">\n')
_END = re.compile(r"</svg>\n?$")


class HighlightError(Exception):
    pass


def _n(v):
    s = ("%.2f" % max(0.0, round(v, 2))).rstrip("0").rstrip(".")
    return s or "0"


def logical_text(el, om):
    """the element's LOGICAL text from the object map (never re-derived)"""
    eid = el.get("id")
    item = (om.get("elements") or {}).get(eid, {}).get("item")
    for it in om.get("display_items") or []:
        if it.get("id") == item:
            return it.get("text") or ""
    return el.text or ""


def text_box(el, logical):
    fs = float(el.get("font-size"))
    w = text_width(logical, fs)
    asc, desc = text_extent(logical, fs)
    x, y = float(el.get("x")), float(el.get("y"))
    anc = el.get("text-anchor")
    x0 = x - w / 2.0 if anc == "middle" else (x - w if anc == "end" else x)
    return (x0 - BOX_PAD, y - asc - BOX_PAD, x0 + w + BOX_PAD,
            y + desc + BOX_PAD)


def highlight(svg, object_map, object_id):
    obj = (object_map.get("objects") or {}).get(object_id)
    if obj is None and object_id == FIGURE_OBJECT:
        # (v6.16 r2) every element of the figure, in file order
        obj = {"parts": [{"element": e, "span": "whole"} for e in
                         sorted(object_map.get("elements") or {})]}
    if obj is None:
        raise HighlightError("object %r is not in the object map" % object_id)
    root = ET.fromstring(svg.encode("utf-8"))
    els = {}
    for el in root.iter():
        if el.get("id"):
            els[el.get("id")] = (el.tag.replace(NS, ""), el)
    out = []
    for part in obj.get("parts") or []:
        eid = part["element"]
        if eid not in els:
            raise HighlightError("part %s is not in the figure" % eid)
        if part.get("span") != "whole":
            raise HighlightError("part %s: a pie part is whole" % eid)
        tag, el = els[eid]
        hook = el.get("data-pie")
        if tag == "path" and hook == "wedge":
            out.append('<path d="%s" fill="%s" fill-opacity="0.45" '
                       'stroke="%s" stroke-width="3" stroke-linejoin="round" '
                       'data-hl="%s"/>' % (el.get("d"), HL, HL, eid))
        elif tag == "path":
            out.append('<path d="%s" fill="none" stroke="%s" '
                       'stroke-width="5" stroke-linecap="round" '
                       'stroke-linejoin="round" data-hl="%s"/>' % (
                           el.get("d"), HL, eid))
        elif tag == "circle" and hook == "bdot":
            r = float(el.get("r")) + 3.0
            out.append('<circle cx="%s" cy="%s" r="%s" fill="%s" '
                       'data-hl="%s"/>' % (el.get("cx"), el.get("cy"), _n(r),
                                           HL, eid))
        elif tag == "circle":
            out.append('<circle cx="%s" cy="%s" r="%s" fill="none" '
                       'stroke="%s" stroke-width="5" data-hl="%s"/>' % (
                           el.get("cx"), el.get("cy"), el.get("r"), HL, eid))
        elif tag == "polygon":
            out.append('<polygon points="%s" fill="%s" stroke="%s" '
                       'stroke-width="4" stroke-linejoin="round" '
                       'data-hl="%s"/>' % (el.get("points"), HL, HL, eid))
        elif tag == "text":
            b = text_box(el, logical_text(el, object_map))
            out.append('<polygon points="%s,%s %s,%s %s,%s %s,%s" fill="%s" '
                       'data-hl="%s"/>' % (
                           _n(b[0]), _n(b[1]), _n(b[2]), _n(b[1]), _n(b[2]),
                           _n(b[3]), _n(b[0]), _n(b[3]), HL_SOFT, eid))
        else:
            raise HighlightError("part %s is a %s" % (eid, tag))
    grp = '<g data-layer="highlight" data-object="%s">\n%s\n</g>\n' % (
        object_id.replace("&", "&amp;").replace("<", "&lt;").replace(
            ">", "&gt;").replace('"', "&quot;"), "\n".join(out))
    m = _LABELS.search(svg)
    at = m.start() if m else _END.search(svg).start()
    return svg[:at] + grp + svg[at:]


def verify_highlight(base_svg, hl_svg, object_map, object_id):
    """[problem]: the highlighted file must be exactly highlight()'s output
    for this object (the figure unchanged, one overlay group)."""
    try:
        want = highlight(base_svg, object_map, object_id)
    except HighlightError as e:
        return ["HL_REFUSED: %s" % e]
    return [] if want == hl_svg else ["HL_NOT_EXACT: the highlighted file "
                                      "is not the overlay of %s" % object_id]


__all__ = ["highlight", "verify_highlight", "HighlightError", "HL",
           "HL_SOFT", "_has_rtl", "FIGURE_OBJECT"]
