# -*- coding: utf-8 -*-
"""wspec.render.coord -- family A (v6.12, BRIEF_V612 section 1): the
COORDINATE PLANE, drawn from the numbers of the PUBLIC model.

    out = wspec.render.render(public_model, settings, ENGINE_VERSION)
    (engine.render hands a figure whose frame is a coordinate_plane here)
    -> {svg, object_map, placements, validation}   (the same four outputs)

INPUT: the public model only (engine.render ran gate.require_public) and
the closed display settings below. The public frame gives, per axis, the
number of intervals and the printed numbers by tick index -- never min /
max / step; the renderer derives value <-> tick index from the printed
numbers (two of them fix an axis) and draws nothing else.

display settings (closed; defaults in brackets)
  figure        the figure id (required)
  layout  [[]]  where a shown point goes when the public model does not say
                it (a point whose coordinates are read off / found):
                  {"p": NAME, "xy": [x, y]}    in coordinate values
                  {"p": NAME, "tick": [i, j]}  in intervals from the origin
                A point with public coordinates is placed by them; a layout
                entry for it must agree (else RENDER_LAYOUT).
  origin        [i, j]: tick index of 0 on x and on y -- only needed when
                the frame prints too few numbers to fix it (it must agree)
  square [13.33] px per interval (10 .. 26); the figure GROWS it (x1.15 per
                try, up to 26) when an axis number has no room -- numbers are
                never dropped; then RENDER_AXIS_CROWDED names the fix
                (label_every / a larger square)
  font_family [serif]   serif | sans-serif | David Libre,serif
  number_size [10.67]   10.67 (8 pt) | 12      name_size [12.67] 12 | 12.67 | 14
  point_radius [2.67]   2 | 2.5 | 2.67 | 3     grow [true]

HOUSE LOOK (figkit_plus.plane, the author's rules of 2026-09-16/17): grey
grid (0.35 pt) at every step when the frame has a grid, knocked out under
every text; black axes (0.8 pt) through the origin with a filled arrowhead
at the positive end and the axis letter (drawn name fact) beside it; tick
marks at the printed numbers (at every step without a grid); axis numbers
8 pt, below the x axis / left of the y axis, one '0' in the lower-left
corner of the origin, negative numbers with U+2212; a number never dropped,
never cut, never crossed by a stroke -- a colliding number moves slightly
(<= 3 px, still nearest its own tick), then the square grows, then FAIL.
Data strokes 1 pt, dots 2 pt, names 9.5 pt.

WHAT IS DRAWN: exactly the figure's shown set (family.figure_shows) plus
the marks of its drawn facts:
  name(P)                 the point's letter next to its dot
  name(axis)              the axis letter at its arrow
  coordinate(P, x|y)      both drawn: the caption '(x, y)' beside P
  guide(P, axis)          the dashed reading guide from P to that axis
                          (a stated given only -- family.FAMILY_GUIDE)
  perpendicular / angle_measure = 90   right-angle mark at the common point
  length = v              the value beside the segment
  on_segment, parallel, rectangle, square, parallelogram, rhombus,
  trapezoid, isosceles_trapezoid, right_triangle, inside   by position
  anything else           RENDER_FACT_NOT_MARKED (validation FAIL)
A point / segment / polygon the student must plot or find is never in the
shown set (family.FIGURE_SHOWS_TO_PLOT / the spec's targets).

SVG (wspec-coord-svg/1): layers grid, axes, lines, marks, points, labels;
every element numbered e0001.. in document order; ONE hook per element:
  <line data-grid="x 3">   a grid line (piece) at tick index 3 of axis x
  <line data-axis="x">     <polygon data-arrow="x">   <line data-tick="x 3">
  <text data-num="x 3">    an axis number (tick index)   data-num="origin"
  <text data-axname="x">   <circle data-pt="A">   <text data-for="A">
  <text data-for="coord A">   <text data-for="seg A B">
  <line data-seg="A B">  <line data-line="A B">  <line data-ray="A B">
  <line data-guide="A x">  <polyline data-mark="right A V B">
Hooks carry tick indices and names only -- never a value.

object_map: engine, dialect, figure, public_hash, settings_hash, elements,
display_items (roles ROLES), objects (point: dot + name + caption; segment:
its line or its span of a longer line + caption; polygon: its sides; line /
ray: its line; axis: line + arrow + letter + tick marks + numbers (the
origin '0' is in both axes); plane: the grid pieces; tick entity: its mark +
number; a drawn guide: under its fact id, kind 'guide'), construction [].

v6.16 gaps (corpus-v2 OPEN_ENGINE_GAP G1 / G2 / G5) -- objects, NO new ink:
  origin entity    ('origin:O', listed by the figure) kind 'origin': the two
                   axis lines (they cross there) + the origin's '0' when the
                   frame prints one. No dot, no letter: a drawn name of the
                   origin is RENDER_FACT_NOT_MARKED.
  partial polygon  a public polygon the figure's QUESTION names (a public
                   fact of it, or a bound name of the question's / items'
                   text), not listed by the figure, of which the figure shows
                   some vertices but not all: kind 'polygon', parts = the
                   drawn sides between consecutive shown vertices (own
                   segment, or the span of a longer drawn line) + the dots of
                   the shown vertices. Its missing vertices stay undrawn.
  unnamed vertices a polygon declared by coordinates only (poly:<tag>, its
                   vertices vtx:<tag>:<n>) is never shown: a vertex is no
                   coordinate-plane kind (RENDER_KIND_UNSUPPORTED).

v6.16 gaps r3 -- the SKETCH plane (corpus-v2 F1: G7-T08 c 1ד / 11ד; the
public frame carries "sketch": {"origin": [i, j], "places": {pt: [i, j]}},
family.public_sketch): the same house look with NO tick mark and NO number
(its axes print none); the axes cross at the sketch's origin index; every
shown point sits at its sketch place (tick indices from min) -- never at a
coordinate, and a display 'layout' / 'origin' may not move it (a layout
entry refused, an origin that differs refused: RENDER_LAYOUT); a drawn
coordinate or guide is refused (RENDER_FORM_UNSUPPORTED: a sketch prints no
number). placements model_to_svg "model" is "sketch_index". Everything
else -- grid (the frame's choice), axes, arrows, letters, dots, names,
segments, polygons, partial polygons, marks -- is drawn as on any plane.
"""
import hashlib
import json
import math
from fractions import Fraction

from .. import canon
from .. import family as FAM
from .. import schema as S
from .. import sheet_data as SDA
from .. import sheet_locus as SLO
from . import geo
from .gate import RenderRefused

COORD_ENGINE = "wspec-coord/1.0.0"
DIALECT = "wspec-coord-svg/1"
INK = "#000000"
GRID_INK = "#c8c8c8"
W_AXIS = "1.07"         # 0.8 pt
W_DATA = "1.33"         # 1 pt
W_GRID = "0.47"         # 0.35 pt
W_TICK = "0.8"          # 0.6 pt
W_GUIDE = "0.8"
W_MARK = "0.8"
GUIDE_DASH_PX = 3.0      # a reading guide: dashes of 3 px ...
GUIDE_GAP_PX = 2.0       # ... 2 px apart, from the point to the axis
TICK_HALF_PX = 3.0
NUM_GAP_PX = 1.5
ARROW_LEN_PX = 7.0
ARROW_HALF_PX = 2.8
AX_EXT_NEG = 0.5        # squares an axis runs past its negative end
AX_EXT_POS = 0.6        # squares past its last tick before the arrowhead
MIN_SQUARE_PX = 10.0
MAX_SQUARE_PX = 26.0
DEFAULT_SQUARE_PX = 13.33
GROW = 1.15
NOFLIP_GROW_MAX = 1.35
LABEL_PAD_PX = 1.0
NUM_INK_SLACK_PX = 1.0  # an axis number's box: its estimated ink + this (the
                       # face's real ink runs up to ~0.5 px wider)
NUM_SPACE_PX = 3.5     # an axis number keeps this from any other text (no "−1 0"
                       # read as "−10")
DOT_CLEAR_PX = 1.5
OWN_MARGIN_PX = 2.0
MARGIN_PX = 6.0
KNOCK_PX = 1.0
DESCENT = 0.22          # a letter's descent (g j p q y), x font size
RIGHT_LEG_PX = 7.0
LINE_EXT_SQ = 0.4       # a line / ray runs this far past the grid box
LABEL_ROOM_SQ = 2.5     # labels stay within this of the grid box
LAYERS = ("grid", "axes", "lines", "marks", "points", "labels")
ROLES = ("grid_line", "axis_line", "axis_arrow", "axis_tick", "axis_number",
         "origin_number", "axis_name", "point", "point_name",
         "coord_caption", "segment", "polygon_side", "line", "ray", "guide",
         "right_mark", "segment_caption", "data_dot", "data_square", "axis_break", "parameter_locus")
POSITION_ONLY = ("on_segment", "parallel", "axis_parallel", "rectangle",
                 "square",
                 "parallelogram", "rhombus", "trapezoid",
                 "isosceles_trapezoid", "right_triangle", "inside")
SETTINGS = {
    "figure": (lambda v: isinstance(v, str), None),
    "layout": (lambda v: isinstance(v, list), []),
    "data_layout": (lambda v: isinstance(v, list), []),
    "origin": (lambda v: v is None or (
        isinstance(v, list) and len(v) == 2 and all(
            isinstance(x, int) and not isinstance(x, bool) and x >= 0
            for x in v)), None),
    "square": (lambda v: isinstance(v, (int, float)) and
               not isinstance(v, bool) and
               MIN_SQUARE_PX <= v <= MAX_SQUARE_PX, DEFAULT_SQUARE_PX),
    "font_family": (lambda v: v in ("serif", "sans-serif",
                                    "David Libre,serif"), "serif"),
    "number_size": (lambda v: v in (10.67, 12), 10.67),
    "name_size": (lambda v: v in (12, 12.67, 14), 12.67),
    "point_radius": (lambda v: v in (2, 2.5, 2.67, 3), 2.67),
    "grow": (lambda v: isinstance(v, bool), True),
}


def _issue(code, where, detail):
    return {"code": code, "where": where, "detail": detail}


def is_coord(fig):
    return isinstance(fig, dict) and isinstance(fig.get("frame"), dict) and \
        fig["frame"].get("family") == "coordinate_plane"


def settings(ds):
    if not isinstance(ds, dict):
        raise RenderRefused("RENDER_BAD_SETTINGS", "not a dict")
    extra = sorted(set(ds) - set(SETTINGS))
    if extra:
        raise RenderRefused("RENDER_BAD_SETTINGS", "unknown key(s) %s for a "
                            "coordinate plane (closed list: %s)"
                            % (extra, sorted(SETTINGS)))
    out = {}
    for k, (ok, dflt) in sorted(SETTINGS.items()):
        if k not in ds:
            if k == "figure":
                raise RenderRefused("RENDER_BAD_SETTINGS", "figure missing")
            out[k] = dflt
            continue
        if not ok(ds[k]):
            raise RenderRefused("RENDER_BAD_SETTINGS", "%s=%r" % (k, ds[k]))
        out[k] = ds[k]
    return out


def _q(v):
    try:
        a, b, r = canon.parse_exact(v)
    except Exception:                               # noqa: BLE001
        return None
    return a if r == 1 else None


def num_text(v, form=None):
    """An axis / caption number as printed: U+2212, a decimal point. A
    plane prints integers and terminating decimals only."""
    q = v if isinstance(v, Fraction) else _q(v)
    if q is None:
        raise RenderRefused("RENDER_FRAME", "%r is not a rational" % (v,))
    if form in ("fraction", "mixed") or not canon.terminating(q):
        raise RenderRefused("RENDER_FORM_UNSUPPORTED", "%s: a coordinate "
                            "plane prints whole numbers and decimals (the "
                            "number line prints fractions)"
                            % canon.canon_number(str(q)))
    return canon.family_display(str(q), mode="plain")


def _seg_hits_box(a, b, box):
    """the segment a-b meets the box (Liang-Barsky)."""
    x0, y0, x1, y1 = box
    dx, dy = b[0] - a[0], b[1] - a[1]
    t0, t1 = 0.0, 1.0
    for pk, qk in ((-dx, a[0] - x0), (dx, x1 - a[0]), (-dy, a[1] - y0),
                   (dy, y1 - a[1])):
        if abs(pk) < 1e-12:
            if qk < 0:
                return False
            continue
        t = qk / pk
        if pk < 0:
            if t > t1:
                return False
            t0 = max(t0, t)
        else:
            if t < t0:
                return False
            t1 = min(t1, t)
    return t0 <= t1


def _clip_line(p, q, box):
    """the infinite line through p, q clipped to box -> (a, b) or None."""
    dx, dy = q[0] - p[0], q[1] - p[1]
    t0, t1 = -1e9, 1e9
    for pk, qk in ((-dx, p[0] - box[0]), (dx, box[2] - p[0]),
                   (-dy, p[1] - box[1]), (dy, box[3] - p[1])):
        if abs(pk) < 1e-12:
            if qk < 0:
                return None
            continue
        t = qk / pk
        if pk < 0:
            t0 = max(t0, t)
        else:
            t1 = min(t1, t)
    if t0 > t1:
        return None
    return (p[0] + t0 * dx, p[1] + t0 * dy), (p[0] + t1 * dx, p[1] + t1 * dy), \
        t0, t1


class _Axis(object):
    """One printed axis: n intervals, labels [(index, value)], and the
    value <-> index map the printed numbers (and the origin) fix."""

    def __init__(self, pub_axis, origin_index, where):
        self.aid = pub_axis["axis"]
        self.letter = self.aid.split(":", 1)[1]
        self.n = int(pub_axis["intervals"])
        self.form = pub_axis.get("form")
        self.broken = pub_axis.get("break_before") is True
        self.labels = []
        for i, v in pub_axis.get("labels") or []:
            q = _q(v)
            if q is None or not isinstance(i, int) or not 0 <= i <= self.n:
                raise RenderRefused("RENDER_FRAME", "%s label %r" % (
                    self.aid, [i, v]))
            self.labels.append((i, q))
        pts = dict(self.labels)
        if origin_index is not None:
            if origin_index > self.n:
                raise RenderRefused("RENDER_LAYOUT", "origin index %d is past "
                                    "the %d intervals of %s" % (
                                        origin_index, self.n, self.aid))
            if origin_index in pts and pts[origin_index] != 0:
                raise RenderRefused("RENDER_LAYOUT", "origin index %d of %s "
                                    "prints %s, not 0" % (
                                        origin_index, self.aid,
                                        canon.canon_number(str(
                                            pts[origin_index]))))
            pts.setdefault(origin_index, Fraction(0))
        self.step, self.zero = None, None
        ks = sorted(pts)
        if len(ks) >= 2:
            st = (pts[ks[-1]] - pts[ks[0]]) / (ks[-1] - ks[0])
            if st <= 0 or any(pts[k] != pts[ks[0]] + (k - ks[0]) * st
                              for k in ks):
                raise RenderRefused("RENDER_FRAME", "the printed numbers of "
                                    "%s are not one step apart per interval"
                                    % self.aid)
            self.step = st
            z = -(pts[ks[0]] - ks[0] * st) / st
            if not self.broken and (z.denominator != 1 or not 0 <= z <= self.n):
                raise RenderRefused("RENDER_FRAME", "0 is not a tick of %s "
                                    "(the axes of a plane cross at the "
                                    "origin)" % self.aid)
            self.zero = z if self.broken else int(z)
            if origin_index is not None and origin_index != self.zero:
                raise RenderRefused("RENDER_LAYOUT", "origin index %d of %s: "
                                    "its printed numbers put 0 at %d" % (
                                        origin_index, self.aid, self.zero))
        elif len(ks) == 1 and pts[ks[0]] == 0:
            self.zero = ks[0]
        if self.zero is None:
            raise RenderRefused("RENDER_LAYOUT", "%s prints too few numbers "
                                "to fix its origin: give display 'origin': "
                                "[i, j] (%s)" % (self.aid, where))

    def index_of(self, v, who):
        if self.step is None:
            raise RenderRefused("RENDER_LAYOUT", "%s prints fewer than two "
                                "numbers: its step is not printed, so %s "
                                "cannot be placed by value -- use layout "
                                "'tick'" % (self.aid, who))
        return Fraction(self.zero) + Fraction(v) / self.step


class _Builder(object):
    def __init__(self, pub, ix, fig, st, square):
        self.pub, self.ix, self.fig, self.st = pub, ix, fig, st
        self.sq = float(square)
        self.issues = []
        self.els = []          # [layer, tag, attrs(list), text, item_id, geom]
        self.items = []        # [{id, role, source, text?}]
        self.item_els = {}
        self.objects = {}
        self.dots = {}         # name -> (x, y) px
        self.strokes = []      # (p, q) obstacles for labels (not the grid)
        self.boxes = []        # placed text boxes
        self.fs_num = float(st["number_size"])
        self.fs_name = float(st["name_size"])
        self.r = float(st["point_radius"])
        fr = fig["frame"]
        org = st.get("origin") or [None, None]
        # (v6.16 gaps r3, F1) a sketch plane: the model fixes the origin
        self.sketch = fr.get("sketch") if isinstance(fr.get("sketch"),
                                                     dict) else None
        if "sketch" in fr and self.sketch is None:
            raise RenderRefused("RENDER_FRAME", "frame sketch %r" % (
                fr.get("sketch"),))
        if self.sketch is not None:
            so = self.sketch.get("origin")
            if not (isinstance(so, list) and len(so) == 2 and all(
                    isinstance(i, int) and not isinstance(i, bool)
                    for i in so)):
                raise RenderRefused("RENDER_FRAME", "sketch origin %r" % (
                    so,))
            if st.get("origin") is not None and list(st["origin"]) != so:
                raise RenderRefused("RENDER_LAYOUT", "display origin %s: the "
                                    "sketch's origin is %s" % (
                                        st["origin"], so))
            if st.get("layout"):
                raise RenderRefused("RENDER_LAYOUT", "a sketch plane places "
                                    "its points by its frame (sketch.places);"
                                    " a display layout never moves them")
            org = so
        axes = fr.get("axes") or []
        if len(axes) != 2:
            raise RenderRefused("RENDER_FRAME", "a plane has two axes")
        self.ax = _Axis(axes[0], org[0], fig["id"])
        self.ay = _Axis(axes[1], org[1], fig["id"])
        self.grid = bool(fr.get("grid"))
        self.plane = fr.get("plane")
        self.drawn = [ix.facts[d] for d in sorted(fig.get("draws") or [])
                      if d in ix.facts]
        self.shown = FAM.figure_shows(fig, ix)

    # --------------------------------------------------------- helpers --
    def X(self, i):
        return float(i) * self.sq

    def Y(self, j):
        return float(self.ay.n - j) * self.sq

    def item(self, role, source, text=None):
        it = {"id": "d%03d" % (len(self.items) + 1), "role": role,
              "source": source}
        if text is not None:
            it["text"] = text
        self.items.append(it)
        self.item_els[it["id"]] = []
        return it["id"]

    def add(self, layer, tag, attrs, item, text=None, geom=None):
        k = len(self.els)
        self.els.append([layer, tag, attrs, text, item, geom])
        self.item_els[item].append(k)
        return k

    def part(self, oid, kind, k, span="whole"):
        o = self.objects.setdefault(oid, {"kind": kind, "parts": []})
        o["parts"].append({"element": k, "span": span})

    def line(self, layer, hook, p, q, width, item, extra=()):
        attrs = [hook, ("x1", p[0]), ("y1", p[1]), ("x2", q[0]),
                 ("y2", q[1]), ("stroke", GRID_INK if hook[0] == "data-grid"
                                else INK), ("stroke-width", width)] + \
            list(extra)
        return self.add(layer, "line", attrs, item, geom=("line", p, q))

    def free(self, box, own=None, pad=LABEL_PAD_PX, text_gap=LABEL_PAD_PX):
        b = geo.inflate(box, pad)
        bt = geo.inflate(box, text_gap)
        room = (-LABEL_ROOM_SQ * self.sq, -LABEL_ROOM_SQ * self.sq,
                self.X(self.ax.n) + LABEL_ROOM_SQ * self.sq,
                self.Y(0) + LABEL_ROOM_SQ * self.sq)
        if b[0] < room[0] or b[1] < room[1] or b[2] > room[2] or \
                b[3] > room[3]:
            return False
        if any(geo.boxes_overlap(bt, o) for o in self.boxes):
            return False
        for n, c in dict(self.dots, **getattr(self, "data_dots", {})).items():
            if geo.box_point_dist(box, c) < self.r + DOT_CLEAR_PX:
                return False
        return not any(_seg_hits_box(p, q, b) for p, q in self.strokes)

    def owned(self, box, own):
        """the label box is nearer its own dot than any other by a margin"""
        d0 = geo.box_point_dist(box, self.dots[own])
        return all(geo.box_point_dist(box, c) >= d0 + OWN_MARGIN_PX
                   for n, c in self.dots.items() if n != own)

    # ------------------------------------------------------------- plan --
    def plan(self):
        ix = self.ix
        kinds = {}
        for e in sorted(self.shown):
            k = ix.kind(e)
            if k not in FAM.FAMILY_ENTITY_KINDS["coordinate_plane"]:
                raise RenderRefused("RENDER_KIND_UNSUPPORTED", "a %s (%s) on "
                                    "a coordinate plane" % (k, e))
            kinds.setdefault(k, []).append(e)
        self.kinds = kinds
        for a in (self.ax.aid, self.ay.aid):
            if a not in self.shown:
                raise RenderRefused("RENDER_FRAME", "%s is not shown by the "
                                    "figure" % a)
        # public coordinates of the shown points
        vals = {}
        for f in sorted(ix.facts.values(), key=lambda f: f["id"]):
            if f.get("rel") != "coordinate" or f.get("value") is None or \
                    f.get("role") not in ("given", "derived", "context"):
                continue
            p, a = f["args"]
            # v6.13 fix_r1 (T08B-D7, from work_t08_b/skillfix): the figure's
            # OWN question only -- a level spec reuses point names in other
            # questions at other values (as family.coordinates, check/coord.py
            # q_facts and render/nline.py public_value do)
            if ix.scope_question.get(f.get("item")) != \
                    ix.scope_question.get(self.fig.get("scope")):
                continue
            if p in self.shown:
                q = _q(f["value"])
                if (p, a) in vals and vals[(p, a)] != q:
                    raise RenderRefused("RENDER_LAYOUT", "%s has two %s "
                                        "values in the public model" % (p, a))
                vals[(p, a)] = q
        lay = {}
        for stp in self.st["layout"]:
            if not isinstance(stp, dict) or set(stp) not in (
                    {"p", "xy"}, {"p", "tick"}) or \
                    not isinstance(stp.get("xy", stp.get("tick")), list) or \
                    len(stp.get("xy", stp.get("tick"))) != 2:
                raise RenderRefused("RENDER_LAYOUT", "step %r: {'p', 'xy'} or "
                                    "{'p', 'tick'} with two numbers" % (stp,))
            if stp["p"] in lay:
                raise RenderRefused("RENDER_LAYOUT", "%s placed twice"
                                    % stp["p"])
            if ix.kind(stp["p"]) != "point":
                raise RenderRefused("RENDER_LAYOUT", "%r is not a public "
                                    "point" % stp["p"])
            if stp["p"] not in self.shown:
                raise RenderRefused("RENDER_LAYOUT", "%s is not shown by %s: "
                                    "a layout never adds a point" % (
                                        stp["p"], self.fig["id"]))
            lay[stp["p"]] = stp
        self.idx = {}
        if self.sketch is not None:
            # (v6.16 gaps r3, F1) every shown point at its sketch place
            places = self.sketch.get("places")
            if not isinstance(places, dict):
                raise RenderRefused("RENDER_FRAME", "sketch places")
            for p in sorted(kinds.get("point", [])):
                xy = places.get(p)
                got = [_q(c) for c in xy] if isinstance(xy, list) and \
                    len(xy) == 2 else [None]
                if None in got:
                    raise RenderRefused("RENDER_LAYOUT", "%s has no sketch "
                                        "place" % p)
                for i, axis in zip(got, (self.ax, self.ay)):
                    if not 0 <= i <= axis.n:
                        raise RenderRefused("RENDER_LAYOUT", "%s lies outside"
                                            " the frame on %s" % (p, axis.aid))
                self.idx[p] = tuple(got)
                self.dots[p] = (self.X(got[0]), self.Y(got[1]))
            return
        for p in sorted(kinds.get("point", [])):
            got = []
            for n, axis in enumerate((self.ax, self.ay)):
                i_f = None
                if (p, axis.aid) in vals:
                    i_f = axis.index_of(vals[(p, axis.aid)], p)
                i_l = None
                if p in lay:
                    stp = lay[p]
                    v = _q(stp.get("xy", stp.get("tick"))[n])
                    if v is None:
                        raise RenderRefused("RENDER_LAYOUT", "%s: %r" % (
                            p, stp))
                    i_l = axis.index_of(v, p) if "xy" in stp else \
                        Fraction(axis.zero) + v
                if i_f is not None and i_l is not None and i_f != i_l:
                    raise RenderRefused("RENDER_LAYOUT", "%s: the layout puts "
                                        "it at tick %s of %s, its public "
                                        "coordinate at %s" % (
                                            p, i_l, axis.aid, i_f))
                i = i_f if i_f is not None else i_l
                if i is None:
                    raise RenderRefused("RENDER_LAYOUT", "%s has no public "
                                        "coordinate on %s: place it with a "
                                        "layout step" % (p, axis.aid))
                if not 0 <= i <= axis.n:
                    raise RenderRefused("RENDER_LAYOUT", "%s lies outside the "
                                        "frame on %s" % (p, axis.aid))
                got.append(i)
            for row in SLO.objects(self.pub, self.fig["id"]).values():
                if row["point"] == p and row["example"]:
                    free = self.ax if row["free_axis"] == self.ax.aid else self.ay
                    free_index = got[0 if free is self.ax else 1]
                    if (free_index - free.zero) * free.step < _q(row["domain"]["lo"]):
                        raise RenderRefused("RENDER_LAYOUT", "illustrative parameter point is outside its stated domain")
            self.idx[p] = tuple(got)
            self.dots[p] = (self.X(got[0]), self.Y(got[1]))

    # ------------------------------------------------------------- draw --
    def draw_axes(self):
        ax, ay = self.ax, self.ay
        sq = self.sq
        yx = self.Y(0 if ay.broken else ay.zero)
        xy = self.X(ax.zero)
        self.axis_px = {ax.aid: yx, ay.aid: xy}
        self.axis_line_el = {}
        x0 = self.X(0) - (AX_EXT_NEG * sq if ax.zero > 0 else 0.6 * sq)
        x1 = self.X(ax.n) + AX_EXT_POS * sq
        y0 = self.Y(0) + (AX_EXT_NEG * sq if ay.zero > 0 else 0.6 * sq)
        y1 = self.Y(ay.n) - AX_EXT_POS * sq
        for axis, p, q, tip, pts in (
                (ax, (x0, yx), (x1, yx), (x1 + ARROW_LEN_PX, yx),
                 [(x1, yx - ARROW_HALF_PX), (x1 + ARROW_LEN_PX, yx),
                  (x1, yx + ARROW_HALF_PX)]),
                (ay, (xy, y0), (xy, y1), (xy, y1 - ARROW_LEN_PX),
                 [(xy - ARROW_HALF_PX, y1), (xy, y1 - ARROW_LEN_PX),
                  (xy + ARROW_HALF_PX, y1)])):
            it = self.item("axis_line", {"entity": axis.aid})
            k = self.line("axes", ("data-axis", axis.letter), p, q, W_AXIS, it)
            self.part(axis.aid, "axis", k)
            self.axis_line_el[axis.aid] = k      # v6.16 gaps: the origin
            self.strokes.append((p, q))
            it = self.item("axis_arrow", {"entity": axis.aid})
            path = bool(self.fig.get("data"))
            k = self.add("axes", "path" if path else "polygon", [
                ("data-arrow", axis.letter), ("d" if path else "points", pts), ("fill", INK),
                ("stroke", "none")], it, geom=("poly", pts))
            self.part(axis.aid, "axis", k)
            for i in range(3):
                self.strokes.append((pts[i], pts[(i + 1) % 3]))
            axis.tip = tip
            if axis.broken:
                # A visible break separates the crossing from the first
                # printed value. Its geometry is independently measured.
                cy = self.Y(0.5)
                pts = [(xy-3,cy+3),(xy+3,cy+1),(xy-3,cy-1),(xy+3,cy-3)]
                it = self.item("axis_break", {"entity":axis.aid})
                k = self.add("axes","polyline",[("data-break",axis.letter),
                    ("points",pts),("fill","none"),("stroke",INK),
                    ("stroke-width",W_AXIS)],it,geom=("poly",pts))
                self.part(axis.aid,"axis",k)
                self.strokes.extend(zip(pts,pts[1:]))
        # tick marks: at the printed numbers (every step without a grid),
        # never at the origin (the axes cross there); a sketch has none
        for axis in (ax, ay) if self.sketch is None else ():
            labelled = set(i for i, _v in axis.labels)
            for i in range(axis.n + 1):
                if i == (0 if axis.broken else axis.zero) or (self.grid and i not in labelled):
                    continue
                if axis is ax:
                    p, q = (self.X(i), yx - TICK_HALF_PX), \
                        (self.X(i), yx + TICK_HALF_PX)
                else:
                    p, q = (xy - TICK_HALF_PX, self.Y(i)), \
                        (xy + TICK_HALF_PX, self.Y(i))
                it = self.item("axis_tick", {"entity": axis.aid})
                k = self.line("axes", ("data-tick", "%s %d" % (axis.letter, i)),
                              p, q, W_TICK, it)
                self.part(axis.aid, "axis", k)
                self.strokes.append((p, q))
                axis.tick_el = getattr(axis, "tick_el", {})
                axis.tick_el[i] = k

    def draw_data(self):
        ix = self.ix
        k_ = self.kinds
        self.lin_el = []      # (element, p, q, names on it)
        for oid, row in sorted(SLO.objects(self.pub, self.fig["id"]).items()):
            fixed = self.ax if row["axis"] == self.ax.aid else self.ay
            free = self.ay if fixed is self.ax else self.ax
            fv = float(_q(row["value"]) / fixed.step + fixed.zero)
            low = max(0, float(_q(row["domain"]["lo"]) / free.step + free.zero))
            if low >= free.n or not 0 <= fv <= fixed.n:
                raise RenderRefused("RENDER_LAYOUT", "parameter locus misses the printed frame")
            p, q = ((self.X(low), self.Y(fv)), (self.X(free.n), self.Y(fv))) if fixed is self.ay else ((self.X(fv), self.Y(low)), (self.X(fv), self.Y(free.n)))
            it = self.item("parameter_locus", {"entity": oid})
            el = self.line("lines", ("data-locus", row["token"]), p, q, W_DATA, it,
                           [("stroke-dasharray", "3 3")])
            self.part(oid, "line", el)
            self.strokes.append((p, q)); self.lin_el.append((el, p, q))
        for kind in ("line", "ray"):
            for e in sorted(k_.get(kind, [])):
                ent = ix.entities[e]
                a, b = (ent["through"] if kind == "line" else
                        [ent["from"], ent["through"]])
                P, Q = self.dots[a], self.dots[b]
                ext = LINE_EXT_SQ * self.sq
                box = (self.X(0) - ext, self.Y(self.ay.n) - ext,
                       self.X(self.ax.n) + ext, self.Y(0) + ext)
                c = _clip_line(P, Q, box)
                if c is None:
                    raise RenderRefused("RENDER_LAYOUT", "%s misses the frame"
                                        % e)
                p, q, t0, t1 = c
                if kind == "ray":
                    p = P
                    if t1 < 1.0:
                        raise RenderRefused("RENDER_LAYOUT", "%s runs out of "
                                            "the frame" % e)
                it = self.item(kind, {"entity": e})
                hook = ("data-" + kind, "%s %s" % (a, b) if kind == "ray"
                        else " ".join(sorted([a, b])))
                el = self.line("lines", hook, p, q, W_DATA, it)
                self.part(e, kind, el)
                self.strokes.append((p, q))
                self.lin_el.append((el, p, q))
        drawn_segs = {}

        def seg_parts(a, b):
            key = tuple(sorted([a, b]))
            if key in drawn_segs:
                return drawn_segs[key]
            P, Q = self.dots[a], self.dots[b]
            for el, p, q in self.lin_el:
                if geo.seg_dist(P, p, q) <= 0.01 and \
                        geo.seg_dist(Q, p, q) <= 0.01:
                    drawn_segs[key] = (el, [key[0], key[1]])
                    return drawn_segs[key]
            return None
        for e in sorted(k_.get("segment", [])):
            a, b = sorted(ix.entities[e]["ends"])
            got = seg_parts(a, b)
            if got is None:
                it = self.item("segment", {"entity": e})
                el = self.line("lines", ("data-seg", "%s %s" % (a, b)),
                               self.dots[a], self.dots[b], W_DATA, it)
                self.strokes.append((self.dots[a], self.dots[b]))
                drawn_segs[(a, b)] = (el, "whole")
                got = drawn_segs[(a, b)]
            self.part(e, "segment", got[0], got[1])
        for e in sorted(k_.get("polygon", [])):
            vs = ix.entities[e]["vertices"]
            for i in range(len(vs)):
                a, b = sorted([vs[i], vs[(i + 1) % len(vs)]])
                got = seg_parts(a, b)
                if got is None:
                    it = self.item("polygon_side", {"entity": e})
                    el = self.line("lines", ("data-seg", "%s %s" % (a, b)),
                                   self.dots[a], self.dots[b], W_DATA, it)
                    self.strokes.append((self.dots[a], self.dots[b]))
                    drawn_segs[(a, b)] = (el, "whole")
                    got = drawn_segs[(a, b)]
                self.part(e, "polygon", got[0], got[1])
        self.drawn_segs = drawn_segs

    def draw_facts(self):
        """guides and right marks (before the labels: they are obstacles)"""
        ix = self.ix
        self.caption_facts = []
        self.coord_drawn = {}
        self.named = {}
        for f in self.drawn:
            rel, args = f.get("rel"), f.get("args") or []
            if rel == "name":
                if ix.kind(args[0]) == "origin":
                    # (v6.16 gaps, G2) the origin prints no letter: the
                    # corner holds the axes' '0'
                    self.issues.append(_issue(
                        "RENDER_FACT_NOT_MARKED", f["id"], "the origin's "
                        "name is not drawn on a coordinate plane"))
                    continue
                self.named[args[0]] = f
            elif rel in ("coordinate", "guide") and self.sketch is not None:
                # (v6.16 gaps r3) a sketch prints no number, no guide
                raise RenderRefused("RENDER_FORM_UNSUPPORTED", "%s: a sketch "
                                    "plane draws no %s" % (f["id"], rel))
            elif rel == "coordinate":
                self.coord_drawn.setdefault(args[0], {})[args[1]] = f
            elif rel == "guide":
                self._guide(f)
            elif rel in ("perpendicular", "angle_measure"):
                self._right(f)
            elif rel == "length":
                self.caption_facts.append(f)
            elif rel in POSITION_ONLY:
                continue
            else:
                self.issues.append(_issue("RENDER_FACT_NOT_MARKED", f["id"],
                                          "%s has no mark on a coordinate "
                                          "plane" % rel))

    def _guide(self, f):
        p, aid = f["args"]
        if p not in self.dots or aid not in self.axis_px:
            self.issues.append(_issue("RENDER_FACT_NOT_MARKED", f["id"],
                                      "the guide's point / axis is not "
                                      "drawn"))
            return
        P = self.dots[p]
        letter = aid.split(":", 1)[1]
        Q = (P[0], self.axis_px[aid]) if aid == self.ax.aid else \
            (self.axis_px[aid], P[1])
        if geo.d(P, Q) < 1.0:
            self.issues.append(_issue("RENDER_FACT_NOT_MARKED", f["id"],
                                      "%s lies on %s: its guide is empty"
                                      % (p, aid)))
            return
        # the dashes are drawn as pieces (no stroke-dasharray: every
        # renderer / rasteriser prints the same ink, and each dash is a
        # straight element the checker and G79 can measure)
        it = self.item("guide", {"fact": f["id"], "entity": p})
        L = geo.d(P, Q)
        u = geo.unit(P, Q)
        t = 0.0
        while t < L - 0.5:
            t1 = min(L, t + GUIDE_DASH_PX)
            a = (P[0] + u[0] * t, P[1] + u[1] * t)
            b = (P[0] + u[0] * t1, P[1] + u[1] * t1)
            k = self.line("lines", ("data-guide", "%s %s" % (p, letter)), a,
                          b, W_GUIDE, it)
            self.part(f["id"], "guide", k)
            t = t1 + GUIDE_GAP_PX
        self.strokes.append((P, Q))

    def _right(self, f):
        ix = self.ix
        args = f.get("args") or []
        trip = None
        if f["rel"] == "angle_measure":
            if _q(f.get("value")) != 90:
                self.issues.append(_issue("RENDER_FACT_NOT_MARKED", f["id"],
                                          "an angle value on a coordinate "
                                          "plane (only the right angle is "
                                          "marked)"))
                return
            e = ix.entities.get(args[0]) or {}
            trip = (e["arms"][0], e["vertex"], e["arms"][1])
        else:
            pts = [set(self._pts(a)) for a in args[:2]]
            com = pts[0] & pts[1]
            if len(com) == 1:
                v = list(com)[0]
                o1 = sorted(pts[0] - com)[0]
                o2 = sorted(pts[1] - com)[0]
                trip = (o1, v, o2)
        if trip is None or any(n not in self.dots for n in trip):
            self.issues.append(_issue("RENDER_FACT_NOT_MARKED", f["id"],
                                      "no common drawn point for the right-"
                                      "angle mark"))
            return
        a, v, b = trip
        V = self.dots[v]
        u = geo.unit(V, self.dots[a])
        w = geo.unit(V, self.dots[b])
        L = RIGHT_LEG_PX
        pts = [(V[0] + u[0] * L, V[1] + u[1] * L),
               (V[0] + u[0] * L + w[0] * L, V[1] + u[1] * L + w[1] * L),
               (V[0] + w[0] * L, V[1] + w[1] * L)]
        it = self.item("right_mark", {"fact": f["id"], "entity": args[0]})
        a_, b_ = sorted([a, b])
        k = self.add("marks", "polyline", [
            ("data-mark", "right %s %s %s" % (a_, v, b_)), ("points", pts),
            ("fill", "none"), ("stroke", INK), ("stroke-width", W_MARK)],
            it, geom=("poly", pts))
        for e in args[:2]:
            self.part(e, ix.kind(e) or "segment", k)
        self.strokes += [(pts[0], pts[1]), (pts[1], pts[2])]

    def _pts(self, e):
        ent = self.ix.entities.get(e) or {}
        k = ent.get("kind")
        if k == "segment":
            return list(ent["ends"])
        if k == "line":
            return list(ent["through"])
        if k == "ray":
            return [ent["from"], ent["through"]]
        return []

    def draw_points(self):
        self.dot_el = {}
        for p in sorted(self.dots):
            c = self.dots[p]
            it = self.item("point", {"entity": p})
            k = self.add("points", "circle", [
                ("data-pt", p), ("cx", c[0]), ("cy", c[1]), ("r", self.r),
                ("fill", INK), ("stroke", "none")], it, geom=("dot", c))
            self.part(p, "point", k)
            self.dot_el[p] = k                   # v6.16 gaps: G1

    def plan_observations(self):
        """Private positions are display settings, never public answers."""
        self.data_dots = {}
        self.observations = SDA.objects(self.pub, self.fig["id"])
        lay = {}
        for row in self.st["data_layout"]:
            if not isinstance(row, dict) or set(row) != {"id", "xy"} or \
                    not isinstance(row["id"], str) or row["id"] in lay or \
                    not isinstance(row["xy"], list) or len(row["xy"]) != 2:
                raise RenderRefused("RENDER_LAYOUT", "invalid data_layout row")
            obj = self.observations.get(row["id"], {})
            if obj.get("kind") != "data_point" or not obj.get("drawn"):
                raise RenderRefused("RENDER_LAYOUT", "data_layout cannot add an observation")
            lay[row["id"]] = row["xy"]
        for oid, p in sorted(self.observations.items()):
            if p["kind"] != "data_point" or not p["drawn"]:
                continue
            xy = p.get("coords", lay.get(oid))
            if xy is None or any(_q(v) is None for v in xy):
                raise RenderRefused("RENDER_LAYOUT", "missing data placement for %s" % oid)
            if oid in lay and "coords" in p and any(_q(a) != _q(b) for a,b in zip(xy,lay[oid])):
                raise RenderRefused("RENDER_LAYOUT", "data placement disagrees with printed givens")
            i,j = [a.index_of(_q(v), oid) for a,v in zip((self.ax,self.ay),xy)]
            if any(not (1 if a.broken else 0) <= k <= a.n for a,k in zip((self.ax,self.ay),(i,j))):
                raise RenderRefused("RENDER_LAYOUT", "data observation lies outside the printed range")
            self.data_dots[oid] = (self.X(i), self.Y(j))

    def draw_observations(self):
        for oid, c in sorted(self.data_dots.items()):
            p = self.observations[oid]
            series = self.observations["series:" + p["series"]]
            square = series["marker"] == "square"
            role, hook = ("data_square", "data-square") if square else ("data_dot", "data-dot")
            it = self.item(role, {"entity":oid})
            hv = p["series"] + " " + p["point"]
            if square:
                r = self.r + 0.5
                pts = [(c[0]-r,c[1]-r),(c[0]+r,c[1]-r),(c[0]+r,c[1]+r),(c[0]-r,c[1]+r)]
                k = self.add("points", "path", [(hook,hv),("d",pts),
                     ("fill","none"),("stroke",INK),("stroke-width",W_DATA)],it,
                     geom=("poly",pts))
            else:
                k = self.add("points","circle",[(hook,hv),("cx",c[0]),("cy",c[1]),
                     ("r",self.r),("fill",INK),("stroke","none")],it,geom=("dot",c))
            self.part(oid,"data_point",k)
            self.part("series:"+p["series"],"data_series",k)

    def reading_objects(self):
        """An axis-reading object comprises exactly its existing marks/numbers."""
        for oid,r in sorted(self.observations.items()):
            if r["kind"] != "axis_reading": continue
            axis = self.ax if r["axis"] == self.ax.aid else self.ay
            for i in range(axis.n+1):
                v = (Fraction(i)-axis.zero)*axis.step
                if "lo" in r and (v < _q(r["lo"]) or (v == _q(r["lo"]) and not r["lo_in"])): continue
                if "hi" in r and (v > _q(r["hi"]) or (v == _q(r["hi"]) and not r["hi_in"])): continue
                for k in (getattr(axis,"tick_el",{}).get(i),getattr(axis,"num_el",{}).get(i)):
                    if k is not None: self.part(oid,"axis_reading",k)
            if oid not in self.objects:
                raise RenderRefused("RENDER_LAYOUT", "axis reading selects no visible mark")

    # ----------------------------------------------------------- labels --
    def label_axis_names(self):
        """the axis letter (italic) beside its arrowhead; the box holds the
        letter's descent (y) so nothing is placed under it."""
        fs = self.fs_name
        for axis in (self.ax, self.ay):
            f = self.named.get(axis.aid)
            if f is None:
                continue
            t = axis.letter
            w, h = geo.text_width(t, fs), geo.GLYPH_H * fs
            desc = DESCENT * fs if t in "gjpqy" else 0.0
            tx, ty = axis.tip
            if axis is self.ax:
                x0, base = tx + 2.0, ty + 0.25 * h + h / 2
            else:
                x0, base = tx - ARROW_HALF_PX - 2.0 - w, ty + h / 2
            box = (x0, base - h, x0 + w, base + desc)
            it = self.item("axis_name", {"fact": f["id"], "entity": axis.aid},
                           t)
            k = self._text_el(it, t, box, ("data-axname", axis.letter),
                              "middle", fs, italic=True, base=base)
            self.part(axis.aid, "axis", k)

    def label_numbers(self):
        ax, ay = self.ax, self.ay
        fs = self.fs_num
        h = geo.GLYPH_H * fs
        yx, xy = self.axis_px[ax.aid], self.axis_px[ay.aid]
        below = yx + TICK_HALF_PX + NUM_GAP_PX
        left = xy - TICK_HALF_PX - NUM_GAP_PX
        zero_x = any(i == ax.zero for i, _v in ax.labels)
        zero_y = any(i == ay.zero for i, _v in ay.labels)
        jobs = []
        if zero_x or zero_y:
            w = geo.ink_width("0", fs)
            box = (xy - NUM_GAP_PX - w, below, xy - NUM_GAP_PX, below + h)
            jobs.append(("origin", None, "0", box, "end"))
        for i, v in ax.labels:
            if i == ax.zero:
                continue
            t = num_text(v, ax.form)
            w = geo.ink_width(t, fs) + NUM_INK_SLACK_PX
            X = self.X(i)
            jobs.append(("x", i, t, (X - w / 2, below, X + w / 2, below + h),
                         "middle"))
        for j, v in ay.labels:
            if j == ay.zero:
                continue
            t = num_text(v, ay.form)
            w = geo.ink_width(t, fs) + NUM_INK_SLACK_PX
            Y = self.Y(j)
            jobs.append(("y", j, t, (left - w, Y - h / 2, left, Y + h / 2),
                         "end"))
        for kind, i, t, box, anchor in jobs:
            chosen = None
            ob = getattr(self, "origin_box", None)
            for b in self._num_cands(kind, box):
                if self.free(b) and (ob is None or not geo.boxes_overlap(
                        geo.inflate(b, NUM_SPACE_PX), ob)):
                    chosen = b
                    break
            if chosen is None:
                self.issues.append(_issue(
                    "RENDER_AXIS_CROWDED", "%s %s" % (kind, i if i is not None
                                                      else ""),
                    "the number %s has no free place at its tick: a larger "
                    "square (display 'square') or fewer printed numbers "
                    "(label_every) -- a number is never dropped" % t))
                chosen = box
            if kind == "origin":
                self.origin_box = chosen
                it = self.item("origin_number", {"entity": self.plane}, t)
                hook = ("data-num", "origin")
            else:
                axis = ax if kind == "x" else ay
                it = self.item("axis_number", {"entity": axis.aid}, t)
                hook = ("data-num", "%s %d" % (axis.letter, i))
            k = self._text_el(it, t, chosen, hook, anchor, fs)
            if kind == "origin":
                self.origin_el = k               # v6.16 gaps: the origin
                for a_ in ((ax.aid,) if zero_x else ()) + \
                        ((ay.aid,) if zero_y else ()):
                    self.part(a_, "axis", k)
            else:
                self.part(axis.aid, "axis", k)
                axis.num_el = getattr(axis, "num_el", {})
                axis.num_el[i] = k

    def _num_cands(self, kind, box):
        """where an axis number may stand, in order: at its tick; slid
        along its axis (still nearer its own tick than any other: at most
        half a square less 1 px); across the axis (the other side); a
        little farther out. The origin '0': its four corners."""
        yx, xy = self.axis_px[self.ax.aid], self.axis_px[self.ay.aid]
        lim = int(max(0.0, self.sq / 2.0 - 1.0))
        along = [0]
        for d in range(1, lim + 1):
            along += [d, -d]
        out = []

        def mv(b, dx, dy):
            return (b[0] + dx, b[1] + dy, b[2] + dx, b[3] + dy)
        if kind == "origin":
            w, h = box[2] - box[0], box[3] - box[1]
            g = TICK_HALF_PX + NUM_GAP_PX
            corners = [box, mv(box, w + 2 * NUM_GAP_PX, 0),
                       (box[0], yx - g - h, box[2], yx - g),
                       (xy + NUM_GAP_PX, yx - g - h, xy + NUM_GAP_PX + w,
                        yx - g)]
            for c in corners[:4 if self.flip else 1]:
                for dn in (0, 1, 2, 3):
                    out.append(mv(c, -dn if c[0] < xy else dn,
                                  dn if c[1] > yx else -dn))
            return out
        # v6.12 fix_r1 (CS35): a number flipped ACROSS its axis must not
        # stand where the OTHER axis prints its numbers -- an x number above
        # the x axis within a square left of the y axis (the y numbers'
        # column) reads as a y number ('−0.5' under the y number '0.5'), a
        # y number right of the y axis within a square under the x axis
        # reads as an x number. Such a flipped place is no candidate.
        sq = self.sq
        if kind == "x":
            flip = (box[0], 2 * yx - box[3], box[2], 2 * yx - box[1])
            for side, sgn in ((box, 1), (flip, -1))[:2 if self.flip else 1]:
                for dn in (0, 1, 2, 3):
                    for da in along:
                        c = mv(side, da, sgn * dn)
                        if sgn < 0 and c[2] > xy - sq and c[0] < xy:
                            continue
                        out.append(c)
        else:
            w = box[2] - box[0]
            flip = (2 * xy - box[2], box[1], 2 * xy - box[2] + w, box[3])
            for side, sgn in ((box, -1), (flip, 1))[:2 if self.flip else 1]:
                for dn in (0, 1, 2, 3):
                    for da in along:
                        c = mv(side, sgn * dn, da)
                        if sgn > 0 and c[1] < yx + sq and c[3] > yx:
                            continue
                        out.append(c)
        return out

    def _text_el(self, it, t, box, hook, anchor, fs, italic=False,
                 base=None):
        cx = (box[0] + box[2]) / 2.0
        x = {"middle": cx, "end": box[2], "start": box[0]}[anchor]
        attrs = [hook, ("x", x), ("y", box[3] if base is None else base),
                 ("font-family", self.st["font_family"]), ("font-size", fs)]
        if italic:
            attrs.append(("font-style", "italic"))
        if anchor != "start":
            attrs.append(("text-anchor", anchor))
        attrs.append(("fill", INK))
        self.boxes.append(box)
        return self.add("labels", "text", attrs, it, text=t,
                        geom=("text", box))

    def _around(self, own, w, h, prefer=()):
        c = self.dots[own]
        dirs = (-90, 0, -45, -135, 180, 90, 45, 135)
        cands = list(prefer)
        for gap in (2.0, 3.5, 5.0, 7.0, 9.0):
            for deg in dirs:
                ph = math.radians(deg)
                ext = abs(math.cos(ph)) * w / 2 + abs(math.sin(ph)) * h / 2
                d = self.r + gap + ext
                cc = (c[0] + d * math.cos(ph), c[1] + d * math.sin(ph))
                cands.append((cc[0] - w / 2, cc[1] - h / 2, cc[0] + w / 2,
                              cc[1] + h / 2))
        for b in cands:
            if self.free(b) and self.owned(b, own):
                return b
        return None

    def label_points(self):
        fs = self.fs_name
        h = geo.GLYPH_H * fs
        self.name_box = {}
        for p in sorted(self.dots):
            f = self.named.get(p)
            if f is None:
                continue
            n = self.ix.entities[p]["name"]
            w = geo.text_width(n, fs)
            # Q extends below the baseline (David Libre: 305/2048 em;
            # DejaVu Sans: 264/2048 em). Reserve 1/4 em for its tail,
            # including fallback / raster rounding, in collision placement
            # AND grid knockout. The point itself never moves.
            descent = 0.25 * fs if n == "Q" else 0.0
            b = self._around(p, w, h + descent)
            if b is None:
                self.issues.append(_issue("RENDER_LABEL_NO_PLACE", p,
                                          "the name of %s has no free place"
                                          % p))
                continue
            it = self.item("point_name", {"fact": f["id"], "entity": p}, n)
            k = self._text_el(it, n, b, ("data-for", p), "middle", fs,
                              base=b[3] - descent)
            self.part(p, "point", k)
            self.name_box[p] = b
        # coordinate captions (both coordinates drawn)
        fs = self.fs_num
        h = geo.GLYPH_H * fs
        for p in sorted(self.coord_drawn):
            fx = self.coord_drawn[p].get(self.ax.aid)
            fy = self.coord_drawn[p].get(self.ay.aid)
            if fx is None or fy is None or p not in self.dots or \
                    fx.get("value") is None or fy.get("value") is None:
                for f in (fx, fy):
                    if f is not None:
                        self.issues.append(_issue(
                            "RENDER_FACT_NOT_MARKED", f["id"], "a coordinate "
                            "caption needs both coordinates drawn (with "
                            "their values) and the point shown"))
                continue
            t = "(%s, %s)" % (num_text(fx["value"]), num_text(fy["value"]))
            w = geo.text_width(t, fs)
            prefer = []
            nb = self.name_box.get(p)
            if nb is not None:
                cy = (nb[1] + nb[3]) / 2.0
                prefer = [(nb[2] + 1.5, cy - h / 2, nb[2] + 1.5 + w, cy + h / 2),
                          (nb[0] - 1.5 - w, cy - h / 2, nb[0] - 1.5, cy + h / 2)]
            b = self._around(p, w, h, prefer)
            if b is None:
                self.issues.append(_issue("RENDER_LABEL_NO_PLACE", p,
                                          "the coordinates of %s have no "
                                          "free place" % p))
                continue
            it = self.item("coord_caption", {"fact": fx["id"], "entity": p},
                           t)
            k = self._text_el(it, t, b, ("data-for", "coord %s" % p),
                              "middle", fs)
            self.part(p, "point", k)
        for f in self.caption_facts:
            self._seg_caption(f)

    def _seg_caption(self, f):
        e = f["args"][0]
        ent = self.ix.entities.get(e) or {}
        if ent.get("kind") != "segment" or f.get("value") is None or \
                any(n not in self.dots for n in ent["ends"]):
            self.issues.append(_issue("RENDER_FACT_NOT_MARKED", f["id"],
                                      "a length caption needs a drawn "
                                      "segment and a value"))
            return
        a, b = sorted(ent["ends"])
        P, Q = self.dots[a], self.dots[b]
        t = num_text(f["value"])
        fs = self.fs_num
        w, h = geo.text_width(t, fs), geo.GLYPH_H * fs
        m = ((P[0] + Q[0]) / 2.0, (P[1] + Q[1]) / 2.0)
        u = geo.unit(P, Q)
        nrm = (-u[1], u[0])
        found = None
        for gap in (3.0, 5.0, 8.0):
            for sg in (1, -1):
                ext = abs(nrm[0]) * w / 2 + abs(nrm[1]) * h / 2
                c = (m[0] + sg * nrm[0] * (gap + ext),
                     m[1] + sg * nrm[1] * (gap + ext))
                bx = (c[0] - w / 2, c[1] - h / 2, c[0] + w / 2, c[1] + h / 2)
                if self.free(bx):
                    found = bx
                    break
            if found:
                break
        if found is None:
            self.issues.append(_issue("RENDER_LABEL_NO_PLACE", f["id"],
                                      "the length of %s has no free place"
                                      % e))
            return
        it = self.item("segment_caption", {"fact": f["id"], "entity": e}, t)
        k = self._text_el(it, t, found, ("data-for", "seg %s %s" % (a, b)),
                          "middle", fs)
        self.part(e, "segment", k)

    # ------------------------------------------------------------- grid --
    def draw_grid(self):
        """grid lines at every step (not under the axes), knocked out under
        every text box. Built last, emitted first (layer grid)."""
        if not self.grid:
            return
        boxes = [geo.inflate(b, KNOCK_PX) for b in self.boxes]
        top, bot = self.Y(self.ay.n), self.Y(0)
        lft, rgt = self.X(0), self.X(self.ax.n)
        runs = []
        for i in range(self.ax.n + 1):
            if i == self.ax.zero:
                continue
            x = self.X(i)
            cuts = sorted((b[1], b[3]) for b in boxes if b[0] < x < b[2])
            runs.append(("x", i, [((x, a), (x, c)) for a, c in
                                  _gaps(top, bot, cuts)]))
        for j in range(self.ay.n + 1):
            if j == self.ay.zero:
                continue
            y = self.Y(j)
            cuts = sorted((b[0], b[2]) for b in boxes if b[1] < y < b[3])
            runs.append(("y", j, [((a, y), (c, y)) for a, c in
                                  _gaps(lft, rgt, cuts)]))
        for letter, i, pieces in runs:
            it = self.item("grid_line", {"entity": self.plane})
            for p, q in pieces:
                k = self.line("grid", ("data-grid", "%s %d" % (letter, i)), p,
                              q, W_GRID, it)
                self.part(self.plane, "plane", k)

    def tick_objects(self):
        """a listed tick entity: its mark and its number."""
        for e in sorted(self.kinds.get("tick", [])):
            ent = self.ix.entities[e]
            axis = self.ax if ent["axis"] == self.ax.aid else self.ay
            try:
                i = axis.index_of(_q(ent["at"]), e)
            except RenderRefused:
                raise
            if i.denominator != 1:
                raise RenderRefused("RENDER_LAYOUT", "%s is not at a tick" % e)
            i = int(i)
            for k in (getattr(axis, "tick_el", {}).get(i),
                      getattr(axis, "num_el", {}).get(i)):
                if k is not None:
                    self.part(e, "tick", k)
            if e not in self.objects:
                self.issues.append(_issue("RENDER_FACT_NOT_MARKED", e,
                                          "the tick prints no mark and no "
                                          "number"))

    # ------------------------------------------- v6.16 gaps: G2 and G1 --
    def origin_objects(self):
        """(corpus-v2 G2) a listed origin entity ('origin:O', the point
        where the axes cross): its object is the two axis LINES (they cross
        there) and the origin's printed '0' when the frame prints one. It
        adds no ink: the plane draws no dot and no letter for the origin
        (the house look, figkit_plus.plane), so a highlight halos the two
        axis lines and boxes the '0'."""
        for e in sorted(self.kinds.get("origin", [])):
            for aid in (self.ax.aid, self.ay.aid):
                self.part(e, "origin", self.axis_line_el[aid])
            k = getattr(self, "origin_el", None)
            if k is not None:
                self.part(e, "origin", k)

    def _drawn_piece(self, a, b):
        """(element, 'whole' | [a, b]) of the drawn straight piece a..b (its
        own segment, or the span of a longer drawn line), or None. Nothing
        is drawn here."""
        key = tuple(sorted([a, b]))
        got = self.drawn_segs.get(key)
        if got is not None:
            return got
        P, Q = self.dots.get(a), self.dots.get(b)
        if P is None or Q is None:
            return None
        for el, p, q in self.lin_el:
            if geo.seg_dist(P, p, q) <= 0.01 and \
                    geo.seg_dist(Q, p, q) <= 0.01:
                return (el, [key[0], key[1]])
        return None

    def partial_polygons(self):
        """(corpus-v2 G1) a PARTIAL polygon: a public polygon that the
        figure's question names -- a public fact of it (its area asked) or
        a name its bound text binds ('$ABCD$ מלבן') -- not listed by the
        figure, of which the figure shows SOME vertices
        but not all ('three of its vertices are marked'; the fourth is the
        answer). Its object: the drawn sides between two consecutive shown
        vertices (a side's own segment or its span of a longer line) + the
        dots of its shown vertices. The missing vertices and their sides
        are never drawn here (they are not in the shown set); the checker
        fails any form of them (POLY_MISSING_VERTEX_NOT_DRAWN)."""
        ix = self.ix
        q = ix.scope_question.get(self.fig.get("scope"))
        named = set()
        for f in ix.facts.values():
            if ix.scope_question.get(f.get("item")) != q:
                continue
            for a in f.get("args") or []:
                if ix.kind(a) == "polygon":
                    named.add(a)
        # the public model's bound blocks of the question and its items
        # (project.PUBLIC_KEYS 'bound': [{text, bind, prints}])
        qd = ix.questions.get(q) or {}
        for sc in [qd] + list(qd.get("items") or []):
            for blk in (sc.get("bound") or []) if isinstance(sc, dict) \
                    else []:
                for b in (blk.get("bind") or []) if isinstance(blk, dict) \
                        else []:
                    if isinstance(b, dict) and \
                            ix.kind(b.get("entity")) == "polygon":
                        named.add(b["entity"])
        for e in sorted(named - set(self.shown)):
            vs = list((ix.entities.get(e) or {}).get("vertices") or [])
            if any(ix.kind(v) != "point" for v in vs):
                continue                 # unnamed vertices: never shown
            have = [v for v in vs if v in self.dots]
            if not have or len(have) == len(vs):
                continue
            n = len(vs)
            for i in range(n):
                a, b = vs[i], vs[(i + 1) % n]
                if a in self.dots and b in self.dots:
                    got = self._drawn_piece(a, b)
                    if got is not None:
                        self.part(e, "polygon", got[0], got[1])
            for v in have:
                self.part(e, "polygon", self.dot_el[v])

    # ----------------------------------------------------------- output --
    def finish(self):
        """translate so every ink / label box sits MARGIN_PX inside the
        canvas; number the elements in layer order."""
        xs, ys = [], []
        for layer, tag, attrs, text, it, g in self.els:
            if g[0] == "line":
                xs += [g[1][0], g[2][0]]
                ys += [g[1][1], g[2][1]]
            elif g[0] == "poly":
                xs += [p[0] for p in g[1]]
                ys += [p[1] for p in g[1]]
            elif g[0] == "dot":
                xs += [g[1][0] - self.r, g[1][0] + self.r]
                ys += [g[1][1] - self.r, g[1][1] + self.r]
            elif g[0] == "text":
                xs += [g[1][0], g[1][2]]
                ys += [g[1][1], g[1][3]]
        dx, dy = MARGIN_PX - min(xs), MARGIN_PX - min(ys)
        self.W = geo.r2(max(xs) - min(xs) + 2 * MARGIN_PX)
        self.H = geo.r2(max(ys) - min(ys) + 2 * MARGIN_PX)
        self.off = (dx, dy)
        order = []
        for layer in LAYERS:
            order += [k for k, el in enumerate(self.els) if el[0] == layer]
        self.ref = dict((k, "e%04d" % (n + 1)) for n, k in enumerate(order))
        self.order = order

    def _v(self, name, v):
        dx, dy = self.off
        if name == "d":
            return "M " + " L ".join("%s,%s" % (geo.fmt(x+dx),geo.fmt(y+dy)) for x,y in v) + " Z"
        if name in ("x1", "x2", "x", "cx"):
            return geo.fmt(v + dx)
        if name in ("y1", "y2", "y", "cy"):
            return geo.fmt(v + dy)
        if name == "points":
            return " ".join("%s,%s" % (geo.fmt(p[0] + dx), geo.fmt(p[1] + dy))
                            for p in v)
        if isinstance(v, float) or isinstance(v, int):
            return geo.fmt(v)
        return str(v)

    def svg(self):
        out = ['<?xml version="1.0" encoding="UTF-8"?>',
               '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %s %s" '
               'width="%s" height="%s" data-dialect="%s">' % (
                   geo.fmt(self.W), geo.fmt(self.H), geo.fmt(self.W),
                   geo.fmt(self.H), DIALECT)]
        for layer in LAYERS:
            ks = [k for k in self.order if self.els[k][0] == layer]
            if not ks:
                continue
            out.append('<g data-layer="%s">' % layer)
            for k in ks:
                _l, tag, attrs, text, _it, _g = self.els[k]
                a = " ".join(['id="%s"' % self.ref[k]] +
                             ['%s="%s"' % (n, _esc(self._v(n, v)))
                              for n, v in attrs])
                if tag == "text":
                    out.append("<text %s>%s</text>" % (a, _esc(text)))
                else:
                    out.append("<%s %s/>" % (tag, a))
            out.append("</g>")
        out.append("</svg>")
        return "\n".join(out) + "\n"

    def object_map(self, public_hash, settings_hash):
        els = {}
        items = []
        for it in self.items:
            refs = sorted((self.ref[k] for k in self.item_els[it["id"]]),
                          key=lambda r: int(r[1:]))
            if not refs:
                continue
            d = dict(it)
            d["elements"] = refs
            items.append(d)
            for r in refs:
                els[r] = {"tag": self.els[self._k(r)][1], "item": it["id"]}
        objects = {}
        for oid in sorted(self.objects):
            o = self.objects[oid]
            parts, seen = [], set()
            for p in o["parts"]:
                key = (self.ref[p["element"]], "whole" if p["span"] == "whole"
                       else tuple(p["span"]))
                if key in seen:
                    continue
                seen.add(key)
                parts.append({"element": key[0], "span": p["span"]})
            parts.sort(key=lambda p: (int(p["element"][1:]),
                                      str(p["span"])))
            objects[oid] = {"kind": o["kind"], "parts": parts}
        return {"engine": COORD_ENGINE, "dialect": DIALECT,
                "figure": self.fig["id"], "public_hash": public_hash,
                "settings_hash": settings_hash, "elements": els,
                "display_items": items, "objects": objects,
                "construction": []}

    def _k(self, ref):
        if not hasattr(self, "_rev"):
            self._rev = dict((v, k) for k, v in self.ref.items())
        return self._rev[ref]

    def placements(self):
        dx, dy = self.off
        pts = dict((p, [geo.r2(c[0] + dx), geo.r2(c[1] + dy)])
                   for p, c in sorted(dict(self.dots, **getattr(self,"data_dots",{})).items()))
        # v6.12 fix_r1 (t08_b D3): model -> svg, like the number line's:
        # the VALUE on each axis when its printed numbers fix the step, else
        # the tick index (model "tick_index"); both from the public frame
        x0, y0 = dx, self.Y(0) + dy
        kx = self.sq / float(self.ax.step) if self.ax.step else self.sq
        ky = self.sq / float(self.ay.step) if self.ay.step else self.sq
        m2s = {"matrix": [_r6(kx), 0.0, 0.0, _r6(-ky),
                          _r6(x0 + self.sq * self.ax.zero),
                          _r6(y0 - self.sq * self.ay.zero)],
               "model": "sketch_index" if self.sketch is not None else
               "value" if (self.ax.step and self.ay.step)
               else "tick_index"}
        return {"canvas_px": [self.W, self.H], "square_px": geo.r2(self.sq),
                "model_to_svg": m2s,
                "axes": {
                    self.ax.aid: {"px_of_index": [geo.r2(dx), geo.r2(self.sq)],
                                  "zero_index": float(self.ax.zero) if self.ax.broken else self.ax.zero,
                                  "intervals": self.ax.n},
                    self.ay.aid: {"px_of_index": [geo.r2(self.Y(0) + dy),
                                                  geo.r2(-self.sq)],
                                  "zero_index": float(self.ay.zero) if self.ay.broken else self.ay.zero,
                                  "intervals": self.ay.n}},
                "points_px": pts,
                "page": {"unit": "pt", "pt_per_px": 0.75,
                         "size_pt": [geo.r2(self.W * 0.75),
                                     geo.r2(self.H * 0.75)]}}


def _r6(x):
    return round(float(x), 6)


def _gaps(lo, hi, cuts):
    """[lo, hi] minus the cut intervals, pieces >= 0.5 px."""
    out, cur = [], lo
    for a, b in cuts:
        if b <= cur or a >= hi:
            continue
        if a - cur >= 0.5:
            out.append((cur, a))
        cur = max(cur, b)
    if hi - cur >= 0.5:
        out.append((cur, hi))
    return out


def _esc(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(
        ">", "&gt;").replace('"', "&quot;")


def _attempt(pub, ix, fig, st, sq, flip):
    b = _Builder(pub, ix, fig, st, sq)
    b.flip = flip
    b.plan()
    b.plan_observations()
    b.draw_axes()
    b.draw_data()
    b.draw_facts()
    b.draw_points()
    b.draw_observations()
    b.label_axis_names()
    b.label_numbers()
    b.label_points()
    b.draw_grid()
    b.tick_objects()
    b.reading_objects()
    b.origin_objects()              # v6.16 gaps, corpus-v2 G2
    b.partial_polygons()            # v6.16 gaps, corpus-v2 G1
    return b


def _map_issues(svg_text, om, pub):
    import re
    ids = re.findall(r' id="(e[0-9]{4})"', svg_text)
    out = []
    if sorted(ids) != sorted(om["elements"]) or len(set(ids)) != len(ids) \
            or ids != ["e%04d" % (k + 1) for k in range(len(ids))]:
        out.append(_issue("MAP_NOT_TOTAL", om["figure"], "file ids %d vs map "
                          "%d" % (len(ids), len(om["elements"]))))
    ents = set(e["id"] for e in pub["entities"])
    ents.update(SDA.objects(pub, om["figure"]))
    ents.update(SLO.objects(pub, om["figure"]))
    facts = set(f["id"] for f in pub["facts"])
    owner = {}
    for it in om["display_items"]:
        if it["role"] not in ROLES:
            out.append(_issue("MAP_BAD_ROLE", it["id"], it["role"]))
        src = it["source"]
        if not src or (src.get("entity") and src["entity"] not in ents) or \
                (src.get("fact") and src["fact"] not in facts):
            out.append(_issue("MAP_BAD_SOURCE", it["id"], repr(src)))
        for e in it["elements"]:
            if e in owner:
                out.append(_issue("MAP_SHARED_ELEMENT", e, "%s and %s"
                                  % (owner[e], it["id"])))
            owner[e] = it["id"]
    for e, rec in om["elements"].items():
        if owner.get(e) != rec["item"]:
            out.append(_issue("MAP_NOT_TOTAL", e, "no single owner"))
    for oid, o in om["objects"].items():
        if oid not in ents and oid not in facts:
            out.append(_issue("MAP_BAD_PART", oid, "not a public id"))
        for p in o["parts"]:
            if p["element"] not in om["elements"]:
                out.append(_issue("MAP_BAD_PART", oid, p["element"]))
    return out


def render(public_spec, display_settings, engine_version):
    """engine.render's coordinate-plane branch (the version and the public
    gate already ran there)."""
    st = settings(display_settings)
    ix = S.Index(public_spec)
    fig = ix.figures.get(st["figure"])
    if fig is None:
        raise RenderRefused("RENDER_BAD_SETTINGS", "figure %r is not in the "
                            "public model" % st["figure"])
    if not is_coord(fig):
        raise RenderRefused("RENDER_BAD_SETTINGS", "figure %s is not a "
                            "coordinate plane" % fig["id"])
    # a crowded number: first it slides along its axis and the square
    # grows a little (x1.35 at most); only then may it cross its axis (or
    # the origin's '0' take another corner), the square growing to 26 px
    sq0 = float(st["square"])
    for flip, top in ((False, min(MAX_SQUARE_PX, sq0 * NOFLIP_GROW_MAX)),
                      (True, MAX_SQUARE_PX)):
        sq = sq0
        while True:
            b = _attempt(public_spec, ix, fig, st, sq, flip)
            crowded = any(i["code"] in ("RENDER_AXIS_CROWDED",
                                        "RENDER_LABEL_NO_PLACE")
                          for i in b.issues)
            if not crowded or not st["grow"] or sq >= top - 1e-9:
                break
            sq = min(top, round(sq * GROW, 2))
        if not crowded:
            break
    b.finish()
    svg = b.svg()
    # The optional data extension has no placement semantics when empty.
    # Preserve hashes of existing coordinate maps for absent/empty layouts;
    # every nonempty layout and all other settings remain fully hash-bound.
    hash_settings = dict(st)
    if hash_settings.get("data_layout") == []:
        hash_settings.pop("data_layout")
    settings_hash = hashlib.sha256(canon.dumps(hash_settings).encode("utf-8")) \
        .hexdigest()
    om = b.object_map(public_spec["public_hash"], settings_hash)
    issues = sorted(b.issues + _map_issues(svg, om, public_spec),
                    key=lambda i: (i["code"], i["where"], i["detail"]))
    validation = {"engine": COORD_ENGINE, "figure": fig["id"],
                  "status": "PASS" if not issues else "FAIL",
                  "issues": issues,
                  "checked": ["gate: public model only", "settings closed "
                              "(coordinate plane)", "every shown point at its "
                              "public coordinates / layout (they agree)",
                              "every printed number placed (never dropped), "
                              "free of strokes, dots and other labels",
                              "object map total, one owner per element, "
                              "sources resolve"],
                  "svg_sha256": hashlib.sha256(svg.encode("utf-8"))
                  .hexdigest()}
    pl = b.placements()
    pl["asked_square_px"] = geo.r2(sq0)
    pl["grown"] = abs(sq - sq0) > 1e-9
    return {"svg": svg, "object_map": om, "placements": pl,
            "validation": validation}


def dumps(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, indent=1) + \
        "\n"
