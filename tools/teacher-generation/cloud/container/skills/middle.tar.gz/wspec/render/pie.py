# -*- coding: utf-8 -*-
"""wspec.render.pie -- the PIE CHART family renderer (v6.16, BRIEF_V616 PIE
scope). Stdlib only. Owner: the pie engine (v616/progress/engine_pie.md).

    out = pie.render(public_model, display_settings, pie.ENGINE_VERSION)
        -> {"svg", "object_map", "placements", "validation"}
    (engine.render() hands a figure whose frame family is 'pie_chart' here:
    v616/HOOKS.txt section PIE.)

INPUT: only a PUBLIC model (pie.public_issues(): the house scan + the pie
scan; exact top-level keys; public_hash of the content). The renderer reads
the figure's frame and the GIVEN facts; it computes every other number
itself: a missing sector is the exact rest, an equal group shares the rest,
every span is value x 3.6 deg (percent) or the value (degree). Invalid data
is REFUSED with the named reasons of wspec.pie (RENDER_PIE_DATA_INVALID:
PIE_SUM_NOT_TOTAL ...): no SVG, no map, nothing is written.

DISPLAY SETTINGS (closed; defaults in brackets)
  figure (required)   radius [72] px (48 .. 150; the pie, 72 px = 54 pt =
  19 mm, the source's 18.5 mm)   build_radius [113.39] px (68.04 .. 170.08 =
  18 .. 45 mm at 0.75 pt/px; 113.39 = 30 mm)   margin [4] (2 .. 40)
  font_family [David Libre,serif] (| serif)   name_size [12.67] (12 | 12.67
  | 14)   value_size [10.67] (10.67 | 12)   palette [source] (| print:
  (v6.16 integrate) greys + black / grey strokes, the worksheet's neutral
  figure; the sheet path's default -- wspec_fam616.settings)
  row_radius [84 = 22.2 mm] (68.04 .. 150; v6.16 r2: the ONE radius of
  every disc of a row -- an optional key, absent from the settings (and
  their hash) unless given)

WHAT IS DRAWN (closed dialect wspec-pie-svg/1, svg_dialect_pie.json)
  per pie: one filled wedge per sector, stroked (its boundary rays and its
  arc; one sector = the whole disc, no stroke), in the declared order from
  the declared start (degrees clockwise from 12 o'clock) in the declared
  direction; the outline circle over them; the sector's name and GIVEN
  value inside its wedge (name above value) -- or, when the block cannot sit
  in its wedge with 3 px clear of every stroke (or the frame lists the
  sector as outside), outside next to the wedge with a leader line from
  inside the wedge; a legend (names = legend): one colour square + text per
  sector in order, left of the pie (single) / under it (side by side) /
  under both (shared); the caption and the total label under the pie.
  per build part: ONE empty circle (+ the centre dot when declared) (+ its
  declared caption under it, v6.16 r2).
  (v6.16 r2) layout row: the discs in one row, the FIRST part rightmost
  (read right to left), one radius (row_radius), the captions of all discs
  on one baseline; a REGION is drawn as one wedge and prints no name, its
  value label only inside it (never outside, never a leader); names none
  prints no name; a fraction pie prints no value.
  Nothing else: no angle arc, no right-angle mark, no tick, no degree scale,
  no radius, no number that is not a declared given label. A missing
  sector's value, an angle / percent the student finds, a count: never.
Deterministic: sorted iteration, fixed number format, no clock, no random.
"""
import hashlib
import json
import math
from fractions import Fraction

from .. import canon
from .. import pie as PIE
from .gate import RenderRefused

ENGINE_VERSION = "wspec-render-pie/1.0.0"
DIALECT_VERSION = "wspec-pie-svg/1"
INK, PAPER = "#000000", "#ffffff"
W_WEDGE, W_OUTLINE, W_LEADER, W_SWATCH, W_BUILD = "1", "1", "0.8", "0.8", \
    "1.33"
DOT_R = "2"
# the source's four pastels first (G8-T30 sheets), then four more
PALETTE = ("#a8c6e8", "#e8b4b4", "#b8d8b0", "#ddcf95", "#c9b8e0", "#f2c9a0",
           "#a8dcd9", "#e0c0d8")
STROKES = ("#2f3e4e", "#000000", "#595959", "#808080", "#a6a6a6", "#ffffff")
# (v6.16 integrate) the house PRINT palette: the worksheet's neutral-figure
# policy (BRIEF_V671 s3, check_didactic N4 / D3: ink and greys only -- a
# colour is never a hint) -- distinct greys for neighbouring sectors (each
# >= 4.5:1 with black text), strokes black / grey only (display setting
# palette="print"; "source", the default, keeps the source's pastels)
PRINT_PALETTE = ("#f2f2f2", "#cccccc", "#e3e3e3", "#b3b3b3", "#ececec",
                 "#c2c2c2", "#d9d9d9", "#a8a8a8")
PRINT_STROKES = STROKES[1:]
CLEAR = 3.0          # a label box this far from every stroke centre line
LABEL_SEP = 2.0      # two label boxes keep this apart
LINE_GAP = 1.5       # between the name line and the value line of a block
LEADER_IN = 0.72     # a leader starts at this fraction of r on the bisector
SWATCH = 10.0
LEGEND_GAP = 5.0     # swatch to text
LEGEND_ROW = 17.0
LEGEND_SIZE = 12
CAPTION_SIZE = 12.67
TOTAL_SIZE = 12
PART_GAP = 28.0
ROW_RADIUS = 84.0    # (v6.16 r2) a row's discs: 22.2 mm printed
ROW_MAX_PX = 640.0   # (v6.16 r2) a row fits the page: 169 mm at 0.75 pt/px
LAYERS = ("wedges", "lines", "marks", "labels")
ROLES = ("sector_wedge", "pie_outline", "sector_name_label",
         "sector_value_label", "leader_line", "legend_swatch", "legend_text",
         "caption", "total_label", "build_circle", "center_dot")
RHO = (0.6, 0.55, 0.65, 0.5, 0.7, 0.45, 0.75, 0.4, 0.8, 0.35)
DELTAS = (0, 6, -6, 12, -12, 18, -18, 24, -24, 30, -30, 40, -40, 50, -50,
          60, -60, 75, -75, 90, -90)


def _pos(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and \
        math.isfinite(v) and v > 0


SETTINGS = {
    "figure": (lambda v: isinstance(v, str), None),
    "radius": (lambda v: _pos(v) and 48 <= v <= 150, 72),
    "build_radius": (lambda v: _pos(v) and 68.04 <= v <= 170.08, 113.39),
    "margin": (lambda v: _pos(v) and 2 <= v <= 40, 4),
    "font_family": (lambda v: v in ("David Libre,serif", "serif"),
                    "David Libre,serif"),
    "name_size": (lambda v: v in (12, 12.67, 14), 12.67),
    "value_size": (lambda v: v in (10.67, 12), 10.67),
    # (v6.16 integrate) the palette of undeclared fills (see PRINT_PALETTE)
    "palette": (lambda v: v in ("source", "print"), "source"),
    # (v6.16 r2) OPTIONAL (default None = not added): the radius of every
    # disc of a row; 68.04 px = 18 mm keeps an empty disc printable
    "row_radius": (lambda v: _pos(v) and 68.04 <= v <= 150, None),
}


def settings(ds):
    if not isinstance(ds, dict):
        raise RenderRefused("RENDER_BAD_SETTINGS", "not a dict")
    extra = sorted(set(ds) - set(SETTINGS))
    if extra:
        raise RenderRefused("RENDER_BAD_SETTINGS", "unknown key(s) %s (the "
                            "pie settings are closed: %s)" % (
                                extra, sorted(SETTINGS)))
    out = {}
    for k, (ok, dflt) in sorted(SETTINGS.items()):
        if k not in ds:
            if k == "figure":
                raise RenderRefused("RENDER_BAD_SETTINGS", "figure missing")
            if dflt is None:
                # (v6.16 r2) an optional setting: absent unless given, so
                # the settings hash of every earlier figure is unchanged
                continue
            out[k] = dflt
            continue
        if not ok(ds[k]):
            raise RenderRefused("RENDER_BAD_SETTINGS", "%s=%r" % (k, ds[k]))
        out[k] = ds[k]
    return out


# ------------------------------------------------------------ the gate ---
def require_public(pub):
    """A public model and nothing else (the house gate's three tests, with
    the pie half of the scan): exact top-level keys, no scan issue, the
    public_hash of its own content."""
    from .. import project as P
    if not isinstance(pub, dict):
        raise RenderRefused("RENDER_NOT_PUBLIC", "not a dict")
    want = P.PUBLIC_KEYS["top"]
    if set(pub) != want:
        raise RenderRefused("RENDER_NOT_PUBLIC", "top-level keys %s are not "
                            "the public model's (a private model, a spec or "
                            "an answer store is refused)" % sorted(
                                set(pub) ^ want))
    bad = PIE.public_issues(pub)
    if bad:
        raise RenderRefused("RENDER_NOT_PUBLIC", "scan: %s" % "; ".join(
            str(i) for i in bad[:5]))
    body = dict((k, v) for k, v in pub.items() if k != "public_hash")
    if PIE.public_hash(body) != pub.get("public_hash"):
        raise RenderRefused("RENDER_NOT_PUBLIC", "public_hash does not match "
                            "the content (edited after it was built)")


# ------------------------------------------------------------- numbers ---
def _r2(x):
    v = round(x + 0.0, 2)
    return 0.0 if v == 0 else v


def _fmt(x):
    v = _r2(x)
    if v < 0:
        raise ValueError("negative coordinate %r" % x)
    s = ("%.2f" % v).rstrip("0").rstrip(".")
    return s or "0"


def _polar(r, deg):
    """page offset of the point at distance r, deg clockwise from 12."""
    a = math.radians(deg)
    return (r * math.sin(a), -r * math.cos(a))


def _angle(dx, dy):
    """degrees clockwise from 12 of the offset (dx, dy), in [0, 360)."""
    a = math.degrees(math.atan2(dx, -dy)) % 360.0
    return 0.0 if a >= 360.0 - 1e-12 else a


def _in_arc(a, lo, hi):
    """a within the clockwise interval lo..hi (degrees, hi - lo <= 360)."""
    span = hi - lo
    return (a - lo) % 360.0 <= span + 1e-9


# ------------------------------------------------------------- colours ---
def _lum(hexc):
    c = [int(hexc[i:i + 2], 16) / 255.0 for i in (1, 3, 5)]
    c = [v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
         for v in c]
    return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]


def contrast(a, b):
    la, lb = _lum(a), _lum(b)
    hi, lo = max(la, lb), min(la, lb)
    return (hi + 0.05) / (lo + 0.05)


# ----------------------------------------------------------------- text ---
# advance widths in em: max(DavidLibre-Regular, a Times-like fallback) --
# the page prints David Libre, the checker's MuPDF raster a fallback serif;
# a box must hold both (v616/pie_engine/gen_widths.py for David Libre)
_DAVID = {u" ": 0.21, u"%": 0.5, u",": 0.36, u"-": 0.36, u".": 0.36,
          u":": 0.36, u"°": 0.26, u"–": 0.48, u"׳": 0.26, u"״": 0.36,
          u"א": 0.64, u"ב": 0.5, u"ג": 0.36, u"ד": 0.5, u"ה": 0.64,
          u"ו": 0.36, u"ז": 0.36, u"ח": 0.64, u"ט": 0.64, u"י": 0.36,
          u"ך": 0.5, u"כ": 0.5, u"ל": 0.5, u"ם": 0.64, u"מ": 0.64,
          u"ן": 0.36, u"נ": 0.36, u"ס": 0.64, u"ע": 0.5, u"ף": 0.5,
          u"פ": 0.51, u"ץ": 0.5, u"צ": 0.5, u"ק": 0.64, u"ר": 0.5,
          u"ש": 0.64, u"ת": 0.63}
_FALLBACK = {u"%": 0.84, u"°": 0.4, u".": 0.25, u",": 0.25, u":": 0.28,
             u" ": 0.25, u"–": 0.5, u"-": 0.34}
_DESC = set(u"ךןףץקgjpqy,")


def _em(ch):
    if ch.isdigit():
        return 0.5
    if u"A" <= ch <= u"Z":
        return 0.74
    if u"a" <= ch <= u"z":
        return 0.56
    return max(_DAVID.get(ch, 0.64), _FALLBACK.get(ch, 0.0))


def text_width(t, fs):
    return sum(_em(c) for c in t) * fs * 1.03


def text_extent(t, fs):
    """(ascent, descent) of the ink above / below the baseline."""
    asc = 0.9 * fs if u"ל" in t else 0.76 * fs
    desc = 0.27 * fs if any(c in _DESC for c in t) else 0.08 * fs
    return asc, desc


def _has_rtl(t):
    return any(u"א" <= c <= u"ת" for c in t)


def _btype(c):
    if u"א" <= c <= u"ת" or c in u"׳״":
        return "R"
    if (u"A" <= c <= u"Z") or (u"a" <= c <= u"z"):
        return "L"
    if c.isdigit():
        return "EN"
    if c in u"%°":
        return "ET"
    if c in u".,:":
        return "CS"
    if c == u"-":
        return "ES"
    if c == u" ":
        return "WS"
    return "ON"


def visual(text):
    """The VISUAL (left-to-right) order of a label whose paragraph is
    right-to-left (it has a Hebrew letter): UAX #9 rules W4-W7, N1-N2,
    I1-I2 and L2 for the closed label alphabet (no explicit embeddings, no
    mirrored characters). A label without a Hebrew letter is LTR as is."""
    if not _has_rtl(text):
        return text
    t = list(text)
    ty = [_btype(c) for c in t]
    n = len(t)
    # W4: a single ES / CS between two EN -> EN
    for i in range(1, n - 1):
        if ty[i] in ("ES", "CS") and ty[i - 1] == "EN" and \
                ty[i + 1] == "EN":
            ty[i] = "EN"
    # W5: a sequence of ET next to EN -> EN
    changed = True
    while changed:
        changed = False
        for i in range(n):
            if ty[i] == "ET" and ((i > 0 and ty[i - 1] == "EN") or
                                  (i + 1 < n and ty[i + 1] == "EN")):
                ty[i] = "EN"
                changed = True
    # W6: remaining separators / terminators -> ON
    ty = ["ON" if x in ("ES", "CS", "ET") else x for x in ty]
    # W7: EN after a strong L (sos = R) -> L
    last = "R"
    for i in range(n):
        if ty[i] in ("L", "R"):
            last = ty[i]
        elif ty[i] == "EN" and last == "L":
            ty[i] = "L"
    # N1 / N2: neutral runs between strong types (EN counts as R)
    i = 0
    while i < n:
        if ty[i] in ("WS", "ON"):
            j = i
            while j < n and ty[j] in ("WS", "ON"):
                j += 1
            before = "R" if i == 0 else ("R" if ty[i - 1] in ("R", "EN")
                                         else "L")
            after = "R" if j == n else ("R" if ty[j] in ("R", "EN")
                                        else "L")
            d = before if before == after else "R"
            for k in range(i, j):
                ty[k] = d
            i = j
        else:
            i += 1
    # I1 / I2 at paragraph level 1: R -> 1, L / EN -> 2
    lv = [1 if x == "R" else 2 for x in ty]
    # L2: reverse runs at level >= 2, then the whole line (level >= 1)
    out = list(t)
    i = 0
    while i < n:
        if lv[i] >= 2:
            j = i
            while j < n and lv[j] >= 2:
                j += 1
            out[i:j] = out[i:j][::-1]
            i = j
        else:
            i += 1
    return u"".join(out[::-1])


class _Block(object):
    """A label block: one or two lines [(hook, logical text, font size,
    fact id or None)], centred on (cx, cy)."""

    def __init__(self, lines):
        self.lines = lines
        self.metrics = []
        h = 0.0
        w = 0.0
        for k, (hook, t, fs, _f) in enumerate(lines):
            asc, desc = text_extent(t, fs)
            tw = text_width(t, fs)
            self.metrics.append((asc, desc, tw))
            h += asc + desc + (LINE_GAP if k else 0.0)
            w = max(w, tw)
        self.w, self.h = w, h
        self.cx = self.cy = 0.0

    def box(self, cx=None, cy=None):
        cx = self.cx if cx is None else cx
        cy = self.cy if cy is None else cy
        return (cx - self.w / 2.0, cy - self.h / 2.0, cx + self.w / 2.0,
                cy + self.h / 2.0)

    def line_boxes(self, cx=None, cy=None):
        """the box of each line (centred on the block's x)"""
        cx = self.cx if cx is None else cx
        cy = self.cy if cy is None else cy
        y = cy - self.h / 2.0
        out = []
        for k, (asc, desc, tw) in enumerate(self.metrics):
            if k:
                y += LINE_GAP
            out.append((cx - tw / 2.0, y, cx + tw / 2.0, y + asc + desc))
            y += asc + desc
        return out

    def baselines(self):
        y = self.cy - self.h / 2.0
        out = []
        for k, (asc, desc, _tw) in enumerate(self.metrics):
            if k:
                y += LINE_GAP
            out.append(y + asc)
            y += asc + desc
        return out


# ------------------------------------------------------------ geometry ---
def _seg_seg_d(a, b, c, d):
    def cross(o, p, q):
        return (p[0] - o[0]) * (q[1] - o[1]) - (p[1] - o[1]) * (q[0] - o[0])
    d1, d2 = cross(c, d, a), cross(c, d, b)
    d3, d4 = cross(a, b, c), cross(a, b, d)
    if ((d1 > 0) != (d2 > 0)) and ((d3 > 0) != (d4 > 0)):
        return 0.0
    return min(_pt_seg_d(a, c, d), _pt_seg_d(b, c, d), _pt_seg_d(c, a, b),
               _pt_seg_d(d, a, b))


def _pt_seg_d(p, a, b):
    vx, vy = b[0] - a[0], b[1] - a[1]
    L = vx * vx + vy * vy
    t = 0.0 if L == 0 else max(0.0, min(1.0, ((p[0] - a[0]) * vx +
                                            (p[1] - a[1]) * vy) / L))
    return math.hypot(p[0] - a[0] - t * vx, p[1] - a[1] - t * vy)


def _seg_box_d(a, b, box):
    x0, y0, x1, y1 = box
    if x0 <= a[0] <= x1 and y0 <= a[1] <= y1:
        return 0.0
    if x0 <= b[0] <= x1 and y0 <= b[1] <= y1:
        return 0.0
    sides = [((x0, y0), (x1, y0)), ((x1, y0), (x1, y1)),
             ((x1, y1), (x0, y1)), ((x0, y1), (x0, y0))]
    return min(_seg_seg_d(a, b, c, d) for c, d in sides)


def _box_gap(a, b):
    dx = max(a[0] - b[2], b[0] - a[2], 0.0)
    dy = max(a[1] - b[3], b[1] - a[3], 0.0)
    return math.hypot(dx, dy) if (dx and dy) else max(dx, dy)


def _box_far(box):
    """largest distance from the origin to a corner of the box"""
    return max(math.hypot(x, y) for x in (box[0], box[2])
               for y in (box[1], box[3]))


def _box_near(box):
    """smallest distance from the origin to the box"""
    dx = max(box[0], 0.0, -box[2])
    dy = max(box[1], 0.0, -box[3])
    return math.hypot(dx, dy)


def _union(boxes):
    boxes = [b for b in boxes if b]
    return (min(b[0] for b in boxes), min(b[1] for b in boxes),
            max(b[2] for b in boxes), max(b[3] for b in boxes))


# --------------------------------------------------------------- build ---
class _El(object):
    def __init__(self, tag, layer, attrs, text=None):
        self.tag, self.layer, self.attrs, self.text = tag, layer, attrs, text
        self.id = None
        self.item = None


class _Item(object):
    def __init__(self, iid, role, source, text=None):
        self.id, self.role, self.source, self.text = iid, role, source, text
        self.els = []


class _Part(object):
    """One part laid out around its own centre (0, 0)."""

    def __init__(self, kind, eid, r):
        self.kind, self.eid, self.r = kind, eid, r
        self.cx = self.cy = 0.0
        self.bounds = [0.0] * 5          # boundary angles (cw from 12)
        self.wedges = []                 # (sid, lo, hi)
        self.blocks = []                 # (sid, block, "in" | "out")
        self.leaders = {}                # sid -> [(x, y), ...] (local)
        self.fill = {}
        self.stroke = None
        self.text_fill = {}
        self.legend = []                 # (sid, text, fact) rows
        self.legend_box = None           # local box
        self.caption = None
        self.total = None                # (text, fact id)
        self.under = []                  # (kind, text, y_local, fact)
        self.box = (-r, -r, r, r)
        self.centre_dot = False


class _Build(object):
    def __init__(self, pub, fig, st):
        self.pub, self.fig, self.st = pub, fig, st
        self.ix = PIE.PieIndex(pub)
        self.fr = fig["frame"]
        self.issues = []
        self.items = []
        self.els = []
        self.parts = []
        self.hidden = set()
        self.shared = None

    def issue(self, code, where, detail):
        self.issues.append({"code": code, "where": where, "detail": detail})

    def item(self, role, source, text=None):
        it = _Item("d%03d" % (len(self.items) + 1), role, source, text)
        self.items.append(it)
        return it

    def add(self, it, tag, layer, attrs, text=None):
        el = _El(tag, layer, attrs, text)
        el.item = it
        it.els.append(el)
        self.els.append(el)
        return el

    # ------------------------------------------------------------ data --
    def resolve(self):
        probs = []
        self.res = {}
        for i, p in enumerate(self.fr["parts"]):
            if p["part"] != "pie":
                continue
            r = PIE.resolve(self.ix, p)
            self.res[p["pie"]] = r
            for code, detail in r.problems:
                probs.append("%s (%s): %s" % (code, p["pie"], detail))
        if probs:
            raise RenderRefused("RENDER_PIE_DATA_INVALID", "; ".join(probs))
        # the values the student finds: never printed (validation)
        for pid, r in sorted(self.res.items()):
            for s in r.order:
                v = r.value[s]
                ang = v * Fraction(360) / r.total
                if r.source[s] != "given":
                    self.hidden.add(v)
                if r.unit == "fraction":
                    # (v6.16 r2) a fraction pie prints no number: its
                    # angles and percents are both the student's
                    self.hidden.add(ang)
                    self.hidden.add(ang * Fraction(100, 360))
                else:
                    self.hidden.add(ang if r.unit == "percent" else
                                    ang * Fraction(100, 360))
        for f in self.pub.get("facts") or []:
            if f.get("role") == "target" and f.get("rel") in (
                    "sector_value", "sector_angle", "sector_percent"):
                s = (f.get("args") or [None])[0]
                for pid, r in self.res.items():
                    if s in r.value:
                        v = r.value[s]
                        ang = v * Fraction(360) / r.total
                        self.hidden.add({"sector_value": v,
                                         "sector_angle": ang,
                                         "sector_percent":
                                         ang * Fraction(100, 360)}[
                                             f["rel"]])

    def given_value_fact(self, sid):
        drawn = set(self.fig.get("draws") or [])
        for f in self.ix.facts_about(sid, "sector_value", ("given",)):
            if f["id"] in drawn:
                return f
        return None

    def total_fact(self, pid):
        drawn = set(self.fig.get("draws") or [])
        for f in self.ix.facts_about(pid, "pie_total", ("given",)):
            if f["id"] in drawn:
                return f
        return None

    # ---------------------------------------------------------- layout --
    def plan(self):
        st = self.st
        r_pie, r_build = float(st["radius"]), float(st["build_radius"])
        row = self.fr["layout"] == "row"
        if row:
            # (v6.16 r2) every disc of a row has ONE radius
            r_pie = r_build = float(st.get("row_radius") or ROW_RADIUS)
        elif self.fr.get("same_size"):
            # one radius for every part; next to a build circle the pie
            # takes the build size (the circle keeps 18..45 mm)
            if any(p["part"] == "build" for p in self.fr["parts"]):
                r_pie = r_build
            else:
                r_build = r_pie
        for p in self.fr["parts"]:
            if p["part"] == "build":
                pt = _Part("build", p["circle"], r_build)
                pt.centre_dot = bool(p["centre_dot"])
                pt.side = p.get("side")
                pt.caption = p.get("caption")                   # v6.16 r2
                self.parts.append(pt)
                self.finish_build(pt)
                continue
            pt = _Part("pie", p["pie"], r_pie)
            pt.side = p.get("side")
            pt.spec = p
            self.parts.append(pt)
            self.plan_pie(pt, p)
        if self.fr.get("shared_legend"):
            self.plan_shared_legend()
        if self.fr["layout"] == "side_by_side":
            self.parts.sort(key=lambda q: 0 if q.side == "left" else 1)
        if row:
            self.align_row()

    def finish_build(self, pt):
        """(v6.16 r2) an empty disc's box: the circle + its caption"""
        pt.core = (-pt.r, -pt.r, pt.r, pt.r)
        pt.core_bottom = pt.r
        pt.legend_box = None
        self._under(pt, pt.r)

    def align_row(self):
        """(v6.16 r2) the captions of every disc of a row on ONE baseline,
        under the lowest disc / label of the row"""
        y0 = max(p.core_bottom for p in self.parts)
        caps = [p.caption for p in self.parts if p.caption]
        if not caps:
            return
        asc = max(text_extent(c, CAPTION_SIZE)[0] for c in caps)
        for p in self.parts:
            self._under(p, p.core_bottom, y_cap=y0 + 6.0 + asc)

    def plan_pie(self, pt, p):
        r = self.res[p["pie"]]
        order = r.order
        spans = r.spans()
        start = Fraction(p["start"])
        cw = p["direction"] == "clockwise"
        acc = start
        pt.exact = {}
        for s, sp in zip(order, spans):
            if cw:
                lo, hi = acc, acc + sp
                acc = hi
            else:
                lo, hi = acc - sp, acc
                acc = lo
            lo = lo % 360
            hi = lo + sp
            pt.exact[s] = (lo, hi)
            pt.wedges.append((s, float(lo), float(lo) + float(sp)))
        # fills: declared, else the palette (neighbours differ, cyclic)
        fills = list(p.get("fills") or [])
        pal = PRINT_PALETTE if self.st.get("palette") == "print" else PALETTE
        if not fills:
            n = len(order)
            fills = [pal[i % len(pal)] for i in range(n)]
            if n > 1 and fills[-1] == fills[0]:
                for c in pal:
                    if c != fills[0] and c != fills[-2]:
                        fills[-1] = c
                        break
        for s, c in zip(order, fills):
            pt.fill[s] = c
        self.colours(pt)
        # label blocks
        st = self.st
        outside = set(p.get("outside") or [])
        regions = set(p.get("regions") or [])                  # v6.16 r2
        for s, lo, hi in pt.wedges:
            lines = []
            if p["names"] == "in_sector" and s not in regions:
                lines.append(("name", self.ix.ents[s]["name"],
                              st["name_size"], None))
            vf = self.given_value_fact(s)
            if vf is not None and p["values"] == "in_sector":
                lab = PIE.value_label(PIE._q(vf["value"]), p["unit"])
                if lab is None:
                    raise RenderRefused("RENDER_PIE_VALUE_FORM", "%s: the "
                                        "value %s has no terminating decimal "
                                        "form" % (s, vf["value"]))
                lines.append(("val", lab, st["value_size"], vf["id"]))
            if not lines:
                continue
            blk = _Block(lines)
            if s in regions:
                # (v6.16 r2) a region's label stays INSIDE it: no leader
                # ever crosses a region
                if self.place_in(pt, s, lo, hi, blk):
                    pt.blocks.append((s, blk, "in"))
                else:
                    self.issue("RENDER_LABEL_NO_PLACE", s, "the label of "
                               "region %s has no place inside it (a "
                               "region's label never goes outside)" % s)
                continue
            if s not in outside and self.place_in(pt, s, lo, hi, blk):
                pt.blocks.append((s, blk, "in"))
            else:
                pt.blocks.append((s, blk, "out"))
        self.place_all_out(pt)
        # legend rows
        if p["names"] == "legend" and not self.fr.get("shared_legend"):
            for s in order:
                t = self.ix.ents[s]["name"]
                vf = self.given_value_fact(s)
                fact = None
                if p["values"] == "legend" and vf is not None:
                    lab = PIE.value_label(PIE._q(vf["value"]), p["unit"])
                    if lab is None:
                        raise RenderRefused("RENDER_PIE_VALUE_FORM", "%s: no "
                                            "terminating decimal" % s)
                    t = t + u" " + lab
                    fact = vf["id"]
                pt.legend.append((s, t, fact))
        pt.caption = p.get("caption")
        tf = self.total_fact(p["pie"])
        if tf is not None:
            lab = PIE.total_label(PIE._q(tf["value"]))
            if lab is None:
                raise RenderRefused("RENDER_PIE_VALUE_FORM", "total %s" %
                                    tf["value"])
            pt.total = (lab, tf["id"])
        self.finish_part(pt)

    def colours(self, pt):
        """stroke: the first dialect grey with >= 3:1 against every fill;
        text in a wedge: ink, else paper, with >= 4.5:1 against its fill."""
        order = [w[0] for w in pt.wedges]
        fills = [pt.fill[s] for s in order]
        pt.stroke = None
        strokes = PRINT_STROKES if self.st.get("palette") == "print" else \
            STROKES
        for c in strokes:
            if all(contrast(c, f) >= 3.0 for f in fills):
                pt.stroke = c
                break
        if pt.stroke is None:
            pt.stroke = strokes[0]
            self.issue("RENDER_PIE_CONTRAST", pt.eid, "no stroke colour "
                       "with 3:1 against every fill %s" % fills)
        for s in order:
            f = pt.fill[s]
            if contrast(INK, f) >= 4.5:
                pt.text_fill[s] = INK
            elif contrast(PAPER, f) >= 4.5:
                pt.text_fill[s] = PAPER
            else:
                pt.text_fill[s] = INK
                self.issue("RENDER_PIE_CONTRAST", s, "no text colour with "
                           "4.5:1 against the fill %s" % f)

    def rays(self, pt):
        if len(pt.wedges) < 2:
            return []
        out = []
        for _s, lo, _hi in pt.wedges:
            out.append(((0.0, 0.0), _polar(pt.r, lo)))
        return out

    def fits_in(self, pt, lo, hi, box):
        """the box (local) inside the wedge lo..hi with CLEAR to strokes."""
        if _box_far(box) > pt.r - CLEAR:
            return False
        if len(pt.wedges) < 2:
            return True
        for a, b in self.rays(pt):
            if _seg_box_d(a, b, box) < CLEAR:
                return False
        c = ((box[0] + box[2]) / 2.0, (box[1] + box[3]) / 2.0)
        return _in_arc(_angle(*c), lo, hi)

    def place_in(self, pt, s, lo, hi, blk):
        mid = (lo + hi) / 2.0
        for rho in RHO:
            c = _polar(rho * pt.r, mid)
            box = blk.box(c[0], c[1])
            if self.fits_in(pt, lo, hi, box):
                blk.cx, blk.cy = c
                return True
        return False

    def place_all_out(self, pt):
        """outside labels: in wedge order, else reversed, else smallest
        wedge first -- the first order that places every label (each label
        at its cheapest place: straight out along its bisector preferred);
        otherwise the validation FAILS naming the label."""
        outs = [(s, blk) for s, blk, w in pt.blocks if w == "out"]
        if not outs:
            return
        spans = dict((w[0], w[2] - w[1]) for w in pt.wedges)
        orders = [outs, outs[::-1], sorted(outs, key=lambda x: (
            spans[x[0]], [w[0] for w in pt.wedges].index(x[0])))]
        inside = [b.box() for _s, b, w in pt.blocks if w == "in"]
        best = None
        for order in orders:
            pt.leaders = {}
            placed = list(inside)
            miss = []
            for s, blk in order:
                lo, hi = [(a, b) for x, a, b in pt.wedges if x == s][0]
                if self.place_out(pt, s, lo, hi, blk, placed):
                    placed.append(blk.box())
                else:
                    miss.append(s)
            got = (dict(pt.leaders), dict((s, (blk.cx, blk.cy))
                                          for s, blk in outs))
            if best is None or len(miss) < len(best[0]):
                best = (miss, got)
            if not miss:
                break
        miss, (leaders, cents) = best
        pt.leaders = leaders
        for s, blk in outs:
            blk.cx, blk.cy = cents[s]
        for s in miss:
            self.issue("RENDER_LABEL_NO_PLACE", s, "no place for the outside "
                       "label of %s" % s)

    def place_out(self, pt, s, lo, hi, blk, placed):
        mid = (lo + hi) / 2.0
        a = _polar(LEADER_IN * pt.r, mid)
        rim = _polar(pt.r, mid)
        others = self.rays(pt)
        lead_others = [v for k, v in pt.leaders.items() if k != s]
        best = None
        for d in range(int(pt.r) + 14, int(pt.r) + 200, 5):
            for dl in DELTAS:
                cost = (d - pt.r) + 2.0 * abs(dl)
                if best is not None and cost >= best[0]:
                    continue
                c = _polar(float(d), mid + dl)
                box = blk.box(c[0], c[1])
                if _box_near(box) < pt.r + CLEAR + 2.0:
                    continue
                if any(_box_gap(box, q) < LABEL_SEP for q in placed):
                    continue
                # never on an earlier leader
                if any(_seg_box_d(p0, p1, box) < 1.5 for other in lead_others
                       for p0, p1 in zip(other, other[1:])):
                    continue
                e = self._line_exit(c, a, blk)
                pts = [a, e] if dl == 0 else [a, rim, e] \
                    if self._elbow_ok(rim, e, mid) else None
                if pts is None:
                    continue
                if not self._leader_ok(pt, pts, others, placed, lead_others,
                                       box, lo, hi):
                    continue
                best = (cost, c, pts)
        if best is None:
            return False
        blk.cx, blk.cy = best[1]
        pt.leaders[s] = best[2]
        return True

    @staticmethod
    def _elbow_ok(rim, e, mid):
        return math.hypot(e[0] - rim[0], e[1] - rim[1]) > 2.0

    def _line_exit(self, c, a, blk):
        """where the leader from a meets the label: the nearest point of
        the line boxes (grown 1 px) on the segment a -> c, else the point
        of the line boxes nearest a"""
        best = None
        for lb in blk.line_boxes(c[0], c[1]):
            g = (lb[0] - 1.0, lb[1] - 1.0, lb[2] + 1.0, lb[3] + 1.0)
            e = self._box_exit(((g[0] + g[2]) / 2.0, (g[1] + g[3]) / 2.0),
                               a, g, pad=0.0)
            d = math.hypot(e[0] - a[0], e[1] - a[1])
            if best is None or d < best[0]:
                best = (d, e)
        return best[1]

    @staticmethod
    def _box_exit(c, a, box, pad=1.5):
        """the point where the segment c -> a leaves the box grown 1.5 px"""
        x0, y0, x1, y1 = box[0] - pad, box[1] - pad, box[2] + pad, \
            box[3] + pad
        dx, dy = a[0] - c[0], a[1] - c[1]
        ts = []
        for t in ((x0 - c[0]) / dx if dx else None,
                  (x1 - c[0]) / dx if dx else None,
                  (y0 - c[1]) / dy if dy else None,
                  (y1 - c[1]) / dy if dy else None):
            if t is not None and t > 0:
                px, py = c[0] + t * dx, c[1] + t * dy
                if x0 - 1e-6 <= px <= x1 + 1e-6 and \
                        y0 - 1e-6 <= py <= y1 + 1e-6:
                    ts.append(t)
        t = min(ts) if ts else 0.0
        return (c[0] + t * dx, c[1] + t * dy)

    def _leader_ok(self, pt, pts, rays, placed, leads, box, lo, hi):
        segs = list(zip(pts, pts[1:]))
        for a, b in segs:
            for ra, rb in rays:
                if _seg_seg_d(a, b, ra, rb) < 1.0:
                    return False
            for q in placed:
                if _seg_box_d(a, b, q) < 1.0:
                    return False
            for other in leads:
                for c, d in zip(other, other[1:]):
                    if _seg_seg_d(a, b, c, d) < 2.0:
                        return False
        # inside the disc the leader stays in its own wedge
        for a, b in segs:
            for k in range(0, 21):
                t = k / 20.0
                x, y = a[0] + t * (b[0] - a[0]), a[1] + t * (b[1] - a[1])
                if math.hypot(x, y) < pt.r - 0.5 and not _in_arc(
                        _angle(x, y), lo, hi):
                    return False
        return True

    def plan_shared_legend(self):
        pies = [p for p in self.parts if p.kind == "pie"]
        first = pies[0].spec
        rows = []
        for s in first["order"]:
            rows.append((s, self.ix.ents[s]["name"], None))
        self.shared = {"rows": rows, "fill": dict(
            (self.ix.ents[s]["name"], pies[0].fill[s]) for s in
            first["order"])}
        # the same names carry the same fills in both pies
        for q in pies[1:]:
            for s in q.spec["order"]:
                q.fill[s] = self.shared["fill"][self.ix.ents[s]["name"]]
            self.colours(q)

    def legend_size(self, rows):
        w = max(text_width(t, LEGEND_SIZE) for _s, t, _f in rows)
        return w + LEGEND_GAP + SWATCH, LEGEND_ROW * len(rows)

    def finish_part(self, pt):
        """the part's local box: disc + outside labels + legend + caption +
        total."""
        boxes = [(-pt.r, -pt.r, pt.r, pt.r)]
        boxes += [b.box() for _s, b, _w in pt.blocks]
        core = _union(boxes)
        y = core[3]
        if pt.legend and self.fr["layout"] == "single":
            lw, lh = self.legend_size(pt.legend)
            x1 = core[0] - PART_GAP
            pt.legend_box = (x1 - lw, -lh / 2.0, x1, lh / 2.0)
        elif pt.legend:
            lw, lh = self.legend_size(pt.legend)
            pt.legend_box = (-lw / 2.0, y + 8.0, lw / 2.0, y + 8.0 + lh)
            y = pt.legend_box[3]
        pt.core = core
        pt.core_bottom = y
        self._under(pt, y)

    def _under(self, pt, y, y_cap=None):
        """the caption (at y_cap when a row aligns it, v6.16 r2) and the
        total under the part's core; its local box"""
        core = pt.core
        pt.under = []
        if pt.caption:
            asc, desc = text_extent(pt.caption, CAPTION_SIZE)
            yb = y + 6.0 + asc if y_cap is None else y_cap
            pt.under.append(("cap", pt.caption, yb, None, CAPTION_SIZE))
            y = yb + desc
        if pt.total:
            asc, desc = text_extent(pt.total[0], TOTAL_SIZE)
            yb = y + 5.0 + asc
            pt.under.append(("total", pt.total[0], yb, pt.total[1],
                             TOTAL_SIZE))
            y = yb + desc
        boxes = [core]
        if pt.legend_box:
            boxes.append(pt.legend_box)
        for _k, t, yb, _f, fs in pt.under:
            w = text_width(t, fs)
            asc, desc = text_extent(t, fs)
            boxes.append((-w / 2.0, yb - asc, w / 2.0, yb + desc))
        pt.box = _union(boxes)

    def arrange(self):
        m = float(self.st["margin"])
        top = min(p.box[1] for p in self.parts)
        x = m
        # (v6.16 r2) a row is read right to left: its first part is placed
        # rightmost
        seq = list(reversed(self.parts)) if self.fr["layout"] == "row" \
            else self.parts
        for p in seq:
            p.cx = x - p.box[0]
            p.cy = m - top
            x = p.cx + p.box[2] + PART_GAP
        W = x - PART_GAP + m
        H = max(p.cy + p.box[3] for p in self.parts) + m
        if self.shared:
            rows = self.shared["rows"]
            lw, lh = self.legend_size(rows)
            mid = sum(p.cx for p in self.parts) / float(len(self.parts))
            y0 = H - m + 8.0
            self.shared["box"] = (mid - lw / 2.0, y0, mid + lw / 2.0,
                                  y0 + lh)
            W = max(W, mid + lw / 2.0 + m)
            H = y0 + lh + m
        self.W, self.H = W, H
        if self.fr["layout"] == "row" and W > ROW_MAX_PX:
            self.issue("RENDER_ROW_TOO_WIDE", self.fig["id"], "the row is "
                       "%.0f px wide (%.0f mm at 0.75 pt/px), more than the "
                       "page's %.0f px" % (W, W * 0.75 * 25.4 / 72.0,
                                          ROW_MAX_PX))
        if W > 1200 or H > 1200:
            raise RenderRefused("RENDER_PIE_TOO_LARGE", "canvas %.0f x %.0f "
                                "px" % (W, H))

    # ------------------------------------------------------------ draw --
    def draw(self):
        ff = self.st["font_family"]
        for p in self.parts:
            if p.kind == "build":
                continue
            n = len(p.wedges)
            for s, lo, hi in p.wedges:
                it = self.item("sector_wedge", {"entity": s})
                d = self.wedge_d(p, *p.exact[s])
                self.add(it, "path", "wedges", [
                    ("d", d), ("fill", p.fill[s]),
                    ("stroke", p.stroke if n > 1 else "none")] +
                    ([("stroke-width", W_WEDGE),
                      ("stroke-linejoin", "round")] if n > 1 else []) +
                    [("data-pie", "wedge"), ("data-for", s)])
            it = self.item("pie_outline", {"entity": p.eid})
            self.add(it, "circle", "lines", [
                ("cx", _fmt(p.cx)), ("cy", _fmt(p.cy)), ("r", _fmt(p.r)),
                ("fill", "none"), ("stroke", p.stroke if n > 1 or
                                   contrast(p.stroke, PAPER) >= 3.0
                                   else INK),
                ("stroke-width", W_OUTLINE), ("data-pie", "outline"),
                ("data-for", p.eid)])
            for s, pts in sorted(p.leaders.items(), key=lambda kv: [
                    w[0] for w in p.wedges].index(kv[0])):
                it = self.item("leader_line", {"entity": s})
                d = "M %s %s" % (_fmt(p.cx + pts[0][0]),
                                 _fmt(p.cy + pts[0][1]))
                for q in pts[1:]:
                    d += " L %s %s" % (_fmt(p.cx + q[0]), _fmt(p.cy + q[1]))
                self.add(it, "path", "lines", [
                    ("d", d), ("fill", "none"), ("stroke", INK),
                    ("stroke-width", W_LEADER), ("stroke-linecap", "round"),
                    ("data-pie", "leader"), ("data-for", s)])
        for p in self.parts:
            if p.kind == "build":
                it = self.item("build_circle", {"entity": p.eid})
                self.add(it, "circle", "marks", [
                    ("cx", _fmt(p.cx)), ("cy", _fmt(p.cy)),
                    ("r", _fmt(p.r)), ("fill", "none"), ("stroke", INK),
                    ("stroke-width", W_BUILD), ("data-pie", "bcirc"),
                    ("data-for", p.eid)])
                if p.centre_dot:
                    it = self.item("center_dot", {"entity": p.eid})
                    self.add(it, "circle", "marks", [
                        ("cx", _fmt(p.cx)), ("cy", _fmt(p.cy)),
                        ("r", DOT_R), ("fill", INK), ("data-pie", "bdot"),
                        ("data-for", p.eid)])
                continue
            if p.legend:
                self.draw_legend_marks(p.legend, p.legend_box, p.cx, p.cy,
                                       p.fill)
        if self.shared:
            fills = {}
            for s, name, _f in self.shared["rows"]:
                fills[s] = self.shared["fill"][name]
            self.draw_legend_marks(self.shared["rows"], self.shared["box"],
                                   0.0, 0.0, fills)
        # labels
        for p in self.parts:
            if p.kind == "build":
                # (v6.16 r2) an empty disc's declared caption, under it
                for kind, t, yb, fid, fs in p.under:
                    it = self.item("caption", {"entity": p.eid}, t)
                    self.text(it, p.cx, p.cy + yb, t, fs, "middle", "bcap",
                              p.eid, ff, INK)
                continue
            for s, blk, where in sorted(p.blocks, key=lambda b: [
                    w[0] for w in p.wedges].index(b[0])):
                ys = blk.baselines()
                for (hook, t, fs, fid), yb in zip(blk.lines, ys):
                    role = "sector_name_label" if hook == "name" else \
                        "sector_value_label"
                    src = {"entity": s} if fid is None else \
                        {"fact": fid, "entity": s}
                    it = self.item(role, src, t)
                    fill = p.text_fill[s] if where == "in" else INK
                    self.text(it, p.cx + blk.cx, p.cy + yb, t, fs, "middle",
                              hook, s, ff, fill)
            if p.legend:
                self.draw_legend_text(p.legend, p.legend_box, p.cx, p.cy, ff)
            for kind, t, yb, fid, fs in p.under:
                if kind == "cap":
                    it = self.item("caption", {"entity": p.eid}, t)
                else:
                    it = self.item("total_label", {"fact": fid,
                                                   "entity": p.eid}, t)
                self.text(it, p.cx, p.cy + yb, t, fs, "middle", kind, p.eid,
                          ff, INK)
        if self.shared:
            self.draw_legend_text(self.shared["rows"], self.shared["box"],
                                  0.0, 0.0, ff)

    def draw_legend_marks(self, rows, box, cx, cy, fills):
        x1 = cx + box[2]
        for k, (s, _t, _f) in enumerate(rows):
            yc = cy + box[1] + LEGEND_ROW * k + LEGEND_ROW / 2.0
            it = self.item("legend_swatch", {"entity": s})
            xa, xb = x1 - SWATCH, x1
            ya, yb = yc - SWATCH / 2.0, yc + SWATCH / 2.0
            pts = "%s,%s %s,%s %s,%s %s,%s" % (
                _fmt(xa), _fmt(ya), _fmt(xb), _fmt(ya), _fmt(xb), _fmt(yb),
                _fmt(xa), _fmt(yb))
            self.add(it, "polygon", "marks", [
                ("points", pts), ("fill", fills[s]), ("stroke", INK),
                ("stroke-width", W_SWATCH), ("data-pie", "swatch"),
                ("data-for", s)])

    def draw_legend_text(self, rows, box, cx, cy, ff):
        x1 = cx + box[2] - SWATCH - LEGEND_GAP
        for k, (s, t, fid) in enumerate(rows):
            yc = cy + box[1] + LEGEND_ROW * k + LEGEND_ROW / 2.0
            asc, desc = text_extent(t, LEGEND_SIZE)
            yb = yc + (asc - desc) / 2.0
            src = {"entity": s} if fid is None else {"fact": fid,
                                                     "entity": s}
            it = self.item("legend_text", src, t)
            self.text(it, x1, yb, t, LEGEND_SIZE, "end", "leg", s, ff, INK)

    def text(self, it, x, y, t, fs, anchor, hook, eid, ff, fill):
        attrs = [("x", _fmt(x)), ("y", _fmt(y)), ("font-size",
                                                  _fmt(float(fs))),
                 ("font-family", ff), ("text-anchor", anchor),
                 ("fill", fill)]
        if _has_rtl(t):
            attrs += [("direction", "ltr"), ("unicode-bidi",
                                             "bidi-override")]
        attrs += [("data-pie", hook), ("data-for", eid)]
        self.add(it, "text", "labels", attrs, visual(t))

    def wedge_d(self, p, lo, hi):
        """lo, hi exact (Fraction) degrees: a boundary shared by two
        wedges is the same float, so the same rounded point in both."""
        span = hi - lo
        k = max(1, int(math.ceil(float(span) / 90.0 - 1e-9)))
        pts = [_polar(p.r, float((lo + span * i / k) % 360))
               for i in range(k + 1)]
        d = "M %s %s L %s %s" % (_fmt(p.cx), _fmt(p.cy),
                                 _fmt(p.cx + pts[0][0]),
                                 _fmt(p.cy + pts[0][1]))
        rr = _fmt(p.r)
        for q in pts[1:]:
            d += " A %s %s 0 0 1 %s %s" % (rr, rr, _fmt(p.cx + q[0]),
                                           _fmt(p.cy + q[1]))
        return d + " Z"

    # ------------------------------------------------------ validation --
    def check_hidden(self):
        import re
        for el in self.els:
            # a given value label / total / legend value is its own given
            # (ownership); every other text is scanned
            if el.tag != "text" or "fact" in el.item.source:
                continue
            logical = el.item.text or ""
            toks = re.findall(r"[0-9]+(?:\.[0-9]+)?", logical)
            for t in toks:
                if Fraction(t) in self.hidden:
                    self.issue("RENDER_PRINTS_HIDDEN", el.item.id, "%r "
                               "prints %s, a value the student finds"
                               % (logical, t))
        for el in self.els:
            if el.item.role == "sector_value_label":
                s = el.item.source["entity"]
                for pid, r in self.res.items():
                    if s in r.source and r.source[s] != "given":
                        self.issue("RENDER_PRINTS_HIDDEN", el.item.id,
                                   "%s is a missing / equal sector: its "
                                   "value is never printed" % s)

    def number(self):
        order = [el for layer in LAYERS for el in self.els
                 if el.layer == layer]
        for k, el in enumerate(order):
            el.id = "e%04d" % (k + 1)
        self.order = order

    def svg(self):
        W, H = _fmt(math.ceil(self.W * 100) / 100.0), \
            _fmt(math.ceil(self.H * 100) / 100.0)
        out = ['<?xml version="1.0" encoding="UTF-8"?>',
               '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %s %s" '
               'width="%s" height="%s">' % (W, H, W, H)]
        for layer in LAYERS:
            els = [el for el in self.order if el.layer == layer]
            if not els:
                continue
            out.append('<g data-layer="%s">' % layer)
            for el in els:
                attrs = " ".join('%s="%s"' % (k, _esc(v)) for k, v in
                                 [("id", el.id)] + el.attrs)
                if el.tag == "text":
                    out.append("<text %s>%s</text>" % (attrs, _esc(el.text)))
                else:
                    out.append("<%s %s/>" % (el.tag, attrs))
            out.append("</g>")
        out.append("</svg>")
        return "\n".join(out) + "\n"

    def object_map(self, public_hash, settings_hash):
        elements = dict((el.id, {"tag": el.tag, "item": el.item.id})
                        for el in self.order)
        items = []
        for it in self.items:
            d = {"id": it.id, "role": it.role, "source": dict(it.source),
                 "elements": sorted(el.id for el in it.els)}
            if it.text is not None:
                d["text"] = it.text
            items.append(d)

        def parts(els):
            return [{"element": e, "span": "whole"} for e in sorted(set(els))]
        objs = {}
        by_ent = {}
        for it in self.items:
            ent = it.source.get("entity")
            by_ent.setdefault(ent, []).extend(el.id for el in it.els)
        shared_rows = {}
        if self.shared:
            for it in self.items:
                if it.role in ("legend_swatch", "legend_text"):
                    name = self.ix.ents[it.source["entity"]]["name"]
                    shared_rows.setdefault(name, []).extend(
                        el.id for el in it.els)
        for p in self.parts:
            if p.kind == "build":
                objs[p.eid] = {"kind": "build_circle",
                               "parts": parts(by_ent.get(p.eid, []))}
                continue
            pie_els = list(by_ent.get(p.eid, []))
            for s, _lo, _hi in p.wedges:
                own = list(by_ent.get(s, []))
                if self.shared:
                    own = [e for e in own if self.el_role(e) not in (
                        "legend_swatch", "legend_text")]
                    own += shared_rows.get(self.ix.ents[s]["name"], [])
                objs[s] = {"kind": "sector", "parts": parts(own)}
                pie_els += own
            objs[p.eid] = {"kind": "pie", "parts": parts(pie_els)}
            if p.legend:
                leg = [el.id for it in self.items if it.role in (
                    "legend_swatch", "legend_text") and
                    it.source["entity"] in [w[0] for w in p.wedges]
                    for el in it.els]
                objs["legend:" + p.eid[4:]] = {"kind": "legend",
                                               "parts": parts(leg)}
        if self.shared:
            leg = [e for v in shared_rows.values() for e in v]
            objs["legend:shared"] = {"kind": "legend", "parts": parts(leg)}
            for p in self.parts:
                if p.kind == "pie":
                    objs[p.eid]["parts"] = parts(
                        [q["element"] for q in objs[p.eid]["parts"]] + leg)
        return {"engine": ENGINE_VERSION, "dialect": DIALECT_VERSION,
                "figure": self.fig["id"], "family": PIE.FAMILY,
                "public_hash": public_hash, "settings_hash": settings_hash,
                "elements": elements, "display_items": items,
                "objects": objs}

    def el_role(self, eid):
        for el in self.order:
            if el.id == eid:
                return el.item.role
        return None

    def placements(self):
        parts = []
        for p in self.parts:
            parts.append({"part": p.kind, "entity": p.eid,
                          "centre_px": [_r2(p.cx), _r2(p.cy)],
                          "radius_px": _r2(p.r)})
        return {"canvas_px": [_r2(self.W), _r2(self.H)], "parts": parts,
                "page": {"unit": "pt", "pt_per_px": 0.75,
                         "size_pt": [_r2(self.W * 0.75),
                                     _r2(self.H * 0.75)]}}


def _esc(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(
        ">", "&gt;").replace('"', "&quot;")


def _map_issues(svg_text, om, pub):
    import re
    ids = re.findall(r' id="(e[0-9]{4})"', svg_text)
    out = []
    if sorted(ids) != sorted(om["elements"]) or len(set(ids)) != len(ids):
        out.append({"code": "MAP_NOT_TOTAL", "where": om["figure"],
                    "detail": "file ids %d vs map %d" % (
                        len(ids), len(om["elements"]))})
    ents = set(e["id"] for e in pub["entities"])
    facts = set(f["id"] for f in pub["facts"])
    owner = {}
    for it in om["display_items"]:
        if it["role"] not in ROLES:
            out.append({"code": "MAP_BAD_ROLE", "where": it["id"],
                        "detail": it["role"]})
        src = it["source"]
        if (src.get("entity") and src["entity"] not in ents) or \
                (src.get("fact") and src["fact"] not in facts):
            out.append({"code": "MAP_BAD_SOURCE", "where": it["id"],
                        "detail": repr(src)})
        for e in it["elements"]:
            if e in owner:
                out.append({"code": "MAP_SHARED_ELEMENT", "where": e,
                            "detail": "%s and %s" % (owner[e], it["id"])})
            owner[e] = it["id"]
    return out


def render(public_spec, display_settings, engine_version=ENGINE_VERSION):
    """See the module docstring. Raises RenderRefused for an input it does
    not accept (never a partial output)."""
    if engine_version != ENGINE_VERSION:
        raise RenderRefused("RENDER_VERSION", "this engine is %s, not %r"
                            % (ENGINE_VERSION, engine_version))
    require_public(public_spec)
    st = settings(display_settings)
    fig = [g for g in public_spec.get("figures") or []
           if g.get("id") == st["figure"]]
    if not fig:
        raise RenderRefused("RENDER_BAD_SETTINGS", "figure %r is not in the "
                            "public model" % st["figure"])
    fig = fig[0]
    if not PIE.is_pie_figure(fig):
        raise RenderRefused("RENDER_BAD_SETTINGS", "figure %s has no "
                            "pie_chart frame" % fig["id"])
    shape = PIE.frame_issues(public_spec, fig)
    if shape:
        raise RenderRefused("RENDER_PIE_FRAME", "; ".join(
            str(i) for i in shape[:5]))
    b = _Build(public_spec, fig, st)
    b.resolve()
    b.plan()
    b.arrange()
    b.draw()
    b.check_hidden()
    b.number()
    svg = b.svg()
    sh = hashlib.sha256(canon.dumps(st).encode("utf-8")).hexdigest()
    om = b.object_map(public_spec["public_hash"], sh)
    issues = sorted(b.issues + _map_issues(svg, om, public_spec),
                    key=lambda i: (i["code"], i["where"], i["detail"]))
    validation = {"engine": ENGINE_VERSION, "figure": fig["id"],
                  "status": "PASS" if not issues else "FAIL",
                  "issues": issues,
                  "checked": ["gate: public model only (house scan + pie "
                              "scan, hash)", "settings closed",
                              "frame grammar", "data exact and valid "
                              "(refused otherwise)",
                              "labels inside their wedge 3 px clear of "
                              "every stroke, or outside with a leader",
                              "stroke 3:1 / text 4.5:1 contrast",
                              "no hidden value printed", "object map total"],
                  "svg_sha256": hashlib.sha256(svg.encode("utf-8"))
                  .hexdigest()}
    return {"svg": svg, "object_map": om, "placements": b.placements(),
            "validation": validation}


def dumps(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, indent=1) + \
        "\n"
