# -*- coding: utf-8 -*-
"""highlight(svg, object_map, object_id) -> the SAME figure with an
emphasis overlay under it (brief section 4).

The figure's bytes are kept: one group
    <g data-layer="highlight" data-object="<object id>"> ... </g>
is inserted right after the <svg> start tag, so it is painted UNDER the
figure (the figure's own ink stays on top, the overlay shows as a halo).
It holds one element per PART of the object in the object map, and
nothing else:
  a whole line / mark / outline -> a copy of its geometry, thick, in the
      highlight colour, data-hl="<element id>";
  a piece [X, Y] of a longer element -> a line from X to Y (the drawn
      points), data-hl="<element id>" data-span="XY";
  a point dot -> a disk at the same centre; a label -> a box behind its
      glyph box.
It adds no text, no hook, no point, no value: it only emphasises what is
already drawn -- with ONE exception (v6.9, Codex F3): an ANGLE whose figure
prints no arc and no right-angle mark for it gets a FOCUS ARC in the
overlay, derived from its three drawn points alone:
    <path data-focus="<angle id>" d="M .. L .." fill="none" .../>
centred on the vertex, from one arm to the other through the angle's own
(non-reflex) sector, radius FOCUS_R_PX clipped to FOCUS_ARM_SHARE of the
shorter drawn arm; no number, no equality mark, never a second arc. It
lives only in the temporary overlay -- the printed figure never has it. verify_highlight() re-reads both files and checks exactly
that (the independent checker, wspec/check/, re-does it on its own)."""
import re
import xml.etree.ElementTree as ET

from . import geo

HL = "#f59f00"
HL_SOFT = "#ffe8a3"
HL_W = "6"
# the box behind a label: its estimated glyph box grown by this, so it holds
# the ink of a wide letter (M, W) too (pilot_build: M's ink left the 1.5 px
# box); the checker wants the box to hug the ink within 6 px
LABEL_BOX_PAD_PX = 2.0
NS = "{http://www.w3.org/2000/svg}"
FOCUS_R_PX = 18.0          # the focus arc's radius ...
FOCUS_MIN_R_PX = 9.0       # ... never below this (the checker's arc range)
FOCUS_ARM_SHARE = 0.45     # ... nor past this share of the shorter arm
FOCUS_STEP_DEG = 5.0       # one chord per this many degrees
FOCUS_MAX_SWEEP_DEG = 179.0  # a straight angle has no sector to show
_NAMES = re.compile(r"[A-Z][1-9]?'{0,3}")
_START = re.compile(r"<svg\b[^>]*>\n")


class HighlightError(Exception):
    pass


def _elements(svg):
    root = ET.fromstring(svg.encode("utf-8"))
    out, pts = {}, {}
    for el in root.iter():
        t = el.tag.replace(NS, "")
        if el.get("id"):
            out[el.get("id")] = (t, el)
        if t == "circle" and el.get("data-pt"):
            pts[el.get("data-pt")] = (float(el.get("cx")), float(el.get("cy")))
    return out, pts


def _glyph_box(el):
    fs = float(el.get("font-size"))
    x, y = float(el.get("x")), float(el.get("y"))
    text = el.text or ""
    w, h = geo.ink_width(text, fs), geo.GLYPH_H * fs
    cx = x + {"start": w / 2, "middle": 0.0, "end": -w / 2}[
        el.get("text-anchor", "start")]
    cy = y - h / 2
    # (v6.12) a letter with a descent (the axis letter y) reaches below
    # the baseline; (v6.16 fix r1) so does the tail of a capital Q (as the
    # number-line highlight, nline_hl.py, already has it): without it the
    # box behind a 'Q' label missed the ink of its tail (G7-T08 b q2,
    # HIGHLIGHT_EXACT_ELEMENTS)
    dsc = 0.22 * fs if any(ch in "gjpqyQ" for ch in text) else 0.0
    return (cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2 + dsc)


def _overlay_el(part, els, pts):
    eid = part["element"]
    if eid not in els:
        raise HighlightError("part element %s is not in the figure" % eid)
    t, el = els[eid]
    span = part["span"]
    if span != "whole":
        x, y = span
        if t not in ("line", "polygon") or x not in pts or y not in pts:
            raise HighlightError("span %s%s on %s" % (x, y, eid))
        p, q = pts[x], pts[y]
        return ('<line data-hl="%s" data-span="%s%s" x1="%s" y1="%s" x2="%s" '
                'y2="%s" stroke="%s" stroke-width="%s" stroke-linecap="round"'
                '/>' % (eid, x, y, geo.fmt(p[0]), geo.fmt(p[1]),
                        geo.fmt(q[0]), geo.fmt(q[1]), HL, HL_W))
    if t == "line":
        return ('<line data-hl="%s" x1="%s" y1="%s" x2="%s" y2="%s" '
                'stroke="%s" stroke-width="%s" stroke-linecap="round"/>' % (
                    eid, el.get("x1"), el.get("y1"), el.get("x2"),
                    el.get("y2"), HL, HL_W if el.get("data-mark") is None
                    else "4"))
    if t == "polyline":
        return ('<polyline data-hl="%s" points="%s" fill="none" stroke="%s" '
                'stroke-width="4" stroke-linecap="round" stroke-linejoin='
                '"round"/>' % (eid, el.get("points"), HL))
    if t == "path":
        return ('<path data-hl="%s" d="%s" fill="none" stroke="%s" '
                'stroke-width="4" stroke-linecap="round" stroke-linejoin='
                '"round"/>' % (eid, el.get("d"), HL))
    if t == "polygon":
        return ('<polygon data-hl="%s" points="%s" fill="none" stroke="%s" '
                'stroke-width="%s" stroke-linejoin="round"/>' % (
                    eid, el.get("points"), HL, HL_W))
    if t == "circle":
        return ('<circle data-hl="%s" cx="%s" cy="%s" r="5" fill="%s" '
                'stroke="none"/>' % (eid, el.get("cx"), el.get("cy"), HL))
    if t == "text":
        x0, y0, x1, y1 = geo.inflate(_glyph_box(el), LABEL_BOX_PAD_PX)
        return ('<rect data-hl="%s" x="%s" y="%s" width="%s" height="%s" '
                'fill="%s" stroke="none"/>' % (
                    eid, geo.fmt(max(x0, 0)), geo.fmt(max(y0, 0)),
                    geo.fmt(x1 - max(x0, 0)), geo.fmt(y1 - max(y0, 0)),
                    HL_SOFT))
    raise HighlightError("cannot highlight <%s>" % t)


def focus_arc(object_id, pts):
    """The d= of the focus arc of angle object_id ('ang:ACB', vertex C)
    from the drawn points, or None when it has no sector to show."""
    import math
    if not object_id.startswith("ang:"):
        return None
    names = _NAMES.findall(object_id[4:])
    if "".join(names) != object_id[4:] or len(names) != 3 or \
            any(n not in pts for n in names):
        return None
    a, v, b = pts[names[0]], pts[names[1]], pts[names[2]]
    la, lb = geo.d(v, a), geo.d(v, b)
    if min(la, lb) <= 0:
        return None
    ua = math.atan2(a[1] - v[1], a[0] - v[0])
    ub = math.atan2(b[1] - v[1], b[0] - v[0])
    sw = (ub - ua + math.pi) % (2 * math.pi) - math.pi     # (-pi, pi]
    if abs(math.degrees(sw)) > FOCUS_MAX_SWEEP_DEG or \
            abs(math.degrees(sw)) < 1.0:
        return None
    r = min(FOCUS_R_PX, FOCUS_ARM_SHARE * min(la, lb))
    if r < FOCUS_MIN_R_PX:
        return None
    n = max(2, int(math.ceil(abs(math.degrees(sw)) / FOCUS_STEP_DEG)))
    ps = []
    for k in range(n + 1):
        t_ = ua + sw * k / float(n)
        ps.append("%s %s" % (geo.fmt(v[0] + r * math.cos(t_)),
                             geo.fmt(v[1] + r * math.sin(t_))))
    return "M " + " L ".join(ps)


def _needs_focus(obj, object_id, els):
    """an angle whose parts print no arc / right-angle mark of it."""
    if not object_id.startswith("ang:") or obj.get("kind") not in (
            None, "angle"):
        return False
    for p in obj.get("parts") or []:
        t = els.get(p["element"])
        if t and (t[1].get("data-mark") or "").split(" ")[0] in (
                "arc", "right"):
            return False
    return True


def _family_hl(object_map):
    """(v6.16 integrate) the highlight module of a graph / pie figure"""
    om = object_map or {}
    if om.get("dialect") == "wspec-graph-svg/1":
        from ..graph import highlight as _ghl
        return _ghl
    if om.get("family") == "pie_chart":
        from . import pie_hl as _phl
        return _phl
    return None


def highlight(svg, object_map, object_id):
    if _family_hl(object_map) is not None:            # (v6.16 integrate)
        return _family_hl(object_map).highlight(svg, object_map, object_id)
    if (object_map or {}).get("family") == "number_line":   # (v6.12)
        from . import nline_hl
        return nline_hl.highlight(svg, object_map, object_id)
    obj = (object_map.get("objects") or {}).get(object_id)
    if obj is None:
        raise HighlightError("%s is not an object of figure %s (the drawing "
                             "does not show it)" % (object_id,
                                                    object_map.get("figure")))
    els, pts = _elements(svg)
    lines = [_overlay_el(p, els, pts) for p in obj["parts"]]
    if _needs_focus(obj, object_id, els):
        d_ = focus_arc(object_id, pts)
        if d_:
            lines.append('<path data-focus="%s" d="%s" fill="none" stroke='
                         '"%s" stroke-width="3" stroke-linecap="round" '
                         'stroke-linejoin="round"/>' % (object_id, d_, HL))
    m = _START.search(svg)
    if m is None:
        raise HighlightError("no <svg> start tag")
    block = '<g data-layer="highlight" data-object="%s">\n%s\n</g>\n' % (
        object_id, "\n".join(lines))
    return svg[:m.end()] + block + svg[m.end():]


_BLOCK = re.compile(r'<g data-layer="highlight" data-object="([^"]*)">\n'
                    r'(.*?)\n</g>\n', re.S)


def verify_highlight(base_svg, hl_svg, object_map, object_id):
    """[problem] -- empty when the overlay marks EXACTLY the object's parts,
    each coinciding with the drawn element it names, and the figure itself
    is untouched."""
    if _family_hl(object_map) is not None:            # (v6.16 integrate)
        return _family_hl(object_map).verify_highlight(base_svg, hl_svg,
                                                       object_map, object_id)
    if (object_map or {}).get("family") == "number_line":   # (v6.12)
        from . import nline_hl
        return nline_hl.verify_highlight(base_svg, hl_svg, object_map,
                                         object_id)
    out = []
    blocks = list(_BLOCK.finditer(hl_svg))
    if len(blocks) != 1:
        return ["%d highlight blocks, want 1" % len(blocks)]
    b = blocks[0]
    if b.group(1) != object_id:
        out.append("the block names %r, not %r" % (b.group(1), object_id))
    if hl_svg[:b.start()] + hl_svg[b.end():] != base_svg:
        out.append("the figure's bytes changed")
    obj = (object_map.get("objects") or {}).get(object_id)
    if obj is None:
        return out + ["%s is not in the object map" % object_id]
    want = sorted((p["element"], "" if p["span"] == "whole" else
                   "".join(p["span"])) for p in obj["parts"])
    els, pts = _elements(base_svg)
    try:
        ov = ET.fromstring(('<g xmlns="http://www.w3.org/2000/svg">%s</g>'
                            % b.group(2)).encode("utf-8"))
    except ET.ParseError as e:
        return out + ["overlay is not XML: %s" % e]
    got = []
    focus = [el for el in ov if el.get("data-focus") is not None]
    want_focus = _needs_focus(obj, object_id, els) and \
        focus_arc(object_id, pts) is not None
    if len(focus) != (1 if want_focus else 0):
        out.append("%d focus arc(s); the angle wants %d" % (
            len(focus), 1 if want_focus else 0))
    for el in focus:
        if el.get("data-focus") != object_id or \
                el.tag.replace(NS, "") != "path" or \
                el.get("d") != focus_arc(object_id, pts) or \
                el.get("fill") != "none" or (el.text or "").strip():
            out.append("the focus arc is not the arc of %s's own three "
                       "points" % object_id)
    for el in ov:
        if el.get("data-focus") is not None:
            continue
        t = el.tag.replace(NS, "")
        a = dict(el.attrib)
        if t == "text" or (el.text or "").strip():
            out.append("the overlay prints text")
        bad = sorted(k for k in a if k.startswith("data-") and
                     k not in ("data-hl", "data-span"))
        if bad:
            out.append("overlay element carries %s" % bad)
        ref, span = a.get("data-hl"), a.get("data-span", "")
        got.append((ref or "", span))
        if ref not in els:
            out.append("overlay names %r, not an element" % ref)
            continue
        rt, rel = els[ref]
        if span:
            names = re.findall(r"[A-Z][1-9]?'{0,3}", span)
            if t != "line" or len(names) != 2 or any(n not in pts
                                                      for n in names):
                out.append("span %r on %s" % (span, ref))
                continue
            p, q = (float(a["x1"]), float(a["y1"])), (float(a["x2"]),
                                                      float(a["y2"]))
            if geo.d(p, pts[names[0]]) > 0.011 or \
                    geo.d(q, pts[names[1]]) > 0.011:
                out.append("span %s ends are not at the drawn points" % span)
            segs = []
            if rt == "line":
                segs = [((float(rel.get("x1")), float(rel.get("y1"))),
                         (float(rel.get("x2")), float(rel.get("y2"))))]
            elif rt == "polygon":
                vs = [tuple(float(v) for v in xy.split(","))
                      for xy in rel.get("points").split(" ")]
                segs = [(vs[i], vs[(i + 1) % len(vs)])
                        for i in range(len(vs))]
            if not any(geo.seg_dist(p, u, v) <= 0.05 and
                       geo.seg_dist(q, u, v) <= 0.05 for u, v in segs):
                out.append("span %s does not lie on %s" % (span, ref))
            continue
        same = {"line": ("x1", "y1", "x2", "y2"), "polyline": ("points",),
                "path": ("d",), "polygon": ("points",),
                "circle": ("cx", "cy")}.get(rt)
        if rt == "text":
            box = geo.inflate(_glyph_box(rel), LABEL_BOX_PAD_PX)
            x, y = float(a.get("x", -1)), float(a.get("y", -1))
            if t != "rect" or abs(x - geo.r2(max(box[0], 0))) > 0.011 or \
                    abs(y - geo.r2(max(box[1], 0))) > 0.011:
                out.append("the box of %s is not its label's" % ref)
        elif same is None or t != rt or any(a.get(k) != rel.get(k)
                                            for k in same):
            out.append("overlay %s does not coincide with the element"
                       % ref)
    if sorted(got) != want:
        out.append("overlay parts %s != the object's parts %s"
                   % (sorted(got), want))
    return out
