# -*- coding: utf-8 -*-
"""render(public_spec, display_settings, engine_version) ->
{svg, object_map, placements, validation}   (brief section 2)

* INPUT: only a validated public model (gate.require_public) and closed
  display settings (gate.settings); the private model / answer store is
  refused (RENDER_NOT_PUBLIC) before anything is drawn. engine_version must
  be ENGINE_VERSION: the same input + settings + version give the same
  bytes (no clock, no randomness, sorted iteration, fixed number format).
* OUTPUT: an SVG in the closed dialect wspec-svg/5 (every painted element
  and text numbered e0001.. in document order), and an OBJECT MAP:
    elements      -- every element id -> {tag, item}: the ONE display item
                     that drew it (no unmapped ink, no shared ownership);
    display_items -- {id, role, source {entity | fact (+ entity)}, elements}
                     (an angle = its arms + arc/right mark + caption, each
                     a display item of its own source);
    objects       -- every public entity the drawing shows -> its PARTS:
                     {element, span 'whole' | [X, Y] (the piece of a longer
                     drawn element between the points X and Y)}, so a side
                     of a polygon, a half of a diagonal or an arm of an
                     angle maps back to the element that draws it;
    construction  -- for a figure of a construction item: what is given,
                     what is shown, what the student does (never drawn).
* WHAT IS DRAWN is exactly the figure's shown set (its listed entities and
  everything its drawn facts are drawn on -- baseline._figure_shows) plus
  the marks / captions of its drawn facts (DRAW table). Nothing else: no
  target, no answer, no construction result.
* VALIDATION: the renderer's own report -- geomcheck on the produced file
  (dialect + geometry + labels + marks, against the PUBLIC model), the map
  totality, the construction declaration against the drawing, and every
  drawn fact it could not mark. It is NOT the independent checker
  (wspec/check/, brief section 3), which must re-measure the output."""
import hashlib
import json
import math
import os
import tempfile

from .. import baseline as B
from .. import bidi as BIDI
from .. import canon
from .. import geomcheck as G
from .. import schema as S
from .. import templates as TT
from . import gate
from . import geo
from . import layout as L
from .gate import RenderRefused

# 1.0.1 (v6.9 fix r1, N1/P1): a segment caption straddles a drawn point that
# splits the segment, and that point's name stands on the other side
# 1.0.2 (v6.9 fix r2, E1b): a label with a Hebrew letter is written in
# VISUAL order under direction="ltr" unicode-bidi="bidi-override"
# (wspec-svg/5) -- WeasyPrint prints SVG text without bidi, so the logical
# '5 ס״מ' printed its unit reversed; and (P4) display vertex_dots='corner'
# prints a polygon's vertex with the hidden corner dot (the builder's look)
ENGINE_VERSION = "wspec-render/1.0.3"   # 1.0.3 (v6.10 fix r1): adjacent arcs
DIALECT_VERSION = "wspec-svg/5"

INK = "#000000"
W_OBJ = "1.5"          # objects (segments, lines, rays, outlines)
W_MARK = "1"           # marks (arcs, right-angle marks, ticks)
W_INNER_THIN = "1"     # (v6.9 fix r1, P4) inner segments with inner_stroke=thin
LINE_EXT_PX = 14.0     # a line / ray runs this far past its last point
RIGHT_LEG_PX = 8.0     # right-angle mark leg (geomcheck: 5..20)
TICK_HALF_PX = 4.0     # half a tick (geomcheck: 4..16 long)
TICK_STEP_PX = 3.0     # between the strokes of tick2 / tick3
ARC_STEP_PX = 3.0      # between the strokes of arc2 / arc3
# (1.0.3, v6.10 fix r1 S-1) two arcs at ONE vertex that share an arm (the
# two halves of a bisected angle) at one radius print as ONE arc over the
# whole angle: the later one steps out (or in) by this much, as the v6.7.3
# figures draw a bisector's two arcs
ARC_ADJ_PX = 5.0
ARC_SAMPLE_DEG = 4.0   # arc sampling (sagitta << 0.5 px)
COLLINEAR_PX = 0.02    # a point on a drawn straight element (px, unrounded)
LABEL_PAD_PX = 1.0     # clearance of a label box from strokes and marks
LABEL_GAP_PX = 2.0     # clearance between two label boxes
NEAR_MARGIN_PX = 3.0   # a label nearer its own point / vertex by this much
DOT_CLEAR_PX = 2.5     # a label box this far from every dot (beyond its r)
CAPTION_ARC_GAP_PX = 6.0   # a retried larger arc runs this inside the value
ARC_MAX_PX = 36.0          # geomcheck / checker ARC_MAX_R_PX is 40
CAPTION_ARC_MAX_PX = 14.0  # an angle value box this near its own arc
CAPTION_OWN_ARC_MARGIN_PX = 3.0  # and nearer its own arc than another by this
                           # (checker CAPTION_ARC_PX 20, with ink margin)
LABEL_NEAR_PX = 24.0   # geomcheck LABEL_NEAR_PX
LABEL_VALUE_PX = 60.0  # geomcheck LABEL_VALUE_PX
INNER_PT_PX = 0.5      # (fix r1) a drawn point this near a captioned segment's
                       # line, inside it, splits it (its caption straddles it)
ROLES = ("point", "point_name", "line_name", "segment", "line", "ray", "polygon",
         "polygon_side", "angle_arm", "angle_arc", "right_mark", "tick",
         "parallel_arrow",
         "angle_caption", "segment_caption")
LAYERS = ("lines", "marks", "points", "labels")
MAX_COUNT = 3          # tick3 / arc3
ARC_MIN_PX = 9.0       # geomcheck ARC_MIN_R_PX is 8
# (v6.17, V4) a point this near a side's line (px, unrounded) is ON the line;
# and this far past an end, OUTSIDE the side (on its extension)
EXT_ON_LINE_PX = 0.05
EXT_OUT_PX = 0.5
PAR_LEG_PX = 5.0       # parallel arrow leg (geomcheck: 3..10)
PAR_HALF_DEG = 30.0    # leg off the segment (geomcheck: 20..60)
PAR_STEP_PX = 3.5      # between the chevrons of par2 / par3


class _Item(object):
    def __init__(self, iid, role, source):
        self.id, self.role, self.source = iid, role, source
        self.elements = []
        self.text = None


class _El(object):
    def __init__(self, layer, tag, attrs, item, text=None, geom=None):
        self.layer, self.tag, self.attrs = layer, tag, attrs
        self.item, self.text, self.geom = item, text, geom
        self.id = None


def _issue(code, where, detail):
    return {"code": code, "where": where, "detail": detail}


class _Builder(object):
    def __init__(self, pub, ix, fig, st, arc_override=None):
        self.pub, self.ix, self.fig, self.st = pub, ix, fig, st
        self.arc_override = dict(arc_override or {})
        self.issues = []
        self.items, self.els = [], []
        self.P = {}                   # point name -> px (rounded)
        self.straight = []            # (el, p, q, kind) drawn straight pieces
        self.marks = []               # (el, [pts]) mark strokes
        self.boxes = []               # placed label boxes
        # v6.9 fix r1 (N1/P1): a point INSIDE a captioned segment -> the side
        # of that segment its caption took (the name goes to the other side)
        self.caption_side = {}        # point name -> [(A, B, side)]
        self.tset = TT.load_templates()

    # ------------------------------------------------------------ plan --
    def item(self, role, source):
        it = _Item("d%03d" % (len(self.items) + 1), role, source)
        self.items.append(it)
        return it

    def add(self, layer, tag, attrs, it, text=None, geom=None):
        el = _El(layer, tag, attrs, it, text, geom)
        it.elements.append(el)
        self.els.append(el)
        return el

    def plan(self):
        ix, fig = self.ix, self.fig
        self.shown = B._figure_shows(fig, ix)
        pts = set()
        for eid in self.shown:
            for x in S.entity_closure(eid, ix):
                if ix.kind(x) == "point":
                    pts.add(x)
        self.points = sorted(pts)
        self.drawn = [ix.facts[d] for d in sorted(fig.get("draws") or [])
                      if d in ix.facts]
        for eid in sorted(self.shown):
            k = ix.kind(eid)
            if k in ("circle", "arc", "axis", "tick", "plane", "table_cell",
                     "variable", "number") or k is None:
                self.issues.append(_issue(
                    "RENDER_UNSUPPORTED_KIND", eid, "the renderer draws plane "
                    "geometry of the pilot only (points, segments, lines, "
                    "rays, polygons, angles); %s is %s" % (eid, k)))

    # ---------------------------------------------------------- layout --
    def place(self):
        st = self.st
        try:
            model = L.solve(st["layout"])
        except L.LayoutError as e:
            raise RenderRefused("RENDER_LAYOUT", str(e))
        names = dict((e["name"], eid) for eid, e in self.ix.entities.items()
                     if e.get("kind") == "point")
        for n in sorted(model):
            if n not in names:
                raise RenderRefused("RENDER_LAYOUT", "layout places %s, which "
                                    "is not a point of the public model" % n)
        missing = [p for p in self.points if self.ix.entities[p]["name"]
                   not in model]
        if missing:
            raise RenderRefused("RENDER_LAYOUT", "point(s) %s shown but not "
                                "placed by the layout" % ", ".join(missing))
        shown_names = [self.ix.entities[p]["name"] for p in self.points]
        xs = [model[n][0] for n in shown_names]
        ys = [model[n][1] for n in shown_names]
        bw, bh = max(xs) - min(xs), max(ys) - min(ys)
        W, m = float(st["width"]), float(st["margin"])
        if bw <= 1e-9 and bh <= 1e-9:
            raise RenderRefused("RENDER_LAYOUT", "all shown points coincide")
        if st["height"] is not None:
            H = float(st["height"])
            s = min((W - 2 * m) / bw if bw > 1e-9 else 1e18,
                    (H - 2 * m) / bh if bh > 1e-9 else 1e18)
        else:
            s = (W - 2 * m) / bw if bw > 1e-9 else (W - 2 * m) / bh
            H = max(60.0, math.ceil(bh * s + 2 * m))
            if H > 1.4 * W:
                H = math.ceil(1.4 * W)
                s = min((W - 2 * m) / bw if bw > 1e-9 else 1e18,
                        (H - 2 * m) / bh)
        tx = (W - bw * s) / 2 - min(xs) * s
        ty = (H - bh * s) / 2 + max(ys) * s
        self.W, self.H, self.s, self.tx, self.ty = W, H, s, tx, ty
        self.model = dict((n, model[n]) for n in shown_names)
        for n in shown_names:
            x, y = model[n]
            self.P[n] = (geo.r2(tx + s * x), geo.r2(ty - s * y))
        # every placed point, drawn or not: a construction's result is
        # checked against the drawing at its true place (never drawn)
        self.Pall = dict((n, (tx + s * x, ty - s * y))
                         for n, (x, y) in sorted(model.items()))
        self.name_of = dict((p, self.ix.entities[p]["name"])
                            for p in self.points)

    # ------------------------------------------------------ primitives --
    def _pt(self, pid):
        return self.P[self.ix.entities[pid]["name"]]

    def _covered_by(self, a, b):
        """The drawn straight pieces that contain both a and b."""
        out = []
        for el, p, q, kind in self.straight:
            if geo.line_dist(a, p, q) <= COLLINEAR_PX and \
                    geo.line_dist(b, p, q) <= COLLINEAR_PX and \
                    geo.seg_dist(a, p, q) <= COLLINEAR_PX and \
                    geo.seg_dist(b, p, q) <= COLLINEAR_PX:
                out.append((el, p, q, kind))
        return out

    def _inner(self, p, q):
        """(v6.9 fix r1, P4) a segment with drawn points strictly on BOTH
        sides of its line is an inner line (a diagonal, a cevian, a
        midsegment), not part of the figure's outline."""
        sides = set()
        for r in self.P.values():
            s = geo.line_dist(r, p, q)
            if s <= INNER_PT_PX:
                continue
            sides.add((q[0] - p[0]) * (r[1] - p[1]) -
                      (q[1] - p[1]) * (r[0] - p[0]) > 0)
        return len(sides) == 2

    def _line_el(self, it, hook, name, p, q, dashed=False):
        w = W_OBJ
        if hook == "seg" and self.st.get("inner_stroke") == "thin" and \
                self._inner(p, q):
            w = W_INNER_THIN      # the house look: inner lines thin
        a = [("data-" + hook, name), ("x1", geo.fmt(p[0])),
             ("y1", geo.fmt(p[1])), ("x2", geo.fmt(q[0])),
             ("y2", geo.fmt(q[1])), ("stroke", INK), ("stroke-width", w)]
        if dashed:
            a.append(("stroke-dasharray", "4 3"))
        pr = (geo.r2(p[0]), geo.r2(p[1]))
        qr = (geo.r2(q[0]), geo.r2(q[1]))
        el = self.add("lines", "line", a, it, geom=[pr, qr])
        self.straight.append((el, pr, qr, hook))
        return el

    def _extent(self, a, b, pts_on):
        """The ends of a line through a, b running LINE_EXT_PX past the
        extreme shown points on it (pts_on: parameters t along a->b)."""
        u = geo.unit(a, b)
        L_ = geo.d(a, b)
        t0, t1 = min(pts_on), max(pts_on)
        p = (a[0] + u[0] * (t0 * L_ - LINE_EXT_PX),
             a[1] + u[1] * (t0 * L_ - LINE_EXT_PX))
        q = (a[0] + u[0] * (t1 * L_ + LINE_EXT_PX),
             a[1] + u[1] * (t1 * L_ + LINE_EXT_PX))
        return p, q

    def _on_line_params(self, a, b):
        out = []
        for n, p in sorted(self.P.items()):
            if geo.line_dist(p, a, b) <= COLLINEAR_PX:
                out.append(geo.proj(p, a, b))
        return out

    # ------------------------------------------------------------ draw --
    def _pieces_of_longer(self):
        """Shown segments contained in another shown segment / line / ray
        (collinear, both ends on it, strictly shorter)."""
        ix, out = self.ix, set()
        lin = []
        for eid in sorted(self.shown):
            e = ix.entities.get(eid) or {}
            k = e.get("kind")
            if k == "segment":
                lin.append((eid, "segment", self.P[e["ends"][0]],
                            self.P[e["ends"][1]]))
            elif k in ("line", "ray"):
                a = e["through"][0] if k == "line" else e["from"]
                b = e["through"][1] if k == "line" else e["through"]
                lin.append((eid, k, self.P[a], self.P[b]))
        for eid, k, p, q in lin:
            if k != "segment":
                continue
            for oid, ok, p2, q2 in lin:
                if oid == eid:
                    continue
                if geo.line_dist(p, p2, q2) > COLLINEAR_PX or \
                        geo.line_dist(q, p2, q2) > COLLINEAR_PX:
                    continue
                if ok == "segment":
                    inside = geo.seg_dist(p, p2, q2) <= COLLINEAR_PX and \
                        geo.seg_dist(q, p2, q2) <= COLLINEAR_PX and \
                        geo.d(p2, q2) > geo.d(p, q) + COLLINEAR_PX
                elif ok == "ray":
                    inside = geo.proj(p, p2, q2) >= -1e-9 and \
                        geo.proj(q, p2, q2) >= -1e-9
                else:
                    inside = True
                if inside:
                    out.add(eid)
                    break
        return out

    # ------------------------------------ v6.17 (V4): a height outside ---
    def _base_extensions(self):
        """(v6.17, BRIEF_V617 V4) THE HEIGHT OF AN OBTUSE TRIANGLE FALLS
        OUTSIDE IT. A shown point H is the foot of a height of a drawn
        TRIANGLE when a shown segment joins H to the vertex P opposite a
        side XY at a right angle to the LINE of XY, H on that line but
        OUTSIDE the side (the side adjacent to an obtuse angle), H no corner
        of a drawn polygon, and no other shown segment / line / ray running
        on past H along that line (then H is a point of that object -- a
        diagonal, a longer side -- as in G9-T18 a q12 / q15). The house
        drawing (G7-T19 a/b/c q7): the side XY solid, its EXTENSION from
        the nearer end E to H dashed (a segment EH of its own), and the
        right-angle mark at H. Returns ({extension segment id: (E, H)},
        {(frozenset side ends, H): (P, E)}) and reports what cannot be
        drawn that way:
          RENDER_EXTENSION_MISSING  no shown segment EH: the foot floats
          RENDER_EXTENSION_SOLID    a longer shown segment / line / ray
                                    covers E..H solid (XH drawn as one line)
          RENDER_BASE_DASHED        the side XY itself is asked dashed
        The extension is dashed WITHOUT a display setting: an extension is
        never solid."""
        ix, ent = self.ix, canon.entity_id
        P = getattr(self, "Pall", {})
        name_pt = dict((self.ix.entities[p]["name"], p) for p in self.points)
        segs = {}
        others = []
        for eid in sorted(self.shown):
            e = ix.entities.get(eid) or {}
            k = e.get("kind")
            if k == "segment":
                segs[frozenset(e["ends"])] = eid
                others.append((eid, "segment", e["ends"][0], e["ends"][1]))
            elif k == "line":
                others.append((eid, "line", e["through"][0],
                               e["through"][1]))
            elif k == "ray":
                others.append((eid, "ray", e["from"], e["through"]))
        ext, feet = {}, {}
        polys = self._drawn_polygons(segs)
        corners = set(v for q in polys for v in ix.entities[q]["vertices"])

        def runs_past(a_, b_, ok, pE, pH):
            """does the element a_-b_ (kind ok) lie on the line E..H and
            reach PAST H (away from E)? -> another object carries the
            foot (a diagonal, a longer side): H is no extension's end"""
            pa, pb = P.get(a_), P.get(b_)
            if pa is None or pb is None or \
                    geo.line_dist(pE, pa, pb) > EXT_ON_LINE_PX or \
                    geo.line_dist(pH, pa, pb) > EXT_ON_LINE_PX:
                return None
            u = geo.unit(pE, pH)
            L2 = geo.d(pE, pH)

            def s_(q):
                return (q[0] - pE[0]) * u[0] + (q[1] - pE[1]) * u[1]
            if ok == "line":
                return "past"
            ends = [s_(pa)] + ([s_(pb)] if ok == "segment" else [])
            if ok == "ray":
                ends.append(1e18 if s_(pb) > s_(pa) else -1e18)
            lo, hi = min(ends), max(ends)
            if hi > L2 + EXT_OUT_PX and lo < L2 - EXT_OUT_PX:
                return "past"
            if min(hi, L2) - max(lo, 0.0) > EXT_OUT_PX:
                return "covers"
            return None

        for pid in polys:
            vs = ix.entities[pid]["vertices"]
            if len(vs) != 3:
                continue                          # the height of a TRIANGLE
            for i in range(3):
                X, Y = vs[i], vs[(i + 1) % 3]
                Q = vs[(i + 2) % 3]
                pX, pY = P[X], P[Y]
                L_ = geo.d(pX, pY)
                if L_ < 1e-9:
                    continue
                for H in sorted(name_pt):
                    if H in corners or H not in P or \
                            frozenset([Q, H]) not in segs:
                        continue
                    pH = P[H]
                    if geo.line_dist(pH, pX, pY) > EXT_ON_LINE_PX:
                        continue
                    t = geo.proj(pH, pX, pY)
                    if -EXT_OUT_PX / L_ <= t <= 1 + EXT_OUT_PX / L_:
                        continue                  # on the side: no extension
                    E = Y if t > 1 else X
                    far = pX if E == Y else pY
                    if abs(geo.angle_deg(pH, P[Q], far) - 90) > 0.2:
                        continue                  # QH is no height
                    how = [(oid, runs_past(a_, b_, ok, P[E], pH))
                           for oid, ok, a_, b_ in others
                           if frozenset([a_, b_]) != frozenset([X, Y])]
                    if any(h == "past" for _o, h in how):
                        continue                  # H lies on another object
                    feet[(frozenset([X, Y]), H)] = (Q, E)
                    sid = segs.get(frozenset([E, H]))
                    if sid is None:
                        self.issues.append(_issue(
                            "RENDER_EXTENSION_MISSING", pid, "the height %s%s "
                            "falls outside %s on the extension of %s%s: show "
                            "the extension as its own segment %s (drawn "
                            "dashed), or the foot %s floats off the base" % (
                                Q, H, pid, X, Y, ent({"kind": "segment",
                                                      "ends": [E, H]}), H)))
                        continue
                    ext[sid] = (E, H)
                    for oid, h in how:
                        if h == "covers" and oid != sid:
                            self.issues.append(_issue(
                                "RENDER_EXTENSION_SOLID", oid, "%s covers "
                                "the extension %s%s of %s%s solid: the "
                                "height %s%s falls outside %s, so show the "
                                "side %s%s and the extension %s alone (it "
                                "is drawn dashed), not %s" % (
                                    oid, E, H, X, Y, Q, H, pid, X, Y, sid,
                                    oid)))
                    side = segs.get(frozenset([X, Y]))
                    if side in set(self.st["dashed"]):
                        self.issues.append(_issue(
                            "RENDER_BASE_DASHED", side, "the side %s%s is "
                            "asked dashed: the base stays solid, only its "
                            "extension %s is dashed" % (X, Y, sid)))
        self.ext_dashed = ext
        self.ext_feet = feet
        return ext

    def _drawn_polygons(self, segs=None):
        """(v6.17, V4) the polygons of the public model the figure draws:
        shown, or every side a shown segment (a triangle drawn by its
        sides), every vertex placed"""
        ix, P = self.ix, getattr(self, "Pall", {})
        if segs is None:
            segs = set(frozenset(ix.entities[e]["ends"]) for e in self.shown
                       if ix.kind(e) == "segment")
        out = []
        for pid in sorted(ix.entities):
            pe = ix.entities[pid]
            if pe.get("kind") != "polygon" or pe.get("tag") is not None:
                continue
            vs = pe.get("vertices") or []
            if not vs or not all(v in P and v in self.name_of for v in vs):
                continue
            n = len(vs)
            if pid in self.shown or all(
                    frozenset([vs[i], vs[(i + 1) % n]]) in segs
                    for i in range(n)):
                out.append(pid)
        return out

    def _height_inside(self, k1, k2, fid):
        """(v6.17, V4) a drawn 'PH ⟂ XY' whose foot H is placed INSIDE the
        side XY of a shown polygon while the true foot of P on the line XY
        lies OUTSIDE it (the angle at X or Y is obtuse): the height of an
        obtuse triangle drawn inside it. RENDER_HEIGHT_INSIDE_OBTUSE (the
        foot belongs on the extension, drawn dashed)."""
        P = getattr(self, "Pall", {})
        if not (k1 and k2) or len(k1) != 2 or len(k2) != 2 or (k1 & k2):
            return
        polys = self._drawn_polygons()
        for kh, ks in ((k1, k2), (k2, k1)):
            X, Y = sorted(ks)
            for pid in polys:
                vs = self.ix.entities[pid]["vertices"]
                if len(vs) != 3 or X not in vs or Y not in vs:
                    continue                      # a triangle's side
                n = len(vs)
                if abs(vs.index(X) - vs.index(Y)) not in (1, n - 1):
                    continue                      # not a side
                for apex in sorted(kh):
                    H = sorted(kh - set([apex]))[0]
                    if apex not in vs or H in vs or not all(
                            p in P for p in (apex, H, X, Y)):
                        continue
                    L_ = geo.d(P[X], P[Y])
                    th = geo.proj(P[H], P[X], P[Y])
                    tf = geo.proj(P[apex], P[X], P[Y])
                    if geo.line_dist(P[H], P[X], P[Y]) <= EXT_ON_LINE_PX \
                            and EXT_OUT_PX / L_ < th < 1 - EXT_OUT_PX / L_ \
                            and not (-EXT_OUT_PX / L_ <= tf <=
                                     1 + EXT_OUT_PX / L_):
                        self.issues.append(_issue(
                            "RENDER_HEIGHT_INSIDE_OBTUSE", fid, "the height "
                            "from %s to %s%s is drawn to %s INSIDE the side, "
                            "but %s is obtuse at %s: the true foot lies on "
                            "the extension of %s%s beyond %s (draw it there, "
                            "the extension dashed, the right angle at the "
                            "foot)" % (apex, X, Y, H, pid,
                                       Y if tf > 1 else X, X, Y,
                                       Y if tf > 1 else X)))

    def draw_objects(self):
        ix, dashed = self.ix, set(self.st["dashed"])
        for eid in sorted(dashed):
            if eid not in self.shown or ix.kind(eid) not in (
                    "segment", "line", "ray", "polygon"):
                self.issues.append(_issue("RENDER_BAD_SETTINGS", eid,
                                          "dashed names no shown segment / "
                                          "line / ray / polygon"))
        # (v6.17, V4) a base extension under a height is ALWAYS dashed
        dashed |= set(self._base_extensions())
        # segments, lines, rays the figure shows: each its own hooked line
        # -- except a segment that is a PIECE of another shown segment /
        # line / ray (OC of the diagonal AC): drawn once, by the longer one,
        # and mapped as its piece (pilot_build: no overlapping second
        # stroke; geomcheck._piece_drawn)
        pieces_of = self._pieces_of_longer()
        for eid in sorted(self.shown):
            e = ix.entities.get(eid) or {}
            k = e.get("kind")
            if k == "segment" and eid in pieces_of:
                continue
            if k == "segment":
                a, b = e["ends"]
                it = self.item("segment", {"entity": eid})
                self._line_el(it, "seg", a + b, self.P[a], self.P[b],
                              eid in dashed)
            elif k == "line":
                a, b = e["through"]
                pa, pb = self.P[a], self.P[b]
                p, q = self._extent(pa, pb, self._on_line_params(pa, pb))
                it = self.item("line", {"entity": eid})
                self._line_el(it, "line", a + b, p, q, eid in dashed)
            elif k == "ray":
                a, b = e["from"], e["through"]
                pa, pb = self.P[a], self.P[b]
                ts = [t for t in self._on_line_params(pa, pb) if t >= -1e-9]
                u = geo.unit(pa, pb)
                L_ = geo.d(pa, pb) * max(ts)
                q = (pa[0] + u[0] * (L_ + LINE_EXT_PX),
                     pa[1] + u[1] * (L_ + LINE_EXT_PX))
                it = self.item("ray", {"entity": eid})
                self._line_el(it, "ray", a + b, pa, q, eid in dashed)
        # polygons: by their sides when every side is drawn, else an outline
        for eid in sorted(self.shown):
            e = ix.entities.get(eid) or {}
            if e.get("kind") != "polygon":
                continue
            vs = e["vertices"]
            sides = [(vs[i], vs[(i + 1) % len(vs)]) for i in range(len(vs))]
            if all(self._covered_by(self.P[a], self.P[b]) for a, b in sides):
                continue
            it = self.item("polygon", {"entity": eid})
            pts = [self.P[v] for v in vs]
            a = [("data-poly", "".join(vs)),
                 ("points", " ".join("%s,%s" % (geo.fmt(x), geo.fmt(y))
                                     for x, y in pts)),
                 ("fill", "none"), ("stroke", INK), ("stroke-width", W_OBJ)]
            if eid in dashed:
                a.append(("stroke-dasharray", "4 3"))
            a.append(("stroke-linejoin", "miter"))
            el = self.add("lines", "polygon", a, it, geom=list(pts))
            for i in range(len(pts)):
                self.straight.append((el, pts[i], pts[(i + 1) % len(pts)],
                                      "poly"))
        # angles: their arms must be drawn; an undrawn arm is drawn as the
        # segment of the spec it is (hook), else the angle cannot be shown
        for eid in sorted(self.shown):
            e = ix.entities.get(eid) or {}
            if e.get("kind") != "angle":
                continue
            v = e["vertex"]
            for arm in e["arms"]:
                if self._covered_by(self.P[v], self.P[arm]):
                    continue
                sid = canon.entity_id({"kind": "segment", "ends": [v, arm]})
                if sid in ix.entities:
                    it = self.item("angle_arm", {"entity": eid})
                    self._line_el(it, "seg", v + arm, self.P[v], self.P[arm])
                else:
                    self.issues.append(_issue(
                        "RENDER_ARM_UNDRAWABLE", eid, "arm %s%s is not drawn "
                        "and the public model has no segment %s to draw it "
                        "as" % (v, arm, sid)))

    # ----------------------------------------------------------- marks --
    def _classes(self):
        """Equality classes of the DRAWN facts -> the mark count of each
        member (1, 2, 3 by first member), for ticks and arcs separately."""
        ent = canon.entity_id
        tick_u, arc_u = G._Union(), G._Union()
        ticks, arcs = set(), set()
        valued = []
        for f in self.drawn:
            rel, args = f.get("rel"), f.get("args") or []
            if rel == "equal_length":
                tick_u.join(args[0], args[1])
                ticks.update(args)
            elif rel == "midpoint":
                m = self.ix.entities[args[0]]["name"]
                a, b = self.ix.entities[args[1]]["ends"]
                halves = [ent({"kind": "segment", "ends": [a, m]}),
                          ent({"kind": "segment", "ends": [m, b]})]
                if all(h in self.ix.entities for h in halves):
                    tick_u.join(halves[0], halves[1])
                    ticks.update(halves)
                else:
                    self.issues.append(_issue(
                        "RENDER_FACT_NOT_MARKED", f["id"], "the midpoint is "
                        "drawn by position only: the halves %s are not "
                        "segments of the public model, so no tick can name "
                        "them" % " / ".join(halves)))
            elif rel == "equal_angle":
                arc_u.join(args[0], args[1])
                arcs.update(args)
            elif rel == "angle_measure" and f.get("value") is not None \
                    and not B._right_angle(f):
                arcs.add(args[0])
                valued.append(f)
        for i, f in enumerate(valued):
            for g in valued[i + 1:]:
                if G._same_q(f, g):
                    arc_u.join(f["args"][0], g["args"][0])

        def count(u, members):
            roots = {}
            for x in sorted(members):
                roots.setdefault(u.find(x), x)
            order = sorted(roots.values())
            idx = dict((roots_k, order.index(first) + 1)
                       for roots_k, first in roots.items())
            return dict((x, idx[u.find(x)]) for x in members)
        return count(tick_u, ticks), count(arc_u, arcs)

    def _mark_el(self, it, tag, value, pts):
        pts = [(geo.r2(x), geo.r2(y)) for x, y in pts]
        if tag == "line":
            a = [("data-mark", value), ("x1", geo.fmt(pts[0][0])),
                 ("y1", geo.fmt(pts[0][1])), ("x2", geo.fmt(pts[1][0])),
                 ("y2", geo.fmt(pts[1][1])), ("stroke", INK),
                 ("stroke-width", W_MARK)]
        elif tag == "polyline":
            a = [("data-mark", value),
                 ("points", " ".join("%s,%s" % (geo.fmt(x), geo.fmt(y))
                                     for x, y in pts)),
                 ("fill", "none"), ("stroke", INK), ("stroke-width", W_MARK)]
        else:
            a = [("data-mark", value),
                 ("d", "M " + " L ".join("%s %s" % (geo.fmt(x), geo.fmt(y))
                                         for x, y in pts)),
                 ("fill", "none"), ("stroke", INK), ("stroke-width", W_MARK)]
        el = self.add("marks", tag, a, it, geom=pts)
        self.marks.append((el, pts))
        return el

    def _angle_names(self, aid):
        e = self.ix.entities[aid]
        return e["arms"][0], e["vertex"], e["arms"][1]

    def _arms_drawn(self, aid, where):
        a, v, b = self._angle_names(aid)
        for arm in (a, b):
            if arm not in self.P or v not in self.P or \
                    not self._covered_by(self.P[v], self.P[arm]):
                self.issues.append(_issue(
                    "RENDER_FACT_NOT_MARKED", where, "arm %s%s of %s is not "
                    "drawn in this figure" % (v, arm, aid)))
                return False
        return True

    def right_mark(self, aid, f):
        if not self._arms_drawn(aid, f["id"]):
            return
        a, v, b = self._angle_names(aid)
        V, A, Bp = self.P[v], self.P[a], self.P[b]
        if abs(geo.angle_deg(V, A, Bp) - 90) > 0.2:
            self.issues.append(_issue("RENDER_LAYOUT_OFF", f["id"], "%s is "
                                      "laid out %.2f deg, not 90" % (
                                          aid, geo.angle_deg(V, A, Bp))))
            return
        leg = min(RIGHT_LEG_PX, 0.4 * min(geo.d(V, A), geo.d(V, Bp)))
        if leg < 5.0:
            self.issues.append(_issue("RENDER_NO_ROOM", f["id"], "arms of %s "
                                      "too short for a right-angle mark"
                                      % aid))
            return
        ua, ub = geo.unit(V, A), geo.unit(V, Bp)
        p0 = (V[0] + leg * ua[0], V[1] + leg * ua[1])
        p2 = (V[0] + leg * ub[0], V[1] + leg * ub[1])
        c = (p0[0] + p2[0] - V[0], p0[1] + p2[1] - V[1])
        it = self.item("right_mark", {"fact": f["id"], "entity": aid})
        self._mark_el(it, "polyline", "right %s%s%s" % (a, v, b), [p0, c, p2])

    def arc_mark(self, aid, f, n):
        if not self._arms_drawn(aid, f["id"]):
            return None
        a, v, b = self._angle_names(aid)
        V, A, Bp = self.P[v], self.P[a], self.P[b]
        r0 = self.arc_radius(aid)
        room = min(geo.d(V, A), geo.d(V, Bp)) - 2.0
        r0 = min(r0, room - ARC_STEP_PX * (n - 1))
        r0 = self._adjacent_arc_radius(aid, (a, v, b), r0, n, room)
        if r0 < ARC_MIN_PX:
            self.issues.append(_issue("RENDER_NO_ROOM", f["id"], "arms of %s "
                                      "too short for an arc" % aid))
            return None
        ua, ub = geo.unit(V, A), geo.unit(V, Bp)
        a0 = geo.ang_of(ua)
        sweep = geo.signed_sweep(ua, ub)
        steps = max(2, int(math.ceil(abs(math.degrees(sweep)) /
                                     ARC_SAMPLE_DEG)))
        it = self.item("angle_arc", {"fact": f["id"], "entity": aid})
        value = "arc%s %s%s%s" % ("" if n == 1 else n, a, v, b)
        for k in range(n):
            r = r0 + ARC_STEP_PX * k
            pts = [(V[0] + r * math.cos(a0 + sweep * i / steps),
                    V[1] + r * math.sin(a0 + sweep * i / steps))
                   for i in range(steps + 1)]
            # the ends exactly on the arms
            pts[0] = (V[0] + r * ua[0], V[1] + r * ua[1])
            pts[-1] = (V[0] + r * ub[0], V[1] + r * ub[1])
            self._mark_el(it, "path", value, pts)
        self.arc_band[aid] = (v, frozenset((a, b)), r0,
                              r0 + ARC_STEP_PX * (n - 1))
        return r0 + ARC_STEP_PX * (n - 1)

    def _adjacent_arc_radius(self, aid, names, r0, n, room):
        """(1.0.3) r0, moved off the band of an arc already drawn at the
        same vertex on an angle that shares an arm with this one: out past
        it when the arms have room, else in below it."""
        a, v, b = names
        bands = [(lo, hi) for x, (v2, arms2, lo, hi) in
                 sorted(self.arc_band.items())
                 if x != aid and v2 == v and arms2 & set((a, b))]
        if not bands:
            return r0
        span = ARC_STEP_PX * (n - 1)
        clear = lambda r: all(r + span < lo - ARC_ADJ_PX + 0.01 or  # noqa
                              r > hi + ARC_ADJ_PX - 0.01 for lo, hi in bands)
        if clear(r0):
            return r0
        out = max(hi for _lo, hi in bands) + ARC_ADJ_PX
        if out + span <= min(room, ARC_MAX_PX):
            return out
        return min(lo for lo, _hi in bands) - ARC_ADJ_PX - span

    def arc_radius(self, aid):
        """The arc radius of angle aid: the setting, smaller when another
        point is near the vertex (the value must read nearer to the vertex
        than to it), or the retry's override (render: a caption with no
        place gets a smaller arc)."""
        if aid in self.arc_override:
            return self.arc_override[aid]
        a, v, b = self._angle_names(aid)
        V = self.P[v]
        dmin = min(geo.d(V, q) for n, q in self.P.items() if n != v)
        return max(ARC_MIN_PX, min(float(self.st["arc_radius"]),
                                   0.22 * dmin))

    def ticks(self, sid, f, n):
        e = self.ix.entities[sid]
        a, b = e["ends"]
        A, Bp = self.P.get(a), self.P.get(b)
        if A is None or Bp is None or not self._covered_by(A, Bp):
            self.issues.append(_issue("RENDER_FACT_NOT_MARKED", f["id"],
                                      "segment %s is not drawn" % sid))
            return
        u = geo.unit(A, Bp)
        nrm = (-u[1], u[0])
        m = ((A[0] + Bp[0]) / 2, (A[1] + Bp[1]) / 2)
        it = self.item("tick", {"fact": f["id"], "entity": sid})
        for k in range(n):
            off = (k - (n - 1) / 2.0) * TICK_STEP_PX
            c = (m[0] + off * u[0], m[1] + off * u[1])
            p = (c[0] - TICK_HALF_PX * nrm[0], c[1] - TICK_HALF_PX * nrm[1])
            q = (c[0] + TICK_HALF_PX * nrm[0], c[1] + TICK_HALF_PX * nrm[1])
            self._mark_el(it, "line", "tick%s %s%s" % (
                "" if n == 1 else n, a, b), [p, q])

    def _foot_angle(self, k1, k2):
        """'BH ⟂ AC' with the public incidence 'H על AC' (seen by the
        reader of the figure): the right angle at the foot H, as an angle
        entity of the public model (the first of BHA / BHC that exists)."""
        ix = self.ix
        vis = set(ix.visible_scopes(self.fig["scope"])) | set(
            [self.fig["scope"]])
        drawn = set(f["id"] for f in self.drawn)
        on = {}
        for f in ix.facts.values():
            a_ = f.get("args") or []
            if f.get("rel") in ("on_segment", "midpoint") and \
                    len(a_) == 2 and f.get("role") in ("given", "context") \
                    and (f.get("item") in vis or f["id"] in drawn) and \
                    ix.kind(a_[1]) == "segment":
                on.setdefault(a_[0], set()).add(
                    frozenset(ix.entities[a_[1]]["ends"]))
        for ka, kb in ((k1, k2), (k2, k1)):
            for x in sorted(ka):
                if kb in on.get(x, ()):
                    o = sorted(ka - set([x]))[0]
                    for y in sorted(kb):
                        aid = canon.entity_id({"kind": "angle", "vertex": x,
                                               "arms": [o, y]})
                        if aid in ix.entities:
                            return aid
        # (v6.17, V4) 'CH ⟂ AB' where the foot H falls OUTSIDE the side AB
        # (an obtuse triangle): the right angle sits AT THE FOOT H, between
        # the height and the dashed extension EH (_base_extensions) -- the
        # angle entity P-H-E of the public model
        for (side, H), (apex, E) in sorted(
                getattr(self, "ext_feet", {}).items(),
                key=lambda kv: (sorted(kv[0][0]), kv[0][1])):
            for ka, kb in ((k1, k2), (k2, k1)):
                if ka == frozenset([apex, H]) and (
                        kb == side or kb == frozenset([E, H])):
                    aid = canon.entity_id({"kind": "angle", "vertex": H,
                                           "arms": [apex, E]})
                    if aid in ix.entities:
                        return aid
        return None

    def _par_classes(self):
        """Parallel classes of the DRAWN facts (parallel of two segments;
        the opposite sides of a drawn parallelogram / rhombus) -> the count
        of each member segment, and each class's direction (its first
        member, so every arrow of a class points the same way)."""
        ent = canon.entity_id
        u = G._Union()
        members, why = set(), {}
        for f in self.drawn:
            rel, args = f.get("rel"), f.get("args") or []
            pairs = []
            if rel == "parallel":
                ks = [B._line_key(x, self.ix) for x in args]
                if all(k and len(k) == 2 for k in ks):
                    pairs.append([ent({"kind": "segment", "ends": sorted(k)})
                                  for k in ks])
            elif rel in ("parallelogram", "rhombus"):
                vs = self.ix.entities[args[0]]["vertices"]
                sd = [ent({"kind": "segment", "ends": [vs[i], vs[(i + 1) %
                                                                  4]]})
                      for i in range(4)]
                pairs += [[sd[0], sd[2]], [sd[1], sd[3]]]
            for a, b in pairs:
                u.join(a, b)
                for x in (a, b):
                    members.add(x)
                    why.setdefault(x, f)
        roots = {}
        for x in sorted(members):
            roots.setdefault(u.find(x), x)
        order = sorted(roots.values())
        count = dict((x, order.index(roots[u.find(x)]) + 1)
                     for x in members)
        first = dict((x, roots[u.find(x)]) for x in members)
        return count, first, why

    def arrows(self, sid, f, n, ref_sid):
        e = self.ix.entities.get(sid)
        if e is None:
            self.issues.append(_issue("RENDER_FACT_NOT_MARKED", f["id"],
                                      "%s is not a segment of the public "
                                      "model" % sid))
            return
        a, b = e["ends"]
        A, Bp = self.P.get(a), self.P.get(b)
        if A is None or Bp is None or not self._covered_by(A, Bp):
            self.issues.append(_issue("RENDER_FACT_NOT_MARKED", f["id"],
                                      "segment %s is not drawn" % sid))
            return
        u = geo.unit(A, Bp)
        r = self.ix.entities[ref_sid]["ends"]
        if all(x in self.P for x in r):
            ru = geo.unit(self.P[r[0]], self.P[r[1]])
            if u[0] * ru[0] + u[1] * ru[1] < 0:
                u = (-u[0], -u[1])
        nrm = (-u[1], u[0])
        m = ((A[0] + Bp[0]) / 2, (A[1] + Bp[1]) / 2)
        it = self.item("parallel_arrow", {"fact": f["id"], "entity": sid})
        c, sn = math.cos(math.radians(PAR_HALF_DEG)), \
            math.sin(math.radians(PAR_HALF_DEG))
        for k in range(n):
            off = (k - (n - 1) / 2.0) * PAR_STEP_PX
            tip = (m[0] + off * u[0], m[1] + off * u[1])
            e1 = (tip[0] - PAR_LEG_PX * (c * u[0] - sn * nrm[0]),
                  tip[1] - PAR_LEG_PX * (c * u[1] - sn * nrm[1]))
            e2 = (tip[0] - PAR_LEG_PX * (c * u[0] + sn * nrm[0]),
                  tip[1] - PAR_LEG_PX * (c * u[1] + sn * nrm[1]))
            self._mark_el(it, "polyline", "par%s %s%s" % (
                "" if n == 1 else n, a, b), [e1, tip, e2])

    def draw_facts(self):
        ix = self.ix
        par_n, par_first, par_why = self._par_classes()
        for sid in sorted(par_n):
            if par_n[sid] > MAX_COUNT:
                self.issues.append(_issue("RENDER_TOO_MANY_CLASSES", sid,
                                          "more than %d parallel classes"
                                          % MAX_COUNT))
                continue
            self.arrows(sid, par_why[sid], par_n[sid], par_first[sid])
        tick_n, arc_n = self._classes()
        for x, n in sorted(list(tick_n.items()) + list(arc_n.items())):
            if n > MAX_COUNT:
                self.issues.append(_issue("RENDER_TOO_MANY_CLASSES", x,
                                          "more than %d equality classes of "
                                          "one mark kind" % MAX_COUNT))
        done_ticks = set()
        self.arc_r = {}
        self.arc_band = {}           # angle -> (vertex, arms, r in, r out)
        self.captions = []           # (fact, entity)
        self.caption_failed = {}     # fact id -> angle id
        self.caption_far = {}        # fact id -> box distance from vertex
        ent = canon.entity_id
        for f in self.drawn:
            rel, args, fid = f.get("rel"), f.get("args") or [], f["id"]
            if rel == "name":
                continue                         # labels, below
            if rel == "on_segment":
                continue                         # drawn by position
            if rel == "angle_measure" and f.get("value") is not None:
                if B._right_angle(f):
                    self.right_mark(args[0], f)
                else:
                    r = self.arc_mark(args[0], f, min(arc_n[args[0]],
                                                      MAX_COUNT))
                    if r is not None:
                        self.arc_r[args[0]] = r
                    self.captions.append((f, args[0]))
                continue
            if rel == "length" and f.get("value") is not None:
                self.captions.append((f, args[0]))
                continue
            if rel in ("equal_length", "midpoint"):
                segs = args if rel == "equal_length" else [
                    ent({"kind": "segment", "ends": [
                        ix.entities[args[1]]["ends"][0],
                        ix.entities[args[0]]["name"]]}),
                    ent({"kind": "segment", "ends": [
                        ix.entities[args[0]]["name"],
                        ix.entities[args[1]]["ends"][1]]})]
                for sid in segs:
                    if sid in tick_n and sid not in done_ticks:
                        done_ticks.add(sid)
                        self.ticks(sid, f, min(tick_n[sid], MAX_COUNT))
                continue
            if rel == "equal_angle":
                for aid in args:
                    if aid not in self.arc_r:
                        r = self.arc_mark(aid, f, min(arc_n[aid], MAX_COUNT))
                        if r is not None:
                            self.arc_r[aid] = r
                continue
            if rel == "parallel":
                continue                         # arrows, above
            if rel == "perpendicular":
                k1, k2 = (B._line_key(x, ix) for x in args)
                self._height_inside(k1, k2, fid)
                aid = None
                if k1 and k2 and len(k1 & k2) == 1:
                    v = list(k1 & k2)[0]
                    aid = ent({"kind": "angle", "vertex": v,
                               "arms": [list(k1 - k2)[0], list(k2 - k1)[0]]})
                elif k1 and k2 and not (k1 & k2):
                    aid = self._foot_angle(k1, k2)
                if aid in ix.entities:
                    self.right_mark(aid, f)
                else:
                    self.issues.append(_issue(
                        "RENDER_FACT_NOT_MARKED", fid, "no angle entity of "
                        "the public model at the lines' common point to "
                        "carry a right-angle mark"))
                continue
            if rel in ("rectangle", "square"):
                vs = ix.entities[args[0]]["vertices"]
                for i in range(4):
                    aid = ent({"kind": "angle", "vertex": vs[i],
                               "arms": [vs[i - 1], vs[(i + 1) % 4]]})
                    if aid in ix.entities:
                        self.right_mark(aid, f)
                continue
            if rel in ("parallelogram", "triangle", "rhombus", "isosceles",
                       "equilateral"):
                continue                 # the outline (+ arrows, above)
            if rel in ("linear", "greater", "not_parallel", "inside",
                       "trapezoid", "isosceles_trapezoid", "right_triangle",
                       "acute_triangle",
                       # (v6.17-noam V1, builder A) no mark either
                       "obtuse_triangle"):
                # (v6.10) no mark says these: the layout's geometry does;
                # the geometry check measures it (geomcheck MEASURE)
                continue
            self.issues.append(_issue("RENDER_FACT_NOT_MARKED", fid, "the "
                                      "renderer has no mark for %s" % rel))

    def _pieces(self):
        """[(p, q, width, dashed)] of the drawn straight pieces, as the SVG
        will print them (for the corner dots, P4)."""
        out = []
        for el, p, q, _k in self.straight:
            a = dict(el.attrs)
            out.append((p, q, a.get("stroke-width"),
                        "stroke-dasharray" in a))
        return out

    def draw_points(self):
        r = self.st["point_radius"]
        rs = ("%g" % r)
        corner = self.st.get("vertex_dots") == "corner"
        pieces = self._pieces() if corner else []
        for pid in self.points:
            n = self.name_of[pid]
            x, y = self.P[n]
            it = self.item("point", {"entity": pid})
            xy = (geo.r2(x), geo.r2(y))
            # (v6.9 fix r2, P4) a vertex prints as its corner: the dot hides
            # in the join (wspec-svg/5 corner dot); labels keep their
            # clearance from point_radius, so the layout does not move
            rr = G.CORNER_DOT_R if corner and G.is_corner(xy, pieces) \
                else rs
            self.add("points", "circle", [
                ("data-pt", n), ("cx", geo.fmt(x)), ("cy", geo.fmt(y)),
                ("r", rr), ("fill", INK), ("stroke", "none")], it,
                geom=[(x, y)])

    # ---------------------------------------------------------- labels --
    def _box_ok(self, box, own_pieces=(), strict=True):
        W, H = self.W, self.H
        if box[0] < 1 or box[1] < 1 or box[2] > W - 1 or box[3] > H - 1:
            return False
        # clearance from every dot: the estimated glyph box is narrower than
        # the ink of a wide letter (M, W); the checker measures the ink
        # (pilot_build: 'M' touched its dot in b q14)
        rad = float(self.st["point_radius"]) + DOT_CLEAR_PX
        for n, p in self.P.items():
            if geo.box_point_dist(box, p) < rad:
                return False
        pad = geo.inflate(box, LABEL_PAD_PX)
        for el, pts in self.marks:
            for p, q in zip(pts, pts[1:]):
                if geo.clip_len(p, q, pad) > 0:
                    return False
        lim = 0.0 if strict else 1.5
        for el, p, q, k in self.straight:
            if geo.clip_len(p, q, pad if strict else box) > lim:
                return False
        for b in self.boxes:
            if geo.boxes_overlap(geo.inflate(box, LABEL_GAP_PX), b):
                return False
        return True

    def _text_el(self, it, src, text, fs, c):
        x, y = geo.text_anchor_xy(text, fs, c)
        x, y = geo.r2(x), geo.r2(y)
        a = [("data-for", src), ("x", geo.fmt(x)), ("y", geo.fmt(y)),
             ("font-size", str(fs)), ("font-family", self.st["font_family"]),
             ("text-anchor", "middle"), ("fill", INK)]
        cc = (x, y - geo.GLYPH_H * fs / 2)
        box = geo.text_box(text, fs, cc)
        self.boxes.append(box)
        it.text = text
        return self.add("labels", "text", a, it, text=text,
                        geom={"box": [geo.r2(v) for v in box],
                              "center": [geo.r2(cc[0]), geo.r2(cc[1])]})

    def _dirs_at(self, p):
        out = []
        for el, a, b, k in self.straight:
            if geo.seg_dist(p, a, b) > COLLINEAR_PX:
                continue
            for e in (a, b):
                if geo.d(p, e) > 1.0:
                    out.append(geo.ang_of(geo.unit(p, e)))
        return sorted(out)

    def _gap_dir(self, p):
        dirs = self._dirs_at(p)
        cx = sum(q[0] for q in self.P.values()) / len(self.P)
        cy = sum(q[1] for q in self.P.values()) / len(self.P)
        away = math.atan2(p[1] - cy, p[0] - cx) if (p[0], p[1]) != (cx, cy) \
            else -math.pi / 2
        if not dirs:
            return away
        best, bdir = -1.0, away
        for i, a in enumerate(dirs):
            b = dirs[(i + 1) % len(dirs)] + (2 * math.pi if i + 1 ==
                                             len(dirs) else 0)
            gap = b - a
            mid = a + gap / 2
            # prefer the widest gap; among near-equal gaps, the one facing
            # away from the figure
            score = gap + 0.3 * math.cos(mid - away)
            if score > best + 1e-9:
                best, bdir = score, mid
        return bdir

    def label_points(self):
        fs = self.st["name_size"]
        named = {}
        for f in self.drawn:
            if f.get("rel") == "name" and self.ix.kind(f["args"][0]) == \
                    "point":
                named.setdefault(f["args"][0], f)
        for pid in self.points:
            f = named.get(pid)
            if f is None:
                continue
            n = self.name_of[pid]
            p = self.P[n]
            phi0 = self._gap_dir(p)
            w, h = geo.text_width(n, fs), geo.GLYPH_H * fs
            cands = []
            for j in range(0, 13):
                for sgn in ((1,) if j in (0, 12) else (1, -1)):
                    phi = phi0 + sgn * math.radians(15 * j)
                    for gi, gap in enumerate((3.0, 4.5, 6.0, 8.0, 10.0,
                                              12.0)):
                        ext = abs(math.cos(phi)) * w / 2 + \
                            abs(math.sin(phi)) * h / 2
                        c = (p[0] + (gap + ext) * math.cos(phi),
                             p[1] + (gap + ext) * math.sin(phi))
                        cands.append((j + gi * 0.8, len(cands), c))
            cands.sort()
            it = self.item("point_name", {"fact": f["id"], "entity": pid})
            chosen = None
            sides = self.caption_side.get(n, [])
            for strict in (True, False):
                for _, _, c in cands:
                    if any(self._side(c, A, Bp) == sd for A, Bp, sd in
                           sides):
                        # (fix r1, N1/P1) the name of a point inside a
                        # captioned segment never stands on the caption's
                        # side ('8 E' reads as E's 8)
                        continue
                    box = geo.text_box(n, fs, c)
                    dn = geo.d(c, p)
                    if dn > LABEL_NEAR_PX - 0.5:
                        continue
                    if any(geo.d(c, q) < dn + NEAR_MARGIN_PX
                           for m, q in self.P.items() if m != n):
                        continue
                    if self._box_ok(box, strict=strict):
                        chosen = c
                        break
                if chosen:
                    break
            if chosen is None:
                self.issues.append(_issue("RENDER_LABEL_NO_PLACE", pid,
                                          "no place for the name %s by its "
                                          "point (canvas, strokes, marks, "
                                          "other labels)" % n))
                chosen = cands[0][2]
            self._text_el(it, n, n, fs, chosen)

    def label_lines(self):
        """Place an explicitly declared name beside its own complete line."""
        for f in self.drawn:
            eid = (f.get("args") or [None])[0]
            e = self.ix.entities.get(eid) or {}
            if f.get("rel") != "name" or e.get("kind") != "line":
                continue
            name = e.get("name")
            own = [(p, q) for el, p, q, k in self.straight
                   if k == "line" and el.item.source.get("entity") == eid]
            if not name or len(own) != 1:
                self.issues.append(_issue("RENDER_LABEL_NO_PLACE", eid, "named line has no unique drawn stroke"))
                continue
            p, q = own[0]
            u = geo.unit(p, q)
            normal = (-u[1], u[0])
            fs = self.st["name_size"]
            chosen = None
            for frac in (0.9, 0.1, 0.8, 0.2, 0.65, 0.35, 0.5):
                for gap in (9.0, 12.0, 16.0, 20.0):
                    for sign in (-1, 1):
                        c = (p[0] + frac * (q[0] - p[0]) + sign * gap * normal[0],
                             p[1] + frac * (q[1] - p[1]) + sign * gap * normal[1])
                        own_dist = geo.seg_dist(c, p, q)
                        if any(geo.seg_dist(c, a, b) < own_dist + NEAR_MARGIN_PX
                               for el, a, b, k in self.straight
                               if k == "line" and el.item.source.get("entity") != eid):
                            continue
                        if self._box_ok(geo.text_box(name, fs, c), strict=True):
                            chosen = c
                            break
                    if chosen is not None:
                        break
                if chosen is not None:
                    break
            if chosen is None:
                self.issues.append(_issue("RENDER_LABEL_NO_PLACE", eid, "no unambiguous space for line name " + name))
                continue
            item = self.item("line_name", {"fact": f["id"], "entity": eid})
            self._text_el(item, "line " + "".join(e["through"]), name, fs, chosen)

    # (fix r1, N1/P1) a segment caption and the points inside the segment
    def _inner_points(self, a, b):
        """[(t, name)] of the drawn points strictly inside segment ab."""
        A, Bp = self.P[a], self.P[b]
        L = geo.d(A, Bp)
        out = []
        for n, q in sorted(self.P.items()):
            if n in (a, b) or L <= 1e-9:
                continue
            t = geo.proj(q, A, Bp)
            if geo.line_dist(q, A, Bp) <= INNER_PT_PX and \
                    INNER_PT_PX / L < t < 1 - INNER_PT_PX / L:
                out.append((t, n))
        return out

    def _straddles(self, c, A, Bp, inner, w):
        """The caption centred at c stands over an inner point: the point
        is under the middle half of the caption (so the caption belongs to
        the whole segment, not to one of its parts)."""
        L = geo.d(A, Bp)
        tc = geo.proj(c, A, Bp)
        u = geo.unit(A, Bp)
        half = abs(u[0]) * w / 2 + abs(u[1]) * geo.GLYPH_H * \
            self.st["value_size"] / 2
        return any(abs(tc - t) * L <= half / 2 + 0.5 for t, n in inner)

    @staticmethod
    def _side(c, A, Bp):
        return 1 if (Bp[0] - A[0]) * (c[1] - A[1]) - \
            (Bp[1] - A[1]) * (c[0] - A[0]) >= 0 else -1

    def _arc_dists(self, box, angle_name):
        """(distance of box to the arcs of this angle, to any other arc)."""
        own, oth = None, None
        me = set([angle_name, angle_name[::-1]])
        for el, pts in self.marks:
            val = dict(el.attrs).get("data-mark", "")
            k, _, n = val.partition(" ")
            if not k.startswith("arc"):
                continue
            dd = min(geo.box_point_dist(box, p) for p in pts)
            if n in me:
                own = dd if own is None else min(own, dd)
            else:
                oth = dd if oth is None else min(oth, dd)
        return own, oth

    def _value_text(self, f):
        t = TT._value_text(f)
        if f["rel"] == "angle_measure" or \
                self.st["segment_captions_with_unit"]:
            t += TT._unit_text(f)
        return t

    def label_values(self):
        fs = self.st["value_size"]
        for f, eid in self.captions:
            e = self.ix.entities[eid]
            text = self._value_text(f)
            w, h = geo.text_width(text, fs), geo.GLYPH_H * fs
            cands = []
            if e["kind"] == "angle":
                a, v, b = self._angle_names(eid)
                src = "ang %s%s%s" % (a, v, b)
                role = "angle_caption"
                V, A, Bp = self.P[v], self.P[a], self.P[b]
                ua, ub = geo.unit(V, A), geo.unit(V, Bp)
                a0, sw = geo.ang_of(ua), geo.signed_sweep(ua, ub)
                r_in = self.arc_r.get(eid, 0.0)
                split = [t for t in self._dirs_at(V)
                         if geo.in_sector((V[0] + math.cos(t),
                                           V[1] + math.sin(t)), V, A, Bp,
                                          0.5)]
                if split:
                    self.issues.append(_issue(
                        "RENDER_LABEL_NO_PLACE", f["id"], "a drawn line "
                        "splits %s: its value would read as a part of it"
                        % eid))
                for fi, frac in enumerate((0.5, 0.42, 0.58, 0.34, 0.66,
                                           0.26, 0.74)):
                    t = a0 + sw * frac
                    ext = abs(math.cos(t)) * w / 2 + abs(math.sin(t)) * h / 2
                    rho = r_in + 3.0 + ext
                    k = 0
                    while rho <= LABEL_VALUE_PX - 1.0:
                        c = (V[0] + rho * math.cos(t),
                             V[1] + rho * math.sin(t))
                        cands.append((k * 1.0 + fi * 1.5, len(cands), c))
                        rho += 2.0
                        k += 1

                def own(c, V=V, A=A, Bp=Bp, v=v, r_in=r_in, w=w, h=h):
                    dv = geo.d(c, V)
                    if dv > LABEL_VALUE_PX - 0.5 or \
                            not geo.in_sector(c, V, A, Bp, 1.0):
                        return False
                    if r_in > 0:
                        bx = (c[0] - w / 2, c[1] - h / 2, c[0] + w / 2,
                              c[1] + h / 2)
                        # (pilot_build) nearer its own arc than any other
                        # arc by a margin (the checker: CHK_CAPTION_OTHER_ARC)
                        own_d, oth_d = self._arc_dists(bx, a + v + b)
                        if own_d is not None and oth_d is not None and \
                                oth_d < own_d + CAPTION_OWN_ARC_MARGIN_PX:
                            # the retry may draw a larger own arc, next to
                            # this place (then it is the nearest arc)
                            if self._box_ok(geo.text_box(text, fs, c)) and \
                                    f["id"] not in self.caption_far and \
                                    oth_d > CAPTION_ARC_GAP_PX + 1:
                                self.caption_far[f["id"]] = \
                                    geo.box_point_dist(bx, V)
                            return False
                        far = geo.box_point_dist(bx, V) - r_in
                        if far > CAPTION_ARC_MAX_PX:
                            # a place too far from the arc: remember it --
                            # the retry draws a larger arc (a narrow angle)
                            if self._box_ok(geo.text_box(text, fs, c)) and \
                                    f["id"] not in self.caption_far:
                                self.caption_far[f["id"]] = \
                                    geo.box_point_dist(bx, V)
                            return False
                    return all(geo.d(c, q) >= dv + NEAR_MARGIN_PX
                               for m, q in self.P.items() if m != v)
            elif e["kind"] == "segment":
                a, b = e["ends"]
                src = "seg %s%s" % (a, b)
                role = "segment_caption"
                A, Bp = self.P[a], self.P[b]
                u = geo.unit(A, Bp)
                nrm = (-u[1], u[0])
                cx = sum(q[0] for q in self.P.values()) / len(self.P)
                cy = sum(q[1] for q in self.P.values()) / len(self.P)
                m = ((A[0] + Bp[0]) / 2, (A[1] + Bp[1]) / 2)
                out_side = 1.0 if (m[0] - cx) * nrm[0] + \
                    (m[1] - cy) * nrm[1] >= 0 else -1.0
                for ti, t in enumerate((0.5, 0.42, 0.58, 0.34, 0.66, 0.26,
                                        0.74, 0.18, 0.82)):
                    base = (A[0] + t * (Bp[0] - A[0]),
                            A[1] + t * (Bp[1] - A[1]))
                    for si, side in enumerate((out_side, -out_side)):
                        nn = (side * nrm[0], side * nrm[1])
                        ext = abs(nn[0]) * w / 2 + abs(nn[1]) * h / 2
                        for gi, gap in enumerate((3.0, 5.0, 7.0, 9.0)):
                            c = (base[0] + (gap + ext) * nn[0],
                                 base[1] + (gap + ext) * nn[1])
                            cands.append((ti * 1.0 + si * 2.5 + gi * 0.7,
                                          len(cands), c))

                inner = self._inner_points(a, b)

                def own(c, A=A, Bp=Bp, inner=inner, w=w):
                    dd = geo.seg_dist(c, A, Bp)
                    if dd > LABEL_NEAR_PX - 0.5:
                        return False
                    t = geo.proj(c, A, Bp)
                    if not 0.12 <= t <= 0.88:
                        return False
                    if inner and not self._straddles(c, A, Bp, inner, w):
                        # (fix r1, N1/P1) beside one PART of the segment it
                        # reads as that part's length (BC = 8 printed by E,
                        # under BE, reads BE = 8)
                        return False
                    for el, p, q, k in self.straight:
                        if geo.seg_dist(A, p, q) <= COLLINEAR_PX and \
                                geo.seg_dist(Bp, p, q) <= COLLINEAR_PX:
                            continue
                        if G._far_side(c, A, Bp, p, q):
                            continue      # (fix r1) across the segment
                        if geo.seg_dist(c, p, q) < dd + NEAR_MARGIN_PX:
                            return False
                    return True
            else:
                self.issues.append(_issue("RENDER_FACT_NOT_MARKED", f["id"],
                                          "no caption for a %s value"
                                          % e["kind"]))
                continue
            cands.sort()
            it = self.item(role, {"fact": f["id"], "entity": eid})
            chosen = None
            for strict in (True, False):
                for _, _, c in cands:
                    if own(c) and self._box_ok(geo.text_box(text, fs, c),
                                               strict=strict):
                        chosen = c
                        break
                if chosen:
                    break
            if chosen is not None and e["kind"] == "segment" and inner:
                A, Bp = self.P[e["ends"][0]], self.P[e["ends"][1]]
                side = self._side(chosen, A, Bp)
                for tn, n in inner:
                    self.caption_side.setdefault(n, []).append((A, Bp, side))
            if chosen is None:
                self.issues.append(_issue("RENDER_LABEL_NO_PLACE", f["id"],
                                          "no place for %r at %s alone"
                                          % (text, eid)))
                if e["kind"] == "angle":
                    self.caption_failed[f["id"]] = eid
                chosen = cands[0][2] if cands else (self.W / 2, self.H / 2)
            self._text_el(it, src, text, fs, chosen)

    # ------------------------------------------------------- serialise --
    def number(self):
        k = 0
        for layer in LAYERS:
            for el in self.els:
                if el.layer == layer:
                    k += 1
                    el.id = "e%04d" % k

    def svg(self):
        out = ['<?xml version="1.0" encoding="UTF-8"?>',
               '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %s %s" '
               'width="%s" height="%s">' % (geo.fmt(self.W), geo.fmt(self.H),
                                             geo.fmt(self.W),
                                             geo.fmt(self.H))]
        for layer in LAYERS:
            els = [el for el in self.els if el.layer == layer]
            if not els:
                continue
            out.append('<g data-layer="%s">' % layer)
            for el in els:
                attrs = " ".join('%s="%s"' % (k, _esc(v)) for k, v in
                                 [("id", el.id)] + el.attrs)
                if el.tag == "text":
                    # (v6.9 fix r2, E1b) a label with a Hebrew letter is
                    # stored in VISUAL order under a bidi override: WeasyPrint
                    # does not run bidi inside SVG, a browser honours the
                    # override -- both print the same glyph order. The object
                    # map keeps the logical text (el.text).
                    content = el.text
                    if BIDI.has_rtl(content):
                        attrs += "".join(' %s="%s"' % kv
                                         for kv in BIDI.BIDI_ATTRS)
                        content = BIDI.visual(content)
                    out.append("<text %s>%s</text>" % (attrs, _esc(content)))
                else:
                    out.append("<%s %s/>" % (el.tag, attrs))
            out.append("</g>")
        out.append("</svg>")
        return "\n".join(out) + "\n"

    # ------------------------------------------------------ object map --
    def _names_at(self, p):
        return [n for n, q in sorted(self.P.items()) if geo.d(p, q) <= 0.011]

    def cover(self, a, b):
        """Parts drawing the straight piece between the points named a and
        b: one element containing both (the shortest; 'whole' when its ends
        are exactly a and b), else collinear elements whose union covers
        a..b, each clipped at named points. None when it is not drawn."""
        A, Bp = self.P[a], self.P[b]
        one = self._covered_by(A, Bp)
        if one:
            def key(x):
                el, p, q, k = x
                exact = set(self._names_at(p)) >= {a} and \
                    set(self._names_at(q)) >= {b} or \
                    set(self._names_at(p)) >= {b} and \
                    set(self._names_at(q)) >= {a}
                return (0 if exact else 1, geo.d(p, q), el.id)
            el, p, q, k = sorted(one, key=key)[0]
            exact = key((el, p, q, k))[0] == 0
            whole = exact and el.tag == "line"
            return [{"element": el.id,
                     "span": "whole" if whole else [a, b]}]
        # several collinear pieces
        col = [(el, p, q, k) for el, p, q, k in self.straight
               if geo.line_dist(p, A, Bp) <= COLLINEAR_PX and
               geo.line_dist(q, A, Bp) <= COLLINEAR_PX]
        ivs = []
        for el, p, q, k in col:
            t0, t1 = sorted((geo.proj(p, A, Bp), geo.proj(q, A, Bp)))
            lo, hi = max(t0, 0.0), min(t1, 1.0)
            if hi - lo > 1e-9:
                ivs.append((lo, hi, el))
        ivs.sort(key=lambda x: (x[0], -x[1], x[2].id))
        reach, parts = 0.0, []
        tol = COLLINEAR_PX / max(geo.d(A, Bp), 1e-9)
        for lo, hi, el in ivs:
            if lo > reach + tol:
                return None
            if hi <= reach + tol:
                continue
            p0 = (A[0] + max(lo, reach) * (Bp[0] - A[0]),
                  A[1] + max(lo, reach) * (Bp[1] - A[1]))
            p1 = (A[0] + hi * (Bp[0] - A[0]), A[1] + hi * (Bp[1] - A[1]))
            n0, n1 = self._names_at(p0), self._names_at(p1)
            if not n0 or not n1:
                return None
            parts.append({"element": el.id, "span": [n0[0], n1[0]]})
            reach = hi
        if reach < 1 - tol or not parts:
            return None
        return parts

    def objects(self):
        ix = self.ix
        out = {}
        marks_of, caps_of, names_of = {}, {}, {}
        for it in self.items:
            ent_ = it.source.get("entity")
            if it.role in ("angle_arc", "right_mark", "tick",
                           "parallel_arrow"):
                marks_of.setdefault(ent_, []).extend(it.elements)
            elif it.role in ("angle_caption", "segment_caption"):
                caps_of.setdefault(ent_, []).extend(it.elements)
            elif it.role in ("point_name", "line_name"):
                names_of.setdefault(ent_, []).extend(it.elements)
        dots = dict((it.source["entity"], it.elements[0]) for it in
                    self.items if it.role == "point")
        own = dict((it.source["entity"], it.elements[0]) for it in
                   self.items if it.role in ("line", "ray", "polygon"))

        def whole(els):
            return [{"element": el.id, "span": "whole"} for el in els]
        for eid in sorted(ix.entities):
            e = ix.entities[eid]
            k = e.get("kind")
            parts = None
            if k == "point":
                if eid in dots:
                    parts = whole([dots[eid]] + names_of.get(eid, []))
            elif k == "segment":
                a, b = e["ends"]
                if a in self.P and b in self.P:
                    c = self.cover(a, b)
                    if c:
                        parts = c + whole(marks_of.get(eid, []) +
                                          caps_of.get(eid, []))
            elif k in ("line", "ray"):
                if eid in own:
                    parts = whole([own[eid]] + names_of.get(eid, []))
            elif k == "angle":
                a, v, b = self._angle_names(eid)
                if all(x in self.P for x in (a, v, b)):
                    ca, cb = self.cover(v, a), self.cover(v, b)
                    if ca and cb:
                        parts = ca + cb + whole(marks_of.get(eid, []) +
                                                caps_of.get(eid, []))
            elif k == "polygon":
                vs = e["vertices"]
                if all(x in self.P for x in vs):
                    if eid in own:
                        parts = whole([own[eid]] + names_of.get(eid, []))
                    else:
                        cs = [self.cover(vs[i], vs[(i + 1) % len(vs)])
                              for i in range(len(vs))]
                        if all(cs):
                            parts = [p for c in cs for p in c]
            if parts:
                out[eid] = {"kind": k, "parts": parts}
        return out

    def construction(self):
        """For every to_construct item whose reader sees this figure: the
        declaration (templates.construct_decl) -- given (its base and the
        points public givens fix), shown (what this figure draws), and what
        the student does (the result, its new points, join / locate)."""
        ix, fid = self.ix, self.fig["id"]
        out = []
        for f in sorted(ix.facts.values(), key=lambda f: f["id"]):
            if f.get("role") != "to_construct":
                continue
            it = ix.items.get(f.get("item")) or {}
            q = ix.questions.get(ix.scope_question.get(f.get("item"))) or {}
            if fid not in (it.get("figure"), q.get("figure")) and \
                    self.fig.get("scope") not in (f.get("item"), q.get("id")):
                continue
            decl = TT.construct_decl(self.tset, f.get("rel"))
            args = f.get("args") or []
            if decl is None:
                self.issues.append(_issue("RENDER_CONSTRUCTION", f["id"],
                                          "no declaration for %s" % f["rel"]))
                continue
            result = args[decl[0]]
            base = [args[b] for b in decl[1]]
            base_pts = set()
            for b in base:
                base_pts |= B._points_in(b, ix)
            rpts = B._points_in(result, ix)
            given_pts = B._given_points(ix, f.get("item"), rpts)
            # (pilot_build) a POINT result is itself the new point the
            # student finds (construct_midpoint M): it is new too
            new_pts = sorted(p for p in rpts - base_pts
                             if p not in given_pts) \
                if decl[2] else []
            out.append({
                "item": f["item"], "fact": f["id"], "rel": f["rel"],
                "mode": decl[3],
                "given": {"base": base, "points_fixed_by_givens":
                          sorted(given_pts)},
                "shown": sorted(self.shown),
                "student_does": {"result": result,
                                 "defining_points":
                                     B._defining_points(result, ix),
                                 "new_points": new_pts}})
        return out

    def check_construction(self, decls, objs):
        """The declaration against the DRAWING (not the spec). The result
        is placed by the layout (it is never drawn), so the check sees it
        at its true place: no drawn element lies on the result's line (as
        itself, inside a longer element, as collinear pieces, on a line /
        ray through it -- any of them shows it); a new point is not drawn;
        a locate task without a new point does not show all its defining
        points (they fix it); a join task shows the points to join."""
        ix = self.ix
        for d in decls:
            res = d["student_does"]["result"]
            k = ix.kind(res)
            dp = [ix.entities[p]["name"] for p in
                  d["student_does"]["defining_points"]]
            unplaced = [p for p in dp if p not in self.Pall]
            if unplaced:
                self.issues.append(_issue(
                    "CONS_UNPLACED", d["fact"], "the layout does not place "
                    "%s, so the drawing cannot be checked against the "
                    "result %s" % (", ".join(unplaced), res)))
                continue
            if k in ("segment", "line", "ray"):
                A, Bp = self.Pall[dp[0]], self.Pall[dp[1]]
                for el, p, q, kk in self.straight:
                    if geo.line_dist(p, A, Bp) <= COLLINEAR_PX and \
                            geo.line_dist(q, A, Bp) <= COLLINEAR_PX:
                        self.issues.append(_issue(
                            "CONS_RESULT_DRAWN", d["fact"], "the drawn "
                            "element %s lies on the line of the result %s "
                            "(it draws it, or a piece of it, or its "
                            "direction)" % (el.id, res)))
                        break
            if res in objs:
                self.issues.append(_issue("CONS_RESULT_DRAWN", d["fact"],
                                          "the result %s is an object of "
                                          "the drawing" % res))
            for p in d["student_does"]["new_points"]:
                if ix.entities[p]["name"] in self.P:
                    self.issues.append(_issue("CONS_STEP_DRAWN", d["fact"],
                                              "the new point %s is drawn"
                                              % p))
            if d["mode"] == "locate" and not d["student_does"]["new_points"] \
                    and dp and all(p in self.P for p in dp):
                self.issues.append(_issue(
                    "CONS_RESULT_DRAWN", d["fact"], "every defining point of "
                    "the result %s is drawn: they fix it" % res))
            if d["mode"] == "join":
                miss = [p for p in dp if p not in self.P]
                if miss:
                    self.issues.append(_issue(
                        "CONS_JOIN_UNSHOWN", d["fact"], "join: %s not drawn"
                        % ", ".join(miss)))

    def object_map(self, public_hash, settings_hash):
        elements = {}
        for el in self.els:
            elements[el.id] = {"tag": el.tag, "item": el.item.id}
        items = []
        for it in self.items:
            d = {"id": it.id, "role": it.role, "source": dict(it.source),
                 "elements": [el.id for el in it.elements]}
            if it.text is not None:
                d["text"] = it.text
            items.append(d)
        objs = self.objects()
        decls = self.construction()
        self.check_construction(decls, objs)
        return {"engine": ENGINE_VERSION, "dialect": DIALECT_VERSION,
                "figure": self.fig["id"], "public_hash": public_hash,
                "settings_hash": settings_hash, "elements": elements,
                "display_items": items, "objects": objs,
                "construction": decls}

    def placements(self):
        s = self.s
        return {"engine": ENGINE_VERSION, "figure": self.fig["id"],
                "canvas_px": [geo.r2(self.W), geo.r2(self.H)],
                "model_to_svg": {"matrix": [_r6(s), 0, 0, _r6(-s),
                                            _r6(self.tx), _r6(self.ty)],
                                 "note": "X = a*x + e, Y = d*y + f "
                                         "(model y up, SVG y down)"},
                "points_px": dict((n, [p[0], p[1]]) for n, p in
                                  sorted(self.P.items())),
                "page": {"unit": "pt", "pt_per_px": 0.75,
                         "size_pt": [_r6(self.W * 0.75), _r6(self.H * 0.75)],
                         "note": "one SVG px = 0.75 pt; the page builder "
                                 "places the figure box at this size (PDF "
                                 "integration is not part of this round)"}}


def _r6(x):
    v = round(x + 0.0, 6)
    return 0.0 if v == 0 else v


def _esc(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(
        ">", "&gt;").replace('"', "&quot;")


def _map_issues(svg_text, om, pub):
    """The object map is TOTAL and every source resolves: every element of
    the file is in the map with exactly one display item; every item's
    elements are in the file; every source names a public entity / fact;
    every object part names a mapped element."""
    import re
    ids = re.findall(r' id="(e[0-9]{4})"', svg_text)
    out = []
    if sorted(ids) != sorted(om["elements"]) or len(set(ids)) != len(ids):
        out.append(_issue("MAP_NOT_TOTAL", om["figure"], "file ids %d vs map "
                          "%d" % (len(ids), len(om["elements"]))))
    owner = {}
    ents = set(e["id"] for e in pub["entities"])
    facts = set(f["id"] for f in pub["facts"])
    for it in om["display_items"]:
        if it["role"] not in ROLES:
            out.append(_issue("MAP_BAD_ROLE", it["id"], it["role"]))
        src = it["source"]
        if not src or (src.get("entity") and src["entity"] not in ents) or \
                (src.get("fact") and src["fact"] not in facts):
            out.append(_issue("MAP_BAD_SOURCE", it["id"], repr(src)))
        for e in it["elements"]:
            if e in owner:
                out.append(_issue("MAP_SHARED_ELEMENT", e, "%s and %s"
                                  % (owner[e], it["id"])))
            owner[e] = it["id"]
    for e, rec in om["elements"].items():
        if owner.get(e) != rec["item"]:
            out.append(_issue("MAP_NOT_TOTAL", e, "no single owner"))
    for oid, o in om["objects"].items():
        for p in o["parts"]:
            if p["element"] not in om["elements"]:
                out.append(_issue("MAP_BAD_PART", oid, p["element"]))
    return out


GROW_STEPS = (1.0, 1.15, 1.3, 1.5, 1.75, 2.0)


def _attempt(public_spec, ix, fig, st):
    """One build; an angle value with no place gets a smaller arc and the
    figure is built again from scratch (the same retries every time)."""
    override = {}
    for _ in range(8):
        b = _Builder(public_spec, ix, fig, st, override)
        b.plan()
        b.place()
        b.draw_objects()
        b.draw_facts()
        b.draw_points()
        b.label_values()
        b.label_points()
        b.label_lines()
        retry = False
        for i in b.issues:
            aid = b.caption_failed.get(i["where"]) \
                if i["code"] == "RENDER_LABEL_NO_PLACE" else None
            far = b.caption_far.get(i["where"])
            if aid and aid in b.arc_r and far is not None and \
                    far - CAPTION_ARC_GAP_PX > b.arc_r[aid] + 0.5 and \
                    far - CAPTION_ARC_GAP_PX <= ARC_MAX_PX:
                # a narrow angle: its value fits only farther out -- a
                # larger arc keeps the value next to it (pilot_build)
                override[aid] = far - CAPTION_ARC_GAP_PX
                retry = True
            elif aid and aid in b.arc_r and b.arc_r[aid] > ARC_MIN_PX:
                override[aid] = max(ARC_MIN_PX, b.arc_radius(aid) - 2.0)
                retry = True
        if not retry:
            break
    return b


def render(public_spec, display_settings, engine_version):
    """See the module docstring. Raises RenderRefused for an input it does
    not accept; otherwise returns the four outputs, the validation telling
    whether the figure is fit to print (status PASS) or not (FAIL, with
    the issues)."""
    if engine_version != ENGINE_VERSION:
        raise RenderRefused("RENDER_VERSION", "this engine is %s, not %r"
                            % (ENGINE_VERSION, engine_version))
    gate.require_public(public_spec)
    # (v6.12, family B) a number-line figure is drawn by render/nline.py
    # (its own closed settings, dialect wspec-nl-svg/1 and object map)
    _fg = [g for g in public_spec.get("figures") or [] if isinstance(
        display_settings, dict) and g.get("id") == display_settings.get(
            "figure")]
    # (v6.16 integrate) a GRAPH figure (a coordinate_plane figure carrying
    # the public graph model) is drawn by wspec/graph/render.py from that
    # model and the closed graph settings (dialect wspec-graph-svg/1); a PIE
    # CHART by render/pie.py (dialect wspec-pie-svg/1). Both before the
    # coordinate plane: a graph's frame IS a coordinate_plane frame.
    if _fg and isinstance(_fg[0].get("graph"), dict):
        from ..graph import render as _graph
        return _graph.render(_fg[0]["graph"], display_settings,
                             _graph.ENGINE_VERSION)
    if _fg and (_fg[0].get("frame") or {}).get("family") == "pie_chart":
        from . import pie as _pie
        return _pie.render(public_spec, display_settings, _pie.ENGINE_VERSION)
    if _fg and (_fg[0].get("frame") or {}).get("family") == "number_line":
        from . import nline as _nline
        return _nline.render(public_spec, display_settings,
                             _nline.ENGINE_VERSION)
    # (v6.12, family A) a coordinate-plane figure is drawn by render/coord.py
    from . import coord as _coord
    if isinstance(display_settings, dict) and any(
            g.get("id") == display_settings.get("figure") and
            _coord.is_coord(g) for g in public_spec.get("figures") or []):
        return _coord.render(public_spec, display_settings, engine_version)
    st = gate.settings(display_settings)
    ix = S.Index(public_spec)
    fig = ix.figures.get(st["figure"])
    if fig is None:
        raise RenderRefused("RENDER_BAD_SETTINGS", "figure %r is not in the "
                            "public model" % st["figure"])
    # a label with no place: first a smaller arc for an angle value, then
    # a larger figure (GROW_STEPS), and only then a FAIL naming the label
    w0 = float(st["width"])
    h0 = st["height"]
    for g in GROW_STEPS:
        sg = dict(st)
        sg["width"] = min(1200.0, round(w0 * g))
        if h0 is not None:
            sg["height"] = min(1200.0, round(h0 * g))
        b = _attempt(public_spec, ix, fig, sg)
        if not any(i["code"] == "RENDER_LABEL_NO_PLACE" for i in b.issues) \
                or not st["grow"]:
            break
    b.number()
    svg = b.svg()
    settings_hash = hashlib.sha256(canon.dumps(st).encode("utf-8")) \
        .hexdigest()
    om = b.object_map(public_spec["public_hash"], settings_hash)
    geom = []
    fd, path = tempfile.mkstemp(suffix=".svg")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(svg)
        for i in G.check_geometry(path, public_spec, fig["id"]):
            geom.append(_issue(i.code, i.where if i.where != path else
                               "svg", i.detail.replace(path, "svg")))
    finally:
        os.unlink(path)
    issues = sorted(b.issues + geom + _map_issues(svg, om, public_spec),
                    key=lambda i: (i["code"], i["where"], i["detail"]))
    validation = {"engine": ENGINE_VERSION, "figure": fig["id"],
                  "status": "PASS" if not issues else "FAIL",
                  "issues": issues,
                  "checked": ["gate: public model only", "settings closed",
                              "geomcheck (dialect %s, hooks, geometry, "
                              "marks, labels) against the public model"
                              % DIALECT_VERSION,
                              "object map total, one owner per element, "
                              "sources resolve",
                              "construction declaration vs the drawing"],
                  "svg_sha256": hashlib.sha256(svg.encode("utf-8"))
                  .hexdigest()}
    pl = b.placements()
    pl["asked_width_px"] = geo.r2(w0)
    pl["grown"] = b.W != w0
    return {"svg": svg, "object_map": om, "placements": pl,
            "validation": validation}


def dumps(obj):
    """The byte form of a map / placements / validation (sorted keys)."""
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, indent=1) + \
        "\n"
