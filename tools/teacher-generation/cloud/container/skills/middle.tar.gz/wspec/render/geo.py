# -*- coding: utf-8 -*-
"""Plane helpers in SVG px (y down) for the renderer. Stdlib only."""
import math

# the glyph model the dialect's checker uses for a label box (geomcheck
# GLYPH_W / GLYPH_H): a character is 0.6 x 0.7 of the font size
GLYPH_W = 0.6
GLYPH_H = 0.7


def d(p, q):
    return math.hypot(p[0] - q[0], p[1] - q[1])


def seg_dist(p, a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    L2 = dx * dx + dy * dy
    if L2 == 0:
        return d(p, a)
    t = max(0.0, min(1.0, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / L2))
    return d(p, (a[0] + t * dx, a[1] + t * dy))


def line_dist(p, a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    L = math.hypot(dx, dy)
    if L == 0:
        return d(p, a)
    return abs((p[0] - a[0]) * dy - (p[1] - a[1]) * dx) / L


def proj(p, a, b):
    """The parameter t of p's projection on a + t (b - a)."""
    dx, dy = b[0] - a[0], b[1] - a[1]
    L2 = dx * dx + dy * dy
    return ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / L2


def unit(a, b):
    L = d(a, b)
    return ((b[0] - a[0]) / L, (b[1] - a[1]) / L)


def ang_of(u):
    return math.atan2(u[1], u[0])


def angle_deg(v, a, b):
    """The non-reflex angle a-v-b in degrees."""
    ua, ub = unit(v, a), unit(v, b)
    c = max(-1.0, min(1.0, ua[0] * ub[0] + ua[1] * ub[1]))
    return math.degrees(math.acos(c))


def signed_sweep(ua, ub):
    """The signed angle (radians, in (-pi, pi]) turning ua to ub."""
    s = ang_of(ub) - ang_of(ua)
    while s <= -math.pi:
        s += 2 * math.pi
    while s > math.pi:
        s -= 2 * math.pi
    return s


def in_sector(c, v, a, b, margin_deg=0.0):
    """c strictly inside the non-reflex angle a-v-b (with a margin from
    both arms)."""
    if d(c, v) == 0:
        return False
    whole = angle_deg(v, a, b)
    t1, t2 = angle_deg(v, a, c), angle_deg(v, c, b)
    return abs(t1 + t2 - whole) < 1e-6 * max(1.0, whole) and \
        t1 > margin_deg and t2 > margin_deg


def clip_len(p, q, box):
    """Length of segment p-q inside the box (x0, y0, x1, y1)."""
    x0, y0, x1, y1 = box
    dx, dy = q[0] - p[0], q[1] - p[1]
    t0, t1 = 0.0, 1.0
    for pk, qk in ((-dx, p[0] - x0), (dx, x1 - p[0]), (-dy, p[1] - y0),
                   (dy, y1 - p[1])):
        if pk == 0:
            if qk < 0:
                return 0.0
            continue
        t = qk / pk
        if pk < 0:
            t0 = max(t0, t)
        else:
            t1 = min(t1, t)
        if t0 > t1:
            return 0.0
    return (t1 - t0) * math.hypot(dx, dy)


# (pilot_build 2026-09-23) ink width per character, as a fraction of the
# font size, measured on the MuPDF raster of the serif face the renderer
# names (digits 0.46, the degree sign 0.40, M 0.88 ...); an unknown
# character counts GLYPH_W. The box is the INK box: labels are placed and
# highlighted by it (the checker measures the ink).
INK_W = dict([(c, 0.46) for c in "0123456789"] + [
    ("°", 0.41), (".", 0.25), (",", 0.25), (" ", 0.25), ("+", 0.56),
    ("−", 0.56), ("-", 0.33), ("√", 0.55), ("x", 0.5),
    ("A", 0.72), ("B", 0.61), ("C", 0.63), ("D", 0.70), ("E", 0.61),
    ("F", 0.56), ("G", 0.72), ("H", 0.70), ("I", 0.35), ("J", 0.40),
    ("K", 0.72), ("L", 0.61), ("M", 0.88), ("N", 0.72), ("O", 0.68),
    ("P", 0.56), ("Q", 0.68), ("R", 0.67), ("S", 0.56), ("T", 0.61),
    ("U", 0.72), ("V", 0.72), ("W", 0.95), ("X", 0.72), ("Y", 0.72),
    ("Z", 0.61)])


def ink_width(text, fs):
    return fs * sum(INK_W.get(ch, GLYPH_W) for ch in text)


def text_width(text, fs):
    """The width a label is PLACED with: the wider of its ink and the
    dialect's estimate (GLYPH_W per character, which geomcheck measures
    with) -- so both the raster checker and geomcheck find it clear."""
    return max(ink_width(text, fs), GLYPH_W * fs * len(text))


def text_box(text, fs, c):
    """The glyph box (x0, y0, x1, y1) of `text` centred at c."""
    w = text_width(text, fs)
    h = GLYPH_H * fs
    return (c[0] - w / 2, c[1] - h / 2, c[0] + w / 2, c[1] + h / 2)


def text_anchor_xy(text, fs, c):
    """(x, y) of a text-anchor=middle <text> whose glyph box is centred at
    c (the checker reads the box from the baseline: centre y = y - h/2)."""
    return (c[0], c[1] + GLYPH_H * fs / 2)


def inflate(box, m):
    return (box[0] - m, box[1] - m, box[2] + m, box[3] + m)


def boxes_overlap(a, b):
    return not (a[2] <= b[0] or b[2] <= a[0] or a[3] <= b[1] or b[3] <= a[1])


def box_point_dist(box, p):
    dx = max(box[0] - p[0], 0.0, p[0] - box[2])
    dy = max(box[1] - p[1], 0.0, p[1] - box[3])
    return math.hypot(dx, dy)


def r2(x):
    """Round to the dialect's two decimals (and clear -0.0)."""
    v = round(x + 0.0, 2)
    return 0.0 if v == 0 else v


def fmt(x):
    """A dialect number: at most two decimals, no sign, no trailing
    zeros beyond one decimal ('40', '40.5', '40.25')."""
    v = r2(x)
    if v < 0:
        raise ValueError("negative coordinate %r" % x)
    s = "%.2f" % v
    s = s.rstrip("0").rstrip(".") if "." in s else s
    return s
