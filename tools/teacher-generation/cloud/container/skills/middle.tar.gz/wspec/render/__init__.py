# -*- coding: utf-8 -*-
"""wspec.render -- the rendering engine of the closed dialect (brief
sections 2 and 4): render(public_spec, display_settings, engine_version)
and highlight(svg, object_map, object_id). Stdlib only."""
from .engine import ENGINE_VERSION, DIALECT_VERSION, render, dumps  # noqa
from .gate import RenderRefused                                      # noqa
from .highlight import highlight, verify_highlight, HighlightError   # noqa
from .layout import LayoutError                                      # noqa
