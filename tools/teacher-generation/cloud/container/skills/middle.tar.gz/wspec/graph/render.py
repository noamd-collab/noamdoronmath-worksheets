# -*- coding: utf-8 -*-
"""wspec.graph.render -- the GRAPH renderer (v6.16, BRIEF_V616 G1-G3).

    out = render(public_graph, display_settings, ENGINE_VERSION)
    -> {"svg", "object_map", "placements", "validation"}

INPUT: ONLY a public graph model (kinds.public_model: exactly its keys, a
clean scan, its own hash) and the closed display settings below. The
numbers of a curve / mark the public model does not carry (something about
it is asked) come from the settings' "curves" / "marks" layout -- where
the figure puts them, never a text; a layout entry for a public curve must
agree with it (RENDER_LAYOUT).

display settings (closed; defaults in brackets)
  figure        the figure id (required)
  curves  [[]]  [{"curve": id, "def": {...}, "extent"?: [x0, x1]}]
  marks   [[]]  [{"mark": id, "xy": [x, y]}]
  square [13.33] px per x interval (10 .. 26); aspect 'equal' makes the y
                interval square * step_y / step_x px (one data unit as long
                on both axes), 'free' makes the cells square. The figure
                GROWS it (x1.15, up to 26) when a number or a label has no
                room; then RENDER_AXIS_CROWDED / RENDER_LABEL_NO_PLACE.
  font_family [serif] serif | sans-serif | David Libre,serif
  number_size [10.67] 10.67 | 12      name_size [12.67] 12 | 12.67 | 14
  point_radius [2.67] 2 | 2.5 | 2.67 | 3      grow [true]

HOUSE LOOK (the coordinate plane's, render/coord.py): grey grid 0.35 pt at
every step, knocked out under every text; black axes 0.8 pt through the
origin with a filled arrowhead at the positive end; the axis letter
(italic) beside it; an axis title (Hebrew, exactly as given) under the x
axis' numbers / over the y arrow; numbers 8 pt with U+2212, below the x
axis and left of the y axis, never dropped, never crossed by a stroke.
Curves 1 pt, ONE uncut element each, clipped exactly at the window: a line
or a vertical line is a <line>, a parabola ONE quadratic Bezier <path>
(exact: a parabola arc IS a quadratic Bezier, and the page map is affine);
dashed = stroke-dasharray 4 3. Marks: filled dots. Reading guides (dashed,
3 2) only where the public model says they are stated. A curve label
stands beside its own curve (nearer to it than to any other curve by 0.3
step, 0.5 step away from any crossing), a mark label beside its dot; no
text covers a stroke, a dot, a tick, an arrow or another text.

SVG (wspec-graph-svg/1, graph_dialect.json): layers grid, axes, curves,
guides, marks, labels; ids e0001.. in document order; ONE hook per element:
  <line data-grid="x 3">  <line data-axis="x">  <polygon data-arrow="x">
  <line data-tick="x 3">  <line|path data-curve="curve:a">
  <line data-guide="mark:G x">  <circle data-pt="mark:V">
  <text data-num="x 3"> / data-num="origin"  <text data-axname="x">
  <text data-axtitle="x" direction="ltr" unicode-bidi="bidi-override">
  <text data-for="curve:a">  <text data-for="mark:V">
Hooks carry ids and tick indices only -- never a value.

object_map: engine, dialect, figure, public_hash, settings_hash, elements,
display_items (roles ROLES), objects: curve (stroke + label), mark (dot +
label), axis (line + arrow + ticks + numbers + letter + title; the origin
'0' is in both), plane (the grid pieces), guide ('guide:<mark>:<axis>').
A find (a not-drawn object) has no object: its highlight is empty.
"""
import hashlib
import json
import math
import os
import re
from fractions import Fraction

from .. import canon
from ..render import geo
from ..render.gate import RenderRefused
from . import kinds as K
from . import rtl

ENGINE_VERSION = "wspec-graph-render/1.0.0"
DIALECT = "wspec-graph-svg/1"
INK = "#000000"
GRID_INK = "#c8c8c8"
W_AXIS = "1.07"
W_DATA = "1.33"
W_GRID = "0.47"
W_TICK = "0.8"
W_GUIDE = "0.8"
DASH_CURVE = "4 3"
DASH_GUIDE = "3 2"
TICK_HALF_PX = 3.0
NUM_GAP_PX = 1.5
ARROW_LEN_PX = 7.0
ARROW_HALF_PX = 2.8
AX_EXT_NEG = 0.5
AX_EXT_POS = 0.6
MIN_SQUARE_PX = 10.0
MAX_SQUARE_PX = 26.0
MAX_SQUARE_CROWDED_PX = 32.0   # a number still crowded at 26 (a curve
                               # crossing the axis AT its tick) may grow
                               # the square this far, never further
MAX_CANVAS_PX = 1400.0
DEFAULT_SQUARE_PX = 13.33
GROW = 1.15
LABEL_PAD_PX = 1.0
LABEL_TEXT_GAP_PX = 4.0     # a curve / mark label keeps this from other texts
                            # (never read together with a number: 'y = 25 25')
NUM_INK_SLACK_PX = 1.0
NUM_SPACE_PX = 3.5
NUM_ALONG_STEP = 0.245      # a number slides at most this along its axis
NUM_ACROSS_MAX_PX = 12.0    # ... and steps at most this far out from its
                            # usual place (a curve crossing the axis at it)
NUM_CURVE_CLEAR_PX = 2.0    # a number keeps this from a curve stroke
                            # (v6.16 fix r1, verify S-P1: at 1.0 px the
                            # printed glyphs of '−7', '10', '−6' touched a
                            # data curve by 0.1-0.5 pt -- the ink model's box
                            # is a hair narrower than the ink; 2.0 px = the
                            # clearance every other text keeps) ...
NUM_CURVE_CLEAR_MIN_PX = 1.0  # ... on its OWN side of its axis; when no
                            # place there has 2.0 px, the v6.15 placement
                            # (1.0 px, own side first, then across) is kept
                            # unchanged: the wider clearance never sends a
                            # number across its axis (fix r1: an x-axis '−1'
                            # sent above the axis read as a y number, GS44)
DOT_CLEAR_PX = 1.5
OWN_MARGIN_PX = 2.0
MARGIN_PX = 6.0
KNOCK_PX = 1.0
DESCENT = 0.22
LABEL_ROOM_SQ = 2.5
CURVE_OWN_STEP = 0.3        # a curve label nearer its own curve by this
CROSS_CLEAR_STEP = 0.5      # a curve label this far from any crossing
SAMPLE_PX = 2.0             # curve obstacle / distance samples
CURVE_CLEAR_PX = 2.0        # a text keeps this from a curve stroke (other
                            # strokes: LABEL_PAD_PX)
LAYERS = ("grid", "axes", "curves", "guides", "marks", "labels")
# the role names of the acceptance runner (v616/HOOKS.txt [RUNNER] graph)
ROLES = ("grid_line", "axis_line", "axis_arrow", "tick", "axis_number",
         "origin_zero", "axis_name", "axis_unit", "curve", "curve_label",
         "mark", "mark_label", "optional_mark", "optional_label", "guide")
PUBLIC_TOP = {"graph_public", "figure", "frame", "axes", "aspect", "curves",
              "marks", "parallel", "finds", "public_hash"}
PUBLIC_TOP_OPTIONAL = {"givens"}   # (round 2) a givens-only figure: true
PUBLIC_CURVE = {"id", "fn", "style", "label", "def", "extent", "symmetry_of"}
PUBLIC_MARK = {"id", "kind", "on", "label", "guides", "xy", "optional"}
PUBLIC_FIND = {"id", "item", "rel", "args", "at"}
PUBLIC_FRAME = {"family", "plane", "grid", "axes"}
PUBLIC_AXIS = {"axis", "intervals", "labels"}


def _pos(v, lo, hi):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and \
        lo <= v <= hi


SETTINGS = {
    "figure": (lambda v: isinstance(v, str), None),
    "curves": (lambda v: isinstance(v, list), []),
    "marks": (lambda v: isinstance(v, list), []),
    "square": (lambda v: _pos(v, MIN_SQUARE_PX, MAX_SQUARE_PX),
               DEFAULT_SQUARE_PX),
    "font_family": (lambda v: v in ("serif", "sans-serif",
                                    "David Libre,serif"), "serif"),
    "number_size": (lambda v: v in (10.67, 12), 10.67),
    "name_size": (lambda v: v in (12, 12.67, 14), 12.67),
    "point_radius": (lambda v: v in (2, 2.5, 2.67, 3), 2.67),
    "grow": (lambda v: isinstance(v, bool), True),
}


# (v6.16 integrate) the file is closed: an unclosed file's ResourceWarning,
# shown inside a unittest run, turned the swig shutdown warning into the
# last output line and selfcheck_wspec_engine read test_pilot as FAIL
with open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                       "graph_dialect.json"), encoding="utf-8") as _fh:
    _DIALECT = json.load(_fh)


def _desc(text, fs):
    """the descent of a text with g j p q y (the dialect's box holds it)"""
    return _DIALECT["descent"] * fs if any(c in "gjpqy" for c in text) \
        else 0.0


def tw(text, fs):
    """the dialect's text width (graph_dialect.json ink_w / glyph_w): the
    renderer places and the checker measures every text with it"""
    return fs * sum(_DIALECT["ink_w"].get(c, _DIALECT["glyph_w"])
                    for c in text)



# (v6.16 fix r1, verify P2-M1) a label printing a glyph the house text face
# lacks -- the superscript of an equation label 'y = x²' -- names the
# shipped symbol face before the generic one, so the PDF takes the glyph
# from HouseSym (DejaVuSans, pinned by the page's @font-face; G70 accepts
# it) instead of an unpinned system serif. Every other text keeps the
# settings' family (byte-identical SVGs for every figure without one).
SYMBOL_FALLBACK = frozenset(u"\u00b2\u00b3")
HOUSE_WITH_SYM = {"David Libre,serif": "David Libre,HouseSym,serif"}


def _family_for(fam, text):
    if fam in HOUSE_WITH_SYM and any(ch in SYMBOL_FALLBACK
                                     for ch in (text or u"")):
        return HOUSE_WITH_SYM[fam]
    return fam

class _SegIndex(object):
    """segments bucketed by px cells, so a box query sees only its
    neighbours"""
    CELL = 12.0

    def __init__(self):
        self.cells = {}
        self.segs = []

    def add(self, p, q):
        k = len(self.segs)
        self.segs.append((p, q))
        x0, x1 = sorted((p[0], q[0]))
        y0, y1 = sorted((p[1], q[1]))
        for i in range(int(math.floor(x0 / self.CELL)),
                       int(math.floor(x1 / self.CELL)) + 1):
            for j in range(int(math.floor(y0 / self.CELL)),
                           int(math.floor(y1 / self.CELL)) + 1):
                self.cells.setdefault((i, j), []).append(k)

    def extend(self, segs):
        for p, q in segs:
            self.add(p, q)

    def hits(self, box):
        seen = set()
        for i in range(int(math.floor(box[0] / self.CELL)),
                       int(math.floor(box[2] / self.CELL)) + 1):
            for j in range(int(math.floor(box[1] / self.CELL)),
                           int(math.floor(box[3] / self.CELL)) + 1):
                for k in self.cells.get((i, j), ()):
                    if k in seen:
                        continue
                    seen.add(k)
                    p, q = self.segs[k]
                    if _seg_hits_box(p, q, box):
                        return True
        return False


def _issue(code, where, detail):
    return {"code": code, "where": where, "detail": detail}


# ---------------------------------------------------------------- gate ---
def scan_public(pub):
    """closed keys and grammars of a public graph model -> [problem]"""
    bad = []

    def keys(obj, allowed, where, required=()):
        if not isinstance(obj, dict):
            bad.append("%s: not an object" % where)
            return False
        for k in obj:
            if k not in allowed:
                bad.append("%s: key %r not public" % (where, k))
        for k in required:
            if k not in obj:
                bad.append("%s: %r missing" % (where, k))
        return True
    if not keys(pub, PUBLIC_TOP | PUBLIC_TOP_OPTIONAL, "public", PUBLIC_TOP):
        return bad
    if "givens" in pub and pub["givens"] is not True:
        bad.append("givens %r (only true is written)" % (pub["givens"],))
    if pub.get("graph_public") != K.PUBLIC_VERSION:
        bad.append("graph_public %r" % (pub.get("graph_public"),))
    if not (isinstance(pub.get("figure"), str) and
            K.FIG_RE.match(pub["figure"])):
        bad.append("figure id %r" % (pub.get("figure"),))
    if pub.get("aspect") not in K.ASPECTS:
        bad.append("aspect %r" % (pub.get("aspect"),))
    fr = pub.get("frame")
    if keys(fr, PUBLIC_FRAME, "frame", PUBLIC_FRAME):
        if fr.get("family") != "coordinate_plane" or \
                fr.get("plane") != "plane:xy" or \
                not isinstance(fr.get("grid"), bool) or \
                not isinstance(fr.get("axes"), list) or \
                len(fr["axes"]) != 2:
            bad.append("frame shape")
        else:
            for a, name in zip(fr["axes"], ("axis:x", "axis:y")):
                if not keys(a, PUBLIC_AXIS, "frame " + name, PUBLIC_AXIS):
                    continue
                n = a.get("intervals")
                if a.get("axis") != name or not isinstance(n, int) or \
                        isinstance(n, bool) or not 1 <= n <= K.MAX_INTERVALS:
                    bad.append("frame axis %r" % (a.get("axis"),))
                    continue
                last = -1
                for lab in a.get("labels") or []:
                    ok = isinstance(lab, list) and len(lab) == 2 and \
                        isinstance(lab[0], int) and \
                        not isinstance(lab[0], bool) and \
                        last < lab[0] <= n and isinstance(lab[1], str) and \
                        K.Q(lab[1]) is not None and \
                        K.cstr(K.Q(lab[1])) == lab[1]
                    if not ok:
                        bad.append("frame label %r" % (lab,))
                        break
                    last = lab[0]
    ax = pub.get("axes")
    if not isinstance(ax, dict) or sorted(ax) != ["x", "y"]:
        bad.append("axes")
    else:
        for a in ("x", "y"):
            if keys(ax[a], {"letter", "title"}, "axes " + a,
                    ("letter", "title")):
                if not isinstance(ax[a]["letter"], bool) or (
                        ax[a]["title"] is not None and
                        not K._title_ok(ax[a]["title"])):
                    bad.append("axes %s" % a)
    cids = set()
    for c in pub.get("curves") or []:
        if not keys(c, PUBLIC_CURVE, "curve", ("id", "fn", "style",
                                               "label")):
            continue
        cid = c.get("id")
        if not (isinstance(cid, str) and K.CURVE_RE.match(cid)) or \
                cid in cids:
            bad.append("curve id %r" % (cid,))
            continue
        cids.add(cid)
        if c.get("fn") not in K.FNS or c.get("style") not in K.STYLES:
            bad.append("curve %s fn / style" % cid)
            continue
        cur = None
        if "def" in c:
            try:
                d = c["def"]
                if set(d) != {"fn"} | set(K.FN_PARAMS[c["fn"]]) or \
                        d["fn"] != c["fn"] or any(
                            K.cstr(K.Q(d[k])) != d[k]
                            for k in K.FN_PARAMS[c["fn"]]):
                    raise ValueError
                cur = K.Curve.from_def(d)
            except Exception:                       # noqa: BLE001
                bad.append("curve %s def" % cid)
        if "extent" in c and ("def" not in c or not (
                isinstance(c["extent"], list) and len(c["extent"]) == 2 and
                all(isinstance(v, str) and K.Q(v) is not None
                    for v in c["extent"]))):
            bad.append("curve %s extent" % cid)
        lab = c.get("label")
        if lab is not None:
            if isinstance(lab, dict) and set(lab) == {"name"}:
                if not (isinstance(lab["name"], str) and
                        K.CURVE_NAME_RE.match(lab["name"])):
                    bad.append("curve %s label" % cid)
            elif isinstance(lab, dict) and set(lab) == {"equation", "text"}:
                if lab["equation"] not in K.EQ_FORMS[c["fn"]] or \
                        cur is None or \
                        K.equation_text(cur, lab["equation"]) != lab["text"]:
                    bad.append("curve %s equation label" % cid)
            else:
                bad.append("curve %s label" % cid)
        if "symmetry_of" in c and not (isinstance(c["symmetry_of"], str) and
                                       K.CURVE_RE.match(c["symmetry_of"])):
            bad.append("curve %s symmetry_of" % cid)
    mids = set()
    for m in pub.get("marks") or []:
        if not keys(m, PUBLIC_MARK, "mark", ("id", "kind", "on", "label",
                                             "guides")):
            continue
        mid = m.get("id")
        if not (isinstance(mid, str) and K.MARK_RE.match(mid)) or \
                mid in mids:
            bad.append("mark id %r" % (mid,))
            continue
        mids.add(mid)
        if m.get("kind") not in K.MARK_KINDS or not isinstance(
                m.get("on"), list) or any(o not in cids for o in m["on"]):
            bad.append("mark %s kind / on" % mid)
        if not isinstance(m.get("guides"), list) or any(
                g not in ("x", "y") for g in m["guides"]):
            bad.append("mark %s guides" % mid)
        xy = None
        if "xy" in m:
            ok = isinstance(m["xy"], list) and len(m["xy"]) == 2 and all(
                isinstance(v, str) and K.Q(v) is not None and
                K.cstr(K.Q(v)) == v for v in m["xy"])
            if not ok:
                bad.append("mark %s xy" % mid)
            else:
                xy = [K.Q(v) for v in m["xy"]]
        lab = m.get("label")
        if lab is not None:
            if not isinstance(lab, dict) or not set(lab) <= {
                    "name", "coords", "text"} or "text" not in lab:
                bad.append("mark %s label" % mid)
                continue
            if "name" in lab and not (isinstance(lab["name"], str) and
                                      K.POINT_NAME_RE.match(lab["name"])):
                bad.append("mark %s label name" % mid)
            if lab.get("coords") is not None and lab.get("coords") is not \
                    True:
                bad.append("mark %s label coords" % mid)
            if lab.get("coords") and xy is None:
                bad.append("mark %s: a coordinate label with no public xy"
                           % mid)
            elif xy is not None or not lab.get("coords"):
                want = K.mark_label_text(lab, *(xy or (0, 0)))
                if want != lab["text"]:
                    bad.append("mark %s label text" % mid)
    for f in pub.get("finds") or []:
        if not keys(f, PUBLIC_FIND, "find", ("id", "item", "rel", "args")):
            continue
        if f.get("rel") not in K.FIND_RELS or not isinstance(
                f.get("args"), list) or any(a not in cids
                                            for a in f["args"]):
            bad.append("find %r" % (f.get("id"),))
        if "at" in f and (not isinstance(f["at"], str) or
                          K.Q(f["at"]) is None):
            bad.append("find %r at" % (f.get("id"),))
    for pr in pub.get("parallel") or []:
        if not (isinstance(pr, list) and len(pr) == 2 and
                all(p in cids for p in pr)):
            bad.append("parallel %r" % (pr,))
    for s in K._strings(pub):
        if "answer" == s:
            bad.append("an 'answer' string")
    return bad


def require_public(pub):
    if not isinstance(pub, dict):
        raise RenderRefused("RENDER_NOT_PUBLIC", "not a dict")
    if not PUBLIC_TOP <= set(pub) <= PUBLIC_TOP | PUBLIC_TOP_OPTIONAL:
        raise RenderRefused("RENDER_NOT_PUBLIC", "top-level keys %s are not "
                            "the public graph model's (an author spec, a "
                            "private model or an answer store is refused)"
                            % sorted((set(pub) - PUBLIC_TOP_OPTIONAL) ^
                                     PUBLIC_TOP))
    bad = scan_public(pub)
    if bad:
        raise RenderRefused("RENDER_NOT_PUBLIC", "scan: %s" % "; ".join(
            bad[:5]))
    if K.public_hash(pub) != pub.get("public_hash"):
        raise RenderRefused("RENDER_NOT_PUBLIC", "public_hash does not match "
                            "the content (the model was edited after "
                            "kinds.public_model built it)")


def settings(ds):
    if not isinstance(ds, dict):
        raise RenderRefused("RENDER_BAD_SETTINGS", "not a dict")
    extra = sorted(set(ds) - set(SETTINGS))
    if extra:
        raise RenderRefused("RENDER_BAD_SETTINGS", "unknown key(s) %s for a "
                            "graph (closed list: %s)" % (extra,
                                                         sorted(SETTINGS)))
    out = {}
    for k, (ok, dflt) in sorted(SETTINGS.items()):
        if k not in ds:
            if k == "figure":
                raise RenderRefused("RENDER_BAD_SETTINGS", "figure missing")
            out[k] = list(dflt) if isinstance(dflt, list) else dflt
            continue
        if not ok(ds[k]):
            raise RenderRefused("RENDER_BAD_SETTINGS", "%s=%r" % (k, ds[k]))
        out[k] = ds[k]
    return out


# ---------------------------------------------------------------- axes ---
class _Axis(object):
    def __init__(self, pa):
        self.aid = pa["axis"]
        self.letter = self.aid.split(":", 1)[1]
        self.n = int(pa["intervals"])
        self.labels = [(int(i), K.Q(v)) for i, v in pa["labels"]]
        pts = dict(self.labels)
        ks = sorted(pts)
        if len(ks) < 2:
            raise RenderRefused("RENDER_FRAME", "%s prints fewer than two "
                                "numbers: a graph needs its scale printed"
                                % self.aid)
        st = (pts[ks[-1]] - pts[ks[0]]) / (ks[-1] - ks[0])
        if st <= 0 or any(pts[k] != pts[ks[0]] + (k - ks[0]) * st
                          for k in ks):
            raise RenderRefused("RENDER_FRAME", "the printed numbers of %s "
                                "are not one step apart per interval"
                                % self.aid)
        z = -(pts[ks[0]] - ks[0] * st) / st
        if z.denominator != 1 or not 0 <= z <= self.n:
            raise RenderRefused("RENDER_FRAME", "0 is not a tick of %s"
                                % self.aid)
        self.step, self.zero = st, int(z)
        self.lo = -self.zero * st
        self.hi = (self.n - self.zero) * st

    def index(self, v):
        return self.zero + float(v) / float(self.step)


def num_text(v):
    t = K.disp(v)
    if t is None:
        raise RenderRefused("RENDER_FORM_UNSUPPORTED", "%s: a graph prints "
                            "whole numbers and decimals" % K.cstr(v))
    return t


def _seg_hits_box(a, b, box):
    x0, y0, x1, y1 = box
    dx, dy = b[0] - a[0], b[1] - a[1]
    t0, t1 = 0.0, 1.0
    for pk, qk in ((-dx, a[0] - x0), (dx, x1 - a[0]), (-dy, a[1] - y0),
                   (dy, y1 - a[1])):
        if abs(pk) < 1e-12:
            if qk < 0:
                return False
            continue
        t = qk / pk
        if pk < 0:
            if t > t1:
                return False
            t0 = max(t0, t)
        else:
            if t < t0:
                return False
            t1 = min(t1, t)
    return t0 <= t1


def _box_seg_dist(box, a, b):
    """distance between a box and a segment (0 when they meet)"""
    if _seg_hits_box(a, b, box):
        return 0.0
    x0, y0, x1, y1 = box
    corners = [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]
    d = min(geo.seg_dist(c, a, b) for c in corners)
    return min(d, geo.box_point_dist(box, a), geo.box_point_dist(box, b))


def _esc(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(
        ">", "&gt;").replace('"', "&quot;")


class _Curve(object):
    """a drawn curve in px: its element geometry and dense samples"""

    def __init__(self, cid, cur, style, ext):
        self.cid, self.cur, self.style, self.ext = cid, cur, style, ext
        self.samples = []      # px points along the drawn part
        self.el = None
        self.segs = []


class _Builder(object):
    def __init__(self, pub, st, sq):
        self.pub, self.st = pub, st
        fr = pub["frame"]
        self.ax = _Axis(fr["axes"][0])
        self.ay = _Axis(fr["axes"][1])
        self.grid = bool(fr["grid"])
        self.sqx = float(sq)
        if pub["aspect"] == "equal":
            self.sqy = self.sqx * float(self.ay.step) / float(self.ax.step)
        else:
            self.sqy = self.sqx
        if self.sqy < MIN_SQUARE_PX * 0.5 or \
                self.sqy * self.ay.n > MAX_CANVAS_PX or \
                self.sqx * self.ax.n > MAX_CANVAS_PX:
            raise RenderRefused("RENDER_TOO_LARGE", "an equal aspect with "
                                "steps %s / %s makes cells %.1f x %.1f px"
                                % (K.cstr(self.ax.step), K.cstr(self.ay.step),
                                   self.sqx, self.sqy))
        self.issues = []
        self.els = []
        self.items = []
        self.item_els = {}
        self.objects = {}
        self.dots = {}          # mark id -> px
        self.strokes = _SegIndex()        # obstacles for text
        self.curve_strokes = _SegIndex()  # curve pieces: wider clearance
        self.boxes = []         # placed text boxes
        self.num_boxes = []
        self.fs_num = float(st["number_size"])
        self.fs_name = float(st["name_size"])
        self.r = float(st["point_radius"])
        self.curves = []
        self.cross = []         # crossing points of two curves (px)

    # ------------------------------------------------------------ maps --
    def X(self, x):
        return self.ax.index(x) * self.sqx

    def Y(self, y):
        return (self.ay.n - self.ay.index(y)) * self.sqy

    def P(self, x, y):
        return (self.X(x), self.Y(y))

    def step_px(self):
        return min(self.sqx, self.sqy)

    def item(self, role, source, text=None):
        it = {"id": "d%03d" % (len(self.items) + 1), "role": role,
              "source": source}
        if text is not None:
            it["text"] = text
        self.items.append(it)
        self.item_els[it["id"]] = []
        return it["id"]

    def add(self, layer, tag, attrs, item, text=None, geom=None):
        k = len(self.els)
        self.els.append([layer, tag, attrs, text, item, geom])
        self.item_els[item].append(k)
        return k

    def part(self, oid, kind, k):
        o = self.objects.setdefault(oid, {"kind": kind, "parts": []})
        if k not in o["parts"]:
            o["parts"].append(k)

    def line(self, layer, hook, p, q, width, item, stroke=INK, extra=()):
        attrs = [hook, ("x1", p[0]), ("y1", p[1]), ("x2", q[0]),
                 ("y2", q[1]), ("stroke", stroke), ("stroke-width", width)] \
            + list(extra)
        return self.add(layer, "line", attrs, item, geom=("line", p, q))

    # ------------------------------------------------------------ plan --
    def plan(self):
        pub, st = self.pub, self.st
        lay_c, lay_m = {}, {}
        cids = dict((c["id"], c) for c in pub["curves"])
        mids = dict((m["id"], m) for m in pub["marks"])
        for e in st["curves"]:
            if not isinstance(e, dict) or not set(e) <= {"curve", "def",
                                                         "extent"} or \
                    "curve" not in e or "def" not in e:
                raise RenderRefused("RENDER_LAYOUT", "curve entry %r" % (e,))
            if e["curve"] not in cids or e["curve"] in lay_c:
                raise RenderRefused("RENDER_LAYOUT", "curve entry %r: not a "
                                    "public curve (a layout never adds one) "
                                    "or placed twice" % (e["curve"],))
            lay_c[e["curve"]] = e
        for e in st["marks"]:
            if not isinstance(e, dict) or set(e) != {"mark", "xy"} or \
                    e["mark"] not in mids or e["mark"] in lay_m:
                raise RenderRefused("RENDER_LAYOUT", "mark entry %r" % (e,))
            lay_m[e["mark"]] = e
        self.curve_of = {}
        for cid in sorted(cids):
            c = cids[cid]
            pd, ld = c.get("def"), (lay_c.get(cid) or {}).get("def")
            if pd is None and ld is None:
                raise RenderRefused("RENDER_LAYOUT", "%s has no public "
                                    "numbers: place it with a 'curves' "
                                    "layout entry" % cid)
            try:
                cur = K.Curve.from_def(pd or ld)
                if ld is not None:
                    lc = K.Curve.from_def(ld)
            except Exception:                       # noqa: BLE001
                raise RenderRefused("RENDER_LAYOUT", "%s def" % cid)
            if ld is not None and (lc.fn != c["fn"] or (
                    pd is not None and not lc.same(cur))):
                raise RenderRefused("RENDER_LAYOUT", "%s: the layout's def "
                                    "disagrees with the public one" % cid)
            if cur.fn != c["fn"]:
                raise RenderRefused("RENDER_LAYOUT", "%s fn" % cid)
            pe = c.get("extent")
            le = (lay_c.get(cid) or {}).get("extent")
            if pe is not None and le is not None and pe != le:
                raise RenderRefused("RENDER_LAYOUT", "%s extent disagrees"
                                    % cid)
            ext = pe or le
            if ext is not None:
                ext = [K.Q(v) for v in ext]
                if None in ext:
                    raise RenderRefused("RENDER_LAYOUT", "%s extent" % cid)
            self.curve_of[cid] = (cur, c, ext)
        self.mark_xy = {}
        self.mark_rec = mids
        for mid in sorted(mids):
            m = mids[mid]
            pxy = m.get("xy")
            lxy = (lay_m.get(mid) or {}).get("xy")
            if pxy is None and lxy is None:
                raise RenderRefused("RENDER_LAYOUT", "%s has no public "
                                    "coordinates: place it with a 'marks' "
                                    "layout entry" % mid)
            if pxy is not None and lxy is not None and \
                    [K.Q(v) for v in pxy] != [K.Q(v) for v in lxy]:
                raise RenderRefused("RENDER_LAYOUT", "%s: the layout "
                                    "disagrees with its public xy" % mid)
            xy = [K.Q(v) for v in (pxy or lxy)]
            if None in xy:
                raise RenderRefused("RENDER_LAYOUT", "%s xy" % mid)
            if not (self.ax.lo <= xy[0] <= self.ax.hi and
                    self.ay.lo <= xy[1] <= self.ay.hi):
                raise RenderRefused("RENDER_LAYOUT", "%s lies outside the "
                                    "window" % mid)
            for cid in m["on"]:
                if not self.curve_of[cid][0].on(*xy):
                    raise RenderRefused("RENDER_LAYOUT", "%s is not on %s"
                                        % (mid, cid))
            self.mark_xy[mid] = tuple(xy)

    # ------------------------------------------------------------ draw --
    def window(self):
        class W(object):
            pass
        w = W()
        w.x0, w.x1, w.sx = self.ax.lo, self.ax.hi, self.ax.step
        w.y0, w.y1, w.sy = self.ay.lo, self.ay.hi, self.ay.step
        return w

    def draw_axes(self):
        ax, ay = self.ax, self.ay
        yx = self.Y(0)
        xy = self.X(0)
        self.axis_px = {"x": yx, "y": xy}
        x0 = self.X(ax.lo) - (AX_EXT_NEG * self.sqx if ax.zero > 0
                              else 0.6 * self.sqx)
        x1 = self.X(ax.hi) + AX_EXT_POS * self.sqx
        y0 = self.Y(ay.lo) + (AX_EXT_NEG * self.sqy if ay.zero > 0
                              else 0.6 * self.sqy)
        y1 = self.Y(ay.hi) - AX_EXT_POS * self.sqy
        self.tip = {}
        for axis, p, q, tip, pts in (
                (ax, (x0, yx), (x1, yx), (x1 + ARROW_LEN_PX, yx),
                 [(x1, yx - ARROW_HALF_PX), (x1 + ARROW_LEN_PX, yx),
                  (x1, yx + ARROW_HALF_PX)]),
                (ay, (xy, y0), (xy, y1), (xy, y1 - ARROW_LEN_PX),
                 [(xy - ARROW_HALF_PX, y1), (xy, y1 - ARROW_LEN_PX),
                  (xy + ARROW_HALF_PX, y1)])):
            it = self.item("axis_line", {"entity": axis.aid})
            k = self.line("axes", ("data-axis", axis.letter), p, q, W_AXIS,
                          it)
            self.part(axis.aid, "axis", k)
            self.strokes.add(p, q)
            it = self.item("axis_arrow", {"entity": axis.aid})
            k = self.add("axes", "polygon", [
                ("data-arrow", axis.letter), ("points", pts), ("fill", INK),
                ("stroke", "none")], it, geom=("poly", pts))
            self.part(axis.aid, "axis", k)
            for i in range(3):
                self.strokes.add(pts[i], pts[(i + 1) % 3])
            self.tip[axis.letter] = tip
        for axis in (ax, ay):
            labelled = set(i for i, _v in axis.labels)
            for i in range(axis.n + 1):
                if i == axis.zero or (self.grid and i not in labelled):
                    continue
                if axis is ax:
                    X = i * self.sqx
                    p, q = (X, yx - TICK_HALF_PX), (X, yx + TICK_HALF_PX)
                else:
                    Y = (ay.n - i) * self.sqy
                    p, q = (xy - TICK_HALF_PX, Y), (xy + TICK_HALF_PX, Y)
                it = self.item("tick", {"entity": axis.aid})
                k = self.line("axes", ("data-tick", "%s %d" % (axis.letter,
                                                               i)),
                              p, q, W_TICK, it)
                self.part(axis.aid, "axis", k)
                self.strokes.add(p, q)

    def draw_curves(self):
        win = self.window()
        for cid in sorted(self.curve_of):
            cur, c, ext = self.curve_of[cid]
            rng = K.drawn_ranges(cur, win, ext)
            if len(rng) != 1:
                raise RenderRefused("RENDER_LAYOUT", "%s has %d drawn pieces "
                                    "in the window" % (cid, len(rng)))
            lo, hi = rng[0]
            dc = _Curve(cid, cur, c["style"], ext)
            extra = [("stroke-dasharray", _dash(self.step_px()))] if \
                c["style"] == "dashed" else []
            it = self.item("curve", {"entity": cid})
            if cur.fn == "vline":
                p, q = self.P(cur.c, self.ay.lo), self.P(cur.c, self.ay.hi)
                k = self.line("curves", ("data-curve", cid), p, q, W_DATA, it,
                              extra=extra)
                n = max(2, int(abs(q[1] - p[1]) / SAMPLE_PX))
                dc.samples = [(p[0], p[1] + (q[1] - p[1]) * t / n)
                              for t in range(n + 1)]
                dc.param = ("y", float(self.ay.lo), float(self.ay.hi))
            elif cur.fn == "line":
                p = self.P(lo, cur.fl(lo))
                q = self.P(hi, cur.fl(hi))
                k = self.line("curves", ("data-curve", cid), p, q, W_DATA, it,
                              extra=extra)
                n = max(2, int(geo.d(p, q) / SAMPLE_PX))
                dc.samples = [(p[0] + (q[0] - p[0]) * t / n,
                               p[1] + (q[1] - p[1]) * t / n)
                              for t in range(n + 1)]
                dc.param = ("x", lo, hi)
            else:
                f = cur.fl
                y_lo, y_hi = f(lo), f(hi)
                slope = 2 * (lo - float(cur.p))
                cx = (lo + hi) / 2.0
                cy = y_lo + slope * (hi - lo) / 2.0
                P0, P1, P2 = self.P(lo, y_lo), self.P(cx, cy), \
                    self.P(hi, y_hi)
                k = self.add("curves", "path", [
                    ("data-curve", cid), ("d", ("Q", P0, P1, P2)),
                    ("fill", "none"), ("stroke", INK),
                    ("stroke-width", W_DATA)] + extra, it,
                    geom=("quad", P0, P1, P2))
                n = max(8, int((hi - lo) * self.sqx / SAMPLE_PX))
                dc.samples = [self.P(lo + (hi - lo) * t / n,
                                     f(lo + (hi - lo) * t / n))
                              for t in range(n + 1)]
                dc.param = ("x", lo, hi)
            dc.el = k
            self.part(cid, cur.fn, k)
            dc.segs = list(zip(dc.samples[:-1], dc.samples[1:]))
            self.curve_strokes.extend(dc.segs)
            self.curves.append(dc)
        # crossings of two drawn curves (label ownership keeps away)
        for i, a in enumerate(self.curves):
            for b in self.curves[i + 1:]:
                pts = K.intersections(a.cur, b.cur)
                if pts is None:
                    pts = self._num_cross(a, b)
                for x, y in pts:
                    if self.ax.lo <= x <= self.ax.hi and \
                            self.ay.lo <= y <= self.ay.hi:
                        self.cross.append(self.P(float(x), float(y)))

    def _num_cross(self, a, b):
        out = []
        for p1, q1 in a.segs:
            for p2, q2 in b.segs:
                d = (q1[0] - p1[0]) * (q2[1] - p2[1]) - \
                    (q1[1] - p1[1]) * (q2[0] - p2[0])
                if abs(d) < 1e-12:
                    continue
                t = ((p2[0] - p1[0]) * (q2[1] - p2[1]) -
                     (p2[1] - p1[1]) * (q2[0] - p2[0])) / d
                u = ((p2[0] - p1[0]) * (q1[1] - p1[1]) -
                     (p2[1] - p1[1]) * (q1[0] - p1[0])) / d
                if 0 <= t <= 1 and 0 <= u <= 1:
                    X = p1[0] + t * (q1[0] - p1[0])
                    Y = p1[1] + t * (q1[1] - p1[1])
                    out.append(((X / self.sqx - self.ax.zero) *
                                float(self.ax.step),
                                (self.ay.n - Y / self.sqy - self.ay.zero) *
                                float(self.ay.step)))
        return out

    def draw_guides(self):
        for m in sorted(self.pub["marks"], key=lambda m: m["id"]):
            for a in m["guides"]:
                x, y = self.mark_xy[m["id"]]
                p = self.P(x, y)
                q = self.P(x, 0) if a == "x" else self.P(0, y)
                if geo.d(p, q) < 1.0:
                    continue
                gid = "guide:%s:%s" % (m["id"], a)
                it = self.item("guide", {"entity": m["id"], "guide": a})
                k = self.line("guides", ("data-guide", "%s %s" % (m["id"], a)),
                              p, q, W_GUIDE, it,
                              extra=[("stroke-dasharray", DASH_GUIDE)])
                self.part(gid, "guide", k)
                self.strokes.add(p, q)

    def draw_marks(self):
        for mid in sorted(self.mark_xy):
            c = self.P(*[float(v) for v in self.mark_xy[mid]])
            self.dots[mid] = c
            opt = self.mark_rec[mid].get("optional")
            it = self.item("optional_mark" if opt else "mark",
                           {"entity": mid})
            k = self.add("marks", "circle", [
                ("data-pt", mid), ("cx", c[0]), ("cy", c[1]), ("r", self.r),
                ("fill", INK), ("stroke", "none")], it, geom=("dot", c))
            self.part(mid, "mark", k)

    # ---------------------------------------------------------- labels --
    def grid_box(self):
        return (0.0, 0.0, self.ax.n * self.sqx, self.ay.n * self.sqy)

    def free(self, box, pad=LABEL_PAD_PX, room=True,
             curve_clear=CURVE_CLEAR_PX, text_gap=LABEL_PAD_PX):
        b = geo.inflate(box, pad)
        gb = self.grid_box()
        rx, ry = LABEL_ROOM_SQ * self.sqx, LABEL_ROOM_SQ * self.sqy
        if room and (b[0] < gb[0] - rx or b[1] < gb[1] - ry or
                     b[2] > gb[2] + rx or b[3] > gb[3] + ry):
            return False
        bt = geo.inflate(box, text_gap)
        if any(geo.boxes_overlap(bt, o) for o in self.boxes):
            return False
        for c in self.dots.values():
            if geo.box_point_dist(box, c) < self.r + DOT_CLEAR_PX:
                return False
        if self.strokes.hits(b):
            return False
        return not self.curve_strokes.hits(geo.inflate(box, curve_clear))

    def _text_el(self, it, t, box, hook, anchor, fs, italic=False,
                 base=None, rtl_title=False):
        cx = (box[0] + box[2]) / 2.0
        x = {"middle": cx, "end": box[2], "start": box[0]}[anchor]
        if base is None:
            base = box[3] - _desc(t, fs)
        attrs = [hook, ("x", x), ("y", base),
                 ("font-family", _family_for(self.st["font_family"], t)),
                 ("font-size", fs)]
        if italic:
            attrs.append(("font-style", "italic"))
        if anchor != "start":
            attrs.append(("text-anchor", anchor))
        if rtl_title:
            attrs += list(rtl.BIDI_ATTRS)
        attrs.append(("fill", INK))
        self.boxes.append(box)
        stored = rtl.visual(t) if rtl_title else t
        return self.add("labels", "text", attrs, it, text=stored,
                        geom=("text", box))

    def label_numbers(self):
        ax, ay = self.ax, self.ay
        fs = self.fs_num
        h = geo.GLYPH_H * fs
        yx, xy = self.axis_px["x"], self.axis_px["y"]
        below = yx + TICK_HALF_PX + NUM_GAP_PX
        left = xy - TICK_HALF_PX - NUM_GAP_PX
        zero_x = any(i == ax.zero for i, _v in ax.labels)
        zero_y = any(i == ay.zero for i, _v in ay.labels)
        jobs = []
        if zero_x or zero_y:
            w = tw("0", fs)
            jobs.append(("origin", None, "0", (xy - NUM_GAP_PX - w, below,
                                               xy - NUM_GAP_PX, below + h),
                         "end"))
        for i, v in ax.labels:
            if i == ax.zero:
                continue
            t = num_text(v)
            w = tw(t, fs)
            X = i * self.sqx
            jobs.append(("x", i, t, (X - w / 2, below, X + w / 2, below + h),
                         "middle"))
        for j, v in ay.labels:
            if j == ay.zero:
                continue
            t = num_text(v)
            w = tw(t, fs)
            Y = (ay.n - j) * self.sqy
            jobs.append(("y", j, t, (left - w, Y - h / 2, left, Y + h / 2),
                         "end"))
        self.origin_box = None
        # (v6.16 integrate, runner finding G-F1) the BAND of each axis's
        # numbers: a number pushed ACROSS (away from its axis, by a curve at
        # its tick) never enters the other axis's band -- an x-axis '−1'
        # moved into the y numbers' column reads as a y number (SCORING
        # s4.9: an axis number is read at ITS tick); with no other place
        # the square grows, a number is never dropped
        wy = max([tw(num_text(v), fs) for _j, v in ay.labels] or [0.0])
        self.num_band = {
            "x": (left - wy - NUM_SPACE_PX,
                  xy + NUM_GAP_PX + wy + NUM_SPACE_PX),
            "y": (yx - TICK_HALF_PX - NUM_GAP_PX - h - NUM_SPACE_PX,
                  below + h + NUM_SPACE_PX)}
        for kind, i, t, box, anchor in jobs:
            chosen = None
            cands = self._num_cands(kind, box)
            # (fix r1) pass 1: the number's own side of its axis with the
            # wide clearance; pass 2: the v6.15 search (all candidates, the
            # narrow clearance) exactly as before
            for clear, pool in ((NUM_CURVE_CLEAR_PX, [
                    b for b in cands if self._own_side(box, b)]),
                    (NUM_CURVE_CLEAR_MIN_PX, cands)):
                for b in pool:
                    if kind in ("x", "y") and self._in_other_band(kind, box,
                                                                  b):
                        continue
                    if self.free(b, curve_clear=clear) and (
                            self.origin_box is None or not
                            geo.boxes_overlap(geo.inflate(
                                b, NUM_SPACE_PX), self.origin_box)):
                        chosen = b
                        break
                if chosen is not None:
                    break
            if chosen is None:
                self.issues.append(_issue(
                    "RENDER_AXIS_CROWDED", "%s %s" % (kind, "" if i is None
                                                      else i),
                    "the number %s has no free place at its tick (a curve or "
                    "a label crosses it): a larger square -- a number is "
                    "never dropped" % t))
                chosen = box
            if kind == "origin":
                self.origin_box = chosen
                it = self.item("origin_zero", {"entity": "plane:xy"}, t)
                hook = ("data-num", "origin")
            else:
                axis = ax if kind == "x" else ay
                it = self.item("axis_number", {"entity": axis.aid}, t)
                hook = ("data-num", "%s %d" % (axis.letter, i))
            k = self._text_el(it, t, chosen, hook, anchor, fs)
            self.num_boxes.append(chosen)
            if kind == "origin":
                for a_ in ((ax.aid,) if zero_x else ()) + \
                        ((ay.aid,) if zero_y else ()):
                    self.part(a_, "axis", k)
            else:
                self.part(axis.aid, "axis", k)

    def _own_side(self, box, b):
        """(fix r1) candidate b lies on the same side of the x axis and of
        the y axis as the number's usual place box"""
        yx, xy = self.axis_px["x"], self.axis_px["y"]
        return (((box[1] + box[3]) / 2.0 > yx) ==
                ((b[1] + b[3]) / 2.0 > yx) and
                ((box[0] + box[2]) / 2.0 < xy) ==
                ((b[0] + b[2]) / 2.0 < xy))

    def _in_other_band(self, kind, box, b):
        """(v6.16 integrate, G-F1) candidate b of an x (y) number was moved
        across its axis's row (column) and now overlaps the y (x) numbers'
        column (row): refused. The number's own place (b == box, or only
        slid ALONG its axis) is never refused by this rule."""
        if kind == "x":
            across = abs(b[1] - box[1]) > 1e-9 or abs(b[3] - box[3]) > 1e-9
            lo, hi = self.num_band["x"]
            return across and b[0] < hi and b[2] > lo
        across = abs(b[0] - box[0]) > 1e-9 or abs(b[2] - box[2]) > 1e-9
        lo, hi = self.num_band["y"]
        return across and b[1] < hi and b[3] > lo

    def _num_cands(self, kind, box):
        yx, xy = self.axis_px["x"], self.axis_px["y"]

        def mv(b, dx, dy):
            return (b[0] + dx, b[1] + dy, b[2] + dx, b[3] + dy)
        if kind == "origin":
            w, h = box[2] - box[0], box[3] - box[1]
            g = TICK_HALF_PX + NUM_GAP_PX
            corners = [box, (box[0], yx - g - h, box[2], yx - g),
                       (xy + NUM_GAP_PX, below_y(yx, g), xy + NUM_GAP_PX + w,
                        below_y(yx, g) + h),
                       (xy + NUM_GAP_PX, yx - g - h, xy + NUM_GAP_PX + w,
                        yx - g)]
            out = []
            for c in corners:
                for dn in (0, 1, 2, 3):
                    out.append(mv(c, -dn if c[0] < xy else dn,
                                  dn if c[1] > yx else -dn))
            return out
        sq = self.sqx if kind == "x" else self.sqy
        # along its axis a number stays within NUM_ALONG_STEP step of its
        # tick (SCORING s4.9: AX_NUMBERS_OWNED)
        lim = int(max(0.0, NUM_ALONG_STEP * sq) * 4)
        along = [0.0]
        for d in range(1, lim + 1):
            along += [d / 4.0, -d / 4.0]
        dns = [float(d) for d in range(0, int(min(NUM_ACROSS_MAX_PX,
                                                  0.75 * sq)) + 1)]
        out = []
        if kind == "x":
            flip = (box[0], 2 * yx - box[3], box[2], 2 * yx - box[1])
            for side, sgn in ((box, 1), (flip, -1)):
                for dn in dns:
                    for da in along:
                        c = mv(side, da, sgn * dn)
                        if sgn < 0 and c[2] > xy - self.sqx and c[0] < xy:
                            continue
                        out.append(c)
        else:
            w = box[2] - box[0]
            flip = (2 * xy - box[2], box[1], 2 * xy - box[2] + w, box[3])
            for side, sgn in ((box, -1), (flip, 1)):
                for dn in dns:
                    for da in along:
                        c = mv(side, sgn * dn, da)
                        if sgn > 0 and c[1] < yx + self.sqy and c[3] > yx:
                            continue
                        out.append(c)
        return out

    def label_letters(self):
        """the axis letters first (the numbers then keep clear of them)"""
        fs = self.fs_name
        for a in ("x", "y"):
            spec = self.pub["axes"][a]
            axis = self.ax if a == "x" else self.ay
            tx, ty = self.tip[a]
            if spec["letter"]:
                t = a
                w, h = tw(t, fs), geo.GLYPH_H * fs
                desc = DESCENT * fs if t in "gjpqy" else 0.0
                if a == "x":
                    x0, base = tx + 2.0, ty + 0.25 * h + h / 2
                else:
                    x0, base = tx - ARROW_HALF_PX - 2.0 - w, ty + h / 2
                box = (x0, base - h, x0 + w, base + desc)
                it = self.item("axis_name", {"entity": axis.aid}, t)
                k = self._text_el(it, t, box, ("data-axname", a), "middle",
                                  fs, italic=True, base=base)
                self.part(axis.aid, "axis", k)

    def label_titles(self):
        fs = self.fs_name
        for a in ("x", "y"):
            spec = self.pub["axes"][a]
            axis = self.ax if a == "x" else self.ay
            tx, ty = self.tip[a]
            title = spec["title"]
            if title is None:
                continue
            w, h = tw(title, fs), geo.GLYPH_H * fs
            cands = []
            if a == "x":
                yx = self.axis_px["x"]
                nb = max([b[3] for b in self.num_boxes] + [yx + TICK_HALF_PX])
                right = tx
                for dy in (3.0, 6.0, 10.0, 16.0):
                    cands.append((right - w, nb + dy, right, nb + dy + h))
                for dy in (4.0, 8.0):
                    cands.append((right - w - 4.0, yx - dy - h,
                                  right - 4.0, yx - dy))
                for dx in (0.0, self.sqx, 2 * self.sqx):
                    cands.append((right - w - dx, nb + 3.0, right - dx,
                                  nb + 3.0 + h))
            else:
                xy = self.axis_px["y"]
                top = ty - 3.0
                if spec["letter"]:
                    top -= h + 2.0
                for dx in (0.0, w / 2 - 4.0, -(w / 2 - 4.0)):
                    cands.append((xy - w / 2 + dx, top - h, xy + w / 2 + dx,
                                  top))
                for dy in (4.0, 8.0, 14.0):
                    cands.append((xy - w / 2, top - h - dy, xy + w / 2,
                                  top - dy))
            chosen = None
            for b in cands:
                if self.free(b, room=False):
                    chosen = b
                    break
            if chosen is None:
                self.issues.append(_issue("RENDER_LABEL_NO_PLACE",
                                          "title " + a, "the axis title %r "
                                          "has no free place" % title))
                chosen = cands[0]
            it = self.item("axis_unit", {"entity": axis.aid}, title)
            k = self._text_el(it, title, chosen, ("data-axtitle", a),
                              "middle", fs, rtl_title=True)
            self.part(axis.aid, "axis", k)

    def label_marks(self):
        fs = self.fs_name
        for m in sorted(self.pub["marks"], key=lambda m: m["id"]):
            lab = m.get("label")
            if lab is None:
                continue
            t = lab["text"]
            w, h = tw(t, fs), geo.GLYPH_H * fs + _desc(t, fs)
            box = self._around(m["id"], w, h)
            if box is None:
                self.issues.append(_issue("RENDER_LABEL_NO_PLACE", m["id"],
                                          "the label %r has no free place "
                                          "beside its dot" % t))
                c = self.dots[m["id"]]
                box = (c[0] + 4, c[1] - h - 4, c[0] + 4 + w, c[1] - 4)
            it = self.item("optional_label" if m.get("optional") else
                           "mark_label", {"entity": m["id"]}, t)
            k = self._text_el(it, t, box, ("data-for", m["id"]), "middle",
                              fs)
            self.part(m["id"], "mark", k)

    def _around(self, own, w, h):
        """a box whose NEAREST point to the dot is r + gap away, in one of
        twelve directions (the corners first: a coordinate label reads
        beside its point); nearer its own dot than any other"""
        c = self.dots[own]
        dirs = (-45, -135, 45, 135, 0, 180, -90, 90, -20, -160, 20, 160)
        for gap in (2.0, 3.5, 5.0, 7.0, 9.0):
            for deg in dirs:
                b = _box_beside(c, self.r + gap, deg, w, h)
                if not self.free(b, text_gap=LABEL_TEXT_GAP_PX):
                    continue
                d0 = geo.box_point_dist(b, c)
                if all(geo.box_point_dist(b, o) >= d0 + OWN_MARGIN_PX
                       for n, o in self.dots.items() if n != own):
                    return b
        return None

    def _curve_dist(self, box, dc):
        return min(_box_seg_dist(box, p, q) for p, q in dc.segs)

    def _centre_owned(self, b, dc, stp):
        """(v6.16 integrate, runner finding G-F2) the ownership margin from
        the label's CENTRE too (SCORING s4.9 as the runner measures it): a
        label is nearer its own curve by CURVE_OWN_STEP step from either
        reading (the box's nearest point, above, and its centre, here)"""
        ctr = ((b[0] + b[2]) / 2.0, (b[1] + b[3]) / 2.0)
        cb = (ctr[0], ctr[1], ctr[0], ctr[1])
        c0 = self._curve_dist(cb, dc)
        return not any(self._curve_dist(cb, o) < c0 + CURVE_OWN_STEP * stp
                       for o in self.curves if o is not dc)

    def label_curves(self):
        """each label at the cheapest free place beside its own curve: a box
        whose nearest point lies 2-9 px from a point of the curve, in one of
        sixteen directions; cost = its distance from the curve (twice, in
        steps) + 1 outside the grid box + 0.3 away from the curve's ends;
        it must be nearer its own curve than any other by CURVE_OWN_STEP
        step and CROSS_CLEAR_STEP step away from any crossing"""
        fs = self.fs_name
        stp = self.step_px()
        labs = dict((c["id"], c.get("label")) for c in self.pub["curves"])
        gb = self.grid_box()
        for dc in self.curves:
            lab = labs.get(dc.cid)
            if lab is None:
                continue
            t = lab["name"] if "name" in lab else lab["text"]
            w, h = tw(t, fs), geo.GLYPH_H * fs + _desc(t, fs)
            n = len(dc.samples)
            stride = max(1, int(round(6.0 / SAMPLE_PX)))
            best = None
            for ai in range(0, n, stride):
                a = dc.samples[ai]
                frac = ai / float(max(1, n - 1))
                endish = 0.0 if (frac <= 0.2 or frac >= 0.8) else 0.3
                for gap in (2.5, 4.0, 6.0, 9.0):
                    for deg in range(0, 360, 22):
                        b = _box_beside(a, gap, float(deg), w, h)
                        inside = gb[0] <= b[0] and gb[1] <= b[1] and \
                            b[2] <= gb[2] and b[3] <= gb[3]
                        lower = 2.0 * gap / stp + endish + \
                            (0.0 if inside else 1.0)
                        if best is not None and lower >= best[0] - 1e-9:
                            continue
                        if not self.free(b, text_gap=LABEL_TEXT_GAP_PX):
                            continue
                        d0 = self._curve_dist(b, dc)
                        cost = 2.0 * d0 / stp + endish + \
                            (0.0 if inside else 1.0)
                        if best is not None and cost >= best[0] - 1e-9:
                            continue
                        if any(self._curve_dist(b, o) < d0 +
                               CURVE_OWN_STEP * stp
                               for o in self.curves if o is not dc):
                            continue
                        if not self._centre_owned(b, dc, stp):
                            continue
                        if any(geo.box_point_dist(b, x) <
                               CROSS_CLEAR_STEP * stp for x in self.cross):
                            continue
                        best = (cost, b)
            chosen = best[1] if best else None
            if chosen is None:
                self.issues.append(_issue("RENDER_LABEL_NO_PLACE", dc.cid,
                                          "the label %r has no free place "
                                          "beside its curve" % t))
                p = dc.samples[int(len(dc.samples) * 0.9)]
                chosen = (p[0] + 4, p[1] - h - 4, p[0] + 4 + w, p[1] - 4)
            it = self.item("curve_label", {"entity": dc.cid}, t)
            k = self._text_el(it, t, chosen, ("data-for", dc.cid), "middle",
                              fs)
            self.part(dc.cid, dc.cur.fn, k)

    # ------------------------------------------------------------ grid --
    def draw_grid(self):
        if not self.grid:
            return
        cuts_boxes = [geo.inflate(b, KNOCK_PX) for b in self.boxes]
        gb = self.grid_box()
        for i in range(self.ax.n + 1):
            X = i * self.sqx
            cuts = sorted((b[1], b[3]) for b in cuts_boxes
                          if b[0] <= X <= b[2])
            for a, b in _gaps(gb[1], gb[3], cuts):
                it = self.item("grid_line", {"entity": "plane:xy"})
                k = self.line("grid", ("data-grid", "x %d" % i), (X, a),
                              (X, b), W_GRID, it, stroke=GRID_INK)
                self.part("plane:xy", "plane", k)
        for j in range(self.ay.n + 1):
            Y = (self.ay.n - j) * self.sqy
            cuts = sorted((b[0], b[2]) for b in cuts_boxes
                          if b[1] <= Y <= b[3])
            for a, b in _gaps(gb[0], gb[2], cuts):
                it = self.item("grid_line", {"entity": "plane:xy"})
                k = self.line("grid", ("data-grid", "y %d" % j), (a, Y),
                              (b, Y), W_GRID, it, stroke=GRID_INK)
                self.part("plane:xy", "plane", k)

    # ---------------------------------------------------------- output --
    def finish(self):
        xs, ys = [], []
        for el in self.els:
            g = el[5]
            if g[0] == "line":
                xs += [g[1][0], g[2][0]]
                ys += [g[1][1], g[2][1]]
            elif g[0] == "poly":
                xs += [p[0] for p in g[1]]
                ys += [p[1] for p in g[1]]
            elif g[0] == "quad":
                xs += [g[1][0], g[3][0]]
                ys += [g[1][1], g[3][1]]
                ys.append(_quad_extreme_y(g[1], g[2], g[3]))
            elif g[0] == "dot":
                xs += [g[1][0] - self.r, g[1][0] + self.r]
                ys += [g[1][1] - self.r, g[1][1] + self.r]
            elif g[0] == "text":
                xs += [g[1][0], g[1][2]]
                ys += [g[1][1], g[1][3]]
        dx, dy = MARGIN_PX - min(xs), MARGIN_PX - min(ys)
        self.W = geo.r2(max(xs) - min(xs) + 2 * MARGIN_PX)
        self.H = geo.r2(max(ys) - min(ys) + 2 * MARGIN_PX)
        self.off = (dx, dy)
        order = []
        for layer in LAYERS:
            order += [k for k, el in enumerate(self.els) if el[0] == layer]
        self.ref = dict((k, "e%04d" % (n + 1)) for n, k in enumerate(order))
        self.order = order

    def _v(self, name, v):
        dx, dy = self.off
        if name in ("x1", "x2", "x", "cx"):
            return geo.fmt(v + dx)
        if name in ("y1", "y2", "y", "cy"):
            return geo.fmt(v + dy)
        if name == "points":
            return " ".join("%s,%s" % (geo.fmt(p[0] + dx), geo.fmt(p[1] + dy))
                            for p in v)
        if name == "d":
            _q, P0, P1, P2 = v
            return "M %s %s Q %s %s %s %s" % (
                geo.fmt(P0[0] + dx), geo.fmt(P0[1] + dy),
                geo.fmt(P1[0] + dx), _fmt_signed(P1[1] + dy),
                geo.fmt(P2[0] + dx), geo.fmt(P2[1] + dy))
        if isinstance(v, (float, int)):
            return geo.fmt(v)
        return str(v)

    def svg(self):
        out = ['<?xml version="1.0" encoding="UTF-8"?>',
               '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %s %s" '
               'width="%s" height="%s" data-dialect="%s">' % (
                   geo.fmt(self.W), geo.fmt(self.H), geo.fmt(self.W),
                   geo.fmt(self.H), DIALECT)]
        for layer in LAYERS:
            ks = [k for k in self.order if self.els[k][0] == layer]
            if not ks:
                continue
            out.append('<g data-layer="%s">' % layer)
            for k in ks:
                _l, tag, attrs, text, _it, _g = self.els[k]
                a = " ".join(['id="%s"' % self.ref[k]] +
                             ['%s="%s"' % (n, _esc(self._v(n, v)))
                              for n, v in attrs])
                if tag == "text":
                    out.append("<text %s>%s</text>" % (a, _esc(text)))
                else:
                    out.append("<%s %s/>" % (tag, a))
            out.append("</g>")
        out.append("</svg>")
        return "\n".join(out) + "\n"

    def object_map(self, public_hash, settings_hash):
        els, items = {}, []
        for it in self.items:
            refs = sorted((self.ref[k] for k in self.item_els[it["id"]]),
                          key=lambda r: int(r[1:]))
            if not refs:
                continue
            d = dict(it)
            if it["role"] in ("axis_unit",):
                d["text"] = it["text"]          # the LOGICAL text
            d["elements"] = refs
            items.append(d)
            for r in refs:
                k = self._k(r)
                els[r] = {"tag": self.els[k][1], "item": it["id"]}
        objects = {}
        for oid in sorted(self.objects):
            o = self.objects[oid]
            parts = sorted(set(self.ref[k] for k in o["parts"]),
                           key=lambda r: int(r[1:]))
            objects[oid] = {"kind": o["kind"],
                            "parts": [{"element": r, "span": "whole"}
                                      for r in parts]}
        return {"engine": ENGINE_VERSION, "dialect": DIALECT,
                "figure": self.pub["figure"], "public_hash": public_hash,
                "settings_hash": settings_hash, "elements": els,
                "display_items": items, "objects": objects}

    def _k(self, ref):
        if not hasattr(self, "_rev"):
            self._rev = dict((v, k) for k, v in self.ref.items())
        return self._rev[ref]

    def placements(self):
        dx, dy = self.off
        kx = self.sqx / float(self.ax.step)
        ky = self.sqy / float(self.ay.step)
        e = dx + self.X(0)
        f = dy + self.Y(0)
        return {"canvas_px": [self.W, self.H],
                "square_px": [geo.r2(self.sqx), geo.r2(self.sqy)],
                "px_per_unit": [_r6(kx), _r6(ky)],
                "model_to_svg": {"matrix": [_r6(kx), 0.0, 0.0, _r6(-ky),
                                            _r6(e), _r6(f)],
                                 "model": "value"},
                "window": {"x": [K.cstr(self.ax.lo), K.cstr(self.ax.hi)],
                           "y": [K.cstr(self.ay.lo), K.cstr(self.ay.hi)]},
                "marks_px": dict((m, [geo.r2(c[0] + dx), geo.r2(c[1] + dy)])
                                 for m, c in sorted(self.dots.items())),
                "page": {"unit": "pt", "pt_per_px": 0.75,
                         "size_pt": [geo.r2(self.W * 0.75),
                                     geo.r2(self.H * 0.75)]}}


def _box_beside(c, dist, deg, w, h):
    """the w x h box whose nearest point to c lies `dist` away in the
    direction deg (degrees, y down): an edge's middle for the four axis
    directions, a corner for the diagonals, in between otherwise"""
    ph = math.radians(deg)
    ux, uy = math.cos(ph), math.sin(ph)
    px, py = c[0] + ux * dist, c[1] + uy * dist
    # the box extends away from c: its anchor on the side facing c
    ax = 0.5 - 0.5 * _clamp(ux / 0.7071)
    ay = 0.5 - 0.5 * _clamp(uy / 0.7071)
    x0 = px - ax * w
    y0 = py - ay * h
    return (x0, y0, x0 + w, y0 + h)


def _dash(step_px):
    """a dashed curve's pattern: 4 3 px, longer on a large square -- a gap
    is never below 0.12 step and five steps hold at least 3 gaps"""
    a = max(4.0, round(0.2 * step_px, 1))
    b = max(3.0, round(0.12 * step_px, 1))
    return "%s %s" % (geo.fmt(a), geo.fmt(b))


def _clamp(v):
    return max(-1.0, min(1.0, v))


def below_y(yx, g):
    return yx + g


def _quad_extreme_y(P0, P1, P2):
    """the y extreme of a quadratic Bezier (its lowest px on the page)"""
    den = P0[1] - 2 * P1[1] + P2[1]
    if abs(den) < 1e-12:
        return P0[1]
    t = (P0[1] - P1[1]) / den
    t = max(0.0, min(1.0, t))
    return (1 - t) ** 2 * P0[1] + 2 * (1 - t) * t * P1[1] + t * t * P2[1]


def _fmt_signed(v):
    """a Bezier control point may lie off the canvas (above it)"""
    r = geo.r2(v)
    if r < 0:
        return "-" + geo.fmt(-r)
    return geo.fmt(r)


def _r6(x):
    return round(float(x), 6)


def _gaps(lo, hi, cuts):
    out, cur = [], lo
    for a, b in cuts:
        if b <= cur or a >= hi:
            continue
        if a - cur >= 0.5:
            out.append((cur, a))
        cur = max(cur, b)
    if hi - cur >= 0.5:
        out.append((cur, hi))
    return out


def _attempt(pub, st, sq):
    b = _Builder(pub, st, sq)
    b.plan()
    b.draw_axes()
    b.draw_curves()
    b.draw_guides()
    b.draw_marks()
    b.label_letters()
    b.label_numbers()
    b.label_titles()
    b.label_marks()
    b.label_curves()
    b.draw_grid()
    return b


def _map_issues(svg_text, om, pub):
    ids = re.findall(r' id="(e[0-9]{4})"', svg_text)
    out = []
    if sorted(ids) != sorted(om["elements"]) or len(set(ids)) != len(ids) \
            or ids != ["e%04d" % (k + 1) for k in range(len(ids))]:
        out.append(_issue("MAP_NOT_TOTAL", om["figure"], "file ids %d vs map "
                          "%d" % (len(ids), len(om["elements"]))))
    known = set(["axis:x", "axis:y", "plane:xy"] +
                [c["id"] for c in pub["curves"]] +
                [m["id"] for m in pub["marks"]])
    owner = {}
    for it in om["display_items"]:
        if it["role"] not in ROLES:
            out.append(_issue("MAP_BAD_ROLE", it["id"], it["role"]))
        if it["source"].get("entity") not in known:
            out.append(_issue("MAP_BAD_SOURCE", it["id"],
                              repr(it["source"])))
        for e in it["elements"]:
            if e in owner:
                out.append(_issue("MAP_SHARED_ELEMENT", e, "%s and %s"
                                  % (owner[e], it["id"])))
            owner[e] = it["id"]
    for e, rec in om["elements"].items():
        if owner.get(e) != rec["item"]:
            out.append(_issue("MAP_NOT_TOTAL", e, "no single owner"))
    guides = set("guide:%s:%s" % (m["id"], a) for m in pub["marks"]
                 for a in m["guides"])
    for oid, o in om["objects"].items():
        if oid not in known and oid not in guides:
            out.append(_issue("MAP_BAD_PART", oid, "not a public id"))
    for c in pub["curves"]:
        if c["id"] not in om["objects"]:
            out.append(_issue("RENDER_CURVE_MISSING", c["id"], "not drawn"))
    return out


def _self_measure(b):
    """the renderer's own sanity pass: every emitted curve element on its
    curve within 0.02 step (the rounding of the dialect's two decimals)"""
    out = []
    dx, dy = b.off
    for dc in b.curves:
        g = b.els[dc.el][5]
        pts = []
        if g[0] == "line":
            p, q = g[1], g[2]
            pts = [(p[0] + (q[0] - p[0]) * t / 20.0,
                    p[1] + (q[1] - p[1]) * t / 20.0) for t in range(21)]
        else:
            P0, P1, P2 = g[1], g[2], g[3]
            pts = [((1 - t) ** 2 * P0[0] + 2 * (1 - t) * t * P1[0] +
                    t * t * P2[0], (1 - t) ** 2 * P0[1] + 2 * (1 - t) * t *
                    P1[1] + t * t * P2[1])
                   for t in [i / 40.0 for i in range(41)]]
        worst = 0.0
        for X, Y in pts:
            x = (X / b.sqx - b.ax.zero) * float(b.ax.step)
            y = (b.ay.n - Y / b.sqy - b.ay.zero) * float(b.ay.step)
            if dc.cur.fn == "vline":
                err = abs(x - float(dc.cur.c)) / float(b.ax.step)
            else:
                err = abs(y - dc.cur.fl(x)) / float(b.ay.step)
            worst = max(worst, err)
        if worst > 0.02:
            out.append(_issue("RENDER_CURVE_OFF", dc.cid, "%.4f step off its "
                              "equation" % worst))
    return out


def render(public_graph, display_settings, engine_version):
    if engine_version != ENGINE_VERSION:
        raise RenderRefused("RENDER_VERSION", "this engine is %s, not %r"
                            % (ENGINE_VERSION, engine_version))
    require_public(public_graph)
    st = settings(display_settings)
    if st["figure"] != public_graph["figure"]:
        raise RenderRefused("RENDER_BAD_SETTINGS", "figure %r is not %r"
                            % (st["figure"], public_graph["figure"]))
    sq0 = float(st["square"])
    sq = sq0
    last_bad = None

    def crowded_(b_):
        return any(i["code"] in ("RENDER_AXIS_CROWDED",
                                 "RENDER_LABEL_NO_PLACE") for i in b_.issues)
    while True:
        b = _attempt(public_graph, st, sq)
        crowded = crowded_(b)
        numbers = any(i["code"] == "RENDER_AXIS_CROWDED" for i in b.issues)
        top = MAX_SQUARE_CROWDED_PX if numbers else MAX_SQUARE_PX
        if not crowded or not st["grow"] or sq >= top - 1e-9:
            break
        last_bad = sq
        sq = min(top, round(sq * GROW, 2))
    # grown: the smallest square between the last crowded one and this one
    # that fits (bisection to 0.25 px) -- the figure no larger than needed
    if last_bad is not None and not crowded:
        lo, hi = last_bad, sq
        while hi - lo > 0.25:
            mid = round((lo + hi) / 2.0, 2)
            bm = _attempt(public_graph, st, mid)
            if crowded_(bm):
                lo = mid
            else:
                hi, b = mid, bm
        sq = hi
    b.finish()
    svg = b.svg()
    settings_hash = hashlib.sha256(canon.dumps(st).encode("utf-8")) \
        .hexdigest()
    om = b.object_map(public_graph["public_hash"], settings_hash)
    issues = sorted(b.issues + _map_issues(svg, om, public_graph) +
                    _self_measure(b),
                    key=lambda i: (i["code"], i["where"], i["detail"]))
    validation = {"engine": ENGINE_VERSION, "figure": public_graph["figure"],
                  "status": "PASS" if not issues else "FAIL",
                  "issues": issues,
                  "checked": ["gate: public graph model only (keys, scan, "
                              "hash)", "settings closed (graph)",
                              "every curve / mark at its public numbers or "
                              "layout (they agree)",
                              "every printed number placed, free of strokes "
                              "and dots", "labels beside their own curve / "
                              "dot, covering nothing",
                              "object map total, one owner per element",
                              "every curve element on its equation "
                              "(<= 0.02 step)"],
                  "svg_sha256": hashlib.sha256(svg.encode("utf-8"))
                  .hexdigest()}
    pl = b.placements()
    pl["asked_square_px"] = geo.r2(sq0)
    pl["grown"] = abs(sq - sq0) > 1e-9
    return {"svg": svg, "object_map": om, "placements": pl,
            "validation": validation}


def dumps(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, indent=1) + \
        "\n"


def default_settings(spec, **kw):
    """display settings for an author spec: its figure and its layout"""
    lay = K.display_layout(spec)
    st = {"figure": spec["figure"], "curves": lay["curves"],
          "marks": lay["marks"]}
    st.update(kw)
    return st
