# -*- coding: utf-8 -*-
"""Hebrew axis titles inside an SVG <text> (v6.16, graph family).

wspec.bidi handles a label that is an LTR part followed by ONE Hebrew run
('5 ס״מ'). An axis title of a real-life graph is a whole Hebrew phrase with
a parenthesis ('זמן (דקות)', 'עלות (₪)', 'מרחק (ק״מ)'): its paragraph is
RTL, so its visual order (left to right as printed) is the whole string
reversed with the parentheses mirrored. As in wspec.bidi, the SVG stores
the VISUAL order under direction="ltr" unicode-bidi="bidi-override" (so
WeasyPrint, which runs no bidi in SVG, and a browser print the same glyph
order); the object map and every reader use logical().

Only kinds.TITLE_RE strings are accepted: Hebrew letters, geresh /
gershayim, maqaf, spaces, one pair of parentheses and the shekel sign -- no
digit and no Latin letter, whose runs would keep their own LTR order."""
from . import kinds as K

BIDI_ATTRS = (("direction", "ltr"), ("unicode-bidi", "bidi-override"))
_MIRROR = {"(": ")", ")": "("}


class RtlError(ValueError):
    pass


def visual(title):
    if not K._title_ok(title):
        raise RtlError("axis title %r is outside the title grammar" % title)
    return "".join(_MIRROR.get(ch, ch) for ch in reversed(title))


def logical(stored):
    """the inverse of visual() (its own inverse)"""
    return "".join(_MIRROR.get(ch, ch) for ch in reversed(stored))
