# -*- coding: utf-8 -*-
"""wspec.graph -- v6.16 (BRIEF_V616 G1-G3): FUNCTION GRAPHS on a coordinate
plane, on the spec path. A line by its equation (y = mx + b, x = p), a
parabola with a = 1 and its shifts, and (G3) the marked intersection of two
graphs.

Modules (all new in v6.16, owner: the graphs engine agent):
  kinds      the author spec 'wspec-graph/1' (closed), its validation with
             exact rational arithmetic, the leak rules (what a find forbids
             the figure to show), the public projection, the display layout,
             the answer guard, and from_neutral() (the corpus's engine-neutral
             spec -> an author spec, adding nothing)
  rtl        Hebrew axis titles in an SVG <text> (visual order + override)
  render     render(public, settings, ENGINE_VERSION) -> svg, object_map,
             placements, validation   (dialect wspec-graph-svg/1)
  highlight  highlight(svg, object_map, object_id) / verify_highlight
  check      the INDEPENDENT checker (imports nothing from render)
  hooks      the registered hooks into the rest of wspec (install())

Nothing here edits another module of wspec; hooks.install() registers the
graph figure with the sheet-level spec path at run time and HOOKS.txt says
where an integrator merges it (v616/HOOKS.txt).
"""
from .kinds import GRAPH_VERSION, PUBLIC_VERSION, GraphSpecError  # noqa
