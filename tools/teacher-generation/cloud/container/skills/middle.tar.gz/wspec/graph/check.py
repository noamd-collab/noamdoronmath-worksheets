# -*- coding: utf-8 -*-
"""wspec.graph.check -- the INDEPENDENT checker of a graph figure (v6.16,
BRIEF_V616 G1-G3).

It imports nothing from wspec.graph.render or wspec.render and never reads
the renderer's code. It reads the SVG (the closed dialect wspec-graph-svg/1,
the data file graph_dialect.json), the renderer's object map and the PUBLIC
graph model (anything private -- an answer, a key outside the public
whitelist, a model edited after its hash -- is refused: CheckerInputError).
From the rest of wspec it uses wspec.canon (numbers) and, from kinds, only
the exact rational reader Q and the token match of SCORING s0; the
equations printed on the figure are read by its OWN evaluator (below),
not by the kinds module that wrote them.

    rep = check_graph(svg, object_map, public_graph, answer_guard=None)
    private_check(rep, private_model)   # the harness side: hidden numbers
    check_highlight(svg, hl_svg, object_map, object_id)

What it MEASURES on the drawing (nothing is taken from a hook's word):
  axes     grid lines and ticks -> px = a + b * index per axis (a robust
           least-squares fit); the printed numbers -> value per index;
           AX_TICKS_AT_VALUES, AX_SCALE_CONSISTENT, WINDOW_AS_DECLARED,
           ORIGIN_AT_ZERO, AXIS_ARROW_DIRECTION, GRID_AS_DECLARED,
           AXIS_ASPECT_AS_DECLARED (px per data unit equal within 2 %)
  numbers  AX_NUMBERS_AS_DECLARED (every public label printed once, as
           U+2212 text), AX_MINUS_U2212, AX_NUMBERS_OWNED (within 0.25 step
           of its tick along the axis, nearer it than any other tick, next
           to its axis), AX_NUMBERS_NOT_CUT
  curves   every sample of the element (a <line>, or the quadratic Bezier
           of a <path> flattened) within TOL_POS = 0.05 step (Euclidean, in
           step units) of the public equation: LINE_EQUATION_EXACT /
           PARABOLA_EXACT (+ a = 1, the vertex the lowest point);
           CURVE_EXTENT_AS_DECLARED (the window's part, +- 0.5 step, never
           past the window by more than TOL_POS); CURVE_ONE_UNCUT_PATH (one
           element, one piece); CURVE_STYLE_AS_DECLARED (dashed: gaps >= 0.1
           step, >= 3 gaps per 5 steps; solid: none); a curve whose numbers
           are not public is MEASURED (measured.curves) and judged by
           private_check()
  marks    MARKS_AT_COORDS (the dot within TOL_POS of its public xy and of
           every curve it is on), MARK_KIND_EXACT (vertex / zero /
           y-intercept / intersection)
  labels   LABEL_TEXT_AS_DECLARED (a curve's name / equation, read by the
           checker's own evaluator and compared with the curve; a mark's
           '(x, y)' compared with the dot), CURVE_LABEL_OWNED (nearer its
           own curve than any other by 0.3 step, 0.5 step from a crossing,
           near its curve), MARK_LABEL_OWNED, AXIS_NAMES_AS_DECLARED (the
           letter; a Hebrew title in visual order under the bidi override,
           read back to the public text), TEXT_BOX_IN_CANVAS,
           TEXT_NOT_COVERING_MARKS (no text covers a curve, an axis, a tick,
           an arrow, a guide, a dot or another text), TEXT_MIN_SIZE,
           ANGLE_NAMES_THREE_LETTERS
  givens   (round 2) GIVENS_NAMES_ONLY: a givens-only figure (public
           "givens": true) prints only bare names as labels (a point: one
           Latin capital other than X, Y; a curve: f, g, h or such a
           capital) -- read from the printed texts
  didactic GUIDES_ONLY_IF_STATED; TARGET_NOT_DRAWN (answer_guard: no dot
           at a guarded point, no stroke of a guarded curve, no label that
           is a guarded equation, no text containing a guarded text)
  map      OBJMAP_TOTAL_NO_UNMAPPED_INK: every element in exactly one
           display item, roles agree with hooks, every object's parts =
           the elements the checker attributes to it, no object for a find
"""
import json
import math
import os
import re
import xml.etree.ElementTree as ET
from fractions import Fraction

from . import kinds as K

DIALECT_JSON = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            "graph_dialect.json")
NS = "{http://www.w3.org/2000/svg}"
MINUS = u"−"
TOL_POS = 0.05            # step units
TOL_EXTENT = 0.5          # step units
FIT_TOL_PX = 0.3
ASPECT_TOL = 0.02
NUM_ALONG_STEP = 0.25     # a number's centre this near its tick along the axis
NUM_ACROSS_PX = 18.0      # ... and its box this near the axis line (a
                          # number steps out where a curve crosses the axis)
LABEL_NEAR_PX = 16.0      # a curve label this near its own curve
OWN_STEP = 0.3
CROSS_STEP = 0.5
MARK_OWN_PX = 1.0
COVER_SHRINK_PX = 0.25
DASH_MIN_GAP_STEP = 0.1
FAIL, REVIEW, PASS, NA = "FAIL", "REVIEW", "PASS", "NA"
CHECKS = ["PUBLIC_ONLY_INPUT", "DIALECT_CLOSED",
          "OBJMAP_TOTAL_NO_UNMAPPED_INK", "WINDOW_AS_DECLARED",
          "AX_TICKS_AT_VALUES", "AX_SCALE_CONSISTENT",
          "SCALE_PER_AXIS_MEASURED", "ORIGIN_AT_ZERO",
          "AXIS_ARROW_DIRECTION", "GRID_AS_DECLARED",
          "AXIS_ASPECT_AS_DECLARED", "AX_NUMBERS_AS_DECLARED",
          "AX_MINUS_U2212", "AX_NUMBERS_OWNED", "AX_NUMBERS_NOT_CUT",
          "AXIS_NAMES_AS_DECLARED", "LINE_EQUATION_EXACT", "PARABOLA_EXACT",
          "CURVE_EXTENT_AS_DECLARED", "CURVE_ONE_UNCUT_PATH",
          "CURVE_STYLE_AS_DECLARED", "PARALLEL_MEASURED", "MARKS_AT_COORDS",
          "MARK_KIND_EXACT", "LABEL_TEXT_AS_DECLARED", "CURVE_LABEL_OWNED",
          "MARK_LABEL_OWNED", "TEXT_BOX_IN_CANVAS", "TEXT_NOT_COVERING_MARKS",
          "TEXT_MIN_SIZE", "ANGLE_NAMES_THREE_LETTERS",
          "GUIDES_ONLY_IF_STATED", "TARGET_NOT_DRAWN",
          "INTERSECTION_MARK_EXACT", "OPTIONAL_DATUM_EXACT", "AXIS_UNIT_IF_ANY",
          "GIVENS_NAMES_ONLY"]
ROLE_HOOK = {"grid_line": "data-grid", "axis_line": "data-axis",
             "axis_arrow": "data-arrow", "tick": "data-tick",
             "axis_number": "data-num", "origin_zero": "data-num",
             "axis_name": "data-axname", "axis_unit": "data-axtitle",
             "curve": "data-curve", "curve_label": "data-for",
             "mark": "data-pt", "mark_label": "data-for",
             "optional_mark": "data-pt", "optional_label": "data-for",
             "guide": "data-guide"}
MAP_TOP = {"engine", "dialect", "figure", "public_hash", "settings_hash",
           "elements", "display_items", "objects"}
PUBLIC_TOP = {"graph_public", "figure", "frame", "axes", "aspect", "curves",
              "marks", "parallel", "finds", "public_hash"}
PUBLIC_TOP_OPTIONAL = {"givens"}   # (round 2) a givens-only figure: true
PUBLIC_KEYS = {"curve": {"id", "fn", "style", "label", "def", "extent",
                         "symmetry_of"},
               "mark": {"id", "kind", "on", "label", "guides", "xy",
                        "optional"},
               "find": {"id", "item", "rel", "args", "at"}}


class CheckerInputError(Exception):
    pass


def load_dialect(path=DIALECT_JSON):
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


class Rep(object):
    def __init__(self):
        self.findings = []
        self.checks = dict((c, NA) for c in CHECKS)
        self.measured = {"axes": {}, "curves": {}, "marks": {}, "labels": {}}

    def ran(self, check):
        if self.checks.get(check) == NA:
            self.checks[check] = PASS

    def add(self, level, code, check, obj, detail):
        self.findings.append({"level": level, "code": code, "check": check,
                              "object": obj, "detail": detail})
        order = {NA: 0, PASS: 1, REVIEW: 2, FAIL: 3}
        if order[level] > order[self.checks.get(check, NA)]:
            self.checks[check] = level

    def fail(self, check, obj, detail, code=None):
        self.add(FAIL, code or "CHK_" + check, check, obj, detail)

    def review(self, check, obj, detail, code=None):
        self.add(REVIEW, code or "CHK_" + check, check, obj, detail)

    def result(self):
        st = PASS
        if any(f["level"] == FAIL for f in self.findings):
            st = FAIL
        elif any(f["level"] == REVIEW for f in self.findings):
            st = REVIEW
        objs = {}
        for f in self.findings:
            o = f["object"] or "figure"
            objs.setdefault(o, []).append(f)
        return {"status": st, "checks": dict(self.checks),
                "findings": self.findings, "measured": self.measured,
                "objects": dict((o, {"status": FAIL if any(
                    x["level"] == FAIL for x in fs) else REVIEW,
                    "findings": fs}) for o, fs in sorted(objs.items()))}


# --------------------------------------------------------------- input ---
def _hash(pub):
    import hashlib
    from .. import canon
    body = dict((k, v) for k, v in pub.items() if k != "public_hash")
    return hashlib.sha256(canon.dumps(body).encode("utf-8")).hexdigest()


def _gate(pub):
    if not isinstance(pub, dict) or not (
            PUBLIC_TOP <= set(pub) <= PUBLIC_TOP | PUBLIC_TOP_OPTIONAL) or \
            pub.get("givens", True) is not True:
        raise CheckerInputError("not a public graph model: keys %s" % (
            sorted((set(pub) - PUBLIC_TOP_OPTIONAL) ^ PUBLIC_TOP)
            if isinstance(pub, dict) else type(pub).__name__))

    def walk(o):
        if isinstance(o, dict):
            for k, v in o.items():
                if k in ("answer", "answers", "answer_guard", "truth",
                         "private"):
                    raise CheckerInputError("private key %r" % k)
                walk(v)
        elif isinstance(o, list):
            for v in o:
                walk(v)
    walk(pub)
    for kind, key in (("curve", "curves"), ("mark", "marks"),
                      ("find", "finds")):
        for rec in pub.get(key) or []:
            extra = set(rec) - PUBLIC_KEYS[kind]
            if extra:
                raise CheckerInputError("%s %s: keys %s" % (
                    kind, rec.get("id"), sorted(extra)))
    if _hash(pub) != pub.get("public_hash"):
        raise CheckerInputError("public_hash does not match the content")


# ----------------------------------------------------------------- svg ---
class El(object):
    def __init__(self, tag, a, text, layer):
        self.tag, self.a, self.text, self.layer = tag, a, text, layer
        self.id = a.get("id")
        self.hook = None
        self.val = None


def _parse(svg, D, rep):
    rep.ran("DIALECT_CLOSED")
    if "<!" in svg or "<!--" in svg:
        rep.fail("DIALECT_CLOSED", None, "DOCTYPE / comment / CDATA")
    try:
        root = ET.fromstring(svg.encode("utf-8"))
    except ET.ParseError as ex:
        rep.fail("DIALECT_CLOSED", None, "does not parse: %s" % ex)
        return None, []
    if root.tag != NS + "svg":
        rep.fail("DIALECT_CLOSED", None, "root %s" % root.tag)
        return None, []
    for k in root.attrib:
        if k not in D["root_attrs"] and k != "xmlns":
            rep.fail("DIALECT_CLOSED", None, "root attribute %s" % k)
    if root.get("data-dialect") != D["dialect"]:
        rep.fail("DIALECT_CLOSED", None, "data-dialect %r"
                 % root.get("data-dialect"))
    els = []
    layers_seen = []
    num = re.compile(D["number"])
    snum = re.compile(D["signed_number"])
    for g in root:
        if g.tag != NS + "g" or set(g.attrib) != {"data-layer"}:
            rep.fail("DIALECT_CLOSED", None, "top element %s %s" % (
                g.tag, dict(g.attrib)))
            continue
        layer = g.get("data-layer")
        if layer not in D["layers"] or layer in layers_seen or (
                layers_seen and D["layers"].index(layer) <
                D["layers"].index(layers_seen[-1])):
            rep.fail("DIALECT_CLOSED", None, "layer %r out of order" % layer)
        layers_seen.append(layer)
        for c in g:
            tag = c.tag.replace(NS, "")
            e = El(tag, dict(c.attrib), c.text or "", layer)
            if len(list(c)):
                rep.fail("DIALECT_CLOSED", e.id, "nested element")
            hooks = [h for h in D["hooks"] if h in c.attrib]
            if len(hooks) != 1:
                rep.fail("DIALECT_CLOSED", e.id, "hooks %s" % hooks)
                els.append(e)
                continue
            h = hooks[0]
            spec = D["hooks"][h]
            e.hook, e.val = h, c.get(h)
            tags = spec["tag"] if isinstance(spec["tag"], list) else \
                [spec["tag"]]
            if tag not in tags or layer != spec["layer"]:
                rep.fail("DIALECT_CLOSED", e.id, "%s on <%s> in %s" % (
                    h, tag, layer))
            if not re.match(D["grammars"][spec["grammar"]], e.val or ""):
                rep.fail("DIALECT_CLOSED", e.id, "%s=%r" % (h, e.val))
            allowed = set(["id", h] + (spec.get("attrs") or []))
            if tag == "text":
                allowed |= set(D["text_attrs"])
            for k, v in c.attrib.items():
                if k not in allowed:
                    rep.fail("DIALECT_CLOSED", e.id, "attribute %s" % k)
                    continue
                if k in spec and isinstance(spec[k], list) and \
                        v not in spec[k]:
                    rep.fail("DIALECT_CLOSED", e.id, "%s=%r" % (k, v))
                if k == "stroke-dasharray" and isinstance(spec.get(k),
                                                          str) and \
                        not re.match(spec[k].split(" (")[0], v):
                    rep.fail("DIALECT_CLOSED", e.id, "%s=%r" % (k, v))
                if k in ("x1", "y1", "x2", "y2", "cx", "cy", "x", "y", "r") \
                        and not num.match(v):
                    rep.fail("DIALECT_CLOSED", e.id, "number %s=%r" % (k, v))
            if tag == "path":
                parts = (c.get("d") or "").split(" ")
                ok = len(parts) == 8 and parts[0] == "M" and \
                    parts[3] == "Q" and all(num.match(p) for p in
                                            parts[1:3] + parts[4:5] +
                                            parts[6:8]) and \
                    snum.match(parts[5])
                if not ok:
                    rep.fail("DIALECT_CLOSED", e.id, "path d=%r" % c.get("d"))
            if tag == "polygon":
                for p in (c.get("points") or "").split(" "):
                    xy = p.split(",")
                    if len(xy) != 2 or not all(num.match(v) for v in xy):
                        rep.fail("DIALECT_CLOSED", e.id, "points %r" % p)
            if tag == "text":
                if c.get("font-family") not in D["font_families"] or \
                        c.get("font-size") not in D["font_sizes"] or \
                        c.get("text-anchor", "start") not in \
                        D["text_anchors"] or c.get("fill") != "#000000":
                    rep.fail("DIALECT_CLOSED", e.id, "text attributes")
            els.append(e)
    ids = [e.id for e in els]
    if ids != ["e%04d" % (k + 1) for k in range(len(els))]:
        rep.fail("DIALECT_CLOSED", None, "ids are not e0001.. in document "
                 "order")
    return root, els


def _f(v):
    return float(v)


# -------------------------------------------------------------- geometry --
def _seg_hits_box(a, b, box):
    x0, y0, x1, y1 = box
    dx, dy = b[0] - a[0], b[1] - a[1]
    t0, t1 = 0.0, 1.0
    for pk, qk in ((-dx, a[0] - x0), (dx, x1 - a[0]), (-dy, a[1] - y0),
                   (dy, y1 - a[1])):
        if abs(pk) < 1e-12:
            if qk < 0:
                return False
            continue
        t = qk / pk
        if pk < 0:
            if t > t1:
                return False
            t0 = max(t0, t)
        else:
            if t < t0:
                return False
            t1 = min(t1, t)
    return t0 <= t1


def _pt_seg(p, a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    L2 = dx * dx + dy * dy
    if L2 == 0:
        return math.hypot(p[0] - a[0], p[1] - a[1])
    t = max(0.0, min(1.0, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / L2))
    return math.hypot(p[0] - a[0] - t * dx, p[1] - a[1] - t * dy)


def _box_pt(box, p):
    dx = max(box[0] - p[0], 0.0, p[0] - box[2])
    dy = max(box[1] - p[1], 0.0, p[1] - box[3])
    return math.hypot(dx, dy)


def _box_seg(box, a, b):
    if _seg_hits_box(a, b, box):
        return 0.0
    cs = [(box[0], box[1]), (box[2], box[1]), (box[2], box[3]),
          (box[0], box[3])]
    return min([_pt_seg(c, a, b) for c in cs] + [_box_pt(box, a),
                                                  _box_pt(box, b)])


def _overlap(a, b):
    return not (a[2] <= b[0] or b[2] <= a[0] or a[3] <= b[1] or b[3] <= a[1])


def _shrink(b, m):
    return (b[0] + m, b[1] + m, b[2] - m, b[3] - m)


def text_w(t, fs, D):
    """the dialect's text width (graph_dialect.json ink_w, glyph_w)"""
    return fs * sum(D["ink_w"].get(c, D["glyph_w"]) for c in t)


def text_box(e, D):
    fs = _f(e.a["font-size"])
    x, y = _f(e.a["x"]), _f(e.a["y"])
    t = e.text
    w, h = text_w(t, fs, D), D["glyph_h"] * fs
    x0 = x - {"start": 0.0, "middle": w / 2, "end": w}[
        e.a.get("text-anchor", "start")]
    dsc = D["descent"] * fs if any(c in "gjpqy" for c in t) else 0.0
    return (x0, y - h, x0 + w, y + dsc)


def _bezier(d, n=80):
    p = [float(v) for i, v in enumerate(d.split(" ")) if i not in (0, 3)]
    P0, P1, P2 = (p[0], p[1]), (p[2], p[3]), (p[4], p[5])
    out = []
    for i in range(n + 1):
        t = i / float(n)
        out.append(((1 - t) ** 2 * P0[0] + 2 * (1 - t) * t * P1[0] +
                    t * t * P2[0], (1 - t) ** 2 * P0[1] + 2 * (1 - t) * t *
                    P1[1] + t * t * P2[1]))
    return out


def _px_samples(e, n=80):
    if e.tag == "line":
        a = (_f(e.a["x1"]), _f(e.a["y1"]))
        b = (_f(e.a["x2"]), _f(e.a["y2"]))
        return [(a[0] + (b[0] - a[0]) * i / float(n),
                 a[1] + (b[1] - a[1]) * i / float(n)) for i in range(n + 1)]
    return _bezier(e.a["d"], n)


def _fit(pairs):
    """least squares v = a + b i -> (a, b, max residual)"""
    n = len(pairs)
    si = sum(i for i, _v in pairs)
    sv = sum(v for _i, v in pairs)
    sii = sum(i * i for i, _v in pairs)
    siv = sum(i * v for i, v in pairs)
    den = n * sii - si * si
    if n < 2 or den == 0:
        return None
    b = (n * siv - si * sv) / den
    a = (sv - b * si) / n
    res = max(abs(v - (a + b * i)) for i, v in pairs)
    return a, b, res


# ------------------------------------------------ the checker's evaluator --
def eval_equation(text, x):
    """the value at x of a printed 'y = ...' (exact, the checker's own
    reading), or ('vline', c) for 'x = c'; None when unreadable"""
    s = text.replace(MINUS, "-").replace(" ", "")
    if s.startswith("x="):
        try:
            return ("vline", Fraction(s[2:]))
        except (ValueError, ZeroDivisionError):
            return None
    if not s.startswith("y="):
        return None
    src = s[2:]
    pos = [0]

    def peek():
        return src[pos[0]] if pos[0] < len(src) else ""

    def number():
        m = re.match(r"\d+(?:\.\d+)?(?:/\d+)?", src[pos[0]:])
        if not m:
            raise ValueError
        pos[0] += m.end()
        return Fraction(m.group(0))

    def factor():
        c = peek()
        if c.isdigit():
            v = number()
        elif c == "x":
            pos[0] += 1
            v = Fraction(x)
        elif c == "(":
            pos[0] += 1
            v = expr()
            if peek() != ")":
                raise ValueError
            pos[0] += 1
        else:
            raise ValueError
        if peek() == u"²":
            pos[0] += 1
            v = v * v
        return v

    def term():
        v = factor()
        while peek() in ("x", "(") or peek().isdigit():
            v = v * factor()
        return v

    def expr():
        sign = 1
        if peek() in "+-" and peek():
            sign = -1 if peek() == "-" else 1
            pos[0] += 1
        v = sign * term()
        while peek() in ("+", "-") and peek():
            sign = -1 if peek() == "-" else 1
            pos[0] += 1
            v += sign * term()
        return v
    try:
        v = expr()
    except (ValueError, ZeroDivisionError, IndexError):
        return None
    return v if pos[0] == len(src) else None


def _def_value(d, x):
    """y of a public def at x (exact)"""
    if d["fn"] == "line":
        return K.Q(d["m"]) * x + K.Q(d["b"])
    if d["fn"] == "parabola":
        return (x - K.Q(d["p"])) ** 2 + K.Q(d["k"])
    return None


def text_is_curve(text, d):
    """True when the printed equation text IS the curve d (by the
    checker's own evaluation at six points)"""
    if d["fn"] == "vline":
        e = eval_equation(text, 0)
        return isinstance(e, tuple) and e[1] == K.Q(d["x"])
    for x in (Fraction(-3), Fraction(-1), Fraction(0), Fraction(1),
              Fraction(2), Fraction(5)):
        v = eval_equation(text, x)
        if v is None or isinstance(v, tuple) or v != _def_value(d, x):
            return False
    return True


# --------------------------------------------------------------- check ---
class _Map(object):
    """the measured value <-> px map of the two axes"""

    def __init__(self, ax, ay, pub):
        self.ax, self.ay = ax, ay
        fr = pub["frame"]["axes"]
        self.n = (fr[0]["intervals"], fr[1]["intervals"])

    def to_data(self, X, Y):
        ax, ay = self.ax, self.ay
        x = ((X - ax["a"]) / ax["b"] - ax["zero"]) * ax["step"]
        y = ((Y - ay["a"]) / ay["b"] - ay["zero"]) * ay["step"]
        return (x, y)

    def to_px(self, x, y):
        ax, ay = self.ax, self.ay
        return (ax["a"] + ax["b"] * (ax["zero"] + x / ax["step"]),
                ay["a"] + ay["b"] * (ay["zero"] + y / ay["step"]))

    def steps(self, x, y):
        return (x / self.ax["step"], y / self.ay["step"])

    def step_px(self):
        return min(abs(self.ax["b"]), abs(self.ay["b"]))


def _pub_axis(pa):
    labs = [(int(i), float(K.Q(v))) for i, v in pa["labels"]]
    if len(labs) < 2:
        return None
    (i0, v0), (i1, v1) = labs[0], labs[-1]
    st = (v1 - v0) / (i1 - i0)
    zero = i0 - v0 / st
    return {"step": st, "zero": zero, "labels": labs,
            "n": pa["intervals"]}


def _dist_curve(d, xs, ys, sx, sy):
    """Euclidean distance in step units of the data point (xs, ys) from
    the public curve d"""
    if d["fn"] == "vline":
        return abs(xs - float(K.Q(d["x"]))) / sx
    if d["fn"] == "line":
        m, b = float(K.Q(d["m"])), float(K.Q(d["b"]))
        M, B = m * sx / sy, b / sy
        return abs(ys / sy - M * xs / sx - B) / math.sqrt(1 + M * M)
    p, k = float(K.Q(d["p"])), float(K.Q(d["k"]))
    best = abs(ys - ((xs - p) ** 2 + k)) / sy
    lo = xs - 2 * sx
    for i in range(401):
        x = lo + 4 * sx * i / 400.0
        dd = math.hypot((x - xs) / sx, ((x - p) ** 2 + k - ys) / sy)
        best = min(best, dd)
    return best


def _drawn_range(d, win, ext):
    """expected drawn x-range (floats) of a public def inside the window"""
    x0, x1, y0, y1 = win
    if ext is not None:
        x0, x1 = max(x0, ext[0]), min(x1, ext[1])
    if d["fn"] == "vline":
        return (y0, y1)
    if d["fn"] == "line":
        m, b = float(K.Q(d["m"])), float(K.Q(d["b"]))
        if m == 0:
            return (x0, x1)
        u, v = (y0 - b) / m, (y1 - b) / m
        return (max(x0, min(u, v)), min(x1, max(u, v)))
    p, k = float(K.Q(d["p"])), float(K.Q(d["k"]))
    w = math.sqrt(max(0.0, y1 - k))
    return (max(x0, p - w), min(x1, p + w))


def _fit_parabola(pts):
    """least squares y = a x^2 + b x + c -> (a, p, k)"""
    import itertools  # noqa: F401
    S = [[0.0] * 3 for _ in range(3)]
    T = [0.0] * 3
    for x, y in pts:
        v = [x * x, x, 1.0]
        for i in range(3):
            T[i] += v[i] * y
            for j in range(3):
                S[i][j] += v[i] * v[j]
    # Gauss
    A = [S[i] + [T[i]] for i in range(3)]
    for c in range(3):
        piv = max(range(c, 3), key=lambda r: abs(A[r][c]))
        A[c], A[piv] = A[piv], A[c]
        if abs(A[c][c]) < 1e-12:
            return None
        for r in range(3):
            if r != c:
                f = A[r][c] / A[c][c]
                for k in range(c, 4):
                    A[r][k] -= f * A[c][k]
    a, b, c = [A[i][3] / A[i][i] for i in range(3)]
    if abs(a) < 1e-12:
        return None
    p = -b / (2 * a)
    return a, p, c - b * b / (4 * a)


def _coords_of(text):
    m = re.match(u"^([A-Z][1-9]?'{0,3})?\\((−?[0-9.]+), "
                 u"(−?[0-9.]+)\\)$", text)
    if not m:
        return None
    return (float(K.Q(m.group(2))), float(K.Q(m.group(3))))


def check_graph(svg, object_map, public_graph, answer_guard=None):
    D = load_dialect()
    rep = Rep()
    try:
        _gate(public_graph)
    except CheckerInputError:
        raise
    rep.ran("PUBLIC_ONLY_INPUT")
    pub = public_graph
    root, els = _parse(svg, D, rep)
    if root is None:
        return rep.result()
    try:
        return _check_body(rep, D, pub, root, els, svg, object_map,
                           answer_guard)
    except (KeyError, ValueError, IndexError, ZeroDivisionError,
            AttributeError, TypeError) as ex:
        rep.fail("DIALECT_CLOSED", None, "the drawing cannot be measured: "
                 "%s: %s" % (type(ex).__name__, ex), code="CHK_UNREADABLE")
        return rep.result()


def _check_body(rep, D, pub, root, els, svg, object_map, answer_guard):
    W = _f(root.get("width"))
    H = _f(root.get("height"))
    by = {}
    for e in els:
        by.setdefault(e.hook, []).append(e)

    # ------------------------------------------------------------ axes
    pa = [_pub_axis(a) for a in pub["frame"]["axes"]]
    if None in pa:
        rep.fail("SCALE_PER_AXIS_MEASURED", None, "an axis prints fewer "
                 "than two numbers: the scale is not printed")
        return rep.result()
    fits = {}
    for n, a in enumerate(("x", "y")):
        rep.ran("AX_TICKS_AT_VALUES")
        rep.ran("AX_SCALE_CONSISTENT")
        rep.ran("WINDOW_AS_DECLARED")
        pos = []
        for e in by.get("data-grid", []) + by.get("data-tick", []):
            aa, i = e.val.split(" ")
            if aa != a:
                continue
            v = _f(e.a["x1"]) if a == "x" else _f(e.a["y1"])
            v2 = _f(e.a["x2"]) if a == "x" else _f(e.a["y2"])
            if abs(v - v2) > 0.01:
                rep.fail("AX_TICKS_AT_VALUES", "axis:" + a, "%s %s not "
                         "perpendicular to its axis" % (e.hook, e.val))
            pos.append((int(i), v))
        idx = sorted(set(i for i, _v in pos))
        f = _fit(pos)
        if f is None:
            rep.fail("AX_SCALE_CONSISTENT", "axis:" + a, "fewer than two "
                     "grid lines / ticks")
            return rep.result()
        if f[2] > FIT_TOL_PX:
            rep.fail("AX_SCALE_CONSISTENT", "axis:" + a, "ticks / grid lines "
                     "off a uniform scale by %.2f px" % f[2])
        if (a == "x" and f[1] <= 0) or (a == "y" and f[1] >= 0):
            rep.fail("AXIS_ARROW_DIRECTION", "axis:" + a, "values grow the "
                     "wrong way")
        want_n = pub["frame"]["axes"][n]["intervals"]
        if pub["frame"]["grid"] and idx != list(range(want_n + 1)):
            rep.fail("WINDOW_AS_DECLARED", "axis:" + a, "grid lines at %s, "
                     "want 0..%d" % (idx, want_n))
        elif idx and (idx[0] < 0 or idx[-1] > want_n):
            rep.fail("WINDOW_AS_DECLARED", "axis:" + a, "ticks past the "
                     "window")
        fits[a] = {"a": f[0], "b": f[1], "zero": pa[n]["zero"],
                   "step": pa[n]["step"], "res": f[2]}
    M = _Map(fits["x"], fits["y"], pub)
    rep.measured["axes"] = dict((a, {"px_at_0": round(fits[a]["a"], 3),
                                     "px_per_interval":
                                     round(fits[a]["b"], 3),
                                     "px_per_unit": round(
                                         fits[a]["b"] / fits[a]["step"], 4)})
                                for a in fits)
    sx, sy = fits["x"]["step"], fits["y"]["step"]
    spx = M.step_px()
    # grid: pieces within the frame, every line present
    rep.ran("GRID_AS_DECLARED")
    gx0, gx1 = sorted([M.to_px(pa[0]["step"] * (0 - pa[0]["zero"]), 0)[0],
                       M.to_px(pa[0]["step"] * (want_n_x(pub) -
                                                pa[0]["zero"]), 0)[0]])
    gy0, gy1 = sorted([M.to_px(0, pa[1]["step"] * (0 - pa[1]["zero"]))[1],
                       M.to_px(0, pa[1]["step"] * (want_n_y(pub) -
                                                   pa[1]["zero"]))[1]])
    frame_px = (gx0, gy0, gx1, gy1)
    if not pub["frame"]["grid"] and by.get("data-grid"):
        rep.fail("GRID_AS_DECLARED", "plane:xy", "grid lines on a frame "
                 "without a grid")
    for e in by.get("data-grid", []):
        p = (_f(e.a["x1"]), _f(e.a["y1"]))
        q = (_f(e.a["x2"]), _f(e.a["y2"]))
        for c in (p, q):
            if not (gx0 - 0.5 <= c[0] <= gx1 + 0.5 and
                    gy0 - 0.5 <= c[1] <= gy1 + 0.5):
                rep.fail("GRID_AS_DECLARED", "plane:xy", "grid piece %s "
                         "outside the frame" % e.id)
                break
    # axes lines + origin + arrows
    rep.ran("ORIGIN_AT_ZERO")
    rep.ran("AXIS_ARROW_DIRECTION")
    ox, oy = M.to_px(0, 0)
    for e in by.get("data-axis", []):
        a = e.val
        p = (_f(e.a["x1"]), _f(e.a["y1"]))
        q = (_f(e.a["x2"]), _f(e.a["y2"]))
        if a == "x" and (abs(p[1] - oy) > FIT_TOL_PX or
                         abs(q[1] - oy) > FIT_TOL_PX):
            rep.fail("ORIGIN_AT_ZERO", "axis:x", "the x axis is not at y = 0")
        if a == "y" and (abs(p[0] - ox) > FIT_TOL_PX or
                         abs(q[0] - ox) > FIT_TOL_PX):
            rep.fail("ORIGIN_AT_ZERO", "axis:y", "the y axis is not at x = 0")
        if a == "x" and not (min(p[0], q[0]) <= gx0 + 0.5 and
                             max(p[0], q[0]) >= gx1 - 0.5):
            rep.fail("WINDOW_AS_DECLARED", "axis:x", "the axis does not span "
                     "the window")
        if a == "y" and not (min(p[1], q[1]) <= gy0 + 0.5 and
                             max(p[1], q[1]) >= gy1 - 0.5):
            rep.fail("WINDOW_AS_DECLARED", "axis:y", "the axis does not span "
                     "the window")
    arrows = dict((e.val, e) for e in by.get("data-arrow", []))
    for a in ("x", "y"):
        e = arrows.get(a)
        if e is None:
            rep.fail("AXIS_ARROW_DIRECTION", "axis:" + a, "no arrowhead")
            continue
        pts = [tuple(float(v) for v in p.split(","))
               for p in e.a["points"].split(" ")]
        tip = max(pts, key=lambda p: p[0]) if a == "x" else \
            min(pts, key=lambda p: p[1])
        if (a == "x" and tip[0] < gx1) or (a == "y" and tip[1] > gy0):
            rep.fail("AXIS_ARROW_DIRECTION", "axis:" + a, "the arrowhead is "
                     "not past the positive end")
    # aspect
    rep.ran("AXIS_ASPECT_AS_DECLARED")
    kx = abs(fits["x"]["b"] / sx)
    ky = abs(fits["y"]["b"] / sy)
    rep.measured["aspect_y_over_x"] = round(ky / kx, 4)
    if pub["aspect"] == "equal" and abs(ky / kx - 1) > ASPECT_TOL:
        rep.fail("AXIS_ASPECT_AS_DECLARED", "plane:xy", "px per unit y / x "
                 "= %.3f, declared equal" % (ky / kx))

    # --------------------------------------------------------- numbers
    rep.ran("AX_NUMBERS_AS_DECLARED")
    rep.ran("AX_MINUS_U2212")
    rep.ran("AX_NUMBERS_OWNED")
    rep.ran("AX_NUMBERS_NOT_CUT")
    rep.ran("SCALE_PER_AXIS_MEASURED")
    num_re = re.compile(D["texts"]["axis_number"])
    printed = {"x": {}, "y": {}}
    origin = []
    for e in by.get("data-num", []):
        t = e.text
        if "-" in t:
            rep.fail("AX_MINUS_U2212", e.id, "hyphen-minus in %r" % t)
        if not num_re.match(t):
            rep.fail("AX_NUMBERS_AS_DECLARED", e.id, "number text %r" % t)
            continue
        if e.val == "origin":
            origin.append(e)
            if t != "0":
                rep.fail("AX_NUMBERS_AS_DECLARED", e.id, "origin %r" % t)
            continue
        a, i = e.val.split(" ")
        i = int(i)
        if i in printed[a]:
            rep.fail("AX_NUMBERS_AS_DECLARED", e.id, "tick %s %d printed "
                     "twice" % (a, i))
        printed[a][i] = e
    for n, a in enumerate(("x", "y")):
        want = dict((int(i), K.Q(v)) for i, v in
                    pub["frame"]["axes"][n]["labels"])
        zero_i = pa[n]["zero"]
        want_nz = dict((i, v) for i, v in want.items() if v != 0)
        got = dict((i, K.Q(e.text.replace(MINUS, "-")))
                   for i, e in printed[a].items())
        if got != want_nz:
            rep.fail("AX_NUMBERS_AS_DECLARED", "axis:" + a, "printed %s, "
                     "public %s" % (sorted((i, K.cstr(v)) for i, v in
                                           got.items()),
                                    sorted((i, K.cstr(v)) for i, v in
                                           want_nz.items())))
        vals = [(i, float(K.Q(e.text.replace(MINUS, "-"))))
                for i, e in printed[a].items() if e.text != "0"]
        if len(vals) >= 2:
            f = _fit(vals)
            if f and (abs(f[1] - pa[n]["step"]) > 1e-9 or f[2] > 1e-9):
                rep.fail("SCALE_PER_AXIS_MEASURED", "axis:" + a, "the "
                         "printed numbers are not one step apart per "
                         "interval")
        for i, e in printed[a].items():
            b = text_box(e, D)
            c = ((b[0] + b[2]) / 2, (b[1] + b[3]) / 2)
            if a == "x":
                tick = fits["x"]["a"] + fits["x"]["b"] * i
                along = abs(c[0] - tick)
                across = min(abs(b[1] - oy), abs(b[3] - oy))
                others = [abs(c[0] - (fits["x"]["a"] + fits["x"]["b"] * j))
                          for j in range(want_n_x(pub) + 1) if j != i]
            else:
                tick = fits["y"]["a"] + fits["y"]["b"] * i
                along = abs(c[1] - tick)
                across = min(abs(b[0] - ox), abs(b[2] - ox))
                others = [abs(c[1] - (fits["y"]["a"] + fits["y"]["b"] * j))
                          for j in range(want_n_y(pub) + 1) if j != i]
            if along > NUM_ALONG_STEP * abs(fits[a]["b"]) + 0.3 or \
                    (others and min(others) <= along) or \
                    across > NUM_ACROSS_PX:
                rep.fail("AX_NUMBERS_OWNED", e.id, "number %s is %.1f px "
                         "along / %.1f px across from its tick" % (
                             e.text, along, across))
    # a '0' at the origin only when a public label prints 0
    zero_public = any(K.Q(v) == 0 for ax_ in pub["frame"]["axes"]
                      for _i, v in ax_["labels"])
    if origin and not zero_public:
        rep.fail("AX_NUMBERS_AS_DECLARED", origin[0].id, "a '0' no public "
                 "label prints")
    if zero_public and not origin:
        rep.fail("AX_NUMBERS_AS_DECLARED", None, "the public '0' is not "
                 "printed")

    # ---------------------------------------------------------- curves
    pcurves = dict((c["id"], c) for c in pub["curves"])
    win = (pa[0]["step"] * (0 - pa[0]["zero"]),
           pa[0]["step"] * (want_n_x(pub) - pa[0]["zero"]),
           pa[1]["step"] * (0 - pa[1]["zero"]),
           pa[1]["step"] * (want_n_y(pub) - pa[1]["zero"]))
    cel = {}
    for e in by.get("data-curve", []):
        cel.setdefault(e.val, []).append(e)
    known_def = {}
    samples_px = {}
    for cid in sorted(set(pcurves) | set(cel)):
        c = pcurves.get(cid)
        es = cel.get(cid, [])
        rep.ran("CURVE_ONE_UNCUT_PATH")
        rep.ran("CURVE_STYLE_AS_DECLARED")
        rep.ran("CURVE_EXTENT_AS_DECLARED")
        if c is None:
            rep.fail("OBJMAP_TOTAL_NO_UNMAPPED_INK", cid, "a curve the public "
                     "model does not have")
            continue
        if len(es) != 1:
            rep.fail("CURVE_ONE_UNCUT_PATH", cid, "%d elements (one uncut "
                     "element each)" % len(es))
            if not es:
                continue
        e = es[0]
        if c["fn"] == "parabola" and e.tag != "path" or \
                c["fn"] != "parabola" and e.tag != "line":
            rep.fail("CURVE_ONE_UNCUT_PATH", cid, "a %s drawn as <%s>" % (
                c["fn"], e.tag))
            continue
        dash = e.a.get("stroke-dasharray")
        if (c["style"] == "dashed") != (dash is not None):
            rep.fail("CURVE_STYLE_AS_DECLARED", cid, "style %s, dasharray %r"
                     % (c["style"], dash))
        elif dash:
            on, off = [float(v) for v in dash.split(" ")]
            if off < DASH_MIN_GAP_STEP * spx or 5 * spx / (on + off) < 3:
                rep.fail("CURVE_STYLE_AS_DECLARED", cid, "dashes %s too "
                         "sparse / gaps too small" % dash)
        pxs = _px_samples(e, 160)
        samples_px[cid] = pxs
        data = [M.to_data(*p) for p in pxs]
        d = c.get("def")
        ext = [float(K.Q(v)) for v in c["extent"]] if c.get("extent") \
            else None
        chk = "PARABOLA_EXACT" if c["fn"] == "parabola" else \
            "LINE_EQUATION_EXACT"
        rep.ran(chk)
        # the window: no sample past it by more than TOL_POS
        for x, y in data:
            if x < win[0] - TOL_POS * sx or x > win[1] + TOL_POS * sx or \
                    y < win[2] - TOL_POS * sy or y > win[3] + TOL_POS * sy:
                rep.fail("CURVE_EXTENT_AS_DECLARED", cid, "a sample at "
                         "(%.2f, %.2f) outside the window" % (x, y))
                break
        meas = _measure_curve(c["fn"], data, e, M)
        rep.measured["curves"][cid] = meas
        if c["fn"] == "parabola" and meas.get("a") is not None and \
                abs(meas["a"] - 1.0) > 0.05:
            rep.fail("PARABOLA_EXACT", cid, "leading coefficient %.3f, not 1"
                     % meas["a"])
        if d is None:
            continue
        known_def[cid] = d
        worst = max(_dist_curve(d, x, y, sx, sy) for x, y in data)
        if worst > TOL_POS:
            rep.fail(chk, cid, "a sample %.3f step off %s" % (worst, d))
        if c["fn"] == "parabola":
            lowest = min(data, key=lambda p: p[1])
            p, k = float(K.Q(d["p"])), float(K.Q(d["k"]))
            if math.hypot((lowest[0] - p) / sx, (lowest[1] - k) / sy) > \
                    TOL_POS and win[0] <= p <= win[1]:
                rep.fail("PARABOLA_EXACT", cid, "the lowest point (%.2f, "
                         "%.2f) is not the vertex" % lowest)
        rng = _drawn_range(d, win, ext)
        if c["fn"] == "vline":
            got = (min(y for _x, y in data), max(y for _x, y in data))
            tol = TOL_EXTENT * sy
        else:
            got = (min(x for x, _y in data), max(x for x, _y in data))
            tol = TOL_EXTENT * sx
        if abs(got[0] - rng[0]) > tol or abs(got[1] - rng[1]) > tol:
            rep.fail("CURVE_EXTENT_AS_DECLARED", cid, "drawn %.2f..%.2f, "
                     "want %.2f..%.2f" % (got + rng))
    # parallel pairs (stated)
    for a, b in pub.get("parallel") or []:
        rep.ran("PARALLEL_MEASURED")
        ma, mb = rep.measured["curves"].get(a, {}), \
            rep.measured["curves"].get(b, {})
        if "m" in ma and "m" in mb and abs(ma["m"] - mb["m"]) > 0.02:
            rep.fail("PARALLEL_MEASURED", a, "slopes %.3f / %.3f" % (
                ma["m"], mb["m"]))
    # crossings of drawn curves (px)
    crossings = []
    ids = sorted(samples_px)
    for i, a in enumerate(ids):
        for b in ids[i + 1:]:
            crossings += _poly_cross(samples_px[a], samples_px[b])

    # ----------------------------------------------------------- marks
    pmarks = dict((m["id"], m) for m in pub["marks"])
    dots = {}
    for e in by.get("data-pt", []):
        if e.val in dots:
            rep.fail("MARKS_AT_COORDS", e.val, "two dots")
        dots[e.val] = (_f(e.a["cx"]), _f(e.a["cy"]))
    rep.ran("MARKS_AT_COORDS")
    rep.ran("MARK_KIND_EXACT")
    for mid in sorted(set(pmarks) | set(dots)):
        m = pmarks.get(mid)
        if m is None:
            rep.fail("MARKS_AT_COORDS", mid, "a dot the public model does "
                     "not have")
            continue
        if mid not in dots:
            rep.fail("MARKS_AT_COORDS", mid, "the mark is not drawn")
            continue
        x, y = M.to_data(*dots[mid])
        rep.measured["marks"][mid] = [round(x, 4), round(y, 4)]
        if m.get("xy"):
            px, py = [float(K.Q(v)) for v in m["xy"]]
            if math.hypot((x - px) / sx, (y - py) / sy) > TOL_POS:
                rep.fail("MARKS_AT_COORDS", mid, "dot at (%.2f, %.2f), public "
                         "(%s, %s)" % (x, y, m["xy"][0], m["xy"][1]))
        for cid in m["on"]:
            d = known_def.get(cid)
            if d is not None and _dist_curve(d, x, y, sx, sy) > TOL_POS:
                rep.fail("MARKS_AT_COORDS", mid, "not on %s" % cid)
            elif cid in samples_px:
                # on the DRAWN curve (measured; a hidden def too)
                data = [M.to_data(*p) for p in samples_px[cid]]
                dd = min(_pt_seg(((x / sx), (y / sy)),
                                 (a[0] / sx, a[1] / sy),
                                 (b[0] / sx, b[1] / sy))
                         for a, b in zip(data[:-1], data[1:]))
                if dd > TOL_POS:
                    rep.fail("MARKS_AT_COORDS", mid, "%.3f step off the "
                             "drawn %s" % (dd, cid))
        _mark_kind(rep, m, x, y, known_def, sx, sy)
        if m["kind"] == "intersection":
            rep.ran("INTERSECTION_MARK_EXACT")
            for cid in m["on"]:
                if cid not in samples_px:
                    rep.fail("INTERSECTION_MARK_EXACT", mid, "%s is not "
                             "drawn" % cid)
                    continue
                data = [M.to_data(*p) for p in samples_px[cid]]
                dd = min(_pt_seg((x / sx, y / sy), (a[0] / sx, a[1] / sy),
                                 (b[0] / sx, b[1] / sy))
                         for a, b in zip(data[:-1], data[1:]))
                if dd > TOL_POS:
                    rep.fail("INTERSECTION_MARK_EXACT", mid, "%.3f step off "
                             "the drawn %s" % (dd, cid))
            if len(m["on"]) != 2:
                rep.fail("INTERSECTION_MARK_EXACT", mid, "not on two curves")
        if m.get("optional"):
            rep.ran("OPTIONAL_DATUM_EXACT")
            if m.get("xy"):
                px_, py_ = [float(K.Q(v)) for v in m["xy"]]
                if math.hypot((x - px_) / sx, (y - py_) / sy) > TOL_POS:
                    rep.fail("OPTIONAL_DATUM_EXACT", mid, "the optional "
                             "point is not at its printed coordinates")
            else:
                rep.fail("OPTIONAL_DATUM_EXACT", mid, "an optional datum "
                         "with no public coordinates")
            # (round 2) an optional datum's label: its printed coordinates,
            # a point name or both (the corpus AAF1 label forms); the name
            # grammar is the public scan's, the text LABEL_TEXT_AS_DECLARED
            lab = m.get("label")
            if lab and not (lab.get("coords") or lab.get("name")):
                rep.fail("OPTIONAL_DATUM_EXACT", mid, "an optional point's "
                         "label is its coordinates or its name")
        if m["kind"] == "vertex" and m["on"] and \
                m["on"][0] not in known_def:
            mc = rep.measured["curves"].get(m["on"][0]) or {}
            if mc.get("p") is not None and math.hypot(
                    (x - mc["p"]) / sx, (y - mc["k"]) / sy) > TOL_POS:
                rep.fail("MARK_KIND_EXACT", mid, "not at the drawn "
                         "parabola's vertex (%.2f, %.2f)" % (mc["p"],
                                                            mc["k"]))

    # ---------------------------------------------------------- labels
    texts = [e for e in els if e.tag == "text"]
    boxes = dict((e.id, text_box(e, D)) for e in texts)
    rep.ran("TEXT_MIN_SIZE")
    rep.ran("TEXT_BOX_IN_CANVAS")
    rep.ran("TEXT_NOT_COVERING_MARKS")
    rep.ran("ANGLE_NAMES_THREE_LETTERS")
    rep.ran("LABEL_TEXT_AS_DECLARED")
    rep.ran("AXIS_NAMES_AS_DECLARED")
    for e in texts:
        if _f(e.a["font-size"]) < D["min_font_px"] - 1e-9:
            rep.fail("TEXT_MIN_SIZE", e.id, "font-size %s" % e.a["font-size"])
        b = boxes[e.id]
        if b[0] < -0.01 or b[1] < -0.01 or b[2] > W + 0.01 or \
                b[3] > H + 0.01:
            rep.fail("TEXT_BOX_IN_CANVAS", e.id, "%r runs past the canvas"
                     % e.text)
        logical = e.text
        heb = bool(re.search(u"[א-ת]", e.text))
        if heb:
            if e.hook != "data-axtitle" or e.a.get("direction") != "ltr" or \
                    e.a.get("unicode-bidi") != "bidi-override":
                rep.fail("AXIS_NAMES_AS_DECLARED", e.id, "a Hebrew text "
                         "without the visual-order override")
            logical = _logical(e.text)
        elif e.a.get("direction") or e.a.get("unicode-bidi"):
            rep.fail("DIALECT_CLOSED", e.id, "bidi attributes on a text "
                     "without a Hebrew letter")
        for bad in K._angle_names(logical):
            rep.fail("ANGLE_NAMES_THREE_LETTERS", e.id, bad)
    # covering
    strokes, cstrokes = [], []
    for e in els:
        if e.hook in ("data-axis", "data-tick", "data-guide"):
            strokes.append(((_f(e.a["x1"]), _f(e.a["y1"])),
                            (_f(e.a["x2"]), _f(e.a["y2"])), e.id))
        elif e.hook == "data-arrow":
            pts = [tuple(float(v) for v in p.split(","))
                   for p in e.a["points"].split(" ")]
            for i in range(len(pts)):
                strokes.append((pts[i], pts[(i + 1) % len(pts)], e.id))
        elif e.hook == "data-curve":
            s = samples_px.get(e.val) or _px_samples(e, 160)
            for p, q in zip(s[:-1], s[1:]):
                cstrokes.append((p, q, e.val))
    for e in texts:
        b = _shrink(boxes[e.id], COVER_SHRINK_PX)
        for p, q, who in strokes + cstrokes:
            if _seg_hits_box(p, q, b):
                rep.fail("TEXT_NOT_COVERING_MARKS", e.id, "%r is crossed by "
                         "%s" % (e.text, who), code="CHK_TEXT_CROSSED")
                break
        for mid, c in dots.items():
            if _box_pt(b, c) < _f(D["hooks"]["data-pt"]["r"][0]):
                rep.fail("TEXT_NOT_COVERING_MARKS", e.id, "%r covers the dot "
                         "%s" % (e.text, mid))
        for o in texts:
            if o.id < e.id and _overlap(b, _shrink(boxes[o.id],
                                                   COVER_SHRINK_PX)):
                rep.fail("TEXT_NOT_COVERING_MARKS", e.id, "%r overlaps %r" % (
                    e.text, o.text))
    # axis names / titles
    for a in ("x", "y"):
        spec = pub["axes"][a]
        names = [e for e in by.get("data-axname", []) if e.val == a]
        titles = [e for e in by.get("data-axtitle", []) if e.val == a]
        if spec["letter"] != bool(names) or len(names) > 1 or (
                names and names[0].text != a):
            rep.fail("AXIS_NAMES_AS_DECLARED", "axis:" + a, "the letter")
        if (spec["title"] is None) != (not titles) or len(titles) > 1 or (
                titles and _logical(titles[0].text) != spec["title"]):
            rep.fail("AXIS_NAMES_AS_DECLARED", "axis:" + a, "the title %r"
                     % (_logical(titles[0].text) if titles else None))
        for e in names:
            tip = _arrow_tip(arrows.get(a), a)
            if tip and _box_pt(boxes[e.id], tip) > 14:
                rep.fail("AXIS_NAMES_AS_DECLARED", e.id, "the letter is not at "
                         "the arrow")
    for a in ("x", "y"):
        if pub["axes"][a]["title"] is not None:
            rep.ran("AXIS_UNIT_IF_ANY")
            ts = [e for e in by.get("data-axtitle", []) if e.val == a]
            if len(ts) != 1 or _logical(ts[0].text) != pub["axes"][a]["title"]:
                rep.fail("AXIS_UNIT_IF_ANY", "axis:" + a, "the axis text is "
                         "not the public one")
    # curve labels
    rep.ran("CURVE_LABEL_OWNED")
    rep.ran("MARK_LABEL_OWNED")
    flabels = dict((e.val, e) for e in by.get("data-for", []))
    for cid, c in sorted(pcurves.items()):
        lab = c.get("label")
        e = flabels.get(cid)
        if (lab is None) != (e is None):
            rep.fail("LABEL_TEXT_AS_DECLARED", cid, "label %r, public %r" % (
                e.text if e else None, lab))
            continue
        if e is None:
            continue
        want = lab["name"] if "name" in lab else lab["text"]
        if e.text != want:
            rep.fail("LABEL_TEXT_AS_DECLARED", cid, "prints %r, public %r"
                     % (e.text, want))
        if "equation" in lab and c.get("def") and not text_is_curve(
                e.text, c["def"]):
            rep.fail("LABEL_TEXT_AS_DECLARED", cid, "the equation %r is not "
                     "the curve drawn" % e.text)
        if cid not in samples_px:
            continue
        b = boxes[e.id]
        d0 = min(_box_seg(b, p, q) for p, q in
                 zip(samples_px[cid][:-1], samples_px[cid][1:]))
        rep.measured["labels"][cid] = round(d0, 2)
        if d0 > LABEL_NEAR_PX:
            rep.fail("CURVE_LABEL_OWNED", cid, "the label is %.1f px from its "
                     "curve" % d0)
        for o, s in samples_px.items():
            if o == cid:
                continue
            do = min(_box_seg(b, p, q) for p, q in zip(s[:-1], s[1:]))
            if do < d0 + OWN_STEP * spx:
                rep.fail("CURVE_LABEL_OWNED", cid, "the label is as near %s "
                         "(%.1f px) as its own curve (%.1f px)" % (o, do, d0))
        for x in crossings:
            if _box_pt(b, x) < CROSS_STEP * spx:
                rep.fail("CURVE_LABEL_OWNED", cid, "the label is within 0.5 "
                         "step of a crossing")
                break
    for mid, m in sorted(pmarks.items()):
        lab = m.get("label")
        e = flabels.get(mid)
        if (lab is None) != (e is None):
            rep.fail("LABEL_TEXT_AS_DECLARED", mid, "label %r, public %r" % (
                e.text if e else None, lab))
            continue
        if e is None or mid not in dots:
            continue
        if e.text != lab["text"]:
            rep.fail("LABEL_TEXT_AS_DECLARED", mid, "prints %r, public %r"
                     % (e.text, lab["text"]))
        if lab.get("coords"):
            xy = _coords_of(e.text)
            mx, my = M.to_data(*dots[mid])
            if xy is None or math.hypot((xy[0] - mx) / sx,
                                        (xy[1] - my) / sy) > TOL_POS:
                rep.fail("LABEL_TEXT_AS_DECLARED", mid, "%r is not where the "
                         "dot is (%.2f, %.2f)" % (e.text, mx, my))
        b = boxes[e.id]
        d0 = _box_pt(b, dots[mid])
        if d0 > LABEL_NEAR_PX or any(
                _box_pt(b, c) < d0 + MARK_OWN_PX
                for o, c in dots.items() if o != mid):
            rep.fail("MARK_LABEL_OWNED", mid, "the label is not nearest its "
                     "own dot")
    for key, e in flabels.items():
        if key not in pcurves and key not in pmarks:
            rep.fail("LABEL_TEXT_AS_DECLARED", e.id, "a label for %r" % key)
    # (round 2) a givens-only figure prints NAMES only: measured on the
    # printed label texts, never trusted from the public model
    if pub.get("givens") is True:
        rep.ran("GIVENS_NAMES_ONLY")
        for e in texts:
            if e.hook != "data-for":
                continue
            key = e.val
            rx = K.GIVEN_POINT_NAME_RE if str(key).startswith("mark:") \
                else K.GIVEN_CURVE_NAME_RE
            if not rx.match(e.text or ""):
                # (v6.16 fix r1, verify P2-M1) a drawn given's OWN equation
                # (its numbers public: the text prints it, stated_in) may
                # label it -- measured: the printed text must BE the curve
                # the public model declares, in any equation form
                pc = None if str(key).startswith("mark:") else \
                    pcurves.get(key)
                if pc and pc.get("def") and \
                        "equation" in (pc.get("label") or {}):
                    try:
                        own = K.same_curve_as_text(K.Curve.from_def(
                            pc["def"]), e.text or "")
                    except Exception:            # noqa: BLE001
                        own = False
                    if own:
                        continue
                rep.fail("GIVENS_NAMES_ONLY", e.id, "%r labels %s in a "
                         "givens-only figure: a bare name only" % (e.text,
                                                                   key))

    # ---------------------------------------------------------- guides
    rep.ran("GUIDES_ONLY_IF_STATED")
    for e in by.get("data-guide", []):
        mid, a = e.val.split(" ")
        m = pmarks.get(mid)
        if m is None or a not in m["guides"]:
            rep.fail("GUIDES_ONLY_IF_STATED", e.id, "a guide %s no stated "
                     "given draws" % e.val)
            continue
        if mid in dots:
            p = (_f(e.a["x1"]), _f(e.a["y1"]))
            q = (_f(e.a["x2"]), _f(e.a["y2"]))
            c = dots[mid]
            end = (c[0], oy) if a == "x" else (ox, c[1])
            if min(math.hypot(p[0] - c[0], p[1] - c[1]),
                   math.hypot(q[0] - c[0], q[1] - c[1])) > 0.5 or \
                    min(math.hypot(p[0] - end[0], p[1] - end[1]),
                        math.hypot(q[0] - end[0], q[1] - end[1])) > 0.5:
                rep.fail("GUIDES_ONLY_IF_STATED", e.id, "the guide does not "
                         "run from its dot to the %s axis" % a)
    for m in pub["marks"]:
        for a in m["guides"]:
            if not any(e.val == "%s %s" % (m["id"], a)
                       for e in by.get("data-guide", [])):
                rep.fail("GUIDES_ONLY_IF_STATED", m["id"], "the stated guide "
                         "to %s is missing" % a)

    # ----------------------------------------------------------- guard
    rep.ran("TARGET_NOT_DRAWN")
    if answer_guard:
        _guard(rep, answer_guard, dots, M, sx, sy, samples_px, texts,
               flabels, printed)

    # ------------------------------------------------------------- map
    _check_map(rep, els, object_map, pub, by)
    return rep.result()


def want_n_x(pub):
    return pub["frame"]["axes"][0]["intervals"]


def want_n_y(pub):
    return pub["frame"]["axes"][1]["intervals"]


def _logical(stored):
    mir = {"(": ")", ")": "("}
    return "".join(mir.get(c, c) for c in reversed(stored))


def _arrow_tip(e, a):
    if e is None:
        return None
    pts = [tuple(float(v) for v in p.split(","))
           for p in e.a["points"].split(" ")]
    return max(pts, key=lambda p: p[0]) if a == "x" else \
        min(pts, key=lambda p: p[1])


def _measure_curve(fn, data, e, M):
    if fn == "vline":
        return {"fn": "vline", "x": round(sum(x for x, _y in data) /
                                          len(data), 4)}
    if fn == "line":
        (x0, y0), (x1, y1) = data[0], data[-1]
        if abs(x1 - x0) < 1e-9:
            return {"fn": "line", "m": None, "b": None}
        m = (y1 - y0) / (x1 - x0)
        return {"fn": "line", "m": round(m, 4), "b": round(y0 - m * x0, 4)}
    f = _fit_parabola(data)
    if f is None:
        return {"fn": "parabola", "a": None, "p": None, "k": None}
    return {"fn": "parabola", "a": round(f[0], 4), "p": round(f[1], 4),
            "k": round(f[2], 4)}


def _mark_kind(rep, m, x, y, known, sx, sy):
    kind = m["kind"]
    on = m["on"]
    if kind == "vertex":
        d = known.get(on[0]) if on else None
        if d is not None and d["fn"] == "parabola" and math.hypot(
                (x - float(K.Q(d["p"]))) / sx,
                (y - float(K.Q(d["k"]))) / sy) > TOL_POS:
            rep.fail("MARK_KIND_EXACT", m["id"], "not at the vertex")
    elif kind == "zero":
        if abs(y) / sy > TOL_POS:
            rep.fail("MARK_KIND_EXACT", m["id"], "a zero off the x axis")
    elif kind == "y_intercept":
        if abs(x) / sx > TOL_POS:
            rep.fail("MARK_KIND_EXACT", m["id"], "a y-intercept off the y "
                     "axis")
    elif kind == "intersection" and len(on) != 2:
        rep.fail("MARK_KIND_EXACT", m["id"], "an intersection of %d curves"
                 % len(on))


def _poly_cross(a, b):
    out = []
    for p1, q1 in zip(a[:-1], a[1:]):
        for p2, q2 in zip(b[:-1], b[1:]):
            d = (q1[0] - p1[0]) * (q2[1] - p2[1]) - \
                (q1[1] - p1[1]) * (q2[0] - p2[0])
            if abs(d) < 1e-12:
                continue
            t = ((p2[0] - p1[0]) * (q2[1] - p2[1]) -
                 (p2[1] - p1[1]) * (q2[0] - p2[0])) / d
            u = ((p2[0] - p1[0]) * (q1[1] - p1[1]) -
                 (p2[1] - p1[1]) * (q1[0] - p1[0])) / d
            if 0 <= t <= 1 and 0 <= u <= 1:
                out.append((p1[0] + t * (q1[0] - p1[0]),
                            p1[1] + t * (q1[1] - p1[1])))
    # tangency (a double root) shows no sign change: the nearest approach
    if not out:
        best = None
        for p in a:
            for q in b:
                dd = math.hypot(p[0] - q[0], p[1] - q[1])
                if best is None or dd < best[0]:
                    best = (dd, ((p[0] + q[0]) / 2, (p[1] + q[1]) / 2))
        if best and best[0] < 0.75:
            out.append(best[1])
    return out


def _guard(rep, g, dots, M, sx, sy, samples_px, texts, flabels, printed):
    for x, y in g.get("points") or []:
        fx, fy = float(K.Q(x)), float(K.Q(y))
        for mid, c in dots.items():
            mx, my = M.to_data(*c)
            if math.hypot((mx - fx) / sx, (my - fy) / sy) < 0.25:
                rep.fail("TARGET_NOT_DRAWN", mid, "a dot at the guarded point "
                         "(%s, %s)" % (x, y), code="CHK_TARGET_DRAWN")
    for d in g.get("curves") or []:
        for cid, s in samples_px.items():
            data = [M.to_data(*p) for p in s]
            run, best = 0.0, 0.0
            prev = None
            for p in data:
                ok = _dist_curve(d, p[0], p[1], sx, sy) <= TOL_POS
                if ok and prev is not None:
                    run += math.hypot((p[0] - prev[0]) / sx,
                                      (p[1] - prev[1]) / sy)
                elif not ok:
                    run = 0.0
                prev = p if ok else None
                best = max(best, run)
            if best >= 1.0:
                rep.fail("TARGET_NOT_DRAWN", cid, "a stroke of the guarded "
                         "curve %s" % d, code="CHK_TARGET_DRAWN")
    owned_nums = set(e.id for a in printed for e in printed[a].values())
    for e in texts:
        t = _logical(e.text) if re.search(u"[א-ת]", e.text) \
            else e.text
        if e.id in owned_nums or e.hook == "data-num":
            continue
        for ft in g.get("texts") or []:
            if K._tok_contains(t, ft):
                rep.fail("TARGET_NOT_DRAWN", e.id, "%r states the guarded %r"
                         % (t, ft), code="CHK_TARGET_DRAWN")
        for fb in g.get("bare") or []:
            if re.sub(r"\s+", "", t) == re.sub(r"\s+", "", fb):
                rep.fail("TARGET_NOT_DRAWN", e.id, "%r is a guarded answer"
                         % t, code="CHK_TARGET_DRAWN")
        for d in g.get("equations") or []:
            if (t.startswith("y") or t.startswith("x")) and \
                    text_is_curve(t, d):
                rep.fail("TARGET_NOT_DRAWN", e.id, "%r is the guarded "
                         "equation %s" % (t, d), code="CHK_TARGET_DRAWN")


def _check_map(rep, els, om, pub, by):
    chk = "OBJMAP_TOTAL_NO_UNMAPPED_INK"
    rep.ran(chk)
    if om is None:
        rep.review(chk, None, "no object map")
        return
    if set(om) != MAP_TOP:
        rep.fail(chk, None, "map keys %s" % sorted(set(om) ^ MAP_TOP))
        return
    if om.get("figure") != pub["figure"] or \
            om.get("public_hash") != pub["public_hash"]:
        rep.fail(chk, None, "the map is of another figure / model")
    byid = dict((e.id, e) for e in els)
    if sorted(om["elements"]) != sorted(byid):
        rep.fail(chk, None, "map elements %d vs file %d" % (
            len(om["elements"]), len(byid)))
    owner = {}
    for it in om["display_items"]:
        role = it.get("role")
        if role not in ROLE_HOOK:
            rep.fail(chk, it.get("id"), "role %r" % role)
            continue
        src = (it.get("source") or {}).get("entity")
        for r in it.get("elements") or []:
            if r in owner:
                rep.fail(chk, r, "in two display items")
            owner[r] = it["id"]
            e = byid.get(r)
            if e is None:
                rep.fail(chk, r, "not in the file")
                continue
            if e.hook != ROLE_HOOK[role] or \
                    (role == "origin_zero") != (e.val == "origin"):
                rep.fail(chk, r, "role %s on %s=%s" % (role, e.hook, e.val))
            if role in ("mark", "mark_label", "optional_mark",
                        "optional_label"):
                pm = dict((m["id"], m) for m in pub["marks"]).get(src) or {}
                if bool(pm.get("optional")) != role.startswith("optional"):
                    rep.fail(chk, r, "role %s for %s (optional: %s)" % (
                        role, src, bool(pm.get("optional"))))
            want_src = _hook_entity(e)
            if want_src is not None and src != want_src:
                rep.fail(chk, r, "source %r, the hook says %r" % (src,
                                                                   want_src))
            if "text" in it and e.tag == "text":
                txt = _logical(e.text) if e.hook == "data-axtitle" else \
                    e.text
                if it["text"] != txt:
                    rep.fail(chk, r, "item text %r, the file %r" % (
                        it["text"], txt))
            if om["elements"].get(r, {}).get("item") != it["id"]:
                rep.fail(chk, r, "elements table disagrees")
    for r in byid:
        if r not in owner:
            rep.fail(chk, r, "unmapped ink")
    # objects = what the checker attributes by the hooks
    want = {}
    zero_x = any(K.Q(v) == 0 for _i, v in pub["frame"]["axes"][0]["labels"])
    zero_y = any(K.Q(v) == 0 for _i, v in pub["frame"]["axes"][1]["labels"])
    for e in els:
        h, v = e.hook, e.val
        if h is None:
            continue
        if h == "data-grid":
            want.setdefault("plane:xy", set()).add(e.id)
        elif h in ("data-axis", "data-arrow", "data-axname", "data-axtitle"):
            want.setdefault("axis:" + v, set()).add(e.id)
        elif h in ("data-tick",):
            want.setdefault("axis:" + v.split(" ")[0], set()).add(e.id)
        elif h == "data-num":
            if v == "origin":
                if zero_x:
                    want.setdefault("axis:x", set()).add(e.id)
                if zero_y:
                    want.setdefault("axis:y", set()).add(e.id)
            else:
                want.setdefault("axis:" + v.split(" ")[0], set()).add(e.id)
        elif h in ("data-curve", "data-pt", "data-for"):
            want.setdefault(v, set()).add(e.id)
        elif h == "data-guide":
            mid, a = v.split(" ")
            want.setdefault("guide:%s:%s" % (mid, a), set()).add(e.id)
    got = dict((o, set(p["element"] for p in rec.get("parts") or []))
               for o, rec in (om.get("objects") or {}).items())
    for o in sorted(set(want) | set(got)):
        if want.get(o, set()) != got.get(o, set()):
            rep.fail(chk, o, "object parts %s, measured %s" % (
                sorted(got.get(o, set())), sorted(want.get(o, set()))))
    finds_args = set()
    for f in pub.get("finds") or []:
        finds_args.add(f["id"])
    for o in got:
        if o in finds_args:
            rep.fail(chk, o, "a find has an object (it is never drawn)")


def _hook_entity(e):
    h, v = e.hook, e.val
    if h == "data-grid":
        return "plane:xy"
    if h in ("data-axis", "data-arrow", "data-axname", "data-axtitle"):
        return "axis:" + v
    if h in ("data-tick",):
        return "axis:" + v.split(" ")[0]
    if h == "data-num":
        return None if v == "origin" else "axis:" + v.split(" ")[0]
    if h in ("data-curve", "data-pt", "data-for"):
        return v
    if h == "data-guide":
        return v.split(" ")[0]
    return None


# ------------------------------------------------------ private side ---
def private_check(rep, private_model, sxsy=None):
    """the harness side (it holds the private model): every curve / mark
    whose numbers the public model does not carry is compared with what
    the checker MEASURED (report['measured']). Returns the findings added
    (and updates rep's status)."""
    added = []
    mc = rep["measured"]["curves"]
    for cid, d in sorted((private_model.get("curves") or {}).items()):
        m = mc.get(cid)
        if m is None:
            continue
        bad = None
        if d["fn"] == "line" and m.get("m") is not None:
            if abs(m["m"] - float(K.Q(d["m"]))) > 0.02 or \
                    abs(m["b"] - float(K.Q(d["b"]))) > 0.05:
                bad = "measured y = %sx + %s, private %s" % (m["m"], m["b"], d)
        elif d["fn"] == "vline":
            if abs(m["x"] - float(K.Q(d["x"]))) > 0.05:
                bad = "measured x = %s, private %s" % (m["x"], d)
        elif d["fn"] == "parabola" and m.get("a") is not None:
            if abs(m["a"] - 1) > 0.05 or \
                    abs(m["p"] - float(K.Q(d["p"]))) > 0.05 or \
                    abs(m["k"] - float(K.Q(d["k"]))) > 0.05:
                bad = "measured a %s p %s k %s, private %s" % (
                    m["a"], m["p"], m["k"], d)
        if bad:
            chk = "PARABOLA_EXACT" if d["fn"] == "parabola" else \
                "LINE_EQUATION_EXACT"
            f = {"level": FAIL, "code": "CHK_PRIVATE_" + chk, "check": chk,
                 "object": cid, "detail": bad}
            added.append(f)
    for mid, xy in sorted((private_model.get("marks") or {}).items()):
        m = rep["measured"]["marks"].get(mid)
        if m is None:
            continue
        if math.hypot(m[0] - float(K.Q(xy[0])), m[1] - float(K.Q(xy[1]))) \
                > 0.05:
            added.append({"level": FAIL, "code": "CHK_PRIVATE_MARK",
                          "check": "MARKS_AT_COORDS", "object": mid,
                          "detail": "measured %s, private %s" % (m, xy)})
    for f in added:
        rep["findings"].append(f)
        rep["checks"][f["check"]] = FAIL
        rep["status"] = FAIL
    return added


# --------------------------------------------------------- highlight ---
_START = re.compile(r"<svg\b[^>]*>\n")


def check_highlight(base_svg, hl_svg, object_map, object_id):
    """-> [problem]: the base figure unchanged, ONE overlay group right
    after the start tag, holding exactly one element per part of the
    object, each coinciding with its element's geometry, no text and no
    hook; the empty group for an object the figure does not draw"""
    out = []
    m = _START.search(hl_svg)
    if not m or not hl_svg[m.end():].startswith(
            '<g data-layer="highlight"'):
        return ["HL_NO_OVERLAY"]
    end = hl_svg.find("</g>\n", m.end())
    if hl_svg[:m.end()] + hl_svg[end + 5:] != base_svg:
        out.append("HL_FIGURE_CHANGED")
    grp = ET.fromstring(hl_svg[m.end():end + 4])
    if grp.get("data-object") != object_id:
        out.append("HL_WRONG_OBJECT")
    o = (object_map.get("objects") or {}).get(object_id)
    want = sorted(p["element"] for p in o["parts"]) if o else []
    root = ET.fromstring(base_svg.encode("utf-8"))
    els = dict((e.get("id"), e) for e in root.iter() if e.get("id"))
    got = []
    for c in grp:
        tag = c.tag.replace(NS, "")
        eid = c.get("data-hl")
        got.append(eid)
        if c.text or any(k.startswith("data-") and k != "data-hl"
                         for k in c.attrib):
            out.append("HL_ADDS_MATH %s" % eid)
        base = els.get(eid)
        if base is None:
            out.append("HL_EXTRA %s" % eid)
            continue
        bt = base.tag.replace(NS, "")
        same = {"line": ("x1", "y1", "x2", "y2"), "path": ("d",),
                "circle": ("cx", "cy"), "polygon": ("points",)}
        if bt == "text":
            if tag != "rect":
                out.append("HL_ADDS_MATH %s" % eid)
                continue
            D = load_dialect()
            fs = float(base.get("font-size"))
            x, y = float(base.get("x")), float(base.get("y"))
            rx, ry = float(c.get("x")), float(c.get("y"))
            rw, rh = float(c.get("width")), float(c.get("height"))
            w = text_w(base.text or "", fs, D)
            anc = base.get("text-anchor", "start")
            x0 = x - {"start": 0, "middle": w / 2, "end": w}[anc]
            box = (x0, y - D["glyph_h"] * fs, x0 + w, y)
            # the box hugs the label: it holds the glyph box, and every side
            # is within 6 px of it
            if rx > box[0] + 0.01 or ry > box[1] + 0.01 or \
                    rx + rw < box[2] - 0.01 or ry + rh < box[3] - 0.01 or \
                    box[0] - rx > 6 or box[1] - ry > 6 or \
                    rx + rw - box[2] > 6 or ry + rh - box[3] > 6 + \
                    D["descent"] * fs:
                out.append("HL_BOX_OFF %s" % eid)
        elif tag != bt or any(c.get(k) != base.get(k) for k in same[bt]):
            out.append("HL_NOT_COINCIDING %s" % eid)
    if sorted(got) != want:
        missing = sorted(set(want) - set(got))
        extra = sorted(set(got) - set(want))
        if missing:
            out.append("HL_MISSING %s" % missing)
        if extra:
            out.append("HL_EXTRA %s" % extra)
    return out


# ----------------------------------------------------------------- OCR ---
# OCR of every text of the figure from its crop of the FINAL DISPLAY (the
# SVG rasterised by MuPDF, an engine that is not the renderer), with the
# house helpers (wspec/check/ocr.py: macOS Vision; ocr_expect.py: the read
# fold, tiled reads, a signed number's minus confirmed by its ink) --
# checker infrastructure, not the renderer. The CALLER holds
# v616/OCR_RUN.lock. A text of Hebrew letters only is NOT read (Vision
# reads no Hebrew): its ink is required and a NOTE says so; its text and
# its visual order are checked on the SVG (AXIS_NAMES_AS_DECLARED).
OCR_CHECK_OF = {"data-num": "OCR_AXIS_NUMBERS", "data-axname": "OCR_AXIS_NAMES",
                "data-axtitle": "OCR_AXIS_NAMES"}
OCR_HEIGHTS = (24, 32, 40, 52)


def _fold_exp(text):
    from ..check import ocr_expect as X
    return X.fold_read(text.replace(u"\u00b2", "2"))


def _fold_read(read):
    from ..check import ocr_expect as X
    return X.fold_read(read.replace(u"\u00b2", "2"))


def _exp_variants(text, want):
    """(v6.16 fix r1) the folded forms an OCR read of `text` may take: the
    superscript '²' of an equation label ('y = x²') read as '2', or not read
    at all -- Vision drops a raised small digit (G9-T06 q9: 'y =x y =x y =x'
    of the tiled crop). G79 has already matched the PDF's own glyphs
    exactly ('y = x²', wspec_pdf._joined_run); OCR confirms the rest."""
    from ..check import ocr_expect as X
    out = [want]
    if u"\u00b2" in (text or u""):
        out.append(X.fold_read(text.replace(u"\u00b2", u"")))
    return out


def _tile_of(text):
    return 3 if len(_fold_exp(text)) <= 4 else 1


def ocr_texts(svg, rep, keep_dir=None):
    """adds OCR_AXIS_NUMBERS / OCR_AXIS_NAMES / OCR_CURVE_LABELS /
    OCR_MARK_LABELS to a check_graph report (dict). CONFIRMED -> PASS; no
    ink where the text should be -> FAIL; a different read or none ->
    REVIEW; the helper missing / failing -> REVIEW (OCR_UNAVAILABLE),
    never PASS unseen."""
    import tempfile
    from ..check import raster as RR
    from ..check import ocr as O
    from ..check import ocr_expect as X
    checks = ["OCR_AXIS_NUMBERS", "OCR_AXIS_NAMES", "OCR_CURVE_LABELS",
              "OCR_MARK_LABELS"]
    order = {NA: 0, PASS: 1, REVIEW: 2, FAIL: 3}

    def put(check, level, obj, detail, code):
        rep["findings"].append({"level": level, "code": code,
                                "check": check, "object": obj,
                                "detail": detail})
        if level == "NOTE":
            return
        if order[level] > order[rep["checks"].get(check, NA)]:
            rep["checks"][check] = level
        if level == FAIL:
            rep["status"] = FAIL
        elif level == REVIEW and rep["status"] == PASS:
            rep["status"] = REVIEW
    if not RR.available() or not O.helper_ok():
        for c in checks:
            put(c, REVIEW, None, "OCR_UNAVAILABLE: raster or OCR helper "
                "missing", "CHK_OCR_UNAVAILABLE")
        return rep
    root = ET.fromstring(svg.encode("utf-8"))
    W, H = float(root.get("width")), float(root.get("height"))
    texts = [c for g in root for c in g if c.tag.replace(NS, "") == "text"]
    disp = RR.Display(svg, W, H)
    boxes = disp.text_boxes([c.get("id") for c in texts])
    tmp = keep_dir or tempfile.mkdtemp(prefix="wspec_graph_ocr_")
    jobs, meta, crops = {}, {}, {}
    for c in texts:
        ref = c.get("id")
        hook = [h for h in ("data-num", "data-axname", "data-axtitle",
                            "data-for") if c.get(h) is not None][0]
        chk = OCR_CHECK_OF.get(hook) or (
            "OCR_CURVE_LABELS" if c.get("data-for", "").startswith("curve:")
            else "OCR_MARK_LABELS")
        text = _logical(c.text or "") if hook == "data-axtitle" else \
            (c.text or "")
        if rep["checks"].get(chk, NA) == NA:
            rep["checks"][chk] = PASS
        box = boxes.get(ref)
        crop = disp.crop(box) if box else None
        if crop is None or crop.ink_count() == 0:
            put(chk, FAIL, ref, "%r: no ink where the text should be"
                % text, "CHK_OCR_MISSING")
            continue
        want = _fold_exp(text)
        if not re.sub(u"[\u05d0-\u05ea\u05f3\u05f4()\u20aa\u05be]", "",
                      want):
            put(chk, "NOTE", ref, "NOT_OCR: %r is Hebrew only (the OCR "
                "helper reads no Hebrew); its ink is present, its text and "
                "visual order are checked on the SVG" % text,
                "CHK_OCR_NOT_OCR")
            continue
        crops[ref] = (crop, c)
        tiles = [_tile_of(text)] + ([5] if len(want) == 1 else [])
        meta[ref] = [chk, text, want, []]
        for tile in tiles:
            for k, h in enumerate(OCR_HEIGHTS):
                img = O.prepare(crop, h, tile)
                if img is None:
                    continue
                path = os.path.join(tmp, "%s_%d_%d.png" % (ref, tile, k))
                with open(path, "wb") as fh:
                    fh.write(img.png())
                jobs[path] = (ref, tile)
    errs = {}
    reads = O.run_helper(sorted(jobs)) if jobs else {}
    errs.update(getattr(reads, "errors", None) or {})

    def good(ref, s_, tile):
        r_ = _fold_read(s_)
        return any(X.tiled_read(w_, r_, tile) is not None
                   for w_ in _exp_variants(meta[ref][1], meta[ref][2]))
    confirmed = set()
    for path, (ref, tile) in sorted(jobs.items()):
        for s_, conf, kind in reads.get(path, []):
            if kind != "top" or conf < O.T.OCR_MIN_CONF:
                continue
            meta[ref][3].append(s_)
            if good(ref, s_, tile):
                confirmed.add(ref)
    # a signed number Vision did not read whole: the minus by its ink, the
    # digits read alone (ocr_expect.split_signed)
    jobs2 = {}
    for ref, (chk, text, want, rs) in meta.items():
        if ref in confirmed or not text.startswith(MINUS) or len(text) < 2:
            continue
        try:
            ok, dig = X.split_signed(crops[ref][0])
        except Exception:                               # noqa: BLE001
            ok, dig = False, None
        if not ok or dig is None:
            continue
        w2 = _fold_exp(text[1:])
        tile = _tile_of(text[1:])
        for k, h in enumerate(OCR_HEIGHTS):
            img = O.prepare(dig, h, tile)
            if img is None:
                continue
            path = os.path.join(tmp, "%s_d%d_%d.png" % (ref, tile, k))
            with open(path, "wb") as fh:
                fh.write(img.png())
            jobs2[path] = (ref, tile, w2)
    if jobs2:
        r2 = O.run_helper(sorted(jobs2))
        errs.update(getattr(r2, "errors", None) or {})
        for path, (ref, tile, w2) in sorted(jobs2.items()):
            for s_, conf, kind in r2.get(path, []):
                if kind == "top" and conf >= O.T.OCR_MIN_CONF and \
                        X.tiled_read(w2, _fold_read(s_), tile) == "exact":
                    confirmed.add(ref)
                    meta[ref][3].append("(minus by its ink) " + s_)
    # a one-letter label Vision reads as other characters (u read 'nnn', g
    # read '888'): the crop's SHAPE decides against EACH character read (up
    # to four), all rendered alone in the label's font -- confirmed only when
    # the expected letter beats every one by the margin
    for ref, (chk, text, want, rs) in sorted(meta.items()):
        if ref in confirmed or len(want) != 1 or not rs:
            continue
        import collections
        cnt = collections.Counter(ch for x in rs for ch in _fold_read(x)
                                  if ch.isalnum() and ch != want)
        rivals = [ch for ch, _n in sorted(cnt.items(),
                                          key=lambda t: (-t[1], t[0]))][:4]
        if not rivals:
            continue
        vs = [(r_, _shape_decide(crops[ref][0], want, r_, crops[ref][1],
                                 disp)) for r_ in rivals]
        meta[ref][3].append("(shape vs %s)" % ", ".join(
            "%s: %s" % v_ for v_ in vs))
        if all(v_ == "expected" for _r, v_ in vs):
            confirmed.add(ref)
    rep.setdefault("measured", {})["ocr"] = {}
    for ref, (chk, text, want, rs) in sorted(meta.items()):
        rep["measured"]["ocr"][ref] = {"text": text, "reads": rs,
                                       "status": "CONFIRMED" if ref in
                                       confirmed else None}
        if ref in confirmed:
            continue
        mine = [p for p, v in list(jobs.items()) + list(jobs2.items())
                if v[0] == ref]
        if any(p in errs for p in mine) and not rs:
            put(chk, REVIEW, ref, "OCR_UNAVAILABLE for %r" % text,
                "CHK_OCR_UNAVAILABLE")
        elif rs:
            put(chk, REVIEW, ref, "%r read as %s" % (text, sorted(set(rs))),
                "CHK_OCR_CONTRADICTS")
        else:
            put(chk, REVIEW, ref, "%r: ink present, nothing read" % text,
                "CHK_OCR_UNREAD")
    if keep_dir is None:
        for p in list(jobs) + list(jobs2):
            try:
                os.remove(p)
            except OSError:
                pass
        try:
            os.rmdir(tmp)
        except OSError:
            pass
    return rep


SHAPE_MARGIN = 0.08


def _ink_rows(g):
    b = g.binarise()
    bb = b.ink_bbox()
    if bb is None:
        return None
    return b.crop(bb)


def _agree(a, b):
    """share of agreeing pixels of two binary Grays, b scaled to a's size"""
    if a is None or b is None or a.w < 2 or a.h < 2:
        return 0.0
    k = float(a.h) / max(1, b.h)
    bs = b.scaled(k)
    W = min(a.w, bs.w)
    if W < 2 or abs(a.w - bs.w) > 0.35 * max(a.w, bs.w):
        return 0.0
    same = tot = 0
    for y in range(min(a.h, bs.h)):
        ra, rb = a.rows[y], bs.rows[y]
        for x in range(W):
            tot += 1
            same += (ra[x] < 128) == (rb[x] < 128)
    return same / float(tot) if tot else 0.0


def _shape_decide(crop, want, rival, el, disp):
    """'expected' | 'rival' | None: the crop against `want` and `rival`
    rendered alone (ocr_expect.text_renderer: MuPDF, the label's font)"""
    from ..check import ocr_expect as X
    try:
        render = X.text_renderer(dict(el.attrib), disp.scale)
        if render is None:
            return None
        c = _ink_rows(crop)
        sw = _agree(c, _ink_rows(render(want)))
        sr = _agree(c, _ink_rows(render(rival)))
    except Exception:                                   # noqa: BLE001
        return None
    if sw - sr >= SHAPE_MARGIN:
        return "expected"
    if sr - sw >= SHAPE_MARGIN:
        return "rival"
    return None
