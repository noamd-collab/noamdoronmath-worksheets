# -*- coding: utf-8 -*-
"""wspec.graph.highlight -- highlight(svg, object_map, object_id) -> the
SAME graph figure with an emphasis overlay under it (as wspec.render
.highlight: the figure's bytes are kept, one group

    <g data-layer="highlight" data-object="<object id>"> ... </g>

is inserted right after the <svg> start tag, so it is painted UNDER the
figure). One overlay element per PART of the object, nothing else:
  a curve's <line>   -> a copy, thick, data-hl="<element id>"
  a curve's <path>   -> a copy of its d=, thick, unfilled
  a mark's <circle>  -> a disk at the same centre
  a <text>           -> a box behind its glyph box
  a grid / axis line -> a copy; an arrowhead -> a copy of its outline
No text, no hook, no value, no new geometry. An object the figure does not
draw (a find: a point / curve the student must find or plot) has NO parts:
highlight() returns the figure unchanged with an EMPTY group (the empty
set), never a drawing of the answer.

verify_highlight(svg, hl_svg, object_map, object_id) -> [problem]: the
figure unchanged, the overlay exactly the object's parts, each coinciding
with its element (the independent checker re-does this: check.py)."""
import re
import xml.etree.ElementTree as ET

HL = "#f59f00"
HL_SOFT = "#ffe8a3"
HL_W = "6"
LABEL_BOX_PAD_PX = 2.0
GLYPH_W, GLYPH_H, DESC = 0.6, 0.7, 0.22
NS = "{http://www.w3.org/2000/svg}"
_START = re.compile(r"<svg\b[^>]*>\n")


class HighlightError(Exception):
    pass


def _elements(svg):
    root = ET.fromstring(svg.encode("utf-8"))
    out = {}
    for el in root.iter():
        if el.get("id"):
            out[el.get("id")] = (el.tag.replace(NS, ""), el)
    return out


_DIALECT = None


def _dialect():
    global _DIALECT
    if _DIALECT is None:
        import json
        import os
        # (v6.16 integrate) closed (see graph/render.py _DIALECT)
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                               "graph_dialect.json"), encoding="utf-8") as fh:
            _DIALECT = json.load(fh)
    return _DIALECT


def text_box(el):
    """the dialect's glyph box of a <text> (ink_w per character, glyph_h
    above the baseline, a descent for g j p q y)"""
    D = _dialect()
    fs = float(el.get("font-size"))
    x, y = float(el.get("x")), float(el.get("y"))
    t = el.text or ""
    w = fs * sum(D["ink_w"].get(c, D["glyph_w"]) for c in t)
    h = GLYPH_H * fs
    x0 = x - {"start": 0.0, "middle": w / 2, "end": w}[
        el.get("text-anchor", "start")]
    dsc = DESC * fs if any(c in "gjpqy" for c in t) else 0.0
    return (x0, y - h, x0 + w, y + dsc)


def _f(v):
    s = "%.2f" % (round(float(v), 2) + 0.0)
    return s.rstrip("0").rstrip(".") if "." in s else s


def _overlay_el(eid, els):
    if eid not in els:
        raise HighlightError("part element %s is not in the figure" % eid)
    t, el = els[eid]
    if t == "line":
        return ('<line data-hl="%s" x1="%s" y1="%s" x2="%s" y2="%s" '
                'stroke="%s" stroke-width="%s" stroke-linecap="round"/>' % (
                    eid, el.get("x1"), el.get("y1"), el.get("x2"),
                    el.get("y2"), HL, HL_W))
    if t == "path":
        return ('<path data-hl="%s" d="%s" fill="none" stroke="%s" '
                'stroke-width="%s" stroke-linecap="round"/>' % (
                    eid, el.get("d"), HL, HL_W))
    if t == "polygon":
        return ('<polygon data-hl="%s" points="%s" fill="none" stroke="%s" '
                'stroke-width="4" stroke-linejoin="round"/>' % (
                    eid, el.get("points"), HL))
    if t == "circle":
        return ('<circle data-hl="%s" cx="%s" cy="%s" r="5" fill="%s" '
                'stroke="none"/>' % (eid, el.get("cx"), el.get("cy"), HL))
    if t == "text":
        x0, y0, x1, y1 = text_box(el)
        x0, y0 = max(0.0, x0 - LABEL_BOX_PAD_PX), max(0.0,
                                                       y0 - LABEL_BOX_PAD_PX)
        x1, y1 = x1 + LABEL_BOX_PAD_PX, y1 + LABEL_BOX_PAD_PX
        return ('<rect data-hl="%s" x="%s" y="%s" width="%s" height="%s" '
                'fill="%s" stroke="none"/>' % (eid, _f(x0), _f(y0),
                                               _f(x1 - x0), _f(y1 - y0),
                                               HL_SOFT))
    raise HighlightError("cannot highlight <%s>" % t)


def parts_of(object_map, object_id):
    """the element ids of an object ([] for an object the figure does not
    draw -- a find)"""
    o = (object_map.get("objects") or {}).get(object_id)
    if o is None:
        return []
    return [p["element"] for p in o["parts"]]


def highlight(svg, object_map, object_id):
    m = _START.search(svg)
    if not m:
        raise HighlightError("no <svg> start tag")
    els = _elements(svg)
    body = [_overlay_el(e, els) for e in parts_of(object_map, object_id)]
    grp = '<g data-layer="highlight" data-object="%s">%s</g>\n' % (
        object_id.replace('"', "&quot;"), "".join(body))
    return svg[:m.end()] + grp + svg[m.end():]


def verify_highlight(svg, hl, object_map, object_id):
    out = []
    m = _START.search(hl)
    if not m:
        return ["no <svg> start tag"]
    g_end = hl.find("</g>\n", m.end())
    if not hl[m.end():].startswith('<g data-layer="highlight"') or g_end < 0:
        return ["no highlight group right after the <svg> start tag"]
    if hl[:m.end()] + hl[g_end + 5:] != svg:
        out.append("the figure changed")
    try:
        grp = ET.fromstring(hl[m.end():g_end + 4])
    except ET.ParseError as ex:
        return ["overlay does not parse: %s" % ex]
    if grp.get("data-object") != object_id:
        out.append("overlay object %r" % grp.get("data-object"))
    want = parts_of(object_map, object_id)
    got = [c.get("data-hl") for c in grp]
    if sorted(got) != sorted(want) or len(set(got)) != len(got):
        out.append("overlay parts %s, want %s" % (sorted(got), sorted(want)))
    els = _elements(svg)
    for c in grp:
        eid = c.get("data-hl")
        if eid not in els:
            continue
        exp = ET.fromstring(_overlay_el(eid, els))
        if c.tag.replace(NS, "") != exp.tag or dict(c.attrib) != dict(
                exp.attrib) or (c.text or "") != "":
            out.append("overlay element for %s does not coincide" % eid)
    return out
