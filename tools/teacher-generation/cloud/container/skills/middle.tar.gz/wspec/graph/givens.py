# -*- coding: utf-8 -*-
u"""wspec.graph.givens -- GIVENS-ONLY graph figures for the pilot builder
(v6.16 round 2; W-FIGURE-DENSITY, BRIEF_V616 ADDENDUM 1, corpus AAF1).
Owner: the graphs engine agent. Stdlib only; adds NOTHING to a question:
every object comes from the caller (the question's own givens), and the
engine (kinds.validate) refuses what is not a given.

THE AUTHOR RULE: every question of a figure topic gets a figure; where a
full figure would show an answer, the figure draws ONLY the givens, or it
is an EMPTY plane to draw on. The words-share questions (15% / 20% / 10%
per level) get NO figure -- nothing here is for them.

    from wspec.graph import givens as GV
    fig = GV.givens_figure("q2a", "q2a",          # an ITEM's figure: 'q2a'
                           points=[GV.pt(0, 3), GV.pt(2, 9)],
                           undrawn=[GV.line_def("l", 3, 3)],     # asked
                           on={"l": [0, 1]})                  # A, B on it
    fig = GV.empty_figure("q7_head", "q7", x=(0, 10, 1), y=(0, 100, 10),
                          titles=(u"זמן (שעות)", u"מרחק (ק״מ)"),
                          aspect="free")
    rep = GV.preview(fig)            # validate + render: size, issues
    GV.sheet_label_leaks(spec["figures"])       # [] or the conflicts
    GV.stated_marks_problems(spec)             # [] or why

Figure ids follow the sheet's canonical rule (schema SCOPE_NOT_CANONICAL): a
question's figure is '<q>_head' (scope '<q>'), an item's figure is the item
id ('q2a', scope 'q2a'); the question / item shows it ("figure": id).
A figure is the SHEET form (sheet_graph.author_of reads it): {"id",
"scope", "figure_accuracy": "accurate", "entities": [axis:x, axis:y,
plane:xy], "draws": <the caller's axis-name context facts>, "frame",
"graph": {..., "givens": true}}.

WHAT IT GUARANTEES (the engine refuses otherwise -- kinds.validate):
  * only givens are drawn: a drawn curve no find asks about (or whose
    equation the text prints), free points "optional" (text-printed);
  * the asked objects are "drawn": false (undrawn): their stroke, their
    equation and their key points are forbidden, except where a printed
    given sits; "hide" adds answer points / texts that are no key point;
  * labels are bare NAMES (a point: one Latin capital other than X, Y; a
    curve: f, g, h or such a capital) -- never '(0,3)', never 'x = 3'
    (kinds.GIVENS_NAMES_ONLY -- FINAL: the author did not approve
    coordinate labels, APPROVALS V616-A2, 2026-09-27; corpus graph v1.1).
    One exception: a drawn curve whose equation its question's text prints
    (stated_in) may be labelled by THAT equation (line_def(...,
    equation="slope_intercept"), parabola_def(..., equation="expanded"));
    stated_marks_problems proves the label is the text's own printed
    equation, and sheet_label_leaks refuses it where it equals an answer a
    SOURCE figure of the sheet guards (corpus v1.1 GP397: no 'x = 3' on
    G9-T06 c q12);
  * the window holds the origin (0 is a tick of both axes), every drawn
    given with a margin, every "room" point (where the student draws), and
    >= 2 grid steps of every drawn given curve.
"""
import math
from fractions import Fraction

from . import kinds as K

NICE_STEPS = (1, 2, 5, 10, 20, 25, 50, 100, 200, 250, 500, 1000)
MAX_INTERVALS = 12           # per axis, by default (kinds allows 40)
EST_SQUARE_PX = 15.5         # the renderer's square once labels grew it
FRAME_PAD_PX = 46.0          # the axes' numbers, arrows and letters
MAX_EQUAL_PX = (420, 480)    # a figure's default bound (w, h) px
ITEM_MAX_PX = (150, 480)     # an ITEM figure (emit_plus: <= 150 px wide)
EMPTY_DEFAULT = ((-5, 5, 1), (-5, 5, 1))       # an empty plane's window
EMPTY_REAL_LIFE = ((0, 10, 1), (0, 10, 1))
WINDOW_CODES = ("GRAPH_LINE_NOT_LATTICE", "GRAPH_CURVE_OUTSIDE",
                "GRAPH_CURVE_SPLIT", "GRAPH_GIVEN_SHORT",
                "GRAPH_MARK_OUTSIDE", "GRAPH_VERTEX_OUTSIDE")
ENTITIES = ["axis:x", "axis:y", "plane:xy"]
LETTERS = {"x": {"letter": True, "title": None},
           "y": {"letter": True, "title": None}}


# ------------------------------------------------------------ objects ----
def pt(x, y, name=None, on=(), required=False):
    """a given point. Not required = a datum the question's text prints
    ('optional': drawn exactly or not at all); required = a point the
    question refers to as drawn (it must lie on a drawn given curve)"""
    return {"x": x, "y": y, "name": name, "on": list(on),
            "required": bool(required)}


def line_def(tok, m, b, name=None, stated_in=None, style="solid",
             equation=None):
    return {"id": "curve:%s" % tok, "fn": "line", "m": m, "b": b,
            "name": name, "stated_in": stated_in, "style": style,
            "equation": equation}


def vline_def(tok, x, name=None, stated_in=None, style="solid",
              equation=None):
    return {"id": "curve:%s" % tok, "fn": "vline", "x": x, "name": name,
            "stated_in": stated_in, "style": style, "equation": equation}


def parabola_def(tok, p, k, name=None, stated_in=None, style="solid",
                 equation=None):
    """(v6.16 fix r1) equation = an EQ_FORMS form ('vertex', 'expanded',
    'vline', 'slope_intercept'): the drawn curve's label prints its equation
    -- only for a curve its text states (stated_in; kinds _givens_rules)"""
    return {"id": "curve:%s" % tok, "fn": "parabola", "p": p, "k": k,
            "name": name, "stated_in": stated_in, "style": style,
            "equation": equation}


def _curve(d, drawn=True):
    c = {"id": d["id"], "fn": d["fn"], "style": d.get("style", "solid"),
         "label": ({"name": d["name"]} if d.get("name") and drawn else
                   {"equation": d["equation"]} if d.get("equation") and
                   drawn else None)}
    for k in K.FN_PARAMS[d["fn"]]:
        c[k] = _num_out(d[k])
    if d.get("stated_in"):
        c["stated_in"] = d["stated_in"]
    if not drawn:
        c["drawn"] = False
    return c


def _num_out(v):
    q = K.Q(v) if not isinstance(v, Fraction) else v
    if q is None:
        raise ValueError("not an exact number: %r" % (v,))
    return int(q) if q.denominator == 1 else K.cstr(q)


# ------------------------------------------------------------- window ----
def _fits(vals, st, margin, min_neg, min_pos):
    """the window (lo, hi, n) of one axis at step st"""
    vals = [Fraction(v) for v in vals] + [Fraction(0)]
    lo, hi = min(vals), max(vals)
    st = Fraction(st)
    a, b = math.floor(lo / st), math.ceil(hi / st)
    if lo < 0:
        a -= margin
    if hi > 0:
        b += margin
    a, b = min(a, -min_neg), max(b, min_pos)
    return a * st, b * st, b - a


def frame_candidates(xs=(), ys=(), aspect="free",
                     max_intervals=MAX_INTERVALS, margin=1, min_neg=(1, 1),
                     min_pos=(2, 2), steps=None, max_px=MAX_EQUAL_PX,
                     square=EST_SQUARE_PX):
    """the windows holding the origin and the given x / y values with
    `margin` steps beyond them, best first: the smallest nice steps whose
    printed size -- estimated at `square` px per x interval (the renderer's
    grown square) plus the axes' margins -- fits max_px (w, h), then the
    rest by size. aspect 'equal' (one data unit as long on both axes) keeps
    the y step >= the x step."""
    so = steps or (NICE_STEPS, NICE_STEPS)
    fit, rest = [], []
    for sx in so[0]:
        x0, x1, nx = _fits(xs, sx, margin, min_neg[0], min_pos[0])
        if nx > max_intervals:
            continue
        for sy in so[1]:
            if aspect == "equal" and Fraction(sy) < Fraction(sx):
                continue
            y0, y1, ny = _fits(ys, sy, margin, min_neg[1], min_pos[1])
            if ny > max_intervals:
                continue
            cy = square * (float(Fraction(sy) / Fraction(sx))
                           if aspect == "equal" else 1.0)
            w, h = nx * square + FRAME_PAD_PX, ny * cy + FRAME_PAD_PX
            cand = (x0, x1, sx, nx, y0, y1, sy, ny)
            (fit if w <= max_px[0] and h <= max_px[1] else rest).append(
                (w * h, cand))
    order = [c for _a, c in fit] + [c for _a, c in sorted(
        rest, key=lambda r: r[0])]

    def ax(a, lo, hi, st, n):
        return {"axis": a, "min": _num_out(lo), "max": _num_out(hi),
                "step": _num_out(st), "label_every": 1 if n <= 12 else 2}
    for x0, x1, sx, nx, y0, y1, sy, ny in order:
        yield {"family": "coordinate_plane", "plane": "plane:xy",
               "grid": True, "axes": [ax("axis:x", x0, x1, sx, nx),
                                      ax("axis:y", y0, y1, sy, ny)]}


def auto_frame(xs=(), ys=(), **kw):
    """the best frame_candidates window (see there); an item figure:
    max_px=ITEM_MAX_PX (emit_plus: at most 150 px wide)"""
    for fr in frame_candidates(xs, ys, **kw):
        return fr
    raise ValueError("no nice steps fit")


def frame_of(x, y, grid=True, label_every=(1, 1)):
    """an explicit frame: x / y = (min, max, step)"""
    def ax(a, t, le):
        return {"axis": a, "min": t[0], "max": t[1], "step": t[2],
                "label_every": le}
    return {"family": "coordinate_plane", "plane": "plane:xy", "grid": grid,
            "axes": [ax("axis:x", x, label_every[0]),
                     ax("axis:y", y, label_every[1])]}


# ------------------------------------------------------------- figure ----
_TOKENS = "PQRSTUVWKLMNABCDEFGHJ"


def givens_graph(points=(), curves=(), undrawn=(), on=None, finds=(),
                 hide_points=(), hide_texts=(), aspect="free",
                 titles=(None, None)):
    """the sheet 'graph' block of a givens-only figure. points: pt(...);
    curves: drawn GIVEN curves (line_def / vline_def / parabola_def);
    undrawn: the ASKED curves (never drawn); on: {curve token: [indices of
    points on it]} (a point on an undrawn curve is checked exactly on it);
    finds: kinds FIND records (optional); hide_*: answers no key point
    covers."""
    on = on or {}
    cs = [_curve(d) for d in curves] + [_curve(d, drawn=False)
                                        for d in undrawn]
    ids = set(c["id"] for c in cs)
    marks, used = [], set()
    for i, p in enumerate(points):
        tok = p.get("name") or next(t for t in _TOKENS if t not in used and
                                   t not in [q.get("name") for q in points])
        used.add(tok)
        mon = list(p.get("on") or [])
        for ctok, idx in sorted(on.items()):
            if i in idx:
                mon.append("curve:%s" % ctok)
        for cid in mon:
            if cid not in ids:
                raise ValueError("point %d on %s: no such curve" % (i, cid))
        mk = {"id": "mark:%s" % tok, "kind": "point", "on": sorted(set(mon)),
              "x": _num_out(p["x"]), "y": _num_out(p["y"]),
              "label": {"name": p["name"]} if p.get("name") else None}
        if not p.get("required"):
            mk["optional"] = True
        marks.append(mk)
    g = {"axes": {"x": {"letter": True, "title": titles[0]},
                  "y": {"letter": True, "title": titles[1]}},
         "aspect": aspect, "curves": cs, "marks": marks, "parallel": [],
         "finds": list(finds), "givens": True}
    if hide_points or hide_texts:
        g["hide"] = {}
        if hide_points:
            g["hide"]["points"] = [[_num_out(x), _num_out(y)]
                                   for x, y in hide_points]
        if hide_texts:
            g["hide"]["texts"] = list(hide_texts)
    return g


def _values(g, room):
    xs, ys = [], []
    for m in g["marks"]:
        xs.append(K.Q(m["x"]))
        ys.append(K.Q(m["y"]))
    for c in g["curves"]:
        if c.get("drawn") is False:
            continue
        cur = K.Curve.from_def(dict((k, c[k]) for k in
                                    ("fn",) + K.FN_PARAMS[c["fn"]]))
        pts = list(K.key_points(cur))
        if cur.fn == "parabola":
            # the arms: two steps each side of the vertex (y = k + 4)
            pts += [(cur.p - 2, cur.k + 4), (cur.p + 2, cur.k + 4)]
        for x, y in pts:
            if cur.fn == "vline":
                xs.append(x)
            else:
                xs.append(x)
                ys.append(y)
    for x, y in room:
        xs.append(K.Q(x))
        ys.append(K.Q(y))
    return [v for v in xs if v is not None], [v for v in ys if v is not None]


def givens_figure(fid, scope, frame=None, room=(), draws=(), real_life=False,
                  max_intervals=MAX_INTERVALS, max_px=None, **kw):
    """a sheet figure drawing ONLY the question's givens (see givens_graph
    for kw). frame None -> auto_frame over the givens' coordinates and the
    room points (real_life: both axes start at 0); an ITEM figure (fid is
    no '<q>_head') fits ITEM_MAX_PX unless max_px says otherwise."""
    g = givens_graph(**kw)

    def fig_of(fr):
        return {"id": fid, "scope": scope, "figure_accuracy": "accurate",
                "entities": list(ENTITIES), "draws": list(draws),
                "frame": fr, "graph": g}
    if frame is not None:
        fig = fig_of(frame)
        issues = validate(fig)
        if issues:
            raise K.GraphSpecError(issues)
        return fig
    xs, ys = _values(g, room)
    if not [v for v in xs + ys if v != 0]:
        # nothing drawn and no room: the empty plane's default window
        fig = fig_of(frame_of(*(EMPTY_REAL_LIFE if real_life else
                                EMPTY_DEFAULT)))
        issues = validate(fig)
        if issues:
            raise K.GraphSpecError(issues)
        return fig
    neg = (0, 0) if real_life else (1, 1)
    if max_px is None:
        max_px = MAX_EQUAL_PX if fid.endswith("_head") else ITEM_MAX_PX
    first = None
    for fr in frame_candidates(xs, ys, aspect=g["aspect"],
                               max_intervals=max_intervals, min_neg=neg,
                               max_px=max_px):
        fig = fig_of(fr)
        issues = validate(fig)
        if not issues:
            return fig
        if first is None:
            first = issues
        # a window-only problem (a vertical line off the grid, a line with
        # < 2 lattice points, a curve shown < 2 steps): the next window;
        # anything else is the spec's own fault
        if any(i.code not in WINDOW_CODES for i in issues):
            raise K.GraphSpecError(issues)
    raise K.GraphSpecError(first or [])


def empty_figure(fid, scope, x=(-5, 5, 1), y=(-5, 5, 1), aspect="free",
                 titles=(None, None), draws=(), finds=(), hide_points=(),
                 hide_texts=(), label_every=(1, 1)):
    """an EMPTY plane (axes, numbers, grid) to draw on -- the author's
    choice where every drawable given would show an answer. finds / hide:
    what the student will draw (to_plot / plot_point) or must not see."""
    g = givens_graph(finds=finds, hide_points=hide_points,
                     hide_texts=hide_texts, aspect=aspect, titles=titles)
    fig = {"id": fid, "scope": scope, "figure_accuracy": "accurate",
           "entities": list(ENTITIES), "draws": list(draws),
           "frame": frame_of(x, y, label_every=label_every), "graph": g}
    issues = validate(fig)
    if issues:
        raise K.GraphSpecError(issues)
    return fig


def author_spec(fig):
    """the kinds author spec of a sheet figure (sheet_graph.author_of)"""
    d = dict(fig["graph"])
    d.update({"graph_version": K.GRAPH_VERSION, "figure": fig["id"],
              "frame": fig.get("frame")})
    return d


def validate(fig):
    return K.validate(author_spec(fig))[0]


def preview(fig, **settings):
    """validate + render with the engine defaults (+ settings): the size
    the figure prints at, and any issue -- nothing is written"""
    from . import render as R
    issues = validate(fig)
    if issues:
        return {"issues": [str(i) for i in issues]}
    spec = author_spec(fig)
    pub = K.public_model(spec)
    out = R.render(pub, R.default_settings(spec, **settings),
                   R.ENGINE_VERSION)
    pl = out["placements"]
    return {"issues": [], "validation": out["validation"]["status"],
            "canvas_px": pl["canvas_px"], "square_px": pl["square_px"],
            "print_pt": [round(v * 0.75, 1) for v in pl["canvas_px"]]}


# -------------------------------------------------------- sheet level ----
def _label_texts(spec):
    """[(object id, printed label text)] of one author spec"""
    M = K.checked(spec)
    out = []
    for cid in sorted(M.curves):
        if cid in M.undrawn:
            continue
        lab = M.crec[cid].get("label")
        t = K.curve_label_text(M.curves[cid], lab) if lab else None
        if t:
            out.append((cid, t))
    for mid in sorted(M.mrec):
        lab = M.mrec[mid].get("label")
        t = K.mark_label_text(lab, *M.marks[mid]) if lab else None
        if t:
            out.append((mid, t))
    return out


def sheet_label_leaks(figures, only_givens=False):
    """SHEET-WIDE (the frozen SCORING s7 (i) reads figure texts sheet-wide):
    every printed curve / mark label of every graph figure of a sheet
    against the answer guard of every OTHER graph figure of the sheet.
    figures: the sheet spec's figures (those without 'graph' are skipped).
    only_givens: check the labels of givens-only (new) figures only -- a
    SOURCE figure's own printed label that happens to equal another
    question's answer (G9-T06 b: q18's '(1, 3)', a q20 answer) is the
    source's and exempt under s7 (i) (1); a build-time refusal should use
    only_givens=True.
    -> [(figure, object, label, guarded text, guarding figure)]"""
    specs = []
    for f in figures or []:
        if isinstance(f, dict) and isinstance(f.get("graph"), dict):
            try:
                specs.append((f["id"], author_spec(f)))
            except Exception:                    # noqa: BLE001
                continue
    guards = {}
    for fid, sp in specs:
        try:
            guards[fid] = K.answer_guard(sp)
        except K.GraphSpecError:
            continue
    givens_ids = set(fid for fid, sp in specs if sp.get("givens") is True)
    out = []
    for fid, sp in specs:
        if only_givens and sp.get("givens") is not True:
            continue
        try:
            labels = _label_texts(sp)
        except K.GraphSpecError:
            continue
        # (v6.16 fix r1, verify P2-M1) the equation label of a drawn given
        # whose equation its question's TEXT prints (stated_in) repeats
        # printed words: another figure's answer that equals it is printed
        # by that text anyway (G9-T06 q9's 'y = x²', printed by 9א). Only
        # the curve's OWN equation is exempt, never a name or a coordinate.
        # (r3, corpus graph v1.1) the exemption holds against the guards of
        # other GIVENS-ONLY figures only: an answer a SOURCE figure of the
        # sheet guards is a frozen forbidden text of the sheet (SCORING
        # s7 (i), sheet-wide), and v1.1 withdrew exactly such a label
        # (GP397: 'x = 3' on G9-T06 c q12). G9-T06 b q12 'x = 4' (guarded
        # by the new q17 figure) and q9 'y = x²' (new q1 / q3) stay allowed.
        stated = set()
        for c in sp.get("curves") or []:
            lab = c.get("label") or {}
            if c.get("stated_in") and c.get("drawn", True) is not False \
                    and "equation" in lab:
                stated.add(c.get("id"))
        for oid, t in labels:
            for gid, g in sorted(guards.items()):
                if gid == fid:
                    continue            # the figure's own rules: validate
                if oid in stated and gid in givens_ids:
                    continue            # a printed given vs a new figure
                hits = [ft for ft in g.get("texts") or []
                        if K._tok_contains(t, ft)]
                hits += [fb for fb in g.get("bare") or []
                         if "".join(t.split()) == "".join(fb.split())]
                for d in g.get("equations") or []:
                    if K.same_curve_as_text(K.Curve.from_def(d), t):
                        hits.append(K.equation_text(
                            K.Curve.from_def(d),
                            K.EQ_FORMS[d["fn"]][0]) or str(d))
                for h in hits:
                    out.append((fid, oid, t, h, gid))
    return out


def _blocks(obj):
    """every bound block {'text', 'bind'} under obj (a question: its stem,
    items, tables, examples)"""
    if isinstance(obj, dict):
        if isinstance(obj.get("bound"), dict):
            yield obj["bound"]
        for v in obj.values():
            for b in _blocks(v):
                yield b
    elif isinstance(obj, list):
        for v in obj:
            for b in _blocks(v):
                yield b


def printed_pairs(spec, qid):
    """{(x, y)}: the coordinate pairs the texts of question qid PRINT, as
    the sheet path binds them (schema_bound BOUND_COORD_ROLE): the two
    numbers of a pair bound to the x / y coordinate facts of ONE entity
    (a named point or an unnamed vertex vtx:<tag>:<n>) -- or, where a later
    sheet path allows it, to a graph mark's x / y."""
    from .. import schema_bound as SB
    facts = dict((f.get("id"), f) for f in spec.get("facts") or []
                 if isinstance(f, dict))
    q = [x for x in spec.get("questions") or [] if x.get("id") == qid]
    out = set()
    marks = {}
    for f in spec.get("figures") or []:
        for mk in ((f.get("graph") or {}).get("marks") or []) \
                if isinstance(f, dict) else []:
            marks["%s/%s" % (f.get("id"), mk.get("id"))] = mk
    for blk in _blocks(q):
        text, bind = blk.get("text"), blk.get("bind")
        if not isinstance(text, str) or not isinstance(bind, list):
            continue
        at = SB.atoms(text)
        if len(at) != len(bind):
            continue
        for i, j, _n in SB.coord_pairs(text):
            vals, owners = [], []
            for pos, k in ((0, i), (1, j)):
                b = bind[k] if isinstance(bind[k], dict) else {}
                fl = SB.bind_facts(b)
                own, val = set(), None
                for fid in fl:
                    f = facts.get(fid) or {}
                    a = f.get("args") or []
                    if f.get("rel") == "coordinate" and len(a) == 2 and \
                            f.get("role") in ("given", "context") and \
                            a[1] == ("axis:x", "axis:y")[pos]:
                        own.add(a[0])
                        val = K.Q(f.get("value"))
                g = b.get("graph")
                if isinstance(g, str) and g.endswith("/" + "xy"[pos]):
                    mk = marks.get(g.rsplit("/", 1)[0])
                    if mk is not None:
                        own.add(g.rsplit("/", 1)[0])
                        val = K.Q(mk.get("xy"[pos]))
                vals.append(val)
                owners.append(own)
            if None not in vals and owners[0] & owners[1]:
                out.add((vals[0], vals[1]))
    return out


def stated_marks_problems(spec):
    """every OPTIONAL mark ('a datum the question's text prints') of every
    graph figure of a sheet spec is printed by the texts of the figure's
    question: its (x, y) is one of printed_pairs(spec, question).
    -> [why]  (the honesty check of 'optional': a point the text does not
    print is no given -- the engine exempts optional marks from the key
    points of an undrawn curve)"""
    import re
    probs = []
    for f in spec.get("figures") or []:
        if not (isinstance(f, dict) and isinstance(f.get("graph"), dict)):
            continue
        m = re.match(r"^(q\d+)", f.get("scope") or "")
        qid = m.group(1) if m else None
        pairs = printed_pairs(spec, qid) if qid else set()
        for mk in f["graph"].get("marks") or []:
            if mk.get("optional") is not True:
                continue
            xy = (K.Q(mk.get("x")), K.Q(mk.get("y")))
            if xy not in pairs:
                probs.append("%s: optional %s at (%s, %s) -- no text of %s "
                             "prints that pair (bound to the coordinate "
                             "facts of one point)" % (
                                 f["id"], mk.get("id"), mk.get("x"),
                                 mk.get("y"), qid or "?"))
    return probs + stated_labels_problems(spec)


def _norm_text(t):
    """comparison form of a printed text: no math-island dollars, one minus
    sign (U+2212), no white space"""
    import re
    t = (t or u"").replace(u"$", u"").replace(u"-", K.MINUS)
    return re.sub(r"\s+", u"", t)


def unit_texts(spec, unit):
    """the printed texts a unit shows: an item -> its question's stem (and
    whatever the question prints outside its items) + the item's own
    blocks; a question id -> every block of the question. None when the
    unit is no question / item of the spec."""
    import re
    m = re.match(r"^(q\d+)", unit or "")
    if not m:
        return None
    q = [x for x in spec.get("questions") or []
         if isinstance(x, dict) and x.get("id") == m.group(1)]
    if not q:
        return None
    q = q[0]
    if unit == q["id"]:
        blocks = list(_blocks(q))
    else:
        it = [i for i in q.get("items") or []
              if isinstance(i, dict) and i.get("id") == unit]
        if not it:
            return None
        blocks = list(_blocks(dict((k, v) for k, v in q.items()
                                   if k != "items"))) + list(_blocks(it[0]))
    return [b.get("text") for b in blocks if isinstance(b.get("text"), str)]


def stated_labels_problems(spec):
    """(r3, corpus graph v1.1 label_allowed) the equation label of a drawn
    STATED curve of a givens-only figure repeats a printed given only when
    it IS the equation its stated_in unit prints: the label text (in the
    form the label names) must occur in that unit's printed texts
    (unit_texts; token match, dollars / white space / minus sign folded).
    A label in another form than the text's -- 'y = (x − 3)² − 4' where
    the text prints 'y = x² − 6x + 5' -- prints a value no text gives.
    -> [why] (sheet_graph wires stated_marks_problems, which returns these
    too, as GRAPH_GIVENS_NOT_GIVEN)"""
    probs = []
    for f in spec.get("figures") or []:
        if not (isinstance(f, dict) and isinstance(f.get("graph"), dict)):
            continue
        if f["graph"].get("givens") is not True:
            continue
        for c in f["graph"].get("curves") or []:
            lab = c.get("label") or {}
            if c.get("drawn", True) is False or "equation" not in lab:
                continue
            unit = c.get("stated_in")
            try:
                cur = K.Curve.from_def(dict(
                    (k, c[k]) for k in ("fn",) + K.FN_PARAMS[c["fn"]]))
                t = K.curve_label_text(cur, lab)
            except Exception:                     # noqa: BLE001
                continue                          # validate says why
            if not t:
                continue
            texts = unit_texts(spec, unit) if unit else None
            if texts is None:
                probs.append("%s: stated label %r of %s -- stated_in %r is "
                             "no question / item of the sheet" % (
                                 f["id"], t, c.get("id"), unit))
                continue
            if not any(K._tok_contains(_norm_text(x), _norm_text(t))
                       for x in texts):
                probs.append("%s: stated label %r of %s -- no text of %s "
                             "prints that equation (the label must be the "
                             "equation the text prints)" % (
                                 f["id"], t, c.get("id"), unit))
    return probs
