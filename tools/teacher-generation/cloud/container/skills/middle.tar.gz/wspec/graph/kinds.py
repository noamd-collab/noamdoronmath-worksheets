# -*- coding: utf-8 -*-
"""wspec.graph.kinds -- the GRAPH spec kinds (v6.16, BRIEF_V616 G1-G3).

THE AUTHOR SPEC  'wspec-graph/1'  (one figure; closed; numbers exact)
  {"graph_version": "wspec-graph/1",
   "figure": "q4_head",                     id grammar FIG_RE
   "frame":  {"family": "coordinate_plane", "plane": "plane:xy", "grid": true,
              "axes": [AXIS(axis:x), AXIS(axis:y)]}
             AXIS = {"axis", "min", "max", "step", "label_every" | "label_at"}
             (the same frame as wspec.family: 0 a tick, <= 40 intervals)
   "axes":   {"x": {"letter": true, "title": null}, "y": {...}}
             letter: the axis letter at the arrow; title: a Hebrew quantity /
             unit text printed at the axis EXACTLY ("זמן (דקות)")
   "aspect": "equal" | "free"   equal: one data unit as long on both axes
   "curves": [CURVE ...]
   "marks":  [MARK ...]
   "parallel": [{"curves": [C1, C2], "stated": bool}]
   "finds":  [FIND ...]}

  CURVE {"id": "curve:<tok>", "fn": "line" | "vline" | "parabola",
         line: "m", "b"   (y = m x + b)    vline: "x"   (x = x)
         parabola: "p", "k"  (y = (x - p)^2 + k; a = 1 ONLY, upward ONLY)
         "style": "solid" | "dashed",
         "label": null | {"name": "a" | "f" | "A" | "s1" | "(1)"}
                       | {"equation": FORM}  (the printed equation, computed)
         "extent": null | [x0, x1]   (a domain inside the window; default:
                                      the whole window)
         "symmetry_of": null | a parabola's id (a vline: its axis of symmetry)
         "stated_in": null | unit id  (the equation is printed in that
                                       unit's text: a given)}
      FORM line: slope_intercept; vline: vline; parabola: vertex | factored |
      expanded.   Integer vertex; zeros integer when they exist; a line goes
      through >= 2 lattice points of the grid inside the window.
  MARK  {"id": "mark:<tok>", "kind": vertex | zero | y_intercept | point |
         intersection, "on": [curve ids], "x", "y",
         "label": null | {"name": P} | {"coords": true} | {"name": P,
                  "coords": true}    ("(2, −9)", "P(3, 6)", "V")
         "guides": [] | ["x"] | ["y"] | ["x", "y"]  (dashed reading guides:
                  ONLY with "guides_stated_in": the unit whose text states
                  them),
         "optional": true  (a point a question TEXT prints -- "(3, 4)" --
                  drawn here exactly; roles optional_mark / optional_label)}
  FIND  {"id", "item": unit id, "rel": FIND_RELS, "args": [curve ids],
         "at"?: a number (value_at: x; x_for_value: y), "curve"?: a curve
         def (to_plot), "xy"?: [x, y] (plot_point), "answer": ...}
         The answer is PRIVATE; the figure never shows it (LEAK RULES).

LEAK RULES ("never draw what the student must find"): every find forbids
points (no mark within 0.25 step), curves (no stroke of it), equations (no
label that is the same curve in any form) and composite texts (no label
containing them): see forbidden(). A drawn element hitting one is
GRAPH_TARGET_DRAWN. The answer itself is checked against the mathematics
(GRAPH_ANSWER_MISMATCH): an author's answer is never trusted.

GIVENS-ONLY FIGURES (v6.16 round 2, W-FIGURE-DENSITY / corpus AAF1).
Every question of a figure topic gets a figure; where a full figure would
show an answer the figure draws ONLY the question's givens, or nothing (an
EMPTY plane to draw on). Three optional keys express it:
  "givens": true   (top level) the figure is givens-only:
       - every DRAWN curve is a given: no find asks about it, or the text
         prints its equation ("stated_in"); an asked curve is "drawn": false
       - a free point (a mark on no curve) is "optional": true (a datum the
         question's text prints)
       - every drawn curve shows >= 2 grid steps inside the window
       - NAMES ONLY (GIVENS_NAMES_ONLY; FINAL since the author's V616-A2
         NOT_APPROVED, 2026-09-27: bare point names only): a label is a
         bare name -- a point one Latin capital other than X, Y; a curve f,
         g, h or a Latin capital other than X, Y -- never coordinates (a
         printed value there token-matches answers of other questions on
         the same sheet). One exception (v6.16 fix r1 / r3, corpus v1.1
         label_allowed): a drawn curve whose equation its question's TEXT
         prints ("stated_in") may carry that equation as its label; r3: a
         parabola label may not print a form that states what a find of
         the figure asks (vertex form + vertex / axis / minimum, factored
         + zeros, expanded + y-intercept), and at sheet level the label
         must be the equation its text prints (givens.stated_marks_problems)
       - it may be EMPTY (no curve, no mark): axes, numbers and grid only
  CURVE "drawn": false   an UNDRAWN curve: the object the question asks
       about (the line through two given points, the parabola whose zeros
       are asked). Never rendered, never in the public model or the display
       layout; finds may ask about it (the answer is still checked against
       the mathematics); no label / extent / symmetry_of / parallel; a mark
       on it is a kind "point" (a given lying on it). LEAK: its stroke, its
       equation in every form and its KEY POINTS (y-intercept, zeros,
       vertex; a vertical line's x-axis crossing) are forbidden -- except a
       key point the GIVENS already show: an "optional" mark there (the
       text prints that point) or a key point of a drawn curve nothing asks
       about (its drawing shows it). The same exemption holds for the
       points a find on an undrawn curve forbids.
  "hide": {"points": [[x, y] ...], "texts": [...]}   answers of the
       question the figure must not show that are no key point of an
       undrawn curve (a symmetric point, an answer text). STRICT: no mark
       within 0.25 step of a hidden point (optional or not), no label
       containing a hidden text or a hidden point's coordinates.
All of it joins the answer guard (answer_guard / private_model), so the
independent checker and the sheet's G79 verify the drawing against it.

PUBLIC MODEL 'wspec-graph-public/1': what the page prints of the figure.
A curve's numbers (def, extent) are public only when nothing about the
curve is asked (no find names it) or its equation is printed (label or
stated_in); otherwise they go to the DISPLAY LAYOUT (settings "curves"),
which only the renderer reads -- as a read-off point of the coordinate
plane. The same for a mark's coordinates (public when its label prints
them or its curves are public). Finds are public without answers.
"""
import hashlib
import math
import re
from fractions import Fraction

from .. import canon

GRAPH_VERSION = "wspec-graph/1"
PUBLIC_VERSION = "wspec-graph-public/1"
MAX_INTERVALS = 40
FNS = ("line", "vline", "parabola")
STYLES = ("solid", "dashed")
MARK_KINDS = ("vertex", "zero", "y_intercept", "point", "intersection")
ASPECTS = ("equal", "free")
EQ_FORMS = {"line": ("slope_intercept",), "vline": ("vline",),
            "parabola": ("vertex", "factored", "expanded")}
MONOTONE = ("increasing", "decreasing", "constant")
# find relation -> (argument fn kinds per argument, answer kind, extras)
FIND_RELS = {
    "slope": ((("line",),), "number", ()),
    "y_intercept": ((("line", "parabola"),), "number", ()),
    "x_intercept": ((("line",),), "number", ()),
    "zeros": ((("parabola",),), "numbers", ()),
    "vertex": ((("parabola",),), "point", ()),
    "axis_of_symmetry": ((("parabola",),), "number", ()),
    "min_value": ((("parabola",),), "number", ()),
    "equation": ((("line", "vline", "parabola"),), "def", ()),
    "monotone": ((("line",),), "word", ()),
    "increase_interval": ((("parabola",),), "intervals", ()),
    "decrease_interval": ((("parabola",),), "intervals", ()),
    "positive_interval": ((("line", "parabola"),), "intervals", ()),
    "negative_interval": ((("line", "parabola"),), "intervals", ()),
    "value_at": ((("line", "parabola"),), "number", ("at",)),
    "x_for_value": ((("line", "parabola"),), "numbers", ("at",)),
    "intersection": ((("line", "vline", "parabola"),
                      ("line", "vline", "parabola")), "points", ()),
    "shift": ((("parabola",), ("parabola",)), "shift", ()),
    "to_plot": ((), "def", ("curve",)),
    "plot_point": ((), "point", ("xy",)),
}
TOP_FIELDS = {"graph_version": True, "figure": True, "frame": True,
              "axes": True, "aspect": True, "curves": True, "marks": True,
              "parallel": True, "finds": True,
              # v6.16 round 2 (W-FIGURE-DENSITY): optional
              "givens": False, "hide": False}
CURVE_FIELDS = {"id": True, "fn": True, "m": False, "b": False, "x": False,
                "p": False, "k": False, "style": True, "label": True,
                "extent": False, "symmetry_of": False, "stated_in": False,
                "drawn": False}
HIDE_FIELDS = {"points": False, "texts": False}
# names only in a givens-only figure: FINAL (r3). The corpus AMENDMENT P2
# (coordinate labels) was put to the author and NOT approved (APPROVALS
# V616-A2, 2026-09-27T18:17:09Z: 'keep bare point names only'); corpus
# graph v1.1 relabels every new-figure point to a bare name. A label
# printing a given's value ('(0,3)', 'x = 3') token-matches the answers of
# other questions of the same sheet (frozen SCORING s7 (i), sheet-wide)
GIVENS_NAMES_ONLY = True
GIVENS_NAMES_ONLY_AUTHORITY = "V616-A2 NOT_APPROVED 2026-09-27T18:17:09Z"
# (r3) what a parabola's equation FORM states (a label in that form prints
# the answer of a find of this relation on the same curve)
FORM_STATES = {"vertex": ("vertex", "axis_of_symmetry", "min_value"),
               "factored": ("zeros",),
               "expanded": ("y_intercept",)}
GIVEN_POINT_NAME_RE = re.compile(r"^[A-WZ]\Z")
GIVEN_CURVE_NAME_RE = re.compile(r"^(?:[fgh]|[A-WZ])\Z")
GIVEN_MIN_STEPS = 2          # a drawn given curve shows >= 2 grid steps
FN_PARAMS = {"line": ("m", "b"), "vline": ("x",), "parabola": ("p", "k")}
MARK_FIELDS = {"id": True, "kind": True, "on": True, "x": True, "y": True,
               "label": True, "guides": False, "guides_stated_in": False,
               "optional": False}
FIND_FIELDS = {"id": True, "item": True, "rel": True, "args": True,
               "answer": True, "at": False, "curve": False, "xy": False}
FRAME_FIELDS = {"family": True, "plane": True, "axes": True, "grid": True}
AXIS_FIELDS = {"axis": True, "min": True, "max": True, "step": True,
               "label_every": False, "label_at": False}

FIG_RE = re.compile(r"^[a-z0-9][a-z0-9_]{0,31}\Z")
CURVE_RE = re.compile(r"^curve:[A-Za-z0-9]{1,8}\Z")
MARK_RE = re.compile(r"^mark:[A-Za-z0-9]{1,8}\Z")
FIND_ID_RE = re.compile(r"^[A-Za-z0-9_.:#-]{1,64}\Z")
UNIT_RE = re.compile(r"^q[1-9][0-9]?[a-v]?\Z")
CURVE_NAME_RE = re.compile(r"^(?:[A-Za-z][1-9]?|\([1-9]\))\Z")
POINT_NAME_RE = canon.NAME_RE
# a Hebrew axis title: Hebrew letters, geresh / gershayim, spaces, one pair
# of parentheses, the shekel sign and the maqaf -- no digit, no Latin
TITLE_RE = re.compile(u"^[א-ת׳״־ ()₪]{1,40}\\Z")
HEB_RE = re.compile(u"[א-ת]")
MINUS = u"−"
SQUARED = u"²"

REASONS = {
    "GRAPH_BAD_SHAPE": "a part of the graph spec has the wrong JSON shape",
    "GRAPH_UNKNOWN_FIELD": "a field outside the closed graph spec",
    "GRAPH_MISSING_FIELD": "a required field of the graph spec is absent",
    "GRAPH_BAD_ID": "an id breaks its grammar",
    "GRAPH_DUPLICATE_ID": "two curves / marks / finds share an id",
    "GRAPH_BAD_NUMBER": "a number that is not an exact rational",
    "GRAPH_FRAME_BAD": "the coordinate frame is malformed (0 not a tick, "
                       "too many intervals, a label off the ticks)",
    "GRAPH_UNKNOWN_FN": "a curve kind outside line / vline / parabola",
    "GRAPH_NOT_A1": "a parabola whose leading coefficient is not 1 (a != 1 "
                    "and downward parabolas are outside the stage)",
    "GRAPH_VERTEX_NOT_INTEGER": "a parabola's vertex is not a lattice "
                                "point with integer coordinates",
    "GRAPH_ZEROS_NOT_INTEGER": "a parabola's zeros exist but are not whole",
    "GRAPH_VERTEX_OUTSIDE": "a parabola's vertex is outside the window",
    "GRAPH_LINE_NOT_LATTICE": "a line passes through fewer than two lattice "
                              "points of the grid inside the window",
    "GRAPH_CURVE_OUTSIDE": "a curve has no drawn part inside the window",
    "GRAPH_CURVE_SPLIT": "a curve would be drawn in two pieces (it leaves "
                         "and re-enters the window)",
    "GRAPH_CURVE_ON_AXIS": "a curve coincides with a coordinate axis",
    "GRAPH_CURVE_DUPLICATE": "two curves are the same curve",
    "GRAPH_EXTENT_BAD": "an extent that is not a sub-range of the window",
    "GRAPH_LABEL_BAD": "a label outside the closed label grammar",
    "GRAPH_LABEL_FORM": "an equation form the curve cannot be printed in "
                        "(factored without two whole zeros, a non-"
                        "terminating decimal)",
    "GRAPH_MARK_OFF": "a mark is not where its kind says (vertex, zero, "
                      "y-intercept, on its curves, an exact intersection)",
    "GRAPH_MARK_OUTSIDE": "a mark outside the window or the drawn curve",
    "GRAPH_MARK_DUPLICATE": "two marks at one point",
    "GRAPH_GUIDE_UNSTATED": "a reading guide that no stated given draws",
    "GRAPH_PARALLEL_FALSE": "lines declared parallel are not parallel",
    "GRAPH_SYMMETRY_FALSE": "a declared axis of symmetry is not x = p",
    "GRAPH_FIND_BAD": "a find outside the closed vocabulary or with bad "
                      "arguments",
    "GRAPH_ANSWER_MISMATCH": "a find's answer is not what the mathematics "
                             "of the figure gives",
    "GRAPH_TARGET_DRAWN": "the figure would show what a find asks (a mark "
                          "at the answer point, the asked curve or "
                          "equation, a text stating the answer)",
    "GRAPH_TITLE_BAD": "an axis title outside the Hebrew title grammar",
    "GRAPH_ANGLE_NAME": "an angle named by fewer than three letters or a "
                        "triangle name without its three letters",
    "GRAPH_ASPECT_BAD": "aspect outside equal / free",
    # v6.16 round 2 (W-FIGURE-DENSITY): givens-only figures
    "GRAPH_GIVENS_LABEL": "a label of a givens-only figure that is not a "
                          "bare name (coordinates or an equation print a "
                          "value; names only until the author decides "
                          "AMENDMENT P2) or a name outside the givens name "
                          "set",
    "GRAPH_GIVENS_NOT_GIVEN": "a givens-only figure draws something that is "
                              "no given of its question (an asked curve not "
                              "marked drawn: false, a free point the text "
                              "does not print)",
    "GRAPH_GIVEN_SHORT": "a drawn given curve shows fewer than 2 grid steps "
                         "inside the window",
    "GRAPH_UNDRAWN_BAD": "an undrawn curve (drawn: false) with a label, an "
                         "extent, a symmetry / parallel relation or a mark "
                         "that shows its drawing",
    "GRAPH_HIDE_BAD": "the hide block is malformed (points [[x, y]], texts "
                      "[non-empty strings])",
}


class GraphIssue(object):
    __slots__ = ("code", "where", "detail")

    def __init__(self, code, where="", detail=""):
        assert code in REASONS, "unregistered graph reason %r" % code
        self.code, self.where, self.detail = code, where, detail

    def __repr__(self):
        return "GraphIssue(%s @ %s: %s)" % (self.code, self.where,
                                            self.detail)

    __str__ = __repr__

    def as_dict(self):
        return {"code": self.code, "where": self.where,
                "detail": self.detail}


class GraphSpecError(Exception):
    def __init__(self, issues):
        self.issues = list(issues)
        Exception.__init__(self, "; ".join(str(i) for i in self.issues[:8]))

    @property
    def codes(self):
        return sorted(set(i.code for i in self.issues))


# ------------------------------------------------------------- numbers ---
def Q(v):
    """exact rational of v (int, canonical / decimal / fraction string),
    or None; a float is refused (exactness), a bool too."""
    if isinstance(v, bool) or isinstance(v, float) or v is None:
        return None
    if isinstance(v, Fraction):
        return v
    if isinstance(v, int):
        return Fraction(v)
    if not isinstance(v, str):
        return None
    try:
        a, b, r = canon.parse_exact(v.replace(MINUS, "-"))
    except Exception:                               # noqa: BLE001
        return None
    return a if (r == 1 or b == 0) else None


def cstr(q):
    """the canonical string of a rational ('-20', '1/2')"""
    return canon.canon_number(str(Fraction(q)))


def terminating(q):
    d = Fraction(q).denominator
    while d % 2 == 0:
        d //= 2
    while d % 5 == 0:
        d //= 5
    return d == 1


def disp(q):
    """a number as a figure prints it: U+2212, a decimal point; None for a
    non-terminating fraction (a figure prints no p/q)"""
    q = Fraction(q)
    if not terminating(q):
        return None
    neg = q < 0
    m = abs(q)
    if m.denominator == 1:
        s = str(m.numerator)
    else:
        # exact decimal expansion of a terminating fraction
        n, d = m.numerator, m.denominator
        k = 0
        while (n * 10 ** k) % d:
            k += 1
        digits = str(n * 10 ** k // d).rjust(k + 1, "0")
        s = digits[:-k] + "." + digits[-k:]
    return (MINUS + s) if neg else s


def qsqrt(q):
    """exact square root of a non-negative rational, or None"""
    q = Fraction(q)
    if q < 0:
        return None
    rn, rd = math.isqrt(q.numerator), math.isqrt(q.denominator)
    if rn * rn == q.numerator and rd * rd == q.denominator:
        return Fraction(rn, rd)
    return None


def coords_text(x, y, name=""):
    """'(2, −9)' / 'P(3, 6)'; None when a coordinate does not print"""
    dx, dy = disp(x), disp(y)
    if dx is None or dy is None:
        return None
    return "%s(%s, %s)" % (name, dx, dy)


# --------------------------------------------------------------- curves ---
class Curve(object):
    """exact curve: line y = m x + b, vline x = c, parabola (x-p)^2 + k"""

    def __init__(self, fn, **kw):
        self.fn = fn
        if fn == "line":
            self.m, self.b = Fraction(kw["m"]), Fraction(kw["b"])
        elif fn == "vline":
            self.c = Fraction(kw["x"])
        elif fn == "parabola":
            self.p, self.k = Fraction(kw["p"]), Fraction(kw["k"])
        else:
            raise ValueError(fn)

    @classmethod
    def from_def(cls, d):
        return cls(d["fn"], **dict((k, Q(v)) for k, v in d.items()
                                   if k != "fn"))

    def key(self):
        if self.fn == "line":
            return {"fn": "line", "m": cstr(self.m), "b": cstr(self.b)}
        if self.fn == "vline":
            return {"fn": "vline", "x": cstr(self.c)}
        return {"fn": "parabola", "p": cstr(self.p), "k": cstr(self.k)}

    def same(self, o):
        return o is not None and self.key() == o.key()

    def is_function(self):
        return self.fn != "vline"

    def f(self, x):
        x = Fraction(x) if not isinstance(x, float) else x
        if self.fn == "line":
            return self.m * x + self.b
        if self.fn == "parabola":
            return (x - self.p) ** 2 + self.k
        raise ValueError("a vertical line is not a function")

    def fl(self, x):
        """float value"""
        if self.fn == "line":
            return float(self.m) * x + float(self.b)
        return (x - float(self.p)) ** 2 + float(self.k)

    def on(self, x, y):
        x, y = Fraction(x), Fraction(y)
        if self.fn == "vline":
            return x == self.c
        return self.f(x) == y

    def poly(self):
        """(a2, a1, a0) of y = a2 x^2 + a1 x + a0 (functions only)"""
        if self.fn == "line":
            return (Fraction(0), self.m, self.b)
        return (Fraction(1), -2 * self.p, self.p ** 2 + self.k)

    def zeros(self):
        """whole list of exact zeros, [] when none, None when irrational
        or everywhere (y = 0)"""
        if self.fn == "vline":
            return None
        if self.fn == "line":
            if self.m == 0:
                return [] if self.b != 0 else None
            return [-self.b / self.m]
        if self.k > 0:
            return []
        r = qsqrt(-self.k)
        if r is None:
            return None
        return [self.p] if r == 0 else [self.p - r, self.p + r]

    def __repr__(self):
        return "Curve(%r)" % (self.key(),)


def intersections(c1, c2):
    """exact intersection points (sorted), [] when none, None when there are
    infinitely many or an irrational one"""
    if c1.same(c2):
        return None
    a, b = sorted([c1, c2], key=lambda c: FNS.index(c.fn))
    if a.fn == "vline" and b.fn == "vline":
        return []
    if a.fn == "vline":
        return [(a.c, b.f(a.c))]
    if b.fn == "vline":
        return [(b.c, a.f(b.c))]
    p1, p2 = a.poly(), b.poly()
    A, B, C = p1[0] - p2[0], p1[1] - p2[1], p1[2] - p2[2]
    if A == 0:
        if B == 0:
            return [] if C != 0 else None
        x = -C / B
        return [(x, a.f(x))]
    D = B * B - 4 * A * C
    if D < 0:
        return []
    r = qsqrt(D)
    if r is None:
        return None
    xs = sorted(set([(-B - r) / (2 * A), (-B + r) / (2 * A)]))
    return [(x, a.f(x)) for x in xs]


# ----------------------------------------------------- equation texts ---
def _signed(v, first=False):
    """' + 3' / ' − 3' (first=False) for a constant term"""
    d = disp(abs(v))
    if d is None:
        return None
    if first:
        return (MINUS if v < 0 else "") + d
    return (" " + MINUS + " " if v < 0 else " + ") + d


def _lin_factor(z):
    """x - z as printed: 'x', '(x − 2)', '(x + 3)'"""
    if z == 0:
        return "x"
    d = disp(abs(z))
    if d is None:
        return None
    return "(x %s %s)" % (MINUS if z > 0 else "+", d)


def equation_text(curve, form):
    """the printed equation of a curve in a form, or None when the form
    cannot print it (GRAPH_LABEL_FORM)"""
    c = curve
    if form == "vline" and c.fn == "vline":
        d = disp(c.c)
        return None if d is None else "x = " + d
    if form == "slope_intercept" and c.fn == "line":
        if c.m == 0:
            t = _signed(c.b, first=True)
            return None if t is None else "y = " + t
        if abs(c.m) == 1:
            mx = ("" if c.m > 0 else MINUS) + "x"
        else:
            dm = disp(c.m)
            if dm is None:
                return None
            mx = dm + "x"
        if c.b == 0:
            return "y = " + mx
        t = _signed(c.b)
        return None if t is None else "y = " + mx + t
    if c.fn != "parabola":
        return None
    if form == "vertex":
        sq = ("x" if c.p == 0 else _lin_factor(c.p)) + SQUARED
        if c.p != 0 and _lin_factor(c.p) is None:
            return None
        if c.k == 0:
            return "y = " + sq
        t = _signed(c.k)
        return None if t is None else "y = " + sq + t
    if form == "factored":
        zs = c.zeros()
        if not zs or len(zs) != 2 or any(z.denominator != 1 for z in zs):
            return None
        f1, f2 = _lin_factor(zs[0]), _lin_factor(zs[1])
        if f1 == "x":
            return "y = x" + f2
        if f2 == "x":
            return "y = x" + f1
        return "y = " + f1 + f2
    if form == "expanded":
        _a, b1, b0 = c.poly()
        s = "y = x" + SQUARED
        if b1 != 0:
            if abs(b1) == 1:
                s += (" " + MINUS + " x") if b1 < 0 else " + x"
            else:
                d = disp(abs(b1))
                if d is None:
                    return None
                s += (" %s %sx" % (MINUS if b1 < 0 else "+", d))
        if b0 != 0:
            t = _signed(b0)
            if t is None:
                return None
            s += t
        return s
    return None


def all_equation_texts(curve):
    return sorted(set(t for f in EQ_FORMS.get(curve.fn, ())
                      for t in [equation_text(curve, f)] if t))


# a small exact parser of the printed equations (the leak rules and the
# checker read labels mathematically: 'y = (x − 1)(x − 5)' IS
# 'y = x² − 6x + 5')
_TOK = re.compile(u"\\s*(?:(\\d+(?:\\.\\d+)?(?:/\\d+)?)|(x)|(²)|"
                  u"([-+−()=])|(y))")


def parse_equation(text):
    """'y = ...' -> ('fn', (a2, a1, a0)) with exact coefficients, or
    ('vline', c) for 'x = c'; None when it is not an equation of degree
    <= 2 in these forms"""
    if not isinstance(text, str):
        return None
    s = text.replace(MINUS, "-").strip()
    toks, pos = [], 0
    while pos < len(s):
        m = _TOK.match(s, pos)
        if not m or m.end() == pos:
            return None
        pos = m.end()
        num, x, sq, op, y = m.groups()
        if num is not None:
            toks.append(("n", Fraction(num)))
        elif x:
            toks.append(("x", None))
        elif sq:
            toks.append(("^2", None))
        elif op:
            toks.append((op, None))
        elif y:
            toks.append(("y", None))
    if len(toks) >= 3 and toks[0][0] == "x" and toks[1][0] == "=":
        rest = toks[2:]
        sign = Fraction(1)
        if rest and rest[0][0] in "-+":
            sign = Fraction(-1) if rest[0][0] == "-" else Fraction(1)
            rest = rest[1:]
        if len(rest) == 1 and rest[0][0] == "n":
            return ("vline", sign * rest[0][1])
        return None
    if len(toks) < 3 or toks[0][0] != "y" or toks[1][0] != "=":
        return None
    try:
        poly, i = _expr(toks, 2)
    except (ValueError, IndexError):
        return None
    if i != len(toks) or poly is None or len(poly) > 3:
        return None
    poly = list(poly) + [Fraction(0)] * (3 - len(poly))
    return ("fn", (poly[2], poly[1], poly[0]))


def _padd(a, b):
    n = max(len(a), len(b))
    return [(a[i] if i < len(a) else 0) + (b[i] if i < len(b) else 0)
            for i in range(n)]


def _pmul(a, b):
    out = [Fraction(0)] * (len(a) + len(b) - 1)
    for i, u in enumerate(a):
        for j, v in enumerate(b):
            out[i + j] += u * v
    return out


def _expr(t, i):
    """sum of signed terms; returns (poly low->high, next index)"""
    total = [Fraction(0)]
    first = True
    while i < len(t):
        sign = Fraction(1)
        if t[i][0] in "+-":
            sign = Fraction(-1) if t[i][0] == "-" else Fraction(1)
            i += 1
        elif not first:
            break
        term, i = _term(t, i)
        total = _padd(total, [sign * c for c in term])
        first = False
        if i < len(t) and t[i][0] == ")":
            break
    return total, i


def _term(t, i):
    """a product of factors: number, x, (expr), each optionally squared"""
    prod = [Fraction(1)]
    got = False
    while i < len(t) and t[i][0] in ("n", "x", "("):
        if t[i][0] == "n":
            f = [t[i][1]]
            i += 1
        elif t[i][0] == "x":
            f = [Fraction(0), Fraction(1)]
            i += 1
        else:
            f, i = _expr(t, i + 1)
            if i >= len(t) or t[i][0] != ")":
                raise ValueError("paren")
            i += 1
        if i < len(t) and t[i][0] == "^2":
            f = _pmul(f, f)
            i += 1
        prod = _pmul(prod, f)
        got = True
    if not got:
        raise ValueError("term")
    while len(prod) > 1 and prod[-1] == 0:
        prod.pop()
    return prod, i


def same_curve_as_text(curve, text):
    """True when the printed equation `text` is the curve `curve`"""
    e = parse_equation(text)
    if e is None:
        return False
    if e[0] == "vline":
        return curve.fn == "vline" and curve.c == e[1]
    return curve.fn != "vline" and tuple(curve.poly()) == tuple(e[1])


# --------------------------------------------------------------- frame ---
def _ax_nums(ax):
    return Q(ax.get("min")), Q(ax.get("max")), Q(ax.get("step"))


def ticks(ax):
    lo, hi, st = _ax_nums(ax)
    if None in (lo, hi, st) or st <= 0 or hi <= lo:
        return []
    n = (hi - lo) / st
    if n.denominator != 1 or n > MAX_INTERVALS:
        return []
    return [lo + i * st for i in range(int(n) + 1)]


def labelled(ax):
    ts = ticks(ax)
    if not ts:
        return []
    if "label_at" in ax:
        want = set(Q(v) for v in ax.get("label_at") or [])
        return [t for t in ts if t in want]
    k = ax.get("label_every")
    if not isinstance(k, int) or isinstance(k, bool) or k < 1:
        return []
    st = Q(ax.get("step"))
    anchor = Fraction(0) if Fraction(0) in ts else ts[0]
    return [t for t in ts if ((t - anchor) / (k * st)).denominator == 1]


def public_frame(fr):
    """the printed frame: per axis the interval count and the printed
    labels by tick index (the same shape as wspec.family.public_frame)"""
    axes = []
    for ax in fr["axes"]:
        ts = ticks(ax)
        axes.append({"axis": ax["axis"], "intervals": len(ts) - 1,
                     "labels": [[ts.index(t), cstr(t)]
                                for t in labelled(ax)]})
    return {"family": "coordinate_plane", "plane": fr["plane"],
            "grid": bool(fr["grid"]), "axes": axes}


class Window(object):
    def __init__(self, fr):
        ax, ay = fr["axes"]
        self.x0, self.x1, self.sx = _ax_nums(ax)
        self.y0, self.y1, self.sy = _ax_nums(ay)

    def inside(self, x, y):
        return self.x0 <= x <= self.x1 and self.y0 <= y <= self.y1

    def steps(self, x, y):
        return (float(x) / float(self.sx), float(y) / float(self.sy))

    def step_dist(self, a, b):
        return math.hypot((float(a[0]) - float(b[0])) / float(self.sx),
                          (float(a[1]) - float(b[1])) / float(self.sy))


def drawn_ranges(curve, win, extent=None):
    """the x-ranges (floats) of the part of a function curve drawn inside
    the window (and the extent); a vline: [(c, c)] when inside"""
    x0, x1 = float(win.x0), float(win.x1)
    if extent is not None:
        x0, x1 = max(x0, float(extent[0])), min(x1, float(extent[1]))
    if curve.fn == "vline":
        return [(float(curve.c), float(curve.c))] if \
            win.x0 <= curve.c <= win.x1 else []
    y0, y1 = float(win.y0), float(win.y1)
    if curve.fn == "line":
        m, b = float(curve.m), float(curve.b)
        if m == 0:
            return [(x0, x1)] if y0 <= b <= y1 and x0 < x1 else []
        u, v = (y0 - b) / m, (y1 - b) / m
        lo, hi = max(x0, min(u, v)), min(x1, max(u, v))
        return [(lo, hi)] if hi - lo > 1e-12 else []
    p, k = float(curve.p), float(curve.k)
    if k > y1:
        return []
    w = math.sqrt(y1 - k)
    lo, hi = max(x0, p - w), min(x1, p + w)
    if hi - lo <= 1e-12:
        return []
    if k < y0:
        w2 = math.sqrt(y0 - k)
        out = []
        if min(hi, p - w2) - lo > 1e-12:
            out.append((lo, min(hi, p - w2)))
        if hi - max(lo, p + w2) > 1e-12:
            out.append((max(lo, p + w2), hi))
        return out
    return [(lo, hi)]


def lattice_points(curve, win, extent=None):
    """grid points of the window on the drawn part of a line / parabola"""
    out = []
    rng = drawn_ranges(curve, win, extent)
    if curve.fn == "vline" or not rng:
        return out
    n = int((win.x1 - win.x0) / win.sx)
    for i in range(n + 1):
        x = win.x0 + i * win.sx
        if not any(a - 1e-9 <= float(x) <= b + 1e-9 for a, b in rng):
            continue
        y = curve.f(x)
        if win.y0 <= y <= win.y1 and ((y - win.y0) / win.sy).denominator \
                == 1:
            out.append((x, y))
    return out


# ------------------------------------------------------------ validate ---
def _fields(obj, table, where, out):
    if not isinstance(obj, dict):
        out.append(GraphIssue("GRAPH_BAD_SHAPE", where, "expected an "
                              "object"))
        return False
    for k in sorted(obj):
        if k not in table:
            out.append(GraphIssue("GRAPH_UNKNOWN_FIELD", where, k))
    for k, req in sorted(table.items()):
        if req and k not in obj:
            out.append(GraphIssue("GRAPH_MISSING_FIELD", where, k))
    return True


def _num(v, where, out, what):
    q = Q(v)
    if q is None:
        out.append(GraphIssue("GRAPH_BAD_NUMBER", where, "%s %r" % (what,
                                                                    v)))
    return q


def _frame_ok(fr, out):
    w = "frame"
    if not _fields(fr, FRAME_FIELDS, w, out):
        return False
    ok = True
    if fr.get("family") != "coordinate_plane" or \
            fr.get("plane") != "plane:xy" or \
            not isinstance(fr.get("grid"), bool):
        out.append(GraphIssue("GRAPH_FRAME_BAD", w, "family / plane / grid"))
        ok = False
    axes = fr.get("axes")
    if not isinstance(axes, list) or len(axes) != 2:
        out.append(GraphIssue("GRAPH_FRAME_BAD", w, "two axes"))
        return False
    for n, (ax, name) in enumerate(zip(axes, ("axis:x", "axis:y"))):
        wa = "frame.axes[%d]" % n
        if not _fields(ax, AXIS_FIELDS, wa, out):
            ok = False
            continue
        if ax.get("axis") != name:
            out.append(GraphIssue("GRAPH_FRAME_BAD", wa, "axis %r, want %s"
                                  % (ax.get("axis"), name)))
            ok = False
        lo, hi, st = [_num(ax.get(k), wa, out, k)
                      for k in ("min", "max", "step")]
        if None in (lo, hi, st):
            ok = False
            continue
        ts = ticks(ax)
        if not ts:
            out.append(GraphIssue("GRAPH_FRAME_BAD", wa, "min %s max %s step "
                                  "%s: 1..%d whole intervals" % (
                                      cstr(lo), cstr(hi), cstr(st),
                                      MAX_INTERVALS)))
            ok = False
            continue
        if Fraction(0) not in ts:
            out.append(GraphIssue("GRAPH_FRAME_BAD", wa, "0 is not a tick "
                                  "(the axes cross at the origin)"))
            ok = False
        if ("label_every" in ax) == ("label_at" in ax):
            out.append(GraphIssue("GRAPH_FRAME_BAD", wa, "exactly one of "
                                  "label_every / label_at"))
            ok = False
        elif "label_at" in ax:
            la = ax.get("label_at")
            qs = [Q(v) for v in la] if isinstance(la, list) else [None]
            if not la or None in qs or any(q not in ts for q in qs) or \
                    len(set(qs)) != len(qs):
                out.append(GraphIssue("GRAPH_FRAME_BAD", wa, "label_at %r: "
                                      "distinct ticks" % (la,)))
                ok = False
        elif not labelled(ax):
            out.append(GraphIssue("GRAPH_FRAME_BAD", wa, "label_every %r"
                                  % (ax.get("label_every"),)))
            ok = False
    return ok


def _angle_names(s):
    """GRAPH_ANGLE_NAME: '∠A' / '∠AB' (fewer than three letters) or a '△'
    not followed by three point names"""
    bad = []
    for m in re.finditer(u"∠\\s*((?:[A-Z][1-9]?'{0,3})*)", s):
        if len(re.findall(r"[A-Z]", m.group(1))) != 3:
            bad.append(m.group(0))
    for m in re.finditer(u"△\\s*((?:[A-Z][1-9]?'{0,3})*)", s):
        if len(re.findall(r"[A-Z]", m.group(1))) != 3:
            bad.append(m.group(0))
    return bad


def _strings(obj):
    if isinstance(obj, str):
        yield obj
    elif isinstance(obj, dict):
        for k in sorted(obj):
            for s in _strings(obj[k]):
                yield s
    elif isinstance(obj, list):
        for v in obj:
            for s in _strings(v):
                yield s


class Model(object):
    """the validated figure: exact curves, marks, finds"""

    def __init__(self):
        self.curves = {}      # id -> Curve
        self.crec = {}        # id -> record
        self.marks = {}       # id -> (x, y)
        self.mrec = {}
        self.finds = []
        self.win = None
        # v6.16 round 2 (givens-only figures)
        self.givens = False
        self.undrawn = set()   # ids of curves with "drawn": false
        self.hide_points = []  # [(x, y)] exact
        self.hide_texts = []

    def drawn(self, cid):
        return cid in self.curves and cid not in self.undrawn

    def optional_at(self, x, y):
        """an optional mark (a datum the text prints) within 0.25 step of
        (x, y)"""
        for mid, rec in self.mrec.items():
            if rec.get("optional") is True and mid in self.marks and \
                    self.win.step_dist(self.marks[mid], (x, y)) < 0.25:
                return mid
        return None

    def given_at(self, x, y):
        """(round 2) a point the figure's GIVENS already show: an optional
        mark there (the text prints it), or a key point of a drawn curve
        nothing asks about (its drawing shows it: G8-T15 a q5, the given
        line y = -2 crosses the y axis at the asked line's intercept)"""
        mid = self.optional_at(x, y)
        if mid is not None:
            return mid
        for cid in sorted(self.curves):
            if cid in self.undrawn or not _curve_public(self, cid):
                continue
            if (Fraction(x), Fraction(y)) in key_points(self.curves[cid]):
                return cid
        return None


def validate(spec):
    """-> (issues, model). Every issue is a GraphIssue."""
    out = []
    M = Model()
    if not _fields(spec, TOP_FIELDS, "graph", out):
        return out, M
    if spec.get("graph_version") != GRAPH_VERSION:
        out.append(GraphIssue("GRAPH_BAD_SHAPE", "graph_version",
                              repr(spec.get("graph_version"))))
    if not (isinstance(spec.get("figure"), str) and
            FIG_RE.match(spec["figure"])):
        out.append(GraphIssue("GRAPH_BAD_ID", "figure",
                              repr(spec.get("figure"))))
    for s in _strings(spec):
        for b in _angle_names(s):
            out.append(GraphIssue("GRAPH_ANGLE_NAME", "graph", b))
    if spec.get("aspect") not in ASPECTS:
        out.append(GraphIssue("GRAPH_ASPECT_BAD", "aspect",
                              repr(spec.get("aspect"))))
    axes = spec.get("axes")
    if not isinstance(axes, dict) or sorted(axes) != ["x", "y"]:
        out.append(GraphIssue("GRAPH_BAD_SHAPE", "axes", "{x: .., y: ..}"))
    else:
        for a in ("x", "y"):
            rec = axes[a]
            if _fields(rec, {"letter": True, "title": True}, "axes." + a,
                       out):
                if not isinstance(rec.get("letter"), bool):
                    out.append(GraphIssue("GRAPH_BAD_SHAPE", "axes." + a,
                                          "letter"))
                t = rec.get("title")
                if t is not None and not _title_ok(t):
                    out.append(GraphIssue("GRAPH_TITLE_BAD", "axes." + a,
                                          repr(t)))
    fr = spec.get("frame")
    if not _frame_ok(fr, out):
        return out, M
    win = M.win = Window(fr)
    # ------------------------------------------ givens / hide (round 2)
    if "givens" in spec:
        if not isinstance(spec["givens"], bool):
            out.append(GraphIssue("GRAPH_BAD_SHAPE", "givens",
                                  repr(spec["givens"])))
        else:
            M.givens = spec["givens"]
    if "hide" in spec:
        _hide_rules(spec["hide"], M, out)
    # ------------------------------------------------------- curves
    seen = set()
    for n, c in enumerate(spec.get("curves") or []):
        w = "curves[%d]" % n
        if not _fields(c, CURVE_FIELDS, w, out):
            continue
        cid = c.get("id")
        if not (isinstance(cid, str) and CURVE_RE.match(cid)):
            out.append(GraphIssue("GRAPH_BAD_ID", w, repr(cid)))
            continue
        if cid in seen:
            out.append(GraphIssue("GRAPH_DUPLICATE_ID", w, cid))
            continue
        seen.add(cid)
        w = "curve %s" % cid
        cur = _curve_from(c, w, out)
        if cur is None:
            continue
        if c.get("style") not in STYLES:
            out.append(GraphIssue("GRAPH_BAD_SHAPE", w, "style %r"
                                  % (c.get("style"),)))
        if c.get("stated_in") is not None and not (
                isinstance(c["stated_in"], str) and
                UNIT_RE.match(c["stated_in"])):
            out.append(GraphIssue("GRAPH_BAD_ID", w, "stated_in %r"
                                  % (c["stated_in"],)))
        ext = c.get("extent")
        if ext is not None:
            ok = isinstance(ext, list) and len(ext) == 2
            e = [Q(v) for v in ext] if ok else [None]
            if not ok or None in e or not (win.x0 <= e[0] < e[1] <= win.x1) \
                    or cur.fn == "vline":
                out.append(GraphIssue("GRAPH_EXTENT_BAD", w, repr(ext)))
                ext = None
            else:
                ext = e
        M.curves[cid] = cur
        M.crec[cid] = dict(c, extent=ext)
        if "drawn" in c:
            if c["drawn"] is not False:
                out.append(GraphIssue("GRAPH_BAD_SHAPE", w, "drawn: false "
                                      "only (a curve is drawn by default)"))
            else:
                M.undrawn.add(cid)
        if cid in M.undrawn:
            _undrawn_rules(cid, cur, c, out)
        else:
            _curve_rules(cid, cur, ext, win, out)
        _label_rules(cid, cur, c.get("label"), out)
    # duplicates / axes
    ids = sorted(M.curves)
    for i, a in enumerate(ids):
        for b in ids[i + 1:]:
            if M.curves[a].same(M.curves[b]):
                if (a in M.undrawn) != (b in M.undrawn):
                    # the undrawn (asked) curve is drawn after all
                    out.append(GraphIssue("GRAPH_TARGET_DRAWN", a, "the "
                                          "undrawn curve %s is drawn as %s"
                                          % ((a, b) if a in M.undrawn
                                             else (b, a))))
                else:
                    out.append(GraphIssue("GRAPH_CURVE_DUPLICATE", a, b))
    for cid in ids:
        sym = M.crec[cid].get("symmetry_of")
        if sym is not None:
            P = M.curves.get(sym)
            cur = M.curves[cid]
            if P is None or P.fn != "parabola" or cur.fn != "vline" or \
                    cur.c != P.p:
                out.append(GraphIssue("GRAPH_SYMMETRY_FALSE", cid,
                                      "symmetry_of %r" % (sym,)))
            elif sym in M.undrawn:
                out.append(GraphIssue("GRAPH_UNDRAWN_BAD", cid, "the axis "
                                      "of symmetry of the undrawn %s" % sym))
    # ------------------------------------------------------- marks
    mseen = set()
    at = {}
    for n, mk in enumerate(spec.get("marks") or []):
        w = "marks[%d]" % n
        if not _fields(mk, MARK_FIELDS, w, out):
            continue
        mid = mk.get("id")
        if not (isinstance(mid, str) and MARK_RE.match(mid)):
            out.append(GraphIssue("GRAPH_BAD_ID", w, repr(mid)))
            continue
        if mid in mseen:
            out.append(GraphIssue("GRAPH_DUPLICATE_ID", w, mid))
            continue
        mseen.add(mid)
        w = "mark %s" % mid
        x, y = _num(mk.get("x"), w, out, "x"), _num(mk.get("y"), w, out,
                                                     "y")
        if x is None or y is None:
            continue
        on = mk.get("on")
        if not isinstance(on, list) or any(o not in M.curves for o in on) \
                or len(set(on)) != len(on):
            out.append(GraphIssue("GRAPH_BAD_SHAPE", w, "on %r" % (on,)))
            continue
        M.marks[mid] = (x, y)
        M.mrec[mid] = mk
        _mark_rules(mid, mk, x, y, on, M, out)
        if (x, y) in at:
            out.append(GraphIssue("GRAPH_MARK_DUPLICATE", w, at[(x, y)]))
        at[(x, y)] = mid
        _mark_label_rules(mid, mk.get("label"), x, y, out)
        if "optional" in mk and (mk["optional"] is not True or
                                 mk.get("kind") != "point"):
            out.append(GraphIssue("GRAPH_BAD_SHAPE", w, "optional: true on a "
                                  "point only (a datum a question text "
                                  "prints, drawn exactly or not at all)"))
        g = mk.get("guides", [])
        if not isinstance(g, list) or any(a not in ("x", "y") for a in g) \
                or len(set(g)) != len(g):
            out.append(GraphIssue("GRAPH_BAD_SHAPE", w, "guides %r" % (g,)))
        elif g and not (isinstance(mk.get("guides_stated_in"), str) and
                        UNIT_RE.match(mk["guides_stated_in"])):
            out.append(GraphIssue("GRAPH_GUIDE_UNSTATED", w, "guides %s "
                                  "without guides_stated_in" % g))
        elif not g and "guides_stated_in" in mk:
            out.append(GraphIssue("GRAPH_BAD_SHAPE", w, "guides_stated_in "
                                  "without guides"))
    # ------------------------------------------------------- parallel
    for n, pr in enumerate(spec.get("parallel") or []):
        w = "parallel[%d]" % n
        if not _fields(pr, {"curves": True, "stated": True}, w, out):
            continue
        cs = pr.get("curves")
        if not isinstance(cs, list) or len(cs) != 2 or \
                any(c not in M.curves for c in cs) or cs[0] == cs[1] or \
                not isinstance(pr.get("stated"), bool):
            out.append(GraphIssue("GRAPH_BAD_SHAPE", w, repr(pr)))
            continue
        a, b = M.curves[cs[0]], M.curves[cs[1]]
        if not ((a.fn == b.fn == "line" and a.m == b.m) or
                (a.fn == b.fn == "vline")):
            out.append(GraphIssue("GRAPH_PARALLEL_FALSE", w, "%s, %s"
                                  % tuple(cs)))
        elif any(c in M.undrawn for c in cs):
            out.append(GraphIssue("GRAPH_UNDRAWN_BAD", w, "a parallel pair "
                                  "with an undrawn curve (%s, %s)"
                                  % tuple(cs)))
    # ------------------------------------------------------- finds
    fseen = set()
    for n, fd in enumerate(spec.get("finds") or []):
        w = "finds[%d]" % n
        if not _fields(fd, FIND_FIELDS, w, out):
            continue
        fid = fd.get("id")
        if not (isinstance(fid, str) and FIND_ID_RE.match(fid)):
            out.append(GraphIssue("GRAPH_BAD_ID", w, repr(fid)))
            continue
        if fid in fseen:
            out.append(GraphIssue("GRAPH_DUPLICATE_ID", w, fid))
            continue
        fseen.add(fid)
        if not (isinstance(fd.get("item"), str) and
                UNIT_RE.match(fd["item"])):
            out.append(GraphIssue("GRAPH_BAD_ID", "find %s" % fid,
                                  "item %r" % (fd.get("item"),)))
        f = _find_rules(fd, M, out)
        if f is not None:
            M.finds.append(f)
    # ------------------------------------------ givens-only (round 2)
    if M.givens:
        _givens_rules(M, out)
    # ------------------------------------------------------- leaks
    if not any(i.code in ("GRAPH_BAD_SHAPE", "GRAPH_BAD_NUMBER")
               for i in out):
        _leak_rules(M, out)
    return out, M


def _title_ok(t):
    if not isinstance(t, str) or not TITLE_RE.match(t) or \
            not HEB_RE.search(t) or t != t.strip() or "  " in t:
        return False
    if t.count("(") != t.count(")") or t.count("(") > 1:
        return False
    if "(" in t and t.index("(") > t.index(")"):
        return False
    return True


def _curve_from(c, w, out):
    fn = c.get("fn")
    if fn not in FNS:
        out.append(GraphIssue("GRAPH_UNKNOWN_FN", w, repr(fn)))
        return None
    want = FN_PARAMS[fn]
    extra = [k for k in ("m", "b", "x", "p", "k") if k in c and
             k not in want]
    if extra:
        out.append(GraphIssue("GRAPH_UNKNOWN_FIELD", w, "%s on a %s"
                              % (extra, fn)))
        return None
    vals = {}
    for k in want:
        if k not in c:
            out.append(GraphIssue("GRAPH_MISSING_FIELD", w, k))
            return None
        q = _num(c[k], w, out, k)
        if q is None:
            return None
        vals[k] = q
    return Curve(fn, **vals)


def _curve_rules(cid, cur, ext, win, out):
    if cur.fn == "line" and cur.m == 0 and cur.b == 0:
        out.append(GraphIssue("GRAPH_CURVE_ON_AXIS", cid, "y = 0 is the x "
                              "axis"))
        return
    if cur.fn == "vline" and cur.c == 0:
        out.append(GraphIssue("GRAPH_CURVE_ON_AXIS", cid, "x = 0 is the y "
                              "axis"))
        return
    rng = drawn_ranges(cur, win, ext)
    if not rng:
        out.append(GraphIssue("GRAPH_CURVE_OUTSIDE", cid, "no part inside "
                              "the window"))
        return
    if len(rng) > 1:
        out.append(GraphIssue("GRAPH_CURVE_SPLIT", cid, "%d pieces"
                              % len(rng)))
    if cur.fn == "vline":
        if (cur.c - win.x0) / win.sx != int((cur.c - win.x0) / win.sx):
            out.append(GraphIssue("GRAPH_LINE_NOT_LATTICE", cid, "x = %s is "
                                  "not a grid line" % cstr(cur.c)))
        return
    if cur.fn == "line":
        lp = lattice_points(cur, win, ext)
        if len(lp) < 2:
            out.append(GraphIssue("GRAPH_LINE_NOT_LATTICE", cid, "%d lattice "
                                  "point(s) on the drawn part" % len(lp)))
        return
    # parabola
    if cur.p.denominator != 1 or cur.k.denominator != 1:
        out.append(GraphIssue("GRAPH_VERTEX_NOT_INTEGER", cid, "(%s, %s)"
                              % (cstr(cur.p), cstr(cur.k))))
    # (zeros: whole where they are marked, asked or printed -- a zero mark
    # sits at an exact zero (GRAPH_MARK_OFF), a find on irrational zeros is
    # GRAPH_ZEROS_NOT_INTEGER, the factored form needs two whole zeros)
    if not win.inside(cur.p, cur.k) or not any(
            a - 1e-9 <= float(cur.p) <= b + 1e-9 for a, b in rng):
        out.append(GraphIssue("GRAPH_VERTEX_OUTSIDE", cid, "(%s, %s)"
                              % (cstr(cur.p), cstr(cur.k))))


def _label_rules(cid, cur, lab, out):
    if lab is None:
        return
    if not isinstance(lab, dict) or len(lab) != 1:
        out.append(GraphIssue("GRAPH_LABEL_BAD", cid, repr(lab)))
        return
    if "name" in lab:
        if not (isinstance(lab["name"], str) and
                CURVE_NAME_RE.match(lab["name"])):
            out.append(GraphIssue("GRAPH_LABEL_BAD", cid, repr(lab)))
        return
    if "equation" in lab:
        if lab["equation"] not in EQ_FORMS[cur.fn]:
            out.append(GraphIssue("GRAPH_LABEL_BAD", cid, "form %r for a %s"
                                  % (lab["equation"], cur.fn)))
        elif equation_text(cur, lab["equation"]) is None:
            out.append(GraphIssue("GRAPH_LABEL_FORM", cid, "%s cannot print "
                                  "%r" % (cid, lab["equation"])))
        return
    out.append(GraphIssue("GRAPH_LABEL_BAD", cid, repr(lab)))


# ------------------------------------------ givens-only figures (round 2) --
def _undrawn_rules(cid, cur, c, out):
    """an undrawn curve: the object a question asks about, never drawn"""
    if cur.fn == "line" and cur.m == 0 and cur.b == 0:
        out.append(GraphIssue("GRAPH_CURVE_ON_AXIS", cid, "y = 0 is the x "
                              "axis"))
    if cur.fn == "vline" and cur.c == 0:
        out.append(GraphIssue("GRAPH_CURVE_ON_AXIS", cid, "x = 0 is the y "
                              "axis"))
    for k in ("extent", "symmetry_of"):
        if c.get(k) is not None:
            out.append(GraphIssue("GRAPH_UNDRAWN_BAD", cid, "%s on an "
                                  "undrawn curve" % k))
    if c.get("label") is not None:
        out.append(GraphIssue("GRAPH_UNDRAWN_BAD", cid, "a label on an "
                              "undrawn curve (nothing of it is printed)"))


def _hide_rules(hd, M, out):
    w = "hide"
    if not _fields(hd, HIDE_FIELDS, w, out):
        return
    pts = hd.get("points", [])
    if not isinstance(pts, list):
        out.append(GraphIssue("GRAPH_HIDE_BAD", w, "points %r" % (pts,)))
        pts = []
    for p in pts:
        qs = [Q(v) for v in p] if isinstance(p, list) and len(p) == 2 \
            else [None]
        if None in qs:
            out.append(GraphIssue("GRAPH_HIDE_BAD", w, "point %r" % (p,)))
            continue
        if tuple(qs) not in M.hide_points:
            M.hide_points.append(tuple(qs))
    txs = hd.get("texts", [])
    if not isinstance(txs, list):
        out.append(GraphIssue("GRAPH_HIDE_BAD", w, "texts %r" % (txs,)))
        txs = []
    for t in txs:
        if not isinstance(t, str) or not t.strip():
            out.append(GraphIssue("GRAPH_HIDE_BAD", w, "text %r" % (t,)))
            continue
        if t.strip() not in M.hide_texts:
            M.hide_texts.append(t.strip())


def key_points(cur):
    """the exact points that give a curve away: a line's y-intercept and
    zero, a vertical line's x-axis crossing, a parabola's vertex, zeros and
    y-intercept (irrational zeros are no lattice point: left out)"""
    pts = []
    if cur.fn == "line":
        pts.append((Fraction(0), cur.b))
        if cur.m != 0:
            pts.append((-cur.b / cur.m, Fraction(0)))
    elif cur.fn == "vline":
        pts.append((cur.c, Fraction(0)))
    else:
        pts.append((cur.p, cur.k))
        for z in cur.zeros() or []:
            pts.append((Fraction(z), Fraction(0)))
        pts.append((Fraction(0), cur.f(0)))
    out = []
    for p in pts:
        if p not in out:
            out.append(p)
    return out


def shown_steps(cur, win, extent=None):
    """how many grid steps of a curve the window shows (the length of its
    drawn part in step units; a vertical line: its height)"""
    if cur.fn == "vline":
        return float((win.y1 - win.y0) / win.sy) if \
            win.x0 <= cur.c <= win.x1 else 0.0
    sx, sy = float(win.sx), float(win.sy)
    tot = 0.0
    for a, b in drawn_ranges(cur, win, extent):
        n = 1 if cur.fn == "line" else 64
        prev = None
        for i in range(n + 1):
            x = a + (b - a) * i / n
            p = (x / sx, cur.fl(x) / sy)
            if prev is not None:
                tot += math.hypot(p[0] - prev[0], p[1] - prev[1])
            prev = p
    return tot


def _form_rule(cid, M, form, out):
    """(r3) a stated curve's equation label may not print a FORM that states
    the answer of a find of this figure on the same curve: a parabola in
    vertex form states its vertex / axis / minimum, factored its zeros,
    expanded its y-intercept (a text printing 'y = x² − 6x + 5' and asking
    the vertex must not get a 'y = (x − 3)² − 4' label). Skipped when every
    form prints the same text (y = x², a line, a vertical line): then the
    label IS the printed equation."""
    cur = M.curves[cid]
    if len(all_equation_texts(cur)) < 2:
        return
    states = FORM_STATES.get(form, ())
    for f in M.finds:
        if cid in (f.rec.get("args") or []) and f.rel in states:
            out.append(GraphIssue("GRAPH_TARGET_DRAWN", cid, "the %s-form "
                                  "label %r states what find %s (%s) asks: "
                                  "label it by a name, or by the form its "
                                  "text prints" % (
                                      form, equation_text(cur, form),
                                      f.id, f.rel)))


def _givens_rules(M, out):
    """W-FIGURE-DENSITY: a givens-only figure draws ONLY givens"""
    asked = set()
    for f in M.finds:
        asked.update(f.rec.get("args") or [])
    for cid in sorted(M.curves):
        if cid in M.undrawn:
            continue
        rec = M.crec[cid]
        if cid in asked and not rec.get("stated_in"):
            out.append(GraphIssue("GRAPH_GIVENS_NOT_GIVEN", cid, "a find "
                                  "asks about it and no text prints its "
                                  "equation: mark it drawn: false"))
        st = shown_steps(M.curves[cid], M.win, rec.get("extent"))
        if st < GIVEN_MIN_STEPS - 1e-9:
            out.append(GraphIssue("GRAPH_GIVEN_SHORT", cid, "%.2f step(s) "
                                  "inside the window" % st))
        lab = rec.get("label")
        if lab is None:
            continue
        if "name" in lab:
            if not (isinstance(lab["name"], str) and
                    GIVEN_CURVE_NAME_RE.match(lab["name"])):
                out.append(GraphIssue("GRAPH_GIVENS_LABEL", cid, "curve name "
                                      "%r: f, g, h or a Latin capital other "
                                      "than X, Y" % (lab["name"],)))
        elif rec.get("stated_in") and "equation" in lab:
            _form_rule(cid, M, lab["equation"], out)
        elif GIVENS_NAMES_ONLY and not rec.get("stated_in"):
            # (v6.16 fix r1, verify P2-M1) an equation label is allowed on a
            # drawn given whose equation its question's TEXT prints
            # ("stated_in"): it repeats a printed given, it states no answer
            # (G9-T06 q9: the reference graph 'y = x²' of 9א, unlabelled it
            # was read as the two functions of the stem; corpus GP367 /
            # GP381 / GP395 allow it). A label equal to another figure's
            # guarded answer is still refused sheet-wide (GRAPH_TARGET_DRAWN)
            out.append(GraphIssue("GRAPH_GIVENS_LABEL", cid, "an equation "
                                  "label %r prints a value: names only "
                                  "(unless the text prints the curve's "
                                  "equation: stated_in)" % (lab,)))
    for mid in sorted(M.mrec):
        rec = M.mrec[mid]
        if mid not in M.marks:
            continue
        on_drawn = [c for c in rec.get("on") or [] if M.drawn(c)]
        if not on_drawn and rec.get("optional") is not True:
            out.append(GraphIssue("GRAPH_GIVENS_NOT_GIVEN", mid, "a point on "
                                  "no drawn given: a datum the text prints "
                                  "is optional: true"))
        lab = rec.get("label")
        if lab is None:
            continue
        if isinstance(lab, dict) and "name" in lab and not (
                isinstance(lab["name"], str) and
                GIVEN_POINT_NAME_RE.match(lab["name"])):
            out.append(GraphIssue("GRAPH_GIVENS_LABEL", mid, "point name %r: "
                                  "one Latin capital other than X, Y"
                                  % (lab["name"],)))
        if isinstance(lab, dict) and lab.get("coords") and GIVENS_NAMES_ONLY:
            out.append(GraphIssue("GRAPH_GIVENS_LABEL", mid, "a coordinate "
                                  "label prints a value: names only"))


def _mark_rules(mid, mk, x, y, on, M, out):
    w = "mark %s" % mid
    win = M.win
    kind = mk.get("kind")
    if kind not in MARK_KINDS:
        out.append(GraphIssue("GRAPH_BAD_SHAPE", w, "kind %r" % (kind,)))
        return
    if not win.inside(x, y):
        out.append(GraphIssue("GRAPH_MARK_OUTSIDE", w, "(%s, %s)"
                              % (cstr(x), cstr(y))))
    need = {"vertex": 1, "zero": 1, "y_intercept": 1, "intersection": 2}
    if kind in need and len(on) != need[kind]:
        out.append(GraphIssue("GRAPH_MARK_OFF", w, "a %s is on %d curve(s)"
                              % (kind, need[kind])))
        return
    if kind != "point" and any(cid in M.undrawn for cid in on):
        # a vertex / zero / y-intercept / intersection mark shows the
        # undrawn curve's key point (round 2)
        out.append(GraphIssue("GRAPH_UNDRAWN_BAD", w, "a %s mark on the "
                              "undrawn %s" % (kind, ", ".join(
                                  c for c in on if c in M.undrawn))))
        return
    for cid in on:
        cur = M.curves[cid]
        if not cur.on(x, y):
            out.append(GraphIssue("GRAPH_MARK_OFF", w, "(%s, %s) is not on "
                                  "%s" % (cstr(x), cstr(y), cid)))
            return
        if cid in M.undrawn:
            continue                # exact on it; nothing of it is drawn
        rng = drawn_ranges(cur, win, M.crec[cid].get("extent"))
        if cur.fn != "vline" and not any(a - 1e-9 <= float(x) <= b + 1e-9
                                         for a, b in rng):
            out.append(GraphIssue("GRAPH_MARK_OUTSIDE", w, "not on the drawn "
                                  "part of %s" % cid))
    if kind == "vertex":
        P = M.curves[on[0]]
        if P.fn != "parabola" or (x, y) != (P.p, P.k):
            out.append(GraphIssue("GRAPH_MARK_OFF", w, "not the vertex of %s"
                                  % on[0]))
    elif kind == "zero":
        if y != 0 or not M.curves[on[0]].is_function():
            out.append(GraphIssue("GRAPH_MARK_OFF", w, "a zero has y = 0"))
    elif kind == "y_intercept":
        if x != 0 or not M.curves[on[0]].is_function():
            out.append(GraphIssue("GRAPH_MARK_OFF", w, "a y-intercept has "
                                  "x = 0"))
    elif kind == "intersection":
        pts = intersections(M.curves[on[0]], M.curves[on[1]])
        if not pts or (x, y) not in pts:
            out.append(GraphIssue("GRAPH_MARK_OFF", w, "not an exact "
                                  "intersection of %s and %s" % tuple(on)))


def _mark_label_rules(mid, lab, x, y, out):
    if lab is None:
        return
    if not isinstance(lab, dict) or not lab or \
            set(lab) - {"name", "coords"}:
        out.append(GraphIssue("GRAPH_LABEL_BAD", mid, repr(lab)))
        return
    if "name" in lab and not (isinstance(lab["name"], str) and
                              POINT_NAME_RE.match(lab["name"])):
        out.append(GraphIssue("GRAPH_LABEL_BAD", mid, repr(lab)))
    if "coords" in lab:
        if lab["coords"] is not True:
            out.append(GraphIssue("GRAPH_LABEL_BAD", mid, repr(lab)))
        elif coords_text(x, y) is None:
            out.append(GraphIssue("GRAPH_LABEL_FORM", mid, "coordinates "
                                  "(%s, %s) do not print" % (cstr(x),
                                                             cstr(y))))


def mark_label_text(lab, x, y):
    if lab is None:
        return None
    name = lab.get("name") or ""
    if lab.get("coords"):
        return coords_text(x, y, name)
    return name


def curve_label_text(cur, lab):
    if lab is None:
        return None
    if "name" in lab:
        return lab["name"]
    return equation_text(cur, lab["equation"])


# --------------------------------------------------------------- finds ---
class Find(object):
    def __init__(self, rec, curves, truth):
        self.rec, self.curves, self.truth = rec, curves, truth
        self.id, self.rel = rec["id"], rec["rel"]


def _find_rules(fd, M, out):
    w = "find %s" % fd.get("id")
    rel = fd.get("rel")
    if rel not in FIND_RELS:
        out.append(GraphIssue("GRAPH_FIND_BAD", w, "rel %r" % (rel,)))
        return None
    kinds, akind, extras = FIND_RELS[rel]
    args = fd.get("args")
    if not isinstance(args, list) or len(args) != len(kinds) or \
            any(a not in M.curves for a in args) or \
            len(set(args)) != len(args):
        out.append(GraphIssue("GRAPH_FIND_BAD", w, "args %r" % (args,)))
        return None
    for a, ks in zip(args, kinds):
        if M.curves[a].fn not in ks:
            out.append(GraphIssue("GRAPH_FIND_BAD", w, "%s is a %s" % (
                a, M.curves[a].fn)))
            return None
    for k in ("at", "curve", "xy"):
        if (k in fd) != (k in extras):
            out.append(GraphIssue("GRAPH_FIND_BAD", w, "field %r" % k))
            return None
    curves = [M.curves[a] for a in args]
    try:
        truth = _truth(rel, curves, fd, M)
    except _Bad as ex:
        out.append(GraphIssue("GRAPH_ZEROS_NOT_INTEGER" if "zeros" in
                              str(ex) else "GRAPH_FIND_BAD", w, str(ex)))
        return None
    if rel in ("zeros", "x_intercept", "positive_interval",
               "negative_interval") and any(
                   Fraction(z).denominator != 1
                   for z in (curves[0].zeros() or [])) and \
            curves[0].fn == "parabola":
        out.append(GraphIssue("GRAPH_ZEROS_NOT_INTEGER", w, "the zeros of "
                              "%s are not whole" % args[0]))
    got = _norm_answer(akind, fd.get("answer"))
    if got is None:
        out.append(GraphIssue("GRAPH_FIND_BAD", w, "answer %r is not a %s"
                              % (fd.get("answer"), akind)))
        return None
    if got != truth:
        out.append(GraphIssue("GRAPH_ANSWER_MISMATCH", w, "answer %r, the "
                              "figure gives %r" % (got, truth)))
    return Find(fd, curves, truth)


class _Bad(Exception):
    pass


def _norm_answer(kind, a):
    try:
        if kind == "number":
            q = Q(a)
            return None if q is None else cstr(q)
        if kind == "numbers":
            qs = [Q(v) for v in a]
            return None if None in qs else [cstr(q) for q in sorted(qs)]
        if kind == "point":
            qs = [Q(v) for v in a]
            return None if None in qs or len(qs) != 2 else \
                [cstr(qs[0]), cstr(qs[1])]
        if kind == "points":
            pts = []
            for p in a:
                qs = [Q(v) for v in p]
                if None in qs or len(qs) != 2:
                    return None
                pts.append((qs[0], qs[1]))
            return [[cstr(x), cstr(y)] for x, y in sorted(pts)]
        if kind == "def":
            c = Curve.from_def(a)
            return c.key()
        if kind == "word":
            return a if a in MONOTONE else None
        if kind == "intervals":
            out = []
            for iv in a:
                if set(iv) != {"lo", "hi"}:
                    return None
                lo = None if iv["lo"] is None else Q(iv["lo"])
                hi = None if iv["hi"] is None else Q(iv["hi"])
                if (iv["lo"] is not None and lo is None) or \
                        (iv["hi"] is not None and hi is None):
                    return None
                out.append((lo, hi))
            out.sort(key=lambda t: (t[0] is not None,
                                    t[0] if t[0] is not None else 0))
            return [{"lo": None if lo is None else cstr(lo),
                     "hi": None if hi is None else cstr(hi)}
                    for lo, hi in out]
        if kind == "shift":
            if set(a) != {"dx", "dy"}:
                return None
            dx, dy = Q(a["dx"]), Q(a["dy"])
            return None if None in (dx, dy) else {"dx": cstr(dx),
                                                  "dy": cstr(dy)}
    except (TypeError, KeyError, ValueError, AttributeError):
        return None
    return None


def _iv(lo, hi):
    return {"lo": None if lo is None else cstr(lo),
            "hi": None if hi is None else cstr(hi)}


def _truth(rel, cs, fd, M):
    c = cs[0] if cs else None
    if rel == "slope":
        return cstr(c.m)
    if rel == "y_intercept":
        return cstr(c.f(0))
    if rel == "x_intercept":
        z = c.zeros()
        if not z or len(z) != 1:
            raise _Bad("the line has no single x-intercept")
        return cstr(z[0])
    if rel == "zeros":
        z = c.zeros()
        if z is None:
            raise _Bad("irrational zeros")
        return [cstr(v) for v in z]
    if rel == "vertex":
        return [cstr(c.p), cstr(c.k)]
    if rel == "axis_of_symmetry":
        return cstr(c.p)
    if rel == "min_value":
        return cstr(c.k)
    if rel == "equation":
        return c.key()
    if rel == "monotone":
        return MONOTONE[0] if c.m > 0 else MONOTONE[1] if c.m < 0 else \
            MONOTONE[2]
    if rel == "increase_interval":
        return [_iv(c.p, None)]
    if rel == "decrease_interval":
        return [_iv(None, c.p)]
    if rel in ("positive_interval", "negative_interval"):
        pos = rel == "positive_interval"
        z = c.zeros()
        if z is None:
            raise _Bad("irrational zeros")
        if c.fn == "line":
            if c.m == 0:
                raise _Bad("a constant line has no sign interval")
            up = (c.m > 0) == pos
            return [_iv(z[0], None) if up else _iv(None, z[0])]
        if not z:
            return [_iv(None, None)] if pos else []
        if len(z) == 1:
            return [_iv(None, z[0]), _iv(z[0], None)] if pos else []
        return [_iv(None, z[0]), _iv(z[1], None)] if pos else \
            [_iv(z[0], z[1])]
    if rel == "value_at":
        x = Q(fd.get("at"))
        if x is None:
            raise _Bad("at %r" % (fd.get("at"),))
        return cstr(c.f(x))
    if rel == "x_for_value":
        y = Q(fd.get("at"))
        if y is None:
            raise _Bad("at %r" % (fd.get("at"),))
        a2, a1, a0 = c.poly()
        a0 -= y
        if a2 == 0:
            if a1 == 0:
                raise _Bad("a constant line")
            return [cstr(-a0 / a1)]
        D = a1 * a1 - 4 * a2 * a0
        if D < 0:
            return []
        r = qsqrt(D)
        if r is None:
            raise _Bad("irrational solutions")
        return sorted(set(cstr(v) for v in ((-a1 - r) / (2 * a2),
                                            (-a1 + r) / (2 * a2))),
                      key=lambda s: Q(s))
    if rel == "intersection":
        pts = intersections(cs[0], cs[1])
        if pts is None:
            raise _Bad("irrational or infinitely many intersections")
        return [[cstr(x), cstr(y)] for x, y in pts]
    if rel == "shift":
        return {"dx": cstr(cs[1].p - cs[0].p), "dy": cstr(cs[1].k - cs[0].k)}
    if rel == "to_plot":
        try:
            cur = Curve.from_def(fd["curve"])
        except (TypeError, KeyError, ValueError):
            raise _Bad("curve %r" % (fd.get("curve"),))
        return cur.key()
    if rel == "plot_point":
        xy = fd.get("xy")
        qs = [Q(v) for v in xy] if isinstance(xy, list) else [None]
        if None in qs or len(qs) != 2:
            raise _Bad("xy %r" % (xy,))
        return [cstr(qs[0]), cstr(qs[1])]
    raise _Bad(rel)


# ---------------------------------------------------------- leak rules ---
class Forbidden(object):
    """what the finds of a figure forbid it to show"""

    def __init__(self):
        self.points = []      # (x, y, find id)
        self.curves = []      # (Curve, find id)
        self.equations = []   # (Curve, find id): no label that IS it
        self.texts = []       # (text, find id): no label containing it
        self.bare = []        # (text, find id): no label equal to it

    def as_guard(self):
        """the checker's answer_guard (values only, no ids)"""
        return {"points": sorted([cstr(x), cstr(y)] for x, y, _f in
                                 self.points),
                "curves": sorted((c.key() for c, _f in self.curves),
                                 key=lambda d: sorted(d.items())),
                "equations": sorted((c.key() for c, _f in self.equations),
                                    key=lambda d: sorted(d.items())),
                "texts": sorted(set(t for t, _f in self.texts)),
                "bare": sorted(set(t for t, _f in self.bare))}


def _pt_texts(x, y):
    t = coords_text(x, y)
    return [t] if t else []


def forbidden(M):
    F = Forbidden()
    for f in M.finds:
        cs, rel, fid = f.curves, f.rel, f.id
        c = cs[0] if cs else None
        # (round 2) a find on an UNDRAWN curve: a point the question's text
        # prints (an optional mark there) is the given, not the find
        soft = bool(set(f.rec.get("args") or []) & M.undrawn)

        def pt(x, y):
            if soft and M.given_at(x, y) is not None:
                return
            F.points.append((Fraction(x), Fraction(y), fid))
            for t in _pt_texts(x, y):
                F.texts.append((t, fid))

        def tx(t):
            if t:
                F.texts.append((t, fid))

        def bare(q):
            d = disp(q)
            if d:
                F.bare.append((d, fid))
        if rel == "slope":
            tx("m = %s" % disp(c.m) if disp(c.m) else None)
            bare(c.m)
        elif rel == "y_intercept":
            pt(0, c.f(0))
            bare(c.f(0))
        elif rel == "x_intercept":
            for z in c.zeros() or []:
                pt(z, 0)
                tx("x = %s" % disp(z) if disp(z) else None)
                bare(z)
        elif rel == "zeros":
            for z in c.zeros() or []:
                pt(z, 0)
                tx("x = %s" % disp(z) if disp(z) else None)
        elif rel == "vertex":
            pt(c.p, c.k)
            F.curves.append((Curve("vline", x=c.p), fid))
            tx("x = %s" % disp(c.p))
        elif rel == "axis_of_symmetry":
            F.curves.append((Curve("vline", x=c.p), fid))
            F.equations.append((Curve("vline", x=c.p), fid))
            tx("x = %s" % disp(c.p))
            if not any(M.mrec[m].get("kind") == "vertex" and
                       M.mrec[m]["on"] == [f.rec["args"][0]]
                       for m in M.mrec):
                pt(c.p, c.k)
        elif rel == "min_value":
            pt(c.p, c.k)
            F.curves.append((Curve("line", m=0, b=c.k), fid))
            tx("y = %s" % disp(c.k))
            bare(c.k)
        elif rel == "equation":
            F.equations.append((c, fid))
            for t in all_equation_texts(c):
                tx(t)
            if c.fn == "line":
                pt(0, c.b)
                tx("m = %s" % disp(c.m) if disp(c.m) else None)
                tx("b = %s" % disp(c.b) if disp(c.b) else None)
            elif c.fn == "parabola":
                tx("p = %s" % disp(c.p))
                tx("k = %s" % disp(c.k))
        elif rel in ("increase_interval", "decrease_interval",
                     "positive_interval", "negative_interval", "monotone"):
            pass        # interval marks / emphasis / arrows are never drawn
        elif rel == "value_at":
            x = Q(f.rec["at"])
            pt(x, c.f(x))
        elif rel == "x_for_value":
            y = Q(f.rec["at"])
            for s in f.truth:
                pt(Q(s), y)
        elif rel == "intersection":
            for x, y in f.truth:
                pt(Q(x), Q(y))
        elif rel == "shift":
            tx("(%s, %s)" % (disp(cs[1].p - cs[0].p) or "",
                             disp(cs[1].k - cs[0].k) or ""))
        elif rel == "to_plot":
            cur = Curve.from_def(f.rec["curve"])
            F.curves.append((cur, fid))
            F.equations.append((cur, fid))
        elif rel == "plot_point":
            x, y = [Q(v) for v in f.rec["xy"]]
            pt(x, y)
    # (round 2) an UNDRAWN curve: its stroke, its equation in every form and
    # its key points (except where an optional mark -- a printed given --
    # sits); the hide block: strict
    for cid in sorted(M.undrawn):
        cur, tag = M.curves[cid], "undrawn:%s" % cid
        F.curves.append((cur, tag))
        F.equations.append((cur, tag))
        for t in all_equation_texts(cur):
            F.texts.append((t, tag))
        for x, y in key_points(cur):
            if M.given_at(x, y) is None:
                F.points.append((x, y, tag))
                for t in _pt_texts(x, y):
                    F.texts.append((t, tag))
    for x, y in M.hide_points:
        F.points.append((x, y, "hide"))
        for t in _pt_texts(x, y):
            F.texts.append((t, "hide"))
    for t in M.hide_texts:
        F.texts.append((t, "hide"))
    return F


def _tok_contains(s, t):
    """token match of SCORING s0 (comparison form: no white space)"""
    s2 = re.sub(r"\s+", "", s)
    t2 = re.sub(r"\s+", "", t)
    if not t2:
        return False
    i = s2.find(t2)
    while i >= 0:
        before = s2[i - 1] if i > 0 else ""
        after = s2[i + len(t2)] if i + len(t2) < len(s2) else ""
        after2 = s2[i + len(t2) + 1] if i + len(t2) + 1 < len(s2) else ""
        ok = True
        if t2[0].isdigit() and (before.isdigit() or before in
                                (".", MINUS) or before.isalpha() and
                                before.isascii()):
            ok = False
        if t2[0].isascii() and t2[0].isalpha() and (
                before.isascii() and before.isalnum()):
            ok = False
        if t2[-1].isdigit() and (after.isdigit() or (
                after == "." and after2.isdigit())):
            ok = False
        if t2[-1].isascii() and t2[-1].isalpha() and (
                after.isascii() and after.isalnum()):
            ok = False
        if ok:
            return True
        i = s2.find(t2, i + 1)
    return False


def _leak_rules(M, out):
    F = forbidden(M)
    win = M.win
    for mid in sorted(M.marks):
        x, y = M.marks[mid]
        for fx, fy, fid in F.points:
            if win.step_dist((x, y), (fx, fy)) < 0.25:
                out.append(GraphIssue("GRAPH_TARGET_DRAWN", mid, "a mark at "
                                      "(%s, %s), which find %s asks" % (
                                          cstr(x), cstr(y), fid)))
    for cid in sorted(M.curves):
        if cid in M.undrawn:
            continue            # never drawn (round 2)
        cur = M.curves[cid]
        for fc, fid in F.curves:
            if cur.same(fc):
                out.append(GraphIssue("GRAPH_TARGET_DRAWN", cid, "the curve "
                                      "%s, which find %s asks" % (
                                          fc.key(), fid)))
    texts = []
    for cid in sorted(M.curves):
        lab = M.crec[cid].get("label")
        t = curve_label_text(M.curves[cid], lab) if lab else None
        if t:
            texts.append((cid, t, lab))
    for mid in sorted(M.mrec):
        lab = M.mrec[mid].get("label")
        t = mark_label_text(lab, *M.marks[mid]) if lab else None
        if t:
            texts.append((mid, t, lab))
    for oid, t, lab in texts:
        for fc, fid in F.equations:
            if same_curve_as_text(fc, t):
                out.append(GraphIssue("GRAPH_TARGET_DRAWN", oid, "label %r "
                                      "is the equation find %s asks"
                                      % (t, fid)))
        for ft, fid in F.texts:
            if _tok_contains(t, ft):
                out.append(GraphIssue("GRAPH_TARGET_DRAWN", oid, "label %r "
                                      "states %r (find %s)" % (t, ft, fid)))
        for fb, fid in F.bare:
            if re.sub(r"\s+", "", t) == re.sub(r"\s+", "", fb):
                out.append(GraphIssue("GRAPH_TARGET_DRAWN", oid, "label %r "
                                      "is the answer of find %s" % (t, fid)))
    # an equation printed in the question text (stated_in) and asked
    for f in M.finds:
        if f.rel == "equation":
            cid = f.rec["args"][0]
            if M.crec[cid].get("stated_in"):
                out.append(GraphIssue("GRAPH_TARGET_DRAWN", cid, "its "
                                      "equation is stated in %s and asked by "
                                      "%s" % (M.crec[cid]["stated_in"],
                                              f.id)))


# ---------------------------------------------------------- projection ---
def _curve_public(M, cid):
    """a curve's numbers are public when nothing asks about it, or its
    equation is printed (label / stated in a text)"""
    rec = M.crec[cid]
    if rec.get("stated_in") or (rec.get("label") or {}).get("equation"):
        return True
    return not any(cid in f.rec["args"] for f in M.finds)


def _mark_public(M, mid):
    rec = M.mrec[mid]
    if (rec.get("label") or {}).get("coords"):
        return True
    if rec.get("optional") is True and M.undrawn:
        # (round 2) a datum the question's text prints, beside an undrawn
        # (asked) curve: the text states its place
        return True
    return all(_curve_public(M, c) for c in rec["on"]) and not (
        not rec["on"] and any(f.rel in ("plot_point",) for f in M.finds))


def checked(spec):
    """validate and raise GraphSpecError on any issue; -> Model"""
    issues, M = validate(spec)
    if issues:
        raise GraphSpecError(issues)
    return M


def public_model(spec):
    """the PUBLIC model of one graph figure (no answer, no hidden number)"""
    M = checked(spec)
    curves = []
    for cid in sorted(M.curves):
        if cid in M.undrawn:
            continue            # (round 2) never drawn, never public
        rec, cur = M.crec[cid], M.curves[cid]
        lab = rec.get("label")
        pc = {"id": cid, "fn": cur.fn, "style": rec["style"],
              "label": None if lab is None else (
                  {"name": lab["name"]} if "name" in lab else
                  {"equation": lab["equation"],
                   "text": equation_text(cur, lab["equation"])})}
        if _curve_public(M, cid):
            pc["def"] = cur.key()
            if rec.get("extent") is not None:
                pc["extent"] = [cstr(v) for v in rec["extent"]]
        if rec.get("symmetry_of"):
            pc["symmetry_of"] = rec["symmetry_of"]
        curves.append(pc)
    marks = []
    for mid in sorted(M.mrec):
        rec = M.mrec[mid]
        x, y = M.marks[mid]
        lab = rec.get("label")
        pm = {"id": mid, "kind": rec["kind"],
              "on": sorted(c for c in rec["on"] if c not in M.undrawn),
              "label": None if lab is None else dict(
                  [(k, lab[k]) for k in sorted(lab)] +
                  [("text", mark_label_text(lab, x, y))]),
              "guides": sorted(rec.get("guides") or [])}
        if rec.get("optional"):
            pm["optional"] = True
        if _mark_public(M, mid):
            pm["xy"] = [cstr(x), cstr(y)]
        marks.append(pm)
    finds = []
    for f in M.finds:
        # (round 2) an undrawn curve is no public object: a find on it
        # names only the drawn curves it asks about
        pf = {"id": f.id, "item": f.rec["item"], "rel": f.rel,
              "args": [a for a in f.rec["args"] if a not in M.undrawn]}
        if "at" in f.rec:
            pf["at"] = cstr(Q(f.rec["at"]))
        finds.append(pf)
    pub = {"graph_public": PUBLIC_VERSION, "figure": spec["figure"],
           "frame": public_frame(spec["frame"]),
           "axes": {a: {"letter": spec["axes"][a]["letter"],
                        "title": spec["axes"][a]["title"]}
                    for a in ("x", "y")},
           "aspect": spec["aspect"], "curves": curves, "marks": marks,
           "parallel": sorted(sorted(p["curves"]) for p in
                              spec.get("parallel") or [] if p["stated"]),
           "finds": sorted(finds, key=lambda f: f["id"])}
    if M.givens:
        pub["givens"] = True        # (round 2) only when true: old hashes
    pub["public_hash"] = public_hash(pub)
    return pub


def public_hash(pub):
    body = dict((k, v) for k, v in pub.items() if k != "public_hash")
    return hashlib.sha256(canon.dumps(body).encode("utf-8")).hexdigest()


def display_layout(spec):
    """the display settings' "curves" / "marks" entries: the numbers of
    every curve / mark the public model does not carry (only the renderer
    reads them)"""
    M = checked(spec)
    cs, ms = [], []
    for cid in sorted(M.curves):
        if cid in M.undrawn:
            continue            # (round 2) never drawn: no place at all
        if not _curve_public(M, cid):
            e = {"curve": cid, "def": M.curves[cid].key()}
            if M.crec[cid].get("extent") is not None:
                e["extent"] = [cstr(v) for v in M.crec[cid]["extent"]]
            cs.append(e)
    for mid in sorted(M.mrec):
        if not _mark_public(M, mid):
            x, y = M.marks[mid]
            ms.append({"mark": mid, "xy": [cstr(x), cstr(y)]})
    return {"curves": cs, "marks": ms}


def private_model(spec):
    """answers + the full numbers (the harness side; never rendered)"""
    M = checked(spec)
    out = {"figure": spec["figure"],
            "answers": dict((f.id, f.truth) for f in M.finds),
            "curves": dict((cid, M.curves[cid].key()) for cid in M.curves),
            "marks": dict((mid, [cstr(M.marks[mid][0]),
                                 cstr(M.marks[mid][1])])
                          for mid in M.marks),
            "answer_guard": forbidden(M).as_guard()}
    if M.undrawn:
        out["undrawn"] = sorted(M.undrawn)      # (round 2)
    return out


def answer_guard(spec):
    return private_model(spec)["answer_guard"]


# ------------------------------------------------------ from_neutral ---
def _neutral_numbers(nums):
    out = []
    for s in nums:
        q = Q(s)
        if q is None:
            raise GraphSpecError([GraphIssue("GRAPH_BAD_NUMBER", "numbers",
                                             repr(s))])
        out.append(cstr(q))
    return out


def _neutral_label(cur, label, where):
    """a printed label -> the author label that prints EXACTLY it"""
    if label is None:
        return None
    if CURVE_NAME_RE.match(label):
        return {"name": label}
    for form in EQ_FORMS[cur.fn]:
        if equation_text(cur, form) == label:
            return {"equation": form}
    raise GraphSpecError([GraphIssue("GRAPH_LABEL_BAD", where, "no label "
                                     "form prints %r exactly" % label)])


def _neutral_mark_label(label, x, y, where):
    if label is None:
        return None
    if coords_text(x, y) == label:
        return {"coords": True}
    m = re.match(r"^([A-Z][1-9]?'{0,3})(\(.*\))?\Z", label)
    if m and (m.group(2) is None or coords_text(x, y) == m.group(2)):
        return {"name": m.group(1), "coords": True} if m.group(2) else \
            {"name": m.group(1)}
    raise GraphSpecError([GraphIssue("GRAPH_LABEL_BAD", where, "no label "
                                     "form prints %r exactly" % label)])


def from_neutral(neutral, figure="fig"):
    """the corpus's engine-neutral figure spec (corpus_graph synthetic
    source.spec, or a baseline figure) -> an author spec. It ADDS NOTHING:
    every printed text must come out exactly (else GRAPH_LABEL_BAD), no
    find, no guide, no label is invented. A parabola with a != 1 is
    refused (GRAPH_NOT_A1)."""
    win, grid = neutral["window"], neutral["grid"]
    axes = []
    for a, nums in (("x", neutral["x_numbers"]), ("y", neutral["y_numbers"])):
        lo, hi = win[a]
        axes.append({"axis": "axis:" + a, "min": cstr(Q(str(lo))),
                     "max": cstr(Q(str(hi))), "step": cstr(Q(str(grid[a]))),
                     "label_at": _neutral_numbers(nums)})
    names = neutral.get("axis_names") or {"x": "x", "y": "y"}
    ax = {}
    for a in ("x", "y"):
        n = names.get(a)
        ax[a] = {"letter": True, "title": None} if n == a else \
            {"letter": False, "title": n}
    asp = neutral.get("aspect")
    if isinstance(asp, dict):
        asp = asp.get("rule")
    curves, idmap = [], {}
    for n, c in enumerate(neutral.get("curves") or []):
        tok = c["id"].split(":", 1)[1] if ":" in c["id"] else c["id"]
        cid = "curve:" + re.sub(r"[^A-Za-z0-9]", "", tok)[:8]
        idmap[c["id"]] = cid
        kind = c["kind"]
        if kind == "parabola":
            if Q(str(c.get("a", 1))) != 1:
                raise GraphSpecError([GraphIssue("GRAPH_NOT_A1", c["id"],
                                                  "a = %r" % c.get("a"))])
            rec = {"id": cid, "fn": "parabola", "p": cstr(Q(str(c["p"]))),
                   "k": cstr(Q(str(c["k"])))}
        elif kind == "vline":
            rec = {"id": cid, "fn": "vline", "x": cstr(Q(str(c["x"])))}
        else:
            m = Q(c["m_exact"].replace(MINUS, "-")) if c.get("m_exact") \
                else Q(str(c["m"]))
            if m is None:
                raise GraphSpecError([GraphIssue("GRAPH_BAD_NUMBER",
                                                  c["id"], "m")])
            rec = {"id": cid, "fn": "line", "m": cstr(m),
                   "b": cstr(Q(str(c["b"])))}
        cur = Curve.from_def(dict((k, v) for k, v in rec.items()
                                  if k in ("fn", "m", "b", "x", "p", "k")))
        rec["style"] = c.get("style") or "solid"
        rec["label"] = _neutral_label(cur, c.get("label"), c["id"])
        curves.append(rec)
    marks = []
    for n, mk in enumerate(neutral.get("marks") or []):
        x, y = Q(str(mk["xy"][0])), Q(str(mk["xy"][1]))
        on = mk.get("on")
        on = [on] if isinstance(on, str) else list(on or [])
        mid = "mark:%s%d" % ({"vertex": "V", "zero": "Z", "y_intercept": "Y",
                              "point": "P", "intersection": "I"}.get(
                                  mk.get("mark_kind"), "M"), n + 1)
        on_ids = [idmap[o] for o in on if o in idmap]
        kind = mk.get("mark_kind") or "point"
        if kind == "intersection" and len(on_ids) < 2:
            # the corpus names one curve (or none): the curves it lies on
            on_ids = sorted(cid for cid, rec in zip(
                [r["id"] for r in curves], curves)
                if Curve.from_def(dict((k, v) for k, v in rec.items()
                                       if k in ("fn", "m", "b", "x", "p",
                                                "k"))).on(x, y))
        elif not on_ids and kind in ("vertex", "zero", "y_intercept"):
            on_ids = [r["id"] for r in curves if Curve.from_def(dict(
                (k, v) for k, v in r.items()
                if k in ("fn", "m", "b", "x", "p", "k"))).on(x, y)][:1]
        marks.append({"id": mid, "kind": kind, "on": on_ids,
                      "x": cstr(x), "y": cstr(y),
                      "label": _neutral_mark_label(mk.get("label"), x, y,
                                                   mid)})
    par = [{"curves": [idmap[a], idmap[b]], "stated": False}
           for a, b in neutral.get("parallel") or []]
    return {"graph_version": GRAPH_VERSION, "figure": figure,
            "frame": {"family": "coordinate_plane", "plane": "plane:xy",
                      "grid": True, "axes": axes},
            "axes": ax, "aspect": (asp or "FREE").lower(),
            "curves": curves, "marks": marks, "parallel": par, "finds": []}
