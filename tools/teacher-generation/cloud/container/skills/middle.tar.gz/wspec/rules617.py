# -*- coding: utf-8 -*-
u"""v6.17-noam (BRIEF_V617 V1 + V2): the triangle_polygon vocabulary two of
the 18 packages still needed, CHECKED -- not only named.

  V1  G7-T14  the class "obtuse triangle" (משולש קהה־זוויות: a relation, a
              classify answer and a shape the figure checks measure) and the
              rule "the angles of a quadrilateral sum to 360°"
  V2  G9-T15  the angle rules between parallel lines as the sources use them
              -- alternate (מתחלפות, equal), corresponding (מתאימות, equal),
              co-interior (חד־צדדיות, together 180°) -- and the isosceles
              converse (two equal angles: the sides opposite them are equal)

A derived fact names its rule (source {kind: derived, rule, from}). Before
v6.17 a rule was a NAME only: schema.RULES was a registry and nothing read
whether the rule could apply or what it gives. For the five rules below this
module checks both, from the spec alone (validate_rules, run by
schema.validate):

  RULE_NOT_APPLICABLE   the configuration is not the rule's: the 360° rule
                        on an angle that is no interior angle of a
                        quadrilateral (the planted case: on a triangle), or
                        from facts that are not its other three angles; a
                        parallel rule whose angles do not sit at the two
                        crossings of one transversal with two lines that the
                        from facts make parallel; the isosceles converse
                        without two equal angles of one triangle, or
                        concluding sides that are not the ones opposite them
  RULE_VALUE_MISMATCH   the value is not the rule's: 360 − (the other three);
                        the same angle (alternate / corresponding); 180 − it
                        (co-interior); two "equal" angles that differ
  RULE_CONFIG_MISMATCH  the wrong parallel rule for the pair: the three are
                        told apart by the directions of the two angles' arms
                        along the transversal and along the parallels. From
                        the spec, the transversal directions follow from its
                        betweenness facts (on_segment / midpoint); on a
                        FIGURE, figure_issues reads all four directions off
                        the drawn points (geomcheck.check_geometry calls it)

  angle_bisector (the step G9-T15's chains need between a given bisector
  and the parallel rules): the fact is one half of a bisected angle, its
  from facts the bisector (two equal halves sharing a ray) and the whole
  angle's measure -> half of it. triangle_angle_sum (a pre-v6.17 rule)
  is checked in its FULL form only (the other two interior angles as from
  facts: 180° minus them); its looser earlier uses (G9-T18: from one angle
  and a rectangle's corner) are left as they were.

ANGLE IDENTITY. Point names are sheet-wide, so every check reads ONE
question: its lines (segments, lines, rays, angle arms, on_segment /
midpoint -- which also give betweenness) and its polygons (named by its
facts, figures or bound prose). Within it, the ray from V through X is the
ray from V through Y when X and Y are on one line with V and on the same
side of it: with E on BA, ∠EBD is ∠ABD. Equal angles join one class
(transitively) for the isosceles converse.

and two recomputations that need no declared rule at all:

  ANSWER_RULE_MISMATCH      an answer to an interior angle of a triangle /
                            quadrilateral whose other angles the question
                            fixes (givens, derived steps, answers of the
                            same or earlier items) is not 180° / 360° minus
                            their sum
  CLASSIFY_ANGLES_MISMATCH  a triangle's class by its angles -- acute / right
                            / obtuse, answered (classify) or stated -- that
                            its known angles contradict

Exact arithmetic (fractions) only; an angle whose value is not an exact
rational number is not read. Nothing here prints anything: the rules are
private derivation steps (role derived) unless a release makes one public.

printed_by_figure (called by templates.render_spec): a PLANE figure prints
the value labels of the stated given angles / lengths it draws when the
question's bound prose announces them by count -- G7-T14 a q9 states its
three angles only in the drawing ("ובו שלוש זוויות נתונות"), as v6.16's pie
prints its data; an unannounced drawn given stays STATED_NOT_PRINTED. selfcheck_v617_rules.py proves every rule
here with a passing and a planted failing case on REAL questions of G7-T14
and G9-T15 (fixtures/v617_rules).
"""
from collections import Counter
from fractions import Fraction

from . import canon
from .errors import Issue, REASONS

# rule -> what it says (merged into schema.RULES)
RULES617 = {
    "quadrilateral_angle_sum": "angle sum of a quadrilateral (360°)",
    "alternate_angles": "alternate angles between parallel lines are "
                        "equal",
    "corresponding_angles": "corresponding angles between parallel lines "
                            "are equal",
    "co_interior_angles": "co-interior angles between parallel lines sum "
                          "to 180°",
    "isosceles_converse": "a triangle with two equal angles is isosceles: "
                          "the sides opposite them are equal",
    # the step the G9-T15 chains need between a given bisector and the
    # parallel rules (25 of its 72 source questions bisect an angle)
    "angle_bisector": "a bisector halves its angle",
}
# rule -> the curriculum tool it is (curriculum_tools.json ids, the
# didactic allowed_tools of an item that uses it)
RULE_TOOLS = {
    "quadrilateral_angle_sum": "thm.quad_angle_sum",
    "alternate_angles": "thm.alternate_angles",
    "corresponding_angles": "thm.corresponding_angles",
    "co_interior_angles": "thm.co_interior_angles",
    "isosceles_converse": "thm.isosceles_converse",
    "angle_bisector": "thm.angle_bisector",
}
PARALLEL_RULES = ("alternate_angles", "corresponding_angles",
                  "co_interior_angles")
# the classes of a triangle by its angles
ANGLE_CLASSES = ("acute_triangle", "right_triangle", "obtuse_triangle")

REASONS617 = {
    "RULE_NOT_APPLICABLE": "a derived fact names a rule whose configuration "
    "its facts do not have: the 360° rule on an angle that is no interior "
    "angle of a quadrilateral (a triangle's angle) or from facts that are not "
    "its other three angles; a parallel-lines rule whose two angles do not "
    "sit at the crossings of one transversal with two lines its from facts "
    "make parallel (one arm on the transversal, the other on the angle's own "
    "line); the isosceles converse without two equal angles of one triangle "
    "among its from facts, or concluding sides that are not the ones "
    "opposite them",
    "RULE_VALUE_MISMATCH": "a derived fact's value is not what its rule "
    "gives from its from facts: 360° minus the other three angles; the same "
    "angle (alternate / corresponding); 180° minus it (co-interior); or the "
    "two 'equal' angles of the isosceles converse differ",
    "RULE_CONFIG_MISMATCH": "a parallel-lines rule names the wrong pair: "
    "alternate angles have their arms opposite along the transversal and "
    "along the parallels, corresponding ones the same way along both, "
    "co-interior ones opposite along the transversal (towards each other) "
    "and the same way along the parallels -- read from the spec's "
    "betweenness facts or, on a figure, from the drawn points",
    "ANSWER_RULE_MISMATCH": "an answer to an interior angle of a triangle / "
    "quadrilateral whose other angles the question fixes (givens, derived "
    "steps, answers of the same or earlier items) is not 180° / 360° minus "
    "their sum",
    "CLASSIFY_ANGLES_MISMATCH": "a triangle's class by its angles (acute / "
    "right / obtuse; a classify answer or a stated class) that its known "
    "angles contradict",
}
for _k, _v in REASONS617.items():
    REASONS.setdefault(_k, _v)

ANGLE_SUM = {3: Fraction(180), 4: Fraction(360)}


# ------------------------------------------------------------ reading ---
def exact_deg(f):
    """The exact rational value of a fact, or None (no value, a surd)."""
    v = (f or {}).get("value")
    if v is None or isinstance(v, bool):
        return None
    try:
        a, b, _r = canon.parse_exact(v)
    except Exception:            # noqa: BLE001 -- schema reports it
        return None
    return a if b == 0 else None


def _ent(ix, eid):
    return ix.entities.get(eid) if isinstance(eid, str) else None


def angle_parts(ix, aid):
    """(vertex, (arm0, arm1)) of an angle entity, else None."""
    e = _ent(ix, aid) or {}
    arms = e.get("arms")
    if e.get("kind") != "angle" or not isinstance(arms, list) or \
            len(arms) != 2:
        return None
    return e.get("vertex"), tuple(arms)


def _point_vertices(ix, pid):
    """The vertex NAMES of a polygon whose vertices are named points."""
    e = _ent(ix, pid) or {}
    vs = e.get("vertices") or []
    if e.get("kind") != "polygon" or not all(
            (_ent(ix, v) or {}).get("kind") == "point" for v in vs):
        return []
    return [ix.entities[v]["name"] for v in vs]


def interior_at(ix, aid, vs):
    """The index of the vertex at which angle aid is the interior angle of
    the polygon with vertex names vs, else None."""
    ap = angle_parts(ix, aid)
    if ap is None or ap[0] not in vs:
        return None
    i = vs.index(ap[0])
    if set(ap[1]) != set([vs[i - 1], vs[(i + 1) % len(vs)]]):
        return None
    return i


def polygons_of(ix, aid):
    """[(polygon id, vertex names, index)] of the polygons (point vertices)
    angle aid is an interior angle of."""
    out = []
    for pid in sorted(ix.entities):
        vs = _point_vertices(ix, pid)
        if len(vs) >= 3:
            i = interior_at(ix, aid, vs)
            if i is not None:
                out.append((pid, vs, i))
    return out


def _interior_id(ix, vs, i):
    """The id of the angle entity that is the interior angle at vs[i]."""
    for aid, e in ix.entities.items():
        if e.get("kind") == "angle" and interior_at(ix, aid, vs) == i:
            return aid
    return None


# ------------------------------------------------ lines and betweenness ---
def question_entities(ix, qid):
    """The entities question qid speaks of: the arguments of its facts and
    what its figures list, with everything they reference (all entities
    when qid is None)."""
    if qid is None:
        return set(ix.entities)
    from .schema import entity_closure
    out = set()
    for f in ix.facts.values():
        if ix.scope_question.get(f.get("item")) == qid:
            for a in f.get("args") or []:
                out |= entity_closure(a, ix)
    for g in ix.figures.values():
        if ix.scope_question.get(g.get("scope")) == qid:
            for a in g.get("entities") or []:
                out |= entity_closure(a, ix)
    # the names its bound prose prints ("בשרטוט מרובע ABCD": the polygon
    # no fact names)
    try:
        from .schema_bound import blocks_of, bound_entities
        for sid, _at, blk in blocks_of(ix.spec):
            if isinstance(blk, dict) and \
                    ix.scope_question.get(sid) == qid:
                for a in bound_entities(blk):
                    if a in ix.entities:
                        out |= entity_closure(a, ix)
    except Exception:            # noqa: BLE001 -- malformed blocks
        pass
    return set(x for x in out if x in ix.entities)


class _Ctx(object):
    """Per question: its Lines, its Angles and its polygons' interior keys."""

    def __init__(self, ix):
        self.ix, self.cache = ix, {}

    def __call__(self, scope):
        qid = self.ix.scope_question.get(scope)
        if qid not in self.cache:
            L = Lines(self.ix, qid)
            A = Angles(self.ix, L)
            self.cache[qid] = (L, A, interior_keys(self.ix, A, L.ents))
        return self.cache[qid]
class Lines(object):
    """What the spec says about collinearity and order: every segment /
    line / ray entity and every angle arm is a line through its two points;
    an on_segment / midpoint fact (given, derived or context -- a claim the
    spec states as true) puts its point on that segment, strictly BETWEEN
    its ends. Groups that share two points are one line."""

    ROLES = ("given", "derived", "context")

    def __init__(self, ix, qid=None):
        """qid: the question whose entities and facts are read (point
        names are sheet-wide entities: "A" of q1 is "A" of q9 -- lines of
        one question say nothing about another's); None: the whole spec."""
        groups = []
        self.between = set()        # (mid, end, end) mid strictly between
        self.ents = question_entities(ix, qid)
        facts = [f for f in ix.facts.values()
                 if qid is None or ix.scope_question.get(f.get("item")) == qid]
        for eid in sorted(self.ents):
            e = ix.entities.get(eid) or {}
            k = e.get("kind")
            if k == "segment":
                groups.append(set(e.get("ends") or []))
            elif k == "line":
                groups.append(set(e.get("through") or []))
            elif k == "ray":
                groups.append(set([e.get("from"), e.get("through")]))
            elif k == "angle":
                for a in e.get("arms") or []:
                    groups.append(set([e.get("vertex"), a]))
        for f in facts:
            if f.get("rel") not in ("on_segment", "midpoint") or \
                    f.get("role") not in self.ROLES:
                continue
            args = f.get("args") or []
            if len(args) != 2:
                continue
            p = (_ent(ix, args[0]) or {}).get("name")
            ends = (_ent(ix, args[1]) or {}).get("ends") or []
            if p and len(ends) == 2:
                groups.append(set([p] + list(ends)))
                self.between.add((p, ends[0], ends[1]))
                self.between.add((p, ends[1], ends[0]))
        groups = [g for g in groups if len(g) >= 2 and None not in g]
        merged = True
        while merged:
            merged = False
            for i in range(len(groups)):
                for j in range(i + 1, len(groups)):
                    if len(groups[i] & groups[j]) >= 2:
                        groups[i] |= groups.pop(j)
                        merged = True
                        break
                if merged:
                    break
        self.groups = [frozenset(g) for g in groups]

    def line_of(self, *pts):
        """The group holding all of pts, else None."""
        want = set(pts)
        for g in self.groups:
            if want <= g:
                return g
        return None

    def side(self, v, x, w):
        """+1 when x lies on the same side of v as w (on their common line),
        -1 on the other side, None when the spec does not say."""
        if x == w:
            return 1
        if (v, x, w) in self.between:
            return -1               # v between x and w
        if (x, v, w) in self.between or (w, v, x) in self.between:
            return 1                # x between v and w, or w between v and x
        return None


# ----------------------------------------------------- the rule checks ---
def _where(f):
    return "fact %s" % f.get("id")


def _src(f):
    s = f.get("source") or {}
    return s.get("rule") if s.get("kind") == "derived" else None


def _from(ix, f):
    return [ix.facts[x] for x in (f.get("source") or {}).get("from") or []
            if x in ix.facts]


def _check_quad(ix, f, L, out):
    w = _where(f)
    if f.get("rel") != "angle_measure":
        out.append(Issue("RULE_NOT_APPLICABLE", w, "quadrilateral_angle_sum "
                         "gives an angle's measure, not %s" % f.get("rel")))
        return
    A = Angles(ix, L)
    me = A.key((f.get("args") or [None])[0])
    polys = [(pid, vs) for pid, vs, keys in interior_keys(ix, A, L.ents)
             if me in keys]
    if not any(len(vs) == 4 for _p, vs in polys):
        tri = [pid for pid, vs in polys if len(vs) == 3]
        out.append(Issue("RULE_NOT_APPLICABLE", w, "the 360° rule on %s, "
                         "which is %s" % (f["args"][0], (
                             "an angle of the triangle %s (180°)" % tri[0])
                             if tri else "no interior angle of a "
                             "quadrilateral")))
        return
    src = [g for g in _from(ix, f) if g.get("rel") == "angle_measure"]
    if len(src) == 3 and len(_from(ix, f)) == 3 and \
            _sum_check(ix, f, A, src, 4, w, out, "quadrilateral_angle_sum"):
        return
    out.append(Issue("RULE_NOT_APPLICABLE", w, "the from facts are not the "
                     "other three angles of %s" % [
                         pid for pid, vs in polys if len(vs) == 4][0]))


def _lin_points(ix, eid, L):
    """The collinear group of a linear entity (segment / line / ray)."""
    e = _ent(ix, eid) or {}
    k = e.get("kind")
    two = (e.get("ends") if k == "segment" else e.get("through")
           if k == "line" else [e.get("from"), e.get("through")]
           if k == "ray" else None)
    if not two or len(two) != 2:
        return None
    return L.line_of(*two) or frozenset(two)


def _parallel_classes(ix, pars, L):
    """[(group, class id)]: the lines the parallel facts name, the lines a
    chain of parallel facts connects in one class (a ∥ b, b ∥ c)."""
    lines, cls = [], {}

    def find(i):
        while cls[i] != i:
            i = cls[i]
        return i
    for p in pars:
        idx = []
        for a in (p.get("args") or [])[:2]:
            g = _lin_points(ix, a, L)
            if g is None:
                idx = []
                break
            if g not in lines:
                lines.append(g)
                cls[len(lines) - 1] = len(lines) - 1
            idx.append(lines.index(g))
        if len(idx) == 2:
            cls[find(idx[0])] = find(idx[1])
    return [(g, find(i)) for i, g in enumerate(lines)]


def parallel_config(ix, f, L=None):
    """The configuration a parallel-lines rule fact claims, from the spec:
    (config, problem). config = {V1, X1, Y1, V2, X2, Y2}: the from angle at
    V1 with its transversal arm X1 and its parallel arm Y1, the claimed
    angle at V2 likewise; problem = '' or why the rule cannot apply."""
    L = L or Lines(ix, ix.scope_question.get(f.get("item")))
    rel = f.get("rel")
    frm = _from(ix, f)
    pars = [g for g in frm if g.get("rel") == "parallel"]
    if not pars:
        return None, "no parallel fact among its from facts"
    if rel == "angle_measure":
        src = [g for g in frm if g.get("rel") == "angle_measure"]
        if len(src) != 1:
            return None, ("%d angle facts among its from facts (one: the "
                          "angle it is derived from)" % len(src))
        a_from, a_to = src[0]["args"][0], f["args"][0]
    elif rel == "equal_angle":
        if f.get("source", {}).get("rule") == "co_interior_angles":
            return None, "co-interior angles are not equal (they sum to 180°)"
        a_from, a_to = (f.get("args") or [None, None])[:2]
    else:
        return None, "the rule gives an angle's measure or two equal " \
                     "angles, not %s" % rel
    p1, p2 = angle_parts(ix, a_from), angle_parts(ix, a_to)
    if p1 is None or p2 is None:
        return None, "not two angles"
    v1, v2 = p1[0], p2[0]
    if v1 == v2:
        return None, "both angles at %s (one crossing, no transversal " \
                     "between two lines)" % v1
    classes = _parallel_classes(ix, pars, L)
    on1 = [(g, c) for g, c in classes if v1 in g]
    on2 = [(g, c) for g, c in classes if v2 in g]
    pair = [(g1, g2) for g1, c1 in on1 for g2, c2 in on2
            if c1 == c2 and g1 != g2]
    if not pair:
        return None, ("%s and %s are not on two lines the from facts make "
                      "parallel" % (v1, v2))
    g1, g2 = pair[0]
    if v2 in g1 or v1 in g2:
        return None, "the transversal %s%s is one of the parallel lines" % (
            v1, v2)
    tr = L.line_of(v1, v2) or frozenset([v1, v2])

    def arms(parts, g):
        v, (a, b) = parts
        on_t = [x for x in (a, b) if x in tr and x != v]
        on_g = [x for x in (a, b) if x in g and x != v]
        if len(on_t) == 1 and len(on_g) == 1 and on_t != on_g:
            return on_t[0], on_g[0]
        return None
    r1, r2 = arms(p1, g1), arms(p2, g2)
    if r1 is None or r2 is None:
        bad = a_from if r1 is None else a_to
        return None, ("%s does not have one arm on the transversal %s and "
                      "the other on its own parallel line" % (
                          bad, "".join(sorted(tr))))
    return {"V1": v1, "X1": r1[0], "Y1": r1[1], "V2": v2, "X2": r2[0],
            "Y2": r2[1], "from": a_from, "to": a_to}, ""


def _want_signs(rule):
    """(transversal sign, parallel sign) of the rule's pair: +1 the two
    arms point the same way, -1 opposite ways."""
    return {"alternate_angles": (-1, -1), "corresponding_angles": (1, 1),
            "co_interior_angles": (-1, 1)}[rule]


def _config_name(st, sp):
    return {(-1, -1): "alternate", (1, 1): "corresponding",
            (-1, 1): "co-interior", (1, -1): "(corresponding, reversed "
            "along the parallels: supplementary)"}.get((st, sp), "?")


def _check_parallel(ix, f, rule, L, out):
    w = _where(f)
    cfg, why = parallel_config(ix, f, L)
    if cfg is None:
        out.append(Issue("RULE_NOT_APPLICABLE", w, "%s: %s" % (rule, why)))
        return
    # the transversal directions, when the spec's order facts fix them
    s1 = L.side(cfg["V1"], cfg["X1"], cfg["V2"])     # X1 towards V2: +1
    s2 = L.side(cfg["V2"], cfg["X2"], cfg["V1"])     # X2 towards V1: +1
    want_t, _want_p = _want_signs(rule)
    if s1 is not None and s2 is not None:
        # a_t = s1 * t, b_t = -s2 * t  ->  a_t . b_t has the sign -s1*s2
        st = -s1 * s2
        if st != want_t:
            out.append(Issue("RULE_CONFIG_MISMATCH", w, "%s: along the "
                             "transversal the arms %s%s and %s%s point %s "
                             "ways (the spec's order facts)" % (
                                 rule, cfg["V1"], cfg["X1"], cfg["V2"],
                                 cfg["X2"], "the same" if st > 0 else
                                 "opposite")))
        elif rule == "co_interior_angles" and s1 != 1:
            out.append(Issue("RULE_CONFIG_MISMATCH", w, "co_interior_angles:"
                             " the arms %s%s and %s%s point away from each "
                             "other (co-exterior, not co-interior)" % (
                                 cfg["V1"], cfg["X1"], cfg["V2"],
                                 cfg["X2"])))
    if f.get("rel") != "angle_measure":
        return
    src = [g for g in _from(ix, f) if g.get("rel") == "angle_measure"][0]
    a, b = exact_deg(src), exact_deg(f)
    if a is None or b is None:
        return
    want = Fraction(180) - a if rule == "co_interior_angles" else a
    if b != want:
        out.append(Issue("RULE_VALUE_MISMATCH", _where(f), "%s from %s = %s "
                         "gives %s, not %s" % (rule, src["args"][0], a, want,
                                               b)))


# ------------------------------------------ angles as rays (identity) ---
class Angles(object):
    """An angle as the spec knows it: a vertex and two RAYS. The ray from V
    through X is the ray from V through Y when V, X, Y are on one line and
    X, Y on the same side of V (Lines.side): with E on AB, ∠EBD is ∠ABD.
    Equal angles (equal_angle facts) join one class, transitively."""

    def __init__(self, ix, L):
        self.ix, self.L = ix, L
        self.parent = {}

    def ray(self, v, x):
        g = self.L.line_of(v, x)
        if not g:
            return (v, x)
        same = sorted(y for y in g if y != v and self.L.side(v, y, x) == 1)
        return (v, same[0] if same else x)

    def key(self, aid):
        ap = angle_parts(self.ix, aid)
        if ap is None:
            return None
        v, (a, b) = ap
        return (v, frozenset([self.ray(v, a), self.ray(v, b)]))

    def key_at(self, v, a, b):
        return (v, frozenset([self.ray(v, a), self.ray(v, b)]))

    def find(self, k):
        self.parent.setdefault(k, k)
        while self.parent[k] != k:
            k = self.parent[k]
        return k

    def join(self, k1, k2):
        self.parent[self.find(k1)] = self.find(k2)


def _evidence(ix, frm, A):
    """(classes, values) the from facts give: equal_angle facts join their
    angles' classes; angle_measure facts give values (key -> set)."""
    vals = {}
    for g in frm:
        args = list(g.get("args") or [])
        if g.get("rel") == "equal_angle" and len(args) == 2:
            k1, k2 = A.key(args[0]), A.key(args[1])
            if k1 and k2:
                A.join(k1, k2)
        elif g.get("rel") == "angle_measure" and args:
            k, v = A.key(args[0]), exact_deg(g)
            if k and v is not None:
                vals.setdefault(k, set()).add(v)
    return vals


def _equal_by(A, vals, k1, k2):
    """True / False (values differ) / None (nothing says) for k1 = k2."""
    if A.find(k1) == A.find(k2):
        return True

    def val(k):
        got = set()
        for kk, vs in vals.items():
            if A.find(kk) == A.find(k):
                got |= vs
        return got
    v1, v2 = val(k1), val(k2)
    if len(v1) == 1 and len(v2) == 1:
        return v1 == v2
    return None


def _check_isosceles_converse(ix, f, L, out):
    w = _where(f)
    rel = f.get("rel")
    args = list(f.get("args") or [])
    if rel == "equal_length" and len(args) == 2:
        s1 = set((_ent(ix, args[0]) or {}).get("ends") or [])
        s2 = set((_ent(ix, args[1]) or {}).get("ends") or [])
        common = s1 & s2
        if len(s1) != 2 or len(s2) != 2 or len(common) != 1:
            out.append(Issue("RULE_NOT_APPLICABLE", w, "isosceles_converse:"
                             " the two segments are not two sides of one "
                             "triangle from a common vertex"))
            return
        x = list(common)[0]
        tris = [(x, list(s1 - common)[0], list(s2 - common)[0])]
    elif rel == "isosceles" and args:
        vs = _point_vertices(ix, args[0])
        if len(vs) != 3:
            out.append(Issue("RULE_NOT_APPLICABLE", w, "isosceles_converse:"
                             " %s is no triangle" % args[0]))
            return
        tris = [(vs[i], vs[i - 1], vs[(i + 1) % 3]) for i in range(3)]
    else:
        out.append(Issue("RULE_NOT_APPLICABLE", w, "isosceles_converse "
                         "concludes two equal sides or an isosceles "
                         "triangle, not %s" % rel))
        return
    A = Angles(ix, L)
    vals = _evidence(ix, _from(ix, f), A)
    verdicts = []
    for x, y, z in tris:
        # the sides XY, XZ are opposite the angles at Z and at Y
        verdicts.append(((x, y, z), _equal_by(A, vals, A.key_at(y, x, z),
                                              A.key_at(z, x, y))))
    if any(v is True for _t, v in verdicts):
        return
    bad = [t for t, v in verdicts if v is False]
    if bad:
        x, y, z = bad[0]
        out.append(Issue("RULE_VALUE_MISMATCH", w, "isosceles_converse: the "
                         "angles at %s and at %s (opposite %s%s and %s%s) "
                         "are not equal by the from facts" % (
                             y, z, x, z, x, y)))
        return
    x, y, z = tris[0]
    out.append(Issue("RULE_NOT_APPLICABLE", w, "isosceles_converse: no from "
                     "fact makes the angles at %s and at %s of △%s%s%s equal "
                     "(the angles opposite the sides it concludes equal)"
                     % (y, z, x, y, z)))


def _check_bisector(ix, f, L, out):
    """angle_bisector: a bisector halves its angle. f = the measure of one
    half; from = the bisector (equal_angle of the two halves at one vertex,
    sharing their inner ray) and the measure of the whole angle."""
    w = _where(f)
    if f.get("rel") != "angle_measure":
        out.append(Issue("RULE_NOT_APPLICABLE", w, "angle_bisector gives a "
                         "half angle's measure, not %s" % f.get("rel")))
        return
    A = Angles(ix, L)
    frm = _from(ix, f)
    me = A.key((f.get("args") or [None])[0])
    for g in frm:
        if g.get("rel") != "equal_angle" or len(g.get("args") or []) != 2:
            continue
        h1, h2 = A.key(g["args"][0]), A.key(g["args"][1])
        if not h1 or not h2 or h1[0] != h2[0] or me not in (h1, h2):
            continue
        inner = h1[1] & h2[1]
        if len(inner) != 1:
            continue
        outer = (h1[1] | h2[1]) - inner
        whole = (h1[0], frozenset(outer))
        for m in frm:
            if m.get("rel") == "angle_measure" and \
                    A.key((m.get("args") or [None])[0]) == whole:
                a, b = exact_deg(m), exact_deg(f)
                if a is not None and b is not None and a / 2 != b:
                    out.append(Issue("RULE_VALUE_MISMATCH", w, "half of %s "
                                     "is %s, not %s" % (a, a / 2, b)))
                return
    out.append(Issue("RULE_NOT_APPLICABLE", w, "angle_bisector: the from "
                     "facts are not a bisector (two equal halves sharing a "
                     "ray, one of them this angle) and its whole angle"))


def interior_keys(ix, A, ents=None):
    """[(polygon id, vertex names, [interior angle key per vertex])] of the
    polygons whose vertices are named points (angle identity: the interior
    angle at B of △ABD is ∠ABD however the spec names it -- ∠ABC when D is
    on BC)."""
    out = []
    for pid in sorted(ix.entities if ents is None else ents):
        vs = _point_vertices(ix, pid)
        n = len(vs)
        if n >= 3:
            out.append((pid, vs, [A.key_at(vs[i], vs[i - 1], vs[(i + 1) % n])
                                  for i in range(n)]))
    return out


def _sum_check(ix, f, A, src, n_want, w, out, rule):
    """The angle-sum rules in their full form: f is the interior angle of
    an n-gon at one vertex, src its other n-1 interior angles (by identity)
    -> (n-2)*180 - their sum. Returns 'ok' / 'bad' / None (not this form)."""
    me = A.key((f.get("args") or [None])[0])
    got = [A.key((g.get("args") or [None])[0]) for g in src]
    for pid, vs, keys in interior_keys(ix, A, A.L.ents):
        if len(vs) != n_want or me not in keys:
            continue
        i = keys.index(me)
        others = [k for j, k in enumerate(keys) if j != i]
        if Counter(got) != Counter(others):
            continue
        vals, want = [exact_deg(g) for g in src], exact_deg(f)
        if None in vals or want is None:
            return "ok"
        total = ANGLE_SUM[n_want] - sum(vals)
        if total != want:
            out.append(Issue("RULE_VALUE_MISMATCH", w, "%s: %s° − (%s) = %s,"
                             " not %s" % (rule, ANGLE_SUM[n_want],
                                          " + ".join(map(str, vals)), total,
                                          want)))
            return "bad"
        return "ok"
    return None


def _check_triangle_sum(ix, f, L, out):
    """triangle_angle_sum (a pre-v6.17 rule, used loosely before: G9-T18
    derives 55° from 35° and the rectangle's corner). Checked ONLY in its
    full form -- the fact is an interior angle of a triangle and the from
    facts are exactly its other two, with values: then 180° − their sum."""
    if f.get("rel") != "angle_measure":
        return
    frm = _from(ix, f)
    src = [g for g in frm if g.get("rel") == "angle_measure"]
    if len(src) != 2 or len(frm) != 2:
        return
    _sum_check(ix, f, Angles(ix, L), src, 3, _where(f), out,
               "triangle_angle_sum")


def validate_rules(spec, ix, out):
    """The checks of this module, appended to `out` (never raises on a
    malformed spec: schema.py reports the structure)."""
    try:
        ctx = _Ctx(ix)
        for f in ix.facts.values():
            ctx(f.get("item"))
    except Exception:            # noqa: BLE001 -- malformed entities
        return
    for fid in sorted(ix.facts):
        f = ix.facts[fid]
        rule = _src(f)
        if rule is None or rule not in RULES617 and \
                rule != "triangle_angle_sum":
            continue
        L = ctx(f.get("item"))[0]
        if rule == "quadrilateral_angle_sum":
            _check_quad(ix, f, L, out)
        elif rule in PARALLEL_RULES:
            _check_parallel(ix, f, rule, L, out)
        elif rule == "isosceles_converse":
            _check_isosceles_converse(ix, f, L, out)
        elif rule == "angle_bisector":
            _check_bisector(ix, f, L, out)
        elif rule == "triangle_angle_sum":
            _check_triangle_sum(ix, f, L, out)
    answer_issues(ix, out, ctx)
    class_issues(ix, out, ctx)


# ---------------------------------------------- the recomputations ---
KNOWN_ROLES = ("given", "derived", "context", "to_prove", "answer")


def _known(ix, A, scope, same_question=False):
    """{angle key: exact value} the reader of `scope` knows: angle_measure
    facts with a value (given, derived, context, to_prove -- a claim the
    sheet proves true --, answer) of its visible scopes -- or,
    same_question, of every scope of its question. An angle (by identity)
    with two different values is left out."""
    if same_question:
        q = ix.scope_question.get(scope)
        vis = set(s for s, qq in ix.scope_question.items() if qq == q)
    else:
        vis = set(ix.visible_scopes(scope))
    vals = {}
    for f in ix.facts.values():
        if f.get("rel") != "angle_measure" or f.get("item") not in vis or \
                f.get("role") not in KNOWN_ROLES:
            continue
        v = exact_deg(f)
        k = A.key((f.get("args") or [None])[0])
        if v is None or k is None:
            continue
        vals.setdefault(k, set()).add(v)
    return dict((k, list(v)[0]) for k, v in vals.items() if len(v) == 1)


def triangle_angles(ix, A, pid, known):
    """[3 exact values] of a triangle's interior angles from `known` (the
    third from the sum when two are known), else None."""
    vs = _point_vertices(ix, pid)
    if len(vs) != 3:
        return None
    got = [known.get(A.key_at(vs[i], vs[i - 1], vs[(i + 1) % 3]))
           for i in range(3)]
    if got.count(None) == 1:
        got[got.index(None)] = Fraction(180) - sum(v for v in got
                                                   if v is not None)
    return None if None in got else got


def class_of(angles):
    top = max(angles)
    return "obtuse_triangle" if top > 90 else "right_triangle" \
        if top == 90 else "acute_triangle"


def answer_issues(ix, out, ctx=None):
    """ANSWER_RULE_MISMATCH: an answer against the derived steps that
    compute the same angle, and the angle-sum recomputation (each in its
    own question: point names are sheet-wide)."""
    ctx = ctx or _Ctx(ix)
    for fid in sorted(ix.facts):
        a = ix.facts[fid]
        if a.get("role") != "answer" or a.get("rel") != "angle_measure":
            continue
        _L, A, polys = ctx(a.get("item"))
        v = exact_deg(a)
        me = A.key((a.get("args") or [None])[0])
        if v is None or me is None:
            continue
        vis = set(ix.visible_scopes(a.get("item")))
        for d in sorted(ix.facts.values(), key=lambda g: g.get("id")):
            if d.get("role") == "derived" and d.get("item") in vis and \
                    d.get("rel") == "angle_measure" and \
                    A.key((d.get("args") or [None])[0]) == me and \
                    exact_deg(d) is not None and exact_deg(d) != v:
                out.append(Issue("ANSWER_RULE_MISMATCH", "fact %s" % fid,
                                 "the derived step %s gives %s, the answer "
                                 "says %s" % (d.get("id"), exact_deg(d), v)))
        known = _known(ix, A, a.get("item"))
        for pid, vs, keys in polys:
            if len(vs) not in ANGLE_SUM or me not in keys:
                continue
            others = [k for k in keys if k != me]
            if len(others) != len(vs) - 1 or \
                    any(k not in known for k in others):
                continue
            want = ANGLE_SUM[len(vs)] - sum(known[k] for k in others)
            if want != v:
                out.append(Issue("ANSWER_RULE_MISMATCH", "fact %s" % fid,
                                 "%s is an angle of %s: %s° − (%s) = %s, "
                                 "the answer says %s" % (
                                     a["args"][0], pid, ANGLE_SUM[len(vs)],
                                     " + ".join(str(known[k])
                                                for k in others), want, v)))


def class_issues(ix, out, ctx=None):
    """CLASSIFY_ANGLES_MISMATCH: a triangle's class by its angles."""
    ctx = ctx or _Ctx(ix)
    for fid in sorted(ix.facts):
        f = ix.facts[fid]
        rel, role = f.get("rel"), f.get("role")
        A = ctx(f.get("item"))[1]
        pid = (f.get("args") or [None])[0]
        if rel == "classify" and role == "answer" and \
                f.get("value") in ANGLE_CLASSES:
            claim, known = f.get("value"), _known(ix, A, f.get("item"))
        elif rel in ANGLE_CLASSES and role in ("given", "derived",
                                               "to_prove", "answer"):
            claim = rel
            known = _known(ix, A, f.get("item"), same_question=True)
        else:
            continue
        angs = triangle_angles(ix, A, pid, known)
        if angs is None:
            continue
        got = class_of(angs)
        if got != claim:
            out.append(Issue("CLASSIFY_ANGLES_MISMATCH", "fact %s" % fid,
                             "%s has the angles %s: %s, not %s" % (
                                 pid, ", ".join(str(x) for x in angs), got,
                                 claim)))


# --------------------------------------------------- on the figure ---
PRINTED_BY_FIGURE_RELS = ("angle_measure", "length")


def printed_by_figure(spec, ix, rendered):
    """A PLANE figure (no frame: not a coordinate plane / number line / pie;
    no graph) PRINTS the value label of a stated GIVEN angle / length that
    it lists in `draws` WHEN a bound block of the same question announces
    that datum by COUNT -- G7-T14 a q9: "בשרטוט מרובע ABCD ובו שלוש זוויות
    נתונות", "שלוש" bound to {"count": [the three angles]}; their values
    stand only in the drawing. templates.render_spec counts such a given
    printed by the figure (scope: the figure's), as v6.16 does for a pie's
    data (sheet_pie). A given that nothing announces stays
    STATED_NOT_PRINTED even when a figure draws it (v6.13
    selfcheck_v613_prose B8: the text must say there IS such a datum). What
    the drawing shows is still checked where it always was:
    FIGURE_DRAWS_PRIVATE (never a target / answer), the renderer's own
    validation, geomcheck's labels (GEOM_LABEL_MISMATCH / _OFF) and the
    independent checker (+ OCR)."""
    try:
        from .schema_bound import blocks_of
        counted = {}
        for sid, _at, blk in blocks_of(spec):
            if not isinstance(blk, dict):
                continue
            q = ix.scope_question.get(sid)
            for bd in blk.get("bind") or []:
                if isinstance(bd, dict) and isinstance(bd.get("count"),
                                                       list):
                    counted.setdefault(q, set()).update(
                        x for x in bd["count"] if isinstance(x, str))
    except Exception:            # noqa: BLE001 -- malformed blocks
        return
    for g in spec.get("figures") or []:
        if not isinstance(g, dict) or g.get("frame") or g.get("graph"):
            continue
        vis = set(ix.visible_scopes(g.get("scope")))
        here = counted.get(ix.scope_question.get(g.get("scope")), set())
        for fid in g.get("draws") or []:
            f = ix.facts.get(fid) or {}
            if f.get("role") == "given" and f.get("item") in vis and \
                    (f.get("source") or {}).get("kind") == "stated" and \
                    f.get("rel") in PRINTED_BY_FIGURE_RELS and \
                    f.get("value") is not None and \
                    (f.get("args") or [None])[0] in here:
                rendered.printed.setdefault(fid, g.get("scope"))


def _sign(x):
    return 1 if x > 1e-9 else -1 if x < -1e-9 else 0


def figure_rule_scopes(ix, figure_id):
    """Only the question/items that actually use this figure's situation."""
    g = ix.figures.get(figure_id) or {}
    scope = g.get("scope")
    qid = ix.scope_question.get(scope)
    q = ix.questions.get(qid) or {}
    scopes = {qid} if qid else set()
    for item in q.get("items") or []:
        used = item.get("figure") or q.get("figure")
        if used == figure_id:
            scopes.add(item["id"])
    return scopes


def figure_issues(ix, pts, figure_id):
    """RULE_CONFIG_MISMATCH read off a FIGURE: for every parallel-rule fact
    of `ix` whose six points the figure marks (pts: name -> (x, y), as
    geomcheck reads them), the directions of the two angles' arms along the
    transversal and along the parallels must be the rule's. A reflection
    (the SVG's y-down) keeps every sign."""
    out = []
    ctx = _Ctx(ix)
    scopes = figure_rule_scopes(ix, figure_id)
    from . import schema as S
    fig = ix.figures.get(figure_id) or {}
    declared = set()
    for eid in fig.get("entities") or []:
        declared.update(S.entity_closure(eid, ix))
    for fid in sorted(ix.facts):
        f = ix.facts[fid]
        rule = _src(f)
        if rule not in PARALLEL_RULES or f.get("item") not in scopes:
            continue
        cfg, _why = parallel_config(ix, f, ctx(f.get("item"))[0])
        if cfg is None:
            continue
        need = [cfg[k] for k in ("V1", "X1", "Y1", "V2", "X2", "Y2")]
        # A construction not displayed on this situation has no geometric
        # orientation to check. A declared point missing from the actual
        # SVG, however, is a failed proof obligation, never a silent skip.
        if not set(need) <= declared:
            continue
        if not all(n in pts for n in need):
            out.append(Issue("RULE_CONFIG_MISMATCH", "fact %s" % fid,
                             "figure %s is missing declared rule points %s" %
                             (figure_id, sorted(set(need) - set(pts)))))
            continue
        P = dict((k, pts[cfg[k]]) for k in ("V1", "X1", "Y1", "V2", "X2",
                                             "Y2"))

        def vec(a, b):
            return (P[b][0] - P[a][0], P[b][1] - P[a][1])

        def dot(u, v):
            return u[0] * v[0] + u[1] * v[1]
        at, bt = vec("V1", "X1"), vec("V2", "X2")
        ap, bp = vec("V1", "Y1"), vec("V2", "Y2")
        st, sp = _sign(dot(at, bt)), _sign(dot(ap, bp))
        want = _want_signs(rule)
        inward = _sign(dot(at, vec("V1", "V2")))
        if (st, sp) != want or (rule == "co_interior_angles" and
                                inward != 1):
            out.append(Issue("RULE_CONFIG_MISMATCH", "fact %s" % fid,
                             "figure %s draws %s and %s as %s angles, not "
                             "%s" % (figure_id, cfg["from"], cfg["to"],
                                     _config_name(st, sp) if not (
                                         rule == "co_interior_angles" and
                                         (st, sp) == want) else
                                     "co-exterior", rule.split("_")[0] if
                                     rule != "co_interior_angles" else
                                     "co-interior")))
    return out


def private_figure_issues(ix, svg, figure_id):
    """Measure the finished SVG against private steps, without publishing them."""
    scopes = figure_rule_scopes(ix, figure_id)
    if not any(_src(f) in PARALLEL_RULES and f.get("item") in scopes
               for f in ix.facts.values()):
        return []
    import os
    import tempfile
    from . import geomcheck as G
    fd, path = tempfile.mkstemp(suffix=".svg", prefix="private_rule_")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            stream.write(svg)
        drawing = G.read_svg(path)
        if drawing.dialect:
            return list(drawing.dialect)
        return figure_issues(ix, drawing.pts, figure_id)
    finally:
        os.unlink(path)
