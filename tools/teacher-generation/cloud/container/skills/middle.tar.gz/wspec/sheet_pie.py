# -*- coding: utf-8 -*-
u"""wspec.sheet_pie -- (v6.16 integrate) the PIE CHART family on the
SHEET-level spec path. Owner: the integrator. The family itself (entities
pie / sector / build_circle, relations sector_value / sector_equal /
sector_angle / sector_percent / sector_count / pie_total / construct_pie,
the frame grammar 'pie_chart', exact data resolution, renderer, highlight
and the independent checker) is wspec/pie.py, render/pie*.py, check/pie*.py
(pie owner); this module wires it into schema / project / bound prose.

The house schema knows the pie kinds and relations (schema.ENTITY_KINDS,
RELS, PIE_RELS); their pie-specific grammar (names without digits, sector
keys, printed labels, roles, units % / deg, the frame, the exact data, the
answers) is pie.spec_issues, run here. On top (integrator):
  * a sector_count ANSWER is checked against the exact data when a GIVEN
    pie_total of its pie is visible to its item (count = total x share):
    PIE_ANSWER_MISMATCH -- the pie owner's check covers value / angle /
    percent answers only;
  * BOUND PROSE: a percent word ("באחוזים", "אחוזים") has no value -- it
    is bound to its pie's unit: {"tok": u"באחוזים", "pie": "pie:qb/unit"}
    (bind_problem: the word's stem is אחוז / אחוזים and the pie's part
    unit is percent). Numbers are bound to pie facts ("fact"), sector
    labels to sector entities ("entity"), "ארבע" to the sectors ("count").
"""
import re
from fractions import Fraction

from . import pie as P

FAMILY = P.FAMILY
# (v6.16 fix r1, D-BUILD) also "bcirc:<name>/unit": the percent word of a
# BUILD-A-PIE question ("חשבו את האחוז של כל קטגוריה") names the unit of the
# pie the student builds in the empty circle the question prints
REF_RE = re.compile(r"^((?:pie|bcirc):[a-z][a-z_]{0,23})/(unit)\Z")
PERCENT_WORDS = (u"אחוז", u"אחוזים")


def is_pie(fig):
    return P.is_pie_figure(fig)


def uses_pie(model):
    """the spec / public model holds a pie entity, fact or figure"""
    return any(P.is_pie_figure(g) for g in model.get("figures") or []
               if isinstance(g, dict)) or \
        any(P.is_pie_entity(e) for e in model.get("entities") or []
            if isinstance(e, dict)) or \
        any(P.is_pie_fact(f) for f in model.get("facts") or []
            if isinstance(f, dict))


def _issue(i):
    from .errors import Issue
    return Issue(i.code, i.where, i.detail)


def validate(spec, ix, out):
    if not uses_pie(spec):
        return
    for i in P.spec_issues(spec):
        out.append(_issue(i))
    out.extend(count_answer_issues(spec, ix))
    if spec.get("questions"):
        # a sheet: the (pending) given line of sector_equal names TWO
        # sectors ("הגזרות A ו־B שוות"); (v6.16 integrate r2, IR2) three or
        # more that are EVERY sector of their pie have the line 'כל הגזרות
        # בעוגה שוות זו לזו' (templates.sector_equal_all); any other group
        # of three or more would be stated wrongly in noam-ai.json --
        # refused until the author words it
        from .errors import Issue
        from .templates import sector_equal_all
        for f in spec.get("facts") or []:
            if isinstance(f, dict) and f.get("rel") == "sector_equal" and \
                    len(f.get("args") or []) > 2:
                if ix is not None and sector_equal_all(f, ix):
                    continue
                out.append(Issue("TPL_REL_MISMATCH", "fact %s" % f.get("id"),
                                 "the given line of sector_equal names two "
                                 "sectors, or all of a pie's; %d of them "
                                 "have no line (wspec/PENDING_V616.txt)"
                                 % len(f["args"])))


def count_answer_issues(spec, ix):
    """sector_count answers against pie_total x the sector's share"""
    from .errors import Issue
    pix = P.PieIndex(spec)
    share = {}
    for g in pix.figures.values():
        if not P.is_pie_figure(g):
            continue
        for p in (g.get("frame") or {}).get("parts") or []:
            if isinstance(p, dict) and p.get("part") == "pie":
                r = P.resolve(pix, p)
                if r.valid:
                    for s in r.order:
                        share[s] = r.value[s] / r.total
    out = []
    for f in sorted(pix.facts.values(), key=lambda f: str(f.get("id"))):
        if f.get("rel") != "sector_count" or f.get("role") != "answer":
            continue
        s = (f.get("args") or [None])[0]
        pie = (pix.ents.get(s) or {}).get("pie")
        vis = set(ix.visible_scopes(f.get("item")))
        tot = [t for t in pix.facts_about(pie, "pie_total", ("given",))
               if t.get("item") in vis]
        v = P._q(f.get("value"))
        if s not in share or len(tot) != 1 or v is None:
            continue
        want = P._q(tot[0].get("value")) * share[s]
        if v != want:
            out.append(Issue("PIE_ANSWER_MISMATCH", "fact %s" % f["id"],
                             "%s, the total %s x the share of %s gives %s"
                             % (f.get("value"), tot[0].get("value"), s,
                                P.decimal_text(want) or str(want))))
    return out


def public_frame(fr):
    return P.public_frame(fr)


def printed_by_figure(spec, ix, rendered):
    """A pie chart PRINTS the givens it draws (each sector's value label
    '40%', the total label 'סך הכול: 200'): templates.render_spec counts
    them printed by the figure (scope = the figure's scope), so a pie's
    data need no sentence of their own -- the source prints them only in
    the chart. Only GIVEN facts of the pie family, only by a pie figure
    that lists them in `draws` (pie.frame_issues checks draws == what the
    frame prints: PIE_VALUES_DRAWN / PIE_DRAWS)."""
    for g in spec.get("figures") or []:
        if not P.is_pie_figure(g):
            continue
        for fid in g.get("draws") or []:
            f = ix.facts.get(fid) or {}
            if P.is_pie_fact(f) and f.get("role") == "given":
                rendered.printed.setdefault(fid, g.get("scope"))


def scan_public(pub, out):
    """the pie half of project.scan_public (its grammar and leaks)"""
    if not uses_pie(pub):
        return
    for i in P.scan_public_pie(pub):
        out.append(_issue(i))


def bind_problem(model, ref, kind, tok):
    """None when {"pie": ref} binds atom tok, else why. model: the spec or
    the public model (the pie part's unit is public)."""
    from . import schema as S
    m = REF_RE.match(ref) if isinstance(ref, str) else None
    if m is None:
        return "pie ref %r is not pie:<name>/unit" % (ref,)
    pid = m.group(1)
    if pid.startswith("bcirc:"):
        # the build circle must be DRAWN (an empty circle of a build part);
        # the word must be a percent word; the circle has no data, so the
        # word states no value (a build pie is built in percents / degrees
        # from the question's data -- the key holds them, never the figure)
        builds = [p for g in model.get("figures") or [] if P.is_pie_figure(g)
                  for p in (g.get("frame") or {}).get("parts") or []
                  if isinstance(p, dict) and p.get("part") == "build" and
                  p.get("circle") == pid]
        if not builds:
            return "no build circle %s is drawn" % pid
        if kind != "word" or not any(st in PERCENT_WORDS
                                     for st in S._strip_prefixes(tok)):
            return "%r is not a percent word" % tok
        return None
    parts = [p for g in model.get("figures") or [] if P.is_pie_figure(g)
             for p in (g.get("frame") or {}).get("parts") or []
             if isinstance(p, dict) and p.get("pie") == pid]
    if not parts:
        return "no pie %s is drawn" % pid
    if kind != "word" or not any(st in PERCENT_WORDS
                                 for st in S._strip_prefixes(tok)):
        return "%r is not a percent word" % tok
    if parts[0].get("unit") != "percent":
        return "%s is a %s pie" % (pid, parts[0].get("unit"))
    return None


def exact(spec):
    """{(rel, sector): Fraction} of every valid pie of the spec"""
    pix = P.PieIndex(spec)
    out = {}
    for g in pix.figures.values():
        if P.is_pie_figure(g):
            out.update(P.exact_quantities(pix, g))
    return out


def share_of(spec, sid):
    for (rel, s), v in exact(spec).items():
        if rel == "sector_percent" and s == sid:
            return v / Fraction(100)
    return None
