"""Unnamed observations on a coordinate frame, with source-bound metadata.

Values to read/find stay private. A public pair requires two actually printed
given coordinate facts; rendering private read-off positions uses data_layout,
the same separation as named coordinate points. There is no answer field.
"""
import copy
import re
from . import canon
from .errors import Issue

TOKEN = re.compile(r"^[a-zA-Z][a-zA-Z0-9_-]{0,31}$")
ROLES = ("given", "read_off", "to_plot", "to_find")
MARKERS = ("circle", "square")
SYMBOL = {"circle": "●", "square": "□"}


def number(v):
    try:
        a, b, r = canon.parse_exact(v)
        return a if r == 1 else None
    except Exception:
        return None


def norm(t):
    return " ".join(t.replace("$", "").split()) if isinstance(t, str) else ""


def point_id(p):
    return "data:%s:%s" % (p["series"], p["id"])


def objects(pub, fid):
    fig = next((g for g in pub.get("figures") or [] if g.get("id") == fid), {})
    data = fig.get("data") or {}
    out = {}
    for p in data.get("points") or []:
        oid = point_id(p)
        out[oid] = dict(p, id=oid, point=p["id"], kind="data_point")
    for s in data.get("series") or []:
        ps = [point_id(p) for p in data.get("points") or [] if p["series"] == s["id"]]
        oid = "series:" + s["id"]
        out[oid] = dict(s, id=oid, series=s["id"], kind="data_series",
                        points=ps, drawn=any(out[p]["drawn"] for p in ps))
    for r in data.get("readings") or []:
        oid = "reading:" + r["id"]
        out[oid] = dict(r, id=oid, kind="axis_reading", drawn=True)
    return out


def public_data(fig):
    data = copy.deepcopy(fig["data"])
    for p in data.get("points") or []:
        if not p.get("coord_facts") or p.get("role") in ("read_off", "to_find"):
            p.pop("coords", None)
        elif "coords" in p:
            p["coords"] = [canon.canon_number(x) for x in p["coords"]]
    for r in data.get("readings") or []:
        for k in ("lo", "hi"):
            if k in r:
                r[k] = canon.canon_number(r[k])
    return data


def display_layout(fig):
    return [{"id": point_id(p), "xy": list(p["coords"])}
            for p in fig.get("data", {}).get("points") or []
            if p.get("drawn") and (not p.get("coord_facts") or
                                  p.get("role") in ("read_off", "to_find"))]


def _context(spec, public=False):
    texts, owners, printed = {}, {}, set()
    for q in spec.get("questions") or []:
        for sc in [q] + list(q.get("items") or []):
            owners[sc["id"]] = q["id"]
            if public:
                texts[sc["id"]] = norm(sc.get("text"))
                for b in sc.get("bound") or []:
                    printed.update(b.get("prints") or [])
                    for bd in b.get("bind") or []:
                        f = bd.get("fact")
                        printed.update(f if isinstance(f, list) else [f] if f else [])
    if not public:
        from .schema_bound import blocks_of, bound_facts
        for scope, _at, block in blocks_of(spec):
            texts[scope] = texts.get(scope, "") + " " + norm(block.get("text"))
            printed.update(bound_facts(block))
    return texts, owners, printed


def problems(spec, fig, public=False):
    data = fig.get("data")
    if data is None:
        return []
    errors = []
    def bad(t): errors.append(t)
    def fields(obj, allowed, required):
        return isinstance(obj, dict) and not set(obj) - set(allowed) and set(required) <= set(obj)
    if not fields(data, ("series", "points", "readings"), ("series", "points")) or any(not isinstance(data.get(k, []), list) for k in ("series", "points", "readings")):
        return ["data must contain only series, points, readings lists"]
    if (fig.get("frame") or {}).get("family") != "coordinate_plane" or "graph" in fig or (fig.get("frame") or {}).get("sketch"):
        bad("observations require an ordinary coordinate frame without a graph")
    texts, owners, printed = _context(spec, public)
    qid = owners.get(fig.get("scope"))
    facts = {f.get("id"): f for f in spec.get("facts") or []}
    def source(s):
        return fields(s, ("scope", "text"), ("scope", "text")) and isinstance(s["scope"], str) and owners.get(s["scope"]) == qid and bool(norm(s["text"])) and norm(s["text"]) in texts.get(s["scope"], "")
    series = {}
    for s in data["series"]:
        if not fields(s, ("id", "marker", "label", "legend"), ("id", "marker")) or not isinstance(s.get("id"), str) or not TOKEN.fullmatch(s["id"]) or s.get("marker") not in MARKERS:
            bad("invalid series declaration")
            continue
        if s["id"] in series: bad("duplicate series id")
        series[s["id"]] = s
        if "label" in s and (not isinstance(s["label"], str) or not s["label"] or not any(s["label"] in t for sc, t in texts.items() if owners.get(sc) == qid)):
            bad("series label is not printed in its question")
        if "legend" in s:
            if not source(s["legend"]) or SYMBOL[s["marker"]] not in s["legend"].get("text", "") or (s.get("label") and s["label"] not in s["legend"].get("text", "")):
                bad("legend must quote the printed symbol and series label")
    if not series: bad("at least one series is required")
    named = [s for s in series.values() if s.get("legend")]
    if len({s["marker"] for s in named}) != len(named): bad("different legend series require different markers")
    seen = set()
    for p in data["points"]:
        if not fields(p, ("id", "series", "coords", "drawn", "role", "coord_facts"), ("id", "series", "drawn", "role")) or not isinstance(p.get("id"), str) or not TOKEN.fullmatch(p["id"]) or not isinstance(p.get("series"), str) or p["series"] not in series or not isinstance(p.get("drawn"), bool) or p.get("role") not in ROLES:
            bad("invalid observation declaration")
            continue
        oid = point_id(p)
        if oid in seen: bad("duplicate observation id")
        seen.add(oid)
        xy = p.get("coords")
        if xy is not None and (not isinstance(xy, list) or len(xy) != 2 or any(number(v) is None for v in xy)):
            bad("observation coordinates must be an exact numeric pair")
            continue
        if not public and xy is None: bad("private observation coordinates missing")
        if p["role"] in ("to_find", "to_plot") and p["drawn"]: bad("student observation must not be drawn")
        fs = p.get("coord_facts")
        if public and xy is not None and (not fs or p["role"] in ("read_off", "to_find")):
            bad("public observation reveals a read-off/private coordinate")
        if p["role"] == "given" and not fs: bad("given coordinates require printed fact bindings")
        if fs is not None:
            if not isinstance(fs, list) or len(fs) != 2 or any(not isinstance(f, str) for f in fs):
                bad("coord_facts must name x and y given facts")
                continue
            ff = [facts.get(f, {}) for f in fs]
            if any(f.get("rel") != "coordinate" or f.get("role") != "given" or owners.get(f.get("item")) != qid or f.get("id") not in printed for f in ff) or [f.get("args", [None,None])[-1] for f in ff] != ["axis:x", "axis:y"] or ff[0].get("args", [None])[0] != ff[1].get("args", [None])[0] or (xy is not None and any(number(f.get("value")) != number(v) for f,v in zip(ff,xy))):
                bad("observation pair does not match two printed given facts")
        if not public and p["drawn"] and xy is not None:
            axes = (fig.get("frame") or {}).get("axes") or []
            if len(axes) == 2 and any(number(a.get("min")) is not None and number(a.get("max")) is not None and not number(a["min"]) <= number(v) <= number(a["max"]) for a,v in zip(axes,xy)):
                bad("drawn observation outside its frame")
    seen = set()
    for r in data.get("readings") or []:
        if not fields(r, ("id", "axis", "lo", "hi", "lo_in", "hi_in", "source"), ("id", "axis", "lo_in", "hi_in", "source")) or not isinstance(r.get("id"), str) or not TOKEN.fullmatch(r["id"]) or r.get("axis") not in ("axis:x", "axis:y") or not all(isinstance(r.get(k), bool) for k in ("lo_in", "hi_in")):
            bad("invalid axis reading declaration")
            continue
        if r["id"] in seen: bad("duplicate reading id")
        seen.add(r["id"])
        if not source(r["source"]):
            bad("axis reading must quote its printed condition")
            continue
        bounds = [k for k in ("lo", "hi") if k in r]
        if not bounds or any(number(r[k]) is None for k in bounds): bad("reading requires finite exact bound(s)")
        elif all(k in r for k in ("lo", "hi")) and number(r["lo"]) > number(r["hi"]): bad("reading endpoints reversed")
        for k in bounds:
            if number(r[k]) is not None and not re.search(r"(?<![\d.])" + re.escape(canon.canon_number(r[k])) + r"(?![\d.])", norm(r["source"].get("text"))):
                bad("reading bound is not printed in its source")
    return errors


def validate(spec, ix, out):
    for fig in spec.get("figures") or []:
        out.extend(Issue("BAD_TYPE", "figure %s data" % fig.get("id"), e)
                   for e in problems(spec, fig))


def scan_public(pub, out):
    for fig in pub.get("figures") or []:
        out.extend(Issue("PUBLIC_VALUE_NOT_WHITELISTED", "figure %s data" % fig.get("id"), e)
                   for e in problems(pub, fig, public=True))
