# -*- coding: utf-8 -*-
"""Hebrew inside an SVG label (v6.9 fix r2, E1b).

WeasyPrint draws an SVG <text> WITHOUT the bidi algorithm: the characters
are placed left to right in their stored order, so a logical '5 ס״מ' prints
with samekh LEFT of mem ('מ״ס' to a Hebrew reader). A browser does run the
bidi algorithm. The one form that prints the same everywhere:

    <text ... direction="ltr" unicode-bidi="bidi-override">5 מ״ס</text>

the content in VISUAL order (each Hebrew run reversed) and the override that
tells a browser to lay it out exactly as stored. WeasyPrint ignores both
attributes and lays the stored order out as well. So the renderer writes
every label with a Hebrew letter this way (BIDI_ATTRS), every reader of the
SVG turns the content back with logical(), and the PDF gate reads the glyphs'
x order against visual().

A label is an LTR part (letters, digits, signs) followed by at most one
Hebrew run at its END -- the only shape the renderer makes (a number and its
unit: '5 ס״מ', '12 מ׳'). A Hebrew run is a maximal stretch of Hebrew letters
and the Hebrew geresh / gershayim, with a space or ASCII prime between two
of them kept inside it (the bidi algorithm's neutrals between two R).
Anything after a Hebrew run that is not part of it (a digit, a Latin
letter) is refused: its visual order would depend on the full algorithm."""
import re

BIDI_ATTRS = (("direction", "ltr"), ("unicode-bidi", "bidi-override"))

_R = u"א-ת׳״"
_RUN = re.compile(u"[%s](?:[%s '\"]*[%s])?" % (_R, _R, _R))
# a label NEEDS the override only when it has a Hebrew LETTER: a geresh
# alone ('A׳', a prime) is one character, the same in either order
_HAS = re.compile(u"[\u05d0-\u05ea]")


class BidiError(ValueError):
    """A label whose visual order is outside what this module supports."""


def has_rtl(text):
    return bool(_HAS.search(text or ""))


def _check(text):
    runs = list(_RUN.finditer(text))
    if not runs:
        return runs
    if len(runs) > 1 or text[runs[-1].end():].strip():
        raise BidiError(
            "label %r: a Hebrew run must be the END of the label (a number "
            "and its unit); anything after it has no fixed visual order"
            % text)
    return runs


def visual(text):
    """The label in VISUAL order (left to right as printed, base LTR)."""
    text = text or ""
    runs = _check(text)
    if not runs:
        return text
    m = runs[-1]
    return text[:m.start()] + m.group(0)[::-1] + text[m.end():]


def logical(text):
    """The inverse of visual() (it is its own inverse on the labels it
    accepts)."""
    return visual(text)


def is_override(attrs):
    """True when a <text>'s attributes are exactly the override pair."""
    return all(attrs.get(k) == v for k, v in BIDI_ATTRS)


def attrs_issue(content, attrs):
    """None, or why a <text> with this stored content and these attributes
    breaks the rule: a label with a Hebrew letter carries BOTH override
    attributes (content in visual order); a label without one carries
    neither."""
    have = [k for k, _v in BIDI_ATTRS if k in attrs]
    if has_rtl(content):
        if not is_override(attrs):
            return ("a label with a Hebrew letter must carry direction=\"ltr\""
                    " unicode-bidi=\"bidi-override\" and store its text in "
                    "visual order (WeasyPrint does not run bidi in SVG)")
        try:
            _check(content)
        except BidiError as ex:
            return str(ex)
        return None
    if have:
        return ("%s on a label without a Hebrew letter" % "/".join(have))
    return None
