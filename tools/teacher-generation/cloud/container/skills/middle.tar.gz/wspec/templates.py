# -*- coding: utf-8 -*-
"""Phrasing templates: the maths-core text is GENERATED from facts.

A value printed in a generated text comes only from the fact it names. No
template can print a target's value or an answer: target / mention
templates have no value, unit or relation slot (checked when the set is
loaded), and every call is checked again against the roles of the facts it
is given (answers are refused outright). The set itself is approved by
hash: an edited templates_he.json is refused until re-approved."""
import hashlib
import json
import os
import re

from . import canon
from .errors import Issue, SpecError

HERE = os.path.dirname(os.path.abspath(__file__))
TEMPLATES_JSON = os.path.join(HERE, "templates_he.json")
# sha256 of the canonical JSON of templates_he.json -- the author's approval
# of the phrasing set. Changing any template voids it (TPL_SET_UNAPPROVED).
# Re-approved 2026-09-22 (fix r3, R3-07): prove_that gained 'length'
# ("הוכיחו כי AM = 13 ס״מ"); previous set f10b7ec0...1e1c.
# Re-approved 2026-09-22 BY THE FIXER, NOT THE AUTHOR (closing verifier r1,
# C1-07): the plain (given-list) phrases of length / perimeter / area gained
# the unit slot {u} ("AB = 6 ס״מ", not "AB = 6"); previous set a6f2b250...
# 1e27. Both re-approvals await the author (report section 7).
# Re-approved 2026-09-22 BY THE FIXER, NOT THE AUTHOR (addendum S3): the
# one 'construct' template with a free wording list is replaced by eleven
# construction templates that DECLARE their result and base (construct_*),
# with value-free target lines; previous set 28eadab6...c0c7. Awaits the
# author (report section 7).
# Re-approved 2026-09-23 BY THE FIXER, NOT THE AUTHOR (fix structural r1):
# every construction template declares new_point (semantics r1, V5) and
# construct_triangle's argument is a 'triangle' (V6); previous set
# 820e98d0...6e6a. Awaits the author (report section 7).
# Re-approved 2026-09-23 BY THE FIXER, NOT THE AUTHOR (close_gaps SV3-05):
# every construction template declares its mode (locate / join) and
# join_segment ('שרטטו את הקטע EM בין שתי הנקודות הנתונות.') joins two
# points the page shows; previous set f462afd9...3e7b. Awaits the author.
# Re-approved 2026-09-23 BY THE FIXER, NOT THE AUTHOR (v6.9 fix r1, N2/P2,
# P3/C2): the phrases of length / perimeter / area / var_value /
# equal_length / parallel / perpendicular / coordinate gained a 'sheet' form
# (the worksheet skill's mode) that prints the maths as ONE math island
# ("$AC = 18$ ס״מ": a datum never breaks across lines; 'tex' is unchanged);
# new templates given_next ("{f0.rel}", the 2nd.. datum after one "נתון:"),
# midpoint_named, bisector_meets_side, drop_altitude_to_diagonal,
# compute_two, and compute_length_of's list gained "היתר" -- the v6.7.3
# sentences of G9-T18 in template form. Previous set d2139fce...ff3b.
# Awaits the author.
# Re-approved 2026-09-24 BY THE FIXER, NOT THE AUTHOR (v6.10 part 2, the
# spec-language features of BRIEF_V610): 45 new templates, each marked
# "pending": "author" in the file (area / perimeter / root targets,
# relations of quantities, proof claims, classification, the given forms of
# G9-T18, the unnamed-construction hint), phrases for linear / greater /
# not_parallel / inside / the new shape classes / classify, two
# connectors, and wider rel lists of prove_that / given_next / given_rel
# and the word "האנך" in compute_length_of (no existing call prints
# anything new). Previous set 5660389a...8563. AWAITS THE AUTHOR: the
# wording list is wspec/PENDING_V610.txt.
# Re-approved 2026-09-24 BY THE FIXER, NOT THE AUTHOR (v6.10 fix r2, N1): a
# classify says what it classifies ("סוג המרובע ABCD", v6.7.3's find text;
# classify_triangle / classify_polygon for 3 / other vertex counts) and
# class_nouns names each class ("מלבן", the sheet.json find value); m3: the
# congruence phrase's sheet form is ONE math island ('$\\tri ADE \\cong \\tri
# BCF$', as v6.7.3 level c printed it). Previous set 467b6975...1de5.
# AWAITS THE AUTHOR (wspec/PENDING_V610.txt).
# Re-approved 2026-09-24 BY THE FIXER, NOT THE AUTHOR (v6.12, BRIEF_V612
# section 1, schema of the two families): 37 new templates for the
# coordinate plane and the number line (plot / read / distance / absolute
# value / jump / interval / whole-number count / reading guides), each
# "pending": "author"; phrases of the seven family relations with a given
# line and target lines of the six that can be asked; the coordinate
# phrase's tex / sheet form puts its value in a math island ("שיעור y של P:
# $−3$", U+2212); no existing template's text changed. Previous set
# 609d2424...41e1. AWAITS THE AUTHOR: the wording list is
# wspec/PENDING_V612.txt.
# Re-approved 2026-09-25 BY THE AUTHOR (wspec/approvals/APPROVALS_NOAM.json:
# W-NL-COUNT-OPEN, W-NL-JUMP-DIRECTION, W-NL-TICK-DIFFERENCE, W-COORDS-TERM,
# W-V612-TEMPLATES-REST; BRIEF_V613 ADDENDUM 1): count_int_open says ", לא
# כולל הקצוות"; jump_size_q asks "ולאיזה כיוון?" and the jump_value phrase
# prints the positive size with its direction ({vd}, jump_words: "$5$ יחידות
# שמאלה", never a signed value), target line "גודל הקפיצה {a0} וכיוונה";
# interval_value_axis / _line / _given, the interval_value phrase and target
# line say "ההפרש בין הערכים של שתי שנתות סמוכות" (never "בכמה עולים");
# "שיעורי הנקודה" unchanged. The 37 v6.12 templates lose their "pending"
# flag (all author-approved); the 45 v6.10 ones stay pending
# (wspec/PENDING_V610.txt). Previous set d0a32176...0c169.
# Re-approved 2026-09-25 BY THE FIXER, NOT THE AUTHOR (v6.13 fix_r1, C5 /
# N-6.3): two NUMBER-LINE target lines and the PLAIN form of two phrases
# (noam-ai.json / sheet.json / didactic metadata only, never printed; the
# phrases' tex / sheet forms equal the base ones -- phrase_key; plain
# "הנקודה {n0} מייצגת את המספר {v}" from the approved nl_point_is, and
# "... על ישר המספרים = {v}"): "interval_value_nl" = "ההפרש בין הערכים של
# שתי שנתות סמוכות על ישר המספרים" -- the wording the author's
# W-NL-TICK-DIFFERENCE names for a line; "coordinate_nl" = "המספר שמייצגת
# הנקודה {n0}" -- from the approved nl_which_number ("איזה מספר מייצגת
# הנקודה ...?"), NEW, AWAITS THE AUTHOR (wspec/PENDING_V612.txt, section
# fix_r1). They replace "על ציר n" / "שיעור n של P" on a number line only
# (templates.target_key). Previous set 892a5ba7...06b2.
# Re-approved 2026-09-25 BY THE FIXER, NOT THE AUTHOR (v6.13 fix_r2,
# R1-plane-interval-tick-wording): one target line and the PLAIN form of one
# phrase, metadata only (never printed; tex / sheet = the base phrase's):
# "interval_value_grid" = "ההפרש בין הערכים של שני קווי רשת סמוכים על ציר
# {n0}" -- on a gridded plane the renderer ticks only the numbered grid
# lines, so "two neighbouring ticks" was false there (T08 a q4: ticks 20
# apart, the interval 10). The words are the original sheet's (T08 a q3 "כל
# מרווח בין שני קווי רשת סמוכים"). AWAITS THE AUTHOR (wspec/PENDING_V612.txt
# section 7). Previous set fa76499c...192f.
# Same round, same status (BY THE FIXER, AWAITS THE AUTHOR, PENDING_V612.txt
# section 7): the phrase of the new relation axis_parallel (B1) -- metadata
# "AB ∥ ציר x" (tex / plain) and the sheet form "$AB \para$ ציר $x$"; the
# printed question keeps the original words as bound prose. Previous set
# 99452d1f...4604.
# Same round: the connector "\n" -- a LINE BREAK between two stem lines of
# a spec question (the original prints the legend of G7-T08 a q11 / b q5 on
# its own line); no wording. Previous set 45a4814d...e873.
# Re-approved 2026-09-26 BY THE FIXER, NOT THE AUTHOR (v6.16 integrate, the
# graph and pie families on the spec path): METADATA wording only -- never
# printed on a sheet (a question prints its ORIGINAL words as bound prose;
# an answer key prints the ORIGINAL key line, keys=): the target lines of
# the six pie relations (sector_value / sector_angle / sector_percent /
# sector_count / pie_total / construct_pie) and the phrases of five of them
# plus sector_equal (Noam AI given / target lines, sheet.json claims, the
# private model's key); two new keys "graph_target_lines" (the description
# of each graph find, slots {c0} / {c1} = a curve as graph_curve_words +
# its printed name / equation, {at} = the number a find asks at) and
# "graph_curve_words" (הישר / הפרבולה). No existing entry changed. Previous
# set db0bce4f...0a1. AWAITS THE AUTHOR: the list is wspec/PENDING_V616.txt.
# Re-approved 2026-09-27 BY THE FIXER, NOT THE AUTHOR (v6.16 integrate round
# 2, pie IR2 / IR4): METADATA lines that name no never-printed sector handle
# -- the phrase "sector_equal_all" 'כל הגזרות בעוגה שוות זו לזו' (a
# sector_equal over EVERY sector of a pie, three or more; rel_key), and the
# '<rel>_unnamed' phrases / target lines of sector_value / sector_angle /
# sector_percent / sector_count / sector_equal for a sector its figure
# prints no name for (a names-"none" disc or a region; _variant). Never
# printed. No existing entry changed. Previous set 5b3f6237...12b5.
# AWAITS THE AUTHOR (wspec/PENDING_V616.txt section 4).
# APPROVED 2026-09-27 BY THE AUTHOR (wspec/approvals/APPROVALS_NOAM.json
# V616-A5, approved_utc 18:59:11Z, "הניסוח מאושר"; BRIEF_V616 ADDENDUM 2,
# A-5 UPDATE): the section-4 wording of PENDING_V616.txt -- the phrases
# sector_equal_all / sector_equal_unnamed and the '<rel>_unnamed' target
# lines and phrases of sector_value / sector_angle / sector_percent /
# sector_count (a sector its figure prints no name for). Those facts count
# as approved wording from here on. No template changed, so the set hash
# below is the same set 44cd8fc6...9e12 the author approved. Sections 1-3 of
# PENDING_V616.txt (the named-sector pie lines and the graph find lines)
# are not part of V616-A5 and still AWAIT THE AUTHOR.
# Re-approved 2026-09-29 BY THE FIXER, NOT THE AUTHOR (v6.17-noam V1,
# BRIEF_V617: the obtuse triangle of G7-T14 / G7-T19): two ADDED entries,
# no existing one changed, no template added (a sheet prints the original
# wording as bound prose) -- the phrase "obtuse_triangle" ('△ABC הוא משולש
# קהה־זוויות', the given-list / key line of the new relation, as
# acute_triangle's) and the class noun "obtuse_triangle" ('משולש
# קהה־זוויות', the classify answer of "רשמו את שם המשולש לפי הזוויות"; the
# source's own words). Previous set 44cd8fc6...9e12 (V616-A5). AWAITS THE
# AUTHOR: wspec/PENDING_V617.txt section A.
# v6.18: APPROVED 2026-09-29 BY THE AUTHOR (V617-W1-5 / V617-Q7).
# The obtuse-triangle wording and unit words are now approved; var_value
# includes its unit in all three modes. Only the six approved area /
# perimeter templates lose pending:author; all other pending entries stay.
# Exact author decisions and reversible delta: approvals/V618_WORDING_PIN.json.
APPROVED_SET_SHA256 = "c0858c5326fa27a4a73b7f6952c6821b0c574139db222f7712b0577ba6cc0cf7"

TEMPLATE_KINDS = ("given", "target", "to_prove", "to_construct", "mention",
                  "line", "mixed", "to_plot")
# template kind -> roles of the facts it may print ('mixed', v6.10: the
# template lists the roles of each fact it prints, "roles": [[..], [..]] --
# "prove that S(BOC) = 1/4 S(ABCD), and compute it" prints a to_prove and a
# target; the target's value slots stay forbidden)
KIND_ROLES = {"given": ("given",), "target": ("target",),
              "to_prove": ("to_prove",), "to_construct": ("to_construct",),
              "line": ("given", "context"), "mention": (), "mixed": None,
              "to_plot": ("to_plot",)}
# (v6.12) a plot task prints the coordinates it gives beside it: "סמנו את
# הנקודה $A(3, −2)$" is a mixed template of a to_plot and two givens
MIXED_ROLES = ("given", "target", "to_prove", "to_plot")
# kinds that must never carry a value / unit / relation slot
NO_VALUE_KINDS = ("target", "mention", "to_construct", "to_plot")
# (v6.12) roles whose value slots a mixed template may not print
NO_VALUE_ROLES = ("target", "to_plot")
# slot parts that print a fact's value, unit or relation (v6.10: eq = the
# relation without its unit, ub = the bare unit word)
VALUE_PARTS = ("v", "u", "rel", "eq", "ub")
SLOT_RE = re.compile(r"\{([a-z][a-z0-9.]*)\}")
# v6.10: f<k>.tq / f<k>.targ<n> print a triangle argument as "$\tri ABC$";
# e<k>.through / e<k>.base read the parts of an unnamed construction (cline)
# v6.12: e<k>.from / e<k>.to (a jump), e<k>.lo / e<k>.hi (an interval)
TPL_SLOT = re.compile(r"^(?:f(\d+)\.(q|tq|arg\d+|targ\d+|v|u|ub|rel|eq)|"
                      r"e(\d+)(?:\.(through|base|from|to|lo|hi))?|"
                      r"([a-z][a-z0-9]*))$")
# the entity parts a part slot may read, per kind
ENTITY_PARTS = {"cline": ("through", "base"), "jump": ("from", "to"),
                "interval": ("lo", "hi")}
# v6.13 (author decision W-NL-JUMP-DIRECTION): {vd} = a jump's positive
# size in units plus its direction word ("$5$ יחידות שמאלה"), from the
# set's "jump_words"; only the jump_value phrase may use it
PHRASE_SLOT = re.compile(r"^(?:[an](\d+)|v|vd|u|expr)$")
# (v6.10) the words of templates that name a class or a number, read by
# the templates' checks (closed tables: a word outside them is refused by
# the template's own closed param list first)
NOUN_CLASS = {   # noun -> (vertex count, classes that must be stated|None)
    u"המשולש": (3, None), u"המרובע": (4, None),
    u"הטרפז": (4, ("trapezoid", "isosceles_trapezoid")),
    u"המלבן": (4, ("rectangle", "square")),
    u"המקבילית": (4, ("parallelogram", "rectangle", "square", "rhombus")),
    u"הריבוע": (4, ("square",)), u"המעוין": (4, ("rhombus", "square"))}
BARE_CLASS = {   # the same nouns without the article ("בכל מלבן")
    u"מלבן": ("rectangle", "square"),
    u"מקבילית": ("parallelogram", "rectangle", "square", "rhombus"),
    u"ריבוע": ("square",), u"מעוין": ("rhombus", "square"),
    u"משולש ישר־זווית": ("right_triangle",)}
FRACTION_WORDS = {u"חצי": "1/2", u"שליש": "1/3", u"רבע": "1/4"}
MULT_WORDS = {u"שניים": "2", u"שלושה": "3", u"ארבעה": "4"}
PLAIN_FRACTIONS = {"1/2": u"½", "1/3": u"⅓", "2/3": u"⅔", "1/4": u"¼",
                   "3/4": u"¾"}
# pseudo-kind -> (entity kind, vertex count)
ENTITY_PSEUDO = {"triangle": ("polygon", 3)}


def set_hash(data):
    return hashlib.sha256(canon.dumps(data).encode("utf-8")).hexdigest()


class TemplateSet(object):
    def __init__(self, data):
        self.data = data
        self.connectors = list(data["connectors"])
        self.phrases = data["phrases"]
        self.target_lines = data["target_lines"]
        self.templates = data["templates"]
        # (v6.10 fix r2, N1) the class names a classify answer's find
        # value prints ("מלבן"), sheet.json only
        self.class_nouns = data.get("class_nouns") or {}
        # (v6.13, W-NL-JUMP-DIRECTION) the words of a jump's size and
        # direction ("יחידה אחת", "{n} יחידות", "שמאלה", "ימינה")
        self.jump_words = data.get("jump_words") or {}


def check_template_set(data):
    """Structural checks of a template set (independent of approval)."""
    out = []
    for k in ("version", "connectors", "phrases", "target_lines",
              "templates"):
        if k not in data:
            out.append(Issue("MISSING_FIELD", "templates", k))
    if out:
        return out
    for rel, ph in data["phrases"].items():
        for mode in ("tex", "plain", "sheet"):
            for s in SLOT_RE.findall(ph.get(mode, "")):
                if not PHRASE_SLOT.match(s):
                    out.append(Issue("TPL_BAD_SLOT", "phrase " + rel, s))
                elif s == "vd" and rel != "jump_value":
                    # (v6.13) only a jump has a direction
                    out.append(Issue("TPL_BAD_SLOT", "phrase " + rel, s))
    # (v6.13, W-NL-JUMP-DIRECTION) a {vd} phrase needs the jump words
    jw = data.get("jump_words") or {}
    if any("{vd}" in (ph.get(m) or "") for ph in data["phrases"].values()
           for m in ("tex", "plain", "sheet")):
        for k in ("one", "many", "left", "right"):
            if not isinstance(jw.get(k), str) or not jw[k].strip():
                out.append(Issue("MISSING_FIELD", "templates jump_words", k))
        if "{n}" not in (jw.get("many") or ""):
            out.append(Issue("TPL_BAD_SLOT", "templates jump_words",
                             "many has no {n}"))
    # (v6.10 fix r2, N1) every class a classify answer may name has its
    # noun (the find value of sheet.json, "מלבן")
    from . import schema as S          # local: schema imports this module
    cn = data.get("class_nouns") or {}
    for c in S.CLASS_VALUES:
        if not isinstance(cn.get(c), str) or not cn.get(c).strip():
            out.append(Issue("MISSING_FIELD", "templates class_nouns", c))
    for rel, tl in data["target_lines"].items():
        for s in SLOT_RE.findall(tl):
            if not PHRASE_SLOT.match(s):
                out.append(Issue("TPL_BAD_SLOT", "target_line " + rel, s))
            elif s in ("v", "vd", "u"):
                out.append(Issue("TPL_TARGET_HAS_VALUE_SLOT",
                                 "target_line " + rel, s))
    for tid, t in data["templates"].items():
        w = "template " + tid
        kind = t.get("kind")
        if kind not in TEMPLATE_KINDS:
            out.append(Issue("TPL_BAD_SLOT", w, "kind %r" % kind))
            continue
        out.extend(_check_construct_decl(tid, t))
        nf = len(t.get("rels") or [])
        ne = len(t.get("entities") or [])
        params = t.get("params") or {}
        if kind == "mention" and nf:
            out.append(Issue("TPL_TARGET_HAS_VALUE_SLOT", w,
                             "a mention prints no fact"))
        for s in SLOT_RE.findall(t.get("text", "")):
            m = TPL_SLOT.match(s)
            if not m:
                out.append(Issue("TPL_BAD_SLOT", w, s))
                continue
            if m.group(1) is not None:
                k = int(m.group(1))
                if k >= nf:
                    out.append(Issue("TPL_BAD_SLOT", w, s))
                roles_k = ((t.get("roles") or [])[k]
                           if kind == "mixed" and
                           k < len(t.get("roles") or []) else ())
                if (kind in NO_VALUE_KINDS or
                        set(roles_k) & set(NO_VALUE_ROLES)) and \
                        m.group(2) in VALUE_PARTS:
                    out.append(Issue("TPL_TARGET_HAS_VALUE_SLOT", w, s))
            elif m.group(3) is not None:
                if int(m.group(3)) >= ne:
                    out.append(Issue("TPL_BAD_SLOT", w, s))
            elif m.group(5) not in params:
                out.append(Issue("TPL_BAD_SLOT", w, s))
        if kind == "mixed":
            rl = t.get("roles")
            if not (isinstance(rl, list) and len(rl) == nf and all(
                    isinstance(x, list) and x and
                    all(r in MIXED_ROLES for r in x) for x in rl)):
                out.append(Issue("TPL_BAD_SLOT", w, "a mixed template "
                                 "lists the roles of each fact it prints"))
        elif "roles" in t:
            out.append(Issue("TPL_BAD_SLOT", w, "roles on a %s template"
                             % kind))
    return out


def _check_construct_decl(tid, t):
    """S3: every to_construct template DECLARES its result (the new object)
    and its base (the objects it is built on), as argument positions of the
    fact it prints: result = arg 0, base = every other arg (the schema's
    convention for construction relations), identical for every template
    of the same relation. No other kind declares one."""
    from . import schema as S          # local: schema imports this module
    w = "template " + tid
    d = t.get("construct")
    if t.get("kind") != "to_construct":
        return [Issue("TPL_CONSTRUCT_DECL", w, "only a to_construct "
                      "template declares a construction")] if d else []
    rels = t.get("rels") or []
    if not isinstance(d, dict) or len(rels) != 1 or not rels[0]:
        return [Issue("TPL_CONSTRUCT_DECL", w, "missing or malformed "
                      "{result, base}")]
    out = []
    for rel in rels[0]:
        if rel not in S.CONSTRUCT_RELS:
            out.append(Issue("TPL_CONSTRUCT_DECL", w, "%s is not a "
                             "construction relation" % rel))
            continue
        n = len(S.RELS[rel][0])
        want = {"result": 0, "base": list(range(1, n)),
                "new_point": rel in S.CONSTRUCT_NEW_POINT,
                "mode": "join" if rel in S.CONSTRUCT_JOIN else "locate"}
        if d != want:
            # (so every template of one relation declares the same thing)
            out.append(Issue("TPL_CONSTRUCT_DECL", w, "%s: %r != %r"
                             % (rel, d, want)))
    ak = t.get("arg_kinds")
    if ak is not None and not (isinstance(ak, list) and all(
            isinstance(k, list) and k and all(
                x in S.ENTITY_KINDS or x in ENTITY_PSEUDO for x in k)
            for k in ak)):
        out.append(Issue("TPL_CONSTRUCT_DECL", w, "arg_kinds %r" % (ak,)))
    return out


def construct_decl(tset, rel):
    """(result arg index, [base arg indices], new_point, mode) of
    construction relation `rel`, as its templates declare it (mode 'join':
    join points the page shows; 'locate': find something); None when no
    template prints it."""
    for t in tset.templates.values():
        d = t.get("construct")
        if d and rel in (t.get("rels") or [[]])[0]:
            return d["result"], list(d["base"]), bool(d["new_point"]), \
                d["mode"]
    return None


def kind_ok(ent, k):
    """Does entity `ent` have kind k? A pseudo-kind names a kind plus a
    vertex count: 'triangle' is a polygon with 3 vertices. ONE matcher for
    template entity slots and arg_kinds (verifier semantics r1, V6:
    arg_kinds 'polygon' let construct_triangle print 'the triangle ABMH')."""
    base, n = ENTITY_PSEUDO.get(k, (k, None))
    return (ent or {}).get("kind") == base and (
        n is None or len((ent or {}).get("vertices") or []) == n)


def load_templates(path=TEMPLATES_JSON, approved=None):
    """Load and approve a template set. approved: the expected set hash
    (default: APPROVED_SET_SHA256)."""
    with open(path, encoding="utf-8") as fh:
        data = json.load(fh)
    want = APPROVED_SET_SHA256 if approved is None else approved
    if set_hash(data) != want:
        raise SpecError(Issue("TPL_SET_UNAPPROVED", path, set_hash(data)))
    bad = check_template_set(data)
    if bad:
        raise SpecError(bad)
    return TemplateSet(data)


# ------------------------------------------------------------- display ---
# (v6.16 gaps r2, G5) the printed name of a polygon declared by coordinates
# only (a tagged polygon, poly:<tag>): the sheet's noun, never letters
UNNAMED_POLYGON_NOUN = u"המצולע"
# (v6.16 gaps r2, G2 / T08B-D11) the printed name of the origin entity
ORIGIN_NOUN = u"נקודת המפגש של שני הצירים"


def entity_name(eid, ix, override=None):
    """Raw name: the fact's display override, else the canonical letters.
    Every printable kind has a letter name (verifier r2, R2-08: a line, ray,
    circle or arc used to print its raw id, "line:AB"); a kind with no
    printed name (table cell) is refused, never printed as an id."""
    if override:
        return override
    e = ix.entities.get(eid) or {}
    k = e.get("kind")
    if k == "point":
        return e.get("name", eid)
    if k in ("segment", "arc"):
        return "".join(sorted(e["ends"]))
    if k == "line":
        return e.get("name") or "".join(sorted(e["through"]))
    if k == "ray":
        return e["from"] + e["through"]
    if k == "angle":
        a = sorted(e["arms"])
        return a[0] + e["vertex"] + a[1]
    if k == "polygon":
        if e.get("tag") is not None:
            # (v6.16 gaps, G5) no letters. (r2, K4 of t08_c) the sheet's
            # own noun "המצולע", as the v6.7.3 builder rows name it ('שטח
            # המצולע', to_construct 'המצולע'): the vertex list printed
            # numbers the item's text does not (selfcheck_noam_package K15)
            # and no letter run (check_didactic D12). Its vertices keep
            # their public places ("(6, 3)", _vertex_place)
            return UNNAMED_POLYGON_NOUN
        return "".join(canon.canon_cycle(e["vertices"]))
    if k == "vertex":
        return _vertex_place(eid, ix)
    if k == "origin":
        # (v6.16 gaps, G2) (r2, T08B-D11) not its letter O -- the sheets
        # never print it (noam K6) -- and not its term 'ראשית הצירים', which
        # b 1ב / 8ד ask for: the words the questions themselves use
        return ORIGIN_NOUN
    if k == "circle":
        return e.get("name") or e["center"]
    if k in ("variable", "axis", "plane"):
        return e.get("name", eid)
    if k == "number":
        # (v6.12) U+2212 and the number's printed form (plain p/q; a
        # template puts a number slot inside a math island: entity_display)
        return canon.family_display(e["value"], "plain", e.get("form"))
    if k == "jump":
        return "%s→%s" % (entity_name(e["from"], ix),
                          entity_name(e["to"], ix))
    if k == "interval":
        return "%s%s, %s%s" % ("[" if e["lo_in"] else "(",
                               entity_name(e["lo"], ix),
                               entity_name(e["hi"], ix),
                               "]" if e["hi_in"] else ")")
    if k == "tick":
        return canon.number_display(canon.canon_number(e["at"]))
    if k == "sector":
        # (v6.16 integrate) a pie sector is named by its printed label
        # ('A', 'כדורגל'); a pie / an empty build circle has no printed name
        return e.get("name", eid)
    # (v6.10) a cline has NO name on the sheet: a template prints its
    # parts ({e0.through}, {e0.base}), never the object as if named
    raise SpecError(Issue("TPL_NO_NAME", eid, "a %s has no printed name" % k))


def _vertex_place(eid, ix):
    """(v6.16 gaps, G5) an unnamed vertex has no letter: it is named by its
    PUBLIC place '(x, y)' (given / context coordinate facts, never an
    answer); a vertex whose place is not public has no printed name."""
    xy = {}
    for f in sorted(ix.facts.values(), key=lambda f: str(f.get("id"))):
        a = f.get("args") or []
        if f.get("rel") == "coordinate" and len(a) == 2 and a[0] == eid and \
                f.get("role") in ("given", "context") and \
                f.get("value") is not None:
            xy.setdefault(a[1], f["value"])
    if "axis:x" not in xy or "axis:y" not in xy:
        raise SpecError(Issue("TPL_NO_NAME", eid, "an unnamed vertex whose "
                              "place is not public has no printed name"))
    return "(%s, %s)" % (canon.family_display(xy["axis:x"], "plain", None),
                         canon.family_display(xy["axis:y"], "plain", None))


def entity_display(eid, ix, mode, override=None):
    e = ix.entities.get(eid) or {}
    if not override and mode in ("tex", "sheet") and \
            e.get("kind") in ("number", "jump", "interval"):
        # (v6.12) bare maths (\f{p}{q}, U+2212), for a math island
        if e["kind"] == "number":
            return canon.family_display(e["value"], "tex", e.get("form"))
        a, b = ENTITY_PARTS[e["kind"]]
        x, y = entity_display(e[a], ix, mode), entity_display(e[b], ix, mode)
        if e["kind"] == "jump":
            return "%s → %s" % (x, y)
        return "%s%s, %s%s" % ("[" if e["lo_in"] else "(", x, y,
                               "]" if e["hi_in"] else ")")
    n = entity_name(eid, ix, override)
    if ix.kind(eid) == "angle":
        return "$\\angle{%s}$" % n if mode in ("tex", "sheet") else "∠" + n
    return n


def _disp(f, k):
    d = f.get("display")
    return d[k] if isinstance(d, list) and k < len(d) else None


def _value_text(f, mode="tex", ix=None):
    from . import schema as S          # local: schema imports this module
    if f.get("rel") in S.FAMILY_RELS and canon.parse_exact(f["value"])[2] \
            == 1:
        # (v6.12) a family value: U+2212, its printed form, a jump with
        # its sign; bare maths in tex / sheet (the template's math island)
        return canon.family_display(f["value"], "plain" if mode == "plain"
                                    else "tex", f.get("form"),
                                    signed=f.get("rel") == "jump_value")
    if f.get("role") == "answer" and canon.is_irrational(f["value"]):
        sheet = ix.spec.get("sheet") if ix is not None else None
        t = canon.answer_surd_plain(f["value"], sheet) if mode == "plain" \
            else "$%s$" % canon.answer_surd_tex(f["value"], sheet)
    else:
        t = canon.number_display(canon.canon_number(f["value"]))
    if f.get("role") == "answer" and f.get("approx") in \
            canon.APPROX_DECIMALS and canon.is_irrational(f["value"]):
        # (v6.17, V3 / D6) the exact value, then its rounding
        t += " ≈ " + canon.approx_text(f["value"], f["approx"])
    return t


def jump_words(tset, value, form=None, mode="tex"):
    """(v6.13, author decision W-NL-JUMP-DIRECTION) a jump as its POSITIVE
    size plus a direction word: -5 -> '$5$ יחידות שמאלה' (tex / sheet) or
    '5 יחידות שמאלה' (plain); 1 -> 'יחידה אחת ימינה'. The number line runs
    left to right, so a negative jump goes left. Never a signed value."""
    w = tset.jump_words
    a, b, r = canon.parse_exact(value)
    if r != 1 or a == 0:
        raise SpecError(Issue("VALUE_REQUIRED", "jump_words",
                              "a jump needs a non-zero rational size"))
    num, den = a.numerator, a.denominator
    size = "%d/%d" % (abs(num), den) if den != 1 else str(abs(num))
    if abs(a) == 1:
        amount = w["one"]
    else:
        n = canon.family_display(size, "plain" if mode == "plain" else "tex",
                                 form)
        amount = w["many"].replace("{n}", n if mode == "plain"
                                   else "$%s$" % n)
    return "%s %s" % (amount, w["left"] if num < 0 else w["right"])


def _unit_text(f):
    u = canon.canon_unit(f.get("unit"))
    # (v6.17, V5) '1 דקה' / '6 דקות': the unit agrees with its value
    return canon.unit_display(u, f.get("value")) if u else ""


def _fill(text, fn):
    return SLOT_RE.sub(lambda m: fn(m.group(1)), text)


# v6.11 fix r1 (author decision W-TRIANGLE-SYMBOL, wspec/approvals/
# APPROVALS_NOAM.json): the triangle sign is ALWAYS printed before a
# triangle's name, also after the word "משולש" ("במשולש △ABC", "שטח המשולש
# △AEB"). ONE rule for every slot that prints a triangle by name (template
# {eK} / {fK.q} / {fK.argN}, phrase {nK} / {aK}, target line {nK}); a slot
# the text already prefixes with the sign (△, \tri, "$\tri$ ") is left as
# it is, so no sign is ever printed twice.
_TRI_BEFORE = re.compile(r"(?:△|\\tri\$?)\s*$")


def is_triangle(eid, ix):
    # (v6.16 gaps r2, G5) a tagged (unnamed) polygon is named by the noun
    # UNNAMED_POLYGON_NOUN, never by letters: no triangle sign before it
    e = ix.entities.get(eid) or {}
    return kind_ok(e, "triangle") and e.get("tag") is None


def _tri_name(name, before, mode):
    """A triangle's printed name `name` at a slot whose preceding text is
    `before`: with the sign, in the form of the slot's context (plain:
    '△ABC'; tex / sheet: '\\tri ABC' inside a math island, else
    '$\\tri ABC$')."""
    if _TRI_BEFORE.search(before):
        return name
    if mode == "plain":
        return "△" + name
    inside = (len(re.findall(r"(?<!\\)\$", before)) % 2) == 1
    return ("\\tri " + name) if inside else "$\\tri %s$" % name


def _fill_at(text, fn):
    """_fill whose slot function also gets the text before the slot."""
    return SLOT_RE.sub(lambda m: fn(m.group(1), text[:m.start()]), text)


def _phrase(tset, f, ix, mode, where, allow_value=True, with_unit=True):
    """The relation phrase of a fact (value from the fact itself).
    with_unit=False (v6.10, the 'eq' slot part): the phrase without its
    unit, for a template that prints the unit once for several facts."""
    ph = tset.phrases.get(phrase_key(tset, f, ix, mode))
    if not ph:
        raise SpecError(Issue("TPL_REL_MISMATCH", where,
                              "no phrase for %s" % f.get("rel")))
    args = f.get("args") or []

    def slot(s, before=""):
        if s == "expr":
            return relation_expr(f, ix, mode, where, with_unit=with_unit)
        if s == "v":
            if not allow_value:
                raise SpecError(Issue("TPL_PRINTS_TARGET_VALUE", where,
                                      f.get("id")))
            if f.get("value") is None:
                raise SpecError(Issue("VALUE_REQUIRED", where, f.get("id")))
            return _value_text(f, mode, ix)
        if s == "vd":
            # (v6.13, W-NL-JUMP-DIRECTION) positive size + direction word
            if not allow_value:
                raise SpecError(Issue("TPL_PRINTS_TARGET_VALUE", where,
                                      f.get("id")))
            if f.get("value") is None:
                raise SpecError(Issue("VALUE_REQUIRED", where, f.get("id")))
            return jump_words(tset, f["value"], f.get("form"), mode)
        if s == "u":
            return _unit_text(f) if f.get("value") is not None and \
                with_unit else ""
        k = int(s[1:])
        if k >= len(args):
            raise SpecError(Issue("TPL_BAD_SLOT", where, s))
        if is_triangle(args[k], ix):                     # v6.11 fix r1
            return _tri_name(entity_name(args[k], ix, _disp(f, k)), before,
                             "plain" if mode == "plain" else "tex")
        if s[0] == "n":
            return entity_name(args[k], ix, _disp(f, k))
        return entity_display(args[k], ix, mode, _disp(f, k))
    # 'sheet' (v6.9 fix r1): the worksheet's form where the phrase has one,
    # else its tex form
    return _fill_at(ph.get(mode) or ph["tex"] if mode == "sheet" else
                    ph[mode], slot)


# ------------------------------------------ v6.10: relations of quantities -
def _coef_text(c, mode):
    """A coefficient before a term: 1 -> '', 2 -> '2', 1/2 -> '\\f{1}{2}'
    (tex / sheet) or '½' (plain)."""
    if c == 1:
        return ""
    cs = canon.canon_number(str(c))
    if c.denominator == 1:
        return cs
    if mode == "plain":
        return PLAIN_FRACTIONS.get(cs, cs + "·")
    return "\\f{%d}{%d}" % (c.numerator, c.denominator)


def _term(eid, ix, mode, where, override=None):
    k = ix.kind(eid)
    n = entity_name(eid, ix, override)
    if k == "angle":
        return "∠" + n if mode == "plain" else "\\angle{%s}" % n
    if k in ("segment", "variable"):
        return n
    if k == "polygon" and mode == "plain":
        # an AREA term, in words (the description Noam AI reads): "שטח
        # △ABO"; on the sheet an area relation prints only through its own
        # templates (prove_area_equal / prove_area_fraction_compute)
        e = ix.entities.get(eid) or {}
        return u"שטח " + (u"△" + n if kind_ok(e, "triangle") else n)
    raise SpecError(Issue("TPL_REL_MISMATCH", where, "%s: a %s term prints "
                          "only through its own template (area words)"
                          % (eid, k)))


def relation_expr(f, ix, mode, where, with_unit=True):
    """The maths of a 'linear' / 'greater' fact, generated by one fixed rule
    from its arguments, coefficients and constant: 'BD = ½AC',
    '$\\angle{DMB} = 2\\angle{A}$', '$AC = 3x + 4$ ס״מ'. In tex / sheet
    mode the relation is ONE math island (a relation never breaks across a
    line, and RTL text never reorders its terms); a length / area
    constant's unit follows the island (with_unit)."""
    from . import language as LANG
    args = f.get("args") or []
    rel = f.get("rel")
    terms = [_term(a, ix, mode, where, _disp(f, k))
             for k, a in enumerate(args)]
    if rel == "greater":
        body = "%s > %s" % (terms[0], terms[1])
        unit = ""
    else:
        try:
            cs = LANG.coefs(f)
        except Exception:                   # noqa: BLE001
            raise SpecError(Issue("TPL_REL_MISMATCH", where, "coef of %s"
                                  % f.get("id")))
        parts = []
        for c, t in zip(cs, terms[1:]):
            sgn = "-" if c < 0 else "+"
            ct = _coef_text(abs(c), mode)
            parts.append((sgn, ct + (" " if ct and t[:1] >= u"\u05d0"
                                     else "") + t))
        unit = ""
        if f.get("value") is not None:
            a, b, r = canon.parse_exact(f["value"])
            neg = (a < 0) if r == 1 else (a < 0 if a != 0 else b < 0)
            v = canon.canon_number(f["value"])
            mag = canon.number_display(v[1:] if neg else v).replace("$", "")
            if canon.canon_unit(f.get("unit")) == "deg":
                mag += "°"
            elif f.get("unit") and with_unit:
                unit = _unit_text(f)
            parts.append(("-" if neg else "+", mag))
        rhs = ""
        for i, (sgn, x) in enumerate(parts):
            if i == 0:
                rhs = ("-" if sgn == "-" else "") + x
            else:
                rhs += " %s %s" % (sgn, x)
        body = "%s = %s" % (terms[0], rhs)
    if mode == "plain":
        return body + unit
    return "$%s$%s" % (body, unit)


def _tri(eid, ix, mode, where, override=None):
    """A triangle argument as '$\\tri ABC$' (tex / sheet) or '△ABC'."""
    e = ix.entities.get(eid) or {}
    if not kind_ok(e, "triangle"):
        raise SpecError(Issue("TPL_REL_MISMATCH", where, "%s is not a "
                              "triangle" % eid))
    n = entity_name(eid, ix, override)
    return "△" + n if mode == "plain" else "$\\tri %s$" % n


def rel_key(f, ix):
    """The phrase / target-line key of a fact: its relation, except that a
    classify says what it classifies (v6.10 fix r2, N1: "סוג המרובע ABCD",
    as v6.7.3's find printed it, not "סוג ABCD")."""
    rel = f.get("rel")
    if rel == "sector_equal" and sector_equal_all(f, ix):
        return "sector_equal_all"                 # v6.16 integrate r2 (IR2)
    if rel != "classify":
        return rel
    args = f.get("args") or []
    e = ix.entities.get(args[0]) if args else None
    n = len((e or {}).get("vertices") or [])
    return {4: "classify", 3: "classify_triangle"}.get(n, "classify_polygon")


def sector_equal_all(f, ix):
    """(v6.16 integrate r2, pie IR2) a sector_equal over THREE or more
    sectors that are EVERY sector of their pie ('בעוגה שלוש גזרות שוות זו
    לזו'): its line is 'sector_equal_all', which names no sector (a disc of
    equal sectors prints no name: the handles are never printed). A group of
    three or more that is not the whole pie has no line (refused on a sheet,
    sheet_pie.validate)."""
    args = f.get("args") or []
    if f.get("rel") != "sector_equal" or len(args) <= 2:
        return False
    ents = getattr(ix, "entities", None) or {}
    pies = set((ents.get(a) or {}).get("pie") for a in args)
    if len(pies) != 1 or None in pies:
        return False
    pid = pies.pop()
    every = set(eid for eid, e in ents.items()
                if (e or {}).get("kind") == "sector" and e.get("pie") == pid)
    return set(args) == every


# v6.13 fix_r1 (C5, N-6.3): on a NUMBER LINE the axis is an internal name
# ('n'): the printed sheet never says "ציר n", so a target line of a point's
# value or of the tick difference on a number line uses its own line --
# "המספר שמייצגת הנקודה P" / "... על ישר המספרים" (W-NL-TICK-DIFFERENCE) --
# never "שיעור n של P" / "על ציר n". A plane's axes keep their lines.
NL_TARGET_RELS = {"coordinate": 1, "interval_value": 0}


def is_nl_axis(ix, aid):
    """is aid the axis of a NUMBER LINE (a figure frame of family
    number_line names it)? A plane's axes (axis:x / axis:y) are not."""
    for g in (getattr(ix, "spec", None) or {}).get("figures") or []:
        fr = (g or {}).get("frame") or {}
        if fr.get("family") == "number_line" and fr.get("axis") == aid:
            return True
        if fr.get("family") == "coordinate_plane" and aid in [
                (a or {}).get("axis") for a in fr.get("axes") or []]:
            return False
    return aid == "axis:n"


# v6.13 fix_r2 (R1-plane-interval-tick-wording): on a coordinate plane WITH
# A GRID the renderer draws a tick only on a numbered grid line, so "two
# neighbouring ticks" may be two labels apart (T08 a q4: ticks 20 apart, the
# interval 10). There the metadata line of the interval value names the
# grid lines -- the original sheet's own words (T08 a q3: "כל מרווח בין שני
# קווי רשת סמוכים"): "<rel>_grid". Printed text never changes (the tex /
# sheet forms of the _grid phrase equal the base phrase's).
GRID_TARGET_RELS = {"interval_value": 0}
_QID = re.compile(r"^(q\d+)")


def is_grid_axis(ix, aid, item):
    """is aid an axis of a coordinate plane WITH A GRID in the question of
    `item` (every such frame of that question has a grid)?"""
    m = _QID.match(item or "")
    if not m:
        return False
    q = m.group(1)
    seen = []
    for g in (getattr(ix, "spec", None) or {}).get("figures") or []:
        g = g or {}
        fr = g.get("frame") or {}
        sm = _QID.match(g.get("scope") or "")
        if not sm or sm.group(1) != q or \
                fr.get("family") != "coordinate_plane" or aid not in [
                    (a or {}).get("axis") for a in fr.get("axes") or []]:
            continue
        seen.append(bool(fr.get("grid")))
    return bool(seen) and all(seen)


# (v6.16 integrate r2) a sector its figure prints NO name for -- a sector of
# a names-"none" disc or an undivided REGION (wspec-pie/1.1) -- is never
# named in a metadata line: its entity name is a never-printed handle. Its
# relations take the '<rel>_unnamed' line (no {n0}; PENDING the author,
# wspec/PENDING_V616.txt s4). sector_equal takes it when every sector it
# names is unnamed (the whole pie: sector_equal_all, rel_key).
SECTOR_UNNAMED_RELS = ("sector_value", "sector_angle", "sector_percent",
                       "sector_count", "sector_equal")


def sector_unnamed(ix, sid):
    """True when every pie_chart figure part that draws sector sid's pie
    prints no name for it (names "none", or sid is one of its regions)"""
    ent = (getattr(ix, "entities", None) or {}).get(sid) or {}
    if ent.get("kind") != "sector":
        return False
    seen = []
    for g in (getattr(ix, "spec", None) or {}).get("figures") or []:
        fr = (g or {}).get("frame") or {}
        if fr.get("family") != "pie_chart":
            continue
        for p in fr.get("parts") or []:
            if isinstance(p, dict) and p.get("part") == "pie" and \
                    p.get("pie") == ent.get("pie"):
                seen.append(p.get("names") == "none" or
                            sid in (p.get("regions") or []))
    return bool(seen) and all(seen)


def _unnamed_variant(table, f, ix, k):
    args = f.get("args") or []
    if k in SECTOR_UNNAMED_RELS and (k + "_unnamed") in table and args and \
            all(sector_unnamed(ix, a) for a in args):
        return k + "_unnamed"
    return None


def _variant(table, f, ix, k):
    """the '<k>_nl' / '<k>_grid' key of fact f when the table has it
    (and a pie sector's '<k>_unnamed', integrate r2)."""
    u = _unnamed_variant(table, f, ix, k)
    if u:
        return u
    args = f.get("args") or []
    i = NL_TARGET_RELS.get(k)
    if i is not None and len(args) > i and is_nl_axis(ix, args[i]) and \
            (k + "_nl") in table:
        return k + "_nl"
    i = GRID_TARGET_RELS.get(k)
    if i is not None and len(args) > i and \
            is_grid_axis(ix, args[i], f.get("item")) and \
            (k + "_grid") in table:
        return k + "_grid"
    return k


def target_key(tset, f, ix):
    """the target_lines key of a fact: rel_key, or its number-line line
    ('<rel>_nl') when the fact's axis is a number line's, or its grid line
    ('<rel>_grid', v6.13 fix_r2) on a gridded coordinate plane."""
    return _variant(tset.target_lines, f, ix, rel_key(f, ix))


def phrase_key(tset, f, ix, mode):
    """the phrases key of a fact: rel_key; in the PLAIN form (metadata:
    given lines, noam-ai.json) a number line's axis is not named 'n'
    ('<rel>_nl', v6.13 fix_r1) and a gridded plane's interval names its
    grid lines ('<rel>_grid', fix_r2). The printed tex / sheet forms of the
    _nl / _grid phrases equal the base phrase's, so no printed text
    changes."""
    k = rel_key(f, ix)
    if mode == "plain":
        return _variant(tset.phrases, f, ix, k)
    # (integrate r2) a pie sector's line never names an unprinted handle,
    # in any form (pie lines are metadata: a pie question prints its own
    # words as bound prose)
    return _unnamed_variant(tset.phrases, f, ix, k) or k


def classify_what(tset, f, ix):
    """The target line of a classify without its name ("סוג המרובע")."""
    return " ".join(_fill(tset.target_lines[rel_key(f, ix)],
                          lambda s: "").split())


def target_line(tset, f, ix):
    """The public description of a target (never its value)."""
    from . import point_transform as PT
    transform_text = PT.description(ix.spec, f)
    if transform_text is not None:
        return transform_text
    tl = tset.target_lines.get(target_key(tset, f, ix))
    args = f.get("args") or []
    if tl is None:
        return None

    def slot(s, before=""):
        k = int(s[1:])
        if is_triangle(args[k], ix):                     # v6.11 fix r1
            return _tri_name(entity_name(args[k], ix, _disp(f, k)), before,
                             "plain")
        if s[0] == "n":
            return entity_name(args[k], ix, _disp(f, k))
        return entity_display(args[k], ix, "plain", _disp(f, k))
    return _fill_at(tl, slot)


def fact_line(tset, f, ix):
    """The given-list line of a public given/context fact, the plain
    phrase of a to_prove, or the value-free description of a target /
    to_construct (its target_lines template)."""
    tid = f.get("text_template")
    where = "fact %s" % f.get("id")
    if tid:
        t = tset.templates.get(tid)
        if t is None or t.get("kind") != "line":
            raise SpecError(Issue("TPL_UNKNOWN", where, repr(tid)))
        return render_fragment(tset, {"tpl": tid, "facts": [f["id"]]}, ix,
                               where, mode="plain")[0]
    if f.get("role") in ("target", "to_construct", "to_plot"):
        # a target and a construction task are described by their
        # target_lines template (no value slot). A to_construct used to
        # fall through to _phrase(), which has no 'construct' entry, so a
        # valid construct item could never be exported (verifier r3, R3-01)
        line = target_line(tset, f, ix)
        if line is None:
            raise SpecError(Issue("TPL_REL_MISMATCH", where,
                                  "no target line for %s" % f.get("rel")))
        return line
    if f.get("role") == "answer":
        raise SpecError(Issue("TPL_PRINTS_ANSWER", where, f.get("id")))
    return _phrase(tset, f, ix, "plain", where)


# -------------------------------------------------------------- render ---
def _check(check, facts, ents, ix, where, ctx=None):
    name = check[0]
    ctx = ctx or {}

    def ref(r):
        if r.startswith("p."):
            return (ctx.get("params") or {}).get(r[2:])
        if r.startswith("#"):
            return r[1:]
        if r.startswith("f"):
            i, _, part = r[1:].partition(".")
            f = facts[int(i)]
            if not part:
                return f
            return (f.get("args") or [])[int(part[3:])]
        return ents[int(r[1:])]
    if name in LANG_CHECKS:
        try:
            ok = LANG_CHECKS[name](check, ref, ix, ctx)
        except SpecError:
            raise
        except Exception:                   # noqa: BLE001 -- bad shapes
            ok = False
        if not ok:
            raise SpecError(Issue(
                "LANG_TEXT_CHECK" if name in SCOPE_CHECKS else
                "TPL_CONSTRAINT", where, repr(check)))
        return
    if name == "same":
        ok = ref(check[1]) == ref(check[2])
    elif name == "median":
        seg = ix.entities.get(ref(check[1])) or {}
        f = ref(check[2])
        m, side = f["args"][0], ix.entities.get(f["args"][1]) or {}
        ends = seg.get("ends") or []
        other = [p for p in ends if p != m]
        ok = m in ends and len(other) == 1 and \
            other[0] not in (side.get("ends") or [])
    elif name == "diagonals":
        poly = ix.entities.get(ref(check[1])) or {}
        vs = poly.get("vertices") or []
        diags = set()
        if len(vs) == 4:
            diags = {canon.entity_id({"kind": "segment",
                                      "ends": [vs[0], vs[2]]}),
                     canon.entity_id({"kind": "segment",
                                      "ends": [vs[1], vs[3]]})}
        got = {ref(check[2])["args"][1], ref(check[3])["args"][1]}
        ok = len(got) == 2 and got == diags
    elif name == "cevian":
        # a segment from ONE vertex of a triangle to a point that is not a
        # vertex (an altitude / a median)
        seg = ix.entities.get(ref(check[1])) or {}
        poly = ix.entities.get(ref(check[2])) or {}
        vs = poly.get("vertices") or []
        ends = seg.get("ends") or []
        ok = len(vs) == 3 and len([p for p in ends if p in vs]) == 1
    elif name == "ray_from_vertex":
        # the bisector starts at the angle's vertex, between its arms
        ray = ix.entities.get(ref(check[1])) or {}
        ang = ix.entities.get(ref(check[2])) or {}
        ok = ray.get("from") == ang.get("vertex") and \
            ray.get("through") not in (ang.get("arms") or [])
    elif name == "bisector_to_side":
        # (v6.9 fix r1, C2) e0 = the whole angle XVY; f0 = equal_angle of
        # its two parts XVP and PVY (vertex V, the shared arm through P);
        # f1 = on_segment(P, side): the bisector VP meets the side at P
        ang = ix.entities.get(ref(check[1])) or {}
        f0, f1 = ref(check[2]), ref(check[3])
        parts = [ix.entities.get(a) or {} for a in f0.get("args") or []]
        v = ang.get("vertex")
        arms = set(ang.get("arms") or [])
        p = (f1.get("args") or [None])[0]
        ok = len(parts) == 2 and v is not None and len(arms) == 2 and \
            all(x.get("kind") == "angle" and x.get("vertex") == v and
                p in (x.get("arms") or []) for x in parts) and \
            set(a for x in parts for a in x.get("arms") or []
                if a != p) == arms and p not in arms
    elif name == "altitude_to_diagonal":
        # (v6.9 fix r1, C2) e0 = vertex B of polygon e1; f0 =
        # perpendicular(diagonal, BH); f1 = on_segment(H, diagonal): the
        # diagonal joins two opposite vertices of e1 and B is neither
        # and e2 = BH, the perpendicular's other segment (any arg order)
        b, poly = ref(check[1]), ix.entities.get(ref(check[2])) or {}
        alt_id = ref(check[3])
        f0, f1 = ref(check[4]), ref(check[5])
        a0 = list(f0.get("args") or [])
        a1 = f1.get("args") or []
        vs = poly.get("vertices") or []
        diag = ix.entities.get(a1[1]) if len(a1) == 2 else None
        alt = ix.entities.get(alt_id) or {}
        ok = len(vs) == 4 and diag is not None and len(a0) == 2 and \
            sorted(a0) == sorted([a1[1], alt_id]) and b in vs and \
            set(diag.get("ends") or []) in ({vs[0], vs[2]}, {vs[1], vs[3]}) \
            and b not in (diag.get("ends") or []) and \
            set(alt.get("ends") or []) == {b, a1[0]} and a1[0] != b
    elif name == "not_an_end":
        seg = ix.entities.get(ref(check[2])) or {}
        ok = ref(check[1]) not in (seg.get("ends") or [])
    elif name == "through":
        ok = ref(check[2]) in _defining_points(ref(check[1]), ix)
    elif name == "distinct_lines":
        ok = set(_defining_points(ref(check[1]), ix)) != \
            set(_defining_points(ref(check[2]), ix))
    else:
        ok = False
    if not ok:
        raise SpecError(Issue("TPL_CONSTRAINT", where, repr(check)))


def _defining_points(eid, ix):
    e = ix.entities.get(eid) or {}
    k = e.get("kind")
    if k in ("segment", "line"):
        return list(e.get("ends") or e.get("through") or [])
    if k == "ray":
        return [e.get("from"), e.get("through")]
    return []


# ------------------------------------------ v6.10: the language checks ---
# check name -> fn(check, ref, ix, ctx) -> bool. ref resolves "f0",
# "f0.arg1", "e0", "p.<param>" and "#<literal>". The SCOPE checks read the
# question / item the text belongs to (ctx["scope"]): which classes it
# states, which items come before it -- a failure there is LANG_TEXT_CHECK.
SHAPE_RELS = ("rectangle", "square", "parallelogram", "rhombus",
              "trapezoid", "isosceles_trapezoid", "equilateral", "isosceles",
              "right_triangle", "acute_triangle", "obtuse_triangle")


def _visible(ix, scope, roles=("given", "to_prove")):
    if scope is None:
        return []
    vis = set(ix.visible_scopes(scope))
    return [f for f in ix.facts.values()
            if f.get("item") in vis and f.get("role") in roles]


def _classes_of(ix, scope, poly):
    return set(f.get("rel") for f in _visible(ix, scope)
               if f.get("rel") in SHAPE_RELS and
               (f.get("args") or [None])[0] == poly)


def _verts(ix, eid):
    return list((ix.entities.get(eid) or {}).get("vertices") or [])


def _ends(ix, eid):
    return list((ix.entities.get(eid) or {}).get("ends") or [])


def _angle_at(ix, aid, vs):
    """The vertex of angle aid when it is the interior angle of the polygon
    with vertices vs at that vertex, else None."""
    a = ix.entities.get(aid) or {}
    v = a.get("vertex")
    if a.get("kind") != "angle" or v not in vs:
        return None
    i = vs.index(v)
    want = set([vs[i - 1], vs[(i + 1) % len(vs)]])
    return v if set(a.get("arms") or []) == want else None


def _ck_noun(c, ref, ix, ctx):
    poly, w = ref(c[1]), ref(c[2])
    n, classes = NOUN_CLASS[w]
    return len(_verts(ix, poly)) == n and (
        classes is None or bool(set(classes) &
                                _classes_of(ix, ctx.get("scope"), poly)))


def _ck_the_shape(c, ref, ix, ctx):
    poly, w = ref(c[1]), ref(c[2])
    classes = NOUN_CLASS[w][1] or ()
    polys = set((f.get("args") or [None])[0]
                for f in _visible(ix, ctx.get("scope"))
                if f.get("rel") in classes)
    return polys == set([poly])


def _ck_shape_word(c, ref, ix, ctx):
    return ref(c[1]).get("rel") in (NOUN_CLASS[ref(c[2])][1] or ())


def _altitude(ix, tri, seg, perp, on):
    vs = _verts(ix, tri)
    ends = _ends(ix, seg)
    foot, side = (on.get("args") or [None, None])[:2]
    se = _ends(ix, side)
    if len(vs) != 3 or len(ends) != 2 or foot not in ends:
        return False
    v = [p for p in ends if p != foot]
    from .baseline import _line_key
    pk = sorted(map(str, [_line_key(a, ix) for a in perp.get("args") or []]))
    return len(v) == 1 and v[0] in vs and set(se) == set(vs) - set(v) and \
        on.get("rel") == "on_segment" and \
        perp.get("rel") == "perpendicular" and \
        pk == sorted(map(str, [_line_key(seg, ix), _line_key(side, ix)]))


def _ck_altitude_in(c, ref, ix, ctx):
    return _altitude(ix, ref(c[1]), ref(c[2]), ref(c[3]), ref(c[4]))


def _ck_median_in(c, ref, ix, ctx):
    tri, seg, mid = ref(c[1]), ref(c[2]), ref(c[3])
    vs = _verts(ix, tri)
    m, side = (mid.get("args") or [None, None])[:2]
    ends = _ends(ix, seg)
    v = [p for p in ends if p != m]
    return mid.get("rel") == "midpoint" and len(vs) == 3 and m in ends and \
        len(v) == 1 and v[0] in vs and \
        set(_ends(ix, side)) == set(vs) - set(v)


def _ck_end_of(c, ref, ix, ctx):
    return ref(c[1]) in _ends(ix, ref(c[2]))


def _ck_right_at(c, ref, ix, ctx):
    tri, v = ref(c[1]), ref(c[2])
    vs = _verts(ix, tri)
    from .baseline import _right_angle
    for f in _visible(ix, ctx.get("scope"), ("given",)):
        if f.get("rel") == "angle_measure" and _right_angle(f) and \
                _angle_at(ix, (f.get("args") or [None])[0], vs) == v:
            return True
    return False


def _ck_distinct(c, ref, ix, ctx):
    return ref(c[1]) != ref(c[2])


def _ck_piece_of(c, ref, ix, ctx):
    """the segment joins the point to an end of the side it lies on
    (DE for E on DC)"""
    seg, p, side = ref(c[1]), ref(c[2]), ref(c[3])
    ends = set(_ends(ix, seg))
    return p in ends and len(ends) == 2 and \
        (ends - set([p])) <= set(_ends(ix, side))


def _ck_seg_ends(c, ref, ix, ctx):
    return set(_ends(ix, ref(c[1]))) == set([ref(c[2]), ref(c[3])])


def _ck_par_line(c, ref, ix, ctx):
    """e0 = the drawn line MN, e1 = the side AD; f0 = parallel(MN, AD);
    f1 = P on MN; f2 = M on side 1, f3 = N on side 2 (M, N the ends of
    MN, the sides other than AD)"""
    ln, side, par, onp, om, on_ = (ref(x) for x in c[1:7])
    from .baseline import _line_key
    pk = sorted(map(str, [_line_key(a, ix) for a in par.get("args") or []]))
    ends = _ends(ix, ln)
    return par.get("rel") == "parallel" and \
        pk == sorted(map(str, [_line_key(ln, ix), _line_key(side, ix)])) \
        and onp.get("rel") == "on_segment" and \
        (onp.get("args") or [None, None])[1] == ln and \
        (onp.get("args") or [None])[0] not in ends and \
        set([(om.get("args") or [None])[0],
             (on_.get("args") or [None])[0]]) == set(ends) and \
        len(ends) == 2 and all(
            (x.get("args") or [None, None])[1] not in (side, ln)
            for x in (om, on_))


def _ck_side_of_shape(c, ref, ix, ctx):
    seg, w = ref(c[1]), ref(c[2])
    n, classes = NOUN_CLASS[w]
    ends = set(_ends(ix, seg))
    for e in ix.entities.values():
        vs = e.get("vertices") or []
        if e.get("kind") != "polygon" or len(vs) != n:
            continue
        sides = [set([vs[i], vs[(i + 1) % n]]) for i in range(n)]
        if ends in sides and (classes is None or set(classes) &
                              _classes_of(ix, ctx.get("scope"), e["id"])):
            return True
    return False


def _ck_same_value(c, ref, ix, ctx):
    f, g = ref(c[1]), ref(c[2])
    return f.get("value") is not None and g.get("value") is not None and \
        canon.same_quantity(f["value"], f.get("unit"), g["value"],
                            g.get("unit"))


def _ck_same_unit(c, ref, ix, ctx):
    us = [canon.canon_unit(ref(x).get("unit")) for x in c[1:]]
    return us[0] is not None and len(set(us)) == 1 and \
        canon.unit_dimension(us[0]) in ("length", "area")


def _lin(f):
    from . import language as LANG
    return f.get("rel") == "linear", LANG.coefs(f)


def _ck_lin_equal(c, ref, ix, ctx):
    f = ref(c[1])
    ok, cs = _lin(f)
    return ok and cs == [1] and f.get("value") is None and \
        all(ix.kind(a) == "polygon" for a in f.get("args") or [])


def _ck_lin_fraction(c, ref, ix, ctx):
    f, w = ref(c[1]), ref(c[2])
    ok, cs = _lin(f)
    return ok and len(cs) == 1 and \
        canon.canon_number(str(cs[0])) == FRACTION_WORDS[w] and \
        f.get("value") is None and \
        all(ix.kind(a) == "polygon" for a in f.get("args") or [])


def _ck_lin_mult_plus(c, ref, ix, ctx):
    f, w = ref(c[1]), ref(c[2])
    ok, cs = _lin(f)
    if not ok or len(cs) != 1 or f.get("value") is None:
        return False
    a, b, r = canon.parse_exact(f["value"])
    return canon.canon_number(str(cs[0])) == MULT_WORDS[w] and r == 1 and \
        a > 0


def _ck_triangle_angles(c, ref, ix, ctx):
    vs = _verts(ix, ref(c[1]))
    at = [_angle_at(ix, (ref(x).get("args") or [None])[0], vs)
          for x in c[2:]]
    return len(vs) == 3 and None not in at and len(set(at)) == len(at)


def _ck_third_known(c, ref, ix, ctx):
    vs = _verts(ix, ref(c[1]))
    at = set(_angle_at(ix, (ref(x).get("args") or [None])[0], vs)
             for x in c[2:])
    rest = [v for v in vs if v not in at]
    if len(rest) != 1:
        return False
    for f in _visible(ix, ctx.get("scope")):
        if f.get("rel") == "angle_measure" and \
                f.get("value") is not None and \
                _angle_at(ix, (f.get("args") or [None])[0], vs) == rest[0]:
            return True
    return False


def _item_pos(ix, scope):
    k = ix.scope_key.get(scope)
    return k if k is not None and k[1] >= 0 else None


def _ck_earlier_item(c, ref, ix, ctx):
    scope, lab = ctx.get("scope"), ref(c[1])
    k = _item_pos(ix, scope)
    if k is None:
        return False
    q = ix.questions.get(ix.scope_question.get(scope)) or {}
    return any(it.get("label") == lab for it in
               (q.get("items") or [])[:k[1]])


def _ck_not_first_item(c, ref, ix, ctx):
    k = _item_pos(ix, ctx.get("scope"))
    return k is not None and k[1] > 0


def _ck_class_stated(c, ref, ix, ctx):
    classes = set(BARE_CLASS[ref(c[1])])
    return any(f.get("rel") in classes
               for f in _visible(ix, ctx.get("scope"), ("given",)))


def _ck_cline_op(c, ref, ix, ctx):
    return (ix.entities.get(ref(c[1])) or {}).get("op") == ref(c[2])


def _ck_plain_value(c, ref, ix, ctx):
    """the value prints with no math island of its own (a template that
    puts {fN.v} inside $...$ cannot hold '$\\f{1}{3}$')"""
    f = ref(c[1])
    return f.get("value") is not None and "$" not in _value_text(f)


def _ck_nverts(c, ref, ix, ctx):
    return len(_verts(ix, ref(c[1]))) == int(ref(c[2]))


# ---------------------------------------------- v6.12: family checks ---
def _axis_name(ix, aid):
    e = ix.entities.get(aid) or {}
    return e.get("name") if e.get("kind") == "axis" else None


def _ck_coord_pair(c, ref, ix, ctx):
    """f_a, f_b = coordinate(P, x), coordinate(P, y): one point, x then y
    ("$A(3, −2)$" prints x first)"""
    fa, fb = ref(c[1]), ref(c[2])
    aa, ab = fa.get("args") or [], fb.get("args") or []
    return len(aa) == 2 and len(ab) == 2 and aa[0] == ab[0] and \
        fa.get("rel") == fb.get("rel") and \
        fa.get("rel") in ("coordinate", "guide") and \
        _axis_name(ix, aa[1]) == "x" and _axis_name(ix, ab[1]) == "y"


def _ck_plot_coords(c, ref, ix, ctx):
    """f_p = plot(P, plane:xy); f_a, f_b = its x, y coordinates"""
    fp = ref(c[1])
    ap = fp.get("args") or []
    return len(ap) == 2 and ix.kind(ap[1]) == "plane" and \
        _ck_coord_pair(c[1:], ref, ix, ctx) and \
        (ref(c[2]).get("args") or [None])[0] == ap[0]


def _ck_plot_on_line(c, ref, ix, ctx):
    """f_p = plot(P, axis); f_a = coordinate(P, the same axis)"""
    ap, aa = ref(c[1]).get("args") or [], ref(c[2]).get("args") or []
    return len(ap) == 2 and ix.kind(ap[1]) == "axis" and aa == ap


def _ck_line_place(c, ref, ix, ctx):
    """the argument is a place of a number line (a point / a number) and
    the word before it (p.w) names its kind"""
    k = ix.kind(ref(c[1]))
    return {u"הנקודה": "point", u"המספר": "number"}.get(ref(c[2])) == k


def _ck_ivl_ends(c, ref, ix, ctx):
    """interval e: both ends out ('#open') or both in ('#closed')"""
    e = ix.entities.get(ref(c[1])) or {}
    want = {"open": (False, False), "closed": (True, True)}.get(ref(c[2]))
    return e.get("kind") == "interval" and \
        (e.get("lo_in"), e.get("hi_in")) == want


def _ck_axis_named(c, ref, ix, ctx):
    return _axis_name(ix, ref(c[1])) == ref(c[2])


LANG_CHECKS = {
    "noun": _ck_noun, "the_shape": _ck_the_shape,
    "shape_word": _ck_shape_word, "altitude_in": _ck_altitude_in,
    "median_in": _ck_median_in, "end_of": _ck_end_of,
    "right_at": _ck_right_at, "distinct": _ck_distinct,
    "seg_ends": _ck_seg_ends, "par_line": _ck_par_line,
    "piece_of": _ck_piece_of,
    "side_of_shape": _ck_side_of_shape, "same_value": _ck_same_value,
    "same_unit": _ck_same_unit, "lin_equal": _ck_lin_equal,
    "lin_fraction": _ck_lin_fraction, "lin_mult_plus": _ck_lin_mult_plus,
    "triangle_angles": _ck_triangle_angles,
    "third_angle_known": _ck_third_known,
    "earlier_item": _ck_earlier_item, "not_first_item": _ck_not_first_item,
    "class_stated": _ck_class_stated, "cline_op": _ck_cline_op,
    "nverts": _ck_nverts, "plain_value": _ck_plain_value,
    # v6.12 families
    "coord_pair": _ck_coord_pair, "plot_coords": _ck_plot_coords,
    "plot_on_line": _ck_plot_on_line, "line_place": _ck_line_place,
    "ivl_ends": _ck_ivl_ends, "axis_named": _ck_axis_named}
SCOPE_CHECKS = frozenset(["noun", "the_shape", "side_of_shape", "right_at",
                          "third_angle_known", "earlier_item",
                          "not_first_item", "class_stated"])


def _source_printable(f, kind, ix):
    """May a template of this kind print fact f? Every template prints a
    'stated' fact. A given-list 'line' template may also print a context
    fact (closed context list) or a derived fact with an explicit, current,
    reviewed release -- never an unreleased derived one, in a question/item
    text or in a given list (verifier r1, V12)."""
    src = (f.get("source") or {}).get("kind")
    if src == "stated":
        return True
    if kind != "line":
        return False
    if src == "context":
        return f.get("role") == "context"
    if src == "derived":
        from . import project      # local: project imports this module
        return project.released(f, ix)
    return False


def render_fragment(tset, seg, ix, where, mode=None, scope=None):
    """One template call -> (text, [fact ids it printed]). Refuses any call
    that would print an answer or a target's value. scope (v6.10): the
    question / item whose text this is -- the checks that read the scope
    (an earlier item, a stated shape class) need it."""
    tid = seg.get("tpl")
    t = tset.templates.get(tid)
    if t is None:
        raise SpecError(Issue("TPL_UNKNOWN", where, repr(tid)))
    fids = seg.get("facts") or []
    eids = seg.get("entities") or []
    params = seg.get("params") or {}
    for k in seg:
        if k not in ("tpl", "facts", "entities", "params"):
            raise SpecError(Issue("TPL_BAD_SEGMENT", where, k))
    rels = t.get("rels") or []
    ekinds = t.get("entities") or []
    if len(fids) != len(rels) or len(eids) != len(ekinds):
        raise SpecError(Issue("TPL_ARITY", where, tid))
    facts = []
    for fid in fids:
        f = ix.facts.get(fid)
        if f is None:
            raise SpecError(Issue("UNKNOWN_FACT_REF", where, repr(fid)))
        facts.append(f)
    slots = SLOT_RE.findall(t["text"])
    # 1. an answer is never printed by any template
    for f in facts:
        if f.get("role") == "answer":
            raise SpecError(Issue("TPL_PRINTS_ANSWER", where, f["id"]))
    # 2. a target's value is never printed
    for s in slots:
        m = TPL_SLOT.match(s)
        if m and m.group(1) is not None and m.group(2) in VALUE_PARTS:
            f = facts[int(m.group(1))]
            if f.get("role") == "target":
                raise SpecError(Issue("TPL_PRINTS_TARGET_VALUE", where,
                                      f["id"]))
    # 3. role / relation / source
    kind = t["kind"]
    for k, (f, allowed) in enumerate(zip(facts, rels)):
        roles = KIND_ROLES[kind] if kind != "mixed" else \
            (t.get("roles") or [])[k]
        if f.get("role") not in roles:
            raise SpecError(Issue("TPL_ROLE_MISMATCH", where,
                                  "%s is %s" % (f["id"], f.get("role"))))
        if f.get("rel") not in allowed:
            raise SpecError(Issue("TPL_REL_MISMATCH", where,
                                  "%s is %s" % (f["id"], f.get("rel"))))
        if not _source_printable(f, kind, ix):
            raise SpecError(Issue("TPL_SOURCE_NOT_STATED", where, f["id"]))
    for e, ks in zip(eids, ekinds):
        ent = ix.entities.get(e)
        if ent is None:
            raise SpecError(Issue("UNKNOWN_ENTITY_REF", where, repr(e)))
        ok = any(kind_ok(ent, k) for k in ks)
        if not ok:
            raise SpecError(Issue("TPL_REL_MISMATCH", where,
                                  "%s is not %s" % (e, ks)))
    for p, v in params.items():
        if v not in (t.get("params") or {}).get(p, ()):
            raise SpecError(Issue("TPL_BAD_PARAM", where, "%s=%r" % (p, v)))
    for p in (t.get("params") or {}):
        if p not in params:
            raise SpecError(Issue("TPL_BAD_PARAM", where, "%s missing" % p))
    for k, ks in enumerate(t.get("arg_kinds") or []):
        args = (facts[0].get("args") or []) if facts else []
        a = args[k] if k < len(args) else None
        if not any(kind_ok(ix.entities.get(a), x) for x in ks):
            raise SpecError(Issue("TPL_REL_MISMATCH", where,
                                  "%s is not %s" % (a, ks)))
    ctx = {"scope": scope, "params": params}
    for c in t.get("checks") or []:
        _check(c, facts, eids, ix, where, ctx)
    if kind == "line" or mode is None:
        mode = "plain" if kind == "line" else (mode or "tex")

    def tri_or(eid, override, before):
        # v6.11 fix r1 (W-TRIANGLE-SYMBOL): a triangle always with its sign
        if is_triangle(eid, ix):
            return _tri_name(entity_name(eid, ix, override), before,
                             "plain" if mode == "plain" else "tex")
        return entity_display(eid, ix, mode, override)

    def slot(s, before=""):
        m = TPL_SLOT.match(s)
        if m.group(1) is not None:
            f = facts[int(m.group(1))]
            part = m.group(2)
            args = f.get("args") or []
            if part == "q":
                return tri_or(args[0], _disp(f, 0), before)
            if part == "tq":
                return _tri(args[0], ix, mode, where, _disp(f, 0))
            if part.startswith("targ"):
                k = int(part[4:])
                if k >= len(args):
                    raise SpecError(Issue("TPL_BAD_SLOT", where, s))
                return _tri(args[k], ix, mode, where, _disp(f, k))
            if part == "eq":
                return _phrase(tset, f, ix, mode, where, with_unit=False)
            if part == "ub":
                return _unit_text(f).strip()
            if part.startswith("arg"):
                k = int(part[3:])
                if k >= len(args):
                    raise SpecError(Issue("TPL_BAD_SLOT", where, s))
                return tri_or(args[k], _disp(f, k), before)
            if part == "v":
                if f.get("value") is None:
                    raise SpecError(Issue("VALUE_REQUIRED", where, f["id"]))
                return _value_text(f, mode, ix)
            if part == "u":
                return _unit_text(f)
            return _phrase(tset, f, ix, mode, where)
        if m.group(3) is not None:
            eid = eids[int(m.group(3))]
            if m.group(4):
                # (v6.10) the parts of an unnamed construction (cline);
                # (v6.12) the ends of a jump / an interval
                e = ix.entities.get(eid) or {}
                if m.group(4) not in ENTITY_PARTS.get(e.get("kind"), ()):
                    raise SpecError(Issue("TPL_BAD_SLOT", where, s))
                return entity_display(e[m.group(4)], ix, mode)
            return tri_or(eid, None, before)
        return params[m.group(5)]
    return _fill_at(t["text"], slot), [f["id"] for f in facts]


def render_text(tset, segments, ix, scope, mode=None):
    """A question/item text -> (text, [printed fact ids])."""
    where = "text of %s" % scope
    if not isinstance(segments, list):
        raise SpecError(Issue("TPL_BAD_SEGMENT", where, "not a list"))
    parts, printed = [], []
    for seg in segments:
        if not isinstance(seg, dict):
            raise SpecError(Issue("TPL_BAD_SEGMENT", where, repr(seg)))
        if "join" in seg:
            if len(seg) != 1 or seg["join"] not in tset.connectors:
                raise SpecError(Issue("TPL_BAD_CONNECTOR", where,
                                      repr(seg.get("join"))))
            parts.append(seg["join"])
        elif "prose" in seg:
            p = ix.prose.get(seg["prose"])
            if len(seg) != 1 or p is None:
                raise SpecError(Issue("UNKNOWN_PROSE", where,
                                      repr(seg.get("prose"))))
            if p.get("scope") != scope:
                raise SpecError(Issue("TPL_SCOPE_MISMATCH", where, p["id"]))
            parts.append(p["text"])
        elif "bound" in seg:
            # (v6.13, W-BOUND-PROSE) original wording, every number / name
            # bound to a fact / entity (schema_bound validates the table);
            # it prints the facts it binds by value and those it `prints`
            blk = seg["bound"]
            if len(seg) != 1 or not isinstance(blk, dict) or \
                    not isinstance(blk.get("text"), str):
                raise SpecError(Issue("TPL_BAD_SEGMENT", where, repr(seg)))
            from . import schema_bound as SB
            parts.append(blk["text"])
            printed.extend(f for f in SB.bound_facts(blk) if f in ix.facts)
        elif "tpl" in seg:
            txt, fids = render_fragment(tset, seg, ix, where, mode=mode,
                                        scope=scope)
            for fid in fids:
                if ix.facts[fid].get("item") != scope:
                    raise SpecError(Issue("TPL_SCOPE_MISMATCH", where, fid))
            parts.append(txt)
            printed.extend(fids)
        else:
            raise SpecError(Issue("TPL_BAD_SEGMENT", where, repr(seg)))
    return "".join(parts), printed


class Rendered(object):
    def __init__(self):
        self.texts = {}          # scope -> generated text
        self.printed = {}        # fact id -> scope whose text printed it
        self.implied = {}        # (v6.10 fix r1) construct_join -> the
        #                          printed claim that presupposes it
        # (v6.13, W-BOUND-PROSE) question id -> the table / example it
        # prints (the emitter's form), and every entity a printed bound
        # block names (a number there is stated by the text)
        self.tables = {}
        self.examples = {}
        self.bound_entities = {}  # scope -> set of entity ids


def render_spec(spec, tset, ix, out, mode=None):
    """Render every question/item text; record what was printed; report
    STATED_NOT_PRINTED. Refusals go to `out` (one per text)."""
    r = Rendered()
    for q in spec.get("questions") or []:
        scopes = [(q.get("id"), q.get("text"))] + \
            [(it.get("id"), it.get("text")) for it in q.get("items") or []]
        for sid, segs in scopes:
            try:
                txt, fids = render_text(tset, segs, ix, sid, mode=mode)
            except SpecError as e:
                out.extend(e.issues)
                continue
            r.texts[sid] = txt
            for fid in fids:
                r.printed.setdefault(fid, sid)
        # (v6.13) the question's table / worked example: bound blocks of
        # the question's scope
        from . import schema_bound as SB
        if isinstance(q.get("table"), dict) or \
                isinstance(q.get("example"), dict):
            try:
                ex = SB.question_extras(q)
            except (KeyError, TypeError, AttributeError):
                out.append(Issue("TPL_BAD_SEGMENT", "table/example of %s"
                                 % q.get("id"), "not in its closed form"))
                ex = {}
            if "table" in ex:
                r.tables[q.get("id")] = ex["table"]
            if "example" in ex:
                r.examples[q.get("id")] = ex["example"]
    from . import schema_bound as SB
    for sid, _at, blk in SB.blocks_of(spec):
        if not isinstance(blk, dict):
            continue
        r.bound_entities.setdefault(sid, set()).update(
            e for e in SB.bound_entities(blk) if e in ix.entities)
        if not _at.startswith("text:"):
            for fid in SB.bound_facts(blk):
                if fid in ix.facts:
                    r.printed.setdefault(fid, sid)
    _implied_joins(ix, r)
    # (v6.16 integrate) a PIE CHART prints its drawn data itself (the value
    # labels, the total label): a given it draws is printed by the figure
    from . import sheet_pie as _SPI
    _SPI.printed_by_figure(spec, ix, r)
    # (v6.17-noam V1) a PLANE figure prints the value labels of the stated
    # givens it draws when the question's bound prose announces them by
    # count (G7-T14 a q9: "ובו שלוש זוויות נתונות"; the three angles stand
    # only in the drawing), as a pie prints its data
    from . import rules617 as _R617
    _R617.printed_by_figure(spec, ix, r)
    from . import base_height as BH
    BH.printed_by_figure(spec, ix, r, out)
    for f in ix.facts.values():
        if (f.get("source") or {}).get("kind") == "stated" and \
                f.get("id") not in r.printed:
            out.append(Issue("STATED_NOT_PRINTED", f.get("id"),
                             "no generated text prints it"))
    return r


# (v6.17 FIX, the verifier's S2) the approved 'compute' line "חשבו את
# {f0.q}." (rels angle_measure, var_value, perimeter, area) prints only the
# POLYGON for an area / perimeter target: "חשבו את $\\tri ABC$." -- the word
# שטח / היקף is dropped (as in v6.16.2; no delivered sheet prints it). The
# approved line itself is the author's and is NOT changed here (PENDING_V617
# item 7 asks the author). What the SHEET BUILDER refuses (wspec_build.
# expand_question, when a question is put on a sheet; TPL_QUANTITY_WORD_
# MISSING): a template call whose text prints an area / perimeter fact
# through {fN.q} / {fN.tq} without the quantity word in the template's own
# text. schema.validate does not call it: the acceptance pilot converter
# (acceptance/pilot/sheet_to_spec, locked) and the v6.9 test fixture
# fixtures/wspec_g9t18a_q1q4q9.json (q4ד) use 'compute' for an area as a
# data stand-in that is never printed, and their statuses must not move.
QUANTITY_WORDS = {"area": u"שטח", "perimeter": u"היקף"}
from .errors import REASONS as _REASONS          # noqa: E402
_REASONS.setdefault("TPL_QUANTITY_WORD_MISSING", "(v6.17 fix) a template "
                    "prints an area / perimeter target by its figure only, "
                    "without the word שטח / היקף (the sheet builder refuses "
                    "it)")


def quantity_word_issues(spec, tset):
    """[Issue] TPL_QUANTITY_WORD_MISSING of every template call in the
    spec's question / item texts (see above)."""
    facts = dict((f.get("id"), f) for f in spec.get("facts") or []
                 if isinstance(f, dict))
    out = []
    for q in spec.get("questions") or []:
        if not isinstance(q, dict):
            continue
        for sc in [q] + [it for it in q.get("items") or []
                         if isinstance(it, dict)]:
            for seg in sc.get("text") or [] if isinstance(
                    sc.get("text"), list) else []:
                if not isinstance(seg, dict) or "tpl" not in seg:
                    continue
                t = tset.templates.get(seg.get("tpl")) or {}
                text = t.get("text") or ""
                fids = seg.get("facts") or []
                for s_ in SLOT_RE.findall(text):
                    m = TPL_SLOT.match(s_)
                    if not m or m.group(1) is None or \
                            m.group(2) not in ("q", "tq"):
                        continue
                    k = int(m.group(1))
                    f = facts.get(fids[k]) if k < len(fids) else None
                    w = QUANTITY_WORDS.get((f or {}).get("rel"))
                    if w and w not in text:
                        out.append(Issue(
                            "TPL_QUANTITY_WORD_MISSING", "text of %s"
                            % sc.get("id"), u"template %r prints the %s "
                            u"fact %s by its figure only (no '%s')" % (
                                seg.get("tpl"), f.get("rel"), f.get("id"),
                                w)))
    return out


def _implied_joins(ix, r):
    """(v6.10 fix r1, L2) a construction the item's own claim presupposes:
    "הוכיחו כי ME = ½BC" asks about a segment ME that the figure does not
    draw -- the student draws it (v6.7.3 c q14: to_construct ME, MF, EF,
    no instruction printed). A to_construct construct_join(seg:XY) that no
    text prints counts as stated by its OWN item's text when a fact that
    text prints names XY (an argument, a side of a polygon argument, an arm
    of an angle argument). Recorded in r.implied; nothing else is
    implied, and never by another item's text."""
    from . import schema as S          # local: schema imports this module
    r.implied = {}
    for f in ix.facts.values():
        if f.get("role") != "to_construct" or \
                f.get("rel") != "construct_join" or f.get("id") in r.printed:
            continue
        e = ix.entities.get((f.get("args") or [None])[0]) or {}
        want = frozenset(e.get("ends") or [])
        if len(want) != 2:
            continue
        for fid, sc in sorted(r.printed.items()):
            g = ix.facts.get(fid) or {}
            if sc == f.get("item") and g.get("item") == sc and \
                    g.get("role") in ("to_prove", "target") and \
                    want in S.named_segments(g, ix):
                r.printed[f["id"]] = sc
                r.implied[f["id"]] = fid
                break
