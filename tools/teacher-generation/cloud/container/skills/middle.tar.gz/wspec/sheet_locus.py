"""Source-bound one-parameter axis-aligned loci; no parameter answer values.

figure.loci rows: {id,point,variable,coordinate_fact,domain:{lo,lo_in},
source:{scope,text},example:bool}. Domain currently supports the explicitly
stated nonnegative parameter. Example coordinates remain private placement.
"""
import copy,re
from . import canon
from .errors import Issue
from .sheet_data import _context,number,norm,TOKEN


def objects(pub,fid):
 fig=next((g for g in pub.get('figures',[]) if g.get('id')==fid),{})
 facts={f['id']:f for f in pub.get('facts',[])}
 out={}
 for row in fig.get('loci',[]):
  f=facts[row['coordinate_fact']];axis=f['args'][1];value=canon.canon_number(f['value'])
  oid='line:'+axis.split(':')[1]+'='+value
  out[oid]=dict(row,id=oid,token=row['id'],kind='line',through=[],locus=True,
                axis=axis,value=value,free_axis='axis:y' if axis=='axis:x' else 'axis:x')
 return out


def problems(spec,fig,public=False):
 if 'loci' not in fig:return []
 rows=fig['loci'];bad=[]
 if not isinstance(rows,list) or not rows:return ['loci must be a nonempty list']
 if (fig.get('frame') or {}).get('family')!='coordinate_plane' or (fig.get('frame') or {}).get('sketch') or 'graph' in fig or 'data' in fig:
  bad.append('loci require an ordinary coordinate frame without graph/data')
 texts,owners,printed=_context(spec,public);qid=owners.get(fig.get('scope'))
 facts={f['id']:f for f in spec.get('facts',[])};ents={e['id']:e for e in spec.get('entities',[])};seen=set()
 for r in rows:
  if not isinstance(r,dict) or set(r)!={'id','point','variable','coordinate_fact','domain','source','example'} or not isinstance(r.get('id'),str) or not TOKEN.fullmatch(r['id']) or not all(isinstance(r.get(k),str) for k in ('point','variable','coordinate_fact')) or not isinstance(r.get('example'),bool):
   bad.append('invalid closed locus row');continue
  if r['id'] in seen:bad.append('duplicate locus id')
  seen.add(r['id'])
  p,v,f=ents.get(r['point'],{}),ents.get(r['variable'],{}),facts.get(r['coordinate_fact'],{})
  args=f.get('args') or []
  if p.get('kind')!='point' or v.get('kind')!='variable' or f.get('rel')!='coordinate' or f.get('role')!='given' or len(args)!=2 or args[0]!=r['point'] or args[1] not in ('axis:x','axis:y') or number(f.get('value')) is None or owners.get(f.get('item'))!=qid or f.get('id') not in printed:
   bad.append('locus must bind its point, variable and printed given coordinate');continue
  src=r['source'];dom=r['domain']
  if not isinstance(src,dict) or set(src)!={'scope','text'} or not isinstance(src.get('scope'),str) or owners.get(src['scope'])!=qid or not norm(src.get('text')) or norm(src['text']) not in texts.get(src['scope'],''):
   bad.append('locus source must be an exact clause of its own question');continue
  pair=[v['name'],canon.canon_number(f['value'])] if args[1]=='axis:y' else [canon.canon_number(f['value']),v['name']]
  pattern=re.escape(p['name'])+r'\s*\(\s*'+re.escape(pair[0])+r'\s*,\s*'+re.escape(pair[1])+r'\s*\)'
  if not re.search(pattern,norm(src['text'])) or 'מקווקו' not in src['text']:
   bad.append('locus source must explicitly give the parameter pair and dashed line')
  if not isinstance(dom,dict) or set(dom)!={'lo','lo_in'} or number(dom.get('lo'))!=0 or dom.get('lo_in') is not True or not re.search(r'\b'+re.escape(v['name'])+r'\b.*אינו שלילי',norm(src['text'])):
   bad.append('locus domain requires the explicitly stated nonnegative parameter')
  shown=set(fig.get('entities') or [])
  if r['example'] != (r['point'] in shown):bad.append('only a declared illustrative point may be shown')
  # No public or source-stated numeric value may replace the free parameter.
  free='axis:y' if args[1]=='axis:x' else 'axis:x'
  for ff in facts.values():
   if owners.get(ff.get('item'))==qid and ff.get('rel')=='coordinate' and ff.get('args')==[r['point'],free] and ff.get('role') in ('given','derived','context','to_prove'):
    bad.append('a free parameter coordinate is not a numeric given')
 return bad


def validate(spec,ix,out):
 for g in spec.get('figures',[]):out.extend(Issue('BAD_TYPE','figure %s loci'%g.get('id'),x) for x in problems(spec,g))


def public_loci(fig):
 rows=copy.deepcopy(fig['loci'])
 for r in rows:r['domain']['lo']=canon.canon_number(r['domain']['lo'])
 return rows


def scan_public(pub,out):
 for g in pub.get('figures',[]):out.extend(Issue('PUBLIC_VALUE_NOT_WHITELISTED','figure %s loci'%g.get('id'),x) for x in problems(pub,g,True))
