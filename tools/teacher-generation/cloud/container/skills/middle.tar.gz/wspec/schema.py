# -*- coding: utf-8 -*-
"""The spec schema (closed vocabularies) and validate(spec) -> [Issue].

C1: figure_accuracy (how a figure is drawn) and measurement_allowed (per
item: is solving by measuring legitimate) are two independent fields. No
rule ties them. There is no distortion rule anywhere in wspec."""
import json
import os
import re
import unicodedata

from . import canon
from .errors import Issue, REASONS

SPEC_VERSION = "wspec/1"

# ------------------------------------------------------ closed lists ---
ROLES = ("given", "context", "derived", "target", "to_prove", "to_construct",
         "answer", "to_plot")
SOURCE_KINDS = ("stated", "derived", "context")
# role -> source kinds it accepts
ROLE_SOURCES = {
    "given": ("stated", "derived"),
    "context": ("context",),
    "derived": ("derived",),
    "target": ("stated",),         # the DESCRIPTION is printed, never a value
    "to_prove": ("stated",),
    "to_construct": ("stated",),
    "answer": ("derived",),        # rule answer_key, from = [its target]
    # (v6.12) "סמנו את הנקודה A(3, −2)": the task to PLOT a point / a number;
    # its answer is the plotted place (no value), private until answered --
    # no figure of its question shows it (family.FIGURE_SHOWS_TO_PLOT)
    "to_plot": ("stated",),
}
TARGET_ROLES = ("target", "to_prove", "to_construct", "to_plot")
# context: a CLOSED list -- kind -> (relation, entity kinds of its argument)
CONTEXT_KINDS = {
    "point_name": ("name", ("point",)),
    "vertex_name": ("name", ("point",)),        # + the point is a vertex
    "axis_name": ("name", ("axis",)),
    "line_name": ("name", ("line",)),
    "axis_tick": ("tick", ("tick",)),           # + value == the tick's `at`
    "axis_scale": ("scale", ("axis",)),
    "grid": ("grid", ("plane",)),
    "legend": ("legend", None),
    "unit": ("unit_label", None),
    # (v6.12) a number the number line prints at its place (a mark)
    "number_mark": ("mark", ("number",)),
    # (v6.13 fix_r2, B3) where a coordinate plane SHOWS a point whose
    # coordinates the sheet neither states nor asks (G7-T08 a q7: A, B, C, D
    # at the ends of the drawn segments; the student reads them to compute a
    # length): coordinate(P, axis) as figure data, no caption printed. Two
    # arguments (point, axis) -- the one context kind with an axis argument
    "point_place": ("coordinate", ("point",)),
}
# (v6.13 fix_r2) context kinds whose relation is ALSO an ordinary stated /
# answered relation (a coordinate): not a context-only relation
CONTEXT_SHARED = frozenset(["point_place"])
CONTEXT_RELS = frozenset(r for k, (r, _) in CONTEXT_KINDS.items()
                         if k not in CONTEXT_SHARED)
# rule registry for source=derived
RULES = {
    "answer_key": "the answer key of the sheet (answers only)",
    "prior_item_result": "the claim proved / value found in an earlier item",
    "rectangle_props": "properties of a rectangle",
    "parallelogram_props": "properties of a parallelogram",
    "triangle_angle_sum": "angle sum of a triangle",
    "isosceles_base_angles": "base angles of an isosceles triangle",
    "exterior_angle": "exterior angle of a triangle",
    "median_to_hypotenuse": "the median to the hypotenuse is half of it",
    "pythagoras": "Pythagoras",
    "vertical_angles": "vertical angles",
    "supplementary": "adjacent angles on a line",
}
# (v6.17-noam, BRIEF_V617 V1 / V2) five rules that are CHECKED, not only
# named: the 360° angle sum of a quadrilateral, the alternate /
# corresponding / co-interior angles between parallel lines and the
# isosceles converse (wspec/rules617.py: applicability, exact value, the
# pair's arm directions; run by validate)
from .rules617 import RULES617 as _RULES617      # noqa: E402
RULES.update(_RULES617)
TASK_TYPES =("measure", "read_off", "compute", "prove", "construct",
              "verify", "plot")
MEASURE_TASKS = ("measure", "read_off")
# task types that MAY state their target on purpose (C4 exception)
TARGET_GIVEN_ALLOWED = ("verify",)
FIGURE_ACCURACY = ("accurate", "schematic")

LINEAR = ("segment", "line", "ray")
ANY = None
# (v6.10) quantity arguments of 'linear' (+ a variable) and 'greater'
QTY = ("segment", "angle", "polygon", "variable")
QTY_NV = ("segment", "angle", "polygon")
QTY_DIM = {"segment": "length", "angle": "angle", "polygon": "area",
           "variable": None}
# relations whose argument count varies: rel -> (min, max); every argument
# takes the kinds of the relation's single kind list
VARIADIC = {"linear": (2, 5),
            # (v6.16 integrate) equal shares of 2..12 sectors of one pie
            "sector_equal": (2, 12)}
# classes a 'classify' answer may name -> vertex count (None: any)
CLASS_VALUES = {"rectangle": 4, "square": 4, "parallelogram": 4,
                "rhombus": 4, "trapezoid": 4, "isosceles_trapezoid": 4,
                "equilateral": 3, "isosceles": 3, "right_triangle": 3,
                "acute_triangle": 3,
                # (v6.17-noam V1) "רשמו את שם המשולש לפי הזוויות" (G7-T14)
                "obtuse_triangle": 3}
SHAPE_VERTICES = {"trapezoid": 4, "isosceles_trapezoid": 4,
                  "right_triangle": 3, "acute_triangle": 3,
                  "obtuse_triangle": 3, "classify": None}
# roles a relation between quantities may carry
QTY_REL_ROLES = ("given", "derived", "to_prove", "answer")
# entity kind -> required fields (name -> "str" | "list" | "num" | "int")
ENTITY_KINDS = {
    "point": {"name": "str"},
    "segment": {"ends": "list2"},
    "line": {"through": "list2"},
    "ray": {"from": "str", "through": "str"},
    "angle": {"vertex": "str", "arms": "list2"},
    "polygon": {"vertices": "list3+"},
    "circle": {"center": "str"},
    "arc": {"circle": "str", "ends": "list2"},
    "number": {"value": "num"},
    "variable": {"name": "str"},
    "axis": {"name": "str"},
    "plane": {"name": "str"},
    "tick": {"axis": "str", "at": "num"},
    "table_cell": {"table": "str", "row": "int", "col": "int"},
    # (v6.10) a construction result the sheet does not name: the line
    # through `through` parallel / perpendicular (op) to the segment `base`
    "cline": {"op": "str", "through": "str", "base": "str"},
    # (v6.12) number-line objects: a jump (an arc from one place to another,
    # ORDERED) and an interval (the part of the line between two places,
    # each end in or out); a place is a point or a number
    "jump": {"from": "str", "to": "str"},
    "interval": {"lo": "str", "hi": "str", "lo_in": "bool", "hi_in": "bool"},
    # (v6.16 gaps, corpus-v2 G2) the ORIGIN of a coordinate plane -- the
    # point where the axes cross ("ראשית הצירים"), id "origin:O". It is no
    # point entity: a plane never draws a dot for it; a figure that lists it
    # maps it as its two axis lines + the printed '0' (render/coord.py)
    "origin": {"name": "str"},
    # (v6.16 gaps, corpus-v2 G5) an UNNAMED vertex of a polygon the sheet
    # declares by coordinates only ("קודקודיו לפי סדרם, (0,0), (6,0), ..."):
    # vertex n of the polygon tagged `of`, id "vtx:<of>:<n>". No letter is
    # invented for it (as for a cline); its place is its coordinate facts
    "vertex": {"of": "str", "n": "int"},
    # (v6.16 integrate) the PIE CHART family (wspec/pie.py, which checks
    # its own grammar: names without digits, keys, printed labels): a pie,
    # one of its sectors (the printed category label is `name`), and the
    # empty circle of a "build a pie" task
    "pie": {"name": "str"},
    "sector": {"pie": "str", "key": "str", "name": "str"},
    "build_circle": {"name": "str"},
}
CLINE_OPS = ("parallel", "perpendicular")
# (v6.12) a number's printed form (canon.NUMBER_FORMS), checked by family
# (v6.16 gaps, G5) a polygon whose vertices are unnamed vertex entities
# carries a `tag` (its id is "poly:<tag>"); a named polygon never does
ENTITY_OPTIONAL = {"circle": ("name",), "number": ("form",),
                   "polygon": ("tag",), "line": ("name",)}
# entity fields that reference other entities
ENTITY_REFS = {"segment": ("ends",), "line": ("through",),
               "ray": ("from", "through"), "angle": ("vertex", "arms"),
               "polygon": ("vertices",), "circle": ("center",),
               "arc": ("circle", "ends"), "tick": ("axis",),
               "cline": ("through", "base"), "jump": ("from", "to"),
               "interval": ("lo", "hi"),
               "sector": ("pie",)}                    # v6.16 integrate
# the kind every reference field must point to; the POINTS an entity names
# must all differ (verifier semantics r1, V7: a ray AA and an angle whose
# vertex is one of its arms validated and exported)
ENTITY_REF_KINDS = {"segment": {"ends": "point"},
                    "line": {"through": "point"},
                    "ray": {"from": "point", "through": "point"},
                    "angle": {"vertex": "point", "arms": "point"},
                    # (v6.16 gaps, G5) or unnamed vertices (a tagged polygon)
                    "polygon": {"vertices": ("point", "vertex")},
                    "circle": {"center": "point"},
                    "arc": {"circle": "circle", "ends": "point"},
                    "tick": {"axis": "axis"},
                    "cline": {"through": "point", "base": "segment"},
                    # (v6.12) a tuple: any of these kinds
                    "jump": {"from": ("point", "number"),
                             "to": ("point", "number")},
                    "interval": {"lo": ("point", "number"),
                                 "hi": ("point", "number")},
                    # (v6.16 integrate) a sector belongs to its pie
                    "sector": {"pie": "pie"}}
assert dict((k, tuple(v)) for k, v in ENTITY_REF_KINDS.items()) == \
    ENTITY_REFS, "ENTITY_REF_KINDS must declare exactly ENTITY_REFS"

# relation -> (arg entity kinds, value mode, dimension)
#   value mode: "measure" (carries an exact value) | "none"
RELS = {
    "angle_measure": ((("angle",),), "measure", "angle"),
    "length": ((("segment",),), "measure", "length"),
    "perimeter": ((("polygon",),), "measure", "length"),
    "area": ((("polygon",),), "measure", "area"),
    "var_value": ((("variable",),), "measure", None),
    "ratio": ((LINEAR, LINEAR), "measure", None),
    # (v6.16 gaps) an unnamed vertex (G5) is placed by its coordinates as a
    # point is; the origin (G2) has coordinates (0, 0) a question may ask
    "coordinate": ((("point", "vertex", "origin"), ("axis",)), "measure",
                   None),
    "rectangle": ((("polygon",),), "none", None),
    "square": ((("polygon",),), "none", None),
    "parallelogram": ((("polygon",),), "none", None),
    "rhombus": ((("polygon",),), "none", None),
    "equilateral": ((("polygon",),), "none", None),
    "isosceles": ((("polygon",),), "none", None),
    "on_segment": ((("point",), ("segment",)), "none", None),
    "midpoint": ((("point",), ("segment",)), "none", None),
    "equal_length": ((("segment",), ("segment",)), "none", None),
    "equal_angle": ((("angle",), ("angle",)), "none", None),
    "parallel": ((LINEAR, LINEAR), "none", None),
    "perpendicular": ((LINEAR, LINEAR), "none", None),
    "congruent": ((("polygon",), ("polygon",)), "none", None),
    # constructions (addendum S3): arg 0 is always the RESULT (the new
    # object); the others are the objects it is built ON. The templates
    # that print them declare the same result/base (templates_he.json).
    # (close_gaps SV3-05) JOIN points the page already shows: the student
    # draws the segment between them; nothing is located
    "construct_join": ((("segment",),), "none", None),
    "construct": ((("segment", "line", "ray", "point", "polygon"),),
                  "none", None),
    "construct_altitude": ((("segment",), ("polygon",)), "none", None),
    "construct_median": ((("segment",), ("polygon",)), "none", None),
    "construct_bisector": ((("ray",), ("angle",)), "none", None),
    "construct_midpoint": ((("point",), ("segment",)), "none", None),
    "construct_perpendicular": ((LINEAR, LINEAR, ("point",)), "none", None),
    "construct_parallel": ((LINEAR, LINEAR, ("point",)), "none", None),
    # (v6.10, BRIEF_V610 part 2) relations between QUANTITIES:
    #   linear  args[0] = coef[0]*args[1] + ... + coef[k-1]*args[k] + value
    #           (2-5 args; a segment is its length, an angle its measure,
    #           a polygon its AREA, a variable its value; `coef` a list of
    #           exact rationals, `value` the constant with its unit):
    #           AC = 3x + 4 (cm), BD = 1/2 AC, angle DMB = 2 angle A,
    #           angle APB = angle DAP + angle CBP, S(BOC) = 1/4 S(ABCD)
    #   greater args[0] > args[1] (same dimension): CM > CH, angle A > B
    "linear": ((QTY,), "const", None),
    "greater": ((QTY_NV, QTY_NV), "none", None),
    "not_parallel": ((LINEAR, LINEAR), "none", None),
    "inside": ((("point",), ("polygon",)), "none", None),
    # shape classes a question states or asks to prove
    "trapezoid": ((("polygon",),), "none", None),
    "isosceles_trapezoid": ((("polygon",),), "none", None),
    "right_triangle": ((("polygon",),), "none", None),
    "acute_triangle": ((("polygon",),), "none", None),
    # (v6.17-noam V1) משולש קהה־זוויות: one angle above 90° (G7-T14, G7-T19)
    "obtuse_triangle": ((("polygon",),), "none", None),
    # "which special quadrilateral is ABCD?": the target asks the class, the
    # ANSWER carries it (value = a class of CLASS_VALUES); a to_prove of it
    # asks to justify the class without stating it ("נמקו במשפט אחד")
    "classify": ((("polygon",),), "class", None),
    # context relations (role context only)
    "name": ((("point", "axis", "line"),), "none", None),
    "tick": ((("tick",),), "measure", None),
    "scale": ((("axis",),), "measure", None),
    "grid": ((("plane",),), "none", None),
    "legend": ((ANY,), "none", None),
    "unit_label": ((ANY,), "none", None),
    # (v6.12, BRIEF_V612 section 1) the coordinate-plane and number-line
    # families (family.py checks them against the figures' frames):
    #   plot            the task "mark the point / the number" (to_plot and
    #                   its answer only): on a plane (a point) or on one
    #                   axis / number line (a point or a number)
    #   distance        the distance of two places (points / numbers)
    #   abs_value       |a|: the distance of a place from zero
    #   jump_value      the signed size of a jump (to - from)
    #   interval_value  the value of one interval (tick step) of an axis
    #   count_integers  how many whole numbers an interval holds
    #   mark            (context) the figure prints a number at its place
    #   guide           a reading guide (the dashed helper line from a point
    #                   to an axis): a stated given only, drawn by a framed
    #                   figure -- guides appear ONLY where a given states
    #                   them (didactic policy; family.FAMILY_GUIDE)
    # (v6.16 gaps, G5) "סרטטו את המצולע במערכת הצירים": a polygon plotted
    # on a plane (every vertex placed by given coordinates)
    "plot": ((("point", "number", "polygon"), ("plane", "axis")), "none",
             None),
    "distance": ((("point", "number"), ("point", "number")), "measure",
                 None),
    "abs_value": ((("point", "number"),), "measure", None),
    "jump_value": ((("jump",),), "measure", None),
    "interval_value": ((("axis",),), "measure", None),
    "count_integers": ((("interval",),), "measure", None),
    "mark": ((("number",),), "none", None),
    "guide": ((("point",), ("axis",)), "none", None),
    # (v6.13 fix_r2, B1) "הקטע AB מקביל לציר x": a segment / line / ray of a
    # coordinate plane parallel to one of its axes (family.py checks the
    # coordinates; the plane checker measures the drawn segment)
    "axis_parallel": ((LINEAR, ("axis",)), "none", None),
    # (v6.16 integrate) the PIE CHART family (wspec/pie.py RELS: roles,
    # units % / deg, the exact data and the answers are checked there,
    # pie.spec_issues). A sector's value (given: the drawn data; target: a
    # MISSING sector, never printed), equal shares (given, sorted args), the
    # angle / percent / count of a sector and the pie's total (FIND targets),
    # and "build the pie" in an empty circle (to_construct)
    "sector_value": ((("sector",),), "measure", None),
    "sector_equal": ((("sector",),), "none", None),
    "sector_angle": ((("sector",),), "measure", None),
    "sector_percent": ((("sector",),), "measure", None),
    "sector_count": ((("sector",),), "measure", None),
    "pie_total": ((("pie",),), "measure", None),
    "construct_pie": ((("build_circle",),), "none", None),
}
# (v6.16 integrate) the pie family's relations and its own construction
# (built in an empty circle: no geometry template declares it -- the pie
# checker's BUILD_CIRCLE_EMPTY / MUST_NOT_DRAW guard it)
PIE_RELS = frozenset(["sector_value", "sector_equal", "sector_angle",
                      "sector_percent", "sector_count", "pie_total",
                      "construct_pie"])
PIE_CONSTRUCT_RELS = frozenset(["construct_pie"])
# (v6.12) the relations of the two families (their values print with U+2212)
FAMILY_RELS = frozenset(["coordinate", "plot", "distance", "abs_value",
                         "jump_value", "interval_value", "count_integers",
                         "mark", "guide", "axis_parallel"])

CONSTRUCT_RELS = tuple(sorted(r for r in RELS if (
    r == "construct" or r.startswith("construct_")) and
    r not in PIE_CONSTRUCT_RELS))                    # v6.16 integrate
# roles a construction relation may carry: the task and its answer only
CONSTRUCT_ROLES = ("to_construct", "answer")
# (v6.12) the roles the plot relation may carry
PLOT_ROLES = ("to_plot", "answer")
# construction relations whose result is fixed by a NEW point that the
# construction finds (the foot of an altitude, the median's midpoint, a
# point of the bisector, of the perpendicular / parallel, the midpoint
# itself): that point is the construction's essential step and may not be
# drawn (CONSTRUCT_STEP_DRAWN; verifier semantics r1, V5). The generic
# 'construct' joins given points and finds none. Templates declare the same
# flag (templates.construct_decl).
# (close_gaps SV3-05) how a construction's result relates to the page: a
# JOIN draws the result between points the page shows (every defining point
# must be shown -- the declaration is checked against the drawing); every
# other construction LOCATES something, so a page that shows all of its
# result's defining points has already drawn it. Templates declare the
# same mode (templates.construct_decl).
CONSTRUCT_JOIN = frozenset(["construct_join"])
CONSTRUCT_NEW_POINT = frozenset(["construct_altitude", "construct_median",
                                 "construct_bisector", "construct_midpoint",
                                 "construct_perpendicular",
                                 "construct_parallel"])

# --------------------------------------------- ids and public strings ---
# Every string the public model carries is either generated (texts, target
# descriptions), from a closed list, or an id derived by a fixed rule. No
# free string reaches the public model (verifier r1, V10).
#   sheet id   G<grade>-T<topic>/<level>, e.g. "G9-T18/a"
#   question   id "q<n>"; n are whole numbers that increase down the sheet
#   item       label = the Hebrew letter of its position (א, ב, ג, ...),
#              id = question id + the Latin letter of that position (q7d)
#   figure     id = its scope for an item scope, "<question>_head" for a
#              question scope
SHEET_RE = re.compile(r"^G(?:[7-9]|1[0-2])-T[1-9][0-9]{0,2}/[abc]\Z")
ITEM_LABELS = tuple("אבגדהוזחטיכלמנסעפצקרשת")
ITEM_LATIN = tuple("abcdefghijklmnopqrstuv")
# closed (verifier r2, R2-02): a plane is one of the three coordinate
# planes; a table / an axis is one letter (+ one index digit for a table).
PLANE_RE = re.compile(r"^(?:xy|xz|yz)\Z")
AXIS_RE = re.compile(r"^[a-z]\Z")
TABLE_RE = re.compile(r"^[a-z][1-9]?\Z")
# (v6.16 gaps, G5) the tag of a polygon with unnamed vertices: a label the
# sheet never prints ("L6"), only an id part
TAG_RE = re.compile(r"^[A-Z][A-Za-z0-9]{0,7}\Z")
# entity kind -> {name field: grammar} for the free-looking name fields
ENTITY_NAME_RULES = {"point": {"name": canon.NAME_RE},
                     "variable": {"name": canon.VAR_RE},
                     "line": {"name": AXIS_RE},
                     "axis": {"name": AXIS_RE},
                     "plane": {"name": PLANE_RE},
                     "circle": {"name": canon.NAME_RE},
                     "table_cell": {"table": TABLE_RE},
                     # (v6.16 gaps) the origin's conventional letter; the
                     # tag of a polygon with unnamed vertices (never printed)
                     "origin": {"name": canon.NAME_RE},
                     "vertex": {"of": TAG_RE},
                     "polygon": {"tag": TAG_RE}}


def question_id(n):
    return "q%d" % n


def item_id(qid, pos):
    return qid + ITEM_LATIN[pos] if 0 <= pos < len(ITEM_LATIN) else None


def item_label(pos):
    return ITEM_LABELS[pos] if 0 <= pos < len(ITEM_LABELS) else None


def figure_id(scope, is_question):
    return scope + "_head" if is_question else scope


def is_count(v):
    return isinstance(v, int) and not isinstance(v, bool) and v >= 1


# -------------------------------------------------------------- prose ---
# THE GUARANTEE (addendum S2): prose is public ONLY with a human approval
# bound to its exact text -- approved_by + approved_hash = sha256 of the
# text; any edit voids it (PROSE_UNAPPROVED). No number in prose may be the
# value of a target or an answer unless a human approved that exact text:
# the human reading is the control, the scan below is not.
# THE SCAN IS A BACKSTOP (advisory): it must fail loudly on the OBVIOUS
# forms -- a numeral of any script, a math symbol, a Latin/Greek letter, a
# quote mark (Hebrew numerals), a number word from the closed list such as
# "התשובה היא אחד" -- and it does (PROSE_HAS_MATH). Its escapes are
# DOCUMENTED LIMITS, not defects to patch one by one: e.g. אחד followed by
# a question word that starts with מה ("אחד מהי המסקנה", closing verifier
# r2, CR2-07) reads as "one of the ..."; the prefix rule reads הכל as ה+כל,
# so "בסך הכל אחד" reads as "each" (CR2-08); a Hebrew numeral without a
# quote (יג); a claim written out in words.
# Prose is free Hebrew wording (instructions, not maths). It is approved by
# the author (approved_by + approved_hash of the exact text), and a lexical
# backstop refuses anything that can carry a number or name an object.
# After NFKD and removing Hebrew points / invisible marks, prose may hold
# ONLY: Hebrew letters (U+05D0-U+05EA), white space, and the punctuation in
# PROSE_PUNCT (verifier r2, R2-01: a blacklist of quote marks missed
# U+201D, U+2019, U+2033, U+02BA; a whitelist cannot miss one). So no
# numeral of any script, no Latin/Greek letter, no math symbol and no quote
# mark of any shape (the Hebrew numerals י"ג, י״ג, י”ג, ה' all need one).
# On top, Hebrew number words from a closed list are refused, with up to
# FOUR one-letter prefixes (closing verifier r1, C1-09: ו+כ+ש+ה in
# "וכשהשלושים" is four) (ו ה ב ל מ ש כ) and one possessive / plural
# suffix (R2-10: שלושתם, שניהם, ארבעתן) stripped. It is a backstop, not a
# proof: a Hebrew numeral written without a quote (יג) or a claim written
# out in words is not caught -- the author's approval is the control.
PROSE_SYMBOLS = frozenset("$\\=<>∠°√∥⊥△≅%₪^_{}|~+*/")
PROSE_PUNCT = frozenset(" .,;:!?()-\u2013\u2014\u05be\n")
PROSE_PREFIXES = "והבלמשכ"
PROSE_SUFFIXES = ("יהם", "יהן", "הם", "הן", "תם", "תן", "כם", "כן", "נו",
                  "ם", "ן", "ו", "ה", "י", "ך")
PROSE_NUMBER_WORDS = frozenset("""
אפס אחד אחת שניים שנים שתיים שתים שני שתי שלוש שלושה שלשה שלושת שלש
ארבע ארבעה ארבעת חמש חמישה חמשה חמשת שש שישה ששה ששת שבע שבעה שבעת
שמונה שמונת תשע תשעה תשעת עשר עשרה עשרת עשרים שלושים שלשים ארבעים
חמישים שישים ששים שבעים שמונים תשעים מאה מאות מאתיים אלף אלפים אלפיים
רבבה רבבות מיליון מיליונים מיליארד מיליארדים תריסר עשרות אלפי
חצי חציו חציה מחצית מחציתו מחציתה שליש שלישים רבע רבעים חמישית
חמישיות שישית שביעית שמינית תשיעית עשירית עשיריות אחוז אחוזים
ראשון ראשונה שנייה שנית שלישי שלישית רביעי רביעית חמישי שישי שביעי
שמיני תשיעי עשירי פעמיים כפליים כפול כפולה
חצאים חצאי
שלישייה שלישיה רביעייה רביעיה חמישייה חמישיה זוג זוגות
ישרה ישרות שטוחה שטוחות
""".split())


# "one" in a FIXED quantifier phrase is not a number (verifier r3, R3-08):
#   כל אחד / כל אחת      ("each"; כל with up to three prefixes: לכל, ובכל)
#   אחד מה… / אחד מן / אחד מבין   ("one of the ...")
# Only these two shapes, only for אחד/אחת (with up to four one-letter
# prefixes, no suffix). Anywhere else אחד is still a number word: "התשובה
# היא אחד", "אחד מטר" (מט… is not מה/מן/מבין) are refused.
# The two words must be NEIGHBOURS IN ONE CLAUSE: only spaces between them
# (closing verifier r1, C1-03). Any punctuation, a line break or a maqaf
# ends the phrase, so "התשובה היא אחד. מהו הנימוק?" and "היא כל. אחד!" are
# refused. The first word of the text has no neighbour before it (C1-05:
# the index must not wrap round to the last word).
PROSE_MAX_PREFIXES = 4
PROSE_ONE = frozenset(["אחד", "אחת"])
PROSE_ONE_BEFORE = frozenset(["כל"])


def _strip_prefixes(tok):
    """tok and its forms with up to PROSE_MAX_PREFIXES one-letter prefixes
    removed (the stem keeps >= 2 letters)."""
    out = [tok]
    k = 0
    while k < PROSE_MAX_PREFIXES and len(tok) - k > 2 and \
            tok[k] in PROSE_PREFIXES:
        k += 1
        out.append(tok[k:])
    return out


def _fixed_one(toks, i, glued):
    """toks[i] is אחד/אחת inside a fixed quantifier phrase. glued[j]: toks[j]
    follows toks[j - 1] with only spaces between (same clause); glued[0]
    is False."""
    if not any(st in PROSE_ONE for st in _strip_prefixes(toks[i])):
        return False
    # glued[0] is False, so toks[i - 1] is never read at i = 0 (it would
    # wrap round to the LAST word; C1-05)
    if glued[i] and any(st in PROSE_ONE_BEFORE
                        for st in _strip_prefixes(toks[i - 1])):
        return True
    nxt = toks[i + 1] if i + 1 < len(toks) and glued[i + 1] else ""
    return nxt == "מן" or (len(nxt) > 2 and nxt.startswith(("מה", "מבין")))


def _number_word(tok):
    """tok (Hebrew letters) is a number word after stripping up to three
    one-letter prefixes and at most one suffix; the stem keeps >= 2
    letters."""
    stems = _strip_prefixes(tok)
    for st in list(stems):
        for suf in PROSE_SUFFIXES:
            if st.endswith(suf) and len(st) - len(suf) >= 2:
                stems.append(st[:-len(suf)])
    return any(c in PROSE_NUMBER_WORDS for c in stems)


def prose_math(text, approved_words=()):
    """Why prose text may carry maths, or None. approved_words (v6.10): the
    number WORDS a human approval of this exact text declares are not a
    value ("במשפט אחד" -- in one sentence); only those, only words (a
    numeral, a symbol or a Latin letter is never approved this way)."""
    t = unicodedata.normalize("NFKD", text)
    for ch in t:
        if ch.isnumeric():
            return "numeral %r" % ch
        if ch in PROSE_SYMBOLS or unicodedata.category(ch) == "Sm":
            return "math symbol %r" % ch
        name = unicodedata.name(ch, "")
        if name.startswith(("LATIN", "GREEK")):
            return "Latin/Greek letter %r (an object name)" % ch
        if ch in "\u05f3\u05f4":
            return "geresh/gershayim (a Hebrew numeral or unit)"
    # drop invisible format marks and HEBREW points only; any other
    # combining mark stays and fails the whitelist (U+00B4 decomposes to a
    # space + U+0301 -- dropping every Mn made "י´ג" read as "י ג")
    t = "".join(ch for ch in t if not (
        unicodedata.category(ch) == "Cf" or (
            unicodedata.category(ch) == "Mn" and "\u0591" <= ch <= "\u05c7")))
    for ch in t:
        if not ("\u05d0" <= ch <= "\u05ea" or ch in PROSE_PUNCT):
            return "character %r (U+%04X) outside Hebrew letters and " \
                "plain punctuation" % (ch, ord(ch))
    spans = [(m.group(0), m.start(), m.end())
             for m in re.finditer("[\u05d0-\u05ea]+", t)]
    toks = [x[0] for x in spans]
    glued = [False] + [set(t[spans[j - 1][2]:spans[j][1]]) == set(" ")
                       for j in range(1, len(spans))]
    for i, tok in enumerate(toks):
        if _number_word(tok) and not _fixed_one(toks, i, glued) and \
                tok not in approved_words:
            return "number word %r" % tok
    return None


# ------------------------------------------------------ closed fields ---
TOP_FIELDS = {"spec_version": True, "sheet": True, "entities": True,
              "questions": True, "facts": True, "figures": True,
              "prose": False, "releases": False, "didactic": False}
QUESTION_FIELDS = {"id": True, "n": True, "text": True, "figure": False,
                   "items": True, "star": False,
                   # (v6.13, W-BOUND-PROSE) a table as data, a worked
                   # example as bound prose (wspec/schema_bound.py)
                   "table": False, "example": False,
                   "printed_claims": False}
ITEM_FIELDS = {"id": True, "label": True, "task_type": True,
               "measurement_allowed": True, "targets": True, "uses": False,
               "text": True, "figure": False, "key_also": False,
               "transforms": False, "root_equation": False}
FACT_FIELDS = {"id": True, "rel": True, "args": True, "value": False,
               "unit": False, "role": True, "source": True, "item": True,
               "text_template": False, "display": False, "coef": False,
               "form": False,
               # (v6.17, V3 / D6) an irrational ANSWER's printed rounding
               # next to its exact value: 1 | 2 decimal places (numform)
               "approx": False}
SOURCE_FIELDS = {"kind": True, "rule": False, "from": False,
                 "context_kind": False}
FIGURE_FIELDS = {"id": True, "scope": True, "figure_accuracy": True,
                 "entities": True, "draws": True, "frame": False,
                 # (v6.16 integrate) a function graph on a coordinate_plane
                 # frame (wspec/sheet_graph.py, wspec/graph/kinds.py)
                 "graph": False, "data": False, "loci": False,
                 "base_height": False, "inherit_givens": False, "state_change": False}
PROSE_FIELDS = {"id": True, "scope": True, "text": True,
                "approved_hash": True, "approved_by": True,
                "approved_words": False}
# (close_gaps: a release states its BASIS -- 'from_item' provenance, or a
# person's 'approval' with reviewer + timestamp; see project.release_problem)
RELEASE_FIELDS = {"fact": True, "basis": True, "reason": True,
                  "fact_hash": True, "from_item": False, "reviewer": False,
                  "timestamp": False}


def _fields(obj, table, where, out):
    if not isinstance(obj, dict):
        out.append(Issue("BAD_TYPE", where, "expected an object"))
        return False
    for k in obj:
        if k not in table:
            out.append(Issue("UNKNOWN_FIELD", where, k))
    for k, req in table.items():
        if req and k not in obj:
            out.append(Issue("MISSING_FIELD", where, k))
    return True


def _is_list_of_str(v):
    return isinstance(v, list) and all(isinstance(x, str) for x in v)


# --------------------------------------------------------------- index ---
class Index(object):
    """Lookups over a spec: scopes in sheet order, entities, facts."""

    def __init__(self, spec):
        self.spec = spec
        self.entities = {}
        self.facts = {}
        self.scope_key = {}       # scope id -> (question index, item index)
        self.scope_question = {}  # scope id -> question id
        self.items = {}
        self.questions = {}
        for qi, q in enumerate(spec.get("questions") or []):
            if not isinstance(q, dict):
                continue
            self.questions[q.get("id")] = q
            self.scope_key[q.get("id")] = (qi, -1)
            self.scope_question[q.get("id")] = q.get("id")
            for ii, it in enumerate(q.get("items") or []):
                if not isinstance(it, dict):
                    continue
                self.items[it.get("id")] = it
                self.scope_key[it.get("id")] = (qi, ii)
                self.scope_question[it.get("id")] = q.get("id")
        for e in spec.get("entities") or []:
            if isinstance(e, dict):
                self.entities.setdefault(e.get("id"), e)
        for f in spec.get("facts") or []:
            if isinstance(f, dict):
                self.facts.setdefault(f.get("id"), f)
        self.releases = {}
        for r in spec.get("releases") or []:
            if isinstance(r, dict):
                self.releases.setdefault(r.get("fact"), r)
        self.prose, self.figures = {}, {}
        for p in spec.get("prose") or []:
            if isinstance(p, dict):
                self.prose.setdefault(p.get("id"), p)
        for g in spec.get("figures") or []:
            if isinstance(g, dict):
                self.figures.setdefault(g.get("id"), g)

    def kind(self, eid):
        e = self.entities.get(eid)
        return e.get("kind") if e else None

    def visible_scopes(self, scope):
        """Scopes whose facts an item sees: its question, the earlier items
        of that question, and itself."""
        if scope not in self.scope_key:
            return []
        qi, ii = self.scope_key[scope]
        return [s for s, (q, i) in self.scope_key.items()
                if q == qi and i <= ii]

    def facts_in(self, scope):
        return [f for f in self.facts.values() if f.get("item") == scope]


# ------------------------------------------------------------ validate ---
def validate_entities(spec, ix, out):
    seen = set()
    for n, e in enumerate(spec.get("entities") or []):
        w = "entities[%d]" % n
        if not isinstance(e, dict):
            out.append(Issue("BAD_TYPE", w, "entity"))
            continue
        k = e.get("kind")
        if k not in ENTITY_KINDS:
            out.append(Issue("UNKNOWN_ENTITY_KIND", w, repr(k)))
            continue
        table = dict((f, True) for f in ENTITY_KINDS[k])
        table.update(dict((f, False) for f in ENTITY_OPTIONAL.get(k, ())))
        table.update({"id": True, "kind": True})
        if not _fields(e, table, w, out):
            continue
        for f, t in ENTITY_KINDS[k].items():
            v = e.get(f)
            ok = {"str": isinstance(v, str) and v.strip() != "",
                  "list2": _is_list_of_str(v) and len(v) == 2 and
                  v[0] != v[1],
                  "list3+": _is_list_of_str(v) and len(v) >= 3 and
                  len(set(v)) == len(v),
                  "num": v is not None and not isinstance(v, bool),
                  "int": isinstance(v, int) and not isinstance(v, bool),
                  "bool": isinstance(v, bool),
                  }[t]
            if not ok:
                out.append(Issue("BAD_TYPE", w + "." + f, repr(v)))
        for fld, rx in ENTITY_NAME_RULES.get(k, {}).items():
            if fld in e and not (isinstance(e[fld], str) and
                                 rx.match(e[fld])):
                out.append(Issue("BAD_ID", w, "%s %s %r" % (k, fld,
                                                             e.get(fld))))
        want = canon.entity_id(e)
        if e.get("id") != want:
            out.append(Issue("ENTITY_ID_NOT_CANONICAL", w,
                             "%r != %r" % (e.get("id"), want)))
        if e.get("id") in seen:
            out.append(Issue("DUPLICATE_ENTITY", w, e.get("id")))
        seen.add(e.get("id"))
    # references
    for n, e in enumerate(spec.get("entities") or []):
        if not isinstance(e, dict):
            continue
        named = []
        for f, want in ENTITY_REF_KINDS.get(e.get("kind"), {}).items():
            v = e.get(f)
            wants = want if isinstance(want, tuple) else (want,)
            for r in (v if isinstance(v, list) else [v]):
                if not isinstance(r, str) or r not in ix.entities:
                    out.append(Issue("UNKNOWN_ENTITY_REF",
                                     "entities[%d].%s" % (n, f), repr(r)))
                elif ix.kind(r) not in wants:
                    out.append(Issue("ENTITY_REF_KIND",
                                     "entities[%d].%s" % (n, f),
                                     "%r is a %s, not a %s" % (
                                         r, ix.kind(r), " / ".join(wants))))
                if "point" in wants:
                    named.append(r)
        dup = sorted(set(r for r in named if named.count(r) > 1), key=str)
        if dup:
            out.append(Issue("ENTITY_DEGENERATE", "entities[%d]" % n,
                             "%s names %s twice" % (e.get("id"),
                                                    ", ".join(map(str, dup)))))
        if e.get("kind") == "polygon":
            _polygon_tag_issues(e, n, ix, out)


# (v6.16 gaps, corpus-v2 G5) a polygon declared by coordinates only
REASONS.setdefault("POLYGON_TAG", "(v6.16) a polygon with unnamed vertices "
                   "is not tagged, or its vertices are not its own unnamed "
                   "vertices 1..k in order, or a named polygon carries a tag")


def _polygon_tag_issues(e, n, ix, out):
    """a tagged polygon's vertices are exactly vtx:<tag>:1 .. vtx:<tag>:k in
    order (unnamed vertex entities of that tag); a polygon of named points
    carries no tag; one polygon never mixes the two."""
    vs = e.get("vertices") if isinstance(e.get("vertices"), list) else []
    kinds = set(ix.kind(v) for v in vs if isinstance(v, str))
    w = "entities[%d]" % n
    tag = e.get("tag")
    if "vertex" not in kinds:
        if tag is not None:
            out.append(Issue("POLYGON_TAG", w, "%s: a polygon of named "
                             "points has no tag" % e.get("id")))
        return
    if kinds != {"vertex"} or not isinstance(tag, str):
        out.append(Issue("POLYGON_TAG", w, "%s: unnamed vertices need a "
                         "tagged polygon of unnamed vertices only"
                         % e.get("id")))
        return
    for k, v in enumerate(vs):
        ve = ix.entities.get(v) or {}
        if ve.get("of") != tag or ve.get("n") != k + 1:
            out.append(Issue("POLYGON_TAG", w, "%s: vertex %d is %s, not "
                             "vtx:%s:%d" % (e.get("id"), k + 1, v, tag,
                                            k + 1)))


def _display_ok(eid, name, ix):
    """A display name must name the entity: a segment by its two ends in
    either order, an angle by arm-vertex-arm (either order) or by its
    vertex alone, a polygon by any rotation/direction of its vertices."""
    e = ix.entities.get(eid)
    if e is None or not isinstance(name, str):
        return False
    k = e.get("kind")
    if k == "segment":
        a, b = e["ends"]
        return name in (a + b, b + a)
    if k == "angle":
        a, b = e["arms"]
        v = e["vertex"]
        return name in (a + v + b, b + v + a, v)
    if k == "polygon":
        vs = list(name)
        return (len(vs) == len(e["vertices"]) and
                canon.canon_cycle(vs) == canon.canon_cycle(e["vertices"]))
    if k in ("line", "arc"):                 # R2-08: letters, either order
        a, b = e["through"] if k == "line" else e["ends"]
        return name in (a + b, b + a)
    if k == "ray":                           # a ray only from its origin
        return name == e["from"] + e["through"]
    if k == "circle":
        return name in (e.get("name"), e["center"])
    if k == "variable":                      # (v6.10) its own name
        return name == e.get("name")
    return name == eid


def validate_facts(spec, ix, out):
    seen = set()
    for n, f in enumerate(spec.get("facts") or []):
        w = "facts[%d]" % n
        if not _fields(f, FACT_FIELDS, w, out):
            continue
        w = "fact %s" % f.get("id")
        rel, role, args = f.get("rel"), f.get("role"), f.get("args")
        if f.get("item") not in ix.scope_key:
            out.append(Issue("UNKNOWN_SCOPE", w, repr(f.get("item"))))
        if role not in ROLES:
            out.append(Issue("UNKNOWN_ROLE", w, repr(role)))
        elif (role in TARGET_ROLES or role == "answer") and \
                f.get("item") in ix.questions:
            out.append(Issue("ITEM_TARGETS_MISMATCH", w,
                             "a %s belongs to an item, not a question" % role))
        if rel not in RELS:
            out.append(Issue("UNKNOWN_REL", w, repr(rel)))
        if not _is_list_of_str(args):
            out.append(Issue("BAD_TYPE", w + ".args", repr(args)))
            continue
        want = canon.fact_id(f)
        if f.get("id") != want:
            out.append(Issue("FACT_ID_NOT_CANONICAL", w,
                             "%r != %r" % (f.get("id"), want)))
        if f.get("id") in seen:
            out.append(Issue("DUPLICATE_FACT", w, f.get("id")))
        seen.add(f.get("id"))
        for a in args:
            if a not in ix.entities:
                out.append(Issue("UNKNOWN_ENTITY_REF", w, repr(a)))
        # S3: a construction relation is only a to_construct (or its
        # answer), and a to_construct is only a construction relation
        if ((rel in CONSTRUCT_RELS or rel in PIE_CONSTRUCT_RELS) and
                role not in CONSTRUCT_ROLES) or \
                (role == "to_construct" and rel not in CONSTRUCT_RELS and
                 rel not in PIE_CONSTRUCT_RELS):     # v6.16 integrate
            out.append(Issue("CONSTRUCT_REL_ROLE", w, "%s as %s" % (rel,
                                                                    role)))
        # (v6.12) the plot task: 'plot' is a to_plot (or its answer) only,
        # and a to_plot is a 'plot' only
        if (rel == "plot" and role not in PLOT_ROLES) or \
                (role == "to_plot" and rel != "plot"):
            out.append(Issue("PLOT_REL_ROLE", w, "%s as %s" % (rel, role)))
        if rel in RELS:
            kinds, mode, dim = RELS[rel]
            kinds = rel_kinds(rel, len(args))
            if len(kinds) != len(args):
                out.append(Issue("REL_ARG_KIND", w, "arity"))
            else:
                for a, ks in zip(args, kinds):
                    if ks is not ANY and a in ix.entities and \
                            ix.kind(a) not in ks:
                        out.append(Issue("REL_ARG_KIND", w,
                                         "%s is a %s" % (a, ix.kind(a))))
            _check_value(f, rel, role, mode, dim, w, out, ix)
            if len(kinds) == len(args):
                why = _degenerate(rel, args, ix)
                if why:
                    out.append(Issue("REL_DEGENERATE", w, why))
        # display names
        disp = f.get("display")
        if disp is not None:
            if not isinstance(disp, list) or len(disp) != len(args):
                out.append(Issue("DISPLAY_MISMATCH", w, "shape"))
            else:
                for a, d in zip(args, disp):
                    if d is not None and not _display_ok(a, d, ix):
                        out.append(Issue("DISPLAY_MISMATCH", w,
                                         "%r for %s" % (d, a)))
        _check_source(f, ix, w, out)
    # answers <-> targets
    for f in ix.facts.values():
        if not isinstance(f, dict):
            continue
        role = f.get("role")
        if role == "answer":
            tid = f.get("id", "")[:-1] + "t"
            t = ix.facts.get(tid)
            if t is None or t.get("role") not in TARGET_ROLES:
                out.append(Issue("ANSWER_WITHOUT_TARGET", f.get("id"), tid))
        elif role in TARGET_ROLES:
            aid = f.get("id", "")[:-1] + "a"
            if aid not in ix.facts:
                out.append(Issue("TARGET_WITHOUT_ANSWER", f.get("id"), aid))


# relations of two objects that say nothing (or are false) about one
# object twice (close_gaps SV3-01)
PAIR_RELS = ("equal_length", "equal_angle", "parallel", "perpendicular",
             "congruent", "ratio", "greater", "not_parallel")


def _degenerate(rel, args, ix):
    """Why a fact says nothing, or cannot hold, by its own arguments
    (close_gaps SV3-01, verifier semantics r3: 'H על AH' -- H is an end of
    AH -- said nothing, 'H אמצע AH' cannot be, and both counted as givens
    that fix H): '' when it is not degenerate."""
    if rel in ("on_segment", "midpoint") and len(args) == 2 and \
            ix.kind(args[0]) == "point" and ix.kind(args[1]) == "segment":
        p = (ix.entities.get(args[0]) or {}).get("name")
        ends = (ix.entities.get(args[1]) or {}).get("ends") or []
        if p in ends:
            return "%s is an end of %s: %s" % (p, args[1], "a point on its "
                                               "own segment says nothing"
                                               if rel == "on_segment" else
                                               "an end is not the midpoint")
    if rel in PAIR_RELS and len(args) == 2 and args[0] == args[1]:
        return "%s of %s with itself" % (rel, args[0])
    return ""


def rel_kinds(rel, n):
    """The argument kinds of relation `rel` called with n arguments (a
    VARIADIC relation repeats its one kind list; out of range: ())."""
    kinds = RELS[rel][0]
    if rel in VARIADIC:
        lo, hi = VARIADIC[rel]
        return tuple(kinds[0] for _ in range(n)) if lo <= n <= hi else ()
    return kinds


def _check_value(f, rel, role, mode, dim, w, out, ix=None):
    has_v = f.get("value") is not None
    has_u = f.get("unit") not in (None, "")
    if "coef" in f and rel != "linear":
        out.append(Issue("VALUE_FORBIDDEN", w, "coef on " + str(rel)))
    if role == "target":
        if has_v or has_u:
            out.append(Issue("TARGET_HAS_VALUE", w, "value/unit on a target"))
        return
    if mode == "const":
        # (v6.10) linear: the constant is optional; its unit is checked
        # with the terms' dimension (validate_language)
        if has_v:
            try:
                canon.parse_exact(f["value"])
            except Exception:
                out.append(Issue("BAD_NUMBER", w, repr(f["value"])))
        elif has_u:
            out.append(Issue("VALUE_FORBIDDEN", w, "a unit without a "
                             "constant"))
        return
    if mode == "class":
        if role == "answer" and has_v:
            vs = (f.get("value") if isinstance(f.get("value"), str) else "")
            if vs not in CLASS_VALUES:
                out.append(Issue("CLASSIFY_VALUE", w, "class %r is not in "
                                 "%s" % (f.get("value"), sorted(CLASS_VALUES))))
        elif has_v:
            out.append(Issue("CLASSIFY_VALUE", w, "a %s of classify carries "
                             "a value" % role))
        if has_u:
            out.append(Issue("VALUE_FORBIDDEN", w, "unit on classify"))
        return
    if mode == "none" or role in ("to_construct", "to_plot"):
        if has_v:
            out.append(Issue("VALUE_FORBIDDEN", w, rel))
        if has_u and rel != "unit_label":
            out.append(Issue("VALUE_FORBIDDEN", w, "unit on " + rel))
        if rel == "unit_label":
            _check_unit(f, None, w, out, required=True)
        return
    # measure
    if not has_v and role != "to_prove":
        out.append(Issue("VALUE_REQUIRED", w, rel))
    if has_v:
        try:
            canon.parse_exact(f["value"])
        except Exception:
            out.append(Issue("BAD_NUMBER", w, repr(f["value"])))
    from . import base_height as BH
    unitless = ix is not None and f.get("role") == "given" and BH.role_of(f, ix)[0] in ("base", "height")
    _check_unit(f, dim, w, out, required=has_v and dim is not None and not unitless)


def _check_unit(f, dim, w, out, required):
    u = f.get("unit")
    if u in (None, ""):
        if required:
            out.append(Issue("UNIT_DIMENSION_MISMATCH", w, "unit missing"))
        return
    try:
        cu = canon.canon_unit(u)
    except Exception:
        out.append(Issue("UNKNOWN_UNIT", w, repr(u)))
        return
    if dim is not None and canon.unit_dimension(cu) != dim:
        out.append(Issue("UNIT_DIMENSION_MISMATCH", w,
                         "%s is not %s" % (cu, dim)))
    if dim is None and not required and f.get("rel") != "unit_label":
        # a dimensionless relation (ratio, var, tick) with a unit: allowed
        # only when the unit is declared -- the table above checked that
        pass


def _check_source(f, ix, w, out):
    src = f.get("source")
    role = f.get("role")
    if not _fields(src, SOURCE_FIELDS, w + ".source", out):
        return
    k = src.get("kind")
    if k not in SOURCE_KINDS:
        out.append(Issue("UNKNOWN_SOURCE", w, repr(k)))
        return
    if role in ROLE_SOURCES and k not in ROLE_SOURCES[role]:
        out.append(Issue("ROLE_SOURCE_MISMATCH", w, "%s/%s" % (role, k)))
    rel = f.get("rel")
    if k != "context" and rel in CONTEXT_RELS:
        out.append(Issue("CONTEXT_KIND_MISMATCH", w,
                         "context relation %s outside role context" % rel))
    if k == "context":
        ck = src.get("context_kind")
        if ck not in CONTEXT_KINDS:
            out.append(Issue("UNKNOWN_CONTEXT_KIND", w, repr(ck)))
            return
        crel, ckinds = CONTEXT_KINDS[ck]
        args = f.get("args") or []
        nargs = 2 if ck == "point_place" else 1
        if rel != crel or len(args) != nargs or (
                ckinds is not None and ix.kind(args[0]) not in ckinds) or (
                    nargs == 2 and ix.kind(args[1]) != "axis"):
            out.append(Issue("CONTEXT_KIND_MISMATCH", w,
                             "%s on %s(%s)" % (ck, rel, ",".join(args))))
            return
        if ck == "vertex_name" and not any(
                e.get("kind") == "polygon" and args[0] in e.get("vertices", [])
                for e in ix.entities.values()):
            out.append(Issue("CONTEXT_KIND_MISMATCH", w,
                             "%s is no polygon's vertex" % args[0]))
        if ck == "axis_tick":
            e = ix.entities.get(args[0]) or {}
            try:
                same = canon.canon_number(f.get("value")) == \
                    canon.canon_number(e.get("at"))
            except Exception:
                same = False
            if not same:
                out.append(Issue("CONTEXT_KIND_MISMATCH", w,
                                 "tick label differs from the tick's place"))
        for extra in ("rule", "from"):
            if extra in src:
                out.append(Issue("UNKNOWN_FIELD", w + ".source", extra))
    elif k == "derived":
        rule = src.get("rule")
        if rule not in RULES:
            out.append(Issue("UNKNOWN_RULE", w, repr(rule)))
        frm = src.get("from")
        if not _is_list_of_str(frm) or not frm:
            out.append(Issue("DERIVED_FROM_MISSING", w, repr(frm)))
            return
        if role == "answer":
            if rule != "answer_key" or frm != [f.get("id", "")[:-1] + "t"]:
                out.append(Issue("ROLE_SOURCE_MISMATCH", w,
                                 "an answer is answer_key from its target"))
        elif rule == "answer_key":
            out.append(Issue("ROLE_SOURCE_MISMATCH", w,
                             "answer_key outside an answer"))
        me = ix.scope_key.get(f.get("item"))
        for x in frm:
            g = ix.facts.get(x)
            if g is None:
                out.append(Issue("UNKNOWN_FACT_REF", w, repr(x)))
                continue
            if x == f.get("id"):
                out.append(Issue("DERIVED_FROM_LATER", w, "from itself"))
                continue
            gk = ix.scope_key.get(g.get("item"))
            if me is None or gk is None or gk[0] != me[0] or gk > me:
                if role != "answer":
                    out.append(Issue("DERIVED_FROM_LATER", w, x))
        for extra in ("context_kind",):
            if extra in src:
                out.append(Issue("UNKNOWN_FIELD", w + ".source", extra))
    else:   # stated
        for extra in ("rule", "from", "context_kind"):
            if extra in src:
                out.append(Issue("UNKNOWN_FIELD", w + ".source", extra))


def validate_ids(spec, ix, out):
    """One namespace per kind of id; each id at most once (V6)."""
    seen = {}
    for q in spec.get("questions") or []:
        if not isinstance(q, dict):
            continue
        seen.setdefault(("scope", q.get("id")), []).append("question")
        for it in q.get("items") or []:
            if isinstance(it, dict):
                seen.setdefault(("scope", it.get("id")), []).append("item")
    for k, fld in (("figures", "id"), ("prose", "id"), ("releases", "fact")):
        for x in spec.get(k) or []:
            if isinstance(x, dict):
                seen.setdefault((k, x.get(fld)), []).append(k)
    for (ns, i), where in sorted(seen.items(), key=lambda kv: repr(kv[0])):
        if len(where) > 1:
            out.append(Issue("DUPLICATE_ID", "%s %r" % (ns, i),
                             "%d times (%s)" % (len(where),
                                                ", ".join(where))))


def validate_items(spec, ix, out):
    last_n = 0
    for qn, q in enumerate(spec.get("questions") or []):
        wq = "questions[%d]" % qn
        if not _fields(q, QUESTION_FIELDS, wq, out):
            continue
        if not canon.TOKEN_RE.match(str(q.get("id"))):
            out.append(Issue("BAD_ID", wq, repr(q.get("id"))))
        n = q.get("n")
        if not is_count(n):
            out.append(Issue("BAD_TYPE", wq + ".n", repr(n)))
        else:
            if q.get("id") != question_id(n):
                out.append(Issue("SCOPE_NOT_CANONICAL", wq, "%r != %r" % (
                    q.get("id"), question_id(n))))
            if n <= last_n:
                out.append(Issue("SCOPE_NOT_CANONICAL", wq,
                                 "question %d after %d" % (n, last_n)))
            last_n = n
        if "star" in q and not isinstance(q["star"], bool):
            out.append(Issue("BAD_TYPE", wq + ".star", repr(q["star"])))
        if q.get("figure") is not None and q["figure"] not in ix.figures:
            out.append(Issue("UNKNOWN_FIGURE", wq, repr(q["figure"])))
        if not isinstance(q.get("items"), list):
            out.append(Issue("BAD_TYPE", wq + ".items", "list"))
            continue
        for itn, it in enumerate(q["items"]):
            w = "%s.items[%d]" % (wq, itn)
            if not _fields(it, ITEM_FIELDS, w, out):
                continue
            w = "item %s" % it.get("id")
            if not canon.TOKEN_RE.match(str(it.get("id"))):
                out.append(Issue("BAD_ID", w, repr(it.get("id"))))
            want_id = item_id(str(q.get("id")), itn)
            if it.get("id") != want_id:
                out.append(Issue("SCOPE_NOT_CANONICAL", w, "%r != %r" % (
                    it.get("id"), want_id)))
            if it.get("label") != item_label(itn):
                out.append(Issue("SCOPE_NOT_CANONICAL", w, "label %r != %r"
                                 % (it.get("label"), item_label(itn))))
            tt = it.get("task_type")
            if tt not in TASK_TYPES:
                out.append(Issue("UNKNOWN_TASK_TYPE", w, repr(tt)))
            ma = it.get("measurement_allowed")
            if not isinstance(ma, bool):
                out.append(Issue("BAD_TYPE", w + ".measurement_allowed",
                                 repr(ma)))
            elif tt in MEASURE_TASKS and not ma:
                out.append(Issue("MEASURE_NEEDS_MEASUREMENT", w, tt))
            for f in ix.facts_in(it.get("id")):
                if f.get("role") == "to_construct" and tt != "construct" \
                        and not claim_presupposes_join(f, ix):
                    # S3: a construction task sits in a construct item
                    out.append(Issue("CONSTRUCT_NOT_IN_CONSTRUCT_ITEM", w,
                                     "%s in a %r item" % (f.get("id"), tt)))
            for f in ix.facts_in(it.get("id")):
                if f.get("role") == "to_plot" and tt != "plot":
                    # (v6.12) a plot task sits in a plot item
                    out.append(Issue("PLOT_NOT_IN_PLOT_ITEM", w,
                                     "%s in a %r item" % (f.get("id"), tt)))
            if tt == "plot" and not any(
                    f.get("role") == "to_plot"
                    for f in ix.facts_in(it.get("id"))) and \
                    it.get("id") not in _graph_plot_items(ix):
                out.append(Issue("PLOT_ITEM_NO_TARGET", w,
                                 "a 'plot' item without a to_plot"))
            if tt == "construct" and not any(
                    f.get("role") == "to_construct"
                    for f in ix.facts_in(it.get("id"))):
                # (verifier semantics r2, SR2-07) the converse of the rule
                # above: a construct item asks for a construction
                out.append(Issue("CONSTRUCT_ITEM_NO_TARGET", w,
                                 "a 'construct' item without a to_construct"))
            want = sorted(f["id"] for f in ix.facts_in(it.get("id"))
                          if f.get("role") in TARGET_ROLES)
            if sorted(it.get("targets") or []) != want:
                out.append(Issue("ITEM_TARGETS_MISMATCH", w,
                                 "%r != %r" % (it.get("targets"), want)))
            if it.get("figure") is not None:
                fg = ix.figures.get(it["figure"])
                if fg is None:
                    out.append(Issue("UNKNOWN_FIGURE", w, repr(it["figure"])))
            for u in it.get("uses") or []:
                if u not in ix.facts:
                    out.append(Issue("UNKNOWN_FACT_REF", w + ".uses", u))
            _key_also_issues(it, q, ix, w, out)


def _graph_plot_items(ix):
    """(v6.16 integrate) items whose plot task is a graph find (to_plot /
    plot_point of a graph figure): their target is the find, not a fact"""
    from . import sheet_graph as SGR
    return SGR.plot_items(ix)


def named_segments(f, ix):
    """(v6.10 fix r1, L2) the segments a fact names: its segment
    arguments, the sides of its polygon arguments, the arms of its angle
    arguments (as frozensets of the two point names)"""
    out = set()
    for a in f.get("args") or []:
        e = ix.entities.get(a) if isinstance(a, str) else None
        if not e:
            continue
        k = e.get("kind")
        if k == "segment":
            out.add(frozenset(e.get("ends") or []))
        elif k == "polygon":
            vs = list(e.get("vertices") or [])
            out.update(frozenset((vs[i], vs[(i + 1) % len(vs)]))
                       for i in range(len(vs)))
        elif k == "angle":
            v = e.get("vertex")
            out.update(frozenset((v, x)) for x in e.get("arms") or [])
    return out


def claim_presupposes_join(f, ix):
    """(v6.10 fix r1, L2) a to_construct construct_join whose segment a
    to_prove / target of its OWN item names ('ME = ½BC' presupposes drawing
    ME): the student's construction inside a prove / compute item"""
    if f.get("role") != "to_construct" or f.get("rel") != "construct_join":
        return None
    e = ix.entities.get((f.get("args") or [None])[0]) or {}
    want = frozenset(e.get("ends") or [])
    if len(want) != 2:
        return None
    for g in sorted(ix.facts_in(f.get("item")), key=lambda x: x["id"]):
        if g.get("role") in ("to_prove", "target") and \
                want in named_segments(g, ix):
            return g["id"]
    return None


def _key_also_issues(it, q, ix, w, out):
    """(v6.10 fix r1, K) key_also: [fact id] -- values the answer key line
    restates beside the item's own answers (v6.7.3's '∠ABC = 90°' in the key
    of 'חשבו את זוויות המשולש ABC', where ∠ABC = 90° is what the previous
    item proved: a known value is no target -- TARGET_ALREADY_GIVEN -- so
    the key names it this way). Private (the key only); each one a given /
    to_prove WITH a value of the same question, at or before the item, and
    not one of the item's own targets."""
    ka = it.get("key_also")
    if ka is None:
        return
    if not isinstance(ka, list) or not ka:
        out.append(Issue("BAD_TYPE", w + ".key_also", repr(ka)))
        return
    mine = ix.scope_key.get(it.get("id"))
    for x in ka:
        f = ix.facts.get(x) if isinstance(x, str) else None
        if f is None:
            out.append(Issue("UNKNOWN_FACT_REF", w + ".key_also", repr(x)))
            continue
        sk = ix.scope_key.get(f.get("item"))
        why = None
        if f.get("role") not in ("given", "to_prove"):
            why = "role %s (a given or a proved claim only)" % f.get("role")
        elif f.get("value") is None:
            why = "no value"
        elif f.get("rel") not in ("angle_measure", "length"):
            why = "relation %s (an angle or a length)" % f.get("rel")
        elif sk is None or mine is None or sk[0] != mine[0] or sk > mine:
            why = "not of this question at or before the item"
        elif x in (it.get("targets") or []):
            why = "one of the item's own targets"
        if why:
            out.append(Issue("KEY_ALSO_BAD", w + ".key_also",
                             "%s: %s" % (x, why)))


def entity_closure(eid, ix):
    """eid and every entity it references, transitively (a segment -> its
    two points; an arc -> its circle -> the centre; a tick -> its axis)."""
    seen, todo = set(), [eid]
    while todo:
        x = todo.pop()
        if x in seen or not isinstance(x, str):
            continue
        seen.add(x)
        e = ix.entities.get(x) or {}
        for fld in ENTITY_REFS.get(e.get("kind"), ()):
            v = e.get(fld)
            todo.extend(v if isinstance(v, list) else [v])
    return seen


def validate_figures(spec, ix, out):
    for n, g in enumerate(spec.get("figures") or []):
        w = "figures[%d]" % n
        if not _fields(g, FIGURE_FIELDS, w, out):
            continue
        w = "figure %s" % g.get("id")
        if g.get("figure_accuracy") not in FIGURE_ACCURACY:
            out.append(Issue("BAD_FIGURE_ACCURACY", w,
                             repr(g.get("figure_accuracy"))))
        if g.get("scope") not in ix.scope_key:
            out.append(Issue("UNKNOWN_SCOPE", w, repr(g.get("scope"))))
        else:
            want = figure_id(g["scope"], g["scope"] in ix.questions)
            if g.get("id") != want:
                out.append(Issue("SCOPE_NOT_CANONICAL", w, "%r != %r" % (
                    g.get("id"), want)))
        for e in g.get("entities") or []:
            if e not in ix.entities:
                out.append(Issue("UNKNOWN_ENTITY_REF", w, repr(e)))
        listed = set(g.get("entities") or [])
        for d in g.get("draws") or []:
            if d not in ix.facts:
                out.append(Issue("UNKNOWN_FACT_REF", w, repr(d)))
                continue
            # a drawn fact is drawn ON the figure's entities: each argument
            # and every entity it is built from must be listed, so the
            # geometry check requires and measures them (verifier r2, R2-07)
            need = set()
            for a in ix.facts[d].get("args") or []:
                need |= entity_closure(a, ix)
            miss = sorted(x for x in need - listed if x in ix.entities)
            if miss:
                out.append(Issue("FIGURE_DRAWS_UNLISTED", w, "%s needs %s" % (
                    d, ", ".join(miss))))


def validate_figure_links(spec, ix, out):
    """(close_gaps SV3-04) every figure is SHOWN by a question or an item
    (its figure field): a figure no scope shows is an orphan -- the item it
    was drawn for shows something else."""
    shown = set()
    for q in spec.get("questions") or []:
        if isinstance(q, dict):
            shown.add(q.get("figure"))
            for it in q.get("items") or []:
                if isinstance(it, dict):
                    shown.add(it.get("figure"))
    for g in spec.get("figures") or []:
        if isinstance(g, dict) and g.get("id") not in shown:
            out.append(Issue("FIGURE_NOT_SHOWN", "figure %s" % g.get("id"),
                             "no question or item shows it"))


def validate_prose(spec, ix, out):
    for n, p in enumerate(spec.get("prose") or []):
        w = "prose[%d]" % n
        if not _fields(p, PROSE_FIELDS, w, out):
            continue
        w = "prose %s" % p.get("id")
        t = p.get("text")
        if not isinstance(t, str):
            out.append(Issue("BAD_TYPE", w, "text"))
            continue
        if p.get("scope") not in ix.scope_key:
            out.append(Issue("UNKNOWN_SCOPE", w, repr(p.get("scope"))))
        if p.get("approved_hash") != canon.sha256_text(t):
            out.append(Issue("PROSE_UNAPPROVED", w, "hash of exact text"))
        if not (isinstance(p.get("approved_by"), str) and
                p["approved_by"].strip()):
            out.append(Issue("PROSE_UNAPPROVED", w, "no approved_by"))
        aw = p.get("approved_words")
        if aw is not None and not (isinstance(aw, list) and all(
                isinstance(x, str) and x.strip() for x in aw)):
            out.append(Issue("BAD_TYPE", w, "approved_words"))
            aw = []
        approved = p.get("approved_hash") == canon.sha256_text(t) and \
            isinstance(p.get("approved_by"), str) and \
            p["approved_by"].strip()
        why = prose_math(t, tuple(aw or ()) if approved else ())
        if why:
            out.append(Issue("PROSE_HAS_MATH", w, why))


def validate_releases(spec, ix, out):
    for n, r in enumerate(spec.get("releases") or []):
        w = "releases[%d]" % n
        if not _fields(r, RELEASE_FIELDS, w, out):
            continue
        f = ix.facts.get(r.get("fact"))
        if f is None:
            out.append(Issue("UNKNOWN_FACT_REF", w, repr(r.get("fact"))))
            continue
        if f.get("role") in ("answer", "target"):
            out.append(Issue("RELEASE_OF_PRIVATE", w, f.get("id")))
        from .project import release_problem
        bad = release_problem(r, f, ix)
        if bad:
            out.append(Issue(bad[0], w, "%s: %s" % (f.get("id"), bad[1])))
        if r.get("fact_hash") != canon.fact_hash(f):
            out.append(Issue("RELEASE_STALE", w, f.get("id")))


def validate(spec, templates=None):
    """All checks. Returns a list of Issue (empty = valid), SORTED by
    (code, where, detail): the same spec gives the same list whatever the
    order of its input lists (verifier semantics r2, SR2-06)."""
    return sorted(_validate(spec, templates),
                  key=lambda i: (i.code, str(i.where), str(i.detail)))


def _validate(spec, templates=None):
    from . import templates as T
    from . import project as P
    from . import baseline as B
    out = []
    if not _fields(spec, TOP_FIELDS, "spec", out):
        return out
    if spec.get("spec_version") != SPEC_VERSION:
        out.append(Issue("BAD_TYPE", "spec.spec_version",
                         repr(spec.get("spec_version"))))
    if not isinstance(spec.get("sheet"), str):
        out.append(Issue("BAD_TYPE", "spec.sheet", "a sheet id string"))
    elif not SHEET_RE.match(spec["sheet"]):
        out.append(Issue("BAD_ID", "spec.sheet", repr(spec["sheet"])))
    for k in ("entities", "questions", "facts", "figures"):
        if not isinstance(spec.get(k), list):
            out.append(Issue("BAD_TYPE", "spec." + k, "list"))
    if out:
        return out
    ix = Index(spec)
    validate_ids(spec, ix, out)
    validate_entities(spec, ix, out)
    validate_items(spec, ix, out)
    validate_facts(spec, ix, out)
    from . import language as LANG
    LANG.validate_language(spec, ix, out)
    # (v6.17-noam V1 / V2) the checked rules and the angle recomputations
    from . import rules617 as R617
    R617.validate_rules(spec, ix, out)
    from . import family as FAM
    FAM.validate_family(spec, ix, out)
    validate_figures(spec, ix, out)
    # (v6.16 integrate) the graph blocks of coordinate_plane figures and the
    # pie chart family (their own grammar, exact data and answers)
    from . import sheet_graph as SGR
    from . import sheet_pie as SPI
    SGR.validate(spec, ix, out)
    SPI.validate(spec, ix, out)
    from . import sheet_data as SDA
    SDA.validate(spec, ix, out)
    from . import sheet_locus as SLO
    SLO.validate(spec, ix, out)
    from . import named_lines as NL
    out.extend(NL.schema_issues(spec, ix))
    validate_figure_links(spec, ix, out)
    from . import figure_scopes618 as FS618
    FS618.validate(spec, ix, out)
    validate_prose(spec, ix, out)
    # (v6.13, W-BOUND-PROSE) bound prose, tables, worked examples
    from . import schema_bound as SB
    SB.validate_bound(spec, ix, out)
    from . import point_transform as PT
    PT.validate(spec, ix, out)
    # (v6.17, V3 / V5) the √ number form, approx, exact answers (numform)
    from . import numform as NF
    NF.validate_numform(spec, ix, out)
    validate_releases(spec, ix, out)
    if any(i.code in ("BAD_TYPE", "MISSING_FIELD") for i in out):
        return out
    tset = templates or T.load_templates()
    printed = T.render_spec(spec, tset, ix, out)
    from . import printed_claims as PC
    for q in spec.get("questions") or []:
        out.extend(Issue("BAD_TYPE", "question %s" % q.get("id"), why)
                   for why in PC.faults(q, ix.entities, ix.facts,
                                        printed.texts, spec.get("figures") or []))
    P.check_public(spec, ix, printed, out)
    out.extend(B.target_given_issues(spec, ix))
    out.extend(B.construct_drawn_issues(ix, tset))
    if not out:
        # VALID MEANS EXPORTABLE (verifier semantics r1, V2: a released
        # 'ratio' passed validate and then had no given-list phrase). The
        # export itself is the last check: whatever the public / private
        # builders refuse is a validation issue, with the builder's code.
        from .errors import SpecError
        try:
            P.public_model(spec, tset, check=False)
            P.private_model(spec, tset)
        except SpecError as e:
            out.extend(e.issues)
    return out


# ---------------------------------------------------------- schema.json ---
def schema_document():
    """The closed vocabularies, for other tools (written to schema.json)."""
    return {
        "spec_version": SPEC_VERSION,
        "roles": list(ROLES),
        "source_kinds": list(SOURCE_KINDS),
        "role_sources": dict((k, list(v)) for k, v in ROLE_SOURCES.items()),
        "context_kinds": dict((k, {"rel": r, "arg_kinds": list(a) if a else None})
                              for k, (r, a) in CONTEXT_KINDS.items()),
        "rules": RULES,
        "task_types": list(TASK_TYPES),
        "measure_tasks": list(MEASURE_TASKS),
        "target_given_allowed": list(TARGET_GIVEN_ALLOWED),
        "construct_relations": list(CONSTRUCT_RELS),
        "construct_roles": list(CONSTRUCT_ROLES),
        "figure_accuracy": list(FIGURE_ACCURACY),
        "entity_kinds": ENTITY_KINDS,
        "relations": dict((r, dict({"args": [list(k) if k else None
                                             for k in ks],
                                    "value": m, "dimension": d},
                                   **({"variadic": list(VARIADIC[r])}
                                      if r in VARIADIC else {})))
                          for r, (ks, m, d) in RELS.items()),
        "quantity_dimensions": QTY_DIM,
        "classify_values": CLASS_VALUES,
        "cline_ops": list(CLINE_OPS),
        "plot_roles": list(PLOT_ROLES),
        "family_relations": sorted(FAMILY_RELS),
        "number_forms": list(canon.NUMBER_FORMS),
        "frames": _frame_doc(),
        "symmetric_relations": sorted(canon.SYMMETRIC_RELS),
        "units": dict((u, {"dimension": d, "factor": str(f)})
                      for u, (d, f) in canon.UNITS.items()),
        "unit_aliases": canon.UNIT_ALIASES,
        "ids": {"sheet": SHEET_RE.pattern,
                "question": "q<n>, n increasing",
                "item": "<question id><latin letter of position>",
                "item_labels": list(ITEM_LABELS),
                "figure": "<item id> | <question id>_head",
                "names": dict((k, dict((f, r.pattern) for f, r in v.items()))
                              for k, v in ENTITY_NAME_RULES.items())},
        "prose_guarantee": "prose is public only with a human approval "
                           "bound to its exact text (approved_by + "
                           "approved_hash); no number in prose may be a "
                           "target/answer value unless a human approved "
                           "that text. The number-word scan is an advisory "
                           "backstop that fails loudly on obvious forms; "
                           "its escapes are documented limits.",
        "prose_number_words": sorted(PROSE_NUMBER_WORDS),
        "prose_one_fixed_phrases": ["כל אחד", "כל אחת", "אחד מה…",
                                    "אחד מן", "אחד מבין", "אחת מה…",
                                    "אחת מן", "אחת מבין"],
        "prose_one_phrase_rule": "the two words are neighbours in one "
                                 "clause: only spaces between them",
        "bound_prose": _bound_doc(),
        "prose_prefixes": PROSE_PREFIXES,
        "prose_max_prefixes": PROSE_MAX_PREFIXES,
        "fields": {"top": TOP_FIELDS, "question": QUESTION_FIELDS,
                   "item": ITEM_FIELDS, "fact": FACT_FIELDS,
                   "source": SOURCE_FIELDS, "figure": FIGURE_FIELDS,
                   "prose": PROSE_FIELDS, "release": RELEASE_FIELDS},
        "id_rules": {
            "point": "<name>", "segment": "seg:<ends sorted>",
            "line": "line:<through sorted>", "ray": "ray:<from><through>",
            "angle": "ang:<arm min><vertex><arm max>",
            "polygon": "poly:<canonical rotation/direction>",
            "jump": "jump:<from id>><to id>",
            "interval": "ivl:<[ or (><lo id>,<hi id><] or )>",
            "pie": "pie:<name>", "sector": "sector:<pie name>:<key>",
            "build_circle": "bcirc:<name>",
            "fact": "<item>:<rel>(<args; sorted if symmetric>)#<a|t|g>"},
        # (v6.16 integrate) the two v6.16 families on the spec path
        "families_v616": _families_v616_doc(),
    }


def _families_v616_doc():
    from .graph import kinds as GK
    from . import pie as PIE
    return {
        "graph": {"figure_field": "graph",
                  "on_frame": "coordinate_plane",
                  "grammar": GK.GRAPH_VERSION,
                  "public": GK.PUBLIC_VERSION,
                  "curve_kinds": list(GK.FNS),
                  "mark_kinds": list(GK.MARK_KINDS),
                  "find_relations": sorted(GK.FIND_RELS),
                  "reasons": sorted(GK.REASONS),
                  # (v6.16 integrate r2) the figure / curve keys incl. the
                  # optional round-2 givens-only keys (W-FIGURE-DENSITY)
                  "top_fields": dict(sorted(GK.TOP_FIELDS.items())),
                  "curve_fields": dict(sorted(GK.CURVE_FIELDS.items())),
                  "hide_fields": sorted(GK.HIDE_FIELDS),
                  "givens_names_only": GK.GIVENS_NAMES_ONLY,
                  "rule": "a find names the item that asks it; its answer "
                          "is private and checked against the mathematics; "
                          "a figure never shows what a find asks"},
        "pie_chart": {"frame_family": PIE.FAMILY,
                      "grammar": PIE.FAMILY_VERSION,
                      "entity_kinds": sorted(PIE.ENTITY_KINDS),
                      "relations": sorted(PIE_RELS),
                      "frame_keys": sorted(PIE.FRAME_KEYS),
                      "part_keys": {"pie": sorted(PIE.PIE_PART_KEYS),
                                    "build": sorted(PIE.BUILD_PART_KEYS)},
                      # (v6.16 integrate r2) the value sets (row / fraction /
                      # names none are the pie owner's round-2 additions)
                      "layouts": list(PIE.LAYOUTS),
                      "units": sorted(PIE.UNIT_OF),
                      "names_modes": list(PIE.NAMES_MODES),
                      "values_modes": list(PIE.VALUES_MODES),
                      "reasons": sorted(PIE.PIE_REASONS)}}


def _bound_doc():
    from . import schema_bound as SB
    return {"rule": "W-BOUND-PROSE: original wording printed as it is when "
                    "every number, number word, variable and name in it is "
                    "bound to a spec fact / entity (one binding per atom, "
                    "in order); G80 verifies the printed block against the "
                    "bindings. Tables are data (cells bound), a worked "
                    "example is bound prose.",
            "segment": {"bound": "block"},
            "block_fields": SB.BLOCK_FIELDS,
            "bind_refs": list(SB.BIND_REFS),
            "table_fields": SB.TABLE_FIELDS,
            "table_classes": list(SB.TABLE_CLASSES),
            "example_fields": SB.EXAMPLE_FIELDS,
            "public_value_roles": list(SB.PUBLIC_VALUE_ROLES),
            "private_value_roles": list(SB.PRIVATE_VALUE_ROLES),
            "name_kinds": dict((k, list(v))
                               for k, v in SB.NAME_KINDS.items()),
            "word_values": dict((w, str(v)) for w, v in
                                sorted(SB.WORD_VALUES.items()))}


def _frame_doc():
    from . import family as FAM
    return FAM.frame_document()


SCHEMA_JSON = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                           "schema.json")


def write_schema_json(path=SCHEMA_JSON):
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(json.dumps(schema_document(), ensure_ascii=False, indent=1,
                            sort_keys=True) + "\n")


if __name__ == "__main__":
    write_schema_json()
