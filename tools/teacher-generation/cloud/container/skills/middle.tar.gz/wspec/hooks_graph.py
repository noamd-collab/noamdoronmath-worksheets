# -*- coding: utf-8 -*-
"""wspec.hooks_graph -- the GRAPH family's hook module (v6.16, BRIEF_V616
G1-G3; owner: the graphs engine agent). Two audiences:

1. THE ACCEPTANCE RUNNER (v616/HOOKS.txt [RUNNER]; acceptance/tools/
   v616_engine.py imports this module by name). The attributes it reads:

     API_VERSION   "v616-graph/1"
     SPEC_SHAPE    "corpus-neutral/1": the runner may hand render / check /
                   validate / public_model the corpus's neutral figure
                   wrapped as {"family": "graph", "figures": {fid: neutral}};
                   the engine translates it with kinds.from_neutral, which
                   ADDS NOTHING (a label it cannot print exactly, a != 1,
                   an unknown key -> a named refusal, never a guess)
     render(public_spec, figure_id, display_settings=None, **settings)
                   -> {"svg", "object_map", "placements", "validation"}
                   public_spec: a graph public model (wspec-graph-public/1),
                   the neutral wrapper above, or (after install()) a sheet
                   public model whose figure carries "graph". A curve whose
                   numbers are asked is not public: its display layout comes
                   in display_settings ({"curves": [...], "marks": [...]},
                   kinds.display_layout; the pilot builder saves it beside
                   the figure). Refusal: wspec.render.gate.RenderRefused
                   (.code RENDER_*).
     validate(spec) -> [(code, detail)]      (author spec or the wrapper)
     public_model(spec) -> graph public model (author spec or the wrapper)
     check(svg, object_map, public_spec, figure_id, ocr=True,
           answer_guard=None) -> report {status, checks, findings,
                   measured, objects, object_map}. ocr=True runs the house
                   OCR helper on the MuPDF raster (the CALLER holds
                   v616/OCR_RUN.lock). answer_guard: {points, curves,
                   texts, bare, equations} (kinds.answer_guard) or the
                   corpus's must_not_draw blocks / answer_guard (converted).
     highlight(svg, object_map, object_id) -> svg (an EMPTY overlay for an
                   object the figure does not draw -- a find)
     check_highlight(base_svg, hl_svg, report, object_id)
                   -> {"status": PASS|FAIL, "findings": [...]}
     object_report(report, object_id) -> {"status", "findings"}
   plus helpers: from_neutral, answer_guard, private_check, display_layout,
   private_model, sheet_answers, install / uninstall; (round 2) the
   givens-only helpers givens_figure, empty_figure, auto_frame, preview,
   sheet_label_leaks, stated_marks_problems (wspec.graph.givens); (round 3)
   stated_labels_problems, unit_texts, FORM_STATES,
   GIVENS_NAMES_ONLY_AUTHORITY.
   normalize_guard also reads the AAF1 must_not_draw blocks ({x, y}
   points, a vertical line's "p").

2. THE SHEET-LEVEL SPEC PATH. (v6.16 integrate) merged permanently by the
   integrator (wspec/sheet_graph.py): a figure of a sheet spec may carry
   "graph" (the author graph block without version / figure / frame -- the
   figure's own id and frame are used); schema.validate checks it (+ each
   find's item is an item of the figure's question); project.public_model
   puts the public graph model into the public figure; project.scan_public
   scans it; wspec.render.render and wspec.check.check_figure send a graph
   figure here. install() / uninstall() are no-ops kept for callers.
"""
from .graph import kinds as K
from .graph import render as GR
from .graph import check as GC
from .graph import highlight as GH

API_VERSION = "v616-graph/1"
SPEC_SHAPE = "corpus-neutral/1"
ENGINE_VERSION = GR.ENGINE_VERSION
# (codes are names, not literals in a call: the house reason-table test reads
# every wspec/*.py for a call with a literal code)
_C_SHAPE, _C_FIND, _C_ID = "GRAPH_BAD_SHAPE", "GRAPH_FIND_BAD", "GRAPH_BAD_ID"
_C_PUBLIC = "PUBLIC_VALUE_NOT_WHITELISTED"


def _fig_token(fid):
    t = str(fid).lower().replace("-", "_").replace("/", "_")
    return "".join(c for c in t if c.isalnum() or c == "_")[:32] or "fig"


def _neutral_of(spec, figure_id=None):
    """the neutral figure of a {"family": "graph", "figures": {...}}
    wrapper, or None"""
    if isinstance(spec, dict) and spec.get("family") == "graph" and \
            isinstance(spec.get("figures"), dict):
        figs = spec["figures"]
        if figure_id is None:
            if len(figs) != 1:
                raise K.GraphSpecError([K.GraphIssue(
                    _C_SHAPE, "figures", "name the figure")])
            figure_id = sorted(figs)[0]
        if figure_id not in figs:
            raise K.GraphSpecError([K.GraphIssue(
                _C_ID, "figures", repr(figure_id))])
        return figs[figure_id], figure_id
    return None


def _author(spec, figure_id=None):
    """an author spec from an author spec or a neutral wrapper"""
    n = _neutral_of(spec, figure_id)
    if n is not None:
        return K.from_neutral(n[0], _fig_token(n[1]))
    return spec


def _graph_public(public_spec, figure_id):
    """-> (graph public model, layout settings or None)"""
    if isinstance(public_spec, dict) and "graph_public" in public_spec:
        return public_spec, None
    n = _neutral_of(public_spec, figure_id)
    if n is not None:
        a = K.from_neutral(n[0], _fig_token(n[1]))
        return K.public_model(a), K.display_layout(a)
    if isinstance(public_spec, dict) and isinstance(
            public_spec.get("figures"), list):
        for g in public_spec["figures"]:
            if isinstance(g, dict) and g.get("id") == figure_id and \
                    isinstance(g.get("graph"), dict):
                return g["graph"], None
    from .render.gate import RenderRefused
    raise RenderRefused("RENDER_NOT_PUBLIC", "no graph figure %r in the "
                        "given model" % (figure_id,))


# ---------------------------------------------------------------- runner --
def _sheet_issues(spec):
    """(v6.16 integrate) a SHEET model (the delivered wspec/public_spec.json
    or a sheet spec): every graph figure's block -- a public graph model is
    scanned (closed grammar, its hash, its figure / frame), an author block
    validated (kinds.validate); nothing else of the sheet is the graph's"""
    from . import sheet_graph as SGR
    from .graph import render as GR
    out = []
    for g in spec.get("figures") or []:
        if not isinstance(g, dict) or "graph" not in g:
            continue
        gp = g["graph"]
        w = "figure %s graph" % g.get("id")
        if isinstance(gp, dict) and "graph_public" in gp:
            for p in GR.scan_public(gp):
                out.append((_C_UNKNOWN if "key" in str(p) else _C_PUBLIC,
                            "%s: %s" % (w, p)))
            if K.public_hash(gp) != gp.get("public_hash"):
                out.append((_C_PUBLIC, "%s: public_hash" % w))
            if gp.get("figure") != g.get("id") or \
                    gp.get("frame") != g.get("frame"):
                out.append((_C_PUBLIC, "%s: figure / frame" % w))
        else:
            try:
                gi, _M = K.validate(SGR.author_of(g))
            except Exception as ex:          # noqa: BLE001
                out.append((_C_SHAPE, "%s: %s" % (w, ex)))
                continue
            out += [(i.code, "%s: %s: %s" % (w, i.where, i.detail))
                    for i in gi]
    return out


_C_UNKNOWN = "GRAPH_UNKNOWN_FIELD"


def validate(spec):
    if isinstance(spec, dict) and isinstance(spec.get("figures"), list):
        # a sheet model (the pilot's public spec), not one graph figure
        return _sheet_issues(spec)
    try:
        a = _author(spec)
    except K.GraphSpecError as ex:
        return [(i.code, "%s: %s" % (i.where, i.detail)) for i in ex.issues]
    except (KeyError, TypeError, ValueError, AttributeError) as ex:
        return [("GRAPH_BAD_SHAPE", "%s: %s" % (type(ex).__name__, ex))]
    issues, _M = K.validate(a)
    return [(i.code, "%s: %s" % (i.where, i.detail)) for i in issues]


def public_model(spec):
    return K.public_model(_author(spec))


def display_layout(spec):
    return K.display_layout(_author(spec))


def private_model(spec):
    return K.private_model(_author(spec))


def answer_guard(spec):
    return K.answer_guard(_author(spec))


from_neutral = K.from_neutral
# (v6.16 fix r1) the hash of a graph public model: the acceptance runner
# re-hashes a pilot's public model after it ENLARGES the window for an
# outside_window GMN1 variant (SCORING_graph s8.5)
public_hash = K.public_hash


def render(public_spec, figure_id, display_settings=None, **settings):
    gp, lay = _graph_public(public_spec, figure_id)
    st = dict(display_settings or {})
    st.update(settings)
    st["figure"] = gp["figure"]
    if lay is not None:
        for k in ("curves", "marks"):
            if lay.get(k) and k not in st:
                st[k] = lay[k]
    st.setdefault("font_family", "David Libre,serif")
    return GR.render(gp, st, GR.ENGINE_VERSION)


def _num_s(v):
    q = K.Q(str(v).replace(K.MINUS, "-")) if not isinstance(v, (int,)) \
        else K.Q(v)
    return K.cstr(q) if q is not None else None


def normalize_guard(g):
    """the checker's answer_guard from kinds.answer_guard, a corpus
    must_not_draw block (or a list of them), or a corpus answer_guard
    {items, figure_forbidden_texts}"""
    if not g:
        return None
    out = {"points": [], "curves": [], "texts": [], "bare": [],
           "equations": []}
    blocks = g if isinstance(g, list) else [g]
    for b in blocks:
        if not isinstance(b, dict):
            continue
        for k in out:
            for v in b.get(k) or []:
                out[k].append(v)
        for p in b.get("points_absent") or []:
            # frozen blocks: [x, y]; the AAF1 addition: {"x", "y", "why"}
            if isinstance(p, dict):
                p = [p.get("x"), p.get("y")]
            xy = [_num_s(p[0]), _num_s(p[1])]
            if None not in xy:
                out["points"].append(xy)
        for c in b.get("curves_absent") or []:
            kind = c.get("kind")
            if kind == "line" and "x" in c and "m" not in c:
                kind = "vline"
            try:
                if kind == "line":
                    out["curves"].append({"fn": "line", "m": _num_s(c["m"]),
                                          "b": _num_s(c["b"])})
                elif kind == "vline":
                    # frozen: "x"; the AAF1 addition: "p" (x = p)
                    out["curves"].append({"fn": "vline", "x": _num_s(
                        c["x"] if "x" in c else c["p"])})
                elif kind == "parabola":
                    out["curves"].append({"fn": "parabola",
                                          "p": _num_s(c["p"]),
                                          "k": _num_s(c["k"])})
            except KeyError:
                pass
        texts = list(b.get("label_texts_absent") or []) + \
            list(b.get("figure_forbidden_texts") or [])
        for it in b.get("items") or []:
            if isinstance(it, dict) and it.get("figure_forbidden") and \
                    isinstance(it.get("answer"), str):
                texts.append(it["answer"])
        for t in texts:
            if not isinstance(t, str):
                continue
            (out["bare"] if K.Q(t.replace(K.MINUS, "-")) is not None
             else out["texts"]).append(t)
    for k in out:
        seen, keep = set(), []
        for v in out[k]:
            key = repr(v)
            if key not in seen:
                seen.add(key)
                keep.append(v)
        out[k] = keep
    return out


def check(svg, object_map, public_spec, figure_id, ocr=True,
          answer_guard=None, **kw):
    gp, _lay = _graph_public(public_spec, figure_id)
    rep = GC.check_graph(svg, object_map, gp,
                         answer_guard=normalize_guard(answer_guard))
    if ocr:
        GC.ocr_texts(svg, rep, keep_dir=kw.get("keep_ocr_dir"))
    else:
        for c in ("OCR_AXIS_NUMBERS", "OCR_AXIS_NAMES", "OCR_CURVE_LABELS",
                  "OCR_MARK_LABELS"):
            rep["checks"].setdefault(c, "NA")
    _axis_line_mapped(rep, object_map)
    rep["object_map"] = object_map
    rep["api"] = API_VERSION
    rep["figure"] = gp["figure"]
    return rep


def _axis_line_mapped(rep, om):
    """AXIS_LINE_MAPPED: each axis object holds its line and its arrow"""
    st = "PASS"
    objs = (om or {}).get("objects") or {}
    els = (om or {}).get("elements") or {}
    items = dict((it["id"], it) for it in (om or {}).get("display_items")
                 or [])
    for a in ("axis:x", "axis:y"):
        roles = set()
        for p in (objs.get(a) or {}).get("parts") or []:
            it = items.get((els.get(p["element"]) or {}).get("item"))
            if it:
                roles.add(it["role"])
        if not {"axis_line", "axis_arrow"} <= roles:
            st = "FAIL"
            rep["findings"].append({"level": "FAIL",
                                    "code": "CHK_AXIS_LINE_MAPPED",
                                    "check": "AXIS_LINE_MAPPED", "object": a,
                                    "detail": "roles %s" % sorted(roles)})
            rep["status"] = "FAIL"
    rep["checks"]["AXIS_LINE_MAPPED"] = st


def private_check(report, spec):
    return GC.private_check(report, K.private_model(_author(spec)))


def highlight(svg, object_map, object_id):
    return GH.highlight(svg, object_map, object_id)


def check_highlight(base_svg, hl_svg, report, object_id):
    om = report.get("object_map") if isinstance(report, dict) and \
        "object_map" in report else report
    probs = GC.check_highlight(base_svg, hl_svg, om or {}, object_id)
    checks = dict((c, "PASS") for c in _HL_CHECKS.values())
    finds = []
    for p in probs:
        code = p.split(" ")[0]
        c = _HL_CHECKS.get(code, "HIGHLIGHT_EXACT_ELEMENTS")
        checks[c] = "FAIL"
        finds.append({"level": "FAIL", "code": code, "check": c,
                      "object": object_id, "detail": p})
    return {"status": "FAIL" if probs else "PASS", "checks": checks,
            "findings": finds}


_HL_CHECKS = {"HL_NO_OVERLAY": "HIGHLIGHT_EXACT_ELEMENTS",
              "HL_WRONG_OBJECT": "HIGHLIGHT_EXACT_ELEMENTS",
              "HL_MISSING": "HIGHLIGHT_EXACT_ELEMENTS",
              "HL_EXTRA": "HIGHLIGHT_EXACT_ELEMENTS",
              "HL_NOT_COINCIDING": "HIGHLIGHT_ON_MEASURED_GEOMETRY",
              "HL_BOX_OFF": "HIGHLIGHT_ON_MEASURED_GEOMETRY",
              "HL_ADDS_MATH": "HIGHLIGHT_ADDS_NO_MATH",
              "HL_FIGURE_CHANGED": "HIGHLIGHT_ADDS_NO_MATH"}


def object_report(report, object_id):
    fs = [f for f in report.get("findings") or []
          if f.get("object") in (object_id, None)]
    # an object's own findings and the figure-wide ones decide it
    st = "FAIL" if any(f["level"] == "FAIL" for f in fs) else \
        "REVIEW" if any(f["level"] == "REVIEW" for f in fs) else "PASS"
    return {"status": st, "findings": fs}


def sheet_answers(spec):
    """{item id: [{find, rel, args, value}]} -- the finds' exact answers
    (the private side; the sheet's key prints them in approved wording)"""
    a = _author(spec)
    M = K.checked(a)
    out = {}
    for f in M.finds:
        out.setdefault(f.rec["item"], []).append(
            {"find": f.id, "rel": f.rel, "args": list(f.rec["args"]),
             "value": f.truth})
    return out


# ------------------------------------------------ givens-only (round 2) --
# v6.16 round 2 (W-FIGURE-DENSITY, BRIEF_V616 ADDENDUM 1, corpus AAF1): the
# GIVENS-ONLY figures a figure-topic question gets where a full figure would
# show an answer -- kinds grammar "givens": true / "drawn": false / "hide"
# (kinds.py docstring), builder helpers in wspec.graph.givens. For the pilot
# builder and the integrator (v616/HOOKS.txt [GRAPH] UPDATE r2):
#   givens_figure / empty_figure / auto_frame / preview   (the helper)
#   sheet_label_leaks(figures)      SHEET-WIDE: a printed label of one graph
#                                   figure that another figure's guard forbids
#   stated_marks_problems(spec)     every optional mark is a pair its
#                                   question's text prints (bound to the
#                                   coordinate facts of one point)
from .graph import givens as GIVENS                                  # noqa

givens_figure = GIVENS.givens_figure
empty_figure = GIVENS.empty_figure
auto_frame = GIVENS.auto_frame
preview = GIVENS.preview
sheet_label_leaks = GIVENS.sheet_label_leaks
stated_marks_problems = GIVENS.stated_marks_problems
GIVENS_NAMES_ONLY = K.GIVENS_NAMES_ONLY
# (round 3, corpus graph v1.1; the author: V616-A2 NOT approved -> names only
# is FINAL) stated_labels_problems(spec): the equation label of a drawn
# STATED curve is the equation its stated_in unit prints (stated_marks_
# problems returns these too, so sheet_graph's wiring refuses them as
# GRAPH_GIVENS_NOT_GIVEN); unit_texts(spec, unit): the texts a unit prints;
# FORM_STATES: what a parabola label's form states (kinds form rule)
stated_labels_problems = GIVENS.stated_labels_problems
unit_texts = GIVENS.unit_texts
FORM_STATES = K.FORM_STATES
GIVENS_NAMES_ONLY_AUTHORITY = K.GIVENS_NAMES_ONLY_AUTHORITY


# ------------------------------------------------------------ integrator --
# (v6.16 integrate) The graph figure is MERGED into the sheet-level spec path
# permanently (wspec/sheet_graph.py, called from schema.validate,
# project.public_model / scan_public, render.engine.render and
# check.check_figure / object_report / check_highlight). The run-time
# registration this module used to do (monkeypatching those functions) is
# gone: install() / uninstall() are kept for callers and change nothing.
INTEGRATED = "integrated"


def install():
    """no-op: the graph family is merged into wspec (v6.16 integrate)"""
    return INTEGRATED


def uninstall():
    """no-op: the graph family is merged into wspec (v6.16 integrate)"""
    return INTEGRATED
