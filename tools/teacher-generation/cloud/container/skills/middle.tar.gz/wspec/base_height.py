# -*- coding: utf-8 -*-
"""Source-bound base/height data printed by a native obtuse-triangle figure.

This declaration licenses four specific given facts, never an arbitrary datum.
The normal renderer and independent geometry/label checks still prove the ink.
The foot retains its technical entity ID but has no learner-facing name.
"""
import re
from .errors import Issue

FIELDS = {"triangle", "base", "height", "perpendicular", "extension", "source"}

def _text(spec, scope):
    for q in spec.get("questions") or []:
        for r in [q] + list(q.get("items") or []):
            if r.get("id") != scope:
                continue
            t = r.get("text")
            if isinstance(t, str):
                return t
            return " ".join(s["bound"].get("text", "") for s in t or []
                            if isinstance(s, dict) and isinstance(s.get("bound"), dict))
    return ""

def _norm(t):
    return " ".join(str(t).replace("$", "").split())

def _record(spec, fig, ix):
    """Return the verified declaration, or (None, a precise error)."""
    d = fig.get("base_height")
    if d is None:
        return None, None
    if not isinstance(d, dict) or set(d) != FIELDS:
        return None, "base_height requires exactly triangle/base/height/perpendicular/extension/source"
    if any(not isinstance(d[k], str) for k in FIELDS - {"source"}):
        return None, "base_height IDs must be strings"
    src = d["source"]
    if not isinstance(src, dict) or set(src) != {"scope", "text"} or not all(isinstance(x, str) and x for x in src.values()):
        return None, "source requires scope and exact printed text"
    qid = ix.scope_question.get(fig.get("scope"))
    if (not qid or src["scope"] != qid or fig.get("scope") != qid or
        _norm(src["text"]) not in _norm(_text(spec, qid)) or
        not all(w in src["text"] for w in ("בשרטוט", "משולש", "הגובה", "הבסיס", "מחוץ"))):
        return None, "source must be this figure's own printed outside-height stem"
    if fig.get("figure_accuracy") != "accurate" or any(k in fig for k in ("frame", "graph", "data", "loci")):
        return None, "base_height requires an accurate native plane figure"
    fs = {k: ix.facts.get(d[k], {}) for k in ("base", "height", "perpendicular", "extension")}
    if any(f.get("role") != "given" or f.get("item") != qid or (f.get("source") or {}).get("kind") != "stated" for f in fs.values()):
        return None, "all four facts must be this question's stated givens"
    for k in ("base", "height"):
        f = fs[k]
        if f.get("rel") != "length" or len(f.get("args", [])) != 1 or "unit" in f:
            return None, "base/height must be unitless given lengths (the source prints no units)"
        try:
            from . import canon
            if canon.exact_float(f["value"]) <= 0:
                raise ValueError()
        except Exception:
            return None, "base/height require positive printed values"
    poly = ix.entities.get(d["triangle"], {})
    base = ix.entities.get(fs["base"]["args"][0], {})
    height = ix.entities.get(fs["height"]["args"][0], {})
    vv = set(poly.get("vertices", [])); bb = set(base.get("ends", [])); hh = set(height.get("ends", []))
    if poly.get("kind") != "polygon" or len(vv) != 3 or base.get("kind") != "segment" or height.get("kind") != "segment" or len(bb) != 2 or not bb < vv or len(hh) != 2 or len(hh & vv) != 1 or hh & vv != vv - bb:
        return None, "base must be a triangle side and height its opposite vertex to a separate foot"
    foot = next(iter(hh - vv))
    if fs["perpendicular"].get("rel") != "perpendicular" or set(fs["perpendicular"].get("args", [])) != {base["id"], height["id"]}:
        return None, "perpendicular fact must join this base and height"
    ext = fs["extension"]
    ee = ext.get("args", [])
    longer = ix.entities.get(ee[1], {}) if len(ee) == 2 else {}
    if ext.get("rel") != "on_segment" or len(ee) != 2 or ee[0] not in bb or longer.get("kind") != "segment" or set(longer.get("ends", [])) != (bb - {ee[0]}) | {foot}:
        return None, "extension must put the near base endpoint between the far endpoint and the foot"
    ext_seg = next((e["id"] for e in ix.entities.values() if e.get("kind") == "segment" and set(e.get("ends", [])) == {ee[0], foot}), None)
    shown = set(fig.get("entities", [])); draws = set(fig.get("draws", []))
    if not vv | {foot, base["id"], height["id"], ext_seg} <= shown or not {d[k] for k in ("base", "height", "perpendicular")} <= draws:
        return None, "figure must actually draw the base, height, extension, vertices and both value labels/right mark"
    if any(f.get("rel") == "name" and f.get("args") == [foot] and f.get("id") in draws for f in ix.facts.values()):
        return None, "the source leaves the height foot unlabelled"
    ids = {d["base"], d["height"]}
    q = ix.questions.get(qid, {})
    for row in [q] + list(q.get("items") or []):
        text = row.get("text")
        blocks = []
        if isinstance(text, list):
            for seg in text:
                if isinstance(seg, dict):
                    if ids.intersection(seg.get("facts", [])):
                        return None, "read-off datum must be printed by the figure alone, not a text template"
                    if isinstance(seg.get("bound"), dict):
                        blocks.append(seg["bound"])
        else:
            blocks = row.get("bound") or []
        for block in blocks:
            refs = set(block.get("prints", [])) | {v.get("fact") for v in block.get("bind", []) if isinstance(v, dict)}
            if ids.intersection(refs):
                return None, "read-off datum must be printed by the figure alone, not a bound text"
    return dict(d, foot=foot), None

def record(spec, fig, ix):
    try:
        return _record(spec, fig, ix)
    except (TypeError, ValueError, KeyError, StopIteration, IndexError):
        return None, "malformed base_height declaration or referenced geometry"


def records(spec, ix):
    return [(g, record(spec, g, ix)[0]) for g in spec.get("figures") or [] if g.get("base_height") is not None]

def validate(spec, ix, out):
    for g in spec.get("figures") or []:
        _, why = record(spec, g, ix)
        if why:
            out.append(Issue("BASE_HEIGHT_SOURCE", g.get("id"), why))

def printed_by_figure(spec, ix, rendered, out):
    validate(spec, ix, out)
    for g, d in records(spec, ix):
        if d:
            for k in ("base", "height", "perpendicular", "extension"):
                rendered.printed.setdefault(d[k], g["scope"])

def role_of(f, ix):
    for g, d in records(ix.spec, ix):
        if not d:
            continue
        for k in ("base", "height", "perpendicular", "extension"):
            if f.get("id") == d[k]:
                return k, d
        if f.get("role") == "target" and f.get("rel") == "area" and f.get("args") == [d["triangle"]] and ix.scope_question.get(f.get("item")) == g["scope"]:
            return "area", d
        if f.get("role") == "target" and (ix.items.get(f.get("item")) or {}).get("task_type") == "read_off":
            for k in ("base", "height"):
                given = ix.facts[d[k]]
                if f.get("rel") == "length" and f.get("args") == given.get("args") and ix.scope_question.get(f.get("item")) == g["scope"]:
                    text = _text(ix.spec, f["item"])
                    if "אורך הבסיס" in text and "אורך הגובה" in text:
                        return k, d
    return None, None

def read_off_pair(f, g, ix):
    k, d = role_of(f, ix)
    return bool(f.get("role") == "target" and k in ("base", "height") and d[k] == g.get("id"))

def description(f, ix):
    k, d = role_of(f, ix)
    if not k:
        return None
    if f.get("role") == "target":
        return _text(ix.spec, f["item"])
    if k in ("base", "height"):
        from . import canon
        return "אורך %s: %s." % ("הבסיס" if k == "base" else "הגובה", canon.canon_number(f["value"]))
    return {"perpendicular": "הגובה מאונך לבסיס.", "extension": "עקב הגובה נמצא על המשך הבסיס מחוץ למשולש."}[k]

def unnamed(ix, fid):
    g = ix.figures.get(fid, {})
    d, _ = record(ix.spec, g, ix)
    return {d["foot"]} if d else set()
