# -*- coding: utf-8 -*-
u"""v6.16 gaps (corpus-v2 OPEN_ENGINE_GAP G1 / G2 / G5): authoring helpers for
the three coordinate-plane objects the spec path could not state before.
Pure convenience on top of wspec.author -- validate() re-derives every id.

G2  THE ORIGIN ("ראשית הצירים")
    origin()                      -> the entity {"kind": "origin", "name": "O",
                                     "id": "origin:O"}
    A figure LISTS it (figure["entities"] += ["origin:O"]) when a question or
    item is about the axes' meeting point (b q1ב, b q8ד, c q1ב). The plane
    draws nothing new for it: its object is the two axis lines (they cross
    there) + the origin's printed '0' when the frame prints one. Its
    coordinates may be targets: coordinate(origin:O, axis:x) = 0 (the frame
    showing the origin is no leak: nothing is read off the grid). Its name is
    never drawn (a drawn name fact -> RENDER_FACT_NOT_MARKED); the text calls
    it by its term, and a printed fact about it needs no bound name
    (schema_bound.UNNAMED_OK).

G5  A POLYGON DECLARED BY COORDINATES ONLY ("קודקודיו לפי סדרם, (0,0), ...")
    ents = unnamed_polygon("L6", 6)   -> [vtx:L6:1 .. vtx:L6:6, poly:L6]
    facts = vertex_places("q14", "L6", [(0, 0), (6, 0), ...])
                                  -> the given (stated) coordinate facts, in
                                     vertex order, x then y -- bind the
                                     printed pairs to them in that order
                                     (BOUND_COORD_ROLE holds: both numbers of
                                     a pair are coordinates of one vertex)
    No letter is invented: the vertices are "vtx:<tag>:<n>", the polygon
    "poly:<tag>" (the corpus's poly:L6). "סרטטו את המצולע" is
    plot(poly:<tag>, plane:xy) with role to_plot (task_type "plot"); its area
    / perimeter are ordinary targets. No figure may show it (FAMILY_ENTITY:
    a vertex is no coordinate-plane kind); the checker fails a dot at a
    vertex's place (PT_NOT_DRAWN_ANY_FORM) and a stroke along a side
    (SEG_NOT_DRAWN). Printed names in the keys / Noam AI lines: the vertex
    list "(0, 0), (6, 0), ..." (templates.entity_name), public places only.

G1  A PARTIAL POLYGON ("שלושה מקודקודיו מסומנים בשרטוט")
    Nothing to author beyond the usual: the polygon entity (poly:ABCD) named
    by a fact of the question (rectangle given, area target, ...), the figure
    listing the SHOWN vertices (and drawn sides as segments), NOT the polygon.
    The renderer and the checker both derive the partial polygon object: its
    drawn sides between consecutive shown vertices + the dots of its shown
    vertices; the missing vertices and their sides are never drawn."""
from . import author as W


def origin(name="O"):
    return W.ent("origin", name=name)


def unnamed_polygon(tag, n):
    """[vertex 1 .. vertex n, the tagged polygon]"""
    vs = [W.ent("vertex", of=tag, n=k + 1) for k in range(n)]
    return vs + [W.ent("polygon", vertices=[v["id"] for v in vs], tag=tag)]


def vertex_places(item, tag, coords):
    """the GIVEN (stated) coordinate facts placing vertex k of polygon <tag>
    at coords[k], x then y per vertex -- the sheet prints them."""
    out = []
    for k, (x, y) in enumerate(coords):
        vid = "vtx:%s:%d" % (tag, k + 1)
        for ax, v in (("axis:x", x), ("axis:y", y)):
            out.append(W.fact(item, "coordinate", [vid, ax], "given",
                              W.stated(), value=v))
    return out


def unnamed_places(tag, n):
    """(v6.16 gaps r2) the n UNNAMED places of a list the text prints
    ("לפניכם רשימת נקודות, (5,0), (0,3), ...", G7-T08 b q8): vertex entities
    vtx:<tag>:1..n and NO polygon (the text declares no figure made of
    them). Place them with vertex_places(item, tag, coords); they are never
    shown (a dot at a place -> PT_NOT_DRAWN_ANY_FORM, object vtx:<tag>:<k>;
    check.coord.unnamed_place_at maps a place back to its id)."""
    return [W.ent("vertex", of=tag, n=k + 1) for k in range(n)]
