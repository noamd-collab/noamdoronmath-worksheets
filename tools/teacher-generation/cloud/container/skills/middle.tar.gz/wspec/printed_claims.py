"""Source-backed descriptions retained by a partial spec migration.

These are declared excerpts, not new mathematical facts. No value or answer
field is accepted. Both private validation and the public scan establish the
same source/scope/target constraints, without consulting an answer key.
"""
import re
from . import schema_bound as SB


def norm(text):
    return " ".join(text.replace("$", "").split()).strip() if isinstance(text, str) else ""


def excerpts(claim, role):
    value = claim.get("what" if role == "to_prove" else "text")
    return [norm(x) for x in (value if isinstance(value, list) else [value])]


def line(claim, role):
    text = "; ".join(excerpts(claim, role))
    return "הערך " + text if role == "to_prove" else text


def identity(c):
    return c.get("point") or c.get("polygon_entity") or ":".join(c.get("points") or []) or "data_points"


def selects(c, eid, entity):
    if entity.get("kind") == "point":
        return c.get("point") == (entity.get("name") or eid)
    if entity.get("kind") == "polygon":
        return (c.get("points") == entity.get("vertices") if "points" in c else
                bool(entity.get("tag")) and c.get("polygon_entity") == eid)
    return False


def names(text):
    tokens = {tok for kind, tok in SB.atoms(text) if kind == "name"}
    # Conventional segment/polygon words PQ/ABCD name their vertices too.
    return tokens | {p for t in tokens for p in re.findall(r"[A-Z][′″']*[0-9]?", t)}


def construction_claim(c):
    out = {"type": "polygon" if "points" in c or "polygon_entity" in c else "point",
           "text": line(c, "to_construct")}
    for k in ("point", "points"):
        if k in c:
            out[k] = c[k]
    return out


def query_claim(c):
    out = {"type": "find", "quantity": c.get("quantity", "value"),
           "what": "; ".join(excerpts(c, "to_prove")),
           "text": line(c, "to_prove")}
    for k in ("of", "unit"):
        if k in c:
            out[k] = c[k]
    return out


def axis_start_text(c, figures, scope):
    ref = c.get("axis_start")
    if not isinstance(ref, dict) or set(ref) != {"figure", "axis"} or ref.get("axis") != "axis:y":
        return None
    fig = next((g for g in figures if g.get("id") == ref.get("figure") and g.get("scope") == scope), {})
    axes = (fig.get("frame") or {}).get("axes") or []
    ax = next((a for a in axes if a.get("axis") == ref["axis"]), {})
    if ax.get("break_before") is not True:
        return None
    if "min" in ax:
        value = SB.value_of(ax["min"])
    else:
        first = next((v for i, v in ax.get("labels") or [] if i == 1), None)
        value = SB.value_of(first) if first is not None else None
    if value is None:
        return None
    return "ציר y מתחיל ב-%s" % str(value)


def query_unit_allowed(unit, text, stem, figures, scopes):
    if not isinstance(unit, str) or not unit:
        return False
    if unit in norm(text) + " " + norm(stem):
        return True
    # A geometric distance on an abstract coordinate grid is in coordinate
    # units. This supplies no answer value and no real-world unit conversion.
    return unit == "יחידות" and any(w in norm(text) for w in ("מרחק", "אורך", "היקף")) and any(
        g.get("scope") in scopes and (g.get("frame") or {}).get("family") == "coordinate_plane"
        and not (g.get("frame") or {}).get("sketch") for g in figures)


def rows(q, scope, role):
    return (((q.get("printed_claims") or {}).get("scopes") or {}).get(scope) or {}).get(role) or []


def faults(q, entities, facts, texts, figures):
    """Validate one question's declarations using source or public targets."""
    decl = q.get("printed_claims")
    if decl is None:
        return []
    out = []
    def bad(why):
        out.append("%s printed_claims: %s" % (q.get("id"), why))
    if (not isinstance(decl, dict) or set(decl) != {"scopes", "unsupported"}
            or not isinstance(decl.get("unsupported"), bool)
            or not isinstance(decl.get("scopes"), dict) or not decl["scopes"]):
        bad("expected scopes and boolean unsupported; no values or answers")
        return out
    scopes = {r.get("id"): r for r in [q] + list(q.get("items") or [])}
    shown = {e for g in figures if g.get("scope") in scopes for e in g.get("entities") or []}
    for scope, groups in decl["scopes"].items():
        if scope not in scopes or not isinstance(groups, dict) or not groups:
            bad("unknown/empty scope %r" % scope)
            continue
        target = [t if isinstance(t, dict) else facts.get(t, {})
                  for t in scopes[scope].get("targets") or []]
        points = {((entities.get((t.get("args") or [None])[0]) or {}).get("name")
                   or (t.get("args") or [None])[0])
                  for t in target
                  if (entities.get((t.get("args") or [None])[0]) or {}).get("kind") == "point"
                  and (t.get("rel") == "construct" and t.get("role") == "to_construct"
                       or t.get("rel") == "plot" and t.get("role") == "to_plot"
                       or t.get("rel") == "coordinate" and (t.get("args") or [None])[0] not in shown)}
        for role, claims in groups.items():
            if role not in ("given", "to_construct", "to_prove") or not isinstance(claims, list) or not claims:
                bad("invalid role/list %r" % role)
                continue
            seen = set()
            for c in claims:
                allowed = {"text", "axis_start"} if role == "given" else {"what", "unit", "quantity", "of", "key_text", "key_number", "key_pair", "supplemental"} if role == "to_prove" else {"point", "points", "polygon_entity", "data_points", "text", "printed_in"}
                if not isinstance(c, dict) or set(c) - allowed:
                    bad("undeclared fields in %s" % role)
                    continue
                source = c.get("printed_in", scope)
                if not isinstance(source, str) or source not in ({scope} if role != "to_construct" else {scope, q.get("id")}):
                    bad("cross-scope source for %s" % scope)
                    continue
                parts = excerpts(c, role)
                if role == "given" and "axis_start" in c:
                    if parts != [axis_start_text(c, figures, scope)] or parts == [None]:
                        bad("axis start description differs from its own measured broken frame")
                        continue
                elif not parts or any(not p or p not in norm(texts.get(source)) for p in parts):
                    bad("description absent from printed source %s" % source)
                    continue
                text = line(c, role)
                if role == "to_construct":
                    point = c.get("point")
                    named = names(text)
                    if sum(k in c for k in ("point", "points", "polygon_entity", "data_points")) != 1:
                        bad("construction requires exactly one target selector")
                        continue
                    if "data_points" in c:
                        source_scope = scope if scopes[scope].get("figure") else q.get("id")
                        observations = [p for g in figures if g.get("scope") == source_scope
                                        for p in (g.get("data") or {}).get("points") or []]
                        if c["data_points"] is not True or not any(p.get("role") == "to_plot" and p.get("drawn") is False for p in observations):
                            bad("unnamed construction requires this scope's undrawn plot observations")
                    elif "polygon_entity" in c:
                        eid = c["polygon_entity"]
                        if (not isinstance(eid, str) or not selects(c, eid, entities.get(eid, {}))
                                or not any(t.get("rel") == "construct" and t.get("role") == "to_construct"
                                           and t.get("args") == [eid] for t in target)):
                            bad("unnamed polygon description is not of this scope's declared construction")
                            continue
                    elif "points" in c:
                        vs = c["points"]
                        polygons = [entities.get((t.get("args") or [None])[0], {}) for t in target
                                    if t.get("rel") in ("construct", "plot") and t.get("role") in ("to_construct", "to_plot")]
                        if (not isinstance(vs, list) or not vs or not all(isinstance(v, str) for v in vs)
                                or not any(e.get("kind") == "polygon" and e.get("vertices") == vs for e in polygons)
                                or not (set(vs) <= named or "".join(vs) in named)):
                            bad("polygon description is not of this scope's declared construction")
                            continue
                    elif not isinstance(point, str):
                        bad("construction point must be a string")
                        continue
                    elif point not in points or point not in named:
                        bad("description is not of this scope's point construction %r" % point)
                    ident = identity(c)
                elif role == "to_prove":
                    if scope == q.get("id") or (any(t.get("role") != "to_construct" for t in target) and c.get("supplemental") is not True) or not decl["unsupported"]:
                        bad("preserved query requires a targetless unsupported item")
                    if "supplemental" in c and c["supplemental"] is not True:
                        bad("supplemental query flag must be literal true")
                    if c.get("quantity", "value") not in ("value", "graph_value", "count", "coordinates", "variable"):
                        bad("unsupported preserved query quantity")
                        continue
                    if "key_text" in c and c["key_text"] is not True:
                        bad("key_text is an explicit private-key preservation flag")
                    if "key_number" in c and (type(c["key_number"]) is not int or c["key_number"] < 0 or "key_text" in c):
                        bad("key_number must select one numeric atom of the private original key")
                    if "key_pair" in c and (type(c["key_pair"]) is not int or c["key_pair"] < 0 or c.get("quantity") != "coordinates" or "key_text" in c or "key_number" in c):
                        bad("key_pair must select a coordinate pair of the private original key")
                    native_names = {entities.get(a, {}).get("name") or a for t in target for a in t.get("args") or []
                                    if entities.get(a, {}).get("kind") == "point"}
                    printed_variables = {e.get("name") for e in entities.values() if e.get("kind") == "variable"
                                         and any(tok == e.get("name") for kind, tok in SB.atoms(text))}
                    if c.get("quantity") == "variable" and c.get("of") not in printed_variables:
                        bad("variable query requires its own printed variable entity")
                        continue
                    permitted_names = printed_variables if c.get("quantity") == "variable" else names(text) | native_names
                    if "of" in c and (not isinstance(c["of"], str) or c["of"] not in permitted_names):
                        bad("query object is absent from its printed question")
                        continue
                    unit = c.get("unit")
                    if unit is not None and not query_unit_allowed(unit, texts.get(source), texts.get(q.get("id")), figures, scopes):
                        bad("query unit absent from source")
                    ident = (c.get("quantity", "value"), tuple(excerpts(c, role)), c.get("of"))
                else:
                    ident = text
                if ident in seen:
                    bad("duplicate %s declaration" % role)
                seen.add(ident)
    return out


def construction_lines(q, scope):
    return {identity(c): line(c, "to_construct") for c in rows(q, scope, "to_construct")}
