"""Source declarations of named geometric lines; no layout or private values."""
from .schema import Issue


def schema_issues(spec, ix):
    out = []
    for q in spec.get("questions") or []:
        scopes = {q.get("id")} | {i.get("id") for i in q.get("items") or []}
        used = set()
        # Both author segments and projected public bound blocks can name
        # an entity without making it an argument of a mathematical fact.
        from .schema_bound import bound_entities
        for scope in [q] + list(q.get("items") or []):
            blocks = [segment.get("bound") for segment in scope.get("text") or []
                      if isinstance(segment, dict) and isinstance(segment.get("bound"), dict)]
            blocks += [block for block in scope.get("bound") or [] if isinstance(block, dict)]
            for block in blocks:
                used.update(e for e in bound_entities(block) if isinstance(e, str))
        for f in ix.facts.values():
            if f.get("item") in scopes:
                used.update(f.get("args") or [])
        for g in spec.get("figures") or []:
            if g.get("scope") in scopes:
                used.update(g.get("entities") or [])
        byname = {}
        for eid in used:
            e = ix.entities.get(eid) or {}
            if e.get("kind") in ("line", "variable", "axis") and isinstance(e.get("name"), str) and e["name"]:
                byname.setdefault(e["name"], []).append(eid)
        for name, eids in byname.items():
            if len(eids) > 1 and any(ix.kind(e) == "line" for e in eids):
                out.append(Issue("BAD_TYPE", "question " + q["id"],
                                 "line name %r is ambiguous between %s" % (name, sorted(eids))))
    for g in spec.get("figures") or []:
        if g.get("frame") and any(ix.kind(e) == "line" and ix.entities[e].get("name")
                                  for e in g.get("entities") or []):
            out.append(Issue("BAD_TYPE", "figure " + g["id"],
                             "named lines currently require the plane-geometry renderer"))
    for f in ix.facts.values():
        args = f.get("args") or []
        if f.get("rel") == "name" and args and ix.kind(args[0]) == "line" and not ix.entities[args[0]].get("name"):
            out.append(Issue("BAD_TYPE", "fact " + f["id"], "line name fact needs an explicit line.name"))
    return out
