# -*- coding: utf-8 -*-
u"""Print the public final answers in place of a package's private key (Noam, 2 November 2026).

content.py calls apply() on each built level. FINAL[level][(question, item label)]
holds the answer text in the engine's $...$ notation. A level with an item that has
no final answer, or a final answer for an item that does not exist, does not build.
The answers note names the level, so every answer page says whose answers it holds.
"""

NOTE = u"התשובות הסופיות. בשאלות שבהן נדרש נימוק, הסבר או הוכחה — הכתיבה המלאה היא חלק מן הפתרון שלכם."
NAMES = {"a": u"רמה א׳", "b": u"רמה ב׳", "c": u"מצוינות"}


def apply(L, final, note=None, single=False):
    """note: the package's own student-facing note, when it says more than NOTE.
    single: a one-level sheet; its note does not name a level."""
    import wspec_build as WB
    L = WB.expand_level(L)      # spec (pie) questions get their answer rows here
    key = L["key"]
    table = final[key]
    seen, answers = set(), []
    for a in L["answers"]:
        n, rows = a[0], a[1]
        out = []
        for lab, _ in rows:
            assert (n, lab) in table, ("item without a final answer", key, n, lab)
            seen.add((n, lab))
            out.append((lab, table[(n, lab)]))
        answers.append((n, out) + tuple(a[2:]))
    extra = sorted(set(table) - seen)
    assert not extra, ("final answer for an item that does not exist", key, extra)
    L = dict(L)
    L["answers"] = answers
    L["ansnote"] = (note or NOTE) if single else NAMES[key] + u" · " + (note or NOTE)
    return L
