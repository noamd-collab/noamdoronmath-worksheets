---
name: hebrew-math-worksheet-v5
description: "v6.18-noam (deliver.SKILL_VERSION). Hebrew RTL middle-school math worksheet engine and strict Noam AI export. Integrates Codex coordinate fixes into v6.17, preserving its checked rules, exact numbers, units and the approved v6.16.2 item-figure amendment. Author-approved V617-W1-5/Q6/Q7 wording and package-specific readiness repairs. Read V618-REPORT-HE.md for final measured validation and remaining author decisions. Worksheet production belongs to Claude; this package prepares and validates the skill."
---

# hebrew-math-worksheet — v6.18-noam

**v6.18-noam — כיסוי סופי: 77 H, ‏77 I, עוגות J ובדיקת נעילה K.** צירים strict v2: 277/286 PASS; REVIEW 4, UNSUPPORTED 5, FAIL 0.

קראו [דוח מדוד](V618-REPORT-HE.md) ו־[הוראות שילוב](V618-INTEGRATION-NOTES.md), כולל היסטוריית הכשלים והחריגה המאושרת לנעילה נוספת. תוצאות היסטוריות להלן אינן ציוני המשפחות המאומתים במסירה זו. בניות הרגרסיה מקורן H; K אינו מוסיף נעיצה. בקידומת 155 פקודות: 142 בקוד 0, ‏12 REVIEW בקוד 2, ופקודת העוגות J בקוד 1 משום שהיעד הכולל לא הושג; בדיקת הנעילה K בלבד חדשה ומסתיימת בקוד 0. יעד העוגות הכולל לא הושג; 532 זהים אינם 532 PASS.

הבניות הן רגרסיות ודוגמאות; all_18_production_ready=false. מקור G7-T08 חיצוני נדרש. קלוד ממשיך לפי האישורים הקיימים, כולל W-AUTO-RESUME-AFTER-RESET ושער הפיילוט האנושי W-V7-SKELETON-SHARE; אין לבקש שוב את האישורים הקיימים.

## היסטוריית הגרסאות הקודמות


# hebrew-math-worksheet — v6.17-noam

> **Codex coordinate improvement candidate, 2026-09-29.** Based on v6.16.1; not an installed release. See the accompanying review report for measured candidate results. Adds G7-T08 b14/c6 spec migrations, figureless a8 coordinate relations, source-checked public claim descriptions, unit preservation, Unicode prime lookup, executable wrong-object highlight controls for undrawn targets, a measured empty-canvas absence check, and exact-input coordinate checker memoization. Frozen corpora and expectations remain unchanged. Undrawn region support and paired-coordinate Noam typed-field parity remain incomplete. The historical release results below describe the base package, not this candidate.

**חובה — חבילת נועם AI:** לפני בניית חבילה קרא את `references/noam-ai-deliverable-he.md`
(סעיף "חובה לאתר נועם דורון: חבילת נועם AI" למטה).

**v6.17-noam (29.9) — מצב במסירה (בכנות):** `deliver.SKILL_VERSION = "6.17-noam"`. זה שלב 2 של מפת הדרכים המתוקנת (נועם: ״כן וודאי״): אוצר המילים הקטן ש־18 החבילות עוד צריכות, לפי plan18/PLAN18.json (BRIEF_V617). בגרסה הזו לא נבנה אף דף חדש, ואף ניסוח, מספר או תשובה של דף שנמסר לא השתנו. הניסוח החדש מחכה לנועם (wspec/PENDING_V617.txt, חמישה פריטים ושתי שאלות).

**מה נוסף ב־v6.17:** (1) V1, בשביל G7-T14: היחס ״משולש קהה־זוויות״ (נתון, מסקנה, להוכיח ותשובה של סיווג לפי הזוויות; הוא נמדד על השרטוט), והכלל ״סכום הזוויות במרובע 360°״. (2) V2, בשביל G9-T15: זוויות מתחלפות, מתאימות וחד־צדדיות בין ישרים מקבילים, המשפט ההפוך במשולש שווה־שוקיים, וחוצה זווית. כל כלל נבדק: אם הוא חל, מה הערך המדויק, ובכללי המקבילים גם כיוון הזרועות. תשובה של זווית במשולש או במרובע, וסוג המשולש לפי זוויותיו, מחושבים מחדש מהנתונים (wspec/rules617.py). (3) V3, בשביל G8-T49 ו־G9-T31: צורה אחת מדויקת לשורש (2√22, 3 − √2). תשובה בגיאומטריה מחושבת מחדש במדויק מהנתונים (פיתגורס, שטח, היקף, המרת יחידות). תשובה באלגברה (x = …) מחושבת מחדש כשורש של המשוואה שהשאלה מדפיסה, בסעיף עצמו או בגוף השאלה: משוואה אחת ממעלה 1 או 2 במשתנה אחד (נוסף בתיקון שאחרי הבדיקה הבלתי־תלויה). בשני המקרים תשובה שעוגלה לעשרוני נכשלת, וכך גם תשובה שגויה. תשובה שהנתונים או משוואה מודפסת לא קובעים אינה מחושבת מחדש. בשאלה מהמציאות המפתח מדפיס גם עיגול לעשירית, למשל 2√22 ≈ 9.4 (החלטה D6; wspec/numform.py). (4) V4, בשביל G7-T19: כשהגובה נופל מחוץ למשולש קהה־זוויות, המשך הבסיס משורטט מקווקו וסימן הזווית הישרה עומד בעקב הגובה. המשרטט וגם הבודק הבלתי־תלוי נכשלים על המשך רציף או חסר, על בסיס מקווקו ועל גובה שצויר בתוך משולש קהה־זוויות. (5) V5, בשביל G8-T15: היחידות דקות, שעות, ליטר וק״מ, עם המרות. מילת יחידה אחרי מספר שאינה מתאימה לנתון נכשלת. היחידה של תשובה חייבת להיות היחידה שהסעיף שואל במילים שלו (״כמה דקות״, ״בס״מ״, ״לקילומטרים״), אחרת היא נכשלת (נוסף בתיקון). לכל כלל יש מקרה שעובר ומקרה שנשתל בו פגם ונכשל, על שאלות אמיתיות מקובצי המקור (selfcheck_v617_rules.py, selfcheck_v617_forms.py).

**מה לא נבנה (בכנות):** (1) ישר ששמו אות (״נתון a ∥ b״): 19 מתוך 74 שאלות המקור של G9-T15 משתמשות בזה, והסקיל עוד לא יודע להדפיס שם של ישר. השאלות האלה מחכות לשלב הבא או לשאלה חלופית (D5). (2) צורת שורש לא מפושטת לכיתה ח׳ (√88 במקום 2√22) מחכה לתשובה של נועם. (3) הנקודה הסימטרית והנקודה המוזזת של G7-T10 שייכות למשפחת מערכת הצירים, ש־Codex אחראי עליה. (4) צעד פרטי של כלל מקבילים נבדק מול השרטוט רק בבדיקה העצמית; בבנייה נבדקים מול השרטוט רק הצעדים שמשתחררים לנועם AI (HOOKS H-A4, לשלב הייצור של G9-T15). (5) G7-T19 שאלה 7 עוד לא נבנית מהנוסח המקורי לבדו: הבסיס והגובה מודפסים רק בשרטוט המקור, והשורות שהסקיל מוסיף בשבילם מציינות את עקב הגובה H, שהשרטוט לא מסמן, ומוסיפות ס״מ (HOOKS H-B2). גם סעיף ג של G8-T49 א שאלה 19 (הסולם שזז) נבנה רק בנוסח ערוך (H-B3). הרשימה המלאה לנועם נמצאת ב־PENDING_V617. (6) השורה המאושרת ״חשבו את {…}.״ משמיטה את המילה שטח או היקף. מאז התיקון בונה הדף דוחה אותה בשאלת שטח או היקף, והשאלה מחכה לנועם (PENDING_V617, פריט 7). (7) תשובה באלגברה נבדקת רק מול משוואה מודפסת, והיחידה הנשאלת נקראת רק מהמילים של הסעיף (״כמה …״, ״ב…״, ״ל…״; HOOKS H-F2, H-F3).

**התוצאות של v6.17:** הסוויטה המלאה, 72 קבצים בזה אחר זה ולבד, תחת נעילת ה־OCR: כולם עברו. 68 מתוך 70 הקבצים של v6.16.2 נתנו בדיוק את אותן שורות סיום. שניים השתנו כמצופה: selfcheck_v612_lock עבר 121/121 (היו 118; בטביעת האצבע של הקוד יש שלושה קבצים חדשים, ולכל אחד בדיקה ששותל בו בית אחד ונדחית), ו־selfcheck_v616_fix1c עבר 61/61 (היו 58; הבדיקה A5 מוכיחה עכשיו שהסט שנועם אישר, 44cd8fc6, עומד בלי שינוי בתוך הסט של v6.17, ויש לה שני מקרי כשל). הבדיקות החדשות: selfcheck_v617_rules עבר 155/155 ו־selfcheck_v617_forms עבר 100/100. G9-T18 לבד, תחת הנעילה: 532 סטטוסים זהים לבסיס, שהם 518 PASS, 12 REVIEW, 0 FAIL ו־2 UNSUPPORTED. אלה לא 532 PASS. הפיילוטים G9-T06, G8-T15, G8-T30 ו־G7-T08 נבנו מחדש בלי OCR: כל 387 הקבצים הציבוריים (PDF, noam-ai.json, sheet.html, didactic.json, public_spec.json וכל השרטוטים) זהים בית־לבית לבנייה של v6.16.2. ב־sheet.json השתנו רק built_at ומחרוזת הגרסה. לכן הסטטוסים של הגרפים, של העוגה ושל מערכת הצירים לא השתנו. נעילת הקבלה חודשה פעם אחת, במכוון: fingerprint 73ba84233f8939e6 (99 קבצים). 173 הקבצים הנעולים של acceptance לא השתנו; רק LOCK.txt חודש. גרפים: בפיילוט 314/320 (v6.16). עוגה: היעד הכולל לא הושג. מערכת צירים (של Codex): v2 161/286, והיעד 272 לא הושג.

**תיקון v6.17 (29.9, אחרי הבדיקה הבלתי־תלויה, שני must וארבעה should):** (M1) ב־G9-T31 תשובה שהיא שורש שעוגל (4.41) או שורש שגוי (3 ± √3) של המשוואה המודפסת נכשלת עכשיו. (M2) תשובה ביחידה שהסעיף לא שאל נכשלת: ״כמה דקות״ שנענה בשעות, או ״לקילומטרים״ שנענה 1500 מ׳. (S2) בונה הדף דוחה שאלת שטח או היקף שהשורה שלה משמיטה את המילה שטח או היקף. (S1, S3) שאלות הבדיקה מדפיסות עכשיו את הנוסח המקורי בכל מקום שהסקיל יכול, ומה שעדיין נערך רשום לנועם ב־PENDING_V617. (S4) פריט 6 ברשימה תוקן: רק אפשרות (א) לא דורשת קוד חדש. כל קבוצת בדיקות רצה פעם אחת: selfcheck_v617_forms עבר 123/123, selfcheck_v617_rules עבר 155/155, selfcheck_v616_fix1c עבר 61/61, selfcheck_v610_lang עבר 143, test_stage1 עבר 386, selfcheck_v613_prose עבר 75/75, selfcheck_v612_lock עבר 121/121, ותחת נעילת ה־OCR גם selfcheck_v69 (78), v69_fix1 (46), v69_fix2 (34), v69_codex (52) ו־v610_gaps (136). נבדקו המפרטים שהסקיל מכיל כקבצים ושהקבלה בונה: 25 קובצי JSON, 3 המרות הפיילוט, 60 התרחישים הסינתטיים ו־18 הרמות שנמסרו. אין אף הבדל בבעיות, במפתחות או בטקסטים. גם ב־18 הרמות המודלים, השרטוטים והסטטוסים זהים. G9-T18 רץ לבד, תחת הנעילה: 532 סטטוסים זהים לבסיס, שהם 518 PASS, 12 REVIEW, 0 FAIL ו־2 UNSUPPORTED. אלה לא 532 PASS. נעילת הקבלה חודשה פעם נוספת, במכוון: fingerprint 96e0600c204653ca (99 קבצים). 173 הקבצים הנעולים לא השתנו.

**התיאור הקודם של הסקיל (frontmatter של v6.16.2-noam), מילה במילה, נשמר כהיסטוריה:** v6.16.2-noam (deliver.SKILL_VERSION). Create professional, sellable Hebrew (RTL) math worksheets in the style of Israeli textbook publishers, levels a/b/c: plane geometry, coordinate plane, number line, line and parabola graphs (a = 1) and pie charts, drawn from their numbers and checked on the finished PDF (gates G42-G84); the answers stay in a private sheet.json, and every level ships the public Noam AI package noam-ai.json (read references/noam-ai-deliverable-he.md first). On a figure topic every question gets a figure, except the author's drawing-from-words share (a 15%, b 20%, excellence 10%; gates G82/G83). Honest status: graph pilot 314/320, FAIL 0 (target met); pie pilot 98/98, FAIL 0, but the overall pie target is NOT met (synthetic 44/55, added 44/56); coordinate plane G7-T08 with Codex's repair: v2 161/286, v1 164/286, target 272 NOT met; number line below target; G9-T18: 532 identical statuses (518 PASS, 12 REVIEW, 2 UNSUPPORTED). Open items: the top of SKILL.md and INSTALL.md.

**v6.16.2-noam (29.9) — מצב במסירה (בכנות):** `deliver.SKILL_VERSION = "6.16.2-noam"`. זה סבב מוגבל אחד, אחרי שנועם ענה על שאלת הניקוד של G9-T06: ״לעדכן את 4 הבדיקות בגלוי (מומלץ)״ (ההחלטה V6161-Q21-AMEND ב־APPROVALS_NOAM.json). אף ניסוח, מספר או תשובה של שאלה לא השתנו, ולא נוספה הוראה לשרטט. ההשהיה של v6.16.1 (״מסומן ומושהה״ למטה) בוטלה בגרסה הזו: שני הסעיפים עומדים עכשיו בכלל השרטוטים (W-FIGURE-DENSITY). מה שכתוב על v6.16.1 למטה נשאר כהיסטוריה.

**מה השתנה ב־v6.16.2:** (1) ב־G9-T06, סעיף 21ג ברמה א׳ (הישר y = 36) וסעיף 21ב ברמה ב׳ (p = 5) מקבלים עכשיו מערכת צירים ריקה משלהם, זו שהוכנה ב־v6.16.1 (המתגים Q21C_OWN_FIGURE ו־Q21B_OWN_FIGURE דלוקים). אין בה גרף, אין נקודות חיתוך ואין תשובה, והחלון שלה מכיל את המצב החדש: ברמה א׳ x מ־6− עד 12 ו־y מ־2− עד 38, ברמה ב׳ x מ־1− עד 9 ו־y מ־1− עד 10. ברמה א׳ המשבצת של מערכת הצירים הזו גדלה מ־10 ל־11 פיקסלים. זה שינוי תצוגה בלבד: ב־10 פיקסלים ה־0 של הראשית ישב קרוב מדי לקו הרשת y = 2−, והקורא הקפוא קרא אותו כמספר של ציר x. השאלה נשארת כולה בעמוד 18. (2) תיקון גלוי של ארבעה תרחישים קפואים של הגרפים: GP189, GP255, GP256 ו־GP257. לכל תרחיש רשומה משלו, עם הציפייה הישנה, הציפייה החדשה, הסיבה, מזהה ההחלטה ותמונות ראיה. השרטוט בראש השאלה (q21_head) נבדק כמו קודם, מול הבסיס הקפוא ועם המוטציות הקפואות. השרטוט של הסעיף נבדק לפי הכלל שלו: מערכת צירים ריקה בלי דבר מהמצב הקודם ובלי דבר מהמצב החדש, ובדיקות MUST_NOT_DRAW והתשובות חלות עליו במלואן. הקורפוס עצמו (v1.1) לא השתנה, מספר התרחישים לא השתנה, ואף תרחיש לא הוסר, לא נוסף ולא נבחר מחדש. הרשומות נמצאות ב־acceptance/corpus_graph/amendment_v1_1_q21.json, והן נרשמו מתחת ל־ADDED AFTER FREEZE ב־FROZEN_graph.txt. החלק הקפוא של הקובץ נשאר זהה בית־לבית. (3) שינוי ממוקד ברץ הקבלה, שחל רק על ארבעת התרחישים האלה: RUNNER_V616.txt D41 והקובץ tools/v616_amend.py. הבדיקה selfcheck_v6162_amend.py כוללת מקרים שעוברים ומקרים ששתלנו בהם גרף, נקודת חיתוך או טקסט אסור, וכולם נכשלים כמו שצריך. נעילת הקבלה חודשה פעם אחת, במכוון.

**התוצאות של v6.16.2:** הסוויטה המלאה, 70 קבצים בזה אחר זה: כולם עברו. 69 הקבצים של v6.16.1 נתנו בדיוק את אותן ספירות, והקובץ החדש selfcheck_v6162_amend.py עבר 40 מתוך 40. קבלה ממוקדת, עם OCR ומוטציות, על כל 206 התרחישים של G9-T06 ברמות א׳ ו־ב׳: 197 PASS, 9 REVIEW ו־0 FAIL. זה בדיוק כמו ב־v6.16.1, ואף PASS לא אבד. GP189 ו־GP255–257 עוברים לפי הציפייה החדשה: שורות הבדיקה של השרטוט בראש השאלה זהות ל־v6.16.1, וכל שורות הבדיקה של השרטוט של הסעיף עוברות. תוצאות המוטציות ובדיקות השלילה של v1.1 זהות. G8-T15 ו־G8-T30 נבנו מחדש וזהים בית־לבית (PDF, noam-ai.json ושרטוטים). G9-T18: 532 סטטוסים זהים לבסיס, שהם 518 PASS, 12 REVIEW ו־2 UNSUPPORTED. אלה לא 532 PASS. הגלאי gate_situation עובר עכשיו בשלוש הרמות של G9-T06, ו־noam-ai.json מקשר את א׳ 21ג ואת ב׳ 21ב לשרטוטים שלהם. גרפים: בפיילוט 314/320, 0 FAIL, והיעד הושג (קבלת v6.16; הקבלה הממוקדת זהה לה). עוגה: בפיילוט 98/98, אבל היעד הכולל של עוגה לא הושג (בסינתטי 44/55, בנוספים 44/56). מערכת צירים (G7-T08, של Codex): v2 161/286, v1 164/286, והיעד 272 לא הושג. נעילת הקבלה: fingerprint 296503a64b439e93.

**התיאור הקודם של הסקיל (frontmatter של v6.16.1-noam), מילה במילה, נשמר כהיסטוריה:** v6.16.1-noam (deliver.SKILL_VERSION). Create professional, sellable Hebrew (RTL) math worksheets in the style of Israeli textbook publishers, levels a/b/c: plane geometry, coordinate plane, number line, line and parabola graphs (a = 1) and pie charts, drawn from their numbers and checked on the finished PDF (gates G42-G84); the answers stay in a private sheet.json, and every level ships the public Noam AI package noam-ai.json (read references/noam-ai-deliverable-he.md first). On a figure topic every question gets a figure, except the author's drawing-from-words share (a 15%, b 20%, excellence 10%; gates G82/G83). Honest status: graph pilot 314/320, FAIL 0 (target met); pie pilot 98/98, FAIL 0, but the overall pie target is NOT met (synthetic 44/55, added 44/56); coordinate plane G7-T08 with Codex's repair: v2 161/286, v1 164/286, target 272 NOT met; number line below target; G9-T18: 532 identical statuses (518 PASS, 12 REVIEW, 2 UNSUPPORTED). Open items: the top of SKILL.md and INSTALL.md.

**v6.16.1-noam (29.9) — מצב במסירה (בכנות):** `deliver.SKILL_VERSION = "6.16.1-noam"`. זה סבב מוגבל אחרי הביקורת של Codex על v6.16 ואחרי תיקון מערכת הצירים של Codex. אין בו סבב מנוע שלישי. אף ניסוח, מספר או תשובה של שאלה לא השתנו, ואף קובץ קפוא (קורפוס, FROZEN, SCORING) לא השתנה.

**מה השתנה ב־v6.16.1:** (1) תיקון מערכת הצירים של Codex שולב אחרי ביקורת ממוקדת, בלי ממצא חוסם. הקבצים הם acceptance/tools/run_family_v612.py, wspec/check/coord.py ו־wspec/render/coord.py. קטע נמצא בלי תלות בסדר האותיות (SL הוא LS). מקום ברשימה שהקורפוס הקפוא אומר שאינו מצויר לא מחופש במפה. מתחת לשם הנקודה Q נשמר מקום לזנב של האות, והנקודה עצמה לא זזה. בסקיצה בלי רשת נמדדים קנה המידה של ציר x ושל ציר y כל אחד לחוד. ב־G7-T08 השאלות ב׳ 2, ב׳ 8, מצוינות 3 ומצוינות 11 מודפסות עכשיו ממסלול המפרט, באותו ניסוח. הדף, המפתח והתשובות שלהן לא השתנו, אבל בקובץ נועם AI (noam-ai.json) השדות המובנים שלהן דלים יותר מאשר ב־v6.16, והוא לא זהה ל־v6.16: במצוינות 11 ירדו הנתון ״מלבן שצלעותיו מקבילות לצירים, ו־A, C קודקודים נגדיים״, התנאים של B ו־D והיחידות של ההיקף והשטח; במצוינות 3 ירד מי כתב איזה זוג (דנה, יואב); בב׳ 8 לסעיפים א–ג אין עוד יעד, וזה מוצהר. הטקסט המלא של כל שאלה נשאר בקובץ, ולכן אין כאן טעות. הממצא הועבר ל־Codex לסבב מערכת הצירים הבא, ו־G7-T08 לא שונה כאן. בדיקה: selfcheck_codex_coord.py. (2) tools/highlight.py, הצרכן לדוגמה של הדגשות נועם AI (לא המנוע): הדגשה של גזרה בעוגה מצוירת עכשיו מעל הגזרות ולא מתחתן. הדגשה של עוגה שלמה או של עיגול בנייה היא קו בלי מילוי ברדיוס של העוגה, כך שקווי החלוקה נשארים גלויים. גרפים ושרטוטי גאומטריה לא השתנו. בדיקה: selfcheck_v6161_highlight.py. (3) גלאי חדש, gate_situation.py, שלא מחובר לבנייה: הוא מסמן סעיף שמדפיס ערך חדש לפרמטר או לישר של השרטוט בראש השאלה, בלי שרטוט משלו. בדיקה: selfcheck_v6161_situation.py.

**מסומן ומושהה, לא תוקן בגרסה הזו:** ב־G9-T06 רמה א׳ סעיף 21ג (הישר y = 36) ורמה ב׳ סעיף 21ב (p = 5) עדיין מודפסים על השרטוט של המצב הקודם, בדיוק כמו ב־v6.16. לכל אחד מהם מוכנה מערכת צירים ריקה בקובצי הרמה, מאחורי המתגים Q21C_OWN_FIGURE ו־Q21B_OWN_FIGURE, והמתגים כבויים. הסיבה: רץ הקבלה הקפוא בודק שרטוט של סעיף מול שרטוט הראש (SCORING_graph s0), ולכן GP189 ו־GP255–257 היו עוברים מ־PASS ל־FAIL. לעומתו, SCORING_graph_aaf1 A10 אומר ששרטוט של סעיף נבדק לפי הכלל שלו. זו החלטת ניקוד של נועם: תיקון גלוי של התרחישים האלה, או קריאה מתועדת של הרץ עם נעילה מחדש. אין שינוי שקט של הקורפוס. הגלאי gate_situation מסמן בדיוק את שני הסעיפים האלה. שני הסעיפים לא עומדים בכלל השרטוטים (W-FIGURE-DENSITY) ולא נספרים כעומדים בו. גם noam-ai.json מקשר אותם לשרטוט של השאלה (figure_id = q21_head), ולכן מי שיקרא את נקודות החיתוך מהשרטוט בב׳ 21ב יקבל תשובה של p = 1 ולא של p = 5. הניסוח, המספרים והתשובות עצמם נכונים.

**התוצאות:** מערכת צירים (G7-T08, עם התיקון של Codex): v2 161/286 (14 REVIEW, 0 FAIL, 111 UNSUPPORTED), v1 164/286 (2 REVIEW, 0 FAIL, 120 UNSUPPORTED), ואף PASS לא אבד. היעד 272/286 לא הושג. אלה תוצאות הקבלה של Codex. ה־PDF, noam-ai.json והשרטוטים של G7-T08 שנבנו כאן זהים בית־לבית לבנייה של Codex, ורק מחרוזות הגרסה והבנייה שונות, ולכן קבלת מערכת הצירים לא הורצה שוב. מגבלה ב־v1: בשמונה שורות PASS (CP134–139 ו־CP208/209) רק הבודק מוודא שמקום ברשימה לא מצויר, ובקרת ״תשובה מצוירת״ של הרץ לא נבנית להן. גרפים: בפיילוט 314/320, 0 FAIL, והיעד הושג (קבלת v6.16). בקבלה ממוקדת עכשיו, עם OCR ומוטציות, על כל 206 התרחישים של G9-T06 ברמות א׳ ו־ב׳ (כולל GP189 ו־GP255–257): 197 PASS, 9 REVIEW ו־0 FAIL. התוצאה זהה לקבלת v6.16 בדיקה אחר בדיקה, ואף PASS לא אבד. עוגה: בפיילוט 98/98, 0 FAIL, אבל היעד הכולל של עוגה לא הושג: בסינתטי 44/55 ובנוספים 44/56. ישר מספרים (G7-T01): v1 35/216, מתחת ליעד. G9-T18: 532 סטטוסים זהים לבסיס, שהם 518 PASS, 12 REVIEW ו־2 UNSUPPORTED. אלה לא 532 PASS.

**ממתין להחלטה של נועם:** (1) הניקוד של שרטוט סעיף ב־G9-T06 (21ג ברמה א׳, 21ב ברמה ב׳), כמתואר למעלה. השאלה נשלחה לנועם בחלון במק ב־29.9, עם שלוש אפשרויות: תיקון גלוי של התרחישים (מומלץ), קריאה מתועדת של הרץ, או להשאיר מסומן. עד להחלטה חסומה רק הדפסת שתי מערכות הצירים. (2) שאלות העוגה ״האם העוגות נראות זהות״ (א׳ 13, א׳ 15, ב׳ 20, מצוינות 3 ו־19): האם להוסיף הוראה לצייר לפני ההשוואה. נועם כבר נשאל ב־Codex, והניסוח ובחירת L לא שונו. (3) התיקונים לתרחישים CP216–219 ו־CP174 של מערכת צירים, וקורפוס v2.1 של ישר מספרים. (4) G9-T06 מצוינות, שאלה 22: נשארת תיבת ״מגבלה מקומית״. שאר הרשימה של v6.16 למטה עדיין בתוקף.

נעילת הקבלה: fingerprint 25646269dd6f8a8e. היא חודשה פעם אחת, במכוון, עם --note, כי קוד מערכת הצירים של Codex ומספר הגרסה ב־deliver.py השתנו. הסוויטה המלאה היא 69 קבצים שרצים בזה אחר זה: 66 הקבצים של v6.16, ועוד selfcheck_codex_coord.py, selfcheck_v6161_highlight.py ו־selfcheck_v6161_situation.py. את selfcheck_v615_runner.py מריצים עם ‎--t08 על out/deliver של G7-T08 שנבנה מחדש. selfcheck_codex_coord.py קורא את level_b.py של G7-T08 מהתיקייה ‎../G7-T08 שליד הסקיל, או מ־PYTHONPATH. התיאור הקודם (v6.16) ו־v6.16-noam למטה נשמרים כהיסטוריה.

**התיאור הקודם של הסקיל (frontmatter של v6.16-noam), מילה במילה, נשמר כהיסטוריה:** v6.16-noam (deliver.SKILL_VERSION). Create professional, sellable Hebrew (RTL) math worksheets in the style of Israeli textbook publishers, levels a/b/c: plane geometry, coordinate plane, number line, line and parabola graphs (a = 1) and pie charts, drawn from their numbers and checked on the finished PDF (gates G42-G84); the answers stay in a private sheet.json, and every level ships the public Noam AI package noam-ai.json (read references/noam-ai-deliverable-he.md first). On a figure topic every question gets a figure, except the author's drawing-from-words share (a 15%, b 20%, excellence 10%; gates G82/G83). Honest status: graph pilot 314/320 and pie pilot 98/98 with FAIL 0 (target met); the coordinate plane (G7-T08, 133/286) is handed to Codex and the number line (G7-T01) is below target; G9-T18 stays 532/532. Pending author decisions and open items: the status at the top of SKILL.md and INSTALL.md.

**v6.16-noam (28.9) — מצב במסירה (בכנות):** `deliver.SKILL_VERSION = "6.16-noam"`. זה שלב B של תוכנית 18 החבילות (W-PLAN18-LIST): גרף של ישר לפי משוואה, פרבולה עם a = 1 והזזותיה, ודיאגרמת עוגה, כולם במסלול המפרט. פיילוטי הקבלה הם G8-T15 (פונקציה קווית), G9-T06 (פונקציה ריבועית) ו־G8-T30 (דיאגרמת עוגה), ברמות א׳, ב׳ ומצוינות, והם נבנו מתוכן המקור. אלה פיילוטים לקבלה ולא דפי הייצור. אף מספר או תשובה של המקור לא השתנו. בשאלות של השרטוט ממילים הוסרה רק מילת ההפניה לשרטוט (ADDENDUM 1, כלל 5). שאלה אחת של G9-T06 שאינה בנושא מחכה לשאלה חלופית (D5): שאלה 24 ברמות א׳ ו־ב׳ לא הודפסה, ובמצוינות מודפסת במקום שאלה 22 תיבת ״מגבלה מקומית״.

**מה נוסף ב־v6.16:** (1) משפחת גרפים (wspec/graph): ישר y = mx + b דרך נקודות סריג, ישרים אנכיים ואופקיים, ישרים מקבילים, וצירים מהחיים עם קנה מידה. פרבולה בצורות x² + c, (x − p)², (x − p)² + k, (x − a)(x − b) ו־x² + bx + c, עם קודקוד, נקודות אפס, חיתוך עם ציר y וציר סימטריה מקווקו. שיפוע, נקודות חיתוך ותחומי עלייה הם יעדי מציאה: הם מופיעים רק במפתח ולעולם לא מצוירים. (2) משפחת עוגה (wspec/pie): גזרות באחוזים או במעלות, שם הקטגוריה בגזרה או במקרא, גזרה חסרה שערכה יעד מציאה, שתי עוגות זו לצד זו, ועיגול ריק לשאלת ״בנו עוגה״. (3) כלל השרטוטים של נועם (W-FIGURE-DENSITY): בנושא של שרטוטים יש שרטוט לכל שאלה, וסעיף במצב אחר מקבל שרטוט משלו. חלק קבוע מהשאלות נשאר בלי שרטוט כדי לתרגל שרטוט ממילים (א׳ 15%, ב׳ 20%, מצוינות 10%, בטווח של שאלה אחת), ומתחת לכל אחת מהן יש מקום ריק של כ־70 מ״מ (V616-A7). שלושה שערים חדשים: G82 FIG_REF (שאלה שמפנה לשרטוט חייבת שרטוט), G83 FIG_DENSITY (החלק בלי שרטוט, והמקום הריק נמדד על ה־PDF), ו־G84 NUM_CLEAR (מספר על ציר לא נוגע בקו של גרף, נמדד על ה־PDF). (4) קורפוסי קבלה קפואים חדשים לגרפים (v1.1, 1e276dc6) ולעוגה. בונה בלתי תלוי בנה אותם, וספקן בדק אותם לפני ההקפאה. הם רצים בפקודה acceptance/run.py --family graph|pie (תיעוד: acceptance/RUNNER_V616.txt). כל שינוי בקורפוס אחרי ההקפאה מתועד כ־AMENDMENT עם מזהה ההחלטה של נועם, והמכנה לא קטן.

**התוצאות (קבלה מלאה עם OCR ומוטציות):** גרפים: בפיילוט 314 מתוך 320 (98.1%), 0 FAIL, והיעד הושג (G8-T15: א׳ 38/38, ב׳ 41/42, מצוינות 45/45; G9-T06: א׳ 63/65, ב׳ 66/67, מצוינות 61/63). בסינתטי 43 מתוך 50, 0 FAIL. ה־REVIEW הם שמות צירים בעברית, שה־OCR במחשב הזה לא קורא. עוגה: בפיילוט 98 מתוך 98, 0 FAIL. בסינתטי 44 מתוך 55 ובנוספים 44 מתוך 56, 0 FAIL, וכל השאר REVIEW של OCR עברי. שאלה 8 ב־G8-T30 רמה א׳ (תרשים עמודות במקור) היא חריגה באישור נועם (V616-A4), והיא מדווחת כחריגה ולא כ־PASS. מערכת צירים (G7-T08) הועברה ל־Codex לפי החלטת נועם מ־28.9, ורצה כבדיקת נסיגה בלבד: v2 133/286, v1 130/286, 0 FAIL, ואף PASS לא אבד. היעד של 95% לא הושג. ישר מספרים v1 (G7-T01): 35/216, זהה בית־לבית ל־v6.15, 0 FAIL. היעד לא הושג, והציון יזוז במסלול הצדדי של קורפוס v2.1. G9-T18: כל 532 התוצאות זהות לבסיס.

**ממתין להחלטה של נועם או לשלב הבא:** (1) G9-T06 מצוינות, שאלה 22: צריך שאלה חלופית, מכותב בלתי תלוי ובאישור נועם. בינתיים מודפסת תיבת ״מגבלה מקומית״, והמבוא עדיין מזכיר את שאלות 22–24. (2) שאלות העוגה ״האם העוגות נראות זהות״ (א׳ 13, א׳ 15, ב׳ 20, מצוינות 3 ו־19): לבחור LOOK L1 (המצב עכשיו), L2 או L3, או לאשר הוראה לצייר בעיגול. (3) שמות צירים בגרפים מהחיים: כרגע מודפסים רק x ו־y. (4) O-3: שני מספרים על ציר x בפונקציה קווית (א׳ שאלה 18, מצוינות שאלה 11) עומדים כחצי נקודה מקו. הם קריאים ולכן נשארו. (5) ניסוחי Noam AI בסעיפים 1–3 של wspec/PENDING_V616.txt (סעיף 4 אושר, V616-A5). (6) ישר מספרים: שאלת B5 וקורפוס v2.1 ממתינים ל־Codex. (7) G7-T08: כלל השרטוטים יחול עליו בייצור (בפיילוט הנסיגה G83 מסומן DEFERRED). לא בגרסה הזו: עמודות, היסטוגרמות, a ≠ 1, פרבולה הפוכה, v7 ו־18 חבילות הייצור.

נעילת הקבלה: fingerprint 42e0fad3ad0e965d.היא חודשה במכוון עם --note, כי רק מספר הגרסה ב־deliver.py השתנה. הסוויטה המלאה היא 66 קבצים שרצים בזה אחר זה. הדוחות: REPORT.txt בכל תיקיית דוגמה ובחבילת Codex. התיאור הקודם (v6.15) ו־v6.15-noam למטה נשמרים כהיסטוריה.

**התיאור הקודם של הסקיל (frontmatter של v6.15-noam), מילה במילה, נשמר כהיסטוריה:** v6.15-noam (deliver.SKILL_VERSION). Create professional, sellable Hebrew (RTL) math worksheets in the style of Israeli textbook publishers, levels a/b/c: plane geometry, coordinate plane and number line figures drawn from their numbers and checked on the finished PDF (gates G42-G81); the answers stay in a private sheet.json, and every level ships the public Noam AI package noam-ai.json (read references/noam-ai-deliverable-he.md first). Honest status: the 95% pilot target is NOT met (G7-T08 coordinate plane, G7-T01 number line); G9-T18 stays 532/532 against its frozen baseline. v6.15 adds the corpus-v2 acceptance runner (acceptance/run.py --corpus v2; v1 stays the default, unchanged); v6.14 added role-checked coordinate pairs, typed parallel and scale givens, and the check on the Noam AI metadata lines. Pending author decisions and open items: the status at the top of SKILL.md and INSTALL.md.

**v6.15-noam (25.9) — מצב במסירה (בכנות):** `deliver.SKILL_VERSION = "6.15-noam"`. v6.14 לא נארזה כחבילה נפרדת, ולכן החבילה הזו כוללת גם את השינויים שלה. אף שאלה, מספר, תשובה או דף לא השתנו ב־v6.15.

**מה נוסף ב־v6.14:** (F1) G80 בודק זוג שיעורים לפי תפקיד: המספר הראשון קשור לשיעור ה־x של אותה נקודה והשני לשיעור ה־y, ולכן C(−3,2) שהוחלף ב־C(2,−3) נכשל (BOUND_COORD_ROLE, selfcheck_v614_roles.py). (F2) הנתון 'AB ∥ ציר x' (T08 a q7, b q9) נשמר כנתון מוקלד עם אובייקטים, ונועם AI יכול להדגיש אותו. (F3) 'כל יחידה מייצגת 10 מטרים' (T08 a q11, b q5) הוא נתון קנה מידה מובנה, ונתון 7ב 'חישוב התלמיד' חזר. (F4) ב־T08 a הפטור הכללי משרטוט הוחלף בפטור לשאלה 8 בלבד, ונוספו שרטוטי 17ג ו־18ג שמראים נתונים בלבד. התנאי של W-META-LINES-3 נאכף: כל שורת תיאור בנועם AI מקושרת לעובדה אחת שהשאלה כבר מדפיסה, בלי ערך, רמז או מסקנה (selfcheck_v614_givens.py, selfcheck_v614_meta.py, K25 ב־selfcheck_noam_package).

**מה נוסף ב־v6.15 — רץ קבלה לקורפוס v2 (W-CORPUS-V2):** הקורפוסים הקפואים של v2 הותקנו בית־לבית ב־acceptance/corpus_v2/ (ה־sha תואם ל־FROZEN_*_v2.txt). הפקודה: `python3 acceptance/run.py --corpus v2 --v2-only --family coord --coord-deliver <G7-T08>/out/deliver`, ובאותו אופן `--family numberline --numberline-deliver <G7-T01>/out/deliver`. ברירת המחדל נשארת `--corpus v1`, ותוצאות v1 זהות בית־לבית ל־v6.14. בדיקות חדשות: MUST_NOT_DRAW (שרטוט או סימן שהוסר וחזר נותן FAIL), TEXT_BOUND (נתון מודפס שהשתנה נותן FAIL, עם גבולות מספר: 'אורכו 60' אינו 'אורכו 6'), ANSWER_NOT_EXPOSED, ומוטציות שמוודאות שכל בדיקה באמת תופסת. FAIL גובר על UNSUPPORTED, פיילוט וסינתטי תמיד בנפרד, והתקרה שאפשר להגיע אליה מודפסת. תיעוד: acceptance/RUNNER_V2.txt (החלטות D1–D21). בדיקות: selfcheck_v615_runner.py (175).

**התוצאות על פיילוטי v6.14 — היעד לא הושג:** צירים v2 (G7-T08): בפיילוט 91 PASS מתוך 286, 0 FAIL, 195 UNSUPPORTED (a 52/100, b 39/96, c 0/90). 91 היא התקרה של הרץ הזה, כי 195 שרטוטים נבנים במסלול הבונה ואין להם עדיין צינור בדיקה. היעד 272 לא ניתן להשגה: 30 פערי מנוע פתוחים מגבילים את הפיילוט ל־256. הסינתטיים בנפרד: 32 PASS, 3 REVIEW, 5 UNSUPPORTED מתוך 40. ישר מספרים v2 (G7-T01): כל 216 תרחישי הפיילוט REVIEW בגלל כלל ההקפאה B5, כי v6.14 בנתה את T01 מחדש אחרי ההקפאה (sheet.json, noam-ai.json ו־build.json השתנו; sheet.pdf זהה לגרסה הקפואה). מתחת ל־B5 יוצאים 155 PASS, 61 UNSUPPORTED ו־0 FAIL, וזה מידע בלבד. הסינתטיים: 31 PASS, 9 UNSUPPORTED מתוך 40. v1 ללא שינוי: צירים 82/286, ישר מספרים 35/216, FAIL 0. G9-T18: 532/532 זהים לבסיס (פיילוט 458/471, סינתטי 60/61). בדיקה בלתי תלויה החזירה שרטוט מסגיר, שינתה מספר והחליפה x/y — כל אחד מהם נתן FAIL. הממצא היחיד שלה (TEXT_BOUND כתת־מחרוזת) תוקן בסבב תיקון אחד. 35 תרחישי v2 נבדקו בעין (8 בבניית הרץ, 15 בהרצה, 12 בדגימה), וכולם נכונים.

**ממתין להחלטה של נועם או לשלב הבא:** (1) B5: להקפיא מחדש את בסיסי T01 של v6.14 כגרסת קורפוס חדשה, או לבדוק על הבתים הקפואים של v6.13. (2) צינור בדיקה לשרטוטי הבונה, או העברת הפיילוטים למסלול המפרט. בלעדיהם אף יעד של v2 לא ניתן להשגה. פתוח (minor): run_family_v2.py שמורץ ישירות עם --no-mutations מחזיר קוד יציאה שמתעלם מהדגל (run.py לא מעביר אותו); הרצת תת־קבוצה עם --corpus v2 בלי --v2-only מריצה את v1 על אפס תרחישים; coord_target_value_text לא סופר זוג תשובה שלילי (אין כזה בפיילוט). פתוחים מ־v6.14: BUILDER-PAR-UNTIED, C-SCALE-UNSTRUCTURED, Q7B-FACT-LINK (החלטה של נועם), AXIS-TEXT-SPELLING ('axis-x' בנתוני הבונה), META-DETECT-PARAPHRASE. עדיין pending: 45 התבניות של v6.10 (wspec/PENDING_V610.txt) ורשימת not_approved_by_this בקובץ האישורים. לא בגרסה הזו: גרפים (ישר, פרבולה עם a=1, עוגה), v7 ו־18 החבילות. אלה השלבים הבאים.

נעילת הקבלה: fingerprint 848395fdaec17fba. היא חודשה במכוון עם --note, כי מספר הגרסה ב־deliver.py השתנה. הסוויטה המלאה היא 57 קבצים, שרצים בזה אחר זה: 53 הקבצים של v6.13, ועוד selfcheck_v614_roles.py, selfcheck_v614_givens.py, selfcheck_v614_meta.py ו־selfcheck_v615_runner.py. פירוט: RUN.txt, INDEP_CHECK.txt, SAMPLE.txt ו־RESULT.txt בחבילת Codex. התיאור הקודם (v6.13) ו־v6.13-noam למטה נשמרים כהיסטוריה.

**התיאור הקודם של הסקיל (frontmatter של v6.13-noam), מילה במילה, נשמר כהיסטוריה:** v6.13-noam (deliver.SKILL_VERSION): bound original wording; pilots partly on spec path, target NOT met. v6.12-noam: engines for coordinate plane + number line, own frozen acceptance; pilots not on the spec path (pilot 0%, target NOT met); see INSTALL.md. v6.11-noam: G80 binds sheet.pdf to the spec; portable acceptance/; △ always, angles in three letters (G81). v6.10-noam: STATUS AT DELIVERY (honest): all 45 G9-T18 questions on the spec path; PDF acceptance, frozen corpus, 532 object scenarios (not exercises), v6.10 runner: pilot 458/471 = 97.24% (95% met), synthetic 60/61, overall 518/532, FAIL 0; the runner choice and new wording are PENDING Noam. v6.9-noam: a question may carry spec= (a wspec spec): the vendored engine (wspec/) draws its figures, inlined in the sheet byte-exact; the maths-core text comes from the approved templates and the answer key from the private part; gate G79-spec checks every engine figure ON THE PDF (geometry, labels, cover, answer, OCR); noam-ai.json names the engine's objects (id -> parts); tools/highlight.py. v6.7.3-noam: find-target leak checks; gaps listed below. v6.7.2-noam: to_prove also holds compute / find targets ({type: find, quantity, of}; value private in sheet.json; checked by check_didactic D12). v6.7.1-noam: the author's didactic policy on top of v6.7-noam -- to_construct beside given/to_prove (a relation in two lists is refused unless from_item), a neutral starting figure under STRICT (every mark / value label an explicit given, no guide lines, no colours, no drawn construction), ONE general visual layer (visual_model, visual-model/v1, §9: a registry of kinds -- plane geometry, construction, coordinate plane, function graph, number line, table, solids; tree / Venn / pie / sample space ... as schema + validator, shipped unsupported with no drawing -- highlight_given for the givens overlay, aux figures as patches, and the closed action list show / highlight / show_aux: Noam AI never draws), a private didactic.json for hints (noam-ai.json carries hint_mode and approved hints only), a curriculum block from curriculum_tools.json, and check_didactic.py (independent). v6.7-noam (the v6.7 engine + the v6.8 Noam AI contract + the author's final spec, BRIEF_V68 §5): every level a/b/c writes noam-ai.json next to the package, built as a FIELD-BY-FIELD WHITELIST (package, level, question/item ids, text, label, figure_id, given/to_prove, question tables and worked examples as data; figures with svg, view, objects with svg_id, constraints with status) -- never answers, solutions, hints, code or code paths, hashes, built_at, skill_version, fam, sheet ids, strict flags or report rows. sheet.json stays private with the answers. selfcheck_noam_package.py is an independent stdlib checker (python3 selfcheck_noam_package.py out/deliver/a out/deliver/b out/deliver/c; no args runs its pass+fail fixtures). STRICT by default: PACKAGE = G<grade>-T<nn>, STRICT_FIGURES written, every proof request declares to_prove, a marked claim is refused. Every svg_id sits on ink; ticks and angle arcs carry ink_xy on their strokes; every printed mark is named by a marked constraint (mark_ids lists a whole group); circle_fig exports tangent, the equal tangent segments and the diameter's midpoint/collinear. verify_export.py a b c (no skill imports) re-runs every figure script, re-measures every constraint (tangent, ratio, concentric included) and reads noam-ai.json. T' in a Hebrew line was measured on the printed PDF: the prime's ink is right of the T (the reported 'T was a reading-direction false alarm; .m stays an LTR embedding). Create professional, sellable Hebrew (RTL) math worksheets in the style of Israeli textbook publishers; gates G42-G78 read the finished PDF, and every enforced rule has a passing AND a failing test.

**v6.13-noam (25.9) — מצב במסירה (בכנות):** `deliver.SKILL_VERSION = "6.13-noam"`. **נוסח מקורי קשור (W-BOUND-PROSE, אושר ע"י נועם):** נוסח השאלה המקורי מודפס כמו שהוא כשכל מספר, מילת מספר, משתנה ושם (נקודה, קטע, זווית, משולש) קשור לעובדה או לישות במפרט (טבלת קישור לכל בלוק, wspec/schema_bound.py); G80 בודק כל בלוק מודפס מול הקישורים שלו ומול sheet.pdf (G80_BOUND). מספר לא קשור, מספר שקשור לתשובה או מספר שהשתנה בדף — נדחים. טבלאות (נתונים) ודוגמאות פתורות (נוסח קשור) נכתבים כנתונים ל־sheet.json / noam-ai.json / public_spec.json. △ תמיד, זווית בשלוש אותיות. בדיקות: selfcheck_v613_prose.py, selfcheck_v613_tables.py. **תקלות האינטגרציה D1–D6 נסגרו** (selfcheck_v613_integ.py). **אמינות ה־OCR:** מיפוי מתועד של תווים דומים (מינוס U+2212, O/0, B/В קירילית) וקריאה ברמת החיתוך מול קבוצת ערכים צפויה (wspec/check/ocr_expect.py, selfcheck_v613_ocr.py); מה שאינו חד־משמעי נשאר REVIEW, ו־0 אמיתי במקום O עדיין נכשל. **ניסוח התבניות:** ארבע ההחלטות של נועם (ספירה 'לא כולל הקצוות', קפיצה 'ולאיזה כיוון?' ובמפתח '5 יחידות שמאלה', 'מה ההפרש בין הערכים של שתי שנתות סמוכות?', 'שיעורי הנקודה' ללא שינוי) הוכנסו ל־templates_he.json; כל 37 תבניות v6.12 מאושרות ע"י נועם ואינן מסומנות pending. **עדיין ממתינות לנועם** שלוש שורות מטא־נתונים שהוסיף המתקן (לא מודפסות בדף): 'המספר שמייצגת הנקודה {n0}', 'ההפרש בין הערכים של שני קווי רשת סמוכים על ציר {n0}', '{n0} ∥ ציר {n1}'; את ה־hash של הסט (db0bce4f) קבע המתקן, לא נועם. כותרת STATUS ב־wspec/PENDING_V612.txt מיושנת (כתוב שם hash 892a5ba7 ו'אין ממתינות'); הסעיפים 6–7 בקובץ ורשימה זו הם הנכונים. 45 התבניות של v6.10 עדיין pending (wspec/PENDING_V610.txt). **הפיילוטים עברו חלקית למסלול המפרט, היעד (95% מהפיילוט) לא הושג:** מערכת צירים G7-T08 — 82/286 = 28.67% (a 43/100, b 39/96, c 0/90; רמה c כולה עדיין במסלול הישן), FAIL 0, REVIEW 0; ישר מספרים G7-T01 — 35/216 = 16.20% (a 15/165, b 16/25, c 4/26), FAIL 0, REVIEW 0. שאר התרחישים UNSUPPORTED: נקודות ונתונים/סדרות שאין להם מנוע, יחסים שהמפרט לא יודע לומר (נגדי, בין, אמצע), תרחישים בקורפוס הקפוא ששמים אובייקט שהרמה המסופקת כבר לא מציירת, ושאלות ב־T01 a שאין להן שרטוט בדף. סינתטי: צירים 32 PASS, 3 REVIEW (CS09–CS11: המסגרת הייתה מדפיסה את הצעד הנשאל — שאלה פתוחה לנועם), 0 FAIL, 5 UNSUPPORTED; ישר מספרים 31/40 PASS, 0 REVIEW, 0 FAIL, 9 UNSUPPORTED. G9-T18 ללא שינוי: 532/532 סטטוסים זהים לבסיס (פיילוט 458/471, סינתטי 60/61, כולל 518/532). נעילת הקבלה: fingerprint 6e441eb9ee1fbde7 (חודשה במכוון בסבב תיקון 2). שני סבבי התיקון המותרים נוצלו. פתוח (פירוט ב־REPORT.txt): הנתון 'AB ∥ ציר x' ב־T08 a q7 / b q9 אינו ניתן להדגשה בנועם AI (S-1), נתון קנה המידה 'כל יחידה מייצגת 10 מטרים' ירד מרשימת הנתונים ב־T08 a q11 / b q5 (S-2), ה־0 של הראשית במרחק 1.12 pt מציר y, ספרות בנוסח רץ בצורת old-style. פירוט, כל תוצאה שאינה PASS, אילו שאלות עברו וסעיפים פתוחים: REPORT.txt בדוגמאות G7-T08-v613-example ו־G7-T01-v613-example. מדריך כתיבה: CONVENTIONS_v613 (בחבילת Codex). v6.12-noam למטה נשמר כהיסטוריה.

**v6.12-noam (24.9) — מצב במסירה (בכנות):** `deliver.SKILL_VERSION = "6.12-noam"`. VP-2r נסגר: טביעת האצבע של הקבלה (acceptance/LOCK.txt) כוללת עכשיו את כל סגירת הייבוא של פסק הדין ושל G79/G80/G81 — 70 קבצים, ביניהם mathsvg.py, figkit.py, figkit_plus.py, numberline.py; שינוי של בית אחד באחד מהם נחסם ב־exit 4 (selfcheck_v612_lock.py); הנעילה חודשה במכוון עם --note, לא נעקפה (fingerprint c64eef7f06f840cf). שתי משפחות מנוע חדשות ב־wspec: מערכת צירים (wspec/render/coord.py, wspec/check/coord.py) וישר מספרים (wspec/render/nline.py, wspec/check/nline.py), כל אחת עם קורפוס קבלה קפוא משלה שהוקפא לפני קוד המנוע (acceptance/corpus_coord.json, corpus_numberline.json, FROZEN_coord.txt, FROZEN_numberline.txt): `python3 acceptance/run.py --family coord --coord-deliver <G7-T08>/out/deliver` ו־`--family numberline --numberline-deliver <G7-T01>/out/deliver`. **היעד לא הושג (95% מהפיילוט בכל משפחה):** פיילוט צירים G7-T08 0/286 ופיילוט ישר מספרים G7-T01 0/216 — כל התרחישים UNSUPPORTED, כי שש רמות הפיילוט עדיין נבנות במסלול הישן (figkit / numberline מתוך content.py) ולא במסלול המפרט (אין source/level_spec.json). ההמרה מחכה לאישור נועם לניסוח 37 התבניות החדשות (wspec/PENDING_V612.txt) ולתכונות שאינן בגרסה (סדרות נתונים, קווים מוערמים, קרניים, טבלאות, דוגמאות פתורות). סינתטי: צירים PASS 19/40 (REVIEW 16, FAIL 0, UNSUPPORTED 5), ישר מספרים PASS 29/40 (REVIEW 2, FAIL 0, UNSUPPORTED 9); כל REVIEW נבדק בעין: השרטוט נכון, ה־OCR קרא לא נכון (מינוס, O, B קירילית) או שיעד קנה המידה נחסם כדליפה (CS09/10/11). FAIL 0 בשתי המשפחות. G9-T18 ללא שינוי: 532/532 סטטוסים זהים (פיילוט 458/471, סינתטי 60/61, כולל 518/532; רמה c לבדה 94.25%). חבילות G7-T08 ו־G7-T01 (a/b/c) נבנות נקיות: כל השערים, verify_export 0, selfcheck_noam_package 0, check_didactic FAIL 0 (REVIEW נשאר REVIEW); T01 b/c נכתבו מה־PDF המקורי בלי לשנות שאלה, מספר או תשובה, ולא מצויר דבר שהתלמיד מסמן או מוצא. ממתין לנועם: ניסוח התבניות החדשות, T08 a figure_sheet=False, מספור כל שנת ב־T01 c שאלה 9, הסרת (1)(2)(3) ב־T01 a/b שאלה 36, △ קטן יותר (בגובה אות) בכל דף שייבנה מעכשיו. פירוט, כל תוצאה שאינה PASS וסעיפים פתוחים: REPORT.txt בדוגמאות G7-T08-v612-example ו־G7-T01-v612-example. בדיקות v6.12: selfcheck_v612_lock.py, selfcheck_v612_schema.py, selfcheck_v612_coord.py, selfcheck_v612_nline.py, selfcheck_v612_fix1.py, selfcheck_v612_fix2.py. v6.11-noam למטה נשמר כהיסטוריה.

**v6.11-noam (24.9) — מצב במסירה (בכנות):** `deliver.SKILL_VERSION = "6.11-noam"`. NEW-1 נסגר: שער G80-text קושר כל בלוק טקסט ומתמטיקה מודפס ב־sheet.pdf (גבעול, סעיף, מפתח) לטקסט המאומת — שכבת הטקסט, רסטר של אזור הבלוק ובדיקה סמנטית של מספרים, משתנים, פעולות, יחסים ויעדים; בבנייה (יציאה 1), ב־verify_export ובכל תרחיש קבלה של השאלה. 4→9 של Codex ב־PDF בלבד — FAIL. selfcheck_noam_package ו־check_didactic אינם בודקים NEW-1 ואינם שער מסירה לבדם. קבלה ניידת: `python3 acceptance/run.py --deliver <package>/out/deliver` (README.txt, PORTABILITY.txt, LOCK.txt שם). G9-T18, שלושה מספרים נפרדים: פיילוט 458/471 = 97.24%, סינתטי 60/61 = 98.36%, כולל 518/532 = 97.37%, FAIL 0; רמה c לבדה 164/174 = 94.25% (מתחת ל־95%). ניסוח: 0 PASS נשענים על ניסוח ממתין; 201 נשענים על ניסוח שאושר בהחלטות נועם (wspec/approvals/APPROVALS_NOAM.json): הסימן △ תמיד לפני שם משולש; זווית תמיד בשלוש אותיות, ושער G81 נכשל על זווית באות אחת. עדיין ממתין לנועם: שאר ניסוחי התבניות (wspec/PENDING_V610.txt), ה־dialect, צד היחידה העברית, REVIEW דידקטי 15/13/7, BD במודל של a/c q10. פתוח (קטן): טביעת האצבע של הקבלה אינה כוללת את mathsvg.py (ואת figkit, numberline, figkit_plus שנטענים בעצלות) — שינוי בהם אינו נחסם ב־exit 4; הודעת G80 על החלפת סעיפים מתארת שינוי אסימונים ולא החלפה; במפתח c q15, a q8c, c q8b סדר הקרניים הפוך מהגבעול (אותה זווית, אותו ערך); הסוגריים ב־c q14 נשברים בין שורות (כמו ב־v6.10). לא בגרסה: מערכות צירים, גרפים, גופים במסלול המפרט, 143 החבילות. פירוט: REPORT.txt בדוגמה G9-T18-v611-example. בדיקות v6.11: `selfcheck_v611_bind.py`, `selfcheck_v611_accept.py`, `selfcheck_v611_fix1.py` (הסוויטה: 34 הקבצים של v6.10 ועוד שלושה). v6.10-noam למטה נשמר כהיסטוריה.

**v6.10-noam — מצב במסירה (בכנות, 24.9):** `deliver.SKILL_VERSION = "6.10-noam"`. כל 45 שאלות G9-T18 במסלול המפרט. קבלה על השרטוטים כפי שהודפסו ב־PDF, קורפוס קפוא (sha256 d1da60f3…), תרחישי אובייקט ולא תרגילים, שלושה מספרים נפרדים (רץ v6.10): פיילוט 458/471 = 97.24% (יעד 95% הושג; REVIEW 12, FAIL 0, UNSUPPORTED 1), סינתטי 60/61 = 98.36%, כולל 518/532 = 97.37%. רמה c לבדה 94.3%. ממתין לנועם: השימוש ברץ v6.10 להכרעה (הרץ הקפוא של v6.9 נותן 61/532 — חפץ של הרץ), ו־50 PASS שנשענים על ניסוח תבנית חדש (בלעדיהם 408/471 = 86.6%). פתוח: P405 (בנייה בלי שם), S49 (כיתוב אלגברי), NEW-1 (אין בדיקה שהטקסט המודפס הוא טקסט ה־JSON), H3 (רק verify_export לבדו מדלג), var4 (קשת מודפסת שהוסרה בעקביות — רק verify_export תופס). פירוט: REPORT.txt בדוגמה G9-T18-v610-example. בדיקות v6.10: `selfcheck_v610_gaps.py`, `selfcheck_v610_lang.py`, `selfcheck_v610_integ.py`, `selfcheck_v610_fix1.py`, `selfcheck_v610_fix2.py`. הסוויטה המלאה (34 קבצים, להריץ בזה אחר זה): `selfcheck.py`, `selfcheck_noam_package.py`, `check_didactic.py`, `selfcheck_plus.py`, `selfcheck_rectkit.py`, `selfcheck_solidkit.py`, `selfcheck_v6.py`, `selfcheck_v63.py`, `selfcheck_v64_close.py`, `selfcheck_v64_t2.py`, `selfcheck_v64_t2_r1.py`, `selfcheck_v65.py`, `selfcheck_v65_close.py`, `selfcheck_v65_deliver.py`, `selfcheck_v65_x1.py`, `selfcheck_v65_x2.py`, `selfcheck_v65_x2r1.py`, `selfcheck_v65_x3.py`, `selfcheck_v66.py`, `selfcheck_v67.py`, `selfcheck_v671.py`, `selfcheck_v672.py`, `selfcheck_v673.py`, `selfcheck_v68.py`, `selfcheck_v69.py`, `selfcheck_v69_codex.py`, `selfcheck_v69_fix1.py`, `selfcheck_v69_fix2.py`, `selfcheck_wspec_engine.py`, `selfcheck_v610_gaps.py`, `selfcheck_v610_lang.py`, `selfcheck_v610_integ.py`, `selfcheck_v610_fix1.py`, `selfcheck_v610_fix2.py`; מבחני המנוע ב־`wspec_tests/` (test_stage1, test_render, test_check, test_pilot, test_lang — 559) רצים דרך `selfcheck_wspec_engine.py`.

**v6.10-noam — סבב תיקון 2 (24.9):** `verify_export` בודק גם H3 (כל נתון שהשכבה יכולה לסמן נמצא ב־`highlight_given`
וב־`actions.highlight`), N4 (תווית מספרית קשורה ב־`for` לעצם שערכו הנתון הוא המספר המודפס, בכל עותק: `objects.labels`,
`sheet.json`, `visual_model`, שרטוט עזר) ו־W1 (טקסטי `wspec/public_spec.json` הם הטקסטים המודפסים, והקובץ הוא המודל
הציבורי שהמנוע גוזר מחדש מ־`source/level_spec.json`). `selfcheck_noam_package` בודק את אותם כללים כ־K21–K23 (אותו
בלוק קוד בשני הקבצים). יעד סיווג הוא שוב find כמו ב־v6.7.3 (`סוג המרובע ABCD`, הערך `מלבן` רק ב־`sheet.json`);
★ חוזר לשורות המפתח של שאלות אתגר; שורת שטח/היקף של משולש כמו במפתח הבית (`שטח △BOC הוא 12`); טענת חפיפה
היא אי מתמטי אחד. כל ניסוח חדש ממתין לאישור נועם (`wspec/PENDING_V610.txt`). בדיקות: `selfcheck_v610_fix2.py`.

**v6.11 — שער G80-text: ה־PDF המודפס קשור לטקסט המאומת (Codex NEW-1):** `emit_html` כותב `data-bind`
על כל בלוק מודפס (`stem:q2:0`, `item:q2a`, `fig:q2`, `table:q2`, `example:q2`, `answer:q2`), והבנייה רושמת
ב־`build.json text_binding` היכן כל בלוק הודפס (עמוד, תיבה, גרסת WeasyPrint והגופנים). `textbind.py` מוודא את
השרשרת: כל שורת `sheet.json` היא בדיוק HTML של הבלוק שלה ב־`sheet.html`; `sheet.html` מרונדר מחדש, וכל בלוק
ב־`sheet.pdf` מושווה לו בשכבת הטקסט (מספרים, משתנים, פעולות, יחסים — בשמם: `number '4' -> '9'`) וברסטר (200 dpi,
כולל מתמטיקה שמצוירת כנתיבים: סימן זווית, שבר, שורש), וגם שאר העמוד ומפתח התשובות. FAIL או REVIEW: הבנייה יוצאת
1 (`GATES: ... G80-text`), `verify_export` מדווח שגיאת G80, ו־`acceptance/hooks/new1_hook.py` מכשיל/מעביר ל־REVIEW
כל תרחיש קבלה של השאלה. חבילה ישנה (בלי `data-bind`) נקשרת לפי מבנה ה־HTML. בדיקות: `selfcheck_v611_bind.py`.

**v6.9-noam — שאלה מתוך מפרט wspec (BRIEF_ENGINE_PDF):** שאלה יכולה לשאת `spec=` במקום שרטוטי בונה.
המנוע (`wspec/`, wspec-engine-v1) מצייר את השרטוטים, וה־SVG שלו נכנס לדף **בדיוק** (בלי שינוי בית);
הטקסט המתמטי נוצר מהתבניות המאושרות, ומפתח התשובות מהחלק הפרטי. שער **G79-spec** בודק כל שרטוט מנוע על
ה־PDF עצמו (מיקום, גאומטריה, אותיות, כיסוי, תשובה, OCR); FAIL עוצר את הבנייה, REVIEW משאיר את הרמה
לא מאושרת עד `accept_review`. `noam-ai.json` נושא את עצמי המנוע (מזהה → `parts`), ו־`tools/highlight.py`
מדגיש מתוכו בלבד. שאלה בלי `spec` נבנית בדיוק כבעבר. פירוט בסעיף "v6.9-noam" למטה; בדיקות: `selfcheck_v69.py`, `selfcheck_v69_codex.py`, `selfcheck_v69_fix1.py`, `selfcheck_v69_fix2.py`, ומבחני המנוע `selfcheck_wspec_engine.py` (541, `wspec_tests/`).

**v6.9-noam — מצב במסירה (בכנות, 23.9):** קבלה על השרטוטים **כפי שהודפסו ב־PDF**, קורפוס קפוא (sha256 d1da60f3…), מכנה 532 = תרחישי אובייקט, לא תרגילים: PASS 135 · REVIEW 0 · FAIL 0 · UNSUPPORTED 397 = 25.38% — **יעד 95% לא הושג**. רק 9 מ־45 שאלות G9-T18 עברו למסלול המפרט (a q1 q5 q9, b q4 q7 q9 q10, c q1 q5); 395 תרחישים שייכים לשאלות שנשארו במסלול הבונה, ועוד S49 (כיתוב אלגברי) ובנייה אחת בלי שם (P405). OCR מאשר רק את החלק הלא־עברי של תווית מעורבת; יחידה עברית (ס״מ) נבדקת בסדר האותיות לפי x, לא ב־OCR. פתוח (לא נסגר בגרסה זו): חלק בלי span / אובייקט בלי כל חלקיו עובר את הבודקים (C1r2); verify_export אינו דורש `figures/<id>.map.json` (E2); צד היחידה בתווית עברית (המספר משמאל ליחידה) ממתין להחלטת המחבר; ה־dialect הוצמד מחדש בידי סוכן (9f58d449) וממתין לאישור המחבר; ניסוח תבניות (∡BAD / ∡ABC במקום ∡A / ∡B), שברים הפוכים בגזעי הבונה (a q8, q14 — כמו ב־v6.7.3), צלעות מקבילית נתונה אינן ב־highlight_given (a q5). פירוט: REPORT.txt בדוגמה G9-T18-v69-example.

**v6.7.1-noam — מדיניות דידקטית (BRIEF_V671):** השרטוט ההתחלתי נקי וניטרלי;
`to_construct`, שכבת המחשה כללית `visual_model` (highlight_given, שרטוטי עזר כ־patch, פעולות סגורות), `didactic.json` פרטי,
בלוק `curriculum` ו־`check_didactic.py`. פירוט בסעיף "המדיניות הדידקטית"
ב־`references/noam-ai-deliverable-he.md`.

**סגירה (22.9):** קשתות זווית מקושרות לנתון (M1), `shapekit.segment`/`point` (R1), `check_didactic` D11
(טענה ככתובה כעובדה — FAIL ו־deliver מסרב). פתוח: אין סוג יעד "חשבו" (to_prove=[]). פירוט ב־INSTALL.md.

(גרסה v6.7-noam: מנוע v6.7, חוזה נועם AI של v6.8, והמפרט הסופי של המחבר —
`noam-ai.json` כרשימה לבנה ובודק עצמאי. בקובץ `deliver.py`: `SKILL_VERSION = "6.7-noam"`.)

**r1 (אימות חוזר):** הבודק העצמאי מחזיק סכמה לבנה משלו — כל מפתח שאינו
בסכמה נכשל בכל עומק (K2), גם `answer_text`, `תשובה`, `md5`, `generated_at`;
ערכים: גיבוב של 32+ ספרות הקס, `/home/`, `~/`, חותמת זמן (K3); טענה כמחרוזת
או מסוג לא מוכר נבדקת לפי השמות שבה (K6); עצם בלי `svg_xy` נכשל (K7).
`plane(sketch=True)` מייצא `view.sketch`; בציר מספרים לכל תווית `text` ולנקודה
`letter`; תחת STRICT מספר מודפס בלי `for` לא נמסר.


## חובה לאתר נועם דורון: חבילת נועם AI

**v6.7.3-noam (סופי, 22.9) — בכנות:** `deliver.SKILL_VERSION = "6.7.3-noam"`. נבדק על G9-T18 ו־G7-T08 (a/b/c):
verify_export 0, selfcheck_noam_package 0, check_didactic FAIL 0 (REVIEW בלבד). הסוויטה כולה ירוקה מפריסה נקייה.
**עדיין פתוח (verify_r2):** ערך אורך ביחידות מורכבות ('6 ס"מ ו-4 מ"מ', גם במילים) אינו נתפס (V2-M1); עשרוני
בנקודה מובילה ('.6') אינו נקרא (V2-M2); שבר מפוצל על שלוש תוויות ('3' '/' '5') אינו מחובר (V2-M3); ביטוי ספרות
ששווה לערך ('6+6', '2·3.2') אינו נתפס בתווית חופשית (V2-S1); עריכת sheet.json אחרי הבנייה אינה מזוהה — hash
של build.json אינו נבדק (V2-m1; קובץ פרטי, התלמיד אינו רואה).

**v6.7.2-noam — מטרות חישוב / מציאה (BRIEF_V672):** `{"type": "find", "quantity", "of"}` ב־to_prove;
הערך פרטי (sheet.json); פירוט ב־`references/noam-ai-deliverable-he.md`. `selfcheck_v672.py`.

**v6.7.2-noam (סגירה, 22.9) — בכנות:** נבדק על G9-T18 ו־G7-T08 (a/b/c): verify_export 0, selfcheck_noam_package 0,
check_didactic FAIL 0. תוקן בסגירה: מספר שנת צירים (lbl-x8, lbl-ym3, lbl-8 בישר מספרים) אינו נחשב ערך יעד מודפס (f_svg; selfcheck_v672 I1-I6).
**עדיין פתוח:** f_json אינו קורא visual_model.relations / figure.constraints ומתיר כל מספר שמופיע ב־given של השאלה —
ערך יעד יכול לדלוף דרכם (M1); בטבלאות אינו קורא value/text/label של תאים אחרים ולא עצמי label (M2);
אינו קורא שרטוטים של שאלות אחרות (S1); צורה שקולה (0.6 מול 3/5) אינה נתפסת (m1). check_didactic אינו ממפה
"חוצה / אנך / גבהים" ליחסים (REVIEW D4 מיותרים), ו־"קבעו בנימוק אם" אינו נתפס כחישוב (REVIEW D5 לשאלות כן/לא).

**v6.7.3 r1 (22.9) — verify_r1 M1–M5, S1, S2, m1 נסגרו:** מילות השאלה של היעד עצמו (text, intro, טקסט כל סעיף, ראש ושורות הטבלה, caption / title שלה) מדפיסות את הערך רק אם given מוצהר של השאלה נושא אותו מספר, או שהוא שנתת ציר / נתון תרשים של השאלה; סעיף **מאוחר** שבונה על התוצאה = REVIEW. הערך נקרא בכל כתיב: אות צמודה ('ב60%', '6.4ס"מ', '6.4cm'), יחידה אחרת ליעד אורך ('64 מ"מ'), שורש ('√41' מעוגל), שבר מעורב ('6⅖', '6 2/5'), '%60', '600‰', 'a מתוך b', ומילים ('שש נקודה ארבע', 'שלוש חמישיות', 'שישים אחוז', 'שתים עשרה', 'תריסר'). ערך מפוצל על שתי תוויות (זו ליד זו, או זו מעל זו כשבר) = FAIL. נסרקים גם aux (של המודל ושל האיור), visual_model.caption ושדות חופשיים ב־actions. dict בתוך highlight_given מדווח (V3 / K13) ולא מפיל. בדיקות: selfcheck_v673 סעיף F.

**v6.7.3 (תיקון דליפות, 22.9) — M1 M2 S1 m1 נסגרו:** ערך של יעד find מותר ב־noam-ai.json רק היכן ש־given
**מוצהר** (שהטקסט / הטבלה / נתוני התרשים של השאלה מדפיסים את מספריו) נושא אותו מספר, ורק על האובייקט / היחס
של אותו given. בכל מקום אחר בקובץ כולו — relations, constraints, given שקיים רק ב־JSON, תא טבלה (value / text /
label), עצמי label / dimension / tick, שרטוט של שאלה אחרת — FAIL (check_didactic.f_file). השוואה לפי ערך:
3/5 = 0.6 = 60% = \frac{3}{5}. given של אותה כמות שמבקשים למצוא, או given רק־JSON הנושא את הערך — deliver מסרב
(didactic.find_given_faults). מקרה ∠ODC = ∠BAC = 35° נשאר PASS. `selfcheck_v673.py` (38 בדיקות; מול הגרסה
הקודמת כל מקרי הבריחה נכשלים), מורץ גם מתוך selfcheck_v672 (J1).

לפני בניית חבילה חדשה קרא את
[`references/noam-ai-deliverable-he.md`](references/noam-ai-deliverable-he.md).
ה־PDF לבדו אינו תוצר מלא. כל רמה חייבת למסור גם את חבילת `deliver/` של v6.6:
המקור הניתן לבנייה מחדש, `sheet.json`, כל שרטוט כ־SVG מדויק, הקוד שיצר אותו,
`build.json`, ו־`noam-ai.json` ללא תשובות לשימוש באתר.

לכל שאלה מצוירת השתמש בבונה שמייצא עצמים ואילוצים. אין למסור SVG ידני או
צילום שאין להם מזהי נקודות, קטעים, זוויות ויחסים מתמטיים. כתוב `given` ו־
`to_prove` בכל שאלת הוכחה; אל תסמן בציור את מה שהתלמיד נדרש להוכיח. ברירת
המחדל בבנייה היא `STRICT_FIGURES=True`. חריגה מותרת רק לתחזוקת דף ישן, עם
`STRICT_FIGURES=False` מפורש, ואינה חבילה חדשה מוכנה לנועם AI.

לפני מסירה הרץ על כל אחת משלוש הרמות:

```
python3 verify_export.py out/deliver/a out/deliver/b out/deliver/c
```

ואחריו את הבודק העצמאי (ללא ייבוא מהסקיל):

```
python3 selfcheck_noam_package.py out/deliver/a out/deliver/b out/deliver/c
```

אפס שגיאות בשניהם הוא תנאי למסירה. `noam-ai.json` נבנה שדה־שדה מרשימה לבנה:
אין בו תשובות, פתרונות, רמזים, קוד, נתיבים, גיבובים, `built_at` או דגלים
פנימיים; כל `svg_id` שבו קיים בדיוק פעם אחת בקובץ ה־SVG ויושב על הדיו; כל עצם
שנזכר ב־`given`/`to_prove` מוגדר בשרטוט; טבלה או דוגמה מודרכת של שאלה נמסרות
כנתונים.

**v6.8 in one screen (read this before the rest).**
What v6.8 adds: the Noam AI package contract enforced end to end (sections
"v6.8 …" at the end of this file). Proven on ONE complete topic, **G7-T08**
(כיתה ז׳ / 08, levels a, b, c built together by `build_plus.py`): all gates
pass; `verify_export.py out/deliver/a out/deliver/b out/deliver/c` → 0 errors
(45 + 42 + 52 figures, every figure script re-run byte-identical, every
constraint re-measured); `noamchk/audit.py` clean on each level (0 empty
anchors, 0 numeric labels without `for`, no `answer` key, every SVG present).
The final round added: a number line exports its letters (`lbl-A`, `for` the
point) and ties its numbers to their ticks; verify_export refuses a numeric
label without `for` (N3, both JSONs) and a constraint it cannot measure (C1);
a claim is read wherever it stands in the text and in the question's own
text; `to_prove=[]` with no relation symbol in the text is honoured as
"explain" (no report row) unless the text names a relation in symbols or
geometric words. Tests: `selfcheck_v68.py` sections M…Y + Z.

**NOT in v6.8 (known, open):**
- the author's FINAL SPEC (BRIEF_V68 §5) is only partly met: noam-ai.json is
  built as sheet.json minus answers and code, not as a field-by-field
  whitelist — it still carries `built_at`, `source_hash`, `skill_version`,
  `fam` (with a hash), `sheet_id_prefix`, `sheet_svg_id`; and
  `selfcheck_noam_package.py` still imports `deliver` and takes no level
  folders. The release keeps the name v6.8, not "v6.7-noam".
- `euclid.circle_fig`: parts ('centre','two-tangents') export no tangent / no
  radius ⊥ tangent; ('centre','diameter') no midpoint / collinear of O.
- verify_export does not check that every mark (ticks, arcs, right angles)
  has a marked constraint; a tick's `svg_xy` is its edge's endpoints and a
  right angle's is its vertex (the ink is at `ink_xy`; ticks have none).
- the pilot's own open review findings (level content, not the engine):
  see the pilot's REPORT.md (beside the pilot, not in the skill) — e.g. ג׳ 14ב/14ג draw a mirrored L that is not
  the question's polygon, 8ד's bars carry no series, T' prints as 'T in RTL
  text (emit_html), several item figures lean toward the answer.
- charts and probability, question variety, conics (as in v6.7).

**Read this first.** The folder keeps the name `hebrew-math-worksheet-v5`
because the installer expects it; the engine inside is v6.8 (the v6.7 notes
below still describe what v6.7 added). The v5 text below
still holds (content schema, DSL, gates); the v6 sections at the end say what
changed, newest last (v6.7: "v6.7 F", "v6.7 F r1", "v6.7 F r2", "v6.7
close-out").

**What v6.7 adds, honestly.** It closes the v6.6 open findings
(`regen/v66_result.json`, s_open + e_open), tested in `selfcheck_v67.py`
(sections D C A P L R K N F Q V T, every rule PASS + FAIL, each new rule shown
failing on the code before it):

- **determinism** — no clock decides whether a figure renders. describe's
  solid routes, solidkit's failing fit and a refusal's route probe are capped
  by COUNTS (`_SOLID_ATTEMPTS`, `_FAIL_DRAWS`, `_PROBE_MAX`). The wall clock
  is only a safety net (`solidkit.SolidMachineError`,
  `generate.GenerateMachineError`) that says MACHINE PROBLEM and is never an
  AssertionError. `selfcheck_v66` and `selfcheck_v67` were run three times
  each, once with 10 busy loops: all green.
- **flat cone** — a cone whose apex would fall inside its base ellipse is drawn
  with a lower eye (proj tag `cabinet45:right:k0.08`), r and h on dimension
  lines outside with witness lines from the last ink; a cone no view can show
  raises `solidkit.SolidUndrawable` naming a call that renders.
- **angles and proofs** — `∠A` / `$\angle A$` resolve to the one angle the
  figure draws at A (ambiguous ones are reported); `∡`, `\hat`, `\widehat`,
  `Â`, "זווית ישרה", "ישר זווית", `90^o`, "90 מעלות" and the worded forms are
  read as claims; the imperative/past verbs הוכיחו/הראו/נמקו/הסבירו/הצדיקו/בססו
  with כי / ש־ / ":" / מדוע / למה, and "בדקו האם … ונמקו", make a proof item.
  A MARKED claim in any of these forms is refused, with routes that were drawn
  and that say when they change the question's givens.
- **export** — round solids: centre O, rim point R (`seg-OR`, `lbl-OR`), cone
  height `lbl-OS`; a cylinder's h is measured along the drawn generator;
  hand-drawn dimension barbs export as marks and the shaft as a dimension; a
  number on part of a stroke carries `for_part`; anchors carry `data-ink`;
  `export.light_import` keeps attribute assignments and the light script is
  checked in a FRESH process.

**Regression (checked).** ז׳/01 (ported), ז׳/08 and ז׳/47 print PDFs that are
byte-identical to v6.6 (md5 equal; all gates pass on both). Their SVGs render
pixel-identical (200 dpi); ז׳/47's differ only in added `data-ink` and in the
ids of q12b/q12c/q15d's dimension barbs, now exported as 24 mark segments + 6
dimensions instead of 30 `data` segments, and q12's two `L` labels now carry
`for_part` [0, 0.5] / [0.5, 1]. Exports pass `verify_export.py` with 0 errors
(ז׳/08 45 figures / 1016 objects / 65 lettered points / 3 derived; ז׳/01 100 /
1992 / 0 / 0; ז׳/47 76 / 1441 / 375 / 169 derived); every figure script is
runnable (45/45, 100/100, 76/76).

**NOT in v6.7 (known, open after the fix rounds):**
- charts (bar, line, pie, histogram) and probability, question variety (the
  structure bank), conics.
- **infinitive proof wordings** (must): deliver's verb list has only the
  imperative and past forms, so "יש להוכיח כי ∠BAC = ∠EDF", "צריך להוכיח
  ש…", "עליכם להוכיח כי …" and "יש להוכיח כי ∠A = 90°" on a figure that MARKS
  the claim ship with no refusal and no report row. Until fixed: write
  הוכיחו, and never mark what the student proves.
- **readable claims only reported**: "הוכיחו, כי X", "הוכיחו:" + newline + X,
  "הוכיחו כי מתקיים: X", "הראו שמתקיים X", "הוכיחו את השוויון X", "X. הוכיחו.",
  `∠BAC ≅ ∠EDF` / `\cong`, "∠BAC ו-∠EDF שוות", "הזווית BAC והזווית EDF שוות",
  "גודל הזווית BAC שווה לגודל הזווית EDF", and "נתון AB = DE, הוכיחו כי X"
  (a sentence opening with נתון is skipped whole) get only a "worded in a form
  deliver cannot read" row, not a refusal, even when X is marked.
- **false report rows**: items like "הסבירו כיצד פתרתם…" / "מדוע …?" add
  `given_on_proof_item` rows advising `∠BAC = 90°` (ז׳/08 3, ז׳/01 2, ז׳/47 5
  rows; v6.6 had none). They are noise; read the row's claim before acting.
- an ambiguous single-letter angle prints in the report row as
  `angle(A,,A,deg,90.0)` (the item still ships; only the row flags it).
- a SHORT cylinder (h < 1.5 r): the JSON h dimension's `measures_svg_xy` still
  ends at the top centre O1 (no ink there), while the drawing ties it to the
  rims with witness lines.
- test gaps: `selfcheck_v67` T1 does not check WHICH generator the cylinder's
  h is measured along (a flipped side filter passes); no test fails when the
  "נתון/ידוע sentence is never a claim" rule is removed.
- carried over: a pyramid/prism right angle in 3D exports as a mark
  (`space: true`), not a perpendicular constraint; solids' scripts print a
  trailing `<!--v3d:...-->` after `</svg>`; `plane(values=...)` labels have
  no `for`; sheets written before v6.5 declare no given/to_prove, so their
  constraints export as `derived`.

## Earlier release notes (v6.6)


**Read this first.** The folder keeps the name `hebrew-math-worksheet-v5`
because the installer expects it; the engine inside is v6.6. The v5 text below
still holds (content schema, DSL, gates); the v6 sections at the end say what
changed, newest last (v6.6: "v6.6 S", "v6.6 S round 1", "v6.6 E").

**What v6.6 adds, honestly.** It closes the open v6.4 / v6.5 findings before
page production, in two parts:

- **the export** (`selfcheck_v66.py E`, `F`) — equal-angle arcs are a marked
  claim; `given` / `to_prove` read the sheet's own `$...$` notation and a
  number written first; a given declared on a proof item is reported; one
  fact is one constraint entry; ids unique per SHEET (the sheet HTML carries
  `<fig>__<id>`, figure files keep the short id, `sheet.json` records both);
  labels on a side or a dimension carry `for`; ids sit on the ink (or a `<g>`
  wrapping it); solids export in the question's units with every vertex a
  named point (`pt-A`, `xyz`) and runnable `figures/<id>.py`; `source/` is
  portable and `source_hash` does not depend on the build folder (a stray
  `/tmp` path in the source is refused).
- **solidkit / shapekit / describe** (`selfcheck_v66.py S`, `R`) —
  `edge_label` idempotent, refusals never cut and naming a route that was
  tried and renders, a same-face `space_diagonal` refused with a working
  call, the cone's liquid washed, every liquid fill luminance >= 0.92,
  `variant='right'` for a kite (a parallelogram refuses it), and
  `describe.py` reaches solids (`תיבה ABCDEFGH; AB = 4; ...`, `גליל r=2 h=5`,
  `פירמידה ריבועית`, `מנסרה משולשת`), growing the drawing before it hides a
  datum.

**Regression (checked).** ז׳/01 (ported) prints the same PDF as v6.5 byte for
byte. ז׳/08's PDF is pixel- and text-identical on all 12 pages at 200 dpi; its
bytes differ only by five empty `q Q` pairs (the empty `<g>` id wrappers).
ז׳/47 is now drawn on `solidkit`: 11 pages, every number and the answer page
unchanged, items on pages 3-7 break at different places, some prisms are drawn
in another pose or with a number on the equal parallel edge. Exports of all
three pass `verify_export.py` with 0 errors (ז׳/47: 76 figures, 1441 objects,
375 named vertices, 169 derived constraints; 76/76 figure scripts re-draw
their `<svg>` exactly).

**NOT in v6.6 (known, open):**
- charts (bar, line, pie, histogram) and probability, question variety (the
  structure bank), conics.
- `describe` fits a solid inside a wall-clock budget (~2.7 s, a failing fit
  stopped after 0.5 s): on a busy or cold machine the SAME text can render in
  one run and be refused in the next (e.g. `גליל r=10 h=1`), and the
  `selfcheck_v66.py R` timing checks can then fail. Rebuild, or write the
  «...» text the refusal names. `describe.solid()` (the add-on route) draws
  at tier 'side' only.
- a very flat cone (apex inside the base ellipse, e.g. r=10, h<=3) is drawn
  as an ellipse with no slant sides, and its h dimension reads against
  nothing; `describe` can ship it. Avoid such data.
- `to_prove` written with single-letter angles (`∠A = 90°`, `∠A = ∠D`) is
  NOT checked against the marks (listed as unchecked only): write `∠BAC`.
  Proof texts with a maqaf (`הוכיחו ש־∠...`, `הראו ש־`), `בדקו האם ...` or
  the worded form are not read as claims.
- export gaps: a cone / cylinder's r and h numbers have no `for` and its
  centre is unnamed; a pyramid's 3D right-angle strokes and the dimension
  arrowheads on raw `figkit.Figure` pages (ז׳/47 q12b/c, q15d) export as
  `data` segments; a number on HALF an edge names the whole edge; solid
  vertex anchors carry no `data-ink`.
- a light figure script (`export.light_import`) does not replay a level's
  module-level attribute assignments (`figkit.INK = ...`); the byte check
  runs in-process. Solids' scripts print a trailing `<!--v3d:...-->` comment
  after `</svg>` (the `<svg>` element is identical, the file is not).
- an author's `edge_label` refused as "read against nothing" names
  `inside=<face>` / `pose=` as placeholders, not a value that renders.
- sheets written before v6.5 declare no given/to_prove, so their constraints
  export as `derived`.

## Earlier release notes (v6.5)

**Read this first.** The folder keeps the name `hebrew-math-worksheet-v5`
because the installer expects it; the engine inside is v6.5. The v5 text below
still holds (content schema, DSL, gates); the v6 sections at the end say what
changed, newest last (v6.5: "stable element ids", "v6.5 X2", "v6.5 close-out").

**What v6.5 adds, honestly.** Nothing is drawn differently: a sheet built with
v6.5 prints the same PDF, byte for byte, as v6.4 (checked on ז׳/08, ז׳/47 and
ז׳/01). What is new is what ships beside it:

- **ids** — every point, segment, polygon, circle, arc, mark and label in every
  builder's SVG has an `id` that is stable across rebuilds (`pt-A`, `seg-AB`,
  `lbl-AB`, `ra-Q`; an unnamed object gets a hash of its geometry, never an
  index). An edge that is drawn as part of a polygon gets an anchor on a
  transparent `<g class="ids">` layer, and that anchor must sit on real ink.
- **the objects export** — per figure, what it drew, with `xy` (the question's
  units), `svg_xy` (the file's viewBox) and `view.data_to_svg` to convert.
- **constraints** with `source` = given / to_prove / derived / decorative and
  `item`; `given=` / `to_prove=` in the content schema (`deliver.py` docstring).
- **the deliverable package** (`deliver.py`, run by every build): `sheet.pdf`,
  `source/`, `sheet.json`, `figures/<id>.svg`, `figures/<id>.py`, `build.json`.
- **`verify_export.py`** — an outside check of a written package (xml.etree, no
  skill imports): ids, positions, ink, the coordinate map, every constraint
  re-measured, to_prove unmarked, hashes. `python3 verify_export.py <out>/deliver/a`.

**Not yet:** charts and probability, question variety. (`describe.py` for solids: v6.6 S.)
Sheets written before v6.5 declare no given/to_prove (all constraints are
`derived`), and few plane figures export constraints yet (ז׳/08: 3 for 45
figures). A figure drawn on a raw `figkit.Figure` exports unnamed segments and
no named points, and its `figures/<id>.py` is marked not runnable.

## Earlier release notes (v6.4)

**Read this first.** The folder keeps the name `hebrew-math-worksheet-v5`
because the installer expects it; the engine inside is v6.4. The v5 text below
still holds (content schema, DSL, gates); the v6 sections at the end say what
changed, newest last.

**What v6.3 is for, honestly.** It draws three things well: **coordinate
planes**, **number lines**, and now **plane-geometry shapes**. Four things are
new since v6.2 and nothing else changed:

- `shapekit.py` — every base shape a ז׳–ט׳ sheet needs, built from its own
  numbers and verified against them, plus one set of add-ons that works on all
  of them. It replaces the package-local drawing helper: `euclid.quad` and
  `euclid.triangle_with` each drew ONE fixed vertex list per kind, so a
  "scalene triangle" was always the same triangle. `euclid.py` and `rectkit.py`
  are untouched and keep their exact signatures.
- **the tick-vs-point fix** — an equality tick on a side that a question puts
  its own points on used to be refused, and the documented escape was
  `marks=False`, which DELETES the ticks and the right angle. The tick now
  moves off the midpoint when that still reads as naming the whole side, and
  otherwise becomes a bracket spanning the side end to end. `marks=False` is
  still available and is no longer the cure.
- `describe.py` — a figure from Hebrew sentences, one datum per sentence,
  against an EXPLICIT grammar. A sentence outside the grammar is refused with
  the whole list of what is understood; nothing is guessed or silently skipped.
  Hebrew goes in; the SVG carries Latin letters, digits, ° and U+2212 only.
- **the generator** (`generate.py`) — it solves the description's constraints,
  refuses a degenerate or self-contradicting figure with a message naming the
  fix, is deterministic from a seed, is bounded by a hard time cap, offers
  `alternatives(n)` (which also detects data that does not determine the
  figure), and `violate(constraint)` for "find the mistake" items.

It still does **not** do solids (prisms, cylinders, pyramids — the projection,
when it comes, will be CABINET), the `euclid` / construction rewrite, charts
(bar, line, pie, histogram), or question variety (the structure bank of
question shapes). A package that needs a solid draws it in a package-local kit
on `figkit.Figure`, as `P/regen/work/z47_a` does.

**What stage 1 does.**
- *Coordinate planes* (`figkit_plus.plane`, `wide`, `figkit.coord_plane`):
  axis numbers are pinned to their ticks, numbered every 2 squares on a long
  axis and every 1 on a short one unless `step=` says otherwise. A number that
  meets a line moves a little (along its axis, across it, diagonally), always
  nearer its own tick than any other; failing that the step coarsens, the
  figure grows within `max_width`, and only then is the figure refused, with a
  message that names a call which renders. **No data stroke is ever cut and
  no number is ever deleted.** `curves=` plots `y = f(x)` or a point list as
  one uncut path clipped exactly to the window, with poles and jumps broken
  correctly; `intersections(f, g, x0, x1)` gives exact crossing points.
  Markers filled/open/tri/square/cross, U+2212 minus everywhere,
  `number_pt=` / `new_sheet(number_pt=7.6)` for one printed number size per
  sheet.
- *Number lines* (`numberline.py`; `figkit.number_line` is a shim over it):
  integers and fractions (stacked), find-the-scale (`sparse=True`), jumps and
  chains with nested arcs, inequality sets (rays, intervals, union,
  intersection, all reals, ∅), rows (`stack`), `zoom`, `double`, vertical
  lines, sign charts, bars from zero, reference lines, and critique lines drawn
  wrong on purpose (`asks=['find_error']`). Placement tiers item/side/block/
  strip with one printed number size.
- *Checks*: `svgcheck.py` reads the finished SVG independently (struck text,
  numbers off their ticks, lost ink, reading merges, markers, marks against
  geometry). 294 checks in `selfcheck_v6.py`.

**What is NOT in stage 1** (do not expect it, do not build on it):
- **Solids** (prisms, cylinders, pyramids). The house projection will be
  CABINET; no solid builder ships yet. A package that needs one still carries
  its own kit.
- **Analytic curves beyond `plane(curves=)`**: no parametric or implicit
  curves, no conics by equation, no asymptote/tangent helpers, no shading
  between curves.
- **The `euclid` rewrite**: `euclid.py` is the v5.6 builder with the stage-1
  mark checks (E5) on top; it has not been rebuilt on the new label rules.
- **Charts** (bar, line, pie, histograms, stem-and-leaf): no builder.


Successor to v4.3. Same content schema, same authoring DSL; nothing you have
written needs to change. What changed is that the sheet now renders in the
font it claims, and four new gates read the finished PDF geometrically.


## ידע דידקטי — מה לקרוא לפני שכותבים

שני קבצים בתיקיית הסקיל נושאים את הידע הדידקטי, והם נפרדים מ־`curriculum_tashpaz.json`
שנושא את פריסת ההוראה הרשמית.

**`didactic_principles.json` — קרא תמיד.** תמצית מבצעית: עשרה עקרונות כתיבה ולכל אחד
מה הוא אומר ומה הוא מחייב בדף, חלוקה ליסודי ולחטיבה, מבנה התגובה לטעות, ומצב הרישוי.
הקובץ קטן, ונועד להיקרא בכל בנייה של דף.

**`references/didactic-sources-he.md` — קרא כשצריך את הנימוק המלא.** המחקר השלם של
מקורות הידע הדידקטי בעברית: מה מכסה כל מקור, אילו רמות אומתו בו, מה מצבו המשפטי,
ואיפה פערי הכיסוי. פנה אליו כשנדרשת החלטה על מקור, כשיש ספק לגבי שיוך כיתה, או כשעולה
שאלה של זכויות.

מה זה משנה בפועל בדף:

- השאלה הראשונה בכל חלק נשענת רק על ידע קודם ודאי; מה שחדש מופיע בדוגמה המודרכת.
- בנושא חזותי לפחות שאלה אחת בכל חלק נפתרת מתוך הייצוג ולא מתוך נוסחה.
- בשברים, ביחס ובאחוזים המשמעות באה לפני האלגוריתם.
- בכל דף לפחות שאלת ביקורת אחת: התלמיד בוחן טענה או פתרון שגוי ומסביר את הטעות.
- בכל דף לפחות סעיף אחד של בדיקה או סבירות.
- רמת מצוינות מעמיקה באותם כלים של הכיתה. אין להכניס חומר מחוץ לתוכנית.

**רישוי.** העקרונות נוסחו מחדש. אין להעתיק פסקאות ממסמכי משרד החינוך, ממאגרי המרכזים
או מחומרי מאור ומשימטיקה אל תוך דף או אל תוך פרומפט. ייבוא שיטתי של תוכן מוגן דורש
אישור כתוב לכל מקור בנפרד.


## Why v5 exists

A full audit of 447 shipped sheets (3,528 pages, Sep 2026) found 1,548
defects. They were not 1,548 separate mistakes. A handful of causes produced
them, and the largest cause was silent.

## What was fixed

**1. The silent font fallback — the root cause.**
`ASSETS` pointed at `~/.fonts`, a directory that does not exist on the
author's machine. All three `@font-face` rules failed without error, David
Libre never loaded, and every sheet rendered in whatever serif the OS
offered. The audit found DejaVu, FreeSerif, NimbusRoman and Noto across the
corpus. This is also why minus signs misprinted: DejaVu's U+2212 sits low
and short against David Libre's digit metrics, so `-5` printed as a
struck-through 5, and 59 sheets carried that defect. The fonts now ship in
`assets/` next to the emitter, and a missing font is a build failure rather
than a silent substitution.

**2. `★` and `□` came from a Japanese font.**
`.sym` asked for "DejaVu Serif", which is not installed either, so the
generic `serif` fallback resolved to Hiragino Mincho. Both glyphs now come
from a bundled face.

**3. The star that touched the first letter.**
The marker gutter was 30pt. A two-digit marker `(12)` measures 20.2pt and
its star adds 10pt more, so on every starred question numbered 10 or above
the star printed against the first Hebrew letter. Measured in ז/25, ז/27
and ט/02. The gutter is now sized for the widest real marker with a 4pt air
text.

**4. The copyright line never printed.**
Two `@bottom-right` rules were declared in the same `@page` block. The
second won, so the S-26 notice was dropped from every sheet the skill ever
produced. It now sits bottom-left, uncontested.

**5. The `.1` defect, where it actually survived.**
v4.3 closed this for question numbers by switching them to `(N)`: a mirrored
parenthesis pair has no dangling neutral, so nothing can flip. Sub-item
labels were left as `lab.` and the identical bug lived on there whenever the
label was a digit. `1.` is an LTR digit run followed by a bidi-neutral
period; UAX#9 rule N2 gives that period the paragraph direction, RTL, and it
lands to the LEFT: `.1`. A Hebrew label is immune, because the letter is
itself strong RTL. Verified by render, then fixed by label type:

| label | emitted | why |
|---|---|---|
| א ב ג | `א.` | house style, renders correctly |
| 1 2 10 | `(1)` | same cure as the question number |
| A B | `(A)` | same reason |

The sub-item gutter grew from 19pt to 28pt in the same pass, because `(10)`
measures 20pt and printed on the first letter once the parentheses were in.

**6. Answer rows carrying a stacked fraction (preventive).**
Line height in the answer key raised from 1.40 to 1.72, so a wrapped row no
longer prints tight against the row beneath it.

## figkit — the figure engine

`figkit.py` is new in v5 and is where the audit's largest defect class is
actually prevented rather than merely detected.

**Labels are placed, not posed.** Every label is registered with an anchor
and a preferred side; the engine then searches outward for a position that
no stroke crosses and no other label overlaps. `trapz_kit` already looked for
this collision, but it raised and left the author to nudge the figure by
hand, and it exempted vertex letters from the sweep entirely — which is
exactly where the 120 sheets went. Here every label is swept, and a vertex
letter that would sit on the hypotenuse is moved off it.

**Axis labels keep to their own side.** A tick label may be pushed further
out but never flipped across the axis: given a free ring the solver once
dodged a plotted line by putting the x-label `-1` above the axis, where it
reads as a y-value. `sector` caps the swing.

**Figures are drawn from the numbers.** `triangle(sides=(3,4,5))` computes
its own coordinates and re-measures them before emitting; a drawing whose
ratios contradict its givens raises. An impossible triangle raises too,
rather than posing a question with no answer.

**The font floor is measured where the reader sees it.** A label's effective
size is `size × display/viewBox × 0.75`pt, so a 12-unit label in a 300-unit
viewBox shown 150px wide reaches the page at 4.5pt. That number, not the raw
attribute, is checked against `MIN_PT` (7.0).

```python
from figkit import triangle, rect, axes, number_line

triangle(sides=(3, 4, 5), right_angle="B", width=150)
triangle(sides=(6, 6, 8), ticks=[("A", "B")], width=150)
rect(12, 5, diagonal="AC", width=170)
axes((-5, 5), (-4, 4), points=[((2, 3), "A")],
     lines=[((-4, -3), (4, 4), "f")], width=300)
number_line(-5, 5, marks=[(-2, "A")], width=300)
```

`python3 figkit.py` runs its own self-test: it re-sweeps each finished SVG
for struck labels without reusing the solver's bookkeeping, because a gate
that trusts the thing it is gating is not a gate.

## The new gates

All four read the finished PDF. They are in `gates_runner.py` and run with
the existing ones; as before, `SKIPPED` counts as failure.

| Gate | Blocks | Found in the audit |
|---|---|---|
| G70-font | body not set in David Libre, or any unpinned fallback face | root cause of 59 minus-sign defects |
| G72-struck | a glyph whose ink is crossed by a stroked path | **120 sheets — the largest single class** |
| G73-pages | a page footer whose total disagrees with the document | the "עמוד 5 מתוך 6" on five-page files |
| G74-gutter | *(source-side)* a marker wider than the gutter that holds it | the ★-on-first-letter defect |
| figkit | *(source-side)* struck labels, sub-7pt text, out-of-scale drawings | 120 + 71 + 59 sheets |

G74 runs at source, not on the PDF, and that is deliberate. The first
attempt measured the gap in the finished file and had to be thrown away: an
inline answer label followed by a space is geometrically identical to a
marker touching the text, because the space belongs to the neighbouring
span's bounding box. Both read 0.00pt. G74 instead measures the marker
against the real advance widths in the bundled font before anything is
rendered, so it is exact and cannot produce a false positive.

G72 is the one that matters most. A vertex letter, an axis number or a
length label with a line through it extracts perfectly and prints
ambiguously: `60` on a diagonal reads as `-60`. No text-layer gate can see
it. G72 sweeps every stroked path against every glyph box, shrunk to the
ink so a label legitimately resting against an edge does not trip it.

## Running the gates

```
python3 gates_runner.py out/*.pdf
python3 gates_runner.py --selftest
```

## Requirements

WeasyPrint needs its system graphics libraries. On an Apple Silicon Mac with
Homebrew they are present but not on the default search path, so run the
build with:

```
DYLD_FALLBACK_LIBRARY_PATH=/opt/homebrew/lib python3 build.py ...
```

Python packages: `weasyprint`, `pymupdf`, `matplotlib`.

## What v5 does NOT fix

The audit also found defects that live in sheet content, not in the
generator: wrong answers in the key, questions that cannot be solved from
the data given, and figures copied from another question. Those need the
author, not the emitter.

figkit only protects figures BUILT WITH figkit. A raw SVG string passed to
`fig=` bypasses it entirely, and most of the existing corpus is raw SVG. For
those, G72 in `gates_runner.py` is the backstop: it reads the finished PDF
and fails the build on a struck glyph whatever drew it.


---

# v5.1 — what 137 rebuilt packages taught the emitter

v5 was written from the audit. v5.1 was written from the repair: 137 packages
of that corpus were re-authored with v5, and every one was then read by a
second agent that had not built it. That review is where these came from. The
pattern worth naming: **most of them are cases where the generator forced an
author to damage the sheet.** A tool that cannot express something correct
does not stay neutral — it pushes the author into something wrong.

## Rules that were making sheets worse

**The instruction box was mandatory.** `L['rule']` raised `KeyError` when it
was absent, so an author rebuilding a sheet that never had a grey box wrote
one in house style to make the build run. The generator was manufacturing
text the author never wrote. It is optional now; omit the key and no box is
emitted.

**A question had to have lettered parts.** `items=[]` crashed, so a source
question that is one plain instruction got an invented `א.` that the page
never had. Now `items=[]` with `space=40` gives writing room and no label.

**A subscript printed as ink.** `x_{1}` came out as those literal characters
— the same markup-leak class as `\sqrt` — and inside `\sqrt{}` it was
refused outright. One package wrote `BP_min` out in words to avoid it. Both
sides now render it, and the writing blank `___` is still not a subscript.

**A figure label could not carry an exponent.** U+00B2 is not in the bundled
face and a label bypasses the maths emitter, so `y = x²` was dropped from a
band title in one package and from a parabola in another. `^2` and `^{10}`
now render as a real raised run in the bundled font.

**Ratios and scales were forced into fractions.** The division gate blocks a
colon between digits, which is right for `81 : 3` and wrong for `1:50000`.
Sheets printed scales as built fractions, which is not how a scale is
written. `\rat{1}{50000}` prints a real ratio colon; the gate accepts that
one glyph in ratio shape only, so a division still fails.

**Clock times were deleted to pass a gate.** The exemption keyed on a word
boundary, which does not exist between a Hebrew letter and a digit, so
`בשעה 6:00` failed and an author removed the times from the sheet. The
exemption now anchors on the digits.

**A level whose source filename carries no level token was never verified.**
Two of a package's three files both said "רמה א"; the word comparison
silently covered nothing and reported a quiet note. Unmatched now reads as
`UNVERIFIED` and counts as a failure, and `content.py` may declare
`SOURCE = {"a": "<filename>.pdf", ...}` to say which file is which.

## Layout defects the rebuild reproduced

**The dashed writing rule cut across side figures.** A floated figure does
not shorten a full-width border, so the rule ran straight through the
drawing — the audit's own "dashed rule crossing a figure" class, 45 files,
reproduced by the fix. Painting an opaque ground on the float does not cover
it. A side figure is now its own column.

**Gridlines ran through the axis numbers.** Measured with the audit's own
instrument, the rebuilt sheets scored *worse* than the originals on crossed
text: 2,982 against 1,951. The gates could not see it because they ignore
light strokes by design. Gridlines are now cut around every label, and the
same measurement reads 163.

**Two labels could read as one.** The placer kept labels 1.5 figure units
apart, which at a small display scale is under a point on paper; a review
found a vertex letter and a value 2.6pt apart, reading as `C 5 G`. The pad is
a point floor now, and `verify()` refuses a figure that still violates it.

**Writing space was being traded for page count.** `space_scale` was added to
recover a page and immediately drifted to 0.38 in one package — a third of
the room the author specified — purely to make the sheet look as short as the
original. It is floored at 0.75.

**The worked-example heading printed its markup as ink.** `example=(title,
lines)` escaped the title instead of emitting it, so a heading reading
`כאשר המקדם $b$ הוא אפס` put the dollar signs on the page. Found by measuring
the finished sheets with the audit's own instrument, not by review — one sheet
showed it, and 98 of 117 packages use that heading, so every one of them
carried the same risk. It goes through the maths layer now.

## The one class the emitter cannot catch

Six figures in one package contradicted their own question: a cylinder drawn
at half its stated height because the diameter was passed to the radius
parameter, rhombus diagonals drawn the wrong way round, a point placed by a
fixed fraction instead of by the given angles. **In every case the original
sheet was correct and the rebuild broke it.** figkit verifies what it draws
itself; a package-local helper is outside it. The only thing that caught
these was a second reader computing from the data what the figure should show
and measuring what it does show. Budget for that step.

## selfcheck.py

```
python3 selfcheck.py
```

Thirteen checks, each with a case that must pass and a case that must fail —
a rule with no failing case proves nothing. Every check names the defect that
put it there. Run it after any change to the emitter, the gates or figkit.


## v5.1 — the second review

After 140 packages shipped, four reviewers were pointed at the delivered
package itself. Ten of their findings reproduced. The three that mattered:

**Every heading was escaped, not emitted.** The `<h1>`, the level line, the
subtitle and the answer-key note printed their own markup as ink — the
largest text on the page. The part band and the worked-example heading had
the same bug and were fixed one at a time; this is the whole family, fixed
together and covered by one check.

**The struck-label gate was blind to curves.** It collected straight
segments and rectangles only, so an arc, a circle, a parabola or a pie slice
could run through a label and the page reported "no stroked figure on any
page". This is the gate this file calls the one that matters most, and the
corpus it backstops is full of curves. Both sweeps — the PDF-side gate and
figkit's own — now flatten curves and check them like any edge.

**A two-letter Hebrew sub-item label printed reversed.** `יא` and `יב` — the
tenth and eleventh items of a long question — fell through to the
parenthesised branch, whose CSS reverses whatever it is given, and came out
as `(אי)` and `(בי)`. The file's own comment warned about exactly this; the
pattern that decided which branch to take did not.

Also fixed: `\pm` did not exist, so the quadratic formula — named five times
in the curriculum file shipped inside this skill — could not be written; a
question with no lead sentence, a part band with no question range, and a
sheet with no answer key all raised or printed an empty page, and each one
pushed the author into inventing text; and `mathsvg.py` looked for the
bundled fonts three directories above the package, the same shape as the
font-path bug this version exists to fix.

**`build.py` now ships.** This file told the author to run it and it was not
in the package, so every package in the corpus rebuild grew its own copy —
and three of them diverged in ways that mattered: one disabled half a gate,
one widened a check until its own output passed.

**Raw SVG could still pull a fallback font.** `fig=` splices its SVG in
untouched, and a `<text font-family="serif">` inside it resolves to whatever
the OS offers — Times New Roman here — which is the silent fallback this
version exists to end, arriving through the one door nobody guarded. Two
assessment packages built from their own sources failed G70 on exactly that.
Generic families in a figure are now pinned to the bundled face, and a
`<text>` that names no face gets one.

### Known and not fixed

- `check_render_integrity.g46`'s figure-proof count has no producer: nothing
  emits the anchors it counts, so that half of the check never runs.
- `check_render_integrity._fonts()` shells out to poppler's `pdffonts` and has
  no caller; it is dead code from before pymupdf.
- Characters the body face lacks are pinned to a sans stack, so `≠ ≈ → ∈`
  change texture mid-formula.
- `TEXT_TEXT_OVERLAP` in the audit instrument stays high on correct sheets: it
  compares whole span boxes, and in bidi text those overlap constantly.


---

# v5.2 — a sheet is not one drawing repeated

Three analytic-geometry sheets (כיתה ח׳, "סינתזה גאומטרית במערכת צירים",
Sep 2026) were rebuilt with v5.1 and passed every gate in this file. Their
author opened them and saw the same rhombus on five questions of רמה א׳, the
same tilted square on six questions of רמת מצוינות, and three questions of
twenty on each sheet with no drawing at all. The audit's instruments count
defects IN figures — a struck label, a fallback face, a drawing out of scale.
Not one of them counts figures, so a sheet that reuses one correct SVG on
every question scores perfectly.

## G75 — figure variety (source-side, every build)

`emit_html.assert_figure_variety(L)` runs from `build_html`, next to G74. It
reads the level dict, not the PDF, so it is exact and cannot be argued with.

| check | rule | the case it was written for |
|---|---|---|
| REUSE | one SVG serves at most **2** questions | the same rhombus on questions 1, 2, 10, 11, 15 |
| COVER | on a figure sheet, at least **60%** of the questions carry a drawing | a geometry sheet with three text-only questions of twenty is the floor, not the target |
| OBJECTS | a figure sheet with 8 or more drawn questions shows at least **3** different objects | one square dressed six ways |

A **figure sheet** is one whose title or part bands name geometry —
גאומטריה, מערכת צירים, וקטורים, משולש, מרובע, טרפז, מקבילית, מעוין, מלבן,
מעגל, גליל, פיתגורס, דמיון, חפיפה, זוויות, תיבה, פירמידה … (`FIG_KEYWORDS`
in `emit_html.py`) — or one where 40% of the questions already carry a
drawing, whatever it is called. 60% is the curriculum file's own trigger
for "a geometry sheet", applied in the other direction: if the sheet is
about figures, it draws them.

An **object** is `figkit.figure_family(svg)`: the polygons of the drawing,
translated to the origin and rounded. A rhombus and the same rhombus with a
diagonal drawn in are ONE object; a rhombus and a trapezoid are two. A raw
SVG with no polygon is keyed by every dark stroke it contains, the same way.

`figure_sheet=False` on a level switches off COVER and OBJECTS. `build.py`
prints the override on the build line so it cannot be quiet, and it never
lifts REUSE: an algebra sheet has no more right to print one graph five
times than a geometry sheet has.

## What the author does with this

The cap on reuse is not a request for decoration. It says: a question that
goes back to an object already drawn draws **what the question adds**. Same
coordinates, new drawing, and the drawing is now the question's own diagram
instead of a reminder of an earlier one.

- the diagonals → dashed `AC`, `BD`, and their intersection `O` as a
  labelled point
- an altitude → the dashed segment, its foot labelled, the right-angle mark
  at the foot
- a midpoint, or a point dividing a side in a ratio → the point, dashed to
  the opposite vertex
- similar triangles → the second triangle drawn (dashed), not described
- a counter-example ("a rhombus that is not a square") → its own drawing,
  from its own coordinates
- a completed fourth vertex → the three given points first, open; the
  parallelogram only once `S` has been found

And across the sheet, vary the **object** between parts. Twenty questions on
one rhombus is a drill, not a synthesis: a different point set per part, a
shape on the axes and a shape off them, one with a negative coordinate, a
small one and a large one.

`build.py` now prints, per level, what G75 saw:

```
built a    רמה א׳         10 pages   figures 17/20 · distinct 13 · objects 4
```

## coord_plane — the builder this needed

`figkit.axes()` plots points and lines. The rebuilt sheets needed a polygon
on a grid, dashed diagonals and altitudes, a right-angle mark and extra
labelled points — and the package wrote its own helper to get them, which is
the "package-local helper outside figkit" this file already warned about.
`coord_plane()` is that helper, on `Figure`, with everything `Figure` gives:

```python
from figkit import coord_plane

# rhombus with its diagonals and their intersection
coord_plane((0, 11), (0, 5),
            polys=[[(1, 1), (6, 1), (10, 4), (5, 4)]],
            dashed=[((1, 1), (10, 4)), ((6, 1), (5, 4))],
            points=[((1, 1), "A"), ((6, 1), "B"), ((10, 4), "C"),
                    ((5, 4), "D"), ((5.5, 2.5), "O")])

# 6-8-10 with the altitude to the hypotenuse and its foot
coord_plane((0, 7), (0, 9), polys=[[(0, 0), (6, 0), (0, 8)]],
            right=[((0, 0), (6, 0), (0, 8)), ((3.84, 2.88), (6, 0), (0, 0))],
            dashed=[((0, 0), (3.84, 2.88))],
            points=[((0, 0), "K"), ((6, 0), "L"), ((0, 8), "M"),
                    ((3.84, 2.88), "N")])

# three given points, the fourth still to be built (open path, negative x)
coord_plane((-2, 6), (0, 6), solid=[((1, 1), (5, 2)), ((5, 2), (3, 5))],
            points=[((1, 1), "P"), ((5, 2), "Q"), ((3, 5), "R")])
```

Every stroke is registered, so the label solver keeps every letter off every
line; a vertex label is pushed away from its own shape; one `size` drives
both axes, so a slope reads true; a wide range shrinks to the 210px side
column with its labels enlarged FIRST, so the tick numbers still clear the
7pt floor. (The first attempt shipped 6.8pt ticks and `verify()` refused
it — which is what `verify()` is for.) Latin letters and digits only, as
everywhere in figkit; the Hebrew caption belongs in the question text.

## Also in this release

- `python3 figkit.py`: the `__main__` block moved to the end of the file.
  The helpers that used to sit below it (`_svg_segments`, which
  `figure_family` needs) are now defined before the self-test runs.
- `selfcheck.py`: 21 checks. G75 is exercised on real figkit output in both
  directions — a sheet that passes; one SVG on three questions; a geometry
  title over a text sheet; one object dressed eight ways; the override that
  must not lift the cap. `coord_plane` is checked for struck labels, for
  fitting the side column, and for drawing a rhombus with equal sides.
- `curriculum_tashpaz.json`: `coverage_policy.figure_rule` documents the
  three numbers; the gate itself reads the constants in `emit_html.py`.


---

# v5.3 — the primitives the sheets needed, and a key that computes itself

Three new כיתה ח׳ analytic-geometry packages were authored with v5.2 (Sep 2026).
They passed every gate in this file, and getting them there required two things
the skill does not ship. Both are added here as NEW FILES: nothing in
`figkit.py`, `emit_html.py`, `gates_runner.py` or `selfcheck.py` is edited, and
every existing call keeps working exactly as before.

| file | what it is |
|---|---|
| `figkit_plus.py` | `plane()` — a superset of `coord_plane()`, on `figkit.Figure` |
| `mathkit.py` | the answer key computed from the same coordinates as the figure |
| `selfcheck_plus.py` | 20 checks, each with a passing AND a failing case |

```
python3 selfcheck_plus.py      # the additions
python3 selfcheck.py           # unchanged, still 21 checks
```

## Why `coord_plane` was not enough

v5.2 added `coord_plane()` for exactly the reason this file keeps repeating: a
package that cannot say something in figkit writes its own helper, and a
package-local helper is outside every check the engine has. The new packages
needed the image of a transformation, a circle through lattice points, a mirror
line with its equation printed beside it, and ticks every 2 on one axis. None of
those has a parameter in `coord_plane`, and helper number seven was one keystroke
away. `plane()` is that parameter list, inside the engine.

- `dpolys` — a dashed closed shape: the image under a הזזה / שיקוף / סיבוב /
  הגדלה, a bounding rectangle, a counter-example drawn beside the original.
- `circles` — centre and radius in grid units, so "every point at distance 5
  from P" is a drawing and not a sentence.
- `labels` / `values` — free text at a coordinate, placed by the solver:
  `labels` italic for a line's name (`y = x`, `x = 2`), `values` upright for a
  length written on an edge. Latin and digits only, as everywhere in figkit.
- `dots` — plotted points with no letter.
- `xticks` / `yticks` — the two axes numbered independently, which a tall narrow
  range needs.

## Two defects it fixes on the way

**A dot is ink, and the placer did not know it.** `Figure.dot()` appends to
`parts` and not to `segs`, so every plotted point is free space as far as the
label solver is concerned — and `coord_plane` draws a dot at every named point.
The first drawing built for these packages printed the vertex letter `C` on the
dot of a neighbouring point. `verify()` does not see it (a filled disc is not a
stroke), and neither does G72, for the same reason. In `plane()` every dot
registers a small square of its own, so the solver walks around it.

**The finished SVG is re-swept, not trusted.** `figkit._struck()` exists and is
used by figkit's own selftest, but no builder calls it at emit time: the
drawing is returned on the strength of the solver's own bookkeeping. `plane()`
reads its output back with that independent sweep and raises on a struck label
— the same doctrine as `python3 figkit.py`, applied one step earlier, where the
author can still move a coordinate.

Also: `coord_plane` enlarges the labels before shrinking only when `width` is
None, so a narrow EXPLICIT width drops the tick numbers under the 7pt floor and
`verify()` refuses the drawing — at which point the author's cheapest fix is to
delete the ticks, which is the wrong outcome. `plane()` runs the same
enlargement for an explicit width.

## `mathkit` — the class of defect the emitter cannot catch

This file has always said it: "wrong answers in the key ... need the author, not
the emitter." In a coordinate package that arithmetic is mechanical — a squared
distance, a midpoint, a slope, a shoelace area — and an author typing sixty
sub-items of it by hand will get some of them wrong, silently, on a sellable
sheet. So the content file computes it, from the SAME tuples the figure is drawn
from:

```python
from mathkit import d2, dist, mid, slope, perp, area, per_int, between, fr, pt

A, B, C = (-2, 1), (4, 9), (5, 2)
dist(A, B)                    # 10      — None when the length is not an integer
area([A, B, C])               # 25      — shoelace, survives a reflex vertex
between(52)                   # (7, 8)  — refuses a perfect square on purpose
fr(slope(A, B))               # "\f{4}{3}"  — house markup, straight into $...$
pt(mid(A, B))                 # "(1, 5)"
```

Everything runs on `Fraction`, so a midpoint is `-1/2` and not
`-0.49999999999999994`, and `fr()` reads a float back as the short fraction the
author meant. Three refusals are deliberate, because a quiet approximation is
worse than a stop: `dist()` returns None rather than a decimal when the length is
irrational, `per_int()` returns None when any side is, and `between()` raises on
a perfect square, where the length is exact and the bracket would be a worse
answer than the number.

Change a coordinate and the key follows. Type the key by hand and it does not.


---

# v5.4 — G76: variety that scales with the sheet

v5.2 wrote G75 after an author opened three rebuilt sheets and saw the same
rhombus on five questions. G75 fixed the loudest half. The author looked at the
next set and named the half that survived, so this is the gate for it. G75 is
not replaced; both run, and G75's REUSE, COVER and OBJECTS checks are untouched.

**What G75 cannot see.** REUSE caps the same *SVG* at two questions. It does not
cap the same *SHAPE*. A rhombus drawn plain, then with its diagonals, then with
an altitude, then with a midpoint, then with a right-angle mark is five
different SVGs and one object — G75 passes it, and that is precisely the sheet
that was complained about. And `FIG_FAMILIES_MIN` is the flat number 3: a
reasonable floor for an eight-question sheet, and on a twenty-question sheet a
licence for a twenty-question drill on three shapes.

## The three checks

| check | rule | the case it was written for |
|---|---|---|
| SCALE | distinct objects ≥ `ceil(drawn / 3)`, capped at 8 | 17 drawn questions on 4 shapes |
| DOMINANCE | the busiest object serves ≤ `max(2, ceil(drawn / 5))` questions | the same rhombus on questions 1, 2, 10, 11, 15 |
| PART | a part with 3+ drawn questions shows 2+ objects | a whole חלק that is one shape, five ways |

`drawn` is the number of questions that carry a figure, never the number of
questions, so a sheet is not asked to invent shapes for its text items. An
"object" is `figkit.figure_family(svg)` — the same key G75 uses, blind to
decoration and sensitive only to the shape.

SCALE and PART run on a figure sheet, and `figure_sheet=False` switches them off
exactly as it does for COVER and OBJECTS. DOMINANCE runs always and the override
never lifts it, on the principle that already keeps REUSE unconditional: an
algebra sheet has no more right to run half its questions on one parabola.

## How it runs, and why it cannot be skipped

```
DYLD_FALLBACK_LIBRARY_PATH=/opt/homebrew/lib python3 /path/to/build_plus.py
```

`build_plus.py` installs the gate into `emit_html` and then runs the stock
`build.py` — no edit to `build.py`, `emit_html.py` or `gates_runner.py`. And
because a package built with the stock `build.py` would otherwise skip it
silently, importing `figkit_plus` installs it too: any sheet that draws with
`plane()` is gated either way. A failed install prints; it is never swallowed.

Each level prints what G76 saw, next to G75's line:

```
G76 a    objects 15/6 · busiest 2/4 · parts 7
built a    רמה א׳         10 pages   figures 17/20 · distinct 17 · objects 15
```

## What the author does with a failure

The same thing G75 asks for, one level up. G75 says: a question that returns to a
shape already drawn draws what IT adds. G76 says: across the sheet, change the
SHAPE. A different point set per part, a shape on the axes and a shape off them,
one with a negative coordinate, a concave one, a small one and a large one, a
circle among the polygons.

`selfcheck_plus.py` is now 32 checks; the twelve new ones exercise G76 in both
directions — a level that passes and a level that fails, for each of SCALE,
DOMINANCE, PART, the override, and the install.


---

# v5.5 — more shapes, and an image that is computed

G76 asks a sheet for more objects. A gate that demands something the author has
to hand-compute every time is a gate that gets argued with, so this release is
the supply side: a shape library, four more drawing primitives, and a catalogue
that renders all of it.

| file | what it is |
|---|---|
| `shapelib.py` | 18 shape generators and 8 transformations, each verifying its own claim |
| `gallery.py` | renders every shape in the library to `out/gallery.pdf` — a catalogue and a smoke test with a picture |

## The library

```python
from shapelib import (rect, square, parallelogram, rhombus_from_diagonals,
                      kite, dart, iso_trapezoid, right_trapezoid,
                      right_triangle, iso_triangle, l_shape, staircase, cross,
                      house, arrow, chevron, regular_polygon, star,
                      midpoints, divide,
                      translate, reflect_x, reflect_y, reflect_line_x,
                      reflect_line_y, reflect_yx, rotate, scale_from)
```

Every generator returns lattice coordinates wherever the shape allows them, and
**verifies the shape it claims**: a rhombus has four equal sides, a kite two
pairs *and* the pairs different (a kite that is really a rhombus raises and says
so), a dart's notch is reflex, an isosceles trapezoid has equal legs and
different bases, an L's bite is smaller than its rectangle. A shape that cannot
be built raises at authoring time instead of drawing something else.

## The image is computed, not typed

This is the release's real subject. SKILL.md has said since v5.1 that six
figures in one package contradicted their own question and that "the only thing
that caught these was a second reader computing from the data what the figure
should show". Writing a reflected triangle's three image points by hand is
exactly that mistake, one keystroke wide, and invisible to every gate: the
drawing is clean, the labels are unstruck, the font is right, and the picture is
of the wrong triangle.

```python
T  = iso_trapezoid(y_bot=0, y_top=4, bottom_half=5, top_half=2, cx=1)
T2 = reflect_line_x(T, 7)          # the image, from the rule
T3 = rotate(T, centre=(0, 0), quarter_turns=1)
T4 = scale_from(T, (0, 0), 3)
```

Every isometry checks that it preserved every squared side length; `scale_from`
checks that it multiplied each by k². `rotate` takes quarter turns only, on
purpose: any other angle leaves the lattice and a student cannot read the image
off the squares.

## Four more primitives in `plane()`

| parameter | draws |
|---|---|
| `arcs` | an angle arc — `(vertex, to1, to2)` or `(…, n)` for the equal-angles marking |
| `tickmarks` | `((p, q), n)` — equality ticks across a side, the standard way to say "these are equal" without a number |
| `shaded` | a polygon filled light grey: the region whose area is the question. Above the 0.85 luminance line both struck-label sweeps use, so it can never be mistaken for ink |
| `arrows` | `(p, q)` — a shaft and two barbs: a translation vector, a direction, a ray |

Also in `plane()`: the font floor no longer refuses a wide-and-short drawing. The
label size was estimated from the x-range alone and `verify()` rejected the
result, at which point the author's cheapest fix was to delete tick numbers —
the wrong outcome. `plane()` now retries with a larger font until `verify()` is
satisfied. `verify()` still decides; nothing here weakens it.

## The catalogue

```
DYLD_FALLBACK_LIBRARY_PATH=/opt/homebrew/lib python3 /path/to/gallery.py
-> out/gallery.pdf      20 shapes, 5 pages, every gate including G76
```

`selfcheck_plus.py` is now 46 checks.


---

# v5.6 — a drawing inside the sub-item, and geometry without a grid

Two things, from one measurement. The author counted three finished packages:

    per QUESTION   94% of questions carried a drawing
    per SUB-ITEM   23-27%

and said the page "looks like copy-paste, most of it with no drawing". Both
numbers are right, and the second is the one a reader sees. `emit_html` draws
once per question, beside `items[0]`; every other sub-item is a bare ruled
band. G75 and G76 both count questions, so neither could see it. The same count
found that all 49 figures in those packages were placed identically — narrow,
left column, one size — because the emitter has exactly two placements and 210px
decides between them.

| file | what it is |
|---|---|
| `emit_plus.py` | a figure INSIDE a sub-item: 4-tuple items, by wrapping the emitter |
| `euclid.py` | six Euclidean builders — no coordinate system, every one rotates |
| `figkit_plus.row()` / `.wide()` | the two placements the sheet never had |
| `gate_variety` G77 | visual density: per-question, **per sub-item**, and placement |
| `gate_variety.figure_family_plus` | the object key a Euclidean figure needs |

## Per-item figures, without editing the renderer

`items` is a fixed 3-tuple and item text is escaped by `seg()`, so a figure fits
through neither. `emit_plus` does not re-implement `question_html` — forking 60
lines of hardened layout to add one slot is how a rebuild loses an audit. It
rewrites the LEVEL (a 4-tuple item becomes a 3-tuple carrying a plain-text
token, with its writing space raised to the figure's height), lets the original
renderer run untouched, swaps the token for the figure in the finished HTML, and
appends one `<style>` block.

```python
items=[("א", "חשבו את השטח", 34, plane(..., width=120)),   # own figure
       ("ב", "הסבירו במשפט אחד", 26)]                       # unchanged
```

A sheet with no 4-tuple anywhere produces output **byte-identical** to the stock
emitter, which `selfcheck_plus` asserts by comparing the two strings.

## G77 — visual density

| check | rule |
|---|---|
| QUESTIONS | ≥98% carry a drawing — at 14-24 questions that is every one |
| SUB-ITEMS | **≥90%** carry a drawing: their own, or the head figure beside item א |
| PLACEMENT | a sheet of 8+ questions uses ≥2 of side / block / row / item |
| WIDTH | an item figure over 150px is refused — that size belongs at the head |

The three shipped packages score 23-27% on the sub-item line and would be
blocked. Measured on their own content: 82% of sub-items ask something a drawing
can answer, and the remaining 18% are "הסבירו במשפט אחד" and "נסחו כלל" — so 90%
is reached by giving a reference figure to about half of those, which improves
the question and not only the page.

## euclid — geometry without a coordinate system

`parallels` · `angles_at_point` · `triangle_with` · `congruent_pair` ·
`circle_fig` · `quad`. Before this, the skill could draw two Euclidean objects
(`figkit.triangle`, `trapz_kit.trapezoid`) and everything else was hand-built
SVG, outside every check the engine has.

Every builder verifies what it claims — a rhombus's four sides, a trapezoid's
single parallel pair, a median landing on the midpoint, an altitude meeting the
base at a right angle and not at a vertex. `quad_from_angles` was retired in an
earlier version for shipping a parallelogram on a sheet that asked the student to
prove one; these builders are laid out from parameters that fix the shape.

**Every one takes `rotate=`.** 21 configurations × 11 angles = 231 drawings were
swept with the struck-label sweep before this shipped, and the sweep found real
defects: a numbered angle sitting on the transversal below 28°, an `O` on its own
radius at 180°, and placement hints that did not turn with the figure. The
documented angle range for `parallels` (28-80) is where the sweep is clean, not
a guess.

## The object key a Euclidean figure needs

`figkit.figure_family` keys on polygon coordinates. Verified, both directions: a
triangle drawn larger or rotated gets a **different** key, so twelve sizes of one
configuration would satisfy G76; and a circle with no polygon falls to the
`("none", whole svg)` branch, where a changed label invents an object. So every
`euclid` figure declares its configuration — `<!--fam:triangle.right+altitude-->`
— and `figure_family_plus` keys on the declaration, falling back to the
coordinate key when there is none. Rotation and scale collapse to one object,
which is the truth for a reader, and rotation cannot be used to farm variety past
G76.

`selfcheck_plus.py` is now 60 checks. `gallery.py` is 26 shapes over 7 pages.


---

# v5.7 / v5.8 — what the first v5.6 pilot broke

One package (כיתה ח׳ / 28, שיפוע וישר y=mx, three levels) was rebuilt with v5.6
and read by reviewers who had not built it. v5.6 could not build it as shipped,
and three of its own fixes printed wrong numbers. All fixed here; each has a
passing and a failing case in `selfcheck_plus.py` (now 75 checks).

**G77 never saw an item figure.** `emit_plus` rewrites 4-tuple items into
tokens and the gates inside `build_html` read that rewritten level, so a sheet
drawn on every sub-item reported "16 of 76" and failed. `selfcheck_plus` called
G77 directly and never noticed. The gates now read the author's level.

**Every drawn item was twice as tall as its drawing.** `item_fig_space` padded
the band by the figure's height, but `.it{overflow:hidden}` already contains
the float. 7-page sheets built at 22 pages. The band now keeps the writing room
the author asked for, less what the figure beside it provides.

**Axis numbers read as other values.** A tick number blocked by a plotted line
could swing 30° and walk 22 steps out, and the x-axis "2" printed between ticks
under line v. A y-axis number was seated by its baseline, so every one sat above
its tick. Now the text box is centred on its tick, it may slide at most
0.6 × font size along the axis and two steps outward, a wide number (1140, −7.5)
starts clear of its own tick mark, and axis numbers are placed before free
labels.

**A coordinate plane must carry its numbers (v5.8).** The first v5.7 rebuild
refused a number that touched any stroke, and the authors "fixed" that by
deleting numbers: axes numbered only at ±4, axes with no numbers at all, grids of
5px squares. The author called the coordinate systems broken, and was right. So:

- `plane()` refuses an axis numbered with gaps, at a single value, or not at all;
  numbers sit at one regular step, at most every max(2, squares/6) squares.
  `data_ticks=True` allows numbers at the data values; `sketch=True` allows an
  unnumbered picture — both explicit.
- A straight line or a shape edge that crosses an axis number is cut around the
  number, and the stub left between the number and the axis is dropped: a guide
  reads "P ---- 8|", never "- 8 -" (the first cut, without the stub rule, printed
  exactly that and it read as −8). A dot, curve, circle, axis or letter on the
  number still refuses, with a message that says not to drop the number.
- A grid square must print at 10px or more.
- A shaded fill is emitted without a stroke, so it is not counted as ink.

**`plane(shaded=)` painted over the strokes** it was meant to sit under.

**`plane()` had no scaled axis**, so every level of the pilot wrote its own
helper for a price or distance axis, outside every check. `xscale=` / `yscale=`
give real units per square; ranges, ticks and coordinates stay in real units,
so a figure is drawn from the numbers the question prints. A range that is not
a whole number of squares is refused.

## What the reviewers taught about drawings (for the author, not the engine)

- A figure gives the answer away only when it prints or marks the value the item
  asks for, or draws what the student is told to draw. Plotting data the question
  gives is the representation, and `didactic_principles.json` asks for it.
  Read more strictly than that, an author stripped a sheet to 36% and switched
  G77 off.
- A sub-item figure that copies the head graph is decoration. Draw what the item
  adds: the rise/run step, the traced input, the given output traced back, the
  point substituted.
- A dashed guide never runs through an axis number. The engine now refuses it.
- Budget a reader who recomputes every figure from the code. In the pilot that
  reader found a line reaching the origin that answered the question above it,
  and lines of different slopes drawn at one angle because the y-scale was
  missing. No gate can see either.


# v6 — stage 1

Stage 1 of v6 fixes the engine the figures are built on. Each fix is a rule
in `selfcheck_v6.py` with a case that must pass and a case that must fail. A
defect only counts as caught when an independent parser reads the finished
SVG and sees it. The solver's bookkeeping is never enough: `verify()` once
passed z01 28ב with its axis numbers slid off their ticks.

## E7 — a figure prints U+2212, never the ASCII hyphen

**What was wrong.** At print resolution `-2` came out as a short dash. t17 had
184 hyphen tick labels, and z01, z08 and the pilots had them too.

**What changed.** Every generated number now uses the true minus sign:
`figkit._num` (axis ticks, `number_line`, `plane`), `Figure.label` (so the
sign is converted whoever typed the text), the `trapz_kit` canvas, and
`mathkit.n`, `pt` and `fr`. Inside `$...$` the emitter treats U+2212 exactly
like `-`, spacing included, so a formula built from `n()` renders identically.
Raw SVG written in a level file is converted as it passes through
`emit_html.fig_html` (`true_minus_svg`; only text content changes, never
attributes), and so are `emit_plus` item figures. `svgcheck.ascii_minus`
refuses an ASCII `-` directly before a digit inside `<text>`, and so does it
for the look-alike dashes a copied number brings in (U+2010 hyphen, U+2011,
U+2012 figure dash, U+2013 en dash, U+FE63, U+FF0D); `svgcheck.true_minus`
converts all of them.
Fixtures corrected: the three `selfcheck_plus` mathkit checks now expect U+2212.

## E21 — a minus after an answer blank

`___ -3` is a comparison item whose right-hand side is the number −3, so the
sign stays attached to the 3. `___ - 3` is a binary minus and is spaced. Before
this fix both were spaced as binary, and z01 typed U+2212 by hand to get round it.

A sign that is the last character before a macro looks past the macro: `___
-\f{4}{3}` (the exact form `mathkit.fr(F(-4, 3))` returns) is the number −4/3
and stays glued, `___ - \f{4}{3}` is spaced. In the first cut the plain run was
flushed before `\f`, the sign saw nothing after it and was spaced as binary.

## E2 — an arc and a dot are ink

`Figure.arc` adds its polyline to `segs`, and `Figure.dot(p, r, pad=0.6)` adds
a box around the disc. Before, the solver treated both as empty paper: it put
'60' on its own arc, put A on B's dot, and struck '3' in
`euclid.parallels(58, mark=(2, 6), rotate=30)`. Now the solver moves the label
away instead of refusing the figure.

## E3 — the struck sweep reads everything, at emit time

`figkit._struck` now delegates to `svgcheck.struck`, which has its own
tokenizer. The old version read `<text>` bodies as `[^<]*`, so it skipped any
label containing a tspan (`y = x<tspan>2</tspan>`). It also read path data as
M/L/Q/C only. The new sweep handles every path command, absolute and relative
(M L H V C S Q T A Z), plus polylines, rects, circle and ellipse rims, filled
dots and group transforms. Light gridlines (lightest channel > 0.85) are
still background.

`Figure.render(margin, width, check=True, dot_values=None, owners=None,
irregular=False)` runs `svgcheck.assert_clean` on the string it is about to
return, so every builder is swept, not only the selftests. `check=False`
exists for FAIL fixtures only. `trapz_kit._Canvas.render` runs the same sweep.

Every sweep reads every figure in its input. `svgcheck.blocks(s)` splits a
string into its top-level `<svg>` blocks, and each sweep runs once per block,
so `_struck` and `figkit_plus.assert_unstruck` see a struck label in the
second figure of a `row()`. They used to read only the first. The parser also
reads compact arc flags (`a40 40 0 0060 0` is no longer dropped), draws
`<use href="#id">`, reads CDATA as text, and treats a stroke as wide as it is
drawn: a run is struck when the ink's edge reaches it. `true_minus_svg` also
converts `&#45;` and hyphens inside CDATA.

The parser follows CSS where hand-written or extracted SVG differs from
figkit's: a `style` declaration beats the presentation attribute
(`stroke="#000" style="stroke:none"` draws nothing, `font-size="12"
style="font-size:5px"` is 5), and font sizes carry their units (`4pt` is 5.33
units, `50%` and `em` are relative to the inherited size). `marker-start`,
`marker-mid` and `marker-end` draw their `<marker>` at the path's vertices,
turned with the path, so an arrowhead written as a marker is ink and an arrow.
`figkit_plus.assert_unstruck` names the fix (re-place, halo or cut, enlarge,
widen) and no longer offers "drop the label".

The font floor is now checked per run. A superscript is its own run at its own
printed size: at 0.72 em the exponent of `y = x^2` printed at 6.15pt. `render`
raises the run to the floor, so the correct result is the default and the
label is never refused. The label's box reserves the raised run where it
prints (lifted 0.36 em, at its own size and ascent), and `render` re-places
the labels whenever it raises a run. In the first cut the box was still the
plain-text box: the raised '2' of `y = x^2 − 1` at `width=100` reached a line
the solver thought was clear, and the new sweep refused a trivial figure.

Font sizes are written rounded UP to 0.01 (`figkit._fs`). Written with `%.1f`,
a 9.34 label that `verify()` passed at 7.004pt was emitted as 9.3 and read
back at 6.98pt. `svgcheck.ROUND_PT = 0.02` absorbs the 0.1-unit rounding of
width and viewBox, and nothing a reader could see. `plane()`'s retry loop now
enlarges the font on the sweep's floor message as well as on `verify()`'s.

## E29 — `svgcheck.py`, independent sweeps of the finished SVG

The module imports no figkit. A PDF gate can call the same functions on the
SVGs it extracts.

    struck(svg)                      labels with dark ink through any run
    ascii_minus(svg)                 '-' before a digit in <text>
    font_floor(svg, min_pt=7)        (text, run, printed pt) under the floor
    tick_alignment(svg, tol=0.15, distance=True, irregular=False)
                                     numbers within 0.15 x spacing of their
                                     tick, and on the RIGHT tick
    arrowhead_clearance(svg)         tip >= 1.5pt from the next shaft's start and
                                     >= r + 1.5pt from any dot
    label_ownership(svg, owners)     [(text, (p, q))]: nearer its own stroke x1.5
    dot_on_other_tick(svg, values=None)
    problems(svg, ..., ticks=True|"values"|False, irregular=False) -> [str]
                                     all of them; a row() is checked per <svg>
    blocks(s)                        the top-level <svg> blocks of a string
    assert_clean(svg, where, ...)    raises, naming the fix

Axes are found from the ink alone: a long stroke crossed by at least three
evenly spaced short strokes. The origin and step are fitted by least squares on
the tick index. With the step rounded to 0.1, an axis of 15 or more ticks put
its far ticks off the lattice, and their numbers looked slid. A number is
matched to an axis only if it sits within its run of ticks, so the y-axis '2'
beside the origin is not read as a slid x-axis number.

Numbers on the wrong tick. Measuring only the distance to the nearest tick
passed an axis with '3' and '4' swapped, a '3' printed on the tick of 5, and
a '3' slid 1.3 spacings (it was taken for a value label). Now every pair of
aligned numbers proposes a numbering (value = v0 + k x step over tick index
k) and the others vote. When at least three numbers and a majority agree, an
aligned number that disagrees is refused as "sits on the tick of 5". A number
off every tick is refused as slid when its own tick is within 1.5 spacings
and does not already carry it.

Only the ROW of axis numbers votes. A jump's `+2` centred over the tick of 3,
a length `4` over a segment from 1 to 5, a point's `3.1` over its dot are
correct labels that are not tick numbers, and the first cut refused all of
them ("'+2' sits on the tick of 3") — an author would have deleted the jump
label. Numbers beside an axis are grouped into rows by side of the axis and
offset from it (near edge, centre or far edge within 0.75 em); the row with
the most tick-aligned numbers is judged, and another row only if it agrees on
a numbering of its own. Within the judged row a number printed exactly at its
own value between ticks (`2.5` at 2.5) is a value label, as is one whose own
tick is far away or already numbered. A wrong number printed IN the row is
still refused, and the message says to print a jump, length or point value
off the row, never to drop it.
`irregular=True` (on `tick_alignment`, `problems` and `Figure.render`) is for
a figure whose content IS a wrongly numbered line, a "what is wrong here?"
item: it skips the vote and keeps the distance check.

Arrows: an arrowhead is two short barbs and a SHAFT, or a small filled
triangle with a shaft running into its base. The shaft is the whole line the
head sits on. The sweep follows it through every joint where one segment runs
on without turning a corner, so a jump arc written as a `Q` path or sampled
into `M L L ...` counts. The first cut needed one straight segment twice the
barb's length, which no curve has, so every curved jump was invisible to it.
It also took a triangular head's base as the arrow's start. A double-headed
dimension line, two dimensions meeting head to head, and a ray drawn on top of
its own axis are accepted. A hop chain (`->->`, z08 4ג) is refused, straight
or curved. The refusal names the fix and the distance: end the shaft or arc
that much sooner (`figkit_plus.stop_short(a, b, stops)` gives the point).
An open chevron whose shaft stops at the head's base (no stroke at the tip
but the two barbs) is read like a triangle head; a lone V with nothing running
into it is not an arrow.
**The correct path is the default:** `plane(arrows=)` stops each tip 2pt
short of any plotted point, and keeps a 2pt gap before the next arrow. Every
hop in one chain has one length and lands on its value: its tip comes back
only by the largest dot pull D in the chain, and its START moves up by
max(0, gap − D). In the first cut only the tips that landed on something were
pulled (z08's two scale-setting hops printed at 9.2 and 10 units); in the
second every tip was pulled back equally, so the chain ended 2.2pt short of
the 20 gridline. Now both tips sit on 10 and 20.

Dots: without `values`, a dot is refused only when it sits at least 0.5pt off
the nearest tick's centre while its disc still reaches that tick. With
`values`, each dot is read back through the axis's own numbers and must match
one of the values. A dot whose value is not the value of the tick it covers is
refused however centred it looks: at 0.105 px per metre, −0.5 printed on the 0
tick. The message gives the stretch factor that clears the tick ("at least
2.59x the drawing units per value"). It points to a shorter range, a larger
unit/size/maxw in the builder, or a finer step, and says never to move or drop
the point.

`Figure.TICK_SWEEP = True` (since E1, below): every render runs the
wrong-tick vote and the 0.15 x spacing distance check. It was `"values"` while
the v5 solver still let a tick number slide 0.6 em. Arrows, dots, struck labels, minus signs and the
font floor are all checked by default. `label_ownership` runs only when the
caller passes `owners=`, and it too is judged per `<svg>` block (a label is "not found" only
when no block of a row holds it). Wired to every `edge_label` it refused the stock
`triangle(sides=(6, 6, 8), ticks=[AB])`, whose '6' sits nearer its own edge's
equality tick than its edge. Telling a mark on the edge from another stroke
is E24.

`trapz_kit` angle values now look for a clear spot. They walk outward from the
arc and swing inside the angle until the house box clears every stroke and
diagonal, and `check()`'s 8px rule still holds. Before, a diagonal from the
vertex ran through '40°' and '72°'. The whole box must stay INSIDE its angle
and its centre inside the trapezoid, no farther out than 45% of the shorter
edge: the first cut swung '50°' past AB and printed it outside the figure,
where it reads as the exterior angle (19 of 156 values). With no room left,
`_Canvas.clear_spot(..., sides=)` returns None and `trapezoid()` redraws itself
larger (three steps of ×1.2 over the caller's `target`) so the wedges widen under the 11.5px text; past that
it refuses, naming target=, dropping the diagonal or rotating.

**What a level built on v5.8 now meets.** z01_a (113 figures) is refused at
import. The package-local `nline`/`dbars` helpers produce four figures where a
dot's disc half-covers a tick that is not its value (812 on the 800 tick, −7.8
against −7.5). Its jump helper produces six more where a curved jump's head is
buried in the landing dot or in the next jump's start (figs 15, 28, 33, 65,
66, 76), and fig 71 is a deliberately irregular line ('2.5' after '1') that
must pass `irregular=True`. All are true positives, so the level has to be
regenerated with tips stopped short and more units per value. z08_a (127) and
z47_a (283) render clean. The pilots were already refused by the v5.8 axis
rules.

## E1 — tick numbers are pinned to their ticks

> **Amended by v6 stage 1b** (the last section of this file): a number a
> stroke reaches no longer cuts it. The pinning, the plate and the slide are
> as described; what changed is the answer when something is in the way.

**What was wrong.** Axis numbers went through the label solver like any other
label: a number blocked by a line could swing 32° and slide 0.6 em along its
axis. z09 printed '−1' under the gap between −2 and −1, h19 pushed '−3' and '2'
off their ticks, and z01 28ב shipped with numbers that `verify()` passed. A
student reads a slid number as a different coordinate.

**What changed.** `axes`, `coord_plane`, `figkit_plus.plane` / `wide` and
`number_line` no longer solve their numbers. Each one is pinned with
`Figure.tick_label(tick, text, axis="x"|"y", size, gap=2.5, side=None,
spacing=None, tick_half=3.0)`. An x-axis number is centred under its tick. A
y-axis number is right-aligned beside its tick, with its box centred on it.
`gap` is the white a reader sees between the tick's end and the digits. The
solver's box may come closer than that, but never within 0.6 units of the
tick. All three builders share one helper, `figkit.number_axes(f, X, Y, xr,
yr, xt, yt, font, xmarks=None, ymarks=None, hide=(), origin=None, square=None)`, so they
cannot disagree.

When something is in the way:

- a data line, a polygon edge, a curve, an arc or a circle rim is **cut**
  behind the number. A curve used to refuse the number, and authors then
  deleted it. The cut is made in the file, not painted over with a white plate,
  so G72 and `svgcheck.struck`, neither of which models paint order, agree with
  the printed page;
- when the strokes on the number row's own side would lose a lot to those cuts,
  the **whole row crosses its axis** (x numbers above, y numbers to the right).
  See "C2 round 2" below; a single number a stroke runs through first slides
  clear of it, or crosses alone to a side where it cuts nothing ("C2 round 3");
- another number, a dot, an axis, a tick mark or an arrowhead: the number may
  **slide along its axis**, by the least amount that clears it and never more
  than `PIN_SLIDE = 0.14` of the tick spacing, and that spacing is never
  taken wider than the axes' `step` (round 3). The finished SVG is held to
  0.15, so the number stays on its tick;
- a dot or an arrowhead that no slide clears: that one number **crosses its
  axis**, still on its tick, unless there it would stand within an em of the
  other axis's numbers and read as one of them;
- still blocked: the figure is **refused**. The message names only what is
  actually there ("its ink overlaps the y-axis number '−1'", "a plotted point at
  (48.0, 8.8) covers it; across the axis a plotted point as well") and gives a
  fix that keeps the number and works. It says "Do NOT drop the number".

A number is measured by its ink. The digits of the shipped face
(DavidLibre-Regular, measured with fontTools) advance 0.50 em and stand at most
0.63 em above the baseline and 0.022 em below it; the engine and svgcheck use
0.66 and 0.03 (0.20 with a comma). The solver's box is 0.58 em per character
and 1.02 em tall, and it would have refused every four-quadrant plane at the
default size. A dot is tested by its disc against that ink: a point on the axis
at the tick of 6 sits clear of its '6'.

`plane(shaded=)` is now painted before the axes as well as before the data
strokes. Painted after them, a shaded triangle over the y-axis hid the axis
and its tick marks at 2 and 4 (gallery figure 7).

The legacy `Figure.label(..., sector=32)` still works for figures that build
their own axes (z01's `nline`). `number_line` pins its numbers too.

## E4 — a cut never deletes an edge or a piece of a curve

> **Superseded by v6 stage 1b** (the last section of this file): a data
> stroke is never cut at all. What survives here is the completeness rule --
> `Figure.check_complete` -- which now asserts 100%, and the account of how
> v5.8 lost whole edges.

**What was wrong.** v5.8 dropped every leftover piece of a cut stroke that was
shorter than 1.1 em. `coord_plane((0, 6), (-2, 4))` with a rectangle whose
bottom edge runs at y = −0.8, along the row of x numbers, printed a three-sided
box. Every piece between the numbers was short, so all of them went, and the
figure's G75 key fell from `poly` to `segs`. A parabola drawn as a chain of
short `solid` segments lost 5.4% of itself beside '−2'. Nothing reported
either.

**What changed.**

- A cut polygon stays a `<polygon>` (its fill and its G75 key) drawn with
  `stroke="none"`. Its outline is one `<path>` holding every piece. A cut curve
  stays one `<path>`. A cut circle becomes one `<path>` rim with a gap under the
  number. No piece is dropped, however short: the drawing matters more than
  tidiness.
- The one exception is v5.8's guide rule. A DASHED line that ENDS on an axis
  at a pinned number, is continued by no other stroke there and ends at no
  plotted point, loses only its stub between the number and the axis, so the
  guide reads 'P ---- 8|' and never '- 8 -'. A solid segment AB with B on the
  axis keeps its piece up to B (round 1 took it).
- An arrowhead is never cut. Its barbs, and the shaft under them, are
  registered as `role="head"`: a number slides away from them, crosses its axis,
  or is refused. In round 1 an arrow along the row of x numbers printed as
  dashes with a 1.4-unit stub for each barb, and nothing reported it.
- **Completeness is asserted at every render** (`Figure.check_complete(svg)`).
  The dark stroke length of the finished SVG, measured by svgcheck's own parser
  (`svgcheck.stroke_length`), must reach 99.5% of what the figure's primitives
  draw outside the numbers' plates (and guide stubs). That expected length is
  derived again from the primitives and the plates (`Figure._expected_ink`),
  never from what the renderer booked while emitting: in round 1 a renderer
  that dropped short pieces and booked them as stubs passed its own books.
  With the v5.8 rule back, the rectangle and the chain above are both refused.
  So is dropping one 6-unit piece (0.6%) of the rectangle's edge.
  `Figure.ink_report` holds the numbers of the last render, `expected`
  included.

## E6 — a four-quadrant plane at the default size

**What was wrong.** `coord_plane((-5, 5), (-5, 5), step=1)` and
`plane((-5, 5), (-5, 5), step=1)` were refused at every width. The x-axis '−1'
and the y-axis '−1' both wanted the corner below-left of the origin. The
refusal also blamed "a plotted point, a curve, a circle" on a plane that
had none.

**What changed.**

- '0' is printed once, for both axes (`Figure.origin_label`). `origin=None`,
  the default, prints it when both axes print at least one number; `True`
  always, `False` never. (With `origin=True` as the default in round 1, an axis
  with no numbers grew a column for the '0' and a pilot plane fell under the
  10px square.) It sits in the y-axis numbers' column and as close to the
  x-axis as its stroke allows. It goes in the first corner where it neither
  touches a number, nor **reads into** one, nor cuts a stroke: the corner of
  the number row and column (below-left by convention), else above-left,
  above-right, below-right. When every corner that solves cuts something, the
  one that cuts least wins. Round 1 took the first corner that solved, and a
  line through the origin lost its crossing to the '0'. A '0' closer than 0.45 em to a number on its band
  merges with it. In the first cut, below-left at size 16 printed '−1 0' as
  '−10', so at that size the '0' goes above-left, under the '1'.
- The two '−1's are separated by sliding each away from the other, by the least
  amount that parts their ink. At the default font the y-axis '−1' moves 0.13
  of a square down and the x-axis '−1' does not move.
- `svgcheck.tick_alignment` accepts a '0' as the origin number only when a
  perpendicular axis or long stroke crosses the axis, this axis's numbering
  puts 0 at the crossing, and the '0' lies wholly inside one quadrant within
  one em of the crossing. A '0' 20 units lower is refused. A '0' in the corner
  is judged against EACH axis's numbering on its own (`_corner_zeros`), not
  inside a row. In round 1 it was skipped as "a value label" or because "the
  tick already carries this number", so a plane whose numbers all read one too
  high (step 1) or two too high (step 2) passed with the '0' contradicting
  them.
- A plane that really is too small for its numbers (`size=9`) is refused by
  what is there: "its ink overlaps the x-axis number …", with the fix
  (`size=`, `width=`, step 2).

## E13 — ticks anchored at 0, each axis its own, sparse and hide declared

- `figkit.anchored_ticks(lo, hi, step)`: multiples of `step` inside the range.
  `axes` and `coord_plane` used `range(lo, hi + 1, step)`, so step=2 on
  (−5, 5) numbered −5 −3 −1 1 3 5 and the origin fell between two numbers.
  They now print −4 −2 2 4, and 0 at the origin. `plane` was already anchored.
- `axes(..., xticks=None, yticks=None, hide=(), sparse=False, origin=None)` and
  `coord_plane(..., xticks=None, yticks=None, hide=(), sparse=False,
  origin=None)`. Each axis is numbered from its own list. `coord_plane(ticks=)`
  keeps its old meaning (one list for both axes) unless `xticks`/`yticks` are
  given.
- `sparse=True`, for an "infer the scale" item. Tick marks go at every `step`,
  and numbers only at the values listed in `xticks=`/`yticks=`. It needs a list
  and is refused without one. In `plane` a sparse axis must print at least one
  number besides 0, on a grid line unless `data_ticks=True`, and the
  regular-numbering rules of v5.8 are lifted for that axis only.
- `hide=` — **GONE in v6 (P3)**. Every call raises: an axis number is never
  deleted (rule 2). This paragraph described v6.0's declared mode; it is kept
  only to say what replaced it. Hide the ANSWER by not marking it — the point
  out of `points=`/`dots=`, its trace out of `dashed=`, its number out of
  `values=` — and ask for the value in the Hebrew question text. On a number
  line, `NL(...).point(v, value_label=False)` and `answer_hidden=`.
- `plane(..., hide=(), sparse=False, origin=None)`: the new parameters come
  last, so every existing call keeps its meaning.

**What a v5.8 level meets.** z08_a (every figure) and z47_a (283) build clean.
The only z08 change is the '0' at each origin. z01_a meets exactly the 11
refusals listed above, no more: its `nline` numbers are legacy `sector` labels
and stay within 0.15 of their ticks.

## C2 round 2 — what the verifier found in the pinned numbers

**A point on a number's spot was refused with a fix that could not work.**
`coord_plane((-2, 6), (-2, 4), points=[((4, -0.5), "Q")])` was refused with
"a larger size=". Once a figure is capped at `max_width`, `coord_plane` and
`plane` enlarge the font with `size`, so the point and the number grew apart at
the same rate and no size parted them. Now the number crosses its axis (an x
number above it, a y number to its right), still centred on its tick. It does
not cross when there it would stand within an em of the other axis's numbers
(an x '−1' above-left of the origin reads as a y value).

svgcheck judges a crossed number where it is. A number across the axis at the
number row's offset (within 0.35 em), whose value belongs to the row's
numbering, is moved into the row (`svgcheck._mirrors`). Before that, a lone
number on the far side was a row of its own and was never judged.

A point on BOTH sides is refused. The message gives the stretch that parts
them with the numbers kept at their size: "stretch the squares by x2.00 ...:
size=32 and width=330". The builders pass `square=size` to `number_axes` so the
message can name `size=`. The test renders the figure at exactly that size and
width.

**A row of numbers crosses its axis when that saves the drawing.**
`Figure._choose_sides` scores each row on each side by the ink its plates would
cut. A dashed guide that ends at that very tick is not counted. The row crosses
when the other side saves at least `_FLIP_GAIN = 0.7` tick spacings and at
least half the loss. If the crossed layout cannot be solved, every row goes
back to the convention. (Round 3 lowered the gain to half an em when that is
less, and dropped the "no more uncuttable ink" condition; see below.)

In round 1 three figures came out broken:

- the E4 rectangle's bottom edge printed as '1_2_3_4_5' with its short sides
  hidden behind '1' and '5', so the rectangle read as standing on the x-axis;
- a line at x = −0.4 printed dotted through the y numbers;
- in triangle O(0,0) A(−3,0) B(−3,−3), side AB stopped a square short of A.

All three now draw whole. The rectangle keeps 100% of its bottom edge and 97%
or more of each short side up to the axis; AB and OB each keep 90% or more.

**Cuts go to the digits' ink.** A stroke is cut back to the number's `plate`:
its ink box, padded by `svgcheck.NUM_PAD_EM` (0.06 em) and `_PLATE_EDGE` (1.2
units: half the widest data stroke plus 0.4 of white). Round 1 cut to the
solver's box grown 1.5 × 1.0 units, a third larger than the number.

`svgcheck.struck` now reads a run of digits, U+2212, '+', '.' and ',' by the
same ink box (`Run.ink`). Letters keep the 0.58 × 1.02 em box. A stroke through
the digits is still struck; one 0.2 em under the baseline is not. G72 needs no
change, since it already shrinks each glyph box to its core.

The parabola chain in `plane((-3, 3), (-5, 5))` keeps 88% of its length (round
1: 83.7%). What is lost is the curve passing behind '−3' and '−4' beside its
vertex, which no side and no slide can avoid.

A stroke that cannot be cut (an axis, a tick mark, an arrowhead) is tested
against the ink grown by its half width plus 0.3. On the 960-plane sweep this
refuses no plane that round 1 drew, and draws 3 that round 1 refused (768 clean
against 765).

**What an existing level meets.** z08_a (132 figures), z47_a (283) and z01_a
render byte-identical to round 1: none of their numbers is cut, and all their
axes are numbered. The pilot work_a was also run with v5.8's axis rule switched
off:

- its figures with unnumbered axes lose their '0';
- the '0' of a numbered plane moves to a corner no line runs through;
- its figure 11 is no longer refused under the 10px square.

Its figure 57, a hand-drawn value scale beside x = 4 whose '20', '40', '60'
the label solver places 0.19 of a square above their ticks, is refused by the
tick sweep. That refusal has existed since round 1 turned the distance sweep on,
and is not changed here.

## C2 round 3 — lines that look dashed, numbers off the grid, a sweep that could not fail

**A solid line along the row printed as dashes.** With the numbers two
squares apart (`step=2`, or `ticks=[2, 4, 6]`) a row crossed its axis only
when it saved 0.7 spacings, 22 units. A line cut behind '2', '4' and '6' loses
about 9 units at each, so `plane((-1, 7), (-8, 8), step=2, yscale=4, ...)`
printed '0 - 2 -- 4 -- 6' with the other side of the axis empty. In black and
white a dash is another kind of object. The gain needed is now
`min(_FLIP_GAIN x spacing, _FLIP_EM x size)`, with `_FLIP_EM = 0.5`.

The row also no longer stays home because uncuttable ink waits across the
axis. A dot over one number there is that number's business: it slides, or
crosses back alone. Ink nothing handles makes the flipped layout unsolvable,
and `_place_pins` puts every row back. In round 2 a dot above '3' kept the
whole row under a line it cut into dashes; now the row goes above and '3'
alone stays below.

**A lone number slid onto the grid.** A number slides at most `PIN_SLIDE`
times its tick spacing, and with `xticks=[6]` alone that spacing was the 6
squares from the origin: a point beside the tick pushed '6' 0.42 of a square
right, where it read 6.4, and the line after it printed as '6 -' (pilot
work_a figure 15). `number_axes(..., pitch=None, page=None)` is new: the
builders pass `pitch` = `step` squares in figure units, and no spacing is
taken wider than it. The '6' now crosses its axis on its tick.

**Single numbers spare the lines near the origin.** A pinned number a stroke
runs through now tries, least first:

1. a slide that clears the stroke, within 0.14 of a grid **square** (the full
   0.14 of a two-square spacing put '2' a quarter square off its tick);
2. crossing its axis alone, when the cut is at least half an em and the other
   side cuts **nothing**, holds no uncuttable ink and stands a full em clear
   of the other axis's numbers. Crossing to a side that also cuts (a circle
   through both ticks of 2) only scattered the numbers and kept the gaps;
3. staying, with the stroke cut.

A row still reads as a row: when more than a quarter of its numbers (at
least one) would cross alone, none does. A dot or an arrowhead still makes a
number cross regardless, as in round 2.

What the verifier measured (share of the data strokes drawn): y = 2x 88.9%
to 94.1%, y = x + 1 90.5% to 98.4%, y = x + 1 with y = x/2 87.3% to 91.5%.
On y = 2x the '−2' stands right of the axis; '−1' cannot (it would read into
the x-axis '1') and is still cut. The parabola in `plane((-3, 3), (-5, 5))`
is unchanged at 86%: it crosses the x-axis exactly at ±2 and has its vertex
on the y-axis, so every side cuts.

**svgcheck could not fail on a lone or a crossed number.**
`tick_alignment` never judged a row of one number, which is exactly
`sparse=True` with one listed value, and `_mirrors` gave up when the main row
held fewer than two numbers. A '6' moved 0.38 of a square passed. Now:

- a lone number is judged against its nearest tick. One half-way between two
  ticks (`_LONE_REACH = 0.45`) is a value such as '2.5', not a slid number;
- an axis with one or two tick marks is measured by its light grid
  (`_grid_ticks`, reading the new `Model.light`), provided every tick mark
  crosses the axis and sits on that grid. A guide ending on a dashed line is
  no tick. Its lone number belongs to the nearest real mark within one
  square;
- a number across the axis at the row's offset joins a row of one, and a row
  whose numbers do not agree on a numbering, by its offset alone.

The round-2 f015 drawing is now refused: "'6' sits 0.52 x spacing from its
tick".

**A refusal named a stretch no page holds.** A point on both sides of a
number's spot got "size=44 and width=560" for a plane capped at 210px, and
the easy escape was `hide=`, which drops the number. The message now starts
with a move in squares (`Figure._move_hint`): "move each point off the
number's spot: at least 0.40 squares along the x-axis from the tick of 3, or
at least 1.10 squares from the x-axis on either side where no other number
stands". It offers the stretch only when that width fits the builder's page
(`max_width`, 430 for `wide`), and otherwise says how wide it would have to
be. The test renders both moves.

**A value scale's numbers stood above their ticks.** `plane(values=)` placed
an upright number with a horizontal `prefer` on its baseline, so the '20',
'40', '60' beside a hand-drawn scale stood 0.19 of a square high. The tick
sweep refused pilot work_a figure 57 with "pin it to the tick", which a
`values=` author cannot act on. Such a number is now centred on its anchor
(`Figure.label(..., centred=True)`, set by `plane` for upright numeric values
with a horizontal `prefer`). The pilot run with v5.8's axis rule off now
reaches figure 64, as the v5.8 snapshot does.

**Mutants.** M10 (a number crossing for any uncuttable blocker) is killed by
a figure whose hand-added stroke under '3' must be refused. M14 (flip without
`h1 <= h0`) is gone with the rule; a mutant that removes the fall-back instead
is killed. All 16 mutants of this round's code (M10 included) are killed
(v6/C2r3/mut.log).

**What an existing level meets.** z47_a (283 figures) and z01_a (113 with
CONT, the same 11 refusals) are byte-identical to round 2. z08_a changes
three figures (99-101): the '−4' beside a point with `prefer=(1, 0)` now sits
to the right of the point, as its author asked, instead of above it. Pilot
work_a (NOAXIS CONT): figure 15 now prints '6' on its tick, and figures 57-63
render. On the 960-plane sweep 769 are clean against 768, none lost; 208 of
them change layout, the rows and single numbers moving off lines.


## E5 — every mark is checked against the geometry

**What was wrong.** A mark is a claim, and nothing measured it. The first
example in this file, `triangle(sides=(3, 4, 5), right_angle="A")`, marked a
53.1° angle: `sides` is (AB, BC, CA), so the right angle is at B. The same call
was the first figure of `figkit.selftest`, `selfcheck.py` and `selfcheck_v6`.
`coord_plane(right=...)` printed a right-angle mark on a 69° vertex,
`triangle(sides=(3, 4, 6), right_angle="B")` marked 117°, `trapz_kit` printed
equality ticks on the legs of a scalene trapezoid, and its own selftest wrote
'72°' on a 59.04° angle. `euclid.triangle_with("iso", "midsegment")` drew six
single ticks, which say AM = AC.

**What changed.**

- `Figure.right_angle(vertex, to1, to2, size=9, check=True)` measures the
  angle before drawing: 90 ± 0.5° (`RIGHT_TOL`), or it refuses. `triangle()`
  names the vertex: "right_angle='A', but angle A = 53.1° (A 53.1°, B 90.0°,
  C 36.9°). With sides=(AB, BC, CA) the right angle is at B: pass
  right_angle='B'". `coord_plane` and `plane` measure `right=` as DRAWN, so on
  unequal scales a tilted right angle is refused and the message names the
  scales. A right angle along the axes still prints square.
- `Figure.ticks` and `Figure.parallel_arrows` record what they claim.
  `verify()` refuses segments that share a tick count but differ by more than
  1.5% (`EQUAL_TOL`), and segments that share an arrow count but differ by
  more than 0.5° (`PARALLEL_TOL`). A drawn projection declares each edge's
  real length with `ticks(..., real=)`.
- `trapz_kit.trapezoid`: `ticks=True` is refused unless the legs are equal,
  a numeric angle value is checked against the drawn angle (to its written
  precision + 0.1°), and `_Canvas.right_angle` measures too.
- `svgcheck.mark_geometry(svg, lengths=True)` reads the finished SVG, and
  `render` runs it:
  - a right-angle mark is two equal short strokes meeting at a corner, with
    the far ends on two long strokes that meet at the opposite corner. That
    corner's angle is the vertex's angle;
  - an equality tick is a short LONE stroke crossing a longer non-axis stroke
    through its middle. Its marked length is a piece of the carrier between
    two stops -- the carrier's ends, a straight stroke ending on it (a vertex,
    a cevian's foot) or a dot -- and it is the piece whose middle the tick
    stands nearest (C3 round 2, below). A gap cut behind a number is not a
    vertex. Groups of one count must agree within 2%;
  - chevrons of one count sit on parallel strokes;
  - a text such as '59°' next to an angle arc is measured by the arc's two
    rays and must agree within 0.6°.
  Axes are never carriers, including an axis the sweep cannot measure: a long
  horizontal and a long vertical stroke that cross.

**Fixtures corrected.** `right_angle="A"` becomes `"B"` in SKILL.md,
`figkit.selftest`, `selfcheck.py` and `selfcheck_v6`. trapz_kit's selftest
prints '59°'. `r2_trapz_swept` prints the true 59° at A and B (it printed
'40°'/'72°'), and `r3_trapz_values_inside` refuses '24°', not '70°'. In
`euclid.triangle_with(..., "midsegment")` the halves of AC and of BC get
different tick counts unless AC = BC; the leg ticks that fell on M and N are
not drawn, because the halves imply them; on an equilateral triangle the
halves carry two ticks, since AB carries one for a whole side. The old
`t_label_gap` fixture expected two FREE labels 0.4 units apart to pass. They
are now tick numbers pinned to one axis, and the free pair is the fail case
(E24).

**svgcheck `_axes` anchor.** The tick lattice is now anchored on the tick most
others agree with. It used to anchor on the first mark, so a right-angle mark
standing on the x-axis left of the first tick hid the whole axis from every
tick sweep (gallery question 5).

## E8 — marker styles

`Figure.marker(p, style="filled", r=None, width=1.2, pad=0.6)` draws one of
`MARKER_STYLES = ("filled", "open", "tri", "square", "cross")`:

- "open" is a white disc with a dark rim: an excluded end point, a hollow
  step;
- "tri" and "square" are white with a dark outline; "cross" is ×.

Half the marker's extent is at least `MARKER_R_PT` (3.5pt) as printed, at any
display scale. Markers are painted after every stroke, so a line stops at an
open point's rim. A marker registers as a dot: labels walk round it, and a
pinned number never covers it.

Builders: `plane(points=[(p, "A", style)], dots=[(p, style)])`,
`coord_plane`/`axes(points=[(p, "A", style)])` and
`number_line(marks=[(v, "A", style)])`. `plane(circles=[(p, "open")])` is a
marker too, so the unequal-scale refusal no longer applies to markers: they
are screen-space. A data circle on unequal scales is still refused, and the
message now names the marker forms. z08 Q17's legend no longer has to turn ○
into ●.

`svgcheck.markers(svg)`, run at render, checks three things:
- a small closed shape with a white fill and a dark outline has a half extent
  of at least 3.5pt;
- no stroke is painted over it;
- a small dark ring with `fill="none"` that a stroke passes through is
  refused, because the line shows through the "open" point.

z01's hand-built number lines draw open circles at 2.3pt. They are now
refused, with a message that names `Figure.marker`.

## E9 — primitives: dimension, ticks, arrowhead, parallel arrows, bezier

Every primitive below is registered ink (the solver walks labels round it)
and is emitted through `render`.

    Figure.ticks(p, q, n=1, size=5, t=None, width=1.1, real=None)
    Figure.parallel_arrows(p, q, n=1, t=None, size=6, width=1.2)
    Figure.arrowhead(at, dir, size=6, style="open"|"filled", angle=28, width=1.4)
    Figure.dimension(p, q, offset=10, text=None, witness=True, size=11,
                     gap=2, head=5, style="open")
    Figure.bezier(p0, c, p1, width=1.4, dash=None, n=24)   # c=(c1, c2): cubic
    Figure.marker(p, style="filled", r=None)

**Printed floors.** h36/h38 printed equality ticks 3.7pt long and 2.5 units
apart, so two ticks read as one thick one. Ticks and chevron arms are now at
least `TICK_LEN_PT` (5pt) long, with `TICK_GAP_PT` (2.5pt) of paper between
two of a group, and barbs are at least `HEAD_PT` (4pt). A floor is a printed
size. It is known only once the frame is, so these marks are specs (part kind
"mark") that `render` redraws at the final scale in the same loop that raises
superscripts. Marks only grow, with 3% headroom, and `verify()` refuses one
drawn for a larger print than it got. Marks are never cut behind a pinned
number (roles "mark" and "head").

`dimension`: `offset` is to the LEFT of p→q as seen on the page (positive is
above for p left of q). It draws an arrowhead at each end and witness lines
from `gap` off the segment to 2.5 units past the dimension line. `text` goes
on the far side and OWNS the dimension line (E24). The filled arrowhead is a
`<path>`, so it never reads as a polygon object.

## E10 — the fam tag is public; figure_family is scale-invariant

`figkit.tag(svg, fam)` is public (it was `euclid._tag`, which remains as an
alias). It re-tags rather than tagging twice, and refuses a name that is not
Latin, digits and `. + - _ : = ,`. `Figure.render(..., fam=None)` and every
builder take `fam=`: `triangle`, `rect`, `axes`, `coord_plane`,
`number_line`, `cylinder`, `plane`/`wide`, `trapz_kit.trapezoid`,
`grid_quad` and (C3 round 2) every `euclid` builder, whose own configuration
name stays the default. The default stays None, so existing G76 counts do not collapse.
`gate_variety.figure_family_plus` reads the tag first.

`figkit.figure_family(svg)`:
- polygons are translated AND scaled to a unit extent (rounded to 0.001), so
  one triangle drawn at two sizes is one object;
- a shaded region (a light fill, no outline) is not an object, and E4 keeps
  every polygon when edges are cut;
- a figure with no polygon is keyed by its SOLID dark strokes (a dashed guide
  is an addition), its dots and markers (filled 'd' and open 'o' told apart)
  and its circles with their radii, all normalised the same way.

The repros this fixes, all tested:
- two circles on one set of axes shared a key;
- six number lines with different marks were one family;
- one triangle with different dashed guides, a point or shading gave five
  families.

G75/G76 on the levels: z08_a goes from 15 to 17 question families (its point
sets now count) and z47_a stays at 13. Both still pass. Six number lines
with different marks now pass DOMINANCE; one 3-4-5 triangle at six sizes is
refused.

## E24 — reading merges and value-label ownership

**Merges.** '5 16' and '12 13' (z47), '4 Q' (h31), 'B D' (h45, t12, h43).
Two labels whose boxes share a baseline band (their heights overlap by at
least half the smaller one) with less than `MERGE_EM` (0.6 em) of paper
between them read as one word.
- The solver treats such a spot as not clear and re-places the later label.
- `verify()` refuses such a pair. Two numbers of one axis row, pinned or
  legacy `sector=`, are exempt.
- A label standing IN the row of an axis's numbers also reads as one of
  them: between two numbers, or past the end ones by up to half a spacing or
  0.6 em, with a quarter of its height in the row's band. '4 Q 6' is one such
  case. Another is '2 6 4', the value of an edge lying on the axis. The solver
  keeps labels out of that band (`_pin_rows`, `_in_row`).
- `svgcheck.reading_merge(svg)` reads both cases from the SVG. A number
  printed at its own value in the row ('2.5' at 2.5) reads true and passes.

**Ownership.** Every label bound to a stroke must be nearer it than any other
stroke by `OWN_FACTOR` (1.5). Bound labels are: `edge_label(..., own=True)`,
a `dimension` text, and `plane(values=[(at, "6", prefer, (p, q))])`. The
solver only accepts spots that satisfy this. When none exists it refuses:
"enlarge the figure (size= / width=), give the label a prefer= ..., never
drop the label". `render` hands every bound label to
`svgcheck.label_ownership` automatically, for every builder.

Three readings keep the check honest:
- a stroke lying along the owner does not compete (an axis the edge lies on,
  or a piece of the same edge);
- a short stroke crossing the owner or standing on its interior does not
  compete (its equality tick, its chevron, an axis tick under it);
- an adjacent stroke whose nearest point to the label is the joint it shares
  with the owner does not compete (`_beyond_joint`). Measured naively, the
  '2' beside the short side of `triangle(sides=(20, 20, 2))` was "nearer" the
  two long sides that start at its ends.

Owners may carry the point where the label was written, `(text, (p, q),
(x, y))`, so two equal texts (a value '6' and the axis number '6') are told
apart.

**Also.** The trapz_kit refusal for an angle value with no room no longer
suggests drawing the figure without the diagonal (C1 open issue); it names a
larger `target=` or a rotation.

**What an existing level meets.** z08_a: 132 figures, one changed (figure
131, its equality ticks now 5pt). z47_a: 283 figures, 16 changed (the same
ticks, larger). Pilot work_a (NOAXIS CONT): 64 figures, byte-identical. z01_a
with CONT: 113 figures. Its 11 old refusals are unchanged, and 13 figures are
newly refused for open circles under 3.5pt.
Tests: 18 C3 checks in `selfcheck_v6.py` (112 in all), each with a pass and
a fail direction; the fail direction is a broken SVG or wrong data. A
mutation pass over this chunk's code (47 mutants, v6/C3/mut.log) kills every
one.

## C3 round 2 — what the verifier found in the marks

**An arc's end read as a vertex.** `mark_geometry` measured an equality
tick's length to the nearest stroke end each way, and the end of an angle
arc is a stroke end. A correct isosceles triangle with ticks on both legs
and an arc at one base angle was refused as "equal marks on unequal
segments", which told the author to put false tick counts on it. The foot of
a bisector on a ticked side did the same, so `euclid.triangle_with("iso",
"bisector")` and `("equilateral", "bisector")` were refused, although they
rendered before C3. Now:
- the end of a curved stroke (an arc, a curve) is never a stop;
- the carrier is the segment chained across cut gaps, and only stops on it
  count, never the end of an axis it lies on or a stroke ending on its line
  beyond it;
- of the pieces between a stop behind the tick and a stop ahead, the tick
  names the one whose MIDDLE it stands nearest (`Figure.ticks` draws at the
  middle). A tick in the middle of BC names BC, whatever foot lies on BC; a
  tick in the middle of AM, with M the midpoint of AC, names AM.

**figure_family without polygons was not scale-invariant.** Tick lengths,
axis overshoot, arrowheads and marker radii are fixed units, so one number
line at `size=30` and at `size=45` were two objects, and so were a plane of
points or a circle at two sizes. The no-polygon key is now framed by what
scales: the midpoints of ticks standing on their lines, the points and the
circles. Long strokes are clipped to that frame, ticks are keyed by their
midpoints, other ornaments (barbs, right-angle marks) by count, and a small
marker by its style and centre (`tri` and `square` paths and the `cross` are
spots, not strokes). A light-filled polygon whose outline one dark element
traces (an edge cut behind a number) stays a polygon; plain shading still
does not count.

**A value re-placed off the row landed where the sweep reads a slid tick
number.** The E24 in-row rule moved a side's length '5' out of '2 4 6 8', to
just above the axis at 4.5. There `tick_alignment` joins a number printed
across the axis to the row, and it refused the figure as "tick label '5' sits
0.25 x spacing from its tick". The solver now asks the sweep's question
first (`Figure._num_rows`, `_reads_as_tick`). A free NUMBER is kept out of
three bands: the row's own band, the band a line farther out, and the row's
band mirrored across the axis. In the row and mirrored bands the test is
within 1.5 spacings of the tick its value names, but off that tick. In the band
a line farther out it is anywhere under the row's span: a '7' under the '4'
reads as a second row of axis numbers. A length whose anchor sits in the
number row may therefore land inside the shape, or two lines out from the
numbers, where it reads as a caption of the side rather than as a number. Both
sides now treat the reach of 1.5 spacings as exclusive (`svgcheck.SLID_REACH`),
so a number exactly half-way between two numbered ticks is a value.

**Equality ticks beside an axis tick read as one more tick.** A rectangle's
side on the x-axis: at the middle its ticks stood on the axis tick and its
number (refused, naming `t=`), and at `t=0.35` they read as '|| |'.
`Figure.ticks` and `Figure.parallel_arrows` now default to `t=None` (and
`plane(tickmarks=[((p, q), n)])` passes None). None means the middle, except
on a segment lying along an axis: there the group goes half-way between two
of the axis's tick marks, nearest the middle. A group whose centre is within
`AXIS_MARK_CLEAR` (0.35) of a tick spacing of an axis tick or crossing axis,
or with under 5pt of paper to it, is refused at source, and the message names
the `t=` values that work. `svgcheck.mark_geometry` reads the same claim from
the SVG. A short stroke across an axis OFF its tick lattice, on a drawn edge
lying along the axis, is an equality tick; it must stand clear, and the edge
is judged for equal length like any other.

**A dimension line through the shape.** `Figure.dimension` accepted an
offset that put the line inside the triangle and a witness line on its
side. `verify()` now refuses a dimension or witness line that crosses or lies
along a drawn stroke. The message names the other side (`offset=-14`) when
that side is clear, and a larger offset when neither is.

**Smaller things.**
- `HEAD_PT` had no test: barbs are now measured from the SVG at `width=60`.
- The right-angle sweep's allowance for coordinate rounding comes from the
  rounding the SVG was written with (0.01 or 0.1, `_grid_step`). It was a
  flat 0.15 units, which passed an 89.2° mark.
- `svgcheck.markers` reads a `<path>` ring filled with nothing, not only a
  `<circle>`.
- A `square` marker at a numbered tick was refused as "an equality tick
  covers it". A marker's outline is a point to a pinned number, which slides
  or crosses its axis like a dot's.
- Value labels on `trapz_kit`'s canvas (the sides and the height) are judged
  by `label_ownership` at render.
- The solver's last-resort refusal no longer says "or drop one".

**What an existing level meets.** z08_a (132 figures), z47_a (283), z01_a
(CONT, 113) and pilot work_a (NOAXIS CONT, 64): every emitted figure is
byte-identical to C3 round 1, with the same refusals. Tests: 9 C3r2 checks in
`selfcheck_v6.py` (121 in all). Each fails on the round-1 code or under a
mutant of this round's code (v6/C3r2/mut2.log).


## C3 round 3 — false refusals of correct drawings, and refusals that named no way out

**The sweep read equality ticks as the axis's own lattice.** With `t=None`
the ticks on a side lying along the x-axis go half-way between two axis
ticks. On a `step=2` plane the axis ticks are 32 units apart and a group's
ticks about 5. The most common gap between neighbouring marks was the
group's, so the lattice ran through the group and one axis tick, and the
real ticks fell off it. A correct rectangle was then refused twice: "2
equality ticks stand 2.87pt from the axis tick at 78.9" (though `t=None`
had placed them), and "tick label '2' sits 2.65 x spacing" (though the
number was pinned). The verifier's 144-case sweep had 12 such refusals.
`svgcheck._best_lattice` now proposes a spacing from every gap between a mark
and its next four neighbours, and anchors each proposal on each mark. Two
kinds of mark do not count toward a lattice:
- a mark with a neighbour of the same length nearer than `GROUP_PT` (4pt of
  paper): it belongs to a group, since figkit keeps groups 5pt clear of axis
  ticks;
- a mark whose length fewer than three marks share, while three or more
  marks share another length: a lone equality tick or a side of a mark.

A lattice that leaves more than half of its places empty is a coincidence.
Of the rest, the one that explains the most counted marks wins, then the
fuller one, then the wider one. The marks of a group never join the lattice
when three counted marks carry it. So a group straddling an axis tick is
judged as three ticks, where it used to be read as the tick itself. An axis
whose commonest gap is under 4 units (a group straddling a tick) is read
when three counted marks agree on a wider lattice. A stroke on the axis
counts as that axis's own tick only if the lattice was read from it (within
0.3 units). Anywhere else within 0.15 spacing of a tick, it is a mark.

**Trapezoid labels could not move.** Round 2 passed the owners of
`trapz_kit`'s side and height labels to `label_ownership`, and 11 of 120
trapezoids that rendered in round 1 were refused. Two fixes, one in the
reading and one in the drawing:
- `label_ownership`, and figkit's solver through `Figure._owns`, no longer
  counts as competition (a) the two strokes of a right-angle mark whose
  vertex lies on the owner (the mark at the foot of a height), or (b) a
  stroke that the owner stands between it and the label (`_shielded`: the
  '3' above the short top base, a diagonal below that base).
- `_Canvas.text(..., owner=, alts=[...])` takes alternative positions. The
  height label tries 0.6, 0.7, 0.5, 0.8 and 0.4 of the height, at 12, 15 and
  18 px, first on its own side and then on the other. A side label slides
  along its side and steps outward. `render()` moves each owned label the
  finished SVG reads as another stroke's to the first alternative it owns,
  keeping `check()`'s 17px and 8px rules. If none works, `trapezoid()` grows
  by 1.2 up to `_GROW_MAX`, as it does for a crowded angle value. It then
  refuses, naming a target that works: "pass target=320 or larger, or
  rotate the figure; never drop the label, the height or a diagonal". The
  growth recursion now keeps `fam=`.

The verifier's sweep now renders 93 of 120, against 91 in round 1 and 80 in
round 2. Three figures that were refused as struck render with the label
moved. One figure is newly refused, and its refusal is correct: in round 1
the '2' beside a short height sat on a diagonal. At `target=320` it
renders.

**A dimension's witness line along its own base.** The witness from the foot
of a height lies along the base, so `_verify_dims` refused z47's height
dimension at every offset. The message said "give a larger offset, or
dimension a free side", which pointed to dropping the dimension. Now:
- A witness line lying along a drawn stroke is carried by that stroke and is
  not a hit. Its crossing at that stroke's own vertex is not a hit either.
- A dimension line inside a closed shape is a hit even when it crosses
  nothing (it ends on two sides). The message says "(or lies inside a
  shape)".
- The dimension check runs before the label solver, so a dimension inside
  the shape is refused with its own message, not as "label '12' has no
  clear spot".
- `_dim_fix` tries the fixes and names the first that clears: the other
  side, then `witness=False`, then an offset standing beyond every stroke.
  The test renders whatever call the message names.

**An owned length on a short base at the origin.** The mirrored-band rule of
round 2 banned every spot just above such a base. A 2x1 triangle's base
length needed `size=60`. A number across the axis is now exempt when the row
already prints its value at that value's tick (`svgcheck._judge_row` skips
it: "the tick already carries this number"), provided it stands more than
the sweep's tolerance plus 0.05 spacing off every numbered tick (otherwise
the sweep votes it onto that tick). The row band itself and the band a line
farther out are unchanged. `rt3x4` and `rect2x5` at step 1 render as in
round 1, and the 2x1 base renders at `size=40`. When an owned label still
has no spot, `plane()` tries `size` x1.4, x1.9, x2.5 and x3.2 and appends the
first that renders: "(tried: size=52, max_width=730 and no width= renders
it)".

**Stops.** A dot on a carrier was a documented stop that no test could fail
(mutant M18 survived); it is now tested in both directions. A curve standing
on the line with both ends, such as a semicircle on a sub-segment PQ, divides
it at both ends again. An angle arc, which has one end on the line, still
does not.

**The row starts at the corner '0'.** Round 1 printed a free '2' half a
spacing before the first numbered tick, after the corner '0', so the row
read '0 2 2 4 6'. The sweep passed it because the row's reach past its end
number is 0.6 em. Now, both in `reading_merge` and in the solver's
`_pin_rows`, the origin's '0' printed in the band within 1.5 spacings of the
end number extends the row to it.

**What an existing level meets.** z08_a, z47_a, z01_a (CONT) and work_a
(NOAXIS CONT): every figure byte-identical to round 2, with the same census.
Six C3r3 checks in `selfcheck_v6.py` (127 in all). Each fails on the round-2
code, and 19 mutants of this round's rules are all killed
(v6/C3r3/mut.py).

## C4 — `numberline.py`, the number-line builder

**What was wrong.** Number lines had no builder. `figkit.number_line` printed
integers with every tick numbered and nothing else, so z01 drew its 113
figures with a package-local kit (`nline`, `dline`, `stacked`, `lines`,
`dbars`, `_decorate`, `_fit`). That kit shipped every defect in
`regen/work/z01_a/open_issues.json`: lines numbered every 3rd or 5th tick
(2ב, 28ב, 34ב, 36ב), ticks 4.4pt apart (5ו, 13ב, 28 head), −0.5 printed on the
0 tick and a bar 0.04pt long (3, 3ב), −120 and −75 merged into one blob (36),
jump heads buried in the landing dot or the next jump (8ב, 22ב), an open
circle touching the arrowhead (q20), a bracket from 0 to −5 beside "find the
distance of −5" (1ג/34ב), and a reversed range or an off-line mark drawn
silently.

**What changed.** `numberline.NL` draws the line from its numbers and reads
the result back. The rules below are each refused with a message that names
the fix (a coarser tick, a wider tier, `between=True`, a second line, a
different marker, `from_inequality`) and never "drop it":

- Every value is a `Fraction`; ticks sit at multiples of `tick` counted
  from 0. `lo < hi`, and every mark must lie on the line.
- Three tick lengths, all printed: numbered (9px), half (6px) and minor
  (4px). Numbers are pinned to their ticks and never pass through the label
  solver. `label_fmt` is `int`, `dec`, `frac` or `mixed`. Fractions are
  stacked with a drawn bar and centred on their tick; a lone sign is a stroke
  beside the fraction, since a text '−' alone in the row read as a number. A
  format that cannot print a tick exactly (`dec` with thirds, `int` with
  halves) is refused.
- Density: of the whole-step ticks (multiples of the first whole multiple of
  `tick`), no two in a row go unnumbered unless `sparse=True, label_at=[...]`
  ("find the scale": ticks of one length) or `sketch=True` is declared.
  `label_every="auto"` picks the densest numbering that stands 1.6 x the
  widest number apart at the fitted unit.
- Placement tiers `item` 150, `side` 205, `block` 420 and `strip` 600 px. The
  unit is fitted to the tier and the tick numbers print at one size
  (`TICK_PT` 7.5) on every tier. Floors in printed pt: minor ticks >= 6pt
  apart, numbered ticks >= 1.6 x the widest number apart.
- `new_sheet(arrows=)` / `style(arrows=, tick_pt=)` set the convention once
  per sheet. A line that asks otherwise, or a change after the first line,
  is refused.
- Marks: `point(v, name, style, value_label, between)` (filled, open, tri,
  square, cross; r >= 3.5pt, painted last). A letter goes to the nearest
  clear height above the point. Two points print
  >= 2r + 1.5pt apart, and a point never lands within r of another tick
  ("−0.5 prints within r of the 0 tick"). A value off the ticks
  needs `between=True`; that is checked after the magnitude rule, so the
  more telling message wins. There is one marker per value, and a circle
  point on a line carrying a set must agree with the set (use `tri`/`cross`
  or `test_markers` otherwise).
- `span(a, b, label, kind="bracket"|"arrow2")`, `symmetric(a)`,
  `double_arrow(c, d)` and `midpoint(a, b)`. Never dashed. A numeric label
  must equal |b − a|.
- `jump(a, b, label)`, `chain([...], labels)` and `repeat(start, step, n)`:
  quadratic arcs. Height = clamp(0.34 x span, 5px, 18px), never over 0.5 x
  span. The head's tip stops r + 2.4pt above the axis, so it clears any dot. A
  chain that continues in the same direction stays on its side and starts
  each hop 2.5pt past the previous tip; a reversal switches side. Overlapping
  jumps are grounded (see round 2). A numeric label must equal b − a ('+6' on
  a 5-jump is refused).
- Sets: `from_inequality("2x+3<=7" | "−1<x<=4" | ("<=", v), closed=,
  domain=)`, `interval`, `ray`, `union`, `intersect`, `all_reals(source=)`,
  `empty(source=)` (the ∅ caption comes back as HTML), and `integers_in`.
  The bar is 2.5x the axis stroke, with white knock-outs where ticks cross
  it. A ray's head lands past the last tick and replaces the axis head on
  that side, and an end circle gets 3pt of axis beyond its rim. At the call,
  the set is sampled at 400 points (plus every boundary) against the parsed
  inequality and compared structurally: a ray at 5 on −5..5 for an identity
  "disagrees past the end of the line". At render, `sweep()` samples the set
  again from the SVG. `all_reals`/`empty` without a source are refused.
- `test_markers([(v, "x"|"tri")])`, `answer_values` (inside the line with a
  tick of margin), `answer_hidden` (no point, span end, jump landing, set end
  or label at a hidden value), and `blank=True` (no marks).
- fam: `<!--fam:numberline[lo,hi,tick,kind]{marks-hash}-->`. The hash covers
  the values, kinds and styles of the marks, but not the letters or the
  width. `fam=` overrides it. `gate_variety.figure_family_plus` now refuses
  an SVG that draws nothing.

**The sweep reads the SVG, not the builder.** `numberline.sweep(svg,
member=None, lo=, hi=, label_spacing=True, lengths=True)` works through
`svgcheck.model` and checks:
- the printed spacing, with the width attribute included (a figure squeezed
  after rendering is caught);
- each number, grouped with its bar and sign strokes and read to a VALUE,
  sits within 0.15 x spacing of its tick;
- the values lie on one line against the tick positions, by a vote, so
  swapped fraction numerators are refused;
- numbers stand on the long ticks and every long tick carries one, so a '1'
  moved one tick over on a two-number quarters line is caught (no vote with
  two numbers could catch it);
- no other text stands in the row;
- arc height ratio (the z02 teardrop), head boxes disjoint, and an open rim
  >= 3pt from the axis end;
- set membership, when `member` is given.

Every render also runs `svgcheck.assert_clean`. That covers struck labels,
minus signs, the font floor, tick alignment (the wrong-tick vote is skipped
for frac/mixed/sparse/sketch lines, where `sweep` reads the values), arrows,
dots against `dot_values`, markers, and merges (skipped for `mixed`, whose
whole part stands beside its fraction; `sweep` refuses any other text in the
row).

**svgcheck fixes this builder needed** (each tested both ways in
`c4_svgcheck_reads_short_number_lines`):
- `_best_lattice` counted a mark whose length fewer than three marks share as
  a lone equality tick. On a short number line the two numbered ticks are
  exactly that, so the lattice was read through the minor ticks and '0' and
  '1' were refused as half a spacing off. Lone marks are now ticks when two
  or more of them complete a lattice of the median gap, end to end, with
  only an arrowhead base allowed past either end. A single equality tick
  half-way between axis ticks still leaves a hole and stays grouped.
- `dot_on_other_tick` read the value of the tick under a dot through the
  fitted spacing, so a dot for 0.75 was refused "on the tick of 0.7469". It
  now takes the tick's value by its index on the lattice. −0.5 on the 0 tick
  is still refused.

**`figkit.number_line` is a shim.** Its signature and meaning are unchanged:
`step`, `size` units per unit (v5.8's X = v * size), `font`, display `width`, no arrowheads, and
marks `(v, name, style)`. Underneath it calls `NL(..., label_every=1,
_legacy=...)`. The line-spacing rule is not applied to legacy callers (z08 2ב
prints '10' at 15.8 units on 20-unit steps). The figure is fam-tagged, ticks
are anchored at 0, a mark between ticks is drawn as an estimate
(`between=True`), and off-line or reversed marks are refused. Of the census
(z01_a, z08_a, z47_a, work_a) only z08 f008 (2ב) changes: its dot now prints
at the 3.5pt marker floor, where it was a 1.4pt speck.

**Not in this chunk** (they arrive in C5 below): vertical lines,
`stack`/`double`/`zoom`, `sign_chart`, `bars_from_zero`, `reference`,
`student_drawing`. `intersect` draws the result on the line it is called on;
a separate result row belongs to `stack`.

Tests: 20 C4 checks in `selfcheck_v6.py` and 36 cases in
`python3 numberline.py` in the first cut; round 2 below brings them to 35 C4
checks (162 in all) and 53 cases.

### C4 round 2 — what the verifier found, and the fixes

**What was wrong.** An independent verifier drove the first cut and found
fifteen defects:
- A value label printed `_num(v)`: '0.333333' beside the tick '1/3', '1.5'
  beside '1½', '3.16228' for √10.
- The set read-back could not fail for a deleted end circle, a deleted ray
  head, or a boundary circle moved off its boundary.
- Correct drawings were refused with a wrong diagnosis:
  - a square marker's sides were read as ticks on a thirds line;
  - a sketch line's two ticks were read as equality marks;
  - a mixed number's whole part was grouped with the previous tenth.
- A point on an open set end was told "use tri", and the tri was then refused
  as "one marker per value", a loop with no way out.
- Two sets on one line passed at the call and were refused at render, naming
  the call already made.
- The builder drew layouts its own checks refused:
  - jumps called out of order (head into the next start);
  - short arrow2 spans (heads overlapping);
  - a '?' placed where another arc ran through it;
  - symmetric()'s tips meeting at 0 in a bow-tie.
- Overlapping jumps floated on stacked levels, unconnected to their ticks.
- A point on a line breaking the 6pt floor was blamed "within r of the next
  tick", and the message suggested a zoom() that does not exist.
- '+7/2' and '4 cm' labels were never compared with the drawing.
- Eight rules had no test that could fail.
- The shim read `size` per step, not per unit.
- Set boundaries and answer_values off the ticks were accepted.
- '1 < x > 3' was accepted.
- Some messages named fixes that did not exist.

**What changed.**
- Value labels: `value_label=True` draws the value as the line draws its
  numbers: a stacked fraction on frac/mixed lines, and wherever a decimal
  cannot print the value. An estimate needs `value_label='3.2'`, which is
  checked to its last digit.
- The sweep reads sets from the drawing:
  - every bar end carries a circle or a ray head;
  - every circle on the axis is read at its own value (filled = in, open =
    out) against the source;
  - samples are taken just past every drawn bar end;
  - a ray head (or its absence) is a claim about the values past the line's
    end.
- svgcheck's axis reader no longer counts the sides of a small white-filled
  closed marker, or the base of a filled arrowhead, as tick marks. Sketch
  lines skip mark_geometry.
- `sweep` assembles numbers before assigning them to ticks: a stacked pair,
  plus a whole part beside it at mid height.
- A point on a set end is refused naming the call that works,
  `point(v, name, '<the end's style>')`, and that call renders.
- One set per line, refused at the call, naming `nl.union(N.solve(...),
  N.solve(...))`, `nl.intersect`, or a second line.
- Jumps are laid out in chain order and GROUNDED: every arc leaves its start
  tick and lands its head beside the axis (above) or beside the row of
  numbers (below). A jump that overlaps another takes the other side first,
  then a taller arc crossing it; the first choice whose head stands the arrow
  gap clear of every other arc and head wins. Room for each label over its
  apex is reserved while arcs are chosen. Labels are then placed at the apex,
  or slid along the arc, clear of every arc, head and label, with nothing
  between the label and its own arc. Jumps that land on one value from one
  side, on both sides and at every height, are refused ("draw these jumps on
  two number lines"). The sweep refuses a floating arc.
- A jump printed shorter than 2 head lengths, or an arrow2 span shorter than
  two heads plus the gap, is refused naming `tier=` or `kind='bracket'`.
- Arrow2/double heads that meet at one value stop half the arrow gap short
  of it. Stacked spans clear each other's heads. The sweep wants head boxes
  >= 1pt apart.
- Refusals found during layout (separation, off-tick, short spans or jumps)
  are raised after the printed floors, so the floor message wins. No message
  names zoom().
- Labels parse `+7/2`, `−1 1/2` and `4 cm`. A label mixing digits with other
  text is refused. `symmetric(1/3)` prints `1/3`.
- Set boundaries (`from_inequality`/`interval`/`ray`/`union`/`intersect`/
  `integers_in`) and `answer_values` must stand on a tick; set ends accept
  `between=True`.
- A chain reads one way, with x in the middle; an inequality needs an x.
- The shim: `size` is units per unit again (v5.8), and a mark between ticks
  is drawn with `between=True`.
- New sweep rules: labels off the row stand >= 0.5 em apart; every tick
  inside a bar has its white knock-out. The unreachable
  "letter below the row" fallback is removed.

Tests: `c4r2_*` in `selfcheck_v6.py`, 15 checks. Each fails on the first cut
(v6/verify_C4_r1/skill_frozen) and passes now. `python3 numberline.py` has 53
cases. v6/C4r2/mut.py runs 44 mutants, and all are killed except `auto_k1`.
That one is equivalent: `_pick_k` re-chooses `k` at render. Of the verifier's
43 mutants (v6/C4r2/vmut.py), 38 are killed and `auto_k1` survives. Three
no longer match the code and were re-targeted in mut.py, where they are
killed. `letter_below_row` mutated code that has been removed. The census
(z01_a, z08_a, z47_a, work_a) is byte-identical to the first cut.

### C4 round 3 — Hebrew, labels read back, and refusals that push the right way

**What was wrong.** The verifier's third pass found:
- Hebrew went straight into the number line's `<text>` and printed reversed.
  `figkit.Figure` refused it, but a point name, a span label or a jump label
  on `NL` did not, and no sweep read it.
- Only the builder checked jump and span labels. A mutant that moved every
  jump label to its arc's start passed every check, and so did hand edits of
  the finished SVG: '+5' moved over the next hop, '+5' changed to '+6', a
  `symmetric()` label 4 changed to 3, a span label 5 changed to 4.
- An estimate point within r of a tick was told to use a wider tier or a
  shorter range, even where neither helped. The fix that works for real
  data, a coarser tick, was never named, so the easy escape was to round
  −395 to −400.
- The off-tick refusal for `symmetric` and `double_arrow` named
  `between=True`, a keyword neither accepted.
- A jump label was compared with `answer_hidden`, so '+3' on 1 → 4 was
  refused beside a hidden answer at the position 3.
- A test marker on a set's end was told to become an open point, which drops
  the marker.
- `label_every="auto"` on frac/mixed lines counted every 1, 2, 4, 5 or 10
  ticks from 0. A thirds line numbered −2/3, 0, 2/3 and left the whole
  numbers and both ends bare.
- Nothing tested the rim clearance at the hi end, and the sweep read open
  circles only.
- Some simple 3- and 4-hop walks were refused.
- The shim refused a crowded line with a bare "struck label".

**What changed.**
- **Hebrew.** `NL` refuses a right-to-left letter in a point name, value
  label, span, jump, symmetric or double-arrow label at the call. The message
  says to draw a Latin letter or number and put the word in the HTML.
  `svgcheck.rtl_text` (new, part of `problems()` for every figure) reads
  Hebrew, gershayim and Arabic in the finished SVG.
- **Labels read from the SVG** (`numberline._carried_labels`, run by
  `sweep`). A label off the row that is not centred over a marker belongs to
  the first jump arc or span straight under it, toward the axis. The builder
  keeps every other arc out of that column. The rules:
  - a jump label stands over 18–82% of its hop (the builder slides it within
    20–80%), never over a junction;
  - it stands within 2px plus one line of its arc (a span label within its
    head plus 1.5px), or it floats;
  - a numeric label equals what the drawing shows: tip − start for a jump,
    the distance between the ends (arrow tips or bracket legs) for a span or
    a double-arrow half, within 0.45 × the minor tick spacing;
  - a label over no arc, span or point is refused.

  The message reads the drawing back to its ticks ("the drawing shows as
  +5"). The label-to-start mutant and the four hand edits are caught.
- **Estimates near a tick.** The refusal now computes a coarser tick first
  (×2, ×2.5, ×5, ×10 … of the tick, at least 4 on the line) on which every
  exact value is still a tick and every estimate clears every tick. It names
  it ("use a coarser tick (tick=5)" for the z01 q11 temperatures, "tick=250"
  for −395). `tier='strip'` is named only when the strip clears the value.
  The rule still counts unnumbered ticks: svgcheck's independent dot sweep
  (E29) refuses a disc half over any tick, so dropping them from the
  builder's rule only swapped this message for svgcheck's, which names no
  tick. The message marks such a tick "(unnumbered)" and ends "never round
  the value".
- `symmetric(a, label=True, kind="arrow2", between=False)` and
  `double_arrow(center, d, label=None, between=False)`. A test marker's
  off-tick refusal no longer names `between=`.
- `answer_hidden` is positions: a jump that lands on one is refused, and so
  is a span label equal to one, but a jump label (a displacement) is not.
- A test marker on a set end is refused naming a second line with the same
  range, `N.NL(lo, hi).test_markers([(v, 'x')])`, and that call renders.
- Auto numbering on dec/frac/mixed lines picks only every k-th tick where k
  divides the denominator or is a multiple of it. A thirds line numbers
  −1, 0, 1, and every whole number is numbered or none in between is. An
  explicit `label_every=` is kept.
- The rim sweep reads filled circles too ("a filled circle's rim"). A right
  end circle and a filled point at hi are tested both ways.
- Jumps: after every taller choice fails, LOWER arcs nested under an
  overlapping jump are tried. Every layout that had a place keeps it.
  `chain([−4, 3, −8, 2])`, `[−2, 6, −5, 5]` and `[−1, −8, −4, −7]` now
  render (3 of the verifier's 23 refused walks). No arc may pass within
  2 × the arrow gap of another jump's START, which would hide the tick that
  jump leaves. Two jumps leaving one tick fan out and are exempt. The
  builder and `sweep` both apply this rule. It refuses `[1, −4, 5, 0]`,
  whose only lower arc grazed the start of 1 → −4. Before the rule, no
  layout accepted in 700 random walks broke it. Hops that land on one value
  from one side are still refused ("two number lines").
- `double_arrow` half labels closer than 0.6 em are refused by the builder,
  naming `tier=`. svgcheck used to refuse them naming no fix.
- `figkit.number_line` (legacy): numbers that strike each other are refused
  naming `size=` (computed) or a coarser `step=`. Numbers printed under 7pt
  are refused naming `width=` (computed), and a smaller `size=` when one
  still clears the numbers. Neither message offers a smaller font. The two
  v5.8 calls this now refuses (`0..1 step .25`, `−1..1 step .5`) raised
  TypeError in v5.8 and printed overlapping numbers in the first C4 cut.
  E13 stays: a step other than 1 numbers multiples of step from 0.

Tests: `c4r3_*` in `selfcheck_v6.py`, 11 checks (173 in all). Each fails on
the round-2 code (v6/C4r3/frozen) and passes now. Fixtures corrected:
`c4r2_correct_drawings_accepted` pins `label_every=4` to keep its whole
parts, since auto now numbers the halves. `c4r2_floors_before_point_rules`
no longer wants `tier=` in a strip line's message: strip is the widest tier.
`c4r2_mutant_killers` gets its crowded line by hand-enlarging a clean
line's numbers, since the shim now refuses the crowd itself. The census
(z01_a, z08_a, z47_a, work_a) is byte-identical to round 2.
`python3 numberline.py` has 63 cases. v6/C4r3/mut3.py runs 25 mutants of the
new rules, and all are killed. The verifier's v6/C4r2 mutant list
(v6/C4r3/vmut2.py) now kills `jump_label_at_start` and `no_rim_pad_r`.
`samples_4` and `bar_under_marker_order` still survive; both are
equivalent (the call-time check also compares the set's parts, and the
second mutant only assigns an unused variable). `hidden_ok_symmetric_lab`
is killed by a new line in `c4r3_jump_label_is_not_a_position`.

## C5 — rows of number lines, a second scale, a vertical scale, sign charts, bars, references, and the wrong drawing

**What was missing.** C4 shipped one horizontal number line at a time. The
packages need more: z01 compares a decimal line with a fraction line (5ו,
23), draws distance bars from 0 (1ב, 3ב, 11ב, 34ב, 36ב), marks a mirror or a
water level across the axis (q1), and prints a thermometer standing up (36);
ח ratio and percent items want a double number line; ט quadratic
inequalities want a sign chart; h52 and z01 q24 want a line drawn WRONG for
the student to criticise. The package kits did all of this by hand, and each
hand-drawn version carried its own defects (a one-sided dash that read as a
stray tick, a bar 0.04pt long, rows that were not on one scale).

### The API

    import numberline as N
    N.new_sheet(arrows="right")                     # once per sheet, as before

    # a vertical scale: numbers left, points and jumps right
    N.NL(-40, 60, tick=10, orientation="v", height=230)   # height = lo..hi, px
     .reference(0, "sea", label="S").point(30, "A").jump(-20, 30, "+50").svg()

    # a dashed reference line across the axis (mirror | level | sea)
    NL.reference(v, kind="level", both_sides=True, label=None, between=False)

    # distance bars from 0, one row each, keyed by Latin letters
    NL.bars_from_zero(values, order="given"|"asc", row_ids=["A", "B", ...],
                      min_len_pt=3, between=True)

    # rows under one another; captions come back as an HTML column
    N.stack(rows, scale="shared"|"own", captions=[...], connect=[values],
            tier=None, width=None) -> Stack     (.svg(), .html(), .rows)

    # a magnified segment under its line, joined by dashed connectors
    NL.zoom(a, b, subdiv=10, tier=None, captions=None) -> Stack
                                                (.parent, .child)

    # one axis, two scales: ratio, percent, unit conversion
    N.double(scale_a, scale_b, parts, hide_a=(), hide_b=(), pairs=(),
             ratio=True, tier="block", captions=(over, under)) -> Double

    # the sign chart of a polynomial
    N.sign_chart(roots, signs, closed=True, poly=None, touch=(), tier="side",
                 student_drawing=False, asks=None)

    # a deliberately WRONG line, for an error-finding item
    N.NL(..., student_drawing=True, asks=["find_error"],
         wrong_scale=[(2, "2.5")])
    NL.from_inequality("x<2", closed=True)       # the student's wrong circle
    N.NL(..., asks=["find_error"],                             # C5 r3
         student_drawing="the point stands at 3, the answer is 2")
    N.sign_chart([-2, 3], ["−", "+", "−"], poly=[1, -1, -6],   # C5 r2
                 student_drawing=True, asks=["find_error"])

    # the sweeps, each reading a finished SVG and nothing else
    N.sweep_v(svg, dots=[values]) / N.stack_sweep(svg, shared=, zoom=, rows=)
    N.double_sweep(svg, ratio=) / N.sign_sweep(svg, poly=)
    N.critique_guard(question)                   # emit_html calls it for you

**A vertical line is the same drawing, turned.** Every layout is computed in
one SCALE FRAME: x along the scale, y across it, decorations at y < 0 and the
row of numbers at y > 0. A horizontal line prints the frame as it is; a
vertical line prints it through (x, y) → (−y, −x), so the scale runs up,
numbers stand left of the axis and points, letters, jumps and spans right of
it. Text stays upright, so in the frame a text box of a vertical line is 1.02
em along the scale and its advance across it (`_Canvas.dims`); the jump
layout, the spans, the letter placement, the separation rules and the sets
are the C4 code, unchanged. Two rules are the vertical line's own: a number's
HEIGHT is what stands along the scale, so numbered ticks need
`LABEL_V_SPACING` (1.3) lines instead of 1.6 widths, and `height=` (the
printed length of lo..hi) replaces the tier's width. `label_fmt='frac'` is
refused on a vertical line: a stacked fraction cannot be read beside a tick
in one line. `sweep_v` turns the finished SVG back into the frame and hands
it to `sweep`, so every C4 rule applies again — plus the vertical spacing
rule and the side-by-side merge rule, read on the drawing as printed.

**Rows.** `stack` draws and checks every row on its own, then composes them
into ONE figure with `<g transform="translate(...)">`, so the alignment can
be drawn and read back. `scale='shared'` (the default when the rows share
their range) fits every row to one unit and puts a value at the same x on
every row; `scale='own'` fits each row to the width. Rows with different
ranges and no `scale=` are refused, naming both. `connect=[values]` draws
dashed connectors (`CONNECT_DASH`) between adjacent rows; a connector runs
from just past the ink of its column on the upper row to just before the ink
of its column on the lower one, and everything in that column must stand
centred on the value — a connector that would stop at a jump arc crossing the
column is refused, naming a value whose column is clear ("the rows stay
aligned without a connector"). A connector at a value one row has no tick and
no point for is refused, naming `point(v)` on that row.

**zoom.** `NL.zoom(a, b, subdiv)` shades a..b on the line (a light band, not
ink, so nothing hides a tick) and draws that stretch magnified below, joined
by two dashed connectors. Its ends must be ticks of the parent (the message
names the enclosing ticks), and the magnified row numbers its OWN ticks
(`label_fmt` is set from the child's tick, since auto numbering would have
printed only 2 and 3 on a tenths line).

**double.** One axis, `scale_b` numbered under it and `scale_a` over it, both
in `parts` equal steps. `hide_a` / `hide_b` print '?' where the item asks for
a value. `pairs` are the pairs the item states, and a pair this line does not
draw is refused ("32 pairs with 40"). `ratio=True` (the default) demands 0
against 0; two scales that are linear but not proportional (°C and °F) need
`ratio=False`. `double_sweep` cuts the two scales apart on the finished SVG,
MOVES the upper row under the axis (a translation, so a stacked fraction
still reads numerator over denominator) and reads each with `sweep`; then it
checks that every tick carries exactly one entry above and one below, that a
'?' stands on a tick, and — with `ratio` — that the tick carrying 0 below
carries 0 above.

**sign_chart.** The roots as circles on a sketch line (filled where the
inequality is weak), a '+' or U+2212 over each interval. With
`poly=[coefficients]` the chart is READ OFF the polynomial: every listed root
is a root, no root is missing (the search runs to the Cauchy bound, so a root
far from the listed ones is found), and every sign is the polynomial's own
sign on its interval. Without a polynomial the signs must alternate, except
at a root declared in `touch=` (a double root). `sign_sweep` reads the
finished SVG: one sign per interval, clear of the root circles, and the sign
the polynomial has at a value read back from the numbers.

**bars_from_zero.** The z01 distance-bars device: one bar per value from 0,
one row each, top-down in the item's order (or `order='asc'`), each keyed by
a Latin letter drawn left of the line — so the item text names the rows
without a Hebrew caption inside the SVG. A bar shorter than `min_len_pt`
(3pt) is refused BY NAME, and the message computes a line on which that value
can be seen ("N.NL(-1, 0, tick=0.1)", a split scale with
`N.stack([...], scale='own')`); z01 3ב drew that bar 0.04pt long and the empty
row was the answer. A bars line carries its bars only; a point or a jump on it
is refused, naming a line of its own. The same "too small to see" message now
ends the point-near-a-tick refusal as well.

**reference.** A dashed line across the axis at a value: past the ticks on
the decorations' side and, with `both_sides`, past the number standing at
that value on the other. It is CUT around every label it would run through
(doctrine: cut the stroke, never drop the information) and it runs past
everything standing in its column, so it is never mistaken for that
decoration's own mark. `sweep` refuses a dashed mark that runs less than
`REF_MIN_PT` (10pt) from the axis where a tick would stand — the z01 q1
one-sided dash that read as a stray tick — and a label floating over its
reference line.

**The wrong drawing.** `student_drawing=True` / `wrong_scale=[(v, text)]`
draw a line that is wrong on purpose. They are refused unless the LINE
declares `asks=['find_error']`; the SVG then carries `<!--critique:
find_error-->` and the fam key says `+critique`. In critique mode the
inequality sampling and the value vote are skipped (the numbers are wrong on
purpose) while every other rule still holds. A critique line must be drawn
wrong — see C5 round 3 below. `emit_html` calls `numberline.critique_guard(q)`
for every question and `emit_plus` calls it for every question that carries
item figures: a critique figure beside an item that does not declare
`asks=['find_error']` is refused (it would read as the answer), and a question
that declares it but shows only CORRECT number lines is refused too (the
giveaway rule, L7).

**Captions.** `Stack.html()` and `Double.html()` return the figure with its
captions as an HTML column beside it, each caption on its row's axis, so
Hebrew never enters the SVG (G49). The SVG alone is still available from
`svg()`.

Tests: `c5_*` in `selfcheck_v6.py`, 8 checks, each with a case
that renders and a case read back from a hand-edited SVG (a row shifted off
the shared scale, rows pushed together, a connector moved, a zoom band
widened, a number of the second scale changed, a '?' slid off its tick, a
sign flipped or slid against its root, a reference cut back to a tick's
length, a bar that misses its value, a row letter deleted, a vertical number
slid or swapped, two letters printed side by side). The census (z01_a, z08_a,
z47_a, work_a) is byte-identical to C4 round 3.

### C5 round 2 — the parts a double line draws, the dot on a vertical line,
### and the sign chart a student got wrong

Five things the independent verifier found, each now with a case that fails
without the fix.

**A double line's parts ARE the axis ticks.** `double()` numbers the axis
from `scale_b`, and a line's ticks stand at multiples of its step from 0
(E13). With ends that are not multiples of that step the line quietly drew
OTHER numbers than the parts asked for — `double((0, 100), (32, 212), 10)`
printed 36, 54, … under the axis instead of 32, 50, … — and only the generic
second-scale sweep complained, twelve times and without naming a fix. The
ends are now checked at the call, and the refusal names the paths that exist:

    numberline.double: the axis is numbered from scale_b, whose ticks stand at
    multiples of the step from 0 — 32..212 in 10 parts steps by 18, and 32 is
    not a multiple of it, so the line would print 36, 54, ... instead of
    32, 50, ... — swap the scales — double((32, 212), (0, 100), 10,
    ratio=False) numbers the axis from the scale that does fall on ticks and
    prints this one over it (hide_a/hide_b, pairs= and captions= swap with
    them); parts=6 (a step of 5, which divides both ends); or move scale_b's
    ends to multiples of its step

The swap is named only when scale_a's own ends do fall on its step (so the
named call renders), and a `parts=` is named only when one exists at or under
20 (`_double_parts`). The °C/°F line therefore works in both orders: one
renders, the other says which one to write.

**A dot on a vertical line reads its value.** C5 passed `dot_values=` to
svgcheck only for a horizontal line — svgcheck reads the numbers against a
horizontal lattice — and nothing took over upright, so a point drawn a whole
tick off passed every check (the z01 28-ב defect, standing up). `sweep_v`
now takes `dots=[values]` and runs `svgcheck.dot_on_other_tick` in the turned
frame, and `render()` feeds it the same list the horizontal line gets:

    N.sweep_v(svg, lo=-150, hi=150, dots=[120.0, -120.0])
    -> ["dot at -50.0 reads as 110, not one of [120.0, -120.0] — draw it at
        its value"]

(the coordinate is in the turned frame, as every `sweep_v` message is; the
value it reads back is the page's own.)

**A sign chart can be drawn wrong on purpose.** `sign_chart()` took
`student_drawing=` and `asks=`, but its sign and root rules ran first and
refused the wrong chart an error-finding item is about — so such an item
could not be drawn at all, and no refusal mentioned the route. Now:

    N.sign_chart([-2, 3], ["−", "+", "−"], poly=[1, -1, -6],
                 student_drawing=True, asks=["find_error"])   # renders

`poly=` is required in that mode (a chart is only wrong against the
polynomial it should have been read off), every disagreement is collected
instead of refused, and a chart that turns out to be RIGHT is refused — the
giveaway rule again, this time inside the builder. Outside that mode every
sign refusal now ends with `CRITIQUE_FIX`, which names the route:
"— or, if the item asks the reader to FIND this error, draw it on purpose:
student_drawing=True, asks=['find_error']".

**A value read off a drawing prints as a number.** `_read(v, step)` rounds a
value measured off the SVG to a thousandth of the step it was measured in, so
the vote's message says "stands on the tick of 0" where it used to say
"stands on the tick of −1.77636e−15".

**Four sweep branches got their failing case** (doctrine 2): a distance bar
that does not start at 0, a connector that skips a row, a connector that
floats below its upper row, and a zoom that shades two stretches of its line.
Each is now killed by a hand-edited SVG in `c5r2_stack_and_bar_branches`.

Tests: `c5r2_*` in `selfcheck_v6.py`, 5 checks; the census is unchanged.
Gallery question 37 is the sign chart drawn wrong on purpose.

### C5 round 3 — the critique contract everywhere, the readers that were
### never called, and refusals that name the caller's own knob

Seven more findings from the independent verifier. Five of them are one
shape: a rule was written and then not reached.

**The critique contract reads the ITEM figures too.** `emit_html` calls
`critique_guard(q)` inside `if q.get("fig")`, so the contract covered the
question head only. An item figure — the `emit_plus` 4-tuple
`("א", text, space, fig)`, a route real levels ship on — reached the page
through `emit_plus._prepare`, which rewrites the 4-tuples away before the
emitter ever sees them. A deliberately wrong number line stood beside an
ordinary item with nothing to stop it, and the giveaway direction was just
as blind there. `critique_guard` now reads EVERY figure of the question —
`q['fig']` and each item's — and names the item it refuses:

    question 1 item א shows a deliberately wrong number line (student_drawing
    / wrong_scale) but does not declare asks=['find_error'] — ...

`emit_plus._prepare` calls it for every question, on the author's own dict,
where `asks` is still in reach. The giveaway direction asks that at least one
of the question's number lines be the student's, so an error-finding item may
still show a correct line beside the wrong one. Gallery question 38 ships
that route.

**A critique LINE must be drawn wrong.** For a number line the giveaway rule
was satisfied by the FLAG: `NL(..., student_drawing=True,
asks=['find_error'])` with nothing wrong on it rendered, carried the critique
marker and passed `critique_guard` — the correct answer, standing beside an
item that asks the reader to find the error. `sign_chart` refused exactly
this ("…but it is the CORRECT chart of p(x)"); a line did not. Now the line
remembers WHAT is wrong on it: a `wrong_scale` number, or a set that
disagrees with the inequality it was drawn from (in critique mode the
disagreement is kept instead of refused, and recorded). A line with nothing
recorded is refused, and the refusal names the three routes:

    numberline: this line declares student_drawing=True ... but nothing on it
    is drawn wrong — it IS the correct drawing ... Draw the error:
    wrong_scale=[(2, '2.5')] ... or from_inequality('x<2', closed=True) ...;
    if the error is one the drawing cannot show by itself (a point at the
    wrong value, a missing arrow), name it in words —
    student_drawing='the point stands at 3, the answer is 2'

That third route is the new one: `student_drawing=` takes a string, which is
the author's own statement of the error and counts as the declaration. It
keeps the rule from blocking the errors a builder drawing from numbers cannot
see — doctrine 4, the easy path first.

**`sign_sweep` is called at render.** It is the independent reader of a sign
chart, and `NL._sweep` dispatched to `double_sweep` / `sweep_v` / `sweep`
only — and `sweep(signs=True)` deliberately marks the '+' / '−' texts as
owned and says nothing more about them. A sign in the wrong interval, two
signs in one interval or a sign missing altogether shipped unseen. `render()`
now runs `sign_sweep` on every sign chart, with the chart's own polynomial —
except a critique chart, which is read WITHOUT it (its disagreement with p(x)
is the point of the figure; the structural rules still run).

**The ratio rule reaches the drawing.** `double_sweep`'s "a ratio line pairs
0 with 0" could not fire on a shipped figure: `NL._sweep` built its kwargs
without `ratio=`, and `nl._ratio` was never read. It is passed now.

**Both halves of one pair hidden** was refused by a generic svgcheck message
— "label '?' stands in the row of the x-axis numbers … place it off the row"
— naming a fix that belongs to the builder, not to its caller. `double()`
refuses it by name:

    numberline.double: the pair (24, 30) is hidden on BOTH scales
    (hide_a=24 and hide_b=30) — that tick carries '?' over the axis and '?'
    under it, and nothing is left to read the pair from. Hide one side of a
    pair: hide_a=[24] ... or hide_b=[30] ...

**A reference line is held to `answer_hidden`.** `NL.reference` passed
`hidden=False`, so a dashed line across the axis at the hidden answer, with
its Latin label over it, marked the answer's position — while a bar, point or
span on the same value was refused.

**A zoom names `subdiv=`.** When the magnified row broke the printed tick
floor the refusal named `tick=` and the placement tier — parameters the
author never wrote on that figure. The row now knows it is a zoom:

    numberline.zoom: the magnified row cuts 3..4 into 50 intervals, 2.6pt
    apart, floor 6pt — use fewer intervals (subdiv=21), or a wider placement
    (tier='block' or 'strip')

and `subdiv=21` renders. Where no subdiv fits, the refusal says so instead of
naming one.

**One more, found by the gallery.** `emit_plus` appends its `<style>` block
after the house sheet, and two of its rules were unscoped: `table.figrow{…}`
and `table.figrow td{padding:0 7pt}`. One item figure anywhere on a page
therefore added 7pt to each side of every cell of every QUESTION-level figure
row, widening the rows until a title beside one wrapped into the figures
(gallery q23's `triangle_with`, struck by a triangle's side, as soon as q38
put an item figure on the sheet). Both rules are now scoped to
`.it > .ifig`, and a check asserts every selector of that block stays inside
an item.

Tests: `c5r3_*` in `selfcheck_v6.py`, 6 checks (192 in all); `python3
numberline.py` has 119 cases; 33 + 13 + 17 mutants (`v6/C5/mut.py`,
`v6/C5r2/mut2.py`, `v6/C5r3/mut.py`) are all killed; the SVG figure census
is byte-identical to the previous round. *Correction (stage-1 open issues):*
a figure census cannot see page layout, and one shipped page did change —
z47_a page 8 carries both item figures (q15) and a question-level figrow
(q16's five prisms); with the rules scoped, that prism row lost the 7pt cell
padding it never should have had and 53 words on the page moved. The page is
correct (G72 passes, nothing lost), and it is exactly the fix above, but "no
shipped level changed" was not true. With the fixes reverted (`v6/C5r3/unfix.py`)
`selfcheck_v6` reports 186 of 192 — the six new checks and nothing else. The
gallery is 38 figures on 9 pages: question 38 is a student's wrong drawing
inside a sub-item, its error named in words.


# v6 — stage 1b: a number never cuts a line

The tool comparison (Typst, LaTeX/TikZ, Penrose and this engine drawing the
same five figures) settled a question stage 1 had answered the wrong way.
Asked for a triangle A(−4, −2) B(3, −2) C(3, 4) on a −6..6 plane at 8 cm, our
engine printed **two of its three sides in pieces**: side AB was cut behind
the y-axis number −2 and side AC behind the x-axis −2. The same run put a hole
in a parabola beside the y-axis −2. Every gate passed: `svgcheck.problems`
reported nothing on either figure, because no gate knew that ink had gone
missing. Typst, drawing from the same JSON, cut nothing and moved the two
numbers instead.

The author's rule, 2026-09-16:

> A data stroke — a line, a segment, a polygon edge, a curve, a circle, an
> arc, an arrow — is **never cut, broken, shortened or hidden by a number**.
> Only light grid lines may be knocked out under a number, and the axis line
> itself is never cut. **A number is never deleted.** The number is what
> moves, and only the number that is in the way.

## What changed in the engine

**Nothing is cuttable any more.** `Figure._pin_blockers` used to sort the ink
under a pinned number's plate into "cuttable" (a data stroke, cut at render)
and "hard" (an axis, a tick, a dot, an arrowhead, a mark). Now every one of
them is hard. `L.cut` is never set, `render` emits no cut boxes, and the
legacy `label(..., sector=)` path no longer cuts either — it takes its spot
only when nothing is there. `Figure.check_complete` therefore now asserts that
the file draws **100%** of what the figure was asked to draw.

**The number moves, in four tiers** (`Figure._pin_spots`), nearest first:

1. it slides along its own axis, up to `PIN_SLIDE_INK` (0.34) × the tick
   spacing — under half a spacing, so its centre stays nearer its own tick
   than any other;
2. the other side of its axis, at the same slides;
3. the nearest diagonal spots: a step of up to `PIN_DROP_EM` (0.70 em) away
   from the axis together with a slide, its own side before the other;
4. failing all of those, the figure is refused, and the message names the
   fixes that keep both the number and the stroke. It never offers "drop the
   number".

A number that crosses its axis may not land in the other axis's row of
numbers (`Figure._in_other_row`) — there it reads as one of them, which
`svgcheck.reading_merge` refuses off the finished file.

**A row still reads as a row.** `_choose_sides` sends a whole row across its
axis when staying would scatter it; it now scores the two sides by the number
of BLOCKED NUMBERS, not by the length of stroke a cut would have taken, since
nothing is cut any more. After the search, `_solve_pins` re-reads every number
where it finally stands and refuses three things the solver could otherwise
talk itself into: a number ink still covers, a row split more than one in four
across the axis, and a row whose numbers have nearly all had to stand aside.

**`step=None` is the default** (`figkit_plus.auto_step`): every 2 squares on an
axis long enough to carry two numbers that way, every 1 on a short one, each
axis for itself. This is not cosmetic. With a number on every square, the line
y = 0.8x runs through the '−1' of both axes at once, and with nothing cut and
the other side of the axis taken by the y numbers, that figure has no answer.
Numbered every 2 it is drawn with room to spare. An explicit `step=` is
honoured, and an axis the author numbered himself is judged at the step his own
values imply. `plane()` also climbs a ladder before it refuses (rule 5): the
step the author asked for, then every 2, then bigger squares while the drawing
still fits `max_width`.

**A dashed guide is a data stroke too.** v5.8's one legal deletion — the stub
of a guide between a pinned number and its axis, so it read 'P ---- 8|' — is
gone. The guide is drawn end to end and the number crosses its axis.

## `curves=` in `plane()`

Stage 1 had no way to draw a function. A package had to sample it itself and
hand `plane()` a list of `solid=` segments, which is how the comparison's F4
came to be a chain of 240 `<line>` elements that lost 5.4% of itself.

    plane((-3, 6), (-5, 8),
          curves=[(lambda x: x*x - 2*x - 3, "f"), (lambda x: x + 1, "g")],
          points=[(p, n) for p, n in zip(
              intersections(lambda x: x*x - 2*x - 3, lambda x: x + 1, -3, 6),
              "PQ")])

- an entry is `(f, "name")` with `f` a callable `y = f(x)`, or
  `(points, "name")` with points already in data units; `None` for the name
  draws it unnamed;
- a callable is **sampled adaptively** (`_sample`): an interval is split
  wherever its midpoint leaves the chord, so a parabola's vertex is round and
  a straight stretch costs four points. A pole or a negative root simply ends
  the run;
- every piece is **clipped exactly to the window** (`clip_polyline`,
  Liang–Barsky per segment). A curve that leaves the window and comes back
  gives two pieces, with the crossing points computed, not sampled;
- each piece is emitted as **one `<path>`** (`Figure.curve`), never a chain of
  `<line>`s;
- the name goes at a free end of the curve: the anchor is walked back along
  the last piece and the placer's ring search takes it off the curve;
- `intersections(f, g, x0, x1)` returns the crossings, bracketed on a fine
  grid and bisected, so the dots a question asks for sit on the exact points.

## The lost-ink gate (`svgcheck`)

Two sweeps, both reading the finished file and neither knowing anything about
the builder.

**`lost_ink(svg)`** — collinear dark pieces of the same width, with a hole
between them no wider than the plate of a NUMBER that stands in it, are one
stroke that was cut. The hole must also be small beside the pieces it left, so
two shapes that share a baseline (the two triangles of a congruence pair) are
not mistaken for one cut stroke; a dashed stroke is skipped, and so is a hole
holding a plotted point or an arrowhead — that is what `stop_short` draws. It
runs inside `svgcheck.problems`, so every render is swept.

**`draws(svg, geometry)` / `assert_draws`** — the emitted dark stroke length
must reach 99.5% of the geometry the builder hands in, measured off the file
by this module's own parser. `Figure.check_complete` is the same rule derived
from a figure's own primitives; `draws` is the door for a package that builds
its SVG another way.

## What svgcheck now allows, and what it does not

A number that has stood aside is still judged. `TICK_TOL` (0.15) remains the
tolerance for a number on its tick. `MOVED_TOL` (0.35) is how far ONE number
of a row may stand from its tick to keep a stroke whole — still well inside
half a spacing, so a reader cannot mistake which tick it names. Past that it
is refused as slid, exactly as before. And a row is refused when more than one
number in `MOVED_SHARE` (3, at least two) has moved, or when every number of
it has: a row with no number on its tick has slid, which is the z01 28ב defect
and stays refused at 0.15. The concession belongs to a number that stands ON a
tick; a value printed BETWEEN ticks ('2.5' at 2.5) has no tick to be driven
off and is still judged at 0.15. Number lines keep their own, stricter rule:
their numbers are under the line and their data above it, so none of them ever
has to dodge.

## Nested jump arcs (ported from the comparison)

Typst's number line drew a jump's height from its **nesting depth**: the
longer jump is the outer arc. Ours searched heights from the bottom up, and
since the `ARC_MAX` clamp gives every long hop the same height, a chain
1 → 9 then 3 → 7 came out as two arcs crossing each other twice. A jump's
height search now starts at the number of jumps that lie strictly inside it,
and level 0 stays available to a jump that nests under an arc already placed.
The three-deep case (0 → 12, 2 → 10, 4 → 8) draws as one arc inside another
with the third below the line. Our arrival tips and departures already stood
clear (a departure from a point another jump lands on starts an arrow-gap
along it), and our hollow markers are held to 3.5pt printed by E8, larger than
the comparison's 2.3pt, so neither was ported.

## Fixtures corrected, and why

Six v5.8 fixtures asserted the behaviour this policy ends, and were rewritten
to assert the policy instead. `selfcheck_plus`: "a number boxed in by two
lines stays at its tick and both are cut" now expects a refusal, and the guide
check expects one whole dashed line instead of a stub. `selfcheck_v6`:
`c2_e1_cut_pass_fail` became `c2_e1_uncut_pass_fail` (one `<line>`, and the
cut version refused by `lost_ink`); `c2_e4_polygon_kept` splits into a polygon
drawn whole and a new `c2_e4_row_boxed_in_refused`; `c2_e4_curve_chain` draws
its parabola with `Figure.curve` and asserts one path with one subpath;
`c2r2_completeness_independent` asserts `stubs == 0`; `c2r3_no_dashed_look`
expects ONE number to cross where the whole row used to. Where a fixture
cornered a number with two plotted points, it now takes a column of four —
two are answered by the step-out tier.

Tests: `s1b_*` in `selfcheck_v6.py`, 9 checks (212 in all with the round-3
checks below), including the
exact F4 and F5 data of the comparison at 9 cm and 8 cm. `python3
numberline.py` has 119 cases. z08_a and z47_a rebuild byte-for-byte green in
scratch copies; the pilot's `work_a` does not build on v5.8 either (it was
written for v5.6, before both axes had to carry numbers), and z01_a's
pre-existing `dot_on_other_tick` refusal is the same on both engines.

## Rounds 2 and 3 — what three independent lenses found

Three reviews read the finished stage-1b engine (one on the numbers, one on
the printed look, one pressing the author's rules against ordinary figures).
Between them they found that the policy above was right and the engine did
not yet keep it everywhere. What follows is the shipped behaviour.

**A pole ends the run** (`figkit_plus._sample`). `curves=` used to keep
appending into one list where `f` blew up, so `clip_polyline` joined the last
sample before the pole to the first after it and `y = k/x` — the ordinary
grade-9 inverse proportion — printed a **straight stroke down the asymptote**,
claiming the function has the value 0 where it has none. No gate saw it: the
stroke was whole. The sampler now returns RUNS. A gap in the samples alone
does not prove a pole (a steep stretch also skips), so `_pole` narrows on the
largest |y| it finds and declares one only when that maximum keeps GROWING as
the window narrows. `y = 4/x` is two paths, `tan x` on −3..3 is three, and a
parabola is still one.

**`intersections()` returns crossings.** The scan bracketed a root that
landed exactly on its grid TWICE — once correctly, and once as
[root, root + h] with f(a) = 0 — and the second bisection converged on the far
end, so `plane(points=…)` drew and lettered a dot where the curves do not
meet. It bit every window whose span divides the scan (−5..5, −4..4, 0..10,
−10..10); the only fixture, −3..6, did not. Every returned point is now
checked against d(r) ≈ 0.

**The origin's '0' slides too.** It had no slide tier at all — only the four
corner diagonals — so a stroke on each diagonal of a square blocked all four
corners and *a square with both diagonals*, and *y = x with y = −x*, were
refused at every size, width and step. `_pin_spots` now gives the origin the
same ladder as any other number, with its budget as the (x, y) pair.

**`hide=` and `origin=False` cannot blank a blocked number.** They used to
clear any pin refusal by deleting the number before the solve ran — rule 2 and
doctrine 4, in one keyword, and the escape a builder under deadline reaches
for. A blanked number is now put through the same collision test as a printed
one: if a stroke would have stood on it, the figure is refused with the real
message. (P3: `hide=` is now refused outright, whatever is standing on the
number — see the v6 — P3 section.)

**A row of TWO numbers is a row.** The slid-row back-stop was guarded by
`len(grp) < 3`, which made it dead code on exactly the rows the automatic step
of 2 squares produces on a short axis: the solver slid both numbers off their
ticks, believed the layout fine, and svgcheck then refused the finished file
with a message naming no fix. The guard is now `< 2`. In a 750-figure census
the `row` back-stop fires 130 times (it fired 0) and 525 of the 750 build (343
did). The `split` back-stop beside it stays defensive — `_choose_sides` picks
one side for the whole row before any number crosses — so its predicate
`_row_reads` is tested where it lives instead.

**The slide budget is a grid SQUARE.** `PIN_SLIDE_INK` was a fraction of the
number PITCH; with the automatic step of 2 that let a number stand 0.68 of a
square from its tick — a full glyph height at print size, its own tick bare,
its row-mates exactly on theirs — while svgcheck measures the same offset
against the tick spacing it reads off the file. The solver was producing
layouts its own gate refused. `_pin_budget` now takes the smaller of the
pitch and the square.

**The ladder is not stopped by a phrase.** `plane()`'s rule-5 enlarge ladder
retried only when the message contained "Do NOT drop the number", so every
refusal svgcheck raised off the finished file stopped it at rung 0 even when a
later rung rendered the figure cleanly. It now tests the exception CLASS
(`svgcheck.LayoutError`). And when every rung fails, the refusal says which
rungs were tried — an author who reads "a larger size=" and answers it with
`size=23` must not get the same refusal back.

**A number line never cuts either.** `numberline._cut_span` cut a reference
line behind EVERY box in its column and threw away any piece shorter than 2
units; one reference printed as three dashed stubs with the middle one gone,
and nothing could see it (`lost_ink` skips dashed strokes by design, and
numberline emits the pieces rather than cutting them out of a whole, so there
was no length to compare). A reference is now ONE stretch per span, running
out to the first label in its column — a guide that ends at the letter it
points to loses nothing.

**`lost_ink` sees a hole in a curve.** It matched only COLLINEAR pieces, so
the second of the two defects this chunk exists to kill — the gap in F4's
parabola — was invisible to the independent file-level gate. Two more
excuses had to go with it. The gap cap is the width a NUMBER's plate could
have taken out, but two pieces of the SAME `<path>` are not two objects that
happen to line up — every builder here emits one subpath per curve — so for
them only the "no wider than 0.6 of a piece" test applies. And a dot or an
arrowhead in the hole explained it with a reach that GREW with the gap, so a
2.4-unit plotted point excused a 48pt hole cut around it; each may now
explain only a hole it could fill.

**`draws()` walks the geometry, and `plane()` calls it.** The clause the brief
asked for ("builders pass the input geometry and render asserts emitted dark
stroke length ≥ 99.5% of it") was public API with no caller: only
`Figure.check_complete`, the builder's own bookkeeping, stood between a hole
and the page. Two changes make it real. `svgcheck.covers` walks the geometry
and asks at every step whether dark ink lies ON it, because comparing two
TOTALS lets the axes and ticks pay for a piece that went missing — a hole cut
out of the middle of the parabola left the sum above 99.5% and `draws` saw
nothing. And `Figure.frame0` now reports the corner the emitted coordinates
are measured from, so a builder can put its input geometry in the file's
frame; `figkit_plus.plane` does exactly that and asserts it on every render.
The message names the longest stretch with no ink on it, so it points at the
hole.

**A slid number cannot escape `tick_alignment`.** Refusal used to be
non-monotonic — a crossed number 0.36 and 0.45 of a spacing off its tick was
refused, 0.56 and 0.68 were called CLEAN. Two holes: a number that scored
badly against its own ticks scored better against the OTHER axis's and moved
into that group, where it was excused as a value label ("the tick already
carries it"); and a number slid past the FIRST tick of the run left both
groups, since `_axis_labels` reached only half a spacing beyond the end ticks.
Sliding far enough was an escape from the sweep that measures how far it slid.
Now an axis carries each value ONCE (a second '2' beside it is not its number,
and goes to the next axis that can reach it), and the run reaches a whole
spacing past its end ticks.

### Not changed, and why

*Partly overlapping jump arcs still cross.* The ported preference (the longer
jump is the outer arc) is enforced wherever it can be: 1 → 9 with 3 → 7 nests,
and so does 0 → 12 / 2 → 10 / 4 → 8. But when two jumps overlap without either
containing the other, the longer one's head must land INSIDE the shorter one's
span, so its arc crosses that stroke whatever height it takes — in the walk
`[-2, 6, -5, 5]` only one height on the free side clears at all, and it is the
low one. Crossing there is geometry, not policy.

*A y row may change side once at the origin.* A steep line through the origin
blocks the left of the axis above it and the right below, so `y = 8x` prints
2 … 10 on one side and −2 … −10 on the other. `_row_reads` allows exactly that
— two blocks, one change — and refuses a row that changes side twice or puts
two crossed numbers side by side.

Tests: `s1br3_*` in `selfcheck_v6.py`, 10 checks (212 in all), each with a
passing and a failing half, plus the corrected halves of
`c2_e4_polygon_kept`, `s1b_f4_curves_whole` and
`s1b_draws_measures_the_geometry` (`draws()` now returns two messages for a
deleted edge — the stretch with no ink on it and the total that is short — so
they read the list rather than its first entry) and `_geom()`, which now
shifts a figure's parts by `Figure.frame0`. An 18-figure corpus of ordinary
analytic geometry has no refusal the v5.8 snapshot did not also have (and one
it did); z08_a and z47_a rebuild green in scratch copies.

## Round 4 — the escapes a refusal left open, and a ladder that never climbed

Three more reviews pressed the round-3 engine the way a builder under deadline
would: take a refusal, and find the cheapest edit that turns it green. Every
cheap edit they found dropped information, and the one fix the rules actually
name — a bigger drawing — never ran. What follows is the shipped behaviour.

**Rule 5's enlarge tier runs** (`figkit_plus._ladder`). A bigger size was
gated on `span × size + 34 ≤ max_width`, reading `size` as printed px. It is
not: `_plane` scales the drawing down to `max_width`, so on a 17-square window
no rung above 16 ever ran — `_ladder((-8, 8), (-8, 8), None, 16, 210, None)`
was one rung, while `plane(size=20)` drew the refused figure at exactly 210px.
The engine was refusing figures it could draw, which is what sent builders to
`hide=`, `sparse=` and `sketch=`. Every rung (×1.15 … ×2.0) now runs; an
explicit `width=` still stops the tier, as an explicit `step=` stops the step
tier. A rung that grows the squares scales into the same width, so it draws
every data stroke, dash, arrowhead, axis and dot `pen = rung size / size asked`
thicker: the rescued figure prints its edges and points as the figure asked
for would (without it, an edge printed at 0.67pt and a point at a 1pt
radius). The numbers get their room by printing nearer their pt floor, not by
the ink going thin. A later rung's OWN refusal (a figure whose grid square
drops under 10px) is that rung failing and no longer replaces the refusal of
the figure as asked.

**A tick number clears its own tick at every size** (`Figure._pin_geometry`).
The gap between a tick's end and its number was a fixed 2 units, and svgcheck
reads a number by its digits padded by `NUM_PAD_EM`. Once the font passed ~18
units the pad outgrew the gap and every y number touched its own tick: a plain
`plane((-8, 8), (-6, 6), size=30)` was refused "struck label 2, 4, 6". That is
why a larger `size=` could turn a rendering figure back into a refusal (16
refused, 20 and 24 drew, 32 refused). The gap is now at least the pad plus
0.9 units; below that font size nothing moves (a 143-case sweep of ordinary
planes, curves and number lines is byte-identical).

**`hide=` cannot clear the refusal it names** (`Figure.place`). The round-3
phantom solved a blanked number AFTER the printed ones, against the layout
the hide itself produced — the neighbours re-placed into its room and the
phantom found a spot there, so `hide=[('x', -2)]`, the one-token edit the
message invited, printed the row −8 −6 −4 _ 2 4 6 8 with every sweep clean.
A blanked number is now solved WITH the printed ones, as a full participant,
and only then left unprinted: `hide=` renders a figure if and only if the
unhidden figure renders. (The refusal may name a different number of the row,
since it is the whole row that has no room.)

**`sparse=True` and a gridded sketch cannot clear one either**
(`number_axes(ghosts=)`). Both leave numbers unprinted by DECLARATION, and both
skipped the collision rule for them: `sparse=True, xticks=[4], yticks=[4]` drew
a refused triangle with three numbers, and `sketch=True, ticks=False` with none.
The numbers the axis's regular step would print are now solved as hidden ones
(the "ghosts") and read back from the finished file (`Figure._sweep_hidden`),
so neither declaration renders a figure the numbered plane refuses. A sketch
with `grid=False` has no scale and is left alone. And a sparse axis reads its
scale from TWO printed values: one listed value is enough beside the origin's
'0', and is refused ("two or more") when no '0' prints — `origin=False`, a
hidden 0, or a window without the origin — the floor `numberline.NL(sparse=True)`
already held. `data_ticks=True` excuses numbers at data values OFF the grid;
an axis whose every number sits on a grid line is ordinary numbering and is
judged as one (`data_ticks=True, xticks=[-5, 5]` drew two numbers on a
10-square axis).

**The refusal names the call that renders.** "A larger size=" alone cured 6
of 19 axis refusals and was not monotonic; `size=24` WITH `max_width=420`
cured 18, and `max_width` was never named. When the ladder is exhausted,
`_wider_hint` now probes the full-width figure (`max_width=430`, the width of
`wide()`) at the sizes the ladder tried and prints the exact call —
"A WIDER figure does: size=22, max_width=430 renders it with every number and
every stroke (a full-width block above the items, not beside them)". When
none does, it says so and turns the author to the figure. The report is the
refusal of the figure AS ASKED (the first rung), not whatever the biggest rung
tripped on. `ticks=False` no longer answers with "pass sketch=True only for a
deliberately unscaled picture" — two steps from an axis refusal to a gridded
plane with no numbers — but names the real paths, and says what an unscaled
picture is: `sketch=True, grid=False, ticks=False`.

**`lost_ink`'s straight arm reads any label but a lone point name.** It only
refused a hole with a NUMBER in it, so a cut behind a value label or a
segment's name ('BC', '2x', 'x+1') was clean. Any label now counts, except one
vertex letter (with primes or an index): two shapes on one baseline — euclid's
congruence pair — leave exactly a letter-wide gap with 'B' in it, and nothing
in the file tells that apart from a cut behind 'B'.

**A gridded sketch keeps the 10px square.** `sketch=True` lifted the
countable-square floor for every sketch, so on a 21-square window
`sketch=True, ticks=False` drew in the side column a plane the numbered figure
could not have, with no numbers at all. A sketch on a grid is a scale the
reader counts, numbered or not; only `grid=False` lifts the floor now.

Measured on the reviewers' own 215-figure family: the axis-number refusals
went from 19 to 11 (8 are drawn by the ladder); `hide=` the named number
(was 6 of 19), `sparse=True` with one value per axis (was 12 of 19), `hide=`
every other number, a gridded sketch with no numbers and `data_ticks=True`
at the ends escape 0 of the 11; every one of the 11 carries the "already
tried" line (was 0); and 10 of the 11 name a wider call that renders.

### Not changed, and why

*A hole with NOTHING in it is still not refused.* Two collinear pieces with a
small gap and no label between them are what two shapes on one line look like,
and the engine makes no cut that is not FOR a label — so a cut that came back
would stand behind the label it was made for, which the arm now reads.

*`figkit.axes` / `coord_plane` do not hold the numbering rules* (regular step,
two values). They are the low-level builders `plane()` is the rule-keeping
front of, as in v5.8; they do share the ghost solve, so `sparse=True` there
cannot clear a collision either.

Tests: `s1br4_*` and `s1br5_*` in `selfcheck_v6.py`, 6 checks (218 in all),
each with a failing half that fails on the skill before the fix. Three
existing refusal fixtures now pass `width=210`, because the ladder draws those
figures at a bigger size and the refusal under test is the engine's own at the
size asked for. z08_a and z47_a rebuild "GATES: all pass" in scratch copies.

## Round 6 — what three more lenses found (numbers / print look / author pressure)

Twenty issues against the round-5 engine. Each fix below has a test in
`selfcheck_v6.py` (`s1br6_*`, 13 checks, 231 in all) whose failing half was
run against the skill before the fix (or, for the two "untested clause"
issues, against a mutant copy with the clause removed) and fails there.

**A curve reaches its pole and the edge of its domain.** `curves=` stepped the
window in 16 intervals and threw away any interval with an undefined end, so
y = 1/x on -5..5 stopped at y = -1.6, sqrt(9 - x^2) stopped 0.66 above the axis
it meets, sqrt(x) began at x = 0.375 and a dotted O(0, 0) sat off its own
curve — by amounts that changed with the window. `_sample` now bisects to the
break (no value, or a value further than 1000 window-heights away, is a
break), walks the run right up to it, and `_exact_exits` solves the exact
point where a run crosses the window's top or bottom ON fn, so the clip that
follows is exact. `draws()` could never see this: the geometry it is handed
is the curve as sampled.

**`intersections()` finds touching points.** A double root has no sign change;
it was found only when a scan point landed on it (y = x^2 and y = 2x - 1 met
on -5..5, not on -3..6). A dip of |f - g| between scan points is narrowed by
golden section and kept only if it reaches zero (1e-9 relative); a nearby
short decimal is preferred when it meets at least as closely. The root guard
(every answer put back into both functions) now has a failing case: a step
function's jump.

**A number owns its tick across BOTH axes (rule 4).** The slide budget only
bounds a move along a number's own axis; a diagonal step-out put a y '-1'
1.23 squares from its tick and 1.17 from the x tick (-1, 0), right under the
x '-1'. `svgcheck._foreign_tick` (run by `tick_alignment` on any figure with a
horizontal and a vertical axis) refuses a number whose centre is not nearer
its own tick than `OWN_RATIO` (0.90) x its distance to any tick of the other
axis; the solver (`Figure._owns_tick`) treats such a spot as taken, with a
margin (0.80). Along its own axis a number is still judged by the slide
allowance only. Refusal rates on random step=1 / step=None planes are
unchanged (28 vs 28, 5 vs 6 of 120).

**Lost-ink clause (b) reads edges on axes, circles, arrows — and every
builder.** `covers()` no longer counts an axis line as ink for a data stroke
lying along it (a triangle at the origin with both legs deleted passed); an
axis the geometry itself asks for still counts. `plane()` hands in circle
rims, arrow shafts and heads, and angle arcs. `Figure.render` hands every
figure's data strokes (`_data_geometry`: lines that are not grid/axis/tick,
polygon outlines, paths, circle rims) to `svgcheck.assert_draws`, so
coord_plane, euclid, shapelib and trapz_kit are read back too; numberline's
canvas records the strokes it emits (`_Canvas.geometry`) and its render does
the same.

**Data outside the window is refused.** A point, dot or marker outside the
ranges, a vertex, segment end or circle rim more than half a square outside,
a reversed range and step <= 0 are refused at the call, naming a window that
holds the data. Corrected fixtures: gallery 17 now uses (-4, 16) at width 260
(the triangle reaches -3 and its mirror 15), gallery 19 uses (-8, 8) (the leg
of 8), and selfcheck_plus's wide-and-short check the same window.

**`wide()` grows its squares.** It set width=430, and an explicit width= stops
the enlarge rungs, so wide() refused figures plane() drew in the side column
and said every knob was exhausted. wide()'s own width no longer stops the
rungs; an author's width= passed to wide() still does. A stretch a figkit
refusal names ("size=18 and width=300") is tried by plane() and removed from
the message when it does not render.

**Refusals never move the data.** "move each point off the number's spot"
(a vertex the question prints) is gone from every refusal; for a dot or an
arrow's end the message says it is data and stays, and names the numbering
or the room. "a shape moved off the axes" became "where the coordinates are
yours to choose, a shape placed off the row of numbers"; the letter-by-hand
fix is named only when a lettered point is involved, with the arguments that
do it (dots= plus labels=); "a regular step of 2 squares" is not named on an
axis already numbered every 2. Corrected fixtures: the four tests that drew
the moved point now draw the named step instead.

**A pair of neighbours may cross.** `_row_reads` refused two neighbouring
numbers that both crossed their axis, so a V dipping just under the x-axis
was refused at every size (28 of 156 such triangles) and the author was
pushed to shaded= or a sketch. A run of two is allowed (still at most one in
four of the row); a run of three is a second row. Corrected fixtures: the
round-4 `_R4_T` and `_R4_HARD` figures now render, so the tests use figures
refused for a reason this does not touch, and the `_row_reads` table gains
the pair and the run of three.

**No declaration clears a number.** A sketch WITHOUT a grid is now solved
with its numbers as ghosts too, at the size asked for (the enlarge rungs,
which shrink squares a gridless sketch does not floor, are skipped); the
ticks=False refusal no longer names that combination as the way out. A
shaded region's edge blocks a number as a side does, so shaded=[P] in place
of polys=[P] is no escape. Corrected fixture: the round-4 test's "an unscaled
picture renders" half now draws a real unscaled picture (z08's) and the
refused figure as a sketch is refused. Measured on the reviewers' 22 escape
figures: a gridless sketch now clears 0 of the 12 refused for a number (was
8 of 12).

**A point's letter does not stack on a number.** F4 at 9 cm put P directly
above the x '-2' (moved above the axis): 'P / -2' read as P's x. The label
solver keeps a vertex letter out of a pinned number's column on its side of
the axis within `svgcheck.STACK_EM` (0.9 em), and `reading_merge` refuses it
off the file (planes only; a number line stands its letters above and its
numbers below by design).

**Nested jump arcs do not cross.** `_layout_jumps` first solves the whole walk
with arcs forbidden to cross an arc that shares no end with them
(`_arcs_cross`); if any jump finds no such place, the older layout is used
whole. `numberline.sweep` refuses two arcs on one side, one strictly inside
the other's span, that cross. Arcs taller than the sweep allows
(ARC_RATIO) are no longer tried: they were always refused as a teardrop, so a
labelled side-tier chain the engine could not place was refused with no fix;
it now says "no clear place ... tier='block'", which renders it. A signed
number ('+1') is never read as a tick number (`_axis_labels`).

### Not changed, and why

*A fan still crosses.* Two jumps leaving one tick the same way (4 -> -10 and
4 -> -1) are left to the fan rule. Sent to opposite sides, their arcs leave
the tick up and down and print as one stroke through the tick's number —
`lost_ink` refuses exactly that file (the C4r3 fan fixture). Forced crossings
(spans interleaving on both sides) also stay as before. Over 450 random
block-tier jump sets the crossings went from 16 to 11.

*A gridless sketch refused only for square size.* 6 of the 22 escape figures
were refused numbered for a grid square under 10px, not for a number; a
sketch with no grid has no squares to count and still draws them (z08's
unscaled pictures print at 9.6px squares).

## Stage-1 open issues — what the round-3 verifiers left open

`regen/stage1_open_issues.json` holds the r3 findings of the five stage-1
verifiers (C1–C5). Every must and should, the minors that mislead an author,
and every rule a mutant proved could not fail were taken up. Each fix has a
test that fails with the fix reverted and passes on the skill: the nine OI2
checks all fail on `v6/OPENr2/pre` (`unfix.py` builds it, `run2.py pre` runs
them); nine of the eleven OI1 checks fail on `v6/OPEN/pre_skill`, and the other
two pin thresholds, proved by the 12 mutants in `v6/OPENr2/muts.log` (11
killed; M42 is discussed below). They are the `OI1` and `OI2` checks at the
end of `selfcheck_v6.py`.

**Fixed in the first pass (OI1).** A group of three equality ticks along an
axis is judged against figkit's own group spacing in figure units, so it no
longer turns into "one more axis tick" once a unit prints wider than 0.9pt.
The owned-label size hint no longer approves a base length printed below the
row of x numbers. A tick typed as a rounded decimal (`tick=0.666667`) is
refused, naming `tick='2/3'`; no refusal prints a rounded tick or offers a
coarser tick on which the whole numbers are not ticks. A quoted call in a
refusal pastes as Python (ASCII minus). A double arrow whose centre is
between ticks is refused, naming `.point(c, 'M', between=True)`. "A wider
placement" is named only where a wider tier exists, `tier='strip'` where it
renders a labelled walk, no `label_every=` the density rule cannot reach, and a
vertical line says its jumps go on ONE side. `Stack` is proved to call
`stack_sweep` and `assert_clean` on the composed SVG; `zoom(connect=False)`
is judged as declared. `wrong_scale=[(v, t)]` must print something other than
what the tick prints. The trapezoid's refusals name a target/rotation that was
tried and renders, and never "draw the figure without that diagonal". The
1.5pt arrowhead gap, an entity-escaped hyphen, the minus look-alikes (em dash,
U+FE58, U+2796, U+02D7), a value row farther out on the numbers' side, the
owner's shield, the lone-marks guard, Arabic as RTL, the filled rim, the
shim's 7pt floor and the 0.6 em double-arrow gap each have a failing case at
the threshold.

**Fixed in the second pass (OI2).**

* *An even step is named only where it renders* (C2 doctrine 4). plane()'s
  refusal said "number the axis every 2 squares" for a scatter hugging the
  axis on both sides of every tick, where step=2 is refused too.
  `_checked_even` tries `step=2` (ladder and all) or knows the ladder already
  did, and takes the phrase out when it does not render.
* *A lone number cannot slide past a square* (C2). On an axis measured by its
  grid (one or two tick marks), a number more than one square from its mark
  was never judged — a '6' moved 1.2 squares right, onto the unmarked grid
  line of 7, read as 7 and passed. A lone number is now measured to its MARK,
  not to the nearest grid line, and beyond one square it is still judged when
  the axes' crossing and the mark give its value a step a person numbers by
  (`_mark_owns`: 1, 2, 2.5 or 5 x 10^k per square). A value whose number does
  not fit the mark ('4' as a length beside a mark 6 squares out) is left to
  `label_ownership`.
* *coord_plane turns its own size* (C2 E6). `coord_plane(size=None)` is the
  new default: the engine tries size 16, 18, … 32 inside the same width
  before refusing, so ±6 and ±7 four-quadrant planes render at the default
  210px. An explicit `size=` is honoured as given; ±8 is refused, naming the
  sizes tried and a wider figure.
* *A label over a point is still read* (C4r3v-04). The carried-label sweep
  skipped every text centred over a marker, so the label of a span with its
  midpoint, of `symmetric(a)` with points at ±a/2, or of a jump over a point
  could be edited to any number. A NUMBER over a marker with an arc or span
  under it is now read as that carrier's label; a letter is still a point's.
* *A fallback forgets its flips* (C2, minor). `_place_pins` put every row
  back on its home side after an unsolvable flipped layout but left
  `pin['flipped']` set, so the re-solve crossed the number again.
* *The axis letter is no member of the row* (C2, minor). With the x numbers
  flipped above the axis the letter 'x' stood on their baseline one pitch
  after the last number ('1 2 3 4 5 6 x'). An italic one-letter label is kept
  out of the x row's band within 1.25 spacings of its ends
  (`Figure._continues_row`); it now takes the other side.
* *The parser reads root and shorthand styles* (C1, minor). `<svg
  font-size="6">`, `style="font:6px serif"` and `!important` were misread.
* *Row ownership is judged per figure* (C1, minor). In a row of figures each
  printing '5', a label is refused only when every figure holding it refuses
  it.
* *The gallery's critique is checked* (C5r3-V6). q38 drew a correct closed
  interval and declared the error in words; it now draws
  `from_inequality('-1 <= x < 2', closed=True)`, which the builder verifies to
  be wrong.

### Not changed, and why

*Already fixed by later rounds* (proved by rerunning the verifiers' probes on
this skill): the dashed look of a polygon edge on the number row (C2 E4 —
stage 1b never cuts a stroke; the q12 rectangle is one `<polygon>`, and the
q4 speck case is refused naming `size=22, max_width=430`); the moves named for
a point on both sides of a number (C2 doctrine 4 — C6 r6 no longer names
moves, and every q10/q11 case now renders); the shim's size hint and walks
with labels (C4r3v-05/07, covered by OI1).

*The first hop of a plane() chain still starts a little after its value* (C1
plane-first-hop-start-detached). Each hop of a chain loses the same amount so
equal hops print equal (`r2_plane_hops_equal`, z08 fig 20 sets the x-scale
with them) while every tip lands on its value; attaching the first start
would make that hop longer than the rest. The two rules cannot both hold.

*z01_a still does not import* (C1). Its 11 refusals are true positives (a dot
0.94pt off the 800 tick, hop heads buried in the next hop's start) and each
names a non-destructive fix; the level must be regenerated by its builder.

*A mutant that cannot fail* (C1 M42, `side = 1` in `svgcheck._rows`). Two
labels on opposite sides of an axis can have near/centre/far offsets within
0.75 em only when both stand within about 0.4 em of the axis line, where the
line strikes them; over 27 placements the mutant and the code return the
same problems (`v6/OPEN/M1.txt`, `M42.txt`, `v6/OPENr2/probe/p_m42b.py`). It
is an equivalent mutant, not a missing test.

*A value between an edge and a diagonal* (C1 trapz-value-in-subangle) and *a
length just across the axis nearer another numbered tick* (C3
mirrored-band-value-near-wrong-tick) are readable in context and were worse
in v5.8; they are layout preferences, not wrong readings, and are left for the
visual lens.


## Stage-1 open issues, round 3 — what the numbers / print / pressure lenses found

**What was wrong.** A test that could not fail (the C4r3v-01 coarse-tick test
read only `tick=1`, never `tick=F(5, 6)`). The OI2 carried-label reading
refused every correct `point(v, value_label=True)` at a jump's start or tip,
over a span end or at a chain junction, so dropping the value label was the way
out. A point's letter printed straight on a span's or double arrow's label
('M' over the '6' of `span(0, 6)` read M = 6). A strip walk drew two arcs
crossing at 8 degrees, almost along each other, and the block refusal had named
that strip. Neighbouring axis numbers slid until they touched ('−2−1'), and no
check measured it. The coord_plane size ladder halved every stroke and dot.
Past the ladder, refusals said "a wider figure or fewer squares" or "a larger
size=" without trying either. The minor-tick floor named `tick x 2` untried
(1/7 went 2/7, 4/7, 8/7). On a sparse axis a lone number moved a whole square
landed on another tick and passed. In a row of figures, one figure's correct
'5' hid another figure's misowned '5'.

**What changed.**
- numberline: a number that equals the value of the marker under it is that
  point's own label, never a carrier's. Spans and double arrows over a point
  with a letter or value stand high enough that the letter prints UNDER them
  (`_under_labels`). The sweep refuses a point's letter stacked on a carrier's
  label ("read as one"). Forced arc crossings are tried steep first
  (`CROSS_MIN_DEG = 12`). One that stays shallow is refused, naming two stacked
  lines (`N.stack`), and the sweep reads shallow crossings off the file (fans
  leaving one tick are exempt). A wider tier is named only when the line renders
  there (`_wider_tried`). The minor-tick floor names the tick `_coarser_tick`
  picks with `min_tick=`, or the width that clears the floor.
- svgcheck: `ROW_GAP_EM = 0.12` (box to box) between two numbers of one axis
  row, in `reading_merge`. The pin solver's `clash` keeps the same gap, so the
  numbers move apart instead of being refused. A number on an axis with a tick
  at every square, with no row to vote, is judged by the axes' crossing
  (`_fits_nice`). With `label_ownership` on a row, every block that draws the
  owner's stroke is judged.
- figkit.coord_plane: the ink (strokes, tick marks, dots, dash pattern) grows
  with the squares, so it prints as heavy as the size-16 drawing of the same
  window would (`_ink`, private). A drawing that is not shrunk, or is drawn at
  size <= 16, is unchanged. A refusal about room tries larger sizes
  (`_coord_probe`): it names the one that renders, with its printed square, or
  says none does. 'a larger size=' is rewritten to match.
- figkit_plus.plane: the owned-label hint tries a `prefer=` at the author's
  size first, then the smallest larger size. It says when that size no longer
  sits beside its text.

**Tests.** selfcheck_v6 OI3 (9 checks, each fails on the round-2 skill). The
o1 coarse-tick and o2 lone-number, parser and row-ownership tests were
sharpened. 17 mutants are killed.

**Fixtures corrected.** `o1_wider_placement_is_named_only_where_it_exists` no
longer expects the strip for `chain([-2, 6, -5, 5])`, because it drew the
shallow crossing. The case where a wider tier really renders is
`chain([-4, -1, -4, 8])`, from side to block. `o2_row_ownership_is_judged_per_figure`
now expects the second figure's misowned '5' to be refused.
`c5r3_reference_and_zoom` still finds 'tick=' in the honest floor message.

### Not changed, and why
- z01_a: the refusals are true positives. A regenerated copy builds with GATES
  all pass (v6/OPENr3/z01, 5 figure edits, each commented). regen/work was out
  of this brief's reach.
- The crowded origin (the '0' under the y '1') and a number beside a column of
  dots (C7P-05) are accepted: both are legible, and no rule was added for them.
- figkit_plus.plane's own size ladder does not scale its ink yet (at +-6 the
  grid prints 0.21pt against coord_plane's 0.26pt).

## Stage-1 open issues, round 4 — the origin's '0', numbers past the axis, rings, nested arcs

**What was wrong.** The round-3 verifiers found these:
- The origin's '0' could stand up to 1.6 squares from the crossing, on the
  grid point (-1, 1) inside a triangle or on the x '-1'. It was then nearer
  another tick than the origin, and `problems()` returned []. This was true in
  about 1 of 7 random planes from +-4 to +-7.
- A number moved past the end of its axis (under the axis letter, or off the
  figure) was never judged. A lone sparse number exactly half-way between two
  ticks passed.
- On a shrunk +-7 plane, a letter printed 0.36pt from its open marker ('QO').
  A number standing wholly inside a point's box met none of the box's sides,
  so the solver never tested it against the point, and the gallery-style
  fixture printed an x '2' under a square marker.
- The ink scaling missed the open-marker outline and the tick-mark length.
  The grid and dash scaling had no test.
- On a line numbered every 2nd tick, a span or jump labelled with its length
  was read as the missing tick number slid half a spacing ('pin it to the
  tick'). A labelled walk drew a nested jump as tall as its outer arc and
  crossed it. Two jumps leaving one tick the same way met at one apex height
  and crossed at 2.5-8 degrees, and the sweep exempted them as a fan.
- A point's value label straight over its dot was never checked: a dot at 3
  labelled 5 passed.
- The floor refusal's coarser tick rendered only at tier='item', and there it
  could leave the ends unnumbered. The density refusal named no tick. A tick
  that left an exact value off its ticks was blamed on 'fewer than 4 ticks'.
- A named fix (max_width=280) drew a y number crossed into a triangle, where
  it read as a side length.
- Refusal lists had an empty slot ('room:  or a wider figure'). The owned-hint
  prefer= tier was tested only in a stray copy (skill/selfcheck_v6_cur.py),
  and the row gap, solver gap and printed-mm values were unpinned.

**What changed.**
- svgcheck `_zero_owner` (ZERO_RATIO 1.25): the '0' by a crossing stands no
  farther from it than 1.25 x its distance to any other tick of either axis.
  This covers a '0' in a corner and one slid out of the corner's reach (up to
  3 squares). The margin is 1.25, not 1.0, because the conventional corner '0'
  on a small square already stands 1.0-1.15 x as far; every misowned '0'
  measured stood 1.34-2.7 x as far. figkit `_zero_owns` (1.2) applies the same
  rule in the spot search and in the final re-read. An axis with fewer than
  three tick marks is judged by its grid squares, as svgcheck reads it. When
  every corner fails, `_solve_origin` moves to the next corner, and the refusal
  names room or step 2.
- svgcheck `_free_ends` / `_past_free_end`: at an end of an axis that no
  perpendicular stroke crosses, a number beyond the ticks is this axis's
  number and is refused past MOVED_TOL. A lone number more than _LONE_REACH
  from a tick is judged by `misread`, so '5' at 5.5 is refused and '5.5' at
  5.5 passes.
- Markers: `Figure._letter_owns` keeps a marker's letter MARKER_PAD_PT (1.8pt)
  of printed paper from the rim. The letter must also be within an em of the
  rim and nearer its point than any other point or vertex; if not, it is
  refused as crowded, and max_width=280 renders the verifier's +-6 and +-7.
  svgcheck `marker_clearance` refuses a letter under MARKER_CLEAR_PT (1.0pt)
  from a white marker, and a number printed under one. `_pin_blockers` now
  tests every dot and marker against the number's ink directly. In numberline,
  a triangle's letter starts over its apex, and an outlined marker's letter
  clears the rim (`_letter_floor`).
- coord_plane: the marker outline scales with `_ink`. Tick marks grow with
  sqrt(_ink), and the digits' gap with them. Growing them in full cost 8 of 38
  random +-7 renders; the square root cost none.
- svgcheck `_carried`: a label with a span's shaft or a jump's arc between it
  and the line is never taken for a crossed tick number.
  `_crossed_into_shape`: a tick number that crossed its axis, sits on its
  tick, and is a value the row's numbering prints, is refused inside a drawn
  closed shape. figkit `_in_shape` makes that spot not free.
- numberline layout: the fallback layout first keeps a jump from crossing the
  arc it lies inside ("nest" pass). `_fan_cross` (FAN_START 0.3 of the shorter
  chord) keeps fans nested in the layout and in a post-check that names
  N.stack. The sweep refuses a fan whose arcs meet past the shared start.
- numberline sweep `_carried_labels`: with no carrier between it and the
  line, a number straight over a point must be that point's value. A stacked
  fraction, found by its bar, is left alone. A number equal to the point under
  it counts as the point's value only at a carrier's end or junction, or when
  the carrier has no other label nearer the line. At the carrier's label spot
  it is judged as the carrier's label, so a span '6' edited to '3' is refused.
- numberline ticks: `NL._ctor` keeps the call. `_coarser_ticks` returns every
  candidate and the values a coarser tick would strand.
  `_tick_that_renders` tries up to 8 candidates as bare lines and names the
  first that renders with both ends numbered (else the first that renders).
  The floor and density refusals name it. The floor refusal names stranded
  values.
- figkit `_larger_size` handles every list shape. The stray
  selfcheck_v6_cur.py was deleted; the suite fails if it comes back.

**Tests.** selfcheck_v6 OI4, 12 checks (272 in all). 11 of them fail on the
round-start snapshot (v6/OPENr4/pre). `o4_thresholds_are_pinned` passes there
by design: it pins values that already existed. 24 of 25 mutants of the new
rules are killed (v6/OPENr4/muts2.log). N15, which drops the first regex of
`_larger_size`, is an equivalent mutant: the later clean-up produces the same
text.

**Fixtures corrected.**
- `_guide_fig`: 20 units a square. At 16 its '0' stood 1.58 squares out.
- c2r2 arrowhead: the plane now prints at size 18, with scaled stroke widths.
- s1br4: the sparse call is refused for its printed '0'.
- c2r3: '6' at 5.5 is refused; '5.5' at 5.5 passes.
- s1br6 old-solver simulation: also disables `_zero_owns`, `_in_shape` and
  `_crossed_into_shape`.
- s1br6 refusal fixture: the triangle is (-6, 2), (-2, -1), (4, 2); the old
  one now renders clean.
- c3r2 square markers: at (56, +-13). At (50, +-13) the old file hid the '2'
  under a square, and that call is now refused.
- c5 vertical: the named tick is 25, not 20, so both ends are numbered.

### Not changed, and why
- ROW_GAP_EM stays 0.12. At 0.15, 15 of 38 random +-7 step=1 triangles render
  (18 at 0.12); at 0.17 none do. The value is pinned by a test.
- An unsigned jump label equal to a positive hop ('5' on +5) and '+2' as a
  point's value are accepted as the same number.
- P2-06: value labels at a span's ends share the length label's row. This is
  legible and was left as is.
- A number moved perpendicular to its axis into the grid (the x '4' lifted
  1.2 squares) is still judged by nothing.
- At an explicit size=18-26 the verifier's Q plane is refused with raw
  svgcheck or cluster messages ('2' and 'Q' 1.4pt apart). The default refuses
  with 'enlarge it', and max_width=280 renders.
- figkit_plus.plane's own size ladder still does not scale its ink.

## Stage-1 fix round r1 — what three verifiers found on the whole stage

Twenty findings (numbers, print, author pressure). Each fix has an `S1F`
check in selfcheck_v6.py (292 checks).

**Curves.** `_sample` welded a finite jump into one path. A piecewise f or
`floor(x)` printed a riser through values the function never takes, and the
drawing disagreed with `intersections()`. A step is now bisected down to
neighbouring floats. A jump keeps its size, so the run ends at the left limit
and restarts at the right one. A continuous step shrinks away (cbrt's vertical
tangent stays one piece).

**Letters.**
- A point's letter may not stand in an axis number's SLOT, whether the number
  is there or has stepped aside. It also may not stand in the row's band
  nearer that tick than any point. `svgcheck.letter_in_slot` reads this off
  the file, and `Figure._in_slot` applies the same rule in the solver.
- A plain dot's letter tries a spot within an em first, on the 30-degree ring
  and then a 5-degree ring. Only after that does it fall back to the open
  search. F4's P now sits in the wedge under its crossing.
- "No clear position for label" and the label-cluster refusal are
  `LayoutError`s, so the size ladders run on them. A(-2, 0) with B(-2, -1)
  renders. On -9..9 the refusal names `max_width=430`, which renders.

**Numbers.**
- `sparse=True` may not list more than half of a step's values. An axis with
  one odd number left out is refused as a deleted number.
- With `data_ticks=True`, the values that sit on grid lines are judged as a
  numbering whenever two or more of them are printed.
- `svgcheck._numbering` fits on the ticks the aligned numbers stand at. Two
  legal slides no longer move 0 off the origin, so x^2 - 4 with 1/x renders
  with its '0'. A '0' blanked by `origin=False` is read where it would print,
  alongside the printed numbers.
- Two numbers from different axes may not stack, and neither may the origin's
  '0' with a number (`svgcheck.number_boxes`, and in the solver's clash).
- `plane(number_pt=)` and `figkit_plus.new_sheet(number_pt=7.6)` give one
  printed size to the numbers on every plane of a sheet. Font and pen scale
  together (pen = font / 12), and `printed_number_pt(svg)` reads the size back.

**Shapes and marks.**
- The rule against a crossed number inside a shape covers every closed shape:
  a polygon (solid or dashed), a closed curve, and a loop of `solid=`
  segments (`svgcheck.closed_shapes`, `Figure._closed_shapes`).
- Equality ticks on a side lying along an axis lean 25 degrees
  (`ON_AXIS_TICK_LEAN`). `_axis_edge_groups` reads strokes up to 35 degrees
  off the perpendicular as marks.
- One shade grey for all builders: `svgcheck.SHADE_FILL = #dcdcdc`. The plane
  used #eeeeee before.
- `_broken_curves` skips closed outlines. Two open markers one square apart
  are no longer a "curve in two pieces".

**Number lines.**
- On a vertical line, `reference()` draws only the decorations' side. The dash
  on the numbers' side printed as a minus sign. `numberline.dash_as_sign`
  refuses such a dash in `sweep_v`.
- A sketch that carries data (points, jumps, spans, sets) is held to the tick
  floor of the line it sketches. `answer_values` on a sketch is refused.
- Labelled walks get a second series of layout passes that do not reserve
  room over the apexes. The passes that let a fan cross come after both
  series. Refusals of jumps and their labels name `N.stack([...])`, split at
  the jump, and only when that stack renders.
- A jump leaving the tick where another landed steps along by at most
  0.13 of a spacing. The old 3.3px step is a fallback when nothing else fits.
- The tick under a cross or triangle marker is covered by white strokes; the
  axis is not.
- A span stands above the letters of the points under it.

**Messages.** `svgcheck.fix_text(kinds)` includes only the clauses that
apply. The skip-values text no longer mentions cutting. "Every 2 squares" is
not offered for an even tick. The plane ladder removes the size and width
knobs it has already tried.

**Fixtures corrected.**
- OI4 ring: the ladder now draws the ±7 plane.
- OI1: the block walk now draws with its labels.
- c2r3: coverage is measured on the figure's own tick spacing, because the
  ladder may pick a larger square.

### Not changed, and why
- PR4 (numbers close to their ticks): an ink gap of 0.26–0.33 em broke 11–12
  existing checks. Small step=1 planes lose room for x '−1' against y '−1'.
  It needs its own round.
- PR11 corner staircase: an x '−1' and a y '−1' overlapping at a box corner
  are still accepted. Only stacks are refused, because refusing corners
  failed every default ±4/±5 step=1 fixture.
- About 18% of refused labelled walks at block (4 of 22 in one run) still
  draw without their labels. Their refusals now quote an `N.stack` call that
  renders.


## v6.0 deliverables round — what the showcase and the comparison found

Drawing every number-line family at three tiers and the five comparison
figures with the new engine found two engine defects. Both are fixed, each
with a D6 check in selfcheck_v6.py (294 checks) that fails on the pre-fix
copy.

**A compound-set stack could not be joined at its boundaries.**
`stack([x>=-2, x<3, -2<=x<3], connect=[-2, 3])`, the textbook drawing of an
intersection, was refused at every tier by the stack's own sweep: "a stroke
is painted over the marker". `Stack._column` skipped every element whose
format held `#fff`, which was meant for white knock-out strokes but also
caught the white-filled end circles, and it ignored any mark straddling the
axis. So the connector stopped 2px from the axis, inside the ring. Now only
white strokes are skipped, and a marker centred on the connector's value
counts as part of its column, so the connector stops at the rim. The check
reads the file: every connector end stands outside every ring. The FAIL half
pushes one connector into its ring and svgcheck refuses the file.

**A double number line's floor refusal named knobs `double()` does not
take.** At `tier='item'`, `double((0, 80), (0, 100), 10)` was refused with the
inner line's text: `label_every=` and `tick=20`. `Double.svg` now rewrites a
floor refusal to name `double()`'s own knobs. It tries a wider tier, then fewer
parts that keep every hidden value and stated pair on the scale, and names
only calls that render: "tier='block' or tier='strip' (each renders)".

### Seen, not changed
- `plane()` without `number_pt=` scales numbers with the display width: the
  comparison's F4 printed its numbers at 15.4pt at 9 cm and F5 at 10.8pt at
  8 cm. `new_sheet(number_pt=7.6)` is the sheet convention, and the comparison
  uses it.
- A reversed jump in a chain drops under the line into the number row
  (C4 rule). Typst nests both jumps above.
- An empty set's ∅ is an HTML caption (`Set.caption`). `stack(...).svg()` of
  an `empty()` row prints a bare line unless the author passes the caption.

## v6.1 — P1: the plane's printed look (house look)

### What was wrong
The author set v6.0 beside Typst (F4, F5 at 9 cm, 8 cm and side width). A
plane's numbers, letters and strokes followed its display width: F4 printed
15.4pt numbers and 2.3pt strokes at 9 cm and 7.8pt beside the text, so one
sheet had two looks. Tick marks were long and heavy and read as '+' crosses.
The grid (#e8e8e8 at 0.4 units) was almost invisible and could vanish on a
laser printer. The axes had no arrowheads. Dots were 3.5pt blobs.

### What changed
- **One house look, in printed pt, whatever the width** (`figkit_plus.HOUSE`):
  axis numbers 8pt, letters 9.5pt, data strokes 1pt (dashed 0.8pt), axes
  0.8pt, grid 0.35pt in `svgcheck.GRID_GREY` (#c8c8c8, luminance inside
  `GRID_BAND`), tick marks 4.4pt across at 0.6pt, dots r 2pt, open markers
  r 2.4pt white-filled (`svgcheck.MARKER_R_PT` = 2.4, the floor), a filled
  5pt arrowhead at each axis's positive end with its letter beside it.
  `number_pt=` (per call) and `new_sheet(number_pt=...)` still set the number
  size; `axis_arrows=False` / `new_sheet(axis_arrows=False)` drop the heads;
  `new_sheet(house=False)` restores v6.0's width-following look.
- **Sizing per rung** (`_house_rung`): plane()'s ladder is unchanged; each
  rung finds the font that prints the numbers at the house size and the
  printed scale the strokes are drawn for, from the render itself (the scale
  is settled before the font moves; the font stays inside a bracket). A rung
  that fits the numbers only smaller is refused with the layout refusal of
  the nearest larger font, so the ladder climbs and the author reads the
  refusal that names the room (a wider figure). Hint probes (`_probe_plane`)
  are sized as the author's call is, so a named "max_width=430 renders it"
  does render.
- **Backward compatibility**: an item figure a level sized under 180px
  (`HOUSE["narrow_px"]`) that has no room for the house look prints at the
  nearest size that renders, or as v6.0 drew it, and is listed in
  `figkit_plus.HOUSE_FALLBACKS` (never silently). z08_a lists 3 such figures.
- `svgcheck.house_look(svg, arrows=True, number_pt=None)` reads the FINISHED
  SVG and reports every departure in printed pt (numbers, letters, strokes,
  axes, grid grey and width, tick length and width, dot and marker radii,
  arrowheads, the axis letter within 14pt of its tip).
- `svgcheck.lost_ink` compares the pieces of one stroke even with a thinner
  tick mark standing in the hole (the house tick sat exactly there).
- `figkit.figure_family` counts a small filled closed path (an arrowhead) as
  an ornament, so the family stays scale-invariant.
- An axis letter past its arrowhead is not "the row's next number"
  (`Label.past_head`).

### Tests
selfcheck_v6: six P1 checks, each pass + fail on the finished SVG (numbers
8pt at 9/8/5 cm and v6.0's 15pt refused; ticks 2.5x longer or heavier
refused; #e8e8e8 and a 0.1pt grid refused, the grid still background;
arrowheads deleted or a letter moved away refused; dot doubled, marker shrunk,
2pt strokes refused; the narrow fallback listed and a 200px figure refused).
Fixtures that pinned v6.0's literal widths ("1.50", "#e8e8e8", "4,3") now read
printed pt. Fifteen rule tests whose collision fixtures were found at v6.0's
7pt side-column print run under `_v60_sizes` (new_sheet(house=False)); the
rules they test do not branch on the look.

### Seen, not changed
- A plain -8..8 plane with size=34/40 in the side column is refused at the
  house size ('-2' and '0' share a baseline); size=16..30 render.
- F4's P at the default side width stands nearer tick -2 than its dot (the
  owning check runs at v6.0 sizes; at 8 cm and 9 cm it holds).

## v6.1 r1 — P1 fixes: one plane look on every sheet, fast

### What was wrong (three verifiers)
- plane() could take minutes to render or refuse (a 12x12 step=1 plane
  >120s on a loaded machine; new_sheet(number_pt=4) 310s a figure): each
  rung of the ladder stepped its font down toward 3pt before refusing, and
  hint probes did the same. Builders under a deadline looked stalled.
- figkit.coord_plane and figkit.axes kept the v6.0 look (a 400px
  coord_plane printed 20.4pt numbers, no arrowheads).
- Nothing gated the sheet: a narrow item figure fell back to 7.2pt or to the
  v6.0 look beside 8pt planes and the level still printed "GATES: all pass".
  HOUSE_FALLBACKS piled up across sheets and logged a figure five times.
- house_look had holes: upright point names, dashed strokes, a too-light or
  missing grid, a dot over 8pt and an arrowhead over the last tick all
  passed; a too-dark grid was reported as "data line 0.35pt".
- number_pt=6 was refused with "a larger width= or fewer squares" (both make
  numbers bigger); a width=130 refusal named max_width=430, which still
  refused while width=130 stayed.

### What changed
- **Speed**: a rung steps its font down at most twice (three times for an
  explicit width under 180px) before refusing. A rung whose display width is
  pinned (width= given, or max_width reached) prints the same figure as the
  pinned rung below it, so after one such refusal the next steps down once
  only -- shared across the hint probes of one plane() call (not stepping at
  all refused two figures that render). `figkit._numeric`, asked ~3 million
  times a figure, is memoised. Every known worst case renders or refuses in
  under 2s (a -20..20 plane: 3.1s -> 1.8s; 12x12 step=1: 1.5s -> 0.8s).
- **number_pt under 7pt** is refused at once by new_sheet() and plane(),
  naming the 7pt floor.
- A width refusal for an explicit width= says "width=None (drop width=130),
  max_width=430 renders it".
- **coord_plane / axes** are drawn by figkit_plus.plane at the house look
  (same sizing, arrowheads, number rules, refusals); new_sheet(house=False)
  restores their v6.0 bodies. Right-angle marks, angle arcs and equality
  ticks print at HOUSE["mark_pt"] 0.9pt.
- **Fallbacks**: new_sheet() clears HOUSE_FALLBACKS; a figure is listed once.
  A fallback SVG carries `<!--house-fallback:...,renders_at=W-->`: plane()
  tries up to six wider widths (up to 150px, then 180px) and names the first
  that prints the house look (`none` when none does).
- **G78** (`gate_variety.assert_one_plane_look`, runs in build_plus with G76
  and G77): every coordinate plane of a level prints one look. NARROW: a
  fallback is refused naming the width that renders it (or the question head
  when only a width over an item figure's 150px does). SIZE: numbers more
  than 0.4pt apart are refused. ARROWS: heads on some planes and not others
  are refused. Off only at new_sheet(house=False) with no number_pt.
- **house_look** now also reads upright point names (9.5pt band), dashed
  strokes (0.8pt band), a grid darker or lighter than the band or missing
  (plane(grid=False) tags the SVG `<!--grid:off-->`, which passes), dots of
  any size, an arrowhead whose base is not clear of the last tick, and an
  axis that stops inside the grid.
- `svgcheck.is_coordinate_plane(svg)` tells G78 which figures are planes.

### Proven on z08_a (scratch copy)
Built with its original widths (148/140/124 item figures), G78 refuses and
names width=150, width=150 and width=130. With those widths the level builds
with all gates passing: 41 planes at 7.8-8.1pt, arrowheads on all.

### Tests
selfcheck_v6: ten P1r1 checks, each failing on the P1 skill and passing now:
speed (CPU under 3s for eight worst cases), the 7pt floor at once, the width
hint that does not loop, the old builders' house look, point names, dashed
strokes, grid and dot faults, the head clear of the last tick, fallbacks per
sheet with a rendering width, and G78 (NARROW, SIZE, ARROWS). The 17
coord_plane/axes fixture tests written for v6.0's bodies run under
`_v60_old` (new_sheet(house=False)).

### Seen, not changed
- figkit.number_line / numberline.py print their own tick size (7.5pt on
  z08_a page 1) beside 8pt planes. G78 reads coordinate planes only.

## v6.1 r2 — P1 fixes: G78 sees every plane, shipped levels build, arcs nest

### What was wrong (three verifiers)
- G78 could not see a plane whose axes do not cross (a window without 0),
  an unnumbered sketch, or a sketch with a fallback tag. The cheapest way
  past NARROW was `sketch=True, ticks=False`, which drops every number.
- `new_sheet(house=False)` turned G78 off with no message, so a sheet mixing
  7.2 and 7.7pt planes built with "GATES: all pass".
- The shipped z08_a was refused by G78 until someone edited three item
  widths by hand, though plane() already knew the widths that work
  (150/150/130, all within an item's 150px).
- Angle arcs at one vertex shared a radius: `arcs=[BAD 1, DAC 1, BAC 3]`
  drew BAD and DAC on BAC's inner arc, so the equal-angles mark was lost.
- A -10..10 plane with a circle was refused "at size=16..32 within
  max_width=430", though size=30 at max_width=430 drew it. After the first
  rung, the grown squares were only tried at step 2.
- Some hints led nowhere. A narrow refusal named only width=None,
  max_width=430, even when 150 or 180 renders. axes() refusals named a
  max_width= that axes() does not accept. At the house look, refusals still
  said "a larger size=", which never helps at a fixed width.
- At new_sheet(number_pt=7), plane numbers printed at 7.34pt next to
  axes() numbers at 7.00pt (a 5% font clamp). The fallback tag said
  target=8.0. G78 named "q16 item 1" when it meant item ג.

### What changed
- **Item widths are taken.** When an explicit width= falls back or is
  refused, and a width up to `ITEM_MAX_PX` (150) prints the house look,
  plane() draws the figure at that width. The SVG is tagged
  `<!--house-widened:from=W,to=W2-->`. Past 150px the figure stays a
  fallback, and G78 names the move. z08_a now builds unchanged.
- **G78 reads every plane.** plane() tags its SVG `svgcheck.PLANE_TAG`
  (`<!--coordinate-plane-->`). `is_coordinate_plane` accepts that tag, a
  house-fallback tag, or ticked horizontal and vertical axes that do not
  cross. `svgcheck.axis_heads(svg)` finds the arrowheads on an unnumbered
  sketch. G78 is never off: at house=False it still judges SIZE and ARROWS,
  and its SIZE message says what house=False does. SIZE takes the sheet's
  own size as the common one. Items are named by label (`q16 item ג`).
- **Arcs nest.** plane() draws arcs from the smallest angle to the largest.
  `Figure.arc` moves an arc outward past any earlier arc at the same vertex
  whose angle overlaps it. `svgcheck.mark_geometry` refuses two angle arcs
  on one circle that overlap by more than 2 degrees
  (`svgcheck.coincident_arcs_in`).
- **Ladder.** Each grown size is tried at the author's own step first, then
  at every 2. At the house look, once the display is pinned at max_width,
  the ladder continues to 3.5x the size (`_GROW_PINNED`, one render per
  rung). Pinned rungs that were already refused are sampled at least 15%
  apart (`_PIN_SAMPLE`), which also makes the ladder faster.
- **Hints.** For an explicit width, the hint tries the nearest widths first
  (W+10, 150, 180, 210) and names the first that renders. After
  "renders it" it says where that puts the figure (the printed px; inside
  an item, beside the text, or a block above the items). When the ladder at
  max_width=430 finds the figure, the hint names plain max_width=430, not
  the size the probe happened to use. The house look drops "a larger
  size=". figkit.axes hints never name max_width=.
- **Sizes.** The font clamp in _plane is limited by the house target, so
  number_pt=7 prints 7.00-7.10pt across plane, coord_plane and axes. A
  fallback tag's target is the call's or the sheet's number_pt.
  `HOUSE_TOL_PT` stays at 0.35: 0.25 refused gallery figures that print
  at 7.68pt at width=200.

### Tests
selfcheck_v6 adds seven P1r2 checks: arcs nest, G78 reads every plane,
G78 is not off at house=False, item widths are taken up to 150px, hints
name a call that renders, the big plane is found by the ladder, and one
size at number_pt=7 (with the tag target and item labels). The P1r1 speed
test adds three cases (bigcircle, tri10x4, tri140). Four fixtures that
needed a narrow fallback now get one by lowering `ITEM_MAX_PX` inside the
test (`_NoItemWidening`), since those figures are now widened.

### Seen, not changed
- A window without 0 still draws its axes at the true 0, outside the grid,
  in both looks. G78 now reads such planes, but whether to extend the window
  to 0 or to draw the axis on the grid edge with a break mark is the
  author's decision.
- Tick marks appear only at numbered values; the LaTeX and Typst references
  put a tick at every square. Adding minor ticks changes the collision
  rules, so it was left for its own round.
- Number lines still print their own size next to the plane numbers.

## v6.1 P2 — number-line jumps drawn like the Typst reference

### What was wrong
- A walk that turns back was sent UNDER the line by rule: in -8 -> -3 -> -5
  the -2 was drawn below, through the row of numbers, where Typst drew both
  arcs above, the -2 nested under the +5 (compare/typst/F1.png).
- Several jumps from one tick fused for about 12mm at the start (2->6 and
  2->8) or crossed (33 of 78 random shared-start pairs). The sweep only
  refused a crossing when one span lay strictly inside the other, or a
  crossing under 12 degrees, so all of these shipped.
- A fan sent over and under its line was refused by lost_ink as one curve
  with a 19pt hole, with no fix that worked (C7r3-P1).
- Markers printed 3.5pt half-extent, a 7pt blob beside 7.5pt numbers.
- A one-tick hop at item width was refused ("prints 9pt, under the 10.5pt
  an arc and its head need"), naming tiers where the walk did not render.

### What changed
- **Nested layout first** (`NL._nest_layout`). Side assignments are tried
  with as few jumps below the line as possible, none first. Two jumps whose
  spans interleave, or that land on one point, never share a side. On each
  side the jumps are placed shortest first, each at the lowest height whose
  arc, head and label room keep `gap` of paper from every jump already
  there (`_nest_clear`, exact polyline distances). So the longer jump is the
  outer arc. An arrival tip stops above its point, and a departure from a
  point where another jump lands starts a little along and low, passing
  under that head. Two arcs leaving one point leave at least `FAN_DEG` (18
  degrees) apart. Along their length, two arcs keep `NEST_APART` (2.5) gaps
  apart, and a label's room keeps one gap from any other arc. The older
  solver runs only when no assignment fits.
- **No crossing, no merging.** `numberline.sweep` refuses two arcs on one
  side that cross away from a shared point (`ARC_TOUCH_PT`), come closer
  than `ARC_APART_PT` (1pt) outside `ARC_ZONE_PT`, or leave one point under
  12 degrees apart. The builder checks the same rule (`_arcs_meet`) and
  refuses with the `N.stack` split that renders. Walks that are not a chain
  get the split too (`_split_jumps`).
- **lost_ink** leaves two complete arrows alone: two pieces that each carry
  a head at the far end, and none at the gap, are two jumps.
- **Markers** print at 2.7pt (`MARK_R_PT`). The open ring's circle is 0.95r
  so it stays over svgcheck's 2.4pt floor. The cross keeps 3.5pt, since its
  strokes read as ticks when smaller.
- **Short hops** get a smaller head, down to `JUMP_HEAD_MIN_PT` (4pt). A
  tip over a point another jump leaves stops a little farther out
  (`ARRIVE_LIFT_PT` 1.2 above the line, `ARRIVE_LIFT_BELOW_PT` 3.0 under it).
  The "too short" refusal names only tiers that render, plus the split.
- **Refusals name a call that renders.** `_split_call` tries every split
  point, then three lines (`_split_at`).
- **Speed:** `_cross` exits early on boxes that do not meet, `_poly_d`
  prefilters by boxes, and the height search takes coarse rungs first.

### Fixtures corrected (and why)
- c4 chain levels: the F1 walk now has both arcs above, nested (was "2 levels").
- 0->5, 2->7, 4->9 cross on any one side. The pass case is now 0->5, 3->8;
  numberline's selftest refuses the three, naming a stack.
- The blob and within-r values moved to 0..21 and 4.1. At the new marker
  size, 0..18 and sqrt(17) render correctly.
- Walks that used to be refused now render and are pass cases (looked at:
  v6p/P2/newly_render.png). The new refusal cases are [-3, 1, 0, 1] at side,
  [9, -1, 0, -6] at block and vertical [-20, 5, -20].
- o3 is rewritten: every crossing is refused. [-7, 5, -7, 3, 7] must cross,
  so it is refused, and the stack named in the refusal renders.

### Tests
selfcheck_v6 adds six P2 checks, each with a pass and a fail case: a
turning walk nests above; fans open out and never meet; lost_ink leaves a
split fan alone; a minus jump label is no tick number; markers print like
Typst's; random walks mostly render, and each refusal names a call that
renders.

### Random walks (v6p/P2/probe_walks.py, 60 per row, seed 7, range fitted)
Refused before -> after. "Clean before" counts walks the old code drew
that the new sweep does not refuse for crossing or merging arcs
(crossed_before.py).

| tier, labels | refused before | clean before | refused after |
|---|---|---|---|
| item, none   | 51.7% | 15/60 | 33.3% |
| item, labels | 63.3% | 14/60 | 43.3% |
| side, none   | 30.0% | 24/60 | 28.3% |
| side, labels | 33.3% | 25/60 | 31.7% |
| block, none  | 15.0% | 39/60 | 18.3% |
| block, labels| 16.7% | 39/60 | 20.0% |

Before, 7 refusals named no call or a tier that did not render. After,
every refusal names an N.stack call, and that call renders. Most of the
refusals left are walks that go back over the same hop (for example
[-4, -3, -4, -3]) or tightly nested hops at item width.

### Seen, not changed
- The minus-label refusal (nl-negative-jump-label-read-as-tick-number) no
  longer reproduces at HEAD: a sweep of 738 single minus-labelled jumps
  showed no refusal caused by the label. A regression test guards it.
- Nested outer arcs can stand tall, up to the sweep's ARC_RATIO, when they
  must clear an inner label, as in Typst.
### r1 — what three verifiers found, and what it cost

- **Arrowheads follow their arcs** (`_arc_geom`). The head used to point
  along the curve's end tangent while the shaft was cut a head length back
  from the tip: on a short hop the two parted by 50-96 degrees and the shaft
  poked out beside the head -- a hook, not an arrow (31 of 107 heads over 40
  degrees on seeded walks; 1 of 107 now). The head now lies along the CHORD
  from the point where the shaft is cut -- a point ON the curve -- to the
  tip, and the shaft ends exactly at the head's base. A hop under `SHORT_HOP`
  (2.6) heads long gets a smaller head, down to `JUMP_HEAD_MIN_PT`.
  `numberline.sweep` reads the finished file and refuses a head turned more
  than `HEAD_TURN_DEG` (45) off the last `HEAD_BACK_PT` of its shaft.
- **A split names the whole line, not the jumps only.** Every decoration
  call made on an NL is recorded (`_recorded`, `NL._calls`) and the whole
  constructor kept (`_ctor_all`), so the `N.stack` a refusal names carries
  the line's `tick=`, `width=`, points and sets. Before, a line's point P
  was silently dropped, and a `tick=2` line was rebuilt with `tick=1`, which
  failed the minor-tick floor -- so no call was named at all.
- **The words match the call.** The prose said "the jumps up to 4 on the
  first, from 4 on on the second" over a call that split elsewhere, and
  "two number lines" over a three-row stack. `_split_advice` now says how
  many lines the call really has, and nothing about where it cuts.
- **A vertical line is split side by side.** `N.stack` refuses vertical rows,
  so a vertical crossing refusal named a fix that could not run. It now names
  one figure per line (at most three, no two interleaving jumps on one).
- **A hop is called too short only when it is.** The check uses the smallest
  head the engine would draw, so a hop the named stack draws at the same
  width is no longer called too short (it is refused for its place instead).
  "Use a shorter range" is named only when that range, with the same calls,
  renders (`_shorter_range`), and an item walk's split is looked for at the
  wider tiers as well -- the item refusals that named nothing at all.
- **A refused stack names its wider tier.** `Stack._build` retries the same
  rows at `tier='side'/'block'/'strip'` and names the one that renders (a row
  of a stack cannot take "a shorter range": the scale is shared).
- **A fan is anchored to its tick**: with no marker on the line, jumps start
  just over the tick top instead of a marker's radius above the axis.
  (Arc HEIGHT is still read the sweep's way, off the shaft's own chord. A
  verifier measured a nested outer arc at 0.53 of its start-to-tip chord;
  capping that at 0.5 as well pushed the return hop of a turning walk BELOW
  the line -- the very thing P2 fixed -- and doubled the layout search, so it
  was reverted.)
- **Speed.** A refused item walk took 5-13s: every solver pass built the
  fixes for every error, and each rendered stacks that looked for splits
  again. The fixes are now worked out for the refusal actually RAISED
  (`NL._later`, resolved in `render`), split and wider-tier searches are
  memoised and guarded by `_SPLITTING`, and the worst known cases answer in
  under 3s (`p2r1_every_jump_figure_answers_fast`).

Tests (each with a pass and a fail case): the run-together rule and the
fan-angle rule are each proven alone (the verifiers deleted either with the
suite still green); heads follow their arcs; a named split keeps the whole
line; a vertical split is side by side; a too-short hop names what renders;
a tip stands off where a jump leaves (nothing depended on `ARRIVE_LIFT_PT`);
a fan is anchored to its tick; every jump figure answers fast. The random-
walk check now runs each named call and compares its jumps and labels with
the walk.


### r2 — the second verifier round on P2

**A short hop printed as a comma.** r1 laid a head along the chord it cuts
and read the engine's worst head at 36.5 degrees, so `sweep` refused a head
turned more than 45. Seeded walks reach 44.7 (`NL(-8, 8, tier='side')
.chain([3, 5, 6, -2])`) and `chain([1, 2, 3, 4])` drew a 62-degree head its
OWN sweep refuses — the guard had 0.3 degrees of headroom and the defect was
still on the paper. The cause was not the head but the arc: `ARC_MIN` is an
absolute 5px, so a one-tick hop got an arc as tall as a long jump's, the
shaft ended AT the apex and the 4pt head carried the whole descent. A short
hop's arc is now capped by `_turn_cap(span, k_s)` (apex ≤ ½·tan
`TURN_TARGET_DEG`·span, the angle a head's chord leaves the apex at) and then
lowered against the geometry the engine really draws — an arrival lift and a
departure shift bend the end more than a plain quadratic. Both layout paths
keep a turned-but-clear place only as a SPARE, used when no straight place is
free, so no jump is ever refused for want of a straight arrow.
`HEAD_TURN_DEG` is now 40 against a measured worst of 29.4 over 270 seeded
walks (r1: 44.7 against 45).

**Every marker one family.** The `cross` kept a 3.5pt half-extent and a
1.5px stroke — 7.08pt across and 25% heavier than the dot, ring, triangle
and square, so `test_markers([(-2,'x'), (0,'tri'), (3,'x')])` printed two
families. r1 declined the fix because a dot-sized cross made
`figkit.figure_family` read its arms as ticks; that was a bug in the family
key, not a reason: 'two strokes of one length sharing a midpoint' also pairs
a TICK with one arm standing on it, so a tick-sized cross keyed as three
crosses and swallowed its tick. The key now also needs the two strokes
PERPENDICULAR (a tick meets an arm at 45 degrees) and uses each stroke once,
and the cross is drawn at the square's box exactly: half-extent `MARK_R_PT`,
stroke 1.20px, 6.30pt across at 0.90pt. Its registered ink box now covers its
arms.

**A refusal that named nothing.** On a line with a value OFF ITS TICKS and a
layout fault, `_errs[0]` is the layout error and every trial the advice
machinery renders is refused for the off-tick value, so split, shorter range
and wider tier all came back empty while the one-keystroke fix sat in
`self._offtick`. `NL._finer_tick_tried()` now names the finer tick — with a
wider placement when the finer tick alone is refused for crowded numbers —
and only after that call RENDERS. `'has no clear place'` was also the one
jump refusal with no never-drop clause, and its cheapest exit worked
(deleting the walk's `+1`/`-2` labels makes the same call render): it now
ends *never drop the jump, and never drop its label*. A vertical line's
refusal offers a horizontal line only after trying it
(`NL._horizontal_tried`), and a Stack whose row still needs splitting names a
split-row stack that renders (`Stack._row_split_tried`) instead of a bare
symptom.

**Budgets.** The r1 perf guards asserted 3.0s CPU on cases that measure
2.2-2.9s idle, so background load turned the suite red for no defect. Both
are 6s now — still far under the 5-13s (jumps) and the minutes (planes) the
fixes removed.

**Wrong issue, proven.** Two verifiers reported that `sweep_v` carries none
of the new jump rules (they grep inside `sweep_v` for `HEAD_TURN_DEG`).
`sweep_v` turns the model into the horizontal frame and calls `sweep`, so
every arc rule applies unchanged: rotating a vertical jump's head 70 degrees
about its base in the finished file is refused by `sweep_v` in the same words
as the horizontal twin's. Pinned by a test so a later round does not 'add' it
twice. The r1 report's own not-done line said the same wrong thing.

**Tests** (`selfcheck_v6.py`, 339): a short hop prints as an arrow, not a
comma; a jump head is cut from its own arc (on `_arc_geom` itself — r1's head
test only exercised a local copy of the old geometry, so reverting the
shipped function left the suite green); a vertical line reads by the same
jump rules; a refusal always names something that renders; no refusal offers
dropping a label; every number-line marker is one family; a tick-sized cross
is one marker, not three.

## v6 — P3: the leftovers (hide=, the window, the origin's '0', letters, curves)

**`hide=` no longer exists as a way to blank a number.** It survived every
round as "a giveaway blanked, the axis still numbered regularly", and it kept
being the one-token edit that turned a crowding refusal into a rendered
figure with two numbers gone (the ±7 Q plane rendered with the x '2' and the
y '2' missing, every sweep clean). The author's rule 2 is flat: an axis
number is NEVER deleted. `figkit.hide_sets` refuses any `hide=`, in one place
for `axes`, `coord_plane`, `plane` and `wide`, and the refusal names the way
to hide an ANSWER that keeps the axis whole — do not mark the point (leave it
out of `points=`, or drop its letter), leave the value label off, or ask for
the value in the Hebrew text — and, when ink is in the way, room: `width=` /
`max_width=`, `size=`, a finer `xscale=`/`yscale=`, another window.

**A listed number is printed, or the call is refused**
(`figkit.assert_ticks_inside`). `coord_plane(xticks=[0, 2, 4, 8])` on a
(0, 6) axis printed the axis without the 8 and said nothing. The legacy
`ticks=`, one list shared by two axes of different lengths, was written to be
clipped and still is — `coord_plane` clips it per axis before the call.

**`coord_plane` refuses data outside its window** (`figkit.assert_data_inside`).
`figkit_plus.plane` always did; the native path (an old builder's
`house=False`, and every explicit-ink rung) drew a point, a polygon vertex or
a segment end past the axis arrow, off the numbered axes, and
`svgcheck.problems()` called it clean.

**The origin's '0' stays in a corner at any step.** The O3-01 rule compared
the '0' only with NUMBERED ticks, 2 squares apart at the default step, so a
'0' a whole square out — on the grid point (−1, −1), under the point at
x = −1, or in the x-number row where it reads as the number of −1 — measured
a ratio of 1.06 and passed. Now it is bounded in GRID SQUARES, read off the
light grid (`svgcheck._grid_square`): a corner (both offsets ≤ `ZERO_SQ`), or
a slide ALONG one axis (the other offset ≤ `ZERO_ALONG`, out to `ZERO_FAR`) —
the plane whose two diagonals fill every corner needs that slide. The solver
(`Figure._ZERO_SQ` / `_ZERO_ALONG` / `_ZERO_FAR`) is a shade stricter than the
gate, as everywhere else.

**A point's letter stays on its point's side of the ink.** The ring search has
a pass that drops the reach rule when the near spots are taken; it printed
'Q' two squares away, under the triangle's base, where it names the point the
base crosses — and left the ring nameless. `Figure._letter_reaches` refuses
any spot parted from the point by a DATA stroke (the axes, their ticks and
the grid are not data; a stroke that ends at the point, or grazes it within
0.6 em, parts nothing), and caps the reach at 3 em. `svgcheck.letter_side`
reads the same off the finished file, on coordinate planes only — a number
line's brackets and arcs stand between a letter and its dot by design.

**`intersections()` survives poles and close roots.** It evaluated `f - g`
straight on its scan grid, so a hyperbola against a line on a symmetric
window raised `ZeroDivisionError` out of the builder; and two roots inside
one scan interval came back as one. Values now go through the sampler's
guard, no bracket spans a point where either function has no value, and an
interval whose inside dips through zero is split at the dip and both halves
bisected. (Step functions were already sampled as separate runs: `floor x` on
−3..3 is six runs and the finished plane has no riser.)

**Refusals name a call that renders.** A number line's floor refusal named
"a wider placement (tier='block' or tier='strip')" where neither tier draws
the line as called; it now names only the tiers that do (`_wider_tried`), and
where a coarser tick needs a wider placement it names the pair as a call:
`N.NL(0, 100, tick=5, tier='block').point(35, 'A') renders`
(`NL._tier_and_tick`). `figkit`'s "no clear position for label" no longer
offers "shorten the label".

**Tests** (`selfcheck_v6.py`, 346): hide= never unnumbers an axis;
coord_plane refuses data outside its window; a listed tick is printed or
refused; the origin '0' stays in the corner at step 2; a letter stays on its
point's side of the ink; steps, poles and close roots; floor refusals name a
call that renders. Fixtures corrected, with the reason: the ±7 Q plane is
drawn at `max_width=280` (inside 210px the ladder's answer was the letter
across the base), `s1br4`'s yticks were outside its window, `c4_quarters`
asserted a tier on a `width=` line, and `s1br6` neutralises the new bounds
while it rebuilds the OLD solver's file.

## v6 — P3 leftovers (r1): what the three verifiers found after P3

P3 closed hide=, the window, the origin's '0', the letter rule and the
intersections helper. Three independent verifiers then read the result and
found that four of those closures were unpinned, unreachable or still wrong on
paper, and that six open items had never been touched. This round is that list.

**The origin-'0' corner bound is PINNED.** Setting `svgcheck.ZERO_SQ`,
`ZERO_ALONG`, `ZERO_FAR` and `figkit.Figure._ZERO_SQ/_ZERO_ALONG/_ZERO_FAR` to
9.0 left the whole suite green: the one must P3 credited to this rule could be
reverted without a red test, because the check's pass half asserted against the
constant it was meant to hold and its fail half was caught by the older
ownership ratio. The constants are now pinned by LITERALS (the pattern
`selfcheck_v6:5674` already used for `MOVED_TOL`), and the fail half is a
displacement of 0.60 × 1.00 squares at step 2 that ONLY the corner clause sees
(the ratio reads 1.00 there and passes it).

**A named point's nearest text is its own letter.** `svgcheck.number_owns_its_tick`
(new sweep, run inside `problems()` under `marker=`). The ±7 Q plane still
printed wrong at its shipped default width: the x-axis '2' slid 0.32 of a
spacing along the axis and came to rest 0.63 squares from the open ring at
(2, −1) — nearer the ring than its own tick (0.95) and 2.3× nearer than the
point's own letter Q (1.43). On paper the ring read '2' and Q named nothing.
The sweep fires only when all four hold: the number slid ALONG its axis, the
marker stands further from the axis than the number's own row, the number is
nearer the marker than its own tick, and nearer it than the point's letter.

**A point's letter stays with its point.** Two halves. `svgcheck.letter_side`
gained a clause for a letter printed OUTSIDE the drawn plane, past an axis's
end, NEARER that axis's own name than its own point — the 'y O' above the y
arrow on pilot level a page 9, with the origin dot left nameless. And
`CONFUSE_EM` (1.0, beside `MERGE_EM` 0.6) in both `svgcheck` and `figkit`: two
marks a reader cannot tell apart at 8pt ('O' beside the axis '0', 'I' beside
'1') need a whole em on one line, not the 0.6 that parts two ordinary labels.

**The two number rows do not meet on one line.** `reading_merge` now knows
WHICH row a number belongs to. The close-row concession (`ROW_GAP_EM`, 0.12 em)
is for two numbers of ONE row, which a reader scans along; it was applied to
any two axis numbers, so on pilot level c page 11 the x '−2' and the y '−5'
printed 0.66 em apart on one line and read as '−2−5'. `CROSS_ROW_EM` (0.90)
with `CROSS_BAND` (0.15): a pair from the two rows that shares a line needs a
word space and more. The house corner is untouched — the x '−1' and the y '−1'
of a step-1 plane touch corner to corner and share NO line at all (−0.007).

**A scale never runs backwards.** `svgcheck._scale_runs_the_right_way`, inside
`tick_alignment`. Negating every x tick number of a finished plane (or of a
number line) used to give `problems() == []`: each number was only ever
measured against the tick it stands on, and the lattice was fitted with a
signed step.

**A crossed number stays at its tick.** `svgcheck._stray_across` (coordinate
planes). A number that stepped ACROSS its axis and then slid along it was
judged by nothing: `_mirrors` merges it back into the row only at the row's own
offset, and a row of one is thrown away by `_lattice`. A sweep of one x '4'
over a whole spacing caught only 0.56–0.75; it now catches every slide past
`MOVED_TOL`, on both sides alike.

**Curves print as curves.** `Figure.curve`/`bezier` tag their part `"smooth"`
and the emitter draws such a run with CUBIC segments (clamped Catmull-Rom
hands; zero-length steps dropped). 2cos x at width=430 turned 24.8° between
neighbouring segments with 18.7pt pieces — about 1pt, 0.36mm, off the true
curve, and the F4 vertex printed with a flat bottom. It now turns 2.8° with
2.0pt pieces, and every sample is still within 0.05 units of f(x).
`Figure._SMOOTH_CURVES` exists so the test can print the faceted drawing and
measure it.

**`data_ticks=` is not a way to unnumber an axis.** `_assert_axis_numbers`
returned at once whenever `data_ticks=True` and fewer than two listed values
sat on grid lines, so NO rule ran on that axis: a plane refused for its x '−3'
rendered with `xticks=[-4.5, -1.5, 2.5, 4.5]` — four numbers, not one integer,
across 12 squares. `_DATA_TICKS_MAX` (2): with nothing on the grid, at most two
values may be listed; they are the item's data values, not a numbering.

**`sparse=` is not the surviving hide.** `_sparse_is_didactic` runs the list's
own rules and then probes the SAME figure fully numbered (xticks/yticks and
step back to the engine). If the full numbering is refused, sparse is refused
too and names that refusal: sparse is the declared "infer the scale" mode, not
a way past a crowded figure. It had been reaching the C7r3-P3 drawing (the x
'2' and the y '2' gone from the Q plane) in one more token than `hide=`.

**A dead end names a call that renders.** `_last_resort` probes a coarser step
and a WIDER window at the full width and names the first that renders. The old
tail, "a window with fewer squares (each prints bigger)", never rendered these
figures and since P3 added `assert_data_inside` is itself refused whenever the
data fills the window. With no call at all the message names the drawing
itself, never a knob.

**Smaller things.** A refusal names its tick by its DATA VALUE ("beside its
tick at x = −3"), not in SVG pixels. `max_width=None` means the page width
(`PAGE_MAX`, 430) instead of crashing with a raw TypeError. The
curve-outside-window refusal no longer offers to drop the curve, and the
owned-value hint no longer says "move the shape off the axis" (that is moving
the data). `figkit.assert_ticks_complete` refuses, on the native
coord_plane/axes path too, a listed set that is a regular numbering with a HOLE
inside it. `svgcheck.Model.critique` reads the `<!--critique:-->` marker a
declared student_drawing emits, so `problems()` no longer reports the item's
own deliberate error as a defect. The window a scaled figure's out-of-window
refusal names is rounded out to whole squares, so the next call is not refused
for the number the first one handed the author.

**hide= in the docs.** `figkit_plus.plane`, `figkit.coord_plane` and
`figkit.axes` documented `hide=` as a working declared mode while every call
raised, and the refusal named `value_label=False` / `label=`, which are
`numberline.NL.point` parameters — a builder who followed the message got a
TypeError. The docstrings, the refusal and the v5.x SKILL.md sections now say
what replaced it: hide the ANSWER by not marking it (the point out of
`points=`/`dots=`, its trace out of `dashed=`, its number out of `values=`),
and on a number line `NL(...).point(v, value_label=False)` with `answer_hidden=`.

## v6 — P3 leftovers (r2)

Three verifiers read the r1 hand-over. What they found, and what changed.

**A curve given as a LIST OF POINTS is drawn through its points.** r1 drew
every `curves=` run with Catmull-Rom hands. For a sampled function that is
right; for a point list — the form the stage-1b brief and `plane()`'s
docstring both promise — the polyline IS the data, and the hands bowed the
line off it: a list with a corner (`[(-3,3),(0,0),(3,3)]`, a travel graph, a
zigzag) was REFUSED at every width by the skill's own lost-ink gate ("80.88%
of the geometry the figure was given has no ink on it"), and a mild list
rendered 0.052 units off the line the author gave with every sweep silent.
`Figure._CORNER_DEG` (20°) makes a sharp vertex a CORNER — no hand there —
and `Figure._SMOOTH_DEV` (0.30 viewBox units) caps how far across its chord
a hand may reach, so a cubic can never stand further than that off the
geometry handed in. Measured: the four point lists render at three widths,
the drawn line is within 0.02 units of its chords, and the curve tests of r1
(worst turn ≤ 6°, printed pieces ≤ 4pt) are unchanged.

**`data_ticks=` names DATA.** r1 capped the list at two values when none sat
on a grid line; two were still enough to strip an axis and to clear a real
refusal (`plane((-6,6),(-6,6), polys=[...], step=1)` is refused for its
crowded '−3'; adding `data_ticks=True, xticks=[-4.5, 1.5]` drew it with no
integer on the x-axis at all, `problems() == []`). `_data_ticks_is_didactic`
now asks the parameter's own question: when NOT ONE listed value sits on a
grid line, at least one of them must be a coordinate of something drawn. The
shipped figures (a point at x = 1.5, dots at 2.5 and 6.5) are unaffected.

**Three reading rules, as AUDIT SWEEPS.** The verifiers found three
placements that read wrong and that nothing reported:

* `svgcheck.number_on_data(svg)` — an axis number that left its row, crossed
  the axis and landed ON the drawing (the gallery's `divide` printed its x
  '2' 0.77 of a spacing above the row beside the dashed median; the pilot's
  run/rise figure printed its x '2' 6.1px from the dashed RISER and 13.3px
  from its own tick).
* `svgcheck.row_straddles(svg)` — a row of numbers printed on BOTH sides of
  its axis (pilot a 4b: '0' and '2' above, '4' and '6' below).
* `svgcheck.zero_owner_strict(svg)` — rule 4 read literally for the origin's
  '0': nearer the CROSSING than any other tick when it was pushed ALONG an
  axis (`ZERO_RATIO`'s 1.25 of slack was measured on corner zeros, which sit
  on the diagonal; a '0' 1.06 squares along a step-2 axis measured 1.11 and
  passed).
* `svgcheck.letter_side(svg)` gained the reading-distance clause for the
  ORIGIN's letter (`LETTER_NEAR_EM` 1.4): 24 of 209 pilot planes printed 'O'
  a full square or more from the origin dot — up to 2.27 squares — while the
  axis '0' sat beside that dot, so the dot's nearest text was a number.

None of the four REFUSES inside `problems()`, and that is deliberate
(doctrine 4): where they fire the placement is often the only one the figure
has at any width — the gallery's parallelogram keeps an edge beside the tick
at x = −2 however wide it is drawn, and the homothety figure's triangle has
its vertex ON the origin. A refusal there would name no fix that works. Each
rule is also a BUILDER switch, off by default, exercised by its test:
`figkit._ROW_NEAR_EM = 0.75` makes the solver pass over a crossed spot whose
stroke is `_ROW_INK` (1.6) times nearer than the tick — that is what puts
the pilot's '2' back in its row; `figkit.Figure._LETTER_NEAR_EM = 1.3` holds
a point's letter to the reading distance in the ring search's first pass;
`figkit.Figure._ZERO_STRICT = True` solves the origin's corner under the
strict bound first. Each was measured with the whole suite: held on by
default, they re-place labels in figures that had settled (eight to nine
stage-1b checks went red on drawings that read fine), so the sweeps are what
a sheet is audited with and the switches are there for a builder who wants
the stricter search.

**Smaller things.** A refusal names an object by the coordinates the AUTHOR
wrote, never by SVG pixels (`svgcheck._at`, `_at_point`, `figkit._num_pair`,
and `figkit_plus` hands the figure a `_data_at`); `numberline.NL(...,
asks=True)` is a refusal naming the list instead of a bare TypeError; no
live refusal offers "a window with fewer squares" any more (figkit ×4,
figkit_plus ×3, gate_variety ×2 — they name `step=2`, `size=` and a wider
figure, which do render); and a dead end whose WINDOW cannot be numbered at
that width says so (`_fewer_objects_helps` probes the empty window first)
instead of sending the author to split the item, which is refused too.

## v6.1 — the stage review (three verifiers, one round)

Three independent verifiers read all of v6.1. What they found, and what the
engine does now.

**ONE printed look, on every figure kind — not only on planes.** P1 gave
`plane()`/`wide()` a house look in pt and left every other builder following
its own width, and G78 — the only gate that judges it — dropped anything
`svgcheck.is_coordinate_plane` rejected. The showcase document was the
evidence: on gallery page 6 the two figures of ONE question printed their
angle numbers at **7.2pt and 8.9pt** and their strokes at 0.91/0.73 against
1.24/0.99, and across the gallery the digits printed at 7.2 / 7.5 / 7.7 /
7.9 / 8.0 / 8.9pt. Three things changed:

* `figkit_plus.house_text_pt(key)` is the one place a printed TEXT size comes
  from — HOUSE, moved with the sheet's own `number_pt`. Strokes are not
  scaled: a 1pt line is a 1pt line whatever the numbers print at.
* `euclid._Fig.render` SOLVES its font instead of growing it from below: it
  draws once to learn pt-per-unit, then re-draws at `house_text_pt` until the
  scale settles (two or three passes). The size follows the TEXT, not the
  call — a bare number prints at the number size and a name at the letter
  size, because `mark()` carries an angle on one builder and a line's name
  (`m`, `O`, `r`) on another. Stroke weights are pinned in pt around
  `HOUSE["main_pt"]`, keeping each builder's relative weights. When the house
  size cannot be drawn the figure falls back to the v5.6 loop **and carries
  `figkit_plus._fallback`'s tag**, so G78 reports it instead of letting a
  second look ship in silence.
* `numberline.py` is wired to `figkit_plus.HOUSE` (`_house()`, `_hpt`,
  `_hpx`): tick numbers 8pt, letters 9.5pt, axis 0.80pt, ticks 0.60pt,
  4.4pt across, markers at the plane's open-marker radius. It printed
  7.50pt / 8.25pt / 1.05pt / 6.8pt before, so a sheet with a plane over a
  number line printed two looks — z08_a page 1 ships exactly that — and
  `figkit_plus.new_sheet(number_pt=...)`, the whole P1 API, did not reach a
  number line at all. `new_sheet` now carries the size both ways.
  The sweeps' weight bands follow the pen (`AXIS_W_LO/HI`, `TICK_W_HI`,
  `ZERO_W`) instead of the literals 1.2/1.7/1.6, which is what made
  `sweep_v` report "no vertical axis" the moment the axis pen changed.

G78 reads **every** figure now: numbers against numbers, letters against
letters, each family with its own spread (letters print 19% larger, so the
same drift is more points), the arrowhead rule still planes-only. A figure
with no axis numbers at all (a sketch plane, `ticks=False`) is sized on its
LETTERS — it used to keep its first font guess, which is why z08_a's item
sketches printed 8.4pt beside the sheet's 9.5pt. A figure the
`figkit.number_line` SHIM drew keeps its caller's own `size=`/`font=` by
design; it now says so in the file and G78 names the builder call that puts
it back in the sheet's look.

**A walk keeps one side.** `chain([2, 3, 4, 5])` drew hop 1 above the line,
hop 2 **below the row of numbers** and hop 3 above: a detached comma under
the digits, with its `+1` beneath it, and the one thing the figure teaches —
a walk read left to right — gone. The side was only a preference, tried at
each height before the height grew. Now hop-after-hop in the SAME direction
is a *walk*: `_nest_layout` drops every side assignment that puts a walking
hop below the line, and the older solver tries every pass on the walk's own
side before it looks at the other one. A walk that cannot hold one side is
REFUSED, naming the split stack and the wider placements — all of which
render.

**A number printed on a drawing is a claim about it.** The plane was the one
surface where it was not checked: `svgcheck.value_labels` measures a printed
coordinate pair (`A(3, 1)`) against the dot it labels, and a length printed
beside a horizontal or vertical dimension arrow against that arrow, and both
run inside `problems()`. On the number line the rule fired only for a BARE
numeral — it worked by reading the text as a tick number on the wrong tick —
so `A(4)` or `x=4` over a dot at 3 drew clean; `_point_value_labels` reads
them now. `svgcheck`'s angle-text rule reached only `r + 4.5 em` from an arc,
which `euclid.angles_at_point` steps past by printing its label at a ray's
far end; a degree text strictly inside exactly one wedge is measured however
far out it stands.

**The hatches, again.** `data_ticks=` refused an all-off-grid axis only ABOVE
its cap of two, so the commonest shape — exactly two off-grid values — fell
through with no density, regularity or completeness rule run at all: a
20-square axis numbered `−4.5` and `1.5`, nothing on a grid line,
`problems() == []`, and two dots at those x values cleared the didactic
guard. At least one number stands on a grid line now, whatever the count.
`between=` was the one hatch with no didactic guard at all, and the off-tick
refusal offered it as a co-equal alternative to a finer tick — strictly
cheaper under deadline. `_between_is_didactic` refuses it on a value that
sits ON a tick, and (on a whole-number tick) when half that tick shows the
value exactly and that call renders.

**Refusals that name what renders.** The tick-spacing refusals named "a wider
placement (tier=X or tier=Y)" without drawing the line there: over 5 seeds ×
120 random walks, 258 named a wider placement and 14 named only tiers that
are themselves refused. They use `_wider_tried` now (which renders a trial
first) and fall back to the tick-and-tier pair; the same probe reports 0.
`svgcheck._room` no longer names "a larger unit / size / maxw in the builder"
— knobs a builder need not have (z01_a's own `_fit` only ever SHRINKS the
unit and, on a vertical line, returns after the first render) — but the
window, the step, a larger figure, and past 3× the zoom. The dead-end clause
prints the width it drops (`width=None (drop width=124), step=3,
max_width=430`), as its sibling clause always did. `wrong_scale=True`,
`'2.5'` and `['2.5']` are refusals naming the `(tick, text)` list instead of
bare `TypeError`/`ValueError`, as `asks=True` already was.

**Two rules that answered by accident.** "Numbers stand on the LONG ticks"
broke a tie with `max(set(...), key=count)` — the iteration order of a set of
floats — so the rule's answer changed when the tick lengths did; the longer
tick wins a tie. And "a refusal names nothing that renders" tested for the
literal `N.stack(`, which the PROSE fallback also contains, so a message with
no runnable call lost its off-tick fix; it looks for `N.NL(` (every runnable
call quotes one).

**Smaller things.** `plane(shaded=[...])` emitted the grid BEFORE the shade,
so the shade painted over it and the squares could not be counted inside the
region the question is about — it ships on z08_a page 9 and gallery page 2;
the shade goes first now. `svgcheck.row_straddles` allowed 2 of 6 numbers to
cross, and 2 of 6 is the commonest straddle (a sine curve's `−6` and `−4`
below the axis, the rest above): two crossers standing SIDE BY SIDE are a
second row whatever the share, while crossers that each stand alone are rule
4 at work. A `values=` label printed 0.26pt LARGER than the axis numbers of
its own figure at every width; it prints at their size, with the clearance
its bigger box used to give the ring search. And an item width taken up to
150px to hold the house look (`width=124` drawn at 140) was a comment inside
the SVG and nothing else — G78 says it.

Sixteen checks were added to `selfcheck_v6.py` (the `SR ...` rows), each with
a case that must pass and one that must fail.


## v6.1 — the regression round: three engine fixes found by rebuilding shipped levels

Five packages were rebuilt against this engine — `z08_a` and `z47_a` from the
regeneration queue, and the three numbered-axes pilot levels (ח׳/28 א׳, ב׳,
רמת מצוינות) — and every page of every PDF was looked at, beside the same
level copies built on the v5.8 snapshot. Page counts are identical
(12 / 11 / 11 / 15 / 14) and, apart from the two refusals below and a font-size
string written `10.60` instead of `10.6`, every finished figure is byte for
byte what v5.8 drew. Three things were wrong, and each is fixed with a test
that passes AND a test that fails.

**1. A `values=` caption was counted as a LETTER (G78 refused a sheet for a
size the engine itself chose).** `figkit_plus._plane` prints a `values=` text
at `font * 0.92` — the axis-NUMBER size — on purpose, and says so. Nothing in
the finished file said so, so `printed_letter_pt` read a non-numeric one
(`x > 0`, `3 cm`) as a letter; on the pilot's רמת מצוינות sheet four quadrant
captions outvoted the two axis letters in the median, the figure reported its
letters at 7.9pt against the sheet's 9.5pt, and **G78 refused three figures**.
The message named no fix, so the easy escape was deleting the captions.
*Fix*: `figkit.Figure` emits `class="value"` on a `values=` label (a new
`Label.value_text` slot, set by `figkit_plus`), and `printed_letter_pt` skips
it. The captions still print, at the number size, where they belong.
Test: `sr_a_values_caption_is_not_a_letter` — 9.5pt with the mark, 8.0pt with
the mark stripped out of the file.

**2. A number line's own tick was read as an equality tick.**
`svgcheck._axis_like` knew an axis only as a long horizontal stroke crossing a
long vertical one. A number line has no vertical, so `numberline.sign_chart`'s
two boundary ticks — the house tick, 4.4pt — were read as equality ticks on the
axis as carrier and reported under the 5pt mark floor, on a drawing that
`numberline`, its own `sweep` and every gate pass.
*Fix*: a long stroke that **ends in an arrowhead** is an axis too — that is
what an axis's arrow means — so it joins the axis lines and its ticks stop
being anybody's equality ticks. Test:
`sr_a_number_lines_tick_is_not_an_equality_tick` — clean at all three tiers
with the ticks still in the file; strip the arrowhead and the report comes
back; a genuinely short equality tick on a polygon edge is still refused.

**3. A refusal that named no way out.** `numberline.sweep` refused the vertical
thermometer at `tier='item'` with *"label 'L' floats 12.4pt over its reference
line"* — a right catch, the dashed line really does stop short of its label at
that height — but it named no fix, and doctrine 4 says a refusal that names
none sends the builder to the escape the author complained about: deleting the
label. *Fix*: the message now names the calls that render (`height=` or a wider
`tier=`, `reference(v, both_sides=True)`) and says **Keep the label**. Test:
`sr_the_floating_label_refusal_names_a_fix` — refused at `height=150`, renders
at `height=205`, and the message never says drop or remove.

### What the comparison and the showcase show at default settings

`compare_v61.pdf` redraws the five comparison figures with **no `number_pt=`**
— the house default decides — beside Typst/cetz and LaTeX/TikZ at the same
printed width. F5's side AB is whole (v5.8 cut it in two around the y number
−2) and F4's parabola has no gap; the numbers that were in the way stepped to
the other side of their axis instead. v6.1 numbers every 2, which is the
author's rule; Typst numbers every 1 and LaTeX every 2.

`numberline_showcase.pdf` draws all thirteen families at `item` / `side` /
`block`. Two changes since v6.0 are the engine reading its own sizes more
strictly, not regressions: the widest-number measurement is 12.0pt where it was
11.2pt, so the spacing a numbered tick needs is 19.2pt where it was 18.0pt, and
the jump-chain family now needs `tier='block'` (18.6pt at `side` misses by 3%);
and the vertical thermometer is refused at `item` by fix 3 above. Both
refusals name calls that render, and both families render at `block`.

### Known false positives in the generic sweep (unchanged from v6.0)

`svgcheck.problems()` — the generic sweep, not any builder's own — still
reports `tick label '1' sits on the tick of 2` on two families: **stacked
fractions**, where a numerator is read as a standalone tick label, and the
**double number line**, where the second scale's numbers are measured against
the first scale's lattice. Both drawings are correct and both builders' own
sweeps pass them. Do not "fix" a sheet because of these two; they are a
reading bug in the generic sweep, and they are the reason a PDF-level gate
built on `svgcheck.problems()` is not enabled yet.

---

## v6.2 — Q1: angle arcs, the origin's letter, and the `data_ticks` escape

Three things the author found on the v6.1 pages. All three were cases where the
drawing was wrong and **no gate could fail**.

### 1. Angle arcs

**What was wrong.** Adjacent angles marked *equal* at one vertex —
`arcs=[(A,B,D,1), (A,D,C,1), (A,B,C,3)]` — drew their single arcs at the **same
radius**. They met end to end along the shared ray `AD`, so the page showed one
unbroken ring right across `BAC`, with the triple arc outside it: the containing
angle looked like it carried four arcs, and *BAD = DAC* could not be read at
all. `coincident_arcs_in` did not see it, because the two arcs do not overlap —
they only touch. Three more faults came with it: the step-out that keeps arcs
off each other had **no bound** and nothing checked what the arc it moved landed
on (on a −1..3 window the outer ring came out at r 22.3 with a vertex dot 22.63
away and a side 22.63 away — the arc ran through both, silently); the same angle
listed twice became a **double arc**, which on the page means "equal to the
other double-arc angles", a meaning nobody wrote; and the radius and spacing
were in **figure units** (r 18, step 4.5), so one marking printed 4.2pt rings
2.1pt apart at an item width and 14pt rings 7.1pt apart at 430px.

**What changed.** `figkit.Figure.arc` keeps a **nest per vertex**
(`_arc_nest` / `_arc_layout` / `_arc_draw`):

* Arcs at one vertex whose angles **overlap OR TOUCH** take separate radii.
  (Breaking the ring with a gap instead was tried and dropped: `svgcheck`
  measures an arc's span against its angle *text* to `ANGLE_TOL = 0.6°`, and a
  readable 1.5pt gap is 7° at a 12pt radius.)
* The nest is bounded by `ARC_INSIDE` (0.5) of the **shorter ray** of every
  angle at that vertex, and the whole nest is **compressed** — the earlier rings
  redrawn in place — to fit, down to `ARC_R_MIN_PT` / `ARC_STEP_MIN_PT`. Only
  then is it refused, and the refusal is a `LayoutError`, so `plane()`'s rule-5
  ladder climbs: a wider figure is *fewer figure units per printed pt*, so it
  really does cure this one.
* `r=None` (what `figkit_plus.plane` passes at the house look) sizes the nest in
  **printed pt**: `ARC_R_PT` 7.5, `ARC_STEP_PT` 2.6. A number is still a radius
  in figure units, with `step=` beside it, so `euclid` and older callers are
  unchanged.
* The same angle listed twice is **merged** when both ask for the same number of
  strokes, and **refused** when they disagree ("marked twice over … drop one of
  the two entries from `arcs=`").
* The anchor `arc()` returns for the angle's own text is outside the
  **outermost** ring, not the innermost.

**New sweeps, reading the finished SVG** (both inside `problems()`):

* `svgcheck.arcs_join(svg)` — two arcs at one vertex on one radius meeting end
  to end under an arc that spans them both.
* `svgcheck.arc_crossings(svg)` — an arc that runs through a dot, a label or a
  side. A stroke through the arc's **own vertex** is not a crossing: the two
  rays and any cevian leave the vertex by construction.

Tests: `q1_adjacent_equal_arcs_are_separate_rings`,
`q1_an_arc_stays_inside_its_angle`, `q1_a_repeated_angle_is_merged_or_refused`,
`q1_arc_rings_print_at_one_size` — each with a case that must pass and a case
that must fail, read back with `selfcheck_v6._q1_arcs`, that file's own arc
parser.

### 2. The origin's letter and the origin's `0`

**What was wrong.** Two reading rules were **detection-only**.
`svgcheck.letter_side`'s reading clause ran only when called with
`reading=True`, and `problems()` called it with `reading=False`;
`svgcheck.zero_owner_strict` was public and tested and `problems()` never called
it. So 27 of the 206 rebuilt pilot figures printed the origin's `O` far enough
from its dot that the **axis `0` was the nearest text to it** — the point read
as named by the number and the letter as naming nothing — and 7 printed a `0`
nearer another tick than the crossing. Every gate was silent.

**What changed.** Both run inside `problems()` now, tagged as layout refusals,
so `plane()`'s rule-5 ladder climbs. Each is held to doctrine 4 by a gate that
reads the finished file and asks whether a better place exists at all:

* `svgcheck._zero_has_a_free_corner(M)` — the `0` rule fires only when one of
  the four corners of the axes' crossing is free paper. The plane with BOTH
  diagonals drawn has no free corner at any width, and that figure keeps
  rendering (it is a shipped check).
* `svgcheck._letter_near_spot_free(M, own, T)` plus a second threshold,
  `LETTER_REFUSE_EM` (1.75), above the reporting one. A point ON the origin has
  a floor of its own: the skill's own gallery q15 — a circle centred on the
  origin with two chords through it — prints `O` at **1.56–1.62 em at every
  width from 210 to 430 and at every hand offset**, so refusing at 1.4 em would
  name no fix that renders. `letter_side(svg, reading=True)` still REPORTS from
  1.4 em, which is where it was calibrated; `problems()` passes `curable=True`
  and refuses from 1.75 em, and only where a near spot is actually free.

Both builder-side switches stay as they shipped. `Figure._ZERO_STRICT = True`
broke two shipped checks (the confusable `0`/`O` rule and the origin-slide
test) and `Figure._LETTER_NEAR_EM = 1.3` broke four while curing nothing
measurable on the pilot — the sweep holds the rule and the ladder cures it. The
FINE ring of the label search does now keep the reading distance
(`passes.append((fine, True, dot_))`), so a spot the 30° ring misses and the 5°
ring finds is taken before the reach rule is dropped.

**Doctrine 4 — the refusal names a fix that renders.** `q1_the_origin_letter_is_enforced`
proves the rule can FAIL (the mutation `R3-LETTER-SWITCH-VACUOUS`): a plane whose
origin letter stands 2.5 em out with free paper beside the dot is named by
`problems()` itself, not only by the audit call — and the same file with the
letter beside its dot is clean. The uncurable gallery figure renders and is
still reported.

**Measured on the rebuilt pilot.** Across `work_a` + `work_b` the origin-letter
findings now sit at 1.47–1.92 em (they were 1.51–2.93): `work_a` 13 → 9,
`work_b` 11 → 10, and the `0`-owner findings 4 → 0. Two figures are newly
refused — `work_a` q1 item ב and `work_b` q5 item ד — each with a message
naming `width=180`, which is the item's own fix. Never by dropping the letter
or the number.

Tests: `q1_the_origin_letter_is_enforced`, `q1_the_origin_zero_owner_is_enforced`.

### 3. The `data_ticks` escape

**What was wrong.** `_assert_axis_numbers` returned as soon as **one** listed
value sat on a grid line, so one on-grid value switched off the density,
regularity and completeness rules for the whole axis. A call refused for a
crowded `−3` rendered with eleven numbers per axis gone and `problems() == []`.

**What changed.** The on-grid numbers are the axis's **own numbering** and are
judged as one *whatever their count* — the branch recurses on them, so an axis
carrying a single `2` beside a data value `−4.5` reaches the head rule ("the
x-axis carries 1 number(s)"). `data_ticks=` still adds at most
`_DATA_TICKS_MAX` values off the grid **beside** a real numbering, which is what
it was always for.

Four shipped fixtures encoded the escape (`xticks=[1.5, 4, 7.5]`,
`yticks=[300, 1140]`, `xticks=[1.5, 3, 4.5]`, `xticks=[2.5, 5, 6.5]`) and were
corrected: each now carries the axis's regular numbering with the data value
beside it, at a width that fits them. `1140` became `1125` — with a numbering
every 2 squares, `1140` stands half a square from `1200` and the two numbers
touch.

Test: `q1_data_ticks_cannot_skip_the_numbering`.

## v6.2b — closing the round: the origin's letter for real, the shim's size, `Set`

An independent verifier rebuilt 70 plane figures from the pilot and read them
back with its own parser. Three of its findings are answered here; the other
three are recorded honestly below.

### 1. The origin's letter (V1 — the defect the round was chartered to fix)

**What was still wrong.** Section 2 above put the rule inside `problems()` and
then gave it two floors that between them let the defect through: the refusal
needed `LETTER_REFUSE_EM = 1.75` **and** a free near spot. On the 70 rebuilt
pilot planes 12 letters stood past the reading distance, 18 printed the axis
`0` nearer the origin than the `O`, and **nothing was refused**. Worse, the
escape the notes named — a wider figure — measured *worse*, and the letter had
a way out of the rule entirely.

**The way out, and the fix.** `letter_side` paired a letter with its NEAREST
dot. A letter far enough from the origin is nearer some OTHER point's dot, so
the sweep read it as that point's letter, standing comfortably in reach — the
pilot's 14b parked `O` 0.78 em from `P`'s dot and passed. **A dot at the axes'
crossing now owns `O`**, wherever the letter ended up. No rung can hide it, and
`plane()`'s ladder does real work against it: 14b came down from 1.74 em to
1.48.

**The fix that renders, and the floor.** Where the text that owns the point is
the axes' own `0`, the cure is not a near spot — it is `origin=False`: the
origin has ONE name, and the letter is it. Measured on all 12 offenders:
`origin=False` renders every one and brings the letter to 0.88–1.41 em, 11 of
the 12 then nearer their own point than any other text. So at the origin the
refusal no longer asks for a free near spot, and `LETTER_REFUSE_EM` is **1.65**,
re-measured by rendering the cases and LOOKING at them: `K` on the origin of the
3-4-5 triangle at 1.44 em and of the trapezoid at 1.53 em read perfectly, and so
does the pilot's 12b at 1.46; 18b at 1.65 prints `O` above the plane beside the
`y` arrow and 14b at 1.74 two rows under the `x` axis, and those name nothing.

Five figures took the fix rather than the refusal: the gallery's q19 and q20
(rotation and dilation about a named centre `O`) and three `selfcheck_v6`
fixtures whose square or triangle has a **named vertex on the origin**. In each
the figure names the origin itself, so the axes do not number it as well.

Test: `q1b_the_origin_letter_is_refused_and_origin_false_cures_it` — the parked
letter is named (it was not), the gallery's own dilation is refused at two
widths with `origin=False` in the message, that call renders clean with the
letter inside the reading distance, and a named vertex on the origin at 1.44 /
1.53 em still renders, so the rule does not over-fire.

### 2. `figkit.number_line` prints the sheet's look (V2)

`regen/work/z08_a` did not build, against v6.1 either: its q2 item ב is a
`figkit.number_line`, and the shim printed its **caller's own** `font=15.8` on a
150px drawing — 7.5pt — while the rest of the sheet printed numbers at 8.0pt and
letters at 9.5pt, so `G78` refused the level. Doctrine 5 says the shim keeps
existing levels working.

A `font=` a v5.x call chose was chosen to be *readable at that width*, which is
exactly what the house look now settles for every figure on the sheet. So it is
the **seed** of a search, not the answer: `number_line` renders, measures what
the numbers actually printed at off the finished file, and corrects until they
print at the sheet's `number_pt`; the letter keeps the house ratio to it
(`numberline.NL._letter_px`). The geometry — `size=` units per unit, `width=`,
the ticks, the marks — is the caller's, unchanged. `house=False` keeps the raw
px for a caller who wants it.

Test: `q1b_the_number_line_shim_prints_the_sheets_look` (pass: the sheet's
sizes; fail: `house=False` prints the caller's; and the tick positions are
identical either way, so only the type size moved).

### 3. `Set` hands its line back (V6 — documented at last)

`numberline.interval()`, `union()` and the other module-level set functions
return a `Set`. A `Set` now carries the line it was built on:

```python
N = numberline.NL(-5, 5, tier='side')
s = N.interval(-2, 3, closed=(True, False))   # a Set on THIS line
s.on()        # the NL it belongs to
s.svg()       # ... and its render, so .interval(...) keeps the chain
s.render()
```

A `Set` built by the **module-level** `numberline.interval(...)`, which has no
line, refuses `.svg()` / `.render()` with a message naming
`NL(lo, hi).interval(...)` — the call that renders. Before this, `.interval()`
broke the chain and every set figure needed a package-local wrapper.

Test: `v6.2 a set hands its line back (pass+fail)`.

### What this round did NOT fix

* **V3** — `pilot/work_a` does not build against v6.x, and did not against
  v6.1 either: three v5.6-era `plane()` calls are refused (an axis with no
  numbers, a number every 4 squares on an 8-square axis, a `−8` with no room
  at `width=125`). Each refusal names a route that renders; the level was
  never updated. Pre-existing, not a regression.
* **V4** — the `z01_a` port ships q28g with words and no picture. The route
  the escape ladder names (the head figure moved to block width, `q['fig']`)
  was used for q16, q11 and q34 on that sheet and not tried for 28g.
* **V5** — the port report says `selfcheck_v6.py` prints 399 PASS lines; it
  prints 398 (400 with this round's two new checks). The report's count was
  off by one.

## v6.3 — S1: `shapekit.py`, and the tick-vs-point defect fixed for real

### 1. What was wrong

`euclid.quad`, `euclid.triangle_with` and `euclid.circle_fig` each draw **one
fixed vertex list per kind** (their `V` dicts), because each verifies its whole
family from that one list. A sheet does not work that way: one question wants a
15×6 rectangle, the next a 16×12 one, the next a trapezoid whose bases are 9 and
4 with height 6, the next a 5-12-13 triangle. `rectkit.py` proved the way out
for a single shape — a parametric figure on `euclid._Fig` plus computed add-ons,
one line per figure. Everything else still needed a package-local helper, which
is outside every check the engine has.

Second, and worse: `rectkit` shipped with a **workaround**, `marks=False`.
svgcheck reads an equality tick back from the finished SVG and asks which
*piece* of its carrier it names — of the pieces between a stop behind it and one
ahead (the ends, every vertex, every cevian foot, every dot), the tick names the
one whose middle it stands nearest, the shorter winning a tie
(`svgcheck._marked_length`). A tick sits at its side's exact middle. Put two
points on that side symmetrically about the middle (DE = CF on DC — an everyday
ז׳–ט׳ configuration) and the middle piece EF has its middle in the same place: a
tie, won by the shorter piece, so the tick read as "EF = AB" and `render()`
refused the figure. The cure was to pass `marks=False`, which deleted the four
equality ticks **and** the right angle — doctrine 4's forbidden escape, the one
where the easy path drops information the sheet needs.

### 2. The engine fix (`euclid._Fig._tick_plan`) — r1

The first attempt slid the tick off the middle until the whole side won
svgcheck's nearest-middle contest. On the printed page that is not a fix, and
the independent verifier caught it: for the headline case (E at 0.25, F at 0.75
on DC) DC's middle and EF's middle are **the same point**, so the slid tick
stands between E and F and a student reads "EF = AB". It won the *normalised*
score — the offset divided by the piece's own length — not the reader.

So the mark is placed by `_tick_plan(a, b)`, which has three answers:

* **nothing on the side** → the tick at its exact middle. The v5.6 behaviour,
  untouched, and still what almost every figure gets.
* **something on it, and a position that reads as the whole side exists** →
  the tick slides there. The smallest slide that (a) keeps `_TICK_CLEAR` (0.10
  of the side) from every point on it, (b) wins svgcheck's contest by
  `_TICK_WIN` (0.04, rounded as svgcheck rounds), and (c) — new in r1 — stands
  `_TICK_EYE` (0.06 of the side) **further from the middle of any piece holding
  it than from the side's own middle, on paper**. (c) is what the first attempt
  lacked.
* **no such position** → the mark goes on a **span bracket**: a thin line
  parallel to the side, offset outside the figure, running exactly from a to b,
  with the ticks at *its* middle (`figkit.Figure.span_ticks`). Its ends are the
  two endpoints and nothing stands on it, so both the reader and
  `_marked_length` read the whole side. This is the second route BRIEF_V63 §2
  offered, and it is the only one that is unambiguous when the points are
  symmetric. Nothing is ever dropped and nothing is ever refused for want of a
  tick position.

`_tick_stops` collects what svgcheck will find on the side: every dot and
stroke end strictly inside it, **and** (r1) every sample point of a circle
standing on it. svgcheck reads a `<circle>` as a 48-gon, so near a tangency
several of its vertices land on the side — which is why a regular polygon with
an inscribed circle was refused at rotate 0 and 90 and drawn at 17, 37 and 143.
The solver now builds the same 48 points in the same page frame
(`_Fig._page_pts`), so it sees exactly what the checker will see: no guessed
margin, and no figure refused for a stop that is not there. A circle grazing a
side is a stop for the checker but **not** an eye stop — a graze is no division
a reader reads — so it costs the tick a small slide, never a bracket.

`_TICK_CLEAR`, `_TICK_WIN` and `_TICK_EYE` were **measured on the gallery**,
not guessed, and `_ON_LINE` (0.8) is svgcheck's own tolerance, copied.

Chevrons go through `_arrow_t`, not `_tick_plan`: a parallel mark claims a
*direction*, which every piece of a segment shares, so a chevron read as naming
a piece says nothing false. It dodges what stands on the segment and is never
refused.

`_Fig` also gained `parallel(a, b, n, t=None)` — chevrons, through the same
solver. It had no way to draw the mark that says "these sides are parallel", so
every builder that needed one left the claim unmarked.

`marks=False` still works. It is a choice now, not a repair.

### 3. `shapekit.py`

rectkit's pattern for every shape. Base shapes built **from their data** and
verified against it:

    shape("rectangle",     w=, h=)            # delegates to rectkit.rect_base
    shape("square",        a=)
    shape("parallelogram", a=, b=, angle=)
    shape("rhombus",       d1=, d2=)          or (a=, angle=)
    shape("trapezoid",     variant="iso"|"right"|"scalene", a=, b=, h=[, dx=])
    shape("kite",          a=, b=, q=)
    shape("triangle",      variant="sss"|"sas"|"asa"|"right"|"iso"|"equilateral", ...)
    shape("polygon",       n=, a=)            or (n=, R=)
    shape("circle",        r=)

It returns `(g, d)` — the open `_Fig` and a dict of vertex handles by name — so
add-ons compose, and `finish(g, fam)` renders. Add-ons take **handles**, never
"the shape", so a face of a solid can reuse them in v6.4: `diagonals` (+ the
intersection O), `midpoint`, `point_at`, `perp_foot`, `altitude`, `median`,
`bisector`, `parallel_through`, `extend`, `incircle`, `circumcircle`,
`angle_arc`, `equal_ticks`, `parallel_marks`, `right_angle`, `side_label`.

`fam=` is required (G76 keys on it). `rotate=` is on every call. Every computed
point is worked out in the pre-rotation frame, so the figure turns as one rigid
body. Data that cannot be the shape it claims is refused with a message naming
data that would work — "a=b=5 makes four equal sides — that is a rhombus: call
`shape('rhombus', a=5, angle=...)`", "the two shorter sides must add to MORE
than the longest (3 + 4 = 7, which is not more than 9): try 3, 4, 6.3". So are
add-ons that are not defined: a kite has no circumcircle, a triangle has no
diagonals, an altitude whose foot falls outside its side.

`euclid.py`'s builders and `rectkit.py` are untouched: `euclid.quad("rectangle")`
still draws its fixed 2.3×1.35 box, and `selfcheck_rectkit` proves it.

### 4. Tests — `selfcheck_v63.py` (the file now runs 476 checks; it was 238 when this section was written, and v6.4 corrected four fixtures)

Every rule with a passing **and** a failing case, and everything measured from
the **finished SVG** by a reader that never looks at the numbers that built the
figure: the outline is re-derived from the emitted `<polygon>`, side proportions
and interior angles from it, dots from `<circle>`, in/circumcircles from their
radii. Every claim is checked at rotate 0 **and** 37, and the two must print the
same figure. The failing cases are real: the reader must not read a 15×6
rectangle as a 15×10 one, nor 62° as 90°; one tick count on a 15-side and a
6-side is refused; a right-angle mark on a 44° vertex is refused by figkit
itself; "50°" printed on a 36.87° wedge is caught by the SVG reader; a circle
40% too big is not read as touching the sides.

**Fixtures corrected.** `selfcheck_rectkit`'s block that asserted the
tick-vs-point defect *stays* refused, and that `marks=False` is the cure, was
made false by the fix. It now checks the opposite (the ticks survive, at 0 and
37). In r1 it changed once more: nine named points on a ticked side are no
longer refused either — they take the bracket — and the failing case is now the
tick **nailed** to the middle of that side (`t=0.5`), which is where the defect
lives and is still refused. No rule was weakened; svgcheck is untouched.

### 5. Round 1 — what the independent verifier found (299 checks)

Nine findings, all fixed, each with a passing and a failing case in
`selfcheck_v63.py` §9:

* **`d["A"]` was the angle, not the vertex.** `_pack` merged the geometry's own
  values last, so `shape("triangle", variant="asa", A=50, c=8, B=60)` overwrote
  the handles `d["A"]`/`d["B"]` with 50.0/60.0 and every add-on died with a
  `TypeError` from inside euclid. Handles win now; the values stay under
  `d["data"]`, and `d["sides"]` is the list of handle pairs on every shape (the
  triangle's lengths moved to `d["side_lengths"]`).
* **A regular polygon with an inscribed circle** was refused at rotate 0 and
  90 — see §2. It renders at every rotation, with its ticks.
* **The slid tick still read as the inner piece** — see §2. The span bracket.
* **Three "fixes" no test could see regress** (the polygon's letters starting
  bottom-left, the scalene trapezoid's default `dx`, the altitude's
  foot-outside-the-side refusal): a mutant of `shapekit.py` passed all 238
  checks. Each now has its failing case.
* **The scalene refusal suggested a `dx` that was not between the values it
  named**, and for a=12, b=4 suggested one whose legs print 1.5% apart — the
  isosceles figure it had just refused. The rule is written on the FIGURE now
  (legs at least 5% apart, base angles at least 3° off 90°) and the suggestion
  is found by search, so it always renders. Bases closer than 15% of the longer
  one are refused too: they print as a parallelogram.
* **`perp_foot` had no degenerate guard** and dropped a named point exactly on
  an existing vertex (whether it shipped depended on the rotation). It refuses,
  naming the point that is already there.
* **Two letters on one dot**: on a regular polygon the incircle and the
  circumcircle share a centre, and each drew its own dot and letter. One dot
  now; a second *letter* on it is refused. And (found by looking at the
  gallery) a centre labelled with a letter a vertex already uses — a decagon
  runs A..J, so `label="I"` printed two I's — is refused, naming the free
  letters.
* **`midpoint()` was always refused** on a rectangle, a parallelogram or a kite:
  it asked for two ticks, the count those shapes already use for their second
  pair of sides. It picks a count that is free (and `n=` sets it by hand).

## v6.3 — S2: `describe.py` and the generator

### 1. What this is for

`shapekit` draws a figure from *numbers*. A question is written in *sentences*.
S2 is the layer between them, and the part that changes the economics of making
a sheet: a question's own words in, several correct figures out.

    from describe import build
    svg = build("ריבוע ABCD; G על AD; ∠GBA = 37°")

    from generate import Generator
    G = Generator("מקבילית ABCD; E על BC; AE חוצה זווית A; AB = 9; BC = 15", seed=1)
    fig  = G.figure()               # one configuration
    more = G.alternatives(3)        # other configurations of the SAME data
    print(G.report())               # what the data fixes, and what it leaves open
    bad  = G.violate("AB = 9")      # one datum broken, for "find the mistake"

### 2. `describe.py` — a grammar, never a guess

The full grammar is in the module docstring and in `describe.understood()`:
fourteen shape words, twenty data patterns (`AB = 15`, `∠ABC = 37°`, `G על AD`,
`M אמצע AB`, `AG : GD = 2 : 3`, `AB ∥ CD`, `BD ⊥ AB`, `אלכסונים`,
`M מפגש האלכסונים`, `AE חוצה זווית A`, `CM תיכון אל AB`, `CH גובה אל AB`,
`H היטל C על AB`, `מעגל חסום` / `חוסם`, `גובה = 6`) and one modifier,
`(לא בשרטוט)`, for a datum that constrains without printing.

One sentence is one datum; sentences are separated by `;` or newlines. A
sentence that matches nothing is **refused, and the refusal prints the whole
list of what is understood, with an example of each**. Nothing is approximated
and nothing is skipped — a figure that quietly reinterprets a sentence is worse
than no figure, because it ships as a claim about the question's data.

Hebrew goes in the description and in the refusals; the SVG that comes out
carries Latin letters, digits, U+2212 and ° only (doctrine 7). The parse runs
in two passes over the sentences, so their order never matters
(`AE חוצה זווית A` may stand before `E על BC`).

### 3. The generator — bind, sample, solve, draw, **read back**

1. **bind** — a length or an angle that IS a parameter of the base shape goes
   straight into it (`AB = 15` on a rectangle is `w`).
2. **sample** — a parameter no datum fixes is drawn from a readable band by the
   seeded RNG, and recorded as free.
3. **solve** — everything else becomes an equation. Each unknown (a free
   parameter, or the position `t` of a point on a segment) is given an equation
   that it actually *moves* — a finite-difference probe, because handing
   `AB = 4` to an unknown it cannot change once "solved" a right triangle with a
   leg of 0.8. A ratio, a length along a segment and a wedge angle are closed
   forms and go through **sympy**; anything else goes through a bounded scan
   plus bisection. Unknowns that couple (a parallelogram given both angles its
   diagonal makes) get a damped Newton over finite differences, clamped to each
   unknown's band. Everything runs under one deadline.
4. **draw** — `shapekit` and nothing else, in the one order that works: the base
   shape, the points it builds, the segments that join them, the marks last.
5. **read back** — the *finished SVG* is parsed again (the polygon and the dots,
   not this module's bookkeeping) and every datum is re-measured on what was
   actually drawn. A drawing that does not match its description is refused even
   when every step above believed it had succeeded. Lengths have no absolute
   scale in a drawing, so the first length datum sets the scale and the rest are
   checked against it.

`(description, seed)` fixes everything — the RNG is seeded from a SHA-256 of the
cleaned text and the seed, never Python's salted `hash` — and a description that
leaves something free gets up to eight attempts from that one RNG, in one order.
`cap=` (3 s) bounds a figure end to end; hitting it is a refusal that names what
to give the solver instead.

### 4. What the generator refuses, and why the refusal names a band

* a point that lands within 0.10 of a vertex ("G comes out at 0.03 along AD"),
  **and the band of values that would land it inside**: the residual is
  evaluated at both ends of the readable range, so `∠GBA = 89°` on a square is
  refused with "the values you can draw here: 0 to 45";
* two named points closer than 0.20 figure units, a vertex angle under 15°, a
  wedge under 12° asked to carry an arc and a number;
* a description that contradicts itself (`∠A = 60°; ∠B = 60°; ∠C = 100°`);
* **an accident**: a configuration nothing asked for that a reader would read as
  a datum — two sides within 5% on a triangle nobody called isosceles, a corner
  within 4° of 90 nobody called right. The author's own sheets say it at the top
  of every page: *"אין להסיק מהם נתונים שלא נכתבו או סומנו"*. When the
  configuration was free the seeded retry simply draws another one; when the
  DATA makes the figure look that way, the refusal says so, because then it is
  the question that misleads.

### 5. `alternatives(n)` and the under-specified question

`under_determined` is **measured, not bookkept**: it is true when another
drawing satisfies the same sentences, compared on a scale-free key (every vertex
angle, every side ratio, every solved `t`). So a square whose side no datum
gives is *determined* — its side only sets the scale — while
`מקבילית ABCD; M מפגש האלכסונים` is not, and `report()` says so in Hebrew and
`alternatives(3)` shows three genuinely different parallelograms. A determined
description returns **one** figure from `alternatives`, which is the honest
answer and not a failure.

### 6. `violate(datum)` — a wrong drawing that can only stand in the right place

`violate` solves every *other* datum exactly, breaks one, and prints the
original number beside the wrong drawing. Three engine changes make that
possible without weakening anything:

* **`figkit.Figure.render(critique=...)`** and `euclid._Fig.critique`: the
  declaration reaches the sweep, exactly as `numberline` has always done it.
* **`svgcheck.problems`** reads a tag that NAMES what is wrong
  (`<!--critique:find_error:marks-->`). The mark-vs-geometry messages are then
  the item, not a defect — **and a figure that declares an error and has none is
  refused**, because a correct drawing beside a find-the-error item gives the
  answer away (the giveaway rule, L7). The rule is turned round, not turned off;
  an undeclared figure is checked exactly as before. `numberline`'s own
  `critique:find_error` tag names nothing and keeps its old meaning.
* `:seen` — figkit's mark check reads the builder's own segments and catches a
  false pair of ticks on two halves of ONE side, which the SVG-level sweep
  resolves to the whole side. When figkit has already caught the declared error
  it says so in the tag, so the two engines do not each demand their own copy.

The figure comes back tagged, so `numberline.critique_guard` — which reads every
figure of a question, whatever its `fam` — refuses it beside an ordinary item
and passes it beside `asks=['find_error']`. A datum the drawing does not SHOW
(`G על AD`) cannot be violated, and the refusal lists the kinds that can; a
description that pins everything cannot have one datum broken alone, and the
refusal names the data that can carry the mistake instead.

### 7. Two engine defects S2 had to fix to be able to check itself

* **An angle number was never measured.** `svgcheck._arcs` measures a wedge from
  the strokes the arc stands on. `∠GBA` on a square names the segment BG, which
  nothing drew — so the arc leaned on nothing, `_arcs` returned nothing, and a
  figure printing **50° over a 37° wedge rendered clean**. The generator now
  DRAWS a ray an angle datum names and the figure does not already contain, and
  the check bites: `selfcheck_v63` measures ∠GBA off the finished SVG at rotate
  0 and 37.
* **One stroke count is one claim.** On the page the number of arc strokes means
  "equal to the other angles marked the same way" (`svgcheck.arc_equality`), so
  30° and 45° in one figure may not both be drawn with one stroke. Each distinct
  value now gets its own count, and a figure wanting more than three of them is
  refused, naming the fix.

### 8. Tests

`selfcheck_v63.py` — **452 checks** (381 before r1, 299 before S2), every rule with a case that
must pass and a case that must fail, everything measured from the finished SVG:
the grammar and seven refusals that each print the full list of what is
understood; determinism from a seed; the time cap; a degenerate configuration
refused; a figure that contradicts its description refused; an under-determined
description reported; a violated constraint tagged and caught by the giveaway
guard; the declared-error rule in both directions; and the five real questions
from the author's own sheets (t21 4, 5, 6, 9 and h42 1) at rotate 0 and 37.

### 9. S2 r1 — the verifier's eight findings, and what each one changed

An independent verifier read S2 and found eight defects. All eight are fixed;
every fix ships with a check that FAILS without it (`selfcheck_v63.py` §11).

* **One claim, one mark.** A datum that restated a mark the shape already
  carries (`ריבוע ABCD; AB = CD`, `טרפז ABCD; AB ∥ CD`) was drawn a SECOND time
  with a count nobody had used yet, so one claim stood twice in two counts — on
  a square all four sides measure the same and the drawing said AB = CD is one
  length and AD = BC another; on a trapezoid the house chevrons and the datum's
  met on DC pointing at each other. `generate._claim_mark` now asks what the
  figure already says: the same count on both segments means the claim is
  already made and nothing is added; a count on one of them is the group the
  other joins; only a pair nobody has marked opens a new count.
* **A narrow angle is called out, never dropped.** A wedge under 12° used to be
  refused with "…or give up marking this angle" — and taking that escape
  (`(לא בשרטוט)`) deleted the arc AND the number. That is the escape doctrine 4
  forbids. `shapekit.angle_arc(lead=)` prints the number just OUTSIDE a narrow
  wedge with a short leader line to the arc; everything down to `MIN_WEDGE` (4°,
  where two rays print as one line) is DRAWN, and the refusal below it names a
  value, or a separate enlargement, never less information. `svgcheck` learned
  to read a leader, so a wrong number on a called-out angle is still refused.
  The two-letters-too-close refusal lost its "or give up one of them" too.
* **The critique tag is bounded and counted.** `<!--critique:find_error:marks-->`
  used to drop EVERY mark message, and `:seen` waived the giveaway rule
  outright — so the tag pasted onto a correct figure silenced right-angle marks
  on non-right angles, unequal ticks, non-parallel chevrons and
  angle-text-vs-arc. The declaration now says how many wrong marks the item
  carries (`:n=K`, default 1, at most 3), figkit reports how many its own check
  already found (`:seen=J`, a NUMBER — a bare `:seen` counts as none), at most
  `K − J` messages are taken as the item and everything beyond that is reported
  as the second, unintended error it is. Counts that disagree are refused.
* **The bisector builds its own point.** `AE חוצה זווית A` was advertised beside
  `CM תיכון אל AB`, which brings its own point, but did not — and the refusal's
  suggested fix named a side through the vertex, which only refuses again. It
  builds E now, where the internal bisector leaves the shape (`_bisector_side`);
  an E another sentence pins still wins; and `E על AC` beside the bisector of A
  is refused statically, naming `E על BC`.
* **A refusal's band is in the datum's own unit.** The band was built from the
  solver's NORMALISED residual and then multiplied by the DEGREE tolerance
  whatever the datum was, so a rhombus refusal offered "−58.2 to −58.2" where
  the only drawable value is 5. `_quantity` measures the datum's own quantity —
  degrees, a length, a ratio, the angle between two segments — and the refusal
  prints that.
* **A kite says which pair is equal.** `דלתון ABCD; AB = BC` fell through to
  shapekit and came back in English about a rhombus. `_static_checks` reads the
  declared shape's own house-mark groups off a probe and refuses the
  contradiction in Hebrew, naming the equalities the shape DOES carry
  (AB = AD; CB = CD) — and the grammar now documents them.
* **The read-back says what it read.** `_read_back` could pass by doing nothing:
  a circle returned at once, a failed affine fit left the built points out, and
  every datum naming one was skipped in silence. It returns the number of data
  it re-measured (`Figure.measured`), refuses a fit that will not close and a
  datum whose point is not in the drawing as the engine faults they are, and
  checks a circle figure instead of returning blind.
* **Checks that could not fail.** Removing `_read_back`, `_accidents`, the
  MIN_GAP rule or the seeded RNG left the suite green. §11 now covers each with
  a case that dies without it: two separate generators with one seed on an
  under-determined description give the same SVG; six seeds of a free triangle
  are measured on the finished SVG for accidental isosceles and accidental
  right angles; two letters 0.02 units apart are refused; the read-back is
  called on a figure that is not its description's.

Two engine holes found on the way, both fixed in `svgcheck`: a CLOSED shape's
edge was read as a coordinate axis — so a triangle's ticked base became an axis
with a tick lattice, the equal-lengths sweep (E5) was VACUOUS on every
axis-aligned polygon, and a right trapezoid's side label was refused as a tick
number "2.90 squares from the axes' crossing" on a figure with no axes; and one
segment carrying two tick groups of different counts is now refused by name
("a count is a length"), which is what let the duplicate mark above pass
`problems() == []`.

## v6.3 — the close-out round: two defects found by building the catalogue

Nothing here came from a test that was already written. Both came from
BUILDING something real out of the finished skill — a nine-page catalogue with
one page per shape family, every base shape and every add-on drawn at three
orientations, plus a page of figures built from Hebrew sentences. The suite was
green before and after; these are the two things only a real document found.

### 1. A circle had an orientation

`shape("circle", r=7, rotate=37, width=130)` was **refused** — *"label 'O'
reaches the reader at 6.9pt, below the 7.0pt floor"* — while the same call at
`rotate=0`, `90`, `180` and `270` drew. Worse than the refusal: at the widths
where every angle drew, the same circle printed at a **different size** for
each one (viewBox 263.9 at 0°, 355.0 at 37°, 393.6 at 143°), so two circles on
one sheet could not hold one printed look.

The cause is in the fitting, not in the circle. `_fit` scales a figure by the
bounding box of its **points**, and `shape("circle", ...)` registered exactly
three: the centre, ONE rim point at `(_SPAN/2, 0)`, and the letter's anchor.
`rotate=` swung that single rim point around the circle, so the point box — and
with it the scale, the viewBox and every printed size — depended on the angle.
The circle's own ink is rotation-invariant; the box the engine measured was not.

The fix hands `_fit` the circle's real bounding square: four corner points,
turned **back** by `rotate` so that after the figure turns they land on the
axis-aligned square every time. The letter's anchor and its preferred direction
are turned back for the same reason. The corners are points, not ink — nothing
draws them. The result: one SVG, character for character, at every rotation,
and the figure now draws at `width=110`, which it never did.

`selfcheck_v63` §12 checks this at four widths and ten angles, from the
finished SVG, and — so the rule is not the vacuous "ignore `rotate=`" — asserts
that a **rectangle** still turns, and that `r=0` and `r=-3` are still refused.

### 2. `describe` refused standard Hebrew spelling

`_clean` normalised every dash it could find — en dash, em dash, U+2212, the
two Unicode hyphens — and mapped an ASCII `-` between two Hebrew words to a
space. It did **not** know U+05BE MAQAF, the Hebrew hyphen, which is how the
grammar in this module's own docstring, the briefs and ordinary Hebrew
orthography all spell the compound shape names. So every correctly typed

    משולש שווה־שוקיים ABC       משולש שווה־צלעות ABC
    משולש ישר־זווית ABC         טרפז שווה־שוקיים ABCD
    טרפז ישר־זווית ABCD

was refused with *"המשפט הראשון חייב להכריז על הצורה"* — a refusal of correct
Hebrew, which pushes an author to mis-spell the shape in order to get a figure.
MAQAF joins the dash table. The ASCII spelling still works, a shape word
outside the grammar (`מרובע שווה־צלעות`) is still refused, and a maqaf standing
where the grammar wants `=` is still refused.

### The catalogue itself

`v63/look/shapes_showcase.pdf` — 9 families x (base shape + 3–4 add-ons) x
3 orientations, 112 figures, plus 8 figures built by `describe.build()` from
Hebrew sentences, all gates green. Building it also proved two refusals RIGHT
and left them alone: a 5-12-13 triangle declared only by its three sides is
refused because the drawing would hand the student a right angle nobody gave,
and figures wider than the text column are caught by G72 (struck glyphs), not
by eye.

## v6.4 — S1: `solidkit.py`, solids in cabinet projection

The skill had no solid at all. A sheet that needed a prism wrote its own kit:
`z47_a/level.py` carries 470 lines of package-local drawing — a projection
constant, a visibility test, a fit loop, a label-inside-a-face search, a
dimension line with barbs, an italic rule — because `figkit.Figure` draws in
two dimensions and nothing above it knew what a solid was. `solidkit.py` is
that layer, and everything that file had to do by hand now lives here.

### The projection

CABINET, fixed for the whole skill: the front plane true size, the depth axis
at 45° drawn at HALF length. `CAB_DEG` and `CAB_K` are module constants, not
parameters; only `side` ('right' or 'left') mirrors the depth direction.

    project((x, y, z)) = (x + s·K·cos45·z,  y + K·sin45·z)

These are MATHS coordinates (y up), the frame `euclid._Fig` works in. The
author's sketch had `sy = y − z·K·sin45` with the note "SVG y grows down" —
a statement about the wrong layer: in this frame it sends the depth axis DOWN
and the box is seen from below. Checked by rendering and LOOKING before
anything else was built (`v64/look/solids/probe_projection_p1.png`).

### Hidden edges are computed, never tabulated

The author's brief proposed a fixed per-shape table ("at this camera angle a
box always hides the same three edges"). True of a box on its base, false of
everything else: the same box laid on a lateral face hides three DIFFERENT
edges, and an open box hides PART of an edge — the bottom of its back-left
vertical, behind the front wall, while the top of that same edge is seen.
`Solid.hidden_edges()` recomputes per pose: face normals against the eye for
a convex solid, true occlusion (every edge cut at every crossing of every
projected face, each piece tested against the faces in front of it) for the
rest. `selfcheck_solidkit` proves they agree on every convex solid at four
poses, and that they DIFFER on an open box — which is why the general method
is there.

### Poses

A solid is placed like a real object: `pose=(rest, yaw)` — which face rests
on the ground, and how far it is turned about the vertical. `pose='base'` is
canonical; `pose=('ABED', 90)` lays a prism on a lateral face and turns the
base square to the reader (the classic "triangle in front" prism); round
solids take `pose='upright'|'lying'|'inverted'`. Every pose settles the solid
onto y = 0, and every add-on is computed in the posed frame, so the figure
turns as one rigid body.

### What it draws

`cube`, `box`, `prism` (on any shapekit base — triangle, parallelogram,
trapezoid, kite, regular polygon), `cylinder`, `cone`, `pyramid`, `open_box`,
`container` (a liquid at a level, cut by a real horizontal plane), 
`unit_cubes` (an opaque stack: no dashed stroke, the unit grid on the faces
the reader sees), `extrude` / `notch_prism` (the L, the step), and `net` — the
faces UNFOLDED, each placed by an isometry of itself, so folding back is true
by construction and what is checked is what can go wrong (a face twice, a face
missing, two faces overlapping). A cylinder's net is the rectangle and its two
circles; a cone's is the sector its slant gives (216° for r=6, l=10).

Add-ons, the same vocabulary as shapekit one dimension up: `point_at`,
`midpoint`, `face_diagonal`, `space_diagonal` (with the right triangle that
solves it), `right_mark`, `angle_mark`, `angle_to_face`, `base_altitude`,
`cross_section`, `edge_label(dim=True)`, `face_label`. Every solid also
carries its maths — `volume()`, `surface_area()`, the space diagonal, a cone's
slant, a liquid's volume — so an answer key is computed from the same numbers
the figure was drawn from. The 3D maths itself (`dist3d`, `dot`, `cross`,
`angle_between`, `volume_tetra`, `point_on3d`, `plane_normal`,
`perpendicular`, `parallel`, `angle_line_plane`) refuses its degenerate cases
instead of returning 0: a flat tetrahedron is wrong data, not volume zero.

### Two engine changes this needed

1. **`figkit.Figure.projection`** — a figure drawn in a projection declares it
   in the file (`<!--proj:cabinet45:right-->`), before the sweep runs, the way
   a critique figure declares itself. `svgcheck.mark_geometry` then delegates
   the two readings whose 2D value is not the claim: a right-angle mark's own
   corner (a box's real 90° at C prints 117°, and the mark is drawn as the
   projected square) and an angle text beside an arc. Everything about size
   and spacing runs unchanged, and the 3D claims are checked instead by
   `selfcheck_solidkit`'s reader against the figure's own `<!--v3d:-->`
   vertices.
2. **A dimension may own its number past its own arrowheads** (`figkit._owns`
   and `svgcheck._is_head_of`). E24 always meant to let "its arrows" off the
   ownership contest, but the test asked for a stroke standing on the owner's
   INTERIOR — and an arrowhead's tip is exactly at its end. So a short
   dimension line (a liquid level 9 deep in a 40-deep tank) could not be
   nearer its own number than its own barbs, and the figure was refused.

### The refusals this kit adds, and the route each one names

A number that contradicts its edge (`labels={'a': '12'}` on a 9-long edge);
a right-angle mark on a corner that is not 90° IN SPACE; a level outside its
container; an opaque stack asked for dashed edges; a pose naming a face the
solid has not; a figure under the tier's size floor or with a sliver edge; a
base altitude that the projection has halved — that last one names the pose
that draws it properly (`pose=('ABED', 90)`), and the named pose was checked
by rendering it. A number that cannot be placed beside its edge is not
dropped and not shrunk: it moves to a dimension line outside the drawing, and
the figure is drawn again.

### Not to scale

Turn a solid by a yaw and no edge is drawn either true or at half length, so
two numbers on one figure stand beside strokes whose ratio is not their own.
That figure tags itself `+nts` — detected from the same shrink factors the
proportion checks are made of, not declared by the caller.

### Tests

`selfcheck_solidkit.py`: 163 checks, every rule with a passing AND a failing
case, measured from the FINISHED SVG by a reader that knows only the file —
it re-projects the figure's own `<!--v3d:-->` claim, fits it to the ink by
matching (not by bounding box: a dimension line stands outside the solid and
threw a bounding-box fit), and then reads back which edges are dashed, where
the letters are, whether the numbers stand outside the silhouette, and what
fraction of a part-hidden edge is dashed. The failing halves are independent
wherever they can be: the passing SVG with a dash stripped, with a letter
dragged onto another vertex, with a number dragged inside the solid, with the
depth edges redrawn at 30°.

### The catalogue

`v64/look/solids/catalogue_p1..p5.png` — every solid at three poses, the
add-ons and the nets, looked at before this was written. Four defects it
found: `figkit.vertex_label` put B and F INSIDE the front face (a letter is
now placed outside the silhouette, or in the widest free wedge for the two
inner vertices); a cylinder's radius drawn to the front-most rim point came
out along the ellipse's own flat (it is drawn horizontal now); three numbers
crowded round a foreshortened base could not each own their side (a base
prints ONE number unless the author asks for more); and the tier heights were
too tight for a cube with an add-on, so the fit came back under the size
floor with no tier able to cure it.

### r-T1 — what an independent verifier found, and what changed

Eight faults, all in this file or in `selfcheck_solidkit.py`. The two that
reached paper:

**A container refused to hold water.** `container(8, 5, 6, level=4)` — the
brief's own "container with a liquid level" — was refused for 12 of 15
ordinary shapes, and the only kwarg that got a figure out was `names=False`,
which drops all eight vertex letters: doctrine 4's forbidden escape, and the
refusal did not name a call that renders. The cause was a colour. `WATER` was
`#cfd8dc`, whose lightest channel is 0.812, and `svgcheck.LIGHT` is 0.85 — so
the wash counted as INK, the filled region struck any label inside it, and
the hidden corner D (whose letter sits in the widest free wedge, inside the
silhouette) was struck by the water it stood in. `WATER` is now `#dcebf1`, a
wash: `svgcheck` reads it as background, exactly as it reads `SHADE`. Fifteen
of fifteen containers and nine of nine open boxes render, with every letter.
The rule has its failing half: the same figure with a dark wash is shown to
strike 'D'.

**`names()` was not idempotent.** `box()` already letters the solid when
`names=True` (the default), so the second `d.names()` — the one in this
file's own module docstring, and in the SKILL.md pattern it came from — drew
a SECOND letter at every vertex, up to 19px from the first. Nothing was
struck and nothing overlapped, so no check saw it; on paper the box read
A A B B C C. `Solid._named` makes the call idempotent, and a letter counter
reading the finished SVG now proves one letter per vertex.

**A check that could not fail.** `svgcheck` stands down on the 2D
right-angle and angle-text readings for any figure carrying `<!--proj:-->`
(a real 90° prints as 117° in cabinet), and nothing else read an
`angle_mark`. A copy of the kit mutated to print the PROJECTED angle shipped
101.8° on a corner that is exactly 90° in space, and the selfcheck still said
ALL CHECKS PASS. A figure now DECLARES every angle it asserts:

    <!--v3dang:angle:C,A,G=90°;right:C,A,G=90;linface:A,G|ABCD=45°-->

and the reader recomputes each one from the `<!--v3d:-->` points, compares it
with the text the page prints, and checks that the declared text IS on the
page. The mutant is caught, and so is a right-angle mark claimed at a corner
that is not square. `volume()` and `surface_area()` — the accessors an answer
key calls, which no check called — are checked against the closed form on all
seven solids, with the halved-surface mutant as the failing half.

**`space_diagonal(via=)` ignored the face it was given.** It scanned the
face's vertices in stored order and took the first that happened to make a
right angle, so `via='ABCD'` and `via='ABFE'` both drew A–B–G, and the
classic ז׳–ט׳ figure (AG over the BASE diagonal AC) could not be drawn at
all. `via` now takes the face's OWN diagonal from `frm` (ABCD → C, ABFE → F,
ADHE → H); a triangular face, which has no diagonal, uses its second side;
and a `via` whose face holds both ends is refused with the faces that work.

**The edge-length floor looped.** Its refusal named `tier='block'`, and
`tier='block'` refused the same data with the same sentence. The message now
works out what the edge would measure at the widest tier FROM THE UNIT THIS
RENDER GOT, names the tier only when the tier really clears the floor, and
otherwise names the smallest datum that renders — a fixed point over the
tier box, because a longer edge also makes the drawing bigger. Every route
the message names is rendered in the selfcheck.

Three smaller ones: a round net's `metrics['area']` was 0 (it is the area of
the pieces now — rectangle plus two circles, sector plus circle — and `net()`
refuses if that is not the surface area); `pose='front'` / `pose=('top', 0)`
were refused although `_apply_pose`'s docstring promised them (a pose word is
resolved from the GEOMETRY now — the face whose outward normal points that
way — so it works on a prism as well as on a box, and the refusal lists both
the letters and the words); and `cylinder(liquid=)` / `cone(liquid=)` drew a
water line but recorded no `liquid_level` or `liquid_volume`, while
`Solid.liquid()` on a box recorded both (a cone's is the frustum's, from the
same radius the drawing uses).

## v6.4 — the nine v6.3 leftovers (shapekit, euclid, svgcheck, generate)

The v6.3 round closed with nine open defects, all with printed evidence. Each
one is fixed here, each fix ships with a test in `selfcheck_v64_t2.py` (60
checks: a passing AND a failing case per rule, everything measured from the
finished SVG), and `v64/T2/prove.py` replays the nine repros against any tree
— 9 of 9 on the v6.3 copy, 0 of 9 here.

**An angle text without a degree sign was never checked.** `angle_arc(text=
"50")` on a 36.87° wedge shipped, because svgcheck's angle-text rule only
ever matched the form WITH the sign — the form SKILL.md claimed was caught.
A bare number is read as degrees now, through the two associations that
cannot be confused with a length label (the number stands strictly inside
exactly one wedge, or a leader ties it to one arc); a number an axis owns
stays that axis's, and ONE DIGIT stays a NAME, because `euclid.parallels(58,
mark=(1, 5))` numbers the eight angles at a transversal 1..8 and no school
figure draws a wedge of 9°. A non-numeric text (`x`, `2x`) is still the
unknown the question asks for.

**The span bracket read as a second edge.** It was a bare line of the
figure's own weight, parallel to the side, with no ends — on a rectangle a
reader saw a duplicate AB below the figure. It has turned ends now, leaned
`SPAN_SERIF_LEAN` (32°) off the perpendicular so the serif's line misses the
vertex: a square end lies on the next side's line on a rectangle, and
`lost_ink` reads the two pieces as one cut stroke, which is why v6.3 had no
ends at all.

**`bisector()` trapped the author three ways.** Its default letter was `D`,
a vertex on every quadrilateral — the documented one-liner was refused on 11
of the 16 shapes; it now takes the first FREE letter (`D` still, on a
triangle), as the tick solver takes a free count, and an explicit letter is
still refused when it is taken. On a quadrilateral the two rays of a vertex
end at its NEIGHBOURS, so `AB` is an undrawn diagonal and v6.3 dropped a
named dot in mid-air: the bisector is carried on to the outline it really
meets (the landing `generate._bisector_side` computes), and when it lands on
a vertex the refusal names another vertex **found by search** whose bisector
renders, and `name=None` — which really draws the rhombus's diagonal. Its
arcs were refused at rotate 0 and 90 and drawn at 17, 37, 143: `svgcheck.
_arcs` fitted a short arc's centre through three rounded points, came out
0.74 units small on a ring of 17, and `arc_crossings` then stopped
recognising the arc's own chords as its own — the arc was refused for
crossing ITSELF. The fit is least squares over every point now, and where
the rays give the true vertex the radius is measured from it.

**`parallel_through()` hard-coded one chevron**, the count every trapezoid's
house marks already use, so a parallel drawn in any other direction was
refused at every rotation and the only one-call way out deleted the claim. A
chevron count is a DIRECTION exactly as a tick count is a length: a new
direction takes a free count, a direction the figure already marks keeps its
own (and the reference is not marked twice), and an explicit `n=` is honoured
as written.

**`perp_foot()`'s refusal named an escape that was refused again.** On a
rectangle or a square two of the three other sides are perpendicular to AB,
so every point of them projects onto the same vertex. The message now names a
point found BY TRYING the shape's own sides, and the selfcheck runs the
sentence it prints and renders it (doctrine 4).

**A polygon with an incircle and a midpoint was refused at 16 of 26
rotations.** Two things: a piece's equality mark and the whole side's mark
both ran out of room on the side (an incircle stands on the middle of every
side), both went on a span bracket, and a piece's bracket is parallel to its
side at the same offset as the side's — so the two lay on each other and
svgcheck read one carrier carrying both groups. Brackets that would land on
one line are stacked now, the shortest innermost (`_SPAN_STEP`). And the tick
solver judged a group only against the pieces INSIDE the segment it marks,
never against the longer segment it lies on; it solves in the CARRIER's frame
now (`_tick_extent`, `_tick_stops(win=)`), which is the frame svgcheck reads.
A circle drawn together with a polygon is refused when the two come within
`shapekit.RING_GAP_PT` (2.5pt) of each other **at their widest** — the
vertex gap, measured in PRINTED points once the figure has a printed size
(`euclid._Fig.defer`, run by `render()`). The refusal names the width at
which this very figure clears the floor, so nothing leaves the drawing.

**A drawing may give no datum the question did not.** The accident sweep ran
inside `generate` and only for triangles, so `shape('triangle', variant=
'sss', a=13, b=12, c=5)` drew a 90.0° corner and marked nothing (the
description layer refused the same figure), and a parallelogram whose
adjacent sides landed within 5% was drawn as a visual rhombus while its own
ticks claimed two different lengths on two sides a reader measures as equal —
34 figures in a sweep of ~360, with `svgcheck.problems()` empty on every one.
One reader's rule now lives in `shapekit.accidents()` with
`shapekit.declared()` (what a shape's DEFINITION gives) beside it, and both
layers ask it: `shape()` refuses in English, `generate` in Hebrew, and
`shape(given={"equal": ..., "right": ...})` carries what the question says in
words but the kwargs cannot (describe builds every triangle through `sss`).
A pair where one side is marked and the other carries no claim is not an
accident, so the everyday 12/6/5 isosceles trapezoid still builds — that
exemption is deliberate and one-sided, and it has exactly one exception:
when EVERY side comes out the same length the figure reads as a shape with a
name (equilateral, rhombus), so an `iso` triangle whose base lands within 5%
of its legs is refused all the same. The shapes that are all-equal by
definition declare the whole group and never reach that test.

**Three tuning constants had no failing case.** `_TICK_CLEAR`, `_TICK_WIN`
and `_SPAN_OUT` could be zeroed (or cut to 1.5) with the whole suite green.
Each is now proved by relaxing it inside the test and measuring the drawing:
a tick lands ON the midpoint dot it exists to dodge (0.00pt against 8.3pt), a
tick's claim ties with the stretch the incircle grazes (margin 0.03 against
0.11), and the bracket lies on the side it names (1.1pt against 8.3pt). The
constants this round adds — `SPAN_SERIF`, `_SPAN_STEP`, `SPAN_SERIF_LEAN`,
`SPAN_SERIF_MAX`, `SPAN_SERIF_INSET` and `RING_GAP_PT` — carry the same kind
of failing case.

Fixtures corrected, with the reason written beside them: `selfcheck_v63.py`'s
`sss 3-4-5` (it draws an unmarked right angle — the declared `variant='right'`
case beside it is the same triangle), `sas b=6 A=50 c=8` (the third side
closes 3% from `b`), `asa 50/65` (two 65° angles), and, for one round only, the
two decagon+incircle fixtures. Nothing was weakened: every rule they proved
is still proved, on data that a reader can read.

### r1 — what a verifier sent back

Six findings against the round above, all fixed, with
`selfcheck_v64_t2_r1.py` (29 checks) beside them — its reader is a plain XML
walk with its own path parser and transform stack, importing nothing from
the skill.

- **The ring refusal was a ratio, and it was wrong.** It refused every
  regular polygon of 7 sides and up with its circle, at every size, and the
  cheapest escape it named deleted the polygon. The octagon it refused
  prints 4.6pt of clear vertex gap at the default width and 18.3pt at 700 —
  readable both times. Doctrine 6 says printed sizes are what matter, and
  the codebase had learnt this once already (`svgcheck.coincident_arcs_in`
  swapped a figure-unit ring test for `ARC_SAME_R_PT` in v6.2). The rule is
  `RING_GAP_PT` now, the escape is "draw it bigger, at this width", and the
  two decagon fixtures in `selfcheck_v63.py` are back where they were.
- **`SPAN_SERIF_LEAN` and `SPAN_SERIF_MAX` had no failing case** — both
  could be neutralised with the whole suite green while drawing exactly what
  their comments forbid. Both are measured now: at lean 0 a serif lies ON
  the line of the rectangle's side (0.000 units off it, against 3.20
  shipped), and at cap 100 the stacked bracket's serif grows 7.0 → 11.0 and
  its free end lands 0.33 units from the bracket inside it. Checking this
  turned up something worth writing down: `svgcheck.lost_ink` does **not**
  refuse the square-ended bracket (`problems()` and `lost_ink()` both come
  back empty on it), though the first note beside `span_ticks` said it did.
  The lean is a drawing decision, and the test measures the collinearity
  itself instead of leaning on a rule that never fires.
- **`generate` retyped `ACC_LEN` / `ACC_DEG` as literals.** One reader's
  rule means one pair of numbers: they are `shapekit`'s, by reference, and
  the call site asks `shapekit` at call time, so tuning one layer moves both.
- **The serif's `size` floor could cross the side it names.** At an offset
  under ~5 units the floor overrode the proportional length and the serif
  poked through the very segment the bracket marks. It is clamped by
  `SPAN_SERIF_INSET` (0.8 of the offset), which changes nothing at the
  offsets the tree really uses (`euclid._SPAN_OUT` is 11).
- **`selfcheck_v64_t2.py` called its reader independent** while three of its
  helpers went through `svgcheck` — the module under test, for D1. The
  header now says exactly which helpers share that plumbing, and D1 is
  re-measured in `selfcheck_v64_t2_r1.py` by a reader that shares none: the
  wedge is 36.87°, so the bare `50` really is a lie.
- **The half-declared exemption had a hole**, closed as described above.


## v6.4 — the close-out: what a real port to `solidkit` asked the engine for

The round ends the way the ones before it did: by REBUILDING a shipped sheet
on the new engine and looking at the result. ז׳/47 (`מנסרה משולשת – מבנה
ונפח`) was the sheet that had to write its own 3-D drawing because the skill
had none — 470 lines of package-local PRISMKIT: a projection constant, a
face-normal visibility test, a fit loop, a label-inside-a-face search, a
dimension with barbs. Its prism figures were rebuilt on `solidkit`, with the
data, the questions and the key untouched, and the port asked for eleven
things the kit did not have. All of them are now in it, each with a passing
and a failing case in `selfcheck_v64_close.py`.

**Two solids on ONE scene.** `box(...)`, `prism(...)`, `cube(...)` and
`extrude(...)` take `scene=` and `at=`. The second solid is drawn on the
scene the first returned, so the fit sees both and they share one scale —
which is the whole point of "the prism is half the box" and "which of these
two holds more". `at=` moves a solid in its own posed frame; every builder
centres its solid on the origin, so a box and a prism of the same bounding
box are already on top of each other and `at=` is for putting one BESIDE the
other. Two solids may not both print A..F at different places: `names()`
refuses that and names the letters to give the second one.

**`equal_edges(edges, n=1)`** — shapekit's equality ticks, one dimension up.
The lengths are re-measured in 3D first, so marking edges equal that are not
is refused instead of drawn.

**`slices(along, n)`** — the loaf a volume question is built on. The cuts are
computed face by face. A cut is not an EDGE of the solid: it is a line drawn
ON it, so by default only the stretches on faces the reader can see are
drawn. `hidden=True` dashes the rest — and the reason that is not the default
was measured: with four slices dashed round the back, `S` inside the base
triangle has no free spot at ANY size, because every slice projects across
the front face.

**`edge_parts(edge, parts, labels=, dim=)`** — a length cut into equal pieces,
each named beside its own piece, or on dimension lines end to end below it.
Those dimensions share ONE lane: given a lane each (the rule that keeps two
unrelated dimensions apart) the two halves of a base came out at two offsets
and read as two unrelated measurements. `Scene.dim(lane=)` is the mechanism.

**`ghost(points)`** — a dashed outline inside the solid, in its own 3-D
frame: the shape it used to be before a dimension was doubled. Every point
must be on or inside the solid; one hanging outside is a second figure, not a
mark on this one, and is refused.

**`caption(text)`** — a name under the solid ("V", "3V"), for a comparison
figure. Hebrew still may not go inside an `<svg><text>`; the refusal says so.

**`base_altitude(..., name=None, draw=False, dim=True)`.** `name=None` leaves
the foot unlettered — an unasked-for letter is a datum the sheet never gave.
`draw=False` computes the height without drawing it (the sheet whose question
is "find the height" must not answer itself), and `dim=True` puts that number
on a dimension line along the altitude, pushed clear by figkit, which
measures the whole scene's ink — a second solid beside this one included.

**`edge_label(inside=<face>, t=)`.** The far side of a right prism's
hypotenuse is a lateral face full of receding and hidden edges; pushed out
past all of them the number landed on a dimension shaft as wide as the whole
drawing (measured: ז׳/47's 5א printed "15" under the solid on a 90px arrow).
`inside=` writes it in the triangle it belongs to. `t=` says where along the
edge it sits — and it used to be accepted and ignored: the renderer took the
midpoint whatever `t` said.

**`extrude(names=, labels=)`.** `names=('GHI','JKL')` CHOOSES the letters, so
a second solid can have its own; `labels=False` leaves them unprinted. They
were one switch until a port wanted named-but-unlettered solids.

**`net(only=[...])`** — a PARTIAL net: the lateral strip (the מעטפת) a
surface-area question asks for. The faces are dropped after the unfolding, so
what is left is still laid flat by the same isometry.

**A net can be NAMED.** `_Net.face_label`, `side_label` (outside, or
`inside=True` for a shared edge) and `dimension` — a net could be drawn and
measured but nothing on it could be called anything.

### What the port cost the sheet, honestly

Four drawing constants changed, and nothing else: the data, the wording, the
answer key and the coverage are byte-for-byte the sheet that shipped
(`original=303 rebuilt=303 missing=0`, all gates pass). PRISMKIT drew the
depth axis at 35°; `solidkit`'s one projection runs it at 45°, so the same
solid at the same scale is `sin45/sin35` = 1.233 taller. The sheet's height
ALLOWANCES are scaled by that ratio in one place instead of at thirty call
sites, two fixed scales grew (a five-prism row at one scale, three prisms at
one scale) so the smallest of each clears the 60px drawing floor, and one
comparison figure's gap went from 4 units to 2 — because solidkit asks a
number to be nearer its own edge than any other by 1.5 and PRISMKIT's
hand-placed `h` did not. The sheet is 13 pages instead of 11, for the same
reason the figures are taller.

Three defects were found by LOOKING at the built PDF, not by any check: the
net's rectangles took their labels in letter order, so the middle rectangle —
the base, the one the two triangles fold onto — printed a leg's length; the
box in "the prism is half the box" was shifted by half its own size and stood
BESIDE the prism; and the hypotenuse's number fell back to that 90px arrow.

### Still not here

`describe.py` speaks only of PLANE shapes. A solid cannot yet be written as a
Hebrew sentence, and the showcase therefore has no such page. (v6.6: it can
now -- see "v6.6 S" at the end.) Analytic
geometry beyond plane curves, complex numbers, charts and the question-variety
structure bank are all still outside this version.


## v6.5 — stable element ids and the objects export (spec items 1 and 2)

### What was wrong

A figure could be drawn, measured and gated, and still not be able to say
what was in it. `plane()` came out with zero `id=` in the whole file, and so
did every other builder. Anything downstream that wanted to point at a
drawing — "highlight the point M", "circle the side AB" — had to look at the
PICTURE again and guess which glyph was which. The author's deliverable spec
(`sheet.json`) asks for the opposite: one verified data source per level, and
a figure that names its own parts.

### What changed

**`export.py` — one module every builder feeds.** Not a function per builder:
the machinery is in one place and the primitives call it, so a new builder
draws through `figkit.Figure` and gets its ids without asking. `numberline`
writes its own SVG and feeds the same module from its canvas.

**The id rule** (in full in `export.py`'s docstring):

1. Name-derived wherever a name exists: `pt-A`, `seg-AB` (the two ends in the
   order they SORT, so one side has one id however it was drawn), `cir-O`,
   `arc-B`, `ra-A`, `tick-AB`, `dim-AB`, `lbl-A` / `lbl-AB`, `poly-ABCD`,
   and on a number line the value itself — `tick-m3`, `lbl-0`, `pt-2`.
2. Never index-derived. An UNNAMED object is keyed by its own geometry:
   `seg-7f3a21`, the first 6 hex of a sha1 over its kind, role and data
   coordinates at 1e-3. Two builds of one figure hash the same; adding an
   unrelated object moves nobody else's coordinates, so it moves nobody
   else's id.
3. A collision is broken by `-2`, `-3` in the order the colliding objects'
   own geometry keys sort — not insertion order, which an unrelated addition
   changes.

**Names come from the drawing.** `Objects.name_point` is called where a
vertex is drawn (`euclid._Fig`'s `name` op, `solidkit`'s vertex letters), and
`Figure.render` harvests the figure's own single-letter labels. Nothing
guesses.

**Where the id sits.** On the element itself when one element IS the object
(a `<line>`, a `<circle>`, a dot, a `<polygon>`, a `<text>`); otherwise — a
polygon EDGE, a named point with no ink of its own, a stroke cut into pieces
behind a number, a multi-element mark — on an anchor in a trailing
`<g class="ids">` layer that carries `data-xy` and no ink. (A phantom
`<line stroke="none">` was the obvious anchor and is wrong: svgcheck reads it
as a grey line, and a real one would be lost ink.)

**The objects export.** `Figure.ex` (also `_Fig.ex`, `solidkit`'s builder,
`NL.objects`) lists what the figure drew: kind, role, name, `xy` in the
builder's DATA frame, `svg_xy` in the finished file, and the view —
`width_px`, `height_px`, `unit_px`, `viewbox`, `rotate`. The view states the
numbers the FILE states, so `unit_px` is the scale a renderer really applies
(file width / file viewBox width) and `svg_xy * unit_px` is the printed
position to the pixel.

**The data frame.** `euclid._Fig` hands `export` the inverse of its own
layout (rotate about the handles' centroid, flip, fit), so `xy` is the frame
the QUESTION talks about — and an unnamed object's id no longer moves when
the same figure is drawn at another rotation (v6.3 requires ten rotations to
be one drawing, character for character).

**The refusal.** `Figure.render` and `NL.render` end with
`export.verify(svg, ex)`: every exported id must be IN the finished string,
at the position the export claims, within a pixel. A figure that cannot say
truthfully what it drew does not ship.

### The API

```python
svg = fig.render(fam="...")          # ids are in the file
ex  = fig.ex                         # or g.ex / solid.ex / NL.objects
ex.as_dict()["objects"]["segments"]  # [{id: "seg-AB", xy: [...], svg_xy: [...]}]
ex.as_dict()["view"]["unit_px"]      # viewBox units -> printed px
export.read_ids(svg)                 # {id: [(x, y), ...]}, from the file alone
```

### Tests

`selfcheck_v65.py`, house style, a passing AND a failing case per rule, read
from the finished SVG by a reader that imports nothing from the skill: ids
stable across two builds (and across rotations); ids unchanged when an
unrelated point is added; every `svg_xy` matching a measured position; a
doctored file refused (an id moved 3 px, an id deleted) and a tenth of a
pixel not refused; `unit_px` converting at two widths and two rotations, with
the other width's `unit_px` shown NOT to convert, so the check is not vacuous.

`selfcheck_v65_x1.py` (21) reads the same files as XML instead of by regex,
corroborates every anchor against the ink, fits one affine map through both
frames and re-reads ids in a fresh process. `selfcheck_v65_x2.py` (46) is
round 2 below.

### v6.5 r1 — the export is about the INK (what round 1 still got wrong)

An independent verifier broke round 1 in nine places. All nine are fixed;
each has a passing and a failing case in `selfcheck_v65_x2.py`, and the
pre-fix copy of the skill fails 23 of its 46 checks.

**A dimension is the line the reader sees.** `dimension()` exported the
segment it MEASURES, so "highlight the dimension" landed `offset` units away
on blank paper, while the drawn dimension line carried no id at all. The
object is now the drawn line (it takes that `<line>`'s id, `dim-AB`), and the
measured segment is kept: `measures_xy` / `measures_svg_xy`.

**An anchored id is corroborated by ink, not by itself.** The `<g class="ids">`
layer is written FROM the export one line before `verify()` read it, so no
anchored id could ever fail — 12 of 19 ids in a quad. `export.verify` now
reads the file with that layer REMOVED and asks the drawing: every anchored
object must lie inside the viewBox and on real ink (an equality tick or a
parallel arrow, whose strokes the tick solver may slide along the segment, is
corroborated by ink anywhere ALONG its segment). A figure that registers
geometry it never draws is refused — which is what round 1 claimed and did
not do.

**Every corner of a polygon.** `verify` asked only whether the export's FIRST
point was somewhere in the drawn element; a polygon drawn with corners 2..n
6 px out passed, and a polygon is the ink of almost every figure. Now the
whole outline is matched (cyclically, either way round), every claimed point
of a tick, arrow or path is checked, and a segment the export gives one end
is refused instead of skipped in silence.

**`seg-AB` never flips.** Asking for ids while drawing cached the pair in
DRAWING order, so `finish()` spelled `seg-CA` the second time and handed out
an id the file does not contain. The cache holds the sorted pair.

**One figure, one set of ids.** Rendering the same `Figure` twice
re-registered every label: the glyph got `lbl-A-2` and `lbl-A` — the id the
caller already held — became an anchor over nothing. `render` forgets the
labels it is about to re-register; two renders now give the same ids and the
same bytes.

**`xy` is the frame the QUESTION talks about.** `shapekit` normalises every
shape to one span, and round 1 exported that scaled copy: the triangle the
sheet calls 7, 6, 5 measured 2.858, 2.450, 2.042 and the scale appeared
nowhere. The figure hands the inverse over (`g.data_units`), so `xy` measures
7, 6, 5; a number line's data frame is its VALUE axis (`pt-2` is at
`xy = [2, 0]`, not at the canvas position 109.75); and `view.data_to_svg` —
six numbers, `svg = (a x + c y + e, b x + d y + f)` — places a point the
export does not list (the midpoint of AB, a ratio point along it). It is
measured from the build's own map, checked against every exported object, and
left out rather than guessed when a builder's data map is not affine.

**A kind the engine does not know is refused** where it is registered
(`export.KINDS`), instead of being given an id and shipped in the JSON.

**A collision is broken by what the objects ARE** — geometry, kind, role,
name and everything the JSON prints about them — so the `-2` cannot move
between builds. A stable sort on geometry alone fell back to insertion order,
the one thing the rule forbids.

**The refusal names the ways out that KEEP the object:** draw the geometry
where the export says it is, or let the ids layer anchor it over ink that is
really there — and says in as many words that deleting the `ex.add()` is not
a fix, because it drops the object from the sheet's JSON and the author's AI
can no longer point at it.

## v6.5 X2 — constraints, given / to_prove, and the deliverable package (spec items 3-6)

### What was missing
X1 made every figure say WHAT IT DREW (ids, both coordinate frames). It did not
say what is TRUE of the drawing, it had no place for the writer to say what a
question gives and what it asks to prove, and nothing wrote the package the
spec lays out. The one rule that needed all three -- "the drawing never marks
what the student is asked to prove" -- could not be checked at all.

### What changed
- **Constraints, from the build (`export.py`).** `Objects.constrain(type, ...)`
  with 13 types: collinear, midpoint, on_segment, parallel, perpendicular,
  equal_length, equal_angle, length, angle, ratio, tangent, concentric,
  hidden_edge. An unknown type, a missing or extra field, or a non-number
  `value` is refused where it is registered. Every constraint carries `source`
  (given / to_prove / derived / decorative) and `item`.
- **Where they come from.** figkit derives what a drawing states: a right-angle
  mark -> `perpendicular`; ticks with one count -> `equal_length`; chevrons ->
  `parallel`; a dimension whose text is a number -> `length`; a named point on
  a drawn segment -> `on_segment` (+ `midpoint` at the middle, + `collinear`).
  shapekit adds `angle` (angle_arc with a number), `length` (side_label with a
  number) and `tangent` (incircle); its add-ons buffer constraints in point
  HANDLES on `euclid._Fig` (`g.constrain`) because the drawing frame is born at
  render. solidkit exports `hidden_edge`; a projected figure refuses the types
  the cabinet does not preserve (`export.PROJECTION_UNSAFE`: length, angle,
  equal_length, equal_angle, ratio, tangent). `plane()` now hands the export
  its data frame, so a plotted A(3, 7) exports `xy [3, 7]` and `kind "plane"`.
  Marks carry `marked: true` + `mark_id`.
- **Re-measured on the finished SVG at every render** (`export.recheck`):
  positions read back from the file by id, carried to the data frame through
  `view.data_to_svg`; without a data frame, lengths are checked against the
  one scale the figure's other lengths agree on. A find-the-error figure
  (`critique`) and a FAIL fixture rendered with `check=False` keep their
  deliberate lie, flagged `violated: true`, instead of refusing.
- **The figure registry.** Every render writes `data-fig="<key>"` on its root
  `<svg>` (a hash of what it drew -- not of the rotation, so ten rotations of
  a circle stay ONE file) and records the build under it. The key survives
  plane tags, the emitter's minus and font rewrites; packaging looks figures
  up and never re-runs a builder.
- **The content schema (`deliver.py`).** A question and a sub-item may declare
  `given=[...]` / `to_prove=[...]`: a string is the wording; a dict is a
  SELECTOR over the figure's own export (`{"type": "midpoint", "point": "M",
  "of": ["A", "B"]}`) that labels it and ties it to the item. A declaration
  that matches nothing is refused, naming what the figure does export. A
  sub-item may be a dict (`label/text/space/fig/given/to_prove/answer`);
  `deliver.normalize()` hands the emitter the tuples it always took. A level
  that declares nothing builds unchanged and exports `derived`.
- **Packaging is part of `build.py`.** Every build writes
  `out/deliver/<level>/` (`DELIVER_DIR`, `PACKAGE`, `DELIVER = False` in
  content.py): `sheet.pdf`, `source/`, `sheet.json`, `figures/<id>.svg`,
  `figures/<id>.py` (the enclosing function or statement that drew it, from
  the call site the render recorded) and `build.json` (skill version, source
  hash, sha256 per file, the check results). Figure ids: `q7_head`, `q7b`
  (Hebrew item letter -> Latin), `_2` for the second SVG of a figure row.
- **Checks before a file is written (spec section 8):** every constraint
  re-measured on the level's SVG; a `to_prove` constraint that is `marked` is
  refused ("the sheet would be giving the proof away"); an object whose
  `svg_id` is not in the SVG is refused; a number printed in the PDF that no
  datum of the level states is reported (`strict_numbers=True` refuses);
  `strict_figures=True` refuses an SVG no builder recorded.

### The API
    ex.constrain("midpoint", point="M", of=["A", "B"], source="given", item="q7b")
    g.constrain("length", of=[a, b], value=12, marked=True)      # euclid._Fig, handles
    export.recheck(svg, objects, lenient=False)
    export.lookup(svg) -> FigureRecord(svg, objects, code, kind, fam, key)
    deliver.deliver(L, out_dir, pdf=, source=[...], package=, built_at=,
                    strict_numbers=False, strict_figures=False) -> report
    deliver.normalize(L); deliver.stray_numbers(L, entries, printed, pages)

### Tests
`selfcheck_v65_deliver.py` -- 40 checks in 7 sections, a pass and a fail per
rule, with its own SVG + JSON reader that re-measures every constraint of a
written package from scratch. Worked example: z08_a exported to
`v65/deliver/z08_a/a/` (45 figures, 44 planes + 1 number line), hand-checked.

### v6.5 X2 r1 — what the verifier broke, and what changed
- **The marks that IMPLY a claim count (`export.implied_by_marks`).** Ticks on
  AM and MB state "M is the midpoint of AB"; a right-angle mark at H states
  CH ⊥ AB and ∠CHB = 90; a "5" on AC plus ticks tying BC to AC state BC = 5.
  A `to_prove` any of those give away is refused, and the refusal names the
  marks (`tick-AM`, `ra-H`, `lbl-AC`). Measured in the file's pixels.
- **Strings are read (`deliver.parse_statement`).** `AM = BM` (and chains),
  `AB = 12` (a unit may follow), `AB ∥ CD`, `AB ⊥ CD`, `M אמצע AB` (with or
  without "הוכיחו ש"), `∠ABC = ∠DEF`, `∠ABC = 37°`. A string that reads as a
  constraint is treated exactly like the dict -- writing the claim as a
  string no longer hides it from the to_prove check. Wording no rule reads
  ships and is listed in `build.json` `checks.statements_not_checked`.
- **An unmarked fact can be declared.** A declaration the figure did not
  export is MEASURED on the finished SVG of the question's figures and added
  (`declared: true`) where it holds; refused if the drawing contradicts it,
  refused (naming `g.constrain` and how to draw the segment) if no figure
  draws its operands. `CM ⊥ AB` in an isosceles triangle with a median needs
  no figure code any more; `plane()` levels get the same path.
- **A declaration names ONE constraint, completely.** A dict carries its
  `type` and every field the type requires (`export.check_fields`), or a
  `text` that parses; `{"text": ...}` alone and `{"type": "length"}` used to
  select every constraint of the question. Operands compare canonically
  (MB is BM, rays unordered).
- **One fact is given OR to_prove.** The same constraint declared `given` in
  one item and `to_prove` in another is refused; declared twice with one
  source, the first item keeps it.
- **figures/<id>.py is the CALL, and it runs.** `export.entry` (plane, wide,
  euclid, trapz_kit, describe.build, figkit.axes/coord_plane/number_line)
  records the author's call into the skill as source with its values;
  `export.seq` logs a shapekit/solidkit figure's calls on `g`; number lines
  and stacks write their own (`NL._replay_lines`, `Stack._replay_src`). The
  script sets the sheet-wide state (`figkit_plus.SHEET`, numberline
  `_SHEET`), finds the skill through `WORKSHEET_SKILL_DIR` (default: the
  folder it was built with) and defines `svg`. Packaging RUNS it
  (`deliver.run_script`, registry and sheet state restored) and marks it
  `# RUNNABLE` only when it re-draws the file byte for byte; otherwise
  `# NOT RUNNABLE ON ITS OWN` with the reason. Below it, for reading: each of
  the author's frames (helpers like z08's `P()` included) with its source and
  literal values. sheet.json says `code_runnable` per figure. z08_a: 45/45
  runnable; z01_a_ported: 100/100.
- **numberline.stack is a recorded figure.** `export.compose` merges the
  rows' exports: ids prefixed `r1-`, `r2-` (in the SVG too), svg_xy moved by
  each row's offset, `view.rows[k].data_to_svg` in the file's frame. The
  readers (`read_ids`, the ink reader) apply `<g transform="translate()">`.
  Packaging refuses an id carried by two elements of one figure.
- **The stray-number check reads what is PRINTED.** Layout keys (`space`,
  `fig`, ...) are skipped and SVG/HTML markup is stripped before the level's
  strings are read; a figure contributes only its `<text>`. `build.py`
  refuses a stray by default (`STRICT_NUMBERS = False` in content.py reports
  instead). z08_a, z47_a, z01_a_ported: no strays.
- **A side's number is `lbl-<side>`.** `shapekit.side_label` ties its label to
  the side (`for: BC`, id `lbl-BC`, stable when another side changes) and the
  `length` constraint names it as `mark_id`. `shapekit._as_length` reads the
  number out of `BC=8`, `(8)`, `~8`, `8'`, `8 cm`; algebra (`2x`) states no
  length; a number it cannot read, or a label naming another side, is
  refused.
- Smaller: `value=True`/NaN/inf refused; `view.data_unit_px` = page px per
  unit of the QUESTION along x and y (`unit_px` is px per SVG unit);
  `xy` printed to 6 decimals (data_to_svg(xy) is svg_xy within 0.01 px on a
  line zoomed to hundredths); leniency for find-the-error figures comes from
  the builder (`Objects.critique`), never from a comment in the SVG;
  `euclid.parallels` exports m ∥ n.
- Tests: `selfcheck_v65_x2r1.py` (61 checks, each rule pass + fail, positions
  read by its own translate-aware reader, figure scripts run in fresh
  processes, determinism across two processes with different hash seeds).


## v6.5 close-out — the regression, the outside verifier, the package

- **Regression.** ז׳/08, ז׳/47 and ז׳/01 (ported) built with v6.4 and with
  v6.5 give byte-identical PDFs; gates all pass; no new refusal.
- **Exports verified from outside** by `verify_export.py` (O1 id exists once,
  O2 at the claimed svg_xy, O3 an ids-layer anchor on visible ink, O4 xy maps
  to svg_xy, C1 every constraint re-measured, including hidden_edge = dashed,
  C2 to_prove not marked, F1 build.json hashes): ז׳/08 45 figures, 1016
  objects, 3 constraints; ז׳/47 76 / 1081 / 3; ז׳/01 100 / 1992 / 0; 0 errors.
- **`selfcheck_v65_close.py`** — 14 checks: a real export passes; a moved
  point, a dropped id, a false constraint, a marked to_prove, a wrong xy, a
  solid edge claimed hidden, a tampered file and an anchor over empty paper
  each fail by their own rule.


## v6.6 S — the solidkit / shapekit carry-overs

Every item below was an open v6.4 finding (repros in the v6.4 result);
`selfcheck_v66.py S` tests each rule with a pass case, a fail case, and a run
against the v6.5 copy that fails it.

- **One edge, one number.** `Solid.edge_label()` is idempotent: the same text
  in the same form ships once. An explicit call on an edge the SOLID labelled
  itself (`box()`/`cube()`/`prism()`/`pyramid()` with `labels=True`)
  REPLACES that automatic label -- so `edge_label('AB', dim=True)` on a
  default box now renders, with 9 on a dimension line and printed once. A
  different second label on an edge the author labelled is refused, naming
  the first. `midpoint()` / `point_at()` twice with the same letter at the
  same point ship one letter; the same letter at a different point is
  refused (it used to print two M's).
- **Refusals are whole.** The fit no longer cuts the inner message at 160
  characters. A fit refusal now ends with the solid-level routes it TRIED and
  that render (the next tier; the automatic label moved onto a dimension
  line; that label left out, its length stated in words) -- never a route
  that is refused again. `box(100, 8, 60, tier='block')` names
  `labels={'b': None}`, which renders.
- **space_diagonal between two vertices of one face** is refused before any
  maths, naming `face_diagonal('ABCD', 'A', 'C')` (or `edge_label('AB')` for
  an edge). It used to draw A->C as a "space diagonal d" with via=None and
  crash inside `angle_between` with via=.
- **A cone's liquid is washed** like a cylinder's and a container's. And the
  level of a cone standing on its POINT is now drawn where its data puts it
  (lv above the apex, with the radius of that height); it was drawn lv below
  the base.
- **`WATER` is `#e0eef4`** (Rec.709 luma 0.923, was 0.911): every liquid wash
  is >= 0.92 and survives a B/W print as a pale wash. The test reads every
  area fill of the solids that emit one AND every tinted colour literal in
  the kits' sources.
- **variant='right'.** `shape('kite', variant='right', a=, b=)` draws right
  angles at B and D (q = 2ab/sqrt(a^2+b^2), computed; a conflicting q= is
  refused) and marks them. A parallelogram / rhombus refuses variant=
  (it was silently ignored), naming `shape('rectangle', ...)` /
  `shape('square', ...)`, and the right-angle accident refusal now names only
  the route the SHAPE has (`_right_route`).
- **describe.py reaches solids.** First sentence `תיבה ABCDEFGH`,
  `קובייה ABCDEFGH`, `גליל r=2 h=5`, `חרוט r=3 h=4`, `פירמידה ריבועית [SABCD]`,
  `פירמידה משולשת [SABC]`, `מנסרה משולשת [ABCDEF]`; data `AB = 4` (an edge),
  `r = 2`, `h = 5` / `גובה = 5`, `SA = 10` (a pyramid's lateral edge fixes its
  height), `(לא בשרטוט)`. All of a solid's defining lengths or none (none
  draws it unnumbered); a length on a non-edge, two values for one length, a
  cube with unequal edges, a height that contradicts a lateral edge -- each
  refused in Hebrew. `build(text)` returns the finished SVG (export kind
  `solidkit.<kind>`, named vertices); `describe.solid(text)` returns
  `(scene, solid)` unfinished, for add-ons and `solid.metrics` (V, S ...) in
  the answer key. When not every number fits readably, the refusal names the
  datum to mark `(לא בשרטוט)`, found by drawing that variant.
  Lengths on a solid are NOT exported as `length` constraints: the projection
  does not preserve them (spec section 8); the data are the solid's own
  parameters and each printed number passes solidkit's proportion check.


### v6.6 S round 1 (verifier findings; `selfcheck_v66.py R`)

- **describe grows before it drops.** A solid that cannot print every number
  at tier 'side' is drawn at 'block', and a triangular prism is also LAID
  DOWN with its base to the reader (`pose=(<lateral face>, ±90)`), before any
  datum leaves the drawing. Only then is one datum (or two) hidden, and the
  refusal hands back the WHOLE text to write -- «...» -- which parses and
  renders (checked by drawing it). A head datum takes the mark too:
  `חרוט r=10 h=1 (לא בשרטוט)`, `גליל r=10 (לא בשרטוט) h=1`. All attempts share
  one ~2.7 s budget; a failing fit is stopped early (`Scene._fail_fast`), a
  succeeding one never is.
- **A number moved onto a dimension line stays at its edge.** Only the ink
  across the dimension's own span pushes it out, and dimensions at different
  places no longer take lanes from each other. When other edges would stand
  across the middle of the span between the edge and the line (an equal
  parallel edge does not count: it measures the same number), the other side
  is tried; a length the SOLID placed (box a/b/c, prism L, a base side) moves
  to an equal parallel edge where it reads (a tipped box prints its 5 beside
  FB, not on a 66px arrow off AE); an AUTHOR'S number that can only float is
  REFUSED ("read against nothing"), naming inside= / pose= / leaving it out.
  (selfcheck_v64_close C9 changed with this: the outside '15' on an
  extruded triangle's hypotenuse used to ship on a 65px arrow; it is now
  refused, and inside='ABC' -- which the same check renders -- is named.)
- **Named add-on points export by name.** `midpoint`, `point_at` and a
  described pyramid's foot are `pt-M` / `pt-O`, their letters `lbl-M` (for
  M), the altitude `seg-OS`; every 3D right-angle mark is an object `ra-<v>`
  (its perpendicular is a fact about the solid, kept in the v3dang tag, not
  a constraint the cabinet projection could re-measure). A dimension's number
  is `lbl-AB`, for AB (figkit.dimension; was a hash with no `for`).
- `midpoint()` after `point_at(edge, 0.5, same letter)` still draws its ticks.
- `edge_label`: the same number asked for in a second FORM on an edge the
  author labelled is refused, naming the single call; the different-number
  refusal names the real key, never `labels={...: None}`.
- `space_diagonal` routes keep the label (`face_diagonal(..., label='d')`);
  on an edge it names `emph()` first (always draws), `edge_label` second.
- A fit refusal's routes include leaving out an AUTHOR'S label and the next
  tier combined with one; "draw it not to scale" (no such option) is gone.
- Liquid: `cylinder(pose='inverted', liquid=)` is washed from the ground up
  (it was washed from the top). `liquid=` on a LYING cylinder / cone is
  refused, naming the upright call.

## v6.6 E — the export: ids, JSON, given / to_prove (`selfcheck_v66.py E`)

What changed, for an author and for the author's AI reading `sheet.json`:

- **Equal arcs are a claim.** `euclid.congruent_pair` (sas/asa), the
  triangle's bisector cevian and `shapekit.bisector(arcs=True)` export a
  MARKED `equal_angle` (operands `{"at": "A", "rays": ["B", "C"]}`,
  `mark_id` the arc). A `to_prove` of that equality is refused like a ticked
  one; `bisector(..., arcs=False)` draws no claim.
- **The sheet's own notation is read.** `given` / `to_prove` strings may be
  written `$AM = MB$`, `$AB \perp AC$`, `$AB \parallel CD$`,
  `$\angle BAC = 90^\circ$`, and the number first (`7 = BC`, `37° = ∠ABC`).
  A false given in `$...$` is refused like any other.
- **A given on a proof item is reported** (`report["given_on_proof_item"]`,
  `build.json` checks, the build line): an item whose text asks for a proof
  (הוכיחו / הראו / נמקו מדוע) that declares as GIVEN the claim it asks to
  prove, or declares givens and no `to_prove` at all.
- **One fact, one entry.** A declared `AM = MB` on a figure whose midpoint
  M is derived relabels the midpoint (`source: to_prove`); `AB ⊥ AC` and a
  90° angle likewise. Nothing is added beside it.
- **`ex.forget(kind)` refuses a kind that has objects** — they are ink.
  Render's own label reset is `ex._rerender('label')`.
- **Ids unique per SHEET.** `figures/<id>.svg` keep the short ids; the
  sheet's HTML (and so the PDF's source) carries `<fig_id>__<id>`
  (`deliver.sheet_unique_ids`, called by `emit_html.build_html`), and every
  object in `sheet.json` records both (`svg_id`, `sheet_svg_id`; the figure
  entry has `sheet_id_prefix`).
- **Field names as the spec shows them:** every object has `svg_id` (`id`
  stays as an alias), every figure has `kind` and `fam` (null when a raw
  builder gave none; euclid figures now pass theirs). Round 1: `fam` is
  what the builder declared, else the `<!--fam:...-->` the SVG declares
  (`deliver.svg_fam`), else a family builder's own kind (`plane`); only a
  raw figure keeps null.
- **Labels say what they label.** A number on a side or a dimension has
  `for`: the segment's name (`lbl-AB`), or — when its ends have no letters
  (a cylinder's h, its r) — the id of the dimension or segment it is
  printed on (`for: "dim-0bcbbd"`).
  Round 1: on solids too -- an altitude's number names the altitude
  (`for: "seg-d58f99"`), a number written INSIDE a face (an area, a net's
  face value) names the face (a polygon object, role `face`), a solid's
  caption (`d.caption("V")`) names the solid's outline (role `solid`), and
  a number on one piece of a cut edge (`L | L`) names the edge. A letter
  that names a length (b, h, L) is no longer taken for a point name.
- **Ids on ink (V2-N4, settled in round 1).** A tick group, a
  right-angle mark (a solid's too), a multi-stroke arc and a line cut
  behind a number carry their id on a `<g id=... data-xy=...>` WRAPPING the
  strokes that draw them -- only strokes that are that object's ALONE, so
  no wrapper ever contains another object's id. An object inked by ANOTHER
  object's element (a polygon's edge: the `<polygon>` draws all its edges
  and has its own id) keeps an anchor in the `class="ids"` layer that names
  that element: `data-ink="poly-PQR"`, and `ink_svg_id` in `sheet.json`. A
  named point with no ink of its own (a solid's vertex, a triangle's
  corner) is an anchor.
- **Solids export the question's units.** `xy` is the cabinet picture in
  the solid's own units (a front-face edge of 5 reads 5), so
  `view.data_to_svg` and `data_unit_px` are real; every vertex of every
  solid is a named point (`pt-A`, so `seg-AB`) even when its letter is not
  printed (`letter_printed: false`), and carries `xyz` in 3D. A point the
  PROJECTION happens to put on an edge is not exported as `on_segment`.
- **`figures/<id>.py` for solids is runnable.** The author's steps on a
  solid (`d.draw()`, `d.edge_label(...)`), on a net, and `s.tier = ...` are
  logged, and `box(..., scene=s)` / `net(d)` continue the log they stand
  on. A level's own helper can be recorded with `export.entry(fn)`; its
  script imports the level from the package's `source/`. Round 1: with
  `export.light_import("level")` -- the level's imports, defs and plain
  constants, NOT its figures -- so one figure re-draws in well under a
  second (z47: 21 s before). deliver ships that form only after running it
  and getting the file back byte for byte; otherwise the plain `import`.
  The script finds the skill by `WORKSHEET_SKILL_DIR`, a `skill` folder
  beside the package, or `~/.claude/skills/hebrew-math-worksheet-v5`; a
  build folder under /tmp is never written into it.
- **Doctrine 4 has no side door (round 1).** An item whose text asks for a
  proof (הוכיחו / הראו / נמקו מדוע ...) is checked against the claims its
  own text states, whatever it declares: a claim the figure MARKS (arcs,
  ticks, a right-angle mark, or marks that imply it) is refused even with
  NO `to_prove`, with the claim relabelled `given`, or beside another
  `to_prove`. A stated claim that no `to_prove` declares is reported
  (`given_on_proof_item`, row with `claim`). `$m\angle BAC = 90$` and
  `m∠BAC = 90°` are read.
- `ex.forget()`'s refusal names an unnamed object by where it is drawn.
- **`source/` is portable.** Every string literal under the build folder or
  the skill folder is rewritten to a path computed at run time
  (`_SRC_HERE`, `_SRC_SKILL` = `WORKSHEET_SKILL_DIR`), and `source_hash` is
  over the rewritten files: the same source in another folder has the same
  hash. Any other `/tmp` path in the source is refused.
- `DELIVERABLE_SPEC.md` rules 4, 5 and 7 now say what the code does:
  `data_to_svg` converts `xy` to `svg_xy`; `unit_px` is page px per viewBox
  unit; `data_unit_px` page px per unit of the question.


## v6.6 close-out — the regression and the package

- ז׳/01 (ported): PDF byte-identical to v6.5. ז׳/08: 12/12 pages pixel- and
  text-identical at 200 dpi; the bytes differ by five empty `q Q` pairs
  (pages 5 and 10), the empty `<g>` id wrappers of V2-N4.
- ז׳/47 on solidkit: every page compared side by side with v6.5; the numbers
  on the sheet (as a multiset) and the answer page are unchanged.
- `verify_export.py`: 0 errors on all three exports. ז׳/08 45 figures,
  1016 objects, 65 named points, 3 derived constraints; ז׳/01 100 / 1992 /
  0 / 0; ז׳/47 76 / 1441 / 375 / 169 derived (163 hidden_edge). A prism's
  `pt-A` sits on its drawn vertex (0.000 px); all 76 ז׳/47 figure scripts
  re-draw their `<svg>` exactly (max 0.32 s).
- ז׳/08 built from two different folders: `sheet.json` identical apart from
  `built_at`, same `source_hash`, no `/tmp` path in `source/`.
- The open findings this version still carries are listed at the top
  ("NOT in v6.6").

## v6.7 F — the last open issues before page production (BRIEF_V67)

Tests: `selfcheck_v67.py` (sections D C A P L R K), every rule PASS + FAIL,
and every new rule shown failing on the v6.6 code (`V67_SKILL=<old copy>`).

* **Determinism.** No clock decides whether a figure renders. describe's
  solid routes are a fixed list (tiers, a prism laid down, then hiding one or
  two data) capped at `_SOLID_ATTEMPTS`; a failing fit gives up after
  `_FAIL_DRAWS` failed DRAWS (`Scene._fail_fast` is now a count); a refusal's
  route probe tries at most `_PROBE_MAX` candidates. The wall clock survives
  only as a safety net: `solidkit.SolidMachineError` (60 s) and
  `generate.GenerateMachineError` (`cap=`, now 30 s by default). Neither is an
  AssertionError, and both say MACHINE PROBLEM -- never a content refusal.
  The same text gives the same result cold, warm and on a loaded machine.
* **Flat cone.** A cone whose apex would fall inside its base ellipse is
  drawn with a lower eye (`Scene.depth`, a smaller depth factor, stated in
  the proj tag as `cabinet45:right:k0.08`), so apex and slant sides are
  drawn and the h dimension ends at ink. A cone no view can show is refused,
  naming a `cone(r, h)` call that was drawn and renders.
* **∠A.** `deliver.parse_statement` reads `∠A` / `$\angle A$` as the angle
  AT A; `deliver.resolve_short` makes it ∠BAC when the figures draw exactly
  one angle at A (two neighbours). Marked -> refused like ∠BAC; unmarked ->
  checked; more than one angle (a median from A) -> reported in `unchecked`
  with the reason, never shipped as checked.
* **Proof phrasings.** ש־ (maqaf/dashes), "את הטענה:", "בדקו האם … ונמקו",
  and the worded forms ("הזווית BAC שווה לזווית EDF", "הקטע AB שווה לקטע
  CD", "AB מקביל/מאונך ל-CD") are proof items.
* **Export.** Round solids: centre O, rim point R (seg-OR, lbl-OR for OR),
  cone height lbl-OS for OS; a cylinder's height stays tied to its dimension
  id (its top centre has no ink). A hand-drawn dimension (shaft + barbs as
  plain lines) exports its barbs as marks and the shaft as a dimension. A
  number on a piece of a stroke carries `for_part` ([t0, t1] along it). An
  anchor names the ink it stands on (`data-ink`: the strokes ending at a
  vertex, the boundary strokes of an undrawn hull).
* **Routes.** describe's final refusal is solidkit's WHOLE message (routes
  kept); the 'read against nothing' refusal names concrete, probed calls
  (`edge_label('BC', '15', inside='ABC')`, `pose=('ABED', 90)`);
  `describe.solid()` grows like `build()`.
* **Light scripts.** `export.light_import` keeps attribute assignments
  (`figkit.INK = ...`) and lists skipped statements with an effect; then
  `deliver.verify_code` checks the light script in a FRESH process.

### v6.7 F r1 — the verifier's round

Tests: `selfcheck_v67.py` sections N F Q (new), K and R (fail cases that
run the rule on a bad input). Each new rule fails on the code before r1.

* **Every angle notation.** `∡` (U+2221), `$\hat{A}$`, `$B\hat{A}C$`,
  `$\widehat{BAC}$`, `Â`, `BÂC`, "זווית A = 90°" (no ה), "90 מעלות",
  "הזווית BAC ישרה" and "המשולש ABC ישר זווית" (at the vertex named with
  ב-A, or the ONE vertex the figure states or measures as right) are read
  as the angle claims they are. A marked claim in any of these spellings is
  refused. A proof item whose claim deliver cannot read at all is reported
  in `given_on_proof_item`. It is never passed over silently.
* **Light scripts.** `light_import` also lists skipped compound statements
  (`if`/`for`/`with`/`try`) in `_light_skipped`, so the fresh-process check
  runs. The `if __name__ == "__main__":` guard, docstrings, `pass` and
  asserts are the only statements skipped silently.
* **Flat cone.** On a cone drawn with a lowered eye, r and h are written on
  dimension lines outside the drawing. Each witness line starts at the last
  ink it meets (`figkit.dimension(witness_from=...)`, which ends at the
  shaft). The radius number no longer sits under the rim. A cone that no
  view can show raises `solidkit.SolidUndrawable`. describe stops at the
  first one, so the refusal takes about 2.6 s instead of about 10 s. Its
  route first keeps the numbers (the text, with no fig=). A different h is
  offered only as a change to the data.
* **Routes.** A refusal for a marked claim names calls this builder has,
  and each one is drawn before it is named
  (`euclid.congruent_pair(..., kind='sss')` for ∠A = ∠D). describe's last
  refusal also names «the text» printed with no fig=.
* **Not in r1:** the cylinder's height stays tied to its dimension id
  (fixed in r2, below).

### v6.7 F r2 — the second verifier's round

Tests: `selfcheck_v67.py` sections V and T (new), K3, and new checks in
F1/F2. Each new rule fails on the code before r2 (`v67/pre_F_r2`).

* **Every request for an argument.** deliver reads one verb list
  (`_VERBS`): הוכיחו/הוכח/הוכיחי, הראו/הראה/הראי, נמקו/נמק/נמקי,
  הסבירו/הסבר/הסבירי, הצדיקו/הצדק/הצדיקי, בססו/בסס. A verb may be followed by
  כי, ש-, ":", מדוע or למה. A sentence that opens with מדוע or למה also
  counts, and so does האם when the item asks for reasons anywhere
  ("האם ∠A = ∠D? נמקו"). The item is read sentence by sentence. A sentence
  that opens with נתון or ידוע is a given, never a claim to prove. A marked
  claim in any of these forms is refused. A bare "נמקו את תשובתכם" after a
  calculation adds no "cannot read" row.
* **More spellings.** `90^o`, "הזווית A היא זווית ישרה", "∠BAC הוא 90°",
  "∆ABC ישר-זווית", "המשולש ישר זווית" (with no name: the one triangle
  the figure draws), "הזוויות BAC ו-EDF שוות" and "שווה ל־∠EDF" (maqaf).
* **Honest routes.** A named route that changes the question's other marks
  says so, for example `kind='sss' [this CHANGES the question's givens:
  drops the given ∠ABC = ∠DEF; adds the givens AC = DF, BC = EF ...]`.
* **Light scripts.** An `assert` that calls or assigns anything is listed
  in `_light_skipped`, so the fresh-process check runs. Only an assert
  that calls nothing is skipped silently.
* **Cylinder height.** h is measured along the drawn generator on the side
  where the dimension stands. Both ends of the dimension face drawn ends
  of that line, so it no longer measures from the top centre, which has
  no ink. The label stays `for` the dimension. A SHORT cylinder
  (h < 1.5 r) keeps its shaft level with the centres, because the number
  beside a short shaft would read against the equal generator 12px away.
  Its two ends get witness lines from the last ink they meet (as on a
  flat cone), so they are tied to ink too. Every cylinder's h
  dimension moves by about 6px along its own direction; the renders are
  in `v67/w/r2/cyl_new.png`, with `cyl_pre.png` for comparison.
* **Speed.** `figkit.Figure._owns` skips a stroke whose bounding box is
  already too far away to compete. The answer is the same (11 describe
  outputs hash-identical to pre-r2). A thin cylinder's cold refusal now
  takes about 1.0 s instead of 3.2 to 3.5 s.

## v6.7 close-out — the regression and the package

- ז׳/01 (ported), ז׳/08 and ז׳/47 built from the same sources with the v6.6
  package and with v6.7: all three PDFs md5-identical, all gates pass in both.
  So ז׳/47's numbers and answer page are unchanged.
- Figure SVGs: ז׳/01 and ז׳/08 byte-identical; ז׳/47 63 files differ only in
  attributes (+`data-ink` on anchors, new ids for the q12b/q12c/q15d barbs),
  0 pixel differences at 200 dpi. In `sheet.json` those barbs and shafts moved
  from 30 `data` segments to 24 mark segments + 6 dimensions (brief item 5),
  and q12_head's two `L` labels carry `for_part` (looked at).
- Build reports: `given_on_proof_item` now lists false rows for "הסבירו
  כיצד…" / "מדוע…?" items (ז׳/08 3, ז׳/01 2, ז׳/47 5; v6.6 0) -- open, see
  the top.
- `verify_export.py`: 0 errors, 0 notes on all three exports (ז׳/08 45 / 1016
  / 65 lettered points / 3 derived; ז׳/01 100 / 1992 / 0 / 0; ז׳/47 76 / 1441
  / 375 / 169 derived). Every figure script runnable (45, 100, 76).
  `deliver.SKILL_VERSION` is now "6.7".
- Packaged as `hebrew-math-worksheet-v6.7.skill`; from a clean unzip the whole
  suite ran sequentially, all rc=0, and `selfcheck_v66` (187 checks) and
  `selfcheck_v67` (142 checks) passed three times each, once with 10 busy
  loops running.
- The open findings this version still carries are listed at the top
  ("NOT in v6.7").

## v6.8 — the Noam AI package (BRIEF_V68 §0, §1, §3)

- **Merged from the author's v6.6-noam:** `references/noam-ai-deliverable-he.md`
  (binding), the section at the top of this file, `noam-ai.json` in
  `deliver.py` (now `deliver.noam_view`: answers dropped at ANY depth, code
  paths dropped), `STRICT_FIGURES` default True in `build.py`, and
  `selfcheck_noam_package.py` (reads `noam_view`).
- **A new package states itself** in `content.py`: `PACKAGE = "G7-T08"` (the
  site topic id, `regen/topic_ids.json`) and `STRICT_FIGURES = True`. Under
  STRICT, deliver refuses a malformed PACKAGE, a level key outside a/b/c and
  a content.py that does not write STRICT_FIGURES; `build.json` records it.
  `STRICT_FIGURES = False` is an old sheet's maintenance build only.
- **Declarations are the source of truth.** Every item/question whose text
  asks for a proof or an argument (הוכיחו/הוכח/להוכיח/הראו/להראות/נמקו/לנמק/
  הסבירו/להסביר/הצדיקו/בססו, after יש/צריך/עליכם, a comma, a colon, a newline,
  or "X. הוכיחו.") must carry a `to_prove` KEY; `to_prove=[]` means "explain,
  no geometric claim". Declared claims are written structured
  (`{"type": "equal_length", "of": ["AM", "MQ"]}`) or as $..$ that parses; an
  unparseable one is refused, a marked one is refused. The text parser stays
  a cross-check: a claim it reads that the figure MARKS is refused whatever
  was declared.
- **Ids on ink (G1).** An object no element of its own draws (a polygon's
  edge, a solid's vertex, a net's face, a ray) gets an exact overdraw of the
  printed stroke there, `class="ink-copy"` (same width, dash and dash
  phase), carrying its id. `svgcheck` and `figure_family` skip those
  (`svgcheck.strip_copies`), so every sweep reads each stroke once. The PDF
  changes only by anti-aliasing at those strokes (0 visible differences on
  ז׳/08 and ז׳/47; ז׳/01 byte-identical).
- **Byte for byte (G2):** a solid's script writes the `<svg>` element alone,
  as the file holds it (the builder's trailing `<!--v3d-->` is in sheet.json).
- **verify_export.py** (`python3 verify_export.py out/deliver/a out/deliver/b
  out/deliver/c`): I1 ids on ink / no empty anchor, R1 re-runs every runnable
  script and compares bytes (skill from WORKSHEET_SKILL_DIR or its own
  folder), N1 noam-ai.json, N2 the three levels, S1 each figure of
  `sheet.html` (now in the package) against `figures/<id>.svg`.
- Also: item `figure` links (own or the question's), `given`/`to_prove` keys
  always, a number beside a plotted point is `for` it, shapekit exports the
  relations it knows (midpoint, altitude foot, unmarked bisector, parallel
  without chevrons, ray-AB), a short cylinder's JSON h measures its drawn
  generator, report rows print claims as the sheet writes them.
- Tests: `selfcheck_v68.py` (M I R G F C N S P T); on the v6.7 code 62 of its
  checks fail. Older tests that encoded the ids layer were updated
  (selfcheck_plus line counts, v65 / v65_close / v65_x1 / v65_x2, v66 E14/F5).

### v6.8 r1 — what the independent verifier found (selfcheck_v68 X)
- `to_prove=[]` never silences a proof request: a strong request (הוכיחו /
  הראו …) over a figure whose claim deliver cannot read is a report row with or
  without the key. More wordings read as claims: "הישרים AB ו-AC מאונכים",
  "הקטעים … מקבילים", "ABC משולש ישר זווית", "BAC = 90°", and a claim BEFORE
  the request ("∠BAC = ∠EDF, הוכיחו זאת"). A marked one is then refused.
  "הסבירו כיצד" is not a strong request ("כי" is a whole word).
- `parallel_through` draws a LINE: exported `ln-…`, and the parallel relation
  names that line.
- verify_export I1: a right-angle mark's svg_xy is the vertex it marks; its L
  must close on that vertex within 1 px. A label's svg_xy is its text anchor,
  within 1 px. N1: an item's figure is the one sheet.json links (its own, else
  the question's head, else null). A bare `<g id>` is an I1 error, not a
  crash; relative level / skill folders work.
- A figure script finds a skill that is importable (PYTHONPATH) before any
  guessed folder. A cone whose radius is not drawn gets its base-centre dot
  when its height is shown, so the height's JSON ends sit on ink.
- Refusals write the claim the sheet's way ("MARKS equal_angle ∠BAC = ∠EDF",
  "declares AB = AC").

### v6.8 r2 — marked relations everywhere (selfcheck_v68 Y)
- A SOLID's marks are constraints too, stated IN SPACE: `right_mark`, the
  foot marks of `base_altitude` / `angle_to_face` export
  `perpendicular(..., space=True)`; ticks (`equal_edges`, `midpoint`) of one
  count export `equal_length(..., space=True)` (grouped by equal 3D length).
  Each operand is a point of the SVG carrying `xyz` (a foot with no letter
  gets `pt-<hash>`), and export.recheck / verify_export re-measure them on
  the xyz. `space` is the only way a projected figure exports a length or an
  angle fact.
- A plane right-angle mark whose ray is not a segment of its own (an
  altitude's foot to a base corner) names the drawn segment that contains the
  ray; a vertex that is no point leaves `at` out, never the fact.
- Every right angle carries `ink_xy` (the corner of its L, on ink); every
  figkit label carries `ink_box` (the box the solver kept clear for its
  glyphs). svg_xy stays the vertex / text anchor. A consumer highlighting a
  mark goes to ink_xy.
- verify_export: R1 every figure must be code_runnable; B1 build.json must
  record strict_figures and strict_figures_declared True; I1 checks ink_xy
  and ink_box; X1 space constraints on xyz; X2 a figure's xyz must be one
  affine picture of its svg_xy (1 px).
- A bare "הוכיחו זאת." proves the question's last stated claim ("בציור ∠BAC
  = ∠EDF."): a marked one is refused. "BAC∠" (the sign typed after the
  letters) reads as ∠BAC.

### v6.8 final — the pilot topic and the last verifier findings (selfcheck_v68 Z)
- `numberline`: every number printed under the line carries `for` its tick
  (`lbl-4` → `tick-4`); a mark's letter is an exported label `lbl-A`, `for`
  its point `pt-<value>` (B-NUM-3: Noam AI can now find A and B).
- verify_export N3: a numeric label with no `for` (noam-ai.json or
  sheet.json) is an error; sheet.json rows must carry given/to_prove lists.
  C1: a constraint verify_export cannot measure is an ERROR, no longer a
  note.
- deliver: when the request reading finds no claim, every formula of the
  item's text is read (a claim sentence opening with any word: "בציור …
  הוכיחו.", "גם … נמקו."); the question's own text is read even when it has
  items (a marked claim in the intro is refused whatever the question
  declares). `to_prove=[]` on a proof verb is reported only when the text
  still holds a relation (=, ∥, ⊥, ≅, ∠) or a geometric word (חופפים, שווים,
  מקביל, מאונך, אמצע, משולש, זווית …) deliver cannot read; otherwise it is the
  author's "explain" declaration (ז׳/08 ג׳ q5b, q10c, q10d rows gone).
  selfcheck_v68 P5's FAIL case now also switches this fallback off when it
  puts v6.7's reading back (the test changed with the behaviour).
- Tests: section Z (Z1–Z9); the old G4/G5 and G6 "FAIL cases" built a dict
  by hand and could not fail — replaced by verify_export runs on mutated
  packages (Z2–Z4). The given-skip rules are tested (Z9) and shown failing on
  two mutants (skip removed in `_claims_before`, in `_formulas_in`). On the
  code before this round, 14 of section Z's checks fail.



# v6.9-noam — a level from a wspec spec (BRIEF_ENGINE_PDF)

## What it is

A question (or a whole level) may declare its figures and the maths core of
its text as a **wspec spec** — the closed plane-geometry dialect of the
wspec engine (wspec-engine-v1, 2026-09-23), vendored here as `wspec/`
(stdlib + PyMuPDF; its OCR helper `tools/wspec_ocr` is compiled from
`tools/wspec_ocr.swift` on first use — `swiftc -O -o tools/wspec_ocr
tools/wspec_ocr.swift` by hand). The chain, checked end to end on the REAL PDF:

    spec -> public model -> engine render (SVG + object_map + placements)
         -> sheet HTML (the SVG inlined byte-exact) -> sheet.pdf
         -> G79-spec: the figure located on its page, rasterised, geometry +
            labels + cover + answer + the engine's checker with OCR
         -> deliverable (sheet.json, noam-ai.json, figures/, didactic.json,
            build.json, wspec/public_spec.json) from the same spec

## Writing a spec level

    # level_a.py
    import os, wspec_build as WB
    HERE = os.path.dirname(os.path.abspath(__file__))
    LS = WB.LevelSpec(os.path.join(HERE, "g9t18a.wspec.json"))
    Q = [LS.question("q1", space=40, spaces={"q1a": 60},
                     didactic={"q1a": DID(...), "q1b": DID(...)}),
         dict(n=2, intro=..., fig=shapekit..., items=[...])]   # builder path

`g9t18a.wspec.json` = `{"spec": <wspec spec>, "display": {fid: settings}}`
(the settings are the engine's display settings: `layout`, `width`, ... —
`wspec/render/FORMAT.txt`; `font_family` defaults to the house face
`David Libre,serif`). The build copies `*.wspec.json` into `source/`.
A spec question takes from the spec: its text (`intro`), its items and
their texts, its figures (the head figure is `q<n>_head`, an item figure the
item id), given / to_prove / to_construct (the facts), the find targets'
values and the answer key (the private answers). The author keeps only
`space` / `spaces`, `didactic` (per item id), `star`, `part`, `fig_side`,
`dashed`, `no_target_reason`. Refused: a spec question that also writes its
text / figures / items / claims, an `answers=` row for it, an item figure
the engine grows past 150 px (give it `margin: 16` or another width), a
spec that does not validate, a figure whose render validation FAILs.
`WB.sub_spec(spec, ["q1", "q4"])` cuts a spec to some questions.

**One look per sheet (G78).** The engine prints letters at `name_size` 14
(10.5 pt); the builder at 9.5 pt. A level that MIXES engine and builder
figures gives the engine the sheet's sizes: `name_size: 12.67`,
`value_size: 10.67` (9.5 / 8 pt). A level of engine figures only may keep
the engine's defaults.

## G79-spec (wspec_pdf.py)

Runs in `build.py` right after WeasyPrint, on every level with engine
figures (the document is rendered once; its layout gives each figure's
page and box). Per figure: **L** the dots of the page must be the engine's
points at scale 0.75 pt/px in x and in y (a stretched / resized / moved
figure FAILS); **G** every line, dot, arc and mark is a drawing of the page
at its placed coordinates (0.35 pt); **T** every label printed as itself at
its anchor; **C** no page text / foreign drawing touching the figure's ink
or labels (FAIL; inside the box but touching nothing: REVIEW); the box on
the page; **A** no answer value in the box except the figure's own caption
of a drawn given; **K** the engine's independent checker with the PDF
raster (300 dpi) as the final display — OCR of every label on the PDF
pixels; and the sheet HTML inlines every engine SVG exactly
(`G79_HTML_NOT_EXACT`). **FAIL stops the build** (nothing delivered,
`out/g79_<level>.json` names every finding). **REVIEW** (e.g. an object
the text names that the figure does not draw completely) delivers the
package but the level is NOT APPROVED (build exit 1) until the author
accepts each such figure with a reason: `accept_review={"q10c": "..."}` in
the level. `G79_OCR=0` skips OCR (the build line says so; never for a
delivered sheet). build.json records the verdict (`checks.g79_spec`).

## The deliverable of a spec figure

`figures/<id>.svg` the engine's SVG byte for byte; `figures/<id>.map.json`
the object map; `figures/<id>.py` re-renders from `wspec/public_spec.json`
(the PUBLIC model only) and prints the SVG byte for byte (verify_export R1).
sheet.json's figure entry uses the engine's element ids as svg_id (points,
segments, labels, arcs, right-angle / tick / arrow marks) and the spec's
facts as constraints (marked with the marks the engine drew for them). The
visual_model names the engine's objects: `A`, `seg:AB`, `ang:BAC`,
`poly:ABCD` with `parts` [{svg_id, span?}] (a piece of a longer line by its
two points). Checked: verify_export (O2 for a drawn right-angle L = the
L-closure test), selfcheck_noam_package **K16** (every part once in its SVG,
printed; a span over drawn points; one object per id), check_didactic V2
(parts in the SVG). `tools/highlight.py <level> <figure> <object>`
highlights from noam-ai.json alone (stdlib; exit 2 on anything it cannot
find).

## Engine changes made here (each awaits the author's approval)

The dialect `wspec/svg_dialect.json` was re-pinned by the integrating agent
(not a human approval): `font_families` gains `David Libre,serif` (G70: the
PDF may print no other face, and CSS never reaches inline SVG text) and
`font_sizes` gains `10.67`, `12.67` (the sheet's 8 / 9.5 pt); the settings
gate accepts them. `wspec/check/ocr.py` builds the helper on first use. The
engine's 541 tests pass on the vendored copy.

## Not in v6.9

Coordinate planes, graphs and solids through the spec path (plane geometry
only); aux figures (שרטוט עזר) from a spec; a caption that is an expression
('3x + 4'); an unnamed constructed line. A level mixing engine and builder
figures must use the house sizes above (G78).

### v6.9 — the Codex review of wspec-engine-v1 closed (ADDENDUM 2; `selfcheck_v69_codex.py`)
- **F1 dependencies.** `wspec.check` gives every object `depends_on` (its points with their name labels;
  an angle's arms, a polygon's sides) and `blocked_by`: a REVIEW / FAIL on a dependency blocks the
  object's PASS (C printed as A -> ang:ACB, seg:AC, poly:ABCD not PASS; seg:BD stays PASS). An OCR
  service failure (helper missing, crash, timeout, non-zero exit, `#ERR`, an image not answered) is
  `CHK_OCR_UNAVAILABLE` with the reason `OCR_UNAVAILABLE` in `report["infrastructure"]` -- REVIEW, never
  "not read", never PASS.
- **F2 geometric ink.** Given a display image, the checker renders every drawable of the approved SVG
  alone at the display's scale and compares ink (`wspec/check/inkcmp.py`, check
  DISPLAY_INK_MATCHES_FIGURE): an element > 20 % missing FAILS, foreign ink in the canvas FAILS (labels
  are OCR's). G79 feeds it the PDF pixels of the PLACED box and adds G79_SHIFTED (the drawing's fitted
  origin must be the page's placement within 0.35 pt). A dropped line, an added element, a shift, a crop
  by the page and a one-axis stretch all FAIL; the clean pilot figures show 0 missing, 0 foreign ink.
- **F3 focus arc.** Highlighting an angle the figure prints no arc / right mark for adds ONE focus arc
  (`data-focus`) from its three points -- vertex, both arms, its own sector, radius 18 px (<= 0.45 of the
  shorter arm) -- in the temporary overlay only (`wspec/render/highlight.py`, `tools/highlight.py`);
  `wspec/check/highlight.py` verifies it; the printed figure never has it.
- **F4 TEXT_ONLY.** `wspec_build.spec_gaps` lists what a spec question asks / states that its public
  spec lacks (NO_TARGET, EMPTY_TEXT, VAR_UNDEFINED, PROSE_DATUM, PROSE_TARGET); the build refuses such a
  question unless the author marks the WHOLE question `LS.question("q2", spec_unsupported=u"<why>")`;
  sheet.json / noam-ai.json then carry `spec_unsupported: {reason, missing}` and check_didactic D13
  reports it REVIEW. On the G9-T18 pilot specs as they stand: a q2 q3 q6 q11-q15, b q2 q5, c q2 q4 q6
  q11 q13 q15 have gaps (the level author decides: complete the spec or mark).
- **ADDENDUM 1.** `export.recheck`'s refusal names routes that render ("write the measured value, e.g.
  '37', or draw the figure from the given angle"; never "delete the number"): selfcheck_v64_t2 62/62.

### v6.9 — focused fix round 1 after the pilot verifiers (`selfcheck_v69_fix1.py`)
- **Caption on a split segment (N1/P1).** Engine `wspec-render/1.0.1`: a segment caption whose segment
  a drawn point splits (BC = 8 with E the midpoint) stands OVER that point and the point's name goes to
  the other side of the segment; a piece wholly across the segment's line (DE above BC) no longer
  "owns" a caption below it (engine, geomcheck, checker). The checker FAILs a caption beside one part
  (`CHK_CAPTION_SUBSEGMENT`: it reads as the part's length) and REVIEWs one beside the point's name on
  its side (`CHK_CAPTION_BESIDE_NAME`).
- **One math island per datum (N2/P2).** The tex phrases print `$AC = 18$ ס״מ` (and `$OA = OB$`,
  `$AB \para CD$`, `$BH \perp AC$` ...): a datum never breaks across lines. The answer key prints
  `$DE = 4$ ס״מ` and adds `· נימוק` when the item says נמקו (N3/P5).
- **The text layer (P3/C2).** A level's `.wspec.json` may carry `"text": {scope: [segments]}` beside
  `"display"`: another composition of the SAME maths core with approved templates / connectors. The build
  refuses it unless every scope prints exactly the facts the spec's own text prints (none dropped,
  none added), with no new prose; the `"spec"` part is never edited. New approved templates (set
  re-approved BY THE FIXER, awaits the author): `given_next` (one "נתון:" for a list), `midpoint_named`,
  `bisector_meets_side`, `drop_altitude_to_diagonal`, `compute_two`; `compute_length_of` gained "היתר".
  With them the G9-T18 stems read as in v6.7.3 ("חוצה הזווית ... חותך את הצלע", "תיכון ליתר",
  "העבירו את האלכסון ... הורידו אנך", "האלכסונים נפגשים בנקודה O").
- **One line look (P4).** Display setting `inner_stroke: "thin"` draws inner segments (drawn points on
  both sides of the line: diagonals, cevians, midsegments) at width 1 under a 1.5 outline -- the
  builder's look. G78 LOOK refuses an engine figure without it on a level that also prints builder
  figures. Known difference that stays: the engine marks every vertex with a dot (the anchors G79 fits
  the printed figure by).
- **G79 label text (E1).** `wspec_pdf.label_forms`: a caption mixing a number and a Hebrew unit is
  matched in logical or visual order ('5 ס״מ' is extracted as '5מ״ס'), never as a bare multiset.
- **The G79 verdict travels (E2).** verify_export B2: a package with engine figures needs
  `checks.g79_spec` present, approved, OCR on, every engine figure PASS (or ACCEPTED with a reason).
- **A cut line (E3).** `CHK_DISPLAY_INK_GAP`: a straight stroke interrupted for >= 3 px on the final
  display FAILS whatever share of its ink is gone.
- **Parts draw their object (C1).** verify_export V1: a visual_model segment's stroke parts carry its
  ends, an angle's an arm from its vertex, a polygon's a side, a point's dot sits at its svg_xy.
- **0-degree angles (C4)** (H on CA: ACH) are not offered in the visual_model unless a relation names
  them.
- Not changed (minor, reported): the parallelogram given highlights no parallel sides (C3: a typed shape
  has no overlay mark); fractions in builder stems read reversed in RTL (P6, as in v6.7.3).

### v6.9 — focused fix round 2 after the independent acceptance (`selfcheck_v69_fix2.py`)
- **Hebrew units print in the right order (E1b, the acceptance FAILs S08/S14).** WeasyPrint lays SVG
  `<text>` out WITHOUT bidi: the logical `5 ס״מ` printed samekh LEFT of mem, and fix r1's `label_forms`
  accepted that reversed print. Engine `wspec-render/1.0.2`, dialect `wspec-svg/5` (re-pinned BY AN
  AGENT, awaits the author): a label with a Hebrew letter is stored in VISUAL order (`5 מ״ס`) under
  `direction="ltr" unicode-bidi="bidi-override"` -- WeasyPrint prints the stored order, a browser
  honours the override, so both show the same glyphs. `wspec/bidi.py` (one Hebrew run, at the END of a
  label); the object map keeps the logical text; geomcheck, the checker and wspec_build read it back
  logically and refuse Hebrew without the override (or the override without Hebrew). G79 T now reads
  the PDF glyphs BY x and requires exactly the visual order (the first Hebrew letter rightmost):
  `G79_LABEL_BIDI` FAIL for a reversed print, `G79_LABEL_TEXT` when the stored label disagrees with the
  object map. OCR still does not verify Hebrew units (F5); the glyph-order check does.
- **A span is a piece of its own object (C1r).** verify_export V1 and `tools/highlight.py` refuse a
  part whose `span` is not the object's own: a segment's span lies on the segment, an angle's is
  `[vertex, X]` with X on one of its rays, a polygon's on one side (seg:CO with span [D, O] on the line
  of BD, ang:AOB with arm span [O, C] passed all three checks before).
- **B2 on what ships (E2r).** verify_export B2 also runs when the package ships engine figures
  (`figures/*.map.json`, `wspec/public_spec.json`) but build.json lost its `wspec` key.
- **The vertex look (P4).** Display `vertex_dots: "corner"`: a point that is a CORNER of the drawn strokes
  (>= 2 solid normal strokes end there at an angle, none passes through: a polygon's vertex) gets the
  corner dot r=0.75, which lies inside the stroke join -- the vertex prints as its corner, as in the
  builder; a point on a line or where lines cross keeps its visible dot. Every shown point still has
  its dot (G79's anchors); labels do not move. A corner dot anywhere else is outside the dialect
  (geomcheck AND the independent checker). G78 LOOK asks for it on a level that mixes engine and
  builder figures; absent, every dot is unchanged.
- Not changed (minor, listed): template wording `∡BAD` / `CD` (v6.7.3: `∡A` / `DC`, b q4) and `∡ABC`
  (v6.7.3: `∡B`, b q7 q10) -- same facts and numbers; fractions in builder stems (P6, as in v6.7.3); the
  parallelogram given's parallel sides in highlight_given (C3, the author decides).


### v6.16 — focused fix round 1 after acceptance run 0 (`selfcheck_v616_fix1.py`)
Report: v616/fix_r1/REPORT.txt. Each rule below has a passing and a failing case in `selfcheck_v616_fix1.py`.
- **A declared data-chart reprint counts once (G76).** A level may declare `chart_reprints = {n: (original n,
  reason)}`: question n prints the same pie chart as question `original n` (the source reprints it). The gate
  validates each entry (a pie chart, the same figure family, no chains) and counts the pair once for
  DOMINANCE. An empty build-a-pie circle (only `bcirc` / `bdot` hooks) is a workspace, not an object.
- **Build-a-pie questions on the spec path.** A drawn build circle binds its percent word through
  `bcirc:<name>/unit` (sheet_pie `REF_RE`); a `construct_pie` item keys its source line (no value to restate).
- **A to-find point gets a to_construct row** when no figure of its question shows it ("הנקודה X"), and
  verify_export E4 accepts that row (the t08_b skill fix).
- **Names Noam AI resolves (K6, D8, deliver §8).** A graph curve or mark name, a mark's letter, a name made of
  to_construct points, and a text denotation ("נסמן ב-X את ...") define a name.
- **`keep` on one question.** `keep=True` on a question keeps its sub-items on its figure's page (inline
  `break-inside:avoid`; the class stays `q` for G80). `keep_questions=True` still does it level-wide.
- **Axis numbers and curves (graph render).** A number keeps 2.0 px from a curve stroke on its OWN side of its
  axis; when no place there has 2.0 px, the v6.15 search (1.0 px, own side, then across) runs unchanged, so the
  wider clearance never sends a number across its axis.
- **OCR look-alike Q.** G79 may confirm a read "O" / "0" as the expected "Q" by the crop's aspect (confirm only;
  it never fails a read).
- **Coordinate plane.** The highlight box behind a capital `Q` label reaches below the baseline (its tail). The
  independent checker does not count a drawn point's own drawn name as an answer exposure ("which point is the middle
  of PR?" asks for one of the printed names); a value printed in a label is still checked.
- **Acceptance runner (coord).** A figure of one item serves its whole question when the runner looks up the true
  places of read-off points (`fig_scope(..., whole_question=True)`; the number line keeps the v6.15 scope), and the
  harness's private position check also counts for `POLY_VERTICES_AT_COORDS` (RUNNER_V2.txt D7). Graph runner: a
  number printed with an explicit `+` sign is never an axis number.

### v6.16 — fix round 1, W-FIGURE-DENSITY (`selfcheck_v616_fix1b.py`)
The author: "יש מעט מידי שירטוטים לשאלות... איפלו לסעיפים" (APPROVALS W-FIGURE-DENSITY; BRIEF_V616 ADDENDUM 1).
- **G82 FIG_REF** (`gate_figref.py`, installed by `build_plus.py` after G78; every sheet): a question
  whose stem (or worked example) holds a figure REFERENCE word ('בעוגה', 'הגרף', 'בשרטוט', 'שלפניכם',
  ... `REF_TOKENS`) has a head figure, or every item has its own; an item that holds one has its own
  figure or its question's head figure. Not references: a chart-type noun ('העוגה', 'דיאגרמת עמודות'),
  'בלי / ללא שרטוט', a draw instruction ('שרטטו את הגרף'). A reference the skill cannot draw yet is
  declared on the level, `fig_ref_pending={n: "<reason, author decision>"}`: the level is BUILT and NOT
  APPROVED (GATES line, build.json checks.g82_fig_ref, a verify_export G82 error) -- never shipped done.
- **G83 FIG_DENSITY** (a FIGURE TOPIC): the level declares its drawing-from-words share
  `words_share={n: reason}`; its size is round(15% a / 20% b / 10% excellence x questions) +- 1; a
  member draws nothing, prints no reference word and leaves >= 40 mm (113.4 pt) in one item; every other
  question has a figure (head or item), or prints the source's value TABLE (reported); a local-limit
  placeholder (no stem, no item) is no question. G83 replaces G77's question / sub-item floors where it
  governs. `figure_sheet=False` still switches off only the house geometry floors (G75-G77), never G83.
- **The figure-topic status** (`gate_figref.topic_status`, also `emit_html.is_figure_sheet`): an explicit
  `figure_topic` (True / (False, reason)), else the package id (content.py PACKAGE) in
  `figure_topics.json` (the 140 site topics of plan18's inventory, figure | algebra), else a tashpaz unit
  of one kind, else unknown -- NEVER the measured share of drawn questions (FIG_SHEET_SHARE no longer
  decides). The pre-rule pilots G7-T01, G7-T08, G9-T18 are figure topics whose G83 is DEFERRED (printed).
- **Roman list markers** '(i)', '(ii)', '(iii)' bind `{"enum": k}` (schema_bound.roman_value; G80).
- **Graph givens:** a drawn given whose equation its text prints (`stated_in`) may be labelled by that
  equation (`GV.*_def(..., equation="expanded" | "vline" | ...)`); the sheet-wide leak rule exempts it;
  the checker measures it against the curve. A label holding '²' names `David Libre,HouseSym,serif`
  (the pinned face; the dialect lists it); G79 joins a label printed in two spans of one baseline.
- **Dashed axis of symmetry:** a dashed VERTICAL line of a graph figure whose question text names the
  axis of symmetry ('ציר הסימטריה') is accepted by N3 (deliver) and D2 (check_didactic); any other dashed
  data line is still refused (a line that is DATA is drawn solid).
- **G78:** a pie value label '24%' is a number (it was read as a letter: G8-T30 refused).
- **check_didactic D12:** the house fraction macros `\f{p}{q}` / `\d{p}{q}` state p/q.

### v6.16 — fix round 1 continuation: the author's answers A-1..A-7 (`selfcheck_v616_fix1c.py`)
BRIEF_V616 ADDENDUM 2; wspec/approvals/APPROVALS_NOAM.json V616-* (copied from regen, byte for byte).
- **A-7 room (V616-A7):** a drawing-from-words question leaves a blank drawing space of about 70 mm, at
  least 65 mm (`gate_figref.ROOM_MM` 65, `ROOM_TARGET_MM` 70; it was 40 mm), no grid and no axes, BELOW
  the question: G83 checks the declared space of the question's LAST item (>= 184.3 pt; the pilots declare
  200 pt) AND measures it ON THE PDF (`gate_figref.room_on_pdf`, run by build.py on the printed sheet from
  the build's box of that last item): the tallest ink-free band (no text, no drawing; the item's own
  dashed bottom rule is not ink) must be
  >= 65 mm. Recorded in build.json `checks.g83_room`; a FAIL fails GATES and is a verify_export error.
- **A-4 author exception (V616-A4):** `fig_ref_exception={n: ("<approved decision id>", reason)}` excuses a
  G82 reference the skill cannot draw when the AUTHOR ruled it an exception; the id must be an APPROVED
  record of the approvals file (a self-granted one is refused, also by verify_export). The build records
  `checks.g82_fig_ref` status AUTHOR_EXCEPTION and the level can be approved; it is reported as an
  exception, never as a printed figure. (G8-T30 a q8, the bar chart, until the charts stage.)
- **A-5 wording (V616-A5):** PENDING_V616 section 4 (the unnamed-sector lines) is APPROVED; the set
  44cd8fc6...9e12 is unchanged (templates.py records it); sections 1-3 still await the author.
- **A dashed LEVEL line** (horizontal or vertical) of a graph figure whose label equation ('y = 16') the
  question's own text prints is accepted by N3 (deliver) and D2 (check_didactic): a stated given line
  drawn dashed as the source draws it (G9-T06 q21; W-MATCH-ORIGINAL-MARKS). Any other dashed line is refused.
- **Number words:** a MAQAF compound 11..19 ('אחד־עשר') is one number word, and '<number word> חלקי
  <number word>' ('אחד חלקי אחד־עשר' = 1/11) one number atom whose value is the quotient; a teen written
  with a space is read as before (G8-T30 c 9ג, D-C1).
- **A pair '(2,a)'** whose other position is a variable is the point of a graph find at a given place:
  its number binds to the find's 'at' (value_at: first position; x_for_value: second) and the pair
  carries its roles (schema_bound._pair_at_of_find; G8-T15 c q1, D-PAIRVAR).
- **A-3 / A-2 / A-6** are level decisions: G8-T15 a q7 prints one ITEM figure per situation (empty
  real-life planes), G8-T15 b q2 and G9-T06 b q5 their own figures, bare point names only (no '(x, y)'
  labels), keep_questions=True stays.

### v6.16 — fix round 2: G84 NUM_CLEAR on the PDF (`selfcheck_v616_fix2.py`)
The fix-r1 print verifier (P2-S5) saw axis numbers printed 0.22-0.27 pt from a data stroke: G9-T06 q12's
dashed axis of symmetry x = 1 / 4 / 3 runs through the NUMBERED tick, and c q9's y-axis '2' sat against
y = x². The graph engine keeps 2.0 px on the number's own side when a place exists within 0.245 step of
its tick; otherwise it keeps its v6.15 placement, 1.0 px from the stroke's centre line, which prints as a
touch. Nothing measured it on the page.
- **G84 NUM_CLEAR** (`gate_numclear.py`, graph figures only: the SVG dialect wspec-graph-svg): every figure
  text glyph inside a graph figure's printed box keeps >= 0.3 pt of blank from every DATA stroke of the
  figure (a stroke >= 0.9 pt: the engine's curves are 1.0 pt; axes 0.8, ticks and guides 0.6, grid 0.35 pt
  are not; a dashed stroke counts as solid). Measured on the PDF like the verifier's clear2 (the text
  layer's glyph box trimmed to its ink band; segment distance minus half the stroke width). A graph figure
  the build cannot locate is a FAIL. build.py runs it on every level, prints it for a sheet with a graph,
  records build.json `checks.g84_num_clear` (only on such a sheet: other build.json files are unchanged),
  and a FAIL fails GATES and the exit code; verify_export reports a recorded FAIL as an error.
- **The cure is a display square** (`display={fid: {"square": N}}` of the level): at a larger square the
  number finds the 2.0 px place on its own side, still within 0.25 step of its tick. Never a dropped
  number, a cut stroke or a moved window. A square that makes the figure wider than the automatic side
  limit (210 px) may need `fig_side=True` on the question so it stays on one page (G9-T06 c q12).
- **Level fixes of this round** (pilots, not the skill): G9-T06 q12 square 19 (a, b) / 18.5 + fig_side
  (c), c q9 square 18 (at 16 the '2' cleared the curve only by stepping 12 px out of its column, past the
  parabola's arm: a square is chosen by eye on the print, not by the gate alone); G8-T15 b q14 prints an EMPTY head plane (the point A (−6, 0) of the student's claim
  in 14ד was the swapped y-intercept, a ready wrong answer above items א-ג; the corpus scores ONE figure of
  the question unit, so no item figure either).

### v6.16.1 — bounded follow-up to Codex's v6.16 review; Codex's coordinate repair merged (`selfcheck_codex_coord.py`, `selfcheck_v6161_highlight.py`, `selfcheck_v6161_situation.py`)
No third engine round; no corpus, FROZEN, SCORING or RUNNER_*.txt / RUNNER_NEEDS spec file changed (the v1 coord
runner code acceptance/tools/run_family_v612.py did change: Codex's repair); no question wording, number or answer
changed. The acceptance lock was re-pinned ONCE (fingerprint 25646269dd6f8a8e; the note in acceptance/LOCK.txt).
- **Codex's coordinate repair** (coord-from-codex-v616.zip, sha256 925251d8...; focused review without a must
  finding). `acceptance/tools/run_family_v612.py`, coord family only: a segment id is looked up in the engine's
  sorted form (seg:SL finds seg:LS; another segment still misses), and a listed place whose frozen baseline says
  drawn:false is not looked up in the figure's map. `wspec/render/coord.py`: 0.25 em is reserved under a point
  label 'Q' for the glyph's tail, in collision placement and grid knock-out; the dot never moves.
  `wspec/check/coord.py`: a gridless sketch's x and y scales are measured separately; a difference beyond 1 %
  fails AX_SCALE_CONSISTENT (before, one pooled scale was compared with itself). G7-T08 level files: b2, b8, c3
  and c11 print from the spec, with the builder's words. Their printed words, keys and answers are unchanged,
  but their public noam-ai.json fields are THINNER than v6.16's, so G7-T08's noam-ai.json is NOT unchanged from
  v6.16 (it is byte-identical to Codex's accepted build): c q11 loses the given 'axis-parallel rectangle, A and C
  opposite', B's and D's conditions in to_construct and the units of the perimeter / area targets; c q3 loses who
  wrote which pair; b q8a-c lose their targets (declared in no_target_reason). The question texts still carry
  all of it. Handed to Codex for the next coord round; G7-T08 was not changed here.
  Codex's own LOCK.txt hunks were not applied (its pin
  fingerprints its older tree). Results (Codex's acceptance; the G7-T08 PDFs, noam-ai.json and SVGs rebuilt here
  are byte-identical to Codex's build, only the version / build strings differ, so it was not rerun): v2
  161/14/0/111 and v1 164/2/0/120 of 286 (PASS / REVIEW / FAIL / UNSUPPORTED), no PASS lost, target 272 NOT met.
  Limits: in the v1 runner, 'not drawn' for the listed places of CP134-139 and CP208/209 is proven by the checker
  only (the runner's own map check cannot name such a place, and its GMC6 control is not built for these rows;
  v2's GMC6 is built and caught on the same figures). Only 'Q' gets the descender reserve ('J' descends further
  but is never printed as a label today). Some comments in G7-T08 level_b / level_c still describe q2, q8 and q3
  as held (readers only). selfcheck_codex_coord.py imports G7-T08's level_b.py from ../G7-T08 beside the skill
  (Codex's layout) or from PYTHONPATH. selfcheck_v615_runner.py is given the rebuilt G7-T08
  (`--t08 <G7-T08>/out/deliver`): its default pilot holds the v6.14 renders, whose Q label bytes the new
  renderer changes (K CPv2-052 fails there).
- **tools/highlight.py** (the reference consumer of Noam AI highlights, not the engine): a pie's overlay is
  inserted before the labels layer, or before </svg> when a pie has none (as wspec/render/pie_hl.py does), so a
  highlighted sector lies above the opaque wedges; a whole pie (data-pie 'outline') or build circle ('bcirc') is
  copied at its own radius as an unfilled 6 px stroke, so the partition stays visible; a centre dot ('bdot') gets
  a ring. Graph and geometry overlays are unchanged (byte-identical on 24,272 delivered objects; 97 pie objects
  changed, all expected). selfcheck_v6161_highlight.py: pass cases, golden outputs, planted fails (the v6.16
  outputs among them), pixel renders.
- **gate_situation.py** (new; not wired into build or verify_export): CS1_PARAM_CHANGED / CS2_LINE_CHANGED flag an
  item without its own figure that prints a new value for a parameter, or for a constant / vertical line, that
  the head figure draws. Exact, spec path, graph heads only; its limits are listed in the file.
  selfcheck_v6161_situation.py.
- **Held, not fixed:** G9-T06 a 21ג (the line y = 36) and b 21ב (p = 5) still print on the previous situation's
  figure, exactly as in v6.16. An EMPTY item plane for each is ready in the level files behind Q21C_OWN_FIGURE /
  Q21B_OWN_FIGURE, both False here: with them the frozen graph runner scores the item's own figure against the
  head's baseline (SCORING_graph s0 / RUNNER_NEEDS N2.1), so GP189 and GP255-257 turn PASS -> FAIL, while
  SCORING_graph_aaf1 A10 says an item figure is scored by its own rule. Resolving it is the author's scoring
  decision (an open amendment of those scenarios, or a documented runner reading with a re-pin and negative
  tests), never a silent corpus change. gate_situation flags exactly these two items on the delivered levels.
  Both are NOT compliant with W-FIGURE-DENSITY and are not counted as compliant. noam-ai.json still binds them to the head figure
  (figure_id q21_head): reading b 21ב's crossings off that figure gives the p = 1 answer, not the p = 5 one.
  The scoring question was put to the author in a popup on 29.9 (open amendment, recommended / documented
  runner reading / keep the hold); until then only printing the two empty planes is blocked.
- **Targeted graph acceptance** (OCR + mutations, the 206 scenarios of G9-T06 a and b: pilot, added after the
  freeze, guards): 197 PASS / 9 REVIEW / 0 FAIL of 206, identical to the v6.16 acceptance check row by check row and mutation by mutation (GP189 and GP255-257 PASS); G9-T18 run alone: 532 statuses identical to its baseline (518 PASS, 12 REVIEW, 2 UNSUPPORTED), not 532 PASS.

### v6.16.2 — the author's open amendment of GP189 / GP255-257; G9-T06 21ג / 21ב own empty planes (`selfcheck_v6162_amend.py`)

- Author decision V6161-Q21-AMEND (APPROVALS_NOAM.json 2026-09-29T06:54:08Z): "לעדכן את 4 הבדיקות בגלוי". G9-T06 a 21ג and b 21ב print their own EMPTY item planes (level_a.Q21C_OWN_FIGURE / level_b.Q21B_OWN_FIGURE = True, prepared in v6.16.1 T3). No wording, number, answer or drawing instruction changed. Display only: 21ג's plane square 10 -> 11 px (at 10 px the origin '0' sat 0.18 step from the y = -2 grid line and the frozen plane reading took it for an x number).
- Open amendment of the frozen graph scenarios GP189, GP255, GP256, GP257: `acceptance/corpus_graph/amendment_v1_1_q21.json` (one record per scenario: id, old / new expectation, why, author id, evidence crops, pinned target-scenario sha256), recorded below ADDED AFTER FREEZE in `FROZEN_graph.txt` after the byte-identical frozen prefix. The corpus in force (v1.1, 1e276dc6) is unchanged; pilot 320 / synthetic 50 / guards 90 / added 127 unchanged.
- Runner (RUNNER_V616.txt D41, `acceptance/tools/v616_amend.py`, `v616_core.verify_q21`): for exactly these four ids the head q21_head is scored against the frozen baseline as before, and the item's own figure by its own rule (an empty plane, SCORING_graph_aaf1 A10 read for them): ITEM_* checks, plus item rows in MUST_NOT_DRAW and ANSWER_NOT_EXPOSED in full force. Every other scenario is untouched.
- `selfcheck_v6162_amend.py`: FREEZE refusals, the window rule, and on the delivered G9-T06 (`--g9t06 DIR`): the real planes PASS; planted p = 1 / p = 3 curves, crossings, forbidden texts, a noam-ai point, a printed-block curve and a removed plane FAIL; non-amended scenarios unchanged.
- Results (v6.16.2 apply, v6162/APPLY_REPORT.txt): suite 70/70 (the 69 v6.16.1 files with identical counts + selfcheck_v6162_amend 40/40); targeted graph acceptance (OCR + mutations) over all 206 G9-T06 a+b scenarios: 197 PASS / 9 REVIEW / 0 FAIL = v6.16.1, no PASS lost; GP189 and GP255-257 PASS on the new expectation (head rows identical, every item row PASS); mutation outcomes and the v1.1 negative tests identical; G8-T15 / G8-T30 rebuilt byte-identical; G9-T18 532 identical statuses (518 PASS, 12 REVIEW, 2 UNSUPPORTED -- not 532 PASS); gate_situation PASS on G9-T06 a/b/c. Graph pilot 314/320 (v6.16), pie overall target NOT met (synthetic 44/55, added 44/56), coord v2 161/286, v1 164/286 (target 272 NOT met). Lock fingerprint 296503a64b439e93.

### v6.17 — the small vocabulary of the 18 packages: obtuse triangle, angle rules, exact roots, the height outside an obtuse triangle, units (`selfcheck_v617_rules.py`, `selfcheck_v617_forms.py`)

- BRIEF_V617 (the author: "כן וודאי"). Scope V1-V5 from plan18/PLAN18.json. No new sheet; no delivered wording, number or answer changed. New wording awaits the author: `wspec/PENDING_V617.txt` (template set re-pinned BY THE FIXER af847ffb...777d = the author's 44cd8fc6...9e12 + two added entries; selfcheck_v616_fix1c A5 proves it).
- V1 / V2 (`wspec/rules617.py`): relation `obtuse_triangle` (given / derived / to_prove / classify answer, measured by geomcheck and check/figure); checked rules `quadrilateral_angle_sum`, `alternate_angles`, `corresponding_angles`, `co_interior_angles`, `isosceles_converse`, `angle_bisector` (and `triangle_angle_sum` in full form): applicability, exact value, and for the parallel rules the arms' directions; interior-angle answers and a triangle's class by its angles are recomputed. `printed_by_figure`: a plane figure prints the drawn givens a bound stem announces by COUNT.
- V3 (`wspec/canon.py`, `wspec/numform.py`): one canonical exact root form (surd_tex / surd_plain); answers recomputed exactly from the spec's givens (Pythagoras at every stated right angle, triangle area with an outside height, perimeters, unit conversion); ANSWER_ROUNDED_SURD, ANSWER_RECOMPUTE_MISMATCH, APPROX_* (field `approx`, private only; REQUIRED on an irrational answer in m, km, L, min, h, ILS), BOUND_SURD_FORM.
- V4 (`wspec/render/engine.py`, `wspec/check/figure.py`): a height outside an obtuse triangle draws the base's extension dashed and the right-angle mark at the foot; RENDER_EXTENSION_MISSING / _SOLID, RENDER_BASE_DASHED, RENDER_HEIGHT_INSIDE_OBTUSE and CHK_EXT_MISSING / _SOLID, CHK_BASE_DASHED, CHK_FOOT_NO_RIGHT_MARK, CHK_HEIGHT_INSIDE_OBTUSE.
- V5 (`wspec/canon.py`): units min, h (1 h = 60 min), L, km with Hebrew aliases and printed words; BOUND_UNIT_MISMATCH; a var_value key line on the sheet prints its unit.
- Not built: named lines (G9-T15, 19 of 74 source items; HOOKS H-A2); the grade-8 unsimplified root (PENDING item 6); rates (L/min, km/h) as units; wiring the private parallel-rule steps against the drawing into the build (H-A4). G7-T10's symmetric / translated point is the coordinate-plane family (Codex).
- Results (v617/INTEGRATE_REPORT.txt): suite 72/72 rc 0, sequential and alone under the OCR lock (68 of the 70 v6.16.2 files give identical closing lines; v612_lock 118 -> 121 = the three new fingerprinted files, v616_fix1c 58 -> 61 = A5 amended; new: v617_rules 155/155, v617_forms 100/100). G9-T18 alone --expect baseline: 532 identical statuses (518 PASS, 12 REVIEW, 0 FAIL, 2 UNSUPPORTED -- not 532 PASS). Pilots G9-T06 / G8-T15 / G8-T30 / G7-T08 rebuilt without OCR: 387/387 public files byte-identical to v6.16.2's builds; sheet.json differs only in built_at and skill_version. Lock re-pinned once: fingerprint 73ba84233f8939e6 (99 files); the 173 locked acceptance files unchanged (only LOCK.txt moved).
- v6.17 FIX (2026-09-29, after the independent verify v617/verify/VERIFY_REPORT.txt; v617/INTEGRATE_REPORT.txt section 8): M1 `numform.root_issues`: a var_value answer must be a root of the equation its item (else its stem) prints as bound math (one equation, degree 1 or 2, one variable); a rounded root is ANSWER_ROUNDED_SURD, a wrong one ANSWER_RECOMPUTE_MISMATCH; no printed equation, no recompute. M2 `numform.asked_unit_issues`: ANSWER_UNIT_NOT_ASKED, an answer's unit against "כמה X" / "בX" / "לX" in its item's bound prose. S2 `templates.quantity_word_issues` + `wspec_build.expand_question`: TPL_QUANTITY_WORD_MISSING, the sheet builder refuses the approved 'compute' line for an area / perimeter target (schema.validate unchanged; PENDING_V617 item 7). S1 / S3: the fixtures print the source's sentences where the skill can; the rest is listed for the author. S4: PENDING item 6 corrected. Runs, once each: v617_forms 123/123, v617_rules 155/155, v616_fix1c 61/61, v610_lang 143, test_stage1 386, v613_prose 75/75, v612_lock 121/121; under the OCR lock v69 78, v69_fix1 46, v69_fix2 34, v69_codex 52, v610_gaps 136. The specs the skill carries as JSON files and the acceptance builds (25 JSON specs, 3 pilot conversions, 60 synthetic scenarios, 18 delivered levels): 0 differences in issues, keys and texts; the 18 levels also identical in models, SVGs and statuses. G9-T18 alone --expect baseline: 532 identical statuses (518 PASS, 12 REVIEW, 0 FAIL, 2 UNSUPPORTED -- not 532 PASS). Lock re-pinned once more: fingerprint 96e0600c204653ca (99 files); the 173 locked acceptance files unchanged.
