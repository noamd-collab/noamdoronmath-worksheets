# -*- coding: utf-8 -*-
u"""givens614.py -- v6.14-noam (BRIEF_V614 F2 + F3; Codex v6.13 §3 S-1 / S-2).

The PRINTED givens of a spec (bound-prose) question as structured claims
for Noam AI, each linked to the public spec fact(s) it restates:

  F2  axis_parallel ('AB ∥ ציר x', printed in the stem): a typed parallel
      claim {'type': 'parallel', 'of': ['AB', 'axis-x']} -- the builder's
      par() spelling -- so the figure model names its objects (both end
      points, the segment, the axis), offers it in highlight_given /
      actions.highlight, and marks it with a ∥ overlay (given_marks).
  F3  scale ('כל יחידה במערכת הצירים מייצגת 10 מטרים'): a context fact of
      rel 'scale' the stem PRINTS becomes a structured given {'type':
      'scale', 'of': [axes], 'value': 10, 'unit': 'מטרים'}; its text is the
      builder's (T08 c q6: 'כל יחידה מייצגת 250 מטרים').
  F3  a quoted calculation (bound 'calc', 7ב 'תלמיד חישב ... $6 - 6 = 0$')
      is the item's given 'חישוב התלמיד: 6 − 6 = 0' (fix_r1's wording).

Every such claim carries 'facts' -- the public spec fact ids it restates
(noam-ai.json wspec/public_spec.json). given_source_faults() is the rule
behind W-META-LINES-3 for these lines: a given restates ONLY what the
scope prints (a given / context fact the bound block prints or binds, or a
calc it binds) -- never a target, a to_prove fact or an unprinted value, so
a solution conclusion can never be injected as a given. wspec_build calls
it on every spec scope and refuses the build on a fault.

v6.14 fix_r1 (addendum 1, W-META-LINES-3 APPROVED_WITH_CONDITION): every
line in one of the three approved unprinted wordings -- 'המספר שמייצגת
הנקודה A', 'ההפרש בין הערכים של שני קווי רשת סמוכים על ציר x' (a given may
add '= <printed value>'), 'AB ∥ ציר x' -- links the ONE fact it restates
(wspec_build.claim_of); target_source_faults() refuses a target line at
build that restates anything but its own item's printed target, and
meta_line_faults() is the automatic check of the finished noam-ai.json
(deliver; selfcheck_noam_package K25 checks the same rule independently).

This module touches no binding code (textbind / wspec.schema_bound): it
READS the bound blocks the spec already carries.
"""
import re

# the builder's axis tokens (level_*.par(seg, 'x') -> 'axis-x')
AXIS_TOKEN = {"axis:x": "axis-x", "axis:y": "axis-y"}
TOKEN_AXIS = dict((v, k) for k, v in AXIS_TOKEN.items())
# a canonical scale unit -> its plural as the sheets print it
UNIT_PLURAL = {"m": u"מטרים", "km": u"קילומטרים", "cm": u"סנטימטרים",
               "mm": u"מילימטרים"}
MINUS = u"−"


class GivenError(AssertionError):
    """a printed given the module cannot state exactly"""


# ------------------------------------------------------------- scopes -----
def printed_facts(segs):
    """{fact id: how} -- every fact a scope's text PRINTS: a bound block's
    `prints`, its fact bindings, and a template segment's facts."""
    out = {}
    for sg in segs or []:
        if not isinstance(sg, dict):
            continue
        for fid in sg.get("facts") or []:
            out.setdefault(fid, "template")
        b = sg.get("bound")
        if not isinstance(b, dict):
            continue
        for fid in b.get("prints") or []:
            out.setdefault(fid, "prints")
        for bd in b.get("bind") or []:
            fx = bd.get("fact")
            for fid in (fx if isinstance(fx, list) else [fx] if fx else []):
                out.setdefault(fid, "bind")
    return out


def bound_calcs(segs):
    """[(block text, [fact ids bound before it], calc expr, token)] -- every
    quoted calculation (bind 'calc') of a scope's bound text."""
    out = []
    for sg in segs or []:
        b = sg.get("bound") if isinstance(sg, dict) else None
        if not isinstance(b, dict):
            continue
        before = []
        for bd in b.get("bind") or []:
            fx = bd.get("fact")
            if fx:
                before += fx if isinstance(fx, list) else [fx]
            if bd.get("calc"):
                out.append((b.get("text") or u"", list(before),
                            str(bd["calc"]), str(bd.get("tok"))))
    return out


# ------------------------------------------------------------- claims -----
def axis_parallel_claim(f, seg_name, text):
    """F2: the typed claim of one axis_parallel fact (seg_name: the
    segment's printed name, 'AB'). A number line's axis has no plane
    direction: its fact stays a text line."""
    args = list(f.get("args") or [])
    tok = AXIS_TOKEN.get(args[1]) if len(args) == 2 else None
    if tok is None:
        return {"text": text, "facts": [f["id"]]}
    return {"type": "parallel", "of": [seg_name, tok], "text": text,
            "facts": [f["id"]]}


def _unit_of(f, canon_unit):
    u = canon_unit(f.get("unit")) if f.get("unit") else None
    if u not in UNIT_PLURAL:
        raise GivenError(
            u"the printed scale %s has no unit the sheet names (%r): a scale "
            u"given is structured with its unit" % (f["id"], f.get("unit")))
    return u


def scale_givens(ix, segs, scope, num, canon_unit):
    """F3: the structured givens of the scale facts (rel 'scale', role
    context) the scope's text prints -- one per (value, unit), the axes it
    covers in 'of', in the order the text prints them."""
    pf = printed_facts(segs)
    groups, order = {}, []
    for fid in pf:
        f = ix.facts.get(fid) or {}
        if f.get("rel") != "scale" or f.get("item") != scope:
            continue
        u = _unit_of(f, canon_unit)
        k = (str(f.get("value")), u)
        if k not in groups:
            groups[k] = []
            order.append(k)
        groups[k].append(f)
    out = []
    for k in order:
        fs = groups[k]
        axes = [AXIS_TOKEN.get((f.get("args") or [None])[0]) for f in fs]
        if None in axes:
            raise GivenError(u"scale %s is no plane axis's scale"
                             % [f["id"] for f in fs])
        v = num(fs[0].get("value"))
        where = u"" if len(axes) == 2 else u" בציר %s" % axes[0][-1]
        out.append({"type": "scale", "of": axes, "value": v,
                    "unit": UNIT_PLURAL[k[1]],
                    "text": u"כל יחידה%s מייצגת %s %s" % (
                        where, ("%g" % float(v)) if not isinstance(v, int)
                        else v, UNIT_PLURAL[k[1]]),
                    "facts": [f["id"] for f in fs]})
    return out


def calc_givens(segs):
    """F3: a quoted calculation of the scope's bound text as its given
    ('חישוב התלמיד: 6 − 6 = 0' -- a student's work the item prints)."""
    out = []
    for text, facts, expr, tok in bound_calcs(segs):
        who = u"חישוב התלמיד" if u"תלמיד" in text else u"החישוב שבשאלה"
        shown = re.sub(r"\s*-\s*", u" %s " % MINUS, expr).strip()
        out.append({"text": u"%s: %s = %s" % (who, shown,
                                              tok.replace("-", MINUS)),
                    "facts": facts})
    return out


def _figure_datum_claim(ix, scope, claim, fact):
    from wspec import base_height as BH
    description = BH.description(fact, ix)
    return bool(fact.get("item") == scope and fact.get("role") == "given"
                and description and claim == {"text": description, "facts": [fact["id"]]})


def given_source_faults(ix, scope, segs, claims):
    """[reason] -- a given claim that carries 'facts' restates only what the
    scope prints: each fact is printed (bound prints / fact bind / template
    facts) and is a stated given or a printed context fact -- never a
    target, a to_prove / derived fact or a fact of another scope. A calc
    given's facts are the values its quoted calculation binds."""
    pf = printed_facts(segs)
    out = []
    for c in claims or []:
        if not isinstance(c, dict) or "facts" not in c:
            continue
        fl = c.get("facts")
        if not isinstance(fl, list) or not fl:
            out.append(u"%s: given %r links no public fact"
                       % (scope, c.get("text")))
            continue
        for fid in fl:
            f = ix.facts.get(fid)
            if f is None:
                out.append(u"%s: given %r names %s, no fact of the spec"
                           % (scope, c.get("text"), fid))
            elif fid not in pf and not _figure_datum_claim(ix, scope, c, f):
                out.append(u"%s: given %r restates %s, which the scope's "
                           u"text does not print" % (scope, c.get("text"),
                                                      fid))
            elif f.get("role") not in ("given", "context"):
                out.append(u"%s: given %r restates %s (role %s) -- a "
                           u"target / conclusion is never a given"
                           % (scope, c.get("text"), fid, f.get("role")))
    return out


# ------------------------------------------------ figure markings ---------
def _axis_line(rec, axis_id):
    """svg id of the axis line the engine drew for axis_id (display item
    role axis_line), or None"""
    for it in (rec.get("object_map") or {}).get("display_items") or []:
        if it.get("role") == "axis_line" and \
                (it.get("source") or {}).get("entity") == axis_id:
            els = it.get("elements") or []
            return els[0] if els else None
    return None


def _axis_object(by_id, rec, tok):
    """the model object of an axis: the engine's entity (axis:x) or the
    builder plane's recorded axis segment (seg-axis-x)"""
    if rec is not None:
        return TOKEN_AXIS[tok] if TOKEN_AXIS[tok] in by_id else None
    return ("seg-" + tok) if ("seg-" + tok) in by_id else None


def given_marks(vm, rec, toks):
    """F2 + F3 on one figure's visual_model (rec: the ENGINE figure record,
    None for a builder figure). A given parallel to an axis names its
    objects -- both end points, the segment (when drawn) and the axis -- and
    carries its ∥ overlay (mark 'parallel', on the segment's line or its end
    points, and the axis line), offered in highlight_given and
    actions.highlight: the builder's overlay (didactic.given_marks) is kept,
    an engine figure gets its own here. A scale given names the axes it
    scales (no overlay: a scale is no mark). toks: the point tokens of a
    name ('AB' -> ['A', 'B']). Returns the relation ids given an overlay."""
    objs = vm.setdefault("objects", [])
    by_id = dict((o.get("id"), o) for o in objs)
    hg = vm.setdefault("highlight_given", [])
    count = {}
    for o in objs:
        if o.get("display") == "given_highlight" and o.get("n"):
            count[o.get("mark")] = max(count.get(o.get("mark"), 0),
                                       int(o["n"]))
    added = []
    for r in vm.get("relations") or []:
        if r.get("role") != "given":
            continue
        of = r.get("of") if isinstance(r.get("of"), list) else []
        if r.get("type") == "scale":
            ax = [_axis_object(by_id, rec, x) for x in of if x in TOKEN_AXIS]
            r["objects"] = list(r.get("objects") or []) + [
                a for a in ax if a and a not in (r.get("objects") or [])]
            continue
        axis = [x for x in of if x in TOKEN_AXIS]
        segs = [x for x in of if x not in TOKEN_AXIS]
        if r.get("type") != "parallel" or len(axis) != 1 or len(segs) != 1:
            continue
        ends = toks(segs[0])
        seg = [o for o in objs if o.get("type") == "segment" and
               o.get("display") == "initial" and
               sorted(toks(o.get("name") or "")) == sorted(ends)]
        pts = [o for o in objs if o.get("type") == "point" and
               o.get("name") in ends and o.get("display") == "initial"]
        ax_obj = _axis_object(by_id, rec, axis[0])
        if ax_obj is None or (not seg and len(pts) != 2):
            raise GivenError(
                u"figure %s: the given %s ∥ %s names no drawn segment / "
                u"axis to mark" % (vm.get("id"), segs[0], axis[0]))
        want = [p["id"] for p in pts] + [s["id"] for s in seg] + [ax_obj]
        r["objects"] = list(r.get("objects") or []) + [
            x for x in want if x not in (r.get("objects") or [])]
        for x in want:
            if by_id[x].get("role") == "context":
                by_id[x]["role"] = "given"
        line = _axis_line(rec, TOKEN_AXIS[axis[0]]) if rec is not None \
            else None
        if rec is not None and line is None:
            raise GivenError(u"figure %s: no axis line of %s to mark %s ∥ "
                             u"%s on" % (vm.get("id"), axis[0], segs[0],
                                         axis[0]))
        if r.get("highlight"):
            # didactic.given_marks already made its overlay (the builder's
            # on the segment and seg-axis-*; an engine figure's on the
            # segment only): an engine overlay gains the axis line
            for o in objs:
                if o.get("id") == r["highlight"] and line and \
                        line not in (o.get("on") or []):
                    o["on"] = list(o.get("on") or []) + [line]
            continue
        on = [s["svg_id"] for s in seg if s.get("svg_id")] or \
            [p["svg_id"] for p in pts if p.get("svg_id")]
        count["parallel"] = count.get("parallel", 0) + 1
        oid = "hl-" + r["id"][2:]
        ov = {"id": oid, "svg_id": None, "type": "overlay_mark",
              "mark": "parallel", "on": on + [line], "for": r["id"],
              "role": "given", "display": "given_highlight",
              "n": count["parallel"]}
        objs.append(ov)
        r["highlight"] = oid
        if r["id"] not in hg:
            hg.append(r["id"])
        added.append(r["id"])
    act = vm.get("actions")
    if added and isinstance(act, dict) and "highlight" in act:
        act["highlight"] = list(hg)
    return added


_AXIS_TEXT = re.compile(u"∥\\s*(?:ציר|axis)")


def axis_parallel_faults(vm):
    """[reason] -- (F2, the focused check) in one visual_model, every given
    that states a segment parallel to an axis is a typed parallel relation
    whose objects hold both end points and the segment the model draws and
    the axis, offered in highlight_given and actions.highlight, with its ∥
    overlay (mark 'parallel' on the figure)."""
    out = []
    objs = vm.get("objects") or []
    by_id = dict((o.get("id"), o) for o in objs)
    hg = vm.get("highlight_given") or []
    act = (vm.get("actions") or {}).get("highlight") or []
    ov = dict((o.get("for"), o) for o in objs
              if o.get("type") == "overlay_mark")
    fid = vm.get("id")
    for r in vm.get("relations") or []:
        if r.get("role") != "given":
            continue
        of = r.get("of") if isinstance(r.get("of"), list) else []
        axis = [x for x in of if x in TOKEN_AXIS]
        if r.get("type") != "parallel":
            if _AXIS_TEXT.search(u"%s" % (r.get("text") or u"")):
                out.append(u"%s: the given %r is a text line, not a typed "
                           u"parallel relation with objects" % (
                               fid, r.get("text")))
            continue
        if len(axis) != 1:
            continue
        seg = [x for x in of if x not in TOKEN_AXIS][0]
        names = set(_TOK.findall(seg))
        have = r.get("objects") or []
        need = [o["id"] for o in objs if o.get("display") == "initial" and (
            (o.get("type") == "point" and o.get("name") in names) or
            (o.get("type") == "segment" and
             set(_TOK.findall(o.get("name") or "")) == names))]
        need += [x for x in (TOKEN_AXIS[axis[0]], "seg-" + axis[0])
                 if x in by_id]
        miss = [x for x in need if x not in have]
        if miss or not any(x in have for x in (TOKEN_AXIS[axis[0]],
                                               "seg-" + axis[0])):
            out.append(u"%s: %s names objects %s, missing %s" % (
                fid, r.get("id"), have, miss or [u"the axis"]))
        if r.get("id") not in hg or r.get("id") not in act:
            out.append(u"%s: %s is not offered in highlight_given / "
                       u"actions.highlight" % (fid, r.get("id")))
        o = ov.get(r.get("id"))
        if o is None or o.get("mark") != "parallel" or not o.get("on") or \
                o.get("display") != "given_highlight" or \
                r.get("highlight") != o.get("id"):
            out.append(u"%s: %s has no ∥ overlay mark" % (fid, r.get("id")))
    return out


_TOK = re.compile(u"[A-Z][′″']*[0-9]?")


# ------------------------------------------------ the public spec's lines --
class _PubIx(object):
    def __init__(self, pub):
        self.facts = dict((f.get("id"), f) for f in pub.get("facts") or []
                          if isinstance(f, dict))


def _pub_num(v):
    try:
        x = float(v)
    except (TypeError, ValueError):
        return v
    return int(x) if x == int(x) else x


def printed_given_lines(pub, scope):
    """(F3, for verify_export E4) the given lines wspec_build adds to a
    public-spec scope (a question or item row of wspec/public_spec.json:
    its 'bound' blocks) -- the printed scale and quoted calculations,
    regenerated from the public spec alone, so a row may carry them and
    must carry each."""
    segs = [{"bound": b} for b in scope.get("bound") or []]
    try:
        cl = scale_givens(_PubIx(pub), segs, scope.get("id"), _pub_num,
                          lambda u: u) + calc_givens(segs)
    except GivenError:
        return []
    return [c["text"] for c in cl]


# ------------------------------------------------ the noam-ai.json check --
def scale_unit_faults(noam, public_spec):
    """[reason] -- (F3, the focused check) every scale fact a bound stem
    PRINTS exists in noam-ai.json as a structured given of its scope
    (type 'scale', its value, a unit, its fact id in 'facts')."""
    facts = dict((f.get("id"), f) for f in public_spec.get("facts") or [])
    printed = {}

    def segs_of(row):
        # the public spec keeps a scope's bound blocks under 'bound'; the
        # author's spec under 'text' ({'bound': ...} segments)
        return list(row.get("text") or []) + [
            {"bound": b} for b in row.get("bound") or []]
    for q in public_spec.get("questions") or []:
        scopes = [(q.get("id"), segs_of(q))] + [
            (it.get("id"), segs_of(it)) for it in q.get("items") or []]
        for sid, segs in scopes:
            for fid in printed_facts(segs):
                if (facts.get(fid) or {}).get("rel") == "scale":
                    printed[fid] = sid
    rows = {}
    for q in noam.get("questions") or []:
        rows[q.get("id")] = q
        for it in q.get("items") or []:
            rows[it.get("id")] = it
    out = []
    for fid, sid in sorted(printed.items()):
        f = facts[fid]
        hit = [g for g in (rows.get(sid) or {}).get("given") or []
               if isinstance(g, dict) and fid in (g.get("facts") or [])]
        if not hit:
            out.append(u"%s prints the scale %s (%s %s) but its given list "
                       u"has no structured given for it" % (
                           sid, fid, f.get("value"), f.get("unit")))
            continue
        g = hit[0]
        try:
            same = float(g.get("value")) == float(f.get("value"))
        except (TypeError, ValueError):
            same = False
        if g.get("type") != "scale" or not same or not g.get("unit"):
            out.append(u"%s: the scale given %r is not structured (type "
                       u"%r, value %r, unit %r)" % (
                           sid, g.get("text"), g.get("type"),
                           g.get("value"), g.get("unit")))
    return out


# ------------------------------- W-META-LINES-3 (v6.14 fix_r1, addendum 1) --
# The author approved (APPROVALS_NOAM.json W-META-LINES-3, 25.9) three
# UNPRINTED description wordings for Noam AI --
#   'המספר שמייצגת הנקודה {n0}'                       (target_lines coordinate_nl)
#   'ההפרש בין הערכים של שני קווי רשת סמוכים על ציר {n0}'  (interval_value_grid,
#        and its plain phrase '... = {v}' as a given line)
#   '{n0} ∥ ציר {n1}'                                 (phrase axis_parallel)
# -- on a CONDITION: such a line only restates a given or a target the
# question already prints, linked to its source id, and never adds a hint, a
# missing value or a solution conclusion. The lines are found by their
# WORDING (META_ANY), so a line that lost its link, gained a word or a value
# is still found; meta_line_faults() is the automatic check.
META_ANY = re.compile(u"שמייצגת הנקודה|קווי רשת סמוכים|∥\\s*(?:ציר|axis)")
_PNAME = u"[A-Z][′″']*[0-9]?"
META_FORMS = (
    ("nl", re.compile(u"^המספר שמייצגת הנקודה (?P<n>%s)$" % _PNAME)),
    ("grid", re.compile(u"^ההפרש בין הערכים של שני קווי רשת סמוכים על ציר "
                        u"(?P<ax>[xy])(?: = (?P<v>-?[0-9]+(?:\\.[0-9]+)?))?$")),
    ("par", re.compile(u"^(?P<seg>(?:%s){2}) ∥ (?:ציר (?P<ax>[xy])|"
                       u"axis-(?P<ax2>[xy]))$" % _PNAME)),
)
META_REL = {"nl": "coordinate", "grid": "interval_value",
            "par": "axis_parallel"}
# the keys a meta line may carry: its text and its link (a ∥ given also its
# typed form) -- a value, unit or anything else is never part of it
_META_KEYS = {"nl": ("text", "facts"), "grid": ("text", "facts"),
              "par": ("text", "facts", "type", "of")}
# a builder question (no public spec scope) prints its parallelism in words
_PAR_PRINTED = re.compile(u"מקביל\\S*\\s+ל(?:ציר|צירים)")


def is_meta_line(text):
    return isinstance(text, str) and bool(META_ANY.search(text))


def meta_form(text):
    """(form, match) of an approved meta wording, or (None, None)"""
    for k, rx in META_FORMS:
        m = rx.match(text or u"")
        if m:
            return k, m
    return None, None


def _frac(v):
    from fractions import Fraction
    try:
        return Fraction(str(v).strip())
    except (ValueError, ZeroDivisionError):
        return None


def _scope_printed(sc):
    """fact ids the public-spec scopes sc print (bound prints + binds)"""
    return set(printed_facts([{"bound": b} for s in sc
                              for b in s.get("bound") or []]))


def _row_text(q, row):
    def flat(t):
        return u" ".join(t) if isinstance(t, list) else (t or u"")
    return flat(q.get("text")) + (u" " + flat(row.get("text"))
                                  if row is not q else u"")


def _meta_claim_faults(c, key, sc, q, row, facts, ents):
    """[reason] for one claim in a meta wording (row: a noam-ai.json row;
    sc: the public-spec scopes the row shows, [] for a builder row)"""
    if not isinstance(c, dict):
        return [u"a plain string, not a claim linked to its source id"]
    t = c.get("text")
    form, m = meta_form(t)
    if form is None:
        return [u"is not an approved W-META-LINES-3 wording exactly (a word,"
                u" a value or a hint was added)"]
    if key not in ("given", "to_prove"):
        return [u"a W-META-LINES-3 line in %s: it restates a given or a "
                u"target only" % key]
    if not sc:
        # a builder row: no public spec, no fact to link. Only the ∥ given
        # may stand there, restating the parallelism its question prints
        if form != "par":
            return [u"the row has no public spec scope: the line has no "
                    u"source id to restate"]
        out = []
        ax = m.group("ax") or m.group("ax2")
        if c.get("type") != "parallel" or \
                c.get("of") != [m.group("seg"), "axis-" + ax]:
            out.append(u"is not the typed parallel {of: [%s, axis-%s]}"
                       % (m.group("seg"), ax))
        extra = sorted(set(c) - set(("text", "type", "of")))
        if extra:
            out.append(u"carries %s beyond its wording" % extra)
        if key != "given":
            out.append(u"a ∥ line is a given, never a %s" % key)
        if not _PAR_PRINTED.search(_row_text(q, row)):
            out.append(u"its question prints no parallelism to an axis for"
                       u" it to restate")
        return out
    out = []
    extra = sorted(set(c) - set(_META_KEYS[form]))
    if extra:
        out.append(u"carries %s beyond its wording and link" % extra)
    fl = c.get("facts")
    if not isinstance(fl, list) or not fl:
        return out + [u"links no source fact (facts)"]
    if len(fl) != 1:
        return out + [u"links %d facts: a line restates exactly one" % len(fl)]
    fid = fl[0]
    f = facts.get(fid)
    if f is None:
        return out + [u"names %s, no fact of the public spec" % fid]
    ids = [s.get("id") for s in sc]
    if f.get("item") not in ids:
        out.append(u"restates %s, a fact of %s, not of this row (%s)"
                   % (fid, f.get("item"), "/".join(ids)))
    if fid not in _scope_printed(sc):
        out.append(u"restates %s, which the question does not print" % fid)
    role = f.get("role")
    if key == "given" and role not in ("given", "context"):
        out.append(u"restates %s (role %s): a target or a conclusion is "
                   u"never a given" % (fid, role))
    if key == "to_prove" and role != "target" and not (role == "to_prove" and f.get("rel") == "axis_parallel"):
        out.append(u"restates %s (role %s): a to_prove line restates the "
                   u"target its item asks" % (fid, role))
    if f.get("rel") != META_REL[form]:
        out.append(u"its wording is a %s line, the fact %s is %s"
                   % (META_REL[form], fid, f.get("rel")))
        return out
    args = list(f.get("args") or [])
    name = lambda a: (ents.get(a) or {}).get("name") or u"".join(
        (ents.get(a) or {}).get("ends") or [])
    if form == "nl":
        if len(args) != 2 or name(args[0]) != m.group("n") or \
                name(args[1]) in ("x", "y"):
            out.append(u"names point %s on a number line, the fact %s says "
                       u"%s" % (m.group("n"), fid, args))
    elif form == "grid":
        if not args or args[0] != "axis:" + m.group("ax"):
            out.append(u"names axis %s, the fact %s says %s"
                       % (m.group("ax"), fid, args))
        v = m.group("v")
        if v is not None and key == "to_prove":
            out.append(u"a target line carries the value %s (the answer)" % v)
        elif v is not None and (_frac(v) is None or
                                _frac(v) != _frac(f.get("value"))):
            out.append(u"states the value %s, the printed given %s is %s"
                       % (v, fid, f.get("value")))
    else:
        ax = m.group("ax")
        if ax is None:
            out.append(u"spells the axis 'axis-%s': the approved wording is "
                       u"'ציר %s'" % (m.group("ax2"), m.group("ax2")))
            ax = m.group("ax2")
        if len(args) != 2 or sorted(name(args[0])) != sorted(m.group("seg"))\
                or args[1] != "axis:" + ax:
            out.append(u"states %s ∥ %s, the fact %s says %s"
                       % (m.group("seg"), ax, fid, args))
        if c.get("type") != "parallel" or \
                c.get("of") != [m.group("seg"), "axis-" + ax]:
            out.append(u"is not the typed parallel {of: [%s, axis-%s]}"
                       % (m.group("seg"), ax))
    # the public side of the same scope says exactly this line
    if key == "to_prove":
        desc = [tg.get("description") for s in sc
                for tg in s.get("targets") or [] if tg.get("id") == fid]
        if desc != [t]:
            out.append(u"is not the public spec's description of %s (%s)"
                       % (fid, desc))
    elif t not in [x for s in sc for x in s.get("given_lines") or []]:
        out.append(u"is not a given line of the public spec's scope %s"
                   % "/".join(ids))
    return out


def meta_line_faults(noam, pub):
    """[reason] -- (W-META-LINES-3, the automatic check) every line of
    noam-ai.json in an approved meta wording -- a given / to_prove claim of
    a question or an item, and the visual_model relation that repeats it --
    restates ONE printed given or target of its own row: it links the
    public spec fact id (facts), the fact belongs to the row and the row's
    bound text prints it, a given line restates a given / context fact and
    is one of the scope's public given_lines (its value, if any, the
    printed value), a to_prove line restates the item's target and is its
    public description, and the wording is exact (no word, value or key
    added). pub: wspec/public_spec.json, None for a builder level (a
    builder row may carry only the typed ∥ given its question prints)."""
    pub = pub or {}
    facts = dict((f.get("id"), f) for f in pub.get("facts") or []
                 if isinstance(f, dict))
    es = pub.get("entities") or []
    ents = dict(es.items()) if isinstance(es, dict) else dict(
        (e.get("id"), e) for e in es if isinstance(e, dict))
    scopes = {}
    for pq in pub.get("questions") or []:
        scopes[pq.get("id")] = pq
        for it in pq.get("items") or []:
            scopes[it.get("id")] = it
    out, rows = [], {}
    # H-B2 source-linked diagram data: exact semantic projection, with
    # source geometry/value facts retained in the public spec.
    from wspec import base_height as BH
    from wspec import schema as WS
    bix = WS.Index(pub)
    bh_ids = set()
    for fg in pub.get("figures") or []:
        dec = fg.get("base_height") or {}
        bh_ids.update(dec.get(k) for k in ("base", "height", "perpendicular", "extension") if isinstance(dec.get(k), str))
    for q in noam.get("questions") or []:
        for row in [q] + list(q.get("items") or []):
            for claim in row.get("given") or []:
                if not isinstance(claim, dict) or not bh_ids.intersection(claim.get("facts") or []):
                    continue
                linked = claim.get("facts") or []
                f = facts.get(linked[0]) if len(linked) == 1 else None
                if not f or not _figure_datum_claim(bix, row.get("id"), claim, f):
                    out.append("%s: base/height diagram claim is not its exact source projection" % row.get("id"))
    for q in noam.get("questions") or []:
        mine = set(it.get("id") for it in q.get("items") or [])
        pq = scopes.get(q.get("id"))
        for row in [q] + list(q.get("items") or []):
            rid = row.get("id")
            rows[rid] = (q, row)
            if row is q:
                # a stem item (no row of its own) shows in its question
                sc = ([pq] + [it for it in pq.get("items") or []
                              if it.get("id") not in mine]) if pq else []
            else:
                sc = [scopes[rid]] if rid in scopes else []
            for key in ("given", "to_prove", "to_construct"):
                for c in row.get(key) or []:
                    t = c.get("text") if isinstance(c, dict) else c
                    if not is_meta_line(t):
                        continue
                    out += [u"%s %s %r: %s" % (rid, key, t, w) for w in
                            _meta_claim_faults(c, key, sc, q, row, facts,
                                               ents)]
    for F in noam.get("figures") or []:
        vm = (F or {}).get("visual_model") or {}
        qid = vm.get("question") or F.get("question")
        for r in vm.get("relations") or []:
            t = r.get("text")
            if not is_meta_line(t):
                continue
            key = r.get("role")
            if key not in ("given", "to_prove"):
                out.append(u"%s relation %s %r: a W-META-LINES-3 line as a "
                           u"%s relation" % (F.get("id"), r.get("id"), t, key))
                continue
            # a relation of an item names it; one of a stem item (no row
            # of its own) or of the question is stated on the question row
            cand = [r["item"]] if r.get("item") in rows else [qid] + [
                it.get("id") for it in (rows.get(qid) or ({}, {}))[0]
                .get("items") or []]
            # the row's claim of the same wording is checked above
            if not any(isinstance(c, dict) and c.get("text") == t
                       for x in cand for c in
                       (rows.get(x) or ({}, {}))[1].get(key) or []):
                out.append(u"%s relation %s %r restates no linked %s line "
                           u"of %s" % (F.get("id"), r.get("id"), t, key,
                                       "/".join(str(x) for x in cand)))
    return out


def target_source_faults(ix, scope, segs, claims):
    """[reason] -- (W-META-LINES-3, at build) a to_prove claim that links
    facts restates the target its own scope's text asks: each fact is a
    target of this scope that the text prints (bound prints / template
    facts) -- never a given, an answer or another scope's target."""
    pf = printed_facts(segs)
    out = []
    for c in claims or []:
        if not isinstance(c, dict) or "facts" not in c:
            if isinstance(c, dict) and is_meta_line(c.get("text")):
                out.append(u"%s: target line %r links no source fact"
                           % (scope, c.get("text")))
            continue
        for fid in c.get("facts") or [None]:
            f = ix.facts.get(fid) if fid else None
            if f is None:
                out.append(u"%s: target line %r names %s, no fact of the "
                           u"spec" % (scope, c.get("text"), fid))
            elif (f.get("role") != "target" and not (f.get("role") == "to_prove" and f.get("rel") == "axis_parallel")) or f.get("item") != scope:
                out.append(u"%s: target line %r restates %s (role %s, of %s)"
                           u" -- a to_prove line restates its own target"
                           % (scope, c.get("text"), fid, f.get("role"),
                              f.get("item")))
            elif fid not in pf:
                out.append(u"%s: target line %r restates %s, which the "
                           u"scope's text does not print"
                           % (scope, c.get("text"), fid))
    return out
