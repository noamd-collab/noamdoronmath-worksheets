#!/usr/bin/env python3
"""G45 + G46 — render-integrity gates on the FINAL PDF.

Both exist because five shipped packages (35-39, Aug 2026) passed every gate in
this skill and were still wrong:

G45 (body-font identity). G43-F5 only asked for ">=1 embedded Hebrew-capable
font" and named FreeSerif as acceptable. Packages 36-39 shipped with the ENTIRE
body in FreeSerif and David Libre present on just 3 spans per page (בס״ד + two
brand lines) — so F5 passed on the strength of the running head alone. A font
gate must assert WHICH font carries the body, not that some Hebrew font exists.

G46 (figure placement). A figure that is emitted but drawn off-page is invisible
to every count-based check. A `float:left` figure inside an RTL flex item
rendered at bbox=[0, 218, -294, 341] — negative width, off the left edge —
while the page still reserved its space, so the sheet showed a white hole and
the image count matched exactly. Count presence AND geometry.

Usage:  python3 check_render_integrity.py built.pdf [--src original.pdf]
        python3 check_render_integrity.py --selftest
"""
import subprocess
import sys

PAGE_W, PAGE_H = 595.28, 841.89
HOUSE_BODY = ("david libre", "david-libre", "davidlibre")
# Fallback faces that are fine for a stray symbol but must never carry the body.
SYMBOL_ONLY = ("dejavu", "freeserif", "notosans", "wenquanyi", "helvetica")


def _fonts(pdf):
    try:
        out = subprocess.run(["pdffonts", str(pdf)], capture_output=True,
                             text=True, check=True).stdout
    except Exception:
        return None
    names = []
    for line in out.splitlines()[2:]:
        if line.strip():
            names.append(line.split()[0].split("+")[-1])
    return names


# Glyphs a Hebrew serif legitimately lacks. A span made only of these is a
# DELIBERATE pin, not a fallback accident, and must not count against the body.
SYM_CHARS = set("\u2605\u2221\u00b0\u2190\u2192\u00b1\u2264\u2265\u00f7"
                "\u2212\u221a\u2248\u2260")


def _spans_by_font(pdf):
    """Map font-name -> number of CHARACTERS carried, ignoring spans that
    consist solely of pinned symbols. Characters, not spans: wrapping each
    symbol in its own <span> inflates a span count and would make a correctly
    pinned sheet look like a fallback leak."""
    import pymupdf
    tally = {}
    doc = pymupdf.open(str(pdf))
    for page in doc:
        for blk in page.get_text("dict")["blocks"]:
            if blk["type"] != 0:
                continue
            for line in blk["lines"]:
                for sp in line["spans"]:
                    txt = sp["text"].strip()
                    if not txt or all(c in SYM_CHARS for c in txt):
                        continue
                    name = sp["font"].split("+")[-1]
                    tally[name] = tally.get(name, 0) + len(txt)
    return tally


def g45_body_font(pdf):
    """FAIL unless the modal Hebrew-bearing font is David Libre."""
    fails = []
    tally = _spans_by_font(pdf)
    if not tally:
        return ["G45: no text spans found — extraction or build is broken"]
    body, n = max(tally.items(), key=lambda kv: kv[1])
    total = sum(tally.values())
    if not any(h in body.lower() for h in HOUSE_BODY):
        fails.append("G45: body font is %r (%d/%d chars), expected David Libre"
                     % (body, n, total))
    # A symbol-only face carrying a real share of the text is the same defect
    # wearing a different hat (e.g. WenQuanYi picked up as a ★ fallback and
    # then quietly used for prose).
    for name, cnt in tally.items():
        if cnt > max(20, 0.05 * total) and any(s in name.lower() for s in SYMBOL_ONLY):
            fails.append("G45: fallback face %r carries %d/%d chars of prose — "
                         "pin the glyph it was pulled in for to an explicit "
                         "family, or render it as a math path"
                         % (name, cnt, total))
    return fails


def _figure_candidate(rect):
    """A vector drawing large enough to be worksheet figure evidence.

    WeasyPrint keeps inline SVG as vector paths, not image blocks.  The former
    G46 only counted raster blocks, so a vector-only worksheet could report
    zero figures and still pass.  Thin page rules are excluded by requiring
    meaningful extent in both dimensions.
    """
    x0, y0, x1, y1 = tuple(rect)
    return x1 - x0 >= 24 and y1 - y0 >= 12


def _rects_touch(first, second, pad=1.0):
    a0, b0, a1, b1 = tuple(first)
    x0, y0, x1, y1 = tuple(second)
    return (min(a1, x1) + pad >= max(a0, x0)
            and min(b1, y1) + pad >= max(b0, y0))


def g46_figures(pdf, src=None, level=None):
    """Every declared figure must leave visible, on-page output evidence."""
    import pymupdf
    fails = []
    placed = []
    vectors = []
    vector_marks = []
    proof_boxes = {}
    page_sizes = {}
    document = pymupdf.open(str(pdf))
    for page in document:
        page_sizes[page.number + 1] = (page.rect.width, page.rect.height)
        for blk in page.get_text("dict")["blocks"]:
            if blk["type"] != 1:
                continue
            x0, y0, x1, y1 = blk["bbox"]
            placed.append((page.number + 1, blk["bbox"]))
            if x1 <= x0 or y1 <= y0:
                fails.append("G46: p%d figure has non-positive size %s — a "
                             "mirrored/negative CTM draws it off-canvas"
                             % (page.number + 1, [round(v) for v in blk["bbox"]]))
            elif x0 < -1 or y0 < -1 or x1 > PAGE_W + 1 or y1 > PAGE_H + 1:
                fails.append("G46: p%d figure outside the page box %s"
                             % (page.number + 1, [round(v) for v in blk["bbox"]]))
        for drawing in page.get_drawings():
            rect = drawing["rect"]
            vector_marks.append((page.number + 1, tuple(rect)))
            if not _figure_candidate(rect):
                continue
            vectors.append((page.number + 1, tuple(rect)))
            x0, y0, x1, y1 = tuple(rect)
            if x1 <= x0 or y1 <= y0:
                fails.append("G46: p%d vector figure has non-positive size %s"
                             % (page.number + 1, [round(v) for v in rect]))
            elif (x0 < -1 or y0 < -1 or x1 > page.rect.width + 1
                  or y1 > page.rect.height + 1):
                fails.append("G46: p%d vector figure outside the page box %s"
                             % (page.number + 1, [round(v) for v in rect]))
        for link in page.get_links():
            destination = str(link.get("nameddest") or "")
            if not destination.startswith("fig-proof-target-"):
                continue
            rect = tuple(link["from"])
            key = (page.number + 1, destination)
            if key in proof_boxes:
                old = proof_boxes[key]
                rect = (min(old[0], rect[0]), min(old[1], rect[1]),
                        max(old[2], rect[2]), max(old[3], rect[3]))
            proof_boxes[key] = rect
    document.close()
    proofs = [(page, rect) for (page, _destination), rect
              in sorted(proof_boxes.items())]
    for page_number, rect in proofs:
        x0, y0, x1, y1 = rect
        width, height = page_sizes[page_number]
        if x1 <= x0 or y1 <= y0:
            fails.append("G46: p%d figure proof has non-positive size %s"
                         % (page_number, [round(v) for v in rect]))
        elif (x0 < -1 or y0 < -1 or x1 > width + 1 or y1 > height + 1):
            fails.append("G46: p%d figure proof outside the page box %s"
                         % (page_number, [round(v) for v in rect]))
    expected = sum(bool(question.get("fig"))
                   for question in (level or {}).get("questions", []))
    if expected and len(proofs) != expected:
        fails.append("G46: figure-proof count %d != %d declared figures"
                     % (len(proofs), expected))
    for page_number, proof in proofs:
        evidence = ([rect for page, rect in placed if page == page_number]
                    + [rect for page, rect in vector_marks
                       if page == page_number])
        if not any(_rects_touch(proof, rect) for rect in evidence):
            fails.append("G46: p%d declared figure has no raster/vector ink "
                         "inside its proof box" % page_number)
    if src is not None:
        n_src = sum(1 for page in pymupdf.open(str(src))
                    for blk in page.get_text("dict")["blocks"] if blk["type"] == 1)
        if n_src != len(placed):
            fails.append("G46: figure count %d != source %d" % (len(placed), n_src))
    return fails


def check(pdf, src=None, level=None):
    return g45_body_font(pdf) + g46_figures(pdf, src, level)


def _selftest():
    """Both directions: the gates must FIRE on the known-bad shapes and stay
    quiet on the known-good ones. No live PDF needed — the predicates are
    exercised directly."""
    ok = True

    good = {"David-Libre": 300, "David-Libre-Bold": 120, "DejaVu-Serif": 3}
    bad = {"FreeSerif": 293, "FreeSerif-Bold": 142, "DavidLibre-Regular": 24}

    def body_of(t):
        return max(t.items(), key=lambda kv: kv[1])[0]

    if not any(h in body_of(good).lower() for h in HOUSE_BODY):
        print("SELFTEST FAIL: good font tally rejected"); ok = False
    if any(h in body_of(bad).lower() for h in HOUSE_BODY):
        print("SELFTEST FAIL: pkg36-39 font tally accepted"); ok = False

    boxes = {"good": (50, 232, 182, 340), "shipped_bug": (0, 218, -294, 341)}
    for name, (x0, y0, x1, y1) in boxes.items():
        broken = x1 <= x0 or y1 <= y0 or x0 < -1 or x1 > PAGE_W + 1
        if name == "good" and broken:
            print("SELFTEST FAIL: valid figure bbox rejected"); ok = False
        if name == "shipped_bug" and not broken:
            print("SELFTEST FAIL: off-page figure bbox accepted"); ok = False
    if not _figure_candidate((50, 232, 182, 340)):
        print("SELFTEST FAIL: vector figure evidence rejected"); ok = False
    if _figure_candidate((20, 300, 550, 300.7)):
        print("SELFTEST FAIL: page rule counted as vector figure"); ok = False

    print("SELFTEST PASS" if ok else "SELFTEST FAILED")
    return 0 if ok else 1


if __name__ == "__main__":
    if "--selftest" in sys.argv:
        sys.exit(_selftest())
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    src = None
    if "--src" in sys.argv:
        src = sys.argv[sys.argv.index("--src") + 1]
        args = [a for a in args if a != src]
    problems = check(args[0], src)
    for p in problems:
        print(p)
    print("G45/G46: %s" % ("FAIL" if problems else "PASS"))
    sys.exit(1 if problems else 0)
