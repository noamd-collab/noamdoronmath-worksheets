# -*- coding: utf-8 -*-
u"""gate_figref -- v6.16 (fix round 1). G82 FIG_REF and G83 FIG_DENSITY.

WHY THIS FILE EXISTS
--------------------
The author looked at the v6.16 preview and said (W-FIGURE-DENSITY, APPROVALS
2026-09-26T23:58:51Z; BRIEF_V616 ADDENDUM 1):

    "יש מעט מידי שירטוטים לשאלות... איפלו לסעיפים"

A pie sheet drew in 1 of 20 questions, a linear-function sheet in 5 of 20,
and 31 questions said 'בעוגה' / 'הגרף' / 'השרטוט' with NO figure. Nothing in
the skill measured either: G75-G77 count drawings only on a "figure sheet",
and a sheet with less than 40% drawn was, by that very measurement, not one.

THE RULE (binding)
  1. On a FIGURE TOPIC every question gets a figure; a sub-item whose
     situation differs gets its own; where a full figure would reveal the
     answer only the givens are drawn, or an empty plane / circle.
  2. DRAWING FROM WORDS: exactly round(15%) of level a's questions,
     round(20%) of level b's and round(10%) of excellence's have NO figure,
     give all their data in words, never refer to a figure, and leave room
     to draw.
  3. A question that refers to a figure MUST have it ("a missing one is a
     FAIL, never allowed"). Whether a sheet is a figure sheet comes from
     the TOPIC or an explicit declaration, never from measured coverage.

THE TWO GATES
  G82 FIG_REF (every sheet, every topic)
      a question whose stem holds a figure-REFERENCE word has a figure:
      its head figure, or every one of its items has its own; an item that
      holds one has its own figure or its question's head figure.
      A reference word points at a figure ON THE PAGE (REF_TOKENS: 'בעוגה',
      'הגרף', 'בשרטוט', 'שלפניכם', ...); the noun of a chart TYPE ('עוגה',
      'דיאגרמת עמודות') and an instruction to draw ('שרטטו את הגרף') or
      not to ('בלי שרטוט') are not references. A reference the skill
      cannot draw yet is DECLARED for the author, fig_ref_pending={n:
      reason}: the level is built and NOT APPROVED (build.py GATES,
      build.json checks.g82_fig_ref, verify_export G82) -- never done.
      When the AUTHOR has decided such a question is an exception, the
      level declares fig_ref_exception={n: (decision id, reason)}: the
      decision id must be an APPROVED record of the author's approvals file
      (wspec/approvals/APPROVALS_NOAM.json; G8-T30 a q8 = V616-A4, the bar
      chart that comes in the charts stage). The build RECORDS it
      (build.json checks.g82_fig_ref status AUTHOR_EXCEPTION, one row per
      question with the decision) and the level can be approved; it is
      reported as an exception, never as a figure that is there.
  G83 FIG_DENSITY (a FIGURE TOPIC, unless the topic is a pre-rule pilot)
      * the level DECLARES its drawing-from-words share: words_share =
        {n: reason} (or a list of n); size = round(share x questions) +- 1
        (share a 15%, b 20%, excellence 10%; the questions printed as
        questions -- a local-limit placeholder with no stem and no item is
        not one);
      * a member draws nothing, prints no reference word, and leaves room
        to draw BELOW it: its LAST item (or the question) reserves >= ROOM_MM
        of writing space (V616-A7, the author 2026-09-27: "a blank drawing
        space of about 70 mm (at least 65 mm) under each drawing-from-words
        question, with no grid and no axes" -- ROOM_TARGET_MM 70, ROOM_MM
        65; it was 40 mm before the author's answer);
      * the same room MEASURED ON THE PDF (room_on_pdf, run by build.py on
        the printed sheet): inside the question's LAST item box (WeasyPrint's
        layout, the build's text_binding blocks) the tallest band with no
        ink -- no text, no drawing, so no grid and no axes; the item's own
        dashed bottom rule closes the band -- is >= ROOM_MM (build.json
        checks.g83_room; a FAIL fails the build's GATES and verify_export);
      * every OTHER question carries a figure (head or item) -- or prints
        the source's value TABLE as its data (a table question, reported).
      G83 replaces G77's question / sub-item floors on the levels it
      governs (gate_variety.assert_visual_density): the author gives a
      sub-item its own figure when its situation differs, not on a 90%
      quota.

THE FIGURE-TOPIC STATUS (topic_status), in this order -- never a count:
  1. the level's explicit declaration figure_topic = True | False |
     (bool, reason) -- a False needs its reason and is printed;
  2. the package id (L["package"], else the build's content.py PACKAGE,
     read by build_plus) in figure_topics.json (the 140 site topics of
     P/plan18/inventory.json, kind figure | algebra);
  3. the tashpaz unit of curriculum.topic, when every site topic of that
     unit has one kind (figure_topics.json "units");
  4. otherwise UNKNOWN: G83 does not run and the build says so.
  A package in figure_topics.json "pre_rule_pilots" (G7-T01, G7-T08,
  G9-T18: regression pilots under frozen corpora, ADDENDUM 1 rule 4) is a
  figure topic whose G83 is DEFERRED -- printed on every build; G82 runs.

HOW IT RUNS
  build_plus.py installs it (after gate_variety): it wraps
  emit_html.assert_figure_variety, so both gates fire inside build_html on
  every level, after G75-G78. A failure raises AssertionError naming the
  question, the word and the rule.
"""
import ast
import json
import math
import os
import re

__all__ = ["REF_TOKENS", "SHARE", "ROOM_MM", "ROOM_PT", "topic_status",
           "PENDING", "fig_ref_pending", "EXCEPTIONS", "fig_ref_exception",
           "ROOM_TARGET_MM", "room_on_pdf",
           "refs", "fig_ref_report", "assert_fig_ref", "density_report",
           "assert_fig_density", "governs", "install", "package_of"]

HERE = os.path.dirname(os.path.abspath(__file__))
TOPICS_FILE = os.path.join(HERE, "figure_topics.json")

# the words that point at a figure ON THE PAGE. The first line is the frozen
# pie corpus' list (acceptance/corpus_pie/AAF1_pie.json reference_words); the
# rest are the same deixis in the forms the graph and geometry sheets print
REF_TOKENS = frozenset([
    u"בעוגה", u"בעוגות", u"בתרשים", u"התרשים", u"לתרשים", u"לתרשימים",
    u"תרשימי", u"בתרשימים", u"בציור", u"הציור", u"בשרטוט", u"השרטוט",
    u"הגרף", u"בגרף", u"שלפניכם", u"שלפניך", u"בדיאגרמה", u"שבציור",
    # graph / geometry deixis
    u"שבשרטוט", u"שבגרף", u"שבתרשים", u"שבעוגה", u"שבדיאגרמה", u"הגרפים",
    u"בגרפים", u"שבגרפים", u"לגרף", u"מהגרף", u"מהשרטוט", u"מהתרשים",
    u"מהעוגה", u"מהציור", u"לשרטוט", u"בסרטוט", u"הסרטוט", u"שבסרטוט",
    u"מהסרטוט", u"המשורטט", u"המשורטטת", u"המשורטטים", u"המשורטטות",
    u"המסורטט", u"המסורטטת", u"המסורטטים", u"שלפניכן", u"שלפנייך",
    u"התרשימים", u"העוגות"])
# 'העוגה' (the chart TYPE: 'מה העוגה מראה טוב יותר') is not a reference,
# as the frozen pie corpus rules (generic_nouns_allowed); 'העוגות' is the
# plural deixis 'the pies' ('האם העוגות ייראו זהות') and is one
NEGATION = frozenset([u"בלי", u"ללא"])
DRAW_VERBS = frozenset([u"שרטטו", u"סרטטו", u"שרטט", u"סרטט", u"שרטטי",
                        u"סרטטי", u"ציירו", u"צייר", u"ציירי", u"בנו",
                        u"בנה", u"בני", u"הוסיפו", u"השלימו"])
PUNCT = u".,:;?!״\"'()[]{}–-—׳…"

SHARE = {"a": 0.15, "b": 0.20, "c": 0.10}
SHARE_TOLERANCE = 1
# V616-A7 (APPROVALS_NOAM.json, the author 2026-09-27T18:17:09Z): "a blank
# drawing space of about 70 mm (at least 65 mm) under each drawing-from-words
# question, no grid and no axes; measure it on the PDF". (It was 40 mm.)
ROOM_MM = 65.0
ROOM_TARGET_MM = 70.0
ROOM_PT = ROOM_MM * 72.0 / 25.4          # 184.3 pt of blank room
APPROVALS_FILE = os.path.join(HERE, "wspec", "approvals",
                              "APPROVALS_NOAM.json")
LOCAL_LIMIT_TITLE = u"מגבלה מקומית"

_TOPICS = None
_PACKAGE = [None]          # the build's content.py PACKAGE (build_plus)


def topics():
    global _TOPICS
    if _TOPICS is None:
        with open(TOPICS_FILE, encoding="utf-8") as fh:
            _TOPICS = json.load(fh)
    return _TOPICS


def package_of(content_py):
    """The PACKAGE = "..." of a content.py, read without running it (None
    when there is none)."""
    try:
        with open(str(content_py), encoding="utf-8") as fh:
            tree = ast.parse(fh.read())
    except (OSError, SyntaxError, ValueError):
        return None
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(
                isinstance(t, ast.Name) and t.id == "PACKAGE"
                for t in node.targets):
            v = node.value
            if isinstance(v, ast.Constant) and isinstance(v.value, str):
                return v.value
    return None


# ------------------------------------------------------ figure-topic status
def topic_status(L, package=None):
    """{"figure": True | False | None, "source": str, "deferred": reason |
    None, "package": id | None} -- from the topic or a declaration, NEVER
    from how many questions carry a drawing."""
    pkg = L.get("package") or package or _PACKAGE[0]
    T = topics()
    if "figure_topic" in L:
        v = L["figure_topic"]
        why = None
        if isinstance(v, (tuple, list)):
            if len(v) != 2 or not isinstance(v[0], bool):
                raise AssertionError(
                    "G83: figure_topic is True, False or (bool, reason), not "
                    "%r" % (v,))
            v, why = v
        if not isinstance(v, bool):
            raise AssertionError("G83: figure_topic is True, False or (bool, "
                                 "reason), not %r" % (v,))
        if v is False and not str(why or "").strip():
            raise AssertionError(
                "G83: figure_topic=False needs its reason -- (False, "
                "u'<why this sheet is not a figure topic>'): the status comes "
                "from the topic, and a declaration against it is printed")
        return dict(figure=v, source="declared%s" % (
            (": " + str(why)) if why else ""), deferred=None, package=pkg)
    if pkg and pkg in T.get("pre_rule_pilots", {}):
        return dict(figure=True, source="topic %s (figure)" % pkg,
                    deferred=T["pre_rule_pilots"][pkg], package=pkg)
    if pkg and pkg in T["figure"]:
        return dict(figure=True, source="topic %s (figure)" % pkg,
                    deferred=None, package=pkg)
    if pkg and pkg in T["algebra"]:
        return dict(figure=False, source="topic %s (algebra)" % pkg,
                    deferred=None, package=pkg)
    unit = (L.get("curriculum") or {}).get("topic")
    kind = T.get("units", {}).get(unit) if unit else None
    if kind in ("figure", "algebra"):
        dfr = None
        if kind == "figure" and not pkg:
            # (a level with no package id may BE a pre-rule pilot of its
            # unit: deferred, and the build says to declare PACKAGE)
            pil = sorted(p for p, u in (T.get("pilot_units") or {}).items()
                         if u == unit)
            if pil:
                dfr = ("no package id, and tashpaz unit %s holds the "
                       "pre-rule pilot(s) %s -- declare PACKAGE in "
                       "content.py" % (unit, ", ".join(pil)))
        return dict(figure=(kind == "figure"),
                    source="tashpaz unit %s (%s)" % (unit, kind),
                    deferred=dfr, package=pkg)
    return dict(figure=None, source="unknown topic (package %s, unit %s): "
                "declare figure_topic" % (pkg, unit), deferred=None,
                package=pkg)


def governs(L, package=None):
    """True when G83 decides this level's density (a figure topic whose G83
    is not deferred)."""
    st = topic_status(L, package)
    return st["figure"] is True and not st["deferred"]


# ---------------------------------------------------------- the words -----
def _flat(t):
    if t is None:
        return u""
    if isinstance(t, (list, tuple)):
        return u" ".join(_flat(x) for x in t)
    if isinstance(t, dict):
        return _flat(t.get("text"))
    return t if isinstance(t, str) else u""


def _tokens(text):
    s = re.sub(r"\$[^$]*\$", " ", _flat(text))      # math islands
    s = re.sub(r"\*\*|__", " ", s)
    s = s.replace(u"־", " ")                          # maqaf joins a prefix
    return [t.strip(PUNCT) for t in s.split()]


def refs(text):
    """The figure-reference words of a text, in order."""
    out = []
    tk = [t for t in _tokens(text) if t]
    for i, t in enumerate(tk):
        if t not in REF_TOKENS:
            continue
        p1 = tk[i - 1] if i >= 1 else u""
        p2 = tk[i - 2] if i >= 2 else u""
        if p1 in NEGATION:
            continue                       # 'בלי שרטוט', 'ללא הגרף'
        if p1 in DRAW_VERBS or (p1 == u"את" and p2 in DRAW_VERBS):
            continue                       # 'שרטטו את הגרף': make one
        out.append(t)
    return out


def _items(q):
    """[(label, text, space, figure)] of a question as the emitter takes it
    (tuple items, 3- or 4-long; dict items of the v6.5 schema too)."""
    out = []
    for it in q.get("items") or []:
        if isinstance(it, dict):
            out.append((it.get("label") or it.get("id"), it.get("text"),
                        it.get("space", 30), it.get("fig")))
        else:
            out.append((it[0], it[1], it[2] if len(it) > 2 else 30,
                        it[3] if len(it) > 3 else None))
    return out


def _stem(q):
    return [q.get("intro"), q.get("text")]


def _placeholder(q):
    """a local-limit placeholder: the number prints only the framed box
    'מגבלה מקומית' -- no stem, no item, no figure, no table: no question"""
    ex = q.get("example")
    return (not q.get("items") and not q.get("intro") and not q.get("text")
            and not q.get("fig") and not q.get("table") and ex is not None
            and str(ex[0]).strip().startswith(LOCAL_LIMIT_TITLE))


# ------------------------------------------------------------------ G82 ---
def fig_ref_report(L):
    """[(question n, where, words, why)] -- every reference with no figure"""
    bad = []
    for q in L.get("questions", []):
        n = q.get("n")
        its = _items(q)
        head = bool(q.get("fig"))
        own = [bool(f) for _l, _t, _s, f in its]
        w = refs(_stem(q))
        if w and not head and not (its and all(own)):
            bad.append((n, "stem", w, "the stem refers to a figure and the "
                        "question has none%s" % (
                            " (only %d of its %d items carry one)"
                            % (sum(own), len(own)) if any(own) else "")))
        for (lab, txt, _s, f) in its:
            wi = refs(txt)
            if wi and not (f or head):
                bad.append((n, u"item %s" % lab, wi, "the item refers to a "
                            "figure and neither it nor its question has "
                            "one"))
        if q.get("example"):
            we = refs(q["example"][1])
            if we and not head and not any(own):
                bad.append((n, "example", we, "the worked example refers to "
                            "a figure and the question has none"))
    return bad


PENDING = {}       # level key -> [(n, where, words, reason)] (build.py reads it)


def fig_ref_pending(L):
    """{question n: reason} -- the references a level DECLARES it cannot
    resolve without the author (fig_ref_pending): the source's figure is of
    a kind the skill cannot print (G8-T30 a q8's bar chart, decision A-4).
    Such a level is BUILT and NOT APPROVED (build.py GATES, build.json
    checks.g82_fig_ref), like a G79 REVIEW: never delivered as done."""
    pd = L.get("fig_ref_pending") or {}
    if not isinstance(pd, dict):
        raise AssertionError("G82: fig_ref_pending is {question n: reason}, "
                             "not %r" % (pd,))
    qn = set(q.get("n") for q in L.get("questions", []))
    for n, why in pd.items():
        if n not in qn or not str(why or "").strip():
            raise AssertionError("G82: fig_ref_pending names question %s: "
                                 "a question of the level, with its reason"
                                 % n)
    return dict((n, str(w)) for n, w in pd.items())


EXCEPTIONS = {}    # level key -> [(n, where, words, decision id, reason)]


def author_decision(did, path=None):
    """the APPROVED record `did` of the author's approvals file, else None
    (a record needs the file's reviewer and timestamp, as acceptance/run.py
    author_decisions reads it)"""
    try:
        with open(path or APPROVALS_FILE, encoding="utf-8") as fh:
            d = json.load(fh)
    except (OSError, ValueError):
        return None
    if not (d.get("reviewer") and d.get("timestamp_utc")):
        return None
    for x in d.get("decisions") or []:
        if x.get("id") == did and x.get("decision") == "APPROVED":
            return x
    return None


def fig_ref_exception(L, approvals=None):
    """{question n: (decision id, reason)} -- the references the AUTHOR has
    ruled an exception (V616-A4: G8-T30 a q8's bar chart comes in the charts
    stage). Each names an APPROVED decision of the author's approvals file;
    a self-granted one (no such record) is refused."""
    ex = L.get("fig_ref_exception") or {}
    if not isinstance(ex, dict):
        raise AssertionError("G82: fig_ref_exception is {question n: "
                             "(decision id, reason)}, not %r" % (ex,))
    qn = set(q.get("n") for q in L.get("questions", []))
    out = {}
    for n, v in ex.items():
        if not (isinstance(v, (tuple, list)) and len(v) == 2 and
                str(v[0] or "").strip() and str(v[1] or "").strip()):
            raise AssertionError("G82: fig_ref_exception q%s is (decision "
                                 "id, reason), not %r" % (n, v))
        if n not in qn:
            raise AssertionError("G82: fig_ref_exception names question %s, "
                                 "which the level lacks" % n)
        if author_decision(str(v[0]), approvals) is None:
            raise AssertionError(
                "G82: fig_ref_exception q%s cites %r, which is no APPROVED "
                "decision of the author (wspec/approvals/APPROVALS_NOAM.json)"
                " -- an exception is the author's, never the builder's"
                % (n, v[0]))
        out[n] = (str(v[0]), str(v[1]))
    return out


def assert_fig_ref(L, verbose=True, approvals=None):
    """G82 -- raises with every reference that has no figure (a question
    the level declares in fig_ref_pending is recorded instead: the level is
    NOT APPROVED; one in fig_ref_exception -- the author's approved
    exception -- is recorded as AUTHOR_EXCEPTION and the level can be
    approved)."""
    bad = fig_ref_report(L)
    pend = fig_ref_pending(L)
    exc = fig_ref_exception(L, approvals)
    both = sorted(set(pend) & set(exc))
    if both:
        raise AssertionError("G82 (FIG_REF, level %s): q%s is both pending "
                             "and an author exception -- one of them"
                             % (L.get("key", "?"), ", q".join(
                                 str(n) for n in both)))
    excused = [b for b in bad if b[0] in exc]
    EXCEPTIONS[L.get("key", "?")] = [(n, where, w, exc[n][0], exc[n][1])
                                     for n, where, w, _why in excused]
    bad = [b for b in bad if b[0] not in exc]
    held = [b for b in bad if b[0] in pend]
    bad = [b for b in bad if b[0] not in pend]
    PENDING[L.get("key", "?")] = [(n, where, w, pend[n])
                                  for n, where, w, _why in held]
    unused = sorted(set(pend) - set(b[0] for b in held))
    if unused:
        raise AssertionError("G82 (FIG_REF, level %s): fig_ref_pending names "
                             "q%s, which refers to no missing figure -- drop "
                             "it" % (L.get("key", "?"), ", q".join(
                                 str(n) for n in unused)))
    unused = sorted(set(exc) - set(b[0] for b in excused))
    if unused:
        raise AssertionError("G82 (FIG_REF, level %s): fig_ref_exception "
                             "names q%s, which refers to no missing figure "
                             "-- drop it" % (L.get("key", "?"), ", q".join(
                                 str(n) for n in unused)))
    if excused and verbose:
        for n, where, w, did, why in EXCEPTIONS[L.get("key", "?")]:
            print(u"G82 %-4s AUTHOR EXCEPTION q%s %s says %s -- %s: %s -- "
                  u"recorded (not a figure that is there)" % (
                      L.get("key", "?"), n, where, u"/".join(w), did, why))
    if held and verbose:
        for n, where, w, why in PENDING[L.get("key", "?")]:
            print(u"G82 %-4s AUTHOR PENDING q%s %s says %s -- %s -- the level "
                  u"is NOT APPROVED" % (L.get("key", "?"), n, where,
                                        u"/".join(w), why))
    if bad:
        raise AssertionError(
            "G82 (FIG_REF, level %s): %s. A question that refers to a figure "
            "MUST have it (W-FIGURE-DENSITY: 'a missing one is a FAIL'): "
            "draw it -- the givens only, or an empty plane / circle where the "
            "full figure shows an answer"
            % (L.get("key", "?"), "; ".join(
                u"q%s %s says %s: %s" % (n, where, u"/".join(w), why)
                for n, where, w, why in bad)))
    if verbose and not held:
        print("G82 %-4s FIG_REF pass (%d questions%s)"
              % (L.get("key", "?"), len(L.get("questions", [])),
                 ("; author exception(s) q%s" % ", q".join(
                     str(e[0]) for e in excused)) if excused else ""))
    return held


# ------------------------------------------------------------------ G83 ---
def level_band(L):
    """'a' | 'b' | 'c' -- from the level's printed name, else its key"""
    lv = str(L.get("level") or "")
    if u"מצוינ" in lv:
        return "c"
    if re.search(u"רמה\\s*ב", lv):
        return "b"
    if re.search(u"רמה\\s*א", lv):
        return "a"
    k = str(L.get("key") or "")
    return k if k in SHARE else None


def target_of(n_questions, band):
    return int(math.floor(SHARE[band] * n_questions + 0.5))


def words_share(L):
    """{n: reason} -- the declared drawing-from-words questions"""
    ws = L.get("words_share")
    if ws is None:
        return None
    if isinstance(ws, dict):
        out = {}
        for n, why in ws.items():
            if not str(why or "").strip():
                raise AssertionError("G83: words_share question %s gives no "
                                     "reason" % n)
            out[n] = str(why)
        return out
    if isinstance(ws, (list, tuple, set)):
        return dict((n, u"drawing from words") for n in ws)
    raise AssertionError("G83: words_share is {n: reason} or a list of "
                         "question numbers, not %r" % (ws,))


def density_report(L, package=None):
    st = topic_status(L, package)
    scale = max(float(L.get("space_scale", 1.0)), 0.75)
    qs = [q for q in L.get("questions", []) if not _placeholder(q)]
    ph = [q.get("n") for q in L.get("questions", []) if _placeholder(q)]
    ws = words_share(L)
    band = level_band(L)
    nofig, table_q, rooms, wrefs = [], [], {}, {}
    for q in qs:
        its = _items(q)
        drawn = bool(q.get("fig")) or any(f for _l, _t, _s, f in its)
        if not drawn:
            if q.get("table"):
                table_q.append(q.get("n"))
            else:
                nofig.append(q.get("n"))
        sp = [float(s or 0) for _l, _t, s, _f in its] or \
            [float(q.get("space", 30))]
        # (fix r1 cont., V616-A7 "under each drawing-from-words question")
        # the room is the LAST item's space: the band below the question
        rooms[q.get("n")] = sp[-1] * scale
        w = refs(_stem(q)) + [x for _l, t, _s, _f in its for x in refs(t)]
        if w:
            wrefs[q.get("n")] = w
    return dict(status=st, band=band, n=len(qs), placeholders=ph,
                words=ws, target=(target_of(len(qs), band) if band else None),
                nofig=nofig, table=table_q, rooms=rooms, refs=wrefs,
                with_fig=len(qs) - len(nofig) - len(table_q))


def assert_fig_density(L, verbose=True, package=None):
    """G83 -- raises with every number that decided it."""
    r = density_report(L, package)
    st = r["status"]
    key = L.get("key", "?")
    if st["figure"] is not True:
        if verbose:
            print("G83 %-4s not a figure topic -- %s" % (key, st["source"]))
        return r
    if st["deferred"]:
        if verbose:
            print("G83 %-4s DEFERRED -- %s: %s" % (key, st["source"],
                                                   st["deferred"]))
        return r
    bad = []
    if r["band"] is None:
        bad.append("the level is neither a, b nor excellence (level %r, key "
                   "%r): its share cannot be named" % (L.get("level"), key))
    ws = r["words"]
    if ws is None and r["target"] == 0:
        ws = {}          # round(share x n) is 0 (a short sheet): none owed
    if ws is None:
        bad.append("a figure topic (%s) declares no words_share: name the "
                   "drawing-from-words questions {n: reason} (%s of %d "
                   "questions)" % (st["source"], r["target"], r["n"]))
        ws = {}
    qn = set(q.get("n") for q in L.get("questions", []))
    for n in ws:
        if n not in qn:
            bad.append("words_share names question %s, which the level "
                       "lacks" % n)
    if r["target"] is not None and ws is not None and \
            abs(len(ws) - r["target"]) > SHARE_TOLERANCE:
        bad.append("SHARE: %d drawing-from-words question(s) %s, the "
                   "author's target is round(%d%% x %d) = %d (+-%d)"
                   % (len(ws), sorted(ws), int(100 * SHARE[r["band"]]),
                      r["n"], r["target"], SHARE_TOLERANCE))
    for n in sorted(ws):
        if n not in r["nofig"]:
            if n in qn:
                bad.append("q%s is in words_share but carries a figure (or "
                           "a table)" % n)
            continue
        if n in r["refs"]:
            bad.append(u"q%s (drawing from words) refers to a figure: %s"
                       % (n, u"/".join(r["refs"][n])))
        if r["rooms"].get(n, 0) < ROOM_PT - 1e-6:
            bad.append("q%s (drawing from words) leaves %.0f pt (%.1f mm) to "
                       "draw in below it; its LAST item needs >= %.0f pt (%.0f mm)"
                       % (n, r["rooms"].get(n, 0),
                          r["rooms"].get(n, 0) * 25.4 / 72.0, ROOM_PT,
                          ROOM_MM))
    other = [n for n in r["nofig"] if n not in ws]
    if other:
        bad.append("q%s: no figure, and not in the drawing-from-words share "
                   "-- every other question of a figure topic has one (the "
                   "givens only, or an empty plane / circle)"
                   % ", q".join(str(n) for n in other))
    if bad:
        raise AssertionError("G83 (FIG_DENSITY, level %s, %s): %s"
                             % (key, st["source"], " | ".join(bad)))
    if verbose:
        print("G83 %-4s FIG_DENSITY pass -- %s; words share %s = %d of %d "
              "(target %s +-%d), figures on the other %d%s%s"
              % (key, st["source"], sorted(ws), len(ws), r["n"],
                 r["target"], SHARE_TOLERANCE, r["with_fig"],
                 ("; table question(s) %s" % r["table"]) if r["table"]
                 else "",
                 ("; local-limit placeholder(s) %s (no question printed)"
                  % r["placeholders"]) if r["placeholders"] else ""))
    return r


# ------------------------------------------------- G83 room ON THE PDF ---
def _item_rid(n, lab):
    import deliver as _D
    return _D.item_id(n, lab)


def _ink_rows(page, box, skip_bottom_pt=1.6):
    """[(y0, y1)] of every piece of ink inside `box` (text spans and vector
    drawings of the page that overlap it); the item's own dashed bottom
    rule -- a flat drawing within `skip_bottom_pt` of the box's bottom --
    closes the band and is not ink inside it"""
    x0, y0, x1, y1 = box
    rows = []
    for b in page.get_text("dict")["blocks"]:
        for ln in b.get("lines", []):
            for sp in ln.get("spans", []):
                if not str(sp.get("text") or "").strip():
                    continue
                bx0, by0, bx1, by1 = sp["bbox"]
                if bx1 > x0 + 0.5 and bx0 < x1 - 0.5 and by1 > y0 + 0.5 and \
                        by0 < y1 - 0.5:
                    rows.append((max(by0, y0), min(by1, y1)))
    for d in page.get_drawings():
        for r in _drawn_parts(d):
            if not (r.x1 > x0 + 0.5 and r.x0 < x1 - 0.5 and
                    r.y1 > y0 + 0.5 and r.y0 < y1 + 0.5):
                continue
            if r.height <= 1.5 and r.y0 >= y1 - skip_bottom_pt - 1.0:
                continue                   # the item's own bottom rule
            rows.append((max(r.y0, y0), min(r.y1, y1)))
    return rows


def _drawn_parts(d):
    """the rectangles a PDF drawing inks: its bounding rect, except for an
    even-odd fill of two nested rectangles (how WeasyPrint prints a border:
    the item's dashed bottom rule is the outer box minus the inner one) --
    only the strips between them are ink"""
    import pymupdf
    it = d.get("items") or []
    if d.get("even_odd") and len(it) == 2 and all(x[0] == "re" for x in it):
        a, b = pymupdf.Rect(it[0][1]), pymupdf.Rect(it[1][1])
        o, i = (a, b) if a.get_area() >= b.get_area() else (b, a)
        if o.contains(i):
            strips = [pymupdf.Rect(o.x0, o.y0, o.x1, i.y0),
                      pymupdf.Rect(o.x0, i.y1, o.x1, o.y1),
                      pymupdf.Rect(o.x0, i.y0, i.x0, i.y1),
                      pymupdf.Rect(i.x1, i.y0, o.x1, i.y1)]
            return [r for r in strips if r.width > 1e-3 and r.height > 1e-3]
    r = d.get("rect")
    return [r] if r is not None else []


def _largest_gap(y0, y1, rows):
    """(height, top, bottom) of the tallest band of [y0, y1] no row covers"""
    best, cur = (0.0, y0, y0), y0
    for a, b in sorted((max(a, y0), min(b, y1)) for a, b in rows
                       if b > y0 and a < y1):
        if a > cur and a - cur > best[0]:
            best = (a - cur, cur, a)
        cur = max(cur, b)
    if y1 > cur and y1 - cur > best[0]:
        best = (y1 - cur, cur, y1)
    return best


def room_on_pdf(pdf_path, blocks, L, package=None):
    """G83 room measured on the PRINTED sheet (V616-A7): for every
    drawing-from-words question of a governed level, the tallest ink-free
    band inside its item boxes (blocks = the build's text_binding blocks,
    {'item:<rid>': [[page, x0, y0, x1, y1], ...]} in PDF pt). No text, no
    drawing -- so no grid and no axes -- may cross the band; it must be
    >= ROOM_MM. -> {"status": PASS | FAIL | NOT_RUN, "rows": [...]}"""
    st = topic_status(L, package)
    if st["figure"] is not True or st["deferred"]:
        return {"gate": "G83-room", "status": "NOT_RUN",
                "why": st["deferred"] or st["source"], "rows": [],
                "min_mm": ROOM_MM, "target_mm": ROOM_TARGET_MM}
    ws = words_share(L) or {}
    import pymupdf
    doc = pymupdf.open(str(pdf_path))
    rows = []
    for q in L.get("questions", []):
        n = q.get("n")
        if n not in ws:
            continue
        best = None
        # (V616-A7: the room is BELOW the question) the LAST item's box
        for lab, _t, _s, _f in _items(q)[-1:]:
            rid = _item_rid(n, lab)
            for bx in (blocks or {}).get("item:%s" % rid) or []:
                pno, box = int(bx[0]), [float(v) for v in bx[1:5]]
                page = doc[pno]
                h, top, bot = _largest_gap(box[1], box[3] - 1.6,
                                           _ink_rows(page, box))
                mm = h * 25.4 / 72.0
                if best is None or mm > best["mm"]:
                    best = {"question": "q%s" % n, "item": rid,
                            "page": pno + 1, "mm": round(mm, 1),
                            "band_pt": [round(box[0], 1), round(top, 1),
                                        round(box[2], 1), round(bot, 1)]}
        if best is None:
            best = {"question": "q%s" % n, "item": None, "page": None,
                    "mm": 0.0, "band_pt": None,
                    "why": "no printed item box of the question was found "
                           "in the build's layout -- the room cannot be "
                           "measured"}
        best["ok"] = best["mm"] >= ROOM_MM - 1e-6
        rows.append(best)
    doc.close()
    return {"gate": "G83-room", "status": "PASS" if all(
        r["ok"] for r in rows) else "FAIL", "rows": rows,
        "min_mm": ROOM_MM, "target_mm": ROOM_TARGET_MM}


def room_line(key, r):
    if r["status"] == "NOT_RUN":
        return "G83-room   %-4s not run -- %s" % (key, r.get("why"))
    return "G83-room   %-4s %-4s %s" % (key, r["status"], "; ".join(
        "%s %.1f mm%s" % (x["question"], x["mm"],
                          "" if x["ok"] else " < %.0f mm" % ROOM_MM)
        for x in r["rows"]) or "no drawing-from-words question")


# ------------------------------------------------------------- install ----
def install(package=None, verbose=True):
    """Wrap emit_html.assert_figure_variety (after G75-G78) so G82 and G83
    run inside build_html on every level. Idempotent; `package` is the
    build's content.py PACKAGE."""
    import emit_html as E
    if package is not None:
        _PACKAGE[0] = package
    if getattr(E.assert_figure_variety, "_g82_installed", False):
        return E.assert_figure_variety
    inner = E.assert_figure_variety

    def wrapped(L):
        r = inner(L)
        assert_fig_ref(L, verbose=verbose)
        assert_fig_density(L, verbose=verbose)
        return r

    wrapped._g82_installed = True
    wrapped._inner = inner
    for k in ("_g76_installed",):
        if getattr(inner, k, False):
            setattr(wrapped, k, True)
    wrapped.__doc__ = (inner.__doc__ or "") + "\n\nWrapped by gate_figref " \
        "(G82 FIG_REF, G83 FIG_DENSITY)."
    E.assert_figure_variety = wrapped
    return wrapped
