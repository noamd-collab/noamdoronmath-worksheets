# -*- coding: utf-8 -*-
u"""selfcheck_catalog — v7.2.0 gate G89-catalog: is a sheet's public catalog entry (and landing) safe and true?

    python3 -I selfcheck_catalog.py out/catalog/<sheet_id>/catalog-entry.json --deliver out/deliver
                                    [--landing PATH] [--json OUT] [--allow-synthetic]
    python3 -I selfcheck_catalog.py --selftest

    import selfcheck_catalog
    selfcheck_catalog.check(entry_path, deliver_root)  -> {"status": "PASS"|"FAIL"|"SKIP", "messages": [...]}
    selfcheck_catalog.gate_record(entry_path, deliver_root) -> the contract's gate record (gate G89-catalog)

WHY A SEPARATE CHECKER
----------------------
catalog-entry.json and landing.json are the only v7.2 outputs meant to leave the
skill and reach the website (website.md §5). They are built from SHEET and the
registry, not by the engine, so none of the engine's guards (deliver's
whitelist-built noam-ai.json, selfcheck_noam_package K2/K3) look at them. This
checker is that guard. It also re-reads what the build printed, because the
entry is written FROM the manifest: when the manifest and the printed sheet
disagree (fixtures NEGATIVE.md N7/N8), the entry carries the manifest's question
numbers and only a cross-check against noam-ai.json shows the lie.

It runs under `python3 -I` with the standard library only (the contract's rule
for checkers), so it never imports the engine, pkgload or the package, and it
never RUNS package code. SHEET comes from the build's own snapshot: build.py
copies every package .py into out/deliver/<k>/source/, so source/sheet_meta.py is
the manifest the PDF was built with. It is read by a small literal evaluator
(read_sheet_source): constants, lists, dicts, tuples, + - * %, f-strings,
list/tuple/dict/range/sorted, comprehensions without conditions, and module-level
names assigned to such literals ABOVE SHEET (`_S2 = [5, 6, 7, 8]`, then
`"a": _S2`). Anything that needs code to run (an import, a function call, a loop
that edits SHEET) makes SHEET unreadable, and the message says exactly which
name and line — never "missing". A caller that already holds SHEET (gate_sections
via pkgload) can pass sheet=... and then no snapshot is read.

WHERE EACH PUBLIC STRING COMES FROM (and how it is checked)
-----------------------------------------------------------
  SHEET-authored   title, section titles, landing animation id/alt (when SHEET
                   gives one): must equal SHEET; scanned for answers.
  registry-derived section aliases + search_variants (recomputed here with
                   catalog_search.aliases_for / search_variants_for over
                   curriculum_tashpaz.json + glossary_he.json), landing
                   definition_he / definition_plain (plain_math below) /
                   explain_he / intro, related-topic labels: must equal the
                   recomputed value; NOT scanned for answers once equal — a
                   registry sentence such as "סכום זוויות צמודות הוא 180°" may
                   legitimately also be an item's answer, and it is public
                   curriculum text either way.
  fixed frames     h1, description, combo explain_he, default alt_he, CTA label,
                   download names: must equal the frame (the frames live here and
                   landing_build imports them, so the two cannot drift).

RULES (each a FAIL)
-------------------
 1. schema whitelist: top level, levels.<k>, sections[], and the landing — an
    unknown key fails, a missing key fails. The whitelist below IS the schema
    "noam-catalog-entry/v1"; catalog_build imports it.
 2. no answer / hint / path / hash / timestamp keys (DENY) anywhere, and no such
    values. Values are first cleaned (NFC, niqqud and invisible/bidi marks such
    as U+200D/U+200F removed — emit_docx puts them into runs), then:
    absolute paths, ~/ and file:// (selfcheck_noam_package BAD_VALUE), relative
    file paths ("out/deliver/a/sheet.pdf", "deliver/a/noam-ai.json"), known build
    folders ("out/…", "source/…"), a hex run ≥ 32 with a letter (sha/md5), a
    timestamp or build date (ISO extended "2026-11-09", "2026-11-09T10:15",
    ISO basic "20261109T101500Z", "9.11.2026"), an e-mail address.
 3. no printed answer in a SHEET-authored or free string. Answers are read from
    each level's sheet.json (item/question `answer`, find `value`) and compared
    in a folded form: invisible marks out, \\angle{BOC} / ∡BOC / ∠BOC → BOC,
    ^\\circ → °, $ and spaces out, lower case. An answer is hunted whole AND in
    parts (split at ; , : and parentheses), so "∡BOC=122°" alone is caught as
    well as the full printed line. A part is worth hunting when it holds a digit
    (≥ 6 chars), or a Latin letter (point names; ≥ 8 chars), or is a long Hebrew
    sentence (≥ 24 chars); find pairs "<of>=<value>" (BOC=122) are hunted too.
    Short pure-Hebrew answers ("זוויות קודקודיות") are not: they are vocabulary,
    and they are also titles. An answer that the question side already prints
    (sheet title, question text, examples, givens, SHEET titles) is not secret.
 4. levels: the level keys equal the levels in out/deliver; question_ids and
    item_ids equal that level's noam-ai.json, in order; every id also exists in
    sheet.json; pages equals build.json; engine_version equals build.json's
    skill_version (the engine that built it); skill_version is a version string.
 5. sections: ids, subtopics, kinds, titles, combines and question numbers equal
    SHEET's, in order; every section question exists in noam-ai.json; sections
    are disjoint and their union is exactly the level's questions; anchors are
    unique and are the subtopic's slug (anchor_for; "-2", "-3" for a repeated
    subtopic; "<topic>-combo" for a combo); aliases and search_variants are the
    registry's (see above); subtopic_ids is the ordered list of section subtopics.
 6. title == SHEET.title (and sheet_id, package, grade, track, topic_id, scope,
    landing_slug, replaces agree with SHEET); title_search == search_key(title).
 7. landing.json beside the entry: schema whitelist; slug, title, sheet_id agree;
    grade == the entry's grade; exactly ONE animation, with SHEET's animation_id,
    an anchor that exists (SHEET.landing.animation_anchor when given) and
    SHEET's alt text or the fixed frame; exactly one anchor per section, unique,
    in section order, each present in the entry, kinds/subtopics/titles matching,
    definitions and explanations equal to the registry's; example_question_ids
    taken from level a of that section; downloads.<k> == "<sheet_id>_<k>.pdf" /
    ".docx" with the level's name; related topics real registry neighbours
    (requires / next) with the registry's title, sheet and anchor; same value scan.

A legacy package (no SHEET in the build snapshot) returns SKIP with
"legacy package (no SHEET)", never PASS. An entry marked "synthetic" (a planned
sheet generated from the registry for search tests) FAILS unless the caller
passes allow_synthetic=True; then the deliver cross-checks are skipped and said
so. Exit status: 0 PASS or SKIP, 1 FAIL, 2 usage or unreadable input.
"""
import argparse
import ast
import copy
import json
import re
import sys
import time
import types
import unicodedata
from pathlib import Path

HERE = Path(__file__).resolve().parent
GATE = "G89-catalog"
SCHEMA = "noam-catalog-entry/v1"
LANDING_SCHEMA = "noam-landing/v1"
LEVEL_KEYS = ("a", "b", "c")

# ---- the schema (whitelists). catalog_build / landing_build import these. ----
ENTRY_REQUIRED = ("schema", "sheet_id", "package", "grade", "track", "topic_id", "scope",
                  "title", "title_search", "levels", "sections", "subtopic_ids", "replaces",
                  "landing_slug", "skill_version", "engine_version")
ENTRY_OPTIONAL = ("synthetic",)
LEVEL_FIELDS = ("name", "question_ids", "item_ids", "pages")
SECTION_REQUIRED = ("id", "subtopic", "kind", "title", "anchor", "aliases", "search_variants",
                    "question_ids")
SECTION_OPTIONAL = ("combines",)
LANDING_REQUIRED = ("schema", "sheet_id", "slug", "path", "grade", "title", "h1", "description",
                    "intro", "anchors", "animation", "downloads", "relatedTopics", "catalogCta")
LANDING_OPTIONAL = ("synthetic",)
ANCHOR_REQUIRED = ("anchor", "kind", "subtopic", "title", "definition_he", "definition_plain",
                   "explain_he", "example_question_ids")
ANCHOR_OPTIONAL = ("combines",)
ANIMATION_FIELDS = ("id", "anchor", "alt_he")
DOWNLOAD_FIELDS = ("label", "pdf", "docx")
RELATED_FIELDS = ("label", "subtopic", "relation", "sheet", "anchor", "path")
CTA_FIELDS = ("label", "href", "catalogTopicId", "catalogTopicTitle")
LEVEL_NAMES = {"a": u"רמה א׳", "b": u"רמה ב׳", "c": u"מצוינות"}

# ---- the landing's fixed Hebrew frames (landing_build imports them) ------------
GRADE_HE = {"7": u"ז׳", "8": u"ח׳", "9": u"ט׳"}
H1_FRAME = u"%s לכיתה %s"                                                  # (title, grade)
DESCRIPTION_FRAME = u"דף עבודה לכיתה %s בשלוש רמות (רמה א׳, רמה ב׳ ומצוינות): %s."   # (grade, title)
ALT_FRAME = u"הנפשה הממחישה את הנושא: %s."                                  # (anchor title)
CTA_LABEL = u"פתיחת דפי העבודה ובחירת רמה"
COMBO_EXPLAIN = (u"השאלות בסעיף הזה משלבות כמה נושאים מהדף: %s.",          # (combined titles)
                 u"בכל שאלה משתמשים ביותר מנושא אחד.")

# ---- value scans (selfcheck_noam_package K2/K3, widened for a public file) --
DENY_KEY = re.compile(u"answer|solution|solve|hint|hash|md5|sha|secret|token|path|file|"
                      u"built|generat|time|date|stamp|email|mail|key|תשוב|פתר|רמז|מפתח", re.I)
BAD_VALUE = re.compile(r"/private/|/Users/|/tmp/|/home/|/var/|/Volumes/|"
                       r"source/|file://|\.(?:py|pyc|ipynb|sh|skill)\b|"
                       r"(?:^|[\s(\[\"'=:,])(?:~|\.{1,2})?/(?:[\w.-]+/)+|"
                       r"(?:^|[\s(\[\"'=:,])~/|[A-Za-z]:\\")
REL_PATH = re.compile(r"(?<![\w/\\.~-])(?:[\w.-]+[/\\])+[\w.-]+\."
                      r"(?:pdf|docx?|json|html?|py|pyc|ipynb|png|svg|jpe?g|txt|csv|md|zip|skill|sh)\b", re.I)
KNOWN_DIR = re.compile(r"(?<![\w.-])(?:out|deliver|source|figures|catalog|docx|logs|work|tests?|fixtures|"
                       r"scratchpad)[/\\][\w.-]", re.I)
HEX = re.compile(r"(?<![0-9a-fA-F])(?=[0-9a-fA-F]*[a-fA-F])[0-9a-fA-F]{32,}(?![0-9a-fA-F])")
STAMP = re.compile(r"(?<!\d)(?:19|20)\d{2}-(?:0[1-9]|1[0-2])-(?:0[1-9]|[12]\d|3[01])(?!\d)"
                   r"|(?<!\d)(?:19|20)\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12]\d|3[01])T\d{2}:?\d{2}"
                   r"|(?<![\d.])(?:0?[1-9]|[12]\d|3[01])[./](?:0?[1-9]|1[0-2])[./](?:19|20)\d{2}(?!\d)")
EMAIL = re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+")
VALUE_RULES = (("path", (BAD_VALUE, REL_PATH, KNOWN_DIR)), ("hash", (HEX,)), ("timestamp", (STAMP,)),
               ("e-mail", (EMAIL,)))
# keys that look like DENY words but are site field names; their values are validated by the schema rules
PUBLIC_KEYS = ("title_search", "path")
ANCHOR_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
QID_RE = re.compile(r"^q\d+$")
ITEM_RE = re.compile(r"^q\d+\w+$")
VERSION_RE = re.compile(r"^\d+\.\d+(?:\.\d+)?(?:-[A-Za-z0-9.]+)?$")
_INVISIBLE = re.compile(u"[\u00AD\u200B-\u200F\u2060-\u2064\uFEFF\u202A-\u202E\u2066-\u2069]")
_NIQQUD = re.compile(u"[\u0591-\u05BD\u05BF\u05C1\u05C2\u05C4\u05C5\u05C7]")


def _load_json(p):
    with open(p, encoding="utf-8") as fh:
        return json.load(fh)


def clean(text):
    """NFC, invisible/bidi marks and niqqud removed: what a reader sees, what every value rule tests."""
    t = unicodedata.normalize("NFC", u"%s" % (text or u""))
    return _NIQQUD.sub(u"", _INVISIBLE.sub(u"", t))


# ---- anchors (catalog_build imports these; rule 5 verifies them) ---------------
def anchor_for(subtopic_id):
    """st.g7.angles.vertical → "angles-vertical"; st.g9r.powers.product_same_base → "powers-product-same-base"."""
    parts = (subtopic_id or u"").split(".")
    if len(parts) < 4 or parts[0] != "st":
        raise ValueError("not a registry subtopic id: %r" % subtopic_id)
    slug = "-".join(parts[2:]).replace("_", "-").lower()
    return re.sub(r"[^a-z0-9-]+", "-", slug).strip("-")


def _combo_base(topic_id):
    return re.sub(r"[^a-z0-9-]+", "-", (topic_id or "sheet").replace("_", "-").lower()).strip("-") + "-combo"


def _next_free(base, used):
    if base not in used:
        return base
    n = 2
    while "%s-%d" % (base, n) in used:
        n += 1
    return "%s-%d" % (base, n)


def subtopic_anchor(subtopic_id, used):
    """anchor_for(subtopic), or "<slug>-2", "-3" … when an earlier section already took it."""
    return _next_free(anchor_for(subtopic_id), used)


def combo_anchor(topic_id, used):
    return _next_free(_combo_base(topic_id), used)


def _anchor_ok(anchor, base):
    return isinstance(anchor, str) and (anchor == base or bool(re.match(re.escape(base) + r"-(?:[2-9]|[1-9]\d+)$",
                                                                        anchor)))


# ---- plain text of registry math (landing_build imports it) --------------------
_GREEK = {"alpha": u"α", "beta": u"β", "gamma": u"γ", "delta": u"δ", "theta": u"θ"}
_SUP = str.maketrans(u"0123456789nk+-−", u"⁰¹²³⁴⁵⁶⁷⁸⁹ⁿᵏ⁺⁻⁻")


def plain_math(text):
    """Engine $…$ islands → plain Unicode (∡ABC, β, ·, ≠, ≥, √, a/b, superscripts), or None if unsure.

    The site renders plain text (registry meta.text_format), so a definition with
    math islands needs a plain twin; anything this small converter does not know
    yields None rather than a half-converted string. It lives here so that G89
    can recompute definition_plain instead of trusting it.
    """
    if text is None:
        return None
    if u"$" not in text:
        return text

    def wrap(x):
        x = x.strip()
        return x if re.match(u"^[\\w√∡ⁿᵏ⁰-⁹.]+$", x) else u"(" + x + u")"

    def island(m):
        s = m.group(1)
        s = re.sub(r"\\angle\s*\{([^{}]*)\}", u"∡\\1", s)
        s = re.sub(r"\\angle\s*([A-Za-z]+)", u"∡\\1", s)
        s = re.sub(r"\\(alpha|beta|gamma|delta|theta)(?![A-Za-z])", lambda g: _GREEK[g.group(1)], s)
        s = re.sub(r"\\left\s*([(\[|])", u"\\1", s)
        s = re.sub(r"\\right\s*([)\]|])", u"\\1", s)
        for name, ch in (("cdot", u"·"), ("times", u"×"), ("neq", u"≠"), ("geq", u"≥"), ("ge", u"≥"),
                         ("leq", u"≤"), ("le", u"≤"), ("ldots", u"…"), ("cdots", u"…"), ("dots", u"…")):
            s = re.sub(r"\\%s(?![A-Za-z])" % name, ch, s)
        s = re.sub(r"\^\{([0-9nk+\-−]+)\}", lambda g: g.group(1).translate(_SUP), s)
        s = re.sub(r"\^([0-9nk])", lambda g: g.group(1).translate(_SUP), s)
        for _ in range(4):  # inside out: \sqrt{\frac{a}{b}}, \frac{\sqrt{a}}{\sqrt{b}}
            s = re.sub(r"\\sqrt\s*\{([^{}]*)\}", lambda g: u"√" + wrap(g.group(1)), s)
            s = re.sub(r"\\frac\s*\{([^{}]*)\}\s*\{([^{}]*)\}",
                       lambda g: wrap(g.group(1)) + u"/" + wrap(g.group(2)), s)
        s = re.sub(r"\s*([·=≠≥≤×])\s*", u"\\1", s)
        s = s.replace(u"-", u"−") if re.search(r"\d\s*-\s*\d", s) else s
        return s.replace(u"{", u"").replace(u"}", u"").strip()
    out = re.sub(r"\$([^$]*)\$", island, text)
    return None if (u"$" in out or u"\\" in out) else out


# ---- catalog_search (vocabulary + search_key), loaded by path ------------------
_CS = {}


def _catalog_search():
    """catalog_search loaded from its explicit path (works under -I), or None.

    Compiled by hand, not through the import system: under -I the
    PYTHONDONTWRITEBYTECODE switch is ignored and a loader would drop a
    __pycache__ into the skill folder.
    """
    if "m" in _CS:
        return _CS["m"]
    p = HERE / "catalog_search.py"
    m = None
    if p.is_file():
        m = types.ModuleType("_g89_catalog_search")
        m.__file__ = str(p)
        try:
            exec(compile(p.read_text(encoding="utf-8"), str(p), "exec"), m.__dict__)
        except Exception:
            m = None
    _CS["m"] = m
    return m


def _search_key():
    m = _catalog_search()
    return m.search_key if m is not None else None


# ---- the registry, as plain JSON ------------------------------------------------
class Registry(object):
    """curriculum_tashpaz.json["subtopics"] + glossary_he.json, read as JSON (G89 runs under -I).

    Deliberately not subtopics.py: that module may import more than the standard
    library, and G89 needs only lookups by id. subtopics.get returns these same
    JSON objects, so catalog_build and G89 see the same data.
    """

    def __init__(self, skill_dir=None):
        d = Path(skill_dir) if skill_dir else HERE
        self.by_id, self.glossary, self.error = {}, {}, None
        try:
            sub = _load_json(d / "curriculum_tashpaz.json").get("subtopics") or {}
            for track, topics in (sub.get("by_track") or {}).items():
                for topic, ents in (topics or {}).items():
                    for e in ents or []:
                        if isinstance(e, dict) and e.get("id"):
                            self.by_id[e["id"]] = (track, topic, e)
            self.glossary = _load_json(d / "glossary_he.json")
        except (OSError, ValueError, AttributeError) as ex:
            self.error = "%s: %s" % (type(ex).__name__, str(ex)[:160])
        if not self.by_id and not self.error:
            self.error = "curriculum_tashpaz.json has no subtopics"

    def get(self, sid):
        t = self.by_id.get(sid)
        return t[2] if t else None

    def located(self):
        return list(self.by_id.values())


def _explain(e):
    return [x for x in ((e or {}).get("explain_he") or []) if isinstance(x, str) and x.strip()][:2]


# ---- SHEET from the build snapshot, without running it ---------------------------
class _NotLiteral(ValueError):
    pass


_SAFE_CALLS = ("list", "tuple", "dict", "range", "set", "sorted")
_MAX_LEN = 100000


def _sized(v, line):
    if hasattr(v, "__len__") and len(v) > _MAX_LEN:
        raise _NotLiteral("value too large (line %d)" % line)
    return v


def _binop(op, a, b, line):
    num = (int, float)
    try:
        if isinstance(op, ast.Add) and (isinstance(a, num) and isinstance(b, num) or type(a) is type(b)
                                        and isinstance(a, (str, list, tuple))):
            return _sized(a + b, line)
        if isinstance(op, (ast.Sub, ast.Div, ast.FloorDiv)) and isinstance(a, num) and isinstance(b, num):
            return a - b if isinstance(op, ast.Sub) else (a / b if isinstance(op, ast.Div) else a // b)
        if isinstance(op, ast.Mult):
            if isinstance(a, num) and isinstance(b, num):
                return a * b
            if isinstance(a, (str, list, tuple)) and isinstance(b, int) and len(a) * max(b, 0) <= _MAX_LEN:
                return a * b
            if isinstance(b, (str, list, tuple)) and isinstance(a, int) and len(b) * max(a, 0) <= _MAX_LEN:
                return a * b
        if isinstance(op, ast.Mod) and isinstance(a, str):
            return a % (tuple(b) if isinstance(b, list) else b)
    except (TypeError, ValueError, ZeroDivisionError, KeyError):
        pass
    raise _NotLiteral("operator %s on %s and %s (line %d)" % (type(op).__name__, type(a).__name__,
                                                              type(b).__name__, line))


def _comp(node, env, why):
    """[…for x in literal] / {k: v for …} with one generator and no `if`."""
    if len(node.generators) != 1 or node.generators[0].ifs or node.generators[0].is_async:
        raise _NotLiteral("comprehension with conditions or several loops (line %d)" % node.lineno)
    g = node.generators[0]
    it = _lit(g.iter, env, why)
    if not hasattr(it, "__iter__") or (hasattr(it, "__len__") and len(it) > _MAX_LEN):
        raise _NotLiteral("comprehension over a non-iterable (line %d)" % node.lineno)
    out = []
    for x in it:
        local = dict(env)
        _bind(g.target, x, None, local, why, node.lineno)
        if isinstance(node, ast.DictComp):
            out.append((_lit(node.key, local, why), _lit(node.value, local, why)))
        else:
            out.append(_lit(node.elt, local, why))
    if isinstance(node, ast.DictComp):
        return dict(out)
    return set(out) if isinstance(node, ast.SetComp) else out


def _lit(node, env, why):
    """Value of a literal expression; names resolve through env (module-level literals above)."""
    line = getattr(node, "lineno", 0)
    if isinstance(node, ast.Constant):
        return node.value
    if isinstance(node, ast.Name):
        if node.id in env:
            return copy.deepcopy(env[node.id])
        raise _NotLiteral(why.get(node.id) or "name %r (line %d) is not a literal assigned above SHEET"
                          % (node.id, line))
    if isinstance(node, (ast.List, ast.Tuple, ast.Set)):
        out = []
        for e in node.elts:
            if isinstance(e, ast.Starred):
                v = _lit(e.value, env, why)
                if not isinstance(v, (list, tuple, set, str)):
                    raise _NotLiteral("* of a non-sequence (line %d)" % line)
                out.extend(v)
            else:
                out.append(_lit(e, env, why))
        _sized(out, line)
        return out if isinstance(node, ast.List) else (tuple(out) if isinstance(node, ast.Tuple) else set(out))
    if isinstance(node, ast.Dict):
        d = {}
        for k, v in zip(node.keys, node.values):
            if k is None:
                m = _lit(v, env, why)
                if not isinstance(m, dict):
                    raise _NotLiteral("** of a non-dict (line %d)" % line)
                d.update(m)
            else:
                d[_lit(k, env, why)] = _lit(v, env, why)
        return d
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.USub, ast.UAdd)):
        v = _lit(node.operand, env, why)
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            return -v if isinstance(node.op, ast.USub) else v
        raise _NotLiteral("unary operator on %s (line %d)" % (type(v).__name__, line))
    if isinstance(node, ast.BinOp):
        return _binop(node.op, _lit(node.left, env, why), _lit(node.right, env, why), line)
    if isinstance(node, ast.Subscript):
        base = _lit(node.value, env, why)
        try:
            if isinstance(node.slice, ast.Slice):
                lo, hi, st = [None if x is None else _lit(x, env, why)
                              for x in (node.slice.lower, node.slice.upper, node.slice.step)]
                return base[slice(lo, hi, st)]
            return base[_lit(node.slice, env, why)]
        except (KeyError, IndexError, TypeError):
            raise _NotLiteral("subscript that does not resolve (line %d)" % line)
    if isinstance(node, ast.JoinedStr):
        parts = []
        for v in node.values:
            if isinstance(v, ast.Constant):
                parts.append(u"%s" % v.value)
            elif isinstance(v, ast.FormattedValue) and v.conversion == -1 and v.format_spec is None:
                parts.append(u"%s" % _lit(v.value, env, why))
            else:
                raise _NotLiteral("f-string with a format spec (line %d)" % line)
        return u"".join(parts)
    if isinstance(node, (ast.ListComp, ast.SetComp, ast.DictComp, ast.GeneratorExp)):
        return _comp(node, env, why)
    if isinstance(node, ast.Call):
        f = node.func.id if isinstance(node.func, ast.Name) else None
        if f in _SAFE_CALLS and f not in env and f not in why:
            if any(isinstance(a, ast.Starred) for a in node.args) or any(k.arg is None for k in node.keywords):
                raise _NotLiteral("call to %s() with * or ** (line %d)" % (f, line))
            args = [_lit(a, env, why) for a in node.args]
            kw = dict((k.arg, _lit(k.value, env, why)) for k in node.keywords)
            try:
                if f == "range":
                    if kw or not all(isinstance(a, int) for a in args):
                        raise TypeError
                    r = range(*args)
                    if len(r) > _MAX_LEN:
                        raise TypeError
                    return list(r)
                if f == "dict":
                    return dict(*args, **kw)
                if f == "sorted":
                    if set(kw) - {"reverse"}:
                        raise TypeError
                    return sorted(*args, **kw)
                if kw:
                    raise TypeError
                return {"list": list, "tuple": tuple, "set": set}[f](*args)
            except (TypeError, ValueError):
                raise _NotLiteral("call to %s() with unsupported arguments (line %d)" % (f, line))
        r = _root(node.func)
        raise _NotLiteral("call to %s() (line %d)%s" % (f or type(node.func).__name__, line,
                                                         ("; " + why[r]) if r in why else ""))
    if isinstance(node, ast.Attribute):
        r = _root(node)
        raise _NotLiteral(why.get(r) or "attribute access %s.%s (line %d)" % (r, node.attr, line))
    raise _NotLiteral("%s expression (line %d)" % (type(node).__name__, line))


def _unknown(name, reason, env, why):
    env.pop(name, None)
    why[name] = reason


def _root(node):
    while isinstance(node, (ast.Subscript, ast.Attribute, ast.Starred)):
        node = node.value
    return node.id if isinstance(node, ast.Name) else None


def _ref(node, env, why):
    """The real (not copied) object a Name/Subscript chain points at — for `SHEET["x"] = …`."""
    if isinstance(node, ast.Name):
        return env[node.id]
    if isinstance(node, ast.Subscript) and not isinstance(node.slice, ast.Slice):
        return _ref(node.value, env, why)[_lit(node.slice, env, why)]
    raise KeyError


def _bind(target, value, err, env, why, line):
    if isinstance(target, ast.Name):
        if err is None:
            env[target.id] = value
            why.pop(target.id, None)
        else:
            _unknown(target.id, err, env, why)
        return
    if isinstance(target, (ast.Tuple, ast.List)):
        if err is None and isinstance(value, (list, tuple)) and len(value) == len(target.elts) \
                and not any(isinstance(e, ast.Starred) for e in target.elts):
            for t, v in zip(target.elts, value):
                _bind(t, v, None, env, why, line)
        else:
            for n in ast.walk(target):
                if isinstance(n, ast.Name):
                    _unknown(n.id, err or "unpacking that does not resolve (line %d)" % line, env, why)
        return
    root = _root(target)
    if root is None:
        return
    if err is None and isinstance(target, ast.Subscript) and root in env:
        try:
            _ref(target.value, env, why)[_lit(target.slice, env, why)] = copy.deepcopy(value)
            return
        except (KeyError, IndexError, TypeError, _NotLiteral):
            pass
    _unknown(root, err or "%r is changed through %s at line %d" % (root, type(target).__name__, line), env, why)


def _is_main_guard(st):
    t = getattr(st, "test", None)
    return (isinstance(st, ast.If) and isinstance(t, ast.Compare) and isinstance(t.left, ast.Name)
            and t.left.id == "__name__" and len(t.comparators) == 1
            and isinstance(t.comparators[0], ast.Constant) and t.comparators[0].value == "__main__")


def _taint_calls(node, env, why, defs, line):
    """A call to a function defined in this module may change any global its body names."""
    for n in ast.walk(node):
        if isinstance(n, ast.Call):
            touched = set()
            if isinstance(n.func, ast.Name) and n.func.id in defs:
                touched |= defs[n.func.id]
            r = _root(n.func) if isinstance(n.func, ast.Attribute) else None
            if r:
                touched.add(r)   # SHEET["sections"].append(...)
            for nm in touched:
                if nm in env or (nm == "SHEET" and nm not in why):
                    _unknown(nm, "%r may be changed by a call at line %d (G89 does not run code)" % (nm, line),
                             env, why)


def read_sheet_source(src):
    """SHEET from module source without running it: (sheet, None), (None, problem) or (None, None) if absent."""
    try:
        tree = ast.parse(src)
    except SyntaxError as e:
        return None, "is not valid Python (SyntaxError, line %s)" % e.lineno
    env, why, defs = {}, {}, {}
    for st in tree.body:
        line = getattr(st, "lineno", 0)
        if isinstance(st, ast.Expr) and isinstance(st.value, ast.Constant):
            continue                                   # docstring
        if isinstance(st, (ast.Import, ast.ImportFrom)):
            for a in st.names:
                nm = (a.asname or a.name).split(".")[0]
                if nm != "*":
                    _unknown(nm, "name %r comes from an import (line %d)" % (nm, line), env, why)
            continue
        if isinstance(st, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            _unknown(st.name, "name %r is a %s defined at line %d, not a literal"
                     % (st.name, "class" if isinstance(st, ast.ClassDef) else "function", line), env, why)
            defs[st.name] = {n.id for n in ast.walk(st) if isinstance(n, ast.Name)}
            continue
        if isinstance(st, (ast.Assign, ast.AnnAssign, ast.AugAssign)):
            if getattr(st, "value", None) is None:
                continue                               # a bare annotation
            try:
                if isinstance(st, ast.AugAssign):
                    if not isinstance(st.target, ast.Name):
                        raise _NotLiteral("augmented assignment to %s (line %d)" % (type(st.target).__name__, line))
                    value = _binop(st.op, _lit(st.target, env, why), _lit(st.value, env, why), line)
                else:
                    value = _lit(st.value, env, why)
                err = None
            except _NotLiteral as e:
                value, err = None, str(e)
                _taint_calls(st.value, env, why, defs, line)
            for t in (st.targets if isinstance(st, ast.Assign) else [st.target]):
                _bind(t, value, err, env, why, line)
            continue
        if _is_main_guard(st) or isinstance(st, ast.Pass):
            continue
        if isinstance(st, ast.Assert) and not any(isinstance(n, ast.Call) for n in ast.walk(st)):
            continue
        # anything else runs code at import time: every name it touches is unknown afterwards
        kind = "a call" if isinstance(st, ast.Expr) else "a %s statement" % type(st).__name__
        for n in ast.walk(st):
            if isinstance(n, ast.Name) and (n.id in env or n.id == "SHEET"):
                _unknown(n.id, "%r is touched by %s at line %d (G89 does not run code)" % (n.id, kind, line),
                         env, why)
        _taint_calls(st, env, why, defs, line)
    if "SHEET" in env:
        return env["SHEET"], None
    if "SHEET" in why:
        return None, ("SHEET cannot be read without running code: %s. Keep SHEET a literal "
                      "(module-level constants assigned above it are fine)" % why["SHEET"])
    return None, None


def read_sheet(py):
    return read_sheet_source(Path(py).read_text(encoding="utf-8"))


def _imports_sheet(py):
    try:
        tree = ast.parse(Path(py).read_text(encoding="utf-8"))
    except (OSError, SyntaxError, ValueError):
        return False
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and any(a.name == "SHEET" for a in node.names):
            return True
    return False


def sheet_snapshot(deliver_root):
    """(SHEET or None, messages, legacy_levels). Legacy = built levels whose snapshot has no SHEET."""
    root = Path(deliver_root)
    found, msgs, legacy = {}, [], []
    for k in LEVEL_KEYS:
        src = root / k / "source"
        if not src.is_dir():
            continue
        meta, content = src / "sheet_meta.py", src / "content.py"
        if meta.is_file():
            sh, problem = read_sheet(meta)
            if sh is not None:
                found[k] = sh
            else:
                msgs.append("level %s: source/sheet_meta.py %s" % (k, problem or "defines no SHEET"))
        elif content.is_file():
            sh, problem = read_sheet(content)
            if sh is not None:
                found[k] = sh
            elif _imports_sheet(content):
                msgs.append("level %s: content.py imports SHEET but source/sheet_meta.py is missing" % k)
            elif problem and "SHEET" in problem:
                msgs.append("level %s: source/content.py %s" % (k, problem))
            else:
                legacy.append(k)
    vals = list(found.values())
    if vals and any(v != vals[0] for v in vals):
        msgs.append("the SHEET snapshots differ between levels %s" % ",".join(sorted(found)))
    if vals and legacy:
        msgs.append("levels %s have no SHEET in their snapshot" % ",".join(legacy))
    return (vals[0] if vals else None), msgs, legacy


# ---- scans -------------------------------------------------------------------
def _walk(obj, path="$"):
    """(path, key, value) for every key and every string value in a JSON tree."""
    if isinstance(obj, dict):
        for k, v in obj.items():
            yield path, k, None
            for x in _walk(v, "%s.%s" % (path, k)):
                yield x
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            for x in _walk(v, "%s[%d]" % (path, i)):
                yield x
    elif isinstance(obj, str):
        yield path, None, obj


def _under(path, prefix):
    return path == prefix or path.startswith(prefix + ".") or path.startswith(prefix + "[")


def _fold_answer(s):
    """Answer spellings folded together (spaces kept): \\angle{BOC}, ∡BOC and ∠BOC all become boc."""
    t = clean(s)
    t = re.sub(r"\\angle\s*\{([^{}]*)\}", u"\\1", t)
    t = re.sub(r"\\(?:measured|spherical)?angle\s*", u"", t)
    t = re.sub(r"\^\s*\{\s*\\circ\s*\}|\^\s*\\circ|\\circ|\\degree", u"°", t)
    t = re.sub(r"\\(?:left|right)(?![A-Za-z])", u"", t)
    t = re.sub(r"\\cdot(?![A-Za-z])", u"·", t)
    t = re.sub(r"\\times(?![A-Za-z])", u"×", t)
    t = re.sub(r"\\[,;:! ]", u" ", t)
    t = t.replace(u"\u2212", u"-").replace(u"\u2013", u"-").replace(u"\u2014", u"-")
    return re.sub(u"[$∡∠{}]", u"", t).lower()


def akey(s):
    """The comparison form of an answer or of a public string (rule 3)."""
    return re.sub(r"\s+", u"", _fold_answer(s))


_PART_SEP = re.compile(u"[;؛]|,(?=\\s)|،|:(?=\\s)|\\s+\\(|\\)(?=\\s|$)|\\s[-–]\\s")


def _worth(c):
    if re.search(r"\d", c):
        return len(c) >= 6
    if re.search(r"[a-z]", c):
        return len(c) >= 8
    return len(c) >= 24


def answer_secrets(deliver_root, keys, sheet=None):
    """{folded answer: where it came from} for rule 3, minus anything the question side prints."""
    found, printed = {}, []
    if sheet:
        printed.append(akey(sheet.get("title")))
        printed += [akey(s.get("title")) for s in sheet.get("sections") or [] if isinstance(s, dict)]
    for k in keys:
        p = Path(deliver_root) / k / "sheet.json"
        if not p.is_file():
            continue
        try:
            sj = _load_json(p)
        except ValueError:
            continue
        printed += [akey(sj.get("title")), akey(sj.get("subtitle"))]

        def take(v, origin):
            if isinstance(v, (int, float)) and not isinstance(v, bool):
                v = str(v)
            if not isinstance(v, str):
                return
            for c in [akey(v)] + [re.sub(r"\s+", u"", x) for x in _PART_SEP.split(_fold_answer(v))]:
                if _worth(c):
                    found.setdefault(c, origin)

        def walk_q(q):
            qid = q.get("id") or "?"
            printed.append(akey(q.get("text")))
            ex = q.get("example")
            if isinstance(ex, dict):
                printed.extend([akey(ex.get("title"))] + [akey(x) for x in ex.get("lines") or []
                                                          if isinstance(x, str)])
            printed.extend(akey(x) for x in q.get("given") or [] if isinstance(x, str))
            take(q.get("answer"), "%s answer, level %s" % (qid, k))
            for f in q.get("find") or []:
                if not isinstance(f, dict):
                    continue
                take(f.get("value"), "%s find value, level %s" % (qid, k))
                of, val = f.get("of"), f.get("value")
                if isinstance(of, str) and of.strip() and isinstance(val, (str, int, float)) \
                        and re.search(r"\d", str(val)):
                    pairs = [akey(of) + u"=" + akey(str(val))]
                    if str(val).strip().startswith(u"("):
                        pairs.append(akey(of) + akey(str(val)))
                    for pr in pairs:
                        if len(pr) >= 4:
                            found.setdefault(pr, "%s: %s = %s, level %s" % (qid, of, val, k))
            for it in q.get("items") or []:
                if isinstance(it, dict):
                    walk_q(it)
        for q in sj.get("questions") or []:
            if isinstance(q, dict):
                walk_q(q)
    corpus = u"\x00".join(x for x in printed if x)
    return dict((c, o) for c, o in found.items() if c not in corpus)


def scan_public(obj, label, secrets=None, skip=()):
    """Rules 2 and 3 over any JSON tree. `skip`: paths verified equal to the registry or a frame
    (rule 3 is not applied there; rule 2 always is)."""
    if isinstance(secrets, (list, tuple, set)):
        secrets = dict((s, "a printed answer") for s in secrets)
    order = sorted((secrets or {}).items(), key=lambda x: (-len(x[0]), x[0]))
    out = []
    for path, key, val in _walk(obj):
        if key is not None:
            if DENY_KEY.search(key) and key not in PUBLIC_KEYS:
                out.append(u"%s: forbidden key %r at %s" % (label, key, path))
            continue
        cv = clean(val)
        for name, rxs in VALUE_RULES:
            for rx in rxs:
                m = rx.search(cv)
                if m:
                    out.append(u"%s: %s-like value at %s: %r" % (label, name, path, m.group(0)[:60]))
                    break
        if order and not any(_under(path, p) for p in skip):
            ak = akey(val)
            for sec, origin in order:
                if sec in ak:
                    out.append(u"%s: a printed answer appears at %s: %r (%s)" % (label, path, sec[:60], origin))
                    break
    return out


def _noam_ids(deliver_root, k):
    """(question_ids, item_ids) of out/deliver/<k>/noam-ai.json, in order."""
    na = _load_json(Path(deliver_root) / k / "noam-ai.json")
    qids, iids = [], []

    def items(node):
        for it in node.get("items") or []:
            if isinstance(it, dict) and it.get("id"):
                iids.append(it["id"])
                items(it)
    for q in na.get("questions") or []:
        qids.append(q.get("id"))
        items(q)
    return qids, iids


def _sheet_json_ids(deliver_root, k):
    p = Path(deliver_root) / k / "sheet.json"
    if not p.is_file():
        return None
    sj = _load_json(p)
    ids = set()

    def walk(node):
        for it in node.get("items") or []:
            if isinstance(it, dict) and it.get("id"):
                ids.add(it["id"])
                walk(it)
    for q in sj.get("questions") or []:
        ids.add(q.get("id"))
        walk(q)
    return ids


def _keys(obj, required, optional, label, msgs):
    if not isinstance(obj, dict):
        msgs.append("%s: not an object" % label)
        return False
    extra = [k for k in obj if k not in required and k not in optional]
    missing = [k for k in required if k not in obj]
    if extra:
        msgs.append("%s: unknown key(s) %s (schema whitelist)" % (label, ", ".join(sorted(extra))))
    if missing:
        msgs.append("%s: missing key(s) %s" % (label, ", ".join(missing)))
    return not extra and not missing


def _str_list(v):
    return isinstance(v, list) and all(isinstance(x, str) and x.strip() for x in v)


def _diff(got, want):
    got, want = list(got or []), list(want or [])
    extra = [x for x in got if x not in want]
    missing = [x for x in want if x not in got]
    bits = []
    if extra:
        bits.append("extra: %s" % ", ".join(repr(x)[:60] for x in extra[:4]))
    if missing:
        bits.append("missing: %s" % ", ".join(repr(x)[:60] for x in missing[:4]))
    return "; ".join(bits) or "order differs"


# ---- the entry ----------------------------------------------------------------
def check_entry(entry, deliver_root, sheet, allow_synthetic=False, reg=None, derived=None):
    """Rules 1, 4, 5, 6 on the entry. Returns (messages, note). Paths verified as derived go to `derived`."""
    msgs = []
    derived = derived if derived is not None else []
    reg = reg if reg is not None else Registry()
    _keys(entry, ENTRY_REQUIRED, ENTRY_OPTIONAL, "entry", msgs)
    if not isinstance(entry, dict):
        return msgs, None
    if entry.get("schema") != SCHEMA:
        msgs.append("entry: schema is %r, want %r" % (entry.get("schema"), SCHEMA))
    synthetic = bool(entry.get("synthetic"))
    if "synthetic" in entry and entry["synthetic"] is not True:
        msgs.append("entry: synthetic must be true when present")
    if synthetic and not allow_synthetic:
        msgs.append("entry is marked synthetic (generated from the registry, not built); "
                    "a synthetic entry never passes G89")
    sk = _search_key()
    if sk is None:
        msgs.append("catalog_search.py cannot be loaded: title_search, aliases and search_variants "
                    "cannot be verified")
    elif entry.get("title_search") != sk(entry.get("title") or u""):
        msgs.append("entry: title_search %r != search_key(title) %r"
                    % (entry.get("title_search"), sk(entry.get("title") or u"")))
    else:
        derived.append("$.title_search")
    for f in ("skill_version", "engine_version"):
        if not (isinstance(entry.get(f), str) and VERSION_RE.match(entry[f])):
            msgs.append("entry.%s %r is not a version string" % (f, entry.get(f)))
    for f in ("sheet_id", "package", "grade", "track", "topic_id", "scope", "title"):
        if sheet is not None and entry.get(f) != sheet.get(f):
            msgs.append("entry.%s %r != SHEET.%s %r" % (f, entry.get(f), f, sheet.get(f)))
    if sheet is not None:
        if entry.get("landing_slug") != (sheet.get("landing") or {}).get("slug"):
            msgs.append("entry.landing_slug %r != SHEET.landing.slug %r"
                        % (entry.get("landing_slug"), (sheet.get("landing") or {}).get("slug")))
        if entry.get("replaces") != list(sheet.get("replaces") or []):
            msgs.append("entry.replaces != SHEET.replaces")
    if not isinstance(entry.get("replaces"), list):
        msgs.append("entry.replaces must be a list")
    if reg.error:
        msgs.append("registry unreadable (%s): aliases, definitions and related topics cannot be verified"
                    % reg.error)

    # levels
    levels = entry.get("levels") if isinstance(entry.get("levels"), dict) else {}
    if not levels:
        msgs.append("entry.levels is empty or not an object")
    for k, lv in levels.items():
        lab = "levels.%s" % k
        if k not in LEVEL_KEYS:
            msgs.append("%s: unknown level key" % lab)
            continue
        _keys(lv, LEVEL_FIELDS, (), lab, msgs)
        if not isinstance(lv, dict):
            continue
        if lv.get("name") != LEVEL_NAMES[k]:
            msgs.append("%s.name %r != %r" % (lab, lv.get("name"), LEVEL_NAMES[k]))
        if not isinstance(lv.get("question_ids"), list) or not all(
                isinstance(q, str) and QID_RE.match(q) for q in lv.get("question_ids") or []):
            msgs.append("%s.question_ids must be a list of q<n>" % lab)
        if not isinstance(lv.get("item_ids"), list) or not all(
                isinstance(q, str) and ITEM_RE.match(q) for q in lv.get("item_ids") or []):
            msgs.append("%s.item_ids must be a list of q<n><x>" % lab)
        pages = lv.get("pages")
        if not (isinstance(pages, int) and not isinstance(pages, bool) and pages >= 1) \
                and not (synthetic and pages is None):
            msgs.append("%s.pages must be a positive integer" % lab)

    # deliver cross-checks
    deliver_q = {}
    note = "synthetic entry: deliver cross-checks skipped" if synthetic and allow_synthetic else None
    if not synthetic:
        root = Path(deliver_root) if deliver_root else None
        present = [k for k in LEVEL_KEYS if root and (root / k / "noam-ai.json").is_file()]
        if not present:
            msgs.append("no out/deliver/<k>/noam-ai.json under %s" % (deliver_root,))
        for k in present:
            if k not in levels:
                msgs.append("level %s is in out/deliver but not in the entry" % k)
        for k in levels:
            if k in LEVEL_KEYS and k not in present:
                msgs.append("levels.%s has no out/deliver/%s/noam-ai.json" % (k, k))
        engine_said = False
        for k in present:
            try:
                qids, iids = _noam_ids(root, k)
            except (OSError, ValueError) as e:
                msgs.append("level %s: noam-ai.json unreadable (%s)" % (k, type(e).__name__))
                continue
            deliver_q[k] = qids
            lv = levels.get(k) if isinstance(levels.get(k), dict) else {}
            if lv.get("question_ids") != qids:
                missing = [q for q in lv.get("question_ids") or [] if q not in qids]
                msgs.append("levels.%s.question_ids != noam-ai.json questions%s"
                            % (k, (" (not in noam-ai.json: %s)" % ", ".join(missing)) if missing else ""))
            if lv.get("item_ids") != iids:
                msgs.append("levels.%s.item_ids != noam-ai.json items" % k)
            sj = _sheet_json_ids(root, k)
            if sj is not None:
                lost = [q for q in (lv.get("question_ids") or []) + (lv.get("item_ids") or [])
                        if q not in sj]
                if lost:
                    msgs.append("level %s: id(s) not in sheet.json: %s" % (k, ", ".join(lost[:12])))
            bj = root / k / "build.json"
            if bj.is_file():
                try:
                    bjd = _load_json(bj)
                except ValueError:
                    bjd = {}
                pg = bjd.get("pages")
                if isinstance(pg, int) and lv.get("pages") != pg:
                    msgs.append("levels.%s.pages %r != build.json pages %r" % (k, lv.get("pages"), pg))
                ev = bjd.get("skill_version")
                if isinstance(ev, str) and entry.get("engine_version") != ev and not engine_said:
                    msgs.append("entry.engine_version %r != build.json skill_version %r (the engine that "
                                "built level %s)" % (entry.get("engine_version"), ev, k))
                    engine_said = True

    # sections
    secs = entry.get("sections") if isinstance(entry.get("sections"), list) else []
    if not secs:
        msgs.append("entry.sections is empty")
    cs = _catalog_search()
    combo_base = _combo_base(entry.get("topic_id"))
    ids, anchors = [], []
    for i, s in enumerate(secs):
        lab = "sections[%d]" % i
        _keys(s, SECTION_REQUIRED, SECTION_OPTIONAL, lab, msgs)
        if not isinstance(s, dict):
            continue
        ids.append(s.get("id"))
        anchors.append(s.get("anchor"))
        if not (isinstance(s.get("anchor"), str) and ANCHOR_RE.match(s["anchor"])):
            msgs.append("%s.anchor %r is not a slug" % (lab, s.get("anchor")))
        for f in ("aliases", "search_variants"):
            if not isinstance(s.get(f), list) or (s.get(f) and not _str_list(s.get(f))):
                msgs.append("%s.%s must be a list of non-empty strings" % (lab, f))
        kind = s.get("kind")
        if kind == "combo":
            if s.get("subtopic") is not None:
                msgs.append("%s: a combo section has subtopic null" % lab)
            if not _str_list(s.get("combines")):
                msgs.append("%s: a combo section needs combines" % lab)
            if not _anchor_ok(s.get("anchor"), combo_base):
                msgs.append("%s.anchor %r is not %r (a combo anchor is the topic slug + '-combo')"
                            % (lab, s.get("anchor"), combo_base))
            for f in ("aliases", "search_variants"):
                if s.get(f) != []:
                    msgs.append("%s.%s must be empty for a combo section" % (lab, f))
                else:
                    derived.append("$.sections[%d].%s" % (i, f))
        elif kind == "subtopic":
            if "combines" in s:
                msgs.append("%s: combines is only for combo sections" % lab)
            sub = s.get("subtopic")
            if not (isinstance(sub, str) and sub.startswith("st.")):
                msgs.append("%s.subtopic %r is not a registry id" % (lab, sub))
            else:
                try:
                    base = anchor_for(sub)
                except ValueError:
                    base = None
                if base is None or not _anchor_ok(s.get("anchor"), base):
                    msgs.append("%s.anchor %r is not the subtopic's slug %r" % (lab, s.get("anchor"), base))
                ent = reg.get(sub)
                if ent is None and not reg.error:
                    msgs.append("%s.subtopic %r is not in the registry (curriculum_tashpaz.json subtopics)"
                                % (lab, sub))
                if ent is not None and cs is not None:
                    want_al = cs.aliases_for(ent, reg.glossary)
                    if s.get("aliases") != want_al:
                        msgs.append("%s.aliases are not the registry's for %s (%s)"
                                    % (lab, sub, _diff(s.get("aliases"), want_al)))
                    else:
                        derived.append("$.sections[%d].aliases" % i)
                    want_v = cs.search_variants_for(s.get("title") or u"", want_al)
                    if s.get("search_variants") != want_v:
                        msgs.append("%s.search_variants are not the generated spellings of its title and "
                                    "aliases (%s)" % (lab, _diff(s.get("search_variants"), want_v)))
                    else:
                        derived.append("$.sections[%d].search_variants" % i)
        else:
            msgs.append("%s.kind %r (want subtopic or combo)" % (lab, kind))
        qd = s.get("question_ids")
        if not isinstance(qd, dict):
            msgs.append("%s.question_ids must be an object keyed by level" % lab)
            continue
        for k, ql in qd.items():
            if k not in levels:
                msgs.append("%s.question_ids.%s: no such level in the entry" % (lab, k))
            if not isinstance(ql, list) or not all(isinstance(q, str) and QID_RE.match(q) for q in ql):
                msgs.append("%s.question_ids.%s must be a list of q<n>" % (lab, k))
        for k in levels:
            if k not in qd:
                msgs.append("%s.question_ids has no level %s" % (lab, k))
    if len(set(ids)) != len(ids):
        msgs.append("duplicate section ids")
    if len(set(map(str, anchors))) != len(anchors):
        msgs.append("duplicate section anchors")
    for s in secs:
        if isinstance(s, dict) and s.get("kind") == "combo":
            bad = [c for c in s.get("combines") or [] if c not in ids]
            if bad:
                msgs.append("%s combines unknown section(s) %s" % (s.get("id"), ", ".join(map(str, bad))))
    subs = [s.get("subtopic") for s in secs if isinstance(s, dict) and s.get("kind") == "subtopic"]
    want_subs = []
    for x in subs:
        if x not in want_subs:
            want_subs.append(x)
    if entry.get("subtopic_ids") != want_subs:
        msgs.append("subtopic_ids %r != the section subtopics in order %r" % (entry.get("subtopic_ids"), want_subs))

    # per level: membership, disjoint, union == all questions
    for k, lv in levels.items():
        if not isinstance(lv, dict):
            continue
        allq = deliver_q.get(k, lv.get("question_ids") or [])
        seen = {}
        for s in secs:
            if not isinstance(s, dict) or not isinstance(s.get("question_ids"), dict):
                continue
            for q in s["question_ids"].get(k) or []:
                if q in seen:
                    msgs.append("level %s: %s is in both %s and %s (sections must be disjoint)"
                                % (k, q, seen[q], s.get("id")))
                seen[q] = s.get("id")
                if not synthetic and k in deliver_q and q not in deliver_q[k]:
                    msgs.append("level %s: %s (section %s) is not in noam-ai.json" % (k, q, s.get("id")))
        union = set(seen)
        if union != set(allq):
            lost = [q for q in allq if q not in union]
            extra = sorted(union - set(allq), key=lambda x: int(x[1:]) if x[1:].isdigit() else 0)
            msgs.append("level %s: union of section question ids != the level's questions%s%s"
                        % (k, (" (in no section: %s)" % ", ".join(lost)) if lost else "",
                           (" (not questions of the level: %s)" % ", ".join(extra)) if extra else ""))

    # against SHEET
    if sheet is not None:
        ssecs = sheet.get("sections") or []
        if len(ssecs) != len(secs):
            msgs.append("entry has %d sections, SHEET has %d" % (len(secs), len(ssecs)))
        for i, (es, ss) in enumerate(zip(secs, ssecs)):
            if not isinstance(es, dict) or not isinstance(ss, dict):
                continue
            skind = ss.get("kind", "subtopic")
            for f, want in (("id", ss.get("id")), ("kind", skind), ("title", ss.get("title")),
                            ("subtopic", ss.get("subtopic") if skind != "combo" else None)):
                if es.get(f) != want:
                    msgs.append("sections[%d].%s %r != SHEET %r" % (i, f, es.get(f), want))
            if skind == "combo" and es.get("combines") != list(ss.get("combines") or []):
                msgs.append("sections[%d].combines != SHEET" % i)
            sq = ss.get("questions") or {}
            for k in levels:
                try:
                    want = ["q%d" % int(n) for n in sq.get(k) or []]
                except (TypeError, ValueError):
                    want = None
                got = (es.get("question_ids") or {}).get(k) if isinstance(es.get("question_ids"), dict) else None
                if got != want:
                    msgs.append("sections[%d].question_ids.%s %r != SHEET %r" % (i, k, got, want))
    return msgs, note


# ---- the landing ----------------------------------------------------------------
def expected_intro(entry, reg):
    """The landing intro: the first registry explain_he sentence of every subtopic section, or the title."""
    out = []
    for s in entry.get("sections") or []:
        if isinstance(s, dict) and s.get("kind") == "subtopic":
            ex = _explain(reg.get(s.get("subtopic")))
            if ex:
                out.append(ex[0])
    return u" ".join(out) or entry.get("title")


def check_landing(landing, entry, sheet, reg=None, derived=None):
    """Rule 7. Returns the messages; paths verified as registry/frame text go to `derived`."""
    msgs = []
    derived = derived if derived is not None else []
    reg = reg if reg is not None else Registry()
    _keys(landing, LANDING_REQUIRED, LANDING_OPTIONAL, "landing", msgs)
    if not isinstance(landing, dict) or not isinstance(entry, dict):
        return msgs
    if landing.get("schema") != LANDING_SCHEMA:
        msgs.append("landing: schema is %r, want %r" % (landing.get("schema"), LANDING_SCHEMA))
    if bool(landing.get("synthetic")) != bool(entry.get("synthetic")):
        msgs.append("landing.synthetic disagrees with the entry")
    title = entry.get("title")
    for f, want in (("sheet_id", entry.get("sheet_id")), ("slug", entry.get("landing_slug")), ("title", title)):
        if landing.get(f) != want:
            msgs.append("landing.%s %r != %r" % (f, landing.get(f), want))
    if landing.get("path") != "/" + str(landing.get("slug")) or not ANCHOR_RE.match(str(landing.get("slug"))):
        msgs.append("landing.path must be '/' + slug, and the slug a lowercase slug")
    grade = str(entry.get("grade"))
    want_grade = int(grade) if grade.isdigit() else grade
    if landing.get("grade") != want_grade or isinstance(landing.get("grade"), bool):
        msgs.append("landing.grade %r != the entry's grade %r" % (landing.get("grade"), want_grade))
    ghe = GRADE_HE.get(grade, grade)
    for f, want in (("h1", H1_FRAME % (title, ghe)), ("description", DESCRIPTION_FRAME % (ghe, title)),
                    ("intro", expected_intro(entry, reg))):
        if not (isinstance(landing.get(f), str) and landing[f].strip()):
            msgs.append("landing.%s must be non-empty text" % f)
        elif landing.get(f) != want:
            msgs.append("landing.%s is not the expected text %r" % (f, (want or u"")[:80]))
        else:
            derived.append("$.%s" % f)
    secs = [s for s in entry.get("sections") or [] if isinstance(s, dict)]
    by_anchor = dict((s.get("anchor"), s) for s in secs)
    by_id = dict((s.get("id"), s) for s in secs)
    anchors = landing.get("anchors") if isinstance(landing.get("anchors"), list) else []
    names = []
    for i, a in enumerate(anchors):
        lab = "landing.anchors[%d]" % i
        _keys(a, ANCHOR_REQUIRED, ANCHOR_OPTIONAL, lab, msgs)
        if not isinstance(a, dict):
            continue
        names.append(a.get("anchor"))
        es = by_anchor.get(a.get("anchor"))
        if es is None:
            msgs.append("%s: anchor %r is not a section anchor of the entry" % (lab, a.get("anchor")))
            continue
        if a.get("kind") != es.get("kind") or a.get("subtopic") != es.get("subtopic"):
            msgs.append("%s: kind/subtopic disagree with section %s" % (lab, es.get("id")))
        if a.get("title") != es.get("title"):
            msgs.append("%s.title %r != section title %r" % (lab, a.get("title"), es.get("title")))
        ex = a.get("example_question_ids")
        level_a = list((es.get("question_ids") or {}).get("a") or [])
        if not (isinstance(ex, list) and 1 <= len(ex) <= 2 and all(q in level_a for q in ex)):
            msgs.append("%s.example_question_ids must be 1-2 ids of level a of that section" % lab)
        if not (_str_list(a.get("explain_he")) and 1 <= len(a.get("explain_he")) <= 2):
            msgs.append("%s.explain_he must hold 1-2 sentences" % lab)
        if es.get("kind") == "combo":
            want = [by_id[c].get("anchor") for c in es.get("combines") or [] if c in by_id]
            if a.get("combines") != want:
                msgs.append("%s.combines must list the anchors of the combined sections" % lab)
            if a.get("definition_he") is not None or a.get("definition_plain") is not None:
                msgs.append("%s: a combo anchor has no definition (null)" % lab)
            names_he = [by_id[c].get("title") for c in es.get("combines") or [] if c in by_id]
            want_ex = [COMBO_EXPLAIN[0] % u", ".join(map(str, names_he)), COMBO_EXPLAIN[1]]
            if a.get("explain_he") != want_ex:
                msgs.append("%s.explain_he is not the fixed combo frame" % lab)
            else:
                derived.append("$.anchors[%d].explain_he" % i)
            continue
        ent = reg.get(es.get("subtopic"))
        if ent is None:
            if not reg.error:
                msgs.append("%s: subtopic %r is not in the registry" % (lab, es.get("subtopic")))
            continue
        want_def = ent.get("definition_he")
        if not (isinstance(a.get("definition_he"), str) and a["definition_he"].strip()):
            msgs.append("%s.definition_he is empty" % lab)
        elif a.get("definition_he") != want_def:
            msgs.append("%s.definition_he is not the registry definition of %s" % (lab, es.get("subtopic")))
        else:
            derived.append("$.anchors[%d].definition_he" % i)
        if a.get("definition_plain") != plain_math(want_def):
            msgs.append("%s.definition_plain is not plain_math(the registry definition of %s)"
                        % (lab, es.get("subtopic")))
        else:
            derived.append("$.anchors[%d].definition_plain" % i)
        if a.get("explain_he") != _explain(ent):
            msgs.append("%s.explain_he is not the registry explain_he of %s" % (lab, es.get("subtopic")))
        else:
            derived.append("$.anchors[%d].explain_he" % i)
    if len(set(map(str, names))) != len(names):
        msgs.append("landing: duplicate anchors")
    lost = [s.get("anchor") for s in secs if s.get("anchor") not in names]
    if lost:
        msgs.append("landing: no anchor for section(s) %s" % ", ".join(map(str, lost)))
    if len(anchors) != len(secs):
        msgs.append("landing: %d anchors for %d sections (exactly one each)" % (len(anchors), len(secs)))
    elif not lost and names != [s.get("anchor") for s in secs]:
        msgs.append("landing: anchors are not in the section order")
    anim = landing.get("animation")
    land_cfg = ((sheet or {}).get("landing") or {}) if sheet is not None else {}
    if isinstance(anim, list):
        msgs.append("landing.animation must be ONE object, got a list of %d" % len(anim))
    elif _keys(anim, ANIMATION_FIELDS, (), "landing.animation", msgs):
        if sheet is not None and anim.get("id") != land_cfg.get("animation_id"):
            msgs.append("landing.animation.id %r != SHEET.landing.animation_id %r"
                        % (anim.get("id"), land_cfg.get("animation_id")))
        if not (isinstance(anim.get("id"), str) and anim["id"].strip()):
            msgs.append("landing.animation.id is empty")
        if anim.get("anchor") not in names:
            msgs.append("landing.animation.anchor %r is not one of the landing anchors" % (anim.get("anchor"),))
        elif land_cfg.get("animation_anchor") in names and anim.get("anchor") != land_cfg["animation_anchor"]:
            msgs.append("landing.animation.anchor %r != SHEET.landing.animation_anchor %r"
                        % (anim.get("anchor"), land_cfg["animation_anchor"]))
        if not (isinstance(anim.get("alt_he"), str) and anim["alt_he"].strip()):
            msgs.append("landing.animation.alt_he is empty")
        else:
            at = by_anchor.get(anim.get("anchor")) or {}
            frame = ALT_FRAME % (at.get("title") or title)
            authored = land_cfg.get("animation_alt_he")
            if authored:
                if anim["alt_he"] != authored:
                    msgs.append("landing.animation.alt_he != SHEET.landing.animation_alt_he")
            elif anim["alt_he"] != frame:
                msgs.append("landing.animation.alt_he is neither SHEET.landing.animation_alt_he nor the fixed "
                            "frame %r" % frame)
            else:
                derived.append("$.animation.alt_he")
    dl = landing.get("downloads")
    levels = entry.get("levels") if isinstance(entry.get("levels"), dict) else {}
    if not isinstance(dl, dict) or sorted(dl) != sorted(levels):
        msgs.append("landing.downloads must be keyed by the entry's levels")
    else:
        ok = True
        for k, d in dl.items():
            if not _keys(d, DOWNLOAD_FIELDS, (), "landing.downloads.%s" % k, msgs):
                ok = False
                continue
            if d.get("label") != (levels.get(k) or {}).get("name"):
                msgs.append("landing.downloads.%s.label %r != the level name" % (k, d.get("label")))
                ok = False
            for f in ("pdf", "docx"):
                v = d.get(f)
                want = "%s_%s.%s" % (entry.get("sheet_id"), k, f)
                if not (isinstance(v, str) and re.match(r"^[\w.-]+\.%s$" % f, v)):
                    msgs.append("landing.downloads.%s.%s %r must be a bare .%s file name" % (k, f, v, f))
                    ok = False
                elif v != want:
                    msgs.append("landing.downloads.%s.%s %r != %r (this sheet, this level)" % (k, f, v, want))
                    ok = False
        if ok:
            derived.append("$.downloads")
    rel = landing.get("relatedTopics")
    own = set(entry.get("subtopic_ids") or [])
    reqs = set()
    for sid in own:
        reqs |= set((reg.get(sid) or {}).get("requires") or [])
    if not isinstance(rel, list):
        msgs.append("landing.relatedTopics must be a list")
    else:
        seen = set()
        for i, r in enumerate(rel):
            lab = "landing.relatedTopics[%d]" % i
            if not _keys(r, RELATED_FIELDS, (), lab, msgs):
                continue
            sid = r.get("subtopic")
            if sid in seen:
                msgs.append("%s: subtopic %r listed twice" % (lab, sid))
            seen.add(sid)
            if r.get("relation") not in ("requires", "next"):
                msgs.append("%s.relation must be requires/next" % lab)
            pth = r.get("path")
            if pth is not None and not (isinstance(pth, str) and pth.startswith("/") and ANCHOR_RE.match(pth[1:])):
                msgs.append("%s.path must be null or '/<slug>'" % lab)
            ent = reg.get(sid)
            if ent is None:
                if not reg.error:
                    msgs.append("%s.subtopic %r is not in the registry" % (lab, sid))
                continue
            if sid in own:
                msgs.append("%s: %s is a section of this sheet, not a related topic" % (lab, sid))
            elif r.get("relation") == "requires" and sid not in reqs:
                msgs.append("%s: no section of this sheet requires %s" % (lab, sid))
            elif r.get("relation") == "next" and not own & set(ent.get("requires") or []):
                msgs.append("%s: %s does not require any section of this sheet" % (lab, sid))
            try:
                want_anchor = anchor_for(sid)
            except ValueError:
                want_anchor = None
            if r.get("anchor") != want_anchor or r.get("sheet") != ent.get("sheet"):
                msgs.append("%s: anchor/sheet are not the registry's for %s" % (lab, sid))
            if r.get("label") != (ent.get("title") or sid):
                msgs.append("%s.label %r is not the registry title of %s" % (lab, r.get("label"), sid))
            else:
                derived.append("$.relatedTopics[%d].label" % i)
    cta = landing.get("catalogCta")
    if _keys(cta, CTA_FIELDS, (), "landing.catalogCta", msgs):
        if cta.get("label") != CTA_LABEL:
            msgs.append("landing.catalogCta.label is not the fixed label")
        else:
            derived.append("$.catalogCta.label")
        if cta.get("catalogTopicTitle") != title:
            msgs.append("landing.catalogCta.catalogTopicTitle != the sheet title")
        else:
            derived.append("$.catalogCta.catalogTopicTitle")
        if cta.get("href") is not None and not (isinstance(cta.get("href"), str) and cta["href"].startswith("/")):
            msgs.append("landing.catalogCta.href must be null or a site path '/…'")
        if cta.get("catalogTopicId") is not None and not isinstance(cta.get("catalogTopicId"), str):
            msgs.append("landing.catalogCta.catalogTopicId must be null or a string")
    return msgs


# ---- entry point ----------------------------------------------------------------
def check(entry_path, deliver_root, sheet=None, allow_synthetic=False, landing_path=None, registry_dir=None):
    """G89 on one catalog entry (and the landing.json beside it). Returns {"status", "messages"}."""
    msgs = []
    ep = Path(entry_path)
    snap_msgs, legacy = [], []
    if sheet is None and deliver_root:
        try:
            sheet, snap_msgs, legacy = sheet_snapshot(deliver_root)
        except OSError as e:
            snap_msgs = ["cannot read the SHEET snapshot (%s)" % e]
    if not ep.is_file():
        if sheet is None and legacy and not snap_msgs:
            return {"status": "SKIP", "messages": ["legacy package (no SHEET)"]}
        return {"status": "FAIL", "messages": ["catalog entry missing: %s" % ep.name] + snap_msgs}
    try:
        entry = _load_json(ep)
    except (OSError, ValueError) as e:
        return {"status": "FAIL", "messages": ["catalog entry unreadable: %s" % e]}
    if not isinstance(entry, dict):
        return {"status": "FAIL", "messages": ["catalog entry is not a JSON object"]}
    synthetic = bool(entry.get("synthetic"))
    if sheet is None and not (synthetic and allow_synthetic):
        msgs.append("no SHEET to check against: " + ("; ".join(snap_msgs) if snap_msgs else
                                                      "no out/deliver/<k>/source/sheet_meta.py snapshot found"))
    else:
        msgs += snap_msgs
    reg = Registry(registry_dir)
    keys = [k for k in LEVEL_KEYS if k in (entry.get("levels") or {})]
    secrets = answer_secrets(deliver_root, keys, sheet) if deliver_root and not synthetic else {}
    derived = []
    em, note = check_entry(entry, deliver_root, sheet, allow_synthetic, reg=reg, derived=derived)
    msgs += em
    msgs += scan_public(entry, "entry", secrets, skip=derived)
    lp = Path(landing_path) if landing_path else ep.with_name("landing.json")
    if lp.is_file():
        try:
            landing = _load_json(lp)
        except ValueError as e:
            msgs.append("landing.json unreadable: %s" % e)
        else:
            ld = []
            msgs += check_landing(landing, entry, sheet, reg=reg, derived=ld)
            msgs += scan_public(landing, "landing", secrets, skip=ld)
    else:
        msgs.append("landing.json missing beside the entry")
    if msgs:
        return {"status": "FAIL", "messages": msgs}
    ok = ["%s: %d sections, levels %s, landing ok" % (entry.get("sheet_id"), len(entry.get("sections") or []),
                                                     ",".join(keys))]
    if note:
        ok.append(note)
    return {"status": "PASS", "messages": ok}


def gate_record(entry_path, deliver_root, sheet=None):
    r = check(entry_path, deliver_root, sheet)
    return {"gate": GATE, "level": None, "status": r["status"], "messages": r["messages"]}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("entry", nargs="?", help="catalog-entry.json")
    ap.add_argument("--deliver", help="out/deliver (with a, b, c inside)")
    ap.add_argument("--landing", help="landing.json (default: beside the entry)")
    ap.add_argument("--json", help="write the gate record here")
    ap.add_argument("--allow-synthetic", action="store_true",
                    help="accept an entry generated from the registry (tests only)")
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args(argv)
    if a.selftest:
        return selftest()
    if not a.entry or (not a.deliver and not a.allow_synthetic):
        ap.error("ENTRY and --deliver are required")
    r = check(a.entry, a.deliver, allow_synthetic=a.allow_synthetic, landing_path=a.landing)
    rec = {"gate": GATE, "level": None, "status": r["status"], "messages": r["messages"]}
    print("%s %s" % (GATE, r["status"]))
    for m in r["messages"]:
        print("  - " + m)
    if a.json:
        Path(a.json).write_text(json.dumps(rec, ensure_ascii=False, indent=1), encoding="utf-8")
    return 1 if r["status"] == "FAIL" else 0


# ---- selftest (builds its own tiny deliver tree; reads the real registry) -------
_SHEET_SRC = u'''SHEET = {
    "schema": "noam-sheet-sections/v1", "sheet_id": "T7-ANG-99", "package": "G7-T99",
    "grade": "7", "track": u"ז", "topic_id": "angles", "scope": "sectioned",
    "title": u"זוויות צמודות וזוויות קודקודיות",
    "sections": [
        {"id": "T7-ANG-99.s1", "subtopic": "st.g7.angles.adjacent", "kind": "subtopic",
         "title": u"זוויות צמודות", "questions": {"a": [1, 2], "b": [1, 2]}, "justification": None},
        {"id": "T7-ANG-99.s2", "subtopic": "st.g7.angles.vertical", "kind": "subtopic",
         "title": u"זוויות קודקודיות", "questions": {"a": [3], "b": [3]}, "justification": None},
        {"id": "T7-ANG-99.s3", "kind": "combo", "title": u"שילוב",
         "combines": ["T7-ANG-99.s1", "T7-ANG-99.s2"], "questions": {"a": [4], "b": [4]}},
    ],
    "landing": {"slug": "selftest-angles", "animation_id": "rotating-ray"},
    "replaces": [],
}
'''
# the same SHEET written with module-level names, %, +, f-strings, range and a comprehension
_SHEET_SRC_NAMES = u'''# -*- coding: utf-8 -*-
"""doc"""
SID = "T7-ANG-99"
_TWO = list(range(1, 3))
_LEVELS = "ab"
TITLE = u"זוויות צמודות" + u" וזוויות קודקודיות"
BASE = {"schema": "noam-sheet-sections/v1", "grade": "7", "track": u"ז"}
SHEET = {
    **BASE, "sheet_id": SID, "package": "G7-T99", "topic_id": "angles", "scope": "sectioned",
    "title": TITLE,
    "sections": [
        {"id": SID + ".s1", "subtopic": "st.g7.angles.adjacent", "kind": "subtopic",
         "title": u"זוויות צמודות", "questions": {k: _TWO for k in _LEVELS}, "justification": None},
        {"id": "%s.s2" % SID, "subtopic": "st.g7.angles.vertical", "kind": "subtopic",
         "title": u"זוויות קודקודיות", "questions": dict(a=[3], b=[3]), "justification": None},
        {"id": f"{SID}.s3", "kind": "combo", "title": u"שילוב",
         "combines": [SID + ".s1", SID + ".s2"], "questions": {"a": [4], "b": [2 * 2]}},
    ],
    "landing": {"slug": "selftest-angles", "animation_id": "rotating-ray"},
    "replaces": [],
}
if __name__ == "__main__":
    print(SHEET)
'''


def _selftest_tree(root, reg):
    """A deliver tree (levels a, b) + an entry and landing derived the way the builders derive them."""
    root = Path(root)
    sheet = read_sheet_source(_SHEET_SRC)[0]
    for k in ("a", "b"):
        d = root / "deliver" / k
        (d / "source").mkdir(parents=True)
        (d / "source" / "sheet_meta.py").write_text(_SHEET_SRC, encoding="utf-8")
        qs = [{"id": "q%d" % n, "items": [{"id": "q%da" % n}, {"id": "q%db" % n}]} for n in (1, 2, 3, 4)]
        (d / "noam-ai.json").write_text(json.dumps({"questions": qs}), encoding="utf-8")
        sq = [{"id": "q%d" % n, "text": u"נתון: $\\angle{AOC}=58°$.",
               "example": {"title": u"תזכורת", "lines": [u"סכום זוויות צמודות הוא $180°$."]},
               "items": [{"id": "q%da" % n, "answer": u"$\\angle{BOC}=122°$ (סכום זוויות צמודות $180°$)",
                          "find": [{"of": "BOC", "value": "122"}]},
                         {"id": "q%db" % n, "answer": u"$\\angle{AOC}$ חדה, $\\angle{BOC}$ קהה"},
                         {"id": "q%dc" % n, "answer": u"64°"}]} for n in (1, 2, 3, 4)]
        (d / "sheet.json").write_text(json.dumps({"title": sheet["title"], "questions": sq}), encoding="utf-8")
        (d / "build.json").write_text(json.dumps({"pages": 3, "skill_version": "6.18-noam"}), encoding="utf-8")
    cs = _catalog_search()
    title = sheet["title"]
    lv = lambda k: {"name": LEVEL_NAMES[k], "question_ids": ["q1", "q2", "q3", "q4"],
                    "item_ids": [x for n in (1, 2, 3, 4) for x in ("q%da" % n, "q%db" % n)], "pages": 3}

    def sec(i, sub, t, anchor, qa):
        al = cs.aliases_for(reg.get(sub), reg.glossary)
        return {"id": "T7-ANG-99.s%d" % i, "subtopic": sub, "kind": "subtopic", "title": t, "anchor": anchor,
                "aliases": al, "search_variants": cs.search_variants_for(t, al),
                "question_ids": {"a": qa, "b": list(qa)}}
    entry = {"schema": SCHEMA, "sheet_id": "T7-ANG-99", "package": "G7-T99", "grade": "7", "track": u"ז",
             "topic_id": "angles", "scope": "sectioned", "title": title, "title_search": cs.search_key(title),
             "levels": {"a": lv("a"), "b": lv("b")},
             "sections": [
                 sec(1, "st.g7.angles.adjacent", u"זוויות צמודות", "angles-adjacent", ["q1", "q2"]),
                 sec(2, "st.g7.angles.vertical", u"זוויות קודקודיות", "angles-vertical", ["q3"]),
                 {"id": "T7-ANG-99.s3", "subtopic": None, "kind": "combo", "title": u"שילוב",
                  "anchor": "angles-combo", "aliases": [], "search_variants": [],
                  "question_ids": {"a": ["q4"], "b": ["q4"]}, "combines": ["T7-ANG-99.s1", "T7-ANG-99.s2"]}],
             "subtopic_ids": ["st.g7.angles.adjacent", "st.g7.angles.vertical"], "replaces": [],
             "landing_slug": "selftest-angles", "skill_version": "7.2.0-noam", "engine_version": "6.18-noam"}

    def anchor(s, ex):
        if s["kind"] == "combo":
            return {"anchor": s["anchor"], "kind": "combo", "subtopic": None, "title": s["title"],
                    "definition_he": None, "definition_plain": None,
                    "explain_he": [COMBO_EXPLAIN[0] % u"זוויות צמודות, זוויות קודקודיות", COMBO_EXPLAIN[1]],
                    "example_question_ids": ex, "combines": ["angles-adjacent", "angles-vertical"]}
        e = reg.get(s["subtopic"])
        return {"anchor": s["anchor"], "kind": "subtopic", "subtopic": s["subtopic"], "title": s["title"],
                "definition_he": e.get("definition_he"), "definition_plain": plain_math(e.get("definition_he")),
                "explain_he": _explain(e), "example_question_ids": ex}
    rel_sid = "st.g7.angles.sum_diff"
    rel = reg.get(rel_sid)
    landing = {"schema": LANDING_SCHEMA, "sheet_id": "T7-ANG-99", "slug": "selftest-angles",
               "path": "/selftest-angles", "grade": 7, "title": title, "h1": H1_FRAME % (title, GRADE_HE["7"]),
               "description": DESCRIPTION_FRAME % (GRADE_HE["7"], title), "intro": expected_intro(entry, reg),
               "anchors": [anchor(entry["sections"][0], ["q1", "q2"]), anchor(entry["sections"][1], ["q3"]),
                           anchor(entry["sections"][2], ["q4"])],
               "animation": {"id": "rotating-ray", "anchor": "angles-adjacent",
                             "alt_he": ALT_FRAME % u"זוויות צמודות"},
               "downloads": dict((k, {"label": LEVEL_NAMES[k], "pdf": "T7-ANG-99_%s.pdf" % k,
                                      "docx": "T7-ANG-99_%s.docx" % k}) for k in ("a", "b")),
               "relatedTopics": [{"label": rel.get("title"), "subtopic": rel_sid, "relation": "requires",
                                  "sheet": rel.get("sheet"), "anchor": anchor_for(rel_sid), "path": None}],
               "catalogCta": {"label": CTA_LABEL, "href": None, "catalogTopicId": None, "catalogTopicTitle": title}}
    return entry, landing


def selftest():
    import shutil
    import tempfile
    t0 = time.time()
    fails = []
    reg = Registry()
    if reg.error or _catalog_search() is None:
        print("selfcheck_catalog selftest: cannot run (registry: %s; catalog_search loaded: %s)"
              % (reg.error, _catalog_search() is not None))
        return 1
    # the literal evaluator
    a, pa = read_sheet_source(_SHEET_SRC)
    b, pb = read_sheet_source(_SHEET_SRC_NAMES)
    if a is None or b != a:
        fails.append("evaluator: names/%%/f-string/range/comprehension SHEET differs (%s / %s)" % (pa, pb))
    for src, needle in (("import x\nSHEET = {'a': x.Y}\n", "comes from an import"),
                        ("def f():\n    return {}\nSHEET = f()\n", "is a function"),
                        ("SHEET = make_sheet()\n", "call to make_sheet()"),
                        ("SHEET = {'s': []}\nfor i in range(3):\n    SHEET['s'].append(i)\n", "touched by a For"),
                        ("SHEET = {'s': []}\nSHEET['s'].append(1)\n", "touched by a call"),
                        ("def f():\n    SHEET['s'] = 2\nSHEET = {'s': 1}\nf()\n", "changed by a call at line 4"),
                        ("SHEET = {'s': {k: 1 for k in 'ab' if k}}\n", "conditions")):
        sh, problem = read_sheet_source(src)
        if sh is not None or not problem or needle not in problem or "without running code" not in problem:
            fails.append("evaluator should refuse %r with %r, got %r / %r" % (src[:40], needle, sh, problem))
    sh, problem = read_sheet_source("SHEET = {'x': {'y': 1}}\nSHEET['x']['y'] = 2\n")
    if sh != {"x": {"y": 2}}:
        fails.append("evaluator: subscript assignment not followed (%r %r)" % (sh, problem))
    if read_sheet_source("PACKAGE = 'G7-T13'\n") != (None, None):
        fails.append("evaluator: a module without SHEET must read as absent")
    tmp = Path(tempfile.mkdtemp(prefix="g89-selftest-"))
    try:
        entry, landing = _selftest_tree(tmp, reg)
        deliver = tmp / "deliver"

        def run(e, l, want, why, needle=None, **kw):
            d = tmp / "case"
            if d.exists():
                shutil.rmtree(str(d))
            d.mkdir()
            (d / "catalog-entry.json").write_text(json.dumps(e, ensure_ascii=False), encoding="utf-8")
            if l is not None:
                (d / "landing.json").write_text(json.dumps(l, ensure_ascii=False), encoding="utf-8")
            r = check(d / "catalog-entry.json", kw.pop("deliver", deliver), **kw)
            hit = needle is None or any(needle in m for m in r["messages"])
            if r["status"] != want or not hit:
                fails.append("%s: got %s %s" % (why, r["status"], r["messages"][:3]))
            return r

        run(entry, landing, "PASS", "clean entry")

        def mut(fn, want, why, needle=None, on_landing=False, **kw):
            e, l = copy.deepcopy(entry), copy.deepcopy(landing)
            fn(l if on_landing else e)
            return run(e, l, want, why, needle, **kw)

        alias = lambda v: (lambda e: e["sections"][0]["aliases"].append(v))
        title_add = lambda v: (lambda e: e["sections"][2].__setitem__("title", e["sections"][2]["title"] + v))
        mut(lambda e: e.__setitem__("notes", "x"), "FAIL", "unknown top key", "unknown key")
        mut(lambda e: e["sections"][0].__setitem__("answer", "x"), "FAIL", "answer key", "forbidden key")
        mut(lambda e: e["levels"]["a"].__setitem__("hint", "x"), "FAIL", "hint key in level", "unknown key")
        mut(alias("/Users/noam/x.pdf"), "FAIL", "absolute path", "path-like")
        mut(alias(u"/Us\u200ders/noam/x.pdf"), "FAIL", "absolute path with a ZWJ inside", "path-like")
        mut(alias("out/deliver/a/sheet.pdf"), "FAIL", "relative path", "path-like")
        mut(alias("deliver/a/noam-ai.json"), "FAIL", "relative path 2", "path-like")
        mut(alias("ab" * 20), "FAIL", "sha-like hex", "hash-like")
        mut(alias("2026-11-09T01:02"), "FAIL", "timestamp", "timestamp-like")
        mut(alias("20261109T101500Z"), "FAIL", "ISO basic timestamp", "timestamp-like")
        mut(alias(u"נבנה 2026-11-09"), "FAIL", "build date", "timestamp-like")
        mut(alias(u"נבנה 9.11.2026"), "FAIL", "Israeli date", "timestamp-like")
        mut(alias("noam@example.com"), "FAIL", "email", "e-mail-like")
        mut(alias(u"נוסף"), "FAIL", "alias not from the registry", "not the registry's")
        mut(lambda e: e["sections"][1]["search_variants"].append(u"משהו אחר"), "FAIL",
            "variant not generated", "generated spellings")
        # rule 3: answers in SHEET-authored text, in any spelling
        for v, why in ((u" ∡BOC=122°", "value as printed (∡)"), (u" BOC = 122°", "value as the HTML prints it"),
                       (u" $\\angle{BOC}=122°$", "raw LaTeX value"),
                       (u" \u200d$\\angle{BOC}=122°$\u200f", "value with emit_docx marks"),
                       (u" $\\angle{AOC}$ חדה, $\\angle{BOC}$ קהה", "digit-free answer (point names)")):
            mut(title_add(v), "FAIL", "printed answer: " + why, "printed answer")
        mut(lambda l: l["anchors"][0]["explain_he"].__setitem__(1, u"בשאלה 1 מקבלים ∡BOC=122°."), "FAIL",
            "answer value in landing explain_he", "printed answer", on_landing=True)
        mut(title_add(u" 64°"), "FAIL", "short value: not an answer by itself, but the title != SHEET",
            "SHEET")
        r = mut(title_add(u" 64°"), "FAIL", "short value alone is not flagged as an answer")
        if any("printed answer" in m for m in r["messages"]):
            fails.append("a 3-character value was flagged as a printed answer")
        mut(lambda e: e["sections"][1]["question_ids"]["a"].append("q9"), "FAIL", "qid not in noam-ai", "not in noam-ai")
        mut(lambda e: e["sections"][1]["question_ids"]["b"].append("q2"), "FAIL", "overlap", "disjoint")
        mut(lambda e: e["sections"][1]["question_ids"].__setitem__("a", []), "FAIL", "union", "in no section")
        mut(lambda e: e.__setitem__("title", u"אחר"), "FAIL", "title != SHEET", "SHEET.title")
        mut(lambda e: e["sections"][0].__setitem__("subtopic", "st.g7.angles.bisector"), "FAIL", "subtopic != SHEET")
        mut(lambda e: e["levels"].pop("b"), "FAIL", "level missing", "not in the entry")
        mut(lambda e: e["levels"]["a"].__setitem__("pages", 9), "FAIL", "pages != build.json", "build.json")
        mut(lambda e: e["sections"][2].__setitem__("anchor", "angles-adjacent"), "FAIL", "dup anchor", "duplicate")
        mut(lambda e: e["sections"][1].__setitem__("anchor", "angles-other"), "FAIL", "anchor not the slug",
            "subtopic's slug")
        mut(lambda e: e.__setitem__("skill_version", ""), "FAIL", "empty skill_version", "version string")
        mut(lambda e: e.__setitem__("engine_version", "6.17-noam"), "FAIL", "engine != build.json", "build.json")
        mut(lambda e: e.__setitem__("synthetic", True), "FAIL", "synthetic in a gate", "synthetic")
        mut(lambda l: l.__setitem__("animation", [l["animation"], l["animation"]]), "FAIL", "two animations",
            "ONE object", on_landing=True)
        mut(lambda l: l["animation"].__setitem__("id", "other"), "FAIL", "animation id", "animation_id",
            on_landing=True)
        mut(lambda l: l["anchors"].pop(1), "FAIL", "missing landing anchor", "no anchor", on_landing=True)
        mut(lambda l: l["anchors"].append(copy.deepcopy(l["anchors"][0])), "FAIL", "dup landing anchor",
            "duplicate anchors", on_landing=True)
        mut(lambda l: l["downloads"]["a"].__setitem__("pdf", "out/deliver/a/sheet.pdf"), "FAIL",
            "download path", "bare", on_landing=True)
        mut(lambda l: l["downloads"]["a"].__setitem__("pdf", "T7-ANG-99_a.docx"), "FAIL",
            "pdf field holds a .docx", "bare .pdf", on_landing=True)
        mut(lambda l: l["downloads"]["b"].__setitem__("pdf", "G7-ANG-01_c.pdf"), "FAIL",
            "download of another sheet", "this sheet, this level", on_landing=True)
        mut(lambda l: l.__setitem__("grade", 9), "FAIL", "landing grade", "grade", on_landing=True)

        def swap(l):
            x, y = l["anchors"][0], l["anchors"][1]
            for f in ("definition_he", "definition_plain", "explain_he"):
                x[f], y[f] = y[f], x[f]
        mut(swap, "FAIL", "definitions swapped", "registry definition", on_landing=True)
        mut(lambda l: l.__setitem__("intro", l["intro"] + u" ראו out/deliver/a/sheet.pdf"), "FAIL",
            "path in the intro", "path-like", on_landing=True)
        mut(lambda l: l["anchors"][0].__setitem__("example_question_ids", ["q3"]), "FAIL",
            "example from another section", "example_question_ids", on_landing=True)
        mut(lambda l: l["relatedTopics"][0].__setitem__("subtopic", "st.g7.angles.quad_sum"), "FAIL",
            "related topic that is no neighbour", "requires", on_landing=True)
        run(entry, None, "FAIL", "landing missing", "landing.json missing")
        # legit cases that must still PASS
        ent2 = copy.deepcopy(entry)
        for k in ("a", "b"):   # an item answer that is the registry's own sentence (review: false FAIL)
            p = deliver / k / "sheet.json"
            sj = json.loads(p.read_text(encoding="utf-8"))
            sj["questions"][0]["items"][2]["answer"] = reg.get("st.g7.angles.adjacent")["definition_he"]
            p.write_text(json.dumps(sj, ensure_ascii=False), encoding="utf-8")
        run(ent2, landing, "PASS", "answer that states the registry definition")
        for k in ("a", "b"):   # SHEET with names instead of a pure literal (review: false FAIL)
            (deliver / k / "source" / "sheet_meta.py").write_text(_SHEET_SRC_NAMES, encoding="utf-8")
        run(entry, landing, "PASS", "SHEET written with module-level names")
        for k in ("a", "b"):
            (deliver / k / "source" / "sheet_meta.py").write_text(u"SHEET = build()\n", encoding="utf-8")
        r = run(entry, landing, "FAIL", "SHEET that needs code", "cannot be read without running code")
        if any("missing" in m for m in r["messages"]):
            fails.append("unreadable SHEET reported as missing: %s" % r["messages"][:2])
        for k in ("a", "b"):
            (deliver / k / "source" / "sheet_meta.py").write_text(_SHEET_SRC, encoding="utf-8")
        # legacy: no SHEET in the snapshot and no entry -> SKIP
        leg = tmp / "legacy" / "a" / "source"
        leg.mkdir(parents=True)
        (leg / "content.py").write_text("PACKAGE = 'G7-T13'\nLEVELS = []\n", encoding="utf-8")
        (leg.parent / "noam-ai.json").write_text("{}", encoding="utf-8")
        r = check(tmp / "legacy" / "catalog-entry.json", tmp / "legacy")
        if r["status"] != "SKIP" or r["messages"] != ["legacy package (no SHEET)"]:
            fails.append("legacy: %s" % r)
        # synthetic accepted only on request
        e = copy.deepcopy(entry)
        e["synthetic"] = True
        lnd = copy.deepcopy(landing)
        lnd["synthetic"] = True
        run(e, lnd, "PASS", "synthetic with allow_synthetic", deliver=None, allow_synthetic=True,
            sheet=read_sheet_source(_SHEET_SRC)[0])
        # anchors helpers
        if subtopic_anchor("st.g7.angles.vertical", {"angles-vertical"}) != "angles-vertical-2":
            fails.append("subtopic_anchor does not de-duplicate")
        if not _anchor_ok("angles-vertical-2", "angles-vertical") or _anchor_ok("angles-vertical-x", "angles-vertical"):
            fails.append("_anchor_ok")
    finally:
        shutil.rmtree(str(tmp), ignore_errors=True)
    dt = time.time() - t0
    for f in fails:
        print("FAIL " + f)
    print("selfcheck_catalog selftest: %d checks failed, %.2f s" % (len(fails), dt))
    return 1 if fails or dt > 30 else 0


if __name__ == "__main__":
    sys.exit(main())
