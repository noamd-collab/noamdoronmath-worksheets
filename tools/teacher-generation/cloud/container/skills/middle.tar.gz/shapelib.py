# -*- coding: utf-8 -*-
r"""shapelib — v5.5. The shapes a sheet is allowed to be made of, and the
transformations that produce an image WITHOUT the author typing it.

WHY THIS FILE EXISTS
--------------------
Two reasons, and the second is the dangerous one.

**1. G76 asks for variety, and variety has to be cheap.** v5.4 added a blocking
gate that counts objects against the size of the sheet. A gate that demands
something the author has to hand-compute every time is a gate that gets argued
with. Here a rhombus, a dart, a staircase, a cross, an arrow, a regular hexagon
or an isosceles trapezoid is one call that returns its coordinates — already
checked to BE that shape.

**2. The image of a transformation, typed by hand, is the defect class this
skill says only a second reader catches.** SKILL.md, v5.1: six figures in one
package contradicted their own question — a cylinder at half its stated height,
rhombus diagonals the wrong way round, a point placed by a fixed fraction
instead of by the given angles, "and in every case the original sheet was
correct and the rebuild broke it." Writing a reflected triangle's three image
points by hand is exactly that shape of mistake, one keystroke wide, and
invisible to every gate: the drawing is beautiful, the label is unstruck, the
font is right, and the picture is of the wrong triangle.

So the image is COMPUTED from the original and the rule:

    from shapelib import iso_trapezoid, reflect_line_x, translate, scale_from

    T  = iso_trapezoid(y_bot=0, y_top=4, bottom_half=5, top_half=2, cx=1)
    T2 = reflect_line_x(T, 7)        # the image, not a guess
    T3 = translate(T, 3, -2)
    T4 = scale_from(T, (0, 0), 2)

Every generator verifies the shape it claims (a rhombus has four equal sides, a
kite two pairs, an isosceles trapezoid two parallel sides and two equal legs) and
every transformation verifies what it must preserve (an isometry preserves every
squared side length; a homothety multiplies each by k²). A generator that cannot
prove its own claim raises, here, at authoring time — which is the only place the
cost is one rebuild instead of one reprint.

CONVENTIONS
-----------
Every function takes and returns a list of `(x, y)` in GRID units, ready for
`figkit_plus.plane(polys=[...])`. Lattice coordinates wherever the shape allows
one, so a student can read the vertices off the squares; `regular_polygon` and
`star` are the exceptions and say so.

Nothing here draws. Drawing is `plane()`, and it stays the only door.
"""
import math

__all__ = [
    # polygons
    "rect", "square", "parallelogram", "rhombus_from_diagonals", "kite",
    "dart", "iso_trapezoid", "right_trapezoid", "right_triangle",
    "iso_triangle", "l_shape", "staircase", "cross", "house", "arrow",
    "chevron", "regular_polygon", "star",
    # points on a shape
    "midpoints", "divide", "centroid_of", "bbox",
    # transformations
    "translate", "reflect_x", "reflect_y", "reflect_line_x", "reflect_line_y",
    "reflect_yx", "rotate", "scale_from",
    # checks
    "side2", "congruent", "assert_closed",
]


# ------------------------------------------------------------- measuring ---
def side2(pts):
    """The squared length of every side, in order. The house unit."""
    return [(pts[(i + 1) % len(pts)][0] - pts[i][0]) ** 2
            + (pts[(i + 1) % len(pts)][1] - pts[i][1]) ** 2
            for i in range(len(pts))]


def congruent(a, b):
    """Same multiset of squared sides — the cheap test that an isometry did
    what it promised."""
    return sorted(side2(a)) == sorted(side2(b))


def bbox(pts):
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    return (min(xs), min(ys), max(xs), max(ys))


def centroid_of(pts):
    return (sum(p[0] for p in pts) / float(len(pts)),
            sum(p[1] for p in pts) / float(len(pts)))


def assert_closed(pts, n=None, name="shape"):
    if len(pts) < 3:
        raise AssertionError("shapelib: %s has %d point(s)" % (name, len(pts)))
    if n and len(pts) != n:
        raise AssertionError("shapelib: %s should have %d points, has %d"
                             % (name, n, len(pts)))
    if min(side2(pts)) == 0:
        raise AssertionError(
            "shapelib: %s has a zero-length side — two vertices coincide, and "
            "the drawing would pose a question with no answer" % name)
    return pts


# -------------------------------------------------------------- polygons ---
def rect(x0, y0, w, h):
    """Axis-aligned rectangle, anticlockwise from the bottom-left."""
    if w <= 0 or h <= 0:
        raise AssertionError("shapelib: rect needs positive w and h")
    return [(x0, y0), (x0 + w, y0), (x0 + w, y0 + h), (x0, y0 + h)]


def square(x0, y0, a):
    return rect(x0, y0, a, a)


def parallelogram(A, B, D):
    """From three vertices: the fourth is forced, never guessed.
    `A` is the shared corner; the result is A, B, C, D in order."""
    C = (B[0] + D[0] - A[0], B[1] + D[1] - A[1])
    pts = [A, B, C, D]
    s = side2(pts)
    if s[0] != s[2] or s[1] != s[3]:
        raise AssertionError("shapelib: parallelogram(%s, %s, %s) is degenerate"
                             % (A, B, D))
    return assert_closed(pts, 4, "parallelogram")


def rhombus_from_diagonals(centre, dx, dy):
    """A rhombus by its diagonals — horizontal `dx`, vertical `dy`. Use even
    numbers for lattice vertices. The four sides are checked equal."""
    cx, cy = centre
    pts = [(cx, cy - dy / 2.0), (cx + dx / 2.0, cy),
           (cx, cy + dy / 2.0), (cx - dx / 2.0, cy)]
    pts = [(int(x) if float(x).is_integer() else x,
            int(y) if float(y).is_integer() else y) for x, y in pts]
    if len(set(side2(pts))) != 1:
        raise AssertionError("shapelib: rhombus sides came out %s" % side2(pts))
    return assert_closed(pts, 4, "rhombus")


def kite(axis_x, y_bot, y_mid, y_top, half):
    """A kite on a vertical axis: two pairs of equal ADJACENT sides, and the
    two pairs different — otherwise it is a rhombus and should be built as one."""
    pts = [(axis_x, y_bot), (axis_x + half, y_mid),
           (axis_x, y_top), (axis_x - half, y_mid)]
    s = side2(pts)
    if s[0] != s[3] or s[1] != s[2]:
        raise AssertionError("shapelib: kite sides came out %s" % s)
    if s[0] == s[1]:
        raise AssertionError(
            "shapelib: that kite is a rhombus (all four sides %s) — build it "
            "with rhombus_from_diagonals so the sheet says what it means" % s[0])
    return assert_closed(pts, 4, "kite")


def dart(axis_x, y_bot, y_notch, y_top, half):
    """A concave kite: the vertex at `y_notch` points INWARDS. The shape the
    'bounding box minus corners' area route quietly gets wrong, which is why a
    sheet wants one."""
    if not (y_bot < y_notch < y_top):
        raise AssertionError(
            "shapelib: a dart needs y_bot < y_notch < y_top (got %s, %s, %s) — "
            "otherwise the vertex is not reflex and this is a kite"
            % (y_bot, y_notch, y_top))
    return assert_closed([(axis_x, y_bot), (axis_x + half, y_notch),
                          (axis_x, y_top), (axis_x - half, y_notch)],
                         4, "dart")


def iso_trapezoid(y_bot, y_top, bottom_half, top_half, cx=0):
    """Isosceles trapezoid, bases parallel to the x-axis. Legs checked equal,
    bases checked different — a trapezoid with equal bases is a parallelogram."""
    if bottom_half == top_half:
        raise AssertionError(
            "shapelib: equal bases make a parallelogram, not a trapezoid")
    pts = [(cx - bottom_half, y_bot), (cx + bottom_half, y_bot),
           (cx + top_half, y_top), (cx - top_half, y_top)]
    s = side2(pts)
    if s[1] != s[3]:
        raise AssertionError("shapelib: trapezoid legs came out %s, %s"
                             % (s[1], s[3]))
    return assert_closed(pts, 4, "iso_trapezoid")


def right_trapezoid(x0, y0, bottom, top, h):
    """One leg perpendicular to both bases — the trapezoid whose height IS a
    side, so its area needs no construction line."""
    if bottom == top:
        raise AssertionError("shapelib: equal bases make a rectangle")
    return assert_closed([(x0, y0), (x0 + bottom, y0),
                          (x0 + top, y0 + h), (x0, y0 + h)],
                         4, "right_trapezoid")


def right_triangle(A, legx, legy):
    """Right angle at `A`, legs along the axes. Signs choose the quadrant."""
    if legx == 0 or legy == 0:
        raise AssertionError("shapelib: a leg of zero is not a triangle")
    return assert_closed([A, (A[0] + legx, A[1]), (A[0], A[1] + legy)],
                         3, "right_triangle")


def iso_triangle(x_left, x_right, y_base, apex_y):
    """Apex over the midpoint of the base; the two legs are checked equal."""
    if (x_left + x_right) % 2:
        raise AssertionError(
            "shapelib: base endpoints %s and %s put the apex on a half square "
            "— use an even span so the vertices stay on the lattice"
            % (x_left, x_right))
    pts = [(x_left, y_base), (x_right, y_base),
           ((x_left + x_right) // 2, apex_y)]
    s = side2(pts)
    if s[1] != s[2]:
        raise AssertionError("shapelib: legs came out %s, %s" % (s[1], s[2]))
    return assert_closed(pts, 3, "iso_triangle")


def l_shape(x0, y0, w, h, cut_w, cut_h):
    """An L: a `w` x `h` rectangle with a `cut_w` x `cut_h` bite out of the
    top-right. Six right angles, every side parallel to an axis — the shape
    whose area is two rectangles and whose perimeter is six subtractions."""
    if not (0 < cut_w < w and 0 < cut_h < h):
        raise AssertionError("shapelib: the bite must be smaller than the "
                             "rectangle (got %s x %s out of %s x %s)"
                             % (cut_w, cut_h, w, h))
    return assert_closed([(x0, y0), (x0 + w, y0), (x0 + w, y0 + h - cut_h),
                          (x0 + w - cut_w, y0 + h - cut_h),
                          (x0 + w - cut_w, y0 + h), (x0, y0 + h)],
                         6, "l_shape")


def staircase(x0, y0, steps, w, h):
    """A staircase of `steps` steps, each `w` wide and `h` high. Perimeter is
    the same as its bounding rectangle; area is not — which is the question."""
    if steps < 2:
        raise AssertionError("shapelib: a staircase needs at least two steps")
    pts = [(x0, y0)]
    x, y = x0, y0
    for _ in range(steps):
        x += w
        pts.append((x, y))
        y += h
        pts.append((x, y))
    pts.append((x0, y))
    return assert_closed(pts, None, "staircase")


def cross(cx, cy, arm, thick):
    """A plus sign: twelve vertices, four reflex. Good for area by
    decomposition and for a perimeter that surprises."""
    if not 0 < thick < 2 * arm:
        raise AssertionError("shapelib: cross needs 0 < thick < 2*arm")
    t = thick / 2.0
    t = int(t) if float(t).is_integer() else t
    return assert_closed(
        [(cx - t, cy - arm), (cx + t, cy - arm), (cx + t, cy - t),
         (cx + arm, cy - t), (cx + arm, cy + t), (cx + t, cy + t),
         (cx + t, cy + arm), (cx - t, cy + arm), (cx - t, cy + t),
         (cx - arm, cy + t), (cx - arm, cy - t), (cx - t, cy - t)],
        12, "cross")


def house(x0, y0, w, wall_h, roof_h):
    """Rectangle plus an isosceles roof — five vertices, area in two pieces."""
    if w % 2:
        raise AssertionError("shapelib: an odd width puts the ridge on a half "
                             "square; use an even width")
    return assert_closed([(x0, y0), (x0 + w, y0), (x0 + w, y0 + wall_h),
                          (x0 + w // 2, y0 + wall_h + roof_h),
                          (x0, y0 + wall_h)], 5, "house")


def arrow(x0, y0, shaft, shaft_w, head, head_w):
    """A right-pointing arrow, seven vertices, two reflex. Also the shape to
    reach for when a sheet needs a vector without a vector."""
    if head_w <= shaft_w:
        raise AssertionError("shapelib: the head must be wider than the shaft")
    s = shaft_w / 2.0
    hw = head_w / 2.0
    s = int(s) if float(s).is_integer() else s
    hw = int(hw) if float(hw).is_integer() else hw
    return assert_closed(
        [(x0, y0 - s), (x0 + shaft, y0 - s), (x0 + shaft, y0 - hw),
         (x0 + shaft + head, y0), (x0 + shaft, y0 + hw),
         (x0 + shaft, y0 + s), (x0, y0 + s)], 7, "arrow")


def chevron(x0, y0, w, h, rise):
    """A chevron — a bent band. Six vertices, one reflex, and both long edges
    parallel, which is what makes it a band and not a triangle."""
    if w % 2:
        raise AssertionError("shapelib: an odd width puts the peak on a half "
                             "square; use an even width")
    if not 0 < rise:
        raise AssertionError("shapelib: rise must be positive")
    if h <= 0:
        raise AssertionError("shapelib: h must be positive")
    m = w // 2
    return assert_closed([(x0, y0), (x0 + m, y0 + rise), (x0 + w, y0),
                          (x0 + w, y0 - h), (x0 + m, y0 + rise - h),
                          (x0, y0 - h)], 6, "chevron")


def regular_polygon(centre, R, n, rot=90.0, nd=3):
    """A regular n-gon, vertices on a circle of radius R. NOT lattice points —
    use it when the question is about symmetry or perimeter, not about reading
    coordinates off the squares. `rot` is the angle of the first vertex."""
    if n < 3:
        raise AssertionError("shapelib: a polygon needs at least 3 vertices")
    cx, cy = centre
    pts = [(round(cx + R * math.cos(math.radians(rot + 360.0 * k / n)), nd),
            round(cy + R * math.sin(math.radians(rot + 360.0 * k / n)), nd))
           for k in range(n)]
    # The rounding to `nd` decimals is deliberate — a figure file full of
    # 15-digit floats is unreadable — so the tolerance has to allow for it:
    # two vertices each moved by up to 5e-nd move a side by twice that.
    s = side2(pts)
    tol = max(1e-9, 40.0 * (10.0 ** -nd) * R)
    if max(s) - min(s) > tol:
        raise AssertionError("shapelib: regular polygon sides drifted: %s" % s)
    return assert_closed(pts, n, "regular_polygon")


def star(centre, R, r, points=5, rot=90.0, nd=3):
    """A star polygon alternating between radii R and r. Not lattice."""
    if not 0 < r < R:
        raise AssertionError("shapelib: star needs 0 < r < R")
    cx, cy = centre
    out = []
    for k in range(2 * points):
        rad = R if k % 2 == 0 else r
        a = math.radians(rot + 180.0 * k / points)
        out.append((round(cx + rad * math.cos(a), nd),
                    round(cy + rad * math.sin(a), nd)))
    return assert_closed(out, 2 * points, "star")


# ------------------------------------------------------ points on a shape ---
def midpoints(pts):
    """The midpoint of every side, in order — the medial polygon a sheet draws
    dashed inside the original."""
    return [((pts[i][0] + pts[(i + 1) % len(pts)][0]) / 2.0,
             (pts[i][1] + pts[(i + 1) % len(pts)][1]) / 2.0)
            for i in range(len(pts))]


def divide(A, B, m, n):
    """The point dividing AB in the ratio m∶n from A. `divide(A, B, 1, 1)` is
    the midpoint; `divide(A, B, 1, 2)` is the third of the way."""
    if m <= 0 or n <= 0:
        raise AssertionError("shapelib: a ratio needs two positive parts")
    t = float(m) / (m + n)
    x = A[0] + (B[0] - A[0]) * t
    y = A[1] + (B[1] - A[1]) * t
    return (int(x) if float(x).is_integer() else x,
            int(y) if float(y).is_integer() else y)


# ---------------------------------------------------------- the image map ---
def _iso(orig, image, name):
    """An isometry preserves every squared side length. Checked, always: a
    reflected triangle typed by hand is the defect class this file exists for."""
    if not congruent(orig, image):
        raise AssertionError(
            "shapelib: %s did not preserve the shape — sides %s became %s. The "
            "drawing would contradict the question." % (name, side2(orig),
                                                        side2(image)))
    return image


def translate(pts, dx, dy):
    return _iso(pts, [(p[0] + dx, p[1] + dy) for p in pts], "translate")


def reflect_x(pts):
    """Reflection in the x-axis: (x, y) -> (x, -y)."""
    return _iso(pts, [(p[0], -p[1]) for p in pts], "reflect_x")


def reflect_y(pts):
    """Reflection in the y-axis: (x, y) -> (-x, y)."""
    return _iso(pts, [(-p[0], p[1]) for p in pts], "reflect_y")


def reflect_line_x(pts, k):
    """Reflection in the VERTICAL line x = k: (x, y) -> (2k - x, y)."""
    return _iso(pts, [(2 * k - p[0], p[1]) for p in pts], "reflect_line_x")


def reflect_line_y(pts, k):
    """Reflection in the HORIZONTAL line y = k: (x, y) -> (x, 2k - y)."""
    return _iso(pts, [(p[0], 2 * k - p[1]) for p in pts], "reflect_line_y")


def reflect_yx(pts):
    """Reflection in the line y = x: (x, y) -> (y, x)."""
    return _iso(pts, [(p[1], p[0]) for p in pts], "reflect_yx")


def rotate(pts, centre=(0, 0), quarter_turns=2):
    """Rotation by a multiple of 90° about `centre`, anticlockwise. Restricted
    to quarter turns on purpose: any other angle leaves the lattice, and a
    student cannot read the image off the squares."""
    q = quarter_turns % 4
    cx, cy = centre
    out = []
    for x, y in pts:
        u, v = x - cx, y - cy
        for _ in range(q):
            u, v = -v, u
        out.append((cx + u, cy + v))
    return _iso(pts, out, "rotate")


def scale_from(pts, centre, k):
    """Homothety: every squared length is multiplied by k², which is checked —
    the rule the sheet is usually asking the student to discover."""
    cx, cy = centre
    out = []
    for x, y in pts:
        u = cx + (x - cx) * k
        v = cy + (y - cy) * k
        out.append((int(u) if float(u).is_integer() else u,
                    int(v) if float(v).is_integer() else v))
    a, b = side2(pts), side2(out)
    for s0, s1 in zip(a, b):
        if abs(s1 - s0 * k * k) > 1e-6 * max(1.0, abs(s1)):
            raise AssertionError(
                "shapelib: scale_from by %s should multiply every squared side "
                "by %s; %s became %s" % (k, k * k, s0, s1))
    return out
