# -*- coding: utf-8 -*-
u"""gate_numclear -- v6.16 (fix round 2). G84 NUM_CLEAR, measured on the printed PDF.

WHY THIS FILE EXISTS
--------------------
The fix-r1 print verifier found axis numbers of graph figures printed 0.22-0.27
pt from a data stroke -- they look as if they touch it:
  * G9-T06 a / b / c q12: the dashed axis of symmetry x = 1 / 4 / 3 runs through
    the NUMBERED tick, and the number beside it kept 0.23 pt;
  * G9-T06 c q9: the y-axis '2' kept 0.27 pt from the reference parabola y = x².
The graph engine keeps 2.0 px on the number's OWN side of its axis when a place
there exists within 0.245 step of its tick, and otherwise falls back to its
v6.15 placement: 1.0 px from the stroke's CENTRE line (render.py, fix r1: the
wider clearance must never send a number across its axis). With the 1.33 px data
stroke and a glyph whose ink is a hair wider than the model box, 1.0 px prints as
a touch. Nothing in the skill measured it on the page.

THE GATE (graph figures only: the inline SVG dialect wspec-graph-svg; the coord
family's planes, number lines, pies and geometry are not in it)
  Every figure text glyph printed inside a graph figure's box (axis numbers, the
  origin 0, the axis letters, curve and mark labels) keeps at least MIN_PT (0.3 pt)
  of blank from every DATA stroke of that figure: a stroke at least DATA_MIN_W
  (0.9 pt) wide. The engine draws its curves at 1.33 px = 1.0 pt; axes (0.8 pt),
  ticks and guides (0.6 pt) and the grid (0.35 pt) are not data strokes, and a
  dot is a fill. A dashed stroke counts as solid (its dashes move with the
  window).
  Measured as the independent verifier's clear2 did: the glyph box of the PDF
  text layer trimmed to its ink band (0.22 of the box height at the top, 0.20 at
  the bottom, 0.1 pt at each side); the distance to each stroke segment (Bezier
  curves sampled) minus half the stroke width.
  A figure the build cannot locate on the page is a FAIL (a check that cannot
  run must look like a failure).
  build.py runs it on every level (after G79), prints it, records build.json
  checks.g84_num_clear, and a FAIL fails GATES; verify_export reports a recorded
  FAIL as an error (a build before this rule records nothing: no error).
THE CURE is a display square for the figure (the level's display
{fid: {"square": N}}): at a larger square the number finds its 2.0 px place on
its own side within 0.25 step of its tick. Never a dropped number, never a cut
stroke, never a moved window.
"""
from __future__ import print_function

import math
import re

MIN_PT = 0.3
DATA_MIN_W = 0.9
W_EPS = 0.005       # a width written 0.9 may read back 0.8999...
INK_TOP, INK_BOTTOM, INK_SIDE = 0.22, 0.20, 0.1
GATE = "G84-numclear"

_GRAPH_SVG = re.compile(
    r'<svg\b[^>]*data-dialect="wspec-graph-svg/[^"]*"[^>]*>(.*?)</svg>', re.S)
_FIRST_ID = re.compile(r'\bid="([^"]+?)__')


def graph_figure_ids(html):
    """the figure ids of every inline GRAPH figure of a sheet's HTML, in
    order (the engine prefixes each element id with '<fid>__')"""
    out = []
    for m in _GRAPH_SVG.finditer(html or ""):
        i = _FIRST_ID.search(m.group(1))
        if i and i.group(1) not in out:
            out.append(i.group(1))
    return out


def _pt(p):
    return (float(p[0]), float(p[1])) if not hasattr(p, "x") else \
        (float(p.x), float(p.y))


def _segs(dr, bez_steps=48):
    """[(a, b)] line segments of one PyMuPDF drawing"""
    out = []
    for it in dr.get("items") or []:
        op = it[0]
        if op == "l":
            out.append((_pt(it[1]), _pt(it[2])))
        elif op == "c":
            p0, p1, p2, p3 = [_pt(p) for p in it[1:5]]
            prev = p0
            for k in range(1, bez_steps + 1):
                t = k / float(bez_steps)
                u = 1.0 - t
                q = (u ** 3 * p0[0] + 3 * u * u * t * p1[0] +
                     3 * u * t * t * p2[0] + t ** 3 * p3[0],
                     u ** 3 * p0[1] + 3 * u * u * t * p1[1] +
                     3 * u * t * t * p2[1] + t ** 3 * p3[1])
                out.append((prev, q))
                prev = q
        elif op == "re":
            r = it[1]
            c = [(r.x0, r.y0), (r.x1, r.y0), (r.x1, r.y1), (r.x0, r.y1)]
            out += [(c[i], c[(i + 1) % 4]) for i in range(4)]
        elif op == "qu":
            q = it[1]
            c = [_pt(q.ul), _pt(q.ur), _pt(q.lr), _pt(q.ll)]
            out += [(c[i], c[(i + 1) % 4]) for i in range(4)]
    return out


def _clip(a, b, r):
    """the segment ab meets the closed rectangle r (Liang-Barsky)"""
    x0, y0, x1, y1 = r
    dx, dy = b[0] - a[0], b[1] - a[1]
    t0, t1 = 0.0, 1.0
    for p, q in ((-dx, a[0] - x0), (dx, x1 - a[0]),
                 (-dy, a[1] - y0), (dy, y1 - a[1])):
        if p == 0:
            if q < 0:
                return False
            continue
        t = q / p
        if p < 0:
            if t > t1:
                return False
            t0 = max(t0, t)
        else:
            if t < t0:
                return False
            t1 = min(t1, t)
    return t0 <= t1


def _pt_rect(p, r):
    dx = max(r[0] - p[0], 0.0, p[0] - r[2])
    dy = max(r[1] - p[1], 0.0, p[1] - r[3])
    return math.hypot(dx, dy)


def _pt_seg(p, a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    L2 = dx * dx + dy * dy
    t = 0.0 if L2 == 0 else max(0.0, min(1.0, ((p[0] - a[0]) * dx +
                                               (p[1] - a[1]) * dy) / L2))
    return math.hypot(p[0] - (a[0] + t * dx), p[1] - (a[1] + t * dy))


def seg_rect_dist(a, b, r):
    """exact distance between the segment ab and the rectangle r"""
    if _clip(a, b, r):
        return 0.0
    corners = ((r[0], r[1]), (r[2], r[1]), (r[2], r[3]), (r[0], r[3]))
    return min([_pt_rect(a, r), _pt_rect(b, r)] +
               [_pt_seg(c, a, b) for c in corners])


def ink_box(bbox):
    """the ink band of a text-layer glyph box (clear2's trim)"""
    x0, y0, x1, y1 = [float(v) for v in bbox]
    h = y1 - y0
    return (x0 + INK_SIDE, y0 + h * INK_TOP, x1 - INK_SIDE,
            y1 - h * INK_BOTTOM)


def measure_page(page, boxes):
    """{fid: {"worst": row, "rows": [rows < MIN_PT]}} for the graph figures
    of ONE page; boxes = [(fid, [x0, y0, x1, y1])] in PDF pt"""
    drs = [dr for dr in page.get_drawings()
           if dr.get("color") is not None and
           float(dr.get("width") or 0) >= DATA_MIN_W - W_EPS and
           dr.get("type") in ("s", "fs")]
    chars = []
    for blk in page.get_text("rawdict").get("blocks", []):
        for ln in blk.get("lines", []):
            for sp in ln.get("spans", []):
                for c in sp.get("chars", []):
                    if c.get("c", " ").isspace():
                        continue
                    chars.append((c["c"], c["bbox"]))
    out = {}
    for fid, box in boxes:
        bx = [float(v) for v in box]
        grown = (bx[0] - 2, bx[1] - 2, bx[2] + 2, bx[3] + 2)
        segs = []
        for dr in drs:
            r = dr.get("rect")
            rr = (r.x0, r.y0, r.x1, r.y1) if hasattr(r, "x0") else tuple(r)
            if rr[2] < grown[0] or rr[0] > grown[2] or rr[3] < grown[1] or \
                    rr[1] > grown[3]:
                continue
            w = float(dr.get("width") or 0)
            segs += [(a, b, w) for a, b in _segs(dr)]
        res = {"worst": None, "rows": []}
        for ch, bb in chars:
            cx, cy = (bb[0] + bb[2]) / 2.0, (bb[1] + bb[3]) / 2.0
            if not (bx[0] <= cx <= bx[2] and bx[1] <= cy <= bx[3]):
                continue
            ink = ink_box(bb)
            best = None
            for a, b, w in segs:
                if min(a[0], b[0]) - 6 > ink[2] or max(a[0], b[0]) + 6 < \
                        ink[0] or min(a[1], b[1]) - 6 > ink[3] or \
                        max(a[1], b[1]) + 6 < ink[1]:
                    continue
                g = seg_rect_dist(a, b, ink) - w / 2.0
                if best is None or g < best:
                    best = g
            if best is None:
                continue
            row = {"figure": fid, "page": page.number + 1, "glyph": ch,
                   "gap_pt": round(best, 2),
                   "at_pt": [round(ink[0], 1), round(ink[1], 1)]}
            if res["worst"] is None or best < res["worst"]["gap_pt"]:
                res["worst"] = row
            if best < MIN_PT:
                res["rows"].append(row)
        out[fid] = res
    return out


def num_clear_on_pdf(pdf_path, layout, html):
    """G84 on one printed level. layout = wspec_pdf.layout_of(document)
    ({fid: {'page': k, 'box_pt': [...]}}), html = the sheet's HTML (which
    figures are graphs). -> {"gate", "status": PASS | FAIL | NOT_RUN,
    "min_pt", "figures", "rows" (every glyph < MIN_PT), "not_located",
    "worst" (the closest glyph of the level)}"""
    fids = graph_figure_ids(html)
    res = {"gate": GATE, "status": "NOT_RUN", "min_pt": MIN_PT,
           "data_min_w_pt": DATA_MIN_W, "figures": len(fids), "rows": [],
           "not_located": [], "worst": None}
    if not fids:
        res["why"] = "no graph figure on the sheet"
        return res
    import pymupdf
    doc = pymupdf.open(str(pdf_path))
    by_page = {}
    for fid in fids:
        lay = (layout or {}).get(fid)
        if not lay or "box_pt" not in lay:
            res["not_located"].append(fid)
            continue
        by_page.setdefault(int(lay["page"]), []).append((fid, lay["box_pt"]))
    for pno in sorted(by_page):
        for fid, r in sorted(measure_page(doc[pno], by_page[pno]).items()):
            res["rows"] += r["rows"]
            w = r["worst"]
            if w is not None and (res["worst"] is None or
                                  w["gap_pt"] < res["worst"]["gap_pt"]):
                res["worst"] = w
    res["status"] = "FAIL" if (res["rows"] or res["not_located"]) else "PASS"
    return res


def line(key, r):
    if r["status"] == "NOT_RUN":
        return "G84-numclear %-4s not run -- %s" % (key, r.get("why"))
    w = r.get("worst") or {}
    head = "G84-numclear %-4s %-4s %d graph figure(s); closest text %s pt " \
           "(%s %r p%s); min %.1f pt" % (
               key, r["status"], r["figures"], w.get("gap_pt"),
               w.get("figure"), w.get("glyph"), w.get("page"), r["min_pt"])
    bad = "; ".join("%s %r p%s %.2f pt" % (x["figure"], x["glyph"],
                                           x["page"], x["gap_pt"])
                    for x in r["rows"])
    if r["not_located"]:
        bad += ("; " if bad else "") + "not located on the PDF: %s" % \
            ", ".join(r["not_located"])
    return head + (" -- " + bad + " (cure: a display square for the "
                   "figure)" if bad else "")
