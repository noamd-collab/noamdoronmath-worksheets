# -*- coding: utf-8 -*-
r"""mathkit — v5.3. The answer key computed, not typed.

WHY THIS FILE EXISTS
--------------------
SKILL.md names one defect class the emitter cannot catch: "wrong answers in the
key, and questions that cannot be solved from the data given ... those need the
author, not the emitter." Every gate in this skill reads the page; none reads
the arithmetic. In a coordinate-geometry package that arithmetic is mechanical —
a distance, a midpoint, a slope, a shoelace area — and an author typing it by
hand for sixty sub-items will get some of it wrong, silently, on a sellable
sheet.

So the content file computes it. Write the coordinates once, and let the key
come out of the same numbers the figure was drawn from:

    from mathkit import d2, mid, slope, area, per_int, between, fr, pt

    A, B, C = (-2, 1), (4, 9), (5, 2)
    d2(A, B)                # 100  -> "AB = 10"
    area([A, B, C])         # 25
    2 * area([A, B, C]) / (d2(A, B) ** 0.5)   # 5  -> the altitude to AB
    between(52)             # (7, 8)  -> "בין 7 ל-8"
    fr(slope(A, B))         # "\f{4}{3}" -> house markup, straight into a $...$

Exact by construction: everything runs on `Fraction`, so a midpoint of
`(-5, 2)` and `(4, 2)` is `(-1/2, 2)` and not `-0.49999999999999994`.

The point is not the arithmetic — it is that the figure, the question and the
answer all read the SAME tuple. Change a coordinate and the key follows; type
the key by hand and it does not.
"""
from fractions import Fraction as F

__all__ = ["d2", "dist", "mid", "slope", "perp", "area", "per_int",
           "between", "is_square_num", "n", "fr", "pt", "centroid"]


def _F(v):
    """A float reaches here only when an author divided somewhere; `F(0.75)` is
    exact binary and prints as a 16-digit monster, so a float is read as the
    short fraction it was meant to be."""
    return F(v).limit_denominator(10 ** 6) if isinstance(v, float) else F(v)


def d2(A, B):
    """Squared distance. The house unit: ריבוע האורך, no root extracted."""
    return (B[0] - A[0]) ** 2 + (B[1] - A[1]) ** 2


def dist(A, B):
    """Length when it is an integer, else None — so a sheet never prints a
    decimal where it promised an exact value."""
    q = d2(A, B)
    r = int(round(float(q) ** 0.5))
    return r if r * r == q else None


def mid(A, B):
    return (F(A[0] + B[0], 2), F(A[1] + B[1], 2))


def slope(A, B):
    """Fraction, or None for a vertical segment (אין שיפוע)."""
    if A[0] == B[0]:
        return None
    return F(B[1] - A[1], B[0] - A[0])


def perp(m1, m2):
    """True when the two slopes are perpendicular, vertical-vs-horizontal
    included — the case a bare `m1*m2 == -1` gets wrong, because a vertical
    segment has no slope at all."""
    if m1 is None:
        return m2 == 0
    if m2 is None:
        return m1 == 0
    return F(m1) * F(m2) == -1


def area(poly):
    """Shoelace. Works on a concave polygon too, which is why it is here: the
    'bounding box minus corners' route quietly fails on a reflex vertex."""
    s = 0
    for i in range(len(poly)):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % len(poly)]
        s += F(x1) * y2 - F(x2) * y1
    return abs(s) / 2


def per_int(poly):
    """Perimeter when EVERY side is an integer, else None. A None here is the
    signal to ask for ריבועי האורכים in the question instead of the perimeter."""
    tot = 0
    for i in range(len(poly)):
        L = dist(poly[i], poly[(i + 1) % len(poly)])
        if L is None:
            return None
        tot += L
    return tot


def centroid(poly):
    return (sum(F(p[0]) for p in poly) / len(poly),
            sum(F(p[1]) for p in poly) / len(poly))


def is_square_num(q):
    r = int(round(float(q) ** 0.5))
    return r * r == q


def between(q):
    """The two integers a length of squared value `q` sits between — the
    'בין אילו שני שלמים' item, answered from the data instead of by eye.

    Refuses a perfect square on purpose: there the length IS an integer, and
    'between 4 and 5' would be a worse answer than '4'."""
    if is_square_num(q):
        raise AssertionError(
            "mathkit: %s is a perfect square — the length is exactly %d, so "
            "the question should ask for it, not for a bracket"
            % (q, int(round(float(q) ** 0.5))))
    a = int(float(q) ** 0.5)
    while a * a >= q:
        a -= 1
    while (a + 1) ** 2 <= q:
        a += 1
    return a, a + 1


MINUS = "\u2212"


def n(v):
    """A number as it should print: an integer with no decimal point, a
    non-integer as a short decimal, and a negative with U+2212 (v6, E7).

    The ASCII hyphen printed as a short dash wherever the text did not pass
    through the math emitter (a figure label, a table cell, a caption), and
    inside `$...$` the emitter treats U+2212 exactly like '-', so the true
    sign is correct in both places."""
    v = _F(v)
    s = str(v.numerator) if v.denominator == 1 else "%g" % float(v)
    return s.replace("-", MINUS)


def fr(v):
    r"""A value as HOUSE MARKUP: `\f{3}{4}`, ready to drop inside a `$...$`
    island. Not a unicode fraction and not `3/4` — the division gate refuses
    the slash, and correctly."""
    if v is None:
        return ""
    v = _F(v)
    if v.denominator == 1:
        return n(v)
    sign = MINUS if v < 0 else ""          # v6 (E7): U+2212, as n() prints
    return "%s\\f{%d}{%d}" % (sign, abs(v.numerator), v.denominator)


def pt(P):
    """A point as it is written in a question: `(−1, 3)` (U+2212, E7)."""
    return "(%s, %s)" % (n(P[0]), n(P[1]))
