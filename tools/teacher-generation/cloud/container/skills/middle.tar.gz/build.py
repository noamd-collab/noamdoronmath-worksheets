# -*- coding: utf-8 -*-
"""Build one worksheet package: content.py -> PDFs -> gates.

SKILL.md told the author to run `python3 build.py`, and no build.py shipped.
Every package in the corpus rebuild grew its own copy, which is how three of
them quietly diverged — one disabled half a gate, one widened a check to make
its own output pass. Shipping the harness keeps that from being the author's
decision.

    cd <package folder>          # holds content.py, and the source PDFs in ORIG
    DYLD_FALLBACK_LIBRARY_PATH=/opt/homebrew/lib python3 /path/to/build.py

`content.py` must define `LEVELS = [level_dict, ...]`. Optional in it:
    figure_sheet   (per level) True/False -- G75's COVER and OBJECTS checks;
                   an explicit value is printed with the build line
    TITLE          fallback title for a level that omits its own
    ORIG           folder of the ORIGINAL PDFs, for the word comparison
    SOURCE         {"a": "file.pdf", ...} when the filenames carry no level
"""
import importlib.util
import re
import sys
from pathlib import Path

V = Path(__file__).resolve().parent
sys.path.insert(0, str(V))

import deliver as D           # noqa: E402
import emit_html as E          # noqa: E402
import gates_runner as G       # noqa: E402
import wspec_build as WB       # noqa: E402  (v6.9: spec levels)
import wspec_pdf as W79        # noqa: E402  (v6.9: gate G79-spec)
import textbind as TB          # noqa: E402  (v6.11: gate G80-text)
import os                      # noqa: E402
import weasyprint              # noqa: E402
import pymupdf                 # noqa: E402

HERE = Path.cwd()
spec = importlib.util.spec_from_file_location("content", HERE / "content.py")
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

out = HERE / "out"
out.mkdir(exist_ok=True)
# v6.5 (DELIVERABLE_SPEC): every build writes the deliverable package beside
# the PDF -- sheet.json, the figures with their ids and their code, the
# source and the hashes. It is part of a build, not a script a package has
# to remember, because a sheet produced without it has to be rebuilt later
# just for its JSON. `DELIVER = False` in content.py opts out.
DELIVER = getattr(m, "DELIVER", True)
DELIVER_DIR = Path(getattr(m, "DELIVER_DIR", "") or (out / "deliver"))
# v6.9: a spec level's wspec file travels with the source (it is the level)
SOURCES = sorted(str(q) for q in list(HERE.glob("*.py")) +
                 list(HERE.glob("*.wspec.json")))
pdfs = []
HTMLS = {}
G79 = {}
g79_bad = []
TBREC = {}          # v6.11: where each bound block printed (G80-text)
G83ROOM = {}        # v6.16: the drawing-from-words room measured on the PDF
G84 = {}            # v6.16 fix r2: graph figure texts clear the data strokes
for L in m.LEVELS:
    L.setdefault("title", getattr(m, "TITLE", "דף עבודה"))
    # v6.9: spec questions expanded once (the same object when there are
    # none -- the builder path is untouched)
    L = WB.expand_level(L)
    f = out / ("%s.pdf" % L.get("key", "x"))
    # the emitter takes the tuple items it always took; a level that uses the
    # v6.5 content schema (dict items, given/to_prove) is normalised here
    _html = E.build_html(D.normalize(L))
    # v6.11 G80-text: every level is rendered through a document, so the
    # build records where each bound block (data-bind) printed
    doc = weasyprint.HTML(string=_html, base_url=str(V)).render()
    doc.write_pdf(str(f))
    TBREC[id(L)] = TB.record(doc, str(V))
    # v6.16 fix r1 cont. (the author's V616-A7) G83 room ON THE PDF: a
    # drawing-from-words question leaves >= 65 mm of blank (about 70 mm),
    # no grid, no axes -- measured on the printed page (gate_figref)
    try:
        import gate_figref as _GFR
        G83ROOM[id(L)] = _GFR.room_on_pdf(f, TBREC[id(L)]["blocks"], L)
        print(_GFR.room_line(L.get("key"), G83ROOM[id(L)]))
    except ImportError:                    # an old build: no gate_figref
        pass
    if WB.spec_figs(L):
        # v6.9 G79-spec: the engine's figures are checked ON THE PDF --
        # located through WeasyPrint's own layout, then rasterised and read
        _g = W79.check_pdf(f, W79.layout_of(doc), L,
                           ocr=os.environ.get("G79_OCR", "1") != "0",
                           out_dir=None, html=_html)
        G79[id(L)] = _g
        print(W79.line(L.get("key"), _g))
        if _g["status"] == W79.FAIL:
            g79_bad.append(L.get("key"))
        import json as _json
        with open(str(out / ("g79_%s.json" % L.get("key", "x"))), "w",
                  encoding="utf-8") as _fh:
            _json.dump(_g, _fh, ensure_ascii=False, indent=1, default=str)
    # v6.16 fix r2 (verify-print P2-S5) G84 NUM_CLEAR ON THE PDF: every
    # figure text of a GRAPH figure keeps >= 0.3 pt of blank from the
    # figure's data strokes (an axis number printed 0.23 pt from a dashed
    # axis of symmetry read as touching it) -- gate_numclear
    try:
        import gate_numclear as _GNC
        G84[id(L)] = _GNC.num_clear_on_pdf(f, W79.layout_of(doc), _html)
        if G84[id(L)]["status"] != "NOT_RUN":     # a sheet with no graph
            print(_GNC.line(L.get("key"), G84[id(L)]))   # prints nothing
    except ImportError:                    # an old build: no gate_numclear
        pass
    # v6.8 G9: the document the PDF was printed from travels in the package
    # (sheet.html), so the verifier compares each inlined figure with its file
    HTMLS[id(L)] = _html
    pdfs.append((L, f))
    r = E.figure_report(L)
    print("built %-4s %-14s %d pages   figures %d/%d · distinct %d · objects %d%s"
          % (L.get("key"), L["level"], len(pymupdf.open(str(f))),
             r["with_fig"], r["n"], r["distinct"], r["families"],
             ("   G75 OVERRIDE: figure_sheet=%s declared in content.py"
              % L["figure_sheet"] if r["override"] else "") +
             # (v6.14 F4) the questions exempted by name, loudly
             ("   G75/G77 EXEMPT (no figure): %s" % ", ".join(
                 "q%s" % n for n in r.get("exempt") or [])
              if r.get("exempt") else "")))
if g79_bad:
    # FAIL stops the build: a figure that is not true ON THE PAGE is never
    # delivered
    print()
    print("GATES: G79-spec FAIL on level(s) %s -- nothing delivered "
          "(out/g79_<level>.json names every finding)" % ", ".join(g79_bad))
    sys.exit(1)
DDIRS = {}
if DELIVER:
    print()
    for L, f in pdfs:
        _rpt = (D.deliver(L, DELIVER_DIR, pdf=f, source=SOURCES,
                               html=HTMLS.get(id(L)),
                               package=getattr(m, "PACKAGE", None),
                               grade=L.get("grade"),
                               # v6.5 X2 r1 (MUST-6): spec 8 REFUSES a
                               # printed number no datum states; a level
                               # opts back to a report with
                               # STRICT_NUMBERS = False in content.py
                               strict_numbers=getattr(m, "STRICT_NUMBERS",
                                                      True),
                               # New packages must be machine-readable by
                               # Noam AI (the author's v6.6-noam, v6.8):
                               # STRICT by default; an old maintenance
                               # build opts out with STRICT_FIGURES = False,
                               # and a new one writes True explicitly
                               strict_figures=getattr(m, "STRICT_FIGURES",
                                                      True),
                               strict_declared=hasattr(m, "STRICT_FIGURES"),
                               # v6.7.1-noam: the didactic policy (neutral
                               # starting figure, curriculum, hints) follows
                               # STRICT_FIGURES; STRICT_DIDACTIC = False is
                               # the maintenance opt-out of an old sheet
                               neutral=getattr(m, "STRICT_DIDACTIC", None),
                               g79=(W79.summary(G79[id(L)])
                                    if id(L) in G79 else None),
                               # v6.11 G80-text: the build's block record
                               text_binding=TBREC.get(id(L))))
        DDIRS[id(L)] = _rpt["dir"]
        print(D.line(_rpt))
print()

# v6.11 G80-text (Codex NEW-1): the DELIVERED sheet.pdf is bound, block by
# block, to the delivered sheet.json (whose texts W1 binds to the spec):
# the same check verify_export runs. FAIL or REVIEW: not approved, exit 1.
# The verdict is recorded in build.json checks.g80_text.
g80_bad, g80_review = [], []
if DDIRS:
    import json as _json
    print()
    for L, _f in pdfs:
        _d = DDIRS.get(id(L))
        if not _d:
            continue
        # in a separate process, as verify_export runs it: nothing of this
        # build's process (its renderer, a patched writer) is the verifier
        import subprocess as _sp
        _o = None
        try:
            _o = _sp.run([sys.executable, str(V / "textbind.py"), _d,
                          "--json"], capture_output=True, timeout=900,
                         env=dict(os.environ, WORKSHEET_SKILL_DIR=str(V)))
            _r = _json.loads(_o.stdout.decode("utf-8"))
        except (_sp.TimeoutExpired, ValueError):
            _r = {"status": TB.FAIL, "n_blocks": 0, "findings": [
                {"level": TB.FAIL, "code": "G80_NOT_RUN", "bind": None,
                 "detail": "the binding check did not run: %s" % (
                     (_o.stderr.decode("utf-8", "replace").strip()
                      .splitlines() or ["no output"])[-1]
                     if _o is not None else "timeout")}]}
        print(TB.line(L.get("key"), _r))
        _bp = os.path.join(_d, "build.json")
        with open(_bp, encoding="utf-8") as _fh:
            _b = _json.load(_fh)
        _b.setdefault("checks", {})["g80_text"] = TB.summary(_r)
        with open(_bp, "w", encoding="utf-8") as _fh:
            _json.dump(_b, _fh, ensure_ascii=False, indent=1,
                       sort_keys=False)
        with open(str(out / ("g80_%s.json" % L.get("key", "x"))), "w",
                  encoding="utf-8") as _fh:
            _json.dump(_r, _fh, ensure_ascii=False, indent=1, default=str)
        if _r["status"] == TB.FAIL:
            g80_bad.append(L.get("key"))
        elif _r["status"] == TB.REVIEW:
            g80_review.append(L.get("key"))
elif not DELIVER:
    print("G80-text   not run: DELIVER = False (no package to bind)")

# v6.11 fix r1 G81 (author decision W-ANGLE-3-LETTERS, wspec/approvals/
# APPROVALS_NOAM.json): an angle is always named with three letters. A
# one-letter angle name (∠A, "זווית A") in what the package prints or tells
# Noam AI FAILS the build; the finding names the three-letter form. The
# verdict is recorded in build.json checks.g81_angles.
g81_bad = []
if DDIRS:
    import json as _json
    import anglenames as AN
    for L, _f in pdfs:
        _d = DDIRS.get(id(L))
        if not _d:
            continue
        _r = AN.check_level(_d)
        print(AN.line(L.get("key"), _r))
        for _x in _r["findings"][:12]:
            print("    %s %s: %r -> print %s" % (
                _x.get("file"), _x.get("question") or _x.get("where"),
                _x.get("found"), _x.get("three_letters")))
        _bp = os.path.join(_d, "build.json")
        with open(_bp, encoding="utf-8") as _fh:
            _b = _json.load(_fh)
        _b.setdefault("checks", {})["g81_angles"] = {
            "gate": _r["gate"], "status": _r["status"],
            "findings": len(_r["findings"])}
        with open(_bp, "w", encoding="utf-8") as _fh:
            _json.dump(_b, _fh, ensure_ascii=False, indent=1,
                       sort_keys=False)
        if _r["status"] != AN.PASS:
            g81_bad.append(L.get("key"))

# v6.16 fix r1 (the author's W-FIGURE-DENSITY) G82 FIG_REF: a question that
# refers to a figure it cannot print yet, DECLARED by the level for the
# author (fig_ref_pending, gate_figref), is built but the level is NOT
# APPROVED; recorded in build.json checks.g82_fig_ref
g82_pending = []
try:
    import gate_figref as _GF
    _pend = dict(_GF.PENDING)
    _exc = dict(_GF.EXCEPTIONS)
except Exception:                          # noqa: BLE001 -- not installed
    _pend, _exc = {}, {}
if DDIRS:
    import json as _json
    for L, _f in pdfs:
        _d = DDIRS.get(id(L))
        _rows = _pend.get(L.get("key")) or []
        _xrows = _exc.get(L.get("key")) or []
        if _rows:
            g82_pending.append(L.get("key"))
        if not _d or L.get("key") not in _pend:
            continue
        _bp = os.path.join(_d, "build.json")
        with open(_bp, encoding="utf-8") as _fh:
            _b = _json.load(_fh)
        # (v6.16 fix r1 cont.) an AUTHOR EXCEPTION (fig_ref_exception, an
        # APPROVED decision of the author, V616-A4) is recorded with its
        # decision id; the level is approved, the question is reported as
        # an exception -- never as a figure that is printed
        _b.setdefault("checks", {})["g82_fig_ref"] = {
            "gate": "G82", "status": "PENDING_AUTHOR" if _rows else (
                "AUTHOR_EXCEPTION" if _xrows else "PASS"),
            "pending": [{"question": "q%s" % n, "where": w,
                         "words": list(ws), "reason": r}
                        for n, w, ws, r in _rows],
            "exceptions": [{"question": "q%s" % n, "where": w,
                            "words": list(ws), "decision": did,
                            "reason": r}
                           for n, w, ws, did, r in _xrows]}
        with open(_bp, "w", encoding="utf-8") as _fh:
            _json.dump(_b, _fh, ensure_ascii=False, indent=1,
                       sort_keys=False)

# v6.16 fix r1 cont. (V616-A7) G83 room measured on the PDF: recorded in
# build.json checks.g83_room; a FAIL fails GATES (exit 1)
g83_room_bad = []
if DDIRS:
    import json as _json
    for L, _f in pdfs:
        _d = DDIRS.get(id(L))
        _r = G83ROOM.get(id(L))
        if not _d or _r is None:
            continue
        if _r["status"] == "FAIL":
            g83_room_bad.append(L.get("key"))
        _bp = os.path.join(_d, "build.json")
        with open(_bp, encoding="utf-8") as _fh:
            _b = _json.load(_fh)
        _b.setdefault("checks", {})["g83_room"] = _r
        with open(_bp, "w", encoding="utf-8") as _fh:
            _json.dump(_b, _fh, ensure_ascii=False, indent=1,
                       sort_keys=False)

# v6.16 fix r2 G84 NUM_CLEAR: recorded in build.json checks.g84_num_clear;
# a FAIL fails GATES (exit 1) with or without a deliver folder
g84_bad = [L.get("key") for L, _f in pdfs
           if (G84.get(id(L)) or {}).get("status") == "FAIL"]
if DDIRS:
    import json as _json
    for L, _f in pdfs:
        _d = DDIRS.get(id(L))
        _r = G84.get(id(L))
        if not _d or _r is None or _r["status"] == "NOT_RUN":
            continue                # (no graph figure: build.json as before)
        _bp = os.path.join(_d, "build.json")
        with open(_bp, encoding="utf-8") as _fh:
            _b = _json.load(_fh)
        _b.setdefault("checks", {})["g84_num_clear"] = _r
        with open(_bp, "w", encoding="utf-8") as _fh:
            _json.dump(_b, _fh, ensure_ascii=False, indent=1,
                       sort_keys=False)

bad = G.run_output_gates([str(f) for _, f in pdfs], strict=False,
                         colon_division_ok=getattr(m, "COLON_DIVISION_OK", False))

# --- content coverage against the ORIGINAL sheet ------------------------
# A check that cannot run must look like a failure: a quiet "no original
# matched" once meant a level was compared against nothing at all.
ORIG = Path(getattr(m, "ORIG", "")) if getattr(m, "ORIG", "") else None
KEY = {"a": ["רמה א", "רמה_א"], "b": ["רמה ב", "רמה_ב"], "c": ["מצוינות"]}
unverified = []
if ORIG and ORIG.is_dir():
    def words(p):
        t = "".join(pg.get_text("text") for pg in pymupdf.open(str(p)))
        return set(re.findall(r"[א-ת]{3,}", t))

    print()
    srcs = sorted(ORIG.glob("*.pdf"))
    explicit = getattr(m, "SOURCE", None)
    for L, f in pdfs:
        k = L.get("key")
        if explicit and k in explicit:
            cand = [o for o in srcs if o.name == explicit[k]]
        else:
            cand = [o for o in srcs
                    if any(tok in o.name for tok in KEY.get(k, []))]
        if not cand and len(srcs) == 1 and len(pdfs) == 1:
            cand = srcs
        if not cand:
            print("%-4s UNVERIFIED: no source PDF matches %r among %s -- the "
                  "word comparison did not run for this level"
                  % (k, KEY.get(k), [o.name for o in srcs]))
            unverified.append(k)
            continue
        miss = sorted(words(cand[0]) - words(f))
        print("%-4s original=%-4d rebuilt=%-4d missing=%-3d %s"
              % (k, len(words(cand[0])), len(words(f)), len(miss), miss[:9]))

    n_src = len(srcs)
    if n_src and len(pdfs) < n_src:
        built = {L.get("key") for L, _ in pdfs}
        print("INCOMPLETE: the source has %d level(s), LEVELS has %d (%s). "
              "Add the missing level before this package is done."
              % (n_src, len(pdfs), ", ".join(sorted(built))))

# v6.9: a level with a REVIEW figure the author has not accepted
# (accept_review={fid: reason}) is not approved
unapproved = [L.get("key") for L, _f in pdfs
              if id(L) in G79 and not G79[id(L)]["approved"]]
print()
print("GATES:", "all pass" if not (bad or unverified or unapproved or
                                   g80_bad or g80_review or g81_bad or
                                   g82_pending or g83_room_bad or
                                   g84_bad) else
      "%d gate failure(s), %d unverified level(s)%s%s%s%s%s%s" % (
          len(bad), len(unverified),
          ", level(s) %s NOT APPROVED (G79-spec REVIEW)" %
          ", ".join(unapproved) if unapproved else "",
          ", G80-text FAIL on level(s) %s (the printed text is not the "
          "verified text; out/g80_<level>.json)" % ", ".join(g80_bad)
          if g80_bad else "",
          ", level(s) %s NOT APPROVED (G80-text REVIEW)" %
          ", ".join(g80_review) if g80_review else "",
          ", G81 FAIL on level(s) %s (an angle named by one letter; the "
          "author's rule is three letters)" % ", ".join(g81_bad)
          if g81_bad else "",
          ", level(s) %s NOT APPROVED (G82 FIG_REF: a figure the question "
          "refers to waits for the author, fig_ref_pending)" %
          ", ".join(g82_pending) if g82_pending else "",
          ", G83-room FAIL on level(s) %s (a drawing-from-words question "
          "leaves less than 65 mm of blank on the PDF; V616-A7)" %
          ", ".join(g83_room_bad) if g83_room_bad else "") +
      (", G84 NUM_CLEAR FAIL on level(s) %s (a graph figure's text prints "
       "closer than 0.3 pt to a data stroke; cure: a display square)" %
       ", ".join(g84_bad) if g84_bad else ""))
sys.exit(1 if (bad or unverified or unapproved or g80_bad or g80_review or
               g81_bad or g82_pending or g83_room_bad or g84_bad) else 0)
