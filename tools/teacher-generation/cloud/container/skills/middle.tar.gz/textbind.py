# -*- coding: utf-8 -*-
r"""textbind -- v6.11 gate G80-text: the PRINTED sheet.pdf is bound to the
verified digital text, question by question and item by item (Codex v6.10
review, NEW-1).

Before v6.11 nothing compared the question text ON THE PAGE with the data:
a 4 changed to 9 in `AC = 3x + 4` in sheet.pdf only (hash updated) passed
verify_export, selfcheck_noam_package, check_didactic and the acceptance
scenario of the question, while Noam AI and the answer key still described
the old question.

    rep = textbind.verify_level(level_dir)      # a delivered level folder
    rep["status"]              PASS | REVIEW | FAIL
    rep["blocks"][bind]        {status, qid, rid, page, box_pt, findings}
    rep["questions"][qid]      the worst status of the question's blocks
    textbind.line(key, rep)    one printed line

THE CHAIN (every link is checked; a break is FAIL):
  D0 DIGITAL  the text of every row is the same in sheet.json, noam-ai.json
     and (a spec question) wspec/public_spec.json.        G80_DIGITAL
  D  DIGITAL -> DOCUMENT  every question / item row of sheet.json (whose
     texts verify_export W1 binds to wspec/public_spec.json, noam-ai.json
     and the level spec the build used) is ONE bound block of sheet.html
     (data-bind="stem:q2:0", "item:q2a", "fig:q2", "table:q2",
     "example:q2"), and the block's HTML is exactly what the emitter makes
     of that row's text (emit_html.seg; whitespace runs folded). No row
     without a block, no block without a row, the blocks in the order of
     the rows; a question's figure block and an item's figure carry the
     figure sheet.json names.       G80_HTML_TEXT, G80_UNBOUND, G80_EXTRA,
                                     G80_ORDER, G80_FIGURE
     Angle names accept the exact pre-E1 vector printing or E1 body-text
     printing of the same source name, in the same order and multiplicity.
     Only a completely bound row/cell/line proves which tokens are paths;
     T and R still compare the actual PDF against its original HTML.
  L  LOCATION  sheet.html is rendered again (WeasyPrint, the skill's own
     fonts) -- the EXPECTED print -- and each block located through
     WeasyPrint's layout. build.json text_binding (written by the build)
     records where each block printed; the two must agree (0.5 pt).
                                     G80_LOCATION (REVIEW when the render
                                     environment is not the build's)
  T  TEXT      the text layer of sheet.pdf inside each block's box is the
     text layer of the expected print (whitespace ignored); a difference
     is named semantically -- numbers, variables / point names, operators,
     relation symbols ('number 4 -> 9').   G80_TEXT
  R  RASTER    the block's region of sheet.pdf is rendered (DPI) and
     compared with the same region of the expected print, ink against ink
     with a 1-pixel tolerance. Maths the emitter DRAWS (angle signs,
     fractions and roots are paths, not text) is covered here. A whole-
     block shift of up to SHIFT_PT is layout only (PASS, noted); residual
     ink of glyph size is FAIL, a few stray pixels are REVIEW (never
     PASS). Gray levels, not a threshold: a pixel counts when it is DARK
     levels darker than everything within 1 px / 2 px of it in the other
     print (anti-aliasing of another writer is no difference).
                                           G80_RASTER, G80_RASTER_SMALL
  A  ANSWERS   each row of the printed answer key (data-bind
     "answer:q2") is a block too: bound to sheet.html's print by T and R
     (the private answers are not in sheet.json's public rows), charged to
     its question.
  P  PAGE      the same raster and text comparison on the rest of each
     page (question numbers, headings): FAIL there is charged to the
     question nearest the ink (every question when the page has no
     block).                                G80_PAGE_INK, G80_PAGES
  S  SEMANTIC  per row: the numbers, variables, operators and relation
     symbols of the sheet.json text are those the expected print shows as
     text plus those of its drawn maths islands (a reading gap is REVIEW);
     an item's targets (find: of / at+rays) are named by its text.
                                     G80_READ, G80_TARGET

  B  BOUND     (v6.13, author decision W-BOUND-PROSE) a spec question may
     print its ORIGINAL wording as bound prose: every number, number word,
     variable and name of the block is bound to a fact / entity of the spec
     (wspec/schema_bound.py). Per bound block of wspec/public_spec.json:
     the atoms its text prints ARE its binding table (in order); each
     binding resolves in the public spec (a number = its public fact's
     value, never a target / answer; a name = its entity's name; a count,
     a list marker, a question number); the block is the text the row
     prints (a stem / item text holds its blocks in order; a table cell /
     an example line of sheet.json IS its block); and the PRINTED block of
     sheet.pdf (its text layer, plus the maths the emitter draws) shows
     every bound number.                           G80_BOUND
     So a number changed on the page only (G80_TEXT too), in every
     digital copy but not in the binding table, or rebound to a target
     value, FAILs here. (v6.14 F1) A coordinate pair "(a, b)" of a block
     carries its ROLES: its first number is bound to an x-coordinate fact,
     its second to a y-coordinate fact, of one point -- the point named
     before the pair. C(−3, 2) printed as C(2, −3) with the two bindings
     swapped FAILs here (schema_bound.coord_role_problems).

FAIL stops the build (build.py) and fails verify_export (G80); REVIEW
fails both until resolved -- ambiguity is never PASS. The acceptance
runner charges a question's status to every scenario of that question
(scenario_status / patch_runner).

A package built before v6.11 has no data-bind attributes: they are put on
its sheet.html here by the same structure (question by question, in
order), so the binding runs on it too (no build-time record: L is then
only the verification's own layout)."""
import hashlib
import html as _html
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

GATE = "G80-text"
VERSION = "textbind/1"
PASS, REVIEW, FAIL = "PASS", "REVIEW", "FAIL"
_ORDER = {PASS: 0, REVIEW: 1, FAIL: 2}
PT_PER_PX = 0.75
DPI = 200                 # the raster comparison
DARK = 96                 # gray levels: an ink difference is at least this
FAIL_PX = 6               # residual ink pixels (2-px tolerance; 2x at 1 px)
SHIFT_PT = 2.0            # a whole-block shift up to this is layout only
TOL_LOC = 0.5             # pt, recorded location vs the verification layout
PAD_PT = 1.0              # a block's box is compared with this margin
FONT_FILES = ("DavidLibre-Regular.ttf", "DavidLibre-Bold.ttf",
              "DavidLibre-Medium.ttf", "DejaVuSans.ttf")


def _worst(xs):
    w = PASS
    for x in xs:
        if _ORDER.get(x, 0) > _ORDER[w]:
            w = x
    return w


def _ws(s):
    """Whitespace runs folded to one space, ends stripped (a layout-only
    difference never fails)."""
    return re.sub(r"[\s\u00a0\u200f\u200e]+", " ", str(s or "")).strip()


# ======================================================== D: HTML side ===
_OPEN = re.compile(r"<(div|table)\b([^>]*)>")
_CLASS = re.compile(r'\bclass="([^"]*)"')
_BIND = re.compile(r'\sdata-bind="([^"]*)"')
_TAGTOK = re.compile(r"<(/?)(div|table)\b[^>]*>")


def _close(h, start, tag):
    """Index just after the element opened at `start` (nesting-aware)."""
    depth = 0
    for m in _TAGTOK.finditer(h, start):
        if m.group(2) != tag:
            continue
        depth += -1 if m.group(1) else 1
        if depth == 0:
            return m.end()
    return len(h)


def bind_attr(kind, rid, part=None):
    """The attribute the emitter writes on a bound block."""
    return ' data-bind="%s:%s%s"' % (kind, rid,
                                     "" if part is None else ":%d" % part)


def _item_id(n, lab):
    import deliver as D
    return D.item_id(n, lab)


def _fig_of(inner):
    m = re.search(r'\sid="([^"]+?)__', inner)
    return m.group(1) if m else None


def scan(h):
    """The bindable blocks of a sheet.html in document order:
    [{kind, cls, start, end, inner, bind, q}] -- bind is the element's
    data-bind (None on a pre-v6.11 sheet), q the index of the enclosing
    <div class="q">."""
    out = []
    q = -1
    in_ex = None
    for m in _OPEN.finditer(h):
        tag, attrs = m.group(1), m.group(2)
        cm = _CLASS.search(attrs)
        cls = cm.group(1).split() if cm else []
        if tag == "div" and cls == ["q"]:
            q += 1
            continue
        if in_ex is not None and m.start() < in_ex:
            continue                      # inside a worked example
        kind = None
        if tag == "div" and "qintro" in cls:
            kind = "stem"
        elif tag == "div" and cls == ["mline"]:
            kind = "stem"
        elif tag == "div" and "it" in cls and "noitem" not in cls:
            kind = "item"
        elif tag == "div" and "fig" in cls and not (set(cls) - {"fig", "side"}):
            kind = "fig"
        elif tag == "table" and "g" in cls:
            kind = "table"
        elif tag == "div" and cls == ["ex"]:
            kind = "example"
        elif tag == "div" and cls == ["arow"]:
            kind = "answer"             # the printed answer key row
        if kind is None or (q < 0 and kind != "answer"):
            continue
        end = _close(h, m.start(), tag)
        if kind == "example":
            in_ex = end
        bm = _BIND.search(attrs)
        out.append({"kind": kind, "cls": cls, "start": m.start(),
                    "open_end": m.end(), "end": end,
                    "inner": h[m.end():end - len("</%s>" % tag)],
                    "bind": bm.group(1) if bm else None, "q": q})
    return out


def expected_rows(sheet):
    """[(bind, qid, rid, kind, payload)] in the order the sheet prints them:
    per question its worked example, stem lines, figure, table, items.
    payload is the row's text (a line / item text), the figure id, or the
    table / example data.
    v6.12 fix_r1 (G80_ORDER): the emitter prints a worked example FIRST,
    above the stem (emit_html.question_html; the original sheets do so too),
    so the expected order puts it first."""
    rows = []
    for q in (sheet or {}).get("questions") or []:
        qid = q.get("id")
        if q.get("example"):
            rows.append(("example:%s" % qid, qid, qid, "example",
                         q["example"]))
        t = q.get("text")
        lines = t if isinstance(t, list) else ([t] if t else [])
        for k, ln in enumerate(lines):
            rows.append(("stem:%s:%d" % (qid, k), qid, qid, "stem", ln))
        if q.get("figure"):
            rows.append(("fig:%s" % qid, qid, qid, "fig", q.get("figure")))
        if q.get("table"):
            rows.append(("table:%s" % qid, qid, qid, "table", q["table"]))
        for it in q.get("items") or []:
            rows.append(("item:%s" % it.get("id"), qid, it.get("id"),
                         "item", it))
    return rows


def annotate(h, sheet):
    """(html with a data-bind on every bindable block, blocks, findings).

    A block that carries data-bind keeps it (the build wrote it); a
    pre-v6.11 sheet gets them by structure: the k-th <div class="q"> is the
    k-th question of sheet.json, its blocks in print order."""
    blocks = scan(h)
    qs = (sheet or {}).get("questions") or []
    finds = []
    per_q = {}
    for b in blocks:
        if b["kind"] == "answer":
            if b["bind"] is None:
                m = re.search(r'<span class="anum">\((\d+)\)', b["inner"])
                b["bind"] = "answer:q%s" % (m.group(1) if m else "?")
            continue
        per_q.setdefault(b["q"], []).append(b)
    for qi, bl in sorted(per_q.items()):
        if qi >= len(qs):
            for b in bl:
                if b["bind"] is None:
                    b["bind"] = "extra:q#%d" % (qi + 1)
            continue
        q = qs[qi]
        qid, n = q.get("id"), q.get("n")
        k_stem = 0
        for b in bl:
            if b["bind"] is not None:
                continue
            if b["kind"] == "stem":
                b["bind"] = "stem:%s:%d" % (qid, k_stem)
                k_stem += 1
            elif b["kind"] == "item":
                lab = re.search(r'<span class="imark[^"]*">\(?([^<.)]*)',
                                b["inner"])
                b["bind"] = "item:%s" % _item_id(n, lab.group(1)
                                                  if lab else "")
            else:
                b["bind"] = "%s:%s" % (b["kind"], qid)
    # write the attributes (from the end, so offsets hold)
    out = h
    for b in sorted(blocks, key=lambda x: -x["start"]):
        if _BIND.search(out[b["start"]:b["open_end"]]):
            continue
        tag_end = b["open_end"] - 1
        out = out[:tag_end] + ' data-bind="%s"' % b["bind"] + out[tag_end:]
    return out, blocks, finds


_IFIG = re.compile(r'<span class="ifig">.*?</svg>(?:</td></tr></table>)?'
                   r'</span>', re.S)
_IMARK = re.compile(r'^<span class="imark[^"]*">[^<]*</span>')


_TRI_SVGS = None


def _tri_svgs():
    """v6.12 fix_r2 (m1): the two printings of `\\tri` -- the body-size
    symbol of v6.11 (followed by the TeX delimiter space) and the cap-height
    one of v6.12. Both print the same text, a triangle and the name after
    it; the glyph size is typography, so G80 reads them alike and a sheet
    built by v6.11 still binds."""
    global _TRI_SVGS
    if _TRI_SVGS is None:
        import emit_html as E
        from mathsvg import math_svg
        tex = E._BARE_MACROS["tri"]
        _TRI_SVGS = (E._vector(tex),
                     math_svg(tex, getattr(E, "TRI_PT", 13.0), cls="rad tri"))
    return _TRI_SVGS


def _norm_html(s):
    s = str(s or "")
    if "<svg" in s:
        for t in _tri_svgs():
            s = s.replace(t, u"\u25b3")
    return _ws(s).replace(u"\u25b3 ", u"\u25b3")


def _text_html_proof(text, have, want):
    """Bind exact old/current angle printings to this source text only.

    Tokens are structured tuples, not replaceable sentinel strings. Every
    non-angle byte remains subject to the existing whitespace/triangle
    normalization. The proof returns the actual representation of each math
    island; only a completely matching block can supply drawn-token credit.
    """
    import emit_html as E
    source = str(text or "")
    islands = _ISL.findall(source)
    # seg handles paired bold before splitting math islands. Reproduce just
    # that source preparation, preserving the raw island identities consumed
    # by drawn_tokens; valid bold inside math must not become a new D failure.
    marked = E._mark_bold(E._MATH_PUNCT_GAP.sub(r"$\1", source)).split("$")
    if len(marked) % 2 == 0 or len(marked[1::2]) != len(islands):
        raise ValueError("math island delimiters differ from the source")
    prepared = [p.replace(E._B_OPEN, "").replace(E._B_CLOSE, "")
                for p in marked[1::2]]

    def island_body(index):
        body = E.m_body(prepared[index])
        if E._B_OPEN in marked[1::2][index] or E._B_CLOSE in marked[1::2][index]:
            body = "<b>%s</b>" % body
        return body

    forms, current = {}, {}
    for isl in prepared:
        pos = 0
        while True:
            match = re.search(r"\\angle\{", isl[pos:])
            if match is None:
                break
            start = pos + match.start()
            inner, pos = E._brace(isl, start + len(r"\angle"))
            key = E._to_tex(inner)
            now = _norm_html(E.m_body(r"\angle{" + inner + "}"))
            old = _norm_html(E._vector(E._ARG_MACROS["angle"] % key))
            for form in (now, old):
                if form in forms and forms[form] != key:
                    raise ValueError("ambiguous angle representation")
                forms[form] = key
            current[now] = key
    if not forms:
        if _norm_html(have) != _norm_html(want):
            return None
        return [(isl, island_body(i)) for i, isl in enumerate(islands)]
    pattern = re.compile("|".join(re.escape(x) for x in sorted(forms, key=len, reverse=True)))

    def parts(value):
        value = _norm_html(value)
        rows, actual, end = [], [], 0
        for match in pattern.finditer(value):
            rows.extend((("html", value[end:match.start()]),
                         ("angle", forms[match.group()])))
            actual.append((forms[match.group()], match.group()))
            end = match.end()
        rows.append(("html", value[end:]))
        return rows, actual

    have_parts, actual = parts(have)
    want_parts, expected = parts(want)
    if have_parts != want_parts:
        return None
    # A successful match proves the complete sequence, including repeated
    # names. Reconstruct island bodies in precisely that sequence, retaining
    # whether each angle's letters were text or paths in the verified HTML.
    pattern_now = re.compile("|".join(re.escape(x) for x in sorted(current, key=len, reverse=True)))
    remaining = iter(actual)
    consumed = []

    def replace(match):
        try:
            key, body = next(remaining)
        except StopIteration:
            raise ValueError("angle proof ended inside a math island")
        if key != current[match.group()]:
            raise ValueError("angle proof order differs from source")
        consumed.append(key)
        return body

    bodies = [(isl, pattern_now.sub(replace, _norm_html(island_body(i))))
              for i, isl in enumerate(islands)]
    if consumed != [key for key, _body in expected] or next(remaining, None) is not None:
        raise ValueError("angle proof does not cover the source islands")
    return bodies


def html_faults(blocks, sheet, proven_drawn=None):
    """D: [(level, code, bind, detail)] -- sheet.html blocks against the
    sheet.json rows."""
    import emit_html as E
    if proven_drawn is not None:
        proven_drawn.clear()
    rows = expected_rows(sheet)
    exp = dict((r[0], r) for r in rows)
    got = {}
    out = []
    for b in blocks:
        if b["kind"] == "answer":
            continue        # the answer key: bound to sheet.html's print
        if b["bind"] in got:
            out.append((FAIL, "G80_EXTRA", b["bind"],
                        "sheet.html binds %s twice" % b["bind"]))
            continue
        got[b["bind"]] = b
    for r in rows:
        if r[0] not in got:
            out.append((FAIL, "G80_UNBOUND", r[0],
                        "sheet.json row %s (%s) has no block in sheet.html: "
                        "the page does not print it" % (
                            r[0], _ws(r[4] if isinstance(r[4], str) else
                                      (r[4] or {}).get("text")
                                      if isinstance(r[4], dict) else
                                      r[4])[:60])))
    for bnd in got:
        if bnd not in exp:
            out.append((FAIL, "G80_EXTRA", bnd,
                        "sheet.html prints block %s, which is no row of "
                        "sheet.json" % bnd))
    # order: the bound blocks follow the rows
    # (a side figure prints beside the stem, after the first item in the
    # document: figures are bound by their id, not by position)
    order = [b["bind"] for b in blocks if b["bind"] in exp and
             b["kind"] not in ("fig", "answer")]
    want = [r[0] for r in rows if r[0] in got and r[3] != "fig"]
    if order != want:
        k = next((i for i, (a, c) in enumerate(zip(order, want)) if a != c),
                 None)
        out.append((FAIL, "G80_ORDER", order[k] if k is not None else "",
                    "sheet.html prints the blocks in another order than "
                    "sheet.json (at %s: printed %s, expected %s)" % (
                        k, order[k] if k is not None else None,
                        want[k] if k is not None else None)))
    for bnd, b in got.items():
        r = exp.get(bnd)
        if r is None:
            continue
        kind, payload = r[3], r[4]
        try:
            if kind == "stem":
                want_h = E.seg(payload)
                have_h = b["inner"]
            elif kind == "item":
                lab = payload.get("label") or ""
                want_h = E.item_label(lab) + E.seg(payload.get("text") or "")
                have_h = _IFIG.sub("", b["inner"], count=1)
                ifig = _IFIG.search(b["inner"])
                if ifig:
                    f = _fig_of(ifig.group(0))
                    if f != payload.get("figure"):
                        out.append((FAIL, "G80_FIGURE", bnd,
                                    "item %s prints figure %s; sheet.json "
                                    "names %s" % (payload.get("id"), f,
                                                  payload.get("figure"))))
                if not lab:
                    have_h = _IMARK.sub("", have_h)
                    want_h = E.seg(payload.get("text") or "")
            elif kind == "fig":
                f = _fig_of(b["inner"])
                if f != payload:
                    out.append((FAIL, "G80_FIGURE", bnd,
                                "question %s prints figure %s beside its "
                                "text; sheet.json names %s" % (
                                    r[1], f, payload)))
                continue
            elif kind == "table":
                cells = re.findall(r"<t([hd])>(.*?)</t\1>", b["inner"],
                                   re.S)
                have = [c[1] for c in cells]
                texts = list(payload.get("head") or []) + [
                    x for row in payload.get("rows") or [] for x in row]
                proofs = [_text_html_proof(t, h, E.seg(t))
                          for t, h in zip(texts, have)]
                if len(have) != len(texts) or any(p is None for p in proofs):
                    out.append((FAIL, "G80_HTML_TEXT", bnd,
                                "the table of %s in sheet.html is not "
                                "sheet.json's table" % r[1]))
                elif proven_drawn is not None:
                    proven_drawn[bnd] = [v for t, p in zip(texts, proofs)
                                         for v in drawn_tokens(t, p)]
                continue
            elif kind == "example":
                have = re.findall(r'<div class="(?:exh|exl[^"]*)">(.*?)'
                                  r'</div>', b["inner"], re.S)
                texts = [payload.get("title") or ""] + list(payload.get("lines") or [])
                proofs = [_text_html_proof(t, h, E.seg(t))
                          for t, h in zip(texts, have)]
                if len(have) != len(texts) or any(p is None for p in proofs):
                    out.append((FAIL, "G80_HTML_TEXT", bnd,
                                "the worked example of %s in sheet.html is "
                                "not sheet.json's" % r[1]))
                elif proven_drawn is not None:
                    proven_drawn[bnd] = [v for t, p in zip(texts, proofs)
                                         for v in drawn_tokens(t, p)]
                continue
            else:
                continue
            text = payload if isinstance(payload, str) else payload.get("text") or ""
            proof = _text_html_proof(text, have_h, want_h)
        except (ValueError, AssertionError) as e:
            out.append((FAIL, "G80_HTML_TEXT", bnd,
                        "sheet.json text of %s does not emit: %s" % (
                            bnd, str(e)[:120])))
            continue
        if proof is None:
            out.append((FAIL, "G80_HTML_TEXT", bnd,
                        "sheet.html block %s is not the sheet.json text "
                        "%r" % (bnd, _ws(payload if isinstance(payload, str)
                                         else payload.get("text"))[:70])))
        elif proven_drawn is not None:
            proven_drawn[bnd] = drawn_tokens(text, proof)
    return out


def _row_texts(doc):
    """{row id: text} of the questions and items of a sheet.json /
    noam-ai.json / public_spec.json."""
    out = {}
    for q in (doc or {}).get("questions") or []:
        if not isinstance(q, dict):
            continue
        t = q.get("text")
        if isinstance(t, str) and "\n" in t:
            # (v6.13 fix_r2) a spec stem's line break ("\n" connector) is
            # the sheet's list of stem lines
            t = t.split("\n")
        out[q.get("id")] = " / ".join(t) if isinstance(t, list) else t
        for it in q.get("items") or []:
            if isinstance(it, dict):
                out[it.get("id")] = it.get("text")
    return out


def _bind_of_row(rid, sheet):
    for q in (sheet or {}).get("questions") or []:
        if q.get("id") == rid:
            return "stem:%s:0" % rid
    return "item:%s" % rid


def digital_faults(sheet, pub=None, nj=None):
    """D0: the three digital copies of every printed row agree -- sheet.json
    (what G80 binds to the page), noam-ai.json (what Noam AI reads) and,
    for a spec question, wspec/public_spec.json (the verified spec's public
    model; verify_export W1 re-derives it from the level spec the build
    used). Whitespace-only differences are not differences."""
    out = []
    S = _row_texts(sheet)
    P_ = _row_texts(pub) if pub is not None else {}
    spec_q = set(q.get("id") for q in (pub or {}).get("questions") or []
                 if isinstance(q, dict))
    N = _row_texts(nj) if nj is not None else None
    for rid, t in S.items():
        q = re.match(r"(q\d+)", str(rid))
        if pub is not None and q and q.group(1) in spec_q:
            if rid not in P_:
                out.append((FAIL, "G80_DIGITAL", _bind_of_row(rid, sheet),
                            "sheet.json row %s is not in wspec/public_spec."
                            "json" % rid))
            elif _ws(P_[rid]) != _ws(t):
                out.append((FAIL, "G80_DIGITAL", _bind_of_row(rid, sheet),
                            "sheet.json row %s says %r; the verified spec "
                            "(wspec/public_spec.json) says %r" % (
                                rid, _ws(t)[:60], _ws(P_[rid])[:60])))
        if N is not None:
            if rid not in N:
                out.append((FAIL, "G80_DIGITAL", _bind_of_row(rid, sheet),
                            "sheet.json row %s is not in noam-ai.json" % rid))
            elif _ws(N[rid]) != _ws(t):
                out.append((FAIL, "G80_DIGITAL", _bind_of_row(rid, sheet),
                            "sheet.json row %s says %r; noam-ai.json says %r"
                            % (rid, _ws(t)[:60], _ws(N[rid])[:60])))
    # (the level spec may hold questions this level does not print: the
    # public spec is read from the sheet's side, as W1 reads it; noam-ai.json
    # is the sheet's public view and has no row of its own)
    for rid in (N or {}):
        if rid not in S:
            out.append((FAIL, "G80_DIGITAL", _bind_of_row(rid, sheet),
                        "noam-ai.json has row %s, which sheet.json (the "
                        "page) does not" % rid))
    return out


# ================================================= L: render + layout ===
def skill_dir():
    d = os.environ.get("WORKSHEET_SKILL_DIR") or HERE
    return d if os.path.isfile(os.path.join(d, "emit_html.py")) else HERE


def env_fingerprint(sd=None):
    """What the raster depends on: the renderer and the fonts."""
    import weasyprint
    sd = sd or skill_dir()
    fonts = {}
    for f in FONT_FILES:
        p = os.path.join(sd, "assets", f)
        if os.path.isfile(p):
            with open(p, "rb") as fh:
                fonts[f] = hashlib.sha256(fh.read()).hexdigest()[:16]
    try:
        import pymupdf
        mu = pymupdf.VersionBind
    except Exception:                                  # noqa: BLE001
        mu = None
    return {"weasyprint": weasyprint.__version__, "pymupdf": mu,
            "fonts": fonts}


_ASSET_URL = re.compile(r'url\("file://[^"]*?/assets/')


def render(h, sd=None):
    """(WeasyPrint document, pdf bytes) of a sheet.html, its fonts taken
    from the skill folder `sd` (the build's absolute asset paths may not
    exist here)."""
    import weasyprint
    sd = sd or skill_dir()
    a = "file://" + os.path.join(os.path.abspath(sd), "assets") + "/"
    h2 = _ASSET_URL.sub('url("' + a, h)
    doc = weasyprint.HTML(string=h2, base_url=str(sd)).render()
    return doc, doc.write_pdf()


def layout_blocks(document):
    """{bind: [[page, x0, y0, x1, y1] (pt), ...]} -- every element with a
    data-bind, one box per page it prints on (fragments on one page
    united)."""
    out = {}
    for pno, page in enumerate(document.pages):
        stack = [page._page_box]
        seen = {}
        while stack:
            b = stack.pop()
            stack.extend(reversed(list(getattr(b, "children", []) or [])))
            el = getattr(b, "element", None)
            if el is None or not hasattr(el, "get"):
                continue
            bnd = el.get("data-bind")
            if not bnd or getattr(b, "element_tag", None) not in (
                    "div", "table"):
                continue
            try:
                x, y = b.border_box_x(), b.border_box_y()
                w, h = b.border_width(), b.border_height()
            except Exception:                         # noqa: BLE001
                continue
            box = [x * PT_PER_PX, y * PT_PER_PX, (x + w) * PT_PER_PX,
                   (y + h) * PT_PER_PX]
            if bnd in seen:
                s = seen[bnd]
                s[1], s[2] = min(s[1], box[0]), min(s[2], box[1])
                s[3], s[4] = max(s[3], box[2]), max(s[4], box[3])
            else:
                seen[bnd] = [pno] + box
        for bnd, r in seen.items():
            out.setdefault(bnd, []).append([r[0]] + [round(v, 2)
                                                     for v in r[1:]])
    return out


def record(document, sd=None):
    """What the build writes to build.json text_binding."""
    return {"version": VERSION, "blocks": layout_blocks(document),
            "env": env_fingerprint(sd)}


# ============================================== T + R: the PDF side =====
# v6.13 fix_r1 (T08B-D8, from work_t08_b/skillfix): a comma never joins
# digits -- '(2,5)' is the pair 2, 5 (the sheets write decimals with '.'),
# as schema_bound.atoms reads it
_TOK = re.compile(u"\\d+(?:[.]\\d+)?|[A-Za-z]|[=<>\u2264\u2265\u2260\u2225"
                  u"\u22a5\u2245\u223c\u2220\u25b3\u00b0+\\-\u2212\u00d7"
                  u"\u00b7:/\u221a%]")


def tokens(s):
    return [("-" if t == u"\u2212" else t)
            for t in _TOK.findall(str(s or ""))]


def _tclass(t):
    if t[0].isdigit():
        return "number"
    if t.isalpha():
        return "variable/name"
    if t in u"=<>\u2264\u2265\u2260\u2225\u22a5\u2245\u223c":
        return "relation"
    return "operator/symbol"


def token_diff(want, have):
    """'number 4 -> 9; ...' -- the semantic difference of two token lists."""
    import difflib
    sm = difflib.SequenceMatcher(a=want, b=have, autojunk=False)
    out = []
    for op, i1, i2, j1, j2 in sm.get_opcodes():
        if op == "equal":
            continue
        a, b = " ".join(want[i1:i2]), " ".join(have[j1:j2])
        cls = sorted(set(_tclass(t) for t in want[i1:i2] + have[j1:j2]))
        out.append("%s %r -> %r" % ("/".join(cls), a, b))
    return "; ".join(out)


def _glyphs(page, rect):
    """[(line y, x0, x1, ch)] of the text layer whose centre lies in rect."""
    import pymupdf
    R = pymupdf.Rect(*rect)
    cs = []
    for b in page.get_text("rawdict", clip=R)["blocks"]:
        for ln in b.get("lines", []):
            for s in ln["spans"]:
                for c in s["chars"]:
                    ch = c["c"]
                    if ch.isspace():
                        continue
                    x0, y0, x1, y1 = c["bbox"]
                    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
                    if R.x0 <= cx <= R.x1 and R.y0 <= cy <= R.y1:
                        cs.append((c["origin"][1], x0, x1, ch))
    cs.sort()
    lines, cur, y = [], [], None
    for oy, x0, x1, ch in cs:
        if y is None or abs(oy - y) > 2.0:
            if cur:
                lines.append(cur)
            cur, y = [], oy
        cur.append((x0, x1, ch))
    if cur:
        lines.append(cur)
    return [sorted(l) for l in lines]


def _chars(page, rect, spaced=False):
    """The glyphs of the text layer in rect as one string, line by line top
    to bottom, left to right (independent of the order the text layer lists
    them in); no spaces -- or, spaced=True, a space where two glyphs of a
    line stand apart (two numbers never merge into one)."""
    out = []
    for l in _glyphs(page, rect):
        t, px = "", None
        for x0, x1, ch in l:
            if spaced and px is not None and x0 - px > 1.2:
                t += " "
            t += ch
            px = x1
        out.append(t)
    return "\n".join(out)


def _gray(page, dpi, clip=None):
    import numpy as np
    import pymupdf
    pm = page.get_pixmap(dpi=dpi, colorspace=pymupdf.csGRAY,
                         clip=pymupdf.Rect(*clip) if clip else None,
                         alpha=False)
    return np.frombuffer(pm.samples, np.uint8).reshape(pm.h, pm.w)


def _minf(m):
    """3x3 minimum filter (the darkest neighbour; edges padded white)."""
    import numpy as np
    p = np.pad(m, 1, constant_values=255)
    H, W = m.shape
    out = p[1:1 + H, 1:1 + W].copy()
    for dy in (0, 1, 2):
        for dx in (0, 1, 2):
            np.minimum(out, p[dy:dy + H, dx:dx + W], out=out)
    return out


def _residual(a, b):
    """(n1, n2): pixels much darker (by DARK) in one print than anything
    within 1 px (n1) / 2 px (n2) of it in the other. Gray, not a
    threshold: a shade that differs a little (another writer's
    anti-aliasing, a sub-pixel shift) is no ink difference."""
    import numpy as np
    a1, b1 = _minf(a), _minf(b)
    r1 = (a.astype(np.int16) + DARK < b1) | (b.astype(np.int16) + DARK < a1)
    a2, b2 = _minf(a1), _minf(b1)
    r2 = (a.astype(np.int16) + DARK < b2) | (b.astype(np.int16) + DARK < a2)
    return r1, r2


def _shifted(m, dx, dy):
    import numpy as np
    out = np.full_like(m, 255)
    H, W = m.shape
    ys = slice(max(0, dy), H + min(0, dy))
    yd = slice(max(0, -dy), H + min(0, -dy))
    xs = slice(max(0, dx), W + min(0, dx))
    xd = slice(max(0, -dx), W + min(0, -dx))
    out[ys, xs] = m[yd, xd]
    return out


def raster_diff(a, b, dpi=DPI, mask=None):
    """{n1, n2, shift_pt, n0, where}: the best whole-region integer shift
    (up to SHIFT_PT) of print a against print b (gray arrays of the same
    region); n2 counts ink differences no 2-px tolerance explains, n1 those
    no 1-px tolerance explains, n0 n1 at no shift; where = the rows of the
    n2 (or n1) residual."""
    import numpy as np
    if a.shape != b.shape:
        h = min(a.shape[0], b.shape[0])
        w = min(a.shape[1], b.shape[1])
        a, b = a[:h, :w], b[:h, :w]
    if mask is not None:
        a = np.where(mask, a, 255).astype(a.dtype)
        b = np.where(mask, b, 255).astype(b.dtype)
    r1, r2 = _residual(a, b)
    # the shift that explains most at 1 px (a shift must not hide a
    # changed glyph behind the 2-px tolerance)
    best = (int(r1.sum()), int(r2.sum()), 0, 0, r1, r2)
    n0 = best[0]
    if n0:
        s = int(round(SHIFT_PT * dpi / 72.0))
        for dy in range(-s, s + 1):
            for dx in range(-s, s + 1):
                if dx == 0 and dy == 0:
                    continue
                q1, q2 = _residual(_shifted(a, dx, dy), b)
                k = (int(q1.sum()), int(q2.sum()))
                if k < best[:2]:
                    best = k + (dx, dy, q1, q2)
                    if k == (0, 0):
                        break
            if best[:2] == (0, 0):
                break
    ys = np.nonzero(best[4])[0]
    return {"n1": best[0], "n2": best[1], "n0": n0,
            "shift_pt": (round(best[2] * 72.0 / dpi, 2),
                         round(best[3] * 72.0 / dpi, 2)),
            "rows": ys}


def raster_compare(pa, pb, clip, dpi=DPI):
    """raster_diff of one region of two pages."""
    return raster_diff(_gray(pa, dpi, clip), _gray(pb, dpi, clip), dpi)


def raster_verdict(r):
    """At the best whole-region shift (layout only): FAIL when the ink that
    differs is of glyph size -- 2 * FAIL_PX pixels no 1-px tolerance
    explains, or FAIL_PX no 2-px tolerance explains; REVIEW for any smaller
    residual (a speck, another writer's anti-aliasing: never PASS); PASS
    when nothing differs (the prints of one document by one renderer are
    identical to the pixel, measured)."""
    if r["n1"] >= 2 * FAIL_PX or r["n2"] >= FAIL_PX:
        return FAIL
    if r["n1"] > 0:
        return REVIEW
    return PASS


# ======================================================= S: semantic =====
_ISL = re.compile(r"\$([^$]*)\$")


def _untex(s):
    s = re.sub(r"\\angle\s*\{([^}]*)\}", u"\u2220\\1", s)
    s = re.sub(r"\\(?:f|frac|d)\s*\{([^}]*)\}\s*\{([^}]*)\}", r"\1/\2", s)
    s = re.sub(r"\\sqrt\s*\{([^}]*)\}", u"\u221a\\1", s)
    s = re.sub(r"\\triangle\s*\{?([A-Z]*)\}?", u"\u25b3\\1", s)
    s = re.sub(r"\\[a-zA-Z]+", " ", s)
    return s.replace("{", "").replace("}", "")


def row_text(kind, payload):
    if kind == "stem":
        return payload
    if kind == "item":
        return (payload or {}).get("text") or ""
    return ""


def drawn_tokens(text, proven_bodies=None):
    """The tokens of the maths islands of `text` that the emitter's HTML
    does not print as text (drawn: an angle sign or a whole island as an
    <svg> of paths, a fraction bar, a root) -- the text layer cannot show
    them; R binds them on the raster."""
    import emit_html as E
    out = []
    islands = _ISL.findall(str(text or ""))
    if proven_bodies is not None and [x[0] for x in proven_bodies] != islands:
        raise ValueError("drawn-token proof belongs to another source text")
    for index, isl in enumerate(islands):
        try:
            body = E.m_body(isl) if proven_bodies is None else proven_bodies[index][1]
        except Exception:                             # noqa: BLE001
            continue
        vis = re.sub(r"<svg\b.*?</svg>", " ", body, flags=re.S)
        vis = _html.unescape(re.sub(r"<[^>]+>", " ", vis))
        want = tokens(_untex(isl))
        for t in tokens(vis):
            if t in want:
                want.remove(t)
        out.extend(want)
    return out


def _subseq(a, s):
    it = iter(s)
    return all(c in it for c in a)


def targets(item):
    """The names an item's find targets are printed as."""
    out = []
    for f in (item or {}).get("find") or []:
        if f.get("of"):
            out.append([str(f["of"])])
        elif f.get("at") and f.get("rays"):
            r = f["rays"]
            out.append([r[0] + f["at"] + r[1], r[1] + f["at"] + r[0],
                        f["at"]])
    return out


# ============================================== B: bound prose (v6.13) ==
def _bound_bind(scope_kind, sid, at):
    """The data-bind block a public bound block prints in."""
    if at.startswith("table:"):
        return "table:%s" % sid
    if at.startswith("example:"):
        return "example:%s" % sid
    return ("stem:%s:0" % sid) if scope_kind == "question" else \
        ("item:%s" % sid)


def _bound_scopes(pub):
    for q in (pub or {}).get("questions") or []:
        if not isinstance(q, dict):
            continue
        yield "question", q, q
        for it in q.get("items") or []:
            if isinstance(it, dict):
                yield "item", it, q


def _cell_of(q, at):
    """The text of a table cell / example line `at` of a question dict."""
    parts = at.split(":")
    try:
        if parts[0] == "table":
            t = q.get("table") or {}
            if parts[1] == "head":
                return (t.get("head") or [])[int(parts[2])]
            return (t.get("rows") or [])[int(parts[1])][int(parts[2])]
        if parts[0] == "example":
            e = q.get("example") or {}
            if parts[1] == "title":
                return e.get("title")
            return (e.get("lines") or [])[int(parts[1])]
    except (IndexError, ValueError, TypeError, AttributeError):
        return None
    return None


def bound_faults(sheet, pub):
    """B, digital side: [(level, code, bind, detail)] -- every bound block
    of the public spec against its own binding table, the public facts /
    entities and the row / cell it prints in."""
    from wspec import schema_bound as SB
    out = []
    if not isinstance(pub, dict):
        return out
    facts = dict((f.get("id"), f) for f in pub.get("facts") or []
                 if isinstance(f, dict))
    ents = dict((e.get("id"), e) for e in pub.get("entities") or []
                if isinstance(e, dict))
    qn = dict((q.get("id"), q.get("n")) for q in pub.get("questions") or []
              if isinstance(q, dict))
    sq = dict((q.get("id"), q) for q in (sheet or {}).get("questions") or []
              if isinstance(q, dict))
    # (v6.13 fix_r1, C4) the interval count each public figure prints
    ivl = {}
    for g in pub.get("figures") or []:
        if isinstance(g, dict):
            ivl[g.get("id")] = set(
                a.get("intervals") for a in (g.get("frame") or {}).get(
                    "axes") or [] if isinstance(a, dict))
    for kind, sc, q in _bound_scopes(pub):
        pos = 0
        row = sc.get("text") or ""
        for b in sc.get("bound") or []:
            at = str(b.get("at") or "")
            bnd = _bound_bind(kind, sc.get("id"), at)
            txt = b.get("text")
            if not isinstance(txt, str):
                out.append((FAIL, "G80_BOUND", bnd, "%s %s: no text"
                            % (sc.get("id"), at)))
                continue
            want = [t for _k, t in SB.atoms(txt)]
            have = [x.get("tok") for x in b.get("bind") or []]
            if want != have:
                out.append((FAIL, "G80_BOUND", bnd, "%s %s prints %s; its "
                            "binding table binds %s: %s" % (
                                sc.get("id"), at, want[:8], have[:8],
                                token_diff(want, have))))
            else:
                # (v6.14 F1) a coordinate pair carries its roles: x first,
                # y second, both of the point printed before it
                for why in SB.coord_role_problems(
                        txt, b.get("bind") or [], facts, ents,
                        SB.graph_find_rels(pub.get("figures"))):
                    out.append((FAIL, "G80_BOUND", bnd, "%s %s: %s" % (
                        sc.get("id"), at, why)))
            kinds = dict((t, k) for k, t in SB.atoms(txt))
            for x in b.get("bind") or []:
                tok = x.get("tok")
                k = kinds.get(tok)
                why = None
                try:
                    val = SB.atom_value(k, tok) if k in ("number",
                                                         "word") else None
                except Exception:                 # noqa: BLE001
                    val, why = None, "not a number"
                if why:
                    pass
                elif "fact" in x:
                    # (v6.13 fix_r1) one atom may state the same value of
                    # several facts ("fact": [fid, ...]): each is checked
                    fl = SB.bind_facts(x)
                    if not fl:
                        why = "fact %r is not a fact id / list" % (
                            x["fact"],)
                    for fx in fl:
                        f = facts.get(fx)
                        if f is None or "value" not in f:
                            why = "fact %s is not a public fact with a " \
                                "value" % fx
                        elif f.get("role") in SB.PRIVATE_VALUE_ROLES:
                            why = "bound to %s (%s): a private value" % (
                                fx, f.get("role"))
                        elif val is not None and val != SB.value_of(
                                f["value"]):
                            why = "%s is %s" % (fx, f["value"])
                        if why:
                            break
                elif "entity" in x:
                    e = ents.get(x["entity"])
                    if e is None:
                        why = "entity %s is not public" % x["entity"]
                    elif k in ("number", "word"):
                        ev = e.get("value", e.get("at"))
                        if ev is None or (val is not None and
                                          val != SB.value_of(ev)):
                            why = "%s is %s" % (x["entity"], ev)
                    elif not SB.name_ok(e, k, tok[1:] if k in (
                            "angle", "triangle") else tok, None):
                        why = "%s does not name %s" % (tok, x["entity"])
                elif "count" in x:
                    lst = x.get("count") or []
                    if any(c not in ents for c in lst) or (
                            val is not None and val != len(lst)):
                        why = "counts %d public entities" % len(lst)
                elif "enum" in x:
                    # (v6.16 fix r1, I-3) a roman list marker '(ii)' is a
                    # var atom whose roman value is the marker's number
                    if k == "var":
                        if SB.roman_value(tok) != x.get("enum"):
                            why = "list marker %r" % (x.get("enum"),)
                    elif val != x.get("enum"):
                        why = "list marker %r" % (x.get("enum"),)
                elif "question" in x:
                    if val != qn.get(x.get("question")):
                        why = "question %s is number %s" % (
                            x.get("question"), qn.get(x.get("question")))
                elif "calc" in x:
                    # (v6.13 fix_r2) a printed calculation's result
                    nb = [t_ for k_, t_ in SB.atoms(txt)[:[
                        i for i, y in enumerate(b.get("bind") or [])
                        if y is x][0]] if k_ == "number"]
                    why = SB.calc_problem(x.get("calc"), nb, val) \
                        if kinds.get(tok) == "number" else \
                        "calc binds a number"
                elif "intervals" in x:
                    got = ivl.get(x.get("intervals"))
                    if not got or len(got) != 1 or val is None or \
                            val != list(got)[0]:
                        why = "figure %s prints %s intervals" % (
                            x.get("intervals"), sorted(got or [], key=str))
                elif "graph" in x:
                    # (v6.16 integrate) a public number / name of a graph
                    # figure of the question, read from the PUBLIC model
                    from wspec import sheet_graph as SGR
                    why = SGR.bind_problem(
                        SGR.question_graphs(pub, q.get("id"), public=True),
                        x.get("graph"), k, tok, val, txt)
                elif "pie" in x:
                    # (v6.16 integrate) a percent word = its pie's unit
                    from wspec import sheet_pie as SPI
                    why = SPI.bind_problem(pub, x.get("pie"), k, tok)
                else:
                    why = "binds nothing"
                if why:
                    out.append((FAIL, "G80_BOUND", bnd, "%s %s: %r -- %s" % (
                        sc.get("id"), at, tok, why)))
            # the block is what the row / cell prints
            if at.startswith("text:"):
                k2 = row.find(txt, pos)
                if k2 < 0:
                    out.append((FAIL, "G80_BOUND", bnd, "%s: the printed "
                                "text does not hold its bound block %r "
                                "(in order)" % (sc.get("id"), txt[:50])))
                else:
                    pos = k2 + len(txt)
            else:
                have_p = _cell_of(q, at)
                have_s = _cell_of(sq.get(q.get("id")) or {}, at)
                if _ws(have_p) != _ws(txt) or _ws(have_s) != _ws(txt):
                    out.append((FAIL, "G80_BOUND", bnd, "%s %s: the bound "
                                "block says %r; public spec %r, sheet.json "
                                "%r" % (q.get("id"), at, txt[:40],
                                        (have_p or "")[:40],
                                        (have_s or "")[:40])))
    return out


def bound_numbers(pub):
    """{data-bind block: [digit tokens every bound number prints]}."""
    from wspec import schema_bound as SB
    out = {}
    for kind, sc, q in _bound_scopes(pub):
        row = sc.get("text") or ""
        if isinstance(row, list):
            row = "\n".join(row)
        pos = 0
        for b in sc.get("bound") or []:
            at = str(b.get("at") or "")
            text = b.get("text") or ""
            parts = [(_bound_bind(kind, sc.get("id"), at), text)]
            if kind == "question" and at.startswith("text:"):
                start = row.find(text, pos)
                if start >= 0:
                    # `text:k` numbers bound segments, not paragraphs. A
                    # stem may contain several such segments in one printed
                    # paragraph or a bound segment spanning several lines.
                    # Locate it in order, as bound_faults does, then bind each
                    # number to the actual paragraph that must print it.
                    paragraph = row.count("\n", 0, start)
                    parts = [("stem:%s:%d" % (sc.get("id"), paragraph+i), line)
                             for i, line in enumerate(text.split("\n"))]
                    pos = start + len(text)
                # A missing excerpt remains charged to the original block;
                # bound_faults additionally fails its source mismatch.
            for bnd, part in parts:
                for k, t in SB.atoms(part):
                    if k == "number":
                        out.setdefault(bnd, []).extend(
                            x for x in tokens(t) if x[:1].isdigit())
    return out


def _bound_drawn(r, proven_drawn=None):
    """Drawn-maths tokens of a row (stem / item text, table cells,
    example lines): numbers printed as paths are bound by R."""
    if proven_drawn is not None:
        return proven_drawn.get(r[0], [])
    kind, payload = r[3], r[4]
    if kind in ("stem", "item"):
        return drawn_tokens(row_text(kind, payload))
    txts = []
    if kind == "table" and isinstance(payload, dict):
        txts = list(payload.get("head") or []) + [
            c for row in payload.get("rows") or [] for c in row]
    elif kind == "example" and isinstance(payload, dict):
        txts = [payload.get("title") or ""] + list(payload.get("lines") or [])
    out = []
    for t in txts:
        out.extend(drawn_tokens(t))
    return out


# =========================================================== verify =====
def _q_of(bind):
    parts = bind.split(":")
    if len(parts) >= 2:
        m = re.match(r"(q\d+)", parts[1])
        if m:
            return m.group(1)
    return None


def verify_level(level, sd=None, dpi=DPI, pdf_path=None, html=None,
                 sheet=None, build=None):
    """G80 on a delivered level folder (or on the pieces given)."""
    import pymupdf
    sd = sd or skill_dir()
    if sd not in sys.path:
        sys.path.insert(0, sd)
    rep = {"gate": GATE, "version": VERSION, "status": PASS, "blocks": {},
           "questions": {}, "findings": [], "notes": []}

    def add(level_, code, bind, detail):
        rep["findings"].append({"level": level_, "code": code, "bind": bind,
                                "qid": _q_of(bind) if bind else None,
                                "detail": detail})

    def _load(name):
        with open(os.path.join(level, name), encoding="utf-8") as fh:
            return fh.read()
    try:
        sheet = sheet if sheet is not None else json.loads(_load("sheet.json"))
        h = html if html is not None else _load("sheet.html")
    except (OSError, ValueError) as e:
        add(FAIL, "G80_MISSING", None, "sheet.json / sheet.html unreadable: "
            "%s" % e)
        return _finish(rep, {})
    if build is None:
        try:
            build = json.loads(_load("build.json"))
        except (OSError, ValueError):
            build = {}
    pdf_path = pdf_path or os.path.join(level, "sheet.pdf")
    # D0: the digital copies agree (sheet.json / noam-ai.json / public spec)
    def _opt(name):
        try:
            return json.loads(_load(name))
        except (OSError, ValueError):
            return None
    pub_spec = _opt(os.path.join("wspec", "public_spec.json"))
    for lv, code, bnd, det in digital_faults(
            sheet, pub_spec, _opt("noam-ai.json")):
        add(lv, code, bnd, det)
    # B (v6.13): bound prose -- the binding tables of the public spec
    for lv, code, bnd, det in bound_faults(sheet, pub_spec):
        add(lv, code, bnd, det)
    bnums = bound_numbers(pub_spec)
    # D
    h2, blocks, _f = annotate(h, sheet)
    proven_drawn = {}
    for lv, code, bnd, det in html_faults(blocks, sheet, proven_drawn):
        add(lv, code, bnd, det)
    rows = dict((r[0], r) for r in expected_rows(sheet))
    # L
    try:
        doc, pdfb = render(h2, sd)
    except Exception as e:                            # noqa: BLE001
        add(REVIEW, "G80_RENDER", None, "sheet.html does not render here: "
            "%s" % str(e)[:160])
        return _finish(rep, {})
    lay = layout_blocks(doc)
    env = env_fingerprint(sd)
    rec = (build or {}).get("text_binding") or {}
    same_env = bool(rec) and rec.get("env") == env
    if rec:
        rb = rec.get("blocks") or {}
        for bnd in sorted(set(rb) | set(lay)):
            a, b = rb.get(bnd), lay.get(bnd)
            ok = a is not None and b is not None and len(a) == len(b) and \
                all(x[0] == y[0] and all(abs(p - q) <= TOL_LOC for p, q in
                                         zip(x[1:], y[1:]))
                    for x, y in zip(a, b))
            if not ok:
                add(FAIL if same_env else REVIEW, "G80_LOCATION", bnd,
                    "build.json records block %s at %s; the verified "
                    "document prints it at %s%s" % (
                        bnd, a, b, "" if same_env else
                        " (render environment differs from the build's: "
                        "%s)" % env))
    else:
        rep["notes"].append("no build-time text_binding record (built "
                            "before v6.11): locations are the "
                            "verification's own layout")
    if rec and not same_env:
        rep["notes"].append("render environment differs from the build's "
                            "(%s vs %s): raster differences are REVIEW"
                            % (env, rec.get("env")))
    # T + R + P
    try:
        A = pymupdf.open(pdf_path)
    except Exception as e:                            # noqa: BLE001
        add(FAIL, "G80_PAGES", None, "sheet.pdf unreadable: %s" % e)
        return _finish(rep, lay)
    B = pymupdf.open(stream=pdfb, filetype="pdf")
    if len(A) != len(B):
        add(FAIL, "G80_PAGES", None, "sheet.pdf has %d page(s); the "
            "document prints %d" % (len(A), len(B)))
    strict = same_env or not rec
    for bnd, boxes in sorted(lay.items()):
        r = rows.get(bnd)
        for pg, x0, y0, x1, y1 in boxes:
            if pg >= len(A) or pg >= len(B):
                add(FAIL, "G80_PAGES", bnd, "block %s prints on page %d, "
                    "which sheet.pdf lacks" % (bnd, pg + 1))
                continue
            clip = (x0 - PAD_PT, y0 - PAD_PT, x1 + PAD_PT, y1 + PAD_PT)
            want = _chars(B[pg], clip)
            have = _chars(A[pg], clip)
            if want != have:
                d = token_diff(tokens(want), tokens(have))
                add(FAIL, "G80_TEXT", bnd,
                    "page %d, block %s: the printed text is not the "
                    "verified text%s" % (
                        pg + 1, bnd, (": " + d) if d else
                        " (words differ: %r -> %r)" % (want[:50],
                                                       have[:50])))
            rr = raster_compare(A[pg], B[pg], clip, dpi)
            v = raster_verdict(rr)
            if v == FAIL:
                add(FAIL if strict else REVIEW, "G80_RASTER", bnd,
                    "page %d, block %s: %d px of ink differ from the "
                    "verified print (glyphs or drawn maths changed)"
                    % (pg + 1, bnd, rr["n1"]))
            elif v == REVIEW:
                add(REVIEW, "G80_RASTER_SMALL", bnd,
                    "page %d, block %s: %d/%d stray px differ from the "
                    "verified print (smaller than a glyph)" % (
                        pg + 1, bnd, rr["n2"], rr["n1"]))
            elif rr["n0"]:
                rep["notes"].append("page %d, block %s: layout-only "
                                    "difference (shift %s pt, %d px of "
                                    "anti-aliasing)" % (
                                        pg + 1, bnd, rr["shift_pt"],
                                        rr["n1"]))
        # B (v6.13): every bound number is on the PRINTED page (sheet.pdf
        # itself, not the expected print), as text or as drawn maths
        if bnd in bnums and r is not None:
            seen_a = []
            for pg, x0, y0, x1, y1 in boxes:
                if pg < len(A):
                    seen_a.extend(t for t in tokens(_chars(
                        A[pg], (x0 - PAD_PT, y0 - PAD_PT, x1 + PAD_PT,
                                y1 + PAD_PT), spaced=True))
                        if t[:1].isdigit())
            rest = list(bnums[bnd])
            for t in seen_a + [t for t in _bound_drawn(r, proven_drawn)
                               if t[:1].isdigit()]:
                if t in rest:
                    rest.remove(t)
            if rest:
                add(FAIL, "G80_BOUND", bnd,
                    "%s: bound number(s) %s are not on the printed page "
                    "(sheet.pdf prints %s)" % (bnd, rest[:6], seen_a[:12]))
        # S: the row's own tokens against what the print shows
        if r is not None and r[3] in ("stem", "item"):
            txt = row_text(r[3], r[4])
            want = tokens(_untex(re.sub(r"\*\*", "", txt)))
            shown = []
            for pg, x0, y0, x1, y1 in boxes:
                if pg < len(B):
                    shown.extend(tokens(_chars(B[pg], (x0 - PAD_PT,
                                                       y0 - PAD_PT,
                                                       x1 + PAD_PT,
                                                       y1 + PAD_PT),
                                               spaced=True)))
            if r[3] == "item":
                lab = str((r[4] or {}).get("label") or "")
                for t in tokens(lab):
                    if t in shown:
                        shown.remove(t)
            drawn = proven_drawn.get(bnd, [])
            rest = list(want)
            for t in shown + drawn:
                if t in rest:
                    rest.remove(t)
            if rest:
                add(REVIEW, "G80_READ", bnd,
                    "%s: %s of the sheet.json text are neither in the "
                    "printed text nor in its drawn maths" % (bnd, rest[:6]))
            if r[3] == "item":
                # a target the text names (find: of / at+rays) is printed:
                # as text, or in a drawn island (bound by R)
                flat = _untex(txt).replace(" ", "")
                seen = "".join(t for t in shown + drawn if t.isalpha())
                for alts in targets(r[4]):
                    named = [a for a in alts if len(a) > 1 and a in flat]
                    if named and not any(_subseq(a, seen) for a in named):
                        add(REVIEW, "G80_TARGET", bnd,
                            "item %s names its target %s, which the print "
                            "does not show readably" % (r[2], named[0]))
    # P: the rest of each page
    import numpy as np
    for pg in range(min(len(A), len(B))):
        ga, gb = _gray(A[pg], dpi), _gray(B[pg], dpi)
        if ga.shape != gb.shape:
            add(FAIL, "G80_PAGES", None, "page %d has another size" %
                (pg + 1))
            continue
        m = np.ones(ga.shape, dtype=bool)
        k = dpi / 72.0
        mine = []
        for bnd, boxes in lay.items():
            for p2, x0, y0, x1, y1 in boxes:
                if p2 != pg:
                    continue
                mine.append((bnd, y0, y1))
                m[max(0, int((y0 - PAD_PT) * k)):int((y1 + PAD_PT) * k) + 1,
                  max(0, int((x0 - PAD_PT) * k)):int((x1 + PAD_PT) * k) + 1] \
                    = False
        rr = raster_diff(ga, gb, dpi, mask=m)
        v = raster_verdict(rr)
        if v != PASS:
            yc = float(np.median(rr["rows"])) / k if len(rr["rows"]) \
                else 0.0
            near = min(mine, key=lambda t: 0 if t[1] <= yc <= t[2] else
                       min(abs(yc - t[1]), abs(yc - t[2]))) if mine else None
            bnd = near[0] if near else None
            if v == FAIL:
                add(FAIL if strict else REVIEW, "G80_PAGE_INK", bnd,
                    "page %d: %d px of ink outside the bound blocks differ "
                    "from the verified print (near y %.0f pt%s)" % (
                        pg + 1, rr["n1"], yc, ", charged to %s" % bnd
                        if bnd else ", charged to every question"))
            else:
                add(REVIEW, "G80_PAGE_INK", bnd,
                    "page %d: %d/%d stray px outside the bound blocks "
                    "(near y %.0f pt)" % (pg + 1, rr["n2"], rr["n1"], yc))
        elif rr["n0"]:
            rep["notes"].append("page %d: layout-only difference outside "
                                "the blocks (shift %s pt)" % (
                                    pg + 1, rr["shift_pt"]))
        # text layer outside the blocks
        ta = _page_text_outside(A[pg], mine, lay, pg)
        tb = _page_text_outside(B[pg], mine, lay, pg)
        if ta != tb:
            add(FAIL, "G80_PAGE_TEXT", mine[0][0] if mine else None,
                "page %d: the text outside the bound blocks is not the "
                "verified text: %s" % (pg + 1, token_diff(tokens(tb),
                                                         tokens(ta)) or
                                       "words differ"))
    return _finish(rep, lay)


def _page_text_outside(page, mine, lay, pg):
    boxes = [b for bnd, bl in lay.items() for b in bl if b[0] == pg]
    out = []
    for b in page.get_text("rawdict")["blocks"]:
        for ln in b.get("lines", []):
            for s in ln["spans"]:
                for c in s["chars"]:
                    if c["c"].isspace():
                        continue
                    x0, y0, x1, y1 = c["bbox"]
                    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
                    if any(bx[1] - PAD_PT <= cx <= bx[3] + PAD_PT and
                           bx[2] - PAD_PT <= cy <= bx[4] + PAD_PT
                           for bx in boxes):
                        continue
                    out.append((round(c["origin"][1]), round(cx, 1),
                                c["c"]))
    out.sort()
    return "".join(c for _y, _x, c in out)


def _finish(rep, lay):
    for f in rep["findings"]:
        if f["bind"]:
            b = rep["blocks"].setdefault(f["bind"], {"status": PASS,
                                                     "findings": []})
            b["findings"].append(f["code"])
            b["status"] = _worst([b["status"], f["level"]])
    for bnd, boxes in lay.items():
        b = rep["blocks"].setdefault(bnd, {"status": PASS, "findings": []})
        b["boxes"] = boxes
        b["qid"] = _q_of(bnd)
    for bnd, b in rep["blocks"].items():
        q = b.get("qid") or _q_of(bnd)
        if q:
            rep["questions"][q] = _worst([rep["questions"].get(q, PASS),
                                          b["status"]])
    rep["status"] = _worst(f["level"] for f in rep["findings"])
    rep["n_blocks"] = len(lay)
    return rep


def summary(rep):
    """The build.json checks.g80_text record."""
    c = {}
    for f in rep.get("findings") or []:
        c[f["level"]] = c.get(f["level"], 0) + 1
    return {"gate": GATE, "version": VERSION, "status": rep["status"],
            "blocks": rep.get("n_blocks", 0),
            "fail": c.get(FAIL, 0), "review": c.get(REVIEW, 0),
            "findings": [dict((k, f[k]) for k in ("level", "code", "bind",
                                                  "detail"))
                         for f in (rep.get("findings") or [])[:40]]}


def line(key, rep):
    c = {}
    for f in rep.get("findings") or []:
        c[f["level"]] = c.get(f["level"], 0) + 1
    first = [f for f in rep.get("findings") or [] if f["level"] != PASS][:2]
    return "%-10s %-4s %-7s %d block(s) bound to sheet.json%s%s" % (
        GATE, key, rep["status"], rep.get("n_blocks", 0),
        "" if not c else "  FAIL %d REVIEW %d" % (c.get(FAIL, 0),
                                                   c.get(REVIEW, 0)),
        "".join("\n             %s %s %s" % (f["level"], f["code"],
                                             f["detail"][:150])
                for f in first))


# ===================================================== acceptance hook ===
def _q_status(rep, qid):
    """(status, [findings]) charged to question qid: its blocks' findings
    and those with no block (pages missing, the PDF unreadable)."""
    fs = [f for f in rep.get("findings") or [] if f["level"] != PASS and
          (f.get("qid") == qid or not f.get("bind"))]
    st = _worst([rep.get("questions", {}).get(qid, PASS)] +
                [f["level"] for f in fs])
    return st, fs


def scenario_status(rep, scenario):
    """(status, reason) the binding charges to one acceptance scenario:
    the worst status of the blocks of the scenario's question (its stem,
    figure, items, and page ink charged to it). None when nothing of the
    question failed or was ambiguous."""
    src = (scenario or {}).get("source") or {}
    qid = src.get("question")
    if not qid:
        m = re.match(r"(q\d+)", str(src.get("unit_id") or
                                    src.get("figure") or ""))
        qid = m.group(1) if m else None
    if not qid or rep is None:
        return None
    if qid not in rep.get("questions", {}):
        return (FAIL, "%s FAIL: question %s prints no bound block" % (
            GATE, qid))
    st, fs = _q_status(rep, qid)
    if st == PASS:
        return None
    return (st, "%s %s: %s" % (GATE, st, "; ".join(
        "%s %s" % (f["code"], f["detail"][:160]) for f in fs[:3])))


_QCACHE = {}


def check_question(level_dir, level=None, qid=None, ctx=None):
    """The acceptance hook (acceptance/hooks/new1_hook.py delegates here):
    {"status": PASS | REVIEW | FAIL, "reasons": [...]} of question `qid`
    on the delivered level folder -- the worst G80 status of its blocks
    (stem, figure, items, page ink charged to it). The level's G80 runs
    once (cached by folder, sheet.pdf / sheet.json / sheet.html /
    build.json identity). A qid that prints no block is FAIL."""
    key = os.path.abspath(level_dir)
    stamp = tuple(os.stat(os.path.join(key, n)).st_mtime_ns
                  if os.path.exists(os.path.join(key, n)) else 0
                  for n in ("sheet.pdf", "sheet.json", "sheet.html",
                            "build.json"))
    c = _QCACHE.get(key)
    if c is None or c[0] != stamp:
        sd = (ctx or {}).get("skill") if isinstance(ctx, dict) else None
        c = (stamp, verify_level(key, sd if sd and os.path.isfile(
            os.path.join(sd, "emit_html.py")) else None))
        _QCACHE[key] = c
    rep = c[1]
    if not qid:
        return {"status": rep["status"] if rep["status"] != PASS else PASS,
                "reasons": ["%s %s (no question named): level %s" % (
                    GATE, rep["status"], level)]}
    if qid not in rep.get("questions", {}):
        return {"status": FAIL, "reasons": ["%s: question %s prints no "
                                            "bound block on the sheet" % (
                                                GATE, qid)]}
    st, fs = _q_status(rep, qid)
    return {"status": st,
            "reasons": ["%s %s %s: %s" % (GATE, f["level"], f["code"],
                                          f["detail"][:200])
                        for f in fs[:6]] or
            ["%s PASS: %d block(s) of %s bound to sheet.json" % (
                GATE, sum(1 for b in rep["blocks"].values()
                          if b.get("qid") == qid), qid)]}


def patch_runner(cls):
    """Wrap an acceptance runner class (run_acceptance_pdf.PdfRunner or its
    v6.10 successor): every pilot scenario is charged its question's G80
    status -- FAIL makes the scenario FAIL, REVIEW turns a PASS into
    REVIEW. The level's G80 runs once per level (on <deliver>/<k>)."""
    if getattr(cls, "_g80_patched", False):
        return cls
    base_run = cls.run

    def run(self, s):
        r = base_run(self, s)
        src = s.get("source") or {}
        if src.get("synthetic") or not src.get("level"):
            return r
        cache = self.__dict__.setdefault("_g80", {})
        lv = src["level"]
        if lv not in cache:
            d = os.path.join(self.deliver, lv)
            cache[lv] = verify_level(d) if os.path.isfile(
                os.path.join(d, "sheet.pdf")) else None
        v = scenario_status(cache[lv], s)
        r.setdefault("g80", (cache[lv] or {}).get("questions", {}).get(
            src.get("question") or "", "n/a") if cache[lv] else "n/a")
        if v is None:
            return r
        st, why = v
        if st == FAIL and r.get("status") != FAIL:
            r["status"], r["reason"] = FAIL, why
        elif st == REVIEW and r.get("status") == PASS:
            r["status"], r["reason"] = REVIEW, why
        return r

    cls.run = run
    cls._g80_patched = True
    return cls


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    as_json = "--json" in argv
    argv = [a for a in argv if a != "--json"]
    if not argv:
        print("usage: python3 textbind.py <level_dir> [...] [--json]")
        return 2
    bad = 0
    for d in argv:
        rep = verify_level(d)
        if as_json:
            print(json.dumps(rep, ensure_ascii=False, default=str))
        else:
            print(line(os.path.basename(os.path.normpath(d)), rep))
            for f in rep["findings"]:
                print("    %-6s %-16s %-14s %s" % (f["level"], f["code"],
                                                  f["bind"] or "-",
                                                  f["detail"][:200]))
        bad += rep["status"] != PASS
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
