# -*- coding: utf-8 -*-
"""export.py — v6.5: ONE place where every builder's figure says what it drew.

Why this file exists (the author's decision, DELIVERABLE_SPEC.md):
a sheet ships with a JSON that names every point and segment of every figure,
so the author's AI can highlight "the point M" or "the segment AB" without
re-reading an image. That is only true if the ids in the JSON are the ids in
the SVG, and if both come from the ONE build that drew the picture. So the
machinery lives here and every builder feeds it; no builder writes its own
export, and a new builder that draws through figkit.Figure gets ids without
asking for them.

--------------------------------------------------------------------------
THE ID RULE (stable across builds; unchanged when an unrelated object is added)
--------------------------------------------------------------------------
1. NAME-DERIVED WHEREVER A NAME EXISTS. A point the figure names A is `pt-A`.
   A segment between named points is `seg-AB` with the two names in the
   order they sort, so the same segment gets the same id whichever end the
   builder drew from (`seg-AB`, never `seg-BA`). A polygon edge is a segment
   and gets the same `seg-AB`. A circle centred on a named point is `cir-A`;
   an arc at a named vertex is `arc-A`; a mark is `<kind>-<name>` (`ra-A`,
   `tick-AB`, `par-AB`); a dimension is `dim-AB`; a label is `lbl-` plus what
   it labels (`lbl-A` for the letter at A, `lbl-AB` for the 12 on AB).
2. NEVER INDEX-DERIVED WHERE A NAME EXISTS, and never index-derived at all:
   an unnamed object is keyed by ITS OWN GEOMETRY — `seg-7f3a21` where the
   suffix is the first 6 hex of a sha1 over the object's kind, role and its
   data coordinates rounded to 1e-3. Two builds of the same figure from the
   same data hash the same; adding an unrelated object changes nobody else's
   coordinates, so it changes nobody else's id.
3. COLLISIONS (two objects that would claim one id — a figure with two
   unnamed marks on top of each other, or two labels on one segment) are
   broken by appending `-2`, `-3` in the order the colliding objects' own
   geometry keys sort. NOT in insertion order: insertion order moves when an
   unrelated object is added, and geometry does not.

Names reach this module from the drawing itself: `name_point` (a builder that
knows it is drawing vertex A says so) and the figure's own single-letter
labels, which are harvested at finish time. Nothing here guesses a name.

--------------------------------------------------------------------------
THE TWO COORDINATE FRAMES
--------------------------------------------------------------------------
`xy`      the data coordinates — the frame the builder drew in.
`svg_xy`  the same point inside the finished SVG's viewBox, after the figure
          was framed and fitted, so a caller can put a marker on it.
`view`    {width_px, height_px, unit_px, rotate}: `unit_px` is how many
          screen pixels one viewBox unit is worth (width_px / viewBox width),
          so  screen_px = svg_xy * unit_px  and  svg_xy = xy - frame0.
          `rotate` is the builder's rotation in degrees (already baked into
          `xy`; it is reported so a caller can undo it).

--------------------------------------------------------------------------
THE REFUSAL
--------------------------------------------------------------------------
`verify(svg, objects)` re-reads the FINISHED SVG string and refuses when the
export and the picture disagree: an id that is not in the file, or an id whose
element does not sit where the export claims (1 px). A figure that cannot say
truthfully what it drew does not ship.
"""

import hashlib
import math
import re

TOL_PX = 1.0                    # how far an id may sit from its claim
# v6.5 X2 r1 (MINOR-13): `xy` is printed to 6 decimals. At 3, a number line
# zoomed to hundredths (about 1000 px per unit) put data_to_svg(xy) up to
# half a pixel from svg_xy; the spec asks for pixel-exact highlighting.
XY_DP = 6
_NAME_RE = re.compile(u"^[A-Za-z][′″']*[0-9]?$")

_PREFIX = {
    "point": "pt",
    "segment": "seg",
    "circle": "cir",
    "arc": "arc",
    "path": "path",
    "polygon": "poly",
    "label": "lbl",
    "dimension": "dim",
    "mark": "mark",
    "right_angle": "ra",
    "ticks": "tick",
    "parallel": "par",
    "marker": "mk",
    # v6.8 G7: a line or a ray a figure draws is an object too (ln-, ray-)
    "line": "ln",
    "ray": "ray",
}

# v6.5 r1 (X1-07): the kinds this module knows how to id, verify and bucket.
# A kind it has never heard of used to get an id, land in "marks" and take
# verify()'s generic branch -- a typo reaching the author's AI as a
# first-class object. A new kind is added HERE (prefix + as_dict bucket +
# a verify branch), never by passing a new string in.
KINDS = tuple(sorted(_PREFIX))


def _rnd(v, n):
    """Round for the JSON, and never print '-0.0' (a value frame that reads
    -0.0 for the axis is noise a diff has to explain)."""
    x = round(float(v), n)
    return 0.0 if x == 0.0 else x


def _r(v):
    """Round for hashing: 1e-3 of a figure unit, and never '-0.0'."""
    x = round(float(v) + 0.0, 3)
    return 0.0 if x == 0.0 else x


def _key(kind, role, pts, extra=None):
    """The geometry key of an unnamed object: what it is and where it is."""
    body = "%s|%s|%s" % (kind, role or "",
                         ";".join("%.3f,%.3f" % (_r(p[0]), _r(p[1]))
                                  for p in pts))
    if extra is not None:
        body += "|%s" % (extra,)
    return body


def _hash6(body):
    return hashlib.sha1(body.encode("utf-8")).hexdigest()[:6]


def slug(text):
    """A name safe inside an id: Latin letters, digits, primes -> ASCII."""
    out = []
    for ch in (text or ""):
        if ch.isalnum() and ord(ch) < 128:
            out.append(ch)
        elif ch in u"′'":
            out.append("p")
        elif ch == u"″":
            out.append("pp")
        elif ch == u"−":
            out.append("m")          # a true minus: 'lbl-xm3' for the -3
        elif ch == "-":
            out.append("-")          # a builder's own name ('axis-x')
        elif ch == ".":
            out.append("d")
    return "".join(out)


def make_id(kind, name):
    """The id a NAMED object gets — rule 1, for a builder that draws its own
    SVG (numberline) and needs the id while it draws. `Objects.add(name=...)`
    produces exactly this, so the two never disagree."""
    return "%s-%s" % (_PREFIX.get(kind, kind), slug(name))


def pair_name(a, b):
    """`seg-AB`, never `seg-BA`: the two ends in the order they sort."""
    x, y = slug(a), slug(b)
    return x + y if x <= y else y + x


class Item(object):
    """One object a figure drew."""

    __slots__ = ("kind", "pts", "role", "name", "part", "meta", "id",
                 "svg_xy", "ends", "dxy", "ref", "ref_ends", "ref_dxy")

    def __init__(self, kind, pts, role=None, name=None, part=None, meta=None,
                 ref=None):
        self.kind = kind
        self.pts = [tuple(float(c) for c in p) for p in pts]
        self.role = role
        self.name = name          # None until finish() resolves it
        self.part = part          # index into Figure.parts, or None
        self.meta = dict(meta or {})
        self.id = None
        self.svg_xy = None
        self.ends = None
        self.dxy = None           # the DATA frame, when the builder maps it
        # v6.5 r1 (X1-01): `pts` is WHERE THE INK IS. `ref` is the geometry
        # the object is ABOUT when the two differ -- a dimension is drawn on
        # a line offset from the segment it measures, and it is the segment
        # that gives it its name (dim-AB) and the segment a reader wants
        # reported. Both frames are exported; neither is guessed.
        self.ref = [tuple(float(c) for c in q) for q in ref] if ref else None
        self.ref_ends = None
        self.ref_dxy = None

    def as_dict(self):
        # v6.6 E (X1R2-06): `svg_id` is the spec's name for the id of the
        # element in the SVG; `id` stays beside it for v6.5 readers
        d = {"svg_id": self.id, "id": self.id, "kind": self.kind,
             "role": self.role or "data"}
        if self.name:
            d["name"] = self.name
        src = self.dxy or self.pts
        if self.kind in ("point", "label", "circle", "arc", "mark",
                         "right_angle", "marker"):
            d["xy"] = [_rnd(src[0][0], XY_DP), _rnd(src[0][1], XY_DP)]
            if self.svg_xy:
                d["svg_xy"] = [_rnd(self.svg_xy[0], 2),
                               _rnd(self.svg_xy[1], 2)]
        else:
            d["xy"] = [[_rnd(p[0], XY_DP), _rnd(p[1], XY_DP)] for p in src]
            if self.ends:
                d["svg_xy"] = [[_rnd(p[0], 2), _rnd(p[1], 2)]
                               for p in self.ends]
        if self.ref is not None:
            rs = self.ref_dxy or self.ref
            d["measures_xy"] = [[_rnd(q[0], XY_DP), _rnd(q[1], XY_DP)] for q in rs]
            if self.ref_ends:
                d["measures_svg_xy"] = [[_rnd(q[0], 2), _rnd(q[1], 2)]
                                        for q in self.ref_ends]
        if self.meta.get("_ink"):
            # v6.6 E r1: the element that inks this object (a polygon's edge
            # is drawn by the polygon); the svg_id itself is an anchor
            d["ink_svg_id"] = list(self.meta["_ink"])
        for k in sorted(self.meta):
            # a key starting with "_" is this module's own bookkeeping (the
            # hashing salt), not something the deliverable JSON describes
            if not k.startswith("_"):
                d[k] = self.meta[k]
        return d


class Objects(object):
    """The registry a Figure (or any other builder) fills while it draws."""

    def __init__(self):
        self.items = []
        self._names = {}          # rounded point -> name
        self.view = None
        self.frame0 = (0.0, 0.0)
        self.rotate = None
        self.fam = None
        self.kindname = None      # "shapekit.triangle", "plane", ...
        self._data = None         # figure frame -> the builder's data frame
        # X2 (DELIVERABLE_SPEC 3-4): what is TRUE of this figure, from the
        # same build that drew it. `_auto_done` keeps the derivation from
        # running twice when a Figure is rendered twice.
        self.cons = []
        self._auto_done = False
        self.projection = None    # "cabinet45:right" for a solid; None = flat
        # v6.5 X2 r1 (MINOR-14): a figure WRONG ON PURPOSE says so HERE, set
        # by the builder that drew it (figkit.Figure.critique, a number
        # line's student_drawing, a FAIL fixture rendered with check=False).
        # Packaging used to read "<!--critique:" out of the string, so one
        # comment pasted into any SVG turned a real re-measure failure into a
        # `violated` flag.
        self.critique = None

    # -- while drawing ------------------------------------------------------
    @staticmethod
    def _pk(p):
        return (round(float(p[0]), 3), round(float(p[1]), 3))

    def set_data(self, fn):
        """Declare the map back to the DATA frame. A builder that lays its
        figure out by rotating, flipping and fitting its data (euclid._Fig,
        and every shapekit shape through it) hands the inverse in, and then
        `xy` is the frame the QUESTION talks about -- and an unnamed object's
        id stops moving when the same figure is drawn at another rotation
        (v6.3 wants one drawing, character for character, at ten rotations)."""
        self._data = fn
        return self

    def name_point(self, p, name, role=None):
        """Declare that this coordinate IS the point called `name`."""
        if not name:
            return
        k = self._pk(p)
        if k not in self._names:
            self._names[k] = str(name)
            self.add("point", [p], role=role or "vertex")
        return self._names[k]

    def name_of(self, p):
        return self._names.get(self._pk(p))

    def add(self, kind, pts, role=None, name=None, part=None, meta=None,
            ref=None):
        """Register one drawn object. Returns the Item (its id comes later).

        `ref` is the geometry the object is ABOUT when that is not where its
        ink is (a dimension line offset from the segment it measures)."""
        if kind not in KINDS:
            raise AssertionError(
                "export.add: %r is not an object kind this module knows. "
                "The kinds are %s. A figure may only register what the "
                "deliverable JSON can describe -- add the kind to "
                "export.KINDS (prefix, as_dict bucket and a verify branch) "
                "before a builder draws one, or register the object under "
                "the kind it really is." % (kind, ", ".join(KINDS)))
        pts = [tuple(p) for p in pts]
        if kind == "point":
            for it in self.items:
                if it.kind == "point" and self._pk(it.pts[0]) == self._pk(pts[0]):
                    if role and it.role in (None, "point"):
                        it.role = role
                    return it
        it = Item(kind, pts, role=role, name=name, part=part, meta=meta,
                  ref=ref)
        self.items.append(it)
        return it

    def forget(self, kind):
        """Drop every object of one kind (v6.5 r1, X1-05).

        A Figure registers its labels at RENDER time, because a label's
        position is only known after the solver places it. Rendering the same
        Figure twice therefore used to register every label twice: the second
        pass produced lbl-A-2 on the glyph and left lbl-A -- the id a caller
        had already been handed -- as an anchor over nothing. Render clears
        the labels it is about to re-register instead.

        v6.6 E (X1R2-01): this is NOT a way to take drawn objects out of the
        sheet's JSON. A kind that already has objects registered HAS INK in
        the figure, and dropping them ships strokes nobody can name -- the
        very thing the 'registered but never drawn' refusal protects. So a
        kind with objects is refused; the one legitimate use (render
        re-registering the labels it places) goes through `_rerender`."""
        have = [it for it in self.items if it.kind == kind]
        if have:
            raise AssertionError(
                "export.forget(%r): this figure has %d %s object(s) already "
                "registered (%s) -- they are ink on the page, and forgetting "
                "them would ship strokes the sheet's JSON cannot name "
                "(DELIVERABLE_SPEC rule 4). Nothing is dropped: if an object "
                "should not be in the figure, do not draw it; if it is "
                "drawn, it is exported. A phantom refusal is fixed by "
                "drawing what was registered, not by forgetting it."
                % (kind, len(have), kind,
                   ", ".join(sorted(_forget_name(it) for it in have)[:4])))
        return self

    def _rerender(self, kind):
        """Render's own reset before it re-registers the objects it places
        (the labels): the objects are placed again in the same call."""
        self.items = [it for it in self.items if it.kind != kind]
        return self

    # -- when the frame is known -------------------------------------------
    def harvest(self, labels):
        """Take point names from the figure's own single-letter labels."""
        for L in labels:
            anchor = getattr(L, "anchor", None)
            text = getattr(L, "text", "")
            if anchor is None or not _NAME_RE.match(text or ""):
                continue
            if getattr(L, "export_face", None) or \
                    getattr(L, "export_owner", None) is not None or \
                    getattr(L, "owner", None) is not None:
                # v6.6 E r1: a letter written in a face or under a solid (a
                # caption 'V'), or naming a length on a segment (b, h, L),
                # names that face / solid / segment, not a point there
                continue
            k = self._pk(anchor)
            if k not in self._names:
                self._names[k] = text

    def resolve_ids(self):
        """Assign the ids without the frame (a builder that needs them while
        it draws). finish() re-runs it; the answer is the same."""
        self._resolve_ids()
        return self

    def finish(self, T, view, frame0=(0.0, 0.0), rotate=None, fam=None,
               kindname=None):
        """Resolve every id and every svg_xy. Idempotent within one render."""
        self.view = dict(view)
        self.frame0 = tuple(frame0)
        if rotate is not None:
            self.rotate = rotate
        if fam:
            self.fam = fam
        if kindname:
            self.kindname = kindname
        for it in self.items:
            pts = [T(p) for p in it.pts]
            it.ends = pts
            it.svg_xy = pts[0] if pts else None
            if it.ref:
                it.ref_ends = [T(p) for p in it.ref]
            # v6.8 r2 (I1): where the object's INK is, when that is not its
            # svg_xy -- a right-angle mark leaves its vertex bare, so a
            # consumer highlighting it goes to the L's corner (ink_xy); a
            # label's svg_xy is its text anchor on the baseline, and its
            # glyphs stand in the box the solver kept clear (ink_box)
            _c = it.meta.get("_corner")
            if callable(_c):
                # v6.7-noam: a mark whose ink is placed late (ticks,
                # chevrons, arcs) hands a function that reads it
                _c = _c()
            if _c is not None:
                q = T(_c)
                it.meta["ink_xy"] = [_rnd(q[0], 2), _rnd(q[1], 2)]
            if it.meta.get("_box") is not None:
                b = it.meta["_box"]
                qs = [T((b[0], b[1])), T((b[2], b[3]))]
                it.meta["ink_box"] = [
                    _rnd(min(q[0] for q in qs), 2),
                    _rnd(min(q[1] for q in qs), 2),
                    _rnd(max(q[0] for q in qs), 2),
                    _rnd(max(q[1] for q in qs), 2)]
            if self._data is not None:
                it.dxy = [tuple(self._data(p)) for p in it.pts]
                if it.ref:
                    it.ref_dxy = [tuple(self._data(p)) for p in it.ref]
        m = self._data_to_svg(T)
        if m:
            self.view["data_to_svg"] = m
            # v6.5 X2 r1 (MINOR-12): `unit_px` is CSS px per SVG unit (the
            # page scale of the viewBox). What one unit OF THE QUESTION is on
            # the page is this: px per data unit along x and along y.
            u = float(self.view.get("unit_px") or 1.0)
            self.view["data_unit_px"] = [round(u * math.hypot(m[0], m[1]), 6),
                                         round(u * math.hypot(m[2], m[3]), 6)]
        self._resolve_ids()
        if self._tie_labels():
            self._resolve_ids()
        # X2: the constraints are resolved here, where the names are known --
        # a mark registers its claim in coordinates long before the figure
        # has decided what to call that corner.
        self._auto_constraints()
        self._resolve_cons()
        self._link_labels()
        return self

    def _tie_labels(self):
        """v6.6 E (X1R2-03): a label printed on a segment or a dimension
        whose ends carry no letters names that object BY ITS ID (`for`:
        "dim-649752", id lbl-dim-649752), so the author's AI finds "the 5
        on the cylinder's height" from the JSON, not by position. The
        dimension measuring those ends wins over a segment drawn there."""
        tied = False
        for it in self.items:
            if it.kind != "label" or it.meta.get("for"):
                continue
            face = it.meta.get("_for_poly")
            if face and not it.meta.get("_for_pts"):
                want = sorted(self._pk(q) for q in face)
                for o in self.items:
                    if o.kind == "polygon" and o.id and \
                            sorted(self._pk(q) for q in o.pts) == want:
                        it.meta["for"] = o.id
                        it.name = None
                        tied = True
                        break
                continue
            ends = it.meta.get("_for_pts")
            at = it.meta.get("_for_at")
            if not ends and at:
                # v6.8 G6: a number written beside a plotted point (a
                # values= label: the '−4' next to the dot at (5, 10)) names
                # that point -- the nearest exported point / marker the
                # label is anchored to
                k = self._pk(at)
                for o in self.items:
                    if o.kind in ("point", "marker") and o.id and o.pts and \
                            self._pk(o.pts[0]) == k:
                        it.meta["for"] = o.id
                        it.name = None
                        tied = True
                        break
                else:
                    arc = self._degree_arc(it)
                    if arc is not None:
                        it.meta["for"] = arc
                        it.name = None
                        tied = True
                continue
            if not ends:
                continue
            p, q = self._pk(ends[0]), self._pk(ends[1])
            best = None
            for o in self.items:
                if o.kind not in ("dimension", "segment") or not o.id:
                    continue
                src = o.ref or o.pts
                if len(src) < 2:
                    continue
                a, b = self._pk(src[0]), self._pk(src[-1])
                if (a, b) in ((p, q), (q, p)):
                    if best is None or (o.kind == "dimension" and
                                        best.kind != "dimension"):
                        best = o
            part = None
            if best is None:
                # v6.6 E r1: a number on ONE PIECE of a longer stroke (an
                # edge cut in two, 'L | L') names the stroke it sits on
                for o in self.items:
                    if o.kind != "segment" or not o.id or len(o.pts) < 2:
                        continue
                    a, b = o.pts[0], o.pts[-1]
                    if all(_seg_dist(e, a, b) < 1e-3 * max(
                            1.0, math.hypot(b[0] - a[0], b[1] - a[1]))
                           for e in ends):
                        best = o
                        # v6.7 (E-r2-halfedge-label): ...and SAYS it is a
                        # piece: `for_part` is where the piece runs along the
                        # stroke (0 = its first end, 1 = its last), so two
                        # 'L's on the halves of BE read as BE = 2L, not as
                        # BE = L twice
                        L2 = (b[0] - a[0]) ** 2 + (b[1] - a[1]) ** 2 or 1.0
                        ts = sorted(round(((e[0] - a[0]) * (b[0] - a[0]) +
                                           (e[1] - a[1]) * (b[1] - a[1]))
                                          / L2, 4) for e in ends)
                        if ts[0] > 1e-3 or ts[1] < 1.0 - 1e-3:
                            part = ts
                        break
            if best is not None:
                it.meta["for"] = best.id
                if part is not None:
                    it.meta["for_part"] = part
                it.name = None
                tied = True
        return tied

    def _degree_arc(self, it):
        """(v6.10 fix r1, s2) an angle's value ('48°') names the arc it
        belongs to: the arc whose wedge holds the direction from its vertex
        to the label, else (a label set off beside a narrow wedge) the arc
        with the nearest vertex -- only when that choice is clear (no other
        arc vertex within 25% of the distance). None when the label is no
        degree value or no arc is clearly its own."""
        t = str(it.meta.get("text") or "").strip()
        if not t.endswith(u"\u00b0") or not it.pts:
            return None
        P = it.pts[0]

        def wrap(x):
            return math.atan2(math.sin(x), math.cos(x))
        cand = []
        for o in self.items:
            if o.kind != "arc" or not o.id or not o.pts:
                continue
            try:
                a1, a2 = [float(x) for x in str(o.meta.get("_k")).split(",")]
            except (TypeError, ValueError):
                continue
            V = o.pts[0]
            d = math.hypot(P[0] - V[0], P[1] - V[1])
            if d < 1e-9:
                continue
            ang = math.atan2(P[1] - V[1], P[0] - V[0])
            half = abs(wrap(a2 - a1)) / 2.0      # a wedge is < 180 degrees
            mid = a1 + wrap(a2 - a1) / 2.0
            inside = abs(wrap(ang - mid)) <= half + 0.05
            cand.append((0 if inside else 1, d, o.id, self._pk(V)))
        if not cand:
            return None
        cand.sort()
        best = cand[0]
        for c in cand[1:]:
            if c[0] == best[0] and c[3] != best[3] and \
                    c[1] < 1.25 * best[1]:
                return None                      # two vertices: unclear
        return best[2]

    def _link_labels(self):
        """A `length` a printed number states names that number's label as
        its mark (SHOULD-9): the author's AI finds "the label of BC" from
        the constraint, and the to_prove check can name it."""
        labs = {}
        for it in self.items:
            if it.kind == "label" and it.meta.get("for") and it.id:
                labs.setdefault(str(it.meta["for"]), it.id)
        arcs = {}
        at_v = {}
        for it in self.items:
            if it.kind == "arc" and it.id:
                n = self.name_of(it.pts[0])
                if n:
                    arcs.setdefault(n, it.id)
                    at_v.setdefault(n, []).append(it)
        pos = {}
        for it in self.items:
            if it.kind == "point" and it.pts:
                n = self.name_of(it.pts[0])
                if n:
                    pos.setdefault(n, it.pts[0])

        def arc_for(at, rays):
            # v6.7.1-noam (VE-M1): the arc that draws THIS wedge -- two arcs
            # at one vertex (a bisector's halves) are told apart by the
            # direction of their sweep, not merged into the first one
            cand = at_v.get(at) or []
            if not cand:
                return None
            if len(cand) == 1 or not rays or len(rays) != 2 or \
                    at not in pos or any(r not in pos for r in rays):
                return cand[0].id if len(cand) == 1 else None
            v = pos[at]
            ux = [pos[r][0] - v[0] for r in rays]
            uy = [pos[r][1] - v[1] for r in rays]
            ls = [math.hypot(x, y) or 1.0 for x, y in zip(ux, uy)]
            bx = sum(x / L for x, L in zip(ux, ls))
            by = sum(y / L for y, L in zip(uy, ls))
            want = math.atan2(by, bx)
            best = None
            for it in cand:
                try:
                    a1, a2 = [float(t) for t in
                              str(it.meta.get("_k")).split(",")]
                except (TypeError, ValueError):
                    continue
                mid = (a1 + a2) / 2.0
                dd = abs(math.atan2(math.sin(mid - want),
                                    math.cos(mid - want)))
                if best is None or dd < best[0]:
                    best = (dd, it.id)
            return best[1] if best and best[0] < 0.35 else None

        for c in self.cons:
            if c.type == "angle" and c.marked and not c.mark_id:
                m = arc_for(c.f.get("at"), c.f.get("rays"))
                if m:
                    c.mark_id = m
                continue
            if c.type == "equal_angle" and c.marked:
                # v6.6 E (V2-M1): the arcs that state it; v6.7-noam: ALL of
                # them (mark_ids), one per angle it equates
                ids = [arc_for(a["at"], a.get("rays")) or arcs[a["at"]]
                       for a in c.f.get("of") or []
                       if isinstance(a, dict) and a.get("at") in arcs]
                if not c.mark_id and ids:
                    c.mark_id = ids[0]
                if ids:
                    c.mark_ids = list(c.mark_ids or [])
                    for m in ids:
                        if m not in c.mark_ids:
                            c.mark_ids.append(m)
                continue
            if c.type != "length" or not c.marked or c.mark_id:
                continue
            of = c.f.get("of")
            key = None
            if isinstance(of, str):
                t = _NAME_TOK.findall(of)
                key = pair_name(*t) if len(t) == 2 and "".join(t) == of \
                    else of
            if key and key in labs:
                c.mark_id = labs[key]
        return self

    def _data_to_svg(self, T):
        """The affine that takes a DATA point to the finished SVG (X1-06).

        `unit_px` only converts the viewBox to the page. Without this a
        caller can place no point the export does not already list -- not the
        midpoint of AB, not a ratio point along it -- which is half of what
        the spec's "two coordinate systems" is for. Six numbers,
        `svg = (a*x + c*y + e, b*x + d*y + f)`, measured from the build's own
        map and then CHECKED against every exported object; if the builder's
        data map is not affine the key is left out rather than lied about."""
        if self._data is None:
            return None
        try:
            o, ux, uy = (0.0, 0.0), (1.0, 0.0), (0.0, 1.0)
            do, dux, duy = self._data(o), self._data(ux), self._data(uy)
            so, sux, suy = T(o), T(ux), T(uy)
            # data -> figure is the inverse of (figure -> data)
            a11, a21 = dux[0] - do[0], dux[1] - do[1]
            a12, a22 = duy[0] - do[0], duy[1] - do[1]
            det = a11 * a22 - a12 * a21
            if abs(det) < 1e-12:
                return None
            i11, i12 = a22 / det, -a12 / det
            i21, i22 = -a21 / det, a11 / det
            # figure -> svg
            f11, f21 = sux[0] - so[0], sux[1] - so[1]
            f12, f22 = suy[0] - so[0], suy[1] - so[1]

            def to_svg(q):
                x, y = q[0] - do[0], q[1] - do[1]
                fx, fy = i11 * x + i12 * y, i21 * x + i22 * y
                return (so[0] + f11 * fx + f12 * fy,
                        so[1] + f21 * fx + f22 * fy)

            for it in self.items:
                for q, e in zip(it.dxy or [], it.ends or []):
                    g = to_svg(q)
                    if math.hypot(g[0] - e[0], g[1] - e[1]) > 0.05:
                        return None
            z = to_svg((0.0, 0.0))
            ex_ = to_svg((1.0, 0.0))
            ey_ = to_svg((0.0, 1.0))
            return [round(ex_[0] - z[0], 6), round(ex_[1] - z[1], 6),
                    round(ey_[0] - z[0], 6), round(ey_[1] - z[1], 6),
                    round(z[0], 6), round(z[1], 6)]
        except Exception:
            return None

    def _base_id(self, it):
        pre = _PREFIX.get(it.kind, it.kind)
        if it.name:
            return "%s-%s" % (pre, slug(it.name))
        if it.kind == "point":
            n = self.name_of(it.pts[0])
            if n:
                it.name = n
                return "%s-%s" % (pre, slug(n))
        elif it.kind in ("segment", "dimension", "ticks", "parallel"):
            # X1-01: a dimension is named after the segment it MEASURES.
            # X1-04: the cached name is the SORTED pair, so the second pass
            # (which takes the `if it.name:` branch above) spells the same id
            # -- it used to flip seg-AB to seg-BA and hand out an id the file
            # does not contain.
            src = it.ref or it.pts
            a = self.name_of(src[0])
            b = self.name_of(src[-1])
            if a and b and a != b:
                it.name = pair_name(a, b)
                return "%s-%s" % (pre, it.name)
        elif it.kind in ("circle", "arc", "right_angle", "marker"):
            n = self.name_of(it.pts[0])
            if n:
                it.name = n
                return "%s-%s" % (pre, slug(n))
        elif it.kind == "polygon":
            names = [self.name_of(q) for q in it.pts]
            if all(names):
                it.name = "".join(slug(n) for n in names)
                return "%s-%s" % (pre, it.name)
        elif it.kind in ("label", "mark"):
            owner = it.meta.get("for")
            if owner:
                it.name = owner
                return "%s-%s" % (pre, slug(owner))
        return "%s-%s" % (pre, _hash6(self._gkey(it)))

    @staticmethod
    def _gkey(it):
        return _key(it.kind, it.role, it.dxy or it.pts, it.meta.get("_k"))

    @staticmethod
    def _tiebreak(it):
        """The order colliding objects are numbered in (rule 3).

        v6.5 r1 (X1-09): the geometry key alone leaves a stable sort, and a
        stable sort falls back to INSERTION order -- the one thing the rule
        forbids. Everything the JSON would print about the object joins the
        key, so two objects that still tie are the same object twice over and
        the suffix cannot move between builds."""
        return (Objects._gkey(it), it.kind, it.role or "", it.name or "",
                repr(sorted((k, repr(v)) for k, v in it.meta.items())))

    def _resolve_ids(self):
        groups = {}
        for it in self.items:
            groups.setdefault(self._base_id(it), []).append(it)
        for base, its in groups.items():
            if len(its) == 1:
                its[0].id = base
                continue
            # rule 3: geometry order, never insertion order
            order = sorted(its, key=self._tiebreak)
            for i, it in enumerate(order):
                it.id = base if i == 0 else "%s-%d" % (base, i + 1)

    # -- the constraints (X2) ----------------------------------------------
    def constrain(self, ctype, source="derived", item=None, marked=False,
                  mark_id=None, strict=True, **fields):
        """Register one fact about this figure, from the data that drew it.

        Operands are point names ("A"), segment names ("AB"), object ids, or
        RAW COORDINATES in the builder's own frame -- a primitive (a tick
        group, a right-angle mark) knows where it is long before it knows
        what the figure will call that point, so the coordinates are resolved
        into names at finish().

        `strict=False` is for constraints DERIVED FROM THE DRAWING itself: a
        mark on geometry the figure never registered has nothing to name, and
        the mark's own object is exported anyway. A builder stating a fact of
        its own keeps strict=True: an operand it cannot name is a bug in the
        builder, not a silent omission in the JSON.
        """
        if source not in SOURCES:
            _cbad("source=%r" % (source,),
                  "a constraint's source is one of %s (DELIVERABLE_SPEC rule 2)"
                  % ", ".join(SOURCES))
        fields = dict((k, v) for k, v in fields.items() if v is not None)
        check_fields(ctype, fields)
        if self.projection and ctype in PROJECTION_UNSAFE and \
                not fields.get("space"):
            if not strict:
                return None
            _cbad("a %s constraint on a figure drawn in the %s projection"
                  % (ctype, self.projection),
                  "the projection does not preserve it, so nothing can "
                  "re-measure it on the SVG (spec section 8). Export what "
                  "the picture does state -- %s -- and keep the solid's own "
                  "numbers in the question's data"
                  % ", ".join(t for t in CONSTRAINTS
                              if t not in PROJECTION_UNSAFE))
        c = Con(ctype, fields, source, item, marked, mark_id)
        c._pending = strict
        self.cons.append(c)
        return c

    def declare(self, con_key, source, item=None):
        """The content layer's hook: label an EXPORTED constraint `given` or
        `to_prove`. It never creates one -- the figure's own build is the
        single source (spec rule 1), so a declaration that matches nothing is
        a mistake the caller is told about."""
        hit = [c for c in self.cons if c.key() == con_key]
        for c in hit:
            c.source = source
            c.item = item
        return hit

    # names for coordinates, once the figure knows them ---------------------
    def _name_seg(self, p, q, strict):
        # v6.8 r1 (G7): a stroke the figure exports as a LINE (ln-) is that
        # line wherever a constraint names it -- parallel(ln-.., BC)
        for it in self.items:
            if it.kind == "line" and len(it.pts) >= 2 and (
                    (self._pk(it.pts[0]) == self._pk(p) and
                     self._pk(it.pts[-1]) == self._pk(q)) or
                    (self._pk(it.pts[0]) == self._pk(q) and
                     self._pk(it.pts[-1]) == self._pk(p))):
                return it.id
        a, b = self.name_of(p), self.name_of(q)
        if a and b and a != b:
            return pair_name(a, b)
        for it in self.items:
            if it.kind != "segment" or len(it.pts) < 2:
                continue
            if (self._pk(it.pts[0]) == self._pk(p) and
                self._pk(it.pts[-1]) == self._pk(q)) or \
               (self._pk(it.pts[0]) == self._pk(q) and
                    self._pk(it.pts[-1]) == self._pk(p)):
                return it.id
        if strict:
            _cbad("a constraint names the segment (%.2f, %.2f)-(%.2f, %.2f), "
                  "which this figure never drew" % (p[0], p[1], q[0], q[1]),
                  "register the constraint on geometry the figure draws, so "
                  "the JSON's operand has an id in the SVG")
        return None

    def _seg_containing(self, pq, tol=0.05):
        """The id of a drawn segment (or line) that CONTAINS both points of
        `pq` -- the direction a ray of a right-angle mark runs along."""
        if not (isinstance(pq, (list, tuple)) and len(pq) == 2 and
                all(_is_pt(x) for x in pq)):
            return None
        p, q = tuple(pq[0]), tuple(pq[1])
        best = None
        for it in self.items:
            if it.kind not in ("segment", "line") or len(it.pts) < 2 or \
                    not it.id:
                continue
            a, b = it.pts[0], it.pts[-1]
            L = math.hypot(b[0] - a[0], b[1] - a[1])
            if L <= 1e-9:
                continue
            ok = True
            for r in (p, q):
                t = ((r[0] - a[0]) * (b[0] - a[0]) +
                     (r[1] - a[1]) * (b[1] - a[1])) / (L * L)
                if _dist_line(r, a, b) > tol or (
                        it.kind == "segment" and not -1e-6 <= t <= 1 + 1e-6):
                    ok = False
                    break
            if ok and (best is None or L < best[0]):
                best = (L, it)
        if best is None:
            return None
        it = best[1]
        return it.name if it.kind == "segment" and it.name and \
            it.id == "seg-%s" % it.name else it.id

    def _name_pt(self, p, strict):
        n = self.name_of(p)
        if n:
            return n
        for it in self.items:
            if it.kind in ("point", "marker") and \
                    self._pk(it.pts[0]) == self._pk(p):
                return it.id
        if strict:
            _cbad("a constraint names the point (%.2f, %.2f), which this "
                  "figure never drew" % (p[0], p[1]),
                  "name the point (ex.name_point) or draw it before stating "
                  "a constraint about it")
        return None

    def _name_circle(self, p, strict):
        for it in self.items:
            if it.kind == "circle" and self._pk(it.pts[0]) == self._pk(p):
                return it.name or self.name_of(it.pts[0]) or it.id
        n = self.name_of(p)
        if n:
            return n
        if strict:
            _cbad("a constraint names the circle centred at (%.2f, %.2f), "
                  "which this figure never drew" % (p[0], p[1]),
                  "draw the circle before stating a constraint about it")
        return None

    def _resolve_one(self, kind, v, strict):
        """One operand, resolved by WHAT IT IS (FIELD_KIND), never by its
        shape: two coordinates are a segment under `length` and two points
        under `rays`."""
        if kind == "point":
            return self._name_pt(tuple(v), strict) if _is_pt(v) else v
        if kind == "circle":
            return self._name_circle(tuple(v), strict) if _is_pt(v) else v
        if kind == "segment":
            if isinstance(v, (list, tuple)) and len(v) == 2 and \
                    all(_is_pt(x) for x in v):
                return self._name_seg(tuple(v[0]), tuple(v[1]), strict)
            return v
        if kind in ("points", "segments", "circles", "angles"):
            one = {"points": "point", "segments": "segment",
                   "circles": "circle", "angles": "angle"}[kind]
            if one == "angle":
                return [self._resolve_angle(x, strict) for x in v]
            return [self._resolve_one(one, x, strict) for x in v]
        return v

    def _resolve_angle(self, v, strict):
        """An angle operand: "BAC", {"at": "A", "rays": ["B", "C"]}, or --
        from a mark that knows only where it is (v6.6 E, V2-M1) -- three
        coordinates [vertex, ray end, ray end], resolved into the dict form
        once the figure has named its points. None when a point has no
        name or id."""
        if isinstance(v, (list, tuple)) and len(v) == 3 and \
                all(_is_pt(x) for x in v):
            at = self._name_pt(tuple(v[0]), strict)
            r1 = self._name_pt(tuple(v[1]), strict)
            r2 = self._name_pt(tuple(v[2]), strict)
            if at is None or r1 is None or r2 is None:
                return None
            return {"at": at, "rays": sorted([r1, r2])}
        return v

    def _resolve_cons(self):
        """Turn every coordinate operand into a name or an id; drop a derived
        constraint whose geometry the figure did not draw."""
        out, seen = [], {}
        for c in self.cons:
            strict = c._pending
            f = {}
            ok = True
            for k, v in c.f.items():
                kind = FIELD_KIND.get((c.type, k))
                if kind is None:                    # value, unit, t
                    f[k] = v
                    continue
                r = self._resolve_one(kind, v, strict)
                if c.type == "perpendicular" and not strict:
                    # v6.8 r2 (G7): a right-angle mark states a fact about
                    # two DIRECTIONS. The ray from an altitude's foot to a
                    # base corner is not a segment of its own -- it lies on
                    # the base, and the base is the operand. A vertex that is
                    # no point of the export leaves `at` out, not the fact.
                    if k == "of" and isinstance(r, list):
                        r = [x if x is not None else self._seg_containing(q)
                             for x, q in zip(r, v)]
                    elif k == "at" and r is None:
                        continue
                if r is None or (isinstance(r, list) and
                                 any(x is None for x in r)):
                    ok = False
                f[k] = r
            if not ok:
                continue
            c.f = f
            c._pending = False
            if c.mark_id is not None and not isinstance(c.mark_id, str):
                c.mark_id = getattr(c.mark_id, "id", None)
            if c.mark_ids:
                c.mark_ids = [m if isinstance(m, str) else
                              getattr(m, "id", None) for m in c.mark_ids]
                c.mark_ids = [m for m in c.mark_ids if m]
            k = c.key()
            if k in seen:                      # the same fact twice
                old = seen[k]
                old.marked = old.marked or c.marked
                old.mark_id = old.mark_id or c.mark_id
                if c.mark_ids or (c.mark_id and old.mark_id != c.mark_id):
                    old.mark_ids = list(old.mark_ids or [])
                    for m in (c.mark_ids or []) + [c.mark_id]:
                        if m and m not in old.mark_ids:
                            old.mark_ids.append(m)
                if old.source == "derived" and c.source != "derived":
                    old.source, old.item = c.source, c.item
                continue
            seen[k] = c
            out.append(c)
        out.sort(key=lambda c: (c.type, repr(sorted(c.f.items()))))
        self.cons = out
        return self

    def _auto_constraints(self):
        """What the DRAWING itself states, read off the objects it registered.

        This is what gives a plane, a number line or any figure built straight
        on figkit its constraints without a builder writing one: a named point
        that lies on a drawn segment is `on_segment` (and `midpoint` when it
        sits at the middle), and three named points on one segment are
        `collinear`. Marks (ticks, parallel arrows, right angles, a dimension
        with a number) state their own constraint where they are drawn, so
        they carry `marked` and the to_prove check can see them."""
        if self._auto_done:
            return self
        self._auto_done = True
        # the marks: every segment carrying the same tick count is equal to
        # the others (that IS what the mark says on paper), and every segment
        # carrying the same chevron count is parallel to them. figkit already
        # refuses a mark the geometry contradicts (E5), so what is exported
        # here is what the drawing claims AND what it measures.
        for kind, ctype in (("ticks", "equal_length"), ("parallel", "parallel")):
            byn = {}
            for it in self.items:
                if it.kind == kind and len(it.pts) >= 2 and \
                        "_real" not in it.meta:
                    byn.setdefault(it.meta.get("n"), []).append(it)
            for n in sorted(byn, key=lambda v: (v is None, v)):
                grp = byn[n]
                if len(grp) < 2:
                    continue
                _c = self.constrain(ctype,
                                    of=[[it.pts[0], it.pts[-1]]
                                        for it in grp],
                                    marked=True, mark_id=grp[0],
                                    strict=False)
                if _c is not None:
                    _c.mark_ids = list(grp)
        segs = [it for it in self.items
                if it.kind == "segment" and len(it.pts) >= 2]
        # The named points, taken from the OBJECTS that carry the ids -- not
        # from the name table. A builder may know a letter for a point it
        # never registered (a constraint about `K` when the file has no
        # `pt-K` is a claim nothing can re-measure), and a letter's label may
        # be anchored a third of a pixel off the dot it names, which is
        # enough to make a derived `t` disagree with the file it is measured
        # against. The object's own coordinate is the one the SVG carries.
        _ids = set(it.id for it in self.items if it.id)
        named = sorted(((it.name, tuple(it.pts[0])) for it in self.items
                        if it.kind in ("point", "marker") and it.name and
                        it.id == "pt-%s" % slug(it.name)),
                       key=lambda t: t[0])
        _at = dict(named)
        for it in segs:
            a, b = it.pts[0], it.pts[-1]
            na, nb = self.name_of(a), self.name_of(b)
            if not (na and nb and na != nb):
                continue
            if ("pt-%s" % slug(na)) not in _ids or \
                    ("pt-%s" % slug(nb)) not in _ids:
                continue
            # the ends as the FILE draws them, for the same reason
            a = _at.get(na, a)
            b = _at.get(nb, b)
            on = []
            for nm, k in named:
                if nm in (na, nb):
                    continue
                t = _param_on(k, a, b, tol=0.4)
                if t is None:
                    continue
                on.append((t, nm))
            on.sort()
            for t, nm in on:
                self.constrain("on_segment", point=nm, of=[na, nb],
                               t=round(t, 4), strict=False)
                if abs(t - 0.5) <= 1e-3:
                    self.constrain("midpoint", point=nm, of=[na, nb],
                                   strict=False)
            if on:
                pts = [na] + [nm for _, nm in on] + [nb]
                self.constrain("collinear", points=pts, strict=False)
        return self

    def constraints(self):
        return [c.as_dict() for c in self.cons]

    # -- what comes out -----------------------------------------------------
    def by_part(self):
        """{part index in Figure.parts: id} for the emission loop."""
        out = {}
        for it in self.items:
            if it.part is not None and it.id:
                out.setdefault(it.part, it.id)
        return out

    def anchors(self, drawn):
        """The id layer: every object whose id no drawn element carries.

        A `<g>` with data attributes, because it must carry a position
        without carrying ink — a phantom `<line stroke="none">` is read as a
        grey line by svgcheck, and a real one would be lost ink."""
        rows = []
        for it in self.items:
            if not it.id or it.id in drawn:
                continue
            pts = it.ends or []
            xy = " ".join("%.2f %.2f" % (p[0], p[1]) for p in pts)
            # v6.6 E r1: an object whose ink is another object's element (a
            # polygon's edge) names that element
            ink = it.meta.get("_ink") if isinstance(it.meta, dict) else None
            rows.append('<g id="%s" data-kind="%s" data-role="%s" '
                        'data-xy="%s"%s/>'
                        % (it.id, it.kind, it.role or "data", xy,
                           ' data-ink="%s"' % " ".join(ink) if ink else ""))
        if not rows:
            return ""
        return '<g class="ids" fill="none" stroke="none">%s</g>' % "".join(rows)

    def as_dict(self):
        out = {"view": dict(self.view or {}), "objects": {}}
        # v6.6 E (X1R2-06): every figure says what it is and its fam, as the
        # spec's sheet.json shows -- null when a raw builder gave none
        out["fam"] = self.fam
        out["kind"] = self.kindname or "figkit.figure"
        buckets = {"point": "points", "segment": "segments",
                   "circle": "circles", "arc": "arcs", "label": "labels",
                   "dimension": "dimensions", "polygon": "polygons",
                   "path": "paths", "line": "lines", "ray": "rays"}
        for it in self.items:
            b = buckets.get(it.kind, "marks")
            out["objects"].setdefault(b, []).append(it.as_dict())
        for b in out["objects"]:
            out["objects"][b].sort(key=lambda d: d["id"])
        out["constraints"] = self.constraints()
        return out


# ---------------------------------------------------------------------------
# reading the finished file back
# ---------------------------------------------------------------------------
_EL = re.compile(r"<(g|line|circle|polygon|path|text|rect)\b([^>]*?)/?>")
_ATTR = re.compile(r"([\w:-]+)\s*=\s*\"([^\"]*)\"")
_NUM = re.compile(r"-?\d+(?:\.\d+)?")


_TAGS = re.compile(r"<(/?)(g|line|circle|polygon|path|text|rect)\b([^>]*?)(/?)>")
_TRANSLATE = re.compile(r"translate\(\s*(-?[\d.]+)(?:[\s,]+(-?[\d.]+))?\s*\)")


def _elements(svg):
    """(tag, attributes, (dx, dy)) for every element, with the offset of
    the `<g transform="translate(...)">` groups it sits in.

    v6.5 X2 r1 (MUST-4): numberline.stack composes its rows as translated
    groups, and a reader that ignored the transform put every id of the
    second row where the first row is. Only translate() is composed -- no
    builder emits another transform around an id."""
    stack = [(0.0, 0.0)]
    for m in _TAGS.finditer(svg):
        close, tag, raw, selfclose = m.groups()
        if close:
            if tag == "g" and len(stack) > 1:
                stack.pop()
            continue
        at = dict(_ATTR.findall(raw))
        off = stack[-1]
        if tag == "g" and not selfclose:
            t = _TRANSLATE.search(at.get("transform", ""))
            if t:
                stack.append((off[0] + float(t.group(1)),
                              off[1] + float(t.group(2) or 0.0)))
            else:
                stack.append(off)
        yield tag, at, off


def _shift(pts, off):
    if off == (0.0, 0.0):
        return pts
    return [(p[0] + off[0], p[1] + off[1]) for p in pts]


def read_ids(svg):
    """{id: [(x, y), ...]} read from the SVG string alone.

    This is the builders' own reader. The checks in selfcheck_v65.py keep a
    SECOND one that imports nothing from the skill, because a reader shared
    with the writer can agree with it about a mistake."""
    out = {}
    for tag, at, off in _elements(svg):
        oid = at.get("id")
        if not oid:
            continue
        pts = []
        if tag == "g":
            v = [float(x) for x in _NUM.findall(at.get("data-xy", ""))]
            pts = list(zip(v[0::2], v[1::2]))
        elif tag == "line":
            pts = [(float(at.get("x1", 0)), float(at.get("y1", 0))),
                   (float(at.get("x2", 0)), float(at.get("y2", 0)))]
        elif tag == "circle":
            pts = [(float(at.get("cx", 0)), float(at.get("cy", 0)))]
        elif tag == "text":
            pts = [(float(at.get("x", 0)), float(at.get("y", 0)))]
        elif tag == "polygon":
            v = [float(x) for x in _NUM.findall(at.get("points", ""))]
            pts = list(zip(v[0::2], v[1::2]))
        elif tag == "path":
            v = [float(x) for x in _NUM.findall(at.get("d", ""))]
            pts = list(zip(v[0::2], v[1::2]))
        out[oid] = _shift(pts, off)
    return out


def _near(p, q, tol=TOL_PX):
    return math.hypot(p[0] - q[0], p[1] - q[1]) <= tol


def _seg_dist(p, a, b):
    """How far p is from the segment ab (not from the infinite line)."""
    vx, vy = b[0] - a[0], b[1] - a[1]
    L2 = vx * vx + vy * vy
    if L2 <= 1e-12:
        return math.hypot(p[0] - a[0], p[1] - a[1])
    t = ((p[0] - a[0]) * vx + (p[1] - a[1]) * vy) / L2
    t = 0.0 if t < 0.0 else (1.0 if t > 1.0 else t)
    return math.hypot(p[0] - a[0] - t * vx, p[1] - a[1] - t * vy)


_IDS_LAYER = re.compile(r'<g class="ids".*?</g>', re.S)
_VIEWBOX = re.compile(r'viewBox="([^"]*)"')


class _Ink(object):
    """Where the finished file actually has ink, read from the file.

    Built from every drawn element EXCEPT the ids layer, which is why an
    anchor can be checked against it: the layer is written from the export's
    own claim, so comparing an anchor with the layer is the export agreeing
    with itself (doctrine 3). Ink is the second witness."""

    def __init__(self, svg):
        body = _IDS_LAYER.sub("", svg)
        self.pts = []
        self.segs = []
        self.discs = []
        self.box = None
        m = _VIEWBOX.search(svg)
        if m:
            v = [float(x) for x in _NUM.findall(m.group(1))]
            if len(v) == 4:
                self.box = (v[0], v[1], v[0] + v[2], v[1] + v[3])
        for tag, at, off in _elements(body):
            if tag == "g":
                continue
            if at.get("stroke") == "none" and at.get("fill", "none") == "none":
                continue
            if tag == "line":
                a = (float(at.get("x1", 0)) + off[0],
                     float(at.get("y1", 0)) + off[1])
                b = (float(at.get("x2", 0)) + off[0],
                     float(at.get("y2", 0)) + off[1])
                self.pts += [a, b]
                self.segs.append((a, b))
            elif tag in ("polygon", "path", "rect"):
                if tag == "rect":
                    x, y = float(at.get("x", 0)), float(at.get("y", 0))
                    w, h = float(at.get("width", 0)), float(at.get("height", 0))
                    v = [(x, y), (x + w, y), (x + w, y + h), (x, y + h)]
                else:
                    n = [float(x) for x in
                         _NUM.findall(at.get("points") or at.get("d", ""))]
                    v = list(zip(n[0::2], n[1::2]))
                v = _shift(v, off)
                self.pts += v
                closed = tag in ("polygon", "rect") or \
                    (tag == "path" and ("Z" in (at.get("d") or "") or
                                        (len(v) > 2 and _near(v[0], v[-1],
                                                              0.01))))
                for k in range(len(v) - (0 if closed else 1)):
                    self.segs.append((v[k], v[(k + 1) % len(v)]))
                # a plotted point drawn as a small square, diamond or
                # triangle IS its centre: the marker's own ink is the
                # outline, and the object it stands for sits inside it
                if closed and 2 < len(v) <= 8:
                    xs = [q[0] for q in v]
                    ys = [q[1] for q in v]
                    if max(xs) - min(xs) <= 12.0 and max(ys) - min(ys) <= 12.0:
                        self.pts.append((sum(xs) / len(v), sum(ys) / len(v)))
            elif tag == "circle":
                c = (float(at.get("cx", 0)) + off[0],
                     float(at.get("cy", 0)) + off[1])
                self.discs.append((c, float(at.get("r", 0))))
            elif tag == "text":
                self.pts.append((float(at.get("x", 0)) + off[0],
                                 float(at.get("y", 0)) + off[1]))

    def inside(self, p, pad=2.0):
        if not self.box:
            return True
        return (self.box[0] - pad <= p[0] <= self.box[2] + pad and
                self.box[1] - pad <= p[1] <= self.box[3] + pad)

    def on(self, p, tol=TOL_PX):
        """Is there ink at p? A point of a stroke, a point ON a stroke (a
        midpoint, a vertex of an edge drawn as part of a polygon), the rim of
        a circle, or inside a dot."""
        for q in self.pts:
            if _near(p, q, tol):
                return True
        for a, b in self.segs:
            if _seg_dist(p, a, b) <= tol:
                return True
        for c, r in self.discs:
            d = math.hypot(p[0] - c[0], p[1] - c[1])
            if abs(d - r) <= tol or (r <= 4.0 and d <= r + tol):
                return True
        return False


def _cyclic_match(claim, pts, tol=TOL_PX):
    """A polygon's vertices, allowing the file to start anywhere and run
    either way round. EVERY vertex is checked -- verify used to ask only
    whether claim[0] was somewhere in the list, so a polygon drawn with
    vertices 2..n in the wrong place passed (X1-03)."""
    n = len(claim)
    if n == 0 or len(pts) not in (n, n + 1):
        return False
    ring = pts[:n]
    for rev in (ring, ring[::-1]):
        for k in range(n):
            if all(_near(claim[i], rev[(i + k) % n], tol) for i in range(n)):
                return True
    return False


def _corroborated(kind, claim, ink):
    """Is there really ink where an anchor-only object says it is?

    An equality tick or a parallel arrow is named after the SEGMENT it marks
    (tick-AB is what a caller highlights) while its ink is the few short
    strokes crossing that segment, at a parameter v6.3's tick solver is free
    to move. So a mark is corroborated by ink somewhere ALONG its segment;
    everything else by ink at every point it claims."""
    if kind in ("ticks", "parallel", "mark") and len(claim) >= 2:
        for a, b in zip(claim, claim[1:]):
            for i in range(21):
                t = i / 20.0
                if ink.on((a[0] + (b[0] - a[0]) * t,
                           a[1] + (b[1] - a[1]) * t)):
                    return True
        return False
    return all(ink.on(c) for c in claim)


def _anchor_ids(svg):
    """The ids that live in the trailing ids layer, not on a drawn element."""
    # every ids layer: a composed figure (numberline.stack) carries one
    # per row
    out = set()
    for m in _IDS_LAYER.finditer(svg):
        out |= set(re.findall(r'<g id="([^"]+)"', m.group(0)))
    return out


_HOW = ("The export IS the build (export.Objects), so both ways out KEEP the "
        "object: draw the geometry where the export says it is, or -- when no "
        "single element can carry it (a polygon edge, a named point with no "
        "ink of its own, a stroke cut into pieces behind a number) -- let the "
        "ids layer anchor it OVER INK THAT IS REALLY THERE. Deleting the "
        "ex.add() is not a fix: it drops the object from the sheet's JSON and "
        "the author's AI can no longer point at it.")


def verify(svg, objects, where="figure"):
    """Refuse a figure whose export disagrees with its own SVG.

    Every exported id must be IN the file and sit where the export says it
    does (within a pixel), with EVERY point of a polygon or a multi-point
    object checked, not just the first. An id carried by the ids layer is
    checked a second time against the drawing's ink, because that layer is
    written from the export's own claim: without it a figure could register
    geometry it never drew and ship it in the JSON (X1-02)."""
    found = read_ids(svg)
    anchored = _anchor_ids(svg)
    ink = _Ink(svg) if anchored else None
    bad = []
    for it in objects.items:
        if not it.id:
            bad.append("an object (%s) got no id" % it.kind)
            continue
        if it.id not in found:
            bad.append("%s %s is in the export but not in the SVG"
                       % (it.kind, it.id))
            continue
        pts = found[it.id]
        claim = it.ends or []
        if not pts:
            bad.append("%s carries no position in the SVG" % it.id)
            continue
        if not claim:
            bad.append("%s is in the SVG but the export gives it no position"
                       % it.id)
            continue
        if it.kind in ("point", "label", "circle", "arc", "mark",
                       "right_angle", "marker"):
            # a marker drawn as a square or a triangle is a PATH whose points
            # are its corners: the point it marks is their centre
            mid = (sum(p[0] for p in pts) / len(pts),
                   sum(p[1] for p in pts) / len(pts))
            if not any(_near(p, claim[0]) for p in pts) \
                    and not _near(mid, claim[0]):
                bad.append("%s is drawn at (%.2f, %.2f) but the export claims "
                           "(%.2f, %.2f)" % (it.id, pts[0][0], pts[0][1],
                                             claim[0][0], claim[0][1]))
        elif it.kind in ("segment", "dimension", "line", "ray"):
            if len(claim) < 2 or len(pts) < 2:
                bad.append("%s is a %s but %s gives only %d position(s) -- "
                           "a segment has two ends"
                           % (it.id, it.kind,
                              "the export" if len(claim) < 2 else "the SVG",
                              min(len(claim), len(pts))))
            else:
                ok = (_near(pts[0], claim[0]) and _near(pts[-1], claim[-1])) or \
                     (_near(pts[0], claim[-1]) and _near(pts[-1], claim[0]))
                if not ok:
                    bad.append("%s runs (%.2f, %.2f)-(%.2f, %.2f) in the SVG "
                               "but (%.2f, %.2f)-(%.2f, %.2f) in the export"
                               % (it.id, pts[0][0], pts[0][1], pts[-1][0],
                                  pts[-1][1], claim[0][0], claim[0][1],
                                  claim[-1][0], claim[-1][1]))
        elif it.kind == "polygon":
            if not _cyclic_match(claim, pts):
                bad.append("%s: the polygon in the SVG is not the %d corners "
                           "the export claims (first drawn (%.2f, %.2f), "
                           "first claimed (%.2f, %.2f))"
                           % (it.id, len(claim), pts[0][0], pts[0][1],
                              claim[0][0], claim[0][1]))
        else:
            # ticks, parallel marks, paths: EVERY claimed point must be on the
            # element, not merely the first one
            for c in claim:
                if not any(_near(p, c) for p in pts) and \
                        not any(_seg_dist(c, a, b) <= TOL_PX
                                for a, b in zip(pts, pts[1:])):
                    bad.append("%s: the export claims (%.2f, %.2f), which is "
                               "not on the element the SVG draws"
                               % (it.id, c[0], c[1]))
                    break
        # the second witness: an id that no drawn element carries
        if it.id in anchored and ink is not None:
            for c in claim:
                if not ink.inside(c):
                    bad.append("%s is anchored at (%.2f, %.2f), outside the "
                               "figure's own viewBox" % (it.id, c[0], c[1]))
                    break
            else:
                if not _corroborated(it.kind, claim, ink):
                    c = claim[0]
                    bad.append("%s is anchored at (%.2f, %.2f) but the figure "
                               "draws no ink there -- geometry was registered "
                               "and never drawn" % (it.id, c[0], c[1]))
    if bad:
        raise AssertionError(
            "%s: the objects export disagrees with the SVG it was built "
            "from -- %s. %s" % (where, "; ".join(bad[:4]), _HOW))
    return True



# ===========================================================================
# v6.5 X2 — THE CONSTRAINTS (DELIVERABLE_SPEC items 3-4, section 8)
# ===========================================================================
# A figure says WHAT IT DREW (the objects above) and WHAT IS TRUE OF IT (the
# constraints below), from the same build. The author's AI reads "M is the
# midpoint of AB" out of the JSON instead of looking at the picture, and the
# sheet can promise that the drawing never MARKS what the student is asked to
# prove.
#
# `source` is the spec's rule 2:
#   given       the question states it
#   to_prove    the student must prove it   -- never marked in the drawing
#   derived     it follows from the build (a rectangle's fourth corner)
#   decorative  a drawing choice (the rotation angle)
# A level that declares nothing still builds: everything a builder registers
# starts as `derived`, and the content layer upgrades what the author declared.

SOURCES = ("given", "to_prove", "derived", "decorative")

# type -> (required fields, optional fields). The operands are point names
# ("A"), segment names ("AB") or object ids ("seg-7f3a21", "cir-O"); every one
# of them must be findable in the finished SVG, which is what makes a
# constraint re-measurable.
CONSTRAINT_TYPES = {
    "collinear":     (("points",), ()),
    "midpoint":      (("point", "of"), ()),
    "on_segment":    (("point", "of"), ("t",)),
    "parallel":      (("of",), ("space",)),
    "perpendicular": (("of",), ("at", "space")),
    "equal_length":  (("of",), ("space",)),
    "equal_angle":   (("of",), ()),
    "length":        (("of", "value"), ("unit",)),
    "angle":         (("at", "rays", "value"), ("unit",)),
    "ratio":         (("of", "value"), ()),
    "tangent":       (("circle", "to"), ("at",)),
    "concentric":    (("of",), ()),
    "hidden_edge":   (("of",), ()),
}

CONSTRAINTS = tuple(sorted(CONSTRAINT_TYPES))

# What each operand IS, so a pair of coordinates registered by a mark can be
# resolved into the right thing: `angle(at=V, rays=[A, B])` is three POINTS,
# `length(of=[P, Q])` is one SEGMENT, and the two look identical until this
# table is consulted.
FIELD_KIND = {
    ("collinear", "points"): "points",
    ("midpoint", "point"): "point", ("midpoint", "of"): "points",
    ("on_segment", "point"): "point", ("on_segment", "of"): "points",
    ("parallel", "of"): "segments",
    ("perpendicular", "of"): "segments", ("perpendicular", "at"): "point",
    ("equal_length", "of"): "segments",
    ("equal_angle", "of"): "angles",
    ("length", "of"): "segment",
    ("angle", "at"): "point", ("angle", "rays"): "points",
    ("ratio", "of"): "segments",
    ("tangent", "circle"): "circle", ("tangent", "to"): "segment",
    ("tangent", "at"): "point",
    ("concentric", "of"): "circles",
    ("hidden_edge", "of"): "segment",
}

# measuring tolerances, in the frame the figure is measured in
TOL_DEG = 1.0            # an angle, and "parallel", "perpendicular"
TOL_REL = 0.02           # a length ratio (2%: a 200px figure, half a pixel)
TOL_ON = 1.2             # how far a point may sit off the segment it is on


# A figure drawn in a PROJECTION (solidkit's cabinet) is an affine picture of
# a solid, not a scale drawing of it: collinearity, a ratio along one line,
# a midpoint and parallelism survive the projection, and a LENGTH, an ANGLE
# and the equality of two lengths in different directions do not (a depth
# edge of 5 prints at 3.54). Such a constraint is a fact about the SOLID that
# the drawing cannot state, so it is not exported from a projected figure --
# an export nothing can re-measure is exactly what spec section 8 forbids.
PROJECTION_UNSAFE = ("length", "angle", "equal_length", "equal_angle",
                     "ratio", "tangent")


class ConstraintError(AssertionError):
    """A constraint a figure cannot honestly export or cannot hold."""


def _cbad(said, fix):
    raise ConstraintError("export: %s -- %s" % (said, fix))


class Con(object):
    """One constraint: what is true, where it came from, whose item it is."""

    __slots__ = ("type", "f", "source", "item", "marked", "mark_id",
                 "_pending", "violated", "_born", "declared", "implied_by",
                 "mark_ids")

    def __init__(self, ctype, fields, source, item, marked, mark_id):
        self.type = ctype
        self.f = fields
        self.source = source
        self.item = item
        self.marked = bool(marked)
        self.mark_id = mark_id
        # v6.7-noam (R3-G7-mark-coverage): EVERY mark that states this fact
        # (a group of equal ticks is one constraint and several marks)
        self.mark_ids = None
        self._pending = True
        # v6.5 X2: a find-the-error figure MARKS something that is not true
        # on purpose (generate.violate). The claim is exported -- the
        # author's AI must know the tick marks lie -- and it is exported as
        # a lie, never as a fact.
        self.violated = False
        # what the BUILD said this constraint was. A packaging run labels
        # constraints `given` / `to_prove` from the content, and a figure
        # outlives one packaging run (the registry keeps it, and two levels
        # may share a drawing), so the build's own answer is kept and
        # restored before each run -- one level's declaration is never
        # inherited by the next.
        self._born = (source, item)
        # v6.5 X2 r1 (MUST-2): a constraint the CONTENT declared and the
        # figure did not export by itself -- added by the packaging run
        # after it was MEASURED true on the finished SVG, and removed again
        # before the next packaging run (reset_declarations)
        self.declared = False
        # MUST-1: the marks that state this fact without being this
        # constraint (the ticks on AM and MB state "M is the midpoint")
        self.implied_by = None

    def key(self):
        """Two registrations of the same fact are one constraint."""
        def norm(v):
            if isinstance(v, dict):
                # an angle operand {"at": V, "rays": [A, B]} (v6.6 E, V2-M1)
                return tuple(sorted((k, norm(x)) for k, x in v.items()))
            if isinstance(v, (list, tuple)):
                return tuple(sorted(norm(x) for x in v)) \
                    if self.type in ("parallel", "equal_length", "equal_angle",
                                     "concentric", "collinear", "perpendicular") \
                    else tuple(norm(x) for x in v)
            if isinstance(v, float):
                return round(v, 6)
            return v
        return (self.type,
                tuple(sorted((k, norm(v)) for k, v in self.f.items())))

    def as_dict(self):
        d = {"type": self.type}
        for k in sorted(self.f):
            d[k] = self.f[k]
        d["source"] = self.source
        d["item"] = self.item
        if self.marked:
            d["marked"] = True
            if self.mark_id:
                d["mark_id"] = self.mark_id
            ids = [m for m in (self.mark_ids or []) if isinstance(m, str)]
            if self.mark_id and self.mark_id not in ids:
                ids.insert(0, self.mark_id)
            if ids:
                d["mark_ids"] = ids
        if self.violated:
            d["violated"] = True
        if self.declared:
            d["declared"] = True
        return d


def _is_ref(v):
    return isinstance(v, str) and v != ""


def _is_pt(v):
    return (isinstance(v, (tuple, list)) and len(v) == 2 and
            all(isinstance(c, (int, float)) for c in v))


def check_fields(ctype, fields):
    """Validate one constraint's shape BEFORE it is registered."""
    if ctype not in CONSTRAINT_TYPES:
        _cbad("%r is not a constraint type this skill can export" % (ctype,),
              "the types are %s. Add it to export.CONSTRAINT_TYPES (its "
              "required fields AND a measuring rule in export._MEASURE) "
              "before a builder registers one -- a type with no measuring "
              "rule ships a claim nothing can check"
              % ", ".join(CONSTRAINTS))
    req, opt = CONSTRAINT_TYPES[ctype]
    miss = [k for k in req if fields.get(k) is None]
    if miss:
        _cbad("a %s constraint is missing %s" % (ctype, ", ".join(miss)),
              "a %s needs %s (optional: %s)"
              % (ctype, ", ".join(req), ", ".join(opt) or "none"))
    extra = [k for k in fields if k not in req and k not in opt]
    if extra:
        _cbad("a %s constraint carries %s, which it does not define"
              % (ctype, ", ".join(sorted(extra))),
              "a %s takes %s (optional: %s)"
              % (ctype, ", ".join(req), ", ".join(opt) or "none"))
    n = {"collinear": ("points", 3), "parallel": ("of", 2),
         "equal_length": ("of", 2), "equal_angle": ("of", 2),
         "concentric": ("of", 2), "perpendicular": ("of", 2),
         "ratio": ("of", 2), "midpoint": ("of", 2), "on_segment": ("of", 2)}
    if ctype in n:
        k, least = n[ctype]
        v = fields.get(k)
        if not isinstance(v, (list, tuple)) or len(v) < least:
            _cbad("a %s constraint's %r is %r" % (ctype, k, v),
                  "%r is a list of at least %d operands" % (k, least))
    if ctype == "angle" and (not isinstance(fields.get("rays"), (list, tuple))
                             or len(fields["rays"]) != 2):
        _cbad("an angle constraint's rays are %r" % (fields.get("rays"),),
              "rays is the two points the angle opens to, e.g. rays=['A','C']")
    if "space" in fields and fields["space"] is not True:
        # v6.8 r2 (G7): `space` says the fact holds IN SPACE (a solid's
        # right angle, its equal edges) and is re-measured on the named
        # points' xyz, not on the projected picture
        _cbad("a %s constraint's space is %r" % (ctype, fields["space"]),
              "space is True (measured on the points' xyz) or absent")
    for k in ("value", "t"):
        if k in fields and fields[k] is not None and (
                isinstance(fields[k], bool) or
                not isinstance(fields[k], (int, float)) or
                not math.isfinite(float(fields[k]))):
            # v6.5 X2 r1 (MINOR-11): a bool IS an int in Python, so
            # value=True used to be taken as 1, and a NaN only failed later,
            # at the re-measure, with a message about the drawing
            _cbad("a %s constraint's %s is %r, not a finite number"
                  % (ctype, k, fields[k]),
                  "give the number the figure was BUILT from -- never a "
                  "string, a True/False or a NaN")
    return True


def _param_on(p, a, b, tol=0.6):
    """t in (0,1) when p lies ON the segment a-b (not at an end), else None."""
    vx, vy = b[0] - a[0], b[1] - a[1]
    L2 = vx * vx + vy * vy
    if L2 <= 1e-9:
        return None
    t = ((p[0] - a[0]) * vx + (p[1] - a[1]) * vy) / L2
    if not (0.02 < t < 0.98):
        return None
    d = math.hypot(p[0] - a[0] - t * vx, p[1] - a[1] - t * vy)
    return t if d <= tol else None


# ---------------------------------------------------------------------------
# re-measuring the constraints ON THE FINISHED SVG (spec section 8)
# ---------------------------------------------------------------------------
_DASH = re.compile(r'stroke-dasharray\s*=\s*"([^"]*)"')


def _dashed_ids(svg):
    """The ids of elements drawn dashed — what `hidden_edge` claims."""
    out = set()
    for m in _EL.finditer(svg):
        raw = m.group(2)
        at = dict(_ATTR.findall(raw))
        if at.get("id") and at.get("stroke-dasharray"):
            out.add(at["id"])
    return out


class Frame(object):
    """Every constraint is measured HERE: positions read out of the finished
    SVG by id, and carried back to the DATA frame when the figure gave one
    (`view.data_to_svg`), so a `length` of 12 is 12 of the question's units
    and not 37 pixels. Without a data frame the figure's own units are the
    SVG's (the render's transform is a translation), so everything except an
    absolute length still measures exactly; a length then measures against
    the ONE scale the figure's other lengths agree on."""

    def __init__(self, svg, view=None):
        self.ids = read_ids(svg)
        self.dashed = _dashed_ids(svg)
        # a circle's RADIUS is an attribute, not a point, and `tangent` and
        # `concentric` are measured against it
        self.radii = {}
        for m in _EL.finditer(svg):
            at = dict(_ATTR.findall(m.group(2)))
            if m.group(1) == "circle" and at.get("id") and at.get("r"):
                self.radii[at["id"]] = float(at["r"])
        self.view = dict(view or {})
        m = self.view.get("data_to_svg")
        self.inv = None
        if m and len(m) == 6:
            a, b, c, d, e, f = m
            det = a * d - c * b
            if abs(det) > 1e-12:
                self.inv = (d / det, -b / det, -c / det, a / det,
                            (c * f - e * d) / det, (e * b - a * f) / det)

    # -- resolving an operand ----------------------------------------------
    def point(self, ref):
        """The data-frame position of a point operand ("A", or an id)."""
        for cand in (ref, "pt-%s" % slug(ref), "mk-%s" % slug(ref)):
            pts = self.ids.get(cand)
            if pts:
                return self._to_data(pts[0]), cand
        return None, None

    def segment(self, ref):
        """The two ends of a segment operand ("AB", "seg-…", or a pair)."""
        if isinstance(ref, (list, tuple)) and len(ref) == 2:
            p, ip = self.point(ref[0])
            q, iq = self.point(ref[1])
            if p and q:
                return (p, q), "%s+%s" % (ip, iq)
            return None, None
        for cand in ("seg-%s" % slug(ref), ref, "dim-%s" % slug(ref)):
            pts = self.ids.get(cand)
            if pts and len(pts) >= 2:
                return ((self._to_data(pts[0]), self._to_data(pts[-1])), cand)
        if len(ref) == 2 and ref.isalnum():      # "AB" -> its two points
            p, _ = self.point(ref[0])
            q, _ = self.point(ref[1])
            if p and q:
                return (p, q), "pt-%s+pt-%s" % (ref[0], ref[1])
        return None, None

    def circle(self, ref):
        for cand in ("cir-%s" % slug(ref), ref):
            pts = self.ids.get(cand)
            if not pts:
                continue
            c = self._to_data(pts[0])
            r = self.radii.get(cand)
            if r is not None:
                q = self._to_data((pts[0][0] + r, pts[0][1]))
                r = math.hypot(q[0] - c[0], q[1] - c[1])
            elif len(pts) > 1:
                r = max(math.hypot(self._to_data(p)[0] - c[0],
                                   self._to_data(p)[1] - c[1])
                        for p in pts[1:])
            return (c, r), cand
        return None, None

    def _to_data(self, p):
        if not self.inv:
            return (float(p[0]), float(p[1]))
        a, b, c, d, e, f = self.inv
        return (a * p[0] + c * p[1] + e, b * p[0] + d * p[1] + f)


def _len(p, q):
    return math.hypot(q[0] - p[0], q[1] - p[1])


def _dir_deg(s):
    return math.degrees(math.atan2(s[1][1] - s[0][1], s[1][0] - s[0][0])) % 180.0


def _angle3(v, a, b):
    d1 = math.degrees(math.atan2(a[1] - v[1], a[0] - v[0]))
    d2 = math.degrees(math.atan2(b[1] - v[1], b[0] - v[0]))
    x = abs(d1 - d2) % 360.0
    return 360.0 - x if x > 180.0 else x


def _angle_ref(fr, ref):
    """An angle operand: "AVB" (the vertex in the middle) or
    {"at": V, "rays": [A, B]}."""
    if isinstance(ref, dict):
        at, rays = ref.get("at"), ref.get("rays") or []
    elif isinstance(ref, str) and len(ref) == 3:
        at, rays = ref[1], [ref[0], ref[2]]
    else:
        return None
    v, _ = fr.point(at)
    a, _ = fr.point(rays[0]) if len(rays) > 0 else (None, None)
    b, _ = fr.point(rays[1]) if len(rays) > 1 else (None, None)
    if not (v and a and b):
        return None
    return _angle3(v, a, b)


def measure(con, fr, scale=1.0):
    """Measure ONE constraint on the finished figure.

    Returns (ok, said) -- `said` is what the measurement found, in the words
    the refusal will use. A constraint whose operands are not in the SVG is
    NOT ok: an export that points at nothing is exactly what spec rule 8's
    'an object whose svg_id is missing' refuses."""
    t, f = con.type, con.f
    if f.get("space"):
        return _measure_space(con, fr)

    def seg(ref):
        s, _ = fr.segment(ref)
        return s

    def pt(ref):
        p, _ = fr.point(ref)
        return p

    if t == "collinear":
        ps = [pt(n) for n in f["points"]]
        if any(p is None for p in ps):
            return False, "%s is not in the SVG" % _missing(f["points"], ps)
        a, b = ps[0], ps[-1]
        worst = max(_seg_dist(p, a, b) for p in ps[1:-1]) if len(ps) > 2 else 0.0
        return worst <= TOL_ON, "farthest point is %.2f off the line" % worst
    if t in ("midpoint", "on_segment"):
        p = pt(f["point"])
        s = seg(f["of"])
        if p is None or s is None:
            return False, "%s is not in the SVG" % (
                f["point"] if p is None else "".join(map(str, f["of"])))
        tt = _param_on(p, s[0], s[1], tol=TOL_ON)
        if tt is None:
            return False, "the point is not on the segment"
        if t == "midpoint":
            return abs(tt - 0.5) <= 0.01, "it sits at t=%.3f of the segment" % tt
        if f.get("t") is not None:
            return abs(tt - float(f["t"])) <= 0.02, \
                "it sits at t=%.3f, the export says t=%.3f" % (tt, float(f["t"]))
        return True, "t=%.3f" % tt
    if t in ("parallel", "perpendicular"):
        ss = [seg(r) for r in f["of"]]
        if any(s is None for s in ss):
            return False, "%s is not in the SVG" % _missing(f["of"], ss)
        ds = [_dir_deg(s) for s in ss]
        if t == "parallel":
            worst = max(min(abs(d - ds[0]), 180.0 - abs(d - ds[0]))
                        for d in ds[1:])
            return worst <= TOL_DEG, "they differ by %.2f degrees" % worst
        d = abs(ds[0] - ds[1])
        d = min(d, 180.0 - d)
        return abs(d - 90.0) <= TOL_DEG, "they meet at %.2f degrees" % d
    if t == "equal_length":
        ss = [seg(r) for r in f["of"]]
        if any(s is None for s in ss):
            return False, "%s is not in the SVG" % _missing(f["of"], ss)
        Ls = [_len(*s) for s in ss]
        if min(Ls) <= 1e-9:
            return False, "one of them has no length"
        return (max(Ls) - min(Ls)) / max(Ls) <= TOL_REL, \
            "they measure %s" % ", ".join("%.2f" % L for L in Ls)
    if t == "equal_angle":
        As = [_angle_ref(fr, r) for r in f["of"]]
        if any(a is None for a in As):
            return False, "an angle's points are not in the SVG"
        return max(As) - min(As) <= TOL_DEG, \
            "they measure %s degrees" % ", ".join("%.2f" % a for a in As)
    if t == "length":
        s = seg(f["of"])
        if s is None:
            return False, "%s is not in the SVG" % (f["of"],)
        got = _len(*s) / (scale or 1.0)
        want = float(f["value"])
        if want <= 0:
            return False, "a length of %g is not a length" % want
        return abs(got - want) / want <= TOL_REL, \
            "it measures %.3f where the export says %g" % (got, want)
    if t == "angle":
        v = pt(f["at"])
        a, b = pt(f["rays"][0]), pt(f["rays"][1])
        if not (v and a and b):
            return False, "the angle's points are not all in the SVG"
        got = _angle3(v, a, b)
        return abs(got - float(f["value"])) <= TOL_DEG, \
            "it measures %.1f° (%.2f degrees) where the export says %g" \
            % (got, got, float(f["value"]))
    if t == "ratio":
        ss = [seg(r) for r in f["of"]]
        if any(s is None for s in ss):
            return False, "%s is not in the SVG" % _missing(f["of"], ss)
        L1, L2 = _len(*ss[0]), _len(*ss[1])
        if L2 <= 1e-9:
            return False, "the second segment has no length"
        got = L1 / L2
        want = float(f["value"])
        return abs(got - want) <= TOL_REL * max(1.0, abs(want)), \
            "the ratio measures %.4f where the export says %g" % (got, want)
    if t == "tangent":
        c, _ = fr.circle(f["circle"])
        s = seg(f["to"])
        if c is None or s is None:
            return False, "the circle or the segment is not in the SVG"
        (cc, r) = c
        if not r:
            return False, "the circle in the SVG carries no radius"
        d = _dist_line(cc, s[0], s[1])
        return abs(d - r) <= max(TOL_ON, TOL_REL * r), \
            "the centre is %.2f from the line and the radius is %.2f" % (d, r)
    if t == "concentric":
        cs = [fr.circle(r)[0] for r in f["of"]]
        if any(c is None for c in cs):
            return False, "a circle is not in the SVG"
        worst = max(_len(cs[0][0], c[0]) for c in cs[1:])
        return worst <= TOL_ON, "the centres are %.2f apart" % worst
    if t == "hidden_edge":
        s, sid = fr.segment(f["of"])
        if s is None:
            return False, "%s is not in the SVG" % (f["of"],)
        return sid in fr.dashed, \
            "%s is drawn %s" % (sid, "dashed" if sid in fr.dashed else "solid")
    return False, "no measuring rule"


def _space_pt(fr, ref):
    """A point operand's xyz -- only for a point that IS in the SVG."""
    x = (getattr(fr, "xyz", None) or {}).get(ref)
    if x is None:
        return None
    p, _ = fr.point(ref)
    return x if p is not None else None


def _space_seg(fr, ref):
    if isinstance(ref, (list, tuple)) and len(ref) == 2:
        a, b = _space_pt(fr, ref[0]), _space_pt(fr, ref[1])
        return (a, b) if a is not None and b is not None else None
    if isinstance(ref, str):
        for k in range(1, len(ref)):
            a, b = _space_pt(fr, ref[:k]), _space_pt(fr, ref[k:])
            if a is not None and b is not None:
                return (a, b)
    return None


def _measure_space(con, fr):
    """v6.8 r2 (G7): a fact about a SOLID, re-measured on the xyz of the
    named points that carry it (each of them a point of the SVG)."""
    t, f = con.type, con.f
    ss = [_space_seg(fr, r) for r in f.get("of") or []]
    if not ss or any(s is None for s in ss):
        return False, "%s has no point with xyz in the SVG" % _missing(
            f.get("of") or [], ss)
    vs = [[s[1][i] - s[0][i] for i in range(3)] for s in ss]
    Ls = [math.sqrt(sum(c * c for c in v)) for v in vs]
    if min(Ls) <= 1e-9:
        return False, "one of them has no length"
    if t == "equal_length":
        return (max(Ls) - min(Ls)) / max(Ls) <= 1e-4, \
            "in space they measure %s" % ", ".join("%.4f" % L for L in Ls)
    cs = [abs(sum(vs[0][i] * v[i] for i in range(3))) / (Ls[0] * L)
          for v, L in zip(vs[1:], Ls[1:])]
    if t == "perpendicular":
        d = math.degrees(math.acos(max(-1.0, min(1.0, cs[0]))))
        if f.get("at") is not None and _space_pt(fr, f["at"]) is None:
            return False, "%s has no xyz in the SVG" % f["at"]
        return abs(d - 90.0) <= 0.5, "in space they meet at %.2f degrees" % d
    if t == "parallel":
        worst = max(math.degrees(math.acos(max(-1.0, min(1.0, c))))
                    for c in cs)
        return worst <= 0.5, "in space they differ by %.2f degrees" % worst
    return False, "no measuring rule"


def _xyz_of(objects):
    """name and id -> xyz of every exported point that carries one."""
    out = {}
    for it in getattr(objects, "items", []):
        x = it.meta.get("xyz") if isinstance(it.meta, dict) else None
        if it.kind == "point" and x:
            if it.id:
                out[it.id] = x
            if it.name:
                out[it.name] = x
    return out


def _missing(refs, got):
    return ", ".join(str(r) for r, g in zip(refs, got) if g is None) or "an operand"


def _dist_line(p, a, b):
    vx, vy = b[0] - a[0], b[1] - a[1]
    L = math.hypot(vx, vy)
    if L <= 1e-9:
        return _len(p, a)
    return abs((p[0] - a[0]) * vy - (p[1] - a[1]) * vx) / L


def length_scale(cons, fr):
    """How many measured units one declared unit is worth.

    With a data frame it is 1 and the `length` values are checked against it
    directly. Without one (a figure drawn straight in pixels) the lengths are
    checked against EACH OTHER: every `length` in the figure must agree on
    one scale, so a side labelled 12 that is drawn the same length as one
    labelled 8 is still caught."""
    if fr.inv:
        return 1.0
    rs = []
    for c in cons:
        if c.type != "length":
            continue
        s, _ = fr.segment(c.f["of"])
        if s is None or not float(c.f["value"]):
            continue
        rs.append(_len(*s) / float(c.f["value"]))
    if not rs:
        return 1.0
    rs.sort()
    return rs[len(rs) // 2]


def _missing_operand(said):
    return "not in the SVG" in said or "no measuring rule" in said


def recheck(svg, objects, where="figure", lenient=False):
    """Spec section 8, on one figure: every exported constraint re-measured
    on the finished SVG, and every operand really in it. Raises on the first
    batch of disagreements, with what was measured."""
    fr = Frame(svg, objects.view)
    fr.xyz = _xyz_of(objects)
    scale = length_scale(objects.cons, fr)
    bad = []
    for c in objects.cons:
        ok, said = measure(c, fr, scale)
        c.violated = False
        if ok:
            continue
        # a find-the-error figure is WRONG ON PURPOSE (generate.violate): its
        # marked claim is kept and flagged, so the JSON says "the drawing
        # claims this and it is false". An operand that is not in the file at
        # all is never a deliberate mistake -- that is a broken export, and
        # it is refused here as everywhere else.
        if lenient and not _missing_operand(said):
            c.violated = True
            continue
        bad.append("%s %s: %s" % (c.type, _operands(c), said))
    if bad:
        raise ConstraintError(
            "%s: the constraints export disagrees with the finished SVG -- "
            "%s. A constraint is not a comment: it is measured on the file "
            "the sheet ships. Routes that render: write the measured value "
            "(the number the drawing makes true%s), or draw the figure from "
            "the given %s the constraint states. Deleting the constraint or "
            "its number is not a fix: the fact would vanish from the "
            "sheet's JSON and the author's AI could no longer use it "
            "(v6.9, doctrine 4)."
            % (where, "; ".join(bad[:4]),
               ", e.g. %s" % _measured_hint(bad) if _measured_hint(bad)
               else "", "angle" if any(b.startswith("angle ") for b in bad)
               else "numbers"))
    return True


def _measured_hint(bad):
    """'37' for the first angle disagreement ('it measures 36.9° ...'),
    else ''."""
    for b in bad:
        m = re.search(r"it measures ([\d.]+)° ", b)
        if b.startswith("angle ") and m:
            return "'%g'" % round(float(m.group(1)))
    return ""


def _operands(c):
    parts = []
    for k in sorted(c.f):
        v = c.f[k]
        parts.append("%s=%s" % (k, ",".join(map(str, v))
                                if isinstance(v, (list, tuple)) else v))
    return "(%s)" % " ".join(parts)


def reset_declarations(objects):
    """Put every constraint back to what its BUILD said it was, and drop the
    ones a previous packaging run added from the content (MUST-2)."""
    objects.cons = [c for c in objects.cons if not c.declared]
    for c in objects.cons:
        c.source, c.item = c._born
        c.implied_by = None
    return objects


def marked_to_prove(objects, svg=None):
    """The spec's hardest rule: the drawing never MARKS what is to be proved.
    Returns the offending constraints.

    v6.5 X2 r1 (MUST-1): not only the constraint of that exact type. Equal
    ticks on AM and MB state "M is the midpoint of AB"; a right-angle mark
    at M on MC and MB states "CM is perpendicular to AB"; a "5" on one side
    and ticks tying it to another state that the other is 5. With the
    finished `svg` every to_prove constraint is also tested against what the
    marks IMPLY (`implied_by_marks`), and the marks that give it away are
    left on `c.implied_by` for the refusal to name."""
    out = []
    for c in objects.cons:
        if c.source != "to_prove":
            continue
        if c.marked:
            out.append(c)
            continue
        if svg is not None:
            by = implied_by_marks(c, objects.cons, svg)
            if by:
                c.implied_by = by
                out.append(c)
    return out


# -- what the marks of a drawing IMPLY (MUST-1) ------------------------------
# Measured in the SVG's own pixels: "the same line" and "the same segment"
# are questions about where the ink is, and a pixel tolerance is the one the
# rest of this module reads the file with.
_IMP_TOL = 1.5


def _same_seg(s, u, tol=_IMP_TOL):
    return s is not None and u is not None and (
        (_near(s[0], u[0], tol) and _near(s[1], u[1], tol)) or
        (_near(s[0], u[1], tol) and _near(s[1], u[0], tol)))


def _same_line(s, u, tol=_IMP_TOL):
    if s is None or u is None or _len(*s) <= 1e-9:
        return False
    return _dist_line(u[0], s[0], s[1]) <= tol and \
        _dist_line(u[1], s[0], s[1]) <= tol


def _on_ray(v, a, p, tol=_IMP_TOL):
    """Is p on the ray from v through a (not behind v)?"""
    if _len(v, a) <= 1e-9 or _len(v, p) <= tol:
        return False
    if _dist_line(p, v, a) > tol:
        return False
    return (a[0] - v[0]) * (p[0] - v[0]) + (a[1] - v[1]) * (p[1] - v[1]) > 0


def implied_by_marks(c, cons, svg):
    """The MARKED constraints of this figure that state `c` between them
    (empty when the marks do not give it away). Only marks count: a fact
    the drawing merely makes true (a point that happens to sit in the
    middle) is not a giveaway, a tick or a printed number is."""
    marks = [m for m in cons if m is not c and m.marked and not m.violated]
    if not marks:
        return []
    fr = Frame(svg, None)                     # pixels

    def S(ref):
        return fr.segment(ref)[0]

    def P(ref):
        return fr.point(ref)[0]

    lens = [(S(m.f["of"]), float(m.f["value"]), m)
            for m in marks if m.type == "length"]
    eqs = [([S(r) for r in m.f["of"]], m)
           for m in marks if m.type == "equal_length"]
    pars = [([S(r) for r in m.f["of"]], m)
            for m in marks if m.type == "parallel"]
    perps = [([S(r) for r in m.f["of"]], m)
             for m in marks if m.type == "perpendicular"]
    angs = []
    for m in marks:
        if m.type == "angle":
            angs.append((P(m.f["at"]), P(m.f["rays"][0]), P(m.f["rays"][1]),
                         float(m.f["value"]), m))

    def value(seg):
        """(the length the marks state for seg, the marks that state it)"""
        for s, v, m in lens:
            if _same_seg(seg, s):
                return v, [m]
        for grp, m in eqs:
            if any(_same_seg(seg, g) for g in grp):
                for s, v, m2 in lens:
                    if any(_same_seg(s, g) for g in grp):
                        return v, [m, m2]
        return None, []

    def equal(x, y):
        for grp, m in eqs:
            if any(_same_seg(x, g) for g in grp) and \
                    any(_same_seg(y, g) for g in grp):
                return [m]
        vx, bx = value(x)
        vy, by = value(y)
        if vx is not None and vy is not None and abs(vx - vy) <= 1e-9:
            return bx + by
        return []

    def perp_at(x, y):
        for grp, m in perps:
            if len(grp) == 2 and ((_same_line(x, grp[0]) and
                                   _same_line(y, grp[1])) or
                                  (_same_line(x, grp[1]) and
                                   _same_line(y, grp[0]))):
                return [m]
        for v, a, b, val, m in angs:
            if v is None or a is None or b is None or abs(val - 90) > 1e-9:
                continue
            la, lb = (v, a), (v, b)
            if (_same_line(x, la) and _same_line(y, lb)) or \
                    (_same_line(x, lb) and _same_line(y, la)):
                return [m]
        return []

    def angle_value(v, a, b):
        for v2, a2, b2, val, m in angs:
            if v2 is None or a2 is None or b2 is None or \
                    not _near(v, v2, _IMP_TOL):
                continue
            if (_on_ray(v, a, a2) and _on_ray(v, b, b2)) or \
                    (_on_ray(v, a, b2) and _on_ray(v, b, a2)):
                return val, [m]
        if v is not None and a is not None and b is not None:
            if perp_at((v, a), (v, b)):
                return 90.0, perp_at((v, a), (v, b))
        return None, []

    t, f = c.type, c.f
    try:
        if t == "equal_length":
            ss = [S(r) for r in f["of"]]
            if any(x is None for x in ss):
                return []
            got = []
            for y in ss[1:]:
                e = equal(ss[0], y)
                if not e:
                    return []
                got += e
            return got
        if t == "midpoint":
            p = P(f["point"])
            a, b = P(f["of"][0]), P(f["of"][1])
            if p is None or a is None or b is None:
                return []
            e = equal((a, p), (p, b))
            if e:
                return e
            vh, bh = value((a, p))
            vw, bw = value((a, b))
            if vh is not None and vw is not None and \
                    abs(2 * vh - vw) <= 1e-9:
                return bh + bw
            return []
        if t == "length":
            v, by = value(S(f["of"]))
            return by if v is not None and \
                abs(v - float(f["value"])) <= 1e-9 else []
        if t == "ratio":
            v1, b1 = value(S(f["of"][0]))
            v2, b2 = value(S(f["of"][1]))
            if v1 is not None and v2 and \
                    abs(v1 / v2 - float(f["value"])) <= 1e-9:
                return b1 + b2
            return []
        if t == "perpendicular":
            ss = [S(r) for r in f["of"]]
            if len(ss) != 2 or any(x is None for x in ss):
                return []
            return perp_at(ss[0], ss[1])
        if t == "parallel":
            ss = [S(r) for r in f["of"]]
            if any(x is None for x in ss):
                return []
            for grp, m in pars:
                if all(any(_same_line(x, g) or _same_seg(x, g) for g in grp)
                       for x in ss):
                    return [m]
            return []
        if t == "angle":
            v, a, b = P(f["at"]), P(f["rays"][0]), P(f["rays"][1])
            if v is None or a is None or b is None:
                return []
            val, by = angle_value(v, a, b)
            return by if val is not None and \
                abs(val - float(f["value"])) <= 1e-9 else []
        if t == "equal_angle":
            # v6.6 E (V2-M1): equal arcs state the equality between them,
            # whichever points the to_prove names along the same rays
            def trip(r):
                if isinstance(r, dict):
                    at, rays = r.get("at"), r.get("rays") or []
                elif isinstance(r, str):
                    tk = _NAME_TOK.findall(r)
                    if len(tk) != 3:
                        return None
                    at, rays = tk[1], [tk[0], tk[2]]
                else:
                    return None
                if len(rays) != 2:
                    return None
                q = (P(at), P(rays[0]), P(rays[1]))
                return None if any(x is None for x in q) else q

            def same_angle(x, y):
                return _near(x[0], y[0], _IMP_TOL) and (
                    (_on_ray(x[0], x[1], y[1]) and _on_ray(x[0], x[2], y[2]))
                    or (_on_ray(x[0], x[1], y[2]) and
                        _on_ray(x[0], x[2], y[1])))
            want = [trip(r) for r in f["of"]]
            if all(w is not None for w in want):
                for m in marks:
                    if m.type != "equal_angle":
                        continue
                    grp = [trip(r) for r in m.f.get("of") or []]
                    grp = [g_ for g_ in grp if g_ is not None]
                    if all(any(same_angle(w, g_) for g_ in grp)
                           for w in want):
                        return [m]
            vals, by = [], []
            for r in f["of"]:
                if isinstance(r, dict):
                    at, rays = r.get("at"), r.get("rays") or []
                elif isinstance(r, str) and len(r) == 3:
                    at, rays = r[1], [r[0], r[2]]
                else:
                    return []
                if len(rays) != 2:
                    return []
                val, b = angle_value(P(at), P(rays[0]), P(rays[1]))
                if val is None:
                    return []
                vals.append(val)
                by += b
            return by if max(vals) - min(vals) <= 1e-9 else []
    except (KeyError, IndexError, TypeError, ZeroDivisionError):
        return []
    return []


# ---------------------------------------------------------------------------
# the figure registry: an SVG string -> the build that made it
# ---------------------------------------------------------------------------
# The packaging step is handed a level dict full of SVG STRINGS (that is what
# the emitter takes), and it must find the objects and constraints that
# belong to each one. Every builder records its finished figure here as it
# renders it, so packaging is a lookup and never a re-run: re-running would
# be a second build, and spec rule 1 says the PDF, the SVG and the JSON come
# from ONE.

_FIGS = {}
_ORDER = []
SKILL_DIR = None
# where a figure's script finds the skill (figures/<id>.py)
import os as _os                                          # noqa: E402
SKILL_HOME = _os.path.dirname(_os.path.abspath(__file__))


def _fig_key(svg):
    return hashlib.sha1(svg.encode("utf-8")).hexdigest()


class FigureRecord(object):
    __slots__ = ("svg", "objects", "code", "kind", "fam", "seq", "key")

    def __init__(self, svg, objects, code, seq):
        self.svg = svg
        self.objects = objects
        self.code = code or {}
        self.kind = objects.kindname or (code or {}).get("call")
        self.fam = objects.fam
        self.seq = seq


def _engine_files():
    """The skill's OWN modules — the frames a call site is never in.

    Not "every file in this folder": a test and a gallery page live here
    too, and a figure they draw has a call site like any other. The engine
    is what ships as the builders."""
    import os
    here = os.path.dirname(os.path.abspath(__file__))
    out = set()
    try:
        for n in os.listdir(here):
            if n.endswith(".py") and not n.startswith(("selfcheck", "gallery")):
                out.add(n)
    except OSError:
        pass
    return out


_ENGINE = None


def _is_user(fn):
    """A frame in the AUTHOR's code: not a skill module, not the stdlib."""
    global _ENGINE
    import os
    if _ENGINE is None:
        _ENGINE = _engine_files()
    return os.path.basename(fn) not in _ENGINE and "/lib/python" not in fn \
        and not fn.startswith("<")


# -- spec rule 6: the code that drew a figure (v6.5 X2 r1, MUST-3) ----------
# The call site alone was not the code: z08_a's figures all went through the
# level's own helper `P(*a, **kw)`, so 41 of 45 figures/<id>.py were that
# helper's body, identical, with no coordinate in them. What rebuilds a
# figure is the call INTO THE SKILL with the values it was given, so that is
# recorded, as source, at the moment of the call:
#   * `entry` wraps a one-call builder (plane, wide, euclid.quad ...): the
#     outermost call from the author's code writes its own call as source;
#   * `replay` is pushed by a builder that is a SEQUENCE of calls on one
#     object (a shapekit figure, a number line, a stack) with the whole
#     sequence as source.
# Packaging then RUNS that source and ships it as runnable only when it
# re-draws the file byte for byte.
_ENTRY = []
_REPLAY = []


def lit(v):
    """A value as Python source that evaluates back to it, or None."""
    from fractions import Fraction
    if v is None or isinstance(v, (bool, int, str)):
        return repr(v)
    if isinstance(v, float):
        return repr(v) if math.isfinite(v) else None
    if isinstance(v, Fraction):
        return "Fraction(%d, %d)" % (v.numerator, v.denominator)
    if isinstance(v, (list, tuple)):
        inner = [lit(x) for x in v]
        if any(x is None for x in inner):
            return None
        if isinstance(v, list):
            return "[%s]" % ", ".join(inner)
        return "(%s)" % (inner[0] + "," if len(inner) == 1
                         else ", ".join(inner))
    if isinstance(v, dict):
        parts = []
        for k in v:
            a, b = lit(k), lit(v[k])
            if a is None or b is None:
                return None
            parts.append("%s: %s" % (a, b))
        return "{%s}" % ", ".join(parts)
    return None


def call_src(prefix, func, args, kwargs, names=None):
    """`prefix.func(arg, ..., k=v)` as source, or None when a value has no
    source. `names` maps id(object) -> the variable it is in the script."""
    names = names or {}
    out = []
    for a in args:
        x = names.get(id(a)) or lit(a)
        if x is None:
            return None
        out.append(x)
    for k, v in kwargs.items():
        x = names.get(id(v)) or lit(v)
        if x is None:
            return None
        out.append("%s=%s" % (k, x))
    return "%s%s(%s)" % (prefix + "." if prefix else "", func, ", ".join(out))


def sheet_state():
    """The sheet-wide settings a figure is drawn under, as source lines
    (figkit_plus.SHEET, numberline's sheet convention)."""
    import sys as _sys
    lines = []
    fp = _sys.modules.get("figkit_plus")
    if fp is not None and isinstance(getattr(fp, "SHEET", None), dict):
        x = lit(dict(fp.SHEET))
        if x:
            lines.append("import figkit_plus")
            lines.append("figkit_plus.SHEET.update(%s)" % x)
    nl = _sys.modules.get("numberline")
    if nl is not None and isinstance(getattr(nl, "_SHEET", None), dict):
        st = dict((k, v) for k, v in nl._SHEET.items() if k != "lines")
        x = lit(st)
        if x:
            lines.append("import numberline")
            lines.append("numberline._SHEET.update(%s)" % x)
    return lines


def entry(fn):
    """Record the author's call into a one-call builder, as source."""
    import functools
    import sys as _sys
    mod = fn.__module__

    @functools.wraps(fn)
    def w(*a, **kw):
        push = not _ENTRY and _is_user(_sys._getframe(1).f_code.co_filename)
        if push:
            src = call_src(mod, fn.__name__, a, kw)
            _ENTRY.append({"module": mod, "func": fn.__name__,
                           "src": ("import %s\nsvg = %s" % (mod, src))
                           if src else None,
                           "sheet": sheet_state()})
        try:
            return fn(*a, **kw)
        finally:
            if push:
                _ENTRY.pop()
    w.__wrapped_entry__ = fn
    return w


class replay(object):
    """`with export.replay(src, sheet):` around a render whose figure is a
    sequence of calls. `src` must define `svg`; None means 'no source'."""

    def __init__(self, src, sheet=None):
        self.row = {"src": src, "sheet": sheet if sheet is not None
                    else sheet_state()}

    def __enter__(self):
        _REPLAY.append(self.row)
        return self

    def __exit__(self, *exc):
        _REPLAY.pop()
        return False


_SEQ = []
_PRIM = (int, float, str, bool, type(None))


def seq(fn, start=False):
    """Log a call that builds a figure as a SEQUENCE on one object (shapekit:
    `g, d = shape(...)`, `midpoint(g, d, ...)`, `finish(g, fam)`). Only the
    author's own calls are logged; an add-on calling another is not."""
    import functools
    import sys as _sys
    mod = fn.__module__

    @functools.wraps(fn)
    def w(*a, **kw):
        if not _is_user(_sys._getframe(1).f_code.co_filename):
            return fn(*a, **kw)
        if start:
            # v6.6 E (z47): a builder that takes an object the author already
            # built (solidkit.box(..., scene=s), solidkit.net(d)) CONTINUES
            # that object's log, so the script rebuilds what it stands on
            prior = None
            for v in list(a) + list(kw.values()):
                prior = _log_of(v)
                if prior is not None:
                    break
            res = fn(*a, **kw)
            obj = res[0] if isinstance(res, tuple) and res else res
            try:
                obj.__dict__["_seq"] = list(prior or []) + [
                    (mod, fn.__name__, a, dict(kw), res)]
            except (AttributeError, TypeError):
                pass
            return res
        obj = a[0] if a else None
        log = getattr(obj, "__dict__", {}).get("_seq") \
            if obj is not None and not isinstance(obj, _PRIM) else None
        if log is None:
            return fn(*a, **kw)
        log.append((mod, fn.__name__, a, dict(kw), None))
        _SEQ.append(obj)
        try:
            return fn(*a, **kw)
        finally:
            _SEQ.pop()
    return w


def _log_of(x):
    """The call log an object carries, or the log of the scene it is drawn
    on (a solidkit Solid logs into its Scene)."""
    if x is None or isinstance(x, _PRIM):
        return None
    d = getattr(x, "__dict__", None)
    if not isinstance(d, dict):
        return None
    if "_seq" in d:
        return d["_seq"]
    sc = d.get("sc")
    if sc is not None and sc is not x:
        return _log_of(sc)
    return None


def seq_method(fn):
    """v6.6 E (z47): log the author's call of a METHOD on an object whose
    builder is logged (`d.edge_label('AB', '5')` on a solidkit Solid), so
    the figure's script re-makes every step, not only the first and the
    last."""
    import functools
    import sys as _sys

    @functools.wraps(fn)
    def w(self, *a, **kw):
        if _is_user(_sys._getframe(1).f_code.co_filename):
            log = _log_of(self)
            if log is not None:
                log.append(("@", fn.__name__, (self,) + tuple(a), dict(kw),
                            None))
        return fn(self, *a, **kw)
    return w


def seq_set(obj, name, value):
    """Log `obj.name = value` made by the author on a logged object."""
    log = _log_of(obj)
    if log is not None:
        log.append(("=", name, (obj, value), {}, None))


def seq_src(obj):
    """The logged sequence as source that ends in `svg = ...`, or None."""
    log = (getattr(obj, "__dict__", {}) or {}).get("_seq") or []
    if not log:
        return None
    names, mods, lines = {}, [], []
    used = set()

    def fresh(base):
        k = 1
        nm = base
        while nm in used:
            k += 1
            nm = "%s%d" % (base, k)
        used.add(nm)
        return nm
    for k, (mod, name, a, kw, res) in enumerate(log):
        if mod == "@":
            tgt = names.get(id(a[0]))
            src = call_src(tgt, name, a[1:], kw, names) if tgt else None
        elif mod == "=":
            tgt = names.get(id(a[0]))
            x = names.get(id(a[1])) or lit(a[1])
            src = "%s.%s = %s" % (tgt, name, x) if tgt and x else None
        else:
            if mod not in mods:
                mods.append(mod)
            src = call_src(mod, name, a, kw, names)
        if src is None:
            return None
        if res is not None:
            outs = list(res) if isinstance(res, tuple) else [res]
            vs = []
            for j, x in enumerate(outs):
                if not isinstance(x, _PRIM) and id(x) in names:
                    nm = names[id(x)]
                else:
                    nm = fresh("g" if j == 0 else ("d" if j == 1
                                                   else "r%d" % j))
                    if not isinstance(x, _PRIM):
                        names[id(x)] = nm
                vs.append(nm)
            lines.append("%s = %s" % (", ".join(vs), src))
        elif k == len(log) - 1:
            lines.append("svg = %s" % src)
        else:
            lines.append(src)
    return "\n".join(["import %s" % m for m in mods] + lines)


def _literal_locals(f, limit=12):
    out = {}
    for k, v in sorted(f.f_locals.items()):
        if k.startswith("__") or len(out) >= limit:
            continue
        x = lit(v)
        if x is not None and len(x) <= 400:
            out[k] = x
    return out


def callsite():
    """Where this figure was asked for, and the code that asks for it again
    (spec rule 6). The file/line/function of the author's innermost frame
    (as before), the chain of the author's frames out to the module, the
    literal values each of them held, and the recorded call (`entry` /
    `replay`) that re-draws the figure."""
    import os
    import sys as _sys
    f = _sys._getframe(1)
    last, first, chain = None, None, []
    while f is not None:
        fn = f.f_code.co_filename
        row = {"file": os.path.abspath(fn), "line": f.f_lineno,
               "func": f.f_code.co_name}
        if _is_user(fn):
            if first is None:
                first = dict(row)
            if len(chain) < 6:
                row["locals"] = _literal_locals(f) \
                    if f.f_code.co_name != "<module>" else {}
                chain.append(row)
        else:
            last = row
        f = f.f_back
    out = dict(first or last or {})
    out["chain"] = chain
    # the author's OWN call wins: an entry is the one call the author made,
    # a logged sequence is the calls the author made on one object, and a
    # replay is what a builder knows about itself
    if _ENTRY:
        out["replay"] = {"src": _ENTRY[0]["src"], "sheet": _ENTRY[0]["sheet"],
                         "call": "%s.%s" % (_ENTRY[0]["module"],
                                            _ENTRY[0]["func"])}
    elif _SEQ:
        out["replay"] = {"src": seq_src(_SEQ[-1]), "sheet": sheet_state(),
                         "call": "sequence"}
    elif _REPLAY:
        out["replay"] = dict(_REPLAY[-1])
    return out


def compose(parts, kindname=None, view=None, fam=None):
    """ONE export for a figure composed of several recorded ones
    (numberline.stack: rows drawn and checked one by one, then translated
    into one SVG). v6.5 X2 r1 (MUST-4): the stack used to ship with no
    record at all -- `objects {}` in the JSON while its SVG carried every
    row's ids, the same `tick-0` once per row.

    `parts` is [(objects, id_prefix, (dx, dy))]. Every id gets its row's
    prefix (the caller rewrites the same prefix into the row's SVG), every
    svg_xy is moved by the row's offset, every constraint operand is
    renamed to the prefixed id it meant, and `view.rows` carries each row's
    own data_to_svg in the composed file's frame."""
    ex = Objects()
    ex.kindname = kindname
    ex.fam = fam
    ex.view = dict(view or {})
    ex._auto_done = True
    rows = []
    for k, (ob, pre, off) in enumerate(parts):
        off = (float(off[0]), float(off[1]))
        idmap, names = {}, {}
        for it in ob.items:
            n = Item(it.kind, it.pts, role=it.role, name=it.name,
                     meta=dict(it.meta, row=k + 1), ref=it.ref)
            n.id = pre + it.id
            n.ends = _shift(list(it.ends or []), off)
            n.svg_xy = n.ends[0] if n.ends else None
            n.dxy = it.dxy
            n.ref_dxy = it.ref_dxy
            n.ref_ends = _shift(list(it.ref_ends), off) if it.ref_ends else None
            if n.meta.get("ink_xy"):
                q = _shift([n.meta["ink_xy"]], off)[0]
                n.meta["ink_xy"] = [_rnd(q[0], 2), _rnd(q[1], 2)]
            if n.meta.get("ink_box"):
                b = n.meta["ink_box"]
                q = _shift([(b[0], b[1]), (b[2], b[3])], off)
                n.meta["ink_box"] = [_rnd(q[0][0], 2), _rnd(q[0][1], 2),
                                     _rnd(q[1][0], 2), _rnd(q[1][1], 2)]
            idmap[it.id] = n.id
            if it.kind in ("point", "marker") and it.name:
                names.setdefault(it.name, n.id)
            ex.items.append(n)

        def pref(v):
            if isinstance(v, (list, tuple)):
                return [pref(x) for x in v]
            if not isinstance(v, str):
                return v
            if v in idmap:
                return idmap[v]
            if v in names:
                return names[v]
            t = _NAME_TOK.findall(v)
            if len(t) == 2 and "".join(t) == v and all(x in names for x in t):
                sid = idmap.get("seg-%s" % pair_name(*t))
                return sid or [names[t[0]], names[t[1]]]
            return v

        for c in ob.cons:
            f = {}
            for key, v in c.f.items():
                f[key] = pref(v) if FIELD_KIND.get((c.type, key)) else v
            n = Con(c.type, f, c.source, c.item, c.marked,
                    (pre + c.mark_id) if isinstance(c.mark_id, str) else None)
            if c.mark_ids:
                n.mark_ids = [pre + m for m in c.mark_ids
                              if isinstance(m, str)]
            n._born = c._born
            n._pending = False
            ex.cons.append(n)
        m = (ob.view or {}).get("data_to_svg")
        row = {"row": k + 1, "id_prefix": pre, "offset": [off[0], off[1]]}
        if m and len(m) == 6:
            row["data_to_svg"] = [m[0], m[1], m[2], m[3],
                                  round(m[4] + off[0], 6),
                                  round(m[5] + off[1], 6)]
        rows.append(row)
        if ob.critique:
            ex.critique = ob.critique
    ex.view["rows"] = rows
    return ex


_NAME_TOK = re.compile(u"[A-Za-z][′″']*[0-9]?")
_STAMP = re.compile(r'<svg\b')
FIG_ATTR = "data-fig"


def fig_key(objects):
    """A figure's key: a hash of WHAT IT DREW, so it is the same key next
    build and a different key for a different figure. Not a counter: a
    counter moves when a sheet gains a question, and the key is written into
    the file."""
    body = repr([(it.id, it.kind, it.role,
                  [(round(c[0], 3), round(c[1], 3)) for c in (it.ends or it.pts)])
                 for it in sorted(objects.items, key=lambda i: i.id or "")])
    body += repr(sorted((c.type, repr(sorted(c.f.items()))) for c in objects.cons))
    # NOT the whole view: `rotate` and `data_to_svg` are about the data
    # behind the picture, and v6.3 requires the same picture at ten
    # rotations to be ONE FILE, character for character (a circle turned is
    # the same circle). A key that moved with the rotation would write ten
    # different files for one drawing.
    body += repr([(k, (objects.view or {}).get(k))
                  for k in ("width_px", "height_px", "unit_px", "viewbox")])
    return hashlib.sha1(body.encode("utf-8")).hexdigest()[:12]


def stamp(svg, objects, code=None):
    """Write the figure's key into the file and record the build behind it.

    The key is IN THE SVG because the string does not reach packaging
    untouched: figkit_plus tags a plane, the emitter rewrites minus signs and
    pins fonts, and a lookup by the string's own hash would miss every one of
    those. An attribute on the root element survives all of them, and it is
    invisible on paper."""
    k = fig_key(objects)
    if FIG_ATTR not in svg[:200]:
        svg = _STAMP.sub('<svg %s="%s"' % (FIG_ATTR, k), svg, count=1)
    record_figure(svg, objects, code, key=k)
    return svg


def record_figure(svg, objects, code=None, key=None):
    """Called by every builder at the end of render()."""
    rec = None
    for k in [key, _fig_key(svg)] if key else [_fig_key(svg)]:
        if k not in _FIGS:
            _ORDER.append(k)
        if rec is None:
            rec = FigureRecord(svg, objects, code, len(_ORDER))
            rec.key = key or k
        _FIGS[k] = rec
    return rec.key


_KEY_RE = re.compile(r'<svg[^>]*\bdata-fig="([0-9a-f]+)"')


def lookup(svg):
    """The build behind a finished SVG string, or None. By the key written
    into the file first, by the string's own hash second."""
    m = _KEY_RE.search(svg or "")
    if m and m.group(1) in _FIGS:
        return _FIGS[m.group(1)]
    return _FIGS.get(_fig_key(svg or ""))


def _forget_name(it):
    """How forget()'s refusal names an object: its id, its letters, or --
    before finish() has handed out ids -- where it is drawn (v6.6 E r1)."""
    if it.id:
        return str(it.id)
    if it.name:
        return str(it.name)
    return "%s at %s" % (it.kind, " - ".join(
        "(%g, %g)" % (round(p[0], 2), round(p[1], 2)) for p in (it.pts or [])))


def _main_guard(test):
    """`__name__ == "__main__"` (either order)."""
    import ast
    if not (isinstance(test, ast.Compare) and len(test.ops) == 1 and
            isinstance(test.ops[0], ast.Eq)):
        return False
    sides = [test.left, test.comparators[0]]
    return (any(isinstance(x, ast.Name) and x.id == "__name__"
                for x in sides) and
            any(isinstance(x, ast.Constant) and x.value == "__main__"
                for x in sides))


def light_import(name):
    """v6.6 E r1 (E-fig-time): a level module WITHOUT running its figures.

    figures/<id>.py re-draws ONE figure with one call into the level's own
    helper (level.tri2d(...)); `import level` built every figure of the
    sheet first (21 s for z47) to make a call that takes 5 ms. This loads
    the module's source and runs only what a call needs -- the imports, the
    defs and classes, and the plain assignments -- skipping every statement
    that calls one of the module's own functions (FIG["1h"] = prism(...)),
    every assertion and every bare expression. A statement that fails is
    skipped too. deliver.py ships a script that uses this only after running
    it and getting the figure back byte for byte; otherwise the script keeps
    the plain `import`."""
    import ast
    import importlib.util
    import types
    spec = importlib.util.find_spec(name)
    if spec is None or not spec.origin or not spec.origin.endswith(".py"):
        return importlib.import_module(name)
    with open(spec.origin, encoding="utf-8") as fh:
        src = fh.read()
    tree = ast.parse(src, spec.origin)
    own = set(n.name for n in tree.body
              if isinstance(n, (ast.FunctionDef, ast.ClassDef)))

    def calls_own(node):
        for x in ast.walk(node):
            if isinstance(x, ast.Call) and isinstance(x.func, ast.Name) and \
                    x.func.id in own:
                return True
        return False
    mod = types.ModuleType(name)
    mod.__file__ = spec.origin
    mod.__dict__["__builtins__"] = __builtins__
    # v6.7 (E-r2-light-import-state): a statement that sets an ATTRIBUTE
    # (figkit.INK = "#cc0000") is kept -- it is configuration the figure is
    # drawn under, and skipping it drew a different SVG in a fresh process
    # while the in-process check (where the build had already set it) said
    # "identical". What is still skipped and could change another module
    # (a bare call, a subscript store) is listed in `_light_skipped`, and
    # deliver.verify_code then checks the script in a FRESH process.
    skipped = []
    for st in tree.body:
        if isinstance(st, (ast.Import, ast.ImportFrom, ast.FunctionDef,
                           ast.ClassDef)):
            pass
        elif isinstance(st, (ast.Assign, ast.AnnAssign, ast.AugAssign)):
            tg = st.targets if isinstance(st, ast.Assign) else [st.target]
            if any(not isinstance(t, (ast.Name, ast.Tuple, ast.Attribute))
                   for t in tg):
                # FIG["1h"] = prism(...) builds a figure (skipped, no
                # effect on the call); any other store is noted
                if st.value is None or not calls_own(st.value):
                    skipped.append(st.lineno)
                continue
            if st.value is None or calls_own(st.value):
                continue
        else:
            # v6.7 r1 (V67F-light-import-ifblock): every skipped statement
            # that can have an effect is noted -- a call, and a compound
            # statement (if/for/while/with/try/match: `if True: figkit.INK
            # = ...` drew red in the build and black in a fresh process).
            # Only a docstring / constant expression, `pass`, an assertion
            # and the `if __name__ == "__main__":` guard (never run on
            # import) are skipped silently.
            if isinstance(st, ast.Expr) and isinstance(st.value,
                                                       ast.Constant):
                pass
            elif isinstance(st, ast.Pass):
                pass
            elif isinstance(st, ast.Assert) and not any(
                    isinstance(x, (ast.Call, ast.NamedExpr, ast.Await,
                                   ast.Yield, ast.YieldFrom, ast.Lambda))
                    for x in ast.walk(st)):
                # v6.7 r2 (V67F2-light-assert-side-effect): only an
                # assertion that calls nothing is silent -- `assert
                # setattr(figkit, "INK", ...) is None` changes the ink
                pass
            elif isinstance(st, ast.If) and _main_guard(st.test):
                pass
            else:
                skipped.append(st.lineno)
            continue
        code = compile(ast.Module(body=[st], type_ignores=[]), spec.origin,
                       "exec")
        try:
            exec(code, mod.__dict__)
        except Exception:                                # noqa: BLE001
            skipped.append(st.lineno)
            continue
    mod._light_skipped = skipped
    return mod


def forget_figures():
    _FIGS.clear()
    del _ORDER[:]


def selftest():
    o = Objects()
    o.name_point((0, 0), "A")
    o.name_point((10, 0), "B")
    o.add("segment", [(0, 0), (10, 0)])
    o.add("segment", [(10, 0), (4, 7)])
    o.finish(lambda p: (p[0] + 5, p[1] + 5),
             {"width_px": 100.0, "height_px": 100.0, "unit_px": 1.0,
              "rotate": 0})
    ids = sorted(i.id for i in o.items)
    assert ids == sorted(["pt-A", "pt-B", "seg-AB", "seg-%s" % _hash6(
        _key("segment", None, [(10.0, 0.0), (4.0, 7.0)], None))]), ids
    # the same data again -> the same ids
    p = Objects()
    p.name_point((0, 0), "A")
    p.name_point((10, 0), "B")
    p.add("segment", [(0, 0), (10, 0)])
    p.add("segment", [(10, 0), (4, 7)])
    p.add("point", [(-3, -3)])          # an unrelated object
    p.finish(lambda q: (q[0] + 5, q[1] + 5),
             {"width_px": 100.0, "height_px": 100.0, "unit_px": 1.0,
              "rotate": 0})
    for a in o.items:
        assert any(b.id == a.id for b in p.items), a.id
    # X1-04: asking for the ids first must not flip seg-AB to seg-BA
    q = Objects()
    q.name_point((10, 0), "C")
    q.name_point((0, 0), "A")
    q.add("segment", [(10, 0), (0, 0)])
    first = [i.id for i in q.resolve_ids().items]
    q.finish(lambda z: z, {"width_px": 10.0, "height_px": 10.0,
                           "unit_px": 1.0, "rotate": 0})
    assert first == [i.id for i in q.items], (first, [i.id for i in q.items])
    assert "seg-AC" in first, first
    # X1-07: a kind nobody has heard of is refused, not given an id
    try:
        q.add("banana", [(1, 1)])
    except AssertionError as e:
        assert "banana" in str(e) and "kind" in str(e)
    else:
        raise AssertionError("export: an unknown kind was accepted")
    # verify: the anchors layer over real ink passes; over nothing it refuses
    ink = ('<line x1="5.00" y1="5.00" x2="15.00" y2="5.00"/>'
           '<line x1="15.00" y1="5.00" x2="9.00" y2="12.00"/>'
           '<line x1="9.00" y1="12.00" x2="5.00" y2="5.00"/>'
           '<circle cx="2.00" cy="2.00" r="2.0"/>')
    svg = ('<svg viewBox="0 0 40 40">%s%s</svg>' % (ink, p.anchors(set())))
    verify(svg, p, "export.selftest")
    g = Objects()
    g.add("point", [(99.0, 99.0)], role="vertex")
    g.finish(lambda z: z, {"width_px": 40.0, "height_px": 40.0,
                           "unit_px": 1.0, "rotate": 0})
    try:
        verify('<svg viewBox="0 0 40 40">%s%s</svg>'
               % (ink, g.anchors(set())), g, "export.selftest")
    except AssertionError as e:
        assert "never drawn" in str(e) or "viewBox" in str(e), str(e)
    else:
        raise AssertionError("export: a phantom object was accepted")
    print("export.py selftest OK (%d objects)" % len(p.items))
if __name__ == "__main__":
    selftest()
