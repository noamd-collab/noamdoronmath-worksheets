# -*- coding: utf-8 -*-
r"""wspec_pdf -- v6.9 gate G79-spec: every engine (wspec) figure is checked
ON THE FINISHED PDF, where the student sees it.

    layout = wspec_pdf.layout_of(document)          # WeasyPrint's layout
    rep = wspec_pdf.check_pdf(pdf, layout, figs, answers, ocr=True)
    rep["status"]            PASS | REVIEW | FAIL   (FAIL stops the build)
    rep["figures"][fid]      {status, page, box_pt, scale, findings}

Per figure, independently of how the page was made:
  L  LOCATE    the figure's box on its page (WeasyPrint's layout gives the
               page and a coarse box); its origin is then FITTED from the
               PDF's own dots: every engine point must be a dot of the page
               within 3 pt of where the placement puts it (1 SVG px =
               0.75 pt), the fitted scale 0.75 in x AND in y (0.5 %).
               A figure that is missing, rescaled, stretched or moved FAILS.
               v6.9 (Codex F2): the fitted origin must be the placed one
               (0.35 pt): a whole-figure shift FAILS (G79_SHIFTED).
  G  GEOMETRY  every painted element of the engine SVG -- line, dot, arc,
               right-angle mark, tick, arrow, outline -- is a drawing of
               the page at its placed coordinates (0.35 pt): nothing
               re-drawn, dropped or bent.
  T  TEXT      every label (point name, angle / length caption) is printed
               as the same characters at its placed anchor (baseline 0.6 pt,
               centre 1.8 pt); a letter / number the PDF lacks FAILS.
  C  COVER     no page text and no foreign drawing inside the figure's box
               touches its ink or a label (a rule across it, a box over a
               label, a paragraph running into it): FAIL; foreign ink in
               the box that touches nothing: REVIEW. The box lies on the
               page (not clipped).
  A  ANSWER    no text in the box prints a value of the level's answer key
               unless it is the figure's own caption of a drawn GIVEN.
  K  CHECKER   the engine's independent checker (wspec.check) runs on the
               figure with the PDF raster of that box (fixed dpi) as the
               final display: geometry against the PUBLIC spec, labels
               attached to their objects, OCR of every label ON THE PDF
               PIXELS (a blank crop FAILS, an unread one is REVIEW), the
               answer guard. v6.9 (Codex F2): with that raster the checker
               also compares the GEOMETRIC INK -- every element of the
               approved SVG present on the PDF pixels of the placed box, no
               foreign ink (a dropped / cut / shifted / rescaled line, an
               added element, a crop by the page: FAIL).
REVIEW is not approval: a level with a REVIEW figure is not approved until
the author accepts that figure (content: accept_review={fid: reason})."""
import math
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import wspec_build as WB               # noqa: E402

PT_PER_PX = 0.75
DPI = 300
TOL_GEOM = 0.35         # pt, an element's drawing on the page
TOL_DOT = 3.0           # pt, a dot found near its placed position
TOL_SCALE = 0.005       # relative, the fitted scale
TOL_BASE = 0.6          # pt, a label's baseline
TOL_CENTRE = 1.8        # pt, a label's horizontal centre (face metrics)
PASS, REVIEW, FAIL, ACCEPTED = "PASS", "REVIEW", "FAIL", "ACCEPTED"
_ORDER = {PASS: 0, ACCEPTED: 0, REVIEW: 1, FAIL: 2}



# (v6.9 fix r2, E1b) a label with a Hebrew unit ('5 ס״מ'). WeasyPrint lays
# SVG text out WITHOUT bidi: the stored characters go left to right. The
# engine therefore stores such a label in VISUAL order under a bidi override
# (wspec-svg/5; wspec.bidi). The T check reads the PDF's GLYPHS BY THEIR x
# POSITION and requires exactly the label's visual order: the first logical
# Hebrew letter is the RIGHTMOST glyph of its run. The fix-r1 test accepted
# the logical text or its Hebrew-run-reversed form, i.e. also the reversed
# print -- that false PASS is gone.
from wspec import bidi as BIDI         # noqa: E402


def _nospace(s):
    return "".join(ch for ch in (s or "") if not ch.isspace())


def label_logical(text, attrs):
    """A label's logical text from its stored SVG content."""
    return BIDI.logical(text) if BIDI.is_override(attrs) else text


def label_visual(text, attrs):
    """The glyphs, LEFT TO RIGHT, that a correct print of the label shows
    (no spaces)."""
    return _nospace(BIDI.visual(label_logical(text, attrs)))


def printed_visual(span):
    """The glyphs of a PDF span LEFT TO RIGHT by their x centre (no
    spaces) -- independent of the order the text layer lists them in."""
    cs = [(0.5 * (b[0] + b[2]), c) for c, b in span["chars"]
          if not c.isspace()]
    return "".join(c for _x, c in sorted(cs, key=lambda t: t[0]))


def family_visual(rec, logical):
    """(v6.16 integrate, HOOKS G6 / I4) the left-to-right glyphs a correct
    print shows of a GRAPH / PIE label: a graph's Hebrew axis title is its
    whole phrase reversed with the parentheses mirrored (wspec.graph.rtl);
    a pie label may hold several Hebrew runs ('כיתה א׳ – 200 תלמידים',
    'סך הכול: 60') -- the pie's UAX #9 subset (render.pie.visual). None for
    any other figure (the house one-run rule, wspec.bidi)."""
    fam = WB.F616.family_of_rec(rec)
    if fam is None or not BIDI.has_rtl(logical or ""):
        return None
    if fam == "function_graph":
        from wspec.graph import rtl as _grtl
        return _grtl.visual(logical)
    from wspec.render import pie as _rpie
    return _rpie.visual(logical)


def label_forms(text, attrs=None):
    """(kept for callers) the ONE left-to-right glyph string a correct print
    of the stored label shows."""
    return set([label_visual(text, attrs or {})])

def _worst(levels):
    w = PASS
    for x in levels:
        if _ORDER.get(x, 0) > _ORDER[w]:
            w = x
    return w


# ----------------------------------------------------------- layout -----
def layout_of(document):
    """{fid: {'page': k, 'box_pt': [x0, y0, x1, y1], 'size_px': [w, h]}}
    of every inline figure whose ids carry a figure prefix (<fid>__), read
    from a rendered WeasyPrint document (weasyprint.HTML(...).render())."""
    out = {}
    for pno, page in enumerate(document.pages):
        stack = [page._page_box]
        while stack:
            b = stack.pop()
            stack.extend(reversed(list(getattr(b, "children", []) or [])))
            tag = str(getattr(b, "element_tag", "") or "")
            if not (tag == "svg" or tag.endswith("}svg")):
                continue
            el = getattr(b, "element", None)
            if el is None:
                continue
            fid = None
            for c in el.iter():
                i = c.get("id") if hasattr(c, "get") else None
                if i and "__" in i:
                    fid = i.split("__", 1)[0]
                    break
            if fid is None:
                continue
            try:
                x, y = b.content_box_x(), b.content_box_y()
            except Exception:                        # noqa: BLE001
                x, y = b.position_x, b.position_y
            w, h = b.width, b.height
            out.setdefault(fid, {
                "page": pno,
                "box_pt": [round(x * PT_PER_PX, 3), round(y * PT_PER_PX, 3),
                           round((x + w) * PT_PER_PX, 3),
                           round((y + h) * PT_PER_PX, 3)],
                "size_px": [round(w, 3), round(h, 3)]})
    return out


# ------------------------------------------------------- the SVG side ----
def _engine_elements(svg):
    """[(id, tag, attrs, text, pts)] of the engine SVG in document order."""
    out = []
    for m in WB._EL.finditer(svg):
        a = dict(WB._ATTR.findall(m.group(2)))
        if not a.get("id"):
            continue
        tag = m.group(1)
        pts = WB._pts_of(tag, a)
        if tag == "path" and re.match(r"^\s*M[^A-Za-z]*Q[^A-Za-z]*$",
                                      a.get("d") or "") and len(pts) == 3:
            # (v6.16 integrate) a graph's parabola is ONE quadratic Bezier
            # (M P0 Q C P1); the PDF paints it as the cubic of the same
            # curve (degree elevation): P0, P0 + 2/3 (C - P0), P1 + 2/3
            # (C - P1), P1 -- matched point for point
            p0, c, p1 = pts
            pts = [p0, (p0[0] + 2.0 / 3 * (c[0] - p0[0]),
                        p0[1] + 2.0 / 3 * (c[1] - p0[1])),
                   (p1[0] + 2.0 / 3 * (c[0] - p1[0]),
                    p1[1] + 2.0 / 3 * (c[1] - p1[1])), p1]
        elif tag == "path" and a.get("data-pie") is not None:
            # (v6.16 integrate) a pie wedge: M centre L rim A ... rim Z --
            # its ON-CURVE points (the centre and the arcs' end points; an
            # arc's radii / flags are no points)
            pts = _pie_path_pts(a.get("d") or "")
        out.append((a["id"], tag, a, (m.group(3) or "").strip(), pts))
    return out


_PIE_CMD = re.compile(r"([MLAZ])([^MLAZ]*)")


def _pie_path_pts(d):
    """on-curve points of a pie wedge path (M / L / A / Z commands)"""
    pts = []
    for cmd, args in _PIE_CMD.findall(d):
        v = [float(x) for x in WB._NUMR.findall(args)]
        if cmd in ("M", "L") and len(v) >= 2:
            pts.append((v[0], v[1]))
        elif cmd == "A":
            for k in range(0, len(v) - 6, 7):
                pts.append((v[k + 5], v[k + 6]))
    return pts


def _bezier_segs(ps, n=12):
    """(v6.16 integrate) the ink of a cubic PDF item as n chords (its
    one chord P0-P3 would cut through what the curve bends around)"""
    (x0, y0), (x1, y1), (x2, y2), (x3, y3) = ps[:4]
    pts = []
    for i in range(n + 1):
        t = i / float(n)
        u = 1 - t
        pts.append((u * u * u * x0 + 3 * u * u * t * x1 + 3 * u * t * t * x2 +
                    t * t * t * x3,
                    u * u * u * y0 + 3 * u * u * t * y1 + 3 * u * t * t * y2 +
                    t * t * t * y3))
    return list(zip(pts, pts[1:]))


# ------------------------------------------------------- the PDF side ----
def _pdf_drawings(page, clip):
    out = []
    for d in page.get_drawings():
        r = d.get("rect")
        # inclusive: a horizontal / vertical stroke has an EMPTY rect, which
        # Rect.intersects never meets
        if r is None or r.x1 < clip[0] or r.x0 > clip[2] or \
                r.y1 < clip[1] or r.y0 > clip[3]:
            continue
        items = []
        for it in d["items"]:
            op = it[0]
            if op == "l":
                items.append(("l", [(it[1].x, it[1].y), (it[2].x, it[2].y)]))
            elif op == "c":
                items.append(("c", [(p.x, p.y) for p in it[1:5]]))
            elif op == "re":
                q = it[1]
                items.append(("re", [(q.x0, q.y0), (q.x1, q.y0),
                                     (q.x1, q.y1), (q.x0, q.y1)]))
            elif op == "qu":
                q = it[1]
                items.append(("qu", [(q.ul.x, q.ul.y), (q.ur.x, q.ur.y),
                                     (q.lr.x, q.lr.y), (q.ll.x, q.ll.y)]))
        if d.get("even_odd") and d.get("type") == "f" and \
                len(items) == 2 and all(k == "re" for k, _p in items):
            # WeasyPrint paints a border as outer MINUS inner (even-odd):
            # the ink is the frame between them, never the inner area
            items = _frame(items[0][1], items[1][1])
        out.append({"rect": (r.x0, r.y0, r.x1, r.y1), "items": items,
                    "type": d.get("type"), "fill": d.get("fill"),
                    "color": d.get("color"), "width": d.get("width"),
                    "used": False})
    return out


def _frame(a, b):
    """The painted strips of two nested rects under even-odd filling."""
    ra = (a[0][0], a[0][1], a[2][0], a[2][1])
    rb = (b[0][0], b[0][1], b[2][0], b[2][1])
    area = lambda r: (r[2] - r[0]) * (r[3] - r[1])       # noqa: E731
    o, i = (ra, rb) if area(ra) >= area(rb) else (rb, ra)
    if not (o[0] <= i[0] + 1e-6 and o[1] <= i[1] + 1e-6 and
            i[2] <= o[2] + 1e-6 and i[3] <= o[3] + 1e-6):
        return [("re", a), ("re", b)]
    strips = [(o[0], o[1], o[2], i[1]), (o[0], i[3], o[2], o[3]),
              (o[0], i[1], i[0], i[3]), (i[2], i[1], o[2], i[3])]
    out = []
    for x0, y0, x1, y1 in strips:
        if x1 - x0 > 1e-6 and y1 - y0 > 1e-6:
            out.append(("re", [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]))
    return out


def _pdf_spans(page, clip):
    import pymupdf
    R = pymupdf.Rect(*clip)
    out = []
    for b in page.get_text("rawdict", clip=R)["blocks"]:
        if b.get("type") != 0:
            continue
        for ln in b["lines"]:
            for s in ln["spans"]:
                chars = [c for c in s["chars"]]
                txt = "".join(c["c"] for c in chars)
                if not txt.strip():
                    continue
                out.append({"text": txt, "bbox": tuple(s["bbox"]),
                            "origin": tuple(s["origin"]), "font": s["font"],
                            "chars": [(c["c"], tuple(c["bbox"]))
                                      for c in chars], "used": False})
    return out


def _char_run(spans, vis, want, anchor, loose=False):
    """(v6.12, family A) a label printed as a space-bounded run of glyphs
    INSIDE a longer span (the PDF's text layer joined neighbouring labels of
    one baseline): the run's glyphs, left to right, are exactly the label's
    visual text, its baseline and anchor where the engine placed it. The
    run becomes a span of its own (a 'run' record, used), the span keeps
    the rest (_split_runs)."""
    for s in spans:
        if s["used"]:
            continue
        cs = s["chars"]
        if abs(s["origin"][1] - want[1]) > TOL_BASE:
            continue
        taken = s.setdefault("taken", set())
        for i in range(len(cs)):
            if i in taken or cs[i][0].isspace():
                continue
            if i > 0 and not cs[i - 1][0].isspace() and not (
                    loose and _glyph_gap(cs[i - 1], cs[i])):
                continue
            j, got, idx = i, "", []
            while j < len(cs) and len(got) < len(vis):
                if not cs[j][0].isspace():
                    got += cs[j][0]
                    idx.append(j)
                j += 1
            if got != vis or any(k in taken for k in idx) or (
                    j < len(cs) and not cs[j][0].isspace() and not (
                        loose and _glyph_gap(cs[j - 1], cs[j]))):
                continue
            bb = (min(cs[k][1][0] for k in idx), min(cs[k][1][1] for k in idx),
                  max(cs[k][1][2] for k in idx), max(cs[k][1][3] for k in idx))
            cx = {"start": bb[0], "end": bb[2]}.get(anchor,
                                                   (bb[0] + bb[2]) / 2.0)
            if abs(cx - want[0]) > TOL_CENTRE:
                continue
            taken |= set(idx)
            run = {"text": "".join(cs[k][0] for k in idx), "bbox": bb,
                   "origin": s["origin"], "font": s.get("font"),
                   "chars": [cs[k] for k in idx], "used": False, "run": True}
            s.setdefault("runs", []).append(run)
            return run
    return None


JOIN_BASE = 2.0     # pt: a fallback face's glyph may sit off the baseline
JOIN_GAP = 2.5      # pt: at most this between two spans of ONE label


def _joined_run(spans, vis, want, anchor):
    """(v6.16 fix r1) a label printed as consecutive UNUSED spans of one
    baseline (a glyph from a fallback face opens a new span: 'y = x' + '²').
    Candidates: unused spans whose baseline is within JOIN_BASE of the
    label's; taken left to right while each starts within JOIN_GAP of the
    previous one's end; the joined glyphs must read exactly `vis` and the
    anchor must be the engine's (TOL_CENTRE). The spans become used."""
    cand = [s for s in spans if not s["used"] and
            abs(s["origin"][1] - want[1]) <= JOIN_BASE]
    cand.sort(key=lambda s: s["bbox"][0])
    for i in range(len(cand)):
        group, got = [cand[i]], printed_visual(cand[i])
        if not vis.startswith(got) or not got:
            continue
        j = i + 1
        while got != vis and j < len(cand):
            nxt = cand[j]
            if nxt["bbox"][0] - group[-1]["bbox"][2] > JOIN_GAP:
                break
            g2 = got + printed_visual(nxt)
            if not vis.startswith(g2):
                break
            group.append(nxt)
            got = g2
            j += 1
        if got != vis or len(group) < 2:
            continue
        bb = (min(g["bbox"][0] for g in group), min(g["bbox"][1] for g in
                                                    group),
              max(g["bbox"][2] for g in group), max(g["bbox"][3] for g in
                                                    group))
        cx = {"start": bb[0], "end": bb[2]}.get(anchor, (bb[0] + bb[2]) / 2.0)
        if abs(cx - want[0]) > TOL_CENTRE or \
                abs(group[0]["origin"][1] - want[1]) > TOL_BASE:
            continue
        for g in group:
            g["used"] = True
            g["label"] = "(joined)"
        return {"text": "".join(g["text"] for g in group), "bbox": bb,
                "origin": group[0]["origin"], "font": group[0].get("font"),
                "chars": [c for g in group for c in g["chars"]],
                "used": False, "joined": [g for g in group]}
    return None


RUN_GAP = 0.8       # pt: two labels' glyphs joined in one span stand apart


def _glyph_gap(c0, c1):
    """(v6.12 fix_r1, CS13) two neighbouring glyphs of one span belong to
    two labels: a crowded axis (-20..20 every 1) prints its numbers so close
    that the PDF's text layer joins them with NO space ('-20-19-18'); the
    boundary is then the horizontal gap between the glyph boxes."""
    if c0[1] is None or c1[1] is None:
        return True
    return c1[1][0] - c0[1][2] >= RUN_GAP


def _split_runs(spans):
    """spans with their label runs taken out: each run a used span, the
    rest of its span split into the unused glyph runs between them."""
    out = []
    for s in spans:
        if not s.get("taken"):
            out.append(s)
            continue
        out += s.get("runs") or []
        cur = []
        for k, c in enumerate(s["chars"] + [(" ", None)]):
            if k in s["taken"] or c[1] is None:
                if [x for x in cur if not x[0].isspace()]:
                    bb = (min(x[1][0] for x in cur), min(x[1][1] for x in cur),
                          max(x[1][2] for x in cur), max(x[1][3] for x in cur))
                    out.append({"text": "".join(x[0] for x in cur),
                                "bbox": bb, "origin": s["origin"],
                                "font": s.get("font"), "chars": cur,
                                "used": False})
                cur = []
            else:
                cur.append(c)
    return out


def _dot_centre(d):
    x0, y0, x1, y1 = d["rect"]
    return ((x0 + x1) / 2.0, (y0 + y1) / 2.0), max(x1 - x0, y1 - y0)


def _is_dot(d):
    (_c, size) = _dot_centre(d)
    return d["type"] == "f" and d["items"] and \
        all(k == "c" for k, _p in d["items"]) and size <= 6.0


def _near(p, q, tol):
    return math.hypot(p[0] - q[0], p[1] - q[1]) <= tol


def _fit_scale(pairs):
    """least squares X = s x + t per axis over (px, pt) pairs."""
    out = []
    for k in (0, 1):
        xs = [p[k] for p, _q in pairs]
        ys = [q[k] for _p, q in pairs]
        n = float(len(xs))
        mx, my = sum(xs) / n, sum(ys) / n
        vx = sum((x - mx) ** 2 for x in xs)
        if vx < 1e-6:
            out.append((None, my - PT_PER_PX * mx))
            continue
        s = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / vx
        out.append((s, my - s * mx))
    return out


def _poly_match(pts, d, tol):
    """every point of the engine element lies on the drawing's own path
    points (within tol), in order or reversed."""
    got = []
    for k, ps in d["items"]:
        for p in ps:
            if not got or not _near(got[-1], p, 1e-3):
                got.append(p)
    if len(got) < len(pts):
        return False
    return all(any(_near(p, q, tol) for q in got) for p in pts)


def _seg_hits_box(a, b, box):
    x0, y0, x1, y1 = box
    dx, dy = b[0] - a[0], b[1] - a[1]
    t0, t1 = 0.0, 1.0
    for pk, qk in ((-dx, a[0] - x0), (dx, x1 - a[0]), (-dy, a[1] - y0),
                   (dy, y1 - a[1])):
        if abs(pk) < 1e-12:
            if qk < 0:
                return False
        else:
            t = qk / pk
            if pk < 0:
                if t > t1:
                    return False
                t0 = max(t0, t)
            else:
                if t < t0:
                    return False
                t1 = min(t1, t)
    return t0 <= t1


def _box_overlap(a, b, pad=0.0):
    return not (a[2] + pad <= b[0] or b[2] + pad <= a[0] or
                a[3] + pad <= b[1] or b[3] + pad <= a[1])


# ------------------------------------------------------------- the gate --
def check_figure_pdf(doc, lay, rec, answers=(), ocr=True, dpi=DPI,
                     png_out=None, ocr_dir=None):
    """G79 on ONE engine figure of the PDF. Returns {status, findings,
    page, box_pt, scale, checker}."""
    fid = rec["fid"]
    F = []

    def add(level, code, detail):
        F.append({"level": level, "code": code, "detail": detail})
    res = {"figure": fid, "findings": F}
    if lay is None:
        add(FAIL, "G79_NOT_LOCATED", "the PDF layout has no box for %s "
            "(not printed, or printed without its ids)" % fid)
        res["status"] = FAIL
        return res
    page = doc[lay["page"]]
    # (v6.10 fix r1, VER-2) two numberings, both named: `page` is 1-based
    # (the page number a PDF viewer shows), `page_index` is 0-based (as
    # layout_of and pymupdf's doc[i] count) -- a crop reads page_index
    res["page"] = lay["page"] + 1
    res["page_index"] = lay["page"]
    W, H = rec["placements"]["canvas_px"]
    sw, sh = lay["size_px"]
    if abs(sw - W) > 0.5 or abs(sh - H) > 0.5:
        rx, ry = sw / float(W), sh / float(H)
        add(FAIL, "G79_RESCALED", "the page prints %s at %.1f x %.1f px; "
            "the engine placed it at %.1f x %.1f px -- %s (scale only "
            "through the placement: 1 px = 0.75 pt)" % (
                fid, sw, sh, W, H,
                "stretched x%.3f / y%.3f: the geometry breaks" % (rx, ry)
                if abs(rx - ry) > TOL_SCALE else
                "uniformly resized x%.3f" % rx))
    bx = lay["box_pt"]
    win = (bx[0] - 20, bx[1] - 20, bx[2] + 20, bx[3] + 20)
    draws = _pdf_drawings(page, win)
    spans = _pdf_spans(page, win)
    els = _engine_elements(rec["svg"])
    # L: fit the origin (and the scale) from the dots
    o_e = (bx[0], bx[1])
    dots = [d for d in draws if _is_dot(d)]
    pairs, missing = [], []
    for eid, tag, a, _t, pts in els:
        if tag != "circle" or a.get("data-pie") is not None:
            # (v6.16 integrate) a pie's outline / build circle is a drawn
            # circle, not a point's dot (matched below as geometry)
            continue
        want = (o_e[0] + PT_PER_PX * pts[0][0], o_e[1] + PT_PER_PX * pts[0][1])
        best = None
        for d in dots:
            c, _s = _dot_centre(d)
            dd = math.hypot(c[0] - want[0], c[1] - want[1])
            if dd <= TOL_DOT and (best is None or dd < best[0]):
                best = (dd, d, c)
        if best is None:
            missing.append(eid)
        else:
            pairs.append((pts[0], best[2]))
    if missing:
        add(FAIL, "G79_POINT_MOVED", "dot(s) %s of %s are not on the page "
            "where the placement puts them (%.0f pt)" % (
                ", ".join(missing[:6]), fid, TOL_DOT))
    if len(pairs) >= 2:
        (sx, tx), (sy, ty) = _fit_scale(pairs)
        sx = PT_PER_PX if sx is None else sx
        sy = PT_PER_PX if sy is None else sy
        res["scale"] = [round(sx, 5), round(sy, 5)]
        if abs(sx / PT_PER_PX - 1) > TOL_SCALE or \
                abs(sy / PT_PER_PX - 1) > TOL_SCALE:
            add(FAIL, "G79_RESCALED", "the dots of %s fit a scale of "
                "%.4f x %.4f pt/px; the placement is 0.75 (%s)" % (
                    fid, sx, sy, "stretched: the geometry breaks"
                    if abs(sx - sy) > TOL_SCALE * PT_PER_PX else
                    "uniformly resized"))
        n = float(len(pairs))
        ox = sum(q[0] - PT_PER_PX * p[0] for p, q in pairs) / n
        oy = sum(q[1] - PT_PER_PX * p[1] for p, q in pairs) / n
    else:
        ox, oy = o_e
    res["origin_pt"] = [round(ox, 3), round(oy, 3)]
    # v6.9 (Codex F2): the drawing must sit WHERE the page placed the
    # figure -- a whole-figure shift inside its box (a translate the dots'
    # 3 pt search tolerates) is a geometry change of the page
    sx_, sy_ = ox - o_e[0], oy - o_e[1]
    if len(pairs) >= 2 and math.hypot(sx_, sy_) > TOL_GEOM:
        add(FAIL, "G79_SHIFTED", "the drawing of %s is %.2f, %.2f pt away "
            "from where the page placed the figure (%.2f pt allowed)" % (
                fid, sx_, sy_, TOL_GEOM))
    box = (ox, oy, ox + PT_PER_PX * W, oy + PT_PER_PX * H)
    res["box_pt"] = [round(v, 2) for v in box]

    def P(p):
        return (ox + PT_PER_PX * p[0], oy + PT_PER_PX * p[1])
    # the box on the page
    pr = page.rect
    if box[0] < pr.x0 - 0.5 or box[1] < pr.y0 - 0.5 or \
            box[2] > pr.x1 + 0.5 or box[3] > pr.y1 + 0.5:
        add(FAIL, "G79_CLIPPED", "%s reaches past the page (%s)"
            % (fid, [round(v, 1) for v in box]))
    # G: every painted element is a drawing of the page
    ink_segs, label_boxes = [], {}
    for eid, tag, a, text, pts in els:
        if tag == "text":
            continue
        want = [P(p) for p in pts]
        hit = None
        for d in draws:
            if d["used"]:
                continue
            if tag == "line":
                ls = [ps for k, ps in d["items"] if k == "l"]
                if len(ls) == 1 and (
                        (_near(ls[0][0], want[0], TOL_GEOM) and
                         _near(ls[0][1], want[1], TOL_GEOM)) or
                        (_near(ls[0][0], want[1], TOL_GEOM) and
                         _near(ls[0][1], want[0], TOL_GEOM))):
                    hit = d
            elif tag == "circle" and a.get("data-pie") is not None:
                # (v6.16 integrate) a pie's outline / build circle: a drawn
                # circle of its radius about its centre (its Bezier
                # quarters' end points on the rim, its box the circle's)
                r = float(a.get("r", 0)) * PT_PER_PX
                c = want[0]
                ends = [q for k, ps in d["items"] if k == "c"
                        for q in (ps[0], ps[3])]
                rb = d["rect"]
                if ends and len(ends) == 2 * len(d["items"]) and all(
                        abs(math.hypot(q[0] - c[0], q[1] - c[1]) - r) <=
                        TOL_GEOM for q in ends) and all(
                        abs(u - v) <= TOL_GEOM + 1.0 for u, v in zip(
                            rb, (c[0] - r, c[1] - r, c[0] + r, c[1] + r))):
                    hit = d
            elif tag == "circle":
                if _is_dot(d):
                    c, size = _dot_centre(d)
                    r = float(a.get("r", 0)) * PT_PER_PX
                    if _near(c, want[0], TOL_GEOM) and \
                            abs(size - 2 * r) <= 2 * TOL_GEOM:
                        hit = d
            else:
                if _poly_match(want, d, TOL_GEOM):
                    hit = d
            if hit is not None:
                break
        if hit is None:
            add(FAIL, "G79_GEOMETRY", "%s: element %s (%s %s) is not drawn "
                "where the engine placed it" % (
                    fid, eid, tag, a.get("data-seg") or a.get("data-pt") or
                    a.get("data-mark") or a.get("data-line") or
                    a.get("data-poly") or ""))
            continue
        hit["used"] = True
        for k, ps in hit["items"]:
            if k in ("l", "re", "qu"):
                seq = ps + ([ps[0]] if k in ("re", "qu") else [])
                ink_segs += list(zip(seq, seq[1:]))
            elif k == "c":
                # (v6.16 integrate) a graph / pie figure's curves are read
                # along the curve; the house figures keep their v6.15 chord
                ink_segs += _bezier_segs(ps) if WB.F616.family_of_rec(rec) \
                    else [(ps[0], ps[3])]
    # T: every label printed as itself at its anchor. (fix r2, E1b) the
    # label's LOGICAL text is the object map's; the glyphs the PDF shows,
    # left to right, must be exactly its visual order
    om_text = {}
    for it in (rec.get("object_map") or {}).get("display_items") or []:
        if it.get("text") is not None:
            for e_ in it.get("elements") or []:
                om_text[e_] = it["text"]
    for eid, tag, a, text, pts in els:
        if tag != "text":
            continue
        want = P(pts[0])
        best = None
        logical = om_text.get(eid, label_logical(text, a))
        # (v6.16 integrate) a graph / pie label: its family's visual order,
        # and the SVG stores exactly that order (checked here, as the
        # house label's logical text is below)
        fv = family_visual(rec, logical)
        if fv is None and label_logical(text, a) != logical:
            add(FAIL, "G79_LABEL_TEXT", "%s: label %s stores %r, which reads "
                "%r -- the object map says %r" % (
                    fid, eid, text, label_logical(text, a), logical))
        vis = _nospace(BIDI.visual(logical))
        if fv is not None:
            vis = _nospace(fv)
            if _nospace(text) != vis:
                add(FAIL, "G79_LABEL_TEXT", "%s: label %s stores %r, not "
                    "the visual order %r of %r" % (fid, eid, text, fv,
                                                   logical))
        reversed_at = None
        for s in spans:
            if s["used"]:
                continue
            got = printed_visual(s)
            if got != vis:
                if BIDI.has_rtl(text) and sorted(got) == sorted(vis) and \
                        abs(s["origin"][1] - want[1]) <= TOL_BASE:
                    reversed_at = got
                continue
            cx = (s["bbox"][0] + s["bbox"][2]) / 2.0
            if a.get("text-anchor") == "start":
                cx = s["bbox"][0]
            elif a.get("text-anchor") == "end":
                cx = s["bbox"][2]
            if abs(s["origin"][1] - want[1]) <= TOL_BASE and \
                    abs(cx - want[0]) <= TOL_CENTRE:
                best = s
                break
        if best is None and reversed_at is not None:
            add(FAIL, "G79_LABEL_BIDI", "%s: label %s %r (for %s) prints its "
                "Hebrew letters in the wrong order: left to right the PDF "
                "shows %r, a correct print shows %r (the first Hebrew letter "
                "must be the rightmost of its run; WeasyPrint does not run "
                "bidi in SVG -- store the label in visual order under "
                "direction=ltr unicode-bidi=bidi-override)" % (
                    fid, eid, logical, a.get("data-for"), reversed_at, vis))
            continue
        if best is None:
            # (v6.12, family A) the PDF's text layer may join neighbouring
            # labels of one line into ONE span ('−4 −3 −2' on a close axis):
            # the label is then a space-bounded run of that span's glyphs
            best = _char_run(spans, vis, want, a.get("text-anchor"))
        if best is None:
            # (v6.12 fix_r1, CS13) ... or joined with no space at all: the
            # run is bounded by the gap between the two labels' glyphs, and
            # still must print exactly the label at exactly its place
            best = _char_run(spans, vis, want, a.get("text-anchor"),
                             loose=True)
        if best is None:
            # (v6.16 fix r1) ... or in TWO+ spans of one baseline: a glyph
            # the text face lacks ('²' of an equation label 'y = x²') is
            # printed from another face, and the text layer starts a new
            # span there. The spans are joined only when every one of them
            # is unused, on the label's baseline, and glyph-adjacent; the
            # joined glyphs must be exactly the label at exactly its place
            best = _joined_run(spans, vis, want, a.get("text-anchor"))
        if best is None:
            add(FAIL, "G79_LABEL_MISSING", "%s: label %s %r (for %s) is not "
                "printed at its place in the PDF" % (
                    fid, eid, logical, a.get("data-for")))
            continue
        best["used"] = True
        best["label"] = logical
        best["eid"] = eid
        label_boxes[eid] = best["bbox"]
    spans = _split_runs(spans)
    # C: nothing foreign touches the figure
    for s in spans:
        if s["used"]:
            continue
        inside, touch = None, None
        for ch, cb in s["chars"]:
            if ch.isspace() or not _box_overlap(cb, box):
                continue
            inside = inside or (ch, cb)
            core = (cb[0] + 0.2 * (cb[2] - cb[0]), cb[1] + 0.25 *
                    (cb[3] - cb[1]), cb[2] - 0.2 * (cb[2] - cb[0]),
                    cb[3] - 0.15 * (cb[3] - cb[1]))
            if any(_seg_hits_box(p, q, core) for p, q in ink_segs) or \
                    any(_box_overlap(core, lb) for lb in label_boxes.values()):
                touch = (ch, cb)
                break
        if inside is None:
            continue
        ch, cb = touch or inside
        add(FAIL if touch else REVIEW, "G79_COVERED_BY_TEXT",
            "%s: page text %r (%r at %.1f, %.1f) %s the figure" % (
                fid, s["text"][:24], ch, cb[0], cb[1],
                "runs into" if touch else "stands inside the box of"))
    for d in draws:
        if d["used"]:
            continue
        filled = d["type"] in ("f", "fs") and d.get("fill") is not None
        stroked = d["type"] in ("s", "fs")
        white = filled and min(d["fill"]) > 0.9
        found = None
        # item by item: one drawing may be many (a dashed rule is a row of
        # small filled rects spanning the page); only what lies IN the box
        for k, ps in d["items"]:
            ib = (min(p[0] for p in ps), min(p[1] for p in ps),
                  max(p[0] for p in ps), max(p[1] for p in ps))
            if not _box_overlap(ib, box, pad=-0.5):
                continue
            seq = ps + ([ps[0]] if k in ("re", "qu") else [])
            segs = list(zip(seq, seq[1:]))
            touch = False
            if filled and k in ("re", "qu", "c"):
                # a patch: over a label, or over the figure's ink
                touch = any(_box_overlap(ib, lb, pad=0.3)
                            for lb in label_boxes.values()) or \
                    any(_seg_hits_box(p, q, ib) for p, q in ink_segs)
            if not touch and (stroked or k == "l"):
                for p, q in segs:
                    if any(_seg_hits_box(p, q, lb)
                           for lb in label_boxes.values()) or \
                            any(_cross(p, q, a, b) for a, b in ink_segs):
                        touch = True
                        break
            found = (touch or (found or (False, None))[0], ib)
            if touch:
                break
        if found is None:
            continue
        touch, ib = found
        add(FAIL if touch else REVIEW, "G79_COVERED_BY_INK",
            "%s: a foreign %s drawing at %s %s the figure" % (
                fid, "white patch" if white else "filled" if filled
                else "stroked", [round(v, 1) for v in ib],
                "covers" if touch else "stands inside the box of"))
    # A: no answer in the box
    vals = set()
    for v in answers or ():
        vals |= _numbers(str(v))
    if vals:
        for s in spans:
            if not _box_overlap(s["bbox"], box):
                continue
            hit = _numbers(s["text"]) & vals
            if hit and not s["used"]:
                add(FAIL, "G79_ANSWER_VISIBLE", "%s: %r printed in the "
                    "figure shows the answer %s" % (fid, s["text"],
                                                    sorted(hit)))
            elif hit and s["used"]:
                if not _given_caption(rec, s.get("label") or s["text"],
                                      s.get("eid")):
                    add(FAIL, "G79_ANSWER_VISIBLE", "%s: the figure's own "
                        "label %r shows the answer %s" % (
                            fid, s["text"], sorted(hit)))
    # K: the engine's independent checker on the PDF pixels OF THE PLACED
    # BOX (the page's placement, not the fitted one: a shift shows as ink
    # that is not where the approved figure has it -- Codex F2)
    pbox = (o_e[0], o_e[1], o_e[0] + PT_PER_PX * W, o_e[1] + PT_PER_PX * H)
    res["checker"] = _checker(page, pbox, rec, answers, ocr, dpi, png_out,
                              ocr_dir, add)
    res["status"] = _worst(f["level"] for f in F)
    return res


def _cross(p, q, a, b):
    """proper crossing of two segments (touching ends excluded)."""
    def o(u, v, w):
        return (v[0] - u[0]) * (w[1] - u[1]) - (v[1] - u[1]) * (w[0] - u[0])
    d1, d2 = o(a, b, p), o(a, b, q)
    d3, d4 = o(p, q, a), o(p, q, b)
    return (d1 * d2 < -1e-6) and (d3 * d4 < -1e-6)


_NUM = re.compile(u"\\d+(?:[.,]\\d+)?")


def _numbers(s):
    out = set()
    for x in _NUM.findall(str(s or "").replace(u"−", "-")):
        try:
            out.add("%g" % float(x.replace(",", ".")))
        except ValueError:
            pass
    return out


# (v6.16 integrate) the labels a graph / pie figure prints of its own public
# data: the frame (numbers, letters, titles), public mark / curve labels (the
# graph engine refuses a label that states a find: GRAPH_TARGET_DRAWN, and
# its checker's TARGET_NOT_DRAWN reads it independently), a pie's sector
# names, drawn given values, caption, total and legend (the pie refuses a
# printed target: RENDER_PRINTS_HIDDEN / TARGET_VALUE_NOT_SHOWN)
_FAMILY_GIVEN_ROLES = {
    "wspec-graph-svg/1": ("axis_number", "origin_zero", "axis_name",
                          "axis_unit", "curve_label", "mark_label",
                          "optional_label"),
    "wspec-pie-svg/1": ("sector_name_label", "sector_value_label",
                        "caption", "total_label", "legend_text")}


def _given_caption(rec, text, eid=None):
    """the label is the engine's caption of a drawn GIVEN fact. (v6.12,
    family B) on a number line, also a number the FRAME prints (the public
    frame: a tick number) and a value / jump / bracket caption of a drawn
    given -- matched by the element (a stacked fraction prints in runs)."""
    fam_roles = _FAMILY_GIVEN_ROLES.get((rec["object_map"] or {}).get(
        "dialect"))
    if eid is not None and fam_roles is not None:
        for it in rec["object_map"].get("display_items") or []:
            if eid in (it.get("elements") or []):
                return it.get("role") in fam_roles
        return False
    if eid is not None and (rec["object_map"] or {}).get("dialect") == \
            "wspec-coord-svg/1":
        # (v6.12, family A) the frame's own numbers / axis letters, and a
        # caption of a drawn given (coordinates, a length)
        for it in rec["object_map"].get("display_items") or []:
            if eid not in (it.get("elements") or []):
                continue
            if it.get("role") in ("axis_number", "origin_number",
                                  "axis_name"):
                return True
            if it.get("role") in ("coord_caption", "segment_caption"):
                f = rec["level"].ix.facts.get((it.get("source") or {}).get(
                    "fact")) or {}
                return f.get("role") in ("given", "context")
            return False
    if eid is not None and (rec["object_map"] or {}).get("family") == \
            "number_line":
        for it in rec["object_map"].get("display_items") or []:
            if eid not in (it.get("elements") or []):
                continue
            if it.get("role") == "tick_number":
                return True
            if it.get("role") in ("value_caption", "jump_caption",
                                  "span_caption"):
                f = rec["level"].ix.facts.get((it.get("source") or {}).get(
                    "fact")) or {}
                return f.get("role") in ("given", "context")
            return False
    for it in rec["object_map"].get("display_items") or []:
        if it.get("role") in ("angle_caption", "segment_caption") and \
                it.get("text") == text.strip():
            f = rec["level"].ix.facts.get((it.get("source") or {}).get(
                "fact")) or {}
            if f.get("role") == "given":
                return True
    return False


def _checker(page, box, rec, answers, ocr, dpi, png_out, ocr_dir, add):
    try:
        import pymupdf
        from wspec import check as K
    except Exception as e:                            # noqa: BLE001
        add(REVIEW, "G79_CHECKER_UNAVAILABLE", "%s" % e)
        return None
    z = dpi / 72.0
    clip = pymupdf.Rect(*box)
    pm = page.get_pixmap(matrix=pymupdf.Matrix(z, z), clip=clip,
                         colorspace=pymupdf.csGRAY, alpha=False)
    png = pm.tobytes("png")
    if png_out:
        with open(png_out, "wb") as fh:
            fh.write(png)
    try:
        # (v6.16 integrate) a graph figure's checker reads its OWN guard
        # (every point / curve / text / equation its finds forbid,
        # wspec.graph.kinds.answer_guard); the others the level's values
        guard = WB.F616.figure_guard(rec) or list(answers or ())
        rep = K.check_figure(rec["svg_file"], rec["object_map"],
                             rec["level"].pub, rec["fid"], ocr=ocr,
                             display_image=png,
                             display_scale=z * PT_PER_PX,
                             display_origin=(0.0, 0.0),
                             answer_guard=guard,
                             keep_ocr_dir=ocr_dir)
    except Exception as e:                            # noqa: BLE001
        add(FAIL, "G79_CHECKER_ERROR", "the checker could not read %s: %s"
            % (rec["fid"], e))
        return None
    for f in rep.get("findings") or []:
        if f.get("level") in (FAIL, REVIEW):
            add(f["level"], "K:" + f["code"], f.get("detail", ""))
    ink = rep.get("display_ink") or {}
    ocr_st = dict((k, v.get("status")) for k, v in
                  (rep.get("ocr") or {}).items() if isinstance(v, dict))
    if rep.get("api") == "v616-graph/1":
        # (v6.16 integrate) the graph checker reports its OCR as checks
        ocr_st = dict((c, st) for c, st in (rep.get("checks") or {}).items()
                      if c.startswith("OCR_"))
    return {"status": rep.get("status"), "display": (rep.get("measured") or
                                                    {}).get("display"),
            "ocr": ocr_st,
            "infrastructure": list(rep.get("infrastructure") or []),
            # Codex F2: the geometric ink of the PDF pixels vs the approved
            # figure (element count compared, the worst missing share, the
            # foreign ink in px of the raster)
            "display_ink": {"elements": ink.get("elements"),
                            "worst_missing": max(
                                [round(m / float(i), 3) for m, i in
                                 (ink.get("missing") or {}).values() if i] or
                                [0.0]),
                            "extra_px": ink.get("extra_px")} if ink else None}


def answer_values(L):
    """The level's answer values (private) the figures must not print.
    (v6.16 integrate) + the answers of the level's GRAPH finds."""
    out = []
    for rec in WB.spec_figs(L).values():
        out.extend(WB.F616.answer_values(rec["level"]))
        break
    for rec in WB.spec_figs(L).values():
        for a in rec["level"].answers.values():
            if a.get("rel") == "classify":
                # (v6.10 integrate) a classification's answer is a class
                # ('rectangle'), not a number: no figure prints a class
                continue
            if a.get("value") is not None:
                out.append(WB.WC.number_display(WB.WC.canon_number(
                    a["value"])))
        break
    return sorted(set(out))


_SVG_BLOCK = re.compile(r"<svg\b.*?</svg>", re.S)


def html_exact(html, L):
    """{fid: why} for every engine figure the sheet HTML does not inline
    EXACTLY: its block, with the sheet's id prefix <fid>__ taken off, must
    be the engine's SVG from `<svg` on, byte for byte (no font pinning, no
    minus rewriting, no size change)."""
    out = {}
    got = {}
    for blk in _SVG_BLOCK.findall(html or ""):
        m = re.search(r'\sid="([^"]+?)__', blk)
        if m:
            got.setdefault(m.group(1), blk)
    for fid, rec in sorted(WB.spec_figs(L).items()):
        blk = got.get(fid)
        if blk is None:
            out[fid] = "not inlined in the sheet"
            continue
        raw = re.sub(r'(\sid=")%s__' % re.escape(fid), r"\1", blk)
        if raw != rec["svg"]:
            k = next((i for i, (a, b) in enumerate(zip(raw, rec["svg"]))
                      if a != b), min(len(raw), len(rec["svg"])))
            out[fid] = "differs from the engine's SVG at byte %d (%r vs %r)" \
                % (k, raw[max(0, k - 20):k + 30],
                   rec["svg"][max(0, k - 20):k + 30])
    return out


def check_pdf(pdf, layout, L, ocr=True, dpi=DPI, accept=None, out_dir=None,
              html=None):
    """G79 on every engine figure of level L printed in `pdf` (and, given
    the sheet HTML, the figures inlined exactly)."""
    import pymupdf
    figs = WB.spec_figs(L)
    exact = html_exact(html, L) if html is not None else {}
    accept = dict(accept if accept is not None else
                  (L.get("accept_review") or {}))
    doc = pymupdf.open(str(pdf))
    ans = answer_values(L)
    rep = {"gate": "G79-spec", "dpi": dpi, "ocr": bool(ocr), "figures": {},
           "page_numbering": "page = 1-based (as a PDF viewer shows it); "
                             "page_index = 0-based (layout_of, pymupdf "
                             "doc[page_index])"}
    for fid in sorted(figs):
        png = os.path.join(out_dir, "%s.png" % fid) if out_dir else None
        r = check_figure_pdf(doc, (layout or {}).get(fid), figs[fid], ans,
                             ocr=ocr, dpi=dpi, png_out=png)
        if fid in exact:
            r["findings"].insert(0, {"level": FAIL, "code":
                                     "G79_HTML_NOT_EXACT", "detail":
                                     "%s: %s" % (fid, exact[fid])})
            r["status"] = FAIL
        if r["status"] == REVIEW and str(accept.get(fid) or "").strip():
            r["status"] = ACCEPTED
            r["accepted"] = str(accept[fid])
        rep["figures"][fid] = r
    st = [r["status"] for r in rep["figures"].values()]
    rep["status"] = _worst(st) if st else PASS
    rep["counts"] = dict((k, st.count(k)) for k in (PASS, ACCEPTED, REVIEW,
                                                    FAIL))
    rep["approved"] = rep["status"] in (PASS, ACCEPTED)
    return rep


def summary(rep):
    """The build.json record (no pixels, no paths; the printed box of each
    figure in pt)."""
    return {"gate": rep["gate"], "status": rep["status"],
            "approved": rep["approved"], "counts": rep["counts"],
            "dpi": rep["dpi"], "ocr": rep["ocr"],
            "figures": dict((fid, dict(
                status=r["status"], page=r.get("page"),
                page_index=r.get("page_index"),
                # where the figure is printed (pt, fitted from the PDF's
                # dots): the acceptance run in PDF mode reads it from here
                box_pt=r.get("box_pt"), origin_pt=r.get("origin_pt"),
                findings=["%s %s" % (f["level"], f["code"])
                          for f in r["findings"]],
                **({"accepted": r["accepted"]} if r.get("accepted") else {})))
                for fid, r in sorted(rep["figures"].items()))}


def line(key, rep):
    c = rep["counts"]
    bad = [(fid, r) for fid, r in sorted(rep["figures"].items())
           if r["status"] in (FAIL, REVIEW)]
    s = ("G79-spec   %-4s %-8s %d figure(s): PASS %d  ACCEPTED %d  REVIEW %d"
         "  FAIL %d%s%s" % (key, rep["status"], len(rep["figures"]), c[PASS],
                            c[ACCEPTED], c[REVIEW], c[FAIL],
                            "" if rep["ocr"] else "   (OCR OFF: G79_OCR=0)",
                            "" if rep["approved"] else "   NOT APPROVED"))
    for fid, r in bad[:12]:
        for f in r["findings"][:3]:
            s += "\n    %s %s %s %s" % (fid, f["level"], f["code"],
                                       f["detail"][:150])
    return s
