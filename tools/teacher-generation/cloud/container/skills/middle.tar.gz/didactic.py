# -*- coding: utf-8 -*-
"""didactic.py -- v6.7.1-noam: the author's didactic policy (BRIEF_V671).

What deliver.py asks of this module, all on plain data (claims as dicts, a
figure as the dict sheet.json writes, the finished SVG as text):

  canon(claim)             one canonical key per relation, so the same fact
                           written twice ('AM = MB', {'type': 'equal_length',
                           'of': ['MB', 'AM']}) is recognised (§2)
  neutral_faults(...)      §3: what in a STARTING figure is not neutral --
                           a mark / value label that is not an explicit
                           given, a helper (dashed) line, a colour, a drawn
                           to_construct object -- each with a fix that keeps
                           the question's data
  given_marks(...)         §4: per figure, the marks Noam AI may overlay to
                           show how the GIVENS are marked (never drawn)
  hint_verdict(...)        §6: 'ok' / 'decisive' / 'review' for a hint text
  curriculum_block(...)    §7: the package's place in the official sequence,
                           from curriculum_tools.json
  AUX_SHARE, aux_limit()   §5: aux figures are rare

Nothing here draws. deliver.py refuses under STRICT (`neutral`, which
follows STRICT_FIGURES); check_didactic.py re-checks the finished package
without importing any of this.
"""
import json
import math
import os
import re
import unicodedata

HERE = os.path.dirname(os.path.abspath(__file__))
TOOLS_FILE = os.path.join(HERE, "curriculum_tools.json")

# ---------------------------------------------------------------- claims --
# claim types that are not figure constraints: a shape the question names
# (its definition covers the marks it implies), and the objects a student
# CONSTRUCTS (never drawn in the starting figure)
SHAPES = ("rectangle", "square", "parallelogram", "rhombus", "trapezoid",
          "kite", "isosceles", "equilateral", "right_triangle")
OBJECT_TYPES = ("segment", "line", "ray", "point", "polygon", "circle")
DIDACTIC_TYPES = ("shape",) + OBJECT_TYPES
HINT_TYPES = ("construction", "formula", "theorem", "guiding_question",
              "none")
HINT_MODES = ("guiding_question", "concept", "approved_hint")
AUX_SHARE = 0.10
AUX_LABEL = u"שרטוט עזר"

_PT = re.compile(u"[A-Z][0-9]*[\u2032\u2033']*")


def toks(v):
    if isinstance(v, (list, tuple)):
        out = []
        for x in v:
            out += toks(x)
        return out
    return _PT.findall(str(v or ""))


def cseg(v):
    t = toks(v)
    return "".join(sorted(t)) if len(t) == 2 else "|".join(t) or str(v)


def cang(v):
    if isinstance(v, dict):
        return (str(v.get("at")), tuple(sorted(str(x)
                                               for x in v.get("rays") or [])))
    t = toks(v)
    if len(t) == 3:
        return (t[1], tuple(sorted((t[0], t[2]))))
    return (str(v), ())


def _num(v):
    try:
        return round(float(str(v).replace(u"\u2212", "-")), 6)
    except (TypeError, ValueError):
        return str(v)


def canon(c):
    """A hashable key for one claim dict (None when it states nothing)."""
    if not isinstance(c, dict):
        return ("text", re.sub(r"\s+", "", str(c)))
    t = c.get("type")
    of = c.get("of")
    if t in ("equal_length", "parallel", "concentric"):
        return (t, tuple(sorted(cseg(x) for x in of or [])))
    if t == "perpendicular":
        return (t, tuple(sorted(cseg(x) for x in of or [])))
    if t == "equal_angle":
        return (t, tuple(sorted(cang(x) for x in of or [])))
    if t == "length":
        return (t, cseg(of), _num(c.get("value")))
    if t == "angle":
        return (t, cang({"at": c.get("at"), "rays": c.get("rays")}),
                _num(c.get("value")))
    if t in ("midpoint", "on_segment"):
        return (t, str(c.get("point")), cseg(of))
    if t == "collinear":
        return (t, tuple(sorted(str(x) for x in c.get("points") or [])))
    if t == "ratio":
        return (t, tuple(cseg(x) for x in of or []), _num(c.get("value")))
    if t == "tangent":
        return (t, str(c.get("circle")), cseg(c.get("to")), str(c.get("at")))
    if t == "hidden_edge":
        return (t, cseg(of))
    if t in ("segment", "line", "ray"):
        return ("segment", cseg(of))
    if t == "point":
        return (t, str(c.get("point") or of))
    if t in ("polygon", "shape"):
        return (t, tuple(sorted(toks(c.get("points") or of))),
                str(c.get("value") or ""))
    if t == "circle":
        return (t, str(c.get("circle") or of))
    if t == FIND_TYPE:
        return find_key(c)
    if c.get("text"):
        return ("text", re.sub(r"[\s$]+", "", str(c["text"])))
    return None


def names_in(c):
    """Point names a claim dict mentions (its typed fields)."""
    out = []
    for k in ("of", "points", "point", "at", "rays", "to", "circle"):
        if k in c:
            out += toks(c[k])
    return sorted(set(out))


# ----------------------------------------------- find targets (v6.7.2) --
# BRIEF_V672: to_prove holds what the student proves, COMPUTES or FINDS. A
# compute item ("חשבו את ∠ACB", "מצאו את שיעורי D") declares a `find`
# target: {"type": "find", "quantity": "angle", "of": "ACB"}. The VALUE
# (required since r2, "value": 55) is private: sheet.json keeps it with the answer,
# noam-ai.json never carries it. One small vocabulary, registered like the
# visual_model kinds: a new quantity = one row here + one in
# check_didactic.FIND_QUANTITIES.
FIND_TYPE = "find"
#   quantity -> (what `of` names, the Hebrew noun of the default text)
#   of-kinds: angle (3 points / at+rays), segment (2 points), segments
#   (a list of 2-point names), polygon (3+ points), point (1 point),
#   variable (a symbol the question declares), cell (a table cell of a
#   declared table model), any (optional: points or model ids; else `what`)
FIND_QUANTITIES = {
    "angle":       ("angle", u"גודל הזווית"),
    "length":      ("segment", u"אורך"),
    "distance":    ("segment", u"המרחק"),
    "area":        ("polygon", u"שטח"),
    "perimeter":   ("polygon", u"היקף"),
    "coordinates": ("point", u"שיעורי הנקודה"),
    "variable":    ("variable", u"ערך"),
    "ratio":       ("segments", u"היחס"),
    "count":       ("any", u"מספר"),
    "probability": ("any", u"ההסתברות"),
    "cell":        ("cell", u"התא"),
    "graph_value": ("any", u"הערך בגרף"),
    "value":       ("any", u"הערך"),
}
FIND_KEYS = ("type", "quantity", "of", "at", "rays", "unit", "what", "text",
             "value", "curve", "x")
# what noam-ai.json may carry of a find target (never its value)
FIND_PUBLIC = ("type", "quantity", "of", "at", "rays", "unit", "what", "text",
               "curve", "x")
_VAR = re.compile(u"^[a-zα-ω][0-9]*$")
_CELL = re.compile(u"^(?:.*-)?r([0-9]+)c([0-9]+)$")


def is_find(c):
    return isinstance(c, dict) and c.get("type") == FIND_TYPE


def find_key(c):
    q = str(c.get("quantity") or "")
    k = FIND_QUANTITIES.get(q, ("any",))[0]
    of = c.get("of")
    if k == "angle":
        a = cang({"at": c.get("at"), "rays": c.get("rays")}) \
            if c.get("at") else cang(of)
        return (FIND_TYPE, q, a)
    if k == "segment":
        return (FIND_TYPE, q, cseg(of))
    if k == "segments":
        return (FIND_TYPE, q, tuple(cseg(x) for x in of or []))
    if k in ("polygon",):
        return (FIND_TYPE, q, tuple(sorted(toks(of))))
    if isinstance(of, list):
        return (FIND_TYPE, q, tuple(str(x) for x in of))
    return (FIND_TYPE, q, str(of if of is not None else c.get("what") or ""))


def find_text(c):
    """the target in words, never its value ('גודל הזווית ACB')."""
    if c.get("text"):
        return str(c["text"])
    q = str(c.get("quantity") or "")
    noun = FIND_QUANTITIES.get(q, (None, u"הערך"))[1]
    of = c.get("of")
    if c.get("at") and not of:
        rr = list(c.get("rays") or [])
        of = "%s%s%s" % ((rr + ["", ""])[0], c.get("at"), (rr + ["", ""])[1])
    if isinstance(of, list):
        of = u" : ".join(map(str, of)) if q == "ratio" else \
            u", ".join(map(str, of))
    # v6.13 fix_r2 (R1-triangle-symbol-area-metadata, author rule
    # W-TRIANGLE-SYMBOL "△ always"): the area / perimeter of a triangle
    # names it '△ABC' ('שטח △ABC'), never a bare 'שטח ABC'
    if q in ("area", "perimeter") and isinstance(of, str) and \
            _TRI_NAME.match(of):
        of = u"\u25b3" + of
    what = c.get("what")
    return u" ".join(x for x in (noun, str(of or ""), str(what or ""))
                     if x).strip()


_TRI_NAME = re.compile(u"^(?:[A-Z][0-9]*['\u2032]*){3}$")


def find_public(c):
    """the find target as noam-ai.json carries it: no value, ever."""
    d = dict((k, c[k]) for k in FIND_PUBLIC if c.get(k) is not None)
    d["type"] = FIND_TYPE
    d["text"] = find_text(c)
    return d


def find_refs(c):
    """(points, variables, ids) a find target NAMES."""
    q = str(c.get("quantity") or "")
    k = FIND_QUANTITIES.get(q, ("any",))[0]
    of = c.get("of")
    pts, var, ids = [], [], []
    vals = of if isinstance(of, list) else ([] if of is None else [of])
    if k == "angle" and c.get("at"):
        pts = toks([c.get("at")] + list(c.get("rays") or []))
    elif k == "variable":
        var = [str(v) for v in vals]
    elif k == "cell":
        ids = [str(v) for v in vals]
    else:
        for v in vals:
            if toks(v) and re.sub(u"[A-Z0-9′″'\\s,]", "",
                                  str(v)) == "":
                pts += toks(v)
            elif k == "any" and v is not None:
                ids.append(str(v))
            else:
                pts += toks(v)
    if c.get("curve"):
        ids.append(str(c["curve"]))
    return sorted(set(pts)), sorted(set(var)), sorted(set(ids))


def find_schema_faults(c):
    """what is wrong with one find target's own fields (a list of texts)."""
    out = []
    q = c.get("quantity")
    if q not in FIND_QUANTITIES:
        return ["quantity %r is not one of %s" % (q, ", ".join(sorted(
            FIND_QUANTITIES)))]
    bad = [k for k in c if k not in FIND_KEYS and k != "from_item"]
    if bad:
        out.append("unknown field(s) %s (a find target has %s)"
                   % (bad, ", ".join(FIND_KEYS)))
    k = FIND_QUANTITIES[q][0]
    of = c.get("of")
    n = len(toks(of)) if not isinstance(of, list) else None
    if k == "angle" and not c.get("at") and n != 3:
        out.append("an angle is named by 3 points ('ACB') or at + rays")
    elif k == "segment" and n != 2:
        out.append("a %s names one segment, 2 points ('AB')" % q)
    elif k == "segments" and not (isinstance(of, list) and len(of) >= 2):
        out.append("a ratio names 2+ segments / quantities, of=[...]")
    elif k == "polygon" and (n or 0) < 3:
        out.append("an %s names a polygon, 3+ points ('ABCD')" % q)
    elif k == "point" and n != 1:
        out.append("coordinates name one point ('D')")
    elif k == "variable" and not (of and all(
            _VAR.match(str(v)) for v in (of if isinstance(of, list)
                                         else [of]))):
        out.append("a variable is a symbol, of='x'")
    elif k == "cell" and not (of and all(_CELL.match(str(v)) for v in (
            of if isinstance(of, list) else [of]))):
        out.append("a table cell is of='r2c3' (row, column of the table)")
    elif k == "any" and of is None and not str(c.get("what") or "").strip() \
            and not c.get("curve"):
        out.append("name its object (of=...) or say what is counted / "
                   "asked (what=...)")
    return out


# v6.13 fix_r2 (as check_didactic.fnums, T08B-D9): '(7,6)' is two numbers,
# never 7.6 -- the sheets write decimals with '.'
_NUM = re.compile(u"(?<![\\w.])-?\\d+(?:[.]\\d+)?(?!\\w|[.]\\d)")


def nums(s):
    """the numbers a text prints ('6.4', '51.3', '12'), normalised."""
    out = set()
    for x in _NUM.findall(str(s or "").replace(u"\u2212", "-")):
        try:
            out.add("%g" % float(x.replace(",", ".")))
        except ValueError:
            out.add(x)
    return out


FIND_TEXT_FIELDS = ("text", "what", "unit")
_UNIT_OK = re.compile(u"^[^\\d]{0,24}$")


def find_leaks(c, value=None, context=""):
    """r1 T4: the public fields of a find target (text / what / unit) never
    state its value. A unit is a word ('ס"מ', 'מעלות'), never a number; a
    number in text / what that the item's own text does not print is the
    answer leaking (and when the private value is known, its numbers)."""
    out = []
    u = c.get("unit")
    if u is not None and not _UNIT_OK.match(str(u)):
        out.append("unit %r is not a unit word (no digits)" % (u,))
    ctx = nums(context)
    vn = nums(value) if value is not None else set()
    for k in FIND_TEXT_FIELDS:
        v = c.get(k)
        if v is None or k == "unit":
            continue
        extra = nums(v) - ctx
        if extra:
            out.append("%s %r prints %s, which the item's text does not"
                       % (k, v, ", ".join(sorted(extra))))
        elif vn and vn <= nums(v) and not vn <= ctx:
            out.append("%s %r states the value" % (k, v))
    return out


_VDIV = re.compile(u"(?<![\\w.])(-?\\d+(?:[.,]\\d+)?)(?:\\s*[/\u2044]\\s*|"
                   u"[:\u2236]|\\s[:\u2236]\\s)(\\d+(?:[.,]\\d+)?)(?![\\w]|[.,]\\d)")
_VPCT = re.compile(u"(?<![\\w.])(-?\\d+(?:[.,]\\d+)?)\\s*%")


def value_keys(s):
    """v6.7.3: the numbers a text prints BY VALUE -- 3/5, 0.6 and 60% are
    one number (the checker's fvals, the deliver-side copy)."""
    s = str(s if s is not None else "").replace(u"\u2212", "-")
    out = set()
    f = lambda x: "%.9g" % float(str(x).replace(",", "."))
    for x in nums(s):
        try:
            out.add(f(x))
        except ValueError:
            pass
    for a, b in _VDIV.findall(s):
        try:
            if float(b.replace(",", ".")) != 0:
                out.add("%.9g" % (float(a.replace(",", ".")) /
                                  float(b.replace(",", "."))))
        except ValueError:
            pass
    for x in _VPCT.findall(s):
        try:
            out.add("%.9g" % (float(x.replace(",", ".")) / 100.0))
        except ValueError:
            pass
    return out


def value_atoms(value):
    """the private value as atoms of equal spellings: '3/5' -> [{0.6}],
    '60%' -> [{60, 0.6}], '(4, 0)' -> [{4}, {0}]."""
    if value is None or isinstance(value, bool):
        return []
    if isinstance(value, (int, float)):
        return [set(["%.9g" % float(value)])]
    t = str(value).strip().replace(u"\u2212", "-")
    m = re.match(u"^\\s*(-?\\d+(?:[.,]\\d+)?)\\s*[/:\u2044\u2236]\\s*"
                 u"(\\d+(?:[.,]\\d+)?)\\s*$", t)
    if m and float(m.group(2).replace(",", ".")) != 0:
        return [set(["%.9g" % (float(m.group(1).replace(",", ".")) /
                               float(m.group(2).replace(",", ".")))])]
    m = re.match(u"^\\s*(-?\\d+(?:[.,]\\d+)?)\\s*%\\s*$", t)
    if m:
        p = float(m.group(1).replace(",", "."))
        return [set(["%.9g" % p, "%.9g" % (p / 100.0)])]
    return [set(["%.9g" % float(x)]) for x in nums(t)]


_HEB_NUM = {u"אפס": 0, u"אחת": 1, u"אחד": 1, u"שתיים": 2, u"שתים": 2,
            u"שתי": 2, u"שניים": 2, u"שני": 2, u"שלוש": 3, u"שלושה": 3,
            u"ארבע": 4, u"ארבעה": 4, u"חמש": 5, u"חמישה": 5, u"שש": 6,
            u"שישה": 6, u"שבע": 7, u"שבעה": 7, u"שמונה": 8, u"תשע": 9,
            u"תשעה": 9, u"עשר": 10, u"עשרה": 10}
_HEB_RX = re.compile(u"(?<![א-ת])[ובלמשה]?(%s)(?![א-ת])" % "|".join(
    sorted(_HEB_NUM, key=len, reverse=True)))


def stated_text(q):
    """v6.7.3: every word the sheet prints for a source question: its
    text, intro, items' texts and table (number words as digits)."""
    parts = [q.get("text"), q.get("intro")]
    for it in q.get("items") or []:
        if isinstance(it, dict):
            parts += [it.get("text"), it.get("intro")]
    tb = q.get("table")
    if isinstance(tb, dict):
        parts += list(tb.get("head") or [])
        for row in tb.get("rows") or []:
            parts += list(row or [])
    t = u" ".join(str(x) for x in parts if x is not None)
    w = [str(_HEB_NUM[m]) for m in _HEB_RX.findall(t)]
    return t + (u" " + u" ".join(w) if w else u"")


def find_given_faults(c, given, value=None, context=""):
    """v6.7.3 (M1): certain leaks of a find target through its question's
    givens. (1) a given that states the very quantity asked (length MD
    given, length MD to find): section 2 given / to_find overlap. (2) a
    given carrying the target's value (by value) whose numbers the
    question's words do not print: a JSON-only given, the answer in
    noam-ai.json."""
    out = []
    k = FIND_QUANTITIES.get(str(c.get("quantity") or ""), ("any",))[0]
    fk = find_key(c)[2]
    atoms = value_atoms(value)
    tn = set(x.lstrip("-") for x in nums(context))
    for g in given or []:
        if not isinstance(g, dict) or g.get("from_item"):
            continue
        t = g.get("type")
        same = False
        if k == "segment":
            same = t in ("length", "distance") and cseg(g.get("of")) == fk
        elif k == "angle":
            same = t == "angle" and (
                cang({"at": g.get("at"), "rays": g.get("rays")})
                if g.get("at") else cang(g.get("of"))) == fk
        elif k == "polygon":
            same = t == c.get("quantity") and tuple(sorted(toks(
                g.get("of") or g.get("points")))) == fk
        elif k == "point":
            same = t in ("coordinates", "point") and \
                g.get("value") is not None and \
                str(g.get("point") or g.get("of")) == str(fk)
        say = g.get("text") or _say(g)
        if same:
            out.append("the given %s states the quantity the item asks to "
                       "find (a given and a find target at once)" % say)
            continue
        gtxt = u"%s %s" % (g.get("value") if g.get("value") is not None
                           else "", g.get("text") or "")
        gk = value_keys(gtxt)
        gn = set(x.lstrip("-") for x in nums(gtxt))
        if atoms and all(a & gk for a in atoms) and gn and not gn <= tn:
            out.append("the given %s carries the value the item asks to "
                       "find, and the question's text does not state it"
                       % say)
    return out


def find_cell_faults(visuals, c, value=None):
    """r1 T2: a table-cell find target shows no number in its own cell (the
    starting table leaves it blank / '?')."""
    out = []
    if FIND_QUANTITIES.get(str(c.get("quantity") or ""), ("any",))[0] != \
            "cell":
        return out
    of = c.get("of")
    want = [str(x) for x in (of if isinstance(of, list) else [of])]
    for vm in visuals or []:
        for o in vm.get("objects") or []:
            if o.get("type") != "cell":
                continue
            oid = str(o.get("id"))
            if not any(oid == w or (_CELL.match(w) and oid.endswith(
                    "-r%sc%s" % _CELL.match(w).groups()) and (
                    "-" not in w or oid == w)) for w in want):
                continue
            shown = o.get("value")
            if shown is not None and re.search(u"\\d", str(shown)):
                out.append("%s prints %r in the cell the item asks to "
                           "find" % (oid, shown))
    return out


def find_unknown(c, points, variables=(), ids=()):
    """names a find target uses that the model does not hold."""
    P, V, I = find_refs(c)
    miss = [p for p in P if p not in set(points)]
    miss += [v for v in V if v not in set(variables)]
    idset = set(ids)
    for i in I:
        m = _CELL.match(i)
        if i in idset or (m and any(
                x.endswith("-r%sc%s" % m.groups()) for x in idset)):
            continue
        miss.append(i)
    return miss


def _angle_dir(o, p):
    return math.atan2(p[1] - o[1], p[0] - o[0])


def _in_wedge(V, P, Q, L):
    """is L inside the (smaller) angle PVQ?"""
    a, b, x = _angle_dir(V, P), _angle_dir(V, Q), _angle_dir(V, L)
    d = (b - a) % (2 * math.pi)
    if d > math.pi:
        a, b, d = b, a, 2 * math.pi - d
    return 0 < (x - a) % (2 * math.pi) < d, d


def _given_owner(xy, txt, given, pts, tgt=None):
    """v6.7.2 r3 (G9T18-held-targets): the GIVEN angle a free degree label
    prints. shapekit.angle_arc writes a given's number with no `for`, on
    its own bisector (or as a callout beside its arc). A label whose number
    is a given angle's value, inside that given's wedge, and nearer (in
    angle, relative to the half-width) to the given's bisector than to the
    target's, is the given's own: the '35\u00b0' of a given \u2220BAC in a long
    rectangle is not printed on the wider target \u2220ACB or \u2220AOB whose
    wedge happens to hold it. `tgt` = (V, (R1, R2)) point names."""
    if not isinstance(xy, list) or len(xy) < 2:
        return None
    tn = nums(txt)

    def ratio(Vn, rays):
        V = pts.get(str(Vn))
        R = [pts.get(str(r)) for r in rays or []]
        if not V or len(R) != 2 or not all(R):
            return None
        a1 = math.atan2(R[0][1] - V[1], R[0][0] - V[0])
        a2 = math.atan2(R[1][1] - V[1], R[1][0] - V[0])
        d = math.atan2(math.sin(a2 - a1), math.cos(a2 - a1))
        bis = a1 + d / 2.0
        x = math.atan2(xy[1] - V[1], xy[0] - V[0])
        off = abs(math.atan2(math.sin(x - bis), math.cos(x - bis)))
        return off / max(abs(d) / 2.0, 1e-6)
    tr = ratio(tgt[0], tgt[1]) if tgt else None
    Vt = pts.get(str(tgt[0])) if tgt else None

    def half_of(Vn, rays):
        V = pts.get(str(Vn))
        R = [pts.get(str(r)) for r in rays or []]
        if not V or len(R) != 2 or not all(R):
            return None
        a1 = math.atan2(R[0][1] - V[1], R[0][0] - V[0])
        a2 = math.atan2(R[1][1] - V[1], R[1][0] - V[0])
        return abs(math.atan2(math.sin(a2 - a1), math.cos(a2 - a1))) / 2.0
    best = None
    for g in given or []:
        if not isinstance(g, dict) or g.get("type") != "angle" or \
                g.get("value") is None:
            continue
        gn = nums(str(g.get("value")))
        if not gn or not gn <= tn:
            continue
        r = ratio(g.get("at"), g.get("rays"))
        if r is None:
            continue
        if r >= 1.0 or (tr is not None and r >= tr):
            # not on the given's bisector: still its CALLOUT when it stands
            # just outside its wedge (angle_arc: 20deg past the arm) and
            # nearer its vertex than the target's
            Vg = pts.get(str(g.get("at")))
            half = half_of(g.get("at"), g.get("rays"))
            if Vt is None or half is None or \
                    (r - 1.0) * half > math.radians(60) or \
                    math.hypot(xy[0] - Vg[0], xy[1] - Vg[1]) >= \
                    math.hypot(xy[0] - Vt[0], xy[1] - Vt[1]):
                continue
        if best is None or r < best[0]:
            best = (r, cang({"at": g.get("at"), "rays": g.get("rays")}))
    return best[1] if best else None

_NUMTXT = re.compile(u"\\d")


def _label_names(txt, kind, target):
    """does a label's name part ('MD' of 'MD = 6.4') name the target?"""
    m = re.match(u"^\\s*([^=(:]*?)\\s*[=(:]", txt)
    if not m or not _NUMTXT.search(txt[m.end():]):
        return False
    t = toks(m.group(1))
    if kind == "segment":
        return len(t) == 2 and cseg(t) == target
    if kind == "angle":
        return (len(t) == 3 and cang(t) == target) or \
            (len(t) == 1 and t[0] == target[0])
    if kind == "point":
        return t == [target]
    if kind == "polygon":
        return len(t) >= 3 and tuple(sorted(t)) == target
    return False


def find_value_faults(fig, c, given=(), value=None):
    """§3 for a find target: what in ONE starting figure prints or marks its
    value -- a value label on its object, a marked length / angle of it, a
    tick / arc equating it to something the question does not give."""
    out = []
    ob = fig.get("objects") or {}
    q = str(c.get("quantity") or "")
    kind = FIND_QUANTITIES.get(q, ("any",))[0]
    key = find_key(c)
    gk = set(canon(g) for g in given or [] if isinstance(g, dict))
    pts = {}
    for o in ob.get("points") or []:
        if o.get("name") and isinstance(o.get("xy"), list) and \
                len(o["xy"]) >= 2 and not isinstance(o["xy"][0], list):
            pts[str(o["name"])] = o["xy"][:2]
    target = None
    if kind == "angle":
        target = key[2]
    elif kind in ("segment", "point", "polygon"):
        target = key[2]
    # 1. a marked constraint that states / equates the target
    for fc in fig.get("constraints") or []:
        if not fc.get("marked") or fc.get("violated"):
            continue
        t = fc.get("type")
        hit = False
        if kind == "angle" and t == "angle" and cang(
                {"at": fc.get("at"), "rays": fc.get("rays")}) == target:
            hit = "marks its value (%s)" % fc.get("value")
        elif kind == "segment" and t == "length" and cseg(
                fc.get("of")) == target:
            hit = "marks its value (%s)" % fc.get("value")
        elif kind == "angle" and t == "equal_angle" and target in [
                cang(x) for x in fc.get("of") or []] and canon(fc) not in gk:
            hit = "equates it by arcs to another angle, no given says so"
        elif kind == "segment" and t == "equal_length" and target in [
                cseg(x) for x in fc.get("of") or []] and canon(fc) not in gk:
            hit = "equates it by ticks to another segment, no given says so"
        if hit:
            out.append("%s %s" % (fig.get("id"), hit))
    # 2. a value label on its object
    labels = [o for o in ob.get("labels") or []
              if _NUMTXT.search(str(o.get("text") or ""))]
    gnums = set()
    for g in given or []:
        if isinstance(g, dict) and g.get("value") is not None:
            gnums |= nums(g.get("value"))
    for lb in labels:
        txt = str(lb.get("text") or "")
        fo = str(lb.get("for") or "")
        on = False
        if kind == "segment" and fo and len(toks(fo)) == 2 and \
                cseg(fo) == target:
            on = True
        elif kind == "point" and fo and fo == target and \
                re.search(u"\\d", txt):
            on = True
        elif kind == "polygon" and fo and tuple(sorted(toks(fo))) == target:
            on = True
        elif kind == "angle" and not fo and u"°" in txt and \
                isinstance(lb.get("xy"), list) and \
                _given_owner(lb.get("xy"), txt, given, pts,
                             target) not in \
                (None, target):
            # v6.7.2 r3: the number of a given angle elsewhere -- its own
            continue
        elif kind == "angle" and not fo and u"°" in txt and \
                isinstance(lb.get("xy"), list):
            V = pts.get(target[0])
            R = [pts.get(r) for r in target[1]]
            if V and all(R) and len(R) == 2:
                inside, width = _in_wedge(V, R[0], R[1], lb["xy"])
                if inside:
                    # the label belongs to the NARROWEST angle at V that
                    # holds it: a given angle nested inside the target
                    # owns its own value label
                    own = True
                    for g in given or []:
                        if not isinstance(g, dict) or g.get("type") != \
                                "angle" or str(g.get("at")) != target[0]:
                            continue
                        gr = [pts.get(r) for r in g.get("rays") or []]
                        if len(gr) == 2 and all(gr):
                            gi, gw = _in_wedge(V, gr[0], gr[1], lb["xy"])
                            if gi and gw < width - 1e-6:
                                own = False
                    on = own
        elif kind == "angle" and fo and len(toks(fo)) == 3:
            # r1 T7: a value label tied to the target angle by `for`
            on = cang(fo) == target
        elif kind == "any" and fo and fo in [str(x) for x in (
                c.get("of") if isinstance(c.get("of"), list)
                else [c.get("of")])]:
            on = True
        if not on and kind == "variable":
            # r1: 'x = 5' prints the variable's value, whatever it labels
            mv = re.match(u"^\\s*\\$?\\s*([a-zα-ω][0-9]*)\\s*\\$?\\s*=\\s*"
                          u"\\$?\\s*-?\\d", txt)
            on = bool(mv and mv.group(1) in [str(x) for x in (
                c.get("of") if isinstance(c.get("of"), list)
                else [c.get("of")])])
        if not on and kind == "segments" and value is not None and \
                re.search(u"[:/]", txt) and nums(value) and \
                nums(value) <= nums(txt):
            on = True                    # a ratio '1:2' printed anywhere
        if not on and not fo:
            # r1 T3: a free label (no `for`) that NAMES the target and
            # prints a number ('MD = 6.4', '∠AMD = 51.3°', 'D(4, 0)'), or
            # prints the private value itself ('51.3°' anywhere)
            on = _label_names(txt, kind, target)
            if not on and kind in ("angle", "segment", "polygon") and \
                    value is not None and nums(value) and \
                    nums(value) <= nums(txt) and \
                    not nums(value) <= gnums:
                # v6.7.2 r3: a number a GIVEN prints is the given's, even
                # when the answer happens to equal it (as check_didactic's
                # SVG rule already reads it)
                on = True
        if on:
            out.append("%s prints %r on %s, the value the item asks to find"
                       % (fig.get("id"), txt, find_text(c)))
    return out


# ------------------------------------------------------------ the figure --
MARK_KINDS = ("ticks", "arc", "parallel", "right_angle", "dimension", "mark")
_GREY_NAMES = ("none", "transparent", "currentcolor", "black", "white",
               "inherit", "")
_NAMED = {"black": (0, 0, 0), "white": (255, 255, 255), "gray": (128,) * 3,
          "grey": (128,) * 3, "silver": (192,) * 3, "lightgray": (211,) * 3,
          "lightgrey": (211,) * 3, "darkgray": (169,) * 3,
          "darkgrey": (169,) * 3, "dimgray": (105,) * 3, "dimgrey": (105,) * 3,
          "gainsboro": (220,) * 3, "whitesmoke": (245,) * 3}


def _rgb(v):
    v = (v or "").strip().lower()
    if v in _GREY_NAMES or v.startswith("url("):
        return None
    if v in _NAMED:
        return _NAMED[v]
    m = re.match(r"^#([0-9a-f]{3})$", v)
    if m:
        return tuple(int(ch * 2, 16) for ch in m.group(1))
    m = re.match(r"^#([0-9a-f]{6})$", v)
    if m:
        h = m.group(1)
        return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
    m = re.match(r"^rgba?\(([^)]*)\)$", v)
    if m:
        p = [x.strip() for x in m.group(1).split(",")]
        try:
            return tuple(int(float(x.rstrip("%")) * (2.55 if x.endswith("%")
                                                    else 1)) for x in p[:3])
        except ValueError:
            return (255, 0, 0)
    return (255, 0, 0)            # any other named colour is a colour


def colour_faults(svg):
    """[(element id or tag, value)] of fills / strokes off the house
    ink-and-grey palette (r = g = b within 8)."""
    out = []
    for el in re.findall(r"<[a-zA-Z][^>]*>", svg or ""):
        vals = re.findall(r'\b(?:fill|stroke|stop-color|color)="([^"]*)"',
                          el)
        for st in re.findall(r'\bstyle="([^"]*)"', el):
            vals += re.findall(r"(?:fill|stroke|stop-color|color)\s*:\s*"
                               r"([^;]+)", st)
        for v in vals:
            rgb = _rgb(v)
            if rgb is None:
                continue
            if max(rgb) - min(rgb) > 8:
                i = re.search(r'\sid="([^"]+)"', el)
                out.append((i.group(1) if i else el[:40], v))
    return out


def dashed_elements(svg):
    """[(id or None, element text)] of every dashed stroke; an `ink-copy`
    piece is judged with the element it copies (skipped here). A dash set
    on a <g> is inherited by what it holds."""
    out = []
    depth = []                    # stack of (dashed?, group id)
    for m in re.finditer(r"<(/?)([a-zA-Z]+)([^>]*?)(/?)>", svg or ""):
        close, tag, attrs, selfc = m.groups()
        if tag == "g":
            if close:
                if depth:
                    depth.pop()
                continue
            d = bool(re.search(r"stroke-dasharray", attrs)) and \
                "stroke-dasharray:none" not in attrs.replace(" ", "")
            gid = re.search(r'\sid="([^"]+)"', attrs)
            if not selfc:
                depth.append((d, gid.group(1) if gid else None))
            continue
        if close or tag in ("svg", "text", "tspan", "defs", "clipPath",
                            "style", "title", "desc"):
            continue
        own = re.search(r'stroke-dasharray\s*[=:]\s*"?([^";]+)', attrs)
        dashed = own is not None and own.group(1).strip() not in ("none",
                                                                  "0")
        inh = [g for g in depth if g[0]]
        if not dashed and not inh:
            continue
        if 'class="ink-copy"' in attrs:
            continue
        i = re.search(r'\sid="([^"]+)"', attrs)
        eid = i.group(1) if i else (inh[-1][1] if inh else None)
        out.append((eid, m.group(0)[:120]))
    return out


def _obj_index(fig):
    by_id, by_name, pts = {}, {}, {}
    for b, lst in (fig.get("objects") or {}).items():
        for o in lst or []:
            sid = o.get("svg_id")
            if sid:
                by_id[sid] = (b, o)
            nm = o.get("name")
            if nm:
                by_name.setdefault((b, str(nm)), o)
            if b == "points" and nm and o.get("svg_xy"):
                pts[str(nm)] = tuple(o["svg_xy"])
    return by_id, by_name, pts


def seg_obj(fig, name):
    _i, by_name, _p = _obj_index(fig)
    t = toks(name)
    for nm in ("".join(t), "".join(reversed(t)), str(name)):
        o = by_name.get(("segments", nm))
        if o:
            return o
    return None


def _src(c):
    return c.get("source") or c.get("status")


def _shape_cover(c, shapes):
    """Does a GIVEN shape ('rectangle ABCD') state what constraint c marks
    (by definition only: a rectangle's right angles, a square's equal sides
    and right angles, a parallelogram's parallel opposite sides, ...)?"""
    t = c.get("type")
    for sh in shapes:
        P = toks(sh.get("points") or sh.get("of"))
        kind = str(sh.get("value") or "")
        n = len(P)
        if n < 3:
            continue
        sides = set(cseg([P[i], P[(i + 1) % n]]) for i in range(n))
        opp = set()
        if n == 4:
            opp = {tuple(sorted((cseg([P[0], P[1]]), cseg([P[2], P[3]])))),
                   tuple(sorted((cseg([P[1], P[2]]), cseg([P[3], P[0]]))))}
        segs = [cseg(x) for x in c.get("of") or []] \
            if isinstance(c.get("of"), list) else []
        if t == "perpendicular" and kind in ("rectangle", "square") and \
                len(segs) == 2 and all(s in sides for s in segs):
            return True
        if t == "angle" and kind in ("rectangle", "square") and \
                abs(float(c.get("value") or 0) - 90) < 1e-6 and \
                str(c.get("at")) in P:
            return True
        if t == "equal_length" and kind in ("square", "rhombus",
                                            "equilateral") and segs and \
                all(s in sides for s in segs):
            return True
        if t == "parallel" and len(segs) == 2 and \
                tuple(sorted(segs)) in opp and \
                kind in ("parallelogram", "rectangle", "square", "rhombus",
                         "trapezoid"):
            return True
    return False


def _mid_cover(c, given):
    """A given 'M is the midpoint of AB' states exactly what the ticks
    AM = MB say."""
    if c.get("type") != "equal_length" or not isinstance(c.get("of"), list):
        return False
    segs = sorted(cseg(x) for x in c["of"])
    for g in given or []:
        if isinstance(g, dict) and g.get("type") == "midpoint":
            P = str(g.get("point"))
            A, B = (toks(g.get("of")) + ["", ""])[:2]
            if segs == sorted([cseg([A, P]), cseg([P, B])]):
                return True
    return False


def _knob(ctype, mkind=None):
    k = mkind or ctype
    return {
        "perpendicular": "draw it without the right-angle mark (no "
                         "right_angle() / shape(..., marks=False) / plane() "
                         "without that right= corner)",
        "right_angle": "draw it without the right-angle mark (no "
                       "right_angle() / shape(..., marks=False))",
        "equal_length": "draw it without the ticks (ticks=False / "
                        "marks=False on the builder)",
        "ticks": "draw it without the ticks (ticks=False / marks=False)",
        "midpoint": "draw it without the ticks (midpoint(..., ticks=False))",
        "equal_angle": "draw it without the arcs (arcs=False)",
        "arc": "draw it without the arc (no angle arc / arcs=False)",
        "parallel": "draw it without the chevrons (no parallel arrows)",
        "length": "leave the number off the drawing",
        "dimension": "leave the dimension off the drawing",
        "angle": "leave the angle value off the drawing",
    }.get(k, "draw it without that mark")


def _claim_of(c):
    d = dict((k, v) for k, v in c.items()
             if k in ("type", "of", "point", "points", "at", "rays", "value",
                      "unit", "t", "circle", "to"))
    return d


def neutral_faults(fig, svg, given, to_prove=(), to_construct=(),
                   dashed=(), where=None):
    """§3 on ONE starting figure (the dict sheet.json writes for it, after
    the content labelled its constraints): [{rule, fig, ids, said, fix}].

    given / to_prove / to_construct are the claim dicts of the question and
    the items this figure serves; dashed the names / ids the question itself
    calls dashed."""
    fid = fig.get("id")
    where = where or fid
    out = []
    # a result carried from an earlier item (from_item) is that item's
    # conclusion: it never covers a mark of the starting figure, which the
    # earlier item shares
    carried = set(canon(g) for g in given or [] if isinstance(g, dict)
                  and g.get("from_item"))
    given = [g for g in given or [] if not (isinstance(g, dict) and
                                            g.get("from_item"))]
    carried -= set(canon(g) for g in given if isinstance(g, dict))
    by_id, _bn, pts = _obj_index(fig)
    cons = fig.get("constraints") or []
    shapes = [g for g in given or [] if isinstance(g, dict) and
              g.get("type") == "shape"]
    gkeys = set(canon(g) for g in given or [] if isinstance(g, dict))
    covered_marks = set()

    def add(rule, ids, said, fix):
        out.append({"rule": rule, "fig": fid, "ids": sorted(set(ids)),
                    "said": said, "fix": fix})

    # N1 a mark / value label that states something that is not a given
    for c in cons:
        if not c.get("marked") or c.get("violated") or \
                c.get("type") == "hidden_edge":
            continue
        mids = [m for m in ([c.get("mark_id")] + list(c.get("mark_ids") or
                                                      [])) if m]
        if canon(c) in carried:
            covered_marks.update(mids)
            add("N6-goal-marked", mids or [fid],
                "%s marks %s, the result of an earlier item (from_item) -- "
                "the starting figure is shared with the item that proves it"
                % (fid, _say(_claim_of(c))),
                _knob(c.get("type")) + " -- the later item keeps it as a "
                "given with from_item")
            continue
        ok = _src(c) == "given" or canon(c) in gkeys or \
            _shape_cover(c, shapes) or _mid_cover(c, given)
        if ok:
            covered_marks.update(mids)
            continue
        if _src(c) == "to_prove":
            covered_marks.update(mids)       # refused by the to_prove rule
            continue
        cl = _claim_of(c)
        add("N1-mark-not-given", mids or [fid],
            "%s marks %s, which is not a given of %s"
            % (fid, _say(cl), where),
            "if the question STATES it, declare it -- given=[%s] on %s%s "
            "-- and the drawing, its numbers and marks stay as they are; "
            "otherwise %s (the fact stays in the figure's constraints as "
            "derived)" % (json.dumps(cl, ensure_ascii=False), where,
                          " (or the shape it defines: {'type': 'shape', "
                          "'points': [...], 'value': 'rectangle'})"
                          if c.get("type") in ("perpendicular", "angle",
                                               "parallel") else "",
                          _knob(c.get("type"))))
        covered_marks.update(mids)
    # N2 a mark object no constraint accounts for
    for sid, (b, o) in by_id.items():
        if o.get("role") != "mark":
            continue           # a number line's ticks are its data
        kind = o.get("kind")
        if kind not in MARK_KINDS or sid in covered_marks:
            continue
        if kind == "dimension":
            continue     # a dimension with no number names an unknown
        vx = str(o.get("name") or "")
        hit = False
        for g in given or []:
            if isinstance(g, dict) and vx and vx in names_in(g) and \
                    kind in ("arc", "right_angle"):
                hit = True
        if not hit and kind in ("ticks", "parallel") and \
                isinstance(o.get("svg_xy"), list) and \
                len(o["svg_xy"]) == 2:
            a, bb = [tuple(p) for p in o["svg_xy"]]
            for g in given or []:
                if not isinstance(g, dict):
                    continue
                for nm in (g.get("of") if isinstance(g.get("of"), list)
                           else [g.get("of")]):
                    t = toks(nm)
                    if len(t) == 2 and t[0] in pts and t[1] in pts:
                        P, Q = pts[t[0]], pts[t[1]]
                        if {_r(P), _r(Q)} == {_r(a), _r(bb)}:
                            hit = True
        if hit:
            continue
        add("N2-mark-states-no-given", [sid],
            "%s draws a %s mark (%s) that states no given of %s"
            % (fid, kind, sid, where),
            "declare the fact it marks in `given` if the question states "
            "it (the figure keeps its data), otherwise %s" % _knob(None,
                                                                   kind))
    # N3 helper / guide lines: dashed strokes
    hidden = set()
    for c in cons:
        if c.get("type") == "hidden_edge":
            o = seg_obj(fig, c.get("of"))
            if o:
                hidden.add(o.get("svg_id"))
                hidden.update(o.get("ink_svg_id") or [])
            hidden.add("seg-%s" % "".join(toks(c.get("of"))))
    ok_dash = set()
    for d in dashed or []:
        o = seg_obj(fig, d)
        ok_dash.add(str(d))
        if o:
            ok_dash.add(o.get("svg_id"))
    bad = [(i, el) for i, el in dashed_elements(svg)
           if not (i in hidden or i in ok_dash)]
    if bad:
        add("N3-helper-line", [i or "(no id)" for i, _e in bad],
            "%s draws %d dashed stroke(s) that are not hidden edges of a "
            "solid (%s): helper / guide / projection lines are not part of "
            "the starting figure" % (fid, len(bad), ", ".join(
                sorted(set(i or "(no id)" for i, _e in bad))[:6])),
            "drop them from the build -- plane(..., dashed=...) guides, "
            "stubs to the axes, projection lines, helper columns -- the "
            "points, their coordinates and every number stay in the figure "
            "and in noam-ai.json; a line that is DATA is drawn solid; if the "
            "question itself calls the line dashed, declare dashed=['<name>'] "
            "on the question")
    # N4 colour
    col = colour_faults(svg)
    if col:
        add("N4-colour", [i for i, _v in col],
            "%s paints %d element(s) off the ink / grey palette (%s)"
            % (fid, len(col), ", ".join("%s=%s" % x for x in col[:4])),
            "draw in the house ink (#111) and greys only -- a colour is "
            "never a hint; the objects and their ids stay")
    # N5 an object the student constructs is already drawn
    for c in to_construct or []:
        if not isinstance(c, dict):
            continue
        drawn = _drawn(fig, c)
        if drawn:
            add("N5-construct-drawn", drawn,
                "%s already draws %s, which %s asks the student to "
                "construct" % (fid, _say(_claim_of(c)), where),
                "leave it out of the starting figure (the rest of the "
                "figure and its data stay); if a step needs it, draw it in "
                "an aux figure whose step is exactly this construction")
    # N6 a mark of what is to be proved (deliver refuses it separately;
    # listed here so a report is complete)
    tkeys = set(canon(t) for t in to_prove or [] if isinstance(t, dict))
    for c in cons:
        if c.get("marked") and (_src(c) == "to_prove" or canon(c) in tkeys):
            add("N6-goal-marked", [m for m in [c.get("mark_id")] if m] or
                [fid], "%s marks %s, which is to be proved"
                % (fid, _say(_claim_of(c))),
                _knob(c.get("type")) + " -- the claim stays in to_prove")
    return out


def _r(p):
    return (round(p[0]), round(p[1]))


def _drawn(fig, c):
    """svg ids of the figure that already ARE the to_construct object c."""
    by_id, by_name, _p = _obj_index(fig)
    t = c.get("type")
    if t in ("segment", "line", "ray"):
        o = seg_obj(fig, c.get("of"))
        if o:
            return [o["svg_id"]]
        nm = "".join(toks(c.get("of")))
        for b in ("lines", "rays"):
            for key in (nm, nm[::-1]):
                o = by_name.get((b, key))
                if o:
                    return [o["svg_id"]]
        return []
    if t == "point":
        nm = str(c.get("point") or c.get("of"))
        o = by_name.get(("points", nm))
        return [o["svg_id"]] if o else []
    if t == "polygon":
        P = toks(c.get("points") or c.get("of"))
        for (b, nm), o in by_name.items():
            if b == "polygons" and sorted(toks(nm)) == sorted(P):
                return [o["svg_id"]]
        return []
    if t == "circle":
        nm = str(c.get("circle") or c.get("of"))
        o = by_name.get(("circles", nm))
        return [o["svg_id"]] if o else []
    # a relation to construct (a parallel through E, a perpendicular from
    # C): it is already drawn when EVERY segment it names is drawn
    segs = c.get("of") if isinstance(c.get("of"), list) else []
    got = [seg_obj(fig, s) for s in segs]
    if segs and all(got):
        return [o["svg_id"] for o in got]
    return []


def _say(c):
    t = c.get("type")
    of = c.get("of")
    if t == "equal_length":
        return " = ".join(map(str, of or []))
    if t == "parallel":
        return u" \u2225 ".join(map(str, of or []))
    if t == "perpendicular":
        return u" \u22a5 ".join(map(str, of or []))
    if t == "length":
        return "%s = %s" % ("".join(toks(of)), c.get("value"))
    if t == "angle":
        return u"\u2220%s%s%s = %s" % (
            (c.get("rays") or ["?", "?"])[0], c.get("at"),
            (c.get("rays") or ["?", "?"])[-1], c.get("value"))
    if t == "equal_angle":
        return " = ".join(u"\u2220%s" % (
            "".join([x["rays"][0], x["at"], x["rays"][1]])
            if isinstance(x, dict) else str(x)) for x in of or [])
    if t == "midpoint":
        return "%s midpoint of %s" % (c.get("point"), "".join(toks(of)))
    if t in OBJECT_TYPES:
        return "%s %s" % (t, "".join(toks(c.get("of") or c.get("point") or
                                          c.get("points") or
                                          c.get("circle"))))
    return "%s %s" % (t, json.dumps(dict((k, v) for k, v in c.items()
                                         if k != "type"),
                                    ensure_ascii=False))


# --------------------------------------------------------- given_marks ----
_MARK_OF = {"equal_length": "ticks", "midpoint": "ticks",
            "equal_angle": "arc", "parallel": "parallel",
            "perpendicular": "right_angle", "length": "length",
            "angle": "arc"}


def given_marks(fig, given_rows):
    """§4: [{claim, mark, n, svg_ids, item}] -- how each GIVEN of this
    figure is marked when Noam AI shows the student ("הראה לי איך מסמנים את
    הנתונים"). Built ONLY from the givens; never drawn in the PDF or SVG.
    given_rows: [(claim dict, item id or None)]."""
    by_id, by_name, _p = _obj_index(fig)
    out = []
    count = {}

    def pid(n):
        o = by_name.get(("points", str(n)))
        return o["svg_id"] if o else None

    def sid(s):
        o = seg_obj(fig, s)
        if o:
            return [o["svg_id"]]
        return [x for x in (pid(p) for p in toks(s)) if x]

    for c, item in given_rows:
        if not isinstance(c, dict):
            continue
        t = c.get("type")
        mk = _MARK_OF.get(t)
        if mk is None:
            continue
        ids = []
        if t == "midpoint":
            P = str(c.get("point"))
            A, B = (toks(c.get("of")) + ["", ""])[:2]
            ids = sid(A + P) + sid(P + B)
        elif t in ("equal_length", "parallel", "perpendicular"):
            for s in c.get("of") or []:
                ids += sid(s)
            if t == "perpendicular" and c.get("at"):
                ids += [x for x in [pid(c.get("at"))] if x]
        elif t == "length":
            ids = sid(c.get("of"))
        elif t == "angle":
            ids = [x for x in [pid(c.get("at"))] +
                   [pid(r) for r in c.get("rays") or []] if x]
            if abs(float(_num(c.get("value")) if not isinstance(
                    _num(c.get("value")), str) else 0) - 90) < 1e-6:
                mk = "right_angle"
        elif t == "equal_angle":
            for a in c.get("of") or []:
                at, rays = cang(a)
                ids += [x for x in [pid(at)] + [pid(r) for r in rays] if x]
        if not ids:
            continue
        row = {"claim": _claim_of(c), "mark": mk, "svg_ids": ids}
        if mk in ("ticks", "arc", "parallel"):
            count[mk] = count.get(mk, 0) + 1
            row["n"] = count[mk]
        if t in ("length", "angle") and c.get("value") is not None:
            row["value"] = c.get("value")
        if item:
            row["item"] = item
        out.append(row)
    return out


# ------------------------------------------------------------------ hints --
_VERB_C = u"(?:העבירו|העבר|סרטטו|סרטט|שרטטו|בנו|בנה|הורידו|הוריד|חברו|חבר|" \
          u"קבעו|סמנו את הנקודה|המשיכו|הארכו)"
_REL = re.compile(u"((?:\u2220\\s*)?[A-Z][A-Z0-9\u2032']{1,3})\\s*"
                  u"(=|\u2225|\u22a5|\\|\\||\u2245)\\s*"
                  u"((?:\u2220\\s*)?[A-Z][A-Z0-9\u2032']{1,3}|\\d+(?:[.,]\\d+)?)")


def _norm(s):
    s = str(s or "")
    for a, b in ((u"\\angle", u"\u2220"), (u"\\parallel", u"\u2225"),
                 (u"\\perp", u"\u22a5"), (u"\\cong", u"\u2245"),
                 (u"\\|", u"\u2225"), (u"^\\circ", u"\u00b0"),
                 (u"^{\\circ}", u"\u00b0")):
        s = s.replace(a, b)
    s = re.sub(r"\\text\{([^}]*)\}", r"\1", s)
    return re.sub(u"[\\s${}]+", "", s)


def relations_in(text):
    """Relations written in a text ('AM = MB', 'AB ∥ CD', '∠A = ∠B') as
    claim dicts."""
    out = []
    s = _norm(text).replace("||", u"\u2225")
    for m in _REL.finditer(s):
        a, op, b = m.groups()
        if op == "=" and re.match(r"^\d", b):
            if a.startswith(u"\u2220"):
                t = toks(a)
                if len(t) == 3:
                    out.append({"type": "angle", "at": t[1],
                                "rays": [t[0], t[2]], "value": b})
            elif len(toks(a)) == 2:
                out.append({"type": "length", "of": a, "value": b})
            continue
        if a.startswith(u"\u2220") or b.startswith(u"\u2220"):
            if op == "=":
                out.append({"type": "equal_angle",
                            "of": [a.lstrip(u"\u2220"),
                                   b.lstrip(u"\u2220")]})
            continue
        if len(toks(a)) != 2 or len(toks(b)) != 2:
            continue
        t = {"=": "equal_length", u"\u2225": "parallel",
             u"\u22a5": "perpendicular"}.get(op)
        if t:
            out.append({"type": t, "of": [a, b]})
    have = set(canon(r) for r in out)
    return out + [r for r in worded_values(text) if canon(r) not in have]


# r2 S3: a length / angle value written in words ('אורך AB הוא 10 ס"מ',
# 'הזווית ABC שווה ל-40°', 'AB אורכו 10')
_NUMW = u"(\\d+(?:[.,]\\d+)?)"
_L = u"(?<![A-Za-z])([A-Z][0-9]*[\u2032']?[A-Z][0-9]*[\u2032']?)(?![A-Za-z0-9])"
_A = u"(?<![A-Za-z])\u2220?\\s*([A-Z][0-9]*[\u2032']?[A-Z][0-9]*[\u2032']?" \
     u"[A-Z][0-9]*[\u2032']?)(?![A-Za-z0-9])"
_IS = u"\\s*(?:הוא|היא|שווה\\s*ל\\s*[-\u05be]?|שווים\\s*ל\\s*[-\u05be]?|=)\\s*"
_WLEN = [re.compile(u"אורך\\s+(?:ה?קטע\\s+|ה?צלע\\s+)?" + _L + _IS + _NUMW),
         re.compile(_L + u"\\s+(?:אורכו|אורכה|באורך)\\s*(?:של\\s*|הוא\\s*|"
                    u"היא\\s*)?" + _NUMW),
         re.compile(u"(?:ה?קטע|ה?צלע)\\s+" + _L + _IS + _NUMW)]
_WANG = [re.compile(u"(?:גודל\\s+)?ה?זווית\\s+" + _A + _IS + _NUMW),
         re.compile(_A + u"\\s+(?:גודלה|שווה\\s*ל\\s*[-\u05be]?)\\s*" + _NUMW)]


def worded_values(text):
    """length / angle claims a text states in words (r2 S3)"""
    t = plain(text)
    t = re.sub(r"\\text\{([^}]*)\}", r"\1", t).replace("$", " ")
    out, seen = [], set()
    for rx in _WLEN:
        for a, v in rx.findall(t):
            if len(toks(a)) == 2 and (a, v) not in seen:
                seen.add((a, v))
                out.append({"type": "length", "of": a,
                            "value": v.replace(",", ".")})
    for rx in _WANG:
        for a, v in rx.findall(t):
            p = toks(a)
            if len(p) == 3 and (a, v) not in seen:
                seen.add((a, v))
                out.append({"type": "angle", "at": p[1],
                            "rays": [p[0], p[2]],
                            "value": v.replace(",", ".")})
    return out


def restates(text, c):
    """does `text` state the claim c -- written out, as a relation, in
    words, or ('המשולש MDC שווה שוקיים') as the isosceles triangle whose two
    legs c says are equal (r2 M2)?"""
    if not isinstance(c, dict):
        return False
    t = plain(text)
    k = canon(c)
    if k is not None and any(canon(r) == k for r in relations_in(t)):
        return True
    if paraphrase_of(t, c):
        return True
    if c.get("type") == "equal_length" and \
            re.search(u"שווה.?שוקיים|שוות.?שוקיים", t):
        sg = [toks(x) for x in c.get("of") or []]
        if len(sg) == 2 and all(len(x) == 2 for x in sg):
            P = set(sg[0]) | set(sg[1])
            if len(set(sg[0]) & set(sg[1])) == 1 and len(P) == 3:
                return any(set(toks(r)) == P and len(toks(r)) == 3
                           for r in _RUN.findall(t))
    return False


def _numbers(s):
    return set(x.replace(",", ".") for x in
               re.findall(u"(?<![\\w.])-?\\d+(?:[.,]\\d+)?(?![\\w.])",
                          str(s or "").replace(u"\u2212", "-")))


# the words that state a relation in prose (r1 M2: a hint that names BOTH
# objects of the claim with one of these words states the claim, "=" or not)
_SAME_W = u"שוו|שווה|זהים|זהות|זהה|אותו אורך|אותו גודל|באותו|כמו|חופפ|" \
    u"אורכם|=|≅"
_SAY_W = {"equal_length": _SAME_W, "equal_angle": _SAME_W,
          "parallel": u"מקביל|∥|\\|\\|",
          "perpendicular": u"מאונך|מאונכ|ניצב|אנך|⊥|90|ישר",
          "midpoint": u"אמצע|חוצה|מחלק|שוו",
          "shape": u"מלבן|ריבוע|מקבילית|מעוין|טרפז|דלתון|משולש|שווה.?שוקיים"}
_RUN = re.compile(u"(?<![A-Za-z])((?:[A-Z][0-9]*[\u2032\u2033']*)+)"
                  u"(?![A-Za-z])")


def _text_objects(text):
    """{segment keys, angle keys, runs} a text names, in any wording."""
    out = set()
    for run in _RUN.findall(str(text or "")):
        t = toks(run)
        out.add(("run", "".join(sorted(t))))
        if len(t) == 2:
            out.add(("seg",) + tuple(sorted(t)))
        if len(t) == 3:
            out.add(("ang", t[1]) + tuple(sorted((t[0], t[2]))))
        if len(t) == 1:
            out.add(("pt", t[0]))
    return out


def _claim_objects(c):
    """the objects a claim relates, in _text_objects' keys (None: this
    reading cannot list them)"""
    t = c.get("type")
    if t in ("equal_length", "parallel", "perpendicular"):
        of = c.get("of") or []
        o = [("seg",) + tuple(sorted(toks(x))) for x in of]
        return set(o) if len(o) == 2 and all(len(x) == 3 for x in o) \
            else None
    if t == "equal_angle":
        o = set()
        for a in c.get("of") or []:
            at, rays = cang(a)
            if not at or len(rays) != 2:
                return None
            o.add(("ang", at) + tuple(sorted(rays)))
        return o or None
    if t == "midpoint" and c.get("point"):
        return set([("pt", str(c["point"])),
                    ("seg",) + tuple(sorted(toks(c.get("of"))))])
    if t == "shape" and c.get("points"):
        return set([("run", "".join(sorted(toks(c["points"]))))])
    return None


DASH_WORDS = re.compile(u"מקו+קו|קו+קו|מרוסק")
# v6.12 fix_r2: "הקו המקווקו" / "הישר המקווקו" -- one unnamed dashed line
THE_DASHED_LINE = re.compile(u"ה(?:קו|ישר) ה(?:מקו+קו|מרוסק)(?![א-ת])")
UNNAMED_SEG = re.compile(r"^seg-(?![A-Z])[0-9a-z]+$")


def native_locus_dashes(svg, public, fid, object_map, visible_text):
    """License only the measured stroke of a source-stated parameter locus.

    Pure public data + XML; no renderer, private layout, answer or engine
    checker is consulted. This does not grant arbitrary native element ids
    permission to be dashed. Each accepted id must bind its own printed
    clause, fixed coordinate, whole mapped locus and measured axis geometry.
    """
    import xml.etree.ElementTree as ET
    from fractions import Fraction
    def normal(s):return ' '.join(s.replace('$', '').split()) if isinstance(s, str) else ''
    def number(s):return Fraction(str(s))
    try:
        fig = next(f for f in public.get('figures', []) if f.get('id') == fid)
        loci = fig.get('loci')
        if not isinstance(loci, list) or not loci:return set()
        frame = fig.get('frame') or {}
        if frame.get('family') != 'coordinate_plane' or frame.get('sketch') or fig.get('data') or fig.get('graph'):return set()
        tree = ET.fromstring(svg)
        if tree.get('data-dialect') != 'wspec-coord-svg/1':return set()
        elements = list(tree.iter())
        if any(any(k in e.attrib for k in ('transform', 'style')) for e in elements):return set()
        ids = [e.get('id') for e in elements if e.get('id')]
        if len(ids) != len(set(ids)):return set()
        byid = {e.get('id'): e for e in elements if e.get('id')}
        texts, owners, printed = {}, {}, set()
        for q in public.get('questions', []):
            for row in [q] + q.get('items', []):
                texts[row['id']] = normal(row.get('text')); owners[row['id']] = q['id']
                for block in row.get('bound', []):
                    printed.update(block.get('prints', []))
                    for bind in block.get('bind', []):
                        fact = bind.get('fact'); printed.update(fact if isinstance(fact, list) else [fact] if fact else [])
        question = owners[fig['scope']]
        facts = {f['id']: f for f in public.get('facts', [])}
        entities = {e['id']: e for e in public.get('entities', [])}
        def axis_map(axis):
            letter = axis['axis'].split(':')[1]; n = axis['intervals']
            if not isinstance(n, int) or n < 1 or axis.get('break_before'):raise ValueError('invalid locus axis')
            pix = []
            for i in range(n + 1):
                hits = [e for e in elements if e.get('data-grid') == '%s %d' % (letter, i)]
                # Native grids omit the stroke already drawn by the crossing
                # axis. Only an explicitly printed zero licenses that axis
                # as this grid position; no assumed origin or scale.
                if not hits and any(j == i and number(v) == 0 for j,v in axis['labels']):
                    other = 'y' if letter == 'x' else 'x'
                    hits = [e for e in elements if e.get('data-axis') == other]
                if not hits:raise ValueError('unmeasured grid')
                # A grid stroke may have real gaps for label/dot clearance.
                # Every surviving piece must lie on the same measured line.
                at = []
                for el in hits:
                    if el.tag.split('}')[-1] != 'line':raise ValueError('not a grid stroke')
                    k = 'x' if letter == 'x' else 'y'
                    a, b = float(el.get(k+'1')), float(el.get(k+'2'))
                    if abs(a-b) > .05:raise ValueError('grid not axis aligned')
                    at.append(a)
                if max(at)-min(at) > .05:raise ValueError('split grid pieces disagree')
                pix.append(at[0])
            scale = (pix[-1]-pix[0])/n
            if not scale or (letter == 'x') != (scale > 0) or any(abs(p-(pix[0]+i*scale)) > .05 for i,p in enumerate(pix)):raise ValueError('inconsistent grid scale')
            labels = axis['labels']
            if len(labels) < 2:raise ValueError('no printed scale')
            i0,v0 = labels[0]; i1,v1 = labels[-1]; v0,v1 = number(v0),number(v1)
            step = (v1-v0)/(i1-i0)
            if step <= 0 or any(number(v) != v0+(i-i0)*step for i,v in labels):raise ValueError('inconsistent public scale')
            for i,v in labels:
                hits = [e for e in elements if e.get('data-num') == '%s %d' % (letter,i) or number(v) == 0 and e.get('data-num') == 'origin']
                if len(hits) != 1 or hits[0].tag.split('}')[-1] != 'text' or number((hits[0].text or '').replace('−','-')) != number(v):raise ValueError('scale number not printed')
            return n, lambda v: float(i0+(number(v)-v0)/step), lambda i: pix[0]+float(i)*scale
        axes = {a['axis']:axis_map(a) for a in frame['axes']}
        accepted = set()
        for row in loci:
            if not isinstance(row,dict) or set(row) != {'id','point','variable','coordinate_fact','domain','source','example'}:continue
            if not all(isinstance(row.get(k),str) for k in ('id','point','variable','coordinate_fact')) or not isinstance(row['example'],bool):continue
            fact=facts.get(row['coordinate_fact'],{});args=fact.get('args') or []
            point=entities.get(row['point'],{});variable=entities.get(row['variable'],{})
            if fact.get('id') not in printed or fact.get('role') != 'given' or fact.get('rel') != 'coordinate' or len(args)!=2 or args[0]!=row['point'] or args[1] not in axes or owners.get(fact.get('item'))!=question or point.get('kind')!='point' or variable.get('kind')!='variable':continue
            fixed=args[1]; free='axis:y' if fixed=='axis:x' else 'axis:x'
            source=row['source'];dom=row['domain']
            if not isinstance(source,dict) or set(source)!={'scope','text'} or not isinstance(source.get('scope'),str) or owners.get(source['scope'])!=question:continue
            clause=normal(source.get('text'))
            if not clause or clause not in texts.get(source['scope'],'') or clause not in normal(visible_text) or 'מקווקו' not in clause:continue
            pair=[variable['name'],str(fact['value'])] if fixed=='axis:y' else [str(fact['value']),variable['name']]
            if not re.search(re.escape(point['name'])+r'\s*\(\s*'+re.escape(pair[0])+r'\s*,\s*'+re.escape(pair[1])+r'\s*\)',clause):continue
            if not isinstance(dom,dict) or set(dom)!={'lo','lo_in'} or number(dom['lo'])!=0 or dom['lo_in'] is not True or not re.search(r'\b'+re.escape(variable['name'])+r'\b.*אינו שלילי',clause):continue
            oid='line:'+fixed.split(':')[1]+'='+str(fact['value'])
            obj=(object_map.get('objects') or {}).get(oid,{})
            parts=obj.get('parts') or []
            if object_map.get('figure')!=fid or obj.get('kind')!='line' or len(parts)!=1 or parts[0].get('span')!='whole':continue
            sid=parts[0].get('element');el=byid.get(sid)
            if el is None or el.tag.split('}')[-1]!='line' or el.get('data-locus')!=row['id'] or el.get('stroke-dasharray')!='3 3':continue
            items=[i for i in object_map.get('display_items',[]) if sid in i.get('elements',[])]
            if len(items)!=1 or items[0].get('role')!='parameter_locus' or items[0].get('source')!={'entity':oid} or (object_map.get('elements',{}).get(sid) or {}).get('item')!=items[0].get('id'):continue
            n,idx,px=axes[fixed]; fn,fidx,fpx=axes[free]
            at=idx(fact['value']);lo=max(0,fidx(dom['lo']))
            if not 0<=at<=n or not lo<fn:continue
            fixedpx=px(at);aa=fpx(lo);bb=fpx(fn)
            want=[(aa,fixedpx),(bb,fixedpx)] if fixed=='axis:y' else [(fixedpx,aa),(fixedpx,bb)]
            actual=[(float(el.get('x1')),float(el.get('y1'))),(float(el.get('x2')),float(el.get('y2')))]
            if not any(all(abs(x-y)<=.3 for p,q in zip(actual,ordered) for x,y in zip(p,q)) for ordered in (want,want[::-1])):continue
            accepted.add(sid)
        return accepted
    except (KeyError,ValueError,TypeError,ZeroDivisionError,StopIteration,ET.ParseError,IndexError):
        return set()


def says_dashed(text, name):
    """does the text itself call `name` (BD, seg-BD) dashed? The name must
    be written in the text and the text must use a dashed word (r1 S4)"""
    t = sorted(toks(re.sub(r"^[a-z]+-", "", str(name or ""))))
    if not DASH_WORDS.search(str(text or "")):
        return False
    # v6.12 fix_r2 (mD): an UNNAMED line the text calls "הקו המקווקו" (the
    # dashed line, definite, singular) -- declared by its svg id, since it
    # has no letters to write (T08 c q12: P(t,5) moves along the dashed line)
    if UNNAMED_SEG.match(str(name or "")):
        return bool(THE_DASHED_LINE.search(str(text or "")))
    if not t:
        return False
    return any(sorted(toks(r)) == t for r in _RUN.findall(str(text or "")))


def step_names(step, c):
    """does an aux step's text name the construction c (its object's
    letters, in either order)? completes=True is honoured only then"""
    t = sorted(names_in(_claim_of(c)))
    return bool(t) and any(sorted(toks(r)) == t
                           for r in _RUN.findall(str(step or "")))


def paraphrase_of(text, c):
    """True when `text` names every object of claim `c` together with a word
    that states c's relation ('הקטעים MD ו-MC באותו אורך')."""
    objs = _claim_objects(c) if isinstance(c, dict) else None
    w = _SAY_W.get((c or {}).get("type")) if isinstance(c, dict) else None
    if not objs or not w:
        return False
    return objs <= _text_objects(text) and bool(re.search(w, str(text)))


# r2 S1: a full-width 'ＭＤ = ＭＣ' or a bidi mark reads as the plain text
_BIDI = re.compile(u"[\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]")


def plain(s):
    """NFKC and no bidi / zero-width marks: what a reader of the hint sees"""
    return _BIDI.sub("", unicodedata.normalize("NFKC", str(s or "")))


# r2 S1: the claim said with NO point name ('two segments from the midpoint
# of the top side are equal'): a noun for the claim's objects together with
# a word for its relation is REVIEW (a human reads it)
_NOUN_W = {"equal_length": u"קטע|צלע|אורך|אורכ",
           "equal_angle": u"זווית|זוויות",
           "parallel": u"קטע|צלע|ישר|קו",
           "perpendicular": u"קטע|צלע|ישר|קו",
           "midpoint": u"נקוד|קטע|צלע",
           "shape": u"משולש|מרובע|צור"}
_REL_W = {"equal_length": u"שוו|זהים|זהות|זהה|אותו אורך|אותו גודל|חופפ",
          "equal_angle": u"שוו|זהות|זהים|זהה|אותו גודל|חופפ",
          "parallel": u"מקביל",
          "perpendicular": u"מאונך|מאונכ|ניצב|ישרה|90",
          "midpoint": u"אמצע|חוצה|מחלק",
          "shape": u"מלבן|ריבוע|מקבילית|מעוין|טרפז|דלתון|שווה.?שוקיים|"
                   u"שווה.?צלעות|ישר.?זווית"}


def says_unnamed(text, c):
    """does a text say claim c's relation about unnamed objects of its
    kind (r2 S1)?"""
    t = (c or {}).get("type") if isinstance(c, dict) else None
    if t not in _NOUN_W:
        return False
    return bool(re.search(_NOUN_W[t], text)) and \
        bool(re.search(_REL_W[t], text))


def hint_verdict(text, to_prove=(), to_construct=(), answer=None,
                 question_text="", exposure=0, hint_type=None):
    """('ok' | 'decisive' | 'review', why). A hint that states what is to be
    proved, the final answer or the complete construction is DECISIVE (it
    is refused); one this reading cannot settle is REVIEW (a human decides,
    it is never auto-approved)."""
    if not text or not str(text).strip():
        return "ok", "no hint text"
    text = plain(text)
    n = _norm(text)
    tp = [c for c in to_prove or [] if isinstance(c, dict)]
    keys = set(canon(c) for c in tp)
    for c in tp:
        if c.get("text") and len(_norm(plain(c["text"]))) >= 3 and \
                _norm(plain(c["text"])) in n:
            return "decisive", "it states the claim to be proved (%s)" \
                % c["text"]
    for r in relations_in(text):
        if canon(r) in keys:
            return "decisive", "it states the claim to be proved (%s)" \
                % _say(r)
    for c in tp:
        if paraphrase_of(text, c):
            return "decisive", "it states the claim to be proved in words " \
                "(%s)" % (c.get("text") or _say(_claim_of(c)))
    if answer is not None and str(answer).strip():
        a = _norm(answer)
        if len(a) >= 2 and a in n:
            return "decisive", "it contains the answer (%s)" % answer
        new = _numbers(answer) - _numbers(question_text)
        hit = sorted(new & _numbers(text))
        if hit:
            return "decisive", "it contains the answer's number(s) %s" % hit
    for c in to_construct or []:
        if not isinstance(c, dict):
            continue
        nm = "".join(toks(c.get("of") or c.get("point") or
                          c.get("points") or c.get("circle")))
        if nm and re.search(_VERB_C, str(text)) and \
                (nm in n or nm[::-1] in n):
            return "decisive", "it names the whole construction (%s)" \
                % _say(_claim_of(c))
        # r2 M1: 'חברו את A עם C' -- every point of the construction named
        # apart, with a construction verb, is the whole construction too
        pts = set(toks(c.get("of") or c.get("point") or c.get("points") or
                       c.get("circle")))
        if len(pts) >= 2 and re.search(_VERB_C, str(text)) and \
                pts <= set(toks(text)):
            return "decisive", "it names every point of the construction " \
                "(%s: %s) with a construction verb" % (
                    _say(_claim_of(c)), ", ".join(sorted(pts)))
    why = []
    if exposure is not None and int(exposure) >= 3:
        why.append("exposure 3 (strong)")
    if hint_type == "construction":
        why.append("a construction hint")
    names = set()
    for c in tp:
        names.update(names_in(c))
    said = set(toks(text))
    if len(names & said) >= 2:
        # it names two or more of the claim's points: whether it leaves the
        # inference to the student is a human's call (r1 M2)
        why.append("it names %s of the claim's points"
                   % ", ".join(sorted(names & said)))
    # r2 M1: the same for the points of an object to construct
    cn = set()
    for c in to_construct or []:
        if isinstance(c, dict):
            cn.update(names_in(c))
    if len(cn & said) >= 2:
        why.append("it names %s of the construction's points"
                   % ", ".join(sorted(cn & said)))
    # r2 S1: the claim's relation said about unnamed objects
    for c in tp:
        if says_unnamed(text, c):
            why.append("it may state the claim in words without naming "
                       "its points (%s)" % (c.get("text") or
                                            _say(_claim_of(c))))
            break
    if len(str(text).split()) > 25:
        why.append("longer than 25 words")
    if why:
        return "review", "; ".join(why)
    return "ok", "no decisive step found"


# ------------------------------------------------------------- curriculum --
_TRACK_OF_GRADE = {"7": u"ז", "8": u"ח", "9": u"ט_רגילה"}
_GRADE_LETTER = {u"ז": "7", u"ח": "8", u"ט": "9"}


def load_tools(path=None):
    with open(path or TOOLS_FILE, encoding="utf-8") as fh:
        return json.load(fh)


class CurriculumError(ValueError):
    pass


def curriculum_block(spec, grade=None, reg=None):
    """The package's `curriculum` block from its declaration
    {'topic': 'rectangle', 'track': 'ט_רגילה' (default by grade),
     'narrow': [tool ids to keep]}: grade, track, topic, unit, position and
    the tools taught up to here (allowed_tools) and after
    (not_yet_allowed), each as {id, name}."""
    reg = reg or load_tools()
    spec = dict(spec or {})
    g = str(spec.get("grade") or grade or "").strip()
    g = _GRADE_LETTER.get(g, g).replace("G", "")
    track = spec.get("track") or _TRACK_OF_GRADE.get(g)
    if track not in reg["sequences"]:
        raise CurriculumError(
            "track %r is not an official sequence (%s)"
            % (track, ", ".join(sorted(reg["sequences"]))))
    seq = reg["sequences"][track]
    topic = spec.get("topic")
    pos = [k for k, s in enumerate(seq) if s["topic"] == topic and
           s["track"] == track] or \
        [k for k, s in enumerate(seq) if s["topic"] == topic]
    if not pos:
        raise CurriculumError(
            "topic %r is not in the %s sequence (%s)"
            % (topic, track, ", ".join(s["topic"] for s in seq
                                        if s["track"] == track)))
    p = pos[-1]
    here = seq[p]
    place = dict(((s["track"], s["topic"]), k) for k, s in enumerate(seq))
    excluded = set()
    for ex in (reg.get("excluded") or {}).get(track, []):
        excluded.update(ex.get("tools") or [])
    allowed, later = [], []
    for t in reg["tools"]:
        firsts = [place[(u["track"], u["topic"])] for u in t["units"]
                  if (u["track"], u["topic"]) in place]
        row = {"id": t["id"], "name": t["name_he"]}
        if t["id"] in excluded or not firsts:
            later.append(row)
        elif min(firsts) <= p:
            allowed.append(row)
        else:
            later.append(row)
    narrow = spec.get("narrow")
    if narrow is not None:
        ids = set(r["id"] for r in allowed)
        extra = [x for x in narrow if x not in ids]
        if extra:
            raise CurriculumError(
                "narrow names tool(s) not taught by %s/%s: %s"
                % (track, topic, ", ".join(extra[:6])))
        keep = set(narrow)
        later = [r for r in allowed if r["id"] not in keep] + later
        allowed = [r for r in allowed if r["id"] in keep]
    return {"grade": here["grade"], "track": track, "topic": topic,
            "unit": here["unit"], "position": p,
            "allowed_tools": allowed, "not_yet_allowed": later}


def tools_named_in(text, reg=None, ids=None):
    """Tool ids whose keywords occur in a text (a hint, an aux step)."""
    reg = reg or load_tools()
    out = []
    s = str(text or "")
    for t in reg["tools"]:
        if ids is not None and t["id"] not in ids:
            continue
        if any(k and k in s for k in t.get("keywords") or []):
            out.append(t["id"])
    return out


def aux_limit(n_questions):
    """How many questions of a sheet may carry an aux figure (~10%)."""
    return max(1, int(math.floor(AUX_SHARE * n_questions + 0.5)))
