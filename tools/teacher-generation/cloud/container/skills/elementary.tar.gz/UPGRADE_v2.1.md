# שדרוג v2.0.1 → v2.1

## התקנה
פרסו את תוכן ה-ZIP על תיקיית הסקיל הקיימת (מיזוג, לא החלפה):

```
hebrew-math-worksheet-elementary/
  SKILL.md                              ← עודכן
  assets/worksheet_template_elementary.html  ← עודכן (תיקון bidi)
  references/components-plus.md         ← חדש
  scripts/svg_elementary_ext.py         ← חדש
  scripts/ws_html.py                    ← חדש
  scripts/lib/house_gates.py            ← חדש
  scripts/tests/run_tests.sh            ← עודכן (מבחנים 4–6)
```

אימות אחרי ההתקנה:
```
bash scripts/tests/run_tests.sh
```
צריך להדפיס `ALL REGRESSION TESTS PASS` (שישה מבחנים).

**אין שינוי שובר.** `svg_elementary.py`, `content_truth.py`,
`gates_runner.py`, `check_worksheet.py` ו-`build_pdf.py` לא נגעו בהם.
דפים קיימים ממשיכים להיבנות כרגיל.

## מה נוסף ולמה

### 1. `scripts/svg_elementary_ext.py` — 11 רכיבים
נדרשו בפועל בייצור 16 דפים לכיתה ג׳ ולא היו בסקיל:

| רכיב | הפער |
|---|---|
| `column_shown` | `vertical_problem` מחשב את התוצאה בעצמו ומדפיס תמיד את **הנכונה** — ולכן אי אפשר לשרטט איתו "איתור טעות", שהקטלוג דורש כמעט בכל יחידת פעולות חשבון |
| `column_borrow` + `borrow_state` + `n_borrow_ops` | **המחשת פריטה** בחיסור. לסקיל היה `carry="auto"` לחיבור בלבד |
| `column_missing` | ספרה מוסתרת — "שאלה הפוכה" |
| `blank_column(bottom=)` | רשת ריקה; `bottom` משאיר שורה עליונה ריקה כדי ששלב שני בשרשרת לא יחשוף את הראשון |
| `bar_model` | תרשים רצועות לבעיה מילולית — לא היה כלל |
| `split_array` | פירוק גורם בכפל |
| `group_model` | קבוצות לחילוק, לשני המובנים |
| `unequal_shape` | חלוקה **לא שווה** — המסיח של "חלקים שווים" בשברים |
| `frac_line` | ישר 0–1 עם תוויות שבר מדורגות |

### 2. `scripts/ws_html.py` — עוזרי HTML
`keyed` `lettered_items` `frac` `steps_box` `steps_line` `mul_grid`
`figrow` `ltr` `blank` `fmt` `plain` ועוד.
מרכזים מוסכמות bidi שנכתבו בכל דף מחדש — ובכל פעם נשברו אחרת.

### 3. `scripts/lib/house_gates.py` — ארבעה שערים חוסמים
כללים שהיו כתובים ב-references ולא נאכפו בקוד:

| שער | הכלל | מה קרה בלעדיו |
|---|---|---|
| **G50** | ★ 2–4 לדף (`style.md` §5) | 8 מתוך 12 דפים חרגו, עד 9 בדף |
| **G51** | סדר תווים ב-bidi | `(1)` התרנדר `)1(` בדף אחד ולא באחר — אותו קוד |
| **G52** | ראיה שחותמת על עצמה | `L.claim(..., (True, x))` עוברת תמיד, מוכיחה אפס |
| **G53** | שרטוט בלי מקור SVG | `figs=[...]` שנשכח; G37 נכשל רק באריזה |

```
python3 scripts/lib/house_gates.py --html sheet.html --pdf sheet.pdf --gen gen.py
```

### 4. תיקון בתבנית
`td.qn` בעמוד התשובות הדפיס `.1` במקום `1.` — הנקודה תו ניטרלי בתא RTL.
בעמוד התלמיד `::before` כבר טיפל בזה; בעמוד התשובות לא.

### 5. `references/components-plus.md`
כל המלכודות שנתפסו בייצור: מוסכמת ההמרה (מעל העמודה **הבאה**),
`_cells` והפסיק, מלכודת המיקום בין `.figure` ל-`table.drill`,
חמישה ניחושי מנייה שכולם היו שגויים, וכשלים שנשארים באחריות הקורא.

## מבחן מקצה-לקצה
`e2e_demo/` — דף שנבנה **רק** מן הסקיל המשודרג. עבר:
content_truth · G42/G43/G45/G46 · G50–G53 · 0 סוגריים הפוכים.
(שער העימוד מסמן אותו כדף דליל — זו הדגמה בת 6 שאלות, לא דף מסירה.)
