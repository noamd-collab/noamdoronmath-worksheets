# מתכון הפקת PDF עברי — צינור מאושר בלבד (יסודי)

**כלל השרטוטים:** איורים מותרים רק בדפי גיאומטריה או גיאומטריה אנליטית,
בשאלות וברמזים. בדפים אחרים משתמשים בטקסט ובטבלאות, גם לחשבון במאונך.
הוראות SVG להלן חלות על איורים מותרים; תמיכת המנוע אינה היתר לחרוג מהכלל.

## אסור

- Pandoc→LaTeX מכל סוג (pdflatex / xelatex / tectonic / lualatex) — גופני
  Latin Modern חסרי עברית → U+FFFD ותיבות ריקות.
- KaTeX/MathJax מבוססי JS — מתפרקים בהדפסה.
- כל צינור שאינו מטמיע גופן עברי מלא.

## מאושר

1. HTML עם `dir="rtl"` מבוסס `assets/worksheet_template_elementary.html`.
2. גופן: **David Libre מצורף לסקיל** (שלושה TTF ב-`assets/`) דרך
   `@font-face` בתבנית. `build_pdf.py` מעתיק את הגופנים אוטומטית לתיקיית
   ה-HTML לפני הבנייה — אל תסירו את ההעתקה. David Libre ממקם ניקוד נכון
   (GPOS, נבדק) — קריטי לא׳–ב׳.
3. המרה: `python3 scripts/build_pdf.py input.html output.pdf`
   (WeasyPrint; גיבוי: Chromium headless עם `--user-data-dir` זמני).
4. סמלים ש-David Libre חסר (`★ ° ←`) — עטופים `span.sym` (מוצמד ל-DejaVu
   בתבנית). לעולם לא לתת לשרשרת ה-fallback לבחור לבד (G45).

## הגדרות עמוד

- A4, שוליים 1.6/1.8/2 ס"מ; מוגדר בתבנית.
- **מותג רץ — חובה (שער חוסם):** המחרוזת המדויקת `מתמטיקה · נועם דורון`
  (U+00B7, רווח מכל צד) ב-@top-center וב-@bottom-center של כל עמוד, ועוד
  `בס״ד` ב-@top-right. מוגדר בתבנית — אין להסיר ואין לשנות את המחרוזת.

## באגים ידועים במנועי הרינדור (נתפסו בפועל)

- **WeasyPrint:** `<ol start="N">` + `break-inside: avoid` ⇒ מספור שבור.
  פתרון: CSS counter גלובלי (`counter(qnum)` בתבנית) — המספור ממשיך
  אוטומטית בין מקטעים ועמודים. אין `start=` ואין `::marker`.
- **WeasyPrint + `dotted` (G47):** קו מנוקד לרוחב מתפרק לפעולת ציור לכל
  נקודה — 3.34MB→0.35MB נמדד אחרי מעבר ל-`dashed`. לעולם לא `dotted` על
  קו מלא-רוחב; `repeating-linear-gradient` אינו תחליף (נעלם ברינדור).
  תקרות: PDF טקסט ≤ ~500KB; ZIP מסירה ≤ 30MB.
- **WeasyPrint וניקוד כפול ב־David Libre:** `build_pdf.py` מתקן מיפויי
  `ToUnicode` ריקים או משולבים לפי הגופן המצורף, כאשר הדפוס הפגום נמצא.
  התיקון נוגע לחילוץ הטקסט, לא לציור הגליפים. נדרשים `pymupdf` ו־`fonttools`;
  ממשיכים לבדוק ניקוד חזותית ואת הטקסט שחולץ מה־PDF.
- **Chromium:** `::marker` עם content לא מרונדר; נעילת פרופיל תוקעת בנייה
  שנייה 180 שניות — `build_pdf.py` פותח פרופיל זמני ייעודי.
- **SVG בעמוד RTL:** `<text>` יורש כיוון מהעמוד ⇒ `+5` הופך `5+`.
  `svg_elementary.py` מוסיף `direction="ltr" unicode-bidi="embed"` לכל
  טקסט — אם כותבים SVG ידני, לחזור על זה.
- **רוחב שורת רכיבים ≤ 650px (חוסם):** גלישה מעבר לרוחב התוכן גורמת
  להשמטת גליפים שקטה בתא השמאלי (נמדד). מצמצמים cell/font או שוברים שורה.

## תלויות (להתקין פעם אחת בתחילת סשן)

```
python -m pip install 'weasyprint>=66' pymupdf
```
`weasyprint` — הבנייה; `pymupdf` — שערי G45/G46 (בלעדיו gates_runner מדווח
SKIPPED, ושער שדולג = כשל בנייה). `pdftotext`/`pdftoppm`/`pdffonts`
(poppler-utils) מותקנים כרגיל.

מתקינים בסביבה וירטואלית. בגרסה 1.0.5 נבדקו WeasyPrint 66 עם Python 3.9
ו־WeasyPrint 70 עם Python 3.12. WeasyPrint 62.3 נכשל בבדיקת סדר הסעיפים
בפלט PDF; אין להסיק מתאימות תחביר Python שגם מנוע רינדור ישן תקין.

## שערי מסירה (סדר ריצה)

1. `python3 scripts/lib/content_truth.py --work . --quiet` — אמת תוכן
   (Ledger מלא, band מ-meta).
2. `python3 scripts/build_pdf.py sheet.html sheet.pdf` — בנייה.
3. `python3 scripts/check_worksheet.py sheet.pdf preview/ --band elementary`
   (א׳–ב׳: `--band elementary-ab`) — גופנים, מותג בכל עמוד, סימנים, עימוד,
   רינדור PNG.
4. `python3 -c "import sys; sys.path.insert(0,'scripts/lib'); from gates_runner import run_output_gates; run_output_gates(['sheet.pdf'], strict=True)"`
   — G43 (סריקת גליפים אסורים על טקסט ה-PDF) + G45 (זהות גופן: David Libre
   מודלי) + G46 (מיקום שרטוטים בתוך הקנבס). שער שדולג = כשל בנייה.
5. **עיון חזותי בכל PNG** — ניקוד לא צף (א׳–ב׳), אין חיתוכים, ★ במקום,
   פסיקי אלפים צמודים, ואיורים גאומטריים קריאים. חובה לפני מסירה.
