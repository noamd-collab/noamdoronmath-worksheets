#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""דוגמת תאימות היסטורית; אינה דף תלמיד לפי מדיניות השרטוטים הנוכחית."""
import json, os, sys
S = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path[:0] = [f"{S}/scripts", f"{S}/scripts/lib"]
import svg_elementary as se
import svg_elementary_ext as sx
import ws_html as H
from content_truth import Ledger, add_col, sub_col, mul_col, div_qr

OUT = os.path.dirname(os.path.abspath(__file__))
L = Ledger(f"{OUT}/verified.json")
qs, figs = [], []

def q(n, html, ans, claims, star=False):
    for st, ev, m in claims:
        L.claim(n, st, ev, method=m)
    qs.append({"n": n, "html": html, "ans": ans, "star": star})

# 1 — פריטה עם המחשה (הרכיב שלא היה קיים)
work, changed = sx.borrow_state(452, 137)
ex = sx.column_borrow(452, 137, answer=True); figs.append(("q1.svg", ex))
q("1", "כך פותרים: " + H.ltr("452 − 137") + H.fig(ex) +
     "<div class='sub'>איזו ספרה נפרטה ומה ערכה החדש?</div>"
     '<div class="ansline"></div>',
  "פורטים עשרת אחת מתוך " + H.ltr("5") + " העשרות: נשארות "
  + H.ltr("4") + " עשרות, ו־" + H.ltr("2") + " האחדות הופכות ל־"
  + H.ltr("12") + " אחדות.",
  [("452 − 137 = 315", (sub_col(452,137)==315, 315), "closed_form"),
   ("מצב הפריטה [4,4,12]", (work==[4,4,12], work), "figure_assert")], star=True)

# 2 — איתור טעות (דורש תוצאה שגויה מודפסת)
wr = sx.column_shown(452, 137, 325, op="−"); figs.append(("q2.svg", wr))
q("2", "רוני פתרה כך:" + H.fig(wr) +
     "<div class='sub'>בדקו ותקנו.</div><div class=\"ansline\"></div>",
  "לא ; " + H.ltr("452 − 137 = 315"),
  [("325 שגוי; ההפרש 10", (sub_col(452,137)==315 and 325-315==10, 10),
    "closed_form")], star=True)

# 3 — שורת שרטוטים ממותגת אותיות + מפתח ממותג
cols = [(587,243),(769,426),(685,152)]
sv = [se.vertical_problem(a,b,op="−",answer="blank",cell=30) for a,b in cols]
figs += [(f"q3_{i+1}.svg", s) for i,s in enumerate(sv)]
q("3", "פתרו בטור:" + H.figrow(sv),
  H.keyed([H.fmt(a-b) for a,b in cols]),
  [(f"{a} − {b}", (sub_col(a,b)==a-b, a-b), "closed_form") for a,b in cols])

# 4 — מספור באותיות (ולא בסוגריים שמתהפכים)
items = [H.ltr("2,341 + 1,225"), H.ltr("1,458 + 2,317")]
q("4", "אילו תרגילים יש בהם המרה באחדות?<br>" + H.lettered_items(items),
  "סעיף ב",
  [("מנייה: רק ב-ב יש המרה באחדות",
    ([i for i,(a,b) in enumerate([(2341,1225),(1458,2317)])
      if (a%10)+(b%10)>=10] == [1], [1]), "enumeration")])

# 5 — בעיה עם פיגום שלבים ויחידות
q("5", "בספרייה 385 ספרים, הושאלו 147. כמה נשארו?" + H.steps_line(),
  H.ltr("385 − 147 = 238") + " ספרים",
  [("385 − 147 = 238", (sub_col(385,147)==238, 238), "closed_form")])

# 6 — שבר מדורג + מודל כמותי
g = sx.group_model(4, 3); figs.append(("q6.svg", g))
q("6", H.ltr("12") + " עיגולים ב-" + H.ltr("4") + " קבוצות שוות:" + H.fig(g) +
     "<div class='sub'>" + H.frac(1,4) + " מ-" + H.ltr("12") + " הוא "
     + H.blank("1.8cm") + "</div>",
  H.ltr("3"),
  [("רבע מ-12 הוא 3", (div_qr(12,4)==(3,0) and mul_col(4,3)==12, 3),
    "closed_form")], star=True)

L.save()

tpl = open(f"{S}/assets/worksheet_template_elementary.html", encoding="utf8").read()
head = tpl.split("<body",1)[0]
body = ['<body class="band-gd">',
        '<div class="unit">דוגמת תאימות היסטורית</div><hr class="unit-rule">',
        '<div class="subtitle">פריטה · איתור טעות · אותיות סעיף · שברים · רמה ב׳</div>',
        '<div class="details"><span>שם: ____________________</span>'
        '<span>כיתה: ________</span><span>תאריך: __________</span></div>',
        '<ol class="questions">']
for x in qs:
    c = ' class="starred"' if x["star"] else ""
    st = '<span class="star"></span> ' if x["star"] else ""
    # Keep the two technical exercise pages balanced; otherwise q6 sits alone
    # on a near-empty page and fails the PDF page-fill gate.
    page_break = ' style="break-before:page"' if x["n"] == "4" else ""
    body.append(f'<li{c}{page_break}>{st}{x["html"]}</li>')
body.append("</ol>")
body.append('<div class="goodluck">בהצלחה!</div>')
rows = "".join(f'<tr><td class="qn"><span class="ltr">{x["n"]}.</span></td>'
               f'<td>{x["ans"]}</td></tr>' for x in qs)
body.append('<div class="answers"><h2>תשובות סופיות</h2>'
            '<div class="note">התשובות מיועדות לבדיקה עצמית אחרי הפתרון. '
            'ייתכנו תשובות נוספות בסעיפים הפתוחים.</div>'
            f'<table class="ans">{rows}</table>'
            '<div class="teacher-notes">הערות המורה:<div class="tline"></div>'
            '<div class="tline"></div><div class="tline"></div></div></div>')
open(f"{OUT}/sheet.html","w",encoding="utf8").write(head + "\n".join(body) + "\n</body>\n</html>\n")

os.makedirs(f"{OUT}/figures", exist_ok=True)
for name, svg in figs:
    open(f"{OUT}/figures/{name}","w",encoding="utf8").write(
        '<?xml version="1.0" encoding="UTF-8"?>\n' + svg)

json.dump({"meta":{"band":"elementary","grade":"ג","level":"ב",
                   "topic":"דוגמת תאימות היסטורית"},
           "questions":[{"n":x["n"],"text":H.plain(x["html"]),
                         "answer":H.plain(x["ans"])} for x in qs]},
          open(f"{OUT}/content.json","w",encoding="utf8"),
          ensure_ascii=False, indent=1)
print(f"{len(qs)} שאלות, {len(L.entries)} טענות, {len(figs)} שרטוטים")
