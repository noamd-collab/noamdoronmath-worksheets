#!/usr/bin/env python3
"""build_pdf.py — HTML עברי RTL → PDF, צינור מאושר בלבד.

שימוש:  python3 build_pdf.py input.html output.pdf

סדר עדיפויות: WeasyPrint (אם מותקן) ← Chromium headless.
אסור: pandoc/LaTeX (גופנים חסרי עברית).
"""
import shutil
import subprocess
import sys
from pathlib import Path


FONTS = ("DavidLibre-Regular.ttf", "DavidLibre-Bold.ttf", "DavidLibre-Medium.ttf")


def ensure_fonts(html: Path) -> None:
    """מעתיק את גופני David Libre מה-assets של הסקיל אל תיקיית ה-HTML
    (ה-@font-face בתבנית מפנה לשם הקובץ בלבד). G45 דורש ש-David Libre
    יישא את הגוף — בלי ההעתקה ה-fallback ישתלט והשער יחסום."""
    assets = Path(__file__).resolve().parent.parent / "assets"
    for f in FONTS:
        src, dst = assets / f, html.parent / f
        if src.exists() and not dst.exists():
            shutil.copy(src, dst)


def _fix_weasyprint_tounicode(pdf: Path) -> None:
    """מתקן באג ב-ToUnicode CMap של WeasyPrint בעברית מנוקדת (David Libre):
    כאשר אות נושאת שני סימני ניקוד (כגון קמץ+דגש או חיריק+נקודת שׁ), Pango מצמיד
    את שני תווי היוניקוד לגליף הראשון ומשאיר את הגליף השני עם מיפוי ריק `<>`,
    מה שגורם ל-pdftotext/pymupdf לפרש את ה-GID הגולמי (כגון 0x02FC, 0x0309) כתו יוניקוד זר.
    מאחר ש-CIDToGIDMap הוא Identity, אנו משלימים כל מיפוי מרובה/ריק ב-David Libre ליוניקוד המדויק מה-cmap."""
    try:
        import re
        import pymupdf
        from fontTools.ttLib import TTFont
    except ImportError:
        return

    assets = Path(__file__).resolve().parent.parent / "assets"
    font_maps = {}
    for fname, key in (
        ("DavidLibre-Regular.ttf", "David-Libre"),
        ("DavidLibre-Bold.ttf", "David-Libre-Bold"),
        ("DavidLibre-Medium.ttf", "David-Libre-Medium"),
    ):
        fpath = assets / fname
        if fpath.is_file():
            tt = TTFont(str(fpath))
            go = tt.getGlyphOrder()
            font_maps[key] = {go.index(g): c for c, g in tt.getBestCmap().items()}

    if not font_maps:
        return

    doc = pymupdf.open(str(pdf))
    changed = False
    for xref in range(1, doc.xref_length()):
        obj = doc.xref_object(xref)
        if "/ToUnicode" not in obj or "David-Libre" not in obj:
            continue
        m_tu = re.search(r"/ToUnicode\s+(\d+)\s+0\s+R", obj)
        if not m_tu:
            continue
        tu_xref = int(m_tu.group(1))
        if not doc.xref_is_stream(tu_xref):
            continue
        gmap = (
            font_maps.get("David-Libre-Bold") if "David-Libre-Bold" in obj else
            font_maps.get("David-Libre-Medium") if "David-Libre-Medium" in obj else
            font_maps.get("David-Libre")
        )
        if not gmap:
            continue
        raw = doc.xref_stream(tu_xref).decode("latin1")
        if "<>" not in raw:
            continue

        def _repl(m):
            gid_hex, target_hex = m.group(1), m.group(2)
            if target_hex == "" or len(target_hex) > 4:
                gid = int(gid_hex, 16)
                u = gmap.get(gid)
                if u is not None:
                    return f"<{gid_hex}> <{u:04x}>"
            return m.group(0)

        fixed = re.sub(r"<([0-9a-fA-F]{4})>\s*<([0-9a-fA-F]*)>", _repl, raw)
        if fixed != raw:
            doc.update_stream(tu_xref, fixed.encode("latin1"))
            changed = True

    if changed:
        tmp = pdf.with_suffix(".tmp.pdf")
        doc.save(str(tmp))
        doc.close()
        tmp.replace(pdf)
    else:
        doc.close()


def build_with_weasyprint(html: Path, pdf: Path) -> bool:
    import os
    try:
        if Path("/opt/homebrew/lib").is_dir() and "/opt/homebrew/lib" not in os.environ.get("DYLD_FALLBACK_LIBRARY_PATH", ""):
            # On macOS Silicon, cffi/dlopen inside a running process needs DYLD_FALLBACK_LIBRARY_PATH
            # set before process start; run a tiny subprocess with DYLD_FALLBACK_LIBRARY_PATH=/opt/homebrew/lib
            env = dict(os.environ)
            env["DYLD_FALLBACK_LIBRARY_PATH"] = "/opt/homebrew/lib:" + env.get("DYLD_FALLBACK_LIBRARY_PATH", "")
            r = subprocess.run(
                [sys.executable, "-c",
                 "import sys; from weasyprint import HTML; HTML(sys.argv[1]).write_pdf(sys.argv[2])",
                 str(html), str(pdf)],
                env=env, capture_output=True, text=True, timeout=120
            )
            if r.returncode == 0 and pdf.exists():
                _fix_weasyprint_tounicode(pdf)
                return True
        from weasyprint import HTML  # noqa
        HTML(str(html)).write_pdf(str(pdf))
        _fix_weasyprint_tounicode(pdf)
        return True
    except Exception as e:
        print(f"[build_pdf] weasyprint not usable: {e}", file=sys.stderr)
        return False


def build_with_chromium(html: Path, pdf: Path) -> bool:
    mac_chrome = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
    chromium = (
        shutil.which("chromium")
        or shutil.which("chromium-browser")
        or shutil.which("google-chrome")
        or (mac_chrome if Path(mac_chrome).is_file() else None)
    )
    if not chromium:
        return False
    # פרופיל זמני ייעודי לכל בנייה — בלי זה, אם מופע chromium קודם נתקע,
    # נעילת הפרופיל משביתה את כל הבנייה הבאה (timeout 180s). נתפס בפועל.
    import tempfile
    profile = tempfile.mkdtemp(prefix="chrome_pdf_")
    cmd = [
        chromium, "--headless", "--disable-gpu", "--no-sandbox",
        "--no-pdf-header-footer",
        f"--user-data-dir={profile}",
        f"--print-to-pdf={pdf.resolve()}",
        str(html.resolve()),
    ]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
    except subprocess.TimeoutExpired:
        print(f"[build_pdf] chromium timed out (180s)", file=sys.stderr)
        return False
    finally:
        shutil.rmtree(profile, ignore_errors=True)
    if r.returncode != 0 or not pdf.exists():
        print(f"[build_pdf] chromium failed: {r.stderr[:500]}", file=sys.stderr)
        return False
    return True


def main() -> int:
    if len(sys.argv) != 3:
        print(__doc__)
        return 2
    html, pdf = Path(sys.argv[1]), Path(sys.argv[2])
    if not html.exists():
        print(f"[build_pdf] input not found: {html}", file=sys.stderr)
        return 2
    ensure_fonts(html)
    ok = build_with_weasyprint(html, pdf) or build_with_chromium(html, pdf)
    if not ok:
        print("[build_pdf] FAILED: no working pipeline (install weasyprint or chromium)",
              file=sys.stderr)
        return 1
    print(f"[build_pdf] OK -> {pdf} ({pdf.stat().st_size} bytes)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
