# -*- coding: utf-8 -*-
"""Deterministic model-space rotation for elementary pure geometry.

Only ``pure_geometry.py`` imports this module.  Functional components such as
number lines, clocks, column arithmetic and charts deliberately have no
rotation parameter.
"""

from __future__ import annotations

import math
from typing import Iterable, Sequence, Tuple

Point = Tuple[float, float]

_ROT = (0, 21, -17, 34, -28, 12, 47, -39, 25, -11, 38, -22, 16, -33, 29)
_ROT_AB = (0, 12, -15, 10, -12, 15, 0, -10, 14, -13)


def _grade_key(grade: str | None) -> str | None:
    if grade is None:
        return None
    value = str(grade).strip().replace("כיתה", "").strip()
    for mark in ("׳", "'", "’", "‘", "`", '"', "״"):
        value = value.replace(mark, "")
    return value.strip()


def rot_for(n: int, grade: str | None = None) -> int:
    """Stable rotation; ``א``, ``א׳`` and ``כיתה א׳`` are equivalent."""
    seq = _ROT_AB if _grade_key(grade) in {"א", "ב"} else _ROT
    return seq[int(n) % len(seq)]


def _as_point(p: Sequence[float]) -> Point:
    if len(p) != 2:
        raise ValueError(f"point must have two coordinates, got {p!r}")
    return float(p[0]), float(p[1])


class ModelTransform:
    def __init__(self, w=210, h=150, pad=16, rot=0.0) -> None:
        self.rot = float(rot)
        self.w, self.h = float(w), float(h)
        self.pad = float(pad) + (5.0 if self.rot else 0.0)
        self._ready = False

    def _rot_model(self, p: Sequence[float]) -> Point:
        if not self._ready:
            raise RuntimeError("fit(points) must run before points are transformed")
        x, y = _as_point(p)
        ux, uy = x - self.cx, y - self.cy
        return (
            self.cx + ux * self.cs - uy * self.sn,
            self.cy + ux * self.sn + uy * self.cs,
        )

    def fit(self, pts: Iterable[Sequence[float]]) -> "ModelTransform":
        model = [_as_point(p) for p in pts]
        if not model:
            raise ValueError("fit(points) requires at least one point")
        if not all(math.isfinite(v) for p in model for v in p):
            raise ValueError("all model coordinates must be finite")
        self.cx = sum(p[0] for p in model) / len(model)
        self.cy = sum(p[1] for p in model) / len(model)
        th = math.radians(self.rot)
        self.cs, self.sn = math.cos(th), math.sin(th)
        self._ready = True
        rp = [self._rot_model(p) for p in model]
        xs, ys = [p[0] for p in rp], [p[1] for p in rp]
        self.x0, self.x1 = min(xs), max(xs)
        self.y0, self.y1 = min(ys), max(ys)
        bw = max(self.x1 - self.x0, 1e-9)
        bh = max(self.y1 - self.y0, 1e-9)
        if self.rot:
            inner_w = max(self.w - 2 * self.pad, 1.0)
            wanted = 2 * self.pad + inner_w * bh / bw
            self.h = min(max(wanted, 86.0), 250.0)
        inner_w, inner_h = self.w - 2 * self.pad, self.h - 2 * self.pad
        if inner_w <= 0 or inner_h <= 0:
            raise ValueError("padding leaves no drawable canvas")
        self.scale = min(inner_w / bw, inner_h / bh)
        used_w, used_h = self.scale * bw, self.scale * bh
        self.ox = self.pad + (inner_w - used_w) / 2
        self.oy = self.pad + (inner_h - used_h) / 2
        return self

    def tx(self, p: Sequence[float]) -> Point:
        qx, qy = self._rot_model(p)
        return (
            self.ox + self.scale * (qx - self.x0),
            self.h - (self.oy + self.scale * (qy - self.y0)),
        )

    def label_offset(self, dx=0, dy=0) -> Point:
        if not self.rot:
            return float(dx), float(dy)
        th = math.radians(-self.rot)
        cs, sn = math.cos(th), math.sin(th)
        return dx * cs - dy * sn, dx * sn + dy * cs


__all__ = ["ModelTransform", "Point", "rot_for"]
