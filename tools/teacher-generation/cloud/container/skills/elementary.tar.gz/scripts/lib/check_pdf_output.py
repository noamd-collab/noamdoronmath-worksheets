#!/usr/bin/env python3
"""check_pdf_output.py — G43: forbidden-glyph sweep on the FINAL PDF text.

מטאטא קודפוינטים על הטקסט המחולץ מה-PDF הבנוי. סוגר את השכבה שאף שער אחר
לא סורק בפלט:

FAIL (blocking):
  F1  vulgar-fraction glyphs  ½ ⅓ ¼ …  (U+00BC–BE, U+2150–215F, U+2189).
      G14 proves stacked fractions EXIST; it does not prove no glyph-fraction
      ALSO shipped.
  F2  root glyphs  √ ∛ ∜  (U+221A–221C). Roots ship as SVG paths ⇒ ANY root
      codepoint in the extracted text is a leaked vinculum-less glyph. This is
      the non-vacuous closing brace G40(a) admits it lacks (its HTML lint
      passes vacuously under SVG rendering).
  F3  U+FFFD replacement chars.
  F4  Hebrew sanity floor: ≥ 50 Hebrew codepoints, else extraction/build broken.
  F5  pdffonts: ≥ 1 EMBEDDED Hebrew-capable font (David/FreeSerif/Noto/
      DejaVu/… — subset prefixes ABCDEF+ handled). pdffonts missing ⇒
      WARN-skip; the text half still blocks.

WARN (eyeball, never auto-fix):
  W1  מ״ר / מ״ק present — meters, or a leaked cm²/cm³ mislabel? unit chain is
      ס״מ → סמ״ר → סמ״ק.
  W2  zero ★ in the text — G11 passes VACUOUSLY on a sheet that lost its stars.
  W3  digit/digit — inline-fraction suspicion (dates rare on these sheets).

Deliberate NON-scope (owned elsewhere, do not duplicate):
  ÷ and digit:digit  → G42 render half (context-aware: ratio/scale/clock).
  hidden bidi/controls → G7.   fraction STRUCTURE → G14.   vinculum ink → G40(b).

Usage:
    python3 check_pdf_output.py out1.pdf [out2.pdf ...]
    python3 check_pdf_output.py --selftest      # regression, both directions

Exit: 0 = all PDFs pass, 1 = any FAIL, 2 = usage / missing extractor.
"""
import re
import shutil
import subprocess
import sys
from pathlib import Path

HEB_RE = re.compile(r"[\u0590-\u05FF]")
VULGAR_RE = re.compile("[\u00bc\u00bd\u00be\u2150-\u215f\u2189]")
ROOT_RE = re.compile("[\u221a\u221b\u221c]")
FFFD_RE = re.compile("\ufffd")
# מ״ר / מ״ק standalone — with Hebrew gershayim U+05F4 or ASCII quote.
# Negative lookbehind: סמ״ר/סמ״ק (cm²/cm³) and קמ״ר (km²) are legitimate
# units and must NOT trigger — the Kimi fork's version had this false hit.
METERS_RE = re.compile('(?<![סק])מ[\u05f4"][רק]')
SLASH_FRAC_RE = re.compile(r"\d\s*/\s*\d")
HEB_FONT_RE = re.compile(
    r"David|FreeSerif|FreeSans|Noto|DejaVu|Frank|Miriam|Hadas|Rubik|Alef|"
    r"Heebo|Assistant|Arial", re.I)
HEB_MIN = 50
STAR = "\u2605"


# ---------------------------------------------------------------- extraction
def extract_pages(pdf: Path):
    """Text per page. pdftotext (\\f separators) preferred; pypdf fallback.
    Returns list[str] or None if no extractor is available."""
    if shutil.which("pdftotext"):
        r = subprocess.run(["pdftotext", "-enc", "UTF-8", str(pdf), "-"],
                           capture_output=True, text=True, timeout=120)
        if r.returncode == 0:
            return r.stdout.split("\f")
    try:
        from pypdf import PdfReader
        return [(p.extract_text() or "") for p in PdfReader(str(pdf)).pages]
    except Exception:
        return None


def _hits(rx: re.Pattern, pages) -> list:
    """[(page_no_1based, sorted-unique-chars-or-samples)] per page with hits."""
    out = []
    for i, pg in enumerate(pages, 1):
        found = rx.findall(pg)
        if found:
            out.append((i, "".join(sorted(set(found)))[:12]))
    return out


# ------------------------------------------------------------------- scans
def scan_text(pages) -> tuple[list, list]:
    """Pure text scan → (fails, warns). PDF-independent: selftest runs this."""
    fails, warns = [], []
    txt = "\f".join(pages)

    h = _hits(VULGAR_RE, pages)
    if h:
        fails.append(f"F1 vulgar-fraction glyphs {h} — fractions are STACKED "
                     f"structures (G14), never single glyphs")
    h = _hits(ROOT_RE, pages)
    if h:
        fails.append(f"F2 root glyphs {h} — roots ship as SVG paths; a root "
                     f"codepoint in extracted text = leaked vinculum-less glyph")
    h = _hits(FFFD_RE, pages)
    if h:
        fails.append(f"F3 U+FFFD on pages {[p for p, _ in h]}")
    n_heb = len(HEB_RE.findall(txt))
    if n_heb < HEB_MIN:
        fails.append(f"F4 only {n_heb} Hebrew codepoints (<{HEB_MIN}) — "
                     f"extraction or build broken")

    m = _hits(METERS_RE, pages)
    if m:
        warns.append(f"W1 מ״ר/מ״ק on pages {[p for p, _ in m]} — verify METERS "
                     f"intended (chain: ס״מ→סמ״ר→סמ״ק)")
    if STAR not in txt:
        warns.append("W2 zero ★ in extracted text — G11 passes vacuously; "
                     "verify starred questions exist and rendered")
    s = _hits(SLASH_FRAC_RE, pages)
    if s:
        warns.append(f"W3 digit/digit on pages {[p for p, _ in s]} — inline-"
                     f"fraction suspicion, eyeball it")
    return fails, warns


def scan_fonts(pdf: Path) -> tuple:
    """(ok, is_warn_only, msg). pdffonts missing ⇒ warn-skip."""
    if not shutil.which("pdffonts"):
        return True, True, "F5 pdffonts missing — font half SKIPPED (warn)"
    out = subprocess.run(["pdffonts", str(pdf)], capture_output=True,
                         text=True, timeout=60).stdout
    lines = [l for l in out.splitlines() if l.strip()][2:]
    if not lines:
        return False, False, "F5 pdffonts lists no fonts"
    emb_heb = [l for l in lines
               if len(l.split()) >= 5 and l.split()[-5] == "yes"
               and HEB_FONT_RE.search(l)]
    if not emb_heb:
        return False, False, ("F5 no EMBEDDED Hebrew-capable font "
                              f"({len(lines)} fonts listed)")
    name = emb_heb[0].split()[0]
    return True, False, f"F5 Hebrew-capable font embedded ({name})"


# ------------------------------------------------------------------- driver
def check_pdf(pdf: Path) -> bool:
    print(f"— G43 {pdf.name} —")
    pages = extract_pages(pdf)
    if pages is None:
        print("FAIL — no text extractor (install poppler-utils or pypdf); "
              "a delivery gate must RUN, not vanish")
        return False
    fails, warns = scan_text(pages)
    f_ok, f_warn, f_msg = scan_fonts(pdf)
    if not f_ok:
        fails.append(f_msg)
    elif f_warn:
        warns.append(f_msg)
    else:
        print(f"PASS — {f_msg}")
    for m in fails:
        print(f"FAIL — {m}")
    for m in warns:
        print(f"WARN — {m}")
    if not fails:
        print(f"PASS — text sweep clean ({sum(len(p) for p in pages)} chars, "
              f"{len(pages)} page(s))")
    return not fails


GOOD = ["מתמטיקה · נועם דורון — דף עבודה כיתה ז׳. " + STAR + " 15. חשבו את "
        "שטח המלבן שמידותיו 6 ס\u05f4מ ו-4 ס\u05f4מ. תשובה: 24 סמ\u05f4ר. "
        + "בהצלחה! " + "אבגדהוזחטיכלמנסעפצקרשת" * 3]
BAD = ["דף פגום: ½ מהתלמידים, √50, נפח 12 מ\u05f4ק, וגם \ufffd וגם 3/4."]


def selftest() -> int:
    rc = 0
    f, w = scan_text(GOOD)
    w1_fp = any(m.startswith("W1") for m in w)   # סמ״ר must not trigger W1
    if not f and not w1_fp:
        print("PASS selftest good clean (incl. no W1 on סמ״ר)")
    else:
        print(f"FAIL selftest good: fails={f} W1-false-positive={w1_fp}")
        rc = 1
    f, w = scan_text(BAD)
    codes = " ".join(sorted(m.split()[0] for m in f))
    want = {"F1", "F2", "F3", "F4"}
    got = {m.split()[0] for m in f}
    wgot = {m.split()[0] for m in w}
    if want <= got and {"W1", "W3"} <= wgot:
        print(f"PASS selftest bad blocked ({codes})")
    else:
        print(f"FAIL selftest bad slipped: got {sorted(got)} warns {sorted(wgot)}")
        rc = 1
    return rc


def main() -> int:
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    if sys.argv[1] == "--selftest":
        return selftest()
    ok_all = True
    for a in sys.argv[1:]:
        p = Path(a)
        if not p.exists():
            print(f"FAIL — not found: {p}")
            ok_all = False
            continue
        ok_all &= check_pdf(p)
    print("=" * 50)
    print("G43: PASS" if ok_all else "G43: FAIL — fix and rebuild, DO NOT deliver")
    return 0 if ok_all else 1


if __name__ == "__main__":
    sys.exit(main())
