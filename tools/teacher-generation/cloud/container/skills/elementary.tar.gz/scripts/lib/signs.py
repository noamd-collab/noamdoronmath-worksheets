#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""signs.py — מקור אמת יחיד לסימני היסודי (v2.2).

הפער שהמודול סוגר: תקן הסימנים היה כתוב ב-`curriculum.md §1` ולא נאכף
ע"י שום קוד. כל דף נכתב ב-f-string ידני (`f"{a} x {b} ="`), ולכן:
  · גליף כפל שגוי (`·` / `×` בג׳–ו׳ / `*` / `X`) עבר בשקט
  · מקף `-` (U+002D) שימש כמינוס במקום `−` (U+2212)
  · `12/4` ו-`3/4` נכתבו כחילוק/שבר בשורה
  · `☐` `⋅` `≠` הודפסו למרות ש**אינם קיימים ב-David Libre** — נפילה
    שקטה לפונט מערכת (נמדד: DavidLibre-Regular.ttf, אוגוסט 2026)

שימוש בבנייה:
    import signs as S
    S.expr(6, "*", 4)            # ג׳ → "6 x 4"   ב׳ → "6 × 4"
    S.expr(20, "/", 5, grade="ב")  # → "20 : 5"
    S.MUL("ג"), S.MINUS, S.DIV
    S.fmt(4562, "ג")             # → "4,562"   (בא׳–ב׳: "4562")
    S.neg(3)                     # → "(3-)"    (ג׳+ בלבד)

שימוש בשער (G54–G59) — `house_gates.py --grade ג`.
"""
import re
import unicodedata

# --------------------------------------------------------------- הגליפים
PLUS = "+"          # U+002B
MINUS = "\u2212"    # U+2212 MINUS SIGN — לא מקף ולא מקף-קצר!
EQ = "="            # U+003D
TIMES_B = "\u00d7"  # U+00D7 — כיתה ב׳ בלבד (סימן הכפל בספרי ב׳)
TIMES_X = "x"       # U+0078 — כיתה ג׳–ו׳ (59 מופעים בדגימה, 0 מופעי ×)
COLON = ":"         # U+003A — סימן החילוק ביסודי, **עם רווחים**
LT, GT = "<", ">"

# מה שאסור לחלוטין, בכל כיתה, גם אם "נראה נכון"
FORBIDDEN_ALWAYS = {
    "\u00f7": "÷ סימן חילוק — ביסודי חילוק הוא `25 : 5`",
    "\u00b7": "· נקודת כפל — זה תקן החטיבה! ביסודי הכפל הוא x (ג׳–ו׳) / × (ב׳)",
    "\u2219": "∙ BULLET OPERATOR — אותה טעות, קודפוינט אחר",
    "\u22c5": "⋅ DOT OPERATOR — **גם חסר ב-David Libre** (נפילת פונט שקטה)",
    "*": "* כוכבית — סימן מקלדת, לא סימן דפוס",
    "\u2217": "∗ ASTERISK OPERATOR",
    "\u2715": "✕ MULTIPLICATION X",
    "\u2716": "✖ HEAVY MULTIPLICATION X",
    "\u2236": "∶ RATIO — נקודתיים ASCII בלבד",
    "\u221a": "√ שורש — לא קיים ביסודי (וגם חסר בפונט)",
    "\u2221": "∡ / ∠ סימון זווית — ביסודי שמות עבריים בלבד",
    "\u2220": "∠ סימון זווית — ביסודי שמות עבריים בלבד",
    "\u2260": "≠ — **חסר ב-David Libre**; נסחו במילים או `<`/`>`",
    "\u2264": "≤ — לא ביסודי",
    "\u2265": "≥ — לא ביסודי",
    # סמלי גאומטריה: אסורים ביסודי **וגם חסרים ב-David Libre** (נמדד)
    "\u2225": "∥ מקבילים — כתבו במילים",
    "\u22a5": "⊥ מאונך — כתבו במילים",
    "\u2245": "≅ חופפים — כתבו במילים",
    "\u2248": "≈ בקירוב — כתבו במילים",
    "\u221b": "∛ שורש — לא קיים ביסודי",
}
VULGAR = "\u00bc\u00bd\u00be\u2150\u2151\u2152\u2153\u2154\u2155\u2156" \
         "\u2157\u2158\u2159\u215a\u215b\u215c\u215d\u215e\u215f\u2189"

# גליפים שהמסמכים מזכירים כקיצור-סימון אך **אסור להדפיס** — חסרים
# ב-DavidLibre-Regular.ttf ולכן נופלים לפונט מערכת בלי אזהרה.
# הפתרון בכל אחד: רכיב מצויר (CSS/SVG), לא תו.
NOT_IN_DAVID_LIBRE = {
    "\u2610": "☐ תיבה ריקה → `H.box()` (span.box מצויר ב-CSS)",
    "\u25a1": "□ ריבוע → `H.box()` או SVG",
    "\u25ad": "▭ מלבן → SVG",
    "\u25cb": "○ עיגול ריק → SVG (`se.ten_frame` / `dot_array`)",
    "\u25cf": "● עיגול מלא → SVG",
    "\u203e": "‾ קו עליון → SVG",
    "\u2011": "‑ מקף לא-שובר → מקף רגיל",
}
# ★ U+2605 חסר אף הוא, אך הוא **תקן בית מאושר** (G50) ומותר ב-fallback
# כי הוא סמל ולא ספרה/אות עברית — ראו G45.
FALLBACK_OK = "\u2605\u2606\u2713\u2717\u2192\u2190"

BRAND = "מתמטיקה \u00b7 נועם דורון"   # ה-U+00B7 היחיד המותר בדף!
BESD = "בס\"ד"

# ---------------------------------------------------------------- הכיתות
GRADES = ("א", "ב", "ג", "ד", "ה", "ו")


def _g(grade):
    """נרמול: 'ג' / 'ג׳' / 3 / 'band-gd' → אות כיתה."""
    if isinstance(grade, int):
        return GRADES[grade - 1]
    s = str(grade).strip().replace("׳", "").replace("'", "")
    if s in GRADES:
        return s
    m = {"elementary-ab": "ב", "band-ab": "ב", "band-gd": "ג", "band-hv": "ה",
         "elementary": "ג"}
    if s in m:
        return m[s]
    raise ValueError(f"signs: כיתה לא מוכרת {grade!r} (א–ו)")


# פרופיל מלא לכל כיתה. **זה מקור האמת** — שינוי כאן משנה גם את
# הבנייה וגם את השערים. אין להעתיק את הטבלה הזאת לשום קובץ אחר.
PROFILE = {
    "א": dict(mul=None, div=None, minus=MINUS, frac=False, thousands=False,
              decimal=False, neg=False, cmp=False, power=False, degree=False,
              money=None, time="words"),
    "ב": dict(mul=TIMES_B, div=COLON, minus=MINUS, frac=False, thousands=False,
              decimal=False, neg=False, cmp=True, power=False, degree=False,
              money="words", time="words"),
    "ג": dict(mul=TIMES_X, div=COLON, minus=MINUS, frac=True, thousands=True,
              decimal=False, neg=True, cmp=True, power=False, degree=False,
              money="שח", time="digital"),
    "ד": dict(mul=TIMES_X, div=COLON, minus=MINUS, frac=True, thousands=True,
              decimal=True, neg=True, cmp=True, power=True, degree=False,
              money="₪", time="digital"),
    "ה": dict(mul=TIMES_X, div=COLON, minus=MINUS, frac=True, thousands=True,
              decimal=True, neg=True, cmp=True, power=True, degree=True,
              money="₪", time="digital"),
    "ו": dict(mul=TIMES_X, div=COLON, minus=MINUS, frac=True, thousands=True,
              decimal=True, neg=True, cmp=True, power=True, degree=True,
              money="₪", time="digital"),
}


def profile(grade):
    return PROFILE[_g(grade)]


def MUL(grade):
    """גליף הכפל של הכיתה. `None` בא׳ (כפל לא קיים)."""
    return profile(grade)["mul"]


def DIV(grade):
    return profile(grade)["div"]


# ------------------------------------------------------------ בניית ביטוי
_OPS = {"+": "plus", "-": "minus", "−": "minus", "*": "mul", "x": "mul",
        "×": "mul", "/": "div", ":": "div", "=": "eq"}


def op(sym, grade):
    """הגליף הנכון לפעולה, לפי הכיתה. קלט סובלני (`*`, `x`, `/`, `-`)."""
    kind = _OPS.get(sym)
    if kind is None:
        raise ValueError(f"signs.op: פעולה לא מוכרת {sym!r}")
    if kind == "plus":
        return PLUS
    if kind == "minus":
        return MINUS
    if kind == "eq":
        return EQ
    g = _g(grade)
    val = PROFILE[g][kind]
    if val is None:
        raise ValueError(
            f"signs.op: פעולת {kind} אסורה בכיתה {g}׳ "
            f"(curriculum.md §2 — בא׳ רק + − = ___ ☐)")
    return val


def fmt(n, grade):
    """מספר עם מפריד אלפים לפי הכיתה: פסיק מ-4 ספרות מג׳; בא׳–ב׳ בלי."""
    return f"{int(n):,}" if profile(grade)["thousands"] else str(int(n))


def neg(n, grade="ג"):
    """מספר שלילי בכתיב הישראלי `(3-)`. ג׳+ בלבד.

    ‼ מלכודת bidi: הסוגריים חייבים לשבת בתוך `span.ltr` אחרת G51
    יתפוס `)3-(`.
    """
    if not profile(grade)["neg"]:
        raise ValueError(f"signs.neg: שליליים אינם בכיתה {_g(grade)}׳ "
                         f"(בב׳ — 'מינוס 5' במילים בלבד)")
    return f"({abs(int(n))}-)"


def expr(a, sym, b, grade="ג", eq=True, tail=""):
    """תרגיל בשורה עם הגליף והרווחים הנכונים:
        expr(6, "*", 4, "ג")  → "6 x 4 ="
        expr(20, "/", 5, "ב") → "20 : 5 ="
        expr(64, "-", 29, "ב", eq=False) → "64 − 29"
    """
    s = f"{fmt(a, grade)} {op(sym, grade)} {fmt(b, grade)}"
    if eq:
        s += " ="
    return s + (f" {tail}" if tail else "")


def chain(parts, grade="ג", eq=True):
    """שרשרת: chain([7,'+',3,'*',5]) → '7 + 3 x 5 ='."""
    out = []
    for p in parts:
        out.append(op(p, grade) if isinstance(p, str) else fmt(p, grade))
    return " ".join(out) + (" =" if eq else "")


# ================================================================ השערים
_TAG = re.compile(r"<[^>]+>")
# ‼ מלכודת שנתפסה בבנייה: סריקת HTML בלי לקלף CSS נותנת מפל התרעות שווא —
# `line-height:1.6` נקרא כעשרוני, `width:100%` כאחוזים, `*{...}` ככוכבית,
# ו-`content:"·"` כנקודת כפל. הסגנון והתגובות מקולפים ראשונים.
_STYLE = re.compile(r"<(style|script)\b[^>]*>.*?</\1>", re.S | re.I)
_COMMENT = re.compile(r"<!--.*?-->", re.S)
_NEG = re.compile(r"\(\s*\d+\s*[-\u2212]\s*\)")        # (3-) לגיטימי
_RANGE = re.compile(r"(?<=\d)[\u2013](?=\d)")           # 21–25 טווח לגיטימי
_TIME = re.compile(r"(?<!\d)([01]?\d|2[0-3]):[0-5]\d(?!\d)")
MUL_LIKE = "\u00b7\u2219\u22c5*\u2217\u00d7xX\u2715\u2716"


def _plain(text, html=False):
    """טקסט לסריקה: בלי תגיות, בלי המותג (שם ה-`·` חוקי)."""
    if html:
        text = _COMMENT.sub(" ", _STYLE.sub(" ", text))
        text = _TAG.sub(" ", text)
    return text.replace(BRAND, " ").replace("\u00ad", "")


def _samples(rx, txt, n=4):
    return [m.group(0) for m in list(rx.finditer(txt))[:n]]


def g54_multiplication(txt, grade):
    """גליף הכפל — לפי הכיתה, ואחד בלבד לדף."""
    g = _g(grade)
    want = PROFILE[g]["mul"]
    rx = re.compile(rf"(?<=\d)\s*([{re.escape(MUL_LIKE)}])\s*(?=\d)")
    used = {m.group(1) for m in rx.finditer(txt)}
    if want is None:
        if used:
            return False, (f"נמצא כפל ({''.join(sorted(used))}) בכיתה א׳ — "
                           f"מותר רק `+ − = ___ ☐` (curriculum.md §2)")
        return True, "אין כפל (תקין לכיתה א׳)"
    bad = used - {want}
    if bad:
        names = ", ".join(FORBIDDEN_ALWAYS.get(c, f"{c} ({_u(c)})")
                          for c in sorted(bad))
        return False, (f"גליף כפל שגוי לכיתה {g}׳: {names} — התקן הוא "
                       f"`{want}` ({_u(want)}). ראו signs.MUL()")
    if len(used) > 1:
        return False, f"שני גליפי כפל באותו דף: {sorted(used)} — עקביות חובה"
    return True, f"כפל = `{want}` בלבד ({len(used)} גליף)"


def g55_division(txt, grade):
    """חילוק: `25 : 5` עם רווחים. ÷ ו-`/` אסורים תמיד."""
    g = _g(grade)
    if "\u00f7" in txt:
        return False, "÷ בדף — ÷ אסור בכל כיתה ביסודי"
    slash = re.compile(r"(?<=\d)\s*/\s*(?=\d)")
    if slash.search(txt):
        slash_sample = re.compile(r"\d\s*/\s*\d")
        found = ", ".join(_samples(slash_sample, txt))
        return False, (f"`/` בין ספרות ({found}) — "
                       f"חילוק הוא `a : b`; שבר הוא `H.frac()` מדורג")
    if PROFILE[g]["div"] is None:
        if re.search(r"\d\s*:\s*\d", txt):
            return False, f"חילוק בכיתה {g}׳ — לא קיים בתוכנית"
        return True, "אין חילוק (תקין לכיתה א׳)"
    tight = [m.group(0) for m in re.finditer(r"(?<!\d)\d+:\d+(?!\d)", txt)]
    tight = [t for t in tight if not _TIME.fullmatch(t)]
    if tight:
        return False, (f"נקודתיים בלי רווחים: {tight[:4]} — התקן הוא "
                       f"`25 : 5` (רווח משני הצדדים; בלי רווח זה נקרא שעה)")
    if PROFILE[g]["time"] == "words":
        t = [m.group(0) for m in _TIME.finditer(txt)]
        if t:
            return False, (f"כתיב שעה דיגיטלי {t[:3]} בכיתה {g}׳ — "
                           f"בא׳–ב׳ השעה במילים בלבד (\"רבע ל-5\")")
    return True, "חילוק `a : b` תקין (0 מופעי ÷ ו-`/`)"


def g56_minus(txt, grade):
    """מינוס = U+2212. מקף ASCII/מקף-קצר בין ספרות = פסילה."""
    t = _NEG.sub(" ", txt)                       # (3-) מותר
    t = _RANGE.sub("\u2013", t)                  # טווח 21–25 נשמר לזיהוי
    bad = []
    for m in re.finditer(r"(?<=\d)\s*([-\u2013\u2014])\s*(?=\d)", t):
        ch, span = m.group(1), m.group(0)
        if ch == "\u2013" and span == "\u2013":  # 21–25 טווח צמוד — תקין
            continue
        bad.append(span.strip() or ch)
    if bad:
        return False, (f"מקף במקום מינוס בין ספרות ({len(bad)} מופעים) — "
                       f"התקן הוא `−` U+2212 עם רווחים: `64 − 29`. "
                       f"(טווח בפרוזה: מקף-קצר צמוד, `21–25`, ב-`H.num()`)")
    if not PROFILE[_g(grade)]["neg"] and _NEG.search(txt):
        return False, (f"כתיב `(3-)` בכיתה {_g(grade)}׳ — "
                       f"בב׳ 'מינוס 5' במילים בלבד")
    return True, "מינוס = U+2212 בלבד"


def g57_fractions(txt, grade, html=None):
    """שבר: מדורג בלבד, מג׳ ואילך; אפס גליפי-שבר; אין `a/b`."""
    g = _g(grade)
    v = [c for c in txt if c in VULGAR]
    if v:
        return False, (f"גליפי-שבר מוכנים: {''.join(sorted(set(v)))} — "
                       f"שבר מדורג בלבד (`H.frac(1,4)`)")
    if html and not PROFILE[g]["frac"] and 'class="frac"' in html:
        return False, (f"`span.frac` בכיתה {g}׳ — שברים בא׳–ב׳ במילים "
                       f"ובצביעה בלבד (curriculum.md §3)")
    # `v2.1` / `§8.1` אינם מספרים עשרוניים — אות לטינית/§ לפני הספרה
    dec = re.compile(r"(?<![\dA-Za-z\u00a7.])\d+\.\d")
    if not PROFILE[g]["decimal"] and dec.search(txt):
        s = _samples(dec, txt)
        return False, f"מספר עשרוני {s} בכיתה {g}׳ — עשרוני מד׳ בלבד"
    if not PROFILE[g]["thousands"] and re.search(r"\d,\d{3}", txt):
        return False, f"פסיק אלפים בכיתה {g}׳ — בא׳–ב׳ כותבים `1000`"
    return True, "שברים/עשרוני/מפריד — תקינים לכיתה"


def g58_font_coverage(txt):
    """גליף מתמטי שאינו ב-David Libre = נפילת פונט שקטה."""
    hits = {c for c in txt if c in NOT_IN_DAVID_LIBRE}
    if hits:
        fix = "; ".join(NOT_IN_DAVID_LIBRE[c] for c in sorted(hits))
        return False, (f"גליף חסר ב-David Libre בדף: {''.join(sorted(hits))} — "
                       f"נפילה שקטה לפונט מערכת. {fix}")
    return True, "כל הגליפים המתמטיים קיימים ב-David Libre"


def g59_forbidden(txt, grade):
    """סימנים אסורים-תמיד + סימנים שמעל גיל הכיתה."""
    g = _g(grade)
    # `·` הוא **מפריד טיפוגרפי חוקי** בפרוזה עברית ובמותג
    # ("פריטה · איתור טעות · רמה ב׳"). רק `·` **צמוד לספרה** הוא כפל
    # שגוי — וזה בדיוק מה ש-G54 בודק. סריקה עיוורת כאן פסלה כל דף.
    prose_ok = {"\u00b7"}
    hits = {c: why for c, why in FORBIDDEN_ALWAYS.items()
            if c in txt and c not in prose_ok}
    if not PROFILE[g]["cmp"] and re.search(r"\d\s*[<>]\s*\d", txt):
        hits["<>"] = f"`<` `>` בכיתה {g}׳ — מוקנים מב׳"
    if not PROFILE[g]["degree"] and re.search(r"\d\s*\u00b0", txt):
        hits["°"] = f"`°` בכיתה {g}׳ — לזוויות מה׳ בלבד"
    if "%" in txt and g != "ו":
        hits["%"] = "אחוזים — ו׳ בלבד, ובסימון 'מחוץ לדגימה'"
    if hits:
        return False, "; ".join(f"{k} → {v}" for k, v in sorted(hits.items()))
    return True, "אין סימנים אסורים"


def _u(c):
    try:
        return f"U+{ord(c):04X} {unicodedata.name(c)}"
    except ValueError:
        return f"U+{ord(c):04X}"


GATES = ("G54-כפל", "G55-חילוק", "G56-מינוס", "G57-שברים",
         "G58-פונט", "G59-אסורים")


def check(text, grade, html=False):
    """מריץ את כל שערי הסימנים. מחזיר [(שם, ok, הודעה), ...]."""
    src = text
    txt = _plain(text, html=html)
    return [
        (GATES[0], *g54_multiplication(txt, grade)),
        (GATES[1], *g55_division(txt, grade)),
        (GATES[2], *g56_minus(txt, grade)),
        (GATES[3], *g57_fractions(txt, grade, html=src if html else None)),
        (GATES[4], *g58_font_coverage(txt)),
        (GATES[5], *g59_forbidden(txt, grade)),
    ]


def assert_clean(text, grade, html=False):
    """לשימוש בתוך גנרטור — זורק על הפרה במקום להדפיס."""
    bad = [(n, m) for n, ok, m in check(text, grade, html) if not ok]
    if bad:
        raise ValueError("signs: " + " | ".join(f"{n}: {m}" for n, m in bad))
    return True


# ------------------------------------------------------- אימות כיסוי פונט
def verify_font_coverage(ttf_path):
    """מוודא ש-NOT_IN_DAVID_LIBRE עדיין מדויק מול הפונט המצורף בפועל.
    מריצים אחרי כל החלפת גופן. מחזיר (ok, msg)."""
    from fontTools.ttLib import TTFont
    f = TTFont(ttf_path)
    cmap = set()
    for t in f["cmap"].tables:
        cmap |= set(t.cmap.keys())
    must = [PLUS, MINUS, EQ, TIMES_B, TIMES_X, COLON, LT, GT, ",", ".",
            "\u20aa", "\u00b7", "\u00b0"]
    missing = [c for c in must if ord(c) not in cmap]
    ghost = [c for c in NOT_IN_DAVID_LIBRE if ord(c) in cmap]
    if missing:
        return False, f"סימני חובה חסרים בפונט: {missing}"
    return True, (f"כל {len(must)} סימני החובה קיימים"
                  + (f"; לעדכון: {ghost} כבר קיימים בפונט" if ghost else ""))


# ------------------------------------------------------------------ בדיקה
def _selftest():
    ok = True

    def want(cond, msg):
        nonlocal ok
        if not cond:
            print("SELFTEST FAIL:", msg)
            ok = False

    want(expr(6, "*", 4, "ג") == "6 x 4 =", "כפל ג׳")
    want(expr(6, "*", 4, "ב") == "6 × 4 =", "כפל ב׳")
    want(expr(20, "/", 5, "ב") == "20 : 5 =", "חילוק ב׳")
    want(expr(64, "-", 29, "ב", eq=False) == "64 \u2212 29", "מינוס")
    want(fmt(4562, "ג") == "4,562" and fmt(4562, "ב") == "4562", "אלפים")
    want(neg(3) == "(3-)", "שלילי")
    try:
        op("*", "א"); want(False, "כפל בא׳ לא נחסם")
    except ValueError:
        pass
    # שערים
    want(not g54_multiplication("6 · 4 =", "ג")[0], "נקודת כפל לא נתפסה")
    want(not g54_multiplication("6 × 4 =", "ד")[0], "× בד׳ לא נתפס")
    want(not g54_multiplication("6 x 4 =", "ב")[0], "x בב׳ לא נתפס")
    want(g54_multiplication("6 x 4 = 24", "ג")[0], "כפל תקין נחסם")
    want(g54_multiplication(BRAND, "ג")[0] if BRAND else True, "מותג")
    want(not g55_division("12 ÷ 4", "ג")[0], "÷ לא נתפס")
    want(not g55_division("3/4", "ד")[0], "/ לא נתפס")
    want(not g55_division("25:5 =", "ג")[0], "נקודתיים צמודות לא נתפסו")
    want(g55_division("25 : 5 =", "ג")[0], "חילוק תקין נחסם")
    want(g55_division("16:45", "ג")[0], "שעה תקינה נחסמה")
    want(not g55_division("16:45", "ב")[0], "שעה דיגיטלית בב׳ לא נתפסה")
    want(not g56_minus("64 - 29 =", "ג")[0], "מקף כמינוס לא נתפס")
    want(g56_minus("64 \u2212 29 =", "ג")[0], "מינוס תקין נחסם")
    want(g56_minus("21\u201325", "ג")[0], "טווח צמוד נחסם")
    want(g56_minus("(3-)", "ג")[0], "כתיב שלילי נחסם")
    want(not g56_minus("(3-)", "ב")[0], "שלילי בב׳ לא נתפס")
    want(not g57_fractions("\u00bd", "ד")[0], "גליף שבר לא נתפס")
    want(not g57_fractions("25.8", "ג")[0], "עשרוני בג׳ לא נתפס")
    want(not g57_fractions("1,000", "ב")[0], "פסיק אלפים בב׳ לא נתפס")
    want(g57_fractions("1,000", "ג")[0], "פסיק תקין נחסם")
    want(not g58_font_coverage("\u2610")[0], "☐ לא נתפס")
    want(g58_font_coverage("\u2605 \u2605")[0], "★ נחסם בטעות")
    want(not g59_forbidden("5 > 3", "א")[0], "השוואה בא׳ לא נתפסה")
    want(g59_forbidden("5 > 3", "ב")[0], "השוואה תקינה בב׳ נחסמה")
    want(not g59_forbidden("45\u00b0", "ד")[0], "° בד׳ לא נתפס")
    want(not g59_forbidden("AB \u2225 CD", "ו")[0], "∥ לא נתפס")
    want(not g59_forbidden("\u2248 7", "ו")[0], "≈ לא נתפס")
    want(all(o for _, o, _ in check(
        f'<p>{BRAND}</p><span class="ltr">6 x 4 = 24</span>'
        '<span class="ltr">20 : 5 = 4</span>'
        '<span class="ltr">64 \u2212 29 = 35</span>', "ג", html=True)),
         "דף תקין נחסם")
    print("SELFTEST PASS" if ok else "SELFTEST FAILED")
    return 0 if ok else 1


if __name__ == "__main__":
    import sys
    if "--selftest" in sys.argv:
        sys.exit(_selftest())
    if "--font" in sys.argv:
        i = sys.argv.index("--font")
        print(verify_font_coverage(sys.argv[i + 1]))
        sys.exit(0)
    # שימוש: signs.py --grade ג file.html
    grade = "ג"
    if "--grade" in sys.argv:
        grade = sys.argv[sys.argv.index("--grade") + 1]
    paths = [a for a in sys.argv[1:] if not a.startswith("--")
             and a != grade]
    bad = 0
    for p in paths:
        t = open(p, encoding="utf8").read()
        print(f"--- {p} (כיתה {grade}׳)")
        for name, o, msg in check(t, grade, html=p.endswith(".html")):
            print(f"{'PASS' if o else 'FAIL'} — {name}: {msg}")
            bad += not o
    sys.exit(1 if bad else 0)
