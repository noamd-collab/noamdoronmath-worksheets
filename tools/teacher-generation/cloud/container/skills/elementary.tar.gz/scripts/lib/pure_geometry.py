# -*- coding: utf-8 -*-
"""Pure geometric shapes for elementary worksheets, with safe rotation.

This module is deliberately separate from ``svg_elementary.py``.  Only abstract
geometry figures belong here; number lines, clocks, coins, column arithmetic,
long division, ten-frames, charts, place-value blocks and bar models must keep
their meaningful orientation and therefore expose no ``rot`` parameter.
"""

from __future__ import annotations

import html
import math

try:
    from .geometry_rotation import ModelTransform, rot_for
except ImportError:  # worksheet builds add scripts/lib directly to sys.path
    from geometry_rotation import ModelTransform, rot_for

INK = "#1A1A2E"
STROKE = "#1F6FC5"
FILL = "#DCECFB"
HEB = range(0x0590, 0x0600)


def assert_latin_label(text):
    """G49: Hebrew captions belong in HTML, never in SVG ``<text>``.

    WeasyPrint does not reliably apply the bidi algorithm inside SVG text;
    accepting a Hebrew vertex label here would therefore risk a reversed
    glyph order.  Latin letters, digits and mathematical symbols are safe.
    """
    value = str(text)
    bad = sorted({char for char in value if ord(char) in HEB})
    if bad:
        raise AssertionError(
            "Hebrew inside pure-geometry SVG label (G49): %r; "
            "put the Hebrew caption in surrounding HTML" % "".join(bad)
        )
    return value


def _dist(p, q):
    return math.hypot(p[0] - q[0], p[1] - q[1])


def _dot(a, b):
    return a[0] * b[0] + a[1] * b[1]


def _vec(p, q):
    return q[0] - p[0], q[1] - p[1]


def _cross(a, b):
    return a[0] * b[1] - a[1] * b[0]


def _parallel(a, b, tol=1e-9):
    den = max(math.hypot(*a) * math.hypot(*b), 1e-12)
    return abs(_cross(a, b)) / den < tol


def _polygon_area2(pts):
    return sum(
        pts[i][0] * pts[(i + 1) % len(pts)][1]
        - pts[(i + 1) % len(pts)][0] * pts[i][1]
        for i in range(len(pts))
    )


class GeometryFig:
    """Tiny point-derived renderer; glyphs never inherit figure rotation."""

    def __init__(self, pts, w=210, h=150, pad=30, rot=0.0):
        self.model_pts = [tuple(map(float, p)) for p in pts]
        self.xf = ModelTransform(w, h, pad, rot).fit(self.model_pts)
        self.w, self.h, self.rot = self.xf.w, self.xf.h, float(rot)
        self.parts = []
        self.cx = sum(p[0] for p in self.model_pts) / len(self.model_pts)
        self.cy = sum(p[1] for p in self.model_pts) / len(self.model_pts)

    def _p(self, p):
        return self.xf.tx(p)

    def line(self, p, q, *, color=STROKE, width=2.0, dashed=False):
        p, q = self._p(p), self._p(q)
        dash = ' stroke-dasharray="5,4"' if dashed else ""
        self.parts.append(
            f'<line x1="{p[0]:.2f}" y1="{p[1]:.2f}" '
            f'x2="{q[0]:.2f}" y2="{q[1]:.2f}" stroke="{color}" '
            f'stroke-width="{width}"{dash}/>'
        )

    def polygon(self, pts, *, fill=FILL, color=STROKE, width=2.0):
        rp = [self._p(p) for p in pts]
        data = " ".join(f"{x:.2f},{y:.2f}" for x, y in rp)
        self.parts.append(
            f'<polygon points="{data}" fill="{fill}" stroke="{color}" '
            f'stroke-width="{width}"/>'
        )

    def label(self, p, text, dx=0, dy=0, size=14):
        text = assert_latin_label(text)
        x, y = self._p(p)
        dx, dy = self.xf.label_offset(dx, dy)
        self.parts.append(
            f'<text x="{x + dx:.2f}" y="{y + dy:.2f}" '
            f'font-family="David Libre" font-size="{size}" '
            f'font-style="italic" text-anchor="middle" fill="{INK}">'
            f'{html.escape(text)}</text>'
        )

    def label_outside(self, p, text, distance=13):
        vx, vy = p[0] - self.cx, p[1] - self.cy
        length = max(math.hypot(vx, vy), 1e-12)
        # The requested offset is expressed in the unrotated SVG frame.  The
        # transform rotates the offset (not the glyph) with the model figure.
        dx = distance * vx / length
        dy = -distance * vy / length
        self.label(p, text, dx=dx, dy=dy)

    def right_angle(self, vertex, to1, to2, size=0.38):
        u, v = _vec(vertex, to1), _vec(vertex, to2)
        lu, lv = math.hypot(*u), math.hypot(*v)
        u, v = (u[0] / lu, u[1] / lu), (v[0] / lv, v[1] / lv)
        assert abs(_dot(u, v)) < 1e-9, "right-angle marker requires perpendicular rays"
        p1 = (vertex[0] + size * u[0], vertex[1] + size * u[1])
        p3 = (vertex[0] + size * v[0], vertex[1] + size * v[1])
        p2 = (p1[0] + size * v[0], p1[1] + size * v[1])
        self.line(p1, p2, color=INK, width=1.4)
        self.line(p2, p3, color=INK, width=1.4)

    def render(self):
        body = "\n  ".join(self.parts)
        w = f"{self.w:.1f}".rstrip("0").rstrip(".")
        h = f"{self.h:.1f}".rstrip("0").rstrip(".")
        return (
            f'<svg width="{w}" height="{h}" viewBox="0 0 {w} {h}" '
            f'dir="ltr" xmlns="http://www.w3.org/2000/svg">\n  '
            f'{body}\n</svg>'
        )


def _finish_quad(pts, labels, rot, w, h):
    fig = GeometryFig(pts, w=w, h=h, rot=rot)
    fig.polygon(pts)
    for p, label in zip(pts, labels):
        fig.label_outside(p, label)
    return fig.render()


def triangle(rot=0.0, kind="scalene", w=210, h=150, labels=("A", "B", "C")):
    """Abstract triangle; ``kind`` may be scalene, isosceles or right."""
    if kind == "right":
        pts = [(0, 0), (5, 0), (0, 3.2)]
    elif kind == "isosceles":
        pts = [(0, 0), (5, 0), (2.5, 3.8)]
    elif kind == "scalene":
        pts = [(0, 0), (5.3, 0), (1.2, 3.65)]
    else:
        raise ValueError("kind must be scalene, isosceles or right")
    assert abs(_polygon_area2(pts)) > 1e-9
    sides = [_dist(pts[0], pts[1]), _dist(pts[1], pts[2]), _dist(pts[2], pts[0])]
    if kind == "right":
        assert abs(_dot(_vec(pts[0], pts[1]), _vec(pts[0], pts[2]))) < 1e-9
    elif kind == "isosceles":
        assert abs(sides[1] - sides[2]) < 1e-9
    else:
        assert min(abs(sides[i] - sides[j]) for i in range(3) for j in range(i)) > 0.1
    fig = GeometryFig(pts, w=w, h=h, rot=rot)
    fig.polygon(pts)
    if kind == "right":
        fig.right_angle(pts[0], pts[1], pts[2])
    for p, label in zip(pts, labels):
        fig.label_outside(p, label)
    return fig.render()


def rectangle(rot=0.0, w=210, h=150, labels=("A", "B", "C", "D")):
    pts = [(0, 0), (5.6, 0), (5.6, 3.0), (0, 3.0)]
    sides = [_vec(pts[i], pts[(i + 1) % 4]) for i in range(4)]
    assert _parallel(sides[0], sides[2]) and _parallel(sides[1], sides[3])
    assert abs(_dot(sides[0], sides[1])) < 1e-9
    return _finish_quad(pts, labels, rot, w, h)


def square(rot=0.0, w=210, h=150, labels=("A", "B", "C", "D")):
    pts = [(0, 0), (4, 0), (4, 4), (0, 4)]
    lengths = [_dist(pts[i], pts[(i + 1) % 4]) for i in range(4)]
    assert max(lengths) - min(lengths) < 1e-9
    assert abs(_dot(_vec(pts[0], pts[1]), _vec(pts[1], pts[2]))) < 1e-9
    return _finish_quad(pts, labels, rot, w, h)


def rhombus(rot=0.0, w=210, h=150, labels=("A", "B", "C", "D")):
    side, th = 4.0, math.radians(60)
    d = (side * math.cos(th), side * math.sin(th))
    pts = [(0, 0), (side, 0), (side + d[0], d[1]), d]
    lengths = [_dist(pts[i], pts[(i + 1) % 4]) for i in range(4)]
    assert max(lengths) - min(lengths) < 1e-9
    assert abs(_dot(_vec(pts[0], pts[1]), _vec(pts[1], pts[2]))) > 0.5
    return _finish_quad(pts, labels, rot, w, h)


def trapezoid(rot=0.0, w=210, h=150, labels=("A", "B", "C", "D")):
    pts = [(0, 0), (6, 0), (5.15, 3.0), (1.35, 3.0)]
    sides = [_vec(pts[i], pts[(i + 1) % 4]) for i in range(4)]
    parallels = [
        _parallel(sides[0], sides[2]),
        _parallel(sides[1], sides[3]),
    ]
    assert parallels == [True, False], "trapezoid must have exactly one parallel pair"
    return _finish_quad(pts, labels, rot, w, h)


__all__ = [
    "GeometryFig",
    "rectangle",
    "rhombus",
    "rot_for",
    "square",
    "trapezoid",
    "triangle",
]
