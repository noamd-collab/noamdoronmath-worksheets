#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""house_gates.py — שערי כלל-בית שלא היו קיימים (v2.1).

הדוקטרינה של הסקיל היא ש"לאיך הדף נראה יש שערים; לשאלה אם הוא נכון היו
כוונות טובות". ארבעת הכללים כאן היו כתובים ב-references אבל לא נאכפו
ע"י שום קוד — ולכן סחפו בשקט לאורך מארזים שלמים:

  G50  ★ 2–4 לדף            (style.md §5) — נמצאו 9 בדף אחד
  G51  סדר תווים ב-bidi      — `(1)` התרנדר `)1(` בדף אחד ולא באחר
  G52  טענה שחותמת על עצמה   — `L.claim(..., (True, x))` עוברת תמיד
  G53  שרטוט בלי מקור        — figs לא נרשם ⇒ G37 נכשל רק באריזה

v2.2 — **שערי הסימנים** (`signs.py`, נדרש `--grade`):
  G54  גליף כפל לפי כיתה     — `·` `∙` `*` `X`, או `×` בג׳–ו׳ / `x` בב׳
  G55  חילוק `25 : 5`        — ÷ ו-`12/4` ו-`25:5` צמוד
  G56  מינוס U+2212          — מקף ASCII כמינוס
  G57  שבר/עשרוני/פסיק       — לפי הכיתה, מדורג בלבד
  G58  כיסוי גליף ב-David Libre — ☐ □ ○ ⋅ ≠ נופלים לפונט מערכת
  G59  סימנים אסורים/מעל-כיתה

v2.4 — **שערי התוכן** (`content_quality.py`, נדרש `--content`):
  G60  מספרים לא יפים   — שבר לא מצומצם, מחזורי קטום, סדר גודל לא מתאים
  G61  רמה לא עקבית      — פריט חורג או ערבוב רמות; דף קל רק מזהיר
  G62  פריט משוכפל       — טביעה מבנית וגיוון תשובות
  G63  שרטוט חתוך        — גאומטריה ותוויות מחוץ ל-viewBox או חופפות
  G64  סימנים ב-SVG      — מינוס ASCII, חילוק/שבר אסור וטקסט סימנים שגוי
  G65  מציין מקום בתשובה — ארבעה מצייני מקום מדויקים בשדות התשובות בלבד

הרצה:
    python3 house_gates.py --html sheet.html --pdf sheet.pdf \\
                           --verify verified.json --gen gen_sheet.py
    python3 house_gates.py --selftest
כל ארגומנט אופציונלי — נבדק רק מה שנמסר. יציאה 1 = כשל חוסם.
"""
import argparse
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import signs as S
import content_quality as CQ
from answer_layout import g70_answer_layout

HEB = re.compile(r"[\u0590-\u05FF]")


# --------------------------------------------------------------- G50 ★
def g50_stars(html_path, lo=2, hi=4):
    """★ 2–4 לדף. `check_worksheet` רק מזהיר כשאין ★ בכלל, ולכן חריגה
    כלפי מעלה עברה בשקט."""
    src = open(html_path, encoding="utf8").read()
    n = src.count('class="starred"')
    if not lo <= n <= hi:
        return False, (f"★ = {n} — כלל הבית הוא {lo}–{hi} לדף (style.md §5). "
                       f"השאירו את המאתגרות רעיונית (הכללה, ביקורת, מנייה) "
                       f"והורידו את השגרתיות (בדיקת סבירות, איתור טעות פשוט)")
    return True, f"★ = {n} — בטווח {lo}–{hi}"


# ------------------------------------------------------------- G51 bidi
def g51_bidi_order(pdf_path):
    """סדר תווים ברמת הגליף ב-PDF הסופי.

    זוג סוגריים שכל תוכנו ספרות **חייב** להיקרא LTR: `(2)`. אם הוא מקבל
    את כיוון ההטמעה RTL הוא מתהפך ל-`)2(` — התלמיד רואה מספור שבור.
    זוג שמכיל אות עברית (טיפוס חזק RTL) **אמור** להתהפך — זו עברית
    תקינה — ולכן מדולג.

    ‼ העין אינה כלי מדידה כאן. נמדד לפי מיקום הגליף:
        chars = [(c["bbox"][0], c["c"]) for s in spans for c in s["chars"]]
        visual = "".join(c for x, c in sorted(chars))
    """
    try:
        import pymupdf
    except Exception as e:
        return False, f"SKIPPED — pymupdf חסר ({e!r}); שער שדולג = כשל"
    doc = pymupdf.open(pdf_path)
    bad = []
    for pno in range(len(doc)):
        for b in doc[pno].get_text("rawdict")["blocks"]:
            for line in b.get("lines", []):
                ch = [(c["bbox"][0], c["c"])
                      for s in line["spans"] for c in s["chars"]]
                vis = "".join(c for x, c in sorted(ch))
                for m in re.finditer(r"\)([^()]{0,10})\(", vis):
                    inner = m.group(1)
                    if HEB.search(inner):
                        continue
                    if not any(c.isdigit() or c.isalpha() for c in inner):
                        continue
                    bad.append(f"p{pno + 1}:{m.group(0)!r}")
    if bad:
        return False, ("סוגריים הפוכים סביב תוכן מספרי: " + ", ".join(bad[:6])
                       + " — החליפו למספור באותיות עבריות (טיפוס חזק)")
    return True, "סדר תווים תקין (0 סוגריים הפוכים)"


# ----------------------------------------------------- G52 טענה עצמית
SELF_SIGN = re.compile(r"\(\s*True\s*,")


def g52_self_signing(gen_paths):
    """`L.claim(qid, statement, (True, value), method)` עוברת **תמיד**
    ואינה מוכיחה דבר. ה-Ledger אינו יכול לתפוס את זה — רק קריאה.
    כל ראיה חייבת להשוות חישוב לערך צפוי: `(add_col(63,28) == 91, 91)`.
    """
    hits = []
    for p in gen_paths:
        for i, line in enumerate(open(p, encoding="utf8"), 1):
            if SELF_SIGN.search(line) and "claim" not in line.lower():
                # מסננים רק שורות שנראות כראיה של טענה
                if re.search(r"\(\s*True\s*,\s*[^)]+\)\s*,\s*(CF|EN|EX|\")",
                             line):
                    hits.append(f"{os.path.basename(p)}:{i}")
    if hits:
        return False, ("ראיה שחותמת על עצמה `(True, ...)` ב: "
                       + ", ".join(hits)
                       + " — החליפו בהשוואה בין חישוב לערך צפוי")
    return True, "אין ראיות `(True, ...)`"


# ------------------------------------------------- G53 שרטוט בלי מקור
def g53_figures_registered(html_path, figdir):
    """כל `<svg>` שמופיע בדף חייב מקור `.svg` בתיקיית הפלט.

    הכשל בפועל: האיור נבנה והוטמע ב-HTML, אבל `figs=[...]` נשכח ולכן
    המקור לא יוצא. הדף נראה מושלם; G37 נכשל רק בשלב האריזה, אחרי
    שהעיון החזותי כבר עבר."""
    n_svg = open(html_path, encoding="utf8").read().count("<svg")
    n_src = (len([f for f in os.listdir(figdir) if f.endswith(".svg")])
             if os.path.isdir(figdir) else 0)
    if n_svg and n_src == 0:
        return False, (f"{n_svg} שרטוטים בדף ואפס קובצי .svg ב-{figdir} — "
                       f"נשכח `figs=[...]`; G37 ייכשל באריזה")
    if n_svg > n_src:
        return False, (f"{n_svg} שרטוטים בדף אך רק {n_src} מקורות ב-{figdir} — "
                       f"חלק מן ה-`figs` לא נרשמו")
    return True, f"{n_src} מקורות SVG לכל {n_svg} השרטוטים"


# --------------------------------------------------- G54–G59 תקן הסימנים
def g5x_signs(grade, html_path=None, pdf_path=None):
    """מריץ את שערי הסימנים על **המקור וגם על הפלט**.

    שניהם נחוצים ולא חופפים: ה-HTML תופס את הכוונה (`class="frac"`
    בכיתה ב׳), וה-PDF תופס את מה שבאמת הודפס — כולל טקסט בתוך SVG,
    שאינו נראה בסריקת ה-HTML כטקסט רגיל, ושם דווקא נולדים רוב
    גליפי הכפל השגויים (`vertical_problem(op=...)`).
    """
    out = []
    if html_path:
        src = open(html_path, encoding="utf8").read()
        out += [(f"{n}·html", ok, m)
                for n, ok, m in S.check(src, grade, html=True)]
    if pdf_path:
        try:
            import pymupdf
            doc = pymupdf.open(pdf_path)
            txt = "\n".join(pg.get_text() for pg in doc)
        except Exception as e:
            out.append(("G54-G59·pdf", False,
                        f"SKIPPED — pymupdf חסר ({e!r}); שער שדולג = כשל"))
            return out
        out += [(f"{n}·pdf", ok, m) for n, ok, m in S.check(txt, grade)]
    return out


# ------------------------------------------------------- G60–G65 תוכן
def _content_figures(recs, figdir):
    """Load exactly referenced SVGs (inline, wrapped, or external), then any
    additional SVG sources in the declared directory. Missing references are
    a hard failure; an unrelated file must not make ``missing.svg`` pass.
    Context is keyed per extracted figure so a clock/ratio question cannot
    license punctuation in a different SVG on the same sheet."""
    figures, contexts, missing = {}, {}, []
    base = figdir or ""
    seen, referenced_paths = set(), set()
    for rec in recs:
        ref = rec.get("fig")
        marker = str(ref or "")
        if not marker or marker in seen:
            continue
        seen.add(marker)
        label = "Q%s" % rec.get("n", "?")
        context = str(rec.get("context", rec.get("stem", "")))
        if "<svg" in marker.lower():
            found = CQ.extract_svg_sources(ref, label)
            if found:
                for key, source in found.items():
                    figures[key] = source
                    contexts[key] = context
            else:
                missing.append(label + " inline SVG")
            continue
        path = str(ref) if os.path.isabs(str(ref)) else os.path.join(base, str(ref))
        if not os.path.isfile(path):
            missing.append(str(ref)); continue
        referenced_paths.add(os.path.realpath(path))
        source = open(path, encoding="utf-8").read()
        found = CQ.extract_svg_sources(
            source, "%s:%s" % (label, os.path.basename(path)))
        if found:
            for key, svg_source in found.items():
                figures[key] = svg_source
                contexts[key] = context
        else:
            missing.append(str(ref) + " (לא SVG)")
    for filename, source in CQ.load_figs(base).items():
        if os.path.realpath(os.path.join(base, filename)) in referenced_paths:
            continue
        figures.setdefault(filename, source)
    return figures, contexts, missing


def g6x_content(content_path, figdir=None, grade=None, level=None, html_path=None):
    """Run source content gates, including G69 on content, HTML and SVGs."""
    try:
        with open(content_path, encoding="utf8") as source:
            content = json.load(source)
    except Exception as error:
        return [("G60-G65", False, "לא נקרא %s: %r" % (content_path, error))]
    meta = content.setdefault("meta", {})
    declared_grade = CQ.elementary_grade(meta.get("grade"))
    cli_grade = CQ.elementary_grade(grade) if grade is not None else None
    if grade is not None and cli_grade is None:
        return [("G60-G65", False, "--grade אינו כיתה א׳–ו׳: %r" % grade)]
    if declared_grade and cli_grade and declared_grade != cli_grade:
        return [("G60-G65", False,
                 "סתירת כיתה: content=%s, --grade=%s" %
                 (declared_grade, cli_grade))]
    if cli_grade and not declared_grade:
        meta["grade"] = cli_grade
    if level is not None and meta.get("level") not in (None, level):
        return [("G60-G65", False,
                 "סתירת רמה: content=%s, --level=%s" %
                 (meta.get("level"), level))]
    if level is not None:
        meta["level"] = level
    profile = CQ.profile_of(content)
    if profile is None:
        return [("G60-G65", False,
                 "לא הוכרזה כיתה תקינה ב-meta.grade/--grade; "
                 "שער שדולג = כשל")]
    recs = CQ.normalize(content)
    effective_grade = declared_grade or cli_grade or CQ.elementary_grade(
        meta.get("grade"))
    content_dir = os.path.dirname(os.path.abspath(content_path))
    base = figdir or os.path.join(content_dir, "figures")
    if figdir and not os.path.isabs(base):
        base = os.path.join(content_dir, base)
    html = None
    if html_path:
        try:
            with open(html_path, encoding="utf8") as source:
                html = source.read()
        except (OSError, UnicodeError) as error:
            return [("G69-drawings", False,
                     "לא נקרא HTML לבדיקת שרטוטים: %r" % error)]
    # Enforce the subject rule before opening figure files. A forbidden image
    # must fail as policy, even if it is a raster file or a missing reference.
    drawing_status, drawing_message = CQ.g69_drawings(
        content, recs=recs, html=html)
    if drawing_status == CQ.FAIL:
        return [("G69-drawings", False, drawing_message)]
    figures, contexts, missing = _content_figures(recs, base)
    drawing_status, drawing_message = CQ.g69_drawings(
        content, recs=recs, figs=figures, html=html)
    if missing:
        return [("G63-geometry", False,
                 "קובצי שרטוט חסרים: %s" % ", ".join(missing)),
                ("G69-drawings", drawing_status == CQ.PASS, drawing_message)]
    rows = [("G60-numbers",) + CQ.g60_ugly_numbers(recs, profile),
            ("G61-level",) + CQ.g61_level_consistency(recs, profile),
            ("G62-clones",) + CQ.g62_cloned_items(recs, profile),
            ("G65-answer-placeholders",) + CQ.g65_final_answer_placeholders(recs),
            ("G66-chronology",) + CQ.g66_chronology(recs, content=content,
                                                    grade=effective_grade)]
    rows.append(("G67-hints",) + CQ.g67_hints(content, recs=recs))
    rows.append(("G69-drawings", drawing_status, drawing_message))
    if figures or any(r.get("fig") for r in recs):
        rows += [("G63-geometry",) + CQ.g63_figure_geometry(figures),
                 ("G64-svg-signs",) + CQ.g64_svg_signs(
                     figures, colon_mode="elementary", grade=effective_grade,
                     context=contexts)]
    return [(name, status in (CQ.PASS, CQ.WARN),
             ("WARN " + message if status == CQ.WARN else message))
            for name, status, message in rows]


def g68_docx(docx_path):
    """בדיקת קובץ Word עריך (.docx) למאגר המורים."""
    if not os.path.isfile(docx_path):
        return False, f"קובץ Word לא נמצא: {docx_path}"
    try:
        scripts_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        if scripts_dir not in sys.path:
            sys.path.insert(0, scripts_dir)
        import build_docx as BD
        return BD.verify_docx(docx_path)
    except Exception as e:
        return False, f"כשל בבדיקת Word: {e!r}"


# ------------------------------------------------------------------ CLI
def run(html=None, pdf=None, figdir=None, gens=(), quiet=False, grade=None,
        content=None, level=None, docx=None):
    checks = []
    if html:
        checks.append(("G70-answer-layout", g70_answer_layout(html)))
        checks.append(("G50-★", g50_stars(html)))
        checks.append(("G53-figs", g53_figures_registered(
            html, figdir or os.path.join(os.path.dirname(html), "figures"))))
    if pdf:
        checks.append(("G51-bidi", g51_bidi_order(pdf)))
    if gens:
        checks.append(("G52-claim", g52_self_signing(gens)))
    if grade:
        checks += [(n, (ok, m)) for n, ok, m in g5x_signs(grade, html, pdf)]
    elif html or pdf:
        checks.append(("G54-G59-signs",
                       (False, "לא נמסר --grade — שערי הסימנים לא רצו; "
                               "שער שדולג = כשל")))
    if content:
        checks += [(n, (ok, m))
                   for n, ok, m in g6x_content(content, figdir, grade, level,
                                              html_path=html)]
    elif html or pdf:
        checks.append(("G60-G69-content",
                       (False, "לא נמסר --content — שערי התוכן לא רצו; "
                               "שער שדולג = כשל")))
    if docx:
        checks.append(("G68-docx", g68_docx(docx)))
    bad = 0
    for name, (ok, msg) in checks:
        if not quiet or not ok:
            print(f"{'PASS' if ok else 'FAIL'} — {name}: {msg}")
        bad += not ok
    if not checks:
        print("house_gates: לא נמסר דבר לבדיקה")
        return 2
    print("HOUSE GATES: " + ("PASS" if not bad else f"FAIL ({bad})"))
    return 1 if bad else 0


def _selftest():
    import tempfile
    ok = True
    d = tempfile.mkdtemp()
    h = os.path.join(d, "s.html")
    open(h, "w", encoding="utf8").write('<li class="starred">a</li>' * 9)
    if g50_stars(h)[0]:
        print("SELFTEST FAIL: 9 ★ עברו"); ok = False
    open(h, "w", encoding="utf8").write('<li class="starred">a</li>' * 3)
    if not g50_stars(h)[0]:
        print("SELFTEST FAIL: 3 ★ נחסמו"); ok = False
    g = os.path.join(d, "g.py")
    open(g, "w", encoding="utf8").write(
        'x = [("s", (True, 42), CF)]\n')
    if g52_self_signing([g])[0]:
        print("SELFTEST FAIL: (True, ...) לא נתפס"); ok = False
    open(g, "w", encoding="utf8").write(
        'x = [("s", (add_col(1,2) == 3, 3), CF)]\n')
    if not g52_self_signing([g])[0]:
        print("SELFTEST FAIL: ראיה תקינה נחסמה"); ok = False
    if not g53_figures_registered(h, os.path.join(d, "nope"))[0]:
        print("SELFTEST FAIL: דף בלי svg נחסם"); ok = False
    if S._selftest() != 0:
        print("SELFTEST FAIL: signs.py"); ok = False
    if CQ._selftest() != 0:
        print("SELFTEST FAIL: content_quality.py"); ok = False
    if CQ.has_negative("452 − 137") or not CQ.has_negative("−  3"):
        print("SELFTEST FAIL: זיהוי מינוס בינארי/שלילי"); ok = False
    content = os.path.join(d, "content.json")
    json.dump({"meta": {"band": "elementary", "grade": "ג", "level": "ב"},
               "questions": [{"n": "1", "text": "חשבו",
                               "answer": "6.667"}]},
              open(content, "w", encoding="utf8"), ensure_ascii=False)
    if all(result for _, result, _ in g6x_content(content, grade="ג")):
        print("SELFTEST FAIL: 6.667 עבר את G60"); ok = False
    mismatch = g6x_content(content, grade="ד")
    if all(result for _, result, _ in mismatch):
        print("SELFTEST FAIL: סתירת כיתה עברה"); ok = False
    print("SELFTEST PASS" if ok else "SELFTEST FAILED")
    return 0 if ok else 1


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="שערי כלל-בית ליסודי")
    ap.add_argument("--html")
    ap.add_argument("--pdf")
    ap.add_argument("--figdir")
    ap.add_argument("--gen", nargs="*", default=[])
    ap.add_argument("--grade", help="א|ב|ג|ד|ה|ו — חובה לשערי הסימנים")
    ap.add_argument("--content", help="content.json — חובה לשערי התוכן G60–G69")
    ap.add_argument("--level", help="ב|א|מצוינות — מהדק את טווח G61")
    ap.add_argument("--docx", help="sheet.docx — בדיקת קובץ Word עריך למאגר המורים")
    ap.add_argument("--quiet", action="store_true")
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()
    sys.exit(_selftest() if a.selftest
             else run(a.html, a.pdf, a.figdir, a.gen, a.quiet, a.grade,
                      a.content, a.level, a.docx))
