#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
content_truth.py — the MATH-TRUTH half of the gate battery (G31–G39 + G42).

Why this file exists
--------------------
Every gate the skill shipped before this one checks how the sheet LOOKS:
bidi, markers, stars, fractions, pagination, figure overlap, fonts, zip flags.
None of them checks whether the sheet is TRUE. A review of the
"משולשים מיוחדים" set (3 levels) returned FIVE blocking defects and every one
of them was mathematical, not visual:

  * רמה א׳ Q6ד   perimeter 40, base = 2·leg  ⇒  (10,10,20): not a triangle.
  * מצוינות Q6   (6,6,10) declared "not a triangle" — it is one.
  * מצוינות Q18ג literal wording admits (1,2,3); answer says "אין כזה".
  * מצוינות Q20ד "odd perimeter ⇒ never equilateral" — false at 9 = 3+3+3,
                 contradicted by the question's own data.
  * רמה ב׳  Q15  figure drawn scalene for a stated isosceles roof; the
                 answer's 70° base angles are not the drawn ones.

All five passed every existing gate, because the existing gates never look at
the mathematics. This module closes that hole. It is stdlib-only on purpose:
it must run in any container, before any font/PDF machinery exists.

Two ways to use it
------------------
1. HELPERS, imported by the per-sheet `verify.py`. Every helper that decides
   something RECORDS it in a claim ledger (verified.json). The ledger is what
   makes verification auditable instead of "I checked it in my head".

       from content_truth import Ledger, tri_ok, isosceles_by_perimeter, no_counterexample
       L = Ledger("verify_out/verified.json")
       o = isosceles_by_perimeter(40, base_mult=2)
       L.claim("B_Q6d", "היקף 40, בסיס פי 2 משוק", (len(o) == 1, o))
       L.save()

2. LINTER, run before packaging (also wired into build_pdf.py flows):

       python3 content_truth.py --work . [--zip out.zip]

   Exit code 0 = pass. Non-zero = a blocking content defect; do not deliver.
"""

from __future__ import annotations

import argparse
import glob
import json
import math
import os
import re
import sys
import zipfile
from fractions import Fraction

# ----------------------------------------------------------------------------
# 0. tiny geometry truth kernel
# ----------------------------------------------------------------------------

EPS = 1e-9


def tri_ok(a, b, c, strict=True):
    """Strict triangle inequality. (10,10,20) is FALSE, not 'a flat triangle'."""
    a, b, c = sorted(map(float, (a, b, c)))
    return (a + b) > c + EPS if strict else (a + b) >= c - EPS


def tri_kind(a, b, c, tol=1e-6):
    """('equilateral'|'isosceles'|'scalene', 'right'|'obtuse'|'acute') or None."""
    if not tri_ok(a, b, c):
        return None
    a, b, c = sorted(map(float, (a, b, c)))
    if abs(a - c) < tol:
        by_side = "equilateral"
    elif abs(a - b) < tol or abs(b - c) < tol:
        by_side = "isosceles"
    else:
        by_side = "scalene"
    d = a * a + b * b - c * c
    by_angle = "right" if abs(d) < tol else ("obtuse" if d < 0 else "acute")
    return by_side, by_angle


def angle_deg(P, Q, R):
    """Angle at Q, in degrees, for points given as (x, y)."""
    v = (P[0] - Q[0], P[1] - Q[1])
    w = (R[0] - Q[0], R[1] - Q[1])
    nv = math.hypot(*v) or EPS
    nw = math.hypot(*w) or EPS
    c = max(-1.0, min(1.0, (v[0] * w[0] + v[1] * w[1]) / (nv * nw)))
    return math.degrees(math.acos(c))


def dist(p, q):
    return math.hypot(p[0] - q[0], p[1] - q[1])


def sides_angles_consistent(sides, angles, tol_pct=1.0):
    """Law of cosines check: do these sides really carry these angles?

    Catches the shipped (5,5,7) labelled (45°,45°,90°) — the true hypotenuse
    of a 5,5 right isosceles is 7.07, so the data is impossible, and 'nice
    numbers' is not a defence on a sellable sheet.
    """
    a, b, c = map(float, sides)
    if not tri_ok(a, b, c):
        return False
    got = []
    for x, y, z in ((b, c, a), (a, c, b), (a, b, c)):
        cosv = (x * x + y * y - z * z) / (2 * x * y)
        got.append(math.degrees(math.acos(max(-1.0, min(1.0, cosv)))))
    want = sorted(float(t) for t in angles)
    got = sorted(got)
    return all(abs(g - w) <= tol_pct for g, w in zip(got, want))


# ----------------------------------------------------------------------------
# 1. exhaustive answer producers — never hand-derive these
# ----------------------------------------------------------------------------

def isosceles_by_perimeter(perimeter, base_mult=None, given_side=None, integral=True):
    """EVERY isosceles triangle with this perimeter, as real triangles only.

    base_mult   : base = base_mult * leg          (Fraction/int/float)
    given_side  : one of the sides equals this value
    Returns a sorted list of (a, b, c) tuples; [] means NO SUCH TRIANGLE —
    which is an answer the author must print, not silently repair.
    """
    out = set()
    P = Fraction(perimeter)
    if base_mult is not None:
        m = Fraction(base_mult)
        leg = P / (2 + m)
        base = m * leg
        if tri_ok(leg, leg, base):
            out.add(tuple(sorted((leg, leg, base))))
        return sorted(out)
    if given_side is not None:
        s = Fraction(given_side)
        # s is the base -> legs = (P - s)/2
        leg = (P - s) / 2
        if leg > 0 and tri_ok(leg, leg, s):
            out.add(tuple(sorted((leg, leg, s))))
        # s is a leg -> base = P - 2s
        base = P - 2 * s
        if base > 0 and tri_ok(s, s, base):
            out.add(tuple(sorted((s, s, base))))
        return sorted(out)
    if integral:
        Pi = int(P)
        for leg in range(1, Pi):
            base = Pi - 2 * leg
            if base > 0 and tri_ok(leg, leg, base):
                out.add(tuple(sorted((Fraction(leg), Fraction(leg), Fraction(base)))))
    return sorted(out)


def no_counterexample(predicate, domain, name=""):
    """Test a universal claim by brute force. Returns (True, None) or (False, x).

    The claim 'a triangle with an odd perimeter can never be equilateral'
    dies here in one line:
        no_counterexample(lambda p: p % 3 != 0, range(1, 200, 2))
    """
    for x in domain:
        try:
            ok = predicate(x)
        except Exception as exc:  # a crash is not a proof
            return False, ("EXCEPTION", x, repr(exc))
        if not ok:
            return False, x
    return True, None


# ----------------------------------------------------------------------------
# 1א. elementary arithmetic producers (כיתות א׳–ו׳) — honest, code-computed
# ----------------------------------------------------------------------------
# Same discipline as the triangle producers: a printed drill line, vertical
# problem, comparison, sequence or "neighbors" answer comes out of a function,
# never out of the author's head. All are one-liners on purpose — the Ledger
# entry is what makes them auditable.

def add_col(a, b):
    """חיבור בטור — מחזיר את הסכום לטענת L.claim."""
    return a + b


def sub_col(a, b):
    """חיסור בטור. a < b = טעות נתונים ביסודי (מינוס שלילי לא לפני ג׳־ד׳)."""
    if a < b:
        raise ValueError(f"חיסור ביסודי עם תוצאה שלילית: {a} − {b}")
    return a - b


def mul_col(a, b):
    """כפל בטור / לוח הכפל."""
    return a * b


def div_qr(dividend, divisor):
    """חילוק עם שארית: מחזיר (מנה, שארית). חילוק ללא שארית ⇒ שארית 0."""
    if divisor == 0:
        raise ValueError("חילוק באפס")
    return dividend // divisor, dividend % divisor


def frac(n, d):
    """שבר מדורג מאומת (Fraction) — לתשובות שברים בד׳–ו׳."""
    if d == 0:
        raise ValueError("מכנה אפס")
    return Fraction(n, d)


def cmp_sign(a, b):
    """סימן ההשוואה הנכון בין a ל-b: '<' / '=' / '>' — לתרגילי השוואה."""
    return "<" if a < b else (">" if a > b else "=")


def seq_fill(start, jump, n):
    """סדרה חשבונית: n איברים מ-start בקפיצות jump — להשלמת סדרות."""
    return [start + i * jump for i in range(n)]


def neighbors(n, unit):
    """'השכנים' של n ברמת unit (1=יחידות, 10=עשרות, 100=מאות, 1000=אלפים):
    מחזיר (קודם, עוקב) — למשל neighbors(843, 10) = (840, 850)."""
    import math as _m
    lo = (n // unit) * unit
    hi = lo if n % unit == 0 else lo + unit
    if lo == n:
        lo, hi = n - unit, n + unit
    return lo, hi


def mul_table(upto=10):
    """לוח הכפל כמילון {(i, j): i*j} — למשל לטענה 'כל 100 התוצאות נכונות'."""
    return {(i, j): i * j for i in range(1, upto + 1) for j in range(1, upto + 1)}


# ----------------------------------------------------------------------------
# 2. claim ledger — the machine-checkable link between text and verification
# ----------------------------------------------------------------------------

class Ledger:
    """Records what was verified, how, and with what evidence.

    G32/G33 fail the build when content.json makes a claim (a universal
    statement, an existence denial, an enumeration request) that has NO
    ledger entry. That is the structural fix for the class of bug where the
    author verified their INTENT and shipped different WORDS.
    """

    METHODS = {"exhaustive", "enumeration", "sympy", "closed_form", "figure_assert"}

    def __init__(self, path="verified.json"):
        self.path = path
        self.entries = []

    def claim(self, qid, statement, evidence, method="exhaustive", holds=True):
        if method not in self.METHODS:
            raise ValueError(f"unknown method {method!r}; use {sorted(self.METHODS)}")
        if isinstance(evidence, tuple) and len(evidence) == 2 and isinstance(evidence[0], bool):
            holds, evidence = evidence
        if not holds:
            raise AssertionError(
                f"[{qid}] claim is FALSE — counterexample {evidence!r}: {statement}"
            )
        if isinstance(evidence, (list, tuple, set)) and not evidence:
            # An empty enumeration is a LEGITIMATE answer ("no such triangle") —
            # but it means the givens must change, never that the claim shipped.
            # Record non-existence via no_counterexample, not via an empty list.
            raise AssertionError(
                f"[{qid}] empty evidence — the relation admits no object; "
                f"CHANGE THE GIVENS (or claim non-existence with no_counterexample): {statement}"
            )
        self.entries.append(
            {
                "id": str(qid),
                "statement": statement,
                "method": method,
                "evidence": _jsonable(evidence),
            }
        )
        return evidence

    def save(self):
        os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
        with open(self.path, "w", encoding="utf8") as fh:
            json.dump({"claims": self.entries}, fh, ensure_ascii=False, indent=1)
        return self.path


def _jsonable(x):
    if isinstance(x, Fraction):
        return float(x) if x.denominator != 1 else int(x)
    if isinstance(x, (list, tuple, set)):
        return [_jsonable(i) for i in x]
    if isinstance(x, dict):
        return {str(k): _jsonable(v) for k, v in x.items()}
    return x


# ----------------------------------------------------------------------------
# 3. text scanning helpers
# ----------------------------------------------------------------------------

NUM = r"\d+(?:[.,]\d+)?"
TRIPLE_RE = re.compile(
    rf"(?<![\d.])({NUM})\s*[,،]\s*({NUM})\s*[,،]\s*({NUM})(?![\d.])"
)

# a sentence that DENIES existence / asserts a universal
DENIAL = ("אין כזה", "אין כזו", "לא קיים", "לא קיימת", "אי אפשר", "אינו משולש",
          "אינה משולש", "אין משולש", "לא ניתן לבנות", "לא ניתן להרכיב",
          "לא ייתכן", "בלתי אפשרי", "אינו אפשרי", "אינם אפשריים")
UNIVERSAL = ("לעולם", "תמיד", "אף פעם", "בכל מקרה", "לכל ", "אין אף", "כל משולש")
ENUMERATE = ("רשמו את כל", "מצאו את כל", "כל האפשרויות", "כל השלישיות",
             "אילו", "מי מהם", "מי מהן", "האם ייתכן", "כמה אפשרויות")
SINGULAR_ASK = ("איזה צירוף", "מהו הצירוף", "איזו שלישייה", "איזה משולש",
                "מהי השלישייה", "איזו אפשרות")
SHAPE_WORDS = {
    "שווה־שוקיים": "isosceles", "שווה-שוקיים": "isosceles", "שווה שוקיים": "isosceles",
    "שווה־צלעות": "equilateral", "שווה-צלעות": "equilateral", "שווה צלעות": "equilateral",
    "ישר־זווית": "right", "ישר-זווית": "right", "ישר זווית": "right",
}

# --- G42: division is NEVER written with ':' or '÷' (HOUSE RULE, Noam, Aug 2026)
# A division exercise is a STACKED fraction (\f / m:f / span.frac), a mixed
# number, or words ("12 לחלק ל-4") — never `12:4`, never `÷`.
# BUT the same ASCII colon is MANDATED elsewhere by this very skill:
#   * G19 forces יחס as `a:b` (never a stacked fraction),
#   * the LAYOUT RULE forces scale as `1:200` inside figure intros,
#   * clock times (`14:30`) appear in rate/schedule word problems.
# So the discriminator is CONTEXT, not the glyph. A digit:digit pattern is
# treated as colon-division (blocking) unless the SAME question justifies it.
COLON_DIV_RE = re.compile(r"(?<!\d)\d+\s*:\s*\d+(?!\d)")
TIME_RE = re.compile(r"(?<!\d)\d{1,2}\s*:\s*[0-5]\d(?!\d)")
LETTER_RATIO_RE = re.compile(r"[A-Z]{1,2}\s*:\s*[A-Z]{1,2}")   # AE:ED
RATIO_CONTEXT = ("יחס", "ביחס", "היחס", "קנה מידה", "קנה־מידה", "קנה-מידה")
TIME_CONTEXT = ("שעה", "שעות", "השעה", "שעון", "זמן", "דקות",
                "בבוקר", "בערב", "בצהריים", "חצות", "לו״ז", "לוח זמנים")
# ÷ has no legitimate use on any sheet. The colon CONFUSABLES are banned
# unconditionally too — even a legitimate ratio uses ASCII ':' (same codepoint
# doctrine as G41's `·`): U+2236 RATIO, U+A789 MODIFIER COLON, U+FF1A FULLWIDTH.
BANNED_DIV_CHARS = {"÷": "U+00F7 DIVISION SIGN",
                    "∶": "U+2236 RATIO (use ASCII ':')",
                    "꞉": "U+A789 MODIFIER COLON (use ASCII ':')",
                    "：": "U+FF1A FULLWIDTH COLON (use ASCII ':')"}


def walk(obj, path=""):
    """Yield (json_path, string) for every string in the document."""
    if isinstance(obj, dict):
        for k, v in obj.items():
            yield from walk(v, f"{path}.{k}")
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            yield from walk(v, f"{path}[{i}]")
    elif isinstance(obj, str):
        yield path, obj


def find_questions(doc):
    """Return [(label, subtree)] — schema-tolerant. Supports BOTH:
    (a) a bare top-level list of question dicts (each carrying n/num/id),
    (b) any list under a key containing 'question'/'items'/'שאל' whose
    members are dicts."""
    if (
        isinstance(doc, list)
        and doc
        and all(isinstance(e, dict) for e in doc)
        and any(("n" in e or "num" in e or "id" in e) for e in doc)
    ):
        return [
            (f"#{e.get('n') or e.get('num') or e.get('id')}", e) for e in doc
        ]
    found = []

    def rec(obj, path):
        if isinstance(obj, dict):
            for k, v in obj.items():
                if (
                    isinstance(v, list)
                    and v
                    and all(isinstance(e, dict) for e in v)
                    and re.search(r"question|items|שאל", k, re.I)
                ):
                    for i, e in enumerate(v):
                        label = str(
                            e.get("n") or e.get("num") or e.get("id") or (i + 1)
                        )
                        found.append((f"{path}.{k}#{label}", e))
                else:
                    rec(v, f"{path}.{k}")
        elif isinstance(obj, list):
            for i, v in enumerate(obj):
                rec(v, f"{path}[{i}]")

    rec(doc, "")
    return found or [("<whole-document>", doc)]


def text_of(sub):
    return "\n".join(s for _, s in walk(sub))


def answer_text_of(sub):
    return "\n".join(
        s for p, s in walk(sub) if re.search(r"answer|ans|תשוב|solution", p, re.I)
    )


# ----------------------------------------------------------------------------
# 4. the gates
# ----------------------------------------------------------------------------

class Fail(list):
    def add(self, gate, where, msg):
        self.append(f"{gate}  [{where}]  {msg}")


def lid_match(qid, e):
    """Ledger-id ↔ question-id matching without the '6'~'16' substring trap:
    exact match, or one side ends with '#'+other (labels look like
    'content.json.questions#6ד')."""
    return e == qid or e.endswith("#" + qid) or qid.endswith("#" + e)


def g31_triangle_reality(qs, fails):
    """Every numeric side-triple in the sheet must be a REAL triangle, and any
    triple the sheet calls impossible must actually be impossible.

    Catches both directions of the shipped bug:
      (10,10,20) printed as an answer   -> degenerate, blocked
      (6,6,10) called 'not a triangle'  -> it is one, blocked
    """
    for label, sub in qs:
        body = text_of(sub)
        if "משולש" not in body:
            continue
        spans = [m.span() for m in TRIPLE_RE.finditer(body)]
        # bind each denial to the ONE triple nearest to it — a denial that
        # belongs to (6,6,10) must not also condemn the (6,8,8) beside it
        denied_idx = set()
        for d in DENIAL:
            for dm in re.finditer(re.escape(d), body):
                if not spans:
                    break
                dc = (dm.start() + dm.end()) / 2
                near = min(range(len(spans)),
                           key=lambda i: abs((spans[i][0] + spans[i][1]) / 2 - dc))
                if abs((spans[near][0] + spans[near][1]) / 2 - dc) < 120:
                    denied_idx.add(near)
        for idx, m in enumerate(TRIPLE_RE.finditer(body)):
            a, b, c = (float(g.replace(",", ".")) for g in m.groups())
            if min(a, b, c) <= 0:
                continue
            denied = idx in denied_idx
            real = tri_ok(a, b, c)
            if not real and not denied:
                why = "מנוון (a+b=c)" if abs(min(a, b) + sorted((a, b, c))[1] - max(a, b, c)) < EPS \
                      else "מפר את אי־שוויון המשולש"
                fails.add("G31", label, f"({a:g},{b:g},{c:g}) {why} — אך מוצג כמשולש")
            if real and denied:
                fails.add(
                    "G31", label,
                    f"({a:g},{b:g},{c:g}) הוא משולש תקין, אך הטקסט/התשובה טוענים שלא",
                )


def g32_universal_claims(qs, ledger_ids, fails):
    """A universal or existence-denying sentence needs a ledger entry.

    'בהיקף אי־זוגי לעולם אין משולש שווה־צלעות' must be registered by verify.py
    via no_counterexample(...) over a bounded domain. Registering it is what
    kills it: the search finds 9 = 3+3+3 immediately.
    """
    for label, sub in qs:
        body = text_of(sub)
        hits = [w for w in UNIVERSAL + DENIAL if w in body]
        if not hits:
            continue
        qid = label.split("#")[-1]
        if not any(lid_match(qid, e) for e in ledger_ids):
            fails.add(
                "G32", label,
                f"טענה כוללת/שלילת קיום ({hits[0]!r}) בלי רישום ב-verified.json — "
                "הריצו no_counterexample על תחום חסום ורשמו ב-Ledger",
            )


def g33_enumeration(qs, ledger_ids, fails):
    """'list all / which of these / is it possible' answers must come from an
    enumeration recorded in the ledger, never from reasoning in the head."""
    for label, sub in qs:
        body = text_of(sub)
        if not any(k in body for k in ENUMERATE):
            continue
        qid = label.split("#")[-1]
        if not any(lid_match(qid, e) for e in ledger_ids):
            fails.add(
                "G33", label,
                "פריט 'כל האפשרויות / אילו / האם ייתכן' בלי מנייה רשומה ב-verified.json",
            )


def g35_cardinality(qs, fails):
    """Singular question, plural answer (and the reverse)."""
    for label, sub in qs:
        body = text_of(sub)
        ans = answer_text_of(sub) or ""
        if not ans:
            continue
        if any(s in body for s in SINGULAR_ASK):
            members = [p for p in re.split(r"[;,،]| וגם ", ans) if re.search(r"\d", p)]
            if len(members) > 1:
                fails.add(
                    "G35", label,
                    f"השאלה מנוסחת ביחיד אך התשובה מונה {len(members)} פריטים — "
                    "נסחו ברבים או צמצמו את התשובה",
                )
        if "רשמו את כל" in body and ans and not re.search(r"[;,،]", ans):
            fails.add("G35", label, "'רשמו את כל' עם תשובה בת פריט אחד — מנייה או ניסוח")


def g42_no_colon_division(qs, fails, band="middle"):
    """Division is NEVER written `12:4` and NEVER `÷` — stacked fraction,
    mixed number, or words. Questions AND answers.

    BAND RULE (יסודי): in the ELEMENTARY band (`"band": "elementary"` in the
    content.json meta) the colon IS the standard division sign in Israeli
    textbooks (`25 : 5 =`) — so the digit:digit pattern is legal there.
    What stays banned in EVERY band, no exceptions: ÷ and the colon
    lookalike codepoints (U+2236 / U+A789 / U+FF1A).

    A digit:digit colon survives only when the question's own text marks it
    as something that IS written with a colon in this skill:
      * ratio / scale context word (יחס / קנה מידה …) — the G19 convention,
      * a letter-pair split like AE:ED on the same question (its numeric
        counterpart `2:3` is the same ratio),
      * a clock-shaped match (`14:30`) WITH a clock word (שעה / דקות / …).
    Anything else is a division exercise wearing ratio's clothes: FAIL, and
    the fix is a `\\f{a}{b}` stacked fraction — never deleting the colon into
    an inline slash. ÷ and colon-lookalike codepoints fail unconditionally.
    """
    for label, sub in qs:
        body = text_of(sub)
        for ch, name in BANNED_DIV_CHARS.items():
            if ch in body:
                fails.add("G42", label,
                          f"תו אסור {name} — חילוק נכתב כשבר מדורג בלבד")
        # ratio exemption is PER-MATCH and clause-scoped: a ratio word
        # justifies only a colon that follows it with NO sentence-final
        # punctuation in between — so "יחס … 2:5. וגם חשבו: 12:4" still
        # fails on the `12:4`. A letter-pair split (AE:ED) stays
        # question-wide — its numeric counterpart may sit anywhere in it.
        letter_ratio = bool(LETTER_RATIO_RE.search(body))
        ratio_words = [wm.start() for w in RATIO_CONTEXT
                       for wm in re.finditer(re.escape(w), body)]
        time_spans = ([t.span() for t in TIME_RE.finditer(body)]
                      if any(w in body for w in TIME_CONTEXT) else [])
        for m in COLON_DIV_RE.finditer(body):
            if band == "elementary":
                continue  # `25 : 5` הוא סימן החילוק התקני ביסודי (ראו hebrew-rtl.md §8ב)
            if band == "elementary-ab":
                continue
            if letter_ratio:
                continue
            if any(rs < m.start()
                   and not re.search(r"[.!?\n]", body[rs:m.start()])
                   for rs in ratio_words):
                continue
            if any(ts <= m.start() and m.end() <= te for ts, te in time_spans):
                continue
            frag = body[max(0, m.start() - 12):m.end() + 12].replace("\n", " ")
            fails.add("G42", label,
                      f"חילוק בנקודתיים: „…{frag}…” — אין דבר כזה `12:4` ואין ÷; "
                      "כתבו שבר מדורג (\\f), שבר מעורב, או במילים; "
                      "יחס/קנה־מידה/שעה מזוהים לפי מילת הקשר בשאלה עצמה")


def g38_sides_vs_angles(qs, fails):
    """Sides and angles quoted together must satisfy the law of cosines."""
    for label, sub in qs:
        body = text_of(sub)
        if "משולש" not in body:
            continue
        for m in TRIPLE_RE.finditer(body):
            after = body[m.end(): m.end() + 160]
            angs = re.findall(rf"({NUM})\s*°", after)
            if len(angs) < 3:
                continue
            sides = [float(g.replace(",", ".")) for g in m.groups()]
            angles = [float(a.replace(",", ".")) for a in angs[:3]]
            if abs(sum(angles) - 180) > 0.5:
                fails.add("G38", label, f"סכום הזוויות {sum(angles):g}° ≠ 180°")
            elif not sides_angles_consistent(sides, angles):
                fails.add(
                    "G38", label,
                    f"הצלעות {tuple(sides)} אינן נושאות את הזוויות {tuple(angles)} — "
                    "מספרים 'נוחים' שאינם ניתנים לבנייה",
                )


POLY_RE = re.compile(r'<(?:polygon|polyline)[^>]*points="([^"]+)"')


def _tris_in_svg(path):
    try:
        s = open(path, encoding="utf8").read()
    except OSError:
        return []
    out = []
    for pts in POLY_RE.findall(s):
        P = []
        for tok in pts.replace(",", " ").split():
            try:
                P.append(float(tok))
            except ValueError:
                P = []
                break
        if not P or len(P) % 2:
            continue
        V = list(zip(P[0::2], P[1::2]))
        if len(V) >= 2 and dist(V[0], V[-1]) < 1e-6:
            V = V[:-1]
        if len(V) == 3:
            out.append(V)
    return out


def g34_figure_matches_words(qs, work, fails, tol_pct=3.0):
    """A shape the TEXT calls isosceles/equilateral/right must be DRAWN so.

    This is the roof bug (רמה ב׳ Q15): the prose said the roof is isosceles and
    the key said the base angles are 70°, while the drawing had two unequal
    slopes and ~40°/70°. A student measuring the picture gets a different sheet
    than a student reading the words.
    """
    svgs = {os.path.basename(p): p for p in glob.glob(os.path.join(work, "**", "*.svg"), recursive=True)}
    for label, sub in qs:
        body = text_of(sub)
        want = {SHAPE_WORDS[w] for w in SHAPE_WORDS if w in body}
        if not want:
            continue
        refs = [
            os.path.basename(s)
            for _, s in walk(sub)
            if s.lower().endswith(".svg") or s.lower().endswith(".png")
        ]
        cands = []
        for r in refs:
            key = os.path.splitext(r)[0] + ".svg"
            if key in svgs:
                cands.append(svgs[key])
        if not cands:
            continue
        for svg in cands:
            tris = _tris_in_svg(svg)
            if not tris:
                continue
            ok = False
            for V in tris:
                L = sorted(dist(V[i], V[(i + 1) % 3]) for i in range(3))
                kind = tri_kind(*L, tol=max(L) * tol_pct / 100.0)
                if not kind:
                    continue
                by_side, by_angle = kind
                got = {by_side, by_angle}
                if by_side == "equilateral":
                    got.add("isosceles")
                if want <= got:
                    ok = True
                    break
            if not ok:
                drawn = [
                    tri_kind(*sorted(dist(V[i], V[(i + 1) % 3]) for i in range(3)),
                             tol=1e-3)
                    for V in tris
                ]
                fails.add(
                    "G34", label,
                    f"הטקסט אומר {'/'.join(sorted(want))} אך {os.path.basename(svg)} משורטט "
                    f"{drawn} — השרטוט סותר את הנתון",
                )


ANS_NUM_RE = re.compile(rf"({NUM})\s*(°|ס\"מ|ס״מ|סמ\"ר|סמ״ר)")


def g36_figure_assert(qs, ledger_ids, fails):
    """A question with a FIGURE and a numeric answer needs a drawn-geometry assert.

    G34 compares shape WORDS to the drawing; it cannot see role. The roof
    question is isosceles in the drawing yet its BASE angles are 40°/70° —
    the equal pair sits on the wrong side, so the printed 70° is unmeasurable
    on the picture the student is told to measure. No generic parser recovers
    'which side is the base'. So the author must assert it, in verify.py:

        L.claim("B_Q15", "זוויות הבסיס בגג המשורטט",
                (abs(angle_deg(A, B, C) - 70) < 1 and abs(angle_deg(B, A, C) - 70) < 1, "70/70"),
                method="figure_assert")

    and this gate fails the build when that assert is missing. Cheap to write,
    and it is the only thing that would have caught the shipped defect.
    """
    for label, sub in qs:
        has_fig = any(
            s.lower().endswith((".svg", ".png")) for _, s in walk(sub)
        )
        ans = answer_text_of(sub)
        if not (has_fig and ans and ANS_NUM_RE.search(ans)):
            continue
        qid = label.split("#")[-1]
        if not any(lid_match(qid, e) for e in ledger_ids):
            fails.add(
                "G36", label,
                "שרטוט + תשובה מספרית בלי figure_assert ב-verified.json — "
                "ודאו בקוד שהערך הנדרש נמדד בפועל בשרטוט",
            )


def g37_delivery(zip_path, fails, want_docx=False):
    """Every level folder (if the zip uses level folders) ships ≥1 PDF, and
    the Hebrew names carry the UTF-8 flag. DOCX per folder is required only
    when want_docx=True (this skill's standard delivery is PDF-only)."""
    if not zip_path or not os.path.exists(zip_path):
        return
    with zipfile.ZipFile(zip_path) as z:
        infos = z.infolist()
        names = [i.filename for i in infos]
        if not all(i.flag_bits & 0x800 for i in infos):
            fails.add("G37", os.path.basename(zip_path),
                      "לא כל הרשומות מסומנות UTF-8 (0x800) — שמות עברית ייפתחו כג'יבריש")
        levels = {n.split("/")[0] for n in names if "/" in n}
        for lv in sorted(levels):
            inside = [n for n in names if n.startswith(lv + "/")]
            has = lambda ext: any(n.lower().endswith(ext) for n in inside)
            if not has(".pdf"):
                fails.add("G37", lv, "אין PDF בתיקיית הרמה")
            if want_docx and not has(".docx"):
                fails.add("G37", lv, "אין DOCX בתיקיית הרמה — הדף אינו ניתן לעריכה")
            if not has(".svg"):
                fails.add("G37", lv, "אין קובצי SVG מקור בתיקיית הרמה")


def g39_skill_integrity(skill_dir, fails):
    """Every path SKILL.md points at must exist, and the frontmatter must be
    installable. A rule enforced by a file that was never bundled is not a rule —
    it is a wish; and a skill that fails validation never loads at all."""
    md = os.path.join(skill_dir, "SKILL.md")
    if not os.path.exists(md):
        return
    src = open(md, encoding="utf8").read()

    # frontmatter limits — the installer rejects a description over 1024 chars
    if src.startswith("---\n") and "\n---\n" in src[4:]:
        fm = src[4:].split("\n---\n", 1)[0]
        m = re.search(r"description: >-\n((?:  .*\n)+)", fm)
        desc = " ".join(l.strip() for l in m.group(1).strip().splitlines()) if m else ""
        if not desc:
            fails.add("G39", "SKILL.md", "אין שדה description בפרונט־מטר")
        elif len(desc) > 1024:
            fails.add("G39", "SKILL.md",
                      f"description באורך {len(desc)} תווים — המגבלה 1024, חריגה של {len(desc)-1024}")
        if not re.search(r"^name: [a-z0-9-]+$", fm, re.M):
            fails.add("G39", "SKILL.md", "שדה name חסר או אינו kebab-case")
    else:
        fails.add("G39", "SKILL.md", "פרונט־מטר YAML חסר או פגום")

    refs = set(re.findall(r"`((?:scripts/|curriculum_)[A-Za-z0-9_./-]+)`", src))
    for r in sorted(refs):
        if not os.path.exists(os.path.join(skill_dir, r)):
            fails.add("G39", "SKILL.md", f"מפנה לקובץ שאינו קיים בסקיל: {r}")


# ----------------------------------------------------------------------------
# 5. CLI
# ----------------------------------------------------------------------------

def band_of(doc):
    """Grade band of a content.json: "elementary" / "elementary-ab" (א׳–ב׳,
    ניקוד) / "middle" (ברירת מחדל — חטיבה). נקרא מ-meta:
      {"meta": {"band": "elementary", "grade": "ג", "level": "ב"}, "questions": [...]}
    או שדה "band" ברמה העליונה. בסקיל היסודי ברירת המחדל "elementary" —
    content.json בלי band מפורש נבדק ככיתות ג׳–ו׳ (רשמו band תמיד!)."""
    if isinstance(doc, dict):
        meta = doc.get("meta") if isinstance(doc.get("meta"), dict) else {}
        b = meta.get("band") or doc.get("band") or ""
        b = str(b).strip().lower()
        if b in ("elementary", "elementary-ab", "middle"):
            return b
    return "elementary"


def run(work=".", zip_path=None, skill_dir=None, want_docx=False, quiet=False):
    fails = Fail()
    content_paths = sorted(glob.glob(os.path.join(work, "**", "content*.json"), recursive=True))
    ledger_ids = []
    for lp in glob.glob(os.path.join(work, "**", "verified*.json"), recursive=True):
        try:
            ledger_ids += [c["id"] for c in json.load(open(lp, encoding="utf8"))["claims"]]
        except Exception:
            pass

    for cp in content_paths:
        doc = json.load(open(cp, encoding="utf8"))
        band = band_of(doc)
        qs = find_questions(doc)
        tag = os.path.basename(cp)
        qs = [(f"{tag}{lbl}", sub) for lbl, sub in qs]
        g31_triangle_reality(qs, fails)
        g32_universal_claims(qs, ledger_ids, fails)
        g33_enumeration(qs, ledger_ids, fails)
        g35_cardinality(qs, fails)
        g42_no_colon_division(qs, fails, band=band)
        g38_sides_vs_angles(qs, fails)
        g36_figure_assert(qs, ledger_ids, fails)
        g34_figure_matches_words(qs, work, fails)

    g37_delivery(zip_path, fails, want_docx=want_docx)
    if skill_dir:
        g39_skill_integrity(skill_dir, fails)

    if fails:
        if not quiet:
            print("CONTENT-TRUTH GATES: FAIL\n" + "-" * 60)
            for f in fails:
                print(" ✗ " + f)
            print("-" * 60)
            print(f"{len(fails)} blocking content defect(s). Do not deliver.")
        return 1
    if not quiet:
        print(f"CONTENT-TRUTH GATES: PASS  ({len(content_paths)} content file(s), "
              f"{len(ledger_ids)} recorded claim(s))")
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(description="Math-truth gates G31–G39 + G42")
    ap.add_argument("--work", default=".")
    ap.add_argument("--zip", dest="zip_path", default=None)
    ap.add_argument("--skill-dir", default=None)
    ap.add_argument("--docx", action="store_true",
                    help="require a DOCX in every level folder of --zip "
                         "(this skill's default delivery is PDF-only)")
    ap.add_argument("--quiet", action="store_true")
    a = ap.parse_args(argv)
    return run(a.work, a.zip_path, a.skill_dir, a.docx, a.quiet)


if __name__ == "__main__":
    sys.exit(main())
