#!/usr/bin/env python3
"""G45 + G46 — render-integrity gates on the FINAL PDF.

Both exist because five shipped packages (35-39, Aug 2026) passed every gate in
this skill and were still wrong:

G45 (body-font identity). G43-F5 only asked for ">=1 embedded Hebrew-capable
font" and named FreeSerif as acceptable. Packages 36-39 shipped with the ENTIRE
body in FreeSerif and David Libre present on just 3 spans per page (בס״ד + two
brand lines) — so F5 passed on the strength of the running head alone. A font
gate must assert WHICH font carries the body, not that some Hebrew font exists.

G46 (figure placement). A figure that is emitted but drawn off-page is invisible
to every count-based check. A `float:left` figure inside an RTL flex item
rendered at bbox=[0, 218, -294, 341] — negative width, off the left edge —
while the page still reserved its space, so the sheet showed a white hole and
the image count matched exactly. Count presence AND geometry.

Usage:  python3 check_render_integrity.py built.pdf [--src original.pdf]
        python3 check_render_integrity.py --selftest
"""
import subprocess
import sys

PAGE_W, PAGE_H = 595.28, 841.89
HOUSE_BODY = ("david libre", "david-libre", "davidlibre")
# Fallback faces that are fine for a stray symbol but must never carry the body.
SYMBOL_ONLY = ("dejavu", "freeserif", "notosans", "wenquanyi", "helvetica")


def _fonts(pdf):
    try:
        out = subprocess.run(["pdffonts", str(pdf)], capture_output=True,
                             text=True, check=True).stdout
    except Exception:
        return None
    names = []
    for line in out.splitlines()[2:]:
        if line.strip():
            names.append(line.split()[0].split("+")[-1])
    return names


# Glyphs a Hebrew serif legitimately lacks. A span made only of these is a
# DELIBERATE pin, not a fallback accident, and must not count against the body.
SYM_CHARS = set("\u2605\u2221\u00b0\u2190\u2192\u00b1\u2264\u2265\u00f7"
                "\u2212\u221a\u2248\u2260")


def _spans_by_font(pdf):
    """Map font-name -> number of CHARACTERS carried, ignoring spans that
    consist solely of pinned symbols. Characters, not spans: wrapping each
    symbol in its own <span> inflates a span count and would make a correctly
    pinned sheet look like a fallback leak."""
    import pymupdf
    tally = {}
    doc = pymupdf.open(str(pdf))
    for page in doc:
        for blk in page.get_text("dict")["blocks"]:
            if blk["type"] != 0:
                continue
            for line in blk["lines"]:
                for sp in line["spans"]:
                    txt = sp["text"].strip()
                    if not txt or all(c in SYM_CHARS for c in txt):
                        continue
                    name = sp["font"].split("+")[-1]
                    tally[name] = tally.get(name, 0) + len(txt)
    return tally


def _word_chars_by_font(pdf):
    """Map font-name -> count of DIGIT + HEBREW characters only (v2.0.1).
    Symbols (★ ☐ …) legitimately fall back; digits and Hebrew never should."""
    import pymupdf
    import re as _re
    rx = _re.compile(r"[0-9\u0590-\u05FF]")
    tally = {}
    for page in pymupdf.open(str(pdf)):
        for blk in page.get_text("dict")["blocks"]:
            if blk["type"] != 0:
                continue
            for line in blk["lines"]:
                for sp in line["spans"]:
                    n = len(rx.findall(sp["text"]))
                    if n:
                        name = sp["font"].split("+")[-1]
                        tally[name] = tally.get(name, 0) + n
    return tally


def g45_body_font(pdf):
    """FAIL unless the modal Hebrew-bearing font is David Libre."""
    fails = []
    tally = _spans_by_font(pdf)
    if not tally:
        return ["G45: no text spans found — extraction or build is broken"]
    body, n = max(tally.items(), key=lambda kv: kv[1])
    total = sum(tally.values())
    if not any(h in body.lower() for h in HOUSE_BODY):
        fails.append("G45: body font is %r (%d/%d chars), expected David Libre"
                     % (body, n, total))
    # A symbol-only face carrying a real share of the text is the same defect
    # wearing a different hat (e.g. WenQuanYi picked up as a ★ fallback and
    # then quietly used for prose).
    for name, cnt in tally.items():
        if cnt > max(20, 0.05 * total) and any(s in name.lower() for s in SYMBOL_ONLY):
            fails.append("G45: fallback face %r carries %d/%d chars of prose — "
                         "pin the glyph it was pulled in for to an explicit "
                         "family, or render it as a math path"
                         % (name, cnt, total))
    # v2.0.1: digits and Hebrew letters have NO business in a fallback face at
    # ANY meaningful count — 19 SVG long-division digits rode Noto-Sans under
    # the 20-char threshold above (svg <text font-family="inherit"> does not
    # inherit @font-face in WeasyPrint). Stricter floor for word characters.
    word = _word_chars_by_font(pdf)
    for name, cnt in word.items():
        if cnt > 5 and not any(h in name.lower() for h in HOUSE_BODY):
            fails.append("G45: %d digits/Hebrew chars in non-house face %r — "
                         "SVG text must pin font-family=\"David Libre\" "
                         "explicitly (\"inherit\" falls back in WeasyPrint)"
                         % (cnt, name))
    return fails


def g46_figures(pdf, src=None):
    """Every figure must be ON the page with positive width/height."""
    import pymupdf
    fails = []
    placed = []
    for page in pymupdf.open(str(pdf)):
        for blk in page.get_text("dict")["blocks"]:
            if blk["type"] != 1:
                continue
            x0, y0, x1, y1 = blk["bbox"]
            placed.append((page.number + 1, blk["bbox"]))
            if x1 <= x0 or y1 <= y0:
                fails.append("G46: p%d figure has non-positive size %s — a "
                             "mirrored/negative CTM draws it off-canvas"
                             % (page.number + 1, [round(v) for v in blk["bbox"]]))
            elif x0 < -1 or y0 < -1 or x1 > PAGE_W + 1 or y1 > PAGE_H + 1:
                fails.append("G46: p%d figure outside the page box %s"
                             % (page.number + 1, [round(v) for v in blk["bbox"]]))
    if src is not None:
        n_src = sum(1 for page in pymupdf.open(str(src))
                    for blk in page.get_text("dict")["blocks"] if blk["type"] == 1)
        if n_src != len(placed):
            fails.append("G46: figure count %d != source %d" % (len(placed), n_src))
    # VECTOR pass (v2.0.1): WeasyPrint draws inline <svg> as vector paths, not
    # image blocks — the loop above sees NOTHING for svg_elementary figures
    # (empirically: a real sheet with 7 figures = 93 drawings, 0 image blocks).
    # WeasyPrint clips overflow at the page edge but still emits the full path
    # geometry, so an oversized figure (e.g. place_value_blocks 999 at 1249px)
    # is detectable here and ONLY here.
    for page in pymupdf.open(str(pdf)):
        worst = None
        for d in page.get_drawings():
            r = d["rect"]
            if r.x0 < -2 or r.y0 < -2 or r.x1 > PAGE_W + 2 or r.y1 > PAGE_H + 2:
                if worst is None or r.x1 > worst.x1:
                    worst = r
        if worst is not None:
            fails.append("G46: p%d vector drawing extends past the page box "
                         "(reaches x=%d, page is %d) — an oversized SVG is "
                         "being clipped; shrink the figure"
                         % (page.number + 1, round(worst.x1), round(PAGE_W)))
    return fails


def check(pdf, src=None):
    return g45_body_font(pdf) + g46_figures(pdf, src)


def _selftest():
    """Both directions: the gates must FIRE on the known-bad shapes and stay
    quiet on the known-good ones. No live PDF needed — the predicates are
    exercised directly."""
    ok = True

    good = {"David-Libre": 300, "David-Libre-Bold": 120, "DejaVu-Serif": 3}
    bad = {"FreeSerif": 293, "FreeSerif-Bold": 142, "DavidLibre-Regular": 24}

    def body_of(t):
        return max(t.items(), key=lambda kv: kv[1])[0]

    if not any(h in body_of(good).lower() for h in HOUSE_BODY):
        print("SELFTEST FAIL: good font tally rejected"); ok = False
    if any(h in body_of(bad).lower() for h in HOUSE_BODY):
        print("SELFTEST FAIL: pkg36-39 font tally accepted"); ok = False

    boxes = {"good": (50, 232, 182, 340), "shipped_bug": (0, 218, -294, 341)}
    for name, (x0, y0, x1, y1) in boxes.items():
        broken = x1 <= x0 or y1 <= y0 or x0 < -1 or x1 > PAGE_W + 1
        if name == "good" and broken:
            print("SELFTEST FAIL: valid figure bbox rejected"); ok = False
        if name == "shipped_bug" and not broken:
            print("SELFTEST FAIL: off-page figure bbox accepted"); ok = False

    # vector predicate (v2.0.1) — clipped-SVG shape from place_value_blocks 999
    vec = {"good": (51.0, 100.0, 544.0, 300.0),
           "clipped_svg": (51.0, 236.0, 983.3, 341.0)}
    for name, (x0, y0, x1, y1) in vec.items():
        broken = x0 < -2 or y0 < -2 or x1 > PAGE_W + 2 or y1 > PAGE_H + 2
        if name == "good" and broken:
            print("SELFTEST FAIL: valid vector rect rejected"); ok = False
        if name == "clipped_svg" and not broken:
            print("SELFTEST FAIL: clipped oversized SVG accepted"); ok = False

    # word-chars predicate (v2.0.1) — the 19 SVG digits that rode Noto-Sans
    def word_broken(tally):
        return any(cnt > 5 and not any(h in nm.lower() for h in HOUSE_BODY)
                   for nm, cnt in tally.items())
    if word_broken({"David-Libre": 600, "DejaVu-Sans": 1}):
        print("SELFTEST FAIL: lone ★-fallback star rejected"); ok = False
    if not word_broken({"David-Libre": 943, "Noto-Sans": 19}):
        print("SELFTEST FAIL: 19 SVG digits in Noto-Sans accepted"); ok = False

    print("SELFTEST PASS" if ok else "SELFTEST FAILED")
    return 0 if ok else 1


if __name__ == "__main__":
    if "--selftest" in sys.argv:
        sys.exit(_selftest())
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    src = None
    if "--src" in sys.argv:
        src = sys.argv[sys.argv.index("--src") + 1]
        args = [a for a in args if a != src]
    problems = check(args[0], src)
    for p in problems:
        print(p)
    print("G45/G46: %s" % ("FAIL" if problems else "PASS"))
    sys.exit(1 if problems else 0)
