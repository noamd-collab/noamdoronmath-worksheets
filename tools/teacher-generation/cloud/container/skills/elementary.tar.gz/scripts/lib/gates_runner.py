#!/usr/bin/env python3
"""Single entry point for the OUTPUT gates. build.py MUST call this.

Why this file exists: G42's render half and G43-F2 were both defined, both
correct, and both shipped broken packages — because nothing asserted they had
actually RUN. A gate that silently skips (missing extractor, HTML stem != PDF
stem, a sweep scoped to question text so the answers page is never read) is
indistinguishable from a gate that passed. So every check here reports one of
PASS / FAIL / SKIPPED, and **SKIPPED is a build failure**, not a warning.

    from gates_runner import run_output_gates
    run_output_gates(pdf_paths, src_pdfs=None, strict=True)   # raises on FAIL

CLI:  python3 gates_runner.py out/*.pdf
      python3 gates_runner.py --selftest
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

PASS, FAIL, SKIPPED = "PASS", "FAIL", "SKIPPED"
DIVISION_GLYPHS = ("\u00f7", "\u2236", "\ua789", "\uff1a")


def _text(pdf):
    """Full text of EVERY page — answers included. Returns None if no
    extractor is available, which is a SKIPPED, never a quiet pass."""
    try:
        import pymupdf
        return "".join(p.get_text("text") for p in pymupdf.open(str(pdf)))
    except Exception:
        pass
    try:
        import subprocess
        return subprocess.run(["pdftotext", "-enc", "UTF-8", str(pdf), "-"],
                              capture_output=True, text=True, check=True).stdout
    except Exception:
        return None


def g42_render_half(pdf, colon_division_ok=False, band="elementary"):
    """`÷`, the colon lookalikes AND the plain ASCII colon, swept over ALL
    pages.  The three `÷` that shipped in the זוויות package were every one
    of them on the answers page.

    Aug 2026 — the ASCII half was MISSING.  DIVISION_GLYPHS listed U+00F7,
    U+2236, U+A789 and U+FF1A but not U+003A, so a sheet with 62 division
    colons returned PASS.  Half of this gate had never executed.  Pass
    `colon_division_ok=True` only for a sheet whose TOPIC is operator
    precedence (`24:6·2` vs `24:(6·2)` is the question; a fraction bar
    carries implicit grouping and destroys it)."""
    t = _text(pdf)
    if t is None:
        return SKIPPED, "no PDF text extractor available"
    if len(t.strip()) < 20:
        return SKIPPED, "extracted text is empty — sweep saw nothing"
    hits = [g for g in DIVISION_GLYPHS if g in t]
    if hits:
        return FAIL, "division glyph(s) %s in rendered text" % hits
    import re
    # BAND RULE (יסודי): in band elementary / elementary-ab the ASCII colon
    # IS the standard division sign (`25 : 5 =`), so the colon half of this
    # gate is legal there.  ÷ and the colon lookalikes above fail in EVERY
    # band, and inline slash division stays banned in every band too.
    if band in ("elementary", "elementary-ab"):
        colon_division_ok = True
    if not colon_division_ok:
        n = len(re.findall(r"\d\s*:\s*\d", t))
        clock = len(re.findall(r"\b[012]?\d:[0-5]\d\b", t))
        if n - clock > 0:
            return FAIL, ("%d ASCII colon division(s) — use a stacked "
                          "fraction, or declare the precedence exception"
                          % (n - clock))
    slash = len(re.findall(r"[\d)a-zA-Z]\s*/\s*[\d(a-zA-Z]", t))
    if slash:
        return FAIL, ("%d inline slash division(s) — a division is a stacked "
                      "fraction, never `a/b`" % slash)
    return PASS, "%d chars swept" % len(t)


def g43_f2_roots(pdf):
    """Roots ship as SVG paths, so ANY root codepoint in the text layer is a
    leaked vinculum-less glyph."""
    t = _text(pdf)
    if t is None:
        return SKIPPED, "no PDF text extractor available"
    n = sum(t.count(c) for c in "\u221a\u221b\u221c")
    if n:
        return FAIL, "%d bare root codepoint(s) in the text layer" % n
    return PASS, "no bare roots"


def g45_g46(pdf, src=None):
    try:
        from check_render_integrity import check
    except Exception as e:
        return SKIPPED, "check_render_integrity unavailable: %r" % e
    problems = check(pdf, src)
    return (FAIL, "; ".join(problems)) if problems else (PASS, "body font + figures ok")


CHECKS = [("G42-render", g42_render_half),
          ("G43-F2", g43_f2_roots),
          ("G45/G46", g45_g46)]


def run_output_gates(pdfs, src_pdfs=None, strict=True, verbose=True,
                     colon_division_ok=False, band="elementary"):
    """colon_division_ok — set True ONLY for a sheet whose topic is operator
    precedence (סדר פעולות), where `24:6·2` vs `24:(6·c)` IS the question and
    a fraction bar would answer it by construction."""
    pdfs = [Path(p) for p in pdfs]
    if not pdfs:
        raise SystemExit("gates_runner: no PDFs given — a delivery gate must "
                         "run, not vanish")
    src_pdfs = src_pdfs or {}
    bad = []
    for pdf in pdfs:
        for name, fn in CHECKS:
            if name == "G45/G46":
                status, msg = fn(pdf, src_pdfs.get(pdf.name))
            elif name == "G42-render":
                status, msg = fn(pdf, colon_division_ok, band)
            else:
                status, msg = fn(pdf)
            if verbose:
                print("%-10s %-42s %-7s %s" % (name, pdf.name[:42], status, msg))
            if status in (FAIL, SKIPPED):
                bad.append((pdf.name, name, status, msg))
    if bad and strict:
        lines = "\n".join("  %s :: %s :: %s :: %s" % b for b in bad)
        raise SystemExit("BUILD BLOCKED — output gates did not all pass:\n" + lines)
    return bad


def _selftest():
    ok = True
    if g42_render_half.__doc__ is None:
        ok = False
    # SKIPPED must be treated exactly like FAIL
    fake = [("x.pdf", "G43-F2", SKIPPED, "no extractor")]
    if not fake:
        ok = False
    for st in (FAIL, SKIPPED):
        if st not in (FAIL, SKIPPED):
            ok = False
    # a text sweep must see the answers page: assert we concatenate all pages
    src = Path(__file__).read_text(encoding="utf-8")
    if "for p in pymupdf.open" not in src:
        print("SELFTEST FAIL: sweep is not over all pages"); ok = False
    if "SKIPPED is a build failure" not in src:
        print("SELFTEST FAIL: skip-is-failure doctrine missing"); ok = False
    print("SELFTEST PASS" if ok else "SELFTEST FAILED")
    return 0 if ok else 1


if __name__ == "__main__":
    if "--selftest" in sys.argv:
        sys.exit(_selftest())
    args = sys.argv[1:]
    ok = "--colon-division-ok" in args
    if ok:
        args.remove("--colon-division-ok")
    band = "elementary"
    if "--band" in args:
        index = args.index("--band")
        try:
            band = args[index + 1]
        except IndexError:
            sys.exit("--band requires middle|elementary|elementary-ab")
        del args[index:index + 2]
    try:
        run_output_gates([a for a in args if not a.startswith("-")],
                         colon_division_ok=ok, band=band)
    except SystemExit as e:
        print(e)
        sys.exit(1)
    print("ALL OUTPUT GATES PASS")
