#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""G70: bounded source lint for Hebrew answer text inside LTR containers.

Recognizes answer scopes, dir attributes, inline direction and the shipped
.ltr/.num/.frac and .answer-text/.quantity classes. This is not a browser CSS
cascade, a spellchecker, a semantic answer validator or a PDF layout check.
Use visual review for wrapping, labels, punctuation, custom CSS and omissions.
"""
from html.parser import HTMLParser
from pathlib import Path
import re

HEBREW = re.compile(r"[א-ת]")
ANSWER_SCOPES = frozenset(("answers", "ans", "answer", "answer-key",
                           "answer-text", "answer-row"))
LTR_CLASSES = frozenset(("ltr", "num", "frac"))
RTL_CLASSES = frozenset(("answer-text", "quantity"))
VOID = frozenset(("area", "base", "br", "col", "embed", "hr", "img",
                  "input", "link", "meta", "param", "source", "track", "wbr"))
IGNORED = frozenset(("script", "style", "template"))
DIRECTION = re.compile(r"(?:^|;)\s*direction\s*:\s*(ltr|rtl|inherit|initial|unset)"
                       r"\s*(?:!\s*important\s*)?(?=;|$)", re.I)


class _AnswerParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.stack = []
        self.issues = []
        self.scopes = 0
        self.text_nodes = 0

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        parent = self.stack[-1] if self.stack else (None, None, False, False)
        classes = set((attrs.get("class") or "").split())
        scope_here = bool(classes & ANSWER_SCOPES or
                          attrs.get("id") in ANSWER_SCOPES)
        self.scopes += scope_here
        scope = parent[2] or scope_here
        ignored = parent[3] or tag in IGNORED
        direction = parent[1]
        explicit = (attrs.get("dir") or "").lower()
        if explicit in ("ltr", "rtl"):
            direction = explicit
        elif explicit == "auto" or (tag == "bdi" and not explicit):
            # Automatic first-strong bidi is not an explicit LTR constraint.
            direction = None
        # Match the named rules in the distributed template. Inline CSS wins;
        # descendant dir="rtl" resets inherited LTR, while dir on .ltr does
        # not override that element's CSS class.
        if classes & LTR_CLASSES:
            direction = "ltr"
        if classes & RTL_CLASSES:
            direction = "rtl"
        style = re.sub(r"/\*.*?\*/", "", attrs.get("style") or "", flags=re.S)
        matches = list(DIRECTION.finditer(style))
        if matches:
            # Last declaration wins unless an earlier declaration is important.
            important = [m for m in matches
                         if re.search(r"!\s*important", m.group(0), re.I)]
            value = (important or matches)[-1].group(1).lower()
            direction = parent[1] if value in ("inherit", "unset") else (
                "ltr" if value == "initial" else value)
        if tag not in VOID:
            self.stack.append((tag, direction, scope, ignored))

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag not in VOID:
            self.handle_endtag(tag)

    def handle_endtag(self, tag):
        for index in range(len(self.stack) - 1, -1, -1):
            if self.stack[index][0] == tag:
                del self.stack[index:]
                break

    def handle_data(self, data):
        if not self.stack or not self.stack[-1][2] or self.stack[-1][3]:
            return
        if not HEBREW.search(data):
            return
        self.text_nodes += 1
        if self.stack[-1][1] == "ltr":
            text = re.sub(r"\s+", " ", data).strip()
            self.issues.append((self.getpos()[0], text[:100]))


def check_answer_html(source):
    """Return (ok, message); PASS means only this bounded source check passed."""
    parser = _AnswerParser()
    try:
        parser.feed(source)
        parser.close()
    except Exception as error:
        return False, "answer HTML could not be parsed: %r" % error
    if parser.issues:
        examples = "; ".join("line %s: %s" % item for item in parser.issues[:6])
        return False, "Hebrew answer text in LTR container (%s): %s" % (
            len(parser.issues), examples)
    if not parser.scopes:
        return True, ("no recognized answer scope; G70 cannot assess custom answer "
                      "markup — review it manually")
    return True, ("%s Hebrew answer text nodes checked; no known LTR prose "
                  "container. Custom CSS, meaning and rendered layout need review" %
                  parser.text_nodes)


def g70_answer_layout(html_path):
    try:
        source = Path(html_path).read_text(encoding="utf-8")
    except (OSError, UnicodeError) as error:
        return False, "answer HTML could not be read: %r" % error
    return check_answer_html(source)
