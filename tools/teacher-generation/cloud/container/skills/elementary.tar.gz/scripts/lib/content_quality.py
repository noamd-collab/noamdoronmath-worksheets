#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""content_quality.py — שערי תוכן G60–G67 ומדיניות שרטוטים G69.

עד כה כל השערים בדקו **איך הדף נראה**. ארבעת הכשלים שהחזירו את הדף
לביקורת ידנית היו כולם ב**מה כתוב בו**, ולאף אחד מהם לא היה שער:

  G60  מספרים לא יפים   — 6.667, 4/8, מכנה 91, תוצאה בת 6 ספרות בכיתה ג׳
  G61  רמה לא עקבית      — פריט מצוינות בתוך דף רמה ב׳
  G62  שאלה משעממת       — 8 סעיפים שהם אותו סעיף עם מספרים אחרים
  G63  שרטוט לא מדויק    — תווית מחוץ ל-viewBox, שתי תוויות חופפות
  G64  סימנים ב-SVG      — מקף ASCII כמינוס בתווית ציר; `12/4` בשרטוט
  G65  מציין מקום בתשובה — ארבעה מצייני מקום מדויקים, לא אימות מתמטי
  G66  כרונולוגיה        — מילות מפתח לפי הכיתה וקוד הנושא
  G67  רמזים            — שלושה רמזים וסינון דפוסי גילוי תשובה
  G69  מדיניות שרטוטים   — רק בדפי גיאומטריה, בכל חלקי המקור

G60–G62 הם שערי **תוכן** ורצים על המקור. G63–G64 רצים על ה-SVG עצמו,
כלומר **לפני** הקומפילציה — שם התיקון עולה שנייה, לא סבב מלא.

מה השערים האלה *לא* עושים, ובכוונה:
  • G61 מודד **פרוקסי** לקושי (גודל אופרנדים, מספר פעולות, עומק סוגריים).
    הוא תופס פריט חורג — הוא לא מכייל רמה. הכיול נעשה פעם אחת, בתבנית.
  • G62 תופס **חזרתיות מבנית**, לא שעמום. שאלה מקורית ומשעממת תעבור.
    זה נשאר אנושי. שמונה שיבוטים של אותו פריט — זה קוד.

  from content_quality import run_content_gates, normalize
  run_content_gates(normalize(content), content=content, figs={"roof.svg": svg})

CLI:  python3 content_quality.py content.json --profile ט/א --figdir figures
      python3 content_quality.py --selftest
"""
import json
import math
import os
import re
import sys
import unicodedata
import xml.etree.ElementTree as ET
from decimal import Decimal, InvalidOperation
from html.parser import HTMLParser

PASS, FAIL, SKIPPED, WARN = "PASS", "FAIL", "SKIPPED", "WARN"
MINUS = "\u2212"
SVG_NS = "{http://www.w3.org/2000/svg}"


# ============================================================== PROFILES ===
# One place where "what is a nice number here" and "what is this level"
# are declared. A sheet that does not name its profile does not get a
# guess — it gets a SKIPPED, which is a build failure.
class Profile:
    def __init__(self, name, max_den, max_abs, max_decimals, allow_neg,
                 band, max_spread, max_clone=3, min_variety=0.55):
        self.name = name
        self.max_den = max_den            # מכנה מרבי בתשובה
        self.max_abs = max_abs            # ערך מוחלט מרבי בתשובה
        self.max_decimals = max_decimals  # ספרות אחרי הנקודה
        self.allow_neg = allow_neg
        self.band = band                  # (min, max) ציון קושי מותר
        self.max_spread = max_spread      # פער מרבי בין הקל לקשה בדף
        self.max_clone = max_clone        # כמה פריטים זהים מבנית מותרים
        self.min_variety = min_variety    # יחס תשובות שונות/סה״כ


PROFILES = {
    # יסודי — כיתה קובעת
    "א":        Profile("א", 4, 100, 0, False, (1, 4), 3),
    "ב":        Profile("ב", 4, 1000, 0, False, (1, 5), 3),
    "ג":        Profile("ג", 10, 10_000, 1, True, (2, 6), 4),
    "ד":        Profile("ד", 12, 100_000, 2, True, (2, 7), 4),
    "ה":        Profile("ה", 20, 1_000_000, 2, True, (3, 8), 5),
    "ו":        Profile("ו", 25, 1_000_000, 2, True, (3, 9), 5),
    # חטיבה — רמת הקבצה קובעת (ב׳ < א׳ < מצוינות)
    "ב׳":       Profile("ב׳", 12, 10_000, 2, True, (1, 7), 7),
    "א׳":       Profile("א׳", 24, 100_000, 2, True, (2, 10), 8,
                        max_clone=4),
    "מצוינות":  Profile("מצוינות", 60, 1_000_000, 3, True, (3, 16), 9,
                        max_clone=2, min_variety=0.70),
}
ALIAS = {"A": "א׳", "B": "ב׳", "EXC": "מצוינות", "excellence": "מצוינות",
         "a": "א׳", "b": "ב׳"}


def get_profile(spec, prefer_middle=False):
    """Resolve an explicit grade/level profile.

    Bare ``א``/``ב`` are elementary grades unless ``prefer_middle`` is true.
    In a compound middle-school declaration such as ``ט/א`` the trailing
    letter is a level and is interpreted as ``א׳``/``ב׳``.
    """
    if not spec:
        return None
    parts = [p.strip() for p in str(spec).replace("|", "/").split("/")
             if p.strip()]
    compound_middle = len(parts) > 1 and parts[0] not in ELEM_GRADES
    for part in reversed(parts):
        p = re.sub(r"^רמ(?:ה|ת)\s+", "", part).strip()
        p = ALIAS.get(p, p)
        if p in ("א", "ב") and (prefer_middle or compound_middle or
                                  part.startswith(("רמה ", "רמת "))):
            p += "׳"
        if p in PROFILES:
            return PROFILES[p]
    return None


# ============================================================ NORMALIZE ===
def normalize(content):
    """Accept EITHER schema and return [{n, stem, answer, fig}].

    middle school : {"level": "A", "questions":[{n, intro, answer, fig}]}
                    or the richer {"questions":[{n, intro, items:[(lab,t,sp)]}],
                    "answers":[(n,[(lab,t)])]}
    elementary    : {"meta":{grade, level}, "questions":[{n, text, answer}]}
    """
    recs, ans_by_n = [], {}
    for a in content.get("answers", []) or []:
        try:
            by_label = {str(label): str(text) for label, text in a[1]}
            ans_by_n[str(a[0])] = (by_label, " ; ".join(by_label.values()))
        except Exception:
            pass
    for q in content.get("questions", []) or []:
        n = str(q.get("n", "?"))
        stem = q.get("intro", q.get("text", ""))
        if isinstance(stem, list):
            stem = " ".join(map(str, stem))
        stem = str(stem or "")
        items = q.get("items") or []
        direct = q.get("answer") if "answer" in q else None
        by_label, mapped = ans_by_n.get(n, ({}, ""))
        if isinstance(direct, list):
            direct = " ; ".join(map(str, direct))
        whole_answer = mapped if direct is None else str(direct)

        # Emit one record per sub-item: otherwise one hard sub-item vanishes
        # inside an easy question and mechanical clones are invisible.  In the
        # elementary schema items are often strings; treating ``it[1]`` as the
        # item text retained only one character from every exercise.
        if items:
            elementary_answers = [x.strip() for x in
                                  re.split(r"\s*;\s*", whole_answer)]
            for index, item in enumerate(items, 1):
                if isinstance(item, (list, tuple)) and len(item) >= 2:
                    label, item_text = str(item[0]), str(item[1])
                else:
                    label, item_text = str(index), str(item)
                answer = by_label.get(label)
                if answer is None and len(elementary_answers) == len(items):
                    answer = elementary_answers[index - 1]
                if answer is None:
                    answer = whole_answer
                recs.append({"n": n + label,
                             "stem": (stem + " " + item_text).strip(),
                             "context": stem,
                             "item": item_text,
                             "answer": str(answer or ""),
                             "fig": q.get("fig") or "", "items": 1,
                             "starred": bool(q.get("star") or
                                             q.get("starred"))})
            continue

        recs.append({"n": n, "stem": stem, "context": stem, "item": stem,
                     "answer": str(whole_answer or ""),
                     "fig": q.get("fig") or "", "items": 0,
                     "starred": bool(q.get("star") or q.get("starred"))})
    return recs


ELEM_GRADES = ("\u05d0", "\u05d1", "\u05d2", "\u05d3", "\u05d4", "\u05d5")
GRADE_NUMBERS = {str(i + 1): grade for i, grade in enumerate(ELEM_GRADES)}


def elementary_grade(value):
    """Canonicalize common elementary-grade spellings without consulting
    ``meta.level`` (which is a worksheet level, never a fallback grade)."""
    if value is None:
        return None
    s = str(value).strip()
    s = re.sub(r"^כיתה\s*", "", s)
    s = re.sub(r"[\s׳״'\"]", "", s)
    if s in GRADE_NUMBERS:
        return GRADE_NUMBERS[s]
    return s if s in ELEM_GRADES else None


def profile_of(content, override=None):
    """ביסודי הכיתה קובעת; בחטיבה רמת ההקבצה קובעת. `meta.level = "\u05d1"`
    ביסודי הוא **רמה** ב׳, לא **כיתה** ב׳ — הבלבול הזה נתן לדף כיתה ג׳
    את התקרה של כיתה ב׳ וחסם אותו."""
    if override:
        return get_profile(override)
    meta = content.get("meta", {}) or {}
    grade_raw = meta.get("grade") if "grade" in meta else content.get("grade")
    grade = elementary_grade(grade_raw)
    lvl = meta.get("level") or content.get("level")
    elementary = bool(grade) or str(meta.get("band", "")).startswith("elementary")
    if elementary:
        if not grade:
            return None
        P = get_profile(grade)
        if P and "מצוינות" in str(lvl or ""):
            P = Profile(P.name + "/\u05de\u05e6\u05d5\u05d9\u05e0\u05d5\u05ea", P.max_den,
                        P.max_abs, P.max_decimals, P.allow_neg,
                        (P.band[0] + 2, P.band[1] + 3), P.max_spread + 2,
                        max_clone=2, min_variety=0.70)
        if P:
            return P
    return get_profile(lvl, prefer_middle=True) or get_profile(
        grade_raw, prefer_middle=True)


# ================================================== G60  UGLY NUMBERS  ===
FRAC_BRACE = re.compile(r"\\(?:f|frac)\{\s*(-?\d+)\s*\}\{\s*(-?\d+)\s*\}")
FRAC_SLASH = re.compile(r"(?<![\d.,])(-?\d+)\s*[/⁄]\s*(\d+)(?![\d.,])")
DECIMAL = re.compile(r"(?<![\d.,])(-?(?:\d+)?)[.](\d+)(?![\d])")
INTEGER = re.compile(r"(?<![\d.,\u2212-])(-?\d[\d,]*)(?![\d.,])")
# Classic rounded/truncated repeating tails.  A generic decimal such as 3.14
# cannot be declared "rounded" from its spelling alone; the previous
# ``limit_denominator`` heuristic falsely rejected most exact hundredths.
ROUNDED = re.compile(
    r"^(?:3{2,}|6+7|1(?:6*)7|8(?:3+)|"
    r"142857|285714|428571|571429|714286|857143)$")
BASE_NUMBER = (r"(?:\(\s*[+-]?(?:\d[\d,]*(?:[.]\d+)?|[.]\d+)\s*\)|"
               r"[+-]?(?:\d[\d,]*(?:[.]\d+)?|[.]\d+))")
POWER_NUMBER = re.compile(
    r"(?<![\w.])(" + BASE_NUMBER + r")\s*(?:\^|\*\*)\s*([+-]?\d+)")
SUPERSCRIPT_POWER = re.compile(
    r"(?<![\w.])(" + BASE_NUMBER + r")([⁺⁻⁰¹²³⁴⁵⁶⁷⁸⁹]+)")
SCIENTIFIC_NUMBER = re.compile(
    r"(?<![\w.])([+-]?(?:\d+(?:[.]\d*)?|[.]\d+))[eE]([+-]?\d+)(?![\w.])")
SUPERSCRIPT_TRANSLATION = str.maketrans("⁺⁻⁰¹²³⁴⁵⁶⁷⁸⁹", "+-0123456789")
VULGAR = set("¼½¾⅐⅑⅒⅓⅔⅕⅖⅗⅘⅙⅚⅛⅜⅝⅞↉⅟")


def has_negative(s):
    """סימן שלילי, לא חיסור. `452 \u2212 137` הוא פעולה; `\u22123.5` הוא מספר.
    ההבחנה היא בתו שלפני המינוס: אחרי אופרנד (ספרה, `)`, אות) זהו חיסור
    בינארי. הבאג הזה הפיל דף כיתה ג׳ תקין לגמרי בסבב הכיול הראשון."""
    # Israeli elementary notation writes a negative as ``(3-)``.
    if re.search(r"\(\s*\d+(?:[.]\d+)?\s*[-\u2212]\s*\)", s):
        return True
    for m in re.finditer(r"[-\u2212](?=\s*(?:\d|[.]\d))", s):
        j = m.start() - 1
        while j >= 0 and s[j] in " \u00a0":
            j -= 1
        if j < 0 or not (s[j].isdigit() or s[j] in ")]}%°₪|" or
                         s[j].isalpha()):
            return True
    return False


def _ints(s):
    for m in INTEGER.finditer(s):
        try:
            yield int(m.group(1).replace(",", "")), m.group(1)
        except ValueError:
            continue


def _decimal_number(raw):
    """Parse a source number while preserving exact decimal magnitude."""
    cleaned = str(raw).strip().replace(",", "")
    if cleaned.startswith("(") and cleaned.endswith(")"):
        cleaned = cleaned[1:-1].strip()
    return Decimal(cleaned)


def _power_exceeds(base_raw, exponent_raw, limit):
    """Compare ``abs(base ** exponent)`` to ``limit`` without constructing
    an unbounded integer.  Exponentiation is capped once the limit is crossed.
    """
    try:
        base = abs(_decimal_number(base_raw))
        exponent = int(exponent_raw)
    except (InvalidOperation, ValueError):
        return False
    if exponent < 0:
        if base == 0:
            return False
        if base >= 1:
            return False
        base = Decimal(1) / base
        exponent = -exponent
    if exponent == 0 or base in (0, 1):
        return Decimal(1 if exponent == 0 or base == 1 else 0) > limit
    if base > limit:
        return True
    cap = Decimal(limit) + 1
    result, factor = Decimal(1), base
    while exponent:
        if exponent & 1:
            result *= factor
            if result > limit:
                return True
        exponent >>= 1
        if exponent:
            factor *= factor
            if factor > limit:
                factor = cap
    return result > limit


def _scientific_exceeds(mantissa_raw, exponent_raw, limit):
    """Exact magnitude comparison for decimal scientific notation."""
    try:
        mantissa = abs(Decimal(mantissa_raw))
        exponent = int(exponent_raw)
    except (InvalidOperation, ValueError):
        return False
    if not mantissa:
        return False
    target_order = len(str(abs(int(limit)))) - 1
    value_order = mantissa.adjusted() + exponent
    if value_order != target_order:
        return value_order > target_order
    try:
        return mantissa.scaleb(exponent) > Decimal(limit)
    except InvalidOperation:
        return exponent > 0


def g60_ugly_numbers(recs, P):
    """יופי של מספר הוא חוק, לא טעם: שבר מצומצם, מכנה בטווח, עשרוני שאינו
    קטימה של שבר מחזורי, וסדר גודל שמתאים לכיתה. תשובה שנכשלת כאן היא
    תשובה שהתלמיד יכתוב בה 6.67 ויסמן לעצמו טעות."""
    bad = []
    for r in recs:
        a = r["answer"].replace(MINUS, "-")
        if not a.strip():
            continue
        tag = "Q%s" % r["n"]
        vulgar = sorted(set(a) & VULGAR)
        if vulgar:
            bad.append("%s: שבר וולגרי %s — נדרש שבר מדורג ומצומצם"
                       % (tag, "".join(vulgar)))
        for num, den in (FRAC_BRACE.findall(a) + FRAC_SLASH.findall(a)):
            num, den = int(num), int(den)
            if den == 0:
                bad.append("%s: מכנה 0" % tag); continue
            g = math.gcd(abs(num), abs(den))
            if g > 1:
                bad.append("%s: %d/%d לא מצומצם (÷%d)" % (tag, num, den, g))
            if abs(den) > P.max_den:
                bad.append("%s: מכנה %d > %d" % (tag, den, P.max_den))
        for m in DECIMAL.finditer(a):
            whole, frac = m.group(1), m.group(2)
            if len(frac) > P.max_decimals:
                bad.append("%s: %s.%s — %d ספרות עשרוניות (מותר %d)"
                           % (tag, whole, frac, len(frac), P.max_decimals))
            elif ROUNDED.match(frac):
                bad.append("%s: %s.%s — קטימה של שבר מחזורי, תנו שבר"
                           % (tag, whole, frac))
            else:
                # An arbitrary finite decimal is exact as written.  Only
                # unmistakable repeating tails are rejected above.
                pass
        power_tokens = [(m.group(0), m.group(1), m.group(2))
                        for m in POWER_NUMBER.finditer(a)]
        for match in SUPERSCRIPT_POWER.finditer(a):
            exponent = match.group(2).translate(SUPERSCRIPT_TRANSLATION)
            if exponent not in ("", "+", "-"):
                power_tokens.append((match.group(0), match.group(1), exponent))
        for raw, base, exponent in power_tokens:
            if _power_exceeds(base, exponent, P.max_abs):
                bad.append("%s: %s מעל סדר הגודל של %s (%d)"
                           % (tag, raw, P.name, P.max_abs))
        for match in SCIENTIFIC_NUMBER.finditer(a):
            if _scientific_exceeds(match.group(1), match.group(2), P.max_abs):
                bad.append("%s: %s מעל סדר הגודל של %s (%d)"
                           % (tag, match.group(0), P.name, P.max_abs))
        for v, raw in _ints(a):
            if abs(v) > P.max_abs:
                bad.append("%s: %s מעל סדר הגודל של %s (%d)"
                           % (tag, raw, P.name, P.max_abs))
        if not P.allow_neg and has_negative(a):
            bad.append("%s: מספר שלילי ברמה %s" % (tag, P.name))
    return (FAIL, "; ".join(bad[:8]) + (" …(+%d)" % (len(bad) - 8)
                                        if len(bad) > 8 else "")) if bad \
        else (PASS, "כל התשובות בטווח היופי של %s" % P.name)


# =============================================== G61  LEVEL CONSISTENCY ===
# עומק רעיוני שהמספרים לא מודדים. שאלת הוכחה עם מספרים חד-ספרתיים קשה
# משאלת חישוב עם מספרים בני 4 ספרות — הפרוקסי המספרי לבדו הפיל דף
# מצוינות תקין לגמרי בסבב הכיול.
DEPTH = (("\u05d4\u05d5\u05db\u05d9\u05d7", 3), ("\u05d4\u05d5\u05db\u05d9\u05d7\u05d5", 3), ("\u05e0\u05de\u05e7\u05d5", 2), ("\u05d4\u05e1\u05d1\u05d9\u05e8\u05d5 \u05de\u05d3\u05d5\u05e2", 3),
         ("\u05db\u05dc \u05d4\u05d0\u05e4\u05e9\u05e8\u05d5\u05d9\u05d5\u05ea", 2), ("\u05d0\u05d9 \u05d0\u05e4\u05e9\u05e8", 2), ("\u05d3\u05d5\u05d2\u05de\u05d4 \u05e0\u05d2\u05d3\u05d9\u05ea", 3),
         ("\u05dc\u05e2\u05d5\u05dc\u05dd", 2), ("\u05ea\u05de\u05d9\u05d3", 2), ("\u05d4\u05d0\u05dd \u05d9\u05d9\u05ea\u05db\u05df", 2), ("\u05d4\u05db\u05dc\u05dc\u05d4", 3),
         ("\u05d1\u05d3\u05e7\u05d5 \u05d5\u05ea\u05e7\u05e0\u05d5", 2), ("\u05d4\u05e1\u05e7\u05d9\u05e7\u05d5", 2), ("\u05e6\u05d9\u05d9\u05e8\u05d5 \u05d3\u05d5\u05d2\u05de\u05d4", 2))

OPS = {"+": 1, MINUS: 1, "-": 1, "×": 1, "·": 1, "*": 1, ":": 1, "/": 1}
POWER = re.compile(r"[\^²³⁴]|\*\*")
VAR = re.compile(r"(?<![A-Za-z])[a-zA-Z](?![A-Za-z])")
ELEM_MUL_X = re.compile(r"(?<=[\d)])\s*x\s*(?=[\d(])")


def difficulty(rec, P=None):
    """ציון קושי מדיד. זה **פרוקסי**, לא כיול: הוא סופר גודל אופרנדים,
    מספר פעולות שונות, עומק סוגריים, שברים, שליליים, חזקות ומשתנים.
    שאלה עמוקה עם מספרים קטנים תקבל ציון נמוך — ולכן G61 חוסם רק חריגה
    בוטה, לא סטייה קטנה."""
    context = rec.get("context", rec["stem"])
    s = (rec.get("item", rec["stem"]) + " " + rec["answer"])
    # In elementary grades ג–ו, Latin x is the mandated multiplication sign,
    # not a variable.  Replace only operator-shaped occurrences before the
    # operation/variable counts; middle-school algebra keeps x as a variable.
    elementary = bool(P and P.name.split("/", 1)[0] in ELEM_GRADES)
    scan = ELEM_MUL_X.sub("×", s) if elementary else s
    score = 0
    mag = max([len(str(abs(v))) for v, _ in _ints(scan)] or [1])
    score += min(mag, 6)
    score += 2 * bool(FRAC_BRACE.search(scan) or FRAC_SLASH.search(scan))
    score += 2 * bool(DECIMAL.search(scan))
    score += 2 * has_negative(scan)
    score += 2 * bool(POWER.search(scan))
    score += 1 * bool(VAR.search(scan))
    score += max(0, len({c for c in scan if c in OPS}) - 1)
    depth = d = 0
    for c in s:
        if c == "(":
            d += 1; depth = max(depth, d)
        elif c == ")":
            d = max(0, d - 1)
    score += depth
    score += 1 if rec["items"] >= 3 else 0
    score += 2 if rec["starred"] else 0
    score += max([w for k, w in DEPTH if k in context] or [0])
    return score


def g61_level_consistency(recs, P):
    """מה זה חוסם, ומה רק מזהיר — ההבחנה הזו היא כל השער:

      חוסם   פער קושי בתוך הדף (ערבוב רמות), ופריט שחורג מעל
              לתקרת הרמה ביותר מ-2. אלה בדיוק “רמה לא עקבית”.
      מזהיר  דף שכולו נמוך מהרמה שהוכרזה. עומק רעיוני אינו
              נמדד מלא — ושער שחוסם על סמך מדידה חלקית מאבד אמון.
    """
    scores = [(r["n"], difficulty(r, P)) for r in recs]
    if not scores:
        return SKIPPED, "אין שאלות — שער שדולג = כשל"
    lo, hi = P.band
    vals = sorted(s for _, s in scores)
    med = vals[len(vals) // 2]
    spread = vals[-1] - vals[0]
    over = [(n, s) for n, s in scores if s >= hi + 2]
    block, warn = [], []
    if over:
        block.append("פריטים מעל תקרת %s (%d): %s"
                     % (P.name, hi, ", ".join("Q%s=%d" % o for o in over[:6])))
    if spread > P.max_spread:
        block.append("פער קושי %d > %d — הדף מערבב רמות (Q%s=%d מול Q%s=%d)"
                     % (spread, P.max_spread,
                        min(scores, key=lambda x: x[1])[0], vals[0],
                        max(scores, key=lambda x: x[1])[0], vals[-1]))
    if vals[-1] < lo:
        warn.append("חציון %d מתחת ל-%s [%d–%d] — הדף קל מהמוצהר, "
                    "או שהעומק רעיוני ולא חישובי" % (med, P.name, lo, hi))
    if block:
        return FAIL, "; ".join(block + warn)
    return (WARN if warn else PASS), \
        ("; ".join(warn) if warn else
         "קושי %d–%d, חציון %d, בטווח %s" % (vals[0], vals[-1], med, P.name))


# ================================================= G62  CLONED ITEMS   ===
def fingerprint(text):
    """מחליף כל מספר ב-# וכל משתנה ב-@. שני פריטים עם אותה טביעה הם
    אותו פריט — רק המספרים שונים."""
    t = unicodedata.normalize("NFC", text)
    t = re.sub(r"\\(?:frac|f)\b", " FRAC ", t)
    t = re.sub(r"\\d\b", " DIVFRAC ", t)
    t = re.sub(r"\\g\b", " GROUP ", t)
    t = re.sub(r"\d[\d.,]*", "#", t)
    t = re.sub(r"(?<=[#)])\s*x\s*(?=[#(])", "×", t)
    t = VAR.sub("@", t)
    t = re.sub(r"[^\w#@\u0590-\u05FF+\-−×·*/:^=<>≤≥()[\]{}]+", " ", t)
    t = re.sub(r"\s*([+\-−×·*/:^=<>≤≥()[\]{}])\s*", r"\1", t)
    return " ".join(t.split()).strip()


def g62_cloned_items(recs, P):
    """חזרתיות מבנית. אינו מודד עניין — שאלה מקורית ומשעממת תעבור. הוא
    מודד את הכשל שכן ניתן למדוד: אותו פריט N פעמים."""
    seen = {}
    for r in recs:
        fp = fingerprint(r.get("item", r["stem"]))
        # Exact substantive prose can be a clone even when it contains no
        # number or variable.  Only empty/ultra-short generic commands such as
        # "חשבו" are too weak to classify by text alone.
        if not fp or ("#" not in fp and "@" not in fp and len(fp) < 12):
            continue
        seen.setdefault(fp, []).append(r["n"])
    clones = [(fp, ns) for fp, ns in seen.items() if len(ns) > P.max_clone]
    answers = [r["answer"].strip() for r in recs if r["answer"].strip()]
    variety = (len(set(answers)) / len(answers)) if answers else 1.0
    answer_categories = [re.sub(r"[^\w\u0590-\u05FF]+", " ", answer.lower()).strip()
                         for answer in answers]
    categorical_values = {"נכון", "לא נכון", "כן", "לא", "true", "false"}
    categorical = (len(set(answer_categories)) >= 2 and
                   all(value in categorical_values for value in answer_categories))
    msgs = []
    for fp, ns in clones[:4]:
        msgs.append("%d פריטים זהים מבנית (Q%s): «%s»"
                    % (len(ns), ", Q".join(ns[:5]), fp[:46]))
    if answers and not categorical and variety < P.min_variety:
        msgs.append("גיוון תשובות %.0f%% < %.0f%% — %d תשובות שונות מתוך %d"
                    % (variety * 100, P.min_variety * 100,
                       len(set(answers)), len(answers)))
    return (FAIL, "; ".join(msgs)) if msgs else \
        (PASS, "אין שיבוט מעל %d, גיוון תשובות %s"
         % (P.max_clone, "קטגוריאלי" if categorical else "%.0f%%" %
            (variety * 100)))


# ============================================ G63  FIGURE GEOMETRY     ===
NUMBER = r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?"
NUMS = re.compile(NUMBER)
PATH_TOKENS = re.compile(r"[AaCcHhLlMmQqSsTtVvZz]|" + NUMBER)
# David Libre: conservative advance width / font-size for digits, Latin and
# Hebrew.  Combining marks may make this an overestimate, which is preferable
# to shipping a clipped label.
CHAR_W = 0.56
PAD = 2.0
IDENTITY = (1.0, 0.0, 0.0, 1.0, 0.0, 0.0)


def _local_tag(el):
    return el.tag.rsplit("}", 1)[-1]


def _number(value, default=None):
    hit = NUMS.search(str(value or ""))
    return float(hit.group(0)) if hit else default


def _viewbox(root):
    values = [float(x) for x in NUMS.findall(root.get("viewBox") or "")]
    if len(values) >= 4 and values[2] > 0 and values[3] > 0:
        return values[:4]
    width, height = _number(root.get("width")), _number(root.get("height"))
    return [0.0, 0.0, width, height] if width and height and width > 0 and height > 0 else None


def _mat_mul(left, right):
    """Affine composition ``left ∘ right`` for SVG matrices."""
    a, b, c, d, e, f = left
    g, h, i, j, k, l = right
    return (a * g + c * h, b * g + d * h,
            a * i + c * j, b * i + d * j,
            a * k + c * l + e, b * k + d * l + f)


def _apply(matrix, point):
    a, b, c, d, e, f = matrix
    x, y = point
    return a * x + c * y + e, b * x + d * y + f


def _transform_matrix(raw):
    matrix = IDENTITY
    if not raw:
        return matrix
    pos = 0
    for match in re.finditer(r"([A-Za-z]+)\s*\(([^)]*)\)", raw):
        if raw[pos:match.start()].strip(" ,\t\r\n"):
            raise ValueError("transform syntax")
        pos = match.end()
        name = match.group(1)
        values = [float(x) for x in NUMS.findall(match.group(2))]
        if name == "matrix" and len(values) == 6:
            local = tuple(values)
        elif name == "translate" and len(values) in (1, 2):
            local = (1, 0, 0, 1, values[0], values[1] if len(values) == 2 else 0)
        elif name == "scale" and len(values) in (1, 2):
            local = (values[0], 0, 0, values[-1], 0, 0)
        elif name == "rotate" and len(values) in (1, 3):
            angle = math.radians(values[0]); co, si = math.cos(angle), math.sin(angle)
            rotation = (co, si, -si, co, 0, 0)
            if len(values) == 3:
                cx, cy = values[1:]
                local = _mat_mul((1, 0, 0, 1, cx, cy),
                                 _mat_mul(rotation, (1, 0, 0, 1, -cx, -cy)))
            else:
                local = rotation
        elif name in ("skewX", "skewY") and len(values) == 1:
            tangent = math.tan(math.radians(values[0]))
            local = ((1, 0, tangent, 1, 0, 0) if name == "skewX"
                     else (1, tangent, 0, 1, 0, 0))
        else:
            raise ValueError("unsupported transform %s" % name)
        matrix = _mat_mul(matrix, local)
    if raw[pos:].strip(" ,\t\r\n"):
        raise ValueError("transform syntax")
    return matrix


def _font_size(el, inherited=12.0):
    direct = _number(el.get("font-size"))
    if direct is not None:
        return direct
    match = re.search(r"(?:^|;)\s*font-size\s*:\s*(" + NUMBER + ")",
                      el.get("style") or "")
    return float(match.group(1)) if match else inherited


def _text_box(el, inherited_size=12.0):
    x = _number(el.get("x"), 0.0) + _number(el.get("dx"), 0.0)
    y = _number(el.get("y"), 0.0) + _number(el.get("dy"), 0.0)
    fs = _font_size(el, inherited_size)
    txt = "".join(el.itertext())
    glyphs = sum(1 for ch in txt if not unicodedata.combining(ch))
    width = max(glyphs, 1) * CHAR_W * fs
    anchor = el.get("text-anchor") or ""
    x0 = x - width / 2 if anchor == "middle" else x - width if anchor == "end" else x
    return (x0, y - fs * 0.80, x0 + width, y + fs * 0.22, txt)


def _arc_points(start, end, rx, ry, angle, large, sweep):
    """Sample an SVG elliptical arc densely enough for a clipping gate."""
    rx, ry = abs(rx), abs(ry)
    if rx == 0 or ry == 0 or start == end:
        return [end]
    phi = math.radians(angle % 360.0); co, si = math.cos(phi), math.sin(phi)
    dx, dy = (start[0] - end[0]) / 2.0, (start[1] - end[1]) / 2.0
    xp, yp = co * dx + si * dy, -si * dx + co * dy
    scale = xp * xp / (rx * rx) + yp * yp / (ry * ry)
    if scale > 1:
        scale = math.sqrt(scale); rx *= scale; ry *= scale
    denom = rx * rx * yp * yp + ry * ry * xp * xp
    numer = max(0.0, rx * rx * ry * ry - denom)
    factor = (-1.0 if bool(large) == bool(sweep) else 1.0) * math.sqrt(
        numer / denom) if denom else 0.0
    cxp, cyp = factor * rx * yp / ry, factor * -ry * xp / rx
    cx = co * cxp - si * cyp + (start[0] + end[0]) / 2.0
    cy = si * cxp + co * cyp + (start[1] + end[1]) / 2.0

    def theta(ux, uy, vx, vy):
        return math.atan2(ux * vy - uy * vx, ux * vx + uy * vy)

    ux, uy = (xp - cxp) / rx, (yp - cyp) / ry
    vx, vy = (-xp - cxp) / rx, (-yp - cyp) / ry
    start_angle = theta(1, 0, ux, uy)
    delta = theta(ux, uy, vx, vy)
    if not sweep and delta > 0:
        delta -= 2 * math.pi
    elif sweep and delta < 0:
        delta += 2 * math.pi
    steps = max(4, int(math.ceil(abs(delta) / (math.pi / 32.0))))
    return [(cx + co * rx * math.cos(start_angle + delta * i / steps)
             - si * ry * math.sin(start_angle + delta * i / steps),
             cy + si * rx * math.cos(start_angle + delta * i / steps)
             + co * ry * math.sin(start_angle + delta * i / steps))
            for i in range(1, steps + 1)]


def _path_points(raw):
    tokens = PATH_TOKENS.findall(raw or "")
    if not tokens:
        return []
    arity = {"M": 2, "L": 2, "H": 1, "V": 1, "C": 6, "S": 4,
             "Q": 4, "T": 2, "A": 7}
    points, index, command = [], 0, None
    current = start = (0.0, 0.0)
    while index < len(tokens):
        if tokens[index].isalpha():
            command = tokens[index]; index += 1
            if command in "Zz":
                current = start; points.append(current); command = None
                continue
        if command is None or command.upper() not in arity:
            raise ValueError("unsupported/malformed path")
        count = arity[command.upper()]
        if index + count > len(tokens) or any(t.isalpha() for t in tokens[index:index + count]):
            raise ValueError("malformed path operands")
        values = [float(x) for x in tokens[index:index + count]]; index += count
        relative = command.islower(); kind = command.upper(); ox, oy = current

        def pair(offset):
            x, y = values[offset], values[offset + 1]
            return (x + ox, y + oy) if relative else (x, y)

        if kind == "M":
            current = pair(0); start = current; points.append(current)
            command = "l" if relative else "L"
        elif kind in ("L", "T"):
            current = pair(0); points.append(current)
        elif kind == "H":
            current = (values[0] + ox if relative else values[0], oy)
            points.append(current)
        elif kind == "V":
            current = (ox, values[0] + oy if relative else values[0])
            points.append(current)
        elif kind == "C":
            controls = [pair(0), pair(2), pair(4)]
            points.extend(controls); current = controls[-1]
        elif kind in ("S", "Q"):
            controls = [pair(0), pair(2)]
            points.extend(controls); current = controls[-1]
        elif kind == "A":
            end = pair(5)
            points.extend(_arc_points(current, end, values[0], values[1],
                                      values[2], int(values[3]), int(values[4])))
            current = end
    return points


def _coords(el):
    """Local-space points that bound what this SVG element draws."""
    tag, get = _local_tag(el), el.get
    if tag == "line":
        return [(_number(get("x1"), 0), _number(get("y1"), 0)),
                (_number(get("x2"), 0), _number(get("y2"), 0))]
    if tag in ("rect", "image"):
        x, y = _number(get("x"), 0), _number(get("y"), 0)
        width, height = _number(get("width"), 0), _number(get("height"), 0)
        return [(x, y), (x + width, y), (x + width, y + height), (x, y + height)]
    if tag in ("circle", "ellipse"):
        cx, cy = _number(get("cx"), 0), _number(get("cy"), 0)
        rx = _number(get("r"), _number(get("rx"), 0))
        ry = _number(get("r"), _number(get("ry"), 0))
        return [(cx + rx * math.cos(i * math.pi / 16),
                 cy + ry * math.sin(i * math.pi / 16)) for i in range(32)]
    if tag in ("polygon", "polyline"):
        values = [float(x) for x in NUMS.findall(get("points") or "")]
        if len(values) % 2:
            raise ValueError("odd points list")
        return list(zip(values[0::2], values[1::2]))
    if tag == "path":
        return _path_points(get("d"))
    return []


def _box_after(matrix, box):
    corners = [_apply(matrix, p) for p in ((box[0], box[1]), (box[2], box[1]),
                                           (box[2], box[3]), (box[0], box[3]))]
    xs, ys = [p[0] for p in corners], [p[1] for p in corners]
    return (min(xs), min(ys), max(xs), max(ys), box[4])


def g63_figure_geometry(figs, pad=PAD):
    """Require geometry and estimated label boxes to remain inside viewBox
    clearance after SVG transforms, and reject overlapping labels."""
    if not figs:
        return SKIPPED, "לא נמסרו שרטוטים — אם לדף יש fig, שער שדולג = כשל"
    bad = []
    for name, src in figs.items():
        try:
            root = ET.fromstring(src)
        except (ET.ParseError, TypeError) as error:
            bad.append("%s: SVG לא תקין (%s)" % (name, error)); continue
        if _local_tag(root) != "svg":
            bad.append("%s: המקור אינו <svg> יחיד" % name); continue
        viewbox = _viewbox(root)
        if not viewbox:
            bad.append("%s: אין viewBox/width/height תקינים" % name); continue
        x0, y0, width, height = viewbox
        x1, y1 = x0 + width, y0 + height
        boxes = []

        def walk(el, parent=IDENTITY, inherited_size=12.0, hidden=False):
            tag = _local_tag(el)
            style = el.get("style") or ""
            hidden = hidden or el.get("display") == "none" or "display:none" in style
            if hidden or tag in ("defs", "metadata", "title", "desc"):
                return
            # These legal SVG features need coordinate/CSS resolution that
            # this compact gate deliberately does not emulate.  Silently
            # treating them as empty geometry would turn G63 into a bypass, so
            # fail closed and require the source to be flattened first.
            if tag == "svg" and el is not root:
                bad.append("%s: <svg> מקונן אינו נתמך — שטחו לפני G63" % name)
                return
            if tag in ("use", "symbol", "foreignObject"):
                bad.append("%s: <%s> אינו נתמך — הרחיבו לגאומטריה מפורשת"
                           % (name, tag))
                return
            if tag == "style":
                bad.append("%s: CSS <style> אינו נתמך — כתבו מאפיינים ישירים"
                           % name)
                return
            if el.get("class"):
                bad.append("%s: class= ב-<%s> אינו ניתן למדידה ללא CSS"
                           % (name, tag))
                return
            try:
                matrix = _mat_mul(parent, _transform_matrix(el.get("transform")))
            except ValueError as error:
                bad.append("%s: <%s> transform לא נתמך (%s)" % (name, tag, error))
                return
            font_size = _font_size(el, inherited_size)
            if tag == "text":
                child_tags = [_local_tag(child) for child in el]
                if child_tags:
                    bad.append("%s: ילדי <text> (%s) אינם נתמכים — שטחו לטקסט יחיד"
                               % (name, ", ".join(child_tags)))
                    return
                lists = [attr for attr in ("x", "y", "dx", "dy")
                         if len(NUMS.findall(el.get(attr) or "")) > 1]
                if lists:
                    bad.append("%s: רשימת מיקומים ב-<text> (%s) אינה נתמכת"
                               % (name, ", ".join(lists)))
                    return
                if el.get("textLength") is not None:
                    bad.append("%s: textLength אינו נתמך בחישוב תיבת תווית"
                               % name)
                    return
                box = _box_after(matrix, _text_box(el, font_size))
                boxes.append(box)
                if (box[0] < x0 + pad or box[2] > x1 - pad or
                        box[1] < y0 + pad or box[3] > y1 - pad):
                    bad.append("%s: תווית «%s» חורגת מה-viewBox "
                               "(%.1f,%.1f)–(%.1f,%.1f)"
                               % (name, box[4][:14], box[0], box[1],
                                  box[2], box[3]))
                return
            try:
                points = [_apply(matrix, point) for point in _coords(el)]
            except (TypeError, ValueError) as error:
                bad.append("%s: <%s> לא ניתן למדידה (%s)" % (name, tag, error))
                points = []
            for px, py in points:
                if not (x0 + pad <= px <= x1 - pad and
                        y0 + pad <= py <= y1 - pad):
                    bad.append("%s: <%s> מצייר ב-(%.1f,%.1f) בלי שוליים "
                               "בתוך [%.0f,%.0f,%.0f,%.0f]"
                               % (name, tag, px, py, x0, y0, width, height))
                    break
            for child in el:
                walk(child, matrix, font_size, hidden)

        walk(root)
        for i, first in enumerate(boxes):
            for second in boxes[i + 1:]:
                overlap_x = min(first[2], second[2]) - max(first[0], second[0])
                overlap_y = min(first[3], second[3]) - max(first[1], second[1])
                if overlap_x > 1.0 and overlap_y > 1.0:
                    bad.append("%s: תוויות «%s» ו-«%s» חופפות (%.1f×%.1f pt)"
                               % (name, first[4][:10], second[4][:10],
                                  overlap_x, overlap_y))
    return ((FAIL, "; ".join(bad[:8]) + (" …(+%d)" % (len(bad) - 8)
                                          if len(bad) > 8 else "")) if bad
            else (PASS, "%d שרטוטים בתוך גבולותיהם, אין חפיפת תוויות"
                  % len(figs)))


SVG_BLOCK = re.compile(r"<svg\b.*?</svg>", re.S | re.I)


def extract_svg_sources(raw, name="inline"):
    """Extract one or more SVG roots from an inline SVG or an HTML wrapper."""
    blocks = SVG_BLOCK.findall(str(raw or ""))
    if not blocks:
        return {}
    if len(blocks) == 1:
        return {name: blocks[0]}
    return {"%s#%d" % (name, index): block
            for index, block in enumerate(blocks, 1)}


# ============================================ G64  SIGNS INSIDE SVG    ===
SVG_FORBIDDEN = ("\u00f7", "\u2236", "\ua789", "\uff1a", "\ufffd",
                 "\u2222", "\u2206", "\u2220", "√", "∛", "∜", "⁄")
MATH_ATOM = r"(?:−?(?:\d+(?:[.]\d+)?|[^\W\d_]))"
COLON_EXPR = re.compile(r"(?<![\w.])" + MATH_ATOM + r"\s*:\s*" +
                        MATH_ATOM + r"(?![\w.])")
ASCII_UNARY_MINUS = re.compile(r"(?:^|[\s(=+×·*/:])-(?=\s*(?:\d|[A-Za-z]|[.]\d))")
ASCII_BINARY_MINUS = re.compile(
    r"(?<=[\dA-Za-z)\]}%°₪|])\s*-\s*(?=[\dA-Za-z(.])")
ASCII_POWER_MINUS = re.compile(
    r"(?:\^|\*\*)\s*-(?=\s*(?:\d|[^\W\d_]|[.]\d))")
INLINE_SLASH = re.compile(
    r"(?:" + MATH_ATOM + r"|[)\]}])\s*[/⁄]\s*(?:" + MATH_ATOM + r"|[(\[{])")
CLOCK_CONTEXT = ("שעה", "בשעה", "שעון", "זמן", "דקות", "דקה", "clock", "time")
RATIO_CONTEXT = ("יחס", "קנה מידה", "קנה־מידה", "ratio", "scale")
STANDALONE_X = re.compile(r"(?<![A-Za-z])x(?![A-Za-z])")


def _clock_token(token):
    compact = re.sub(r"\s+", "", token)
    match = re.fullmatch(r"(\d{1,2}):(\d{2})", compact)
    return bool(match and 0 <= int(match.group(1)) <= 23 and
                0 <= int(match.group(2)) <= 59)


def _figure_context(context, name):
    if isinstance(context, dict):
        return str(context.get(name, context.get("*", "")) or "")
    return str(context or "")


def g64_svg_signs(figs, extra_forbidden=(), colon_mode="forbid", grade=None,
                  context=None):
    """הטקסט שבתוך שרטוט לא עובר בשערי הסימנים של גוף הדף — הוא לא חלק
    ממודל התוכן. לכן מקף ASCII כמינוס בתווית ציר, `12/4` בטבלה מצוירת
    ו-÷ בתוך מסגרת שרדו את כל הבדיקות. כאן הם נעצרים.

    ``context`` is optional and backward-compatible: a string applies to all
    figures; a mapping applies per figure name.  Clock/ratio colons are
    licensed only by that context (or an explicit ``colon_mode``), never by a
    token that merely happens to look like a time.
    """
    if not figs:
        return SKIPPED, "לא נמסרו שרטוטים — שער שדולג = כשל"
    forb = tuple(dict.fromkeys(tuple(SVG_FORBIDDEN) + tuple(extra_forbidden)))
    bad = []
    for name, src in figs.items():
        try:
            root = ET.fromstring(src)
        except ET.ParseError as error:
            bad.append("%s: SVG לא תקין (%s)" % (name, error))
            continue
        text_elements = [el for el in root.iter() if _local_tag(el) == "text"]
        figure_text = " ".join("".join(el.itertext()) for el in text_elements)
        source_context = (_figure_context(context, name) + " " + figure_text).lower()
        clock_context = (colon_mode == "clock" or
                         any(word in source_context for word in CLOCK_CONTEXT))
        ratio_context = (colon_mode == "ratio" or
                         any(word in source_context for word in RATIO_CONTEXT))
        for el in text_elements:
            t = "".join(el.itertext())
            vulgar = sorted(set(t) & VULGAR)
            if vulgar:
                bad.append("%s: שבר וולגרי %s ב-«%s»"
                           % (name, "".join(vulgar), t[:16]))
            for ch in forb:
                if ch in t:
                    bad.append("%s: גליף אסור %r ב-«%s»"
                               % (name, ch, t[:16]))
            if (ASCII_UNARY_MINUS.search(t) or ASCII_BINARY_MINUS.search(t) or
                    ASCII_POWER_MINUS.search(t)):
                bad.append("%s: מקף ASCII כמינוס ב-«%s» — נדרש U+2212"
                           % (name, t[:16]))
            if INLINE_SLASH.search(t):
                bad.append("%s: חילוק אלכסון ב-«%s» — שבר מדורג בלבד"
                           % (name, t[:16]))
            for match in COLON_EXPR.finditer(t):
                token = match.group(0)
                if colon_mode == "allow":
                    continue
                if ratio_context:
                    continue
                if clock_context and _clock_token(token):
                    continue
                if colon_mode == "elementary" and re.fullmatch(
                        r"\d+\s+:\s+\d+", token):
                    continue
                bad.append("%s: חילוק בנקודתיים לא תקין ב-«%s»"
                           % (name, token[:16]))
            elementary = elementary_grade(grade)
            if elementary:
                if elementary == "א" and (STANDALONE_X.search(t) or "×" in t):
                    bad.append("%s: כפל אינו מותר בכיתה א׳" % name)
                if elementary == "ב" and STANDALONE_X.search(t):
                    bad.append("%s: x הוא כפל שגוי בכיתה ב׳; נדרש ×" % name)
                if elementary in ("ג", "ד", "ה", "ו") and "×" in t:
                    bad.append("%s: × הוא כפל שגוי בכיתה %s; נדרש x"
                               % (name, elementary))
                if any(ch in t for ch in ("·", "∙", "⋅", "*", "X")):
                    bad.append("%s: גליף כפל אסור ב-«%s»" % (name, t[:16]))
    return (FAIL, "; ".join(bad[:8])) if bad else \
        (PASS, "הסימנים בתוך השרטוטים תקינים")


# ============================================ G65 ANSWER PLACEHOLDERS ===
FINAL_ANSWER_PLACEHOLDERS = frozenset((
    "נימוק", "הוכחה", "לפי השרטוט", "ייתכנו תשובות נוספות",
))


def g65_final_answer_placeholders(recs):
    """Reject exact placeholders in normalized final answers only.

    normalize() reads the existing question.answer / answers table schemas.
    Never inspect stem, context, labels or private solutions here. This narrow
    guard neither proves correctness nor checks answer/subpart completeness.
    """
    bad = []
    for rec in recs:
        answer = rec.get("answer", "")
        if not isinstance(answer, str):
            continue
        text = unicodedata.normalize("NFKC", answer)
        # Strip Hebrew combining marks; punctuation is an optional separator.
        text = re.sub(r"[\u0591-\u05bd\u05bf\u05c1-\u05c2\u05c4-\u05c5\u05c7]", "", text)
        text = " ".join("".join(
            " " if unicodedata.category(ch).startswith("P") else ch
            for ch in text).split())
        if text in FINAL_ANSWER_PLACEHOLDERS:
            bad.append("%s: מציין המקום «%s» אינו תשובה סופית" %
                       (rec.get("n", "?"), text))
    return (FAIL, "; ".join(bad[:8])) if bad else \
        (PASS, "לא נמצאו ארבעת מצייני המקום המדויקים בתשובות שנקראו")


# =============================================== G66  CHRONOLOGY GATE  ===
_NIQQUD_RE = re.compile(r"[\u0591-\u05bd\u05bf\u05c1-\u05c2\u05c4-\u05c5\u05c7]")
_TOPIC_ID_RE = re.compile(r"^([א-ו]\d{2})\b")
_REMAINDER_FLIP_RE = re.compile(
    r"^\s*שארית\s+\d+\s*[;,]\s*\d+|;\s*שארית\s+\d+\s*$")
_UNIT_FLIP_RE = re.compile(
    r"^\s*(?:סמ[\"״]ר|מ[\"״]ר|ס[\"״]מ|מ[\"״]מ|ק[\"״]מ|ק[\"״]ג|סמ[\"״]ק)\s*;\s*\d")

_DEFAULT_FORBIDDEN_ALL_ELEM = (
    "משפט פיתגורס", "פיתגורס", "יתר במשולש", "ניצבים במשולש",
    "חפיפת משולשים", "משפט חפיפה", "דמיון משולשים", "יחס דמיון",
    "זוויות קודקודיות", "זוויות צמודות", "זוויות מתחלפות", "זוויות מתאימות",
    "זוויות חד-צדדיות", "זוויות חד צדדיות", "תיכון במשולש", "אנך אמצעי",
    "פונקציה קווית", "פונקציה ריבועית", "שיפוע של ישר", "מערכת משוואות",
    "כינוס איברים דומים", "איברים דומים", "נוסחאות הכפל המקוצר",
    "פירוק לגורמים אלגברי", "פרבולה", "שורש ריבועי", "אי-שוויון אלגברי",
    "מרחב מדגם", "טריגונומטריה", "סינוס", "קוסינוס", "טנגנס",
    "∡", "∠", "√", "∛", "∜",
)

_DEFAULT_FORBIDDEN_BY_GRADE = {
    "א": (
        "כפל", "כפולה", "כפולות", "מכפלה", "לוח הכפל",
        "חילוק", "שארית",
        "מונה", "מכנה", "מספר מעורב",
        "מספר עשרוני", "שבר עשרוני", "נקודה עשרונית", "עשיריות", "מאיות",
        "אחוז", "אחוזים", "%",
        "רבבה", "מיליון",
        "זווית חדה", "זווית קהה", "זווית שטוחה",
        "סמ\"ר", "מ\"ר", "סמ״ר", "מ״ר",
        "מקבילית", "טרפז", "מעוין", "דלתון", "אלכסון", "אלכסונים",
        "מספר ראשוני", "מספר פריק", "חזקה", "חזקות",
        "ממוצע", "קנה מידה", "רדיוס", "קוטר",
    ),
    "ב": (
        "מונה", "מכנה", "שבר מדורג", "מספר מעורב", "הרחבת שברים",
        "צמצום שברים", "מכנה משותף",
        "מספר עשרוני", "שבר עשרוני", "נקודה עשרונית", "עשיריות", "מאיות",
        "אחוז", "אחוזים", "%",
        "שארית", "חילוק ארוך", "סימני התחלקות",
        "מספר ראשוני", "מספר פריק", "חזקה", "חזקות",
        "רבבה", "עשרות אלפים", "מאות אלפים", "מיליון",
        "זווית חדה", "זווית קהה", "זווית שטוחה",
        "מקבילית", "טרפז", "מעוין", "דלתון", "אלכסון", "אלכסונים",
        "נפח", "שטח פנים", "סמ\"ר", "מ\"ר", "סמ״ר", "מ״ר",
        "ממוצע", "קנה מידה", "רדיוס", "קוטר",
        "מ\"מ", "מ״מ", "ק\"מ", "ק״מ", "ק\"ג", "ק״ג", "ליטר",
        "ש\"ח", "ש״ח", "₪",
    ),
    "ג": (
        "מספר עשרוני", "שבר עשרוני", "נקודה עשרונית", "מאיות", "אלפיות",
        "אחוז", "אחוזים", "%",
        "הרחבת שברים", "צמצום שברים", "מכנה משותף", "מספר מעורב",
        "מספר ראשוני", "מספר פריק", "פירוק לגורמים ראשוניים",
        "חזקה", "חזקות", "בסיס החזקה", "מעריך",
        "מאות אלפים", "מיליון",
        "גובה במשולש", "גובה במקבילית", "שטח משולש", "שטח מקבילית", "שטח טרפז",
        "נפח תיבה", "שטח פנים", "סמ\"ק", "סמ״ק",
        "ממוצע", "קנה מידה", "רדיוס", "קוטר", "פאי", "π",
    ),
    "ד": (
        "אחוז", "אחוזים", "%",
        "כפל שברים", "חילוק שברים", "מספר הופכי", "שבר הופכי",
        "כפל מספרים עשרוניים", "חילוק מספרים עשרוניים",
        "גובה במשולש", "גובה במקבילית", "שטח משולש", "שטח מקבילית", "שטח טרפז",
        "ממוצע", "יחס שקול", "קנה מידה",
        "רדיוס", "קוטר", "היקף מעגל", "שטח עיגול", "פאי", "π", "נפח גליל",
    ),
    "ה": (
        "אחוז", "אחוזים", "%",
        "חילוק שברים", "מספר הופכי", "שבר הופכי",
        "קנה מידה",
        "רדיוס", "קוטר", "היקף מעגל", "שטח עיגול", "פאי", "π", "נפח גליל",
    ),
    "ו": (),
}

_CURRICULUM_CACHE = None


def _load_curriculum():
    global _CURRICULUM_CACHE
    if _CURRICULUM_CACHE is not None:
        return _CURRICULUM_CACHE
    skill_root = os.path.dirname(os.path.dirname(os.path.dirname(
        os.path.abspath(__file__))))
    path = os.path.join(skill_root, "curriculum_elementary.json")
    if os.path.isfile(path):
        try:
            with open(path, encoding="utf-8") as f:
                _CURRICULUM_CACHE = json.load(f)
                return _CURRICULUM_CACHE
        except Exception:
            pass
    _CURRICULUM_CACHE = {
        "forbidden_in_all_elementary": list(_DEFAULT_FORBIDDEN_ALL_ELEM),
        "forbidden_by_grade": {k: list(v) for k, v in _DEFAULT_FORBIDDEN_BY_GRADE.items()},
        "topics": [],
    }
    return _CURRICULUM_CACHE


def _strip_niqqud(text):
    return _NIQQUD_RE.sub("", unicodedata.normalize("NFKC", str(text or "")))


def _contains_term(clean_text, term):
    term_clean = _strip_niqqud(term).strip()
    if not term_clean:
        return False
    # Single non-letter symbol (e.g. %, √, ∡, ₪)
    if not any("\u05d0" <= ch <= "\u05ea" or ch.isalpha() for ch in term_clean):
        return term_clean in clean_text
    pattern = r"(?<![\u05d0-\u05eaA-Za-z])" + re.escape(term_clean) + r"(?![\u05d0-\u05eaA-Za-z])"
    return bool(re.search(pattern, clean_text))


def g66_chronology(recs, content=None, grade=None):
    """בדיקת מילות מפתח ליסודי (א׳–ו׳), לפי קטלוג 160 הנושאים.

    הבדיקה אינה מוכיחה שלמות כרונולוגית ואינה מחליפה עיון דידקטי.

    1. חוסם מושגים וסימנים של חטיבת הביניים/תיכון בכל דפי היסודי.
    2. חוסם מושגים, יחידות וסימנים השייכים לכיתה גבוהה יותר מהכיתה המוצהרת.
    3. כאשר מוגדר קוד נושא (כגון א04, ב05, ג01 ב-meta.topic_id או בתחילת meta.topic),
       חוסם מושגים מתוך forbidden_before_here של אותו נושא.
    4. חוסם היפוך דו-כיווניות בתשובות סופיות עם שארית או יחידות מידה (כגון 'שארית 21; 7').
    """
    meta = (content or {}).get("meta", {}) or {}
    eff_grade = (elementary_grade(grade) or
                 elementary_grade(meta.get("grade")) or
                 elementary_grade((content or {}).get("grade")))
    if not eff_grade:
        return PASS, "לא כיתת יסודי — G66 מדלג"

    curr = _load_curriculum()
    forb_all = curr.get("forbidden_in_all_elementary") or _DEFAULT_FORBIDDEN_ALL_ELEM
    forb_grade = list(_DEFAULT_FORBIDDEN_BY_GRADE.get(eff_grade, ()))

    # Topic-level gating when topic_id is declared
    topic_raw = str(meta.get("topic_id") or meta.get("topic") or "").strip()
    topic_match = _TOPIC_ID_RE.match(topic_raw)
    topic_id = topic_match.group(1) if topic_match else None
    forb_topic = []
    if topic_id:
        for t in curr.get("topics", []):
            if t.get("topic_id") == topic_id:
                forb_topic = list(t.get("forbidden_before_here") or [])
                break

    bad = []
    for r in recs:
        tag = "Q%s" % r.get("n", "?")
        stem_clean = _strip_niqqud(r.get("stem", ""))
        ans_clean = _strip_niqqud(r.get("answer", ""))
        combined = stem_clean + " " + ans_clean

        for term in forb_all:
            if _contains_term(combined, term):
                bad.append("%s: המושג/הסימן «%s» שייך לחטיבת הביניים ואסור ביסודי"
                           % (tag, term))
        for term in forb_grade:
            if _contains_term(combined, term):
                bad.append("%s: המושג «%s» אסור בכיתה %s׳ (נלמד בכיתה גבוהה יותר)"
                           % (tag, term, eff_grade))
        for term in forb_topic:
            if _contains_term(combined, term):
                bad.append("%s: המושג «%s» טרם נלמד בנושא %s"
                           % (tag, term, topic_id))

        # Check Bidi flip of remainder or units in final answers
        if _REMAINDER_FLIP_RE.search(ans_clean):
            bad.append("%s: היפוך סדר מנה ושארית בתשובה «%s» — נדרש '<מנה> שארית <שארית>'"
                       % (tag, ans_clean[:30]))
        if _UNIT_FLIP_RE.search(ans_clean):
            bad.append("%s: היפוך יחידת מידה ומספר בתשובה «%s»"
                       % (tag, ans_clean[:30]))

    if bad:
        dedup = list(dict.fromkeys(bad))
        return FAIL, "; ".join(dedup[:8]) + (" …(+%d)" % (len(dedup) - 8)
                                             if len(dedup) > 8 else "")
    msg = "כרונולוגיית מושגים תקינה לכיתה %s׳" % eff_grade
    if topic_id:
        msg += " (%s)" % topic_id
    return PASS, msg


# =================================================== G67  HINTS GATE   ===
_GEOMETRY_KEYWORDS = (
    "גיאומטריה", "גאומטריה", "geometry", "מצולע", "מצולעים", "מרובע", "מרובעים",
    "משולש", "משולשים", "ריבוע", "מלבן", "מקבילית", "טרפז", "מעוין", "דלתון",
    "זווית", "זוויות", "מקבילים", "מאונכים", "אלכסון", "אלכסונים", "שיקוף",
    "סימטריה", "סיבוב", "הזזה", "תיבה", "תיבות", "קובייה", "גופים", "פאון",
    "מנסרה", "פירמידה", "גליל", "חרוט", "מעגל", "עיגול", "שטח", "היקף", "נפח",
    "גובה במשולש", "גובה במקבילית", "צורות",
)
# Some geometric topics live under "measurement" in the source catalogue.
# Only these verified topic IDs qualify; a fractions topic mentioning area
# (for example ו02) must not inherit permission to draw.
_GEOMETRIC_MEASUREMENT_IDS = frozenset((
    "ג15", "ד22", "ד23", "ה22", "ה25", "ה26", "ה27", "ה31",
    "ו13", "ו14", "ו17", "ו26",
))
_GEOMETRY_DOMAINS = frozenset((
    "geometry", "גיאומטריה", "גאומטריה", "analytic_geometry",
    "גיאומטריה אנליטית", "גאומטריה אנליטית",
))
_HINT_DRAWING_RE = re.compile(
    r"<svg\b|\.svg\b|\.png\b|\.jpg\b|<img\b|hint_svg|hint_fig", re.I)


def _is_geometry_worksheet(content):
    """Resolve declared subject, never keywords in question prose.

    A valid catalogue topic ID is authoritative. Conflicting or unknown
    declarations do not grant permission. Legacy exact geometry titles are
    accepted only when no domain or ID was supplied.
    """
    meta = (content or {}).get("meta", {}) or {}
    domain = _strip_niqqud(meta.get("domain") or meta.get("topicType") or "").strip().lower()
    topic = _strip_niqqud(meta.get("topic") or "").strip()
    topic_id = str(meta.get("topic_id") or "").strip()
    match = _TOPIC_ID_RE.match(topic_id or topic)
    if topic_id or match:
        if not match:
            return False
        topic_id = match.group(1)
        entry = next((t for t in _load_curriculum().get("topics", [])
                      if t.get("topic_id") == topic_id), None)
        if entry is None:
            return False
        grade = elementary_grade(meta.get("grade"))
        if grade and grade != elementary_grade(entry.get("grade")):
            return False
        entry_domain = entry.get("domain")
        is_geo = (entry_domain == "geometry" or
                  (entry_domain == "measurement" and
                   topic_id in _GEOMETRIC_MEASUREMENT_IDS))
        compatible = not domain or domain in _GEOMETRY_DOMAINS or (
            domain == "measurement" and entry_domain == "measurement")
        return is_geo and compatible
    if domain:
        return domain in _GEOMETRY_DOMAINS
    title = topic.lower()
    if title in _GEOMETRY_KEYWORDS or title in _GEOMETRY_DOMAINS:
        return True
    return any(title == _strip_niqqud(t.get("title")).lower() and
               (t.get("domain") == "geometry" or
                (t.get("domain") == "measurement" and
                 t.get("topic_id") in _GEOMETRIC_MEASUREMENT_IDS))
               for t in _load_curriculum().get("topics", []))


# ================================================= G69  DRAWING POLICY ===
_DRAWING_KEYS = frozenset((
    "fig", "figs", "figure", "figures", "figureref", "figurerefs",
    "svg", "svgs", "drawing", "drawings", "image", "images",
    "diagram", "diagrams", "illustration", "illustrations",
    "hintsvg", "hintfig", "hintdrawing", "hintimage",
))
_DRAWING_KIND = frozenset(("svg", "figure", "image", "drawing", "diagram"))
_IMAGE_REF_RE = re.compile(
    r"\.(?:svg|png|jpe?g|gif|webp|bmp|tiff?)(?:\b|[?#])|data:image/|!\[[^\]]*\]\(", re.I)
_CSS_DRAWING_RE = re.compile(
    r"(?:background(?:-image)?|content|list-style(?:-image)?|mask(?:-image)?)\s*:[^;{}]*url\s*\(", re.I)


class _DrawingMarkup(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.found = False

    def handle_starttag(self, tag, attrs):
        tag = tag.lower().split(":")[-1]
        attrs = dict(attrs)
        if tag in ("svg", "img", "image", "canvas", "picture", "object", "embed"):
            self.found = True
        if tag == "input" and str(attrs.get("type", "")).lower() == "image":
            self.found = True
        if _CSS_DRAWING_RE.search(attrs.get("style") or ""):
            self.found = True


def _has_drawing_markup(text):
    if _IMAGE_REF_RE.search(text) or _CSS_DRAWING_RE.search(text):
        return True
    if "<" in text:
        parser = _DrawingMarkup()
        parser.feed(text)
        return parser.found
    return False


def _drawing_locations(value, path="content"):
    if isinstance(value, dict):
        for key, item in value.items():
            item_path = "%s.%s" % (path, key)
            normalized_key = re.sub(r"[_-]", "", str(key)).lower()
            if item and normalized_key in _DRAWING_KEYS:
                yield item_path
            elif (normalized_key in ("type", "kind") and
                  isinstance(item, str) and item.lower() in _DRAWING_KIND):
                yield item_path
            else:
                yield from _drawing_locations(item, item_path)
    elif isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            yield from _drawing_locations(item, "%s[%d]" % (path, index))
    elif isinstance(value, str) and _has_drawing_markup(value):
        yield path


def g69_drawings(content=None, recs=None, figs=None, html=None):
    """No drawings anywhere outside geometry, including bare hint fields.

    Checks declared fields and recognizable image/HTML/CSS markup. Plain
    arithmetic, editable tables and table borders remain legal. This source
    check does not replace inspection of the rendered PDF/DOCX.
    """
    locations = list(_drawing_locations(content or {}))
    locations += list(_drawing_locations(recs or [], "records"))
    if figs:
        locations.append("figures")
    if html and _has_drawing_markup(html):
        locations.append("HTML")
    if not locations:
        return PASS, "אין שרטוטים במקור שנבדק"
    if _is_geometry_worksheet(content):
        return PASS, "שרטוטים בדף גיאומטריה — מדיניות התחום תקינה"
    locations = list(dict.fromkeys(locations))
    return FAIL, ("איסור שרטוטים בכל חלקי דף שאינו גיאומטריה "
                  "(הוראת 29.10.2026): %s; נדרשים domain או topic_id גיאומטריים תקפים"
                  % ", ".join(locations[:6]))


class _HintVisibleText(HTMLParser):
    """Extract text and SVG labels, ignoring tag/attribute/CSS syntax."""
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts = []
        self.hidden = 0

    def handle_starttag(self, tag, attrs):
        if tag.lower() in ("script", "style"):
            self.hidden += 1

    def handle_endtag(self, tag):
        if tag.lower() in ("script", "style") and self.hidden:
            self.hidden -= 1

    def handle_data(self, data):
        if not self.hidden:
            self.parts.append(data)


def _hint_visible_text(source):
    parser = _HintVisibleText()
    parser.feed(str(source or ""))
    parser.close()
    return " ".join(parser.parts)


def _inline_hint_drawings(mapping):
    """Return inline drawing markup attached outside a hint's text field.

    External files/raster labels still require the final visual review.
    """
    return [value for key in ("svg", "fig", "drawing", "image", "hint_svg", "hint_fig")
            if isinstance((value := mapping.get(key)), str) and "<" in value]


def _collect_hint_bundles(content, recs):
    """Return (tag, hints_list, answer, has_drawing_field, inline_drawings)."""
    bundles = []
    if not isinstance(content, dict):
        return bundles
    ans_by_n = {str(r.get("n", "")): str(r.get("answer", "")) for r in (recs or [])}

    # 1. Top-level content["hints"]
    top_hints = content.get("hints")
    if isinstance(top_hints, dict):
        for k, v in top_hints.items():
            has_draw = False
            if isinstance(v, dict):
                has_draw = bool(v.get("svg") or v.get("fig") or v.get("drawing") or
                                v.get("hint_svg") or v.get("hint_fig") or v.get("image"))
                hlist = v.get("hints") or v.get("levels") or [
                    v.get("hint1") or v.get("1"),
                    v.get("hint2") or v.get("2"),
                    v.get("hint3") or v.get("3"),
                ]
                hlist = [x for x in hlist if x is not None]
            elif isinstance(v, list):
                hlist = v
            else:
                hlist = [v]
            bundles.append(("Q%s" % k, hlist, ans_by_n.get(str(k), ""), has_draw,
                            _inline_hint_drawings(v) if isinstance(v, dict) else []))
    elif isinstance(top_hints, list):
        for entry in top_hints:
            if isinstance(entry, dict):
                qid = str(entry.get("itemId") or entry.get("questionId") or
                          entry.get("n") or entry.get("id") or "?")
                has_draw = bool(entry.get("svg") or entry.get("fig") or
                                entry.get("drawing") or entry.get("hint_svg") or
                                entry.get("hint_fig") or entry.get("image"))
                hlist = entry.get("hints") or entry.get("levels")
                if hlist is None:
                    hlist = [entry.get(k) for k in ("hint1", "hint2", "hint3")
                             if entry.get(k) is not None]
                ans = str(entry.get("answer") or ans_by_n.get(qid, ""))
                bundles.append(("Q%s" % qid, hlist or [], ans, has_draw,
                                _inline_hint_drawings(entry)))

    # 2. Per-question / per-item hints
    for q in content.get("questions", []) or []:
        if not isinstance(q, dict):
            continue
        qn = str(q.get("n") or q.get("id") or "?")
        if ("hints" in q and q["hints"] is not None) or q.get("hint_svg") or q.get("hint_fig"):
            has_draw = bool(q.get("hint_svg") or q.get("hint_fig"))
            hints = q.get("hints")
            hlist = hints if isinstance(hints, list) else [hints] if hints is not None else []
            bundles.append(("Q%s" % qn, hlist, ans_by_n.get(qn, str(q.get("answer", ""))), has_draw,
                            _inline_hint_drawings({k: q.get(k) for k in ("hint_svg", "hint_fig")})))
        for idx, it in enumerate(q.get("items") or [], 1):
            if isinstance(it, dict) and ("hints" in it or "hint_svg" in it or "hint_fig" in it):
                lab = str(it.get("label") or it.get("id") or idx)
                tag = "Q%s%s" % (qn, lab)
                has_draw = bool(it.get("hint_svg") or it.get("hint_fig") or it.get("svg"))
                hlist = it.get("hints")
                if not isinstance(hlist, list):
                    hlist = [hlist] if hlist is not None else []
                ans = str(it.get("answer") or ans_by_n.get(qn + lab, ""))
                bundles.append((tag, hlist, ans, has_draw, _inline_hint_drawings(it)))
    return bundles


def g67_hints(content, recs=None):
    """בדיקות מבנה ודפוסי ספוילר לפי חוקי הרמזים (29 באוקטובר 2026).

    הבדיקות אינן מוכיחות הדרגה או העדר גילוי תשובה; נדרשת בדיקה פדגוגית.
    1. סולם 3 הרמות: בדיוק 3 רמזים מדורגים לכל שאלה/סעיף מרומז.
    2. אפס ספוילר (Zero-Spoiler): איסור מוחלט על חשיפת התשובה הסופית, ערכה
       המספרי כתוצאה, או סימני השוואה (<, >, =) ברמזים.
    3. כלל השרטוטים ברמזים (29.10.2026): רמזים בשרטוט מותרים אך ורק בדפי
       גיאומטריה! בכל שאר הדפים חל איסור מוחלט על שרטוטים ברמזים.
    """
    if recs is None and isinstance(content, dict):
        recs = normalize(content)
    bundles = _collect_hint_bundles(content, recs)
    if not bundles:
        return PASS, "אין רמזים בקובץ לבדיקה"

    is_geo = _is_geometry_worksheet(content)
    bad = []
    for tag, hlist, ans, has_draw, attached_drawings in bundles:
        if not isinstance(hlist, list) or len(hlist) != 3:
            bad.append("%s: חובת סולם 3 רמות — נמצאו %d רמזים במקום 3"
                       % (tag, len(hlist) if isinstance(hlist, list) else 0))
            continue
        texts = []
        for idx, h in enumerate(hlist, 1):
            if isinstance(h, dict):
                if h.get("svg") or h.get("fig") or h.get("drawing") or h.get("image"):
                    has_draw = True
                t = str(h.get("text") or h.get("content") or "").strip()
                inline_drawings = _inline_hint_drawings(h)
            else:
                t = str(h or "").strip()
                inline_drawings = []
            if not t:
                bad.append("%s: רמז %d ריק" % (tag, idx))
            texts.append(_hint_visible_text(t) + " " +
                         " ".join(_hint_visible_text(svg) for svg in inline_drawings))
            if _HINT_DRAWING_RE.search(t):
                has_draw = True

        # Rule 2 (29.10.2026): No drawings in hints outside geometry!
        if has_draw and not is_geo:
            bad.append("%s: איסור שרטוט ברמז מחוץ לגיאומטריה (הוראת 29.10.2026)" % tag)

        # Rule 1: Zero-Spoiler check
        check_texts = [("רמז %d" % idx, text) for idx, text in enumerate(texts, 1)]
        check_texts += [("שרטוט מצורף", _hint_visible_text(svg)) for svg in attached_drawings]
        ans_clean = _strip_niqqud(_hint_visible_text(ans)).strip()
        for label, t in check_texts:
            t_clean = _strip_niqqud(t)
            if re.search(r"[<>=]", t_clean):
                bad.append("%s %s: איסור סימני השוואה (<, >, =) ברמז (Zero-Spoiler)"
                           % (tag, label))
            if ans_clean in ("<", ">", "="):
                if "גדול יותר" in t_clean or "קטן יותר" in t_clean or "שווים" in t_clean:
                    bad.append("%s %s: הכרעת השוואה ברמז חושפת את התשובה"
                               % (tag, label))
            elif ans_clean:
                # Check if each sub-answer token appears as an explicit result in the hint
                for sub_ans in [x.strip() for x in re.split(r"\s*;\s*", ans_clean) if x.strip()]:
                    if len(sub_ans) >= 1 and (
                        re.search(r"=\s*" + re.escape(sub_ans) + r"(?![\d\u05d0-\u05ea])", t_clean) or
                        re.search(r"(?:התשובה היא|התוצאה היא|נקבל|שווה ל-?)\s*" +
                                  re.escape(sub_ans) + r"(?![\d\u05d0-\u05ea])", t_clean)
                    ):
                        bad.append("%s %s: ספוילר — חושף את התשובה הסופית «%s»"
                                   % (tag, label, sub_ans))

    if bad:
        dedup = list(dict.fromkeys(bad))
        return FAIL, "; ".join(dedup[:8])
    return PASS, "%d סטים של רמזים עברו בדיקות מבנה ודפוסי ספוילר; נדרשת בדיקה פדגוגית (3 רמות%s)" % (
        len(bundles), ", גיאומטריה" if is_geo else ", טקסט בלבד")


# =================================================================== RUN ===
def run_content_gates(recs, profile=None, figs=None, content=None,
                      strict=True, verbose=True, svg_colon_mode=None):
    """מחזיר [(name, status, msg)]. strict=True מרים SystemExit על כל
    FAIL או SKIPPED — שער שלא רץ אינו נבדל משער שעבר."""
    P = get_profile(profile) or (profile_of(content or {}) if content else None)
    rows = []
    if P is None:
        rows.append(("G60–G62", SKIPPED,
                     "לא הוכרזה רמה/כיתה (meta.level / meta.grade / --profile) "
                     "— שערי התוכן לא רצו"))
    else:
        rows.append(("G60-numbers",) + g60_ugly_numbers(recs, P))
        rows.append(("G61-level",) + g61_level_consistency(recs, P))
        rows.append(("G62-clones",) + g62_cloned_items(recs, P))
    rows.append(("G65-answer-placeholders",) + g65_final_answer_placeholders(recs))
    meta = (content or {}).get("meta", {}) or {}
    grade = meta.get("grade") or (content or {}).get("grade")
    if elementary_grade(grade) or (P and P.name.split("/", 1)[0] in ELEM_GRADES):
        rows.append(("G66-chronology",) + g66_chronology(
            recs, content=content, grade=grade or (P.name.split("/", 1)[0] if P else None)))
    if content:
        rows.append(("G67-hints",) + g67_hints(content, recs=recs))
    figs = figs or {}
    rows.append(("G69-drawings",) + g69_drawings(content, recs=recs, figs=figs))
    needs_fig = any(r["fig"] for r in recs)
    if figs or needs_fig:
        rows.append(("G63-geometry",) + g63_figure_geometry(figs))
        elementary = bool(elementary_grade(grade) or
                          str(meta.get("band", "")).startswith("elementary"))
        mode = svg_colon_mode or ("elementary" if elementary else
                                  "allow" if (content or {}).get(
                                      "colon_division_ok") else "forbid")
        source_context = " ".join(dict.fromkeys(
            str(r.get("context", r.get("stem", ""))) for r in recs))
        rows.append(("G64-svg-signs",) + g64_svg_signs(
            figs, colon_mode=mode, grade=grade, context=source_context))
    rows = [(n, s, m) for n, s, m in rows]
    if verbose:
        for n, s, m in rows:
            print("%-14s %-8s %s" % (n, s, m))
    bad = [r for r in rows if r[1] in (FAIL, SKIPPED)]   # WARN אינו חוסם
    if bad and strict:
        raise SystemExit("CONTENT GATES BLOCKED:\n" +
                         "\n".join("  %s :: %s :: %s" % b for b in bad))
    return rows


def load_figs(figdir):
    figs = {}
    if figdir and os.path.isdir(figdir):
        for fn in sorted(os.listdir(figdir)):
            if fn.lower().endswith(".svg"):
                figs[fn] = open(os.path.join(figdir, fn),
                                encoding="utf-8").read()
    return figs


# ============================================================= SELFTEST ===
def _selftest():
    ok = True

    def chk(cond, msg):
        nonlocal ok
        if not cond:
            print("SELFTEST FAIL: " + msg); ok = False

    P = PROFILES["ג"]
    # G60
    st, m = g60_ugly_numbers([{"n": "1", "answer": "6.667", "stem": "",
                               "items": 0, "starred": False, "fig": ""}], P)
    chk(st == FAIL, "6.667 עבר את G60 (%s)" % m)
    st, _ = g60_ugly_numbers([{"n": "1", "answer": "\\f{4}{8}", "stem": "",
                               "items": 0, "starred": False, "fig": ""}], P)
    chk(st == FAIL, "4/8 לא מצומצם עבר")
    st, _ = g60_ugly_numbers([{"n": "1", "answer": "\\f{3}{4}", "stem": "",
                               "items": 0, "starred": False, "fig": ""}], P)
    chk(st == PASS, "3/4 נחסם")
    st, _ = g60_ugly_numbers([{"n": "1", "answer": "1,200,000", "stem": "",
                               "items": 0, "starred": False, "fig": ""}], P)
    chk(st == FAIL, "1,200,000 עבר בכיתה ג׳")
    for spelling in ("10⁶", "(10)^6", "1,000^2", "2e6"):
        st, _ = g60_ugly_numbers([{"n": "1", "answer": spelling, "stem": "",
                                   "items": 0, "starred": False, "fig": ""}], P)
        chk(st == FAIL, "%s עקף את סדר הגודל ב-G60" % spelling)
    # G61 — פריט מצוינות בדף רמה ב׳
    easy = [{"n": str(i), "stem": "חשבו 12 + 3%d" % i, "answer": str(40 + i),
             "items": 0, "starred": False, "fig": ""} for i in range(6)]
    st, _ = g61_level_consistency(easy, PROFILES["ב׳"])
    chk(st == PASS, "דף אחיד קל נחסם ברמה ב׳")
    hard = dict(easy[0], n="X", starred=True,
                stem="פתרו: ((3x\u00b2 \u2212 \\f{5}{7})(2x + 1)) : (x \u2212 4.25)",
                answer="x = \u22123.5")
    st, m = g61_level_consistency(easy + [hard], PROFILES["ב׳"])
    chk(st == FAIL, "פריט מצוינות בדף ב׳ עבר (%s)" % m)
    # G62
    clones = [{"n": str(i), "stem": "חשבו את שטח המלבן שאורכו %d ורוחבו 4"
               % (i + 3), "answer": str(4 * (i + 3)), "items": 0,
               "starred": False, "fig": ""} for i in range(6)]
    st, m = g62_cloned_items(clones, PROFILES["ג"])
    chk(st == FAIL, "6 שיבוטים עברו (%s)" % m)
    st, _ = g62_cloned_items(clones[:2], PROFILES["ג"])
    chk(st == PASS, "2 וריאציות נחסמו")
    prose_clones = [
        {"n": str(i), "stem": "סמנו את הצורה המתאימה", "item":
         "סמנו את הצורה המתאימה", "answer": chr(1488 + i),
         "items": 1, "starred": False, "fig": ""} for i in range(5)]
    st, _ = g62_cloned_items(prose_clones, PROFILES["ג"])
    chk(st == FAIL, "שיבוט טקסטואלי ללא מספר/משתנה עבר")
    tf_stems = ("בדקו את טענת המשולש", "בדקו את טענת המרובע",
                "בדקו את טענת המעגל", "בדקו את טענת הטרפז",
                "בדקו את טענת המקבילית", "בדקו את טענת הדלתון")
    true_false = [
        {"n": str(i), "stem": stem, "item": stem,
         "answer": "נכון" if i % 2 else "לא נכון", "items": 1,
         "starred": False, "fig": ""}
        for i, stem in enumerate(tf_stems, 1)]
    st, _ = g62_cloned_items(true_false, PROFILES["ג"])
    chk(st == PASS, "דף נכון/לא-נכון מגוון נחסם בגלל יחס תשובות")
    # G63
    good = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 100">'
            '<text x="20" y="50" font-size="10">A</text>'
            '<line x1="10" y1="10" x2="180" y2="90"/></svg>')
    st, m = g63_figure_geometry({"g.svg": good})
    chk(st == PASS, "שרטוט תקין נחסם (%s)" % m)
    crop = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 100">'
            '<text x="190" y="50" font-size="12">ABCD</text></svg>')
    st, _ = g63_figure_geometry({"c.svg": crop})
    chk(st == FAIL, "תווית חתוכה עברה")
    ovl = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 100">'
           '<text x="50" y="50" font-size="12">AB</text>'
           '<text x="52" y="51" font-size="12">CD</text></svg>')
    st, _ = g63_figure_geometry({"o.svg": ovl})
    chk(st == FAIL, "תוויות חופפות עברו")
    out = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">'
           '<circle cx="90" cy="50" r="40"/></svg>')
    st, _ = g63_figure_geometry({"x.svg": out})
    chk(st == FAIL, "עיגול שחורג עבר")
    unsupported = {
        "tspan": ('<svg viewBox="0 0 100 100"><text x="10" y="20">'
                  '<tspan x="120">A</tspan></text></svg>'),
        "text-list": ('<svg viewBox="0 0 100 100"><text x="10 120" '
                      'y="20">AB</text></svg>'),
        "use": ('<svg viewBox="0 0 100 100"><defs><rect id="r" width="30" '
                'height="20"/></defs><use href="#r" x="90"/></svg>'),
        "nested-svg": ('<svg viewBox="0 0 100 100"><svg x="90" width="30" '
                       'height="30"><rect x="2" y="2" width="26" '
                       'height="26"/></svg></svg>'),
        "css-class": ('<svg viewBox="0 0 100 100"><style>.big{font-size:40px}'
                      '</style><text class="big" x="70" y="50">AB</text></svg>'),
    }
    for feature, source in unsupported.items():
        st, _ = g63_figure_geometry({feature + ".svg": source})
        chk(st == FAIL, "%s עבר את G63 במקום להיכשל סגור" % feature)
    # G64
    st, _ = g64_svg_signs({"s.svg": '<svg xmlns="http://www.w3.org/2000/svg"'
                           ' viewBox="0 0 10 10"><text x="1" y="1">-3</text>'
                           '</svg>'})
    chk(st == FAIL, "מקף ASCII כמינוס ב-SVG עבר")
    st, _ = g64_svg_signs({"s.svg": '<svg xmlns="http://www.w3.org/2000/svg"'
                           ' viewBox="0 0 10 10"><text x="1" y="1">\u22123'
                           '</text></svg>'})
    chk(st == PASS, "מינוס תקין נחסם")
    st, _ = g64_svg_signs({"s.svg": '<svg xmlns="http://www.w3.org/2000/svg"'
                           ' viewBox="0 0 10 10"><text x="1" y="1">12/4</text>'
                           '</svg>'})
    chk(st == FAIL, "12/4 ב-SVG עבר")
    for token in ("x^-2", "π/2", "x:y"):
        source = ('<svg viewBox="0 0 100 40"><text x="10" y="20">%s'
                  '</text></svg>') % token
        st, _ = g64_svg_signs({"s.svg": source})
        chk(st == FAIL, "%s עבר את G64" % token)
    for token, grade in (("3 × □", "ג"), ("3 x □", "ב")):
        source = ('<svg viewBox="0 0 100 40"><text x="10" y="20">%s'
                  '</text></svg>') % token
        st, _ = g64_svg_signs({"s.svg": source}, colon_mode="elementary",
                              grade=grade)
        chk(st == FAIL, "כפל %s עבר בכיתה %s" % (token, grade))
    clock = '<svg viewBox="0 0 100 40"><text x="10" y="20">12:30</text></svg>'
    chk(g64_svg_signs({"clock.svg": clock})[0] == FAIL,
        "12:30 ללא הקשר עבר כחוקי")
    chk(g64_svg_signs({"clock.svg": clock}, context="השעה")[0] == PASS,
        "12:30 עם הקשר שעה נחסם")
    ratio = '<svg viewBox="0 0 100 40"><text x="10" y="20">2:5</text></svg>'
    chk(g64_svg_signs({"ratio.svg": ratio}, context="יחס")[0] == PASS,
        "2:5 עם הקשר יחס נחסם")
    # SKIPPED must be blocking
    try:
        run_content_gates([], profile=None, strict=True, verbose=False)
        chk(False, "פרופיל חסר לא חסם את הבנייה")
    except SystemExit:
        pass
    print("SELFTEST PASS" if ok else "SELFTEST FAILED")
    return 0 if ok else 1


if __name__ == "__main__":
    if "--selftest" in sys.argv:
        sys.exit(_selftest())
    args = [a for a in sys.argv[1:] if not a.startswith("-")]
    prof = figdir = None
    for i, a in enumerate(sys.argv):
        if a == "--profile" and i + 1 < len(sys.argv):
            prof = sys.argv[i + 1]
        if a == "--figdir" and i + 1 < len(sys.argv):
            figdir = sys.argv[i + 1]
    if not args:
        sys.exit("usage: content_quality.py content.json "
                 "[--profile ט/א] [--figdir figures]")
    content = json.load(open(args[0], encoding="utf-8"))
    figdir = figdir or os.path.join(os.path.dirname(args[0]) or ".", "figures")
    try:
        run_content_gates(normalize(content), profile=prof,
                          figs=load_figs(figdir), content=content)
    except SystemExit as e:
        print(e); sys.exit(1)
    print("ALL CONTENT GATES PASS")
