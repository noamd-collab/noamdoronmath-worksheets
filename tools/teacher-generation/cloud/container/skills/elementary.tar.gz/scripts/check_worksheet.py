#!/usr/bin/env python3
"""check_worksheet.py — שער אימות פרוגרמטי ל-PDF דף עבודה עברי.

שימוש:  python3 check_worksheet.py worksheet.pdf [preview_dir] [--band middle|elementary|elementary-ab]

  --band: middle (חטיבת ביניים — ההתנהגות הקלאסית),
          elementary (ברירת מחדל, יסודי ג׳–ו׳: `25 : 5` חילוק חוקי! ÷ עדיין אסור),
          elementary-ab (יסודי א׳–ב׳: כמו elementary + אזהרת ניקוד —
          טקסט של כיתה א׳–ב׳ אמור להיות מנוקד כמעט במלואו).

בדיקות חוסמות (FAIL = אסור למסור):
  1. pdffonts — גופן עברי מוטמע; LMRoman/Latin Modern כגופן מרכזי = FAIL.
  2. חילוץ טקסט (pdftotext, ובגיבוי PyMuPDF) לכל עמוד — תווים עבריים
     קיימים, אפס U+FFFD.
  2א. דפוס ספרה:ספרה או ÷ בטקסט = חילוק עם נקודתיים = FAIL (שבר מדורג בלבד).
      ב-band=elementary*: דפוס ספרה:ספרה חוקי (סימן החילוק התקני ביסודי);
      ÷ נכשל תמיד, בכל band.
  2ב. תווי-שבר מוכנים (½ ⅓...) = FAIL (שבר מדורג בלבד).
  2ג. קודפוינטים מבלבלים: ∢ U+2222 (במקום ∡ U+2221), ∆ U+2206 (במקום Δ U+0394),
      ונקודתיים נראות-כמו U+2236/U+A789/U+FF1A = FAIL. ∠ U+2220 = WARN
      (תקן הבית: ∡ U+2221 — ראו hebrew-rtl.md סעיף 7).
  2ד. √ חשוף ב-HTML הצמוד (אם קיים) — כל √ חייב radicand עם קו עליון = אחרת FAIL.
  3. מותג: המחרוזת המדויקת "מתמטיקה · נועם דורון" (U+00B7) חייבת להופיע
     בכל עמוד ועמוד (כולל עמוד התשובות) — בראש ובתחתית. עמוד בלי מותג = FAIL.
  4. עימוד (על ה-PNGים המרונדרים): עמוד כמעט ריק (דיו מגיע לפחות מ-45% מגובה
     העמוד) = FAIL; 45–60% = WARN. פער פנימי ענק (>45 מ"מ ריק רצוף בין שאלות)
     = FAIL; 35–45 מ"מ = WARN.
  5. רינדור כל העמודים ל-PNG — לעיון חזותי (חובה לפני מסירה!).

קוד יציאה: 0 = עבר, 1 = נכשל.
"""
from __future__ import annotations

import re
import shutil
import subprocess
import sys
from pathlib import Path

HEBREW_RE = re.compile(r"[\u0590-\u05FF]")
FORBIDDEN_FONTS = ("LMRoman", "LatinModern", "Latin Modern", "CMR")
BRAND = "מתמטיקה · נועם דורון"   # U+00B7 בדיוק — לא • ולא ‧
# תווי-שבר מוכנים (vulgar fractions) — אסורים לחלוטין! שברים מוצגים מדורג
# בלבד (מונה מעל מכנה עם קו שבר, span.frac בתבנית). ראו hebrew-rtl.md סעיף 8.
VULGAR_FRAC_RE = re.compile(
    "[¼½¾⅐⅑⅒⅓⅔⅕⅖⅗⅘⅙⅚⅛⅜⅝⅞⅟↉]")
# √ חשוף — √ שלא מלווה מיד ב-span.radicand = שורש בלי vinculum (קו עליון).
# אסור לחלוטין! ראו hebrew-rtl.md סעיף 9.
BARE_ROOT_RE = re.compile(r"√(?!\s*<\s*span\s+class=[\"']radicand[\"'])")
# חילוק עם נקודתיים (ספרה:ספרה) — אסור לחלוטין! חילוק מוצג כשבר מדורג בלבד
# (span.frac) או שבר מעורב; גם ÷ אסור. ראו hebrew-rtl.md סעיף 8א.
COLON_DIV_RE = re.compile(r"(?<!\d)\d+\s*:\s*\d+(?!\d)")
DIV_SIGN_RE = re.compile("÷")
# יוצאי-דופן מוסכמים לנקודתיים (hebrew-rtl.md §8א): יחס `2:5` כשכתוב "יחס"
# בסמוך, קנה-מידה `1:200`, שעה `14:30` עם מילת זמן. הבדיקה כאן ברמת הטקסט
# של ה-PDF — המבחן העקרוני נשאר: `12:4` חילוקי נכשל תמיד כשאין הצדקת הקשר.
TIME_RE = re.compile(r"(?<!\d)\d{1,2}\s*:\s*[0-5]\d(?!\d)")
RATIO_CONTEXT = ("יחס", "קנה מידה", "קנה־מידה", "קנה-מידה")
TIME_CONTEXT = ("שעה", "שעות", "שעון", "דקות", "בבוקר", "בערב", "בצהריים", "חצות")
# קודפוינטים מבלבלים — נראים נכון ונכשלים רק בביקורת. ראו hebrew-rtl.md סעיף 7.
CONFUSABLES = {"∢": "U+2222 → השתמשו ב-∡ U+2221",
               "∆": "U+2206 INCREMENT → השתמשו ב-Δ U+0394",
               "∶": "U+2236 RATIO → נקודתיים ASCII בלבד",
               "꞉": "U+A789 → נקודתיים ASCII בלבד",
               "：": "U+FF1A → נקודתיים ASCII בלבד"}


def run(cmd: list[str]) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, capture_output=True, text=True, timeout=120)


def page_count(pdf: Path) -> int:
    if shutil.which("pdfinfo"):
        out = run(["pdfinfo", str(pdf)]).stdout
        m = re.search(r"^Pages:\s+(\d+)", out, re.M)
        if m:
            return int(m.group(1))
    try:
        import pymupdf
        with pymupdf.open(pdf) as doc:
            return len(doc)
    except (ImportError, OSError, RuntimeError):
        return 0


def document_text(pdf: Path, first: int | None = None,
                  last: int | None = None) -> str:
    """Extract PDF text without making Poppler a mandatory dependency.

    Page numbers follow pdftotext's one-based, inclusive convention.  PyMuPDF
    is the supported fallback in the bundled Codex document runtime.
    """
    if shutil.which("pdftotext"):
        # Suppress Poppler's synthetic page separators, not PDF glyphs.
        # U+000C from actual content must still fail check_invalid_glyphs.
        cmd = ["pdftotext", "-nopgbrk"]
        if first is not None:
            cmd += ["-f", str(first)]
        if last is not None:
            cmd += ["-l", str(last)]
        return run(cmd + [str(pdf), "-"]).stdout
    try:
        import pymupdf
        with pymupdf.open(pdf) as doc:
            start = max((first or 1) - 1, 0)
            stop = min(last or len(doc), len(doc))
            # Do not inject a form-feed separator: U+000C is intentionally one
            # of the corruption sentinels checked later by G06.
            return "\n".join(doc[i].get_text() for i in range(start, stop))
    except (ImportError, OSError, RuntimeError):
        return ""


def page_text(pdf: Path, i: int) -> str:
    return document_text(pdf, i, i)


def check_fonts(pdf: Path) -> tuple[bool, str]:
    if not shutil.which("pdffonts"):
        return True, "pdffonts missing — skipped (warn)"
    out = run(["pdffonts", str(pdf)]).stdout
    lines = [l for l in out.splitlines() if l.strip()][2:]
    if not lines:
        return False, "pdffonts: no fonts found"
    bad = [l for l in lines if any(f in l for f in FORBIDDEN_FONTS)]
    heb = [l for l in lines if re.search(r"Hebrew|David|FreeSerif|FreeSans|DejaVu", l, re.I)]
    if bad:
        return False, f"forbidden non-Hebrew main font detected: {bad[0].split()[0]}"
    if not heb:
        return False, "no Hebrew-capable embedded font found in pdffonts output"
    return True, f"fonts OK ({len(lines)} fonts, Hebrew-capable embedded)"


def check_text(pdf: Path) -> tuple[bool, str]:
    txt = document_text(pdf)
    if not txt.strip():
        return False, "PDF text extraction produced nothing"
    n_fffd = txt.count("\ufffd")
    n_heb = len(HEBREW_RE.findall(txt))
    if n_fffd > 0:
        return False, f"{n_fffd} U+FFFD replacement chars found"
    if n_heb < 50:
        return False, f"suspiciously few Hebrew chars ({n_heb})"
    return True, f"text OK ({n_heb} Hebrew chars, 0 U+FFFD)"


def check_vulgar_fractions(pdf: Path) -> tuple[bool, str]:
    """כשל קשיח: תו-שבר מוכן (½ ⅓...) ב-PDF = פסילה.
    שברים חייבים להיות מדורגים — מונה מעל מכנה עם קו שבר (hebrew-rtl.md סעיף 8)."""
    txt = document_text(pdf)
    found = VULGAR_FRAC_RE.findall(txt)
    if found:
        return False, (f"vulgar fraction glyphs found: {''.join(sorted(set(found)))} "
                       f"— fractions must be STACKED (numerator over denominator with "
                       f"fraction bar, span.frac), never single glyphs")
    return True, "no vulgar fraction glyphs (all fractions stacked)"


def check_colon_division(pdf: Path, band: str = "elementary") -> tuple[bool, str]:
    """כשל קשיח: דפוס ספרה:ספרה (או ÷) בטקסט ה-PDF = חילוק עם נקודתיים = פסילה.
    חילוק חייב להיות שבר מדורג או שבר מעורב (hebrew-rtl.md סעיף 8א).

    שכבת ההגנה המדויקת היא G42 ברמת התוכן (content_truth.py — מילה-מילית
    על טקסט המקור הנקי, חובה בשלב 5). כאן, על טקסט PDF שחילוץ RTL מסדר
    מחדש, זו רשת-גיבוי: ÷ נכשל תמיד; `digit:digit` נכשל אלא אם בעמוד יש
    מילת יחס/קנה-מידה או שהמופע הוא שעה (H:MM) עם מילת זמן בעמוד.

    יוצא דופן — פס יסודי: ב-band=elementary / elementary-ab הנקודתיים הן
    סימן החילוק התקני (`25 : 5`) ולכן הדפוס חוקי; ÷ נכשל גם שם (סעיף 8ב)."""
    n = page_count(pdf) or 1
    found = []
    for i in range(1, n + 1):
        txt = page_text(pdf, i)
        ratio_ok = any(w in txt for w in RATIO_CONTEXT)
        time_ok = any(w in txt for w in TIME_CONTEXT)
        if not band.startswith("elementary"):
            for m in COLON_DIV_RE.finditer(txt):
                if ratio_ok:
                    continue
                if time_ok and TIME_RE.fullmatch(txt[m.start():m.end()]):
                    continue
                found.append(m.group(0))
        if DIV_SIGN_RE.search(txt):
            found.append("÷")
    if found:
        sample = ", ".join(sorted(set(found))[:6])
        return False, (f"colon-division patterns found: {sample} — division is "
                       f"NEVER written with ':' or '÷'; write it as a STACKED "
                       f"fraction (span.frac) or a mixed number. (A colon is "
                       f"allowed ONLY for יחס/קנה-מידה/שעה with its context word.)")
    return True, "no colon/÷ division (all division shown as fractions)"


def check_confusables(pdf: Path) -> tuple[bool, str]:
    """כשל קשיח: קודפוינט מבלבל בטקסט = פסילה (hebrew-rtl.md סעיף 7).
    ∠ U+2220 אינו פוסל אך מוזהר — תקן הבית הוא ∡ U+2221."""
    txt = document_text(pdf)
    bad = [f"{ch} ({why})" for ch, why in CONFUSABLES.items() if ch in txt]
    if bad:
        return False, "confusable codepoints found: " + "; ".join(bad)
    return True, "no confusable codepoints (∡=U+2221, Δ=U+0394, ASCII colon)"


BESD = "בס״ד"   # בפינה הימנית העליונה של כל עמוד (@top-right) — כלל בית


def check_brand_pages(pdf: Path) -> tuple[bool, str]:
    """כשל קשיח: המותג "מתמטיקה · נועם דורון" (U+00B7, בית ספר־קוד מדויק)
    ו-"בס״ד" חייבים להופיע בכל עמוד — כולל עמוד התשובות. עמוד בלי מותג הוא
    עמוד שאפשר להעביר הלאה בלי שם המחבר = FAIL."""
    n = page_count(pdf)
    if n == 0:
        return True, "pdfinfo unavailable — brand check skipped (warn)"
    missing = [i for i in range(1, n + 1) if BRAND not in page_text(pdf, i)]
    missing_besd = [i for i in range(1, n + 1) if BESD not in page_text(pdf, i)]
    if missing or missing_besd:
        parts = []
        if missing:
            parts.append(f"brand line missing on page(s) {missing}")
        if missing_besd:
            parts.append(f"בס״ד missing on page(s) {missing_besd} (@top-right margin box)")
        return False, ("; ".join(parts) + f" — every page must carry {BRAND!r} "
                       f"and בס״ד in the @page margin boxes")
    return True, f"brand line + בס״ד present on all {n} pages"


def check_page_fill(pdf: Path, preview: Path, band: str = "elementary") -> tuple[bool, str]:
    """עמוד כמעט־ריק או פער פנימי ענק = פסילה. נמדד על ה-PNGים המרונדרים:
    שורת הדיו התחתונה (מעל אזור התחתית, ~6%) חייבת להגיע ל-45% מגובה העמוד
    לפחות; רצף שורות ריק בין הדיו הראשון לאחרון (מחוץ לכותרות) חורג מ-45מ"מ
    = פסילה. 110dpi ⇒ 1מ"מ ≈ 4.33px.
    פס יסודי: עמוד תשובות/פעילות קצר לגיטימי (פונט ענק, מקום לכתוב) —
    הסף 30% (במקום 45%); אזהרה 30–45%."""
    fail_th, warn_th = (0.45, 0.60) if band == "middle" else (0.30, 0.45)
    try:
        from PIL import Image
    except ImportError:
        return True, "PIL missing — page-fill check skipped (warn)"
    pages = sorted(preview.glob("page-*.png"))
    if not pages:
        return True, "no rendered pages yet — fill check deferred (warn)"
    MM = 110 / 25.4
    problems, warns = [], []
    for p in pages:
        g = Image.open(p).convert("L")
        w, h = g.size
        px = g.load()
        ink_rows = [y for y in range(h) if any(px[x, y] < 128 for x in range(0, w, 3))]
        footer = int(h * 0.94)
        body = [y for y in ink_rows if y < footer]
        if not body:
            problems.append(f"{p.name}: page appears EMPTY")
            continue
        reach = max(body) / h
        if reach < fail_th:
            problems.append(f"{p.name}: near-empty page (ink reaches {reach:.0%} of height)")
        elif reach < warn_th:
            warns.append(f"{p.name}: sparse page (ink reaches {reach:.0%})")
        top, bot = min(body), max(body)
        gap = run_ = 0
        for y in range(top, bot + 1):
            if any(px[x, y] < 128 for x in range(0, w, 3)):
                gap = max(gap, run_); run_ = 0
            else:
                run_ += 1
        gap = max(gap, run_) / MM
        if gap > 45:
            problems.append(f"{p.name}: giant interior gap ({gap:.0f}mm of blank rows)")
        elif gap > 35:
            warns.append(f"{p.name}: large interior gap ({gap:.0f}mm)")
    for warn in warns:
        print(f"WARN — {warn}")
    if problems:
        return False, "; ".join(problems)
    return True, f"page fill OK ({len(pages)} pages, no near-empty page / giant gap)"


def check_question_marker_direction(pdf: Path) -> tuple[bool, str]:
    """Validate marker content together with its bidi direction (S-29/S-21).

    The elementary template uses the S-29 form ``(15)`` in an embedded LTR
    unit. The older S-21 period form is safe only with its explicit RTL
    direction. Rejecting every LTR marker confuses these two conventions.
    """
    html = pdf.with_suffix(".html")
    if not html.exists():
        return True, "sibling .html not found — marker direction check skipped (warn)"
    src = html.read_text(encoding="utf-8", errors="replace")
    src = re.sub(r"<!--.*?-->", "", src, flags=re.S)
    src = re.sub(r"/\*.*?\*/", "", src, flags=re.S)
    styles = "\n".join(re.findall(r"<style\b[^>]*>(.*?)</style\s*>", src, flags=re.S | re.I))
    rules = re.findall(r"([^{}]+)\{([^{}]*)\}", styles, flags=re.S)
    base, starred = {}, {}
    saw = False
    for selectors, body in rules:
        for selector in selectors.split(","):
            selector = re.sub(r"\s+", "", selector)
            if selector not in ("ol.questions>li::before",
                                "ol.questions>li.starred::before"):
                continue
            target = starred if ".starred" in selector else base
            if target is base:
                saw = True
            for prop, value in re.findall(
                    r"(?:^|;)\s*(content|direction|unicode-bidi)\s*:\s*([^;]+)",
                    body, flags=re.I):
                target[prop.lower()] = re.sub(r"\s*!important\s*$", "", value).strip()
    if not saw:
        return True, "no base ol.questions counter marker found — skipped (warn)"

    parentheses = re.compile(
        r"(?P<left>[\"'])\s*\((?P=left)\s*counter\(\s*qnum\s*\)\s*"
        r"(?P<right>[\"'])\)\s*(?P=right)")
    period = re.compile(r"counter\(\s*qnum\s*\)\s*(?P<quote>[\"'])\.\s*(?P=quote)")
    for label, properties in (("base", base), ("starred", {**base, **starred})):
        content = properties.get("content", "")
        direction = properties.get("direction", "").lower()
        bidi = properties.get("unicode-bidi", "").lower()
        if parentheses.fullmatch(content):
            if direction != "ltr" or bidi not in ("embed", "isolate"):
                return False, f"{label} parenthesized question marker requires direction: ltr and unicode-bidi: embed/isolate (S-29)"
        elif period.fullmatch(content):
            if direction != "rtl":
                return False, f"{label} period question marker requires direction: rtl (S-21)"
        else:
            return False, f"{label} question marker must use counter(qnum) with '(number)' (S-29) or a trailing period (S-21)"
    return True, "question-number marker content and bidi direction agree"


BRAND_REVERSED_RE = re.compile(r"דורון\s*[·\.\-–—]?\s*נועם")
_REV_LEX = frozenset("""מספר מספרים שאלה שאלות תשובה תרגיל קבוצה קבוצות התחלה מחיר שורה שורות
פריטים מחולק מחלק צלעות דוגמה עיפרון מחברת חסר פעילות גרם קטגוריה מדידה ערך יעד ילדים פרחים
עצים ספרים כדורים אדום כחול ירוק צהוב ספר משחק ציור נקודות שעות דקות שקלים אגורות מטבעות
עמודה טבלה סרגל משקל גובה אורך שטח רוחב בחור נפח בסיס היקף משולש מרובע זווית תיבה הבית""".split())
_INVALID_GLYPH_RE = re.compile("[\u0000-\u0008\u000b\u000c\u000e-\u001f\u02b0-\u02ff\u0300-\u036f\u0400-\u052f\ufdd0-\ufdef\ufffe\uffff]")


def check_brand_order(pdf: Path) -> tuple[bool, str]:
    """S-19: מותג בסדר הפוך "דורון נועם" = bidi שבור; הסדר החוקי: נועם דורון."""
    txt = document_text(pdf)
    if BRAND_REVERSED_RE.search(txt):
        return False, "brand printed in REVERSED word order (דורון נועם) — broken bidi"
    return True, "brand word order OK"


def check_reversed_hebrew(pdf: Path) -> tuple[bool, str]:
    """S-05: עברית שרונדרה הפוך — טוקן שהיפוכו מילה מוכרת (תוקף: 40/40, 0 FP על 489)."""
    txt = document_text(pdf)
    toks = re.findall("[\u05d0-\u05ea]{3,}", txt)
    hits = sorted({t for t in toks if t[::-1] in _REV_LEX and t not in _REV_LEX})
    if hits:
        return False, f"reversed-Hebrew tokens (broken RTL in SVG?): {hits[:6]}"
    return True, "no reversed-Hebrew tokens"


def check_invalid_glyphs(pdf: Path) -> tuple[bool, str]:
    """S-06: בקרה/צירופים זרים/קירילית/noncharacters = השחתת מיפוי-גליף (ב28)."""
    txt = document_text(pdf)
    bad = sorted({ch for ch in txt if _INVALID_GLYPH_RE.match(ch)})
    if bad:
        return False, "invalid glyphs (broken mapping): " + ", ".join(f"U+{ord(c):04X}" for c in bad[:6])
    return True, "no invalid glyphs"


def check_sqrt_markup(pdf: Path) -> tuple[bool, str]:
    """כשל קשיח כשקיים קובץ HTML מקור צמוד (אותו שם, סיומת .html):
    כל √ חייב לבוא עם span.radicand כדי שירונדר vinculum מעל המספר.
    √ חשוף נראה כמו "V50" — ראו hebrew-rtl.md סעיף 9."""
    html = pdf.with_suffix(".html")
    if not html.exists():
        return True, "sibling .html not found — sqrt markup check skipped (warn)"
    src = html.read_text(encoding="utf-8", errors="replace")
    src = re.sub(r"<!--.*?-->", "", src, flags=re.S)  # הערות HTML אינן תוכן נראה
    src = re.sub(r"<(style|script)\b.*?</\1>", "", src, flags=re.S | re.I)  # גם CSS/JS
    n_bad = len(BARE_ROOT_RE.findall(src))
    if n_bad:
        return False, (f"{n_bad} bare √ found in {html.name} — every root must be "
                       f"<span class=\"sqrt\">√<span class=\"radicand\">…</span></span> "
                       f"so the vinculum (overline) renders above the radicand")
    return True, "sqrt markup OK (every √ carries a radicand span with overline)"


NIKUD_RE = re.compile(r"[\u05B0-\u05C7]")


def warn_heuristics(pdf: Path, band: str = "elementary") -> list[str]:
    """אזהרות בלבד (לא פוסלות) — בדיקות טקסט זולות שתופסות כשלים נפוצים."""
    txt = document_text(pdf)
    warns = []
    if "★" not in txt:
        warns.append("no ★ found in extracted text — verify starred questions rendered")
    if "∠" in txt:
        warns.append("∠ U+2220 found — house standard is ∡ U+2221 (hebrew-rtl.md §7)")
    if re.search(r'מ["״]ר', txt):
        warns.append('מ"ר detected — verify these are square METERS, not cm² (cm² = סמ"ר!)')
    # מספרי שאלות מ-CSS counters יוצאים עטופים בתווי בקרת bidi (U+202A–202E) —
    # לנקות אותם לפני הספירה (נתפס בפועל: "max question number found: 0" כוזב)
    clean = re.sub(r"[\u202a-\u202e\u2066-\u2069]", " ", txt)
    # Poppler may expose mirrored parentheses in logical RTL extraction even
    # when the raster is correct. Count both forms here (warning only); the
    # source marker gate and visual review still enforce the displayed form.
    qnums = re.findall(
        r"(?<!\d)(\d{1,2})\s*\.\s|\(\s*(\d{1,2})\s*\)|"
        r"\)\s*(\d{1,2})\s*\(|\)\s*(?:★\s*)?\(\s*(\d{1,2})(?!\d)", clean)
    top = max((int(next(n for n in match if n)) for match in qnums), default=0)
    floor = {"middle": 20, "elementary": 12, "elementary-ab": 8}[band]
    if top < floor:
        unit = "activities" if band == "elementary-ab" else "questions"
        warns.append(f"max question number found: {top} (<{floor}) — verify {unit} count "
                     f"manually (floor: {floor} for band={band}; middle-school floor: 20, "
                     f"or 14 on a geometry sheet with ≥60% figures)")
    if band == "elementary":
        if re.search(r"(?<!\d)(?:[1-9]\d{4,})(?!\d)", txt):
            warns.append("a 5+ digit number without a thousands comma found — "
                         "elementary standard writes 12,345 with commas (§8ב)")
    if band == "elementary-ab":
        heb = len(HEBREW_RE.findall(txt))
        nik = len(NIKUD_RE.findall(txt))
        if heb > 0 and nik / max(heb, 1) < 0.15:
            warns.append(f"nikud density {nik/max(heb,1):.2f} (<0.15) — a כיתה א׳–ב׳ sheet "
                         "should be (almost) fully vocalized (style.md §2)")
    return warns


def render_pages(pdf: Path, outdir: Path) -> tuple[bool, str]:
    if not shutil.which("pdftoppm"):
        return True, "pdftoppm missing — skipped render (warn)"
    outdir.mkdir(parents=True, exist_ok=True)
    prefix = outdir / "page"
    r = run(["pdftoppm", "-r", "110", "-png", str(pdf), str(prefix)])
    if r.returncode != 0:
        return False, f"pdftoppm failed: {r.stderr[:300]}"
    pages = sorted(outdir.glob("page-*.png"))
    if not pages:
        return False, "pdftoppm produced no pages"
    return True, f"rendered {len(pages)} pages to {outdir} — REVIEW ALL OF THEM VISUALLY"


def main() -> int:
    if any(a in ("-h", "--help") for a in sys.argv[1:]):
        print(__doc__)
        return 0
    args, band = [], "elementary"
    it = iter(range(1, len(sys.argv)))
    skip = False
    for i in it:
        if skip:
            skip = False
            continue
        a = sys.argv[i]
        if a == "--band":
            if i + 1 < len(sys.argv):
                band = sys.argv[i + 1]
                skip = True
            continue
        args.append(a)
    if band not in ("middle", "elementary", "elementary-ab"):
        print(f"FAIL: unknown --band {band!r} (middle|elementary|elementary-ab)")
        return 2
    if not args:
        print(__doc__)
        return 2
    pdf = Path(args[0])
    preview = Path(args[1]) if len(args) > 1 else pdf.parent / "preview"
    if not pdf.exists():
        print(f"FAIL: file not found: {pdf}")
        return 1
    if band != "middle":
        print(f"[band={band}] — all-fours rules adjusted (יסודי: ':' חילוק חוקי, ÷ אסור)")

    checks = [check_fonts(pdf), check_text(pdf), check_vulgar_fractions(pdf),
              check_colon_division(pdf, band), check_confusables(pdf),
              check_brand_pages(pdf),
              check_sqrt_markup(pdf), check_question_marker_direction(pdf),
              check_brand_order(pdf), check_reversed_hebrew(pdf), check_invalid_glyphs(pdf),
              render_pages(pdf, preview)]
    checks.append(check_page_fill(pdf, preview, band))
    ok_all = True
    for ok, msg in checks:
        print(f"{'PASS' if ok else 'FAIL'} — {msg}")
        ok_all &= ok
    for w in warn_heuristics(pdf, band):
        print(f"WARN — {w}")
    print("=" * 50)
    print("GATE: PASS" if ok_all else "GATE: FAIL — fix and regenerate, DO NOT deliver")
    if ok_all:
        print("REMINDER: open every PNG in the preview dir and check RTL, "
              "marker raster (template: '(15)', never ')15('; legacy period: '15.'), "
              "★ left of the marker, punctuation, cut text, and figures "
              "before delivering.")
    return 0 if ok_all else 1


if __name__ == "__main__":
    sys.exit(main())
