#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""build_docx.py — ייצוא דף עבודה ליסודי (א׳–ו׳) לקובץ Word ניתן לעריכה (.docx).

מיועד עבור דף המורים בתשלום באתר "מתמטיקה · נועם דורון":
ממיר HTML ורשומות JSON במבנה הנתמך לקובץ Microsoft Word (`.docx`), עם:
  - כיווניות RTL לעברית ו-LTR לביטויים מתמטיים
  - שברים מדורגים אמיתיים (Office Math OMML `<m:f>`) הניתנים לעריכה בלחיצה ב-Word
  - איורי SVG המותרים בדפי גיאומטריה מרונדרים ל-PNG ומשובצים במקומם
  - טבלאות תרגול (`table.drill`), טבלאות פיגום שלבים ולוח כפל הניתנים לעריכה מלאה
  - עמוד תשובות סופיות למורה + רמזים במבנה `questions[].hints` מן המקור שנבחר
  - כותרת עליונה ותחתונה ממותגות ("בס״ד" ו-"מתמטיקה · נועם דורון") בכל עמוד

שימוש:
    python3 scripts/build_docx.py path/to/sheet.html [path/to/output.docx]
    python3 scripts/build_docx.py path/to/content.json [path/to/output.docx]
    python3 scripts/build_docx.py sheet.html out.docx --no-answers

בחירת JSON אינה משתמשת ב-sheet.html סמוך. בייצוא HTML, מקור רמזים מצוין
במפורש באמצעות --content. הייצוא אינו מאמת התאמה בין המקורות, נכונות מתמטית
או עימוד; G68 הוא בדיקה מבנית מוגבלת ונדרשת בדיקה חזותית של הפלט.
"""
from __future__ import annotations

import argparse
import io
import json
import os
import re
import sys
import tempfile
from pathlib import Path

from bs4 import BeautifulSoup, NavigableString, Tag
import docx
from docx.enum.section import WD_ORIENT
from docx.enum.table import WD_ALIGN_VERTICAL, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import nsdecls, qn
from docx.opc.constants import CONTENT_TYPE as CT
from docx.shared import Cm, Inches, Pt, RGBColor
from docx.text.paragraph import Paragraph

SCRIPT_DIR = Path(__file__).resolve().parent
SKILL_DIR = SCRIPT_DIR.parent
ASSETS_DIR = SKILL_DIR / "assets"

BRAND = "מתמטיקה · נועם דורון"
BESD = "בס״ד"
LRM = "\u200e"
RLM = "\u200f"
HEB_RE = re.compile(r"[\u0590-\u05FF]")


# ---------------------------------------------------------------------------
# עוזרי XML ל-RTL, גבולות, רקעים ושברים מדורגים (OMML) ב-Word
# ---------------------------------------------------------------------------

def set_section_rtl(section) -> None:
    """הגדרת מקטע העמוד כ-RTL (כיוון עמודות ושוליים מימין לשמאל)."""
    sectPr = section._sectPr
    if sectPr.find(qn("w:bidi")) is None:
        sectPr.append(OxmlElement("w:bidi"))
    else:
        sectPr.find(qn("w:bidi")).attrib.pop(qn("w:val"), None)
    if sectPr.find(qn("w:rtlGutter")) is None:
        sectPr.append(OxmlElement("w:rtlGutter"))


def set_para_rtl(para, align=WD_ALIGN_PARAGRAPH.RIGHT, space_before: float = 2,
                 space_after: float = 4, line_spacing: float = 1.15,
                 keep_with_next: bool = False) -> None:
    """הגדרת פסקה כ-RTL מלא ב-Word.
    שימו לב לתקן OpenXML (ECMA-376 §17.3.1.13): כאשר מוגדר `<w:bidi/>` על הפסקה,
    ברירת המחדל ללא `<w:jc>` היא יישור לימין (תחילת שורת ה-RTL), ואילו `<w:jc w:val="right"/>`
    מתהפך ב-Word ליישור לשמאל! לכן ביישור לימין מסירים את `w:jc` ומשאירים `<w:bidi/>` נקי."""
    pPr = para._p.get_or_add_pPr()
    bidi = pPr.find(qn("w:bidi"))
    if bidi is None:
        bidi = OxmlElement("w:bidi")
        pPr.append(bidi)
    elif bidi.get(qn("w:val")) in ("0", "false", "off"):
        del bidi.attrib[qn("w:val")]

    if align in (None, WD_ALIGN_PARAGRAPH.RIGHT):
        para.alignment = None
        jc = pPr.find(qn("w:jc"))
        if jc is not None:
            pPr.remove(jc)
    else:
        para.alignment = align

    pf = para.paragraph_format
    pf.space_before = Pt(space_before)
    pf.space_after = Pt(space_after)
    pf.line_spacing = line_spacing
    pf.keep_with_next = keep_with_next


def set_run_font(run, font_name: str = "David Libre", size_pt: float = 12,
                 bold: bool = False, italic: bool = False,
                 color: tuple[int, int, int] | None = None,
                 rtl: bool = True, underline: bool = False) -> None:
    """הגדרת גופן וכיווניות (RTL לעברית, LTR למתמטיקה) על Run בודד, כולל הגדרות Complex Script (cs)."""
    run.font.name = font_name
    run.font.size = Pt(size_pt)
    run.bold = bold
    run.italic = italic
    run.underline = underline
    if color is not None:
        run.font.color.rgb = RGBColor(*color)

    rPr = run._r.get_or_add_rPr()
    rFonts = rPr.find(qn("w:rFonts"))
    if rFonts is None:
        rFonts = OxmlElement("w:rFonts")
        rPr.insert(0, rFonts)
    rFonts.set(qn("w:ascii"), font_name)
    rFonts.set(qn("w:hAnsi"), font_name)
    rFonts.set(qn("w:cs"), font_name)

    half_pts = str(int(round(size_pt * 2)))
    for sz_tag in ("w:sz", "w:szCs"):
        el = rPr.find(qn(sz_tag))
        if el is None:
            el = OxmlElement(sz_tag)
            rPr.append(el)
        el.set(qn("w:val"), half_pts)

    bCs = rPr.find(qn("w:bCs"))
    if bCs is None:
        bCs = OxmlElement("w:bCs")
        rPr.append(bCs)
    if bold:
        if qn("w:val") in bCs.attrib:
            del bCs.attrib[qn("w:val")]
    else:
        bCs.set(qn("w:val"), "0")

    iCs = rPr.find(qn("w:iCs"))
    if iCs is None:
        iCs = OxmlElement("w:iCs")
        rPr.append(iCs)
    if italic:
        if qn("w:val") in iCs.attrib:
            del iCs.attrib[qn("w:val")]
    else:
        iCs.set(qn("w:val"), "0")

    lang = rPr.find(qn("w:lang"))
    if lang is None:
        lang = OxmlElement("w:lang")
        rPr.append(lang)
    lang.set(qn("w:val"), "he-IL" if rtl else "en-US")
    lang.set(qn("w:bidi"), "he-IL")

    existing_rtl = rPr.find(qn("w:rtl"))
    if existing_rtl is not None:
        rPr.remove(existing_rtl)
    if rtl:
        rPr.append(OxmlElement("w:rtl"))
    else:
        rtl_off = OxmlElement("w:rtl")
        rtl_off.set(qn("w:val"), "0")
        rPr.append(rtl_off)


def enforce_docx_rtl(doc) -> None:
    """מעבר סופי (Post-Processing) על מסמך ה-Word לאחר יצירתו:
    מבטיח שבדיפולט המסמך כולו יישמר כ-RTL מלא ב-Microsoft Word ללא צורך בתיקון ידני:
      1. `docDefaults` ב-`styles.xml`: מוסיף `<w:bidi/>` ל-`pPrDefault`, שפה `he-IL` וגופן `David Libre`.
      2. סגנון `Normal` וכל סגנונות הפסקה ב-`styles.xml`: מוסיף `<w:pPr><w:bidi/></w:pPr>` ומסיר `<w:jc w:val="right"/>`.
      3. `settings.xml`: מגדיר `compatibilityMode=15` ושפת ברירת מחדל `he-IL`.
      4. כל המקטעים (`w:sectPr`) וכל הפסקאות (`w:p`) בגוף המסמך, בטבלאות, בכותרות העליונות והתחתונות:
         מוודא `<w:bidi/>` פעיל ומסיר `<w:jc w:val="right"/>` (שגורם ב-Word להיפוך יישור לשמאל תחת `w:bidi`)."""
    # 1. styles.xml — docDefaults + Normal style + TableNormal
    styles_el = doc.styles.element
    docDefaults = styles_el.find(qn("w:docDefaults"))
    if docDefaults is None:
        docDefaults = OxmlElement("w:docDefaults")
        styles_el.insert(0, docDefaults)

    pPrDef = docDefaults.find(qn("w:pPrDefault"))
    if pPrDef is None:
        pPrDef = OxmlElement("w:pPrDefault")
        docDefaults.append(pPrDef)
    pPr_d = pPrDef.find(qn("w:pPr"))
    if pPr_d is None:
        pPr_d = OxmlElement("w:pPr")
        pPrDef.append(pPr_d)
    if pPr_d.find(qn("w:bidi")) is None:
        pPr_d.insert(0, OxmlElement("w:bidi"))
    else:
        pPr_d.find(qn("w:bidi")).attrib.pop(qn("w:val"), None)
    jc_d = pPr_d.find(qn("w:jc"))
    if jc_d is not None and jc_d.get(qn("w:val")) == "right":
        pPr_d.remove(jc_d)

    rPrDef = docDefaults.find(qn("w:rPrDefault"))
    if rPrDef is None:
        rPrDef = OxmlElement("w:rPrDefault")
        docDefaults.append(rPrDef)
    rPr_d = rPrDef.find(qn("w:rPr"))
    if rPr_d is None:
        rPr_d = OxmlElement("w:rPr")
        rPrDef.append(rPr_d)
    rFonts_d = rPr_d.find(qn("w:rFonts"))
    if rFonts_d is None:
        rFonts_d = OxmlElement("w:rFonts")
        rPr_d.insert(0, rFonts_d)
    for attr in ("w:ascii", "w:hAnsi", "w:cs"):
        rFonts_d.set(qn(attr), "David Libre")
    for theme_attr in ("w:asciiTheme", "w:hAnsiTheme", "w:cstheme", "w:eastAsiaTheme"):
        if qn(theme_attr) in rFonts_d.attrib:
            del rFonts_d.attrib[qn(theme_attr)]
    lang_d = rPr_d.find(qn("w:lang"))
    if lang_d is None:
        lang_d = OxmlElement("w:lang")
        rPr_d.append(lang_d)
    lang_d.set(qn("w:val"), "he-IL")
    lang_d.set(qn("w:bidi"), "he-IL")
    lang_d.set(qn("w:eastAsia"), "en-US")

    for st in styles_el.findall(qn("w:style")):
        st_type = st.get(qn("w:type"))
        if st_type == "paragraph":
            st_pPr = st.find(qn("w:pPr"))
            if st_pPr is None:
                st_pPr = OxmlElement("w:pPr")
                st.append(st_pPr)
            st_bidi = st_pPr.find(qn("w:bidi"))
            if st_bidi is None:
                st_pPr.insert(0, OxmlElement("w:bidi"))
            elif st_bidi.get(qn("w:val")) in ("0", "false", "off"):
                del st_bidi.attrib[qn("w:val")]
            st_jc = st_pPr.find(qn("w:jc"))
            if st_jc is not None and st_jc.get(qn("w:val")) == "right":
                st_pPr.remove(st_jc)
        elif st_type == "table":
            st_tblPr = st.find(qn("w:tblPr"))
            if st_tblPr is None:
                st_tblPr = OxmlElement("w:tblPr")
                st.append(st_tblPr)
            if st_tblPr.find(qn("w:bidiVisual")) is None:
                st_tblPr.append(OxmlElement("w:bidiVisual"))

    # 2. settings.xml — compatibilityMode=15 + themeFontLang he-IL
    settings_el = doc.settings.element
    theme_lang = settings_el.find(qn("w:themeFontLang"))
    if theme_lang is None:
        theme_lang = OxmlElement("w:themeFontLang")
        settings_el.append(theme_lang)
    theme_lang.set(qn("w:val"), "he-IL")
    theme_lang.set(qn("w:bidi"), "he-IL")
    theme_lang.set(qn("w:eastAsia"), "en-US")

    compat = settings_el.find(qn("w:compat"))
    if compat is not None:
        for cs in compat.findall(qn("w:compatSetting")):
            if cs.get(qn("w:name")) == "compatibilityMode":
                cs.set(qn("w:val"), "15")

    # 3. כל המקטעים והפסקאות במסמך (כולל טבלאות, כותרות עליונות ותחתונות)
    for sec in doc.sections:
        set_section_rtl(sec)

    for _, root in _story_roots(doc):
        for p in root.iter(qn("w:p")):
            pPr = p.find(qn("w:pPr"))
            if pPr is None:
                pPr = OxmlElement("w:pPr")
                p.insert(0, pPr)
            bidi = pPr.find(qn("w:bidi"))
            if bidi is None:
                pPr.insert(0, OxmlElement("w:bidi"))
            elif bidi.get(qn("w:val")) in ("0", "false", "off"):
                del bidi.attrib[qn("w:val")]
            jc = pPr.find(qn("w:jc"))
            if jc is not None and jc.get(qn("w:val")) == "right":
                pPr.remove(jc)


def _story_roots(doc):
    """Existing body/header/footer parts, including first/even-page variants."""
    yield str(doc.part.partname), doc.element.body
    for part in doc.part.package.parts:
        if part.content_type in (CT.WML_HEADER, CT.WML_FOOTER):
            yield str(part.partname), part.element


def _bidi_enabled(properties) -> bool:
    if properties is None:
        return False
    flags = properties.findall(qn("w:bidi"))
    return len(flags) == 1 and flags[0].get(qn("w:val")) in (None, "1", "true", "on")


def _rtl_validation_error(doc) -> str | None:
    defaults = doc.styles.element.find(
        "./" + qn("w:docDefaults") + "/" + qn("w:pPrDefault") + "/" + qn("w:pPr"))
    normal = doc.styles["Normal"].element.find(qn("w:pPr"))
    for name, properties in (("docDefaults", defaults), ("Normal", normal)):
        if not _bidi_enabled(properties):
            return f"ברירת המחדל {name} חסרה w:bidi פעיל (RTL)"
        jc = properties.find(qn("w:jc"))
        if jc is not None and jc.get(qn("w:val")) == "right":
            return f"ברירת המחדל {name} כוללת jc=right שהופך את היישור ב-RTL"
    for index, section in enumerate(doc.sections, 1):
        if not _bidi_enabled(section._sectPr):
            return f"מקטע {index} חסר w:bidi פעיל (RTL)"
    for name, root in _story_roots(doc):
        for index, paragraph in enumerate(root.iter(qn("w:p")), 1):
            properties = paragraph.find(qn("w:pPr"))
            if not _bidi_enabled(properties):
                return f"פסקה {index} ב-{name} חסרה w:bidi פעיל (RTL)"
            jc = properties.find(qn("w:jc"))
            if jc is not None and jc.get(qn("w:val")) == "right":
                return f"פסקה {index} ב-{name} כוללת jc=right שהופך את היישור ב-RTL"
    return None



def append_omml_fraction(para, num_text: str, den_text: str,
                         size_pt: float = 12) -> None:
    """הוספת שבר מדורג (מונה מעל מכנה עם קו שבר) באמצעות Office Math (OMML).
    המורה יכול ללחוץ ישירות על המונה או המכנה ב-Word ולערוך אותם!"""
    num_esc = (str(num_text)
               .replace("&", "&amp;")
               .replace("<", "&lt;")
               .replace(">", "&gt;"))
    den_esc = (str(den_text)
               .replace("&", "&amp;")
               .replace("<", "&lt;")
               .replace(">", "&gt;"))
    half_pts = int(round(size_pt * 2))
    omml = parse_xml(
        f'<m:oMath {nsdecls("m", "w")}>'
        f'  <m:f>'
        f'    <m:fPr><m:type m:val="bar"/></m:fPr>'
        f'    <m:num>'
        f'      <m:r>'
        f'        <w:rPr><w:rFonts w:ascii="Cambria Math" w:hAnsi="Cambria Math" w:cs="David Libre"/>'
        f'        <w:sz w:val="{half_pts}"/><w:szCs w:val="{half_pts}"/></w:rPr>'
        f'        <m:t>{num_esc}</m:t>'
        f'      </m:r>'
        f'    </m:num>'
        f'    <m:den>'
        f'      <m:r>'
        f'        <w:rPr><w:rFonts w:ascii="Cambria Math" w:hAnsi="Cambria Math" w:cs="David Libre"/>'
        f'        <w:sz w:val="{half_pts}"/><w:szCs w:val="{half_pts}"/></w:rPr>'
        f'        <m:t>{den_esc}</m:t>'
        f'      </m:r>'
        f'    </m:den>'
        f'  </m:f>'
        f'</m:oMath>'
    )
    para._p.append(omml)


def set_table_rtl(table, is_rtl: bool = True) -> None:
    """הגדרת סדר עמודות הטבלה מימין לשמאל (bidiVisual) או משמאל לימין."""
    tblPr = table._tbl.tblPr
    for existing in list(tblPr.findall(qn("w:bidiVisual"))):
        tblPr.remove(existing)
    # A false value must be explicit: removing the flag inherits the RTL table style.
    flag = OxmlElement("w:bidiVisual")
    flag.set(qn("w:val"), "1" if is_rtl else "0")
    tblPr.insert_element_before(
        flag, "w:tblStyleRowBandSize", "w:tblStyleColBandSize", "w:tblW", "w:jc",
        "w:tblCellSpacing", "w:tblInd", "w:tblBorders", "w:shd", "w:tblLayout",
        "w:tblCellMar", "w:tblLook", "w:tblCaption", "w:tblDescription", "w:tblPrChange")


def set_table_borders(table, color: str = "CBD5E1", sz: str = "6",
                      val: str = "single") -> None:
    """הגדרת גבולות אחידים ונקיים לטבלה."""
    tblPr = table._tbl.tblPr
    existing = tblPr.find(qn("w:tblBorders"))
    if existing is not None:
        tblPr.remove(existing)
    borders = parse_xml(
        f'<w:tblBorders {nsdecls("w")}>'
        f'  <w:top w:val="{val}" w:sz="{sz}" w:space="0" w:color="{color}"/>'
        f'  <w:left w:val="{val}" w:sz="{sz}" w:space="0" w:color="{color}"/>'
        f'  <w:bottom w:val="{val}" w:sz="{sz}" w:space="0" w:color="{color}"/>'
        f'  <w:right w:val="{val}" w:sz="{sz}" w:space="0" w:color="{color}"/>'
        f'  <w:insideH w:val="{val}" w:sz="{sz}" w:space="0" w:color="{color}"/>'
        f'  <w:insideV w:val="{val}" w:sz="{sz}" w:space="0" w:color="{color}"/>'
        f'</w:tblBorders>'
    )
    tblPr.append(borders)


def set_cell_shading(cell, fill_hex: str) -> None:
    """צביעת רקע תא בטבלה."""
    tcPr = cell._tc.get_or_add_tcPr()
    existing = tcPr.find(qn("w:shd"))
    if existing is not None:
        tcPr.remove(existing)
    shd = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{fill_hex}"/>')
    tcPr.append(shd)


def set_cell_margins(cell, top_dxa: int = 80, bottom_dxa: int = 80,
                     left_dxa: int = 120, right_dxa: int = 120) -> None:
    """ריפוד פנימי לתא בטבלה."""
    tcPr = cell._tc.get_or_add_tcPr()
    existing = tcPr.find(qn("w:tcMar"))
    if existing is not None:
        tcPr.remove(existing)
    mar = parse_xml(
        f'<w:tcMar {nsdecls("w")}>'
        f'  <w:top w:w="{top_dxa}" w:type="dxa"/>'
        f'  <w:bottom w:w="{bottom_dxa}" w:type="dxa"/>'
        f'  <w:left w:w="{left_dxa}" w:type="dxa"/>'
        f'  <w:right w:w="{right_dxa}" w:type="dxa"/>'
        f'</w:tcMar>'
    )
    tcPr.append(mar)


# ---------------------------------------------------------------------------
# רינדור SVG ל-PNG חד (300 DPI) עם תמיכה מלאה בעברית ובפונט David Libre
# ---------------------------------------------------------------------------

def svg_to_png_bytes(svg_markup: str, dpi: int = 260) -> tuple[bytes, float, float]:
    """ממיר מחרוזת `<svg>...</svg>` ל-(png_bytes, width_px, height_px).
    משתמש ב-WeasyPrint + PyMuPDF (להבטחת רינדור מושלם של עברית וניקוד)
    או ב-PyMuPDF ישיר כגיבוי מהיר."""
    m_w = re.search(r'\bwidth=["\']([\d.]+)', svg_markup)
    m_h = re.search(r'\bheight=["\']([\d.]+)', svg_markup)
    vb = re.search(r'\bviewBox=["\']\s*[\d.-]+\s+[\d.-]+\s+([\d.]+)\s+([\d.]+)', svg_markup)
    w_px = float(m_w.group(1)) if m_w else (float(vb.group(1)) if vb else 320.0)
    h_px = float(m_h.group(1)) if m_h else (float(vb.group(2)) if vb else 160.0)

    import pymupdf

    font_reg = (ASSETS_DIR / "DavidLibre-Regular.ttf").as_uri() if (ASSETS_DIR / "DavidLibre-Regular.ttf").exists() else ""
    font_bold = (ASSETS_DIR / "DavidLibre-Bold.ttf").as_uri() if (ASSETS_DIR / "DavidLibre-Bold.ttf").exists() else ""
    font_css = ""
    if font_reg:
        font_css = f"""
        @font-face {{
            font-family: 'David Libre';
            src: url('{font_reg}');
            font-weight: 400;
        }}
        @font-face {{
            font-family: 'David Libre';
            src: url('{font_bold or font_reg}');
            font-weight: 700;
        }}
        """

    # אם יש טקסט עברי ב-SVG, נרנדר דרך WeasyPrint כדי להבטיח גופן עברי וכיווניות RTL
    if HEB_RE.search(svg_markup):
        try:
            import weasyprint
            pad_px = 8
            pw = max(w_px + pad_px * 2, 60)
            ph = max(h_px + pad_px * 2, 40)
            html_wrap = f"""<!DOCTYPE html>
<html lang="he" dir="rtl">
<head><meta charset="utf-8"><style>
{font_css}
@page {{ size: {pw}px {ph}px; margin: 0; }}
html, body {{
    margin: 0; padding: {pad_px}px;
    background: #ffffff;
    font-family: 'David Libre', Arial, sans-serif;
    display: flex; align-items: center; justify-content: center;
}}
svg {{ display: block; max-width: 100%; height: auto; }}
</style></head>
<body>{svg_markup}</body></html>"""
            pdf_bytes = weasyprint.HTML(string=html_wrap).write_pdf()
            with pymupdf.open(stream=pdf_bytes, filetype="pdf") as doc:
                pix = doc[0].get_pixmap(dpi=dpi, alpha=False)
                return pix.tobytes("png"), w_px, h_px
        except Exception:
            pass

    # רינדור ישיר דרך PyMuPDF
    svg_clean = svg_markup.strip()
    if not svg_clean.startswith("<?xml"):
        svg_clean = '<?xml version="1.0" encoding="UTF-8"?>\n' + svg_clean
    with pymupdf.open(stream=svg_clean.encode("utf-8"), filetype="svg") as doc:
        page = doc[0]
        zoom = dpi / 96.0
        pix = page.get_pixmap(matrix=pymupdf.Matrix(zoom, zoom), alpha=False)
        return pix.tobytes("png"), w_px, h_px


def px_to_cm(px: float, max_cm: float = 15.8) -> float:
    """המרת פיקסלים של SVG לסנטימטרים במסמך Word, עם תקרה למניעת חריגה משולי A4."""
    cm_val = px * 2.54 / 96.0
    return min(max(cm_val, 1.2), max_cm)


# ---------------------------------------------------------------------------
# פענוח DOM של HTML להוספת אלמנטים עשירי-עיצוב ל-Word
# ---------------------------------------------------------------------------

def _blank_underscores(style_str: str) -> str:
    """המרת `min-width: 3.4cm` למספר קווים תחתיים נוח לכתיבה ולעריכה ב-Word."""
    m = re.search(r"min-width\s*:\s*([\d.]+)\s*(cm|mm|px)", style_str or "")
    if not m:
        return "________"
    val = float(m.group(1))
    unit = m.group(2)
    cm_val = val if unit == "cm" else (val / 10.0 if unit == "mm" else val * 2.54 / 96.0)
    n_chars = max(5, min(int(round(cm_val * 4.2)), 42))
    return "_" * n_chars


def _append_ltr_fraction_expression(para, node, base_size_pt: float,
                                    bold: bool, italic: bool, color) -> None:
    """Keep fractions and their operators in one editable, ordered math object.

    Separate oMath objects are bidi-neutral siblings of text runs: an RTL
    paragraph can reverse their order. Inside one oMath, the complete expression
    retains the source's left-to-right order without reversing the Hebrew label.
    """
    scratch = Paragraph(OxmlElement("w:p"), para._parent)
    for child in node.children:
        append_inline_content(scratch, child, base_size_pt=base_size_pt,
                              bold=bold, italic=italic, color=color, force_ltr=True)
    expression = OxmlElement("m:oMath")
    for child in list(scratch._p):
        if child.tag == qn("m:oMath"):
            for math_child in list(child):
                expression.append(math_child)
        elif child.tag == qn("w:r"):
            math_run = OxmlElement("m:r")
            for run_child in list(child):
                if run_child.tag == qn("w:rPr"):
                    math_run.append(run_child)
                elif run_child.tag in (qn("w:t"), qn("w:br"), qn("w:tab")):
                    text = OxmlElement("m:t")
                    text.set(qn("xml:space"), "preserve")
                    text.text = ((run_child.text or "").replace(LRM, "").replace(RLM, "")
                                 if run_child.tag == qn("w:t") else " ")
                    math_run.append(text)
            if math_run.find(qn("m:t")) is not None:
                expression.append(math_run)
    para._p.append(expression)


def append_inline_content(para, node, base_size_pt: float = 12.5,
                          bold: bool = False, italic: bool = False,
                          color: tuple[int, int, int] | None = None,
                          force_ltr: bool = False) -> None:
    """מעבר רקורסיבי על עץ HTML והוספת Runs / שברים מדורגים (OMML) לפסקת Word."""
    if isinstance(node, NavigableString):
        txt = str(node)
        if not txt:
            return
        # נרמול רווחים מרובים תוך שמירה על רווחי קצה
        txt = re.sub(r"[ \t\r\n]+", " ", txt)
        if not txt:
            return
        if force_ltr:
            run = para.add_run(f"{LRM}{txt}{LRM}")
            set_run_font(run, size_pt=base_size_pt, bold=bold, italic=italic,
                         color=color, rtl=False)
        else:
            run = para.add_run(txt)
            is_heb = bool(HEB_RE.search(txt)) or not bool(re.search(r"[0-9a-zA-Z]", txt))
            set_run_font(run, size_pt=base_size_pt, bold=bold, italic=italic,
                         color=color, rtl=is_heb)
        return

    if not isinstance(node, Tag):
        return

    tag = node.name.lower()
    classes = set(node.get("class") or [])

    if tag == "br":
        para.add_run().add_break()
        return

    # כוכבית אתגר ★
    if "star" in classes and not node.get_text(strip=True):
        run = para.add_run("★ ")
        set_run_font(run, size_pt=base_size_pt, bold=True,
                     color=(217, 119, 6), rtl=True)
        return

    # קו השלמה (blank)
    if "blank" in classes:
        underscores = _blank_underscores(node.get("style", ""))
        run = para.add_run(f" {LRM}{underscores}{LRM} ")
        set_run_font(run, size_pt=base_size_pt, bold=False,
                     color=(100, 116, 139), rtl=False)
        return

    # ריבוע סימון (box)
    if "box" in classes and not node.get_text(strip=True):
        run = para.add_run(" ☐ ")
        set_run_font(run, size_pt=base_size_pt + 1, bold=False, rtl=False)
        return

    # שבר מדורג (<span class="frac"><span class="fnum">1</span><span class="fden">4</span></span>)
    if "frac" in classes:
        fnum = node.find(class_=re.compile(r"^(fnum|top|num)$"))
        fden = node.find(class_=re.compile(r"^(fden|bot|den)$"))
        if fnum and fden:
            append_omml_fraction(para, fnum.get_text(strip=True),
                                 fden.get_text(strip=True),
                                 size_pt=base_size_pt)
            return

    # ביטוי מתמטי משמאל לימין (<span class="ltr"> או <span class="num"> או <span class="m">)
    if classes & {"ltr", "num", "m"} or node.get("dir", "").lower() == "ltr":
        # שברים והאופרטורים ביניהם נשמרים כאובייקט מתמטי אחד כדי שלא יתהפכו ב-RTL.
        if node.find(class_="frac"):
            _append_ltr_fraction_expression(
                para, node, base_size_pt,
                bold=bold or tag in ("b", "strong"),
                italic=italic or tag in ("i", "em"), color=color)
            return
        # אחרת נרכיב מחרוזת LTR רציפה ומוגנת ב-LRM
        parts = []
        for child in node.descendants:
            if isinstance(child, Tag) and "blank" in (child.get("class") or []):
                parts.append(_blank_underscores(child.get("style", "")))
            elif isinstance(child, Tag) and "box" in (child.get("class") or []):
                parts.append("☐")
            elif isinstance(child, NavigableString):
                parent_classes = set(getattr(child.parent, "get", lambda *_: [])("class") or [])
                if not (parent_classes & {"blank", "box"}):
                    parts.append(str(child))
        expr_txt = re.sub(r"\s+", " ", "".join(parts)).strip()
        if expr_txt:
            run = para.add_run(f"{LRM}{expr_txt}{LRM}")
            set_run_font(run, size_pt=base_size_pt,
                         bold=bold or (tag in ("b", "strong")),
                         italic=italic or (tag in ("i", "em")),
                         color=color, rtl=False)
        return

    # בלוקים פנימיים שמופיעים בתוך li — מדלגים עליהם כאן כי הם מטופלים ברמת הבלוק
    if tag in ("table", "div", "ol", "ul") and (
        classes & {"figure", "sub", "ansline", "work-lines", "drill", "ans", "teacher-notes"}
        or tag == "table"
    ):
        return

    if tag == "div" and para.text.strip():
        para.add_run().add_break()

    next_bold = bold or (tag in ("b", "strong", "th"))
    next_italic = italic or (tag in ("i", "em"))
    for child in node.children:
        append_inline_content(para, child, base_size_pt=base_size_pt,
                              bold=next_bold, italic=next_italic,
                              color=color, force_ltr=force_ltr)


def _try_parse_vertical_math_svg(svg_str: str) -> dict | None:
    """מזהה אם <svg> הוא תרגיל חשבון במאונך (vertical_problem, column_shown,
    column_missing, blank_column, column_borrow) ומחלץ את מטריצת התאים שלו
    כדי לבנות טבלת Word עריכה במקום תמונת PNG."""
    import xml.etree.ElementTree as ET
    try:
        root = ET.fromstring(svg_str)
    except Exception:
        return None
    tags = {el.tag.rsplit("}", 1)[-1] for el in root.iter()}
    if not tags.issubset({"svg", "line", "rect", "text"}):
        return None

    texts = []
    for el in root.iter():
        if el.tag.rsplit("}", 1)[-1] == "text":
            t = "".join(el.itertext()).strip()
            if not t:
                continue
            # ב-svg_elementary כותרות עבריות עם rtl=True נשמרות הפוכות ויזואלית
            if HEB_RE.search(t) and len(t) > 1:
                t = t[::-1]
            x = float(el.get("x", 0))
            y = float(el.get("y", 0))
            fs = float(el.get("font-size", 20))
            color = el.get("fill", "#1A1A1A")
            texts.append({"x": x, "y": y, "text": t, "fs": fs,
                          "color": color, "strike": False})

    if not any(t["text"] in ("+", "−", "-", "×", "x") for t in texts):
        return None

    hlines_thick = []
    slash_lines = []
    for el in root.iter():
        if el.tag.rsplit("}", 1)[-1] == "line":
            x1, y1 = float(el.get("x1", 0)), float(el.get("y1", 0))
            x2, y2 = float(el.get("x2", 0)), float(el.get("y2", 0))
            sw = float(el.get("stroke-width", 1))
            if abs(y1 - y2) < 0.5 and sw >= 1.8 and abs(x2 - x1) > 40:
                hlines_thick.append(y1)
            elif abs(x2 - x1) > 5 and abs(y2 - y1) > 5:
                slash_lines.append(((x1 + x2) / 2, (y1 + y2) / 2))

    if not hlines_thick:
        return None
    y_sep = hlines_thick[0]

    for cx, cy in slash_lines:
        for t in texts:
            if abs(t["x"] - cx) < 12 and abs((t["y"] - 7) - cy) < 12:
                t["strike"] = True

    for el in root.iter():
        if el.tag.rsplit("}", 1)[-1] == "rect":
            rw, rh = float(el.get("width", 0)), float(el.get("height", 0))
            rx, ry = float(el.get("x", 0)), float(el.get("y", 0))
            if 16 <= rw <= 32 and 16 <= rh <= 32 and el.get("fill") == "white":
                texts.append({"x": rx + rw / 2, "y": ry + rh - 4,
                              "text": "☐", "fs": 18, "color": "#E67E22",
                              "strike": False})

    xs = sorted(set(round(t["x"], 1) for t in texts))
    col_centers = []
    for x in xs:
        if not col_centers or abs(x - col_centers[-1]) > 12:
            col_centers.append(x)
    ys = sorted(set(round(t["y"], 1) for t in texts))
    row_ys = []
    for y in ys:
        if not row_ys or abs(y - row_ys[-1]) > 10:
            row_ys.append(y)

    if not col_centers or not row_ys:
        return None

    grid = []
    sep_row_idx = 0
    for r_i, ry in enumerate(row_ys):
        row_cells = [None] * len(col_centers)
        for t in texts:
            if abs(t["y"] - ry) <= 6:
                c_i = min(range(len(col_centers)),
                          key=lambda i: abs(col_centers[i] - t["x"]))
                row_cells[c_i] = t
        grid.append((ry, row_cells))
        if ry < y_sep:
            sep_row_idx = r_i

    has_result_row = any(ry > y_sep for ry, _ in grid)
    if not has_result_row:
        empty_row = [{"x": cx, "y": y_sep + 24, "text": "", "fs": 20,
                      "color": "#1A1A1A", "strike": False}
                     for cx in col_centers]
        grid.append((y_sep + 24, empty_row))

    return {
        "cols": len(col_centers),
        "sep_after_row": sep_row_idx,
        "rows": [[c for c in r_cells] for _, r_cells in grid],
    }


def _hex_to_rgb(hex_str: str) -> tuple[int, int, int]:
    h = str(hex_str or "").lstrip("#").strip()
    if len(h) == 6:
        try:
            return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
        except ValueError:
            pass
    return (26, 26, 26)


def _add_vertical_math_table(container, vspec: dict,
                             base_size_pt: float = 13.0) -> None:
    """בונה טבלת Word עריכה לחלוטין לתרגיל חשבון במאונך (בטור)."""
    n_rows = len(vspec["rows"])
    n_cols = vspec["cols"]
    sep_idx = vspec["sep_after_row"]

    v_tbl = container.add_table(rows=n_rows, cols=n_cols)
    v_tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
    # כיוון העמודות משמאל לימין: עמודת הסימן משמאל, אחדות בימין
    set_table_rtl(v_tbl, is_rtl=False)
    set_table_borders(v_tbl, color="B8D4E8", sz="4", val="single")

    for r_i, row_data in enumerate(vspec["rows"]):
        row_obj = v_tbl.rows[r_i]
        row_obj.height = Cm(0.72)
        for c_i, cell_info in enumerate(row_data):
            cell = v_tbl.cell(r_i, c_i)
            cell.width = Cm(0.75)
            cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
            set_cell_margins(cell, 30, 30, 40, 40)

            # קו תוצאה עבה מתחת לשורת הפעולה
            if r_i == sep_idx:
                tcPr = cell._tc.get_or_add_tcPr()
                tcBorders = tcPr.find(qn("w:tcBorders"))
                if tcBorders is None:
                    tcBorders = OxmlElement("w:tcBorders")
                    tcPr.append(tcBorders)
                bot = parse_xml(
                    f'<w:bottom {nsdecls("w")} w:val="single" w:sz="14" '
                    f'w:space="0" w:color="1A1A1A"/>'
                )
                tcBorders.append(bot)

            p = cell.paragraphs[0]
            set_para_rtl(p, align=WD_ALIGN_PARAGRAPH.CENTER,
                         space_before=0, space_after=0)
            txt = cell_info["text"] if cell_info else ""
            if txt:
                is_heb = bool(HEB_RE.search(txt))
                run = p.add_run(txt if is_heb else f"{LRM}{txt}{LRM}")
                fs = 9.5 if (cell_info and cell_info.get("fs", 20) < 15) else base_size_pt
                rgb = _hex_to_rgb(cell_info.get("color", "#1A1A1A"))
                set_run_font(run, size_pt=fs, bold=(fs < 11),
                             color=rgb, rtl=is_heb)
                if cell_info.get("strike"):
                    run.font.strike = True


def add_figure_block(doc, fig_div: Tag, base_size_pt: float = 12.0) -> None:
    """הוספת בלוק שרטוט (`.figure`) למסמך Word:
    - אם ה-SVG הוא תרגיל חשבון במאונך (`vertical_problem` / `column_*`),
      ממיר אותו לטבלת Word עריכה לחלוטין (ולא לתמונה!).
    - אם מדובר בשורת שרטוטים (`figrow` עם כמה `span` שמכילים כותרת אות ו-SVG),
      בונה טבלה נקייה ללא גבולות שבה כל שרטוט/טור והאות שלו מופיעים זה לצד זה.
    - אם מדובר בשרטוט גאומטרי/איור בודד, מרנדר ל-PNG ב-300 DPI וממרכז בפסקה."""
    inline_spans = [
        ch for ch in fig_div.find_all("span", recursive=False)
        if ch.find("svg") is not None
    ]
    if len(inline_spans) > 1:
        n_cols = len(inline_spans)
        tbl = doc.add_table(rows=1, cols=n_cols)
        tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
        set_table_rtl(tbl, is_rtl=True)
        set_table_borders(tbl, color="FFFFFF", sz="0", val="none")
        max_col_cm = min(15.2 / n_cols, 6.5)

        for idx, sp in enumerate(inline_spans):
            cell = tbl.cell(0, idx)
            set_cell_margins(cell, 40, 40, 60, 60)
            p = cell.paragraphs[0]
            set_para_rtl(p, align=WD_ALIGN_PARAGRAPH.CENTER,
                         space_before=2, space_after=2)
            cap_div = sp.find("div")
            if cap_div and cap_div.get_text(strip=True):
                r_cap = p.add_run(cap_div.get_text(strip=True))
                set_run_font(r_cap, size_pt=base_size_pt, bold=True,
                             color=(30, 64, 175), rtl=True)
            svg_tag = sp.find("svg")
            if svg_tag is not None:
                vspec = _try_parse_vertical_math_svg(str(svg_tag))
                if vspec is not None:
                    _add_vertical_math_table(cell, vspec, base_size_pt=base_size_pt + 1.0)
                else:
                    if cap_div and cap_div.get_text(strip=True):
                        p.add_run("\n")
                    png_bytes, w_px, _ = svg_to_png_bytes(str(svg_tag))
                    w_cm = px_to_cm(w_px, max_cm=max_col_cm)
                    r_img = p.add_run()
                    r_img.add_picture(io.BytesIO(png_bytes), width=Cm(w_cm))
        return

    svgs = fig_div.find_all("svg")
    if not svgs and fig_div.get_text(strip=True):
        # אלמנט כמו number_cards שמכיל כרטיסי מספרים ב-span ולא SVG
        card_spans = fig_div.find_all("span", recursive=False)
        if len(card_spans) >= 2:
            c_tbl = doc.add_table(rows=1, cols=len(card_spans))
            c_tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
            set_table_rtl(c_tbl, is_rtl=False)
            set_table_borders(c_tbl, color="1F6FC5", sz="8", val="single")
            for idx, sp in enumerate(card_spans):
                cell = c_tbl.cell(0, idx)
                cell.width = Cm(1.4)
                set_cell_shading(cell, "EFF6FF")
                set_cell_margins(cell, 60, 60, 100, 100)
                p = cell.paragraphs[0]
                set_para_rtl(p, align=WD_ALIGN_PARAGRAPH.CENTER,
                             space_before=2, space_after=2)
                append_inline_content(p, sp, base_size_pt=base_size_pt + 1.5,
                                      bold=True, force_ltr=True)
            return
        p = doc.add_paragraph()
        set_para_rtl(p, align=WD_ALIGN_PARAGRAPH.CENTER, space_before=3, space_after=3)
        append_inline_content(p, fig_div, base_size_pt=base_size_pt)
        return

    for svg_tag in svgs:
        vspec = _try_parse_vertical_math_svg(str(svg_tag))
        if vspec is not None:
            _add_vertical_math_table(doc, vspec, base_size_pt=base_size_pt + 1.0)
            continue
        png_bytes, w_px, _ = svg_to_png_bytes(str(svg_tag))
        w_cm = px_to_cm(w_px, max_cm=15.0)
        p = doc.add_paragraph()
        set_para_rtl(p, align=WD_ALIGN_PARAGRAPH.CENTER,
                     space_before=4, space_after=4)
        r_img = p.add_run()
        r_img.add_picture(io.BytesIO(png_bytes), width=Cm(w_cm))


def add_html_table(doc, tbl_tag: Tag, base_size_pt: float = 12.0,
                   header_fill: str = "EFF6FF") -> None:
    """המרת `<table class="drill">` או `<table class="ans">` לטבלת Word עריכה."""
    tr_list = tbl_tag.find_all("tr")
    if not tr_list:
        return
    max_cols = max(len(tr.find_all(["td", "th"])) for tr in tr_list)
    if max_cols == 0:
        return

    is_ltr_table = (tbl_tag.get("dir", "").lower() == "ltr")
    w_tbl = doc.add_table(rows=len(tr_list), cols=max_cols)
    w_tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
    set_table_rtl(w_tbl, is_rtl=not is_ltr_table)
    set_table_borders(w_tbl, color="94A3B8", sz="6", val="single")

    # A question-number column is metadata, not half of the answer area.
    # Restrict sizing to the supported two-column answer table, with an
    # unambiguous qn column; leave drill and other table geometries unchanged.
    qn_columns = {index for tr in tr_list
                  for index, cell in enumerate(tr.find_all(["td", "th"]))
                  if "qn" in (cell.get("class") or [])}
    if "ans" in (tbl_tag.get("class") or []) and max_cols == 2 and len(qn_columns) == 1:
        qn_col = next(iter(qn_columns))
        if all(len(tr.find_all(["td", "th"])) == 2 and
               ("qn" in (tr.find_all(["td", "th"])[qn_col].get("class") or [])
                or tr.find_all(["td", "th"])[qn_col].name == "th") for tr in tr_list):
            section = doc.sections[-1] if hasattr(doc, "sections") else None
            total = (section.page_width - section.left_margin - section.right_margin
                     if section is not None else Cm(15.2))
            widths = [total - Cm(1.35), total - Cm(1.35)]
            widths[qn_col] = Cm(1.35)
            w_tbl.autofit = False
            for index, width in enumerate(widths):
                w_tbl.columns[index].width = width
                for row in w_tbl.rows:
                    row.cells[index].width = width

    for r_idx, tr in enumerate(tr_list):
        cells = tr.find_all(["td", "th"])
        for c_idx, td in enumerate(cells):
            if c_idx >= max_cols:
                break
            w_cell = w_tbl.cell(r_idx, c_idx)
            w_cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
            set_cell_margins(w_cell, 90, 90, 130, 130)
            is_qn = "qn" in (td.get("class") or [])
            is_numeric_qn = is_qn and bool(re.fullmatch(r"\s*\d+[.)]?\s*", td.get_text()))
            is_th = (td.name.lower() == "th") or is_qn
            if is_th:
                set_cell_shading(w_cell, header_fill)

            p = w_cell.paragraphs[0]
            align = (WD_ALIGN_PARAGRAPH.CENTER if (is_th or is_ltr_table)
                     else WD_ALIGN_PARAGRAPH.RIGHT)
            set_para_rtl(p, align=align, space_before=2, space_after=2)
            append_inline_content(p, td, base_size_pt=base_size_pt,
                                  bold=is_th, force_ltr=is_ltr_table or is_numeric_qn)


def add_ansline(doc) -> None:
    """הוספת שורת כתיבה מרווחת לתשובת תלמיד."""
    p = doc.add_paragraph()
    set_para_rtl(p, align=WD_ALIGN_PARAGRAPH.RIGHT, space_before=2, space_after=6)
    r = p.add_run("תשובה: " + "_" * 48)
    set_run_font(r, size_pt=11.5, color=(100, 116, 139), rtl=True)


# ---------------------------------------------------------------------------
# בניית מסמך ה-Word המלא מתוך sheet.html (ובשילוב content.json אם קיים)
# ---------------------------------------------------------------------------

def _append_answer_section(doc, ans_div, base_pt, accent_rgb, banner_fill,
                           preview=False, teacher_notes=()):
    """Render the supported answer table and notes; no general HTML conversion."""
    if not preview:
        doc.add_page_break()
    p_ah = doc.add_paragraph()
    set_para_rtl(p_ah, align=WD_ALIGN_PARAGRAPH.RIGHT, space_before=4, space_after=4)
    h2 = ans_div.find("h2")
    r_ah = p_ah.add_run(h2.get_text(strip=True) if h2 else "תשובות סופיות")
    set_run_font(r_ah, size_pt=base_pt + 3.0, bold=True, color=accent_rgb, rtl=True)

    note_el = ans_div.find(class_="note")
    if note_el:
        p_an = doc.add_paragraph()
        set_para_rtl(p_an, align=WD_ALIGN_PARAGRAPH.RIGHT, space_before=0, space_after=6)
        if preview:
            append_inline_content(p_an, note_el, base_size_pt=base_pt - 1.5,
                                  italic=True, color=(100, 116, 139))
        else:
            r_an = p_an.add_run(note_el.get_text(" ", strip=True))
            set_run_font(r_an, size_pt=base_pt - 1.5, italic=True,
                         color=(100, 116, 139), rtl=True)

    ans_tbl = ans_div.find("table", class_="ans")
    if ans_tbl:
        add_html_table(doc, ans_tbl, base_size_pt=base_pt - 0.5,
                       header_fill=banner_fill)

    if preview:
        for note in teacher_notes:
            para = doc.add_paragraph()
            set_para_rtl(para, space_before=8, space_after=4)
            append_inline_content(para, note, base_size_pt=base_pt - 1.5,
                                  color=(100, 116, 139))
        return

    # Preserve the ordinary worksheet's editable teacher-note area.
    p_tn = doc.add_paragraph()
    set_para_rtl(p_tn, align=WD_ALIGN_PARAGRAPH.RIGHT, space_before=12, space_after=4)
    r_tn = p_tn.add_run("הערות המורה / דגשים לכיתה:")
    set_run_font(r_tn, size_pt=base_pt, bold=True, color=accent_rgb, rtl=True)
    for _ in range(3):
        p_line = doc.add_paragraph()
        set_para_rtl(p_line, align=WD_ALIGN_PARAGRAPH.RIGHT, space_before=2, space_after=4)
        r_l = p_line.add_run("_" * 68)
        set_run_font(r_l, size_pt=11.0, color=(148, 163, 184), rtl=False)


def build_docx_from_html(html_path: Path | str, out_docx: Path | str,
                         content_json_path: Path | str | None = None,
                         include_answers: bool = True,
                         include_teacher_hints: bool = True) -> Path:
    """בונה קובץ `.docx` מעוצב וניתן לעריכה מתוך `sheet.html`."""
    html_path = Path(html_path)
    out_docx = Path(out_docx)
    if content_json_path is not None:
        content_json_path = Path(content_json_path)
    soup = BeautifulSoup(html_path.read_text(encoding="utf-8"), "html.parser")
    body = soup.find("body") or soup
    body_classes = set(body.get("class") or [])
    document_kind = body.get("data-document-kind", "worksheet")
    if document_kind not in ("worksheet", "answer-preview"):
        raise ValueError("Unsupported data-document-kind: %s" % document_kind)
    answer_preview = document_kind == "answer-preview"
    if answer_preview:
        ans_preview_div = body.find("div", class_="answers")
        preview_scope = body.find(class_="preview-scope")
        if not include_answers:
            raise ValueError("answer-preview requires include_answers=True")
        if body.select("ol.questions > li, .q"):
            raise ValueError("answer-preview cannot contain student questions")
        if len(body.find_all(class_="preview-scope")) != 1 or not preview_scope.get_text(strip=True):
            raise ValueError("answer-preview requires one visible .preview-scope")
        if (len(body.find_all("div", class_="answers")) != 1 or
                len(ans_preview_div.find_all("table", class_="ans")) != 1):
            raise ValueError("answer-preview requires one .answers table.ans")
        if content_json_path is not None and include_teacher_hints:
            raise ValueError("answer-preview does not support teacher hints; use --no-hints")

    # התאמת גודל גופן וצבעים לפי שכבת הגיל (א׳–ב׳ גדול יותר)
    if "band-ab" in body_classes:
        base_pt = 14.0
        accent_rgb = (180, 83, 9)      # ענבר חם לכיתות א׳–ב׳
        banner_fill = "FEF3C7"
        banner_border = "F59E0B"
    elif "band-hw" in body_classes:
        base_pt = 12.0
        accent_rgb = (30, 58, 138)     # כחול עמוק לכיתות ה׳–ו׳
        banner_fill = "E0E7FF"
        banner_border = "6366F1"
    else:
        base_pt = 12.5
        accent_rgb = (3, 105, 161)     # כחול שמיים לכיתות ג׳–ד׳
        banner_fill = "E0F2FE"
        banner_border = "0284C7"

    doc = docx.Document()

    # הגדרת עמוד A4 ו-RTL
    section = doc.sections[0]
    section.orientation = WD_ORIENT.PORTRAIT
    section.page_width = Cm(21.0)
    section.page_height = Cm(29.7)
    section.top_margin = Cm(1.6)
    section.bottom_margin = Cm(1.6)
    section.left_margin = Cm(1.8)
    section.right_margin = Cm(1.8)
    set_section_rtl(section)

    # כותרת עליונה (בס״ד מימין, מתמטיקה · נועם דורון משמאל)
    header = section.header
    hp = header.paragraphs[0]
    set_para_rtl(hp, align=WD_ALIGN_PARAGRAPH.RIGHT, space_before=0, space_after=4)
    r_besd = hp.add_run(f"{BESD}\t\t{BRAND}")
    set_run_font(r_besd, size_pt=9.5, bold=True, color=(100, 116, 139), rtl=True)

    # כותרת תחתונה
    footer = section.footer
    fp = footer.paragraphs[0]
    set_para_rtl(fp, align=WD_ALIGN_PARAGRAPH.CENTER, space_before=4, space_after=0)
    r_foot = fp.add_run(f"{BRAND}  ·  גרסת Word ניתנת לעריכה למורים")
    set_run_font(r_foot, size_pt=9.0, color=(100, 116, 139), rtl=True)

    # 1. תיבת כותרת ראשית של דף העבודה
    unit_el = body.find(class_="unit") or body.find("h1")
    sub_el = body.find(class_="subtitle")
    unit_title = unit_el.get_text(" ", strip=True) if unit_el else "דף עבודה במתמטיקה"
    subtitle_text = sub_el.get_text(" ", strip=True) if sub_el else ""

    banner_tbl = doc.add_table(rows=1, cols=1)
    banner_tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
    set_table_rtl(banner_tbl, is_rtl=True)
    set_table_borders(banner_tbl, color=banner_border, sz="12", val="single")
    b_cell = banner_tbl.cell(0, 0)
    set_cell_shading(b_cell, banner_fill)
    set_cell_margins(b_cell, 140, 140, 200, 200)

    bp1 = b_cell.paragraphs[0]
    set_para_rtl(bp1, align=WD_ALIGN_PARAGRAPH.RIGHT, space_before=0, space_after=2)
    r_title = bp1.add_run(unit_title)
    set_run_font(r_title, size_pt=base_pt + 4.5, bold=True, color=accent_rgb, rtl=True)

    if subtitle_text:
        bp2 = b_cell.add_paragraph()
        set_para_rtl(bp2, align=WD_ALIGN_PARAGRAPH.RIGHT, space_before=0, space_after=0)
        r_sub = bp2.add_run(subtitle_text)
        set_run_font(r_sub, size_pt=base_pt - 0.5, bold=False,
                     color=(51, 65, 85), rtl=True)

    if answer_preview:
        scope_para = doc.add_paragraph()
        set_para_rtl(scope_para, space_before=6, space_after=6)
        append_inline_content(scope_para, preview_scope, base_size_pt=base_pt - 0.5,
                              bold=True, color=(36, 80, 122))
        _append_answer_section(
            doc, ans_preview_div, base_pt, accent_rgb, banner_fill, preview=True,
            teacher_notes=body.find_all(class_="teacher-notes"))
        enforce_docx_rtl(doc)
        out_docx.parent.mkdir(parents=True, exist_ok=True)
        doc.save(str(out_docx))
        return out_docx

    # 2. שורת פרטי תלמיד (שם / כיתה / תאריך)
    details_el = body.find(class_="details")
    p_det = doc.add_paragraph()
    set_para_rtl(p_det, align=WD_ALIGN_PARAGRAPH.RIGHT, space_before=6, space_after=8)
    if details_el:
        spans = [s.get_text(" ", strip=True) for s in details_el.find_all("span")]
        det_txt = "     ".join(spans) if spans else details_el.get_text(" ", strip=True)
    else:
        det_txt = "שם התלמיד/ה: ____________________     כיתה: ________     תאריך: __________"
    r_det = p_det.add_run(det_txt)
    set_run_font(r_det, size_pt=base_pt - 1.0, bold=True, color=(71, 85, 105), rtl=True)

    # 3. תיבות פתיחה / תזכורת / חימום אם קיימות לפני השאלות
    for box_el in body.find_all(class_=re.compile(r"^(warmup|tip-box|summary-box|rule-box|worked-example)$"), recursive=False):
        box_tbl = doc.add_table(rows=1, cols=1)
        set_table_rtl(box_tbl, is_rtl=True)
        set_table_borders(box_tbl, color="93C5FD", sz="8", val="single")
        c = box_tbl.cell(0, 0)
        set_cell_shading(c, "F8FAFC")
        set_cell_margins(c, 100, 100, 150, 150)
        p = c.paragraphs[0]
        set_para_rtl(p, align=WD_ALIGN_PARAGRAPH.RIGHT, space_before=2, space_after=2)
        append_inline_content(p, box_el, base_size_pt=base_pt)
        doc.add_paragraph()

    # 4. רשימת השאלות (`ol.questions > li` או `.q`)
    q_ol = body.find("ol", class_="questions")
    q_items = q_ol.find_all("li", recursive=False) if q_ol else body.find_all(class_="q")

    for q_idx, li in enumerate(q_items, start=1):
        q_num = str(q_idx)
        is_starred = "starred" in (li.get("class") or []) or (li.find(class_="star") is not None)

        # פסקת גזע השאלה (Stem)
        p_stem = doc.add_paragraph()
        set_para_rtl(p_stem, align=WD_ALIGN_PARAGRAPH.RIGHT,
                     space_before=8, space_after=4, keep_with_next=True)

        # מספור השאלה
        prefix = f"{q_num}. " + ("★ " if is_starred else "")
        r_num = p_stem.add_run(prefix)
        set_run_font(r_num, size_pt=base_pt, bold=True,
                     color=(217, 119, 6) if is_starred else accent_rgb, rtl=True)

        # מעבר על ילדי השאלה לפי הסדר: טקסט זורם לפסקת הגזע, ובלוקים (שרטוטים, טבלאות, תתי-סעיפים, מסגרות) כבלוקים נפרדים
        def _walk_q_children(container, parent_tag, start_p=None):
            cur_p = start_p
            for child in parent_tag.children:
                if isinstance(child, Tag):
                    c_classes = set(child.get("class") or [])
                    if "star" in c_classes and not child.get_text(strip=True):
                        continue
                    if "figure" in c_classes:
                        add_figure_block(container, child, base_size_pt=base_pt - 0.5)
                        cur_p = None
                        continue
                    if child.name.lower() == "table":
                        add_html_table(container, child, base_size_pt=base_pt - 0.5)
                        cur_p = None
                        continue
                    if "sub" in c_classes:
                        p_sub = container.add_paragraph()
                        set_para_rtl(p_sub, align=WD_ALIGN_PARAGRAPH.RIGHT,
                                     space_before=3, space_after=4)
                        for inline_child in child.children:
                            append_inline_content(p_sub, inline_child, base_size_pt=base_pt)
                        cur_p = None
                        continue
                    if "ansline" in c_classes:
                        add_ansline(container)
                        cur_p = None
                        continue
                    if c_classes & {"frame", "reminder", "vocab"}:
                        f_tbl = container.add_table(rows=1, cols=1)
                        f_tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
                        set_table_rtl(f_tbl, is_rtl=True)
                        brd_c = ("E8821E" if "orange" in c_classes else
                                 ("159E8E" if "teal" in c_classes else "1F6FC5"))
                        bg_c = ("FFF7ED" if "orange" in c_classes else
                                ("F0FDFA" if "teal" in c_classes else "F8FAFC"))
                        set_table_borders(f_tbl, color=brd_c, sz="8", val="single")
                        f_cell = f_tbl.cell(0, 0)
                        set_cell_shading(f_cell, bg_c)
                        set_cell_margins(f_cell, 100, 100, 150, 150)
                        fp0 = f_cell.paragraphs[0]
                        set_para_rtl(fp0, align=WD_ALIGN_PARAGRAPH.RIGHT,
                                     space_before=2, space_after=2)
                        _walk_q_children(f_cell, child, start_p=fp0)
                        cur_p = None
                        continue
                    if child.name.lower() == "div" and (
                        child.find("table") or child.find(class_="figure") or child.find(class_="sub")
                    ):
                        _walk_q_children(container, child, start_p=None)
                        cur_p = None
                        continue
                if cur_p is None:
                    if isinstance(child, NavigableString) and not str(child).strip():
                        continue
                    cur_p = container.add_paragraph()
                    set_para_rtl(cur_p, align=WD_ALIGN_PARAGRAPH.RIGHT,
                                 space_before=2, space_after=4)
                append_inline_content(cur_p, child, base_size_pt=base_pt)

        _walk_q_children(doc, li, start_p=p_stem)

    # שורת "בהצלחה!"
    goodluck_el = body.find(class_="goodluck")
    p_gl = doc.add_paragraph()
    set_para_rtl(p_gl, align=WD_ALIGN_PARAGRAPH.CENTER, space_before=10, space_after=6)
    r_gl = p_gl.add_run(goodluck_el.get_text(strip=True) if goodluck_el else "בהצלחה!")
    set_run_font(r_gl, size_pt=base_pt + 1.5, bold=True, color=accent_rgb, rtl=True)

    # 5. עמוד תשובות סופיות (אם קיים ונדרש)
    ans_div = body.find("div", class_="answers")
    if include_answers and ans_div is not None:
        _append_answer_section(doc, ans_div, base_pt, accent_rgb, banner_fill)

    # 6. רמזים רק ממקור שנבחר במפורש; אין קריאת content.json סמוך בשקט.
    if include_teacher_hints and content_json_path is not None:
        hint_bundles = _read_teacher_hints(content_json_path)
        if hint_bundles:
            p_hh = doc.add_paragraph()
            set_para_rtl(p_hh, align=WD_ALIGN_PARAGRAPH.RIGHT, space_before=14, space_after=4)
            r_hh = p_hh.add_run("נספח למורה — רמזים מדורגים (ללא ספוילר)")
            set_run_font(r_hh, size_pt=base_pt + 2.0, bold=True, color=accent_rgb, rtl=True)
            for qn_str, hints in hint_bundles:
                for h_i, h_txt in enumerate(hints, start=1):
                    ph = doc.add_paragraph()
                    set_para_rtl(ph, align=WD_ALIGN_PARAGRAPH.RIGHT,
                                 space_before=1, space_after=2)
                    rh_lbl = ph.add_run(f"שאלה {qn_str} · רמז {h_i}: ")
                    set_run_font(rh_lbl, size_pt=base_pt - 1.0, bold=True,
                                 color=(30, 64, 175), rtl=True)
                    rh_val = ph.add_run(h_txt)
                    set_run_font(rh_val, size_pt=base_pt - 1.0, bold=False, rtl=True)

    enforce_docx_rtl(doc)
    out_docx.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(out_docx))
    return out_docx


def _read_teacher_hints(content_path: Path) -> list[tuple[str, list[str]]]:
    """Read the supported question-level text hints; never silently omit other forms."""
    data = json.loads(content_path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        return []
    unsupported = (
        "ייצוא רמזים ל-Word תומך רק ב-questions[].hints כרשימה של שלוש "
        "מחרוזות לא ריקות; המירו את המקור במפורש או השתמשו ב--no-hints"
    )
    if data.get("hints"):
        raise ValueError(unsupported)
    bundles = []
    for index, question in enumerate(data.get("questions") or [], 1):
        if not isinstance(question, dict):
            continue
        if any(question.get(key) for key in ("hint_svg", "hint_fig")):
            raise ValueError(unsupported)
        for item in question.get("items") or []:
            if isinstance(item, dict) and any(
                    item.get(key) for key in ("hints", "hint_svg", "hint_fig")):
                raise ValueError(unsupported)
        hints = question.get("hints")
        if not hints:
            continue
        if (not isinstance(hints, list) or len(hints) != 3 or
                any(not isinstance(hint, str) or not hint.strip() for hint in hints)):
            raise ValueError(unsupported)
        bundles.append((str(question.get("n", index)), hints))
    return bundles


def build_docx_from_content_json(content_path: Path | str, out_docx: Path | str,
                                 include_answers: bool = True,
                                 include_teacher_hints: bool = True) -> Path:
    """Build only from the explicitly selected JSON; ignore neighboring HTML files."""
    content_path = Path(content_path)
    out_docx = Path(out_docx)
    # הרכבת HTML אוטומטית מתוך content.json
    data = json.loads(content_path.read_text(encoding="utf-8"))
    meta = data.get("meta", {}) if isinstance(data, dict) else {}
    grade = str(meta.get("grade", "ג")).replace("׳", "").replace("'", "").strip() or "ג"
    topic = str(meta.get("topic", "דף עבודה במתמטיקה"))
    level = str(meta.get("level", ""))
    band_cls = ("band-ab" if grade in ("א", "ב")
                else ("band-hv" if grade in ("ה", "ו") else "band-gd"))

    questions = data.get("questions", []) if isinstance(data, dict) else data
    tpl_path = ASSETS_DIR / "worksheet_template_elementary.html"
    head = (tpl_path.read_text(encoding="utf-8").split("<body", 1)[0]
            if tpl_path.is_file() else "<!DOCTYPE html><html lang='he' dir='rtl'><head><meta charset='utf-8'></head>")

    sub_parts = [f"כיתה {grade}׳"]
    if level:
        sub_parts.append(f"רמה {level}")
    body_lines = [
        f'<body class="{band_cls}">',
        f'<div class="unit">{topic}</div><hr class="unit-rule">',
        f'<div class="subtitle">{" · ".join(sub_parts)}</div>',
        '<div class="details"><span>שם: ____________________</span>'
        '<span>כיתה: ________</span><span>תאריך: __________</span></div>',
        '<ol class="questions">',
    ]
    HEB_LETTERS = "אבגדהוזחטיכלמנסעפצקרשת"

    def _first_nonempty(*values):
        for value in values:
            if value is None:
                continue
            if isinstance(value, (str, list, tuple, dict)) and len(value) == 0:
                continue
            return value
        return ""

    def _fmt_math_html(txt) -> str:
        s = str("" if txt is None else txt)
        # המרת \f{a}{b} או \frac{a}{b} ל-span.frac
        s = re.sub(
            r"\\(?:f|frac)\{\s*([^{}]+?)\s*\}\{\s*([^{}]+?)\s*\}",
            r'<span class="frac"><span class="fnum">\1</span><span class="fden">\2</span></span>',
            s,
        )
        # אם אין עברית במחרוזת ויש ספרות/סימנים, נעטוף ב-span.ltr
        if not HEB_RE.search(s) and re.search(r"[\d+\-−×x:<>=]", s):
            return f'<span class="ltr">{s}</span>'
        return s

    ans_rows = []
    for idx, q in enumerate(questions, start=1):
        qn_str = str(q.get("n", idx))
        q_html = _fmt_math_html(_first_nonempty(
            q.get("html"), q.get("intro"), q.get("text"), q.get("stem")))
        items = q.get("items") or []
        items_html_parts = []
        item_answers = []
        for it_i, it in enumerate(items):
            lbl = HEB_LETTERS[it_i] if it_i < len(HEB_LETTERS) else str(it_i + 1)
            if isinstance(it, dict):
                lbl = str(it.get("label") or lbl)
                it_txt = _fmt_math_html(_first_nonempty(it.get("text"), it.get("html")))
                if it.get("answer") is not None:
                    item_answers.append(f"{lbl}. {_fmt_math_html(it.get('answer'))}" if lbl else _fmt_math_html(it.get("answer")))
            elif isinstance(it, (list, tuple)) and len(it) >= 2:
                lbl = str(it[0])
                it_txt = _fmt_math_html(it[1])
            else:
                it_txt = _fmt_math_html(str(it))
            prefix = f"<b>{lbl}.</b> " if lbl else ""
            items_html_parts.append(f'<div class="sub">{prefix}{it_txt}</div>')

        raw_ans = _first_nonempty(q.get("ans"), q.get("answer"))
        if isinstance(raw_ans, list):
            ans_html = " ; ".join(_fmt_math_html(x) for x in raw_ans)
        elif raw_ans is not None and str(raw_ans).strip():
            ans_html = _fmt_math_html(str(raw_ans))
        elif item_answers:
            ans_html = " &nbsp;|&nbsp; ".join(item_answers)
        else:
            ans_html = ""

        fig_ref = q.get("fig")
        fig_block = ""
        if fig_ref:
            if "<svg" in str(fig_ref):
                fig_block = f'<div class="figure" dir="ltr">{fig_ref}</div>'
            else:
                fig_file = content_path.parent / str(fig_ref)
                if not fig_file.is_file():
                    fig_file = content_path.parent / "figures" / str(fig_ref)
                if fig_file.is_file():
                    svg_txt = fig_file.read_text(encoding="utf-8")
                    svg_txt = re.sub(r"<\?xml[^>]*\?>", "", svg_txt).strip()
                    fig_block = f'<div class="figure" dir="ltr">{svg_txt}</div>'
        subs_joined = "".join(items_html_parts)
        ansline_div = "" if items_html_parts else '<div class="ansline"></div>'
        body_lines.append(f'<li>{q_html}{fig_block}{subs_joined}{ansline_div}</li>')
        ans_rows.append(
            f'<tr><td class="qn"><span class="ltr">{qn_str}.</span></td>'
            f'<td>{ans_html}</td></tr>'
        )
    body_lines.append("</ol>")
    body_lines.append('<div class="goodluck">בהצלחה!</div>')
    body_lines.append(
        '<div class="answers"><h2>תשובות סופיות</h2>'
        '<div class="note">התשובות מיועדות לבדיקה עצמית אחרי הפתרון.</div>'
        f'<table class="ans">{"".join(ans_rows)}</table></div>'
    )
    body_lines.append("</body></html>")

    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_html = Path(tmpdir) / "sheet.html"
        tmp_html.write_text(head + "\n".join(body_lines), encoding="utf-8")
        return build_docx_from_html(tmp_html, out_docx,
                                    content_json_path=content_path,
                                    include_answers=include_answers,
                                    include_teacher_hints=include_teacher_hints)


def verify_docx(docx_path: Path | str) -> tuple[bool, str]:
    """בדיקה מבנית מוגבלת לקובץ `.docx` שנוצר:
    1. הקובץ קיים ולא ריק.
    2. ברירות המחדל, Normal, כל המקטעים והפסקאות בגוף/תאים/כותרות מוגדרים RTL.
    3. המותג 'מתמטיקה · נועם דורון' ו-'בס״ד' נמצאים בכותרת העליונה/תחתונה.
    4. נמצא טקסט עברי בפסקאות הראשיות.
    אינה מאמתת כיסוי תוכן, עריכות הנוסחאות או עימוד חזותי.
    """
    docx_path = Path(docx_path)
    if not docx_path.is_file() or docx_path.stat().st_size < 2000:
        return False, f"קובץ ה-DOCX חסר או ריק: {docx_path}"
    d = docx.Document(str(docx_path))
    rtl_error = _rtl_validation_error(d)
    if rtl_error:
        return False, rtl_error
    header_txt = "\n".join(p.text for p in d.sections[0].header.paragraphs)
    footer_txt = "\n".join(p.text for p in d.sections[0].footer.paragraphs)
    if BRAND not in header_txt and BRAND not in footer_txt:
        return False, f"המותג '{BRAND}' חסר מהכותרת העליונה/תחתונה ב-DOCX"
    if BESD not in header_txt:
        return False, f"'{BESD}' חסר מהכותרת העליונה ב-DOCX"
    body_txt = "\n".join(p.text for p in d.paragraphs)
    if not HEB_RE.search(body_txt):
        return False, "לא נמצא טקסט עברי בגוף ה-DOCX"
    return True, f"DOCX תקין ({len(d.paragraphs)} פסקאות, {len(d.tables)} טבלאות, {docx_path.stat().st_size} בייטים)"


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        description="ייצוא דף עבודה יסודי (sheet.html או content.json) לקובץ Word ניתן לעריכה (.docx) לדף המורים."
    )
    ap.add_argument("input", help="נתיב ל-sheet.html או ל-content.json")
    ap.add_argument("output", nargs="?", help="נתיב לקובץ .docx הפלט (ברירת מחדל: אותו שם עם סיומת .docx)")
    ap.add_argument("--content", help="מקור JSON מפורש לרמזים בייצוא HTML בלבד")
    ap.add_argument("--no-answers", action="store_true", help="ייצוא דף לתלמיד בלבד (ללא עמוד תשובות סופיות)")
    ap.add_argument("--no-hints", action="store_true", help="ללא נספח רמזים למורה")
    args = ap.parse_args(argv)

    in_path = Path(args.input).resolve()
    if not in_path.is_file():
        print(f"שגיאה: קובץ הקלט לא נמצא: {in_path}", file=sys.stderr)
        return 1

    out_path = Path(args.output).resolve() if args.output else in_path.with_suffix(".docx")
    content_path = Path(args.content).resolve() if args.content else None

    if in_path.suffix.lower() == ".json":
        if content_path is not None:
            ap.error("--content מיועד לייצוא HTML בלבד; בייצוא JSON הרמזים נקראים מקובץ הקלט")
        build_docx_from_content_json(
            in_path, out_path,
            include_answers=not args.no_answers,
            include_teacher_hints=not args.no_hints,
        )
    else:
        build_docx_from_html(
            in_path, out_path,
            content_json_path=content_path,
            include_answers=not args.no_answers,
            include_teacher_hints=not args.no_hints,
        )

    ok, msg = verify_docx(out_path)
    if not ok:
        print(f"FAIL: {msg}", file=sys.stderr)
        return 1
    print(f"נוצר בהצלחה: {out_path} — {msg}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
