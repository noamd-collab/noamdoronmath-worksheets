#!/usr/bin/env python3
"""RTL defaults, final coverage and preservation of editable math in DOCX."""
from pathlib import Path
import sys
import tempfile
import unittest

import docx
from bs4 import BeautifulSoup
from docx.enum.section import WD_SECTION_START
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.opc.constants import CONTENT_TYPE as CT
from docx.shared import Cm
from lxml import etree

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import build_docx as BD


def enabled(properties):
    flag = properties.find(qn("w:bidi")) if properties is not None else None
    return flag is not None and flag.get(qn("w:val")) in (None, "1", "true", "on")


def default_paragraph_properties(document):
    return document.styles.element.find(
        "./" + qn("w:docDefaults") + "/" + qn("w:pPrDefault") + "/" + qn("w:pPr"))


def roots(document):
    return [document.element] + [part.element for part in document.part.package.parts
                                if part.content_type in (CT.WML_HEADER, CT.WML_FOOTER)]


class DocxRtlTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / "sheet.docx"

    def document(self):
        document = docx.Document()
        paragraph = document.add_paragraph("טקסט עברי ")
        math = paragraph.add_run("12 − 3 = 9")
        BD.set_run_font(math, rtl=False)
        BD.append_omml_fraction(paragraph, "1", "4")
        centered = document.add_paragraph("כותרת ממורכזת")
        centered.alignment = WD_ALIGN_PARAGRAPH.CENTER
        document.add_paragraph()
        table = document.add_table(rows=2, cols=2)
        BD.set_table_rtl(table, is_rtl=False)
        table.cell(0, 0).text = "12"
        table.cell(0, 1).text = "3"
        nested = table.cell(1, 0).add_table(rows=1, cols=2)
        nested.cell(0, 0).text = "תא מקונן"
        BD.set_table_rtl(nested, is_rtl=True)
        section = document.sections[0]
        section.header.paragraphs[0].text = BD.BESD + " " + BD.BRAND
        section.footer.paragraphs[0].text = BD.BRAND
        section.footer.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        # These accessors deliberately create all header/footer variants for coverage.
        section.first_page_header.paragraphs[0].text = "כותרת ראשונה"
        section.even_page_header.add_table(rows=1, cols=1, width=Cm(5))
        section.first_page_footer.paragraphs[0].text = "תחתית ראשונה"
        section.even_page_footer.paragraphs[0].text = "תחתית זוגית"
        document.add_section(WD_SECTION_START.NEW_PAGE)
        document.sections[1].header.is_linked_to_previous = False
        document.sections[1].header.paragraphs[0].text = "כותרת מקטע שני"
        return document

    def test_new_paragraphs_inherit_rtl_after_reopening(self):
        document = docx.Document()
        BD.enforce_docx_rtl(document)
        inherited = document.styles.add_style("Inherited worksheet", WD_STYLE_TYPE.PARAGRAPH)
        inherited.base_style = document.styles["Normal"]
        document.save(self.path)
        reopened = docx.Document(self.path)
        ordinary = reopened.add_paragraph("פסקה חדשה")
        styled = reopened.add_paragraph("סגנון יורש", style="Inherited worksheet")
        cell_p = reopened.add_table(rows=1, cols=1).cell(0, 0).paragraphs[0]
        for paragraph in (ordinary, styled, cell_p):
            # These new paragraphs have no direct bidi; the persisted styles supply it.
            p_pr = paragraph._p.find(qn("w:pPr"))
            self.assertFalse(enabled(p_pr))
            style = paragraph.style
            while style is not None and not enabled(style.element.find(qn("w:pPr"))):
                style = style.base_style
            self.assertIsNotNone(style)
            self.assertEqual(style.name, "Normal")
        self.assertTrue(enabled(default_paragraph_properties(reopened)))
        for p_pr in (default_paragraph_properties(reopened), reopened.styles["Normal"].element.pPr):
            self.assertIsNone(p_pr.find(qn("w:jc")))
        r_pr = reopened.styles.element.find(
            "./" + qn("w:docDefaults") + "/" + qn("w:rPrDefault") + "/" + qn("w:rPr"))
        self.assertIsNone(r_pr.find(qn("w:rtl")))
        self.assertEqual(r_pr.find(qn("w:lang")).get(qn("w:bidi")), "he-IL")

    def test_final_pass_covers_blank_nested_and_all_header_footer_paragraphs(self):
        document = self.document()
        all_paragraphs = [p for root in roots(document) for p in root.iter(qn("w:p"))]
        self.assertGreater(sum(not p.findall(qn("w:r")) for p in all_paragraphs), 3)
        for p in all_paragraphs[::2]:
            flag = OxmlElement("w:bidi")
            flag.set(qn("w:val"), "false")
            p.get_or_add_pPr().append(flag)
        BD.enforce_docx_rtl(document)
        for root in roots(document):
            for p in root.iter(qn("w:p")):
                self.assertTrue(enabled(p.find(qn("w:pPr"))))
        for section in document.sections:
            self.assertTrue(enabled(section._sectPr))
        document.save(self.path)
        self.assertTrue(BD.verify_docx(self.path)[0])

    def test_normalization_preserves_centered_math_and_table_order(self):
        document = self.document()
        centered = document.paragraphs[1]
        math = document.paragraphs[0].runs[1]
        before_run = math._r.xml
        before_omml = etree.tostring(document.paragraphs[0]._p.find(qn("m:oMath")))
        tables = list(document.element.iter(qn("w:tbl")))
        before_order = [[t.text for t in table.iter(qn("w:t"))] for table in tables]
        before_flags = [table.find(qn("w:tblPr")).find(qn("w:bidiVisual")).get(qn("w:val"))
                        for table in tables]
        self.assertEqual(before_flags, ["0", "1"])
        BD.enforce_docx_rtl(document)
        self.assertEqual(centered.alignment, WD_ALIGN_PARAGRAPH.CENTER)
        self.assertEqual(document.sections[0].footer.paragraphs[0].alignment,
                         WD_ALIGN_PARAGRAPH.CENTER)
        self.assertEqual(math._r.xml, before_run)
        self.assertIs(math.font.rtl, False)
        self.assertEqual(etree.tostring(document.paragraphs[0]._p.find(qn("m:oMath"))), before_omml)
        self.assertEqual([[t.text for t in table.iter(qn("w:t"))] for table in tables], before_order)
        self.assertEqual([table.find(qn("w:tblPr")).find(qn("w:bidiVisual")).get(qn("w:val"))
                          for table in tables], before_flags)

    def test_setters_repair_false_values_and_normalization_is_idempotent(self):
        document = self.document()
        paragraph = document.paragraphs[0]
        for value in ("0", "false", "off"):
            p_pr = paragraph._p.get_or_add_pPr()
            BD.set_para_rtl(paragraph)
            p_pr.find(qn("w:bidi")).set(qn("w:val"), value)
            BD.set_para_rtl(paragraph, align=WD_ALIGN_PARAGRAPH.CENTER)
            self.assertTrue(enabled(p_pr))
            BD.set_section_rtl(document.sections[0])
            document.sections[0]._sectPr.find(qn("w:bidi")).set(qn("w:val"), value)
            BD.set_section_rtl(document.sections[0])
            self.assertTrue(enabled(document.sections[0]._sectPr))
        BD.enforce_docx_rtl(document)
        before = [root.xml for root in roots(document)] + [document.styles.element.xml]
        BD.enforce_docx_rtl(document)
        self.assertEqual([root.xml for root in roots(document)] + [document.styles.element.xml], before)
        self.assertEqual(paragraph.alignment, WD_ALIGN_PARAGRAPH.CENTER)
        paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        BD.enforce_docx_rtl(document)
        self.assertIsNone(paragraph._p.pPr.find(qn("w:jc")))
        BD.set_para_rtl(paragraph)
        self.assertIsNone(paragraph._p.pPr.find(qn("w:jc")))
        empty = docx.Document()
        parts_before = len(empty.part.package.parts)
        BD.enforce_docx_rtl(empty)
        self.assertEqual(len(empty.part.package.parts), parts_before)

    def test_validator_rejects_missing_and_false_defaults_sections_and_paragraphs(self):
        original = self.document()
        BD.enforce_docx_rtl(original)
        original.save(self.path)
        original_bytes = self.path.read_bytes()
        targets = {
            "docDefaults": default_paragraph_properties,
            "Normal": lambda d: d.styles["Normal"].element.find(qn("w:pPr")),
            "second section": lambda d: d.sections[1]._sectPr,
            "body": lambda d: d.paragraphs[0]._p.get_or_add_pPr(),
            "blank": lambda d: d.paragraphs[2]._p.get_or_add_pPr(),
            "nested cell": lambda d: d.tables[0].cell(1, 0).tables[0].cell(0, 0).paragraphs[0]._p.get_or_add_pPr(),
            "header": lambda d: d.sections[1].header.paragraphs[0]._p.get_or_add_pPr(),
            "footer": lambda d: d.sections[0].footer.paragraphs[0]._p.get_or_add_pPr(),
        }
        for name, target in targets.items():
            for value in (None, "0", "false", "off"):
                with self.subTest(target=name, value=value):
                    self.path.write_bytes(original_bytes)
                    document = docx.Document(self.path)
                    properties = target(document)
                    flag = properties.find(qn("w:bidi"))
                    if value is None:
                        properties.remove(flag)
                    else:
                        flag.set(qn("w:val"), value)
                    document.save(self.path)
                    ok, message = BD.verify_docx(self.path)
                    self.assertFalse(ok, message)
                    self.assertIn("RTL", message)

    def test_complex_script_format_matches_requested_hebrew_size_weight_and_italic(self):
        document = docx.Document()
        run = document.add_paragraph().add_run("עברית")
        BD.set_run_font(run, size_pt=17.5, bold=True, italic=True, rtl=True)
        r_pr = run._r.get_or_add_rPr()
        self.assertEqual(r_pr.find(qn("w:sz")).get(qn("w:val")), "35")
        self.assertEqual(r_pr.find(qn("w:szCs")).get(qn("w:val")), "35")
        self.assertIs(run.font.cs_bold, True)
        self.assertIs(run.font.cs_italic, True)
        BD.set_run_font(run, size_pt=12, bold=False, italic=False, rtl=False)
        self.assertEqual(r_pr.find(qn("w:szCs")).get(qn("w:val")), "24")
        self.assertIs(run.font.cs_bold, False)
        self.assertIs(run.font.cs_italic, False)
        self.assertIs(run.font.rtl, False)

    def test_exported_subparagraph_keeps_hebrew_ltr_math_and_editable_fraction(self):
        html = Path(self.tmp.name) / "sheet.html"
        html.write_text(
            '<html dir="rtl"><body><div class="unit">בדיקת כיווניות</div>'
            '<ol class="questions"><li>פתרו:'
            '<div class="sub"><b>א.</b> חשבו את הביטוי '
            '<span class="ltr">12 − 3 = 9</span></div>'
            '<div class="sub"><b>ב.</b> השלימו '
            '<span class="ltr"><span class="frac"><span class="fnum">1</span>'
            '<span class="fden">4</span></span> + 2 = ___</span></div>'
            '</li></ol><div class="answers"><h2>תשובות סופיות</h2>'
            '<table class="ans"><tr><td>1.</td><td>9</td></tr></table></div>'
            '</body></html>', encoding="utf-8")
        BD.build_docx_from_html(html, self.path)
        document = docx.Document(self.path)
        texts = "\n".join(p.text for p in document.paragraphs)
        self.assertIn("חשבו את הביטוי", texts)
        self.assertIn("12 − 3 = 9", texts)
        self.assertIn("השלימו", texts)
        math_runs = [r for p in document.paragraphs for r in p.runs if "12 − 3 = 9" in r.text]
        self.assertEqual(len(math_runs), 1)
        self.assertIs(math_runs[0].font.rtl, False)
        fractions = list(document.element.iter(qn("m:f")))
        self.assertEqual(len(fractions), 1)
        self.assertEqual([t.text for t in fractions[0].iter(qn("m:t"))], ["1", "4"])
        self.assertTrue(BD.verify_docx(self.path)[0])
        for root in roots(document):
            for p in root.iter(qn("w:p")):
                self.assertTrue(enabled(p.find(qn("w:pPr"))))

    def test_two_fractions_and_comparison_are_one_ordered_editable_expression(self):
        document = docx.Document()
        paragraph = document.add_paragraph("השוו: ")
        html = BeautifulSoup(
            '<span class="ltr"><span class="frac"><span class="fnum">1</span>'
            '<span class="fden">2</span></span> &lt; '
            '<span class="frac"><span class="fnum">3</span>'
            '<span class="fden">4</span></span></span>', "html.parser")
        BD.append_inline_content(paragraph, html.span)
        BD.enforce_docx_rtl(document)
        document.save(self.path)
        reopened = docx.Document(self.path)
        p = reopened.paragraphs[0]._p
        expressions = p.findall(qn("m:oMath"))
        self.assertEqual(len(expressions), 1)
        self.assertEqual(len(list(expressions[0].iter(qn("m:f")))), 2)
        self.assertEqual([t.text for t in expressions[0].iter(qn("m:t"))],
                         ["1", "2", " < ", "3", "4"])
        self.assertIn("השוו", reopened.paragraphs[0].text)
        self.assertNotIn("<", reopened.paragraphs[0].text)


if __name__ == "__main__":
    unittest.main()
