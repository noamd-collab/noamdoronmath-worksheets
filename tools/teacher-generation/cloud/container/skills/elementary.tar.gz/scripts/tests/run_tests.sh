#!/bin/bash
# מבחני רגרסיה של הסקיל היסודי — חובה אחרי כל שינוי בסקריפטים.
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
LIB="$HERE/../lib"

echo "[1] known_good_elementary: verify.py + content_truth חייבים לעבור"
cd "$HERE/known_good_elementary"
python3 verify.py > /dev/null
python3 "$LIB/content_truth.py" --work . --quiet
echo "    PASS"

echo "[2] band regression, שני הכיוונים: אותו content עם band=middle חייב להיכשל על ':'"
python3 - "$LIB" <<'PY'
import json, sys, copy
sys.path.insert(0, sys.argv[1])
import content_truth as ct
doc = json.load(open("content.json"))
assert ct.band_of(doc) in ("elementary", "elementary-ab")
mid = copy.deepcopy(doc); mid.setdefault("meta", {})["band"] = "middle"
qs = ct.find_questions(mid); fails = ct.Fail()
ct.g42_no_colon_division(qs, fails, band="middle")
assert fails, "middle band did not fail on ':' — regression broken!"
fails2 = ct.Fail()
ct.g42_no_colon_division(ct.find_questions(doc), fails2, band=ct.band_of(doc))
assert not fails2, f"elementary band failed unexpectedly: {fails2}"
print("    PASS (elementary legal, middle blocks)")
PY

echo "[3] gates_runner --selftest של שערי הפלט"
python3 "$LIB/check_pdf_output.py" --selftest > /dev/null && echo "    G43 selftest PASS"
python3 "$LIB/check_render_integrity.py" --selftest > /dev/null 2>&1 && echo "    G45/G46 selftest PASS" || echo "    G45/G46 selftest skipped (pymupdf?)"
echo "[4] v2.1 — svg_elementary_ext: כל רכיב מחזיר SVG תקין ברוחב <= 650px"
python3 - "$HERE/.." <<'PY2'
import sys, re
sys.path.insert(0, sys.argv[1])
import svg_elementary_ext as sx
cases = {
 "column_shown":   sx.column_shown(158, 126, 274),
 "column_missing": sx.column_missing(2438, 1352, 3790, hide=2),
 "blank_column":   sx.blank_column(cols=4, bottom=3157),
 "column_borrow":  sx.column_borrow(452, 137, answer=True),
 "bar_model":      sx.bar_model([[(4,"4","known")],[(4,"4","known"),(2,"?","unknown")]], brace=(1,"6")),
 "split_array":    sx.split_array(7, 6, 5),
 "group_model":    sx.group_model(6, 5),
 "unequal_shape":  sx.unequal_shape([3,1,1,1], shaded=[1]),
 "frac_line":      sx.frac_line(4, labels=[1,2,3]),
}
for n, s in cases.items():
    assert s.startswith("<svg"), n
    w = float(re.search(r'width="([\d.]+)"', s).group(1))
    assert w <= 650, (n, w)
# מצב הפריטה חייב להתאים לחשבון, כולל שרשרת אפסים
for t, b in [(452,137), (405,138), (600,247), (3004,1567)]:
    work, _ = sx.borrow_state(t, b)
    db = [int(c) for c in str(b).rjust(len(str(t)), "0")]
    assert t - b == int("".join(str(x-y) for x, y in zip(work, db))), (t, b)
assert sx.n_borrow_ops(600, 247) == 1 and sx.n_borrow_ops(769, 426) == 0
print("    PASS (9 רכיבים, borrow_state מאומת מול חשבון)")
PY2

echo "[5] v2.1 — house_gates selftest"
python3 "$LIB/house_gates.py" --selftest > /dev/null && echo "    PASS"

echo "[6] v2.1 — ws_html: keyed ממתג אותיות, frac מדורג, אין a/b"
python3 - "$HERE/.." <<'PY3'
import sys
sys.path.insert(0, sys.argv[1])
import ws_html as H
k = H.keyed(["557", "687", "787"])
assert k.startswith("\u05d0. ") and "\u05d1." in k and "\u05d2." in k, k
f = H.frac(1, 4)
import re as _re
assert "fnum" in f and "fden" in f
assert not _re.search(r"\\d\\s*/\\s*\\d", H.plain(f)), "שבר בשורה a/b"
assert "<b>\u05d0.</b>" in H.lettered_items(["x", "y"])
try:
    H.figrow(["<svg width=\"400\"/>", "<svg width=\"400\"/>"]); raise SystemExit("figrow לא חסם 800px")
except ValueError:
    pass
print("    PASS")
PY3

echo "[7] v2.2 — signs: תקן הסימנים (G54–G59) + כיסוי גליפים ב-David Libre"
python3 "$LIB/signs.py" --selftest > /dev/null && echo "    signs selftest PASS"
python3 - "$LIB" "$HERE/../.." <<'PY3'
import sys
sys.path.insert(0, sys.argv[1]); sys.path.insert(0, sys.argv[1] + "/..")
import signs as S, svg_elementary as se, ws_html as H
# הגליף נקבע מהכיתה, לא ממי שכתב את השורה
assert "x" in se.vertical_problem(12, 4, op="*", grade="ג")
assert "\u00d7" in se.vertical_problem(12, 4, op="*", grade="ב")
for bad in ("\u00b7", "*", "X", "\u2219"):
    try:
        se.vertical_problem(12, 4, op=bad); raise SystemExit(f"{bad!r} לא נחסם")
    except ValueError:
        pass
assert H.expr(20, "/", 5, "ב") == "20 : 5 ="
assert H.mul_grid([2], [3], grade="\u05d1").count("\u00d7") == 1
try:
    H.frac(1, 4, grade="\u05d1"); raise SystemExit("שבר מדורג בב׳ לא נחסם")
except ValueError:
    pass
# הפונט המצורף עדיין מכיל את כל סימני החובה
try:
    import glob
    ttf = glob.glob(sys.argv[2] + "/assets/DavidLibre-Regular.ttf")
    if ttf:
        ok, msg = S.verify_font_coverage(ttf[0])
        assert ok, msg
        print("    font coverage PASS —", msg[:60])
except ImportError:
    print("    font coverage skipped (fonttools)")
print("    PASS (גליף לפי כיתה, ×/x, חסימות)")
PY3

echo "[8] v2.4 — content_quality: G60–G64 ושתי סכמות התוכן"
python3 "$LIB/content_quality.py" --selftest > /dev/null
python3 "$LIB/content_quality.py" "$HERE/known_good_elementary/content.json" \
  --figdir "$HERE/known_good_elementary" > /dev/null
python3 - "$LIB" <<'PY4'
import sys
sys.path.insert(0, sys.argv[1])
import content_quality as C
doc = {"meta": {"band": "elementary", "grade": "ג", "level": "ב"},
       "questions": [{"n": "1", "intro": "פתרו", "items":
                      [f"{i} x 3 = ___" for i in range(1, 9)],
                      "answer": " ; ".join(str(i * 3) for i in range(1, 9))}]}
recs = C.normalize(doc)
assert len(recs) == 8 and all(" x 3" in r["stem"] for r in recs)
assert C.g62_cloned_items(recs, C.profile_of(doc))[0] == C.FAIL
svg = '<svg viewBox="0 0 100 100"><g transform="translate(90 0)"><rect width="20" height="20" x="0" y="10"/></g></svg>'
assert C.g63_figure_geometry({"moved.svg": svg})[0] == C.FAIL
def signs(text, mode="elementary"):
    src = '<svg viewBox="0 0 100 100"><text x="10" y="20">%s</text></svg>' % text
    return C.g64_svg_signs({"s.svg": src}, colon_mode=mode, grade="ג")[0]
assert signs("25 : 5") == C.PASS and signs("25:5") == C.FAIL
assert signs("⅕") == C.FAIL and signs("3 x -2") == C.FAIL
print("    PASS")
PY4

echo "[9] סיבוב במרחב המודל — 12 זוויות + איסור סיבוב רכיבים פונקציונליים"
PYTHONDONTWRITEBYTECODE=1 python3 "$HERE/test_rotation.py"

echo "[10] v2.4.1 — G65: מצייני מקום בתשובות בלבד, שתי סכמות ומסלולי שערים"
PYTHONDONTWRITEBYTECODE=1 python3 "$HERE/test_final_answer_placeholders.py"

echo "[11] v3.0-noam — G66-chronology, G67-hints, G68-docx & build_docx.py"
python3 - "$LIB" "$HERE/.." <<'PY5'
import sys, os, json, tempfile, zipfile
sys.path.insert(0, sys.argv[1])
sys.path.insert(0, sys.argv[2])
import content_quality as C
import house_gates as HG
import build_docx as BD
import svg_elementary as se
import svg_elementary_ext as sx

# 1. G66-chronology: חסימת מושג חט"ב (מספרים שליליים) ומושג מכיתה מתקדמת (אחוזים בכיתה ג')
bad_chron = {
    "meta": {"band": "elementary", "grade": "ג", "topic_id": "ג01"},
    "questions": [
        {"n": "1", "intro": "חשבו אחוזים של המוצר", "items": ["50% מתוך 200"], "answer": "100"}
    ]
}
st, msg = C.g66_chronology(C.normalize(bad_chron), bad_chron)
assert st == C.FAIL and "אחוז" in msg, f"G66 did not block percent in grade ג: {msg}"

good_chron = {
    "meta": {"band": "elementary", "grade": "ג", "topic_id": "ג01"},
    "questions": [
        {"n": "1", "intro": "פתרו", "items": ["240 + 130 = ___"], "answer": "370"}
    ]
}
st_ok, msg_ok = C.g66_chronology(C.normalize(good_chron), good_chron)
assert st_ok == C.PASS, f"G66 failed valid grade ג content: {msg_ok}"

# 2. G67-hints: חסימת שרטוט ברמז בדף לא-גיאומטרי וחסימת ספוילר
bad_hints = {
    "meta": {"band": "elementary", "grade": "ד", "topic_id": "ד01"},
    "questions": [
        {
            "n": "1",
            "intro": "פתרו",
            "items": ["125 + 375 = ___"],
            "answer": "500",
            "hints": [
                "חברו קודם אחדות ואז עשרות <svg width='50' height='50'></svg>",
                "סדרו במאונך",
                "התשובה היא 500"
            ]
        }
    ]
}
st_h, msg_h = C.g67_hints(bad_hints, C.normalize(bad_hints))
assert st_h == C.FAIL and "שרטוט" in msg_h and "500" in msg_h, f"G67 did not catch non-geo SVG or spoiler: {msg_h}"

# 3. build_docx.py: המרת תרגילי מאונך מ-SVG לטבלת Word ניתנת לעריכה + G68-docx
vp_svg = se.vertical_problem(347, 285, op="+", grade="ג", headers=("יחידות", "עשרות", "מאות"))
parsed = BD._try_parse_vertical_math_svg(vp_svg)
assert parsed is not None, "vertical_problem SVG was not parsed as vertical math table"
hdr_texts = [c["text"] for c in parsed["rows"][0] if c]
assert hdr_texts == ["מאות", "עשרות", "יחידות"], f"Unexpected headers: {hdr_texts}"

cb_svg = sx.column_borrow(452, 137, answer=True)
parsed_cb = BD._try_parse_vertical_math_svg(cb_svg)
assert parsed_cb is not None and any(c and c["strike"] for r in parsed_cb["rows"] for c in r), "column_borrow SVG was not parsed with strike"

with tempfile.TemporaryDirectory() as tmpd:
    out_docx = os.path.join(tmpd, "test_out.docx")
    e2e_html = os.path.join(sys.argv[2], "..", "e2e_demo", "sheet.html")
    BD.build_docx_from_html(e2e_html, out_docx)
    ok_v, msg_v = BD.verify_docx(out_docx)
    assert ok_v, msg_v
    ok_g68, msg_g68 = HG.g68_docx(out_docx)
    assert ok_g68, msg_g68

print("    PASS (G66-chronology, G67-hints, G68-docx, editable vertical tables)")
PY5

echo "[12] v3.1-noam — 13 איורים דידקטיים, 11 סוגי object_groups ו-8 תבניות פעילויות"
python3 - "$LIB" "$HERE/.." <<'PY6'
import sys, os, re, tempfile
sys.path.insert(0, sys.argv[1])
sys.path.insert(0, sys.argv[2])
import content_quality as C
import svg_elementary as se
import svg_elementary_ext as sx
import ws_html as H
import build_docx as BD

# 1. כל 11 סוגי object_groups
for k in ("apple", "balloon", "star", "fish", "heart", "flower", "marble", "cookie", "pencil", "book", "car"):
    svg_k = se.object_groups(k, [3, 4])
    assert svg_k.startswith("<svg"), k
    w = float(re.search(r'width="([\d.]+)"', svg_k).group(1))
    assert w <= 650, (k, w)

# 2. כל 21 האיורים הדידקטיים החדשים ב-svg_elementary_ext
new_svgs = {
    "part_whole_tree.svg": sx.part_whole_diagram(whole=15, parts=(9, ""), mode="tree"),
    "part_whole_house.svg": sx.part_whole_diagram(whole=10, mode="house", floors=[(7, ""), ("", 4), (5, 5)]),
    "number_line_jumps.svg": sx.number_line_jumps(34, [10, 10, 5], step=5, hide_landings=(54,)),
    "balance_scale.svg": sx.balance_scale("8 + 5", "10 + ?", tilt=0),
    "abacus.svg": sx.abacus([2, 0, 4, 5], blank_boxes=True),
    "area_grid_shape.svg": sx.area_grid_shape([[1, 1, 1], [1, 0, 0]], cell=24),
    "multiplication_area_model.svg": sx.multiplication_area_model([10, 4], [20, 3], hide_cells=((1, 1),)),
    "fraction_strip_wall.svg": sx.fraction_strip_wall([(1, 1), (2, 1), (4, 2), (8, 4)]),
    "decimal_hundred_square.svg": sx.decimal_hundred_square(34, mode="hundredths"),
    "thermometer_vertical.svg": sx.thermometer_vertical(min_v=-10, max_v=30, step=5, current=15, box_at=-5),
    "measuring_cup.svg": sx.measuring_cup(capacity_ml=1000, step_ml=100, filled_ml=600),
    "polyhedron_3d.svg": sx.polyhedron_3d("box", dims=(5, 3, 4), show_hidden=True),
    "matchstick_pattern.svg": sx.matchstick_pattern(terms=(1, 2, 3), shape="squares"),
    "symmetry_grid.svg": sx.symmetry_grid([(1, 2), (2, 1), (2, 2), (3, 2)], rows=5, cols_half=4, axis="vertical"),
    "number_web.svg": sx.number_web(6, branches=("4 + 2", "10 \u2212 4", "", "")),
    "bead_string.svg": sx.bead_string(total=10, group_size=5, circled=(4, 8)),
    "subtraction_crossed_items.svg": sx.subtraction_crossed_items("cookie", total=8, crossed=3),
    "factor_tree.svg": sx.factor_tree(24, pair_l1=(4, 6), leaves_l2=(2, 2, 2, 3)),
    "unit_cube_structure.svg": sx.unit_cube_structure([[2, 2, 1], [1, 1, 0]]),
    "triangle_with_height.svg": sx.triangle_with_height(kind="obtuse", base_label=6, height_label=4),
    "dice_pair.svg": sx.dice_pair(4, 5),
    "spinner_wheel.svg": sx.spinner_wheel(sectors=8, shaded=(0, 2, 4, 6), dots=(1, 5)),
}
for name, svg_str in new_svgs.items():
    assert svg_str.startswith("<svg"), name
    w = float(re.search(r'width="([\d.]+)"', svg_str).group(1))
    assert w <= 650, (name, w)

st_g63, msg_g63 = C.g63_figure_geometry(new_svgs)
assert st_g63 == C.PASS, f"G63 failed on new SVGs: {msg_g63}"
st_g64, msg_g64 = C.g64_svg_signs(new_svgs, colon_mode="elementary", grade="ד")
assert st_g64 == C.PASS, f"G64 failed on new SVGs: {msg_g64}"

# 3. כל 8 בוני הפעילויות ב-ws_html.py + המרה ל-DOCX
act_htmls = [
    H.number_cards([3, 7, 0, 5], grade="ג"),
    H.hundred_window(45, shape="cross"),
    H.sorting_baskets(["קטן מ-100", "שווה ל-100", "גדול מ-100"], ["45 + 48", "60 + 40", "75 + 35"]),
    H.who_am_i_riddle(["אני מספר תלת-ספרתי זוגי.", "ספרת המאות שלי היא 4.", "סכום ספרותיי הוא 10."]),
    H.error_detection_box("נועה", H.fig(sx.column_shown(348, 275, 513, op="+"))),
    H.function_table([2, 5, 8, ""], [6, 15, "", 30]),
    H.price_list_banner([("מחברת", 8), ("קלמר", 25), ("טושים", 14)], grade="ג"),
    H.magic_square_html([[8, "", 6], [3, 5, ""], ["", 9, 2]], target_sum=15),
]
for h_part in act_htmls:
    assert len(h_part) > 30

print("    PASS (13 איורים דידקטיים, 11 סוגי עצמים ו-8 תבניות פעילויות)")
PY6

echo "[13] DOCX: explicit source selection and supported hints"
PYTHONDONTWRITEBYTECODE=1 python3 "$HERE/test_docx_sources.py"

echo "[14] G69: no drawings outside geometry"
PYTHONDONTWRITEBYTECODE=1 python3 "$HERE/test_drawing_policy.py"

echo "[15] DOCX RTL defaults, final normalization and LTR mathematics"
PYTHONDONTWRITEBYTECODE=1 python3 "$HERE/test_docx_rtl.py"

echo "[16] PDF engine failure preserves Chromium fallback"
PYTHONDONTWRITEBYTECODE=1 python3 "$HERE/test_pdf_fallback.py"

echo "[17] Worksheet checker CLI and template marker contract"
PYTHONDONTWRITEBYTECODE=1 python3 "$HERE/test_worksheet_checker.py"

echo "[18] RTL section order and mixed Hebrew answer isolation"
PYTHONDONTWRITEBYTECODE=1 python3 "$HERE/test_worksheet_direction.py"

echo "[19] Answer prose RTL, numeric units and bounded G70 lint"
PYTHONDONTWRITEBYTECODE=1 python3 "$HERE/test_answer_layout.py"

echo "[20] DOCX explicit answer preview and narrow LTR number labels"
PYTHONDONTWRITEBYTECODE=1 python3 "$HERE/test_docx_answer_preview.py"

echo "ALL REGRESSION TESTS PASS"
