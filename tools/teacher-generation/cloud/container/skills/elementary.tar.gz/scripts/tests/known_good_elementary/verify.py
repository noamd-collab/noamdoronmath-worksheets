# -*- coding: utf-8 -*-
"""Reference verify.py for the ELEMENTARY band (כיתה ג׳): every printed answer
is produced by an arithmetic helper and recorded — same Ledger discipline as
the middle-school band, with elementary helpers (div_qr, cmp_sign, seq_fill,
neighbors)."""
import os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "..", "lib"))
from content_truth import (Ledger, add_col, sub_col, mul_col, div_qr,
                           cmp_sign, seq_fill, neighbors, frac)

L = Ledger(os.path.join(HERE, "verified.json"))

# Q1 — drill line: כל תוצאה מחושבת בקוד
L.claim("1", "6 x 4 ; 25 : 5 ; 40 : 10",
        (mul_col(6, 4) == 24 and div_qr(25, 5) == (5, 0) and div_qr(40, 10) == (4, 0),
         [mul_col(6, 4), div_qr(25, 5), div_qr(40, 10)]), method="closed_form")

# Q2 — השוואות: הסימן מופק מ-cmp_sign, לא מהראש
L.claim("2", "סימני ההשוואה הנכונים",
        (cmp_sign(mul_col(6, 4), mul_col(4, 6)) == "="
         and cmp_sign(div_qr(25, 5)[0], div_qr(36, 6)[0]) == "<",
         [cmp_sign(24, 24), cmp_sign(5, 6)]), method="closed_form")

# Q3 — סדרה בקפיצות 10
L.claim("3", "השלמת הסדרה", (seq_fill(30, 10, 6) == [30, 40, 50, 60, 70, 80],
        seq_fill(30, 10, 6)), method="enumeration")

# Q4 — חילוק עם שארית
q, r = div_qr(23, 5)
L.claim("4", "23 בין 5 חברים", (q == 4 and r == 3, (q, r)), method="closed_form")

# Q5 — שכנים בעשרות
L.claim("5", "השכנים של 843 בעשרות", (neighbors(843, 10) == (840, 850),
        neighbors(843, 10)), method="closed_form")

print("verify.py: all claims hold ->", L.save())
