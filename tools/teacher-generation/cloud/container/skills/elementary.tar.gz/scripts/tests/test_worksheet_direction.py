#!/usr/bin/env python3
"""Keep Hebrew subsection order consistent in HTML, PDF and Word.

The historical demo runs in an isolated temporary copy. The optional layout
test needs WeasyPrint and PyMuPDF. Direct execution on macOS restarts Python
once when Homebrew's library path must be set before the process starts.
"""
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import unittest

from bs4 import BeautifulSoup
import docx
from docx.oxml.ns import qn

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "scripts"))
import build_docx as BD
import svg_elementary as SE
import ws_html as H


class WorksheetDirectionTests(unittest.TestCase):
    def test_row_and_word_table_start_with_same_rightmost_subsection(self):
        # Technical regression fixture for the legacy editable-column exporter.
        operands = [(587, 243), (769, 426), (685, 152)]
        svgs = [SE.vertical_problem(a, b, op="−", answer="blank", cell=30)
                for a, b in operands]
        row = BeautifulSoup(H.figrow(svgs), "html.parser").find(class_="figure")
        self.assertEqual(row["dir"], "rtl")
        parts = row.find_all("span", recursive=False)
        self.assertEqual([part.div.get_text() for part in parts], ["א.", "ב.", "ג."])
        self.assertEqual([part["dir"] for part in parts], ["ltr"] * 3)
        self.assertEqual([part.div["dir"] for part in parts], ["rtl"] * 3)
        # Changing the row direction must not change any SVG's numeric content.
        self.assertEqual([str(part.svg) for part in parts],
                         [str(BeautifulSoup(svg, "html.parser").svg) for svg in svgs])
        document = docx.Document()
        BD.add_figure_block(document, row)
        outer = document.tables[0]
        self.assertEqual(outer._tbl.tblPr.find(qn("w:bidiVisual")).get(qn("w:val")), "1")
        self.assertEqual([cell.paragraphs[0].text for cell in outer.rows[0].cells],
                         ["א.", "ב.", "ג."])
        for cell in outer.rows[0].cells:
            self.assertEqual(cell.tables[0]._tbl.tblPr.find(qn("w:bidiVisual")).get(qn("w:val")), "0")

    def test_unlettered_row_preserves_input_and_ltr_figures(self):
        svgs = ['<svg width="30" height="10"><text>123</text></svg>',
                '<svg width="30" height="10"><text>456</text></svg>']
        row = BeautifulSoup(H.figrow(svgs, letters=False), "html.parser").div
        self.assertEqual(row["dir"], "rtl")
        parts = row.find_all("span", recursive=False)
        self.assertEqual([p.get_text() for p in parts], ["123", "456"])
        self.assertTrue(all(p["dir"] == "ltr" and p.find("div") is None for p in parts))
        with self.assertRaises(ValueError):
            H.figrow(['<svg width="400"/>'] * 2)

    def test_regenerated_demo_explains_borrowing_without_hebrew_inside_ltr(self):
        with tempfile.TemporaryDirectory() as tmp:
            scratch = Path(tmp)
            demo = scratch / "e2e_demo"
            demo.mkdir()
            shutil.copy(ROOT / "e2e_demo" / "demo.py", demo / "demo.py")
            shutil.copytree(ROOT / "scripts", scratch / "scripts",
                            ignore=shutil.ignore_patterns("__pycache__", "tests"))
            shutil.copytree(ROOT / "assets", scratch / "assets")
            subprocess.run([sys.executable, str(demo / "demo.py")],
                           check=True, capture_output=True, text=True)
            page = BeautifulSoup((demo / "sheet.html").read_text(encoding="utf-8"), "html.parser")
            answer = page.select_one("table.ans tr").find_all("td")[1]
            self.assertEqual([span.get_text() for span in answer.select("span.ltr")],
                             ["5", "4", "2", "12"])
            self.assertTrue(all(not re.search(r"[א-ת]", span.get_text())
                                for span in page.select(".answers span.ltr")))
            content = json.loads((demo / "content.json").read_text(encoding="utf-8"))
            self.assertEqual(content["questions"][0]["answer"],
                             "פורטים עשרת אחת מתוך 5 העשרות: נשארות 4 עשרות, ו־ 2 האחדות הופכות ל־ 12 אחדות.")
            self.assertEqual(content["questions"][2]["answer"], "א. 344 ; ב. 343 ; ג. 533")

    @unittest.skipUnless(importlib.util.find_spec("weasyprint") and importlib.util.find_spec("fitz"),
                         "PDF layout regression requires WeasyPrint and PyMuPDF")
    def test_rendered_geometry_subsections_run_right_to_left_and_digits_stay_ltr(self):
        from weasyprint import HTML
        import fitz
        # A geometric figure with a numeric side label; no arithmetic drawings.
        svgs = [f'<svg xmlns="http://www.w3.org/2000/svg" width="120" height="50">'
                f'<rect x="10" y="20" width="80" height="25" fill="none" stroke="black"/>'
                f'<text x="10" y="15">{number}</text></svg>'
                for number in (123, 456, 789)]
        page = '<html dir="rtl"><body>' + H.figrow(svgs) + '</body></html>'
        document = HTML(string=page).render()
        boxes = [box for box in document.pages[0]._page_box.descendants()
                 if type(box).__name__ == "InlineBlockBox" and box.element_tag == "span"]
        self.assertEqual(len(boxes), 3)
        self.assertGreater(boxes[0].position_x, boxes[1].position_x)
        self.assertGreater(boxes[1].position_x, boxes[2].position_x)
        self.assertEqual([box.style["direction"] for box in boxes], ["ltr"] * 3)
        with fitz.open(stream=document.write_pdf(), filetype="pdf") as pdf:
            words = {word[4]: word for word in pdf[0].get_text("words")}
            self.assertTrue(all(number in words for number in ("123", "456", "789")))
            self.assertGreater(words["123"][0], words["456"][0])
            self.assertGreater(words["456"][0], words["789"][0])


if __name__ == "__main__":
    # macOS SIP can strip DYLD_* while run_tests.sh starts through /bin/bash.
    # Restore the path in a direct Python child, before cffi loads Pango. An
    # installed but unusable renderer still fails the test; this is not a skip.
    brew_lib = "/opt/homebrew/lib"
    reexec_flag = "WORKSHEET_DIRECTION_DYLD_REEXEC"
    if (sys.platform == "darwin" and Path(brew_lib).is_dir()
            and importlib.util.find_spec("weasyprint")
            and brew_lib not in os.environ.get("DYLD_FALLBACK_LIBRARY_PATH", "").split(os.pathsep)
            and os.environ.get(reexec_flag) != "1"):
        env = dict(os.environ)
        env["DYLD_FALLBACK_LIBRARY_PATH"] = os.pathsep.join(
            value for value in (brew_lib, env.get("DYLD_FALLBACK_LIBRARY_PATH", "")) if value)
        env[reexec_flag] = "1"
        raise SystemExit(subprocess.run([sys.executable, str(Path(__file__).resolve()),
                                         *sys.argv[1:]], env=env).returncode)
    unittest.main()
