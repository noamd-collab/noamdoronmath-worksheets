#!/usr/bin/env python3
"""Focused G65 regression checks; no PDF generation or production content."""
import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))
import content_quality as cq
import house_gates as hg


def content(answer, **question):
    return {"meta": {"band": "elementary", "grade": "ג", "level": "ב"},
            "questions": [{"n": "1", "text": "חשבו", "answer": answer,
                           **question}]}


def check(doc):
    return cq.g65_final_answer_placeholders(cq.normalize(doc))[0]


class FinalAnswerPlaceholderTests(unittest.TestCase):
    def test_exact_placeholders_with_optional_punctuation_and_niqqud(self):
        for answer in ("נימוק", "הוכחה", "לפי השרטוט", "ייתכנו תשובות נוספות",
                       "  (נִימוּק).  ", "׳הוֹכָחָה׳!", "לְפִי הַשִּׁרְטוּט…",
                       "יִיתָּכְנוּ תְּשׁוּבוֹת נוֹסָפוֹת."):
            with self.subTest(answer=answer):
                self.assertEqual(check(content(answer)), cq.FAIL)

    def test_complete_answers_may_contain_placeholder_words(self):
        for answer in ("24", "נימוק: 5 עשרות הן 50 יחידות.",
                       "הוכחה: סכום שני מספרים זוגיים מתחלק ב־2.",
                       "לפי השרטוט, אורך הקטע 4 ס״מ.",
                       "דוגמה: 4 ו־6; ייתכנו תשובות נוספות שסכומן 10.",
                       "ייתכנו תשובות נוספות: 2 ו־8, וסכומן חייב להיות 10.",
                       "נימוק ; 5 עשרות ⇐ 4 , 2 אחדות ⇐ 12"):
            with self.subTest(answer=answer):
                self.assertEqual(check(content(answer)), cq.PASS)

    def test_question_instruction_and_solution_text_never_scanned(self):
        doc = content("24", text="נימוק", intro="הוכחה",
                      instructions="לפי השרטוט", solution="ייתכנו תשובות נוספות",
                      items=["נימוק", "הוכחה", "לפי השרטוט", "ייתכנו תשובות נוספות"])
        doc["answer_instructions"] = "הוכחה"
        self.assertEqual(check(doc), cq.PASS)

    def test_current_string_items_and_answer_list_are_supported_without_mutation(self):
        for answer in ("24 ; נימוק", ["24", "נימוק"]):
            doc = content(answer, items=["6 x 4 = ___", "הסבירו"])
            before = copy.deepcopy(doc)
            self.assertEqual(check(doc), cq.FAIL)
            self.assertEqual(doc, before)

    def test_existing_separate_answer_table_is_supported(self):
        doc = content(None, items=[["א", "חשבו", 1], ["ב", "הסבירו", 1]])
        doc["answers"] = [["1", [["א", "24"], ["ב", "לפי השרטוט"]]]]
        self.assertEqual(check(doc), cq.FAIL)
        doc["answers"][0][1][1][1] = "אורך הקטע 4 ס״מ לפי השרטוט."
        self.assertEqual(check(doc), cq.PASS)

    def test_both_gate_entry_points_block(self):
        doc = content("נימוק")
        rows = cq.run_content_gates(cq.normalize(doc), content=doc,
                                    strict=False, verbose=False)
        self.assertIn(("G65-answer-placeholders", cq.FAIL),
                      [(name, status) for name, status, _ in rows])
        with self.assertRaises(SystemExit):
            cq.run_content_gates(cq.normalize(doc), content=doc, verbose=False)
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "content.json"
            path.write_text(json.dumps(doc, ensure_ascii=False), encoding="utf8")
            rows = hg.g6x_content(str(path))
        self.assertIn(("G65-answer-placeholders", False),
                      [(name, status) for name, status, _ in rows])

    def test_existing_known_good_fixture(self):
        path = Path(__file__).parent / "known_good_elementary" / "content.json"
        doc = json.loads(path.read_text(encoding="utf8"))
        self.assertEqual(check(doc), cq.PASS)


if __name__ == "__main__":
    unittest.main()
