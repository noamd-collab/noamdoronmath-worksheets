#!/usr/bin/env python3
"""G69 behavior: geometry only, across JSON, HTML and both public runners."""
import contextlib
import copy
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

SCRIPTS = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SCRIPTS / "lib"))
import content_quality as cq
import house_gates as hg

SVG = ('<svg viewBox="0 0 100 100"><rect x="10" y="10" '
       'width="40" height="40"/></svg>')


def source(**meta):
    return {"meta": {"band": "elementary", "grade": "ג", "level": "ב",
                     "domain": "operations", **meta},
            "questions": [{"n": "1", "text": "24 + 15 = ___", "answer": "39"}]}


def status(rows, name="G69-drawings"):
    return next(result for gate, result, _ in rows if gate == name)


class DrawingPolicyTests(unittest.TestCase):
    def test_body_and_nested_drawings_fail_without_any_hints(self):
        for key, value in (("fig", "missing.svg"), ("image", "asset-without-extension"),
                           ("figures", [{"src": "diagram.png"}]), ("svg", SVG),
                           ("hint_fig", "orphan.svg"), ("hint_svg", SVG)):
            with self.subTest(key=key):
                doc = source()
                doc["questions"][0][key] = value
                self.assertEqual(cq.g69_drawings(doc)[0], cq.FAIL)
        doc = source()
        doc["questions"][0]["parts"] = [{"hints": [{"image": "opaque-id"}]}]
        self.assertEqual(cq.g69_drawings(doc)[0], cq.FAIL)

    def test_recognizable_markup_and_image_references_fail(self):
        for markup in (SVG, '<img src="/asset/42">', '<canvas id="plot"></canvas>',
                       '<object data="figure.pdf"></object>', '![רמז](asset)',
                       'figure.webp', '<div style="background-image:url(/asset)"></div>'):
            with self.subTest(markup=markup):
                self.assertEqual(cq.g69_drawings(source(), html=markup)[0], cq.FAIL)
                doc = source()
                doc["questions"][0]["text"] = markup
                self.assertEqual(cq.g69_drawings(doc)[0], cq.FAIL)

    def test_text_and_editable_tables_remain_legal(self):
        html = ('<table style="border:1px solid #111"><tr><td>24</td></tr>'
                '<tr><td>+ 15</td></tr></table>')
        doc = source()
        doc["questions"][0].update(fig="", figures=[], text=html)
        before = copy.deepcopy(doc)
        self.assertEqual(cq.g69_drawings(doc, html=html)[0], cq.PASS)
        self.assertEqual(doc, before)

    def test_valid_geometry_declarations_allow_figures(self):
        for meta in ({"domain": "geometry"}, {"domain": "גיאומטריה"},
                     {"domain": "", "topic_id": "ג16"},
                     {"domain": "measurement", "topic_id": "ג15"},
                     {"domain": "", "topic": "מיון משולשים"}):
            with self.subTest(meta=meta):
                self.assertEqual(cq.g69_drawings(source(**meta), figs={"g.svg": SVG})[0], cq.PASS)

    def test_non_geometry_or_conflicting_topic_cannot_borrow_keywords(self):
        for meta in ({"domain": "operations", "topic": "שטח"},
                     {"domain": "", "topic": "כפל וחילוק בשברים — מודל שטח"},
                     {"domain": "geometry", "topic_id": "ו02", "grade": "ו"},
                     {"domain": "", "topic_id": "ו02", "grade": "ו"},
                     {"domain": "geometry", "topic_id": "ג99"},
                     {"domain": "geometry", "topic_id": "ג16", "grade": "ד"},
                     {"domain": "operations", "topic_id": "ג16"}):
            with self.subTest(meta=meta):
                self.assertEqual(cq.g69_drawings(source(**meta), figs={"g.svg": SVG})[0], cq.FAIL)

    def test_external_figure_inputs_fail_even_without_json_references(self):
        doc = source()
        rows = cq.run_content_gates(cq.normalize(doc), content=doc,
                                    figs={"unreferenced.svg": SVG}, strict=False, verbose=False)
        self.assertEqual(status(rows), cq.FAIL)
        with self.assertRaises(SystemExit):
            cq.run_content_gates(cq.normalize(doc), content=doc,
                                 figs={"unreferenced.svg": SVG}, verbose=False)

    def test_body_and_orphan_hint_block_both_content_entry_points(self):
        for key in ("fig", "hint_fig"):
            doc = source()
            doc["questions"][0][key] = "missing.svg"
            rows = cq.run_content_gates(cq.normalize(doc), content=doc,
                                        strict=False, verbose=False)
            self.assertEqual(status(rows), cq.FAIL)
            with tempfile.TemporaryDirectory() as temp:
                path = Path(temp) / "content.json"
                path.write_text(json.dumps(doc, ensure_ascii=False), encoding="utf8")
                self.assertFalse(status(hg.g6x_content(str(path))))

    def test_html_only_drawing_blocks_house_public_runner(self):
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            path, html = base / "content.json", base / "sheet.html"
            path.write_text(json.dumps(source(), ensure_ascii=False), encoding="utf8")
            html.write_text('<li class="starred">1</li>' * 2 + '<img src="/asset/42">', encoding="utf8")
            self.assertFalse(status(hg.g6x_content(str(path), html_path=str(html))))
            output = io.StringIO()
            with contextlib.redirect_stdout(output):
                code = hg.run(html=str(html), content=str(path), grade="ג")
            self.assertEqual(code, 1)
            self.assertIn("FAIL — G69-drawings", output.getvalue())

    def test_source_cli_blocks_and_geometry_cli_passes(self):
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            figs = base / "figures"
            figs.mkdir()
            (figs / "g.svg").write_text(SVG, encoding="utf8")
            path = base / "content.json"
            for domain, expected in (("operations", 1), ("geometry", 0)):
                doc = source(domain=domain)
                doc["questions"][0]["fig"] = "g.svg"
                path.write_text(json.dumps(doc, ensure_ascii=False), encoding="utf8")
                proc = subprocess.run([sys.executable, str(SCRIPTS / "lib/content_quality.py"),
                                       str(path)], text=True, capture_output=True)
                self.assertEqual(proc.returncode, expected, proc.stdout + proc.stderr)
                self.assertIn("G69-drawings", proc.stdout)

    def test_geometry_runs_all_gates_with_drawings(self):
        doc = source(domain="geometry", topic_id="ג16")
        doc["questions"][0]["fig"] = SVG
        rows = cq.run_content_gates(cq.normalize(doc), content=doc,
                                    figs={"g.svg": SVG}, strict=False, verbose=False)
        self.assertEqual(status(rows), cq.PASS)
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "content.json"
            path.write_text(json.dumps(doc, ensure_ascii=False), encoding="utf8")
            self.assertTrue(status(hg.g6x_content(str(path))))

    def test_three_text_hints_allow_no_comparison_symbols(self):
        doc = source()
        doc["questions"][0]["hints"] = ["חשבו על מבנה המספר.", "חברו את העשרות.", "הוסיפו את היחידות."]
        self.assertEqual(cq.g67_hints(doc)[0], cq.PASS)
        for symbol in "<>=":
            doc["questions"][0]["hints"][2] = "בדקו 2 %s 3" % symbol
            self.assertEqual(cq.g67_hints(doc)[0], cq.FAIL)

    def test_geometry_hint_html_and_svg_syntax_is_not_comparison(self):
        svg = '<svg viewBox="0 0 100 100"><text x="10" y="20">AB</text></svg>'
        doc = source(domain="geometry")
        doc["questions"][0]["hints"] = [
            '<span class="step">התבוננו בצורה.</span>',
            {"text": "זהו את הצלעות.", "svg": svg}, svg]
        doc["questions"][0]["hint_svg"] = svg
        self.assertEqual(cq.g67_hints(doc)[0], cq.PASS)
        self.assertEqual(cq.g69_drawings(doc)[0], cq.PASS)
        doc["meta"]["domain"] = "operations"
        self.assertEqual(cq.g69_drawings(doc)[0], cq.FAIL)

    def test_visible_comparisons_in_html_entities_and_svg_labels_block(self):
        for text in ("2 < 3", "2 > 3", "2 = 3", '<b>2 &lt; 3</b>',
                     '<b>2 &#62; 3</b>', '<span>2 &#61; 3</span>',
                     '<svg viewBox="0 0 100 100"><text x="10" y="20">2 &lt; 3</text></svg>'):
            with self.subTest(text=text):
                doc = source(domain="geometry")
                doc["questions"][0]["hints"] = ["התבוננו בצורה.", "זהו את הצלעות.", text]
                self.assertEqual(cq.g67_hints(doc)[0], cq.FAIL)

    def test_comparison_in_separate_inline_svg_field_blocks(self):
        svg = '<svg viewBox="0 0 100 100"><text x="10" y="20">AB = CD</text></svg>'
        for location in ("hint_dictionary", "question_attachment", "top_level"):
            with self.subTest(location=location):
                doc = source(domain="geometry")
                hints = ["התבוננו בצורה.", "זהו את הצלעות.", "המשיכו להשוואה."]
                doc["questions"][0]["hints"] = hints
                if location == "hint_dictionary":
                    hints[2] = {"text": hints[2], "svg": svg}
                elif location == "question_attachment":
                    doc["questions"][0]["hint_svg"] = svg
                else:
                    doc["hints"] = {"1": {"levels": hints, "svg": svg}}
                self.assertEqual(cq.g67_hints(doc)[0], cq.FAIL)


if __name__ == "__main__":
    unittest.main()
