#!/usr/bin/env python3
"""Runtime entry point and question-marker regressions for the real template."""
import importlib.util
from pathlib import Path
import subprocess
import shutil
import sys
import tempfile
import unittest
from unittest.mock import patch

SCRIPTS = Path(__file__).resolve().parents[1]
CHECKER = SCRIPTS / "check_worksheet.py"
TEMPLATE = SCRIPTS.parent / "assets" / "worksheet_template_elementary.html"
spec = importlib.util.spec_from_file_location("worksheet_checker", CHECKER)
checker = importlib.util.module_from_spec(spec)
spec.loader.exec_module(checker)


class WorksheetCheckerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.pdf = Path(self.temp.name) / "worksheet.pdf"
        self.template = TEMPLATE.read_text(encoding="utf-8")

    def check_html(self, html):
        self.pdf.with_suffix(".html").write_text(html, encoding="utf-8")
        return checker.check_question_marker_direction(self.pdf)

    def test_cli_help_loads_under_the_test_interpreter(self):
        # Compilation alone missed the Python 3.9 int | None runtime failure.
        result = subprocess.run([sys.executable, str(CHECKER), "--help"],
                                capture_output=True, text=True, timeout=30)
        self.assertEqual(result.returncode, 0, result.stderr + result.stdout)
        self.assertIn("check_worksheet.py", result.stdout)
        self.assertIn("--band", result.stdout)
        self.assertNotIn("Traceback", result.stderr)

    def test_actual_template_parentheses_pass(self):
        ok, message = self.check_html(self.template)
        self.assertTrue(ok, message)

    def test_parenthesized_marker_requires_ltr_and_bidi_isolation(self):
        for declaration in ("direction: rtl; unicode-bidi: embed;",
                            "direction: ltr; unicode-bidi: normal;",
                            "unicode-bidi: embed;"):
            with self.subTest(declaration=declaration):
                html = self.template.replace("direction: ltr; unicode-bidi: embed;",
                                             declaration, 1)
                ok, message = self.check_html(html)
                self.assertFalse(ok, message)
                self.assertIn("S-29", message)

    def test_malformed_parentheses_and_wrong_counter_fail(self):
        original = 'content: "(" counter(qnum) ") ";'
        for content in ('content: ")" counter(qnum) "( ";',
                        'content: "(" counter(other) ") ";',
                        'content: "(" counter(qnum) ". ";'):
            with self.subTest(content=content):
                ok, message = self.check_html(self.template.replace(original, content))
                self.assertFalse(ok, message)
                self.assertIn("question marker must use counter(qnum)", message)

    def test_starred_override_cannot_reverse_marker(self):
        html = self.template.replace(
            'ol.questions > li.starred::before { content: "(" counter(qnum) ") "; }',
            'ol.questions > li.starred::before { content: "(" counter(qnum) ") "; direction: rtl; }')
        ok, message = self.check_html(html)
        self.assertFalse(ok, message)
        self.assertIn("starred", message)

    def test_later_base_override_is_checked(self):
        html = self.template.replace('</style>',
            'ol.questions > li::before { direction: rtl; }</style>')
        self.assertFalse(self.check_html(html)[0])

    def test_legacy_period_rule_keeps_its_direction_guard(self):
        html = '''<style>
          ol.questions > li::before {
            content: counter(qnum) ". "; direction: rtl; unicode-bidi: embed;
          }
        </style>'''
        self.assertTrue(self.check_html(html)[0])
        ok, message = self.check_html(html.replace("direction: rtl", "direction: ltr"))
        self.assertFalse(ok, message)
        self.assertIn("S-21", message)

    def test_count_heuristic_recognizes_s29_and_legacy_numbering(self):
        for numbers in ("(1) שאלה (12) שאלה", ")1( שאלה )12( שאלה",
                        "1. שאלה 12. שאלה",
                        "\u202b)\u202a (12\u202cחשבו\u202a:\u202c\u202c",
                        "\u202b)\u202a ★ (15\u202cחשבו\u202a:\u202c\u202c"):
            with self.subTest(numbers=numbers), patch.object(
                    checker, "document_text", return_value=numbers):
                warnings = checker.warn_heuristics(self.pdf, "elementary")
                self.assertFalse(any("max question number found" in w for w in warnings), warnings)
        with patch.object(checker, "document_text", return_value="(1) שאלה (6) שאלה"):
            warnings = checker.warn_heuristics(self.pdf, "elementary")
            self.assertTrue(any("max question number found: 6" in w for w in warnings), warnings)

    @unittest.skipUnless(shutil.which("pdftotext"), "Poppler not on PATH")
    def test_poppler_page_separators_do_not_become_invalid_glyphs(self):
        # A minimal real two-page PDF keeps this regression dependency-free.
        # The original extractor adds U+000C even after the last page.
        objects = [
            b"<< /Type /Catalog /Pages 2 0 R >>",
            b"<< /Type /Pages /Count 2 /Kids [3 0 R 5 0 R] >>",
            b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 200 200] /Resources << /Font << /F1 7 0 R >> >> /Contents 4 0 R >>",
            b"<< /Length 37 >>\nstream\nBT /F1 12 Tf 10 100 Td (first) Tj ET\nendstream",
            b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 200 200] /Resources << /Font << /F1 7 0 R >> >> /Contents 6 0 R >>",
            b"<< /Length 38 >>\nstream\nBT /F1 12 Tf 10 100 Td (second) Tj ET\nendstream",
            b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
        ]
        data, offsets = b"%PDF-1.4\n", [0]
        for index, obj in enumerate(objects, 1):
            offsets.append(len(data))
            data += str(index).encode() + b" 0 obj\n" + obj + b"\nendobj\n"
        xref = len(data)
        data += b"xref\n0 8\n0000000000 65535 f \n"
        data += b"".join(f"{offset:010d} 00000 n \n".encode() for offset in offsets[1:])
        data += f"trailer\n<< /Size 8 /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode()
        self.pdf.write_bytes(data)
        text = checker.document_text(self.pdf)
        self.assertIn("first", text)
        self.assertIn("second", text)
        self.assertNotIn("\f", text)
        self.assertTrue(checker.check_invalid_glyphs(self.pdf)[0])
        second = checker.document_text(self.pdf, first=2, last=2)
        self.assertIn("second", second)
        self.assertNotIn("first", second)

    def test_genuine_invalid_characters_still_fail(self):
        for bad in ("\x00", "\x0c", "\ufffe"):
            with self.subTest(bad=repr(bad)), patch.object(
                    checker, "document_text", return_value="שאלה " + bad):
                ok, message = checker.check_invalid_glyphs(self.pdf)
                self.assertFalse(ok, message)
                self.assertIn(f"U+{ord(bad):04X}", message)

    def test_missing_html_is_explicitly_warned(self):
        ok, message = checker.check_question_marker_direction(self.pdf)
        self.assertTrue(ok)
        self.assertIn("skipped (warn)", message)


if __name__ == "__main__":
    unittest.main()
