#!/usr/bin/env python3
"""All-angle scan for elementary pure geometry and rotation exclusions."""

import inspect
import pathlib
import re
import sys
import xml.etree.ElementTree as ET

HERE = pathlib.Path(__file__).resolve()
SCRIPTS = HERE.parents[1]
LIB = SCRIPTS / "lib"
sys.path[:0] = [str(LIB), str(SCRIPTS)]

import pure_geometry as pg  # noqa: E402
import svg_elementary as se  # noqa: E402
import svg_elementary_ext as sx  # noqa: E402

ANGLES = (0, 17, 35, -28, 62, 90, 143, -115, 180, 210, 300, 355)


def _number(value):
    return float(re.sub(r"[^0-9eE+.-]", "", value))


def assert_upright_and_inside(svg):
    assert svg.startswith("<svg")
    assert 'transform="rotate(' not in svg
    root = ET.fromstring(svg)
    width, height = _number(root.attrib["width"]), _number(root.attrib["height"])
    assert width > 0 and height > 0
    ns = "{http://www.w3.org/2000/svg}"
    for text in root.findall(f".//{ns}text"):
        assert "transform" not in text.attrib, "glyph was rotated"
    for element in root.iter():
        for attr in ("x", "x1", "x2", "cx"):
            if attr in element.attrib:
                x = float(element.attrib[attr])
                assert -0.25 <= x <= width + 0.25, (attr, x, width)
        for attr in ("y", "y1", "y2", "cy"):
            if attr in element.attrib:
                y = float(element.attrib[attr])
                assert -0.25 <= y <= height + 0.25, (attr, y, height)
        if "points" in element.attrib:
            for token in element.attrib["points"].split():
                x, y = map(float, token.split(","))
                assert -0.25 <= x <= width + 0.25
                assert -0.25 <= y <= height + 0.25


def test_all_pure_archetypes():
    archetypes = []
    for name, fn in inspect.getmembers(pg, inspect.isfunction):
        if name.startswith("_") or "rot" not in inspect.signature(fn).parameters:
            continue
        archetypes.append((name, fn))
    assert [name for name, _ in archetypes] == [
        "rectangle", "rhombus", "square", "trapezoid", "triangle"
    ]
    rendered = 0
    for _, fn in archetypes:
        for angle in ANGLES:
            assert_upright_and_inside(fn(rot=angle))
            rendered += 1
    # Exercise the two non-default triangle invariants too.
    for kind in ("right", "isosceles"):
        for angle in ANGLES:
            assert_upright_and_inside(pg.triangle(rot=angle, kind=kind))
            rendered += 1
    assert rendered == 84


def test_functional_components_cannot_rotate():
    protected = {
        se: (
            "number_line", "vertical_problem", "long_division", "clock_face",
            "coins", "ten_frame", "bar_chart", "machine", "fraction_shape",
            "line_chart", "pyramid", "ruler", "digit_tracing_row", "dot_array",
            "object_groups", "place_value_blocks",
        ),
        sx: (
            "column_shown", "column_missing", "blank_column", "column_borrow",
            "bar_model", "split_array", "group_model", "unequal_shape", "frac_line",
        ),
    }
    for module, names in protected.items():
        for name in names:
            assert "rot" not in inspect.signature(getattr(module, name)).parameters, name


def test_grade_appropriate_determinism():
    for grade in ("א", "א׳", "כיתה א׳", "ב", "ב'", "כיתה ב"):
        assert max(abs(pg.rot_for(n, grade)) for n in range(100)) <= 15, grade
    assert 0 in {pg.rot_for(n, "א") for n in range(20)}
    assert 47 in {pg.rot_for(n, "ג") for n in range(30)}
    assert [pg.rot_for(n, "ד") for n in range(30)] == [pg.rot_for(n, "ד") for n in range(30)]


def test_hebrew_labels_are_rejected_by_g49():
    try:
        pg.rectangle(labels=("A", "B", "ג", "D"))
    except AssertionError as exc:
        assert "G49" in str(exc)
    else:
        raise AssertionError("Hebrew SVG label was not rejected by G49")


if __name__ == "__main__":
    test_all_pure_archetypes()
    test_functional_components_cannot_rotate()
    test_grade_appropriate_determinism()
    test_hebrew_labels_are_rejected_by_g49()
    print("elementary rotation: 7 variants x 12 angles = 84 renders; exclusions = PASS")
