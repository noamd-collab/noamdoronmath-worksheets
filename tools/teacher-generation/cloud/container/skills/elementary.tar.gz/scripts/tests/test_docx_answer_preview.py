#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Explicit answer-preview mode and numeric answer-column regressions."""
from pathlib import Path
import sys
import tempfile
import unittest

from bs4 import BeautifulSoup
from docx import Document
from docx.oxml.ns import qn
from docx.shared import Cm

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "scripts"))
import build_docx as BD
import ws_html as H


def preview_html():
    return ('<html dir="rtl"><body class="band-ab" data-document-kind="answer-preview">'
            '<div class="unit">דוגמת תשובות</div><div class="subtitle">כיתה א׳</div>'
            '<div class="preview-scope">מקטע לבדיקה בלבד: '
            '<span class="num">22–23</span></div>'
            '<div class="answers"><h2>תשובות מתוקנות</h2>'
            '<p class="note">הערה: השוויון נבדק בהצבה.</p>'
            '<table class="ans" dir="rtl"><tr><td class="qn">22.</td><td>'
            + H.text_answer('לא. המספר החסר הוא ') + H.num(6) + '</td></tr>'
            '<tr><td class="qn">23.</td><td>' + H.quantity(4, 'קפיצות')
            + '</td></tr></table></div>'
            '<p class="teacher-notes">המקור שוחזר מן ה־PDF; יתר הדף לא תוקן.</p>'
            '</body></html>')


def all_paragraphs(doc):
    return list(doc.paragraphs) + [p for table in doc.tables for row in table.rows
                                  for cell in row.cells for p in cell.paragraphs]


class DocxAnswerPreviewTests(unittest.TestCase):
    def build(self, html=None, **kwargs):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        src, out = Path(directory.name) / 'sheet.html', Path(directory.name) / 'sheet.docx'
        src.write_text(preview_html() if html is None else html, encoding='utf-8')
        BD.build_docx_from_html(src, out, **kwargs)
        return Document(out)

    def test_preview_preserves_scope_notes_and_omits_student_scaffolding(self):
        doc = self.build()
        text = '\n'.join(p.text for p in all_paragraphs(doc))
        for expected in ('דוגמת תשובות', 'כיתה א׳', 'מקטע לבדיקה בלבד', '22–23',
                         'הערה: השוויון נבדק בהצבה.',
                         'המקור שוחזר מן ה־PDF; יתר הדף לא תוקן.'):
            self.assertIn(expected, text)
        for absent in ('שם התלמיד/ה:', 'בהצלחה!', 'הערות המורה / דגשים לכיתה:', '____'):
            self.assertNotIn(absent, text)
        self.assertEqual(len(doc.tables), 2)  # Title banner and answer table only.
        self.assertEqual(len(doc.element.body.findall('.//' + qn('w:br'))), 0)

    def test_number_labels_are_ltr_inside_narrow_rtl_table(self):
        doc = self.build()
        table = doc.tables[1]
        self.assertNotEqual(table._tbl.tblPr.find(qn('w:bidiVisual')).get(qn('w:val')), '0')
        self.assertLess(table.columns[0].width, Cm(1.5))
        self.assertGreater(table.columns[1].width, Cm(14))
        self.assertFalse(table.autofit)
        for row, label in zip(table.rows, ('22.', '23.')):
            cell = row.cells[0]
            self.assertLess(cell.width, Cm(1.5))
            para = cell.paragraphs[0]
            self.assertIsNotNone(para._p.pPr.find(qn('w:bidi')))
            self.assertEqual(para.text, '\u200e' + label + '\u200e')
            self.assertEqual(para.runs[0]._r.rPr.find(qn('w:rtl')).get(qn('w:val')), '0')

    def test_all_preview_stories_keep_rtl_paragraphs(self):
        doc = self.build()
        for _, story in BD._story_roots(doc):
            for paragraph in story.iter(qn('w:p')):
                self.assertTrue(BD._bidi_enabled(paragraph.find(qn('w:pPr'))))
        text = '\n'.join(p.text for p in all_paragraphs(doc))
        self.assertIn('4\u200e\u00a0קפיצות', text)

    def test_ordinary_worksheet_keeps_student_fields_and_answer_page(self):
        html = preview_html().replace(' data-document-kind="answer-preview"', '')
        html = html.replace('<div class="answers">', '<ol class="questions"><li>ספרו:</li></ol>'
                            '<div class="answers">')
        doc = self.build(html)
        text = '\n'.join(p.text for p in all_paragraphs(doc))
        self.assertIn('שם התלמיד/ה:', text)
        self.assertIn('בהצלחה!', text)
        self.assertIn('הערות המורה / דגשים לכיתה:', text)
        page_breaks = [b for b in doc.element.body.iter(qn('w:br'))
                       if b.get(qn('w:type')) == 'page']
        self.assertEqual(len(page_breaks), 1)
        # The normal worksheet gets the same narrow numeric label fix.
        self.assertLess(doc.tables[1].columns[0].width, Cm(1.5))

    def test_preview_rejects_questions_and_no_answers(self):
        with self.assertRaisesRegex(ValueError, 'include_answers'):
            self.build(include_answers=False)
        for questions in ('<ol class="questions"><li>ספרו:</li></ol>', '<div class="q">ספרו:</div>'):
            with self.subTest(questions=questions), self.assertRaisesRegex(ValueError, 'questions'):
                self.build(preview_html().replace('</body>', questions + '</body>'))

    def test_preview_rejects_missing_or_ambiguous_supported_markup(self):
        source = preview_html()
        for html in (source.replace('class="preview-scope"', 'class="custom-scope"'),
                     source.replace('<div class="answers">', '<div class="custom-answers">'),
                     source.replace('class="ans"', 'class="other"'),
                     source.replace('</body>', '<div class="preview-scope">עוד</div></body>'),
                     source.replace('</body>', '<div class="answers"><table class="ans">'
                                    '<tr><td>לא</td></tr></table></div></body>')):
            with self.subTest(html=html), self.assertRaises(ValueError):
                self.build(html)
        with self.assertRaisesRegex(ValueError, 'Unsupported'):
            self.build(source.replace('answer-preview', 'unknown'))
        with self.assertRaisesRegex(ValueError, 'hints'):
            self.build(content_json_path='explicit-hints.json')

    def test_drill_columns_and_hebrew_labels_are_not_forced_ltr(self):
        doc = Document()
        table = BeautifulSoup('<table class="drill"><tr><td>טקסט</td><td>עוד</td></tr></table>',
                              'html.parser').table
        BD.add_html_table(doc, table)
        self.assertTrue(doc.tables[0].autofit)
        self.assertEqual(doc.tables[0].columns[0].width, doc.tables[0].columns[1].width)
        labels = BeautifulSoup('<table class="ans"><tr><td class="qn">א.</td><td>כן</td></tr></table>',
                               'html.parser').table
        BD.add_html_table(doc, labels)
        run = doc.tables[1].rows[0].cells[0].paragraphs[0].runs[0]
        self.assertNotIn('\u200e', run.text)
        self.assertNotEqual(run._r.rPr.find(qn('w:rtl')).get(qn('w:val')), '0')


if __name__ == '__main__':
    unittest.main()
