#!/usr/bin/env python3
"""A failed macOS WeasyPrint attempt must still reach the Chromium fallback."""
from contextlib import redirect_stderr, redirect_stdout
import io
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import build_pdf as BP


class PdfFallbackTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.html = self.root / "sheet.html"
        self.pdf = self.root / "sheet.pdf"
        self.html.write_text('<html lang="he" dir="rtl">בדיקה</html>', encoding="utf-8")

    def mac_process_success(self, args, **kwargs):
        self.assertIn("/opt/homebrew/lib", kwargs["env"]["DYLD_FALLBACK_LIBRARY_PATH"])
        self.pdf.write_bytes(b"weasyprint-output")
        return subprocess.CompletedProcess(args, 0, "", "")

    def chromium_success(self, html, pdf):
        self.assertEqual(html, self.html)
        pdf.write_bytes(b"chromium-output")
        return True

    def run_main(self, process_effect, repair_effect=None):
        # Force the macOS loader branch on every platform while preserving real
        # main/build_with_weasyprint control flow and the resulting file choice.
        with patch.object(Path, "is_dir", return_value=True), \
                patch.dict(os.environ, {"DYLD_FALLBACK_LIBRARY_PATH": ""}), \
                patch.object(BP.subprocess, "run", side_effect=process_effect), \
                patch.object(BP, "_fix_weasyprint_tounicode", side_effect=repair_effect) as repair, \
                patch.object(BP, "build_with_chromium", side_effect=self.chromium_success) as chromium, \
                patch.object(sys, "argv", ["build_pdf.py", str(self.html), str(self.pdf)]), \
                redirect_stderr(io.StringIO()), redirect_stdout(io.StringIO()):
            result = BP.main()
        return result, chromium, repair

    def test_mac_failures_allow_chromium_to_produce_the_final_file(self):
        cases = (
            (subprocess.TimeoutExpired("weasyprint", 120), None),
            (OSError("cannot launch renderer"), None),
            (self.mac_process_success, RuntimeError("cannot repair CMap")),
        )
        for process_effect, repair_effect in cases:
            with self.subTest(failure=repr(process_effect), repair=repr(repair_effect)):
                result, chromium, _ = self.run_main(process_effect, repair_effect)
                self.assertEqual(result, 0)
                chromium.assert_called_once_with(self.html, self.pdf)
                self.assertEqual(self.pdf.read_bytes(), b"chromium-output")

    def test_successful_mac_attempt_keeps_repaired_weasyprint_output(self):
        def repair_pdf(pdf):
            pdf.write_bytes(pdf.read_bytes() + b"-repaired")

        result, chromium, repair = self.run_main(self.mac_process_success, repair_pdf)
        self.assertEqual(result, 0)
        chromium.assert_not_called()
        repair.assert_called_once_with(self.pdf)
        self.assertEqual(self.pdf.read_bytes(), b"weasyprint-output-repaired")


if __name__ == "__main__":
    unittest.main()
