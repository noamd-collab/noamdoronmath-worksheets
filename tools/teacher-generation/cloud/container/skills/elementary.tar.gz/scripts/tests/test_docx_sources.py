#!/usr/bin/env python3
"""Regression checks for explicit DOCX sources and supported hint export."""
import json
from contextlib import redirect_stderr
import io
from pathlib import Path
import sys
import tempfile
import unittest
from zipfile import ZipFile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import build_docx as BD
import docx


def document_text(path):
    document = docx.Document(path)
    parts = [paragraph.text for paragraph in document.paragraphs]
    parts.extend(cell.text for table in document.tables
                 for row in table.rows for cell in row.cells)
    return "\n".join(parts)


class DocxSourceTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.content = self.root / "content.json"
        self.html = self.root / "sheet.html"
        self.output = self.root / "sheet.docx"
        self.hints = ["חשבו על המקום של הספרה", "פרקו את המספר", "חברו את החלקים"]
        self.data = {
            "meta": {"grade": "ג", "level": "ב", "topic": "מקור נבחר"},
            "questions": [{"n": 1, "text": "השאלה מהמקור הנבחר",
                           "answer": r"\frac{1}{2}", "hints": self.hints}],
        }
        self.write_content()
        self.html.write_text(
            '<html lang="he" dir="rtl"><body class="band-gd">'
            '<div class="unit">כותרת HTML</div>'
            '<ol class="questions"><li>שאלה מהקובץ הסמוך</li></ol>'
            '</body></html>', encoding="utf-8")

    def write_content(self):
        self.content.write_text(json.dumps(self.data, ensure_ascii=False), encoding="utf-8")

    def test_json_wins_over_neighboring_html_and_keeps_editable_fraction(self):
        BD.build_docx_from_content_json(self.content, self.output)
        text = document_text(self.output)
        self.assertIn("השאלה מהמקור הנבחר", text)
        self.assertNotIn("שאלה מהקובץ הסמוך", text)
        for hint in self.hints:
            self.assertIn(hint, text)
        with ZipFile(self.output) as archive:
            xml = archive.read("word/document.xml").decode("utf-8")
        self.assertIn("<m:f>", xml)
        self.assertTrue(BD.verify_docx(self.output)[0])

    def test_html_does_not_load_implicit_neighboring_hint_source(self):
        BD.build_docx_from_html(self.html, self.output)
        text = document_text(self.output)
        self.assertIn("שאלה מהקובץ הסמוך", text)
        self.assertNotIn(self.hints[0], text)

    def test_html_includes_explicit_hint_source(self):
        BD.build_docx_from_html(self.html, self.output, content_json_path=self.content)
        text = document_text(self.output)
        for hint in self.hints:
            self.assertIn(hint, text)

    def test_missing_explicit_hint_source_is_an_error(self):
        with self.assertRaises(FileNotFoundError):
            BD.build_docx_from_html(
                self.html, self.output, content_json_path=self.root / "missing.json")
        self.assertFalse(self.output.exists())

    def test_unsupported_hint_shapes_fail_instead_of_disappearing(self):
        variants = [
            {"hints": {"1": self.hints}, "questions": []},
            {"questions": [{"n": 1, "hints": [{"text": h} for h in self.hints]}]},
            {"questions": [{"n": 1, "items": [{"hints": self.hints}]}]},
            {"questions": [{"n": 1, "hints": self.hints[:2]}]},
            {"questions": [{"n": 1, "hints": ["א", "ב", " "]}]},
        ]
        for data in variants:
            with self.subTest(data=data):
                self.content.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
                with self.assertRaisesRegex(ValueError, "questions"):
                    BD.build_docx_from_html(
                        self.html, self.output, content_json_path=self.content)
                self.assertFalse(self.output.exists())

    def test_no_hints_explicitly_omits_unsupported_hint_source(self):
        self.data["hints"] = {"1": self.hints}
        self.write_content()
        BD.build_docx_from_content_json(self.content, self.output, include_teacher_hints=False)
        self.assertNotIn(self.hints[0], document_text(self.output))

    def test_json_rejects_a_second_ignored_content_argument(self):
        with redirect_stderr(io.StringIO()), self.assertRaises(SystemExit) as error:
            BD.main([str(self.content), str(self.output), "--content", str(self.content)])
        self.assertEqual(error.exception.code, 2)
        self.assertFalse(self.output.exists())

    def test_zero_answers_survive_json_export_and_alias_selection(self):
        self.data["questions"] = [
            {"n": 1, "text": "חשבו", "answer": 0},
            {"n": 2, "text": "חשבו", "ans": 0, "answer": 9},
            {"n": 3, "text": "חשבו", "answer": [0, 4, 0.0]},
            {"n": 4, "text": "חשבו", "items": [
                {"label": "א", "text": "חשבו", "answer": 0}]},
            {"n": 5, "text": "חשבו", "ans": "", "answer": 0},
            {"n": 6, "text": "חשבו", "ans": [], "answer": 0},
            {"n": 7, "text": "חשבו", "ans": None, "answer": 0},
        ]
        self.write_content()
        BD.build_docx_from_content_json(self.content, self.output)
        document = docx.Document(self.output)
        answer_tables = [table for table in document.tables
                         if len(table.rows) == len(self.data["questions"])
                         and len(table.columns) == 2]
        self.assertEqual(len(answer_tables), 1)
        answers = [row.cells[1].text.replace("\u200e", "").replace("\u200f", "").strip()
                   for row in answer_tables[0].rows]
        self.assertEqual(answers, ["0", "0", "0 ; 4 ; 0.0", "א. 0", "0", "0", "0"])


if __name__ == "__main__":
    unittest.main()
