#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Regression checks for mixed Hebrew answer prose and inline quantities.

These tests verify source direction, rendered coordinates and Word structure.
They do not assess spelling, pedagogical completeness or arbitrary CSS.
"""
import importlib.util
import contextlib
import io
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import unittest

from bs4 import BeautifulSoup
from docx import Document
from docx.oxml.ns import qn

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT / "scripts" / "lib"))
import build_docx as BD
import ws_html as H
from answer_layout import check_answer_html, g70_answer_layout


def fixture_html():
    template = (ROOT / "assets" / "worksheet_template_elementary.html").read_text(
        encoding="utf-8")
    styles = re.search(r"<style>(.*?)</style>", template, re.S).group(1)
    # Narrow containers force the preceding prose to wrap, so a split between
    # the number and unit would be observable; the whole quantity still fits.
    rows = []
    for width in (110, 145, 180):
        rows.append('<p class="answer-text" style="width:%spx;border:1px solid;'
                    'font-size:14pt;line-height:1.8">%s %s.</p>' % (
                        width, H.text_answer("הַתְּשׁוּבָה הִיא"),
                        H.quantity(123, "תַּפּוּחִים")))
    rows.append('<p class="answer-text">' + H.text_answer("הַתַּרְגִּיל:")
                + ' ' + H.ltr("52 : 4 = 13") + '. '
                + H.quantity(13, "מַטְבְּעוֹת") + '.</p>')
    return ('<!doctype html><html dir="rtl" lang="he"><head><meta charset="utf-8">'
            '<style>' + styles + '</style></head><body class="band-ab">'
            + ''.join(rows) + '</body></html>')


class AnswerSourceTests(unittest.TestCase):
    def test_text_is_escaped_and_quantity_is_inline(self):
        text = H.text_answer('<b>לא & כן</b>')
        node = BeautifulSoup(text, "html.parser").span
        self.assertEqual(node["dir"], "rtl")
        self.assertIsNone(node.find("b"))
        self.assertEqual(node.get_text(), '<b>לא & כן</b>')
        quantity = BeautifulSoup(H.quantity(4, 'קְפִיצוֹת'), "html.parser").span
        self.assertEqual(quantity.get_text(), '4\u00a0קְפִיצוֹת')
        self.assertEqual(quantity.span["dir"], "ltr")
        self.assertIsNone(quantity.find(["br", "div", "p"]))
        self.assertIn('&lt;', H.quantity('4<5', 'ס"מ'))
        for value, unit in (("", "תפוחים"), (4, ""), (4, "תפוחים\nאדומים")):
            with self.assertRaises(ValueError):
                H.quantity(value, unit)

    def test_keyed_preserves_prose_direction_and_math_islands(self):
        mixed = H.keyed(["557", "לֹא. " + H.ltr("5 + 3 = 8")])
        page = BeautifulSoup('<div class="answers">' + mixed + '</div>', "html.parser")
        self.assertEqual([n.get_text() for n in page.select('.ltr')],
                         ["557", "5 + 3 = 8"])
        self.assertEqual(page.select_one('.answer-text')["dir"], "rtl")
        self.assertIn("א. ", page.get_text())
        self.assertIn("ב. ", page.get_text())
        self.assertTrue(check_answer_html(str(page))[0])

    def test_gate_rejects_inherited_and_inline_ltr_prose(self):
        cases = [
            '<div class="answers"><span class="ltr">4 קפיצות</span></div>',
            '<table class="ans"><tr><td dir="ltr"><b>לא</b></td></tr></table>',
            '<section id="answers" dir="ltr"><p>המספר הוא 6</p></section>',
            '<p class="answer-text" style="direction: LTR !important">לא</p>',
            '<div dir="ltr"><section class="answers">לא</section></div>',
            '<div class="answers"><span class="num">מטרים</span></div>',
            '<div class="answers"><span style="direction:initial">לא</span></div>',
            '<div class="answers"><span class="ltr">&#x5dc;&#x5d0;</span></div>',
            '<div class="answers"><span style="direction:ltr /**/;">לא</span></div>',
            '<div class="answers" dir="rtl"><span style="direction:ltr ! important;'
            'direction:rtl">לא</span></div>',
        ]
        for source in cases:
            with self.subTest(source=source):
                ok, message = check_answer_html(source)
                self.assertFalse(ok)
                self.assertIn("Hebrew answer text in LTR", message)

    def test_gate_accepts_rtl_overrides_math_and_nonanswer_content(self):
        cases = [
            '<div class="answers" dir="rtl">' + H.quantity(4, 'קפיצות') + '</div>',
            '<div class="answers" dir="ltr"><p dir="rtl">לא. '
            '<span class="ltr">5 + 3 = 8</span></p></div>',
            '<div class="answers"><span class="ltr"><span dir="rtl">לא</span>'
            '<span>52 : 4 = 13</span></span></div>',
            '<div class="answers" dir="rtl"><div class="eq">תשובה בעברית</div></div>',
            '<p class="ltr">הוראה מחוץ למפתח</p><table class="ans" dir="rtl">'
            '<tr><td class="qn">1.</td><td>כן</td></tr></table>',
            '<div class="answers" dir="ltr"><!-- לא --><script>לא</script>'
            '<style>לא</style><template>לא</template><span dir="rtl">כן</span></div>',
            '<div class="answers"><span class="ltr" style="direction:rtl">לא</span></div>',
            '<div class="answers" dir="ltr"><bdi>לא</bdi><span dir="auto">כן</span></div>',
        ]
        for source in cases:
            with self.subTest(source=source):
                self.assertTrue(check_answer_html(source)[0])

    def test_scope_and_unreadable_file_limits_are_reported(self):
        ok, message = check_answer_html('<p class="custom-answer">לא</p>')
        self.assertTrue(ok)
        self.assertIn("no recognized answer scope", message)
        self.assertFalse(g70_answer_layout(ROOT / "missing-answers.html")[0])

    def test_house_gate_is_integrated(self):
        import house_gates as HG
        from unittest.mock import patch
        with tempfile.TemporaryDirectory() as tmp:
            source = Path(tmp) / "bad.html"
            source.write_text('<div class="answers"><span class="ltr">לא</span></div>',
                              encoding="utf-8")
            with patch.object(HG, 'g50_stars', return_value=(True, "fixture")), \
                 patch.object(HG, 'g53_figures_registered', return_value=(True, "fixture")), \
                 patch.object(HG, 'g5x_signs', return_value=[]), \
                 patch.object(HG, 'g6x_content', return_value=[]), \
                 contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(HG.run(html=str(source), grade='א', content='fixture',
                                        quiet=True), 1)

    def test_word_preserves_rtl_answer_and_nonbreaking_quantity(self):
        with tempfile.TemporaryDirectory() as tmp:
            src, dest = Path(tmp) / "sheet.html", Path(tmp) / "sheet.docx"
            rows = ''.join('<tr><td class="qn">%s.</td><td>%s %s</td></tr>' % (
                i, H.text_answer("הַתְּשׁוּבָה הִיא"), H.quantity(123, "תַּפּוּחִים"))
                for i in range(1, 4))
            rows += '<tr><td>4.</td><td>' + H.ltr("52 : 4 = 13") + '</td></tr>'
            src.write_text('<html dir="rtl"><body class="band-ab"><div class="answers">'
                           '<table class="ans">' + rows + '</table></div></body></html>',
                           encoding="utf-8")
            BD.build_docx_from_html(src, dest)
            doc = Document(dest)
            all_paras = [p for table in doc.tables for row in table.rows
                         for cell in row.cells for p in cell.paragraphs]
            paras = [p for p in all_paras if "תַּפּוּחִים" in p.text]
            self.assertEqual(len(paras), 3)
            for para in paras:
                self.assertIn('123\u200e\u00a0תַּפּוּחִים', para.text)
                self.assertIsNotNone(para._p.pPr.find(qn('w:bidi')))
                self.assertEqual(len(para._p.findall('.//' + qn('w:br'))), 0)
                number = next(run for run in para.runs if "123" in run.text)
                self.assertEqual(number._r.rPr.find(qn('w:rtl')).get(qn('w:val')), '0')
            math = next(run for para in all_paras for run in para.runs
                        if "52 : 4 = 13" in run.text)
            self.assertEqual(math._r.rPr.find(qn('w:rtl')).get(qn('w:val')), '0')

    @unittest.skipUnless(importlib.util.find_spec("weasyprint") and importlib.util.find_spec("fitz"),
                         "rendered answer test requires WeasyPrint and PyMuPDF")
    def test_pdf_quantity_and_math_have_correct_coordinates(self):
        from weasyprint import HTML
        import fitz
        # Only the known template CSS plus explicit local fixture widths.
        document = HTML(string=fixture_html(), base_url=str(ROOT / "assets")).render()
        with fitz.open(stream=document.write_pdf(), filetype="pdf") as pdf:
            self.assertEqual(len(pdf), 1)
            numbers, units = [], []
            for block in pdf[0].get_text("dict")["blocks"]:
                for line in block.get("lines", []):
                    line_text = ''.join(s['text'] for s in line['spans'])
                    if '123' in line_text:
                        numbers.append(line)
                        self.assertIn('ת', line_text)
                        # Actual PDF glyph order: first numeral is right of
                        # the Hebrew unit, and digits remain left-to-right.
                        raw = pdf[0].get_text('rawdict', clip=fitz.Rect(line['bbox']))
                        chars = [c for b in raw['blocks'] for l in b.get('lines', [])
                                 for s in l['spans'] for c in s['chars']]
                        digits = [c for c in chars if c['c'] in '123']
                        hebrew = [c for c in chars if re.match('[א-ת]', c['c'])]
                        self.assertEqual(''.join(c['c'] for c in sorted(digits,
                                             key=lambda c: c['bbox'][0])), '123')
                        self.assertGreater(min(c['bbox'][0] for c in digits),
                                           max(c['bbox'][0] for c in hebrew))
            self.assertEqual(len(numbers), 3)
            # Formula 52 : 4 = 13 keeps operand order by physical x position.
            # Text extractors may attach Hebrew punctuation to the first word,
            # so verify glyph coordinates rather than word-token boundaries.
            raw_lines = [line for block in pdf[0].get_text('rawdict')['blocks']
                         for line in block.get('lines', [])]
            visual_lines = [''.join(c['c'] for c in sorted(
                [c for span in line['spans'] for c in span['chars']],
                key=lambda c: c['bbox'][0])) for line in raw_lines]
            self.assertTrue(any(re.search(r'52\s*:\s*4\s*=\s*13', text)
                                for text in visual_lines))


if __name__ == '__main__':
    brew_lib = '/opt/homebrew/lib'
    flag = 'ANSWER_LAYOUT_DYLD_REEXEC'
    if (sys.platform == 'darwin' and Path(brew_lib).is_dir()
            and importlib.util.find_spec('weasyprint')
            and brew_lib not in os.environ.get('DYLD_FALLBACK_LIBRARY_PATH', '').split(os.pathsep)
            and os.environ.get(flag) != '1'):
        env = dict(os.environ)
        env['DYLD_FALLBACK_LIBRARY_PATH'] = os.pathsep.join(
            v for v in (brew_lib, env.get('DYLD_FALLBACK_LIBRARY_PATH', '')) if v)
        env[flag] = '1'
        raise SystemExit(subprocess.run([sys.executable, str(Path(__file__).resolve()),
                                         *sys.argv[1:]], env=env).returncode)
    unittest.main()
