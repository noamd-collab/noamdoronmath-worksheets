#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ws_html.py — עוזרי HTML לדף יסודי (v2.1).

הפער שהמודול סוגר: התבנית נותנת מחלקות CSS, אבל כמה מוסכמות bidi
וכמה תבניות חוזרות נכתבו בכל דף מחדש — ובכל פעם נשברו אחרת. כאן הן
נכתבות פעם אחת, נכון.

    import ws_html as H
    H.ltr("342 + 215 =") ; H.keyed(["557","687"]) ; H.frac(1,4)
"""
import html as _html
import os as _os
import re
import sys as _sys

_sys.path.insert(0, _os.path.join(
    _os.path.dirname(_os.path.abspath(__file__)), "lib"))
import signs as S  # noqa: E402  — מקור האמת לסימנים (v2.2)

# ייצוא מחדש: בונים תרגילים דרך אלה, לא ב-f-string ידני.
#   H.expr(6, "*", 4, "ג") → "6 x 4 ="      H.op("*", "ב") → "×"
#   H.neg(3)               → "(3-)"          H.MINUS        → U+2212
expr, chain, op, neg, MINUS, PLUS = (S.expr, S.chain, S.op, S.neg,
                                     S.MINUS, S.PLUS)

HEB_LETTERS = "אבגדהוזחטי"


# ------------------------------------------------------------ bidi בסיסי
def ltr(s):
    """כל תרגיל / רשימת מספרים חייב `span.ltr` (hebrew-rtl §8ב).

    ‼ מלכודת: `blank()` או `box()` בקצה משוואה חייבים לשבת **בתוך**
    ה-span. בחוץ הם תווים ניטרליים וקופצים לצד הלא נכון:
        רע  : ltr("156 + 128 = ") + blank()
        טוב : ltr(f"156 + 128 = {blank()}")
    """
    return f'<span class="ltr">{s}</span>'


def num(s):
    """טווח מספרים בתוך פרוזה עברית (`21–25`) — מונע היפוך המקף."""
    return f'<span class="num">{s}</span>'


def text_answer(text):
    """Escaped Hebrew prose in an explicit RTL inline span.

    Accepts plain text, not HTML. For mixed answers, compose this span with
    ``ltr(expr(...))`` and ``quantity(...)`` in an RTL answer paragraph.
    """
    return ('<span class="answer-text" dir="rtl">'
            + _html.escape(str(text)) + '</span>')


def quantity(value, unit):
    """Keep one number and its unit together in Hebrew prose.

    Both arguments are plain text. NBSP survives Word export; the template's
    .quantity rule prevents wrapping a multi-word unit inside the PDF.
    This helper does not validate arithmetic, spelling, grade or units.
    """
    value, unit = str(value).strip(), str(unit).strip()
    if not value or not unit or any(c in value + unit for c in "\r\n"):
        raise ValueError("quantity requires a nonempty single-line value and unit")
    return ('<span class="quantity" dir="rtl"><span class="num" dir="ltr">'
            + _html.escape(value) + '</span>\u00a0'
            + _html.escape(unit) + '</span>')


def blank(width="2.2cm"):
    return f'<span class="blank" style="min-width:{width}"></span>'


def box():
    return '<span class="box"></span>'


def fmt(n, grade=None):
    """פסיק אלפים מ-4 ספרות. `grade="ב"` ⇒ בלי מפריד (`1000`)."""
    return S.fmt(n, grade) if grade else f"{int(n):,}"


def frac(n, d, grade=None):
    """שבר מדורג — מונה מעל מכנה עם קו שבר (hebrew-rtl §8).
    זה הייצוג היחיד המותר: אין `½` ואין `a/b` בשורה.
    `grade="ב"` זורק — שברים בא׳–ב׳ במילים ובצביעה בלבד."""
    if grade and not S.profile(grade)["frac"]:
        raise ValueError(f"frac: שבר מדורג אסור בכיתה {S._g(grade)}׳ "
                         f"(curriculum.md §3 — במילים ובצביעה בלבד)")
    return (f'<span class="frac"><span class="fnum">{n}</span>'
            f'<span class="fden">{d}</span></span>')


# ------------------------------------------------- מפתח תשובות ממותג אותיות
def keyed(values, start=0):
    """שורת מפתח ממותגת: `א. 383 ; ב. 482 ; ג. 391`.

    האות מודפסת גם ליד הרכיב וגם במפתח, כדי שההתאמה לא תסתמך רק
    על מיקום. `figrow()` ו-`table.drill` מסדרים את הסעיפים מימין לשמאל;
    בתוך כל סעיף התרגיל המספרי נשאר LTR.
    """
    # Values remain trusted HTML, as in ltr()/frac(). Hebrew prose must not
    # inherit an LTR wrapper; explicitly marked math inside it stays LTR.
    def value_span(value):
        value = str(value)
        if re.search(r"[א-ת]", plain(value)):
            return f'<span class="answer-text" dir="rtl">{value}</span>'
        return ltr(value)
    return " ; ".join(f'{HEB_LETTERS[start + i]}. {value_span(v)}'
                      for i, v in enumerate(values))


def lettered_items(items, sep=" &nbsp;&nbsp; "):
    """פריטי בחירה ממוספרים באותיות עבריות.

    ‼ אין להשתמש ב-`(1) (2) (3)`: זוג סוגריים שכל תוכנו ספרה הוא טיפוס
    חלש, מקבל את כיוון ההטמעה RTL ומתהפך ל-`)1(`. נמדד ברמת התו: אותו
    קוד בדיוק נתן `(1)` בדף אחד ו-`)1(` בדף אחר. אות עברית = טיפוס חזק.
    """
    return sep.join(f'<b>{HEB_LETTERS[i]}.</b> {t}'
                    for i, t in enumerate(items))


# ------------------------------------------------------------ פיגום פתרון
def steps_box(n_steps=2, known=True, final_unit=True):
    """פיגום פתרון מסודר לבעיה מילולית: מה ידוע · מה מחפשים · שלב 1 ·
    שלב 2 · תשובה **עם יחידה**.

    עונה על שלוש דרישות קטלוג חוזרות בבעיות מילוליות — "מספור שלבים",
    "יחידות", ו"התלמיד מסביר את סדר הפעולות לפני החישוב" — ועל טעות
    היעד "תשובה ללא יחידה".
    """
    rows = []
    if known:
        rows.append("<tr><td><b>מה ידוע?</b></td>"
                    "<td><span class='blank' style='min-width:9cm'></span>"
                    "</td></tr>")
        rows.append("<tr><td><b>מה מחפשים?</b></td>"
                    "<td><span class='blank' style='min-width:9cm'></span>"
                    "</td></tr>")
    for i in range(1, n_steps + 1):
        rows.append(
            f"<tr><td><b>שלב {i}</b></td>"
            f"<td>תרגיל: <span class='blank' style='min-width:4cm'></span>"
            f"&nbsp;&nbsp; תשובה: "
            f"<span class='blank' style='min-width:3cm'></span></td></tr>")
    if final_unit:
        rows.append("<tr><td><b>תשובה</b><br>"
                    "<span style='font-size:0.8em'>(עם יחידה!)</span></td>"
                    "<td><span class='blank' style='min-width:9cm'></span>"
                    "</td></tr>")
    return ('<table class="drill" style="margin:5px 0">'
            + "".join(rows) + "</table>")


def steps_line(unit=True):
    """גרסה קומפקטית לבעיה חד-שלבית — שורה במקום טבלה.

    ‼ הכרחי: טבלת פיגום בכל שאלה מנפחת דף בעיות ל-8 עמודים, ושער
    העימוד פוסל עמודים דלילים. הטבלה שמורה לבעיות דו-שלביות.
    """
    tail = (" &nbsp;&nbsp; תשובה (עם יחידה): "
            "<span class='blank' style='min-width:4.4cm'></span>" if unit else
            " &nbsp;&nbsp; תשובה: "
            "<span class='blank' style='min-width:4cm'></span>")
    return ("<div class='sub'>תרגיל: "
            "<span class='blank' style='min-width:3.4cm'></span>"
            + tail + "</div>")


# ------------------------------------------------------------ לוח כפל חלקי
def mul_grid(row_factors, col_factors, show=(), grade="ג"):
    """לוח כפל **חלקי** — חלק מן המכפלות מודפסות כדוגמה, השאר למילוי.

    `dir="ltr"` על הטבלה בכוונה: התוכן מספרי בלבד, ובעמוד RTL העמודות
    זורמות ימין-לשמאל בעוד מפתח התשובות (`span.ltr`) זורם שמאל-לימין —
    אותה מלכודת מיקום של `keyed()`. לוח LTR מיישר את השניים.
    מומלץ למתג את המפתח לפי **גורם השורה** ("שורת 2: ..."), לא א׳/ב׳/ג׳.
    """
    head = ("<tr><th>" + ltr(S.MUL(grade)) + "</th>"   # ב׳ → × ; ג׳–ו׳ → x
            + "".join(f"<th>{ltr(str(c))}</th>" for c in col_factors)
            + "</tr>")
    body = []
    for r in row_factors:
        cells = [f"<th>{ltr(str(r))}</th>"]
        for c in col_factors:
            cells.append(f"<td>{ltr(str(r * c))}</td>" if (r, c) in show
                         else "<td>&nbsp;</td>")
        body.append("<tr>" + "".join(cells) + "</tr>")
    return ('<table class="drill" dir="ltr" style="width:auto;margin:8px auto">'
            + head + "".join(body) + "</table>")


def drill_table(cells, per_row=2):
    """טבלת תרגילונים. `cells` — רשימת מחרוזות HTML מוכנות (כולל האות)."""
    rows = "".join(
        "<tr>" + "".join(f"<td>{c}</td>" for c in cells[i:i + per_row])
        + "</tr>" for i in range(0, len(cells), per_row))
    return f'<table class="drill">{rows}</table>'


# ------------------------------------------------------------ שרטוטים
def fig(svg):
    """SVG במיכל ממורכז. G46: לעולם לא float בתוך פריט RTL."""
    return f'<div class="figure" dir="ltr">{svg}</div>'


def figrow(svgs, gap=18, letters=True, start=0):
    """שורת שרטוטים אחת, עם אות סעיף מעל כל אחד.
    הסעיף הראשון מימין; כל שרטוט מבודד ב-LTR כדי לא להפוך מספרים.
    חוסם ברוחב > 650px — גלישה גורמת להשמטת גליפים שקטה."""
    total = 0
    for s in svgs:
        m = re.search(r'width="([\d.]+)"', s)
        total += float(m.group(1)) if m else 0
    total += gap * (len(svgs) - 1)
    if total > 650:
        raise ValueError(
            f"figrow: רוחב שורת הרכיבים {total:.0f}px > 650px — "
            f"WeasyPrint ישמיט גליפים בשקט. פצלו לשורות או הקטינו cell.")
    parts = []
    for i, s in enumerate(svgs):
        cap = (f'<div dir="rtl" style="font-weight:bold;font-size:0.9em;'
               f'margin-bottom:2px">{HEB_LETTERS[start + i]}.</div>'
               if letters else "")
        parts.append(f'<span dir="ltr" style="display:inline-block;margin:0 {gap // 2}px;'
                     f'vertical-align:top;text-align:center">{cap}{s}</span>')
    return f'<div class="figure" dir="rtl">{"".join(parts)}</div>'


# ------------------------------------------------------------ טקסט נקי
_TAG = re.compile(r"<[^>]+>")


def plain(h):
    """טקסט נקי ל-content.json (שערי אמת-התוכן סורקים מחרוזות)."""
    return re.sub(r"\s+", " ", _html.unescape(_TAG.sub(" ", h))).strip()


# ===========================================================================
# v3.1-noam — תבניות פעילויות מגוונות ליסודי (א׳–ו׳)
# ===========================================================================

def number_cards(cards, grade=None):
    """שורת כרטיסי ספרות/מספרים מעוצבים לפעילויות מבנה עשורי וקומבינטוריקה
    ('הרכיבו מהכרטיסים שלפניכם...')."""
    spans = []
    colors = (
        ("#DCECFB", "#1F6FC5"),
        ("#FDE9D2", "#E8821E"),
        ("#D7F0ED", "#159E8E"),
        ("#FFF3C9", "#B8860B"),
        ("#FBE4F7", "#7A007A"),
    )
    for i, c in enumerate(cards):
        bg, brd = colors[i % len(colors)]
        val_str = fmt(c, grade) if isinstance(c, int) and abs(c) >= 1000 else str(c)
        spans.append(
            f'<span class="ltr" style="display:inline-block;min-width:38px;'
            f'padding:4px 10px;margin:0 5px;background:{bg};'
            f'border:2px solid {brd};border-radius:8px;font-weight:bold;'
            f'font-size:1.18em;text-align:center">{val_str}</span>'
        )
    return f'<div class="figure" dir="ltr" style="margin:6px 0">{"".join(spans)}</div>'


def hundred_window(center, shape="cross", visible_offsets=((0, 0),)):
    """חלון גזור מלוח ה-100 (כיתות א׳–ב׳) להשלמת שכנים בשורות (±1) ובעמודות (±10).

    center          : המספר במשבצת המרכזית `(0, 0)` של החלון (בין 1 ל-100).
    shape           : "cross" (פלוס של 5 משבצות), "square2x2" (ריבוע 2×2),
                      "L" (צורת ר׳), "row3" (3 בשורה), "col3" (3 בעמודה).
    visible_offsets : אוסף הזזות `(dr, dc)` שבהן המספר מודפס (בברירת מחדל: רק `(0, 0)`).
    """
    shapes_map = {
        "cross":     {(-1, 0), (0, -1), (0, 0), (0, 1), (1, 0)},
        "square2x2": {(0, 0), (0, 1), (1, 0), (1, 1)},
        "L":         {(0, 0), (1, 0), (1, 1)},
        "row3":      {(0, -1), (0, 0), (0, 1)},
        "col3":      {(-1, 0), (0, 0), (1, 0)},
    }
    active = shapes_map.get(shape, shapes_map["cross"])
    vis = set(visible_offsets)
    r_min = min(dr for dr, _ in active)
    r_max = max(dr for dr, _ in active)
    c_min = min(dc for _, dc in active)
    c_max = max(dc for _, dc in active)

    rows_html = []
    for dr in range(r_min, r_max + 1):
        cells_html = []
        for dc in range(c_min, c_max + 1):
            if (dr, dc) not in active:
                cells_html.append(
                    '<td style="border:none;background:transparent;width:42px;height:42px"></td>'
                )
            else:
                val = center + dr * 10 + dc
                if not 1 <= val <= 100:
                    raise ValueError(f"hundred_window: משבצת ({dr},{dc}) מביאה לערך {val} מחוץ ל-1..100")
                if (dr, dc) in vis:
                    cells_html.append(
                        f'<td class="hlB" style="width:42px;height:42px;text-align:center;'
                        f'font-weight:bold;border:2px solid #1F6FC5">{ltr(str(val))}</td>'
                    )
                else:
                    cells_html.append(
                        '<td style="width:42px;height:42px;text-align:center;'
                        'background:#FFFFFF;border:2px solid #E8821E">&nbsp;</td>'
                    )
        rows_html.append("<tr>" + "".join(cells_html) + "</tr>")
    return (
        '<table class="drill" dir="ltr" style="width:auto;margin:6px auto;'
        'border-collapse:collapse">' + "".join(rows_html) + "</table>"
    )


def sorting_baskets(baskets, bank_items, lines_per_basket=2):
    """פעילות 'מיון לסלים / לתיבות' לפי קריטריון מתמטי (כיתות א׳–ה׳).

    baskets    : רשימת כותרות הסלים (למשל `["קטן מ-100", "שווה ל-100", "גדול מ-100"]`).
    bank_items : רשימת מחרוזות (תרגילים או מספרים) במחסן העליון למיון.
    """
    bank_html = " &nbsp;&bull;&nbsp; ".join(ltr(str(it)) for it in bank_items)
    b_styles = (
        ("#F4FAFF", "#1F6FC5"),
        ("#FDE9D2", "#E8821E"),
        ("#D7F0ED", "#159E8E"),
    )
    tds = []
    for idx, title in enumerate(baskets):
        bg, brd = b_styles[idx % len(b_styles)]
        blank_rows = "<br>".join(blank("3.2cm") for _ in range(lines_per_basket))
        tds.append(
            f'<td style="background:{bg};border:2px solid {brd};border-radius:8px;'
            f'padding:8px 10px;vertical-align:top;text-align:center">'
            f'<div style="font-weight:bold;color:{brd};margin-bottom:6px">{title}</div>'
            f'<div>{blank_rows}</div></td>'
        )
    return (
        f'<div class="reminder" style="text-align:center;margin:6px 0">'
        f'<b>מחסן תרגילים:</b> &nbsp; {bank_html}</div>'
        f'<table class="drill" style="margin:6px 0"><tr>{"".join(tds)}</tr></table>'
    )


def who_am_i_riddle(clues, ans_label="המספר הוא:", width="2.8cm"):
    """כרטיסיית חידת 'מי אני?' מבוססת תכונות מתמטיות (כיתות א׳–ו׳).

    clues : רשימת רמזים (משפטי תנאי המצמצמים לאפשרות יחידה).
    """
    bullets = "".join(
        f'<div style="margin:2px 0">&bull; {c}</div>' for c in clues
    )
    return (
        f'<div class="frame teal" style="margin:6px 0;padding:8px 14px">'
        f'{bullets}'
        f'<div style="margin-top:6px"><b>{ans_label}</b> {blank(width)}</div>'
        f'</div>'
    )


def error_detection_box(student_name, work_html, ask_correct=True):
    """תבנית פעילות 'איתור טעות ונימוק' (כיתות ב׳–ו׳).

    student_name : שם התלמיד/ה הדמיוני/ת (למשל 'נועה', 'יואב').
    work_html    : הפתרון המוצג לבדיקה (HTML או איור `fig(...)` של `column_shown`).
    """
    rows = [
        f'<div class="sub"><b>א.</b> האם הפתרון של {student_name} נכון? '
        f'הקיפו: &nbsp; <b>כן</b> &nbsp;/&nbsp; <b>לא</b></div>',
        f'<div class="sub"><b>ב.</b> הסבירו מה הטעות או מדוע הפתרון נכון: '
        f'{blank("7.5cm")}</div>',
    ]
    if ask_correct:
        rows.append(
            f'<div class="sub"><b>ג.</b> כתבו את התרגיל והפתרון הנכון: '
            f'{blank("5.5cm")}</div>'
        )
    return (
        f'<div class="frame orange" style="margin:6px 0;padding:8px 12px">'
        f'<div><b>הפתרון של {student_name}:</b></div>'
        f'{work_html}'
        f'{"".join(rows)}'
        f'</div>'
    )


def function_table(inputs, outputs, in_title="מספר נכנס", out_title="מספר יוצא",
                   rule_prompt=True):
    """טבלת קלט–פלט (מכונת חוקיות בטבלה, כיתות ב׳–ו׳).

    inputs, outputs : רשימות ערכים שוות-אורך. ערך `None` או `""` מצויר כתא ריק להשלמה.
    """
    in_cells = [f"<th>{in_title}</th>"]
    out_cells = [f"<th>{out_title}</th>"]
    for iv, ov in zip(inputs, outputs):
        in_cells.append(f"<td>{ltr(str(iv))}</td>" if iv not in (None, "") else "<td>&nbsp;</td>")
        out_cells.append(f"<td>{ltr(str(ov))}</td>" if ov not in (None, "") else "<td>&nbsp;</td>")
    tbl = (
        '<table class="drill" style="width:auto;margin:6px auto">'
        f'<tr>{"".join(in_cells)}</tr>'
        f'<tr>{"".join(out_cells)}</tr>'
        '</table>'
    )
    if rule_prompt:
        tbl += f'<div class="sub">מה החוקיות בטבלה? {blank("6.5cm")}</div>'
    return tbl


def price_list_banner(items, grade="ג", title="מחירון החנות"):
    """סרט מחירון מאויר ונקי לבעיות מילוליות רב-שלביות של קנייה ועודף (כיתות ב׳–ו׳).

    items : רשימת זוגות `(שם_המוצר, מחיר_מספרי)`, למשל `[("מחברת", 8), ("קלמר", 25)]`.
    מתאים אוטומטית את כתיב הכסף לתקן הכיתה (`שקלים` בא׳–ב׳, `ש"ח` בג׳, `₪` בד׳–ו׳).
    """
    g = S._g(grade) if grade else "ג"
    cells = []
    for name, price in items:
        if g in ("א", "ב"):
            p_str = f'{ltr(str(price))} שְׁקָלִים'
        elif g == "ג":
            p_str = f'{ltr(str(price))} ש"ח'
        else:
            p_str = ltr(f"{price} ₪")
        cells.append(
            f'<td style="padding:6px 12px;text-align:center;background:#FFFDF5;'
            f'border:1.5px solid #E8821E">'
            f'<div style="font-weight:bold">{name}</div>'
            f'<div style="color:#C00000;font-weight:bold">{p_str}</div></td>'
        )
    return (
        f'<div style="margin:6px 0">'
        f'<div style="font-weight:bold;color:#1F6FC5;margin-bottom:3px">{title}:</div>'
        f'<table class="drill" style="width:auto;margin:0 auto"><tr>{"".join(cells)}</tr></table>'
        f'</div>'
    )


def magic_square_html(grid, target_sum=None):
    """ריבוע קסם (3×3 או 4×4) להשלמת סכומים שווים בשורות, בעמודות ובאלכסונים.

    grid : מטריצה דו-ממדית שבה תאים עם `None` או `""` נשארים ריקים להשלמה.
    """
    rows_html = []
    for row in grid:
        tds = []
        for val in row:
            if val in (None, ""):
                tds.append(
                    '<td style="width:44px;height:44px;text-align:center;'
                    'background:#FFFFFF;border:2px solid #159E8E">&nbsp;</td>'
                )
            else:
                tds.append(
                    f'<td style="width:44px;height:44px;text-align:center;'
                    f'background:#D7F0ED;border:2px solid #159E8E;font-weight:bold;'
                    f'font-size:1.15em">{ltr(str(val))}</td>'
                )
        rows_html.append("<tr>" + "".join(tds) + "</tr>")
    cap = (f'<div style="text-align:center;font-size:0.92em;margin-bottom:3px">'
           f'סכום כל שורה, עמודה ואלכסון: <b>{ltr(str(target_sum))}</b></div>'
           if target_sum is not None else "")
    return (
        f'<div style="margin:6px 0">{cap}'
        f'<table class="drill" dir="ltr" style="width:auto;margin:0 auto;'
        f'border-collapse:collapse">{"".join(rows_html)}</table></div>'
    )

