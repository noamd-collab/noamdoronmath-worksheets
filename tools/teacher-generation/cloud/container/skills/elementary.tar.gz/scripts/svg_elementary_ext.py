#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""svg_elementary_ext.py — רכיבי SVG משלימים ליסודי (v2.1).

מרחיב את `svg_elementary.py` בשמונה רכיבים שנדרשו בפועל בייצור מארזי
כיתה ג׳ ולא היו קיימים. כולם באותן מוסכמות: `<svg dir="ltr">` אטומי,
אין עברית בפנים, כל `<text>` נועץ `David Libre` במפורש (G45), ורוחב
חסום ל-650px (גלישה = השמטת גליפים שקטה).

    import svg_elementary as se
    import svg_elementary_ext as sx

| רכיב | הפער שהוא סוגר |
|---|---|
| `column_shown`   | `se.vertical_problem` מדפיס תמיד את התוצאה **הנכונה**, ולכן אי אפשר לשרטט איתו פתרון שגוי — והקטלוג דורש "איתור טעות" כמעט בכל יחידת פעולות חשבון |
| `column_missing` | ספרה מוסתרת בטור — "שאלה הפוכה" |
| `blank_column`   | רשת ריקה לכתיבה מסודרת; `bottom=` משאיר שורה עליונה ריקה כדי ששלב שני בשרשרת לא יחשוף את הראשון |
| `borrow_state`   | אלגוריתם הפריטה בקוד (כולל שרשרת אפסים) — האמת שהשרטוט חייב להציג |
| `column_borrow`  | **המחשת פריטה** בחיסור. לסקיל היה `carry=` לחיבור בלבד |
| `n_borrow_ops`   | ספירת פריטות נכונה (שרשרת אפסים = פריטה אחת) |
| `bar_model`      | תרשים רצועות לבעיה מילולית — לא היה כלל |
| `split_array`    | מערך מפוצל — מודל פירוק גורם בכפל |
| `group_model`    | קבוצות לחילוק, לשני המובנים (הכלה / חלקים שווים) |
| `unequal_shape`  | חלוקה **לא שווה** — המסיח של "חלקים שווים" בשברים |
| `frac_line`      | ישר 0–1 עם תוויות שבר מדורגות (בלי גליף שבר, בלי `a/b`) |
"""
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import svg_elementary as se  # noqa: E402

P = se.PALETTE


def _cells(n):
    """ספרות לתאים, פסיק האלפים צמוד לספרה שלפניו (מוסכמת הספרים)."""
    out = []
    for ch in f"{abs(int(n)):,}":
        if ch == "," and out:
            out[-1] += ","
        else:
            out.append(ch)
    return out


def column_shown(top, bottom, result, op="+", carries=None, cell=30, font=20,
                 grade=None,
                 result_color=None, show_grid=True):
    """תרגיל בטור עם תוצאה **מודפסת כפי שנמסרה** — גם אם היא שגויה.

    top, bottom : המחוברים.
    result      : המספר שנכתב בשורת התוצאה (int) — לא מחושב מחדש!
    carries     : רשימת ספרות המרה משמאל לימין מעל העמודות (0 = בלי תיבה),
                  או None. באורך מספר העמודות של המחוברים.
    result_color: צבע שורת התוצאה (ברירת מחדל: ink).
    """
    result_color = result_color or P["ink"]
    op = se._norm_op(op, grade)          # v2.2 — גליף לפי כיתה
    a, b, r = _cells(top), _cells(bottom), _cells(result)
    cols = max(len(a), len(b), len(r)) + 1          # +1 לעמודת הסימן
    cry_h = cell * 0.78 if carries else 0
    y0 = 4 + cry_h
    rows = 3
    w, h = cols * cell + 8, rows * cell + 8 + cry_h
    s = se.E(w, h)

    if carries:
        for j, cv in enumerate(carries):
            if not cv:
                continue
            x = 4 + (cols - len(carries) + j) * cell
            box_top, box_h = 4 + 1.5, cry_h - 3
            s.rect(x + 3, box_top, cell - 6, box_h, sw=1.1, rx=3, stroke="#2E9E2E")
            fs = font * 0.55
            s.text(str(cv), x + cell / 2, box_top + box_h / 2 + fs * 0.36,
                   size=fs, bold=True, color="#2E9E2E")

    if show_grid:
        for i in range(cols + 1):
            s.line((4 + i * cell, y0), (4 + i * cell, y0 + rows * cell),
                   width_=0.5, color=P["grid_blue"])
        for i in range(rows + 1):
            s.line((4, y0 + i * cell), (4 + cols * cell, y0 + i * cell),
                   width_=0.5, color=P["grid_blue"])

    def row(digs, y, sign=None, color=P["ink"]):
        off = cols - len(digs)
        for j, ch in enumerate(digs):
            s.text(ch, (off + j) * cell + 4 + cell / 2, y + cell - 8,
                   size=font, color=color)
        if sign:
            s.text(sign, 4 + cell / 2, y + cell - 8, size=font, color=color)

    row(a, y0)
    row(b, y0 + cell, sign=op)
    yline = y0 + 2 * cell
    s.line((4, yline), (4 + cols * cell, yline), width_=2)
    row(r, y0 + 2 * cell, color=result_color)
    return s.render()


def column_missing(top, bottom, result, hide, op="+", cell=30, font=20,
                   grade=None):
    """תרגיל בטור שבו ספרה אחת של המחובר העליון מוסתרת בתיבה ריקה.

    hide : אינדקס התא (0 = הספרה השמאלית ביותר של top) שיוחלף בתיבה.
    התוצאה מודפסת במלואה — התלמיד משחזר את הספרה החסרה (שאלה הפוכה).
    """
    op = se._norm_op(op, grade)          # v2.2 — גליף לפי כיתה
    a, b, r = _cells(top), _cells(bottom), _cells(result)
    if not 0 <= hide < len(a):
        raise ValueError(f"hide={hide} מחוץ לטווח ({len(a)} תאים ב-{top})")
    cols = max(len(a), len(b), len(r)) + 1
    y0, rows = 4, 3
    w, h = cols * cell + 8, rows * cell + 8
    s = se.E(w, h)
    for i in range(cols + 1):
        s.line((4 + i * cell, y0), (4 + i * cell, y0 + rows * cell), width_=0.5,
               color=P["grid_blue"])
    for i in range(rows + 1):
        s.line((4, y0 + i * cell), (4 + cols * cell, y0 + i * cell), width_=0.5,
               color=P["grid_blue"])

    def row(digs, y, sign=None, skip=None):
        off = cols - len(digs)
        for j, ch in enumerate(digs):
            x = (off + j) * cell + 4
            if skip is not None and j == skip:
                s.rect(x + 4, y + 4, cell - 8, cell - 8, fill="white",
                       stroke=P["orange"], sw=1.8, rx=3)
                continue
            s.text(ch, x + cell / 2, y + cell - 8, size=font, color=P["ink"])
        if sign:
            s.text(sign, 4 + cell / 2, y + cell - 8, size=font, color=P["ink"])

    row(a, y0, skip=hide)
    row(b, y0 + cell, sign=op)
    s.line((4, y0 + 2 * cell), (4 + cols * cell, y0 + 2 * cell), width_=2)
    row(r, y0 + 2 * cell)
    return s.render()


def blank_column(cols=4, rows=3, cell=30, sign="+", bottom=None, grade=None):
    """רשת טור ריקה — מקום לכתיבה מסודרת (דרישת הקטלוג ל-ג06:
    "מקום לכתיבה מסודרת"). התלמיד כותב לתוכה תרגיל שהוא עצמו המציא,
    ולכן היישור נאכף על ידי הרשת ולא על ידי כתב היד."""
    sign = se._norm_op(sign, grade) if sign else sign   # v2.2
    w, h = (cols + 1) * cell + 8, rows * cell + 8
    s = se.E(w, h)
    y0 = 4
    for i in range(cols + 2):
        s.line((4 + i * cell, y0), (4 + i * cell, y0 + rows * cell),
               width_=0.5, color=P["grid_blue"])
    for i in range(rows + 1):
        s.line((4, y0 + i * cell), (4 + (cols + 1) * cell, y0 + i * cell),
               width_=0.5, color=P["grid_blue"])
    if bottom is not None:
        # שורת המחובר התחתון מודפסת, השורה העליונה נשארת ריקה — כך שלב שני
        # בשרשרת אינו חושף את תוצאת השלב הראשון (נתפס בעיון חזותי).
        digs = _cells(bottom)
        off = (cols + 1) - len(digs)
        for j, ch in enumerate(digs):
            s.text(ch, (off + j) * cell + 4 + cell / 2, y0 + 2 * cell - 8,
                   size=20, color=P["ink"])
    if sign:
        s.text(sign, 4 + cell / 2, y0 + 2 * cell - 8, size=20, color=P["ink"])
    s.line((4, y0 + 2 * cell), (4 + (cols + 1) * cell, y0 + 2 * cell), width_=2)
    return s.render()


def borrow_state(top, bottom):
    """מצב הפריטה בפועל, עמודה-עמודה משמאל לימין.

    מחזיר (work, changed) כאשר work[i] הוא ערך העמודה **אחרי** הפריטה
    (יכול להיות 10–18 בעמודה שקיבלה), ו-changed[i] אומר אם הערך השתנה.
    זו האמת שהשרטוט חייב להציג — לא ניחוש של הכותב.
    """
    da = [int(c) for c in str(int(top))]
    db = [int(c) for c in str(int(bottom))]
    w = max(len(da), len(db))
    da = [0] * (w - len(da)) + da
    db = [0] * (w - len(db)) + db
    if int(top) < int(bottom):
        raise ValueError(f"חיסור ביסודי עם תוצאה שלילית: {top} − {bottom}")
    work = da[:]
    for i in range(w - 1, -1, -1):
        if work[i] < db[i]:
            k = i - 1
            while k >= 0 and work[k] == 0:
                work[k] = 9
                k -= 1
            if k < 0:
                raise ValueError("אין ממי לפרוט")
            work[k] -= 1
            work[i] += 10
    changed = [work[i] != da[i] for i in range(w)]
    return work, changed


def n_borrow_ops(top, bottom):
    """מספר פעולות הפריטה = כמה עמודות קיבלו 10 (שרשרת אפסים נספרת כאחת)."""
    work, _ = borrow_state(top, bottom)
    return sum(1 for v in work if v >= 10)


def column_borrow(top, bottom, answer="blank", cell=30, font=20,
                  show_borrow=True):
    """חיסור בטור עם **המחשת פריטה** במוסכמת ספרי הלימוד:
    הספרה שהשתנתה מסומנת בקו מחיקה, וערכה החדש נרשם קטן מעליה.

    answer: "blank" (מקום לתשובה) / True (מודפסת) / False (בלי שורת תשובה).
    show_borrow=False — התלמיד מסמן את הפריטה בעצמו.
    ‼ הערכים החדשים מגיעים מ-borrow_state (חישוב), לא מהכותב.
    """
    work, changed = borrow_state(top, bottom)
    a, b = _cells(top), _cells(bottom)
    res = int(top) - int(bottom)
    r = _cells(res)
    cols = max(len(a), len(b), len(r)) + 1
    # רצועת הפריטה נשמרת גם כש-show_borrow=False: בלעדיה אין לתלמיד מקום
    # מסומן לכתוב את הערך החדש, וההוראה "כתבו מעליה" נשארת בלי משבצת.
    ann_h = cell * 0.72 if any(changed) else 0
    y0 = 4 + ann_h
    rows = 2 + (1 if answer is not False else 0)
    w, h = cols * cell + 8, rows * cell + 8 + ann_h
    s = se.E(w, h)

    off_a = cols - len(a)
    if ann_h and show_borrow:
        for i, ch in enumerate(changed):
            if not ch:
                continue
            x = (off_a + i) * cell + 4
            s.text(str(work[i]), x + cell / 2, 4 + ann_h - 6, size=font * 0.6,
                   bold=True, color="#C00000")
            # קו מחיקה אלכסוני על הספרה המקורית
            s.line((x + 6, y0 + cell - 6), (x + cell - 6, y0 + 8),
                   width_=1.4, color="#C00000")

    for i in range(cols + 1):
        s.line((4 + i * cell, y0), (4 + i * cell, y0 + rows * cell),
               width_=0.5, color=P["grid_blue"])
    for i in range(rows + 1):
        s.line((4, y0 + i * cell), (4 + cols * cell, y0 + i * cell),
               width_=0.5, color=P["grid_blue"])

    def row(digs, y, sign=None):
        o = cols - len(digs)
        for j, chx in enumerate(digs):
            s.text(chx, (o + j) * cell + 4 + cell / 2, y + cell - 8,
                   size=font, color=P["ink"])
        if sign:
            s.text(sign, 4 + cell / 2, y + cell - 8, size=font, color=P["ink"])

    row(a, y0)
    row(b, y0 + cell, sign="−")
    s.line((4, y0 + 2 * cell), (4 + cols * cell, y0 + 2 * cell), width_=2)
    if answer is True:
        row(r, y0 + 2 * cell)
    return s.render()


def bar_model(bars, width=520, seg_h=34, gap=16, font=15, brace=None,
              labels_right=None):
    """תרשים רצועות (bar model) לבעיה מילולית — הייצוג הוויזואלי התקני
    לבעיות "כמה יותר / כמה בסך הכול" בכיתות היסוד.

    bars   : רשימת רצועות. כל רצועה = רשימת מקטעים (weight, text, kind)
             kind: "known" (תכלת) / "unknown" (כתום) / "empty" (לבן).
             האורך פרופורציוני ל-weight; הטקסט הוא מה שנראה (מספר או "?").
    brace  : (index_של_רצועה, "טקסט") — סוגר מעל הרצועה כולה.
    labels_right : רשימת תוויות קצרות (מספרים/אותיות לטיניות) לימין הרצועות.
                   ‼ אין עברית ב-SVG — תוויות עבריות באות מה-HTML שמסביב.

    כל הטקסטים הם מספרים/סימנים בלבד. רוחב חסום ל-650px.
    """
    FILL = {"known": P["blue_light"], "unknown": P["orange_light"],
            "empty": "#FFFFFF"}
    STROKE = {"known": P["blue"], "unknown": P["orange"], "empty": "#9AA5B1"}
    totals = [sum(w for w, _, _ in bar) for bar in bars]
    span = max(totals) if totals else 1
    left = 8
    right_pad = 46 if labels_right else 10
    if width + left + right_pad > 650:
        raise ValueError(f"bar_model: רוחב {width + left + right_pad} > 650px")
    # הסוגר מצויר **מתחת** לרצועה: מעליה התווית נופלת לתוך הרווח שבין
    # הרצועות ומתנגשת במספר של הרצועה שמעל (נתפס בעיון חזותי).
    brace_h = 24 if brace else 0
    h = len(bars) * (seg_h + gap) - gap + 12 + brace_h
    s = se.E(width + left + right_pad, h)
    y = 4
    bar_y = []
    for bi, bar in enumerate(bars):
        x = left
        bar_y.append(y)
        for w, text, kind in bar:
            seg_w = width * w / span
            s.rect(x, y, seg_w, seg_h, fill=FILL.get(kind, "#FFF"),
                   stroke=STROKE.get(kind, "#333"), sw=1.6, rx=3)
            if text:
                s.text(str(text), x + seg_w / 2, y + seg_h - 11, size=font,
                       bold=(kind == "unknown"), color=P["ink"])
            x += seg_w
        if labels_right and bi < len(labels_right) and labels_right[bi]:
            s.text(str(labels_right[bi]), x + 24, y + seg_h - 11,
                   size=font, color=P["ink"])
        y += seg_h + gap
    if brace:
        bi, text = brace
        w_tot = width * totals[bi] / span
        by = bar_y[bi] + seg_h + 5
        s.path(f"M {left} {by} L {left} {by+7} L {left+w_tot} {by+7} "
               f"L {left+w_tot} {by}", stroke=P["red"], sw=1.5)
        s.text(str(text), left + w_tot / 2, by + 7 + font, size=font,
               bold=True, color=P["red"])
    return s.render()


def split_array(rows, cols, split_after, dot_r=8, gap=None, horizontal=True,
                color_a=None, color_b=None):
    """מערך נקודות rows×cols מפוצל בקו מקווקו — המודל של **פירוק גורם**:
    `7 x 6` נראה כ-`5 x 6` ועוד `2 x 6`.

    split_after : אחרי כמה שורות (horizontal=True) או עמודות לפצל.
    שני החלקים בצבעים שונים — הפירוק מפורש חזותית ולא רק בטקסט.
    """
    if horizontal and not 0 < split_after < rows:
        raise ValueError(f"split_after={split_after} מחוץ לטווח 1..{rows-1}")
    if not horizontal and not 0 < split_after < cols:
        raise ValueError(f"split_after={split_after} מחוץ לטווח 1..{cols-1}")
    color_a = color_a or P["blue"]
    color_b = color_b or P["orange"]
    gap = gap or dot_r * 3
    pad = 10
    w = cols * gap + 2 * pad
    h = rows * gap + 2 * pad
    if w > 650:
        raise ValueError(f"split_array: רוחב {w}px > 650px")
    s = se.E(w, h)
    for i in range(rows):
        for j in range(cols):
            first = (i < split_after) if horizontal else (j < split_after)
            c = color_a if first else color_b
            s.circle(pad + j * gap + dot_r, pad + i * gap + dot_r, dot_r,
                     fill=c, stroke=c, sw=1.4)
    if horizontal:
        y = pad + split_after * gap - gap / 2 + dot_r
        s.line((pad - 4, y), (w - pad + 4, y), dashed=True, width_=1.8,
               color=P["red"])
    else:
        x = pad + split_after * gap - gap / 2 + dot_r
        s.line((x, pad - 4), (x, h - pad + 4), dashed=True, width_=1.8,
               color=P["red"])
    return s.render()


def group_model(n_groups, per_group, dot_r=7, gap=6, box_pad=7, box_gap=14,
                per_row=None, color=None):
    """מודל קבוצות לחילוק: `n_groups` מסגרות, בכל אחת `per_group` עיגולים.

    אותו רכיב משרת את **שני מובני החילוק** — ההבדל הוא בשאלה שנשאלת
    (דרישת הקטלוג: "שני מובני חילוק לפחות"):
      * הכלה  — "כמה קבוצות של 6 יש ב-24?"   (n_groups הוא הנעלם)
      * חלקים שווים — "24 מחולק ל-4 קבוצות, כמה בכל אחת?" (per_group נעלם)

    per_row : כמה עיגולים בשורה בתוך מסגרת (ברירת מחדל: עד 5).
    אין טקסט — התיוג בא מה-HTML שמסביב.
    """
    color = color or P["blue"]
    per_row = per_row or min(per_group, 5)
    rows = (per_group + per_row - 1) // per_row

    def dims(r):
        cell = 2 * r + gap
        bw = per_row * cell - gap + 2 * box_pad
        bh = rows * cell - gap + 2 * box_pad
        return cell, bw, bh, n_groups * bw + (n_groups - 1) * box_gap + 12

    # כיווץ אוטומטי לפני כישלון: שורה שגולשת מעל 650px גורמת ל-WeasyPrint
    # להשמיט גליפים בשקט, ולכן עדיף להקטין את העיגול מאשר לוותר על האיור.
    while dot_r > 4 and dims(dot_r)[3] > 650:
        dot_r -= 1
    cell, bw, bh, w = dims(dot_r)
    h = bh + 12
    if w > 650:
        raise ValueError(
            f"group_model({n_groups},{per_group}): רוחב {w:.0f}px > 650px "
            f"גם ב-dot_r=4 — פצלו לשתי שורות או הקטינו per_row")
    s = se.E(w, h)
    x0 = 6
    for g in range(n_groups):
        s.rect(x0, 6, bw, bh, fill="#FFFFFF", stroke=P["orange"], sw=1.6, rx=8)
        for k in range(per_group):
            r, c = divmod(k, per_row)
            cx = x0 + box_pad + c * cell + dot_r
            cy = 6 + box_pad + r * cell + dot_r
            s.circle(cx, cy, dot_r, fill=color, stroke=color, sw=1.2)
        x0 += bw + box_gap
    return s.render()


def unequal_shape(widths, shaded=(), w=280, h=54):
    """מלבן מחולק לחלקים **לא שווים** — מלכודת "ספירת חלקים בלי שוויון"
    (טעות היעד של ג11). fraction_shape שבסקיל מחלק תמיד לחלקים שווים
    ולכן אינו יכול לייצר את המסיח.

    widths : משקלים יחסיים של החלקים (למשל [3, 1, 1] — החלק הראשון גדול).
    shaded : אינדקסים של חלקים צבועים.
    """
    tot = sum(widths)
    s = se.E(w + 8, h + 8)
    x = 4
    for i, ww in enumerate(widths):
        seg = w * ww / tot
        fill = "#F2A65A" if i in shaded else "#FFFFFF"
        s.rect(x, 4, seg, h, fill=fill, stroke="#C46F1A", sw=1.6)
        x += seg
    return s.render()


def frac_line(denom, boxes=(), labels=(), cell=52, font=13):
    """ישר מספרים מ-0 עד 1 המחולק ל-denom חלקים שווים.

    labels : אינדקסים k שבהם תודפס תווית שבר k/denom (מדורגת: מונה,
             קו שבר, מכנה — אין גליף שבר, ואין `a/b` בשורה).
    boxes  : אינדקסים k שבהם תצויר תיבת השלמה ריקה.
    0 ו-1 מודפסים תמיד כשלמים. אין עברית ב-SVG.
    """
    w = denom * cell + 40
    if w > 650:
        raise ValueError(f"frac_line(denom={denom}): רוחב {w}px > 650px")
    base = 46
    s = se.E(w, base + 52)
    s.line((16, base), (w - 16, base), width_=2.2, color=P["blue"])
    for k in range(denom + 1):
        x = 20 + k * cell
        s.line((x, base - 7), (x, base + 7), width_=1.6, color=P["blue"])
        if k == 0 or k == denom:
            s.text("0" if k == 0 else "1", x, base + 24, size=font + 3,
                   color=P["ink"])
        elif k in boxes:
            s.rect(x - 15, base + 8, 30, 32, fill="white",
                   stroke=P["orange"], sw=1.5, rx=3)
        elif k in labels:
            s.text(str(k), x, base + 22, size=font, color=P["ink"])
            s.line((x - 9, base + 26), (x + 9, base + 26), width_=1.2,
                   color=P["ink"])
            s.text(str(denom), x, base + 40, size=font, color=P["ink"])
    return s.render()


# ===========================================================================
# v3.1-noam — איורים דידקטיים ומודלים חזותיים מקוריים לכיתות א׳–ו׳
# ===========================================================================

def part_whole_diagram(whole="", parts=("", ""), mode="tree", floors=None,
                       box_w=54, box_h=36, font=17):
    """תבנית 'שלם וחלקים' או 'בית המספר' (כיתות א׳–ג׳).

    mode="tree": תיבת 'שלם' עליונה המחוברת בקווים אל 2 (או 3) תיבות 'חלקים'
                 תחתונות. ערך ריק "" מצייר תיבת השלמה לבנה במסגרת כתומה.
    mode="house": 'בית המספר' — גג משולש שבו כתוב ה-whole, ומתחתיו קומות
                  של זוגות חדרים `floors=[(a1, b1), (a2, b2), ...]`.
    """
    if mode == "house":
        floors = list(floors or [parts])
        w = 2 * box_w + 24
        roof_h = 46
        h = roof_h + len(floors) * box_h + 16
        s = se.E(w, h)
        x0 = 12
        y_roof = 8 + roof_h
        s.path(f"M {x0:.1f} {y_roof:.1f} L {w/2:.1f} 8.0 L {w - x0:.1f} {y_roof:.1f} Z",
               fill=P["blue_light"], stroke=P["blue"], sw=2.0)
        if str(whole) != "":
            s.text(str(whole), w / 2, y_roof - 10, size=font + 1, bold=True,
                   color=P["ink"])
        for fi, (pa, pb) in enumerate(floors):
            y = y_roof + fi * box_h
            for ci, val in enumerate((pa, pb)):
                x = x0 + ci * box_w
                is_blank = (str(val) == "" or str(val) == "?")
                fill = "#FFFFFF" if is_blank else P["teal_light"]
                stroke = P["orange"] if is_blank else P["teal"]
                s.rect(x, y, box_w, box_h, fill=fill, stroke=stroke, sw=1.6)
                if str(val) not in ("", "?"):
                    s.text(str(val), x + box_w / 2, y + box_h - 11, size=font,
                           bold=True, color=P["ink"])
        return s.render()

    n_p = len(parts)
    gap = 22
    w = max(n_p * box_w + (n_p - 1) * gap + 24, box_w + 40)
    h = 2 * box_h + 44
    s = se.E(w, h)
    wx = (w - box_w) / 2
    wy = 8
    w_blank = (str(whole) == "" or str(whole) == "?")
    s.rect(wx, wy, box_w, box_h,
           fill="#FFFFFF" if w_blank else P["blue_light"],
           stroke=P["orange"] if w_blank else P["blue"], sw=2.0, rx=6)
    if str(whole) not in ("", "?"):
        s.text(str(whole), wx + box_w / 2, wy + box_h - 11, size=font + 1,
               bold=True, color=P["ink"])

    py = wy + box_h + 28
    total_pw = n_p * box_w + (n_p - 1) * gap
    px0 = (w - total_pw) / 2
    for i, pval in enumerate(parts):
        px = px0 + i * (box_w + gap)
        s.line((wx + box_w / 2, wy + box_h), (px + box_w / 2, py),
               width_=1.6, color=P["blue"])
        p_blank = (str(pval) == "" or str(pval) == "?")
        s.rect(px, py, box_w, box_h,
               fill="#FFFFFF" if p_blank else P["teal_light"],
               stroke=P["orange"] if p_blank else P["teal"], sw=1.8, rx=6)
        if str(pval) not in ("", "?"):
            s.text(str(pval), px + box_w / 2, py + box_h - 11, size=font,
                   bold=True, color=P["ink"])
    return s.render()


def number_line_jumps(start, jumps, step=1, end=None, hide_jumps=(),
                      hide_landings=(), cell=36, font=14):
    """ישר מספרים עם קשתות קפיצה מדורגות וראשי חץ (כיתות א׳–ו׳).

    start         : נקודת ההתחלה של הקפיצה הראשונה (או תחילת הציר אם מתאימה).
    jumps         : רשימת גדלי קפיצות, למשל `[10, 10, 4]` או `[-5, -3]`.
    hide_jumps    : אינדקסים של קפיצות שבהם גודל הקפיצה מעל הקשת מוחלף בתיבה ריקה.
    hide_landings : ערכי נקודות נחיתה שיוחלפו בתיבת השלמה מתחת לישר.
    """
    pts = [start]
    cur = start
    for j in jumps:
        cur = round(cur + j, 6)
        pts.append(cur)
    axis_min = min(pts)
    axis_max = end if end is not None else max(pts)
    vals = []
    v = axis_min
    while v <= axis_max + 1e-9:
        vals.append(round(v, 6))
        v += step
    n = len(vals)
    widest = max(len(f"{val:g}") for val in vals)
    cell = max(cell, int(widest * font * 0.65) + 12)
    while cell > 18 and (n * cell + 48) > 650:
        cell -= 2
    w = n * cell + 48
    if w > 650:
        raise ValueError(f"number_line_jumps: רוחב {w}px > 650px — הקטינו מספר שנתות או הגדילו step")
    base_y = 68
    h = base_y + 52
    s = se.E(w, h)

    def x_of(val):
        return 24 + ((val - axis_min) / step) * cell

    # ציר ראשי וחץ ימינה
    s.line((14, base_y), (w - 14, base_y), width_=2.2, color=P["blue"])
    s.path(f"M {w-14} {base_y} l -8 -5 l 0 10 z", fill=P["blue"], sw=0)

    landings_set = set(pts)
    hide_land_set = set(hide_landings)
    for val in vals:
        x = x_of(val)
        is_land = any(abs(val - p) < 1e-6 for p in landings_set)
        th = 12 if is_land else 7
        s.line((x, base_y - th / 2), (x, base_y + th / 2),
               width_=1.8 if is_land else 1.1, color=P["blue"])
        if any(abs(val - hl) < 1e-6 for hl in hide_land_set):
            s.rect(x - 17, base_y + 10, 34, 28, fill="#FFFFFF",
                   stroke=P["orange"], sw=1.6, rx=3)
        elif is_land or n <= 12:
            s.text(f"{val:g}", x, base_y + 26, size=font,
                   bold=is_land, color=P["ink"])

    # קשתות קפיצה מעל הציר
    for idx, j in enumerate(jumps):
        x1 = x_of(pts[idx])
        x2 = x_of(pts[idx + 1])
        xm = (x1 + x2) / 2
        arc_h = min(34, max(20, abs(x2 - x1) * 0.28))
        ym = base_y - 8 - arc_h
        s.path(f"M {x1:.1f} {base_y - 6:.1f} Q {xm:.1f} {ym:.1f} {x2:.1f} {base_y - 6:.1f}",
               fill="none", stroke=P["orange"], sw=1.8)
        # ראש חץ בנקודת הנחיתה
        dir_sign = 1 if x2 >= x1 else -1
        s.path(f"M {x2:.1f} {base_y - 6:.1f} l {-6*dir_sign:.1f} -6 l {-2*dir_sign:.1f} 7 z",
               fill=P["orange"], sw=0)
        lbl_y = base_y - 8 - arc_h * 0.58
        if idx in hide_jumps:
            s.rect(xm - 16, lbl_y - 22, 32, 22, fill="#FFFFFF",
                   stroke=P["orange"], sw=1.4, rx=3)
        else:
            sign_str = f"+{j:g}" if j >= 0 else f"\u2212{abs(j):g}"
            s.text(sign_str, xm, lbl_y - 6, size=font - 1, bold=True,
                   color=P["red"])
    return s.render()


def balance_scale(left_text="", right_text="", tilt=0, width=320, font=16):
    """מאזני כפות למשוואות מאוזנות ולאי-שוויונות (כיתות א׳–ו׳).

    tilt: 0 = מאוזן (שוויון), -1 = כף שמאל כבדה יותר (נמוכה יותר),
          1 = כף ימין כבדה יותר (נמוכה יותר).
    """
    w = width
    h = 136
    s = se.E(w, h)
    cx = w / 2
    base_y = h - 12
    # בסיס ומשולש נקודת משען
    s.rect(cx - 42, base_y - 8, 84, 8, fill=P["blue"], stroke="#175A9E", sw=1.4, rx=2)
    pivot_y = 68
    s.path(f"M {cx - 18:.1f} {base_y - 8:.1f} L {cx:.1f} {pivot_y:.1f} "
           f"L {cx + 18:.1f} {base_y - 8:.1f} Z",
           fill=P["teal"], stroke="#0E6E63", sw=1.6)
    dy = 12 * int(tilt)
    lx, rx = 64, w - 64
    ly, ry = pivot_y - dy, pivot_y + dy
    # קורת המאזניים
    s.line((lx, ly), (rx, ry), width_=3.0, color=P["ink"])
    s.circle(cx, pivot_y, 4.5, fill=P["gold"], stroke="#B8860B", sw=1.2)

    for px, py, txt in ((lx, ly, left_text), (rx, ry, right_text)):
        # חוטי תלייה וכף
        s.line((px, py), (px - 28, py + 22), width_=1.2, color="#666")
        s.line((px, py), (px + 28, py + 22), width_=1.2, color="#666")
        s.path(f"M {px - 36:.1f} {py + 22:.1f} L {px + 36:.1f} {py + 22:.1f} "
               f"L {px + 28:.1f} {py + 30:.1f} L {px - 28:.1f} {py + 30:.1f} Z",
               fill=P["gold"], stroke="#B8860B", sw=1.4)
        # תיבת משקולת על הכף
        bw, bh = 68, 30
        is_blank = (str(txt) in ("", "?"))
        s.rect(px - bw / 2, py - bh + 20, bw, bh,
               fill="#FFFFFF" if is_blank else P["blue_light"],
               stroke=P["orange"] if is_blank else P["blue"], sw=1.6, rx=4)
        if not is_blank:
            s.text(str(txt), px, py + 14, size=font, bold=True, color=P["ink"])
    return s.render()


def abacus(digits, cols=None, blank_boxes=False, col_w=52, font=16):
    """חשבונייה עמודות למבנה העשורי (כיתות א׳–ד׳).

    digits      : רשימת ספרות משמאל לימין (למשל `[2, 0, 4, 5]` עבור 2,045).
    blank_boxes : אם True, מצייר תיבות ריקות מתחת לעמודות להשלמת הספרות ע"י התלמיד.
    """
    digs = [int(d) for d in digits]
    ncols = cols or len(digs)
    digs = [0] * (ncols - len(digs)) + digs
    w = ncols * col_w + 32
    rod_h = 108
    base_y = 16 + rod_h
    h = base_y + 46
    s = se.E(w, h)
    bead_colors = (P["orange"], P["teal"], P["blue"], P["gold"], "#C00000", "#7A007A")
    # בסיס החשבונייה
    s.rect(12, base_y, w - 24, 10, fill="#FDEBC8", stroke="#B96A35", sw=1.6, rx=3)
    for ci, d in enumerate(digs):
        cx = 16 + ci * col_w + col_w / 2
        # מוט אנכי
        s.line((cx, 16), (cx, base_y), width_=2.4, color="#8B5A2B")
        # חרוזים מושחלים מלמטה למעלה
        col = bead_colors[(ncols - 1 - ci) % len(bead_colors)]
        for bi in range(d):
            by = base_y - 6 - bi * 10
            s.ellipse(cx, by, 14, 4.5, fill=col, stroke=P["ink"], sw=1.0)
        # תיבת ספרה מתחת לבסיס
        bx, by_box = cx - 16, base_y + 14
        s.rect(bx, by_box, 32, 26,
               fill="#FFFFFF" if blank_boxes else P["blue_light"],
               stroke=P["orange"] if blank_boxes else P["blue"], sw=1.5, rx=3)
        if not blank_boxes:
            s.text(str(d), cx, by_box + 19, size=font, bold=True, color=P["ink"])
    return s.render()


def area_grid_shape(grid_mask, cell=24, show_unit_legend=True):
    """מצולע על רשת משבצות לחישוב שטח והיקף (כיתות ג׳–ה׳).

    grid_mask : מטריצת 0/1 (רשימת שורות) שבה 1 מציין משבצת צבועה של הצורה.
    מדגיש אוטומטית את צלעות השפה החיצונית של הצורה כדי להקל גם על ספירת ההיקף.
    """
    rows = len(grid_mask)
    cols = len(grid_mask[0]) if rows else 0
    leg_w = (cell + 28) if show_unit_legend else 0
    w = cols * cell + 20 + leg_w
    h = max(rows * cell + 20, 56)
    if w > 650:
        raise ValueError(f"area_grid_shape: רוחב {w}px > 650px")
    s = se.E(w, h)
    x0, y0 = 10, 10
    # רשת ומילוי תאים
    for r in range(rows):
        for c in range(cols):
            x, y = x0 + c * cell, y0 + r * cell
            filled = bool(grid_mask[r][c])
            s.rect(x, y, cell, cell,
                   fill=P["teal_light"] if filled else "#FFFFFF",
                   stroke=P["grid_blue"], sw=0.8)
    # הדגשת קו המתאר (ההיקף) של הצורה
    for r in range(rows):
        for c in range(cols):
            if not grid_mask[r][c]:
                continue
            x, y = x0 + c * cell, y0 + r * cell
            if r == 0 or not grid_mask[r - 1][c]:
                s.line((x, y), (x + cell, y), width_=2.2, color=P["teal"])
            if r == rows - 1 or not grid_mask[r + 1][c]:
                s.line((x, y + cell), (x + cell, y + cell), width_=2.2, color=P["teal"])
            if c == 0 or not grid_mask[r][c - 1]:
                s.line((x, y), (x, y + cell), width_=2.2, color=P["teal"])
            if c == cols - 1 or not grid_mask[r][c + 1]:
                s.line((x + cell, y), (x + cell, y + cell), width_=2.2, color=P["teal"])

    if show_unit_legend:
        lx = x0 + cols * cell + 14
        ly = y0 + 6
        s.rect(lx, ly, cell, cell, fill=P["teal_light"], stroke=P["teal"], sw=1.8)
        s.text("1", lx + cell / 2, ly + cell - 6, size=12, bold=True, color=P["ink"])
    return s.render()


def multiplication_area_model(row_parts, col_parts, hide_cells=(),
                              hide_row_headers=(), hide_col_headers=(),
                              font=15):
    """מודל שטח (מלבן מפורק) לחוק הפילוג ולכפל רב-ספרתי (כיתות ג׳–ה׳).

    row_parts  : פירוק הגורם האנכי, למשל `[6]` או `[10, 4]`.
    col_parts  : פירוק הגורם האופקי, למשל `[20, 5]` או `[100, 30, 2]`.
    hide_cells : אוסף זוגות `(r, c)` שבהם המכפלה החלקית תוחלף בתיבת השלמה ריקה.
    """
    col_widths = [max(64, min(130, 52 + int(math.log10(max(v, 1))) * 22))
                  for v in col_parts]
    row_heights = [max(44, min(76, 40 + int(math.log10(max(v, 1))) * 14))
                   for v in row_parts]
    left_pad = 44
    top_pad = 34
    w = left_pad + sum(col_widths) + 14
    h = top_pad + sum(row_heights) + 14
    if w > 650:
        raise ValueError(f"multiplication_area_model: רוחב {w}px > 650px")
    s = se.E(w, h)
    fills = (P["blue_light"], P["orange_light"], P["teal_light"], P["yellow_light"])

    # כותרות עמודות (חלקי הגורם האופקי)
    cx = left_pad
    for ci, cp in enumerate(col_parts):
        cw = col_widths[ci]
        if ci in hide_col_headers:
            s.rect(cx + cw / 2 - 18, 4, 36, 24, fill="#FFFFFF",
                   stroke=P["orange"], sw=1.5, rx=3)
        else:
            s.text(str(cp), cx + cw / 2, top_pad - 8, size=font, bold=True,
                   color=P["blue"])
        cx += cw

    # כותרות שורות ותאי המלבן
    cy = top_pad
    for ri, rp in enumerate(row_parts):
        rh = row_heights[ri]
        if ri in hide_row_headers:
            s.rect(6, cy + rh / 2 - 12, 32, 24, fill="#FFFFFF",
                   stroke=P["orange"], sw=1.5, rx=3)
        else:
            s.text(str(rp), left_pad - 10, cy + rh / 2 + 5, size=font,
                   bold=True, anchor="end", color=P["blue"])
        cx = left_pad
        for ci, cp in enumerate(col_parts):
            cw = col_widths[ci]
            fill = fills[(ri * len(col_parts) + ci) % len(fills)]
            s.rect(cx, cy, cw, rh, fill=fill, stroke=P["ink"], sw=1.6)
            if (ri, ci) in hide_cells:
                s.rect(cx + cw / 2 - 22, cy + rh / 2 - 13, 44, 26,
                       fill="#FFFFFF", stroke=P["orange"], sw=1.6, rx=3)
            else:
                prod = rp * cp
                s.text(f"{prod:,}", cx + cw / 2, cy + rh / 2 + 6,
                       size=font, bold=True, color=P["ink"])
            cx += cw
        cy += rh
    return s.render()


def fraction_strip_wall(rows_spec, w=460, row_h=30, gap=8):
    """קיר שברים / רצועות שברים להשוואה, שקילות והרחבה (כיתות ג׳–ו׳).

    rows_spec : רשימת זוגות `(denom, shaded_count)`, למשל `[(1, 1), (2, 1), (4, 2), (8, 4)]`.
    כל רצועה באורך זהה `w` ומחולקת ל-`denom` חלקים שווים, מתוכם `shaded_count` צבועים.
    """
    if w + 16 > 650:
        raise ValueError(f"fraction_strip_wall: רוחב {w + 16}px > 650px")
    h = len(rows_spec) * (row_h + gap) - gap + 16
    s = se.E(w + 16, h)
    palette_cycle = (P["blue_light"], P["orange_light"], P["teal_light"], P["pink_light"])
    stroke_cycle = (P["blue"], P["orange"], P["teal"], P["purple"])
    for ri, (denom, shaded) in enumerate(rows_spec):
        y = 8 + ri * (row_h + gap)
        seg_w = w / denom
        fill_c = palette_cycle[ri % len(palette_cycle)]
        strk_c = stroke_cycle[ri % len(stroke_cycle)]
        for k in range(denom):
            x = 8 + k * seg_w
            s.rect(x, y, seg_w, row_h,
                   fill=fill_c if k < shaded else "#FFFFFF",
                   stroke=strk_c, sw=1.5)
            if denom <= 12:
                lbl = "1" if denom == 1 else f"1/{denom}"
                if denom == 1:
                    s.text("1", x + seg_w / 2, y + row_h - 9, size=14,
                           bold=True, color=P["ink"])
    return s.render()


def decimal_hundred_square(shaded, mode="hundredths", cell=15):
    """ריבוע המאה (10×10) או ריבוע העשיריות (10 פסים) לשברים עשרוניים ואחוזים (ד׳–ו׳).

    shaded : אם mode="hundredths" — מספר המאיות הצבועות (0..100);
             אם mode="tenths" — מספר העשיריות הצבועות (0..10).
    עמודות עשיריות שלמות נצבעות בתכלת, ומאיות בודדות בכתום-בהיר להמחשת המבנה העשרוני.
    """
    side = 10 * cell
    w = h = side + 16
    s = se.E(w, h)
    x0 = y0 = 8
    if mode == "tenths":
        for c in range(10):
            x = x0 + c * cell
            s.rect(x, y0, cell, side,
                   fill=P["blue_light"] if c < shaded else "#FFFFFF",
                   stroke=P["blue"], sw=1.2)
    else:
        full_tenths = shaded // 10
        rem_hundredths = shaded % 10
        for c in range(10):
            for r in range(10):
                x, y = x0 + c * cell, y0 + r * cell
                if c < full_tenths:
                    fill = P["blue_light"]
                elif c == full_tenths and r < rem_hundredths:
                    fill = P["orange_light"]
                else:
                    fill = "#FFFFFF"
                s.rect(x, y, cell, cell, fill=fill, stroke=P["grid_blue"], sw=0.7)
    s.rect(x0, y0, side, side, fill="none", stroke=P["blue"], sw=2.0)
    return s.render()


def thermometer_vertical(min_v=-10, max_v=30, step=5, current=15,
                         box_at=None, px_per_unit=3.8, font=12):
    """מד טמפרטורה אנכי (כיתות ב׳–ו׳) עם כתיב ישראלי למספרים מתחת לאפס.

    min_v, max_v : טווח הטמפרטורות על הסקאלה.
    current      : גובה עמודת הכספית האדומה (אם None — ללא מילוי).
    box_at       : אם נתון ערך טמפרטורה, מצייר לצידו תיבת השלמה ריקה.
    """
    span = max_v - min_v
    tube_h = span * px_per_unit
    w = 136
    top_y = 18
    bot_y = top_y + tube_h
    bulb_r = 16
    h = int(bot_y + bulb_r * 2 + 16)
    s = se.E(w, h)
    cx = 48
    tube_w = 16

    # צינור הזכוכית וגולת הכספית
    s.rect(cx - tube_w / 2, top_y - 6, tube_w, tube_h + 12,
           fill="#F8FAFC", stroke=P["blue"], sw=1.8, rx=8)
    if current is not None:
        clamped = max(min_v, min(max_v, current))
        merc_y = bot_y - (clamped - min_v) * px_per_unit
        s.rect(cx - tube_w / 2 + 3, merc_y, tube_w - 6, bot_y - merc_y + 8,
               fill=P["red"], stroke="none", sw=0)
    s.circle(cx, bot_y + bulb_r - 2, bulb_r, fill=P["red"], stroke="#8F0000", sw=1.8)

    # שנתות ותוויות (כתיב ישראלי לשליליים: (5-))
    v = min_v
    while v <= max_v + 1e-9:
        y = bot_y - (v - min_v) * px_per_unit
        s.line((cx + tube_w / 2, y), (cx + tube_w / 2 + 10, y),
               width_=1.6 if v == 0 else 1.2,
               color=P["red"] if v == 0 else P["ink"])
        if box_at is not None and abs(v - box_at) < 1e-6:
            s.rect(cx + tube_w / 2 + 14, y - 11, 38, 22,
                   fill="#FFFFFF", stroke=P["orange"], sw=1.5, rx=3)
        else:
            lbl = f"({abs(int(v))}-)" if v < 0 else f"{int(v)}°"
            s.text(lbl, cx + tube_w / 2 + 16, y + 4, size=font,
                   anchor="start", bold=(v == 0), color=P["ink"])
        v += step
    return s.render()


def measuring_cup(capacity_ml=1000, step_ml=100, filled_ml=600,
                  label_step=200, cup_w=110, cup_h=150, font=12):
    """משורה / כלי מדידה מדורג לנפח נוזלים (כיתות ב׳–ו׳).

    capacity_ml : קיבולת מרבית במ"ל (למשל 1000 מ"ל = 1 ליטר).
    filled_ml   : גובה הנוזל הצבוע בכלי (0 = ריק).
    """
    w = cup_w + 88
    h = cup_h + 32
    s = se.E(w, h)
    x0, y0 = 24, 16
    bot_y = y0 + cup_h

    # מילוי נוזל תכלת
    if filled_ml and filled_ml > 0:
        fh = cup_h * min(filled_ml, capacity_ml) / capacity_ml
        fy = bot_y - fh
        s.rect(x0 + 2, fy, cup_w - 4, fh - 1,
               fill=P["blue_light"], stroke="none", sw=0)
        s.line((x0 + 2, fy), (x0 + cup_w - 2, fy), width_=2.0, color=P["blue"])

    # דפנות הכלי, פיה וידית אחיזה
    s.path(f"M {x0 - 8:.1f} {y0:.1f} L {x0:.1f} {y0 + 10:.1f} "
           f"L {x0:.1f} {bot_y:.1f} L {x0 + cup_w:.1f} {bot_y:.1f} "
           f"L {x0 + cup_w:.1f} {y0:.1f}",
           fill="none", stroke=P["ink"], sw=2.2)
    s.path(f"M {x0 + cup_w:.1f} {y0 + 24:.1f} L {x0 + cup_w + 18:.1f} {y0 + 24:.1f} "
           f"L {x0 + cup_w + 18:.1f} {bot_y - 28:.1f} L {x0 + cup_w:.1f} {bot_y - 28:.1f}",
           fill="none", stroke=P["ink"], sw=2.0)

    # שנתות מדידה
    v = step_ml
    while v <= capacity_ml:
        y = bot_y - (v / capacity_ml) * (cup_h - 14)
        is_major = (v % label_step == 0)
        tick_len = 18 if is_major else 10
        s.line((x0 + cup_w - tick_len, y), (x0 + cup_w, y),
               width_=1.6 if is_major else 1.0, color=P["ink"])
        if is_major:
            s.text(str(v), x0 + cup_w - tick_len - 6, y + 4, size=font,
                   anchor="end", bold=True, color=P["ink"])
        v += step_ml
    return s.render()


def polyhedron_3d(kind="box", dims=(4, 3, 2), show_hidden=True, scale=26, font=13):
    """שרטוט גוף תלת-ממדי תקני עם מקצועות נסתרים מקווקווים ותוויות מידה (כיתות ד׳–ו׳).

    kind : "box" (תיבה), "cube" (קובייה), "triangular_prism" (מנסרה משולשת),
           "pyramid" (פירמידה מרובעת).
    dims : מידות המקצועות `(אורך, רוחב, גובה)` המודפסות לצד המקצועות.
    """
    if kind == "cube":
        a = dims[0] if dims else 4
        dims = (a, a, a)
    L, Wd, Hh = (dims + (3, 3, 3))[:3]
    fw = max(68, min(150, L * scale))
    fh = max(56, min(120, Hh * scale))
    dx = max(28, min(64, int(Wd * scale * 0.55)))
    dy = max(22, min(48, int(Wd * scale * 0.42)))

    w = fw + dx + 76
    h = fh + dy + 56
    s = se.E(w, h)
    x0 = 26
    y0 = 24 + dy

    if kind == "pyramid":
        # בסיס מקבילית + קודקוד ראש
        A = (x0, y0 + fh)
        B = (x0 + fw, y0 + fh)
        C = (x0 + fw + dx, y0 + fh - dy)
        D = (x0 + dx, y0 + fh - dy)
        apex = (x0 + fw / 2 + dx / 2, 18)
        if show_hidden:
            s.line(A, D, dashed=True, width_=1.3, color="#64748B")
            s.line(D, C, dashed=True, width_=1.3, color="#64748B")
            s.line(D, apex, dashed=True, width_=1.3, color="#64748B")
        s.line(A, B, width_=2.0, color=P["blue"])
        s.line(B, C, width_=2.0, color=P["blue"])
        s.line(A, apex, width_=2.0, color=P["blue"])
        s.line(B, apex, width_=2.0, color=P["blue"])
        s.line(C, apex, width_=2.0, color=P["blue"])
        s.text(str(L), (A[0] + B[0]) / 2, A[1] + 18, size=font, bold=True, color=P["ink"])
        s.text(str(Wd), B[0] + dx / 2 + 12, B[1] - dy / 2 + 6, size=font, bold=True, color=P["ink"])
        return s.render()

    if kind == "triangular_prism":
        # בסיס קדמי משולש + בסיס אחורי משולש מוסט
        A = (x0, y0 + fh)
        B = (x0 + fw, y0 + fh)
        T = (x0 + fw / 2, y0)
        A2 = (A[0] + dx, A[1] - dy)
        B2 = (B[0] + dx, B[1] - dy)
        T2 = (T[0] + dx, T[1] - dy)
        if show_hidden:
            s.line(A, A2, dashed=True, width_=1.3, color="#64748B")
            s.line(A2, B2, dashed=True, width_=1.3, color="#64748B")
            s.line(A2, T2, dashed=True, width_=1.3, color="#64748B")
        s.line(A, B, width_=2.0, color=P["blue"])
        s.line(B, T, width_=2.0, color=P["blue"])
        s.line(T, A, width_=2.0, color=P["blue"])
        s.line(B, B2, width_=2.0, color=P["blue"])
        s.line(T, T2, width_=2.0, color=P["blue"])
        s.line(B2, T2, width_=2.0, color=P["blue"])
        s.text(str(L), (A[0] + B[0]) / 2, A[1] + 18, size=font, bold=True, color=P["ink"])
        s.text(str(Wd), B[0] + dx / 2 + 12, B[1] - dy / 2 + 6, size=font, bold=True, color=P["ink"])
        return s.render()

    # תיבה / קובייה
    # פאה קדמית: (x0, y0) בגודל (fw, fh); פאה אחורית מוסטת ב-(+dx, -dy)
    FL = (x0, y0 + fh)
    FR = (x0 + fw, y0 + fh)
    TL = (x0, y0)
    TR = (x0 + fw, y0)
    BL = (x0 + dx, y0 + fh - dy)
    BR = (x0 + fw + dx, y0 + fh - dy)
    BTL = (x0 + dx, y0 - dy)
    BTR = (x0 + fw + dx, y0 - dy)

    # מילוי עדין לפאות הגלויות
    s.path(f"M {TL[0]} {TL[1]} L {TR[0]} {TR[1]} L {BTR[0]} {BTR[1]} L {BTL[0]} {BTL[1]} Z",
           fill=P["blue_light"], stroke="none", sw=0)
    s.path(f"M {TR[0]} {TR[1]} L {FR[0]} {FR[1]} L {BR[0]} {BR[1]} L {BTR[0]} {BTR[1]} Z",
           fill=P["teal_light"], stroke="none", sw=0)
    s.rect(x0, y0, fw, fh, fill="#F8FAFC", stroke="none", sw=0)

    if show_hidden:
        s.line(FL, BL, dashed=True, width_=1.4, color="#64748B")
        s.line(BL, BR, dashed=True, width_=1.4, color="#64748B")
        s.line(BL, BTL, dashed=True, width_=1.4, color="#64748B")

    # מקצועות גלויים
    s.rect(x0, y0, fw, fh, fill="none", stroke=P["blue"], sw=2.0)
    s.line(TL, BTL, width_=2.0, color=P["blue"])
    s.line(TR, BTR, width_=2.0, color=P["blue"])
    s.line(FR, BR, width_=2.0, color=P["blue"])
    s.line(BTL, BTR, width_=2.0, color=P["blue"])
    s.line(BTR, BR, width_=2.0, color=P["blue"])

    # תוויות מידה: אורך (למטה), רוחב (אלכסון ימני), גובה (שמאל)
    s.text(str(L), x0 + fw / 2, y0 + fh + 18, size=font, bold=True, color=P["ink"])
    s.text(str(Wd), x0 + fw + dx / 2 + 12, y0 + fh - dy / 2 + 6, size=font,
           bold=True, color=P["ink"])
    s.text(str(Hh), x0 - 10, y0 + fh / 2 + 5, size=font, bold=True,
           anchor="end", color=P["ink"])
    return s.render()


def matchstick_pattern(terms=(1, 2, 3), shape="squares", unit=28, font=13):
    """סדרת מבנים גאומטריים מגפרורים / נקודות לחקר חוקיות והכללה (כיתות ג׳–ו׳).

    terms : מספרי האיברים להצגה (למשל `(1, 2, 3)`).
    shape : "squares" (שורת ריבועים מחוברים בגפרורים),
            "triangles" (שורת משולשים מחוברים),
            "stairs" (מדרגות של עיגולים).
    """
    gap_between = 32
    term_widths = [max(unit, t * unit) + 16 for t in terms]
    w = sum(term_widths) + (len(terms) - 1) * gap_between + 24
    if w > 650:
        raise ValueError(f"matchstick_pattern: רוחב {w}px > 650px")
    max_t = max(terms)
    h = (max_t * 16 + 48) if shape == "stairs" else (unit + 54)
    s = se.E(w, h)
    x_cur = 12
    base_y = h - 30

    def stick(p1, p2):
        s.line(p1, p2, width_=2.6, color=P["orange"])
        s.circle(p1[0], p1[1], 2.6, fill=P["red"], sw=0)
        s.circle(p2[0], p2[1], 2.6, fill=P["red"], sw=0)

    for ti, t in enumerate(terms):
        tw = term_widths[ti]
        if shape == "squares":
            for k in range(t):
                sx0 = x_cur + 8 + k * unit
                sy0 = base_y - unit
                stick((sx0, sy0), (sx0 + unit, sy0))
                stick((sx0, base_y), (sx0 + unit, base_y))
                stick((sx0, sy0), (sx0, base_y))
                if k == t - 1:
                    stick((sx0 + unit, sy0), (sx0 + unit, base_y))
        elif shape == "triangles":
            for k in range(t):
                sx0 = x_cur + 8 + k * unit
                stick((sx0, base_y), (sx0 + unit, base_y))
                stick((sx0, base_y), (sx0 + unit / 2, base_y - unit * 0.86))
                stick((sx0 + unit / 2, base_y - unit * 0.86), (sx0 + unit, base_y))
        else:  # stairs
            dot_step = 14
            for r in range(1, t + 1):
                for c in range(r):
                    cx = x_cur + 12 + c * dot_step
                    cy = base_y - (t - r) * dot_step - 6
                    s.circle(cx, cy, 4.5, fill=P["blue"], stroke=P["blue"], sw=1.0)
        s.text(str(t), x_cur + tw / 2, h - 8, size=font, bold=True, color=P["ink"])
        x_cur += tw + gap_between
    return s.render()


def symmetry_grid(filled_cells, rows=6, cols_half=4, axis="vertical",
                  show_reflection=False, cell=24):
    """רשת משבצות עם ציר סימטריה מודגש להשלמת שיקוף (כיתות ג׳–ד׳).

    filled_cells    : רשימת תאים `(r, c)` בחצי השמאלי (`0 <= c < cols_half`) הצבועים מראש.
    show_reflection : אם True (לדף התשובות), צובע גם את התאים המשוקפים מעבר לציר.
    """
    total_cols = cols_half * 2 if axis == "vertical" else cols_half
    total_rows = rows if axis == "vertical" else rows * 2
    w = total_cols * cell + 20
    h = total_rows * cell + 20
    s = se.E(w, h)
    x0 = y0 = 10
    filled_set = set(filled_cells)
    reflected_set = set()
    if show_reflection:
        for r, c in filled_set:
            if axis == "vertical":
                reflected_set.add((r, total_cols - 1 - c))
            else:
                reflected_set.add((total_rows - 1 - r, c))

    for r in range(total_rows):
        for c in range(total_cols):
            x, y = x0 + c * cell, y0 + r * cell
            if (r, c) in filled_set:
                fill = P["blue_light"]
            elif (r, c) in reflected_set:
                fill = P["orange_light"]
            else:
                fill = "#FFFFFF"
            s.rect(x, y, cell, cell, fill=fill, stroke=P["grid_blue"], sw=0.9)

    # ציר השיקוף באדום מקווקו בולט
    if axis == "vertical":
        ax_x = x0 + cols_half * cell
        s.line((ax_x, y0 - 6), (ax_x, y0 + total_rows * cell + 6),
               dashed=True, width_=2.6, color=P["red"])
    else:
        ax_y = y0 + rows * cell
        s.line((x0 - 6, ax_y), (x0 + total_cols * cell + 6, ax_y),
               dashed=True, width_=2.6, color=P["red"])
    return s.render()


def number_web(center, branches=("", "", "", ""), w=280, h=156, font=16):
    """שמש / רשת ייצוגים של מספר במרכז ו-4 תיבות מסביב (כיתות א׳–ג׳)."""
    s = se.E(w, h)
    cx, cy = w / 2, h / 2
    bw, bh = 78, 36
    corners = [
        (12, 10),
        (w - 12 - bw, 10),
        (12, h - 10 - bh),
        (w - 12 - bw, h - 10 - bh),
    ]
    for i, (bx, by) in enumerate(corners):
        s.line((cx, cy), (bx + bw / 2, by + bh / 2), width_=1.8, color=P["purple"])
        val = branches[i] if i < len(branches) else ""
        is_blank = (str(val) in ("", "?"))
        s.rect(bx, by, bw, bh,
               fill="#FFFFFF" if is_blank else P["blue_light"],
               stroke=P["orange"] if is_blank else P["blue"], sw=1.6, rx=5)
        if not is_blank:
            s.text(str(val), bx + bw / 2, by + bh - 11, size=font - 1,
                   bold=True, color=P["ink"])
    s.circle(cx, cy, 22, fill=P["yellow_light"], stroke=P["orange"], sw=2.2)
    s.text(str(center), cx, cy + 6, size=font + 4, bold=True, color=P["red"])
    return s.render()


def bead_string(total=10, group_size=5, circled=(), r=11, gap=6):
    """שרשרת חרוזים דו-צבעונית בקבוצות של 5 (כיתות א׳–ב׳)."""
    step = 2 * r + gap
    w = total * step + 28
    if w > 650:
        raise ValueError(f"bead_string(total={total}): רוחב {w}px > 650px")
    h = 2 * r + 28
    s = se.E(w, h)
    cy = h / 2
    s.line((8, cy), (w - 8, cy), width_=2.0, color=P["ink"])
    circled_set = set(circled)
    for i in range(total):
        cx = 14 + r + i * step
        in_even_grp = ((i // group_size) % 2 == 0)
        fill = P["orange"] if in_even_grp else P["blue"]
        stroke = "#B4650F" if in_even_grp else "#175A9E"
        s.circle(cx, cy, r, fill=fill, stroke=stroke, sw=1.5)
        if (i + 1) in circled_set:
            s.circle(cx, cy, r + 4, fill="none", stroke=P["red"], sw=2.0)
    return s.render()


def subtraction_crossed_items(kind="cookie", total=8, crossed=3, per_row=5, scale=1.0):
    """איור חיסור מוחשי: מצייר total פריטים ומוחק ב-X אדום את crossed האחרונים (א׳–ב׳)."""
    if kind not in se._OBJECT_KINDS:
        raise ValueError(f"subtraction_crossed_items: kind לא מוכר {kind!r}")
    cell_w, cell_h = 44 * scale, 48 * scale
    r = 15 * scale
    cols = min(total, per_row)
    rows = math.ceil(total / cols)
    w = int(cols * cell_w + 24)
    h = int(rows * cell_h + 24)
    s = se.E(w, h)
    s.rect(4, 4, w - 8, h - 8, fill=P["blue_light"], stroke=P["blue"], sw=1.4, rx=10)
    for i in range(total):
        row, col = divmod(i, cols)
        cx = 12 + col * cell_w + cell_w / 2
        cy = 12 + row * cell_h + cell_h / 2
        se._draw_item(s, kind, cx, cy, r, i)
        if i >= total - crossed:
            d = r * 0.95
            s.line((cx - d, cy - d), (cx + d, cy + d), width_=2.4, color=P["red"])
            s.line((cx - d, cy + d), (cx + d, cy - d), width_=2.4, color=P["red"])
    return s.render()


def factor_tree(top_val, pair_l1=("", ""), leaves_l2=None, font=15):
    """עץ גורמים / פירוק כפלי דו-שכבתי או תלת-שכבתי (כיתות ג׳–ו׳)."""
    has_l2 = bool(leaves_l2)
    w = 240 if has_l2 else 180
    h = 162 if has_l2 else 108
    s = se.E(w, h)
    cx = w / 2
    # קודקוד עליון (מלבן)
    bw, bh = 58, 30
    top_blank = (str(top_val) in ("", "?"))
    s.rect(cx - bw / 2, 8, bw, bh,
           fill="#FFFFFF" if top_blank else P["blue_light"],
           stroke=P["orange"] if top_blank else P["blue"], sw=1.8, rx=4)
    if not top_blank:
        s.text(str(top_val), cx, 8 + bh - 9, size=font + 1, bold=True, color=P["ink"])

    # שכבה 1: שני עיגולים
    y1 = 76
    x1_l, x1_r = (cx - 52, cx + 52) if has_l2 else (cx - 42, cx + 42)
    for x1, val1 in ((x1_l, pair_l1[0]), (x1_r, pair_l1[1])):
        s.line((cx, 8 + bh), (x1, y1 - 18), width_=1.6, color=P["ink"])
        b1 = (str(val1) in ("", "?"))
        s.circle(x1, y1, 18,
                 fill="#FFFFFF" if b1 else P["teal_light"],
                 stroke=P["orange"] if b1 else P["teal"], sw=1.7)
        if not b1:
            s.text(str(val1), x1, y1 + 5, size=font, bold=True, color=P["ink"])

    # שכבה 2: ארבעה עלים
    if has_l2:
        y2 = 136
        xs2 = (x1_l - 28, x1_l + 28, x1_r - 28, x1_r + 28)
        parents = (x1_l, x1_l, x1_r, x1_r)
        for idx in range(min(4, len(leaves_l2))):
            v2 = leaves_l2[idx]
            if v2 is None:
                continue
            px, x2 = parents[idx], xs2[idx]
            s.line((px, y1 + 18), (x2, y2 - 16), width_=1.5, color=P["ink"])
            b2 = (str(v2) in ("", "?"))
            s.circle(x2, y2, 16,
                     fill="#FFFFFF" if b2 else P["orange_light"],
                     stroke=P["orange"], sw=1.6)
            if not b2:
                s.text(str(v2), x2, y2 + 5, size=font - 1, bold=True, color=P["ink"])
    return s.render()


def unit_cube_structure(heights_grid, scale=20):
    """מבנה תלת-ממדי מקוביות יחידה לספירת נפח ושכבות (כיתות ד׳–ו׳).

    heights_grid : מטריצה דו-ממדית (רשימת שורות מאחור לקדימה) של מספר הקוביות
                   בערימה בכל תא `(r, c)`, למשל `[[2, 2, 1], [1, 1, 0]]`.
    """
    rows = len(heights_grid)
    cols = len(heights_grid[0]) if rows else 0
    max_h = max((max(r) for r in heights_grid), default=1)
    u = scale
    dx, dy = int(u * 0.45), int(u * 0.35)
    w = cols * u + rows * dx + 36
    h = max_h * u + rows * dy + 36
    s = se.E(w, h)
    x_origin = 16 + (rows - 1) * dx
    y_origin = h - 16 - (rows - 1) * dy

    def draw_single_cube(fx, fy):
        # פאה קדמית: [fx, fx+u] x [fy-u, fy]
        s.rect(fx, fy - u, u, u, fill=P["blue_light"], stroke=P["blue"], sw=1.2)
        # פאה עליונה
        s.path(f"M {fx} {fy - u} L {fx + dx} {fy - u - dy} "
               f"L {fx + u + dx} {fy - u - dy} L {fx + u} {fy - u} Z",
               fill="#FFF3C9", stroke=P["blue"], sw=1.2)
        # פאה ימנית
        s.path(f"M {fx + u} {fy - u} L {fx + u + dx} {fy - u - dy} "
               f"L {fx + u + dx} {fy - dy} L {fx + u} {fy} Z",
               fill=P["teal_light"], stroke=P["blue"], sw=1.2)

    # מציירים מאחור לקדימה, משמאל לימין, מלמטה למעלה (אלגוריתם הצייר)
    for r in range(rows):
        for c in range(cols):
            stack = int(heights_grid[r][c])
            for k in range(stack):
                fx = x_origin + c * u - r * dx
                fy = y_origin + r * dy - k * u
                draw_single_cube(fx, fy)
    return s.render()


def triangle_with_height(kind="acute", base_label="", height_label="",
                         show_right_angle=True, font=14):
    """משולש עם בסיס מודגש בכחול וגובה מודגש באדום (כיתות ה׳–ו׳).

    kind : "acute" (גובה פנימי), "right" (ניצב כגובה), "obtuse" (גובה חיצוני עם המשך בסיס מקווקו).
    """
    w, h = 230, 148
    s = se.E(w, h)
    by = 114
    x_left = 28
    x_right = 158 if kind == "obtuse" else 196
    apex_x = 108 if kind == "acute" else (x_left if kind == "right" else 198)
    apex_y = 22

    # משולש
    s.path(f"M {x_left} {by} L {x_right} {by} L {apex_x} {apex_y} Z",
           fill="#F8FAFC", stroke=P["ink"], sw=1.8)
    # הדגשת הבסיס בכחול
    s.line((x_left, by), (x_right, by), width_=2.8, color=P["blue"])
    if kind == "obtuse":
        s.line((x_right, by), (apex_x, by), dashed=True, width_=1.5, color=P["blue"])

    # הגובה באדום + סימן זווית ישרה
    s.line((apex_x, apex_y), (apex_x, by), width_=2.4, color=P["red"])
    if show_right_angle:
        sq = 9
        dir_x = -sq if apex_x > x_left else sq
        s.path(f"M {apex_x + dir_x} {by} L {apex_x + dir_x} {by - sq} L {apex_x} {by - sq}",
               fill="none", stroke=P["red"], sw=1.3)

    if base_label:
        s.text(str(base_label), (x_left + x_right) / 2, by + 20,
               size=font, bold=True, color=P["blue"])
    if height_label:
        hx = apex_x + (14 if kind != "Acute" else 12)
        s.text(str(height_label), hx, (apex_y + by) / 2 + 4,
               size=font, bold=True, anchor="start", color=P["red"])
    return s.render()


def dice_pair(d1=4, d2=5, side=52):
    """זוג קוביות משחק מנוקדות (1–6) לחיבור, כפל והסתברות (כיתות א׳–ו׳)."""
    vals = (d1,) if d2 is None else (d1, d2)
    gap = 16
    w = len(vals) * side + (len(vals) - 1) * gap + 20
    h = side + 20
    s = se.E(w, h)
    pip_coords = {
        1: [(0.5, 0.5)],
        2: [(0.26, 0.26), (0.74, 0.74)],
        3: [(0.24, 0.24), (0.5, 0.5), (0.76, 0.76)],
        4: [(0.26, 0.26), (0.74, 0.26), (0.26, 0.74), (0.74, 0.74)],
        5: [(0.24, 0.24), (0.76, 0.24), (0.5, 0.5), (0.24, 0.76), (0.76, 0.76)],
        6: [(0.26, 0.22), (0.74, 0.22), (0.26, 0.5), (0.74, 0.5), (0.26, 0.78), (0.74, 0.78)],
    }
    for idx, v in enumerate(vals):
        x0 = 10 + idx * (side + gap)
        y0 = 10
        s.rect(x0, y0, side, side, fill=P["yellow_light"], stroke="#B8860B", sw=2.0, rx=8)
        for px, py in pip_coords.get(int(v), ()):
            s.circle(x0 + px * side, y0 + py * side, 4.5, fill=P["ink"], sw=0)
    return s.render()


def spinner_wheel(sectors=8, shaded=(0, 2, 4, 6), dots=(), r=54):
    """גלגל מסתובב מחולק לגזרות שוות לשברים, סימטריה סיבובית והסתברות (ב׳–ו׳)."""
    w = h = 2 * r + 20
    cx = cy = w / 2
    s = se.E(w, h)
    shaded_set = set(shaded)
    dots_set = set(dots)
    for i in range(sectors):
        a0 = math.pi / 2 - 2 * math.pi * i / sectors
        a1 = math.pi / 2 - 2 * math.pi * (i + 1) / sectors
        x0, y0 = cx + r * math.cos(a0), cy - r * math.sin(a0)
        x1, y1 = cx + r * math.cos(a1), cy - r * math.sin(a1)
        fill = P["blue_light"] if i in shaded_set else "#FFFFFF"
        s.path(f"M {cx:.1f} {cy:.1f} L {x0:.1f} {y0:.1f} "
               f"A {r} {r} 0 0 1 {x1:.1f} {y1:.1f} Z",
               fill=fill, stroke=P["blue"], sw=1.5)
        if i in dots_set:
            am = (a0 + a1) / 2
            s.circle(cx + r * 0.62 * math.cos(am), cy - r * 0.62 * math.sin(am),
                     4.2, fill=P["red"], sw=0)
    s.circle(cx, cy, r, fill="none", stroke=P["blue"], sw=2.0)
    return s.render()


