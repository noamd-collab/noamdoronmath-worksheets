#!/usr/bin/env python3
"""svg_elementary.py — ספריית רכיבי SVG לדפי עבודה לבית ספר יסודי (א׳–ו׳).

משלימה את svg_geometry.py (גאומטריה לחטיבה) — כאן הרכיבים של היסודי:
ישר מספרים, תרגיל בטור על רשת משבצות, שעון, מטבעות, מסגרת-עשר, דיאגרמת
עמודות, מכונת פעולות, חילוק ארוך.

v2.0 "צבע וחיים": כל הרכיבים צבעוניים (פלטת הבית הקנונית PALETTE, hex
קשיח — בלי CSS var), בלי לשבור חתימות: כל פרמטרי הצבע אופציונליים עם
ברירות-מחדל. שני רכיבי איור פונקציונלי חדשים: object_groups (קבוצות
עצמים לספירה/חיבור/כפל) ו-place_value_blocks (קוביות דינס למבנה המספר).

כל הרכיבים מחזירים <svg dir="ltr"> אטומי (בטוח ל-bidi) להטמעה ב-HTML.
מספרים בלבד על הרכיבים — טקסט עברי עובר ל-HTML מסביב (כמו ב-svg_geometry).

דוגמה:
    from svg_elementary import number_line, vertical_problem, clock_face
    print(number_line(156, 161, blanks=[159, 160]))
    print(vertical_problem(845, 3725, op="−", answer="blank"))
    print(clock_face(3, 30))
"""
import math


# פלטת הבית הקנונית (v2.0) — hex קשיח בלבד (WeasyPrint: בלי var()).
PALETTE = {
    "red": "#C00000",        # כותרות (מעוגן)
    "green": "#2E9E2E",
    "purple": "#7A007A",
    "magenta": "#F090F0",    # מנוף כיתה ב׳ (מעוגן)
    "blue": "#1F6FC5",
    "blue_light": "#DCECFB",
    "orange": "#E8821E",
    "orange_light": "#FDE9D2",
    "teal": "#159E8E",
    "teal_light": "#D7F0ED",
    "gold": "#F5C542",
    "yellow_light": "#FFF3C9",
    "pink_light": "#FBE4F7",
    "grid_blue": "#B7D4EE",
    "ink": "#1A1A2E",        # שחור-כמעט לספרות/טקסט
}


def _norm_op(op, grade=None):
    """נרמול גליף פעולה לתקן היסודי (v2.2, `lib/signs.py`).

    ‼ למה זה כאן: `vertical_problem` הדפיסה **כל** מה שנמסר לה. דף שנכתב
    בהרגלי החטיבה (`op="·"`) או במקלדת (`op="*"`) יצא נראה-תקין, והשער
    היחיד שראה טקסט (`check_worksheet`) בדק ÷ בלבד. עכשיו הגליף נקבע
    מהכיתה, ולא ממי שכתב את השורה.
    """
    import os as _os
    import sys as _sys
    _sys.path.insert(0, _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "lib"))
    import signs as _S
    if op in ("-", "\u2212"):
        return _S.MINUS
    if op == "+":
        return _S.PLUS
    if op in (":", "/"):
        return _S.COLON if grade is None else _S.DIV(grade)
    if op in ("*", "x", "X", "\u00d7", "\u00b7", "\u2219", "\u22c5"):
        if grade is None:
            if op in ("\u00b7", "\u2219", "\u22c5", "*", "X"):
                raise ValueError(
                    f"svg_elementary: גליף כפל אסור ביסודי {op!r} — "
                    f"העבירו grade= (ב׳→× ; ג׳–ו׳→x) או op='x'")
            return op
        return _S.MUL(grade)
    return op


def _esc(t):
    return str(t).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


class E:
    """בונא SVG מינימלי באותן מוסכמות של svg_geometry.Svg."""

    def __init__(self, w, h):
        self.w, self.h, self.parts = w, h, []

    def line(self, p, q, dashed=False, width_=1.5, color="black"):
        dash = ' stroke-dasharray="5,4"' if dashed else ""
        self.parts.append(
            f'<line x1="{p[0]:.1f}" y1="{p[1]:.1f}" x2="{q[0]:.1f}" y2="{q[1]:.1f}"'
            f' stroke="{color}" stroke-width="{width_}"{dash}/>')

    def rect(self, x, y, w, h, fill="none", stroke="black", sw=1.4, rx=0):
        r = f' rx="{rx}"' if rx else ""
        self.parts.append(
            f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}"'
            f' fill="{fill}" stroke="{stroke}" stroke-width="{sw}"{r}/>')

    def circle(self, x, y, r, fill="none", stroke="black", sw=1.4):
        self.parts.append(
            f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{r:.1f}"'
            f' fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')

    def ellipse(self, x, y, rx, ry, fill="none", stroke="black", sw=1.4, rot=0):
        t = f' transform="rotate({rot:.1f} {x:.1f} {y:.1f})"' if rot else ""
        self.parts.append(
            f'<ellipse cx="{x:.1f}" cy="{y:.1f}" rx="{rx:.1f}" ry="{ry:.1f}"'
            f' fill="{fill}" stroke="{stroke}" stroke-width="{sw}"{t}/>')

    def text(self, t, x, y, size=13, bold=False, anchor="middle", color="black",
             rtl=False):
        fw = ' font-weight="bold"' if bold else ""
        # direction=ltr על כל טקסט מספרי: ברכיבים יש מספרים/סימנים בלבד
        # (עברית → HTML), ובלי זה ה-bidi של העמוד ה-RTL הופך "+5" ל-"5+".
        # rtl=True — רק לשני יוצאי-הדופן של עברית ב-SVG (coins, כותרות
        # vertical_problem). WeasyPrint מתעלם מ-direction ב-<text> ומצייר
        # בסדר לוגי משמאל-לימין, כך שמילה עברית יוצאת הפוכה ("יחידות" →
        # "תודיחי" — נתפס בעיון חזותי, אוגוסט 2026). הפתרון היחיד שעובד:
        # היפוך ידני לסדר חזותי. מגבלה: בלי ניקוד בטקסט rtl של SVG
        # (ההיפוך התווי ישבור את מיקומו) — כותרות הטור אינן מנוקדות.
        if rtl:
            t = str(t)[::-1]
        self.parts.append(
            f'<text x="{x:.1f}" y="{y:.1f}" font-size="{size}" text-anchor="{anchor}"'
            f' direction="ltr" unicode-bidi="embed"'
            # font-family="inherit" לא יורש @font-face ב-WeasyPrint — ספרות
            # ה-SVG נפלו לפונט מערכת (Noto/DejaVu, נמדד אמפירית: 19 תווים
            # חמקו מתחת לסף G45=20). חובה לנעוץ את David Libre במפורש.
            f' font-family="David Libre" fill="{color}"{fw}>{_esc(t)}</text>')

    def path(self, d, fill="none", stroke="black", sw=1.4):
        self.parts.append(f'<path d="{d}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')

    def render(self):
        body = "\n  ".join(self.parts)
        return (f'<svg width="{self.w}" height="{self.h}" dir="ltr" '
                f'xmlns="http://www.w3.org/2000/svg">\n  {body}\n</svg>')


# ---------------------------------------------------------------- ישר מספרים
def number_line(start, end, step=1, blanks=(), above=(), tick_h=14,
                cell=26, box_side=34, font=15, width=None,
                axis_color=PALETTE["blue"], box_color=PALETTE["orange"],
                label_color=PALETTE["ink"]):
    """ישר מספרים אופקי מ-start עד end בצעדי step.
    blanks: ערכים שבמקומם משורטטת תיבת השלמה ריקה מעל הישר (במקום המספר).
    above:  ערכים שמתויגים מעל (ברירת מחדל: כולם מתויגים מתחת).
    צבעי ברירת-מחדל (v2.0): ציר וחץ כחולים, תיבות השלמה במסגרת כתומה,
    תוויות ink. ניתן לעקוף עם axis_color/box_color/label_color.
    מחזיר <svg>. RTL: הערכים עולים שמאלה? לא — ישר מספרים עולה לימין (LTR),
    בדיוק כמו בספרי הלימוד הישראליים."""
    vals = []
    v = start
    while v <= end + 1e-9:
        vals.append(round(v, 6))
        v += step
    n = len(vals)
    # תיקון התנגשות תוויות (נתפס בעיון חזותי, אוגוסט 2026): תווית בת 3+
    # ספרות רחבה מ-cell=26 — "156157" נצמד. מרווח מינימלי: רוחב התווית
    # הארוכה (≈0.62em לספרה, כולל פסיק-אלפים) + 8px אוויר.
    widest = max(len(f"{val:g}") + (len(f"{val:g}") - 1) // 3 for val in vals)
    cell = max(cell, int(widest * font * 0.62) + 8)
    w = width or (n * cell + 40)
    base_y = box_side + 24
    s = E(w, base_y + 44)
    s.line((14, base_y), (w - 14, base_y), width_=2.2, color=axis_color)
    # חץ קטן בקצה (כיוון הגדילה — שמאלה? לא: שמאל=גדול בישר העברי? תקן: חץ ימינה)
    s.path(f"M {w-14} {base_y} l -8 -5 l 0 10 z", fill=axis_color, sw=0)
    for i, v in enumerate(vals):
        x = 20 + i * cell
        s.line((x, base_y - tick_h / 2), (x, base_y + tick_h / 2), width_=1.6,
               color=axis_color)
        if v in blanks:
            s.rect(x - box_side / 2, 6, box_side, box_side, fill="white",
                   stroke=box_color, sw=1.5)
            s.line((x, 6 + box_side), (x, base_y - tick_h / 2), width_=1.1)
        elif v in above:
            s.text(f"{v:g}", x, 6 + box_side - 8, size=font, color=label_color)
            s.line((x, 6 + box_side - 2), (x, base_y - tick_h / 2), width_=1.1)
        else:
            s.text(f"{v:g}", x, base_y + tick_h + font + 2, size=font,
                   color=label_color)
    return s.render()


# ------------------------------------------------------- תרגיל בטור (משבצות)
def _digits_with_sep(n):
    """רשימת תאים לתרגיל בטור: כל תא = ספרה אחת, והפסיק של האלפים צמוד לספרה
    שלפניו באותו תא ('3,') — לא תא נפרד (מוסכמת ספרי הלימוד: ספרה למשבצת)."""
    grouped = f"{abs(n):,}"
    cells = []
    for ch in grouped:
        if ch == "," and cells:
            cells[-1] += ","
        else:
            cells.append(ch)
    return cells  # 1845 -> ['1,', '8', '4', '5'] ; 46 -> ['4', '6']


def vertical_problem(top, bottom, op="+", answer="blank", cell=30,
                     show_grid=True, font=20, sep_comma=True,
                     headers=None, carry=None, grade=None,
                     grid_color=PALETTE["grid_blue"],
                     digit_color=PALETTE["ink"],
                     header_color=PALETTE["blue"]):
    """תרגיל בטור על רשת משבצות (חיבור/חיסור/כפל).
    top, bottom: מספרים שלמים. op: '+' / '-' / '*' — הגליף **נקבע לפי
    `grade=`** (v2.2): ב׳ → `×` · ג׳–ו׳ → `x` · מינוס תמיד U+2212.
    בלי `grade=` נשמרת ההתנהגות הישנה, אך `·` `∙` `*` `X` נחסמים.
    answer: 'blank' (שורת קו לתשובה), True (מודפסת), False (בלי שורת תשובה).
    headers: כותרות עמודות מימין-לשמאל, למשל headers=("יחידות","עשרות") —
      מודפסות קטן מעל עמודות הספרות (כמו בספרי כיתה ב׳).
    carry: "auto" (שורת המרות אוטומטית לחיבור — הספרה מעל העמודה הבאה,
      כמו "שורת ההמרות" בספר) או רשימת ערכים ידנית מימין-לשמאל; None = בלי.
    צבעי v2.0: רשת grid_blue, ספרות ink, כותרות כחולות, המרות ירוקות (מעוגן).
    RTL: התרגיל נכתב LTR — עמודה הימנית = אחדות. עטוף ב-span.ltr ב-HTML."""
    sign = _norm_op(op, grade)
    if sign == "−" and top < bottom:
        raise ValueError(f"חיסור ביסודי עם תוצאה שלילית: {top} − {bottom}")
    a, b = _digits_with_sep(top) if sep_comma else list(str(abs(top))), \
           _digits_with_sep(bottom) if sep_comma else list(str(abs(bottom)))
    res = top + bottom if sign == "+" else (top - bottom if sign == "−" else top * bottom)
    op = sign
    r = _digits_with_sep(res) if sep_comma else list(str(abs(res)))
    cols = max(len(a), len(b), len(r) if answer is True else 0) + 1  # +1 לעמודת סימן
    rows = 2 + (1 if answer is not False else 0)

    # --- שורת המרות + כותרות עמודות (כיתה ב׳) ---
    carry_vals = []
    if carry == "auto" and sign == "+":
        da, db = [int(c.rstrip(",")) for c in a], [int(c.rstrip(",")) for c in b]
        width = max(len(da), len(db))
        da = [0] * (width - len(da)) + da
        db = [0] * (width - len(db)) + db
        c_ = 0
        carry_vals = [0]  # העמודה הימנית ביותר — אין המרה נכנסת
        for i in range(width - 1, 0, -1):
            c_ = 1 if da[i] + db[i] + c_ >= 10 else 0
            carry_vals.insert(0, c_)
    elif isinstance(carry, (list, tuple)):
        carry_vals = list(carry)
    hdr_h = cell * 0.62 if headers else 0
    # תיבת ההמרה: 0.62·cell יצא "מקומט" — הספרה נגעה בדופן העליונה
    # (דיווח עין, אוגוסט 2026). 0.78·cell + מרכוז אנכי אמיתי של הספרה.
    cry_h = cell * 0.78 if carry_vals else 0
    y0 = 4 + hdr_h + cry_h
    w, h = cols * cell + 8, rows * cell + 8 + hdr_h + cry_h
    s = E(w, h)

    if headers:  # מימין לשמאל: הכותרת הראשונה מעל עמודת האחדות
        for j, t in enumerate(headers):
            x = w - 4 - (j + 1) * cell
            s.text(t, x + cell / 2, 4 + hdr_h - 8, size=font * 0.48,
                   color=header_color, rtl=True)
    if carry_vals:
        for j, cv in enumerate(carry_vals):  # carry_vals[0] = עמודה שמאלית ביותר
            if not cv:
                continue
            x = 4 + (cols - len(carry_vals) + j) * cell
            box_top = 4 + hdr_h + 1.5
            box_h = cry_h - 3
            s.rect(x + 3, box_top, cell - 6, box_h, sw=1.1, rx=3, stroke="#2E9E2E")
            # מרכוז אנכי: baseline = מרכז התיבה + ~0.36 מגובה הגליף
            fs = font * 0.55
            s.text(str(cv), x + cell / 2, box_top + box_h / 2 + fs * 0.36, size=fs,
                   bold=True, color="#2E9E2E")

    def row_cells(digs, y, sign=None, color=None):
        color = color or digit_color
        off = cols - len(digs)
        for j, ch in enumerate(digs):
            x = (off + j) * cell + 4
            s.text(ch, x + cell / 2, y + cell - 8, size=font, color=color)
        if sign:
            s.text(sign, 4 + cell / 2, y + cell - 8, size=font, color=color)

    if show_grid:
        for i in range(cols + 1):
            s.line((4 + i * cell, y0), (4 + i * cell, y0 + rows * cell), width_=0.5,
                   color=grid_color)
        for i in range(rows + 1):
            s.line((4, y0 + i * cell), (4 + cols * cell, y0 + i * cell), width_=0.5,
                   color=grid_color)
    row_cells(a, y0)
    row_cells(b, y0 + cell, sign=op)
    yline = y0 + 2 * cell
    s.line((4, yline), (4 + cols * cell, yline), width_=2)
    if answer is True:
        row_cells(r, y0 + 2 * cell)
    elif answer == "blank":
        pass  # הקו העבה = מקום לתשובה
    return s.render()


def long_division(dividend, divisor, answer="blank", cell=30, font=20,
                  line_color=PALETTE["blue"], digit_color=PALETTE["ink"]):
    """פיגום חילוק ארוך בפריסה הישראלית — תיקון הערת מורה (אוגוסט 2026):
    **המחולק משמאל, המחלק מימין**, ביניהם קו אנכי, וקו אופקי ("גג") מעל
    המחולק בלבד. המנה נכתבת מעל הגג, מיושרת לימין המחולק (אחדות מעל
    אחדות). הגרסה הקודמת (מחלק משמאל, נוסח הפורק) הייתה הפוכה מאופן
    הכתיבה שמלמדים בבתי הספר — אין להחזיר אותה.
    answer: 'blank' (מקום ריק למנה), True (מנה מודפסת).
    מחולק/מנה בני 4+ ספרות מקבלים פסיק-אלפים צמוד לספרה באותו תא.
    צבעי v2.0: גג וקו אנכי כחולים, ספרות ink."""
    q = dividend // divisor
    dvs = list(str(divisor))
    dvd = _digits_with_sep(dividend)
    w = (len(dvs) + len(dvd) + 2) * cell + 16
    h = 3 * cell + 12
    s = E(w, h)
    y0 = 8 + cell
    # מחולק משמאל
    x_dvd_start = 12
    x_dvd_end = x_dvd_start + len(dvd) * cell
    for j2, ch in enumerate(dvd):
        s.text(ch, x_dvd_start + j2 * cell + cell / 2, y0 + cell - 8, size=font,
               color=digit_color)
    # קו אנכי מימין למחולק + "גג" מעל המחולק בלבד
    s.line((x_dvd_end + 6, y0 - 4), (x_dvd_end + 6, y0 + cell), width_=1.8,
           color=line_color)
    s.line((x_dvd_start - 4, y0 - 4), (x_dvd_end + 6, y0 - 4), width_=1.8,
           color=line_color)
    # מחלק מימין לקו
    x_div = x_dvd_end + 6 + cell * 0.6
    for j2, ch in enumerate(dvs):
        s.text(ch, x_div + j2 * cell + cell / 2, y0 + cell - 8, size=font,
               color=digit_color)
    if answer is True:
        # מנה מעל הגג, אחדות מעל אחדות (יישור לימין המחולק)
        qd = _digits_with_sep(q)
        for j2, ch in enumerate(qd):
            s.text(ch, x_dvd_end - (len(qd) - j2) * cell + cell / 2, y0 - 10,
                   size=font, color=digit_color)
    return s.render()


def clock_face(hour, minute, r=44, numbers=True, hands=True,
               rim_color=PALETTE["blue"], face_fill="#F4FAFF",
               hour_color=PALETTE["ink"], minute_color=PALETTE["orange"]):
    """שעון חוגה. hour 1-12, minute 0-59. hands=False → תלמיד מצייר.
    צבעי v2.0: מסגרת כחולה, חוגה #F4FAFF, מחוג שעות ink, מחוג דקות כתום."""
    w = h = 2 * r + 16
    cx, cy = w / 2, h / 2
    s = E(w, h)
    s.circle(cx, cy, r, fill=face_fill, stroke=rim_color, sw=2.5)
    for m in range(60):
        a = math.pi / 2 - m * math.pi / 30
        rr = r - (8 if m % 5 == 0 else 4)
        s.line((cx + rr * math.cos(a), cy - rr * math.sin(a)),
               (cx + (r - 1) * math.cos(a), cy - (r - 1) * math.sin(a)),
               width_=1.6 if m % 5 == 0 else 0.8,
               color=PALETTE["ink"] if m % 5 == 0 else "#8FA8C0")
    if numbers:
        for n in range(1, 13):
            a = math.pi / 2 - n * math.pi / 6
            s.text(str(n), cx + (r - 16) * math.cos(a), cy - (r - 16) * math.sin(a) + 5,
                   size=13, color=PALETTE["ink"])
    if hands:
        am = math.pi / 2 - minute * math.pi / 30
        ah = math.pi / 2 - ((hour % 12) + minute / 60) * math.pi / 6
        s.line((cx, cy), (cx + (r - 24) * math.cos(ah), cy - (r - 24) * math.sin(ah)),
               width_=3.2, color=hour_color)
        s.line((cx, cy), (cx + (r - 12) * math.cos(am), cy - (r - 12) * math.sin(am)),
               width_=2, color=minute_color)
        s.circle(cx, cy, 2.5, fill=minute_color, sw=0)
    return s.render()


# ---------------------------------------------------------------- כסף
def coins(spec, r=17, gap=10, font=13):
    """שורת מטבעות: spec = [(ערך_בשקלים, כמות), ...] — למשל [(10,2),(1,3)].
    ערך עשרוני (0.5 = 50 אגורות) מודפס כ-'50 אג''.
    צבעי v2.0: מטבעות ₪ (ערך ≥ 1) זהב #F5C542 במסגרת #B8860B;
    אגורות (ערך < 1) נחושת #E8A06A במסגרת #B96A35; טקסט ink."""
    items = []
    for val, cnt in spec:
        items += [val] * cnt
    w = len(items) * (2 * r + gap) + gap
    h = 2 * r + gap * 2 + 8
    s = E(w, h)
    for i, val in enumerate(items):
        x = gap + r + i * (2 * r + gap)
        fill = PALETTE["gold"] if val >= 1 else "#E8A06A"
        stroke = "#B8860B" if val >= 1 else "#B96A35"
        s.circle(x, gap + r + 4, r, fill=fill, stroke=stroke, sw=1.8)
        # שורה אחת מרוכזת: "10 ₪" / "50 אג׳" — בלי סמל נפרד שנחתך בתחתית המטבע
        txt = f"{val:g} ₪" if val >= 1 else f"{int(round(val * 100))} אג׳"
        s.text(txt, x, gap + r + 9, size=font - 1, bold=True, color=PALETTE["ink"])
    return s.render()


# ------------------------------------------------------------ מסגרת-עשר
def ten_frame(filled, total=10, cell=34, dot_r=11, dot_colors=None,
              frame_color=PALETTE["teal"]):
    """מסגרת-עשר (2×5) עם filled עיגולים מלאים. total=20 לשתי מסגרות.
    צבעי v2.0: מסגרת teal; עיגולים 1–5 כתומים, 6–10 (והמסגרת השנייה) כחולים —
    ההבדל החזותי מדגיש את חצי-המסגרת (משמעות פדגוגית). dot_colors=(c1, c2)
    לעקיפה."""
    c_low, c_high = dot_colors or (PALETTE["orange"], PALETTE["blue"])
    frames = 2 if total > 10 else 1
    w = 5 * cell + 8
    h = frames * 2 * cell + 8 + (frames - 1) * 10
    s = E(w, h)
    idx = 0
    for f in range(frames):
        y0 = 4 + f * (2 * cell + 10)
        s.rect(4, y0, 5 * cell, 2 * cell, sw=2, stroke=frame_color)
        for i in range(1, 5):
            s.line((4 + i * cell, y0), (4 + i * cell, y0 + 2 * cell), width_=1,
                   color=frame_color)
        s.line((4, y0 + cell), (4 + 5 * cell, y0 + cell), width_=1,
               color=frame_color)
        for i in range(10):
            idx += 1
            if idx <= filled:
                cx = 4 + (i % 5) * cell + cell / 2
                cy = y0 + (i // 5) * cell + cell / 2
                s.circle(cx, cy, dot_r, fill=c_low if idx <= 5 else c_high, sw=0)
    return s.render()


# ---------------------------------------------------------- דיאגרמת עמודות
_BAR_FILLS = (PALETTE["blue"], PALETTE["orange"], PALETTE["teal"], PALETTE["gold"])
_BAR_STROKES = ("#175A9E", "#B4650F", "#0E7A6E", "#C29B1F")


def bar_chart(labels, values, plot_h=170, bar_w=44, gap=26, font=12,
              y_from=0, y_step=None, colors=None):
    """דיאגרמת עמודות: labels מתחת לציר ה-x (LTR), values = גבהי העמודות.
    plot_h: גובה שטח הציור בפיקסלים; הסקלה מחושבת ממנו (y_step = רווח שנאות).
    צבעי v2.0: עמודות בסבב כחול/כתום/teal/זהב עם מסגרת כהה תואמת; צירים ink.
    colors=(fills, strokes) לעקיפה."""
    fills, strokes = colors or (_BAR_FILLS, _BAR_STROKES)
    vmax = max(values)
    step = y_step or max(1, math.ceil(vmax / 5))
    top = math.ceil(vmax / step) * step
    h_unit = plot_h / (top - y_from)          # פיקסלים ליחידת ערך
    w = len(values) * (bar_w + gap) + 64
    h = plot_h + 64
    x0, y0 = 46, h - 34
    s = E(w, h)
    s.line((x0, y0 - plot_h - 8), (x0, y0), width_=1.8, color=PALETTE["ink"])  # ציר y
    s.line((x0, y0), (w - 10, y0), width_=1.8, color=PALETTE["ink"])           # ציר x
    v = y_from
    while v <= top:
        y = y0 - (v - y_from) * h_unit
        s.line((x0 - 4, y), (x0, y), width_=1.4, color=PALETTE["ink"])
        s.text(f"{v:g}", x0 - 8, y + 4, size=font - 1, anchor="end",
               color=PALETTE["ink"])
        v += step
    for i, (lab, val) in enumerate(zip(labels, values)):
        x = x0 + gap / 2 + i * (bar_w + gap)
        bh = (val - y_from) * h_unit
        s.rect(x, y0 - bh, bar_w, bh, fill=fills[i % len(fills)],
               stroke=strokes[i % len(strokes)], sw=1.6)
        s.text(str(lab), x + bar_w / 2, y0 + 16, size=font, color=PALETTE["ink"])
    return s.render()


# ------------------------------------------------------------ מכונת פעולות
def _norm_label(lbl, grade=None):
    """תווית פעולה במכונה (`"×2"`, `"+5"`) — הגליף לפי הכיתה."""
    if lbl and lbl[0] in "+-\u2212*xX\u00d7\u00b7\u2219\u22c5:/":
        return _norm_op(lbl[0], grade) + lbl[1:]
    return lbl


def machine(items, box_w=64, box_h=40, arrow=34, font=17, grade=None):
    """מכונת פעולות: items = רצף של תיבות/פעולות.
    כל פריט: ('box', '7') תיבה עם ערך / ('box', '') תיבה ריקה להשלמה /
    ('op', '+5') פעולה מעל החץ שמוביל לתיבה הבאה — הגליף מנורמל לפי
    `grade=` (`('op','*2')` → `x2` בג׳–ו׳, `×2` בב׳).
    צבעי v2.0: תיבות blue_light במסגרת כחולה, חצים כתומים, פעולה אדומה."""
    n = len(items)
    w = n * box_w + (n - 1) * arrow + 16
    h = box_h + 34
    s = E(w, h)
    for i, (kind, txt) in enumerate(items):
        x = 8 + i * (box_w + arrow)
        y = 24
        if kind == "box":
            s.rect(x, y, box_w, box_h, fill=PALETTE["blue_light"],
                   stroke=PALETTE["blue"], sw=1.8, rx=3)
            if txt:
                s.text(txt, x + box_w / 2, y + box_h - 13, size=font, bold=True,
                       color=PALETTE["ink"])
        if i < n - 1:
            x1 = x + box_w
            s.line((x1 + 2, y + box_h / 2), (x1 + arrow - 4, y + box_h / 2),
                   width_=1.6, color=PALETTE["orange"])
            s.path(f"M {x1+arrow-4} {y+box_h/2} l -7 -4 l 0 8 z",
                   fill=PALETTE["orange"], sw=0)
            if kind == "op":  # הפעולה יושבת מעל החץ שיוצא מהפריט הזה
                s.text(_norm_label(txt, grade), x1 + arrow / 2, y - 6,
                       size=font - 3,
                       color=PALETTE["red"], bold=True)
    return s.render()


# ------------------------------------------------------------ שברים בצורה
def fraction_shape(kind="rect", parts=4, shaded=1, w=150, h=None, font=13,
                   shade_color="#F2A65A", shade_stroke="#C46F1A"):
    """צורה מחולקת ל-parts חלקים שווים, shaded מהם צבועים.
    kind: 'rect' (פסים אנכיים), 'circle' (פרוסות), 'row' (פס אופקי יחיד).
    לתרגילי 'צבעו חצי/שליש/רבע מהצורה' — ה-shaded=0 נותן צורה ריקה לצביעה.
    צבעי v2.0: צבוע #F2A65A במסגרת #C46F1A (במקום אפור), לא-צבוע לבן."""
    h = h or (60 if kind != "circle" else 110)
    if kind == "circle":
        s = E(w + 10, h + 10)
        cx, cy, r = w / 2 + 5, h / 2 + 5, min(w, h) / 2 - 4
        for i in range(parts):
            a0 = math.pi / 2 - 2 * math.pi * i / parts
            a1 = math.pi / 2 - 2 * math.pi * (i + 1) / parts
            large = 1 if abs(a1 - a0) > math.pi else 0
            x0, y0 = cx + r * math.cos(a0), cy - r * math.sin(a0)
            x1, y1 = cx + r * math.cos(a1), cy - r * math.sin(a1)
            fill = shade_color if i < shaded else "white"
            s.path(f"M {cx} {cy} L {x0:.1f} {y0:.1f} A {r} {r} 0 {large} 0 {x1:.1f} {y1:.1f} Z",
                   fill=fill, stroke=shade_stroke, sw=1.6)
        s.circle(cx, cy, r, stroke=shade_stroke, sw=1.8)
        return s.render()
    rows, cols = (1, parts) if kind == "row" else _grid_for(parts)
    h = h or 60
    s = E(w + 10, h + 10)
    cell_w, cell_h = w / cols, h / rows
    for i in range(parts):
        r_, c_ = divmod(i, cols)
        fill = shade_color if i < shaded else "white"
        s.rect(5 + c_ * cell_w, 5 + r_ * cell_h, cell_w, cell_h, fill=fill,
               stroke=shade_stroke, sw=1.5)
    return s.render()


def _grid_for(n):
    """רשת ריבועית כמעט ל-n חלקים: (rows, cols)."""
    cols = math.ceil(math.sqrt(n))
    rows = math.ceil(n / cols)
    return rows, cols


# ------------------------------------------------------------ דיאגרמת קו
def line_chart(labels, values, plot_h=170, font=12, y_from=None, y_step=None,
               degree=False):
    """דיאגרמת קו (למשל טמפרטורה לאורך שבוע). degree=True מוסיף ° לתוויות ציר.
    צבעי v2.0: קו כחול (2.2), נקודות כתומות, צירים ink."""
    vmin, vmax = min(values), max(values)
    y0v = y_from if y_from is not None else math.floor(vmin)
    step = y_step or 1
    top = math.ceil(vmax / step) * step
    h_unit = plot_h / max(top - y0v, 1e-9)
    w = len(values) * 56 + 64
    h = plot_h + 64
    x0, y0 = 46, h - 34
    s = E(w, h)
    s.line((x0, y0 - plot_h - 8), (x0, y0), width_=1.8, color=PALETTE["ink"])
    s.line((x0, y0), (w - 10, y0), width_=1.8, color=PALETTE["ink"])
    v = y0v
    while v <= top:
        y = y0 - (v - y0v) * h_unit
        s.line((x0 - 4, y), (x0, y), width_=1.4, color=PALETTE["ink"])
        s.text(f"{v:g}{'°' if degree else ''}", x0 - 8, y + 4, size=font - 1,
               anchor="end", color=PALETTE["ink"])
        v += step
    pts = []
    for i, (lab, val) in enumerate(zip(labels, values)):
        x = x0 + 28 + i * 56
        y = y0 - (val - y0v) * h_unit
        pts.append((x, y))
        s.line((x, y0), (x, y0 + 4), width_=1.4, color=PALETTE["ink"])
        s.text(str(lab), x, y0 + 16, size=font, color=PALETTE["ink"])
    d = "M " + " L ".join(f"{p[0]:.1f} {p[1]:.1f}" for p in pts)
    s.path(d, stroke=PALETTE["blue"], sw=2.2)
    for p in pts:
        s.circle(p[0], p[1], 3, fill=PALETTE["orange"], sw=0)
    return s.render()


# ------------------------------------------------------------ פרמידת חיבור
_PYR_ROW_FILLS = (PALETTE["teal_light"], PALETTE["orange_light"],
                  PALETTE["blue_light"])


def pyramid(bricks, cell=52, font=17):
    """פרמידת חיבור: bricks = רשימת שורות מלמטה למעלה; כל שורה רשימה של
    ערכים או '' (לבנה ריקה להשלמה). שורה עליונה = לבנה אחת.
    bricks[0] = שורת הבסיס (הכי הרבה לבנים).
    צבעי v2.0: מסגרות לבנים teal; מילוי בסבב teal_light/orange_light/blue_light
    לפי שורה — מבדל רמות בפרמידה (משמעות פדגוגית)."""
    n = len(bricks[0])
    w = n * cell + 8
    h = len(bricks) * (cell * 0.72) + 8
    s = E(w, h)
    for ri, row in enumerate(bricks):
        y = h - 4 - (ri + 1) * cell * 0.72
        x0 = 4 + (n - len(row)) * cell / 2
        for ci, val in enumerate(row):
            x = x0 + ci * cell
            s.rect(x, y, cell, cell * 0.72, fill=_PYR_ROW_FILLS[ri % 3],
                   stroke=PALETTE["teal"], sw=1.6)
            if val != "":
                s.text(str(val), x + cell / 2, y + cell * 0.72 - 14, size=font,
                       bold=True, color=PALETTE["ink"])
    return s.render()


# ------------------------------------------------------------ סרגל
def ruler(cm, mm=True, cell=12, font=9, object_len=None):
    """סרגל באורך cm סנטימטרים עם שנתות מ"מ. object_len: אם נתון, משורטט
    פס מעל הסרגל באורך object_len ס"מ (תרגיל מדידה — 'כמה ארך הקו?').
    צבעי v2.0: גוף הסרגל #FDEBC8 במסגרת #B96A35 (סרגל עץ), שנתות ink,
    פס העצם orange_light במסגרת כתומה."""
    w = cm * cell + 20
    h = 60
    s = E(w, h)
    y = 30
    s.rect(10, y, cm * cell, 22, fill="#FDEBC8", stroke="#B96A35", sw=1.8)
    for m in range(cm * 10 + 1):
        x = 10 + m * cell / 10
        th = 10 if m % 10 == 0 else (6 if m % 5 == 0 else 3.5)
        s.line((x, y), (x, y + th), width_=1.2 if m % 10 == 0 else 0.7,
               color=PALETTE["ink"])
        if m % 10 == 0:
            s.text(str(m // 10), x, y + 20, size=font, color=PALETTE["ink"])
    if object_len:
        s.rect(10, y - 16, object_len * cell, 8, fill=PALETTE["orange_light"],
               stroke=PALETTE["orange"], sw=1.2)
    return s.render()


# ------------------------------------------------------------ אמנות ספרות
def digit_tracing_row(digit, count=7, cell_w=56, row_h=64, font=44):
    """שורת אמנות ספרה (כיתה א׳): שלושה קווים (שני קווים מקווקוים + קו בסיס
    מלא), ספרה מודגמת אחת מלאה, ואז count חזרות בקו מקווקו לעיטוף.
    המקווקו נעשה ב-stroke-dasharray על טקסט — עובד ב-Chromium וב-WeasyPrint.
    צבעי v2.0: קווי הדרכה מקווקוים #9CC3E5, קו בסיס #666, ספרה מודגמת ink,
    ספרת עיטוף במתאר #888 (עיפרון — ללא שינוי)."""
    w = (count + 1) * cell_w + 12
    h = row_h + 14
    s = E(w, h)
    y_base = h - 16
    y_mid = y_base - row_h * 0.45
    y_top = y_base - row_h * 0.8
    s.line((4, y_top), (w - 4, y_top), dashed=True, width_=0.8, color="#9CC3E5")
    s.line((4, y_mid), (w - 4, y_mid), dashed=True, width_=0.8, color="#9CC3E5")
    s.line((4, y_base), (w - 4, y_base), width_=1.1, color="#666")
    for i in range(count + 1):
        x = 6 + i * cell_w + cell_w / 2
        if i == 0:  # מודגם מלא
            s.text(str(digit), x, y_base - 4, size=font, bold=True,
                   color=PALETTE["ink"])
        else:  # עיטוף מקווקו
            s.parts.append(
                f'<text x="{x:.1f}" y="{y_base - 4:.1f}" font-size="{font}"'
                f' text-anchor="middle" font-family="David Libre" fill="none"'
                f' stroke="#888" stroke-width="1" stroke-dasharray="3,2">{digit}</text>')
    return s.render()


# ------------------------------------------------------------ כפל חוזר (מערך)
def dot_array(rows, cols, dot_r=8, gap=None, filled=None,
              fill_color=PALETTE["blue"], empty_stroke="#9AA5B1"):
    """מערך נקודות/עיגולים rows×cols (מודל כפל). filled: כמה ראשונים מלאים.
    צבעי v2.0: מלאים כחולים (fill_color לעקיפה), ריקים לבנים במסגרת #9AA5B1."""
    gap = gap or dot_r * 3
    w = cols * gap + 16
    h = rows * gap + 16
    s = E(w, h)
    for i in range(rows):
        for j in range(cols):
            k = i * cols + j
            if filled is None or k < filled:
                s.circle(8 + j * gap + dot_r, 8 + i * gap + dot_r, dot_r,
                         fill=fill_color, stroke=fill_color, sw=1.4)
            else:
                s.circle(8 + j * gap + dot_r, 8 + i * gap + dot_r, dot_r,
                         fill="white", stroke=empty_stroke, sw=1.4)
    return s.render()


# -------------------------------------------- איורים פונקציונליים (v2.0)
_GROUP_BG = (PALETTE["blue_light"], PALETTE["orange_light"],
             PALETTE["teal_light"], PALETTE["pink_light"])
_GROUP_BORDER = ("#9DC3E8", "#EDBA85", "#8FD0C6", "#E4A9DC")
_BALLOON_COLORS = (PALETTE["gold"], PALETTE["teal"], PALETTE["blue"],
                   PALETTE["orange"])
_BALLOON_STROKES = ("#B8860B", "#0E6E63", "#175A9E", "#B4650F")


def _draw_item(s, kind, cx, cy, r, idx):
    """פריט איור בודד מרוכז ב-(cx, cy) ברדיוס r. מספרים/צורות בלבד — אין טקסט."""
    if kind == "apple":
        s.circle(cx, cy + r * 0.15, r * 0.82, fill=PALETTE["red"],
                 stroke="#8F0000", sw=1.2)
        s.line((cx, cy - r * 0.55), (cx + r * 0.18, cy - r * 1.05),
               width_=2, color="#8B5A2B")
        s.ellipse(cx + r * 0.5, cy - r * 0.95, r * 0.42, r * 0.2,
                  fill=PALETTE["green"], stroke="#1F7A1F", sw=1, rot=-25)
    elif kind == "balloon":
        col = _BALLOON_COLORS[idx % len(_BALLOON_COLORS)]
        st = _BALLOON_STROKES[idx % len(_BALLOON_STROKES)]
        s.ellipse(cx, cy - r * 0.25, r * 0.72, r * 0.88, fill=col, stroke=st, sw=1.2)
        s.path(f"M {cx:.1f} {cy + r*0.62:.1f} l -3 5 l 6 0 z", fill=col, stroke=st,
               sw=0.8)
        s.line((cx, cy + r * 0.7), (cx, cy + r * 1.25), width_=1, color="#888")
    elif kind == "star":
        pts = []
        for k in range(10):
            ang = math.pi / 2 + k * math.pi / 5
            rr = r * 0.95 if k % 2 == 0 else r * 0.42
            pts.append((cx + rr * math.cos(ang), cy - rr * math.sin(ang)))
        d = "M " + " L ".join(f"{p[0]:.1f} {p[1]:.1f}" for p in pts) + " Z"
        s.path(d, fill=PALETTE["gold"], stroke="#B8860B", sw=1.2)
    elif kind == "fish":
        s.path(f"M {cx - r*0.65:.1f} {cy:.1f} L {cx - r*1.25:.1f} {cy - r*0.5:.1f}"
               f" L {cx - r*1.25:.1f} {cy + r*0.5:.1f} Z",
               fill=PALETTE["teal"], stroke="#0E6E63", sw=1.2)
        s.ellipse(cx, cy, r * 0.85, r * 0.55, fill=PALETTE["teal"],
                  stroke="#0E6E63", sw=1.2)
        s.circle(cx + r * 0.45, cy - r * 0.1, r * 0.1, fill=PALETTE["ink"], sw=0)
    elif kind == "heart":
        d = (f"M {cx:.1f} {cy + r*0.75:.1f} "
             f"C {cx - r*1.3:.1f} {cy - r*0.05:.1f} {cx - r*0.55:.1f} {cy - r*1.1:.1f} "
             f"{cx:.1f} {cy - r*0.35:.1f} "
             f"C {cx + r*0.55:.1f} {cy - r*1.1:.1f} {cx + r*1.3:.1f} {cy - r*0.05:.1f} "
             f"{cx:.1f} {cy + r*0.75:.1f} Z")
        s.path(d, fill=PALETTE["red"], stroke="#8F0000", sw=1.2)
    elif kind == "flower":
        s.line((cx, cy + r * 0.2), (cx, cy + r * 1.15), width_=2.0, color=PALETTE["green"])
        for k in range(5):
            ang = k * 2 * math.pi / 5 - math.pi / 2
            px = cx + r * 0.52 * math.cos(ang)
            py = cy - r * 0.15 + r * 0.52 * math.sin(ang)
            s.circle(px, py, r * 0.36, fill="#F090F0", stroke=PALETTE["purple"], sw=1.0)
        s.circle(cx, cy - r * 0.15, r * 0.32, fill=PALETTE["gold"], stroke="#B8860B", sw=1.1)
    elif kind == "marble":
        col = _BALLOON_COLORS[idx % len(_BALLOON_COLORS)]
        st = _BALLOON_STROKES[idx % len(_BALLOON_STROKES)]
        s.circle(cx, cy, r * 0.82, fill=col, stroke=st, sw=1.4)
        s.ellipse(cx - r * 0.25, cy - r * 0.25, r * 0.28, r * 0.16,
                  fill="#FFFFFF", stroke="none", sw=0, rot=-30)
    elif kind == "cookie":
        s.circle(cx, cy, r * 0.85, fill="#E8A06A", stroke="#8B5A2B", sw=1.3)
        for dx, dy in ((-0.32, -0.25), (0.28, -0.22), (-0.18, 0.28), (0.30, 0.22), (0.0, 0.0)):
            s.circle(cx + r * dx, cy + r * dy, r * 0.12, fill="#4A2C11", stroke="none", sw=0)
    elif kind == "pencil":
        s.rect(cx - r * 0.26, cy - r * 0.55, r * 0.52, r * 1.1,
               fill=PALETTE["gold"], stroke="#B8860B", sw=1.1)
        s.rect(cx - r * 0.26, cy - r * 0.85, r * 0.52, r * 0.3,
               fill="#F090F0", stroke="#8F0000", sw=1.0)
        s.path(f"M {cx - r*0.26:.1f} {cy + r*0.55:.1f} L {cx + r*0.26:.1f} {cy + r*0.55:.1f} "
               f"L {cx:.1f} {cy + r*1.05:.1f} Z",
               fill="#FDE9D2", stroke="#8B5A2B", sw=1.0)
        s.circle(cx, cy + r * 0.96, r * 0.09, fill=PALETTE["ink"], sw=0)
    elif kind == "book":
        s.rect(cx - r * 0.65, cy - r * 0.78, r * 1.3, r * 1.56,
               fill=PALETTE["blue"], stroke="#175A9E", sw=1.3, rx=2)
        s.line((cx - r * 0.38, cy - r * 0.78), (cx - r * 0.38, cy + r * 0.78),
               width_=1.4, color="#FFFFFF")
        s.rect(cx - r * 0.18, cy - r * 0.42, r * 0.62, r * 0.32,
               fill=PALETTE["yellow_light"], stroke="#175A9E", sw=0.8)
    elif kind == "car":
        s.rect(cx - r * 0.88, cy - r * 0.05, r * 1.76, r * 0.55,
               fill=PALETTE["orange"], stroke="#B4650F", sw=1.2, rx=3)
        s.path(f"M {cx - r*0.55:.1f} {cy - r*0.05:.1f} L {cx - r*0.32:.1f} {cy - r*0.55:.1f} "
               f"L {cx + r*0.35:.1f} {cy - r*0.55:.1f} L {cx + r*0.58:.1f} {cy - r*0.05:.1f} Z",
               fill=PALETTE["blue_light"], stroke="#B4650F", sw=1.1)
        s.circle(cx - r * 0.48, cy + r * 0.52, r * 0.26, fill=PALETTE["ink"], stroke="#555", sw=1.0)
        s.circle(cx + r * 0.48, cy + r * 0.52, r * 0.26, fill=PALETTE["ink"], stroke="#555", sw=1.0)


_OBJECT_KINDS = (
    "apple", "balloon", "star", "fish", "heart",
    "flower", "marble", "cookie", "pencil", "book", "car",
)


def object_groups(kind, groups, max_per_row=10, scale=1.0):
    """קבוצות עצמים מצוירות — איור פונקציונלי לספירה/חיבור/כפל (אין טקסט!).
    kind: 'apple' (תפוח) / 'balloon' (בלון) / 'star' (כוכב) / 'fish' (דג) /
    'heart' (לב) / 'flower' (פרח) / 'marble' (גולה) / 'cookie' (עוגייה) /
    'pencil' (עיפרון) / 'book' (ספר) / 'car' (מכונית).
    groups: רשימת מספרים — [3, 4] מצייר שתי קבוצות, של 3 ושל 4.
    כל קבוצה על רקע מלבני מעוגל בפסטל (סבב blue_light/orange_light/teal_light/
    pink_light) כדי שהקיבוץ יהיה מפורש חזותית — זה הפונקציונליות: התלמיד
    סופר פריטים בקבוצה ומשלים תרגיל.
    max_per_row: מקסימום פריטים בשורה בתוך קבוצה (גלישה פנימית).
    scale: מקטין/מגדיל את כל הרכיב. זורק ValueError אם שורה בודדת של קבוצה
    תעלה על 640px בסקלה הנתונה (כלל ה-650px)."""
    if kind not in _OBJECT_KINDS:
        raise ValueError(f"object_groups: kind לא מוכר {kind!r} — "
                         f"{'/'.join(_OBJECT_KINDS)}")
    if not groups:
        raise ValueError("object_groups: groups ריקה")
    cell_w = 42 * scale
    cell_h = 48 * scale
    r = 15 * scale
    pad = 8
    gap = 14
    max_w = 650

    layouts = []
    for gi, count in enumerate(groups):
        if count < 1:
            raise ValueError(f"object_groups: קבוצה {gi} ריקה (count={count})")
        per_row = min(count, max_per_row)
        row_w = per_row * cell_w + 2 * pad
        if row_w > 640:
            raise ValueError(
                f"object_groups: שורה של {per_row} פריטים ב-scale={scale} "
                f"רחבה {row_w:.0f}px > 640px — הקטן scale או max_per_row")
        rows = math.ceil(count / per_row)
        layouts.append({"gi": gi, "count": count, "per_row": per_row,
                        "gw": row_w, "gh": rows * cell_h + 2 * pad})

    # פריסת קבוצות משמאל לימין עם שבירת שורה ב-650px
    placed = []
    x = y = row_h = 0
    total_w = 0
    for lay in layouts:
        if x > 0 and x + lay["gw"] > max_w:
            x = 0
            y += row_h + gap
            row_h = 0
        placed.append((x, y, lay))
        x += lay["gw"] + gap
        row_h = max(row_h, lay["gh"])
        total_w = max(total_w, x - gap)
    total_h = y + row_h
    s = E(math.ceil(total_w + 2), math.ceil(total_h + 2))
    for gx, gy, lay in placed:
        gi = lay["gi"]
        s.rect(gx + 1, gy + 1, lay["gw"], lay["gh"],
               fill=_GROUP_BG[gi % len(_GROUP_BG)],
               stroke=_GROUP_BORDER[gi % len(_GROUP_BORDER)], sw=1.2, rx=10)
        for i in range(lay["count"]):
            row, col = divmod(i, lay["per_row"])
            in_row = min(lay["per_row"], lay["count"] - row * lay["per_row"])
            xoff = pad + (lay["gw"] - 2 * pad - in_row * cell_w) / 2
            cx = gx + 1 + xoff + col * cell_w + cell_w / 2
            cy = gy + 1 + pad + row * cell_h + cell_h / 2
            _draw_item(s, kind, cx, cy, r, i)
    return s.render()


def place_value_blocks(hundreds, tens, ones, cell=10):
    """קוביות דינס (בסיס עשרוני) — איור פונקציונלי למבנה המספר (אין טקסט!).
    מאות = לוחית 10×10 (זהב #F5C542/#B8860B), עשרות = מקל 1×10
    (ירוק #7CC47C/#2E9E2E), אחדות = קובייה (כתום #F2A65A/#C46F1A).
    סדר משמאל לימין: מאות, עשרות, אחדות — תואם את כיוון כתיבת המספר.
    קווי הרשת הפנימיים מצוירים — התלמיד סופר יחידות מתוך האיור.
    cell: צלע יחידה בפיקסלים (10 ⇒ לוחית מאה ברוחב 100px)."""
    flat = 10 * cell
    gap = 8
    top = 6
    h = flat + 12
    # רוחב מלא: רווח אחרון לא נספר
    w = 12
    if hundreds:
        w += hundreds * (flat + gap) - gap
        if tens or ones:
            w += gap
    if tens:
        w += tens * (cell + 5) - 5
        if ones:
            w += 5
    if ones:
        w += ones * (cell + 5) - 5
    if w > 650:
        raise ValueError(
            f"place_value_blocks({hundreds},{tens},{ones}, cell={cell}): "
            f"רוחב {w}px > 650px — WeasyPrint יחתוך את האיור בקצה העמוד "
            f"והתלמיד יראה מספר שגוי. פצל לשני איורים (מאות בנפרד) או "
            f"הקטן cell (עבור 999 נדרש cell=4 — גבולי לספירה; עדיף פיצול).")
    s = E(w, h)
    x = 6
    for _ in range(hundreds):
        s.rect(x, top, flat, flat, fill=PALETTE["gold"], stroke="#B8860B", sw=1.6)
        for i in range(1, 10):
            s.line((x + i * cell, top), (x + i * cell, top + flat), width_=0.5,
                   color="#B8860B")
            s.line((x, top + i * cell), (x + flat, top + i * cell), width_=0.5,
                   color="#B8860B")
        x += flat + gap
    for _ in range(tens):
        s.rect(x, top, cell, flat, fill="#7CC47C", stroke="#2E9E2E", sw=1.4)
        for i in range(1, 10):
            s.line((x, top + i * cell), (x + cell, top + i * cell), width_=0.5,
                   color="#2E9E2E")
        x += cell + 5
    for _ in range(ones):
        s.rect(x, top + flat - cell, cell, cell, fill="#F2A65A",
               stroke="#C46F1A", sw=1.4)
        x += cell + 5
    return s.render()


if __name__ == "__main__":
    print(number_line(156, 161, blanks=[159, 160]))
    print(vertical_problem(3725, 845, op="−", answer=True))
    print(clock_face(3, 30))
    print(coins([(10, 1), (5, 1), (1, 2), (0.5, 1)]))
    print(ten_frame(7))
    print(bar_chart(["2007", "2008"], [1000, 1200], y_step=200))
    print(machine([("box", "7"), ("op", "+5"), ("box", ""), ("op", "*2"),
                   ("box", "")], grade="ג"))
    print(long_division(96, 4, answer=True))
    print(dot_array(3, 5))
    print(fraction_shape("rect", 4, 1))
    print(fraction_shape("circle", 3, 0))
    print(line_chart(["ראשון", "שני", "שלישי", "רביעי"], [20, 21, 19, 21], degree=True))
    print(pyramid([["2", "3", "", "5"], ["5", "", ""], ["", "19"], [""]]))
    print(ruler(10, object_len=6))
    print(digit_tracing_row(7))
    print(object_groups("apple", [3, 4]))
    print(object_groups("balloon", [5, 2, 6], scale=0.9))
    print(object_groups("star", [7], max_per_row=4))
    print(object_groups("fish", [2, 3]))
    print(object_groups("heart", [5, 5]))
    print(place_value_blocks(2, 3, 5))
    print(place_value_blocks(1, 0, 4, cell=12))
